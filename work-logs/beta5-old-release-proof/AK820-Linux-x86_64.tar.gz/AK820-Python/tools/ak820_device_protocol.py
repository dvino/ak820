"""Restricted VIA/Vial adapter. Importing this module never imports HID."""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import re
import sys
import time
import lzma

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(ROOT / 'qmk-8051-ak820/util'))
import pack_ak820 as pack
import ak820_diagnose as diag
import ak820_tool as transport
import ak820_extension_settings as extensions
import ak820_profiles as profiles


def require(ok, message):
    if not ok:
        raise ValueError(message)


def bind(release: Path, session: Path, approval: Path):
    """Validate reviewed release and personal recovery inputs before opening HID."""
    spec = importlib.util.spec_from_file_location('ak820_test_installer', ROOT / 'tools/installer/ak820.py')
    installer = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = installer
    try:
        spec.loader.exec_module(installer)
    except BaseException:
        sys.modules.pop(spec.name, None)
        raise
    installer.BUNDLE, installer.APPROVAL = release, approval
    manifest = json.loads((release / 'installer-release.json').read_text(encoding='utf-8'))
    installer.RELEASE = manifest['release']
    installer._load_release(release, approval, approved=True)
    build_report = json.loads((release / 'reports/build-report.json').read_text(encoding='utf-8'))
    configuration = build_report.get('configuration')
    require(isinstance(configuration, dict), 'Missing approved build configuration')
    selected = (profiles.validate_configuration(configuration)
                if configuration.get('profile') in profiles.RELEASE_PROFILES
                else profiles.validate_legacy_configuration(configuration))
    schema = selected['nvm_schema']
    images, payload, backup = transport.session_image(session, 'permanent', target_build_id=schema)
    pack.validate_native(backup)
    for key, name in (('ihx_sha256', 'firmware/application.ihx'), ('map_sha256', 'firmware/application.map')):
        require(images.get(key) == pack.digest((release / name).read_bytes()), 'Personal image belongs to a different build')
    code = diag.diagnostic_build(release / 'firmware/application.ihx', release / 'firmware/application.map',
                                 release / 'reports/build-report.json')
    # The manifest binds CODE, while the personal payload binds its own NVM.
    require(all(payload[a-pack.APP_START] == v for a, v in code.items()
                if pack.APP_START <= a < pack.CODE_END), 'Personal payload CODE differs from release')
    return {'combo_media': selected.get('compact_controls_version') == 2,
            'settings_record_version': selected.get('compact_controls_version', 1), 'nvm_schema': schema, 'release': manifest['release'], 'release_dir': str(release.resolve()),
            'session': str(session.resolve()), 'payload_sha256': pack.digest(payload),
            'backup_sha256': pack.digest(backup), 'payload': payload, 'backup': backup,
            'code': code, 'definition': json.loads((release / 'reference/vial.json').read_text(encoding='utf-8'))}


class DeviceAPI:
    def __init__(self, binding, output, app_factory=None, *, allow_writes=False):
        self.binding, self.output = binding, output
        require(type(allow_writes) is bool, 'allow_writes must be an explicit boolean')
        self.allow_writes = allow_writes
        self.trace = (output / 'transport.jsonl').open('a', encoding='utf-8')
        self.app = None
        try:
            if app_factory is not None:
                self.app = app_factory()
            else:
                selected = transport.select_application()
                require((selected.get('vendor_id'), selected.get('product_id'), selected.get('usage_page'), selected.get('usage'))
                        == (0x320F, 0x505B, 0xFF60, 0x61), 'Expected exactly one Vial application')
                self.app = transport.Application(selected)
        except Exception:
            self.trace.close()
            raise
        self.baseline = None
        self.pending = None

    def close(self):
        try:
            if self.app is not None:
                self.app.close()
        finally:
            self.trace.close()

    def packet(self, *values):
        return bytes(values) + bytes(32-len(values))

    def exchange(self, packet):
        self._validate_request(packet)
        row = {'request_hex': packet.hex()}
        try:
            reply = bytes(self.app.raw(packet))
            row['reply_hex'] = reply.hex()
            require(len(reply) == 32, 'Short protocol response')
            return reply
        except Exception as exc:
            row['error'] = repr(exc)
            raise
        finally:
            self.trace.write(json.dumps(row)+'\n'); self.trace.flush()

    def _validate_request(self, packet):
        """Accept only fixed, typed VIA/Vial requests used by this adapter."""
        require(isinstance(packet, bytes) and len(packet) == 32, 'Protocol request must be exactly 32 bytes')
        command, sub = packet[0], packet[1]
        zero_tail = lambda start: packet[start:] == bytes(32-start)
        write = False
        if command == 1:
            require(zero_tail(1), 'Malformed protocol-version request')
        elif command == 2:
            require(sub == 2 and zero_tail(2), 'Unknown or malformed keyboard-value request')
        elif command == 3:
            write = True
            require(sub == 2 and packet[2:5] == bytes(3) and zero_tail(6),
                    'Unknown or malformed keyboard-value setter')
        elif command == 4:
            require(packet[1] < 6 and packet[2] < 16 and packet[3] < 6 and zero_tail(4), 'Malformed key getter')
        elif command == 5:
            write = True
            require(packet[1] < 6 and packet[2] < 16 and packet[3] < 6 and zero_tail(6), 'Malformed key setter')
        elif command == 7:
            write = True
            if sub == 0x41:
                require(zero_tail(8), 'Malformed RGB setter')
            elif sub == 0x43:
                require(packet[2] == 1 and packet[3] == 82 and any(packet[4:6]) and zero_tail(10), 'Malformed Direct begin')
            elif sub == 0x44:
                require(any(packet[2:4]) and 1 <= packet[5] <= 8 and packet[4] <= 82-packet[5]
                        and zero_tail(6+3*packet[5]), 'Malformed Direct chunk')
            else:
                require(sub in (0x45, 0x46) and any(packet[2:4]) and zero_tail(4), 'Unknown or malformed Direct setter')
        elif command == 8:
            require(sub in (0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47), 'Unknown VialRGB getter')
            if sub in (0x40, 0x41, 0x43, 0x45, 0x47): require(zero_tail(2), 'Malformed VialRGB getter')
            elif sub == 0x42: require(zero_tail(4), 'Malformed VialRGB effect query')
            elif sub == 0x46:
                require(1 <= packet[7] <= 7 and packet[6] <= 82-packet[7] and zero_tail(8), 'Malformed Direct read')
            else: require(packet[2] < 82 and packet[3] == 0 and zero_tail(4), 'Malformed VialRGB LED query')
        elif command == 9:
            write = True
            require(zero_tail(1), 'Malformed RGB save request')
        elif command in (12, 13):
            require(zero_tail(1), 'Malformed macro metadata getter')
        elif command == 14:
            offset, count = int.from_bytes(packet[1:3], 'big'), packet[3]
            require(1 <= count <= 28 and offset <= 8192-count and zero_tail(4), 'Malformed macro getter')
        elif command == 15:
            write = True
            offset, count = int.from_bytes(packet[1:3], 'big'), packet[3]
            require(1 <= count <= 28 and offset <= 8192-count and zero_tail(4+count), 'Malformed macro upload chunk')
        elif command == 17:
            require(zero_tail(1), 'Malformed layer-count getter')
        elif command == 253:
            require(sub in (0, 1), 'Unknown FD diagnostic command')
            if sub == 0:
                address, count = int.from_bytes(packet[2:4], 'big'), packet[4]
                require(1 <= count <= 27 and address <= 65536-count and zero_tail(5), 'Malformed FD00 read')
            else: require(zero_tail(2), 'Malformed FD01 status request')
        elif command == 254:
            require(sub in (0, 1, 2, 3, 4, 9, 10, 11, 12, 13), 'Unknown FE Vial command')
            if sub in (0, 1): require(zero_tail(2), 'Malformed Vial metadata request')
            elif sub == 2: require(packet[4:6] == bytes(2) and zero_tail(6), 'Malformed Vial definition page request')
            elif sub == 3: require(packet[2] < 6 and packet[3] == 0 and zero_tail(4), 'Malformed encoder getter')
            elif sub in (9, 10, 11, 12):
                self._require_extension_schema()
                qsid = int.from_bytes(packet[2:4], 'little')
                if sub == 9:
                    require(zero_tail(4), 'Malformed settings query')
                elif sub == 12:
                    write = True
                    require(zero_tail(2), 'Malformed settings reset')
                else:
                    require(qsid in extensions.FIELDS, 'Unknown settings ID')
                    width = extensions.FIELDS[qsid][1]
                    if sub == 10:
                        require(zero_tail(4), 'Malformed settings getter')
                    else:
                        write = True
                        extensions.field_value(qsid, int.from_bytes(packet[4:4+width], 'little'))
                        require(zero_tail(4+width), 'Malformed settings setter')
            elif sub == 13:
                require(packet[2] in (0, 1, 2, 3, 4, 5, 6), 'Unknown dynamic operation')
                if packet[2] in (1, 2, 5, 6):
                    self._require_extension_schema()
                if packet[2] == 0:
                    require(zero_tail(3), 'Malformed Combo count request')
                else:
                    require(packet[3] < 8, 'Invalid Combo index')
                    if packet[2] in (1, 3, 5):
                        require(zero_tail(4), 'Malformed Combo getter')
                    else:
                        write = True
                        if packet[2] == 4:
                            self.validate_combo(packet[4:14])
                        else:
                            extensions.validate_entry('tap_dance' if packet[2] == 2 else 'key_overrides', packet[4:14])
                        require(zero_tail(14), 'Malformed Combo setter')
            else:
                write = True
                require(packet[2] < 6 and packet[3] == 0 and packet[4] in (0, 1) and zero_tail(7), 'Malformed encoder setter')
        else:
            raise ValueError('Forbidden command')
        if write:
            require(self.allow_writes, 'Writes are disabled for this DeviceAPI instance')

    def _require_extension_schema(self):
        payload = self.binding.get('payload', b'')
        offset = pack.NVM_START - pack.APP_START + 37
        require(int.from_bytes(payload[offset:offset+3], 'little') == extensions.SCHEMA,
                'Typed extensions require a schema03 bound image')

    def _require_writes(self):
        require(self.allow_writes, 'Writes are disabled for this DeviceAPI instance')

    def read_code(self, address, size):
        require(0 <= address <= 65536 and 0 <= size <= 65536 and address <= 65536-size,
                'Invalid CODE read range')
        data = bytearray()
        for delta in range(0, size, 27):
            at, count = address+delta, min(27, size-delta)
            request = self.packet(253, 0, at >> 8, at & 255, count)
            reply = self.exchange(request)
            require(reply[:5] == request[:5], 'FD00 response mismatch')
            data.extend(reply[5:5+count])
        return bytes(data)

    def boot_liveness(self):
        previous = None
        samples = []
        try:
            deadline = time.monotonic()+5
            while time.monotonic() < deadline:
                row = {'get_feature_report': [0, 9]}
                try:
                    raw = bytes(self.app.dev.get_feature_report(0, 9))
                    row['reply_hex'] = raw.hex()
                except Exception as exc:
                    row['error'] = repr(exc)
                    raise
                finally:
                    self.trace.write(json.dumps(row)+'\n'); self.trace.flush()
                require(len(raw) == 9 and raw[:6] == b'\0AKBT\1', 'Invalid boot feature')
                stage, heartbeat, flags = raw[6:]
                require(stage in (1, 2, 3) and not flags & 252, 'Unknown boot feature fields')
                samples.append(list(raw))
                if stage == 3 and flags == 1:
                    if previous is not None and previous != heartbeat:
                        return
                    previous = heartbeat
                else:
                    previous = None
                time.sleep(.2)
            raise TimeoutError('Main loop liveness not observed; stop without reset')
        finally:
            (self.output / 'boot-status.json').write_text(json.dumps(samples), encoding='utf-8')

    def initialize(self):
        self.boot_liveness()
        rom = self.read_code(0, 65536)
        (self.output / 'before-rom.bin').write_bytes(rom)
        require(all(rom[a] == v for a, v in self.binding['code'].items()), 'Live diagnostic CODE differs')
        transport.verify_live(rom, self.binding['payload'], 'permanent', self.binding['backup'],
                              target_build_id=self.binding.get('nvm_schema', self.binding.get('schema', pack.BUILD_ID)),
                              allow_legacy=False)
        self.baseline = rom[pack.NVM_START:pack.NVM_END]
        (self.output / 'baseline-nvm.bin').write_bytes(self.baseline)
        require(self.read_nvm() == self.baseline, 'NVM unstable or stale')
        self.status()

    def status(self):
        status = diag.decode_status(self.exchange(self.packet(253, 1)))
        require(status['first_failure_stage'] == 0 and not status['storage_failed'] and not status['page_dirty'] and status['batch_depth'] == 0
                and not status['vial_unlock_in_progress'], 'Storage failure, busy storage or unlock in progress')
        return status

    def read_nvm(self):
        region = self.read_code(pack.NVM_START, pack.MANIFEST_START-pack.NVM_START)
        (self.output / 'current-nvm-journal.bin').write_bytes(region)
        require(not any(region[pack.NVM_END-pack.NVM_START+64:]), 'Dirty journal header')
        nvm = region[:pack.NVM_END-pack.NVM_START]
        pack.validate_nvm(nvm, int.from_bytes(nvm[37:40], 'little'))
        require(self.read_code(pack.NVM_START, len(nvm)) == nvm, 'Unstable NVM')
        self.status()
        return nvm

    def definition(self):
        require(self.exchange(self.packet(1))[1:3] == b'\0\x09', 'VIA version mismatch')
        ident = self.exchange(self.packet(254, 0))
        require(ident[:4] == (6).to_bytes(4, 'little') and ident[4:12] == bytes.fromhex('0470ff9001b915d3') and ident[12] == 1,
                'Vial identity/version/RGB mismatch')
        size = int.from_bytes(self.exchange(self.packet(254, 1))[:4], 'little')
        require(0 < size <= 65504, 'Definition size invalid')
        compressed = b''.join(self.exchange(self.packet(254, 2, p & 255, p >> 8, 0, 0))
                              for p in range((size+31)//32))[:size]
        definition = json.loads(lzma.decompress(compressed))
        require(definition == self.binding['definition'], 'Live definition differs from release')
        matrix, rotations = [], []
        for row in definition['layouts']['keymap']:
            for key in row:
                if isinstance(key, str):
                    coordinate = key.split('\n')[0]
                    if re.fullmatch(r'\d+,\d+', coordinate):
                        pair = tuple(map(int, coordinate.split(',')))
                        if '\ne' in key: rotations.append(pair)
                        else: matrix.append(pair)
        require(len(matrix) == len(set(matrix)) == 83 and len(rotations) == 2, 'Definition key/rotation count mismatch')
        require(self.exchange(self.packet(17))[1] == 6, 'Layer count mismatch')
        return matrix

    @staticmethod
    def key_offset(layer, key):
        return pack.KEYMAP_ADDR+layer*256+key[0]*16+key[1]*2

    @staticmethod
    def encoder_offset(layer, direction):
        # Wire direction 0=CCW, 1=CW; persistent order is CW, CCW.
        return pack.ENCODER_ADDR+layer*4+(1-direction)*2

    def get_key(self, layer, key):
        require(0 <= layer < 6 and len(key) == 2 and 0 <= key[0] < 16 and 0 <= key[1] < 6,
                'Invalid key getter arguments')
        reply = self.exchange(self.packet(4, layer, *key))
        require(reply[:4] == bytes((4, layer, *key)), 'Key getter header mismatch')
        return int.from_bytes(reply[4:6], 'big')

    def get_encoder(self, layer, direction):
        require(0 <= layer < 6 and direction in (0, 1), 'Invalid encoder getter arguments')
        reply = self.exchange(self.packet(254, 3, layer, 0))
        return int.from_bytes(reply[direction*2:direction*2+2], 'big')

    def set_key(self, layer, key, value):
        self._require_writes()
        require(0 <= layer < 6 and len(key) == 2 and 0 <= key[0] < 16 and 0 <= key[1] < 6
                and 0 <= value <= 0xFFFF, 'Invalid key setter arguments')
        packet = self.packet(5, layer, *key, value >> 8, value & 255)
        return self.exchange(packet) == packet

    def set_encoder(self, layer, direction, value):
        self._require_writes()
        require(0 <= layer < 6 and direction in (0, 1) and 0 <= value <= 0xFFFF, 'Invalid encoder setter arguments')
        packet = self.packet(254, 4, layer, 0, direction, value >> 8, value & 255)
        return self.exchange(packet) == packet

    COMBO_OFFSET = 0x658
    COMBO_MARKER = b'\x20\x08\x01\x00'

    @staticmethod
    def validate_combo(data):
        require(isinstance(data, bytes) and len(data) == 10, 'Combo requires ten bytes')
        a, b, c, d, output = (int.from_bytes(data[i:i+2], 'little') for i in range(0, 10, 2))
        require(c == d == 0, 'Unsupported Combo format/version')
        valid = (a == b == output == 0) or (4 <= a <= 0xA4 and 4 <= b <= 0xA4 and a != b
                and (0xA8 <= output <= 0xC2 or output == 0x7C73 or (output < 0x2000 and
                     (4 <= (output & 255) <= 0xA4 or 0xE0 <= (output & 255) <= 0xE7))))
        require(valid, 'Unsupported Combo keys/output')
        return data

    @classmethod
    def stored_combo(cls, data):
        data = cls.validate_combo(data)
        return data[:4] + cls.COMBO_MARKER + data[8:]

    def dynamic_entry_counts(self):
        reply = self.exchange(self.packet(254, 13, 0))
        require(reply[0] in (0,8) and reply[1] == 8 and reply[2] in (0,8)
                and reply[3:] == bytes(28) + b'\x01', 'Dynamic capabilities differ')
        return tuple(reply[:3])

    def combo_count(self):
        return self.dynamic_entry_counts()[1]

    def get_combo(self, index):
        require(type(index) is int and 0 <= index < 8, 'Invalid Combo index')
        packet = self.packet(254, 13, 3, index)
        reply = self.exchange(packet)
        require(reply[0] == 0 and reply[11:] == packet[11:], 'Combo getter ACK mismatch')
        return self.validate_combo(reply[1:11])

    def set_combo(self, index, data):
        self._require_writes()
        require(type(index) is int and 0 <= index < 8, 'Invalid Combo index')
        data = self.validate_combo(data)
        image = self.binding.get('compatible_images', {}).get(self.binding.get('ihx_sha256'))
        output = int.from_bytes(data[8:10], 'little')
        capability = image if image is not None else self.binding
        require(not 0xA8 <= output <= 0xC2 or (capability.get('combo_media') is True and self._settings_record_version() == 2), 'Media Combo unsupported by exact image')
        before = self.read_nvm()
        packet = self.packet(254, 13, 4, index, *data)
        require(self.exchange(packet) == b'\0' + packet[1:], 'Combo setter ACK mismatch')
        self.status()
        require(self.get_combo(index) == data, 'Combo getter readback differs')
        expected = bytearray(before)
        offset = self.COMBO_OFFSET + 10*index
        expected[offset:offset+10] = self.stored_combo(data)
        require(self.read_nvm() == bytes(expected), 'Combo durable settings or neighboring bytes differ')
        return True

    def get_extension(self, kind, index):
        extensions.slot_offset(kind, index)
        op = 1 if kind == 'tap_dance' else 5
        packet = self.packet(254, 13, op, index)
        reply = self.exchange(packet)
        require(reply[0] == 0 and reply[11:] == packet[11:], 'Extension getter ACK mismatch')
        return extensions.validate_entry(kind, reply[1:11])

    def set_extension(self, kind, index, data):
        self._require_writes()
        offset = extensions.slot_offset(kind, index)
        extensions.validate_entry(kind, data)
        before = self.read_nvm()
        require(int.from_bytes(before[37:40], 'little') == extensions.SCHEMA, 'Extension schema differs')
        packet = self.packet(254, 13, 2 if kind == 'tap_dance' else 6, index, *data)
        require(self.exchange(packet) == b'\0' + packet[1:], 'Extension setter ACK mismatch')
        self.status()
        require(self.get_extension(kind, index) == data, 'Extension getter readback differs')
        expected = bytearray(before)
        expected[offset:offset+10] = data
        require(self.read_nvm() == bytes(expected), 'Extension durable readback or neighboring bytes differ')
        return True

    def settings_query(self, greater_than=0):
        require(type(greater_than) is int and 0 <= greater_than <= 65535, 'Invalid settings query ID')
        reply = self.exchange(self.packet(254, 9, greater_than & 255, greater_than >> 8))
        ids = [int.from_bytes(reply[i:i+2], 'little') for i in range(0,32,2)]
        values = [i for i in ids if i != 65535]
        require(ids == values + [65535]*(16-len(values)) and values == sorted(set(values))
                and all(i in (extensions.FIELDS if self._settings_record_version() == 2 else extensions.LEGACY_FIELDS) and i > greater_than for i in values), 'Invalid settings capabilities')
        return values

    def get_setting(self, qsid):
        require(type(qsid) is int and qsid in extensions.FIELDS, 'Unknown settings ID')
        require(self._settings_record_version() == 2 or qsid in extensions.LEGACY_FIELDS, 'Setting unsupported by exact image')
        reply = self.exchange(self.packet(254, 10, qsid & 255, qsid >> 8))
        require(reply[0] == 0, 'Settings getter failed')
        width = extensions.FIELDS[qsid][1]
        value = int.from_bytes(reply[1:1+width], 'little')
        extensions.field_value(qsid, value)
        return value

    def _settings_record_version(self):
        image = self.binding.get('compatible_images', {}).get(self.binding.get('ihx_sha256'))
        if image is not None:
            return image.get('settings_record_version', 1)
        return self.binding.get('settings_record_version', 2)

    def set_setting(self, qsid, value):
        self._require_writes()
        data = extensions.field_value(qsid, value)
        require(self._settings_record_version() == 2 or qsid in extensions.LEGACY_FIELDS, 'Setting unsupported by exact image')
        before = self.read_nvm()
        values = extensions.decode_settings(before[0x6A8:0x6C0], version=self._settings_record_version())
        unchanged = values[str(qsid)] == value
        # Saved control getters do not expose physical session overrides. An
        # explicit Set must reapply these controls even when storage is equal.
        if unchanged and qsid not in (3, 22):
            require(self.get_setting(qsid) == value, 'Settings no-op getter differs')
            require(self.read_nvm() == before, 'Settings no-op durable readback differs')
            return True
        values[str(qsid)] = value
        packet = self.packet(254, 11, qsid & 255, qsid >> 8, *data)
        require(self.exchange(packet) == b'\0' + packet[1:], 'Settings setter ACK mismatch')
        self.status()
        require(self.get_setting(qsid) == value, 'Settings getter readback differs')
        expected = bytearray(before)
        if not unchanged:
            expected[0x6A8:0x6C0] = extensions.settings_record(values, version=self._settings_record_version())
        require(self.read_nvm() == bytes(expected), 'Settings durable readback or neighboring bytes differ')
        return True

    def reset_settings(self):
        self._require_writes()
        before = self.read_nvm()
        values = extensions.from_nvm(before, version=self._settings_record_version())['qmk_settings']
        unchanged = values == extensions.decode_settings(extensions.settings_record(version=self._settings_record_version()))
        # Reset also reapplies volatile controls. Firmware leaves durable bytes
        # untouched when the effective saved record already contains defaults.
        packet = self.packet(254, 12)
        require(self.exchange(packet) == b'\0' + packet[1:], 'Settings reset ACK mismatch')
        self.status()
        for qsid in self.settings_query():
            require(self.get_setting(qsid) == extensions.FIELDS[qsid][4], 'Settings reset getter differs')
        expected = bytearray(before)
        if not unchanged:
            expected[0x6A8:0x6C0] = extensions.settings_record(version=self._settings_record_version())
        require(self.read_nvm() == bytes(expected), 'Settings reset durable readback differs')
        return True

    def macros(self):
        require(self.exchange(self.packet(12))[1] == 16, 'Macro count mismatch')
        require(int.from_bytes(self.exchange(self.packet(13))[1:3], 'big') == 8192, 'Macro size mismatch')
        data = bytearray()
        for offset in range(0, 8192, 28):
            count = min(28, 8192-offset)
            packet = self.packet(14, offset >> 8, offset & 255, count)
            reply = self.exchange(packet)
            require(reply[:4] == packet[:4], 'Macro getter header mismatch')
            data.extend(reply[4:4+count])
        return bytes(data)

    def get_macro_buffer(self, offset, count):
        """Read a published logical macro range through VIA 0x0E.

        The firmware intentionally hides in-progress upload data from this
        getter. During an upload, verify physical bytes with read_code() at
        pack.NVM_START + pack.MACRO_ADDR + offset instead.
        """
        require(0 <= offset <= 8192 and 0 <= count <= 28 and offset <= 8192-count,
                'Invalid macro read range')
        if count == 0:
            return b''
        packet = self.packet(14, offset >> 8, offset & 255, count)
        reply = self.exchange(packet)
        require(reply[:4] == packet[:4], 'Macro getter header mismatch')
        return reply[4:4+count]

    @staticmethod
    def macro_view(nvm):
        """Protocol hides stale tail after the published logical upload length.

        dynamic_keymap_macro_get_buffer uses ak820_macro_length(), not the
        physical allocation size. Busy or invalid metadata is a hard failure.
        """
        metadata = pack.validate_nvm(nvm)
        start = metadata['macro_addr']
        length = metadata['published_macro_length']
        return nvm[start:start+length] + bytes(metadata['macro_size']-length)

    def rgb_mode(self):
        reply = self.exchange(self.packet(8, 0x41))
        require(reply[:2] == b'\x08\x41', 'RGB mode response mismatch')
        return reply[2:8]

    def set_rgb_mode(self, mode):
        self._require_writes()
        require(isinstance(mode, (bytes, bytearray)) and len(mode) == 6, 'RGB mode requires six bytes')
        packet = self.packet(7, 0x41, *mode)
        return self.exchange(packet) == packet

    def get_layout_options(self):
        reply = self.exchange(self.packet(2, 2))
        require(reply[:2] == b'\x02\x02', 'Layout options response mismatch')
        require(reply[2:5] == bytes(3), 'Layout options exceed the persisted one-byte field')
        return int.from_bytes(reply[2:6], 'big')

    def set_layout_options(self, value):
        self._require_writes()
        require(0 <= value <= 0xFF, 'Layout options must fit the persisted one-byte field')
        packet = self.packet(3, 2, value >> 24, (value >> 16) & 255, (value >> 8) & 255, value & 255)
        return self.exchange(packet) == packet

    def upload_macro_chunk(self, offset, data):
        """Upload one existing VIA macro chunk; caller must satisfy Vial unlock."""
        self._require_writes()
        require(isinstance(data, (bytes, bytearray)) and 1 <= len(data) <= 28
                and 0 <= offset <= 8192-len(data), 'Invalid macro upload chunk')
        packet = self.packet(15, offset >> 8, offset & 255, len(data), *data)
        return self.exchange(packet) == packet

    def save_rgb(self):
        """Persist current VialRGB values through VIA lighting-save command."""
        self._require_writes()
        packet = self.packet(9)
        return self.exchange(packet) == packet

    def rgb(self):
        def query(command, *args):
            reply = self.exchange(self.packet(8, command, *args))
            require(reply[:2] == bytes((8, command)), 'RGB getter header mismatch')
            return reply[2:]
        info = query(0x40)
        require(int.from_bytes(info[:2], 'little') == 1, 'VialRGB version mismatch')
        require(int.from_bytes(query(0x43)[:2], 'little') == 82, 'RGB LED count mismatch')
        effects, previous = [], 0
        while True:
            result = query(0x42, previous & 255, previous >> 8)
            values = [int.from_bytes(result[i:i+2], 'little') for i in range(0, 30, 2)]
            values = [v for v in values if v != 65535]
            if not values: break
            require(all(v > previous for v in values) and values == sorted(set(values)), 'Invalid RGB effect page')
            effects.extend(values); previous = values[-1]
            require(len(effects) <= 256, 'RGB effect list too long')
        require(effects, 'RGB effect list empty')
        leds = [list(query(0x44, i, 0)[:5]) for i in range(82)]
        require(all(led[2] == 4 and 0 <= led[3] < 16 and 0 <= led[4] < 8 for led in leds), 'Invalid LED metadata')
        require(len({tuple(led[3:5]) for led in leds}) == 82, 'Duplicate LED matrix positions')
        mode = query(0x41)[:6]
        require(int.from_bytes(mode[:2], 'little') in [0]+effects, 'RGB mode unsupported')
        # Hue/saturation/value/speed have a stable persistent representation.
        nvm = self.read_nvm()
        require(mode[5] <= info[2], 'RGB brightness outside firmware limit')
        return {'effects': effects, 'leds': leds, 'mode_hex': mode.hex(), 'info_hex': info[:3].hex(),
                'saved_rgb_config_hex': nvm[24:32].hex(),
                'RAM_matches_saved_hsv_speed': mode[2:] == bytes((nvm[28], nvm[25], nvm[26], nvm[27]))}

    def direct_info(self):
        """Negotiate actual Direct support; untouched old-image replies are unavailable."""
        reply = self.exchange(self.packet(8, 0x45))
        require(reply[:2] == b'\x08\x45', 'Direct info header mismatch')
        if reply[2:4] != b'AD':
            return None
        require(reply[4:12] == bytes((1, 3, 82, 1, 1, 160, 7, 8))
                and int.from_bytes(reply[12:14], 'little') == 1000, 'Unsupported Direct capability contract')
        return {'version': 1, 'capabilities': 3, 'count': 82, 'encoding': 'HSV8',
                'mapping': 1, 'maximum_brightness': 160, 'read_chunk': 7,
                'upload_chunk': 8, 'timeout_ms': 1000}

    def direct_status(self):
        if self.direct_info() is None:
            return None
        return self._direct_status()

    def _direct_status(self):
        reply = self.exchange(self.packet(8, 0x47))
        require(reply[:2] == b'\x08\x47' and reply[2] <= 6 and reply[3] <= 82
                and not reply[10] & ~7, 'Malformed Direct status')
        return {'state': reply[2], 'coverage': reply[3],
                'frame_id': int.from_bytes(reply[4:6], 'little'),
                'generation': int.from_bytes(reply[6:10], 'little'), 'flags': reply[10]}

    def direct_snapshot(self, *, attempts=3):
        require(type(attempts) is int and 1 <= attempts <= 3, 'Invalid Direct snapshot attempt bound')
        info = self.direct_info()
        if info is None:
            return None
        for _ in range(attempts):
            generation = self._direct_status()['generation']
            hsv = bytearray()
            for first in range(0, 82, 7):
                count = min(7, 82-first)
                reply = self.exchange(self.packet(8, 0x46, *generation.to_bytes(4, 'little'), first, count))
                require(reply[:2] == b'\x08\x46' and reply[3:5] == bytes((first,count))
                        and not reply[5] & ~7, 'Malformed Direct read response')
                actual = int.from_bytes(reply[6:10], 'little')
                if reply[2] == 3:
                    break
                require(reply[2] == 0 and actual == generation, 'Direct read failed or generation mismatch')
                hsv.extend(reply[10:10+count*3])
            else:
                status = self._direct_status()
                if status['generation'] == generation:
                    require(all(v <= 160 for v in hsv[2::3]), 'Direct palette brightness outside limit')
                    return {'format': 'ak820-direct-ram-1', 'capability': info,
                            'generation': generation, 'flags': status['flags'], 'hsv_hex': hsv.hex()}
        raise ValueError('Direct palette changed during bounded snapshot')

    def _direct_set(self, command, payload):
        self._require_writes()
        packet = self.packet(7, command, *payload)
        reply = self.exchange(packet)
        require(reply[:2] == packet[:2] and reply[3:] == packet[3:], 'Direct setter ACK mismatch')
        require(reply[2] == 0, 'Direct setter failed: status ' + str(reply[2]))
        return True

    def direct_abort(self, frame_id):
        self._require_writes()
        require(type(frame_id) is int and 1 <= frame_id <= 65535, 'Invalid Direct frame ID')
        require(self.direct_info() is not None, 'Direct unavailable')
        return self._direct_set(0x46, frame_id.to_bytes(2, 'little'))

    def set_direct_frame(self, hsv, *, frame_id, expected_generation):
        """Commit a full RAM frame; clamp each V byte to negotiated maximum 160.

        Input bytes are never modified. Success means accepted; display may be pending.

        Failures stop immediately. No automatic abort, retry or legacy fastset.
        """
        self._require_writes()
        require(isinstance(hsv, bytes) and len(hsv) == 246, 'Direct frame requires 82 HSV triples')
        require(type(frame_id) is int and 1 <= frame_id <= 65535, 'Invalid Direct frame ID')
        require(type(expected_generation) is int and 0 <= expected_generation <= 0xffffffff, 'Invalid Direct generation')
        require(self.direct_info() is not None, 'Direct unavailable')
        # Firmware clamps V to 160 before ACKing each upload chunk. Normalize
        # locally so strict ACK equality compares against the transmitted data.
        hsv = bytes(value if index % 3 != 2 else min(value, 160)
                    for index, value in enumerate(hsv))
        ident = frame_id.to_bytes(2, 'little')
        self._direct_set(0x43, bytes((1,82)) + ident + expected_generation.to_bytes(4,'little'))
        for first in range(0,82,8):
            count = min(8,82-first)
            self._direct_set(0x44, ident + bytes((first,count)) + hsv[first*3:(first+count)*3])
        self._direct_set(0x45, ident)
        status = self._direct_status()
        require(status['frame_id'] == frame_id and status['coverage'] == 82
                and status['generation'] == (expected_generation+1) & 0xffffffff
                and status['state'] in (2,3,4,5), 'Direct commit status mismatch')
        return status
