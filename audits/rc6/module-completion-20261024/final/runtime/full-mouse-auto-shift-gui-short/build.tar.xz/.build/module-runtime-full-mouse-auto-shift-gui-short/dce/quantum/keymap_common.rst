                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module keymap_common
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _KEYCODE2CONSUMER
                                     12 	.globl _keycode_at_encodermap_location
                                     13 	.globl _keycode_at_keymap_location
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _ak820_keycode_at_PARM_2
                                    258 	.globl _action_for_keycode
                                    259 	.globl _ak820_keycode_at
                                    260 ;--------------------------------------------------------
                                    261 ; special function registers
                                    262 ;--------------------------------------------------------
                                    263 	.area RSEG    (ABS,DATA)
      000000                        264 	.org 0x0000
                           0000D0   265 _PSW	=	0x00d0
                           0000E0   266 _ACC	=	0x00e0
                           0000F0   267 _B	=	0x00f0
                           0000FD   268 _A_INV	=	0x00fd
                           000081   269 _SP	=	0x0081
                           000082   270 _DPL	=	0x0082
                           000083   271 _DPH	=	0x0083
                           0000A1   272 _SAFE_MOD	=	0x00a1
                           0000B1   273 _GLOBAL_CFG	=	0x00b1
                           000087   274 _PCON	=	0x0087
                           0000BA   275 _POWER_CFG	=	0x00ba
                           0000B9   276 _CLOCK_CFG	=	0x00b9
                           0000A9   277 _WAKE_CTRL	=	0x00a9
                           0000FE   278 _RESET_KEEP	=	0x00fe
                           0000FF   279 _WDOG_COUNT	=	0x00ff
                           0000A8   280 _IE	=	0x00a8
                           0000B8   281 _IP	=	0x00b8
                           0000E8   282 _IE_EX	=	0x00e8
                           0000E9   283 _IP_EX	=	0x00e9
                           0000B2   284 _GPIO_IE	=	0x00b2
                           008584   285 _ROM_ADDR	=	0x8584
                           000084   286 _ROM_ADDR_L	=	0x0084
                           000085   287 _ROM_ADDR_H	=	0x0085
                           008F8E   288 _ROM_DATA_HI	=	0x8f8e
                           00008E   289 _ROM_DATA_HL	=	0x008e
                           00008F   290 _ROM_DATA_HH	=	0x008f
                           000086   291 _ROM_CTRL	=	0x0086
                           000080   292 _P0	=	0x0080
                           0000C4   293 _P0_MOD_OC	=	0x00c4
                           0000C5   294 _P0_DIR_PU	=	0x00c5
                           000090   295 _P1	=	0x0090
                           000092   296 _P1_MOD_OC	=	0x0092
                           000093   297 _P1_DIR_PU	=	0x0093
                           0000A0   298 _P2	=	0x00a0
                           000094   299 _P2_MOD_OC	=	0x0094
                           000095   300 _P2_DIR_PU	=	0x0095
                           0000B0   301 _P3	=	0x00b0
                           000096   302 _P3_MOD_OC	=	0x0096
                           000097   303 _P3_DIR_PU	=	0x0097
                           0000C0   304 _P4	=	0x00c0
                           0000C2   305 _P4_MOD_OC	=	0x00c2
                           0000C3   306 _P4_DIR_PU	=	0x00c3
                           0000C1   307 _P4_LED_KEY	=	0x00c1
                           0000AA   308 _P5_IN	=	0x00aa
                           0000AB   309 _P5_OUT_PU	=	0x00ab
                           0000AC   310 _P5_DIR	=	0x00ac
                           0000AD   311 _P6_IN	=	0x00ad
                           0000AE   312 _P6_OUT_PU	=	0x00ae
                           0000AF   313 _P6_DIR	=	0x00af
                           0000F1   314 _P7	=	0x00f1
                           0000A2   315 _XBUS_AUX	=	0x00a2
                           000088   316 _TCON	=	0x0088
                           000089   317 _TMOD	=	0x0089
                           00008A   318 _TL0	=	0x008a
                           00008B   319 _TL1	=	0x008b
                           00008C   320 _TH0	=	0x008c
                           00008D   321 _TH1	=	0x008d
                           000098   322 _SCON	=	0x0098
                           000099   323 _SBUF	=	0x0099
                           0000C8   324 _T2CON	=	0x00c8
                           0000C9   325 _T2MOD	=	0x00c9
                           00CBCA   326 _RCAP2	=	0xcbca
                           0000CA   327 _RCAP2L	=	0x00ca
                           0000CB   328 _RCAP2H	=	0x00cb
                           00CDCC   329 _T2COUNT	=	0xcdcc
                           0000CC   330 _TL2	=	0x00cc
                           0000CD   331 _TH2	=	0x00cd
                           00CFCE   332 _T2CAP1	=	0xcfce
                           0000CE   333 _T2CAP1L	=	0x00ce
                           0000CF   334 _T2CAP1H	=	0x00cf
                           0000F8   335 _SPI0_STAT	=	0x00f8
                           0000F9   336 _SPI0_DATA	=	0x00f9
                           0000FA   337 _SPI0_CTRL	=	0x00fa
                           0000FB   338 _SPI0_CK_SE	=	0x00fb
                           0000FC   339 _SPI0_SETUP	=	0x00fc
                           0000BC   340 _SCON1	=	0x00bc
                           0000BD   341 _SBUF1	=	0x00bd
                           0000BE   342 _SBAUD1	=	0x00be
                           0000BF   343 _SIF1	=	0x00bf
                           0000B4   344 _SPI1_STAT	=	0x00b4
                           0000B5   345 _SPI1_DATA	=	0x00b5
                           0000B6   346 _SPI1_CTRL	=	0x00b6
                           0000B7   347 _SPI1_CK_SE	=	0x00b7
                           0000F3   348 _ADC_CTRL	=	0x00f3
                           00F5F4   349 _ADC_DAT	=	0xf5f4
                           0000F4   350 _ADC_DAT_L	=	0x00f4
                           0000F5   351 _ADC_DAT_H	=	0x00f5
                           0000F6   352 _ADC_CHAN	=	0x00f6
                           0000A6   353 _LED_COMMON	=	0x00a6
                           0000A7   354 _LED_PWM_OE	=	0x00a7
                           00C7C6   355 _LED_DMA	=	0xc7c6
                           0000C6   356 _LED_DMA_L	=	0x00c6
                           0000C7   357 _LED_DMA_H	=	0x00c7
                           0000F7   358 _LED_STATUS	=	0x00f7
                           0000B3   359 _I2CX_INT	=	0x00b3
                           0000BB   360 _I2CS_INT_ST	=	0x00bb
                                    361 ;--------------------------------------------------------
                                    362 ; special function bits
                                    363 ;--------------------------------------------------------
                                    364 	.area RSEG    (ABS,DATA)
      000000                        365 	.org 0x0000
                           0000D7   366 _CY	=	0x00d7
                           0000D6   367 _AC	=	0x00d6
                           0000D5   368 _F0	=	0x00d5
                           0000D4   369 _RS1	=	0x00d4
                           0000D3   370 _RS0	=	0x00d3
                           0000D2   371 _OV	=	0x00d2
                           0000D1   372 _F1	=	0x00d1
                           0000D0   373 _P	=	0x00d0
                           0000AF   374 _EA	=	0x00af
                           0000AE   375 _E_DIS	=	0x00ae
                           0000AD   376 _ET2	=	0x00ad
                           0000AC   377 _ES	=	0x00ac
                           0000AB   378 _ET1	=	0x00ab
                           0000AA   379 _EX1	=	0x00aa
                           0000A9   380 _ET0	=	0x00a9
                           0000A8   381 _EX0	=	0x00a8
                           0000BF   382 _PH_FLAG	=	0x00bf
                           0000BE   383 _PL_FLAG	=	0x00be
                           0000BD   384 _PT2	=	0x00bd
                           0000BC   385 _PS	=	0x00bc
                           0000BB   386 _PT1	=	0x00bb
                           0000BA   387 _PX1	=	0x00ba
                           0000B9   388 _PT0	=	0x00b9
                           0000B8   389 _PX0	=	0x00b8
                           0000EF   390 _IE_WDOG	=	0x00ef
                           0000EE   391 _IE_GPIO	=	0x00ee
                           0000ED   392 _IE_PWM_I2C	=	0x00ed
                           0000EC   393 _IE_UART1	=	0x00ec
                           0000EB   394 _IE_ADC	=	0x00eb
                           0000E9   395 _IE_USB	=	0x00e9
                           0000E8   396 _IE_SPI0	=	0x00e8
                           000087   397 _P0_7	=	0x0087
                           000086   398 _P0_6	=	0x0086
                           000085   399 _P0_5	=	0x0085
                           000084   400 _P0_4	=	0x0084
                           000083   401 _P0_3	=	0x0083
                           000082   402 _P0_2	=	0x0082
                           000081   403 _P0_1	=	0x0081
                           000080   404 _P0_0	=	0x0080
                           000081   405 _SDA0	=	0x0081
                           000080   406 _SCL0	=	0x0080
                           000083   407 _TXD_	=	0x0083
                           000082   408 _RXD_	=	0x0082
                           000085   409 _AIN13	=	0x0085
                           000084   410 _AIN12	=	0x0084
                           000083   411 _AIN11	=	0x0083
                           000082   412 _AIN10	=	0x0082
                           000081   413 _AIN9	=	0x0081
                           000080   414 _AIN8	=	0x0080
                           000097   415 _P1_7	=	0x0097
                           000096   416 _P1_6	=	0x0096
                           000095   417 _P1_5	=	0x0095
                           000094   418 _P1_4	=	0x0094
                           000093   419 _P1_3	=	0x0093
                           000092   420 _P1_2	=	0x0092
                           000091   421 _P1_1	=	0x0091
                           000090   422 _P1_0	=	0x0090
                           000097   423 _TXD1_	=	0x0097
                           000096   424 _RXD1_	=	0x0096
                           000097   425 _SCK	=	0x0097
                           000096   426 _MISO	=	0x0096
                           000095   427 _MOSI	=	0x0095
                           000094   428 _SCS	=	0x0094
                           000092   429 _INT0_	=	0x0092
                           000091   430 _T2EX	=	0x0091
                           000091   431 _CAP2	=	0x0091
                           000090   432 _T2	=	0x0090
                           000090   433 _CAP1	=	0x0090
                           000097   434 _AIN7	=	0x0097
                           000096   435 _AIN6	=	0x0096
                           000095   436 _AIN5	=	0x0095
                           000094   437 _AIN4	=	0x0094
                           000093   438 _AIN3	=	0x0093
                           000092   439 _AIN2	=	0x0092
                           000091   440 _AIN1	=	0x0091
                           000090   441 _AIN0	=	0x0090
                           0000A7   442 _P2_7	=	0x00a7
                           0000A6   443 _P2_6	=	0x00a6
                           0000A5   444 _P2_5	=	0x00a5
                           0000A4   445 _P2_4	=	0x00a4
                           0000A3   446 _P2_3	=	0x00a3
                           0000A2   447 _P2_2	=	0x00a2
                           0000A1   448 _P2_1	=	0x00a1
                           0000A0   449 _P2_0	=	0x00a0
                           0000A7   450 _TXD1	=	0x00a7
                           0000A6   451 _RXD1	=	0x00a6
                           0000A5   452 _T2EX_	=	0x00a5
                           0000A5   453 _CAP2_	=	0x00a5
                           0000A4   454 _T2_	=	0x00a4
                           0000A4   455 _CAP1_	=	0x00a4
                           0000B7   456 _P3_7	=	0x00b7
                           0000B6   457 _P3_6	=	0x00b6
                           0000B5   458 _P3_5	=	0x00b5
                           0000B4   459 _P3_4	=	0x00b4
                           0000B3   460 _P3_3	=	0x00b3
                           0000B2   461 _P3_2	=	0x00b2
                           0000B1   462 _P3_1	=	0x00b1
                           0000B0   463 _P3_0	=	0x00b0
                           0000B7   464 _SCK1	=	0x00b7
                           0000B6   465 _MISO1	=	0x00b6
                           0000B5   466 _MOSI1	=	0x00b5
                           0000B5   467 _T1	=	0x00b5
                           0000B4   468 _T0	=	0x00b4
                           0000B3   469 _INT1	=	0x00b3
                           0000B2   470 _INT0	=	0x00b2
                           0000B1   471 _TXD	=	0x00b1
                           0000B0   472 _RXD	=	0x00b0
                           0000C6   473 _P4_6	=	0x00c6
                           0000C5   474 _P4_5	=	0x00c5
                           0000C4   475 _P4_4	=	0x00c4
                           0000C3   476 _P4_3	=	0x00c3
                           0000C2   477 _P4_2	=	0x00c2
                           0000C1   478 _P4_1	=	0x00c1
                           0000C0   479 _P4_0	=	0x00c0
                           00008F   480 _TF1	=	0x008f
                           00008E   481 _TR1	=	0x008e
                           00008D   482 _TF0	=	0x008d
                           00008C   483 _TR0	=	0x008c
                           00008B   484 _IE1	=	0x008b
                           00008A   485 _IT1	=	0x008a
                           000089   486 _IE0	=	0x0089
                           000088   487 _IT0	=	0x0088
                           00009F   488 _SM0	=	0x009f
                           00009E   489 _SM1	=	0x009e
                           00009D   490 _SM2	=	0x009d
                           00009C   491 _REN	=	0x009c
                           00009B   492 _TB8	=	0x009b
                           00009A   493 _RB8	=	0x009a
                           000099   494 _TI	=	0x0099
                           000098   495 _RI	=	0x0098
                           0000CF   496 _TF2	=	0x00cf
                           0000CF   497 _CAP1F	=	0x00cf
                           0000CE   498 _EXF2	=	0x00ce
                           0000CD   499 _RCLK	=	0x00cd
                           0000CC   500 _TCLK	=	0x00cc
                           0000CB   501 _EXEN2	=	0x00cb
                           0000CA   502 _TR2	=	0x00ca
                           0000C9   503 _C_T2	=	0x00c9
                           0000C8   504 _CP_RL2	=	0x00c8
                           0000FF   505 _S0_FST_ACT	=	0x00ff
                           0000FE   506 _S0_IF_OV	=	0x00fe
                           0000FD   507 _S0_IF_FIRST	=	0x00fd
                           0000FC   508 _S0_IF_BYTE	=	0x00fc
                           0000FB   509 _S0_FREE	=	0x00fb
                           0000FA   510 _S0_T_FIFO	=	0x00fa
                           0000F8   511 _S0_R_FIFO	=	0x00f8
                           0000F7   512 _ADC_START	=	0x00f7
                                    513 ;--------------------------------------------------------
                                    514 ; overlayable register banks
                                    515 ;--------------------------------------------------------
                                    516 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        517 	.ds 8
                                    518 ;--------------------------------------------------------
                                    519 ; internal ram data
                                    520 ;--------------------------------------------------------
                                    521 	.area DSEG    (DATA)
                                    522 ;--------------------------------------------------------
                                    523 ; overlayable items in internal ram
                                    524 ;--------------------------------------------------------
                                    525 ;--------------------------------------------------------
                                    526 ; indirectly addressable internal ram data
                                    527 ;--------------------------------------------------------
                                    528 	.area ISEG    (DATA)
                                    529 ;--------------------------------------------------------
                                    530 ; absolute internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area IABS    (ABS,DATA)
                                    533 	.area IABS    (ABS,DATA)
                                    534 ;--------------------------------------------------------
                                    535 ; bit data
                                    536 ;--------------------------------------------------------
                                    537 	.area BSEG    (BIT)
                                    538 ;--------------------------------------------------------
                                    539 ; paged external ram data
                                    540 ;--------------------------------------------------------
                                    541 	.area PSEG    (PAG,XDATA)
                                    542 ;--------------------------------------------------------
                                    543 ; uninitialized external ram data
                                    544 ;--------------------------------------------------------
                                    545 	.area XSEG    (XDATA)
      000BB8                        546 _action_for_keycode_keycode_10000_314:
      000BB8                        547 	.ds 2
      000BBA                        548 _action_for_keycode_kind_10000_315:
      000BBA                        549 	.ds 1
      000BBB                        550 _action_for_keycode_mods_10000_315:
      000BBB                        551 	.ds 1
      000BBC                        552 _action_for_keycode___400000077_40000_317:
      000BBC                        553 	.ds 2
      000BBE                        554 _action_for_keycode_key_60000_332:
      000BBE                        555 	.ds 1
      000BBF                        556 _ak820_keycode_at_PARM_2:
      000BBF                        557 	.ds 2
      000BC1                        558 _ak820_keycode_at_layer_10000_334:
      000BC1                        559 	.ds 1
                                    560 ;--------------------------------------------------------
                                    561 ; absolute external ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area XABS    (ABS,XDATA)
                                    564 ;--------------------------------------------------------
                                    565 ; initialized external ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area XISEG   (XDATA)
                                    568 	.area HOME    (CODE)
                                    569 	.area GSINIT0 (CODE)
                                    570 	.area GSINIT1 (CODE)
                                    571 	.area GSINIT2 (CODE)
                                    572 	.area GSINIT3 (CODE)
                                    573 	.area GSINIT4 (CODE)
                                    574 	.area GSINIT5 (CODE)
                                    575 	.area GSINIT  (CODE)
                                    576 	.area GSFINAL (CODE)
                                    577 	.area CSEG    (CODE)
                                    578 ;--------------------------------------------------------
                                    579 ; global & static initialisations
                                    580 ;--------------------------------------------------------
                                    581 	.area HOME    (CODE)
                                    582 	.area GSINIT  (CODE)
                                    583 	.area GSFINAL (CODE)
                                    584 	.area GSINIT  (CODE)
                                    585 ;--------------------------------------------------------
                                    586 ; Home
                                    587 ;--------------------------------------------------------
                                    588 	.area HOME    (CODE)
                                    589 	.area HOME    (CODE)
                                    590 ;--------------------------------------------------------
                                    591 ; code
                                    592 ;--------------------------------------------------------
                                    593 	.area CSEG    (CODE)
                                    594 ;------------------------------------------------------------
                                    595 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    596 ;------------------------------------------------------------
                                    597 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_108'
                                    598 ;------------------------------------------------------------
                                    599 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    600 ;	-----------------------------------------
                           000007   601 	ar7 = 0x07
                           000006   602 	ar6 = 0x06
                           000005   603 	ar5 = 0x05
                           000004   604 	ar4 = 0x04
                           000003   605 	ar3 = 0x03
                           000002   606 	ar2 = 0x02
                           000001   607 	ar1 = 0x01
                           000000   608 	ar0 = 0x00
                                    609 ;	 function action_for_keycode
                                    610 ;	-----------------------------------------
      0098DA                        611 _action_for_keycode:
      0098DA 12 3A 83         [24]  612 	lcall	_ak820_outline_0103
      0098DD 90 0B B8         [24]  613 	mov	dptr,#_action_for_keycode_keycode_10000_314
      0098E0 12 3A 88         [24]  614 	lcall	_ak820_outline_0104
                                    615 ;	quantum/keymap_common.c:91: uint8_t kind = (uint8_t)(keycode >> 8);
      0098E3 90 0B B8         [24]  616 	mov	dptr,#_action_for_keycode_keycode_10000_314
      0098E6 12 3A 40         [24]  617 	lcall	_ak820_outline_0050
                                    618 ;	quantum/keymap_common.c:92: uint8_t key = (uint8_t)keycode;
                                    619 ;	quantum/keymap_common.c:94: if (!kind) {
      0098E9 FD               [12]  620 	mov	r5,a
      0098EA 8E 04            [24]  621 	mov	ar4,r6
      0098EC 70 74            [24]  622 	jnz	00117$
                                    623 ;	quantum/keymap_common.c:95: if ((key >= KC_A && key <= KC_EXSEL) ||
      0098EE BC 04 00         [24]  624 	cjne	r4,#0x04,00251$
      0098F1                        625 00251$:
      0098F1 40 05            [24]  626 	jc	00105$
      0098F3 EC               [12]  627 	mov	a,r4
      0098F4 24 5B            [12]  628 	add	a,#0xff - 0xa4
      0098F6 50 0D            [24]  629 	jnc	00101$
                                    630 ;	free result
      0098F8                        631 00105$:
                                    632 ;	quantum/keymap_common.c:96: (key >= KC_LEFT_CTRL && key <= KC_RIGHT_GUI) || key == KC_TRANSPARENT)
      0098F8 BC E0 00         [24]  633 	cjne	r4,#0xe0,00254$
      0098FB                        634 00254$:
      0098FB 40 05            [24]  635 	jc	00106$
      0098FD EC               [12]  636 	mov	a,r4
      0098FE 24 18            [12]  637 	add	a,#0xff - 0xe7
      009900 50 03            [24]  638 	jnc	00101$
                                    639 ;	free result
      009902                        640 00106$:
      009902 BC 01 08         [24]  641 	cjne	r4,#0x01,00102$
      009905                        642 00101$:
                                    643 ;	quantum/keymap_common.c:97: return ACTION_KEY(key);
      009905 8C 02            [24]  644 	mov	ar2,r4
      009907 7B 00            [12]  645 	mov	r3,#0x00
      009909 12 45 7C         [24]  646 	lcall	_ak820_outline_0142
      00990C 22               [24]  647 	ret
      00990D                        648 00102$:
                                    649 ;	quantum/keymap_common.c:99: if (key >= KC_SYSTEM_POWER && key <= KC_SYSTEM_WAKE)
      00990D BC A5 00         [24]  650 	cjne	r4,#0xa5,00259$
      009910                        651 00259$:
      009910 40 1D            [24]  652 	jc	00108$
      009912 EC               [12]  653 	mov	a,r4
      009913 24 58            [12]  654 	add	a,#0xff - 0xa7
      009915 40 18            [24]  655 	jc	00108$
                                    656 ;	free result
                                    657 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      009917 8C 03            [24]  658 	mov	ar3,r4
      009919 74 DC            [12]  659 	mov	a,#0xdc
      00991B 2B               [12]  660 	add	a, r3
      00991C 90 0B BC         [24]  661 	mov	dptr,#_action_for_keycode___400000077_40000_317
      00991F 12 3A A5         [24]  662 	lcall	_ak820_outline_0123
                                    663 ;	quantum/keymap_common.c:100: return ACTION_USAGE_SYSTEM(KEYCODE2SYSTEM(key));
      009922 90 0B BC         [24]  664 	mov	dptr,#_action_for_keycode___400000077_40000_317
      009925 12 45 65         [24]  665 	lcall	_ak820_outline_0119
      009928 43 03 40         [24]  666 	orl	ar3,#0x40
      00992B 12 45 7C         [24]  667 	lcall	_ak820_outline_0142
      00992E 22               [24]  668 	ret
      00992F                        669 00108$:
                                    670 ;	quantum/keymap_common.c:101: if (key >= KC_AUDIO_MUTE && key <= KC_LAUNCHPAD)
      00992F BC A8 00         [24]  671 	cjne	r4,#0xa8,00262$
      009932                        672 00262$:
      009932 40 15            [24]  673 	jc	00111$
      009934 EC               [12]  674 	mov	a,r4
      009935 24 3D            [12]  675 	add	a,#0xff - 0xc2
      009937 40 10            [24]  676 	jc	00111$
                                    677 ;	free result
                                    678 ;	quantum/keymap_common.c:102: return ACTION_USAGE_CONSUMER(KEYCODE2CONSUMER(key));
      009939 8C 82            [24]  679 	mov	dpl, r4
      00993B 12 71 CB         [24]  680 	lcall	_KEYCODE2CONSUMER
      00993E AA 82            [24]  681 	mov	r2, dpl
      009940 AB 83            [24]  682 	mov	r3, dph
      009942 43 03 44         [24]  683 	orl	ar3,#0x44
      009945 12 45 7C         [24]  684 	lcall	_ak820_outline_0142
      009948 22               [24]  685 	ret
      009949                        686 00111$:
                                    687 ;	quantum/keymap_common.c:104: if (key >= KC_MS_UP && key <= KC_MS_ACCEL2) return ACTION_MOUSEKEY(key);
      009949 BC CD 00         [24]  688 	cjne	r4,#0xcd,00265$
      00994C                        689 00265$:
      00994C 40 10            [24]  690 	jc	00114$
      00994E EC               [12]  691 	mov	a,r4
      00994F 24 20            [12]  692 	add	a,#0xff - 0xdf
      009951 40 0B            [24]  693 	jc	00114$
                                    694 ;	free result
      009953 8C 02            [24]  695 	mov	ar2,r4
      009955 7B 00            [12]  696 	mov	r3,#0x00
      009957 43 03 50         [24]  697 	orl	ar3,#0x50
      00995A 12 45 7C         [24]  698 	lcall	_ak820_outline_0142
      00995D 22               [24]  699 	ret
      00995E                        700 00114$:
                                    701 ;	quantum/keymap_common.c:105: return ACTION_NO;
      00995E 90 00 00         [24]  702 	mov	dptr,#0x0000
      009961 22               [24]  703 	ret
      009962                        704 00117$:
                                    705 ;	quantum/keymap_common.c:107: if (kind < 0x20) return keycode; /* Encoded modifier+basic actions. */
      009962 BD 20 00         [24]  706 	cjne	r5,#0x20,00268$
      009965                        707 00268$:
      009965 50 04            [24]  708 	jnc	00119$
      009967 12 45 60         [24]  709 	lcall	_ak820_outline_0116
      00996A 22               [24]  710 	ret
      00996B                        711 00119$:
                                    712 ;	quantum/keymap_common.c:108: if (kind < 0x50) {
      00996B BD 50 00         [24]  713 	cjne	r5,#0x50,00270$
      00996E                        714 00270$:
      00996E 50 04            [24]  715 	jnc	00121$
                                    716 ;	quantum/keymap_common.c:112: return ACTION_NO;
      009970 90 00 00         [24]  717 	mov	dptr,#0x0000
      009973 22               [24]  718 	ret
      009974                        719 00121$:
                                    720 ;	quantum/keymap_common.c:117: if (kind < 0x52) {
      009974 BD 52 00         [24]  721 	cjne	r5,#0x52,00272$
      009977                        722 00272$:
      009977 50 38            [24]  723 	jnc	00125$
                                    724 ;	quantum/keymap_common.c:118: uint8_t layer = ((kind & 1u) << 3) | (key >> 5);
      009979 74 01            [12]  725 	mov	a,#0x01
      00997B 5D               [12]  726 	anl	a,r5
      00997C 12 3A D0         [24]  727 	lcall	_ak820_outline_0186
      00997F FF               [12]  728 	mov	r7,a
      009980 EC               [12]  729 	mov	a,r4
      009981 C4               [12]  730 	swap	a
      009982 03               [12]  731 	rr	a
      009983 54 07            [12]  732 	anl	a,#0x07
      009985 42 07            [12]  733 	orl	ar7,a
                                    734 ;	quantum/keymap_common.c:119: mods = key & 0x1f;
      009987 74 1F            [12]  735 	mov	a,#0x1f
      009989 5C               [12]  736 	anl	a,r4
      00998A FE               [12]  737 	mov	r6,a
      00998B 90 0B BB         [24]  738 	mov	dptr,#_action_for_keycode_mods_10000_315
      00998E F0               [24]  739 	movx	@dptr,a
                                    740 ;	quantum/keymap_common.c:120: if (mods & 0x10) mods <<= 4; /* Discard the 5-bit right-mod marker. */
      00998F EE               [12]  741 	mov	a,r6
      009990 30 E4 08         [24]  742 	jnb	acc.4,00123$
      009993 EE               [12]  743 	mov	a,r6
      009994 C4               [12]  744 	swap	a
      009995 54 F0            [12]  745 	anl	a,#0xf0
      009997 90 0B BB         [24]  746 	mov	dptr,#_action_for_keycode_mods_10000_315
      00999A F0               [24]  747 	movx	@dptr,a
      00999B                        748 00123$:
                                    749 ;	quantum/keymap_common.c:121: return ACTION_LAYER_MODS(layer, mods);
      00999B 8F 06            [24]  750 	mov	ar6,r7
      00999D 7F 00            [12]  751 	mov	r7,#0x00
      00999F 90 0B BB         [24]  752 	mov	dptr,#_action_for_keycode_mods_10000_315
      0099A2 E0               [24]  753 	movx	a,@dptr
      0099A3 7B 00            [12]  754 	mov	r3,#0x00
      0099A5 42 07            [12]  755 	orl	ar7,a
      0099A7 EB               [12]  756 	mov	a,r3
      0099A8 42 06            [12]  757 	orl	ar6,a
      0099AA 43 06 90         [24]  758 	orl	ar6,#0x90
      0099AD 12 45 86         [24]  759 	lcall	_ak820_outline_0156
      0099B0 22               [24]  760 	ret
      0099B1                        761 00125$:
                                    762 ;	quantum/keymap_common.c:123: if (kind != 0x52) return ACTION_NO;
      0099B1 BD 52 02         [24]  763 	cjne	r5,#0x52,00275$
      0099B4 80 04            [24]  764 	sjmp	00127$
      0099B6                        765 00275$:
      0099B6 90 00 00         [24]  766 	mov	dptr,#0x0000
      0099B9 22               [24]  767 	ret
      0099BA                        768 00127$:
                                    769 ;	quantum/keymap_common.c:124: mods = key & 0x1f;
      0099BA 74 1F            [12]  770 	mov	a,#0x1f
      0099BC 5C               [12]  771 	anl	a,r4
      0099BD FF               [12]  772 	mov	r7,a
                                    773 ;	quantum/keymap_common.c:125: switch (key >> 5) {
      0099BE EC               [12]  774 	mov	a,r4
      0099BF C4               [12]  775 	swap	a
      0099C0 03               [12]  776 	rr	a
      0099C1 54 07            [12]  777 	anl	a,#0x07
      0099C3 FE               [12]  778 	mov  r6,a
      0099C4 24 F9            [12]  779 	add	a,#0xff - 0x06
      0099C6 40 47            [24]  780 	jc	00134$
                                    781 ;	free result
      0099C8 EE               [12]  782 	mov	a,r6
      0099C9 2E               [12]  783 	add	a,r6
                                    784 ;	quantum/keymap_common.c:126: case 0: kind = (ACT_LAYER << 4) | (OP_BIT_SET << 2) | ON_PRESS; break;
      0099CA 90 99 CE         [24]  785 	mov	dptr,#00277$
      0099CD 73               [24]  786 	jmp	@a+dptr
      0099CE                        787 00277$:
      0099CE 80 0C            [24]  788 	sjmp	00128$
      0099D0 80 12            [24]  789 	sjmp	00129$
      0099D2 80 20            [24]  790 	sjmp	00130$
      0099D4 80 26            [24]  791 	sjmp	00132$
      0099D6 80 37            [24]  792 	sjmp	00134$
      0099D8 80 2A            [24]  793 	sjmp	00133$
      0099DA 80 20            [24]  794 	sjmp	00132$
      0099DC                        795 00128$:
      0099DC 90 0B BA         [24]  796 	mov	dptr,#_action_for_keycode_kind_10000_315
      0099DF 74 8D            [12]  797 	mov	a,#0x8d
      0099E1 F0               [24]  798 	movx	@dptr,a
                                    799 ;	quantum/keymap_common.c:127: case 1: return ACTION_LAYER_MOMENTARY(mods);
      0099E2 80 2F            [24]  800 	sjmp	00135$
      0099E4                        801 00129$:
      0099E4 8F 05            [24]  802 	mov	ar5,r7
      0099E6 8D 06            [24]  803 	mov	ar6,r5
      0099E8 7D 00            [12]  804 	mov	r5,#0x00
      0099EA 43 05 F1         [24]  805 	orl	ar5,#0xf1
      0099ED 43 06 A0         [24]  806 	orl	ar6,#0xa0
      0099F0 12 3A AA         [24]  807 	lcall	_ak820_outline_0131
                                    808 ;	quantum/keymap_common.c:128: case 2: kind = (ACT_LAYER << 4) | (OP_BIT_SET << 2); break;
      0099F3 22               [24]  809 	ret
      0099F4                        810 00130$:
      0099F4 90 0B BA         [24]  811 	mov	dptr,#_action_for_keycode_kind_10000_315
      0099F7 74 8C            [12]  812 	mov	a,#0x8c
      0099F9 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/keymap_common.c:130: case 6: kind = (ACT_LAYER << 4) | (OP_BIT_XOR << 2) | ON_RELEASE; break;
      0099FA 80 17            [24]  815 	sjmp	00135$
      0099FC                        816 00132$:
      0099FC 90 0B BA         [24]  817 	mov	dptr,#_action_for_keycode_kind_10000_315
      0099FF 74 8A            [12]  818 	mov	a,#0x8a
      009A01 F0               [24]  819 	movx	@dptr,a
                                    820 ;	quantum/keymap_common.c:131: case 5: return ACTION_MODS(mods); /* Existing held-mod fallback for OSM. */
      009A02 80 0F            [24]  821 	sjmp	00135$
      009A04                        822 00133$:
      009A04 53 07 1F         [24]  823 	anl	ar7,#0x1f
      009A07 8F 06            [24]  824 	mov	ar6,r7
      009A09 7F 00            [12]  825 	mov	r7,#0x00
      009A0B 12 45 86         [24]  826 	lcall	_ak820_outline_0156
                                    827 ;	quantum/keymap_common.c:132: default: return ACTION_NO;
      009A0E 22               [24]  828 	ret
      009A0F                        829 00134$:
      009A0F 90 00 00         [24]  830 	mov	dptr,#0x0000
                                    831 ;	quantum/keymap_common.c:133: }
      009A12 22               [24]  832 	ret
      009A13                        833 00135$:
                                    834 ;	quantum/keymap_common.c:135: key = ((key & 0x1c) << 3) | (1u << (key & 3));
      009A13 8C 07            [24]  835 	mov	ar7,r4
      009A15 53 07 1C         [24]  836 	anl	ar7,#0x1c
      009A18 EF               [12]  837 	mov	a,r7
      009A19 12 3A D0         [24]  838 	lcall	_ak820_outline_0186
      009A1C FF               [12]  839 	mov	r7,a
      009A1D 74 03            [12]  840 	mov	a,#0x03
      009A1F 5C               [12]  841 	anl	a,r4
      009A20 12 7B 56         [24]  842 	lcall	_ak820_outline_0062
      009A23 80 02            [24]  843 	sjmp	00279$
      009A25                        844 00278$:
      009A25 25 E0            [12]  845 	add	a,acc
      009A27                        846 00279$:
      009A27 D5 F0 FB         [24]  847 	djnz	b,00278$
      009A2A 42 07            [12]  848 	orl	ar7,a
                                    849 ;	quantum/keymap_common.c:136: return ((uint16_t)kind << 8) | key;
      009A2C 90 0B BA         [24]  850 	mov	dptr,#_action_for_keycode_kind_10000_315
      009A2F E0               [24]  851 	movx	a,@dptr
      009A30 FE               [12]  852 	mov	r6,a
      009A31 E4               [12]  853 	clr	a
      009A32 FD               [12]  854 	mov	r5,a
      009A33 FC               [12]  855 	mov	r4,a
      009A34 EF               [12]  856 	mov	a,r7
      009A35 42 05            [12]  857 	orl	ar5,a
      009A37 EC               [12]  858 	mov	a,r4
      009A38 42 06            [12]  859 	orl	ar6,a
      009A3A 12 3A AA         [24]  860 	lcall	_ak820_outline_0131
                                    861 ;	quantum/keymap_common.c:281: }
      009A3D 22               [24]  862 	ret
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'ak820_keycode_at'
                                    865 ;------------------------------------------------------------
                                    866 ;position      Allocated with name '_ak820_keycode_at_PARM_2'
                                    867 ;layer         Allocated with name '_ak820_keycode_at_layer_10000_334'
                                    868 ;row           Allocated with name '_ak820_keycode_at_row_10000_335'
                                    869 ;col           Allocated with name '_ak820_keycode_at_col_10000_335'
                                    870 ;------------------------------------------------------------
                                    871 ;	quantum/keymap_common.c:285: uint16_t ak820_keycode_at(uint8_t layer, uint16_t position) {
                                    872 ;	-----------------------------------------
                                    873 ;	 function ak820_keycode_at
                                    874 ;	-----------------------------------------
      009A3E                        875 _ak820_keycode_at:
      009A3E E5 82            [12]  876 	mov	a,dpl
      009A40 90 0B C1         [24]  877 	mov	dptr,#_ak820_keycode_at_layer_10000_334
      009A43 F0               [24]  878 	movx	@dptr,a
                                    879 ;	quantum/keymap_common.c:286: uint8_t row = position >> 8, col = position;
      009A44 90 0B BF         [24]  880 	mov	dptr,#_ak820_keycode_at_PARM_2
      009A47 E0               [24]  881 	movx	a,@dptr
      009A48 FE               [12]  882 	mov	r6,a
      009A49 A3               [24]  883 	inc	dptr
      009A4A E0               [24]  884 	movx	a,@dptr
      009A4B FD               [12]  885 	mov	r5,a
                                    886 ;	quantum/keymap_common.c:295: if (vial_unlock_in_progress) {
      009A4C 90 0E 23         [24]  887 	mov	dptr,#_vial_unlock_in_progress
      009A4F E0               [24]  888 	movx	a,@dptr
      009A50 60 04            [24]  889 	jz	00102$
                                    890 ;	quantum/keymap_common.c:296: return KC_NO;
      009A52 90 00 00         [24]  891 	mov	dptr,#0x0000
      009A55 22               [24]  892 	ret
      009A56                        893 00102$:
                                    894 ;	quantum/keymap_common.c:298: if (row == VIAL_MATRIX_MAGIC && col == VIAL_MATRIX_MAGIC) {
      009A56 BD F0 10         [24]  895 	cjne	r5,#0xf0,00104$
      009A59 BE F0 0D         [24]  896 	cjne	r6,#0xf0,00104$
                                    897 ;	quantum/keymap_common.c:299: return g_vial_magic_keycode_override;
      009A5C 90 0C 79         [24]  898 	mov	dptr,#_g_vial_magic_keycode_override
      009A5F E0               [24]  899 	movx	a,@dptr
      009A60 FC               [12]  900 	mov	r4,a
      009A61 A3               [24]  901 	inc	dptr
      009A62 E0               [24]  902 	movx	a,@dptr
      009A63 FF               [12]  903 	mov	r7,a
      009A64 8C 82            [24]  904 	mov	dpl, r4
      009A66 8F 83            [24]  905 	mov	dph, r7
      009A68 22               [24]  906 	ret
      009A69                        907 00104$:
                                    908 ;	quantum/keymap_common.c:302: if (row < MATRIX_ROWS && col < MATRIX_COLS) {
      009A69 BD 10 00         [24]  909 	cjne	r5,#0x10,00187$
      009A6C                        910 00187$:
      009A6C 50 19            [24]  911 	jnc	00114$
      009A6E BE 08 00         [24]  912 	cjne	r6,#0x08,00189$
      009A71                        913 00189$:
      009A71 50 14            [24]  914 	jnc	00114$
                                    915 ;	quantum/keymap_common.c:304: return keycode_at_keymap_location(layer, row, col);
      009A73 90 0B C1         [24]  916 	mov	dptr,#_ak820_keycode_at_layer_10000_334
      009A76 E0               [24]  917 	movx	a,@dptr
      009A77 FF               [12]  918 	mov	r7,a
      009A78 90 0B 4E         [24]  919 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      009A7B ED               [12]  920 	mov	a,r5
      009A7C F0               [24]  921 	movx	@dptr,a
      009A7D 90 0B 4F         [24]  922 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      009A80 EE               [12]  923 	mov	a,r6
      009A81 F0               [24]  924 	movx	@dptr,a
      009A82 8F 82            [24]  925 	mov	dpl, r7
      009A84 02 8E A2         [24]  926 	ljmp	_keycode_at_keymap_location
      009A87                        927 00114$:
                                    928 ;	quantum/keymap_common.c:307: else if (row == KEYLOC_ENCODER_CW && col < NUM_ENCODERS) {
      009A87 BD FD 0F         [24]  929 	cjne	r5,#0xfd,00110$
      009A8A BE 01 00         [24]  930 	cjne	r6,#0x01,00193$
      009A8D                        931 00193$:
      009A8D 50 0A            [24]  932 	jnc	00110$
                                    933 ;	quantum/keymap_common.c:308: return keycode_at_encodermap_location(layer, col, true);
      009A8F 12 9A AE         [24]  934 	lcall	_ak820_outline_0079
      009A92 04               [12]  935 	inc	a
      009A93 F0               [24]  936 	movx	@dptr,a
      009A94 8F 82            [24]  937 	mov	dpl, r7
      009A96 02 8E D5         [24]  938 	ljmp	_keycode_at_encodermap_location
      009A99                        939 00110$:
                                    940 ;	quantum/keymap_common.c:309: } else if (row == KEYLOC_ENCODER_CCW && col < NUM_ENCODERS) {
      009A99 BD FC 0E         [24]  941 	cjne	r5,#0xfc,00115$
      009A9C BE 01 00         [24]  942 	cjne	r6,#0x01,00197$
      009A9F                        943 00197$:
      009A9F 50 09            [24]  944 	jnc	00115$
                                    945 ;	quantum/keymap_common.c:310: return keycode_at_encodermap_location(layer, col, false);
      009AA1 12 9A AE         [24]  946 	lcall	_ak820_outline_0079
      009AA4 F0               [24]  947 	movx	@dptr,a
      009AA5 8F 82            [24]  948 	mov	dpl, r7
      009AA7 02 8E D5         [24]  949 	ljmp	_keycode_at_encodermap_location
      009AAA                        950 00115$:
                                    951 ;	quantum/keymap_common.c:313: return KC_NO;
      009AAA 90 00 00         [24]  952 	mov	dptr,#0x0000
                                    953 ;	quantum/keymap_common.c:314: }
      009AAD 22               [24]  954 	ret
                                    955 ;------------------------------------------------------------
                                    956 ;Allocation info for local variables in function 'keymap_key_to_keycode'
                                    957 ;------------------------------------------------------------
                                    958 ;key           Allocated with name '_keymap_key_to_keycode_PARM_2'
                                    959 ;layer         Allocated with name '_keymap_key_to_keycode_layer_10000_346'
                                    960 ;------------------------------------------------------------
                                    961 ;	quantum/keymap_common.c:317: __attribute__((weak)) uint16_t keymap_key_to_keycode(uint8_t layer, keypos_t key) {
                                    962 ;	-----------------------------------------
                                    963 	.area CSEG    (CODE)
                                    964 	.area CONST   (CODE)
                                    965 	.area XINIT   (CODE)
                                    966 	.area CABS    (ABS,CODE)
                                    967 
                                    968 ; Experimental exact instruction outlining.
                                    969 	.globl _ak820_outline_0050
                                    970 	.globl _ak820_outline_0062
                                    971 	.globl _ak820_outline_0079
                                    972 	.globl _ak820_outline_0103
                                    973 	.globl _ak820_outline_0104
                                    974 	.globl _ak820_outline_0116
                                    975 	.globl _ak820_outline_0119
                                    976 	.globl _ak820_outline_0123
                                    977 	.globl _ak820_outline_0131
                                    978 	.globl _ak820_outline_0142
                                    979 	.globl _ak820_outline_0156
                                    980 	.globl _ak820_outline_0186
                                    981 
                                    982 	.area CSEG (CODE)
                                    983 ; function ak820_outline_0079
      009AAE                        984 _ak820_outline_0079:
      009AAE 90 0B C1         [24]  985 	mov	dptr,#_ak820_keycode_at_layer_10000_334
      009AB1 E0               [24]  986 	movx	a,@dptr
      009AB2 FF               [12]  987 	mov	r7,a
      009AB3 90 0B 51         [24]  988 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      009AB6 E4               [12]  989 	clr	a
      009AB7 F0               [24]  990 	movx	@dptr,a
      009AB8 90 0B 52         [24]  991 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      009ABB 22               [24]  992 	ret
