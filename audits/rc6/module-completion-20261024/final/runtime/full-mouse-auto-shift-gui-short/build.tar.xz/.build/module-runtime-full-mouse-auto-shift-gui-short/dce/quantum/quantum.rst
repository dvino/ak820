                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _ak820_gui_process
                                     22 	.globl _mcu_reset
                                     23 	.globl _bootloader_jump
                                     24 	.globl _ak820_resolve_key
                                     25 	.globl _default_layer_set
                                     26 	.globl _clear_keyboard
                                     27 	.globl _unregister_weak_mods
                                     28 	.globl _register_weak_mods
                                     29 	.globl _unregister_mods
                                     30 	.globl _register_mods
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _eeconfig_disable
                                     34 	.globl _rgb_matrix_set_suspend_state
                                     35 	.globl _rgb_matrix_task
                                     36 	.globl _mDelaymS
                                     37 	.globl _ADC_START
                                     38 	.globl _S0_R_FIFO
                                     39 	.globl _S0_T_FIFO
                                     40 	.globl _S0_FREE
                                     41 	.globl _S0_IF_BYTE
                                     42 	.globl _S0_IF_FIRST
                                     43 	.globl _S0_IF_OV
                                     44 	.globl _S0_FST_ACT
                                     45 	.globl _CP_RL2
                                     46 	.globl _C_T2
                                     47 	.globl _TR2
                                     48 	.globl _EXEN2
                                     49 	.globl _TCLK
                                     50 	.globl _RCLK
                                     51 	.globl _EXF2
                                     52 	.globl _CAP1F
                                     53 	.globl _TF2
                                     54 	.globl _RI
                                     55 	.globl _TI
                                     56 	.globl _RB8
                                     57 	.globl _TB8
                                     58 	.globl _REN
                                     59 	.globl _SM2
                                     60 	.globl _SM1
                                     61 	.globl _SM0
                                     62 	.globl _IT0
                                     63 	.globl _IE0
                                     64 	.globl _IT1
                                     65 	.globl _IE1
                                     66 	.globl _TR0
                                     67 	.globl _TF0
                                     68 	.globl _TR1
                                     69 	.globl _TF1
                                     70 	.globl _P4_0
                                     71 	.globl _P4_1
                                     72 	.globl _P4_2
                                     73 	.globl _P4_3
                                     74 	.globl _P4_4
                                     75 	.globl _P4_5
                                     76 	.globl _P4_6
                                     77 	.globl _RXD
                                     78 	.globl _TXD
                                     79 	.globl _INT0
                                     80 	.globl _INT1
                                     81 	.globl _T0
                                     82 	.globl _T1
                                     83 	.globl _MOSI1
                                     84 	.globl _MISO1
                                     85 	.globl _SCK1
                                     86 	.globl _P3_0
                                     87 	.globl _P3_1
                                     88 	.globl _P3_2
                                     89 	.globl _P3_3
                                     90 	.globl _P3_4
                                     91 	.globl _P3_5
                                     92 	.globl _P3_6
                                     93 	.globl _P3_7
                                     94 	.globl _CAP1_
                                     95 	.globl _T2_
                                     96 	.globl _CAP2_
                                     97 	.globl _T2EX_
                                     98 	.globl _RXD1
                                     99 	.globl _TXD1
                                    100 	.globl _P2_0
                                    101 	.globl _P2_1
                                    102 	.globl _P2_2
                                    103 	.globl _P2_3
                                    104 	.globl _P2_4
                                    105 	.globl _P2_5
                                    106 	.globl _P2_6
                                    107 	.globl _P2_7
                                    108 	.globl _AIN0
                                    109 	.globl _AIN1
                                    110 	.globl _AIN2
                                    111 	.globl _AIN3
                                    112 	.globl _AIN4
                                    113 	.globl _AIN5
                                    114 	.globl _AIN6
                                    115 	.globl _AIN7
                                    116 	.globl _CAP1
                                    117 	.globl _T2
                                    118 	.globl _CAP2
                                    119 	.globl _T2EX
                                    120 	.globl _INT0_
                                    121 	.globl _SCS
                                    122 	.globl _MOSI
                                    123 	.globl _MISO
                                    124 	.globl _SCK
                                    125 	.globl _RXD1_
                                    126 	.globl _TXD1_
                                    127 	.globl _P1_0
                                    128 	.globl _P1_1
                                    129 	.globl _P1_2
                                    130 	.globl _P1_3
                                    131 	.globl _P1_4
                                    132 	.globl _P1_5
                                    133 	.globl _P1_6
                                    134 	.globl _P1_7
                                    135 	.globl _AIN8
                                    136 	.globl _AIN9
                                    137 	.globl _AIN10
                                    138 	.globl _AIN11
                                    139 	.globl _AIN12
                                    140 	.globl _AIN13
                                    141 	.globl _RXD_
                                    142 	.globl _TXD_
                                    143 	.globl _SCL0
                                    144 	.globl _SDA0
                                    145 	.globl _P0_0
                                    146 	.globl _P0_1
                                    147 	.globl _P0_2
                                    148 	.globl _P0_3
                                    149 	.globl _P0_4
                                    150 	.globl _P0_5
                                    151 	.globl _P0_6
                                    152 	.globl _P0_7
                                    153 	.globl _IE_SPI0
                                    154 	.globl _IE_USB
                                    155 	.globl _IE_ADC
                                    156 	.globl _IE_UART1
                                    157 	.globl _IE_PWM_I2C
                                    158 	.globl _IE_GPIO
                                    159 	.globl _IE_WDOG
                                    160 	.globl _PX0
                                    161 	.globl _PT0
                                    162 	.globl _PX1
                                    163 	.globl _PT1
                                    164 	.globl _PS
                                    165 	.globl _PT2
                                    166 	.globl _PL_FLAG
                                    167 	.globl _PH_FLAG
                                    168 	.globl _EX0
                                    169 	.globl _ET0
                                    170 	.globl _EX1
                                    171 	.globl _ET1
                                    172 	.globl _ES
                                    173 	.globl _ET2
                                    174 	.globl _E_DIS
                                    175 	.globl _EA
                                    176 	.globl _P
                                    177 	.globl _F1
                                    178 	.globl _OV
                                    179 	.globl _RS0
                                    180 	.globl _RS1
                                    181 	.globl _F0
                                    182 	.globl _AC
                                    183 	.globl _CY
                                    184 	.globl _I2CS_INT_ST
                                    185 	.globl _I2CX_INT
                                    186 	.globl _LED_STATUS
                                    187 	.globl _LED_DMA_H
                                    188 	.globl _LED_DMA_L
                                    189 	.globl _LED_DMA
                                    190 	.globl _LED_PWM_OE
                                    191 	.globl _LED_COMMON
                                    192 	.globl _ADC_CHAN
                                    193 	.globl _ADC_DAT_H
                                    194 	.globl _ADC_DAT_L
                                    195 	.globl _ADC_DAT
                                    196 	.globl _ADC_CTRL
                                    197 	.globl _SPI1_CK_SE
                                    198 	.globl _SPI1_CTRL
                                    199 	.globl _SPI1_DATA
                                    200 	.globl _SPI1_STAT
                                    201 	.globl _SIF1
                                    202 	.globl _SBAUD1
                                    203 	.globl _SBUF1
                                    204 	.globl _SCON1
                                    205 	.globl _SPI0_SETUP
                                    206 	.globl _SPI0_CK_SE
                                    207 	.globl _SPI0_CTRL
                                    208 	.globl _SPI0_DATA
                                    209 	.globl _SPI0_STAT
                                    210 	.globl _T2CAP1H
                                    211 	.globl _T2CAP1L
                                    212 	.globl _T2CAP1
                                    213 	.globl _TH2
                                    214 	.globl _TL2
                                    215 	.globl _T2COUNT
                                    216 	.globl _RCAP2H
                                    217 	.globl _RCAP2L
                                    218 	.globl _RCAP2
                                    219 	.globl _T2MOD
                                    220 	.globl _T2CON
                                    221 	.globl _SBUF
                                    222 	.globl _SCON
                                    223 	.globl _TH1
                                    224 	.globl _TH0
                                    225 	.globl _TL1
                                    226 	.globl _TL0
                                    227 	.globl _TMOD
                                    228 	.globl _TCON
                                    229 	.globl _XBUS_AUX
                                    230 	.globl _P7
                                    231 	.globl _P6_DIR
                                    232 	.globl _P6_OUT_PU
                                    233 	.globl _P6_IN
                                    234 	.globl _P5_DIR
                                    235 	.globl _P5_OUT_PU
                                    236 	.globl _P5_IN
                                    237 	.globl _P4_LED_KEY
                                    238 	.globl _P4_DIR_PU
                                    239 	.globl _P4_MOD_OC
                                    240 	.globl _P4
                                    241 	.globl _P3_DIR_PU
                                    242 	.globl _P3_MOD_OC
                                    243 	.globl _P3
                                    244 	.globl _P2_DIR_PU
                                    245 	.globl _P2_MOD_OC
                                    246 	.globl _P2
                                    247 	.globl _P1_DIR_PU
                                    248 	.globl _P1_MOD_OC
                                    249 	.globl _P1
                                    250 	.globl _P0_DIR_PU
                                    251 	.globl _P0_MOD_OC
                                    252 	.globl _P0
                                    253 	.globl _ROM_CTRL
                                    254 	.globl _ROM_DATA_HH
                                    255 	.globl _ROM_DATA_HL
                                    256 	.globl _ROM_DATA_HI
                                    257 	.globl _ROM_ADDR_H
                                    258 	.globl _ROM_ADDR_L
                                    259 	.globl _ROM_ADDR
                                    260 	.globl _GPIO_IE
                                    261 	.globl _IP_EX
                                    262 	.globl _IE_EX
                                    263 	.globl _IP
                                    264 	.globl _IE
                                    265 	.globl _WDOG_COUNT
                                    266 	.globl _RESET_KEEP
                                    267 	.globl _WAKE_CTRL
                                    268 	.globl _CLOCK_CFG
                                    269 	.globl _POWER_CFG
                                    270 	.globl _PCON
                                    271 	.globl _GLOBAL_CFG
                                    272 	.globl _SAFE_MOD
                                    273 	.globl _DPH
                                    274 	.globl _DPL
                                    275 	.globl _SP
                                    276 	.globl _A_INV
                                    277 	.globl _B
                                    278 	.globl _ACC
                                    279 	.globl _PSW
                                    280 	.globl _process_record_quantum_helper_PARM_2
                                    281 	.globl _get_record_keycode_PARM_2
                                    282 	.globl _register_code16
                                    283 	.globl _unregister_code16
                                    284 	.globl _reset_keyboard
                                    285 	.globl _soft_reset_keyboard
                                    286 	.globl _get_record_keycode
                                    287 	.globl _pre_process_record_quantum
                                    288 	.globl _process_record_quantum
                                    289 	.globl _process_record_quantum_helper
                                    290 	.globl _shutdown_user
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
                                    553 ;--------------------------------------------------------
                                    554 ; overlayable items in internal ram
                                    555 ;--------------------------------------------------------
                                    556 ;--------------------------------------------------------
                                    557 ; indirectly addressable internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area ISEG    (DATA)
                                    560 ;--------------------------------------------------------
                                    561 ; absolute internal ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area IABS    (ABS,DATA)
                                    564 	.area IABS    (ABS,DATA)
                                    565 ;--------------------------------------------------------
                                    566 ; bit data
                                    567 ;--------------------------------------------------------
                                    568 	.area BSEG    (BIT)
      000026                        569 _get_record_keycode_sloc0_1_0:
      000026                        570 	.ds 1
      000027                        571 _pre_process_record_quantum_sloc0_1_0:
      000027                        572 	.ds 1
      000028                        573 _process_ak820_nkro_sloc0_1_0:
      000028                        574 	.ds 1
                                    575 ;--------------------------------------------------------
                                    576 ; paged external ram data
                                    577 ;--------------------------------------------------------
                                    578 	.area PSEG    (PAG,XDATA)
                                    579 ;--------------------------------------------------------
                                    580 ; uninitialized external ram data
                                    581 ;--------------------------------------------------------
                                    582 	.area XSEG    (XDATA)
      000BFD                        583 _extract_mod_bits_code_10000_601:
      000BFD                        584 	.ds 2
      000BFF                        585 _register_code16_code_10000_607:
      000BFF                        586 	.ds 2
      000C01                        587 _unregister_code16_code_10000_612:
      000C01                        588 	.ds 2
      000C03                        589 _get_record_keycode_PARM_2:
      000C03                        590 	.ds 1
      000C04                        591 _get_record_keycode_record_argument_10000_650:
      000C04                        592 	.ds 2
      000C06                        593 _pre_process_record_quantum_record_argument_10000_656:
      000C06                        594 	.ds 2
      000C08                        595 _process_record_quantum_record_10000_660:
      000C08                        596 	.ds 2
      000C0A                        597 _process_ak820_nkro_PARM_2:
      000C0A                        598 	.ds 3
      000C0D                        599 _process_ak820_nkro_keycode_10000_662:
      000C0D                        600 	.ds 2
      000C0F                        601 _process_record_quantum_helper_PARM_2:
      000C0F                        602 	.ds 2
      000C11                        603 _process_record_quantum_helper_keycode_10000_667:
      000C11                        604 	.ds 2
      000C13                        605 _get_u8_str_last_num_10000_693:
      000C13                        606 	.ds 1
      000C14                        607 _get_u16_str_last_num_10000_697:
      000C14                        608 	.ds 2
                                    609 ;--------------------------------------------------------
                                    610 ; absolute external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XABS    (ABS,XDATA)
                                    613 ;--------------------------------------------------------
                                    614 ; initialized external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area XISEG   (XDATA)
                                    617 	.area HOME    (CODE)
                                    618 	.area GSINIT0 (CODE)
                                    619 	.area GSINIT1 (CODE)
                                    620 	.area GSINIT2 (CODE)
                                    621 	.area GSINIT3 (CODE)
                                    622 	.area GSINIT4 (CODE)
                                    623 	.area GSINIT5 (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area CSEG    (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; global & static initialisations
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area GSINIT  (CODE)
                                    632 	.area GSFINAL (CODE)
                                    633 	.area GSINIT  (CODE)
                                    634 ;------------------------------------------------------------
                                    635 ;Allocation info for local variables in function 'get_u8_str'
                                    636 ;------------------------------------------------------------
                                    637 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    638 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_692'
                                    639 ;buf           Allocated with name '_get_u8_str_buf_10000_693'
                                    640 ;last_num      Allocated with name '_get_u8_str_last_num_10000_693'
                                    641 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_693'
                                    642 ;------------------------------------------------------------
                                    643 ;	quantum/quantum.c:789: static uint8_t last_num = 0xFF;
      0030F3 90 0C 13         [24]  644 	mov	dptr,#_get_u8_str_last_num_10000_693
      0030F6 74 FF            [12]  645 	mov	a,#0xff
      0030F8 F0               [24]  646 	movx	@dptr,a
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'get_u16_str'
                                    649 ;------------------------------------------------------------
                                    650 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    651 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_696'
                                    652 ;buf           Allocated with name '_get_u16_str_buf_10000_697'
                                    653 ;last_num      Allocated with name '_get_u16_str_last_num_10000_697'
                                    654 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_697'
                                    655 ;------------------------------------------------------------
                                    656 ;	quantum/quantum.c:809: static uint16_t last_num = 0xFF;
      0030F9 90 0C 14         [24]  657 	mov	dptr,#_get_u16_str_last_num_10000_697
      0030FC 74 FF            [12]  658 	mov	a,#0xff
      0030FE F0               [24]  659 	movx	@dptr,a
      0030FF E4               [12]  660 	clr	a
      003100 A3               [24]  661 	inc	dptr
      003101 F0               [24]  662 	movx	@dptr,a
                                    663 ;--------------------------------------------------------
                                    664 ; Home
                                    665 ;--------------------------------------------------------
                                    666 	.area HOME    (CODE)
                                    667 	.area HOME    (CODE)
                                    668 ;--------------------------------------------------------
                                    669 ; code
                                    670 ;--------------------------------------------------------
                                    671 	.area CSEG    (CODE)
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    674 ;------------------------------------------------------------
                                    675 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    676 ;------------------------------------------------------------
                                    677 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    678 ;	-----------------------------------------
                           000007   679 	ar7 = 0x07
                           000006   680 	ar6 = 0x06
                           000005   681 	ar5 = 0x05
                           000004   682 	ar4 = 0x04
                           000003   683 	ar3 = 0x03
                           000002   684 	ar2 = 0x02
                           000001   685 	ar1 = 0x01
                           000000   686 	ar0 = 0x00
                                    687 ;	 function extract_mod_bits
                                    688 ;	-----------------------------------------
      00A124                        689 _extract_mod_bits:
      00A124 12 3A 83         [24]  690 	lcall	_ak820_outline_0103
      00A127 90 0B FD         [24]  691 	mov	dptr,#_extract_mod_bits_code_10000_601
      00A12A 12 3A 88         [24]  692 	lcall	_ak820_outline_0104
                                    693 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      00A12D 90 0B FD         [24]  694 	mov	dptr,#_extract_mod_bits_code_10000_601
      00A130 E0               [24]  695 	movx	a,@dptr
      00A131 A3               [24]  696 	inc	dptr
      00A132 E0               [24]  697 	movx	a,@dptr
                                    698 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A133 FF               [12]  699 	mov	r7,a
      00A134 60 05            [24]  700 	jz	00101$
      00A136 EF               [12]  701 	mov	a,r7
      00A137 24 E0            [12]  702 	add	a,#0xff - 0x1f
      00A139 50 04            [24]  703 	jnc	00102$
                                    704 ;	free result
      00A13B                        705 00101$:
      00A13B 75 82 00         [24]  706 	mov	dpl, #0x00
      00A13E 22               [24]  707 	ret
      00A13F                        708 00102$:
                                    709 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A13F EF               [12]  710 	mov	a,r7
      00A140 30 E4 07         [24]  711 	jnb	acc.4,00106$
      00A143 EF               [12]  712 	mov	a,r7
      00A144 C4               [12]  713 	swap	a
      00A145 54 F0            [12]  714 	anl	a,#0xf0
      00A147 FE               [12]  715 	mov	r6,a
      00A148 80 02            [24]  716 	sjmp	00107$
      00A14A                        717 00106$:
      00A14A 8F 06            [24]  718 	mov	ar6,r7
      00A14C                        719 00107$:
      00A14C 8E 82            [24]  720 	mov	dpl, r6
                                    721 ;	quantum/quantum.c:143: }
      00A14E 22               [24]  722 	ret
                                    723 ;------------------------------------------------------------
                                    724 ;Allocation info for local variables in function 'do_code16'
                                    725 ;------------------------------------------------------------
                                    726 ;f             Allocated with name '_do_code16_PARM_2'
                                    727 ;code          Allocated with name '_do_code16_code_10000_604'
                                    728 ;------------------------------------------------------------
                                    729 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    730 ;	-----------------------------------------
                                    731 ;	 function register_code16
                                    732 ;	-----------------------------------------
      00A14F                        733 _register_code16:
      00A14F 12 3A 83         [24]  734 	lcall	_ak820_outline_0103
      00A152 90 0B FF         [24]  735 	mov	dptr,#_register_code16_code_10000_607
      00A155 12 3A 88         [24]  736 	lcall	_ak820_outline_0104
                                    737 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      00A158 90 0B FF         [24]  738 	mov	dptr,#_register_code16_code_10000_607
      00A15B 12 39 E0         [24]  739 	lcall	_ak820_outline_0004
      00A15E C0 07            [24]  740 	push	ar7
      00A160 C0 06            [24]  741 	push	ar6
      00A162 31 24            [12]  742 	acall	_extract_mod_bits
      00A164 AD 82            [24]  743 	mov	r5, dpl
      00A166 D0 06            [24]  744 	pop	ar6
      00A168 D0 07            [24]  745 	pop	ar7
                                    746 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A16A 12 9F 65         [24]  747 	lcall	_ak820_outline_0114
      00A16D 40 07            [24]  748 	jc	00105$
      00A16F 74 E7            [12]  749 	mov	a,#0xe7
      00A171 9E               [12]  750 	subb	a,r6
      00A172 E4               [12]  751 	clr	a
      00A173 9F               [12]  752 	subb	a,r7
      00A174 50 08            [24]  753 	jnc	00101$
                                    754 ;	free result
      00A176                        755 00105$:
      00A176 90 0B FF         [24]  756 	mov	dptr,#_register_code16_code_10000_607
      00A179 12 71 C3         [24]  757 	lcall	_ak820_outline_0035
      00A17C 70 07            [24]  758 	jnz	00102$
      00A17E                        759 00101$:
                                    760 ;	quantum/quantum.c:153: register_mods(mods);
      00A17E 8D 82            [24]  761 	mov	dpl, r5
      00A180 12 7A 9D         [24]  762 	lcall	_register_mods
      00A183 80 05            [24]  763 	sjmp	00103$
      00A185                        764 00102$:
                                    765 ;	quantum/quantum.c:155: register_weak_mods(mods);
      00A185 8D 82            [24]  766 	mov	dpl, r5
      00A187 12 7A C5         [24]  767 	lcall	_register_weak_mods
      00A18A                        768 00103$:
                                    769 ;	quantum/quantum.c:157: register_code(code);
      00A18A 90 0B FF         [24]  770 	mov	dptr,#_register_code16_code_10000_607
      00A18D E0               [24]  771 	movx	a,@dptr
      00A18E F5 82            [12]  772 	mov	dpl,a
                                    773 ;	quantum/quantum.c:167: }
      00A190 02 79 50         [24]  774 	ljmp	_register_code
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'unregister_code16'
                                    777 ;------------------------------------------------------------
                                    778 ;code          Allocated with name '_unregister_code16_code_10000_612'
                                    779 ;mods          Allocated with name '_unregister_code16_mods_10000_613'
                                    780 ;------------------------------------------------------------
                                    781 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    782 ;	-----------------------------------------
                                    783 ;	 function unregister_code16
                                    784 ;	-----------------------------------------
      00A193                        785 _unregister_code16:
      00A193 12 3A 83         [24]  786 	lcall	_ak820_outline_0103
      00A196 90 0C 01         [24]  787 	mov	dptr,#_unregister_code16_code_10000_612
      00A199 12 3A 88         [24]  788 	lcall	_ak820_outline_0104
                                    789 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      00A19C 90 0C 01         [24]  790 	mov	dptr,#_unregister_code16_code_10000_612
      00A19F 12 39 E0         [24]  791 	lcall	_ak820_outline_0004
      00A1A2 C0 07            [24]  792 	push	ar7
      00A1A4 C0 06            [24]  793 	push	ar6
      00A1A6 31 24            [12]  794 	acall	_extract_mod_bits
      00A1A8 AD 82            [24]  795 	mov	r5, dpl
      00A1AA D0 06            [24]  796 	pop	ar6
                                    797 ;	quantum/quantum.c:172: unregister_code(code);
      00A1AC 8E 04            [24]  798 	mov	ar4,r6
      00A1AE 8C 82            [24]  799 	mov	dpl, r4
      00A1B0 C0 06            [24]  800 	push	ar6
      00A1B2 C0 05            [24]  801 	push	ar5
      00A1B4 12 79 D5         [24]  802 	lcall	_unregister_code
      00A1B7 D0 05            [24]  803 	pop	ar5
      00A1B9 D0 06            [24]  804 	pop	ar6
      00A1BB D0 07            [24]  805 	pop	ar7
                                    806 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A1BD 12 9F 65         [24]  807 	lcall	_ak820_outline_0114
      00A1C0 40 07            [24]  808 	jc	00105$
      00A1C2 74 E7            [12]  809 	mov	a,#0xe7
      00A1C4 9E               [12]  810 	subb	a,r6
      00A1C5 E4               [12]  811 	clr	a
      00A1C6 9F               [12]  812 	subb	a,r7
      00A1C7 50 08            [24]  813 	jnc	00101$
                                    814 ;	free result
      00A1C9                        815 00105$:
      00A1C9 90 0C 01         [24]  816 	mov	dptr,#_unregister_code16_code_10000_612
      00A1CC 12 71 C3         [24]  817 	lcall	_ak820_outline_0035
      00A1CF 70 05            [24]  818 	jnz	00102$
      00A1D1                        819 00101$:
                                    820 ;	quantum/quantum.c:174: unregister_mods(mods);
      00A1D1 8D 82            [24]  821 	mov	dpl, r5
      00A1D3 02 7A B1         [24]  822 	ljmp	_unregister_mods
      00A1D6                        823 00102$:
                                    824 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      00A1D6 8D 82            [24]  825 	mov	dpl, r5
                                    826 ;	quantum/quantum.c:187: }
      00A1D8 02 7A D9         [24]  827 	ljmp	_unregister_weak_mods
                                    828 ;------------------------------------------------------------
                                    829 ;Allocation info for local variables in function 'tap_code16_delay'
                                    830 ;------------------------------------------------------------
                                    831 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    832 ;code          Allocated with name '_tap_code16_delay_code_10000_617'
                                    833 ;i             Allocated with name '_tap_code16_delay_i_20000_619'
                                    834 ;i             Allocated with name '_tap_code16_delay_i_50000_622'
                                    835 ;------------------------------------------------------------
                                    836 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    837 ;	-----------------------------------------
                                    838 ;	 function shutdown_quantum
                                    839 ;	-----------------------------------------
      00A1DB                        840 _shutdown_quantum:
                                    841 ;	quantum/quantum.c:237: clear_keyboard();
      00A1DB 12 7A ED         [24]  842 	lcall	_clear_keyboard
                                    843 ;	quantum/quantum.c:252: shutdown_user();
      00A1DE 91 76            [12]  844 	acall	_shutdown_user
                                    845 ;	quantum/quantum.c:253: wait_ms(250);
      00A1E0 7F FA            [12]  846 	mov	r7,#0xfa
      00A1E2                        847 00106$:
      00A1E2 EF               [12]  848 	mov	a,r7
      00A1E3 60 09            [24]  849 	jz	00108$
      00A1E5 90 00 01         [24]  850 	mov	dptr,#0x0001
      00A1E8 12 5D 2B         [24]  851 	lcall	_mDelaymS
      00A1EB 1F               [12]  852 	dec	r7
      00A1EC 80 F4            [24]  853 	sjmp	00106$
      00A1EE                        854 00108$:
                                    855 ;	quantum/quantum.c:258: }
      00A1EE 22               [24]  856 	ret
                                    857 ;------------------------------------------------------------
                                    858 ;Allocation info for local variables in function 'reset_keyboard'
                                    859 ;------------------------------------------------------------
                                    860 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                    861 ;	-----------------------------------------
                                    862 ;	 function reset_keyboard
                                    863 ;	-----------------------------------------
      00A1EF                        864 _reset_keyboard:
                                    865 ;	quantum/quantum.c:261: shutdown_quantum();
      00A1EF 31 DB            [12]  866 	acall	_shutdown_quantum
                                    867 ;	quantum/quantum.c:262: bootloader_jump();
                                    868 ;	quantum/quantum.c:263: }
      00A1F1 02 36 54         [24]  869 	ljmp	_bootloader_jump
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                    872 ;------------------------------------------------------------
                                    873 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function soft_reset_keyboard
                                    876 ;	-----------------------------------------
      00A1F4                        877 _soft_reset_keyboard:
                                    878 ;	quantum/quantum.c:266: shutdown_quantum();
      00A1F4 31 DB            [12]  879 	acall	_shutdown_quantum
                                    880 ;	quantum/quantum.c:267: mcu_reset();
                                    881 ;	quantum/quantum.c:268: }
      00A1F6 02 36 47         [24]  882 	ljmp	_mcu_reset
                                    883 ;------------------------------------------------------------
                                    884 ;Allocation info for local variables in function 'get_record_keycode'
                                    885 ;------------------------------------------------------------
                                    886 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                    887 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_650'
                                    888 ;record        Allocated with name '_get_record_keycode_record_10000_651'
                                    889 ;------------------------------------------------------------
                                    890 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                    891 ;	-----------------------------------------
                                    892 ;	 function get_record_keycode
                                    893 ;	-----------------------------------------
      00A1F9                        894 _get_record_keycode:
      00A1F9 12 3A 83         [24]  895 	lcall	_ak820_outline_0103
      00A1FC 90 0C 04         [24]  896 	mov	dptr,#_get_record_keycode_record_argument_10000_650
      00A1FF 12 3A 88         [24]  897 	lcall	_ak820_outline_0104
                                    898 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A202 90 0C 04         [24]  899 	mov	dptr,#_get_record_keycode_record_argument_10000_650
      00A205 12 39 F7         [24]  900 	lcall	_ak820_outline_0008
                                    901 ;	quantum/quantum.c:278: if (record->keycode) {
      00A208 4C               [12]  902 	orl	a,r4
      00A209 60 04            [24]  903 	jz	00102$
                                    904 ;	quantum/quantum.c:279: return record->keycode;
      00A20B 12 3A A0         [24]  905 	lcall	_ak820_outline_0121
      00A20E 22               [24]  906 	ret
      00A20F                        907 00102$:
                                    908 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A20F 12 7B 35         [24]  909 	lcall	_ak820_outline_0018
      00A212 7A 00            [12]  910 	mov	r2,#0x00
      00A214 12 45 76         [24]  911 	lcall	_ak820_outline_0141
      00A217 12 39 EA         [24]  912 	lcall	_ak820_outline_0005
      00A21A 60 06            [24]  913 	jz	00105$
      00A21C 90 0C 03         [24]  914 	mov	dptr,#_get_record_keycode_PARM_2
      00A21F E0               [24]  915 	movx	a,@dptr
      00A220 70 04            [24]  916 	jnz	00106$
      00A222                        917 00105$:
                                    918 ;	assignBit
      00A222 C2 26            [12]  919 	clr	_get_record_keycode_sloc0_1_0
      00A224 80 02            [24]  920 	sjmp	00107$
      00A226                        921 00106$:
                                    922 ;	assignBit
      00A226 D2 26            [12]  923 	setb	_get_record_keycode_sloc0_1_0
      00A228                        924 00107$:
      00A228 90 09 90         [24]  925 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A22B A2 26            [12]  926 	mov	c,_get_record_keycode_sloc0_1_0
      00A22D E4               [12]  927 	clr	a
      00A22E 33               [12]  928 	rlc	a
      00A22F F0               [24]  929 	movx	@dptr,a
      00A230 8D 82            [24]  930 	mov	dpl, r5
      00A232 8C 83            [24]  931 	mov	dph, r4
                                    932 ;	quantum/quantum.c:287: }
      00A234 02 7E C0         [24]  933 	ljmp	_ak820_resolve_key
                                    934 ;------------------------------------------------------------
                                    935 ;Allocation info for local variables in function 'get_event_keycode'
                                    936 ;------------------------------------------------------------
                                    937 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                    938 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_654'
                                    939 ;------------------------------------------------------------
                                    940 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                    941 ;	-----------------------------------------
                                    942 ;	 function pre_process_record_quantum
                                    943 ;	-----------------------------------------
      00A237                        944 _pre_process_record_quantum:
      00A237 12 3A 83         [24]  945 	lcall	_ak820_outline_0103
      00A23A 90 0C 06         [24]  946 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_656
      00A23D 12 3A 88         [24]  947 	lcall	_ak820_outline_0104
                                    948 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A240 90 0C 06         [24]  949 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_656
      00A243 12 3A 40         [24]  950 	lcall	_ak820_outline_0050
                                    951 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      00A246 90 0C 03         [24]  952 	mov	dptr,#_get_record_keycode_PARM_2
      00A249 12 4A 7E         [24]  953 	lcall	_ak820_outline_0054
      00A24C C0 07            [24]  954 	push	ar7
      00A24E C0 06            [24]  955 	push	ar6
      00A250 31 F9            [12]  956 	acall	_get_record_keycode
      00A252 12 45 81         [24]  957 	lcall	_ak820_outline_0148
      00A255 D0 06            [24]  958 	pop	ar6
      00A257 D0 07            [24]  959 	pop	ar7
                                    960 ;	quantum/quantum.c:334: record->keycode = keycode;
      00A259 74 07            [12]  961 	mov	a,#0x07
      00A25B 12 3A 30         [24]  962 	lcall	_ak820_outline_0030
      00A25E EC               [12]  963 	mov	a,r4
      00A25F F0               [24]  964 	movx	@dptr,a
      00A260 ED               [12]  965 	mov	a,r5
      00A261 A3               [24]  966 	inc	dptr
      00A262 12 45 42         [24]  967 	lcall	_ak820_outline_0060
                                    968 ;	quantum/quantum.c:361: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A265 12 38 34         [24]  969 	lcall	_ak820_combo_process
      00A268 E5 82            [12]  970 	mov	a, dpl
      00A26A 70 04            [24]  971 	jnz	00104$
                                    972 ;	quantum/quantum.c:366: true;
                                    973 ;	assignBit
      00A26C C2 27            [12]  974 	clr	_pre_process_record_quantum_sloc0_1_0
      00A26E 80 02            [24]  975 	sjmp	00105$
      00A270                        976 00104$:
                                    977 ;	assignBit
      00A270 D2 27            [12]  978 	setb	_pre_process_record_quantum_sloc0_1_0
      00A272                        979 00105$:
      00A272 A2 27            [12]  980 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A274 12 3A C6         [24]  981 	lcall	_ak820_outline_0166
                                    982 ;	quantum/quantum.c:367: }
      00A277 22               [24]  983 	ret
                                    984 ;------------------------------------------------------------
                                    985 ;Allocation info for local variables in function 'post_process_record_quantum'
                                    986 ;------------------------------------------------------------
                                    987 ;record        Allocated with name '_post_process_record_quantum_record_10000_658'
                                    988 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_659'
                                    989 ;------------------------------------------------------------
                                    990 ;	quantum/quantum.c:370: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                    991 ;	-----------------------------------------
                                    992 ;	 function process_record_quantum
                                    993 ;	-----------------------------------------
      00A278                        994 _process_record_quantum:
      00A278 12 3A 83         [24]  995 	lcall	_ak820_outline_0103
      00A27B 90 0C 08         [24]  996 	mov	dptr,#_process_record_quantum_record_10000_660
      00A27E 12 3A 88         [24]  997 	lcall	_ak820_outline_0104
                                    998 ;	quantum/quantum.c:377: uint16_t keycode = get_record_keycode(record, false);
      00A281 90 0C 08         [24]  999 	mov	dptr,#_process_record_quantum_record_10000_660
      00A284 12 3A 40         [24] 1000 	lcall	_ak820_outline_0050
      00A287 90 0C 03         [24] 1001 	mov	dptr,#_get_record_keycode_PARM_2
      00A28A E4               [12] 1002 	clr	a
      00A28B 12 45 42         [24] 1003 	lcall	_ak820_outline_0060
      00A28E 31 F9            [12] 1004 	acall	_get_record_keycode
      00A290 12 45 6B         [24] 1005 	lcall	_ak820_outline_0132
                                   1006 ;	quantum/quantum.c:381: return process_record_quantum_helper(keycode, record);
      00A293 90 0C 08         [24] 1007 	mov	dptr,#_process_record_quantum_record_10000_660
      00A296 12 3A 5F         [24] 1008 	lcall	_ak820_outline_0059
      00A299 90 0C 0F         [24] 1009 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A29C EC               [12] 1010 	mov	a,r4
      00A29D F0               [24] 1011 	movx	@dptr,a
      00A29E ED               [12] 1012 	mov	a,r5
      00A29F A3               [24] 1013 	inc	dptr
      00A2A0 12 45 42         [24] 1014 	lcall	_ak820_outline_0060
                                   1015 ;	quantum/quantum.c:382: }
      00A2A3 61 10            [24] 1016 	ajmp	_process_record_quantum_helper
                                   1017 ;------------------------------------------------------------
                                   1018 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1019 ;------------------------------------------------------------
                                   1020 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1021 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_662'
                                   1022 ;record        Allocated with name '_process_ak820_nkro_record_10000_663'
                                   1023 ;------------------------------------------------------------
                                   1024 ;	quantum/quantum.c:399: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1025 ;	-----------------------------------------
                                   1026 ;	 function process_ak820_nkro
                                   1027 ;	-----------------------------------------
      00A2A5                       1028 _process_ak820_nkro:
      00A2A5 12 3A 83         [24] 1029 	lcall	_ak820_outline_0103
      00A2A8 90 0C 0D         [24] 1030 	mov	dptr,#_process_ak820_nkro_keycode_10000_662
      00A2AB 12 3A 88         [24] 1031 	lcall	_ak820_outline_0104
                                   1032 ;	quantum/quantum.c:401: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A2AE 90 0C 0A         [24] 1033 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A2B1 12 3A 40         [24] 1034 	lcall	_ak820_outline_0050
                                   1035 ;	quantum/quantum.c:405: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A2B4 90 0C 0D         [24] 1036 	mov	dptr,#_process_ak820_nkro_keycode_10000_662
      00A2B7 12 3A 5F         [24] 1037 	lcall	_ak820_outline_0059
      00A2BA C3               [12] 1038 	clr	c
      00A2BB EC               [12] 1039 	mov	a,r4
      00A2BC 94 11            [12] 1040 	subb	a,#0x11
      00A2BE ED               [12] 1041 	mov	a,r5
      00A2BF 94 70            [12] 1042 	subb	a,#0x70
      00A2C1 40 08            [24] 1043 	jc	00101$
      00A2C3 74 13            [12] 1044 	mov	a,#0x13
      00A2C5 9C               [12] 1045 	subb	a,r4
      00A2C6 74 70            [12] 1046 	mov	a,#0x70
      00A2C8 9D               [12] 1047 	subb	a,r5
      00A2C9 50 04            [24] 1048 	jnc	00102$
                                   1049 ;	free result
      00A2CB                       1050 00101$:
      00A2CB 75 82 01         [24] 1051 	mov	dpl, #0x01
      00A2CE 22               [24] 1052 	ret
      00A2CF                       1053 00102$:
                                   1054 ;	quantum/quantum.c:406: if (record->event.pressed) {
      00A2CF 12 39 EA         [24] 1055 	lcall	_ak820_outline_0005
      00A2D2 60 38            [24] 1056 	jz	00105$
                                   1057 ;	quantum/quantum.c:407: clear_keyboard();
      00A2D4 C0 05            [24] 1058 	push	ar5
      00A2D6 C0 04            [24] 1059 	push	ar4
      00A2D8 12 7A ED         [24] 1060 	lcall	_clear_keyboard
      00A2DB D0 04            [24] 1061 	pop	ar4
      00A2DD D0 05            [24] 1062 	pop	ar5
                                   1063 ;	quantum/quantum.c:408: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A2DF BC 13 14         [24] 1064 	cjne	r4,#0x13,00108$
      00A2E2 BD 70 11         [24] 1065 	cjne	r5,#0x70,00108$
      00A2E5 90 0A E5         [24] 1066 	mov	dptr,#_keymap_config
      00A2E8 E0               [24] 1067 	movx	a,@dptr
      00A2E9 23               [12] 1068 	rl	a
      00A2EA 54 01            [12] 1069 	anl	a,#0x01
      00A2EC B4 01 00         [24] 1070 	cjne	a,#0x01,00136$
      00A2EF                       1071 00136$:
      00A2EF 92 28            [24] 1072 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A2F1 E4               [12] 1073 	clr	a
      00A2F2 33               [12] 1074 	rlc	a
      00A2F3 FF               [12] 1075 	mov	r7,a
      00A2F4 80 09            [24] 1076 	sjmp	00109$
      00A2F6                       1077 00108$:
      00A2F6 E4               [12] 1078 	clr	a
      00A2F7 BC 11 04         [24] 1079 	cjne	r4,#0x11,00137$
      00A2FA BD 70 01         [24] 1080 	cjne	r5,#0x70,00137$
      00A2FD 04               [12] 1081 	inc	a
      00A2FE                       1082 00137$:
      00A2FE FF               [12] 1083 	mov	r7,a
      00A2FF                       1084 00109$:
                                   1085 ;	assignBit
      00A2FF EF               [12] 1086 	mov	a,r7
      00A300 24 FF            [12] 1087 	add	a,#0xff
      00A302 E4               [12] 1088 	clr	a
      00A303 33               [12] 1089 	rlc	a
      00A304 90 0A E5         [24] 1090 	mov	dptr,#_keymap_config
      00A307 13               [12] 1091 	rrc	a
      00A308 E0               [24] 1092 	movx	a,@dptr
      00A309 92 E7            [24] 1093 	mov	acc.7,c
      00A30B F0               [24] 1094 	movx	@dptr,a
      00A30C                       1095 00105$:
                                   1096 ;	quantum/quantum.c:410: return false;
      00A30C 75 82 00         [24] 1097 	mov	dpl, #0x00
                                   1098 ;	quantum/quantum.c:411: }
      00A30F 22               [24] 1099 	ret
                                   1100 ;------------------------------------------------------------
                                   1101 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1102 ;------------------------------------------------------------
                                   1103 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1104 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_667'
                                   1105 ;record        Allocated with name '_process_record_quantum_helper_record_10000_668'
                                   1106 ;------------------------------------------------------------
                                   1107 ;	quantum/quantum.c:414: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1108 ;	-----------------------------------------
                                   1109 ;	 function process_record_quantum_helper
                                   1110 ;	-----------------------------------------
      00A310                       1111 _process_record_quantum_helper:
      00A310 12 3A 83         [24] 1112 	lcall	_ak820_outline_0103
      00A313 90 0C 11         [24] 1113 	mov	dptr,#_process_record_quantum_helper_keycode_10000_667
      00A316 12 3A 88         [24] 1114 	lcall	_ak820_outline_0104
                                   1115 ;	quantum/quantum.c:416: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A319 90 0C 0F         [24] 1116 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A31C 12 3A 40         [24] 1117 	lcall	_ak820_outline_0050
                                   1118 ;	quantum/quantum.c:456: ak820_gui_process(keycode, record->event.pressed) &&
      00A31F 90 0C 11         [24] 1119 	mov	dptr,#_process_record_quantum_helper_keycode_10000_667
      00A322 12 3A 5F         [24] 1120 	lcall	_ak820_outline_0059
      00A325 12 45 0C         [24] 1121 	lcall	_ak820_outline_0009
      00A328 E0               [24] 1122 	movx	a,@dptr
      00A329 90 09 96         [24] 1123 	mov	dptr,#_ak820_gui_process_PARM_2
      00A32C 12 3A 71         [24] 1124 	lcall	_ak820_outline_0095
      00A32F C0 07            [24] 1125 	push	ar7
      00A331 C0 06            [24] 1126 	push	ar6
      00A333 C0 05            [24] 1127 	push	ar5
      00A335 C0 04            [24] 1128 	push	ar4
      00A337 12 7F 9B         [24] 1129 	lcall	_ak820_gui_process
      00A33A E5 82            [12] 1130 	mov	a, dpl
      00A33C D0 04            [24] 1131 	pop	ar4
      00A33E D0 05            [24] 1132 	pop	ar5
      00A340 D0 06            [24] 1133 	pop	ar6
      00A342 D0 07            [24] 1134 	pop	ar7
      00A344 70 02            [24] 1135 	jnz	00204$
      00A346 81 3C            [12] 1136 	ajmp	00101$
      00A348                       1137 00204$:
                                   1138 ;	quantum/quantum.c:459: process_ak820_nkro(keycode, record) &&
      00A348 90 0C 0A         [24] 1139 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A34B 12 A4 77         [24] 1140 	lcall	_ak820_outline_0006
      00A34E C0 07            [24] 1141 	push	ar7
      00A350 C0 06            [24] 1142 	push	ar6
      00A352 C0 05            [24] 1143 	push	ar5
      00A354 C0 04            [24] 1144 	push	ar4
      00A356 51 A5            [24] 1145 	acall	_process_ak820_nkro
      00A358 E5 82            [12] 1146 	mov	a, dpl
      00A35A D0 04            [24] 1147 	pop	ar4
      00A35C D0 05            [24] 1148 	pop	ar5
      00A35E D0 06            [24] 1149 	pop	ar6
      00A360 D0 07            [24] 1150 	pop	ar7
      00A362 70 02            [24] 1151 	jnz	00205$
      00A364 81 3C            [12] 1152 	ajmp	00101$
      00A366                       1153 00205$:
                                   1154 ;	quantum/quantum.c:470: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A366 90 0B E8         [24] 1155 	mov	dptr,#_process_last_key_PARM_2
      00A369 12 4A 8E         [24] 1156 	lcall	_ak820_outline_0058
      00A36C 12 3A A0         [24] 1157 	lcall	_ak820_outline_0121
      00A36F C0 07            [24] 1158 	push	ar7
      00A371 C0 06            [24] 1159 	push	ar6
      00A373 C0 05            [24] 1160 	push	ar5
      00A375 C0 04            [24] 1161 	push	ar4
      00A377 12 9E A5         [24] 1162 	lcall	_process_last_key
      00A37A E5 82            [12] 1163 	mov	a, dpl
      00A37C D0 04            [24] 1164 	pop	ar4
      00A37E D0 05            [24] 1165 	pop	ar5
      00A380 D0 06            [24] 1166 	pop	ar6
      00A382 D0 07            [24] 1167 	pop	ar7
      00A384 70 02            [24] 1168 	jnz	00206$
      00A386 81 3C            [12] 1169 	ajmp	00101$
      00A388                       1170 00206$:
      00A388 90 0B ED         [24] 1171 	mov	dptr,#_process_repeat_key_PARM_2
      00A38B 12 4A 8E         [24] 1172 	lcall	_ak820_outline_0058
      00A38E 12 3A A0         [24] 1173 	lcall	_ak820_outline_0121
      00A391 C0 07            [24] 1174 	push	ar7
      00A393 C0 06            [24] 1175 	push	ar6
      00A395 C0 05            [24] 1176 	push	ar5
      00A397 C0 04            [24] 1177 	push	ar4
      00A399 12 9F 1E         [24] 1178 	lcall	_process_repeat_key
      00A39C E5 82            [12] 1179 	mov	a, dpl
      00A39E D0 04            [24] 1180 	pop	ar4
      00A3A0 D0 05            [24] 1181 	pop	ar5
      00A3A2 D0 06            [24] 1182 	pop	ar6
      00A3A4 D0 07            [24] 1183 	pop	ar7
      00A3A6 70 02            [24] 1184 	jnz	00207$
      00A3A8 81 3C            [12] 1185 	ajmp	00101$
      00A3AA                       1186 00207$:
                                   1187 ;	quantum/quantum.c:479: process_record_via(keycode, record) &&
      00A3AA 90 0C 4A         [24] 1188 	mov	dptr,#_process_record_via_PARM_2
      00A3AD 12 A4 77         [24] 1189 	lcall	_ak820_outline_0006
      00A3B0 C0 07            [24] 1190 	push	ar7
      00A3B2 C0 06            [24] 1191 	push	ar6
      00A3B4 C0 05            [24] 1192 	push	ar5
      00A3B6 C0 04            [24] 1193 	push	ar4
      00A3B8 12 A9 58         [24] 1194 	lcall	_process_record_via
      00A3BB E5 82            [12] 1195 	mov	a, dpl
      00A3BD D0 04            [24] 1196 	pop	ar4
      00A3BF D0 05            [24] 1197 	pop	ar5
      00A3C1 D0 06            [24] 1198 	pop	ar6
      00A3C3 D0 07            [24] 1199 	pop	ar7
      00A3C5 70 02            [24] 1200 	jnz	00208$
      00A3C7 81 3C            [12] 1201 	ajmp	00101$
      00A3C9                       1202 00208$:
                                   1203 ;	quantum/quantum.c:514: process_caps_word(keycode, record) &&
      00A3C9 90 0B D1         [24] 1204 	mov	dptr,#_process_caps_word_PARM_2
      00A3CC 12 A4 77         [24] 1205 	lcall	_ak820_outline_0006
      00A3CF C0 07            [24] 1206 	push	ar7
      00A3D1 C0 06            [24] 1207 	push	ar6
      00A3D3 C0 05            [24] 1208 	push	ar5
      00A3D5 C0 04            [24] 1209 	push	ar4
      00A3D7 12 9C 47         [24] 1210 	lcall	_process_caps_word
      00A3DA E5 82            [12] 1211 	mov	a, dpl
      00A3DC D0 04            [24] 1212 	pop	ar4
      00A3DE D0 05            [24] 1213 	pop	ar5
      00A3E0 D0 06            [24] 1214 	pop	ar6
      00A3E2 D0 07            [24] 1215 	pop	ar7
      00A3E4 60 56            [24] 1216 	jz	00101$
                                   1217 ;	quantum/quantum.c:544: process_grave_esc(keycode, record) &&
      00A3E6 90 0B D6         [24] 1218 	mov	dptr,#_process_grave_esc_PARM_2
      00A3E9 12 A4 77         [24] 1219 	lcall	_ak820_outline_0006
      00A3EC C0 07            [24] 1220 	push	ar7
      00A3EE C0 06            [24] 1221 	push	ar6
      00A3F0 C0 05            [24] 1222 	push	ar5
      00A3F2 C0 04            [24] 1223 	push	ar4
      00A3F4 12 9D 59         [24] 1224 	lcall	_process_grave_esc
      00A3F7 E5 82            [12] 1225 	mov	a, dpl
      00A3F9 D0 04            [24] 1226 	pop	ar4
      00A3FB D0 05            [24] 1227 	pop	ar5
      00A3FD D0 06            [24] 1228 	pop	ar6
      00A3FF D0 07            [24] 1229 	pop	ar7
      00A401 60 39            [24] 1230 	jz	00101$
                                   1231 ;	quantum/quantum.c:547: process_rgb(keycode, record) &&
      00A403 90 0B F1         [24] 1232 	mov	dptr,#_process_rgb_PARM_2
      00A406 12 A4 77         [24] 1233 	lcall	_ak820_outline_0006
      00A409 C0 07            [24] 1234 	push	ar7
      00A40B C0 06            [24] 1235 	push	ar6
      00A40D C0 05            [24] 1236 	push	ar5
      00A40F C0 04            [24] 1237 	push	ar4
      00A411 12 9F 6D         [24] 1238 	lcall	_process_rgb
      00A414 E5 82            [12] 1239 	mov	a, dpl
      00A416 D0 04            [24] 1240 	pop	ar4
      00A418 D0 05            [24] 1241 	pop	ar5
      00A41A D0 06            [24] 1242 	pop	ar6
      00A41C D0 07            [24] 1243 	pop	ar7
      00A41E 60 1C            [24] 1244 	jz	00101$
                                   1245 ;	quantum/quantum.c:559: process_tri_layer(keycode, record) &&
      00A420 90 0B F7         [24] 1246 	mov	dptr,#_process_tri_layer_PARM_2
      00A423 12 A4 77         [24] 1247 	lcall	_ak820_outline_0006
      00A426 C0 07            [24] 1248 	push	ar7
      00A428 C0 06            [24] 1249 	push	ar6
      00A42A C0 05            [24] 1250 	push	ar5
      00A42C C0 04            [24] 1251 	push	ar4
      00A42E 11 1E            [12] 1252 	acall	_process_tri_layer
      00A430 E5 82            [12] 1253 	mov	a, dpl
      00A432 D0 04            [24] 1254 	pop	ar4
      00A434 D0 05            [24] 1255 	pop	ar5
      00A436 D0 06            [24] 1256 	pop	ar6
      00A438 D0 07            [24] 1257 	pop	ar7
      00A43A 70 04            [24] 1258 	jnz	00102$
                                   1259 ;	quantum/quantum.c:561: true)) {
      00A43C                       1260 00101$:
                                   1261 ;	quantum/quantum.c:562: return false;
      00A43C 75 82 00         [24] 1262 	mov	dpl, #0x00
      00A43F 22               [24] 1263 	ret
      00A440                       1264 00102$:
                                   1265 ;	quantum/quantum.c:565: if (record->event.pressed) {
      00A440 12 39 EA         [24] 1266 	lcall	_ak820_outline_0005
      00A443 60 2D            [24] 1267 	jz	00117$
                                   1268 ;	quantum/quantum.c:566: switch (keycode) {
      00A445 BC 00 05         [24] 1269 	cjne	r4,#0x00,00214$
      00A448 BD 7C 02         [24] 1270 	cjne	r5,#0x7c,00214$
      00A44B 80 10            [24] 1271 	sjmp	00112$
      00A44D                       1272 00214$:
      00A44D BC 01 05         [24] 1273 	cjne	r4,#0x01,00215$
      00A450 BD 7C 02         [24] 1274 	cjne	r5,#0x7c,00215$
      00A453 80 0E            [24] 1275 	sjmp	00113$
      00A455                       1276 00215$:
                                   1277 ;	quantum/quantum.c:568: case QK_BOOTLOADER:
      00A455 BC 03 1A         [24] 1278 	cjne	r4,#0x03,00117$
      00A458 BD 7C 17         [24] 1279 	cjne	r5,#0x7c,00117$
      00A45B 80 0C            [24] 1280 	sjmp	00114$
      00A45D                       1281 00112$:
                                   1282 ;	quantum/quantum.c:569: reset_keyboard();
      00A45D 31 EF            [12] 1283 	acall	_reset_keyboard
                                   1284 ;	quantum/quantum.c:570: return false;
      00A45F 75 82 00         [24] 1285 	mov	dpl, #0x00
                                   1286 ;	quantum/quantum.c:571: case QK_REBOOT:
      00A462 22               [24] 1287 	ret
      00A463                       1288 00113$:
                                   1289 ;	quantum/quantum.c:572: soft_reset_keyboard();
      00A463 31 F4            [12] 1290 	acall	_soft_reset_keyboard
                                   1291 ;	quantum/quantum.c:573: return false;
      00A465 75 82 00         [24] 1292 	mov	dpl, #0x00
                                   1293 ;	quantum/quantum.c:585: case QK_CLEAR_EEPROM:
      00A468 22               [24] 1294 	ret
      00A469                       1295 00114$:
                                   1296 ;	quantum/quantum.c:592: eeconfig_disable();
      00A469 12 93 C2         [24] 1297 	lcall	_eeconfig_disable
                                   1298 ;	quantum/quantum.c:593: soft_reset_keyboard();
      00A46C 31 F4            [12] 1299 	acall	_soft_reset_keyboard
                                   1300 ;	quantum/quantum.c:595: return false;
      00A46E 75 82 00         [24] 1301 	mov	dpl, #0x00
                                   1302 ;	quantum/quantum.c:650: }
      00A471 22               [24] 1303 	ret
      00A472                       1304 00117$:
                                   1305 ;	quantum/quantum.c:654: return true;
      00A472 75 82 01         [24] 1306 	mov	dpl, #0x01
                                   1307 ;	quantum/quantum.c:658: }
      00A475 22               [24] 1308 	ret
                                   1309 ;------------------------------------------------------------
                                   1310 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1311 ;------------------------------------------------------------
                                   1312 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_675'
                                   1313 ;------------------------------------------------------------
                                   1314 ;	quantum/quantum.c:660: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1315 ;	-----------------------------------------
                                   1316 ;	 function shutdown_user
                                   1317 ;	-----------------------------------------
      00A476                       1318 _shutdown_user:
      00A476 22               [24] 1319 	ret
                                   1320 ;------------------------------------------------------------
                                   1321 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1322 ;------------------------------------------------------------
                                   1323 ;	quantum/quantum.c:676: void suspend_power_down_quantum(void) {
                                   1324 ;	-----------------------------------------
                                   1325 	.area CSEG    (CODE)
                                   1326 	.area CONST   (CODE)
                                   1327 	.area XINIT   (CODE)
                                   1328 	.area CABS    (ABS,CODE)
                                   1329 
                                   1330 ; Experimental exact instruction outlining.
                                   1331 	.globl _ak820_outline_0004
                                   1332 	.globl _ak820_outline_0005
                                   1333 	.globl _ak820_outline_0006
                                   1334 	.globl _ak820_outline_0008
                                   1335 	.globl _ak820_outline_0009
                                   1336 	.globl _ak820_outline_0018
                                   1337 	.globl _ak820_outline_0030
                                   1338 	.globl _ak820_outline_0035
                                   1339 	.globl _ak820_outline_0050
                                   1340 	.globl _ak820_outline_0054
                                   1341 	.globl _ak820_outline_0058
                                   1342 	.globl _ak820_outline_0059
                                   1343 	.globl _ak820_outline_0060
                                   1344 	.globl _ak820_outline_0095
                                   1345 	.globl _ak820_outline_0103
                                   1346 	.globl _ak820_outline_0104
                                   1347 	.globl _ak820_outline_0114
                                   1348 	.globl _ak820_outline_0121
                                   1349 	.globl _ak820_outline_0132
                                   1350 	.globl _ak820_outline_0141
                                   1351 	.globl _ak820_outline_0148
                                   1352 	.globl _ak820_outline_0166
                                   1353 
                                   1354 	.area CSEG (CODE)
                                   1355 ; function ak820_outline_0006
      00A477                       1356 _ak820_outline_0006:
      00A477 EE               [12] 1357 	mov	a,r6
      00A478 F0               [24] 1358 	movx	@dptr,a
      00A479 EF               [12] 1359 	mov	a,r7
      00A47A A3               [24] 1360 	inc	dptr
      00A47B F0               [24] 1361 	movx	@dptr,a
      00A47C E4               [12] 1362 	clr	a
      00A47D A3               [24] 1363 	inc	dptr
      00A47E F0               [24] 1364 	movx	@dptr,a
      00A47F 8C 82            [24] 1365 	mov	dpl,r4
      00A481 8D 83            [24] 1366 	mov	dph,r5
      00A483 22               [24] 1367 	ret
