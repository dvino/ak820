                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000025                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000025                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000AFF                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AFF                        628 	.ds 1
      000B00                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B00                        630 	.ds 1
      000B01                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_366:
      000B01                        632 	.ds 1
      000B02                        633 _dynamic_keymap_get_keycode_PARM_2:
      000B02                        634 	.ds 1
      000B03                        635 _dynamic_keymap_get_keycode_PARM_3:
      000B03                        636 	.ds 1
      000B04                        637 _dynamic_keymap_get_keycode_layer_10000_368:
      000B04                        638 	.ds 1
      000B05                        639 _dynamic_keymap_set_keycode_PARM_2:
      000B05                        640 	.ds 1
      000B06                        641 _dynamic_keymap_set_keycode_PARM_3:
      000B06                        642 	.ds 1
      000B07                        643 _dynamic_keymap_set_keycode_PARM_4:
      000B07                        644 	.ds 2
      000B09                        645 _dynamic_keymap_set_keycode_layer_10000_372:
      000B09                        646 	.ds 1
      000B0A                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B0A                        648 	.ds 1
      000B0B                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_376:
      000B0B                        650 	.ds 1
      000B0C                        651 _dynamic_keymap_get_encoder_PARM_2:
      000B0C                        652 	.ds 1
      000B0D                        653 _dynamic_keymap_get_encoder_PARM_3:
      000B0D                        654 	.ds 1
      000B0E                        655 _dynamic_keymap_get_encoder_layer_10000_378:
      000B0E                        656 	.ds 1
      000B0F                        657 _dynamic_keymap_set_encoder_PARM_2:
      000B0F                        658 	.ds 1
      000B10                        659 _dynamic_keymap_set_encoder_PARM_3:
      000B10                        660 	.ds 1
      000B11                        661 _dynamic_keymap_set_encoder_PARM_4:
      000B11                        662 	.ds 2
      000B13                        663 _dynamic_keymap_set_encoder_layer_10000_382:
      000B13                        664 	.ds 1
      000B14                        665 _dynamic_keymap_get_combo_PARM_2:
      000B14                        666 	.ds 3
      000B17                        667 _dynamic_keymap_get_combo_index_10000_386:
      000B17                        668 	.ds 1
      000B18                        669 _dynamic_keymap_set_combo_PARM_2:
      000B18                        670 	.ds 3
      000B1B                        671 _dynamic_keymap_set_combo_index_10000_392:
      000B1B                        672 	.ds 1
      000B1C                        673 _dynamic_keymap_set_combo_stored_10002_397:
      000B1C                        674 	.ds 10
      000B26                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_400:
      000B26                        676 	.ds 1
      000B27                        677 _dynamic_keymap_reset_combo_10001_409:
      000B27                        678 	.ds 10
      000B31                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B31                        680 	.ds 2
      000B33                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B33                        682 	.ds 2
      000B35                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B35                        684 	.ds 2
      000B37                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B37                        686 	.ds 3
      000B3A                        687 _ak820_dynamic_read_buffer_base_10000_411:
      000B3A                        688 	.ds 2
      000B3C                        689 _ak820_dynamic_read_buffer_available_10000_412:
      000B3C                        690 	.ds 1
      000B3D                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B3D                        692 	.ds 2
      000B3F                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B3F                        694 	.ds 3
      000B42                        695 _dynamic_keymap_get_buffer_offset_10000_418:
      000B42                        696 	.ds 2
      000B44                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B44                        698 	.ds 2
      000B46                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B46                        700 	.ds 3
      000B49                        701 _dynamic_keymap_set_buffer_offset_10000_420:
      000B49                        702 	.ds 2
      000B4B                        703 _dynamic_keymap_set_buffer_chk_offset_30001_427:
      000B4B                        704 	.ds 1
      000B4C                        705 _dynamic_keymap_set_buffer_chk_sz_30001_427:
      000B4C                        706 	.ds 1
      000B4D                        707 _dynamic_keymap_set_buffer_i_40001_434:
      000B4D                        708 	.ds 1
      000B4E                        709 _keycode_at_keymap_location_PARM_2:
      000B4E                        710 	.ds 1
      000B4F                        711 _keycode_at_keymap_location_PARM_3:
      000B4F                        712 	.ds 1
      000B50                        713 _keycode_at_keymap_location_layer_num_10000_438:
      000B50                        714 	.ds 1
      000B51                        715 _keycode_at_encodermap_location_PARM_2:
      000B51                        716 	.ds 1
      000B52                        717 _keycode_at_encodermap_location_PARM_3:
      000B52                        718 	.ds 1
      000B53                        719 _keycode_at_encodermap_location_layer_num_10000_442:
      000B53                        720 	.ds 1
      000B54                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B54                        722 	.ds 2
      000B56                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B56                        724 	.ds 3
      000B59                        725 _dynamic_keymap_macro_get_buffer_offset_10000_450:
      000B59                        726 	.ds 2
      000B5B                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B5B                        728 	.ds 2
      000B5D                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B5D                        730 	.ds 3
      000B60                        731 _dynamic_keymap_macro_set_buffer_offset_10000_452:
      000B60                        732 	.ds 2
      000B62                        733 _decode_keycode_kc_10000_456:
      000B62                        734 	.ds 2
      000B64                        735 _dynamic_keymap_macro_send_id_10000_459:
      000B64                        736 	.ds 1
      000B65                        737 _dynamic_keymap_macro_send_sending_10000_460:
      000B65                        738 	.ds 1
      000B66                        739 _dynamic_keymap_macro_send_p_10001_465:
      000B66                        740 	.ds 2
      000B68                        741 _dynamic_keymap_macro_send_data_10003_472:
      000B68                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008807                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008807 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      00880A 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_366'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      00880B                        810 _dynamic_keymap_key_to_eeprom_address:
      00880B E5 82            [12]  811 	mov	a,dpl
      00880D 90 0B 01         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_366
      008810 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008811 E0               [24]  815 	movx	a,@dptr
      008812 FF               [12]  816 	mov	r7,a
      008813 7E 00            [12]  817 	mov	r6,#0x00
      008815 74 40            [12]  818 	mov	a,#0x40
      008817 12 45 70         [24]  819 	lcall	_ak820_outline_0134
      00881A 7D 00            [12]  820 	mov	r5,#0x00
      00881C 90 0A FF         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00881F E0               [24]  822 	movx	a,@dptr
      008820 75 F0 10         [24]  823 	mov	b,#0x10
      008823 A4               [48]  824 	mul	ab
      008824 2E               [12]  825 	add	a, r6
      008825 FE               [12]  826 	mov	r6,a
      008826 EF               [12]  827 	mov	a,r7
      008827 35 F0            [12]  828 	addc	a, b
      008829 FF               [12]  829 	mov	r7,a
      00882A 90 0B 00         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      00882D E0               [24]  831 	movx	a,@dptr
      00882E 7C 00            [12]  832 	mov	r4,#0x00
      008830 25 E0            [12]  833 	add	a,acc
      008832 FB               [12]  834 	mov	r3,a
      008833 EC               [12]  835 	mov	a,r4
      008834 33               [12]  836 	rlc	a
      008835 FC               [12]  837 	mov	r4,a
      008836 EB               [12]  838 	mov	a,r3
      008837 2E               [12]  839 	add	a, r6
      008838 FE               [12]  840 	mov	r6,a
      008839 EC               [12]  841 	mov	a,r4
      00883A 3F               [12]  842 	addc	a, r7
      00883B FF               [12]  843 	mov	r7,a
      00883C 12 45 60         [24]  844 	lcall	_ak820_outline_0116
      00883F 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      008841 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_368'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_371'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_371'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      008842                        861 _dynamic_keymap_get_keycode:
      008842 E5 82            [12]  862 	mov	a,dpl
      008844 90 0B 04         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_368
      008847 F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008848 E0               [24]  866 	movx	a,@dptr
      008849 FF               [12]  867 	mov	r7,a
      00884A BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      00884D                        869 00121$:
      00884D 50 14            [24]  870 	jnc	00101$
      00884F 90 0B 02         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008852 E0               [24]  872 	movx	a,@dptr
      008853 FE               [12]  873 	mov	r6,a
      008854 BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      008857                        875 00123$:
      008857 50 0A            [24]  876 	jnc	00101$
      008859 90 0B 03         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00885C E0               [24]  878 	movx	a,@dptr
      00885D FD               [12]  879 	mov	r5,a
      00885E BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      008861                        881 00125$:
      008861 40 04            [24]  882 	jc	00102$
      008863                        883 00101$:
      008863 90 00 00         [24]  884 	mov	dptr,#0x0000
      008866 22               [24]  885 	ret
      008867                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008867 12 92 99         [24]  888 	lcall	_ak820_outline_0094
      00886A 11 0B            [12]  889 	acall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      00886C 12 92 A6         [24]  891 	lcall	_ak820_outline_0112
      00886F 12 42 7F         [24]  892 	lcall	_eeprom_read_byte
      008872 AB 82            [24]  893 	mov	r3,dpl
      008874 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008876 0D               [12]  896 	inc	r5
      008877 BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      00887A 0E               [12]  898 	inc	r6
      00887B                        899 00127$:
      00887B 12 51 15         [24]  900 	lcall	_ak820_outline_0043
      00887E 12 42 7F         [24]  901 	lcall	_eeprom_read_byte
      008881 AF 82            [24]  902 	mov	r7, dpl
      008883 7E 00            [12]  903 	mov	r6,#0x00
      008885 EF               [12]  904 	mov	a,r7
      008886 42 04            [12]  905 	orl	ar4,a
      008888 EE               [12]  906 	mov	a,r6
      008889 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      00888B 12 45 9C         [24]  909 	lcall	_ak820_outline_0180
                                    910 ;	quantum/dynamic_keymap.c:215: }
      00888E 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_372'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_375'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      00888F                        925 _dynamic_keymap_set_keycode:
      00888F E5 82            [12]  926 	mov	a,dpl
      008891 90 0B 09         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_372
      008894 F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008895 E0               [24]  930 	movx	a,@dptr
      008896 FF               [12]  931 	mov	r7,a
      008897 BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      00889A                        933 00121$:
      00889A 50 14            [24]  934 	jnc	00101$
      00889C 90 0B 05         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00889F E0               [24]  936 	movx	a,@dptr
      0088A0 FE               [12]  937 	mov	r6,a
      0088A1 BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      0088A4                        939 00123$:
      0088A4 50 0A            [24]  940 	jnc	00101$
      0088A6 90 0B 06         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0088A9 E0               [24]  942 	movx	a,@dptr
      0088AA FD               [12]  943 	mov	r5,a
      0088AB BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      0088AE                        945 00125$:
      0088AE 40 01            [24]  946 	jc	00102$
      0088B0                        947 00101$:
      0088B0 22               [24]  948 	ret
      0088B1                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0088B1 12 92 99         [24]  951 	lcall	_ak820_outline_0094
      0088B4 11 0B            [12]  952 	acall	_dynamic_keymap_key_to_eeprom_address
      0088B6 12 92 A6         [24]  953 	lcall	_ak820_outline_0112
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0088B9 90 0B 07         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0088BC E0               [24]  956 	movx	a,@dptr
      0088BD FB               [12]  957 	mov	r3,a
      0088BE A3               [24]  958 	inc	dptr
      0088BF E0               [24]  959 	movx	a,@dptr
      0088C0 90 06 AA         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      0088C3 F0               [24]  961 	movx	@dptr,a
      0088C4 12 51 15         [24]  962 	lcall	_ak820_outline_0043
      0088C7 12 4F FF         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0088CA 0D               [12]  965 	inc	r5
      0088CB BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      0088CE 0E               [12]  967 	inc	r6
      0088CF                        968 00127$:
      0088CF 90 06 AA         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      0088D2 EB               [12]  970 	mov	a,r3
      0088D3 F0               [24]  971 	movx	@dptr,a
      0088D4 12 51 15         [24]  972 	lcall	_ak820_outline_0043
                                    973 ;	quantum/dynamic_keymap.c:223: }
      0088D7 02 4F FF         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_376'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      0088DA                        985 _dynamic_keymap_encoder_to_eeprom_address:
      0088DA E5 82            [12]  986 	mov	a,dpl
      0088DC 90 0B 0B         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_376
      0088DF F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0088E0 E0               [24]  990 	movx	a,@dptr
      0088E1 75 F0 04         [24]  991 	mov	b,#0x04
      0088E4 A4               [48]  992 	mul	ab
      0088E5 24 40            [12]  993 	add	a, #0x40
      0088E7 FD               [12]  994 	mov	r5,a
      0088E8 74 06            [12]  995 	mov	a,#0x06
      0088EA 35 F0            [12]  996 	addc	a, b
      0088EC FE               [12]  997 	mov	r6,a
      0088ED 7F 00            [12]  998 	mov	r7,#0x00
      0088EF 90 0B 0A         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0088F2 E0               [24] 1000 	movx	a,@dptr
      0088F3 75 F0 04         [24] 1001 	mov	b,#0x04
      0088F6 A4               [48] 1002 	mul	ab
      0088F7 2D               [12] 1003 	add	a, r5
      0088F8 FD               [12] 1004 	mov	r5,a
      0088F9 EE               [12] 1005 	mov	a,r6
      0088FA 35 F0            [12] 1006 	addc	a, b
      0088FC FE               [12] 1007 	mov	r6,a
      0088FD 12 51 15         [24] 1008 	lcall	_ak820_outline_0043
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      008900 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_378'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_381'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_381'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      008901                       1024 _dynamic_keymap_get_encoder:
      008901 E5 82            [12] 1025 	mov	a,dpl
      008903 90 0B 0E         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_378
      008906 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008907 E0               [24] 1029 	movx	a,@dptr
      008908 FF               [12] 1030 	mov	r7,a
      008909 BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      00890C                       1032 00131$:
      00890C 50 0A            [24] 1033 	jnc	00101$
      00890E 90 0B 0C         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008911 E0               [24] 1035 	movx	a,@dptr
      008912 FE               [12] 1036 	mov	r6,a
      008913 BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      008916                       1038 00133$:
      008916 40 04            [24] 1039 	jc	00102$
      008918                       1040 00101$:
      008918 90 00 00         [24] 1041 	mov	dptr,#0x0000
      00891B 22               [24] 1042 	ret
      00891C                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00891C 90 0B 0A         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00891F 12 7B 97         [24] 1046 	lcall	_ak820_outline_0184
      008922 11 DA            [12] 1047 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008924 12 92 A6         [24] 1048 	lcall	_ak820_outline_0112
                                   1049 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008927 90 0B 0D         [24] 1050 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00892A E0               [24] 1051 	movx	a,@dptr
      00892B FC               [12] 1052 	mov	r4,a
      00892C E0               [24] 1053 	movx	a,@dptr
      00892D 60 04            [24] 1054 	jz	00106$
      00892F 7B 00            [12] 1055 	mov	r3,#0x00
      008931 80 02            [24] 1056 	sjmp	00107$
      008933                       1057 00106$:
      008933 7B 02            [12] 1058 	mov	r3,#0x02
      008935                       1059 00107$:
      008935 EB               [12] 1060 	mov	a,r3
      008936 12 92 77         [24] 1061 	lcall	_ak820_outline_0024
      008939 12 42 7F         [24] 1062 	lcall	_eeprom_read_byte
      00893C AA 82            [24] 1063 	mov	r2,dpl
      00893E 7B 00            [12] 1064 	mov	r3,#0x00
                                   1065 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008940 EC               [12] 1066 	mov	a,r4
      008941 60 04            [24] 1067 	jz	00108$
      008943 7C 00            [12] 1068 	mov	r4,#0x00
      008945 80 02            [24] 1069 	sjmp	00109$
      008947                       1070 00108$:
      008947 7C 02            [12] 1071 	mov	r4,#0x02
      008949                       1072 00109$:
      008949 EC               [12] 1073 	mov	a,r4
      00894A 12 3A BA         [24] 1074 	lcall	_ak820_outline_0157
      00894D 0D               [12] 1075 	inc	r5
      00894E BD 00 01         [24] 1076 	cjne	r5,#0x00,00137$
      008951 0E               [12] 1077 	inc	r6
      008952                       1078 00137$:
      008952 12 51 15         [24] 1079 	lcall	_ak820_outline_0043
      008955 12 42 7F         [24] 1080 	lcall	_eeprom_read_byte
      008958 AF 82            [24] 1081 	mov	r7, dpl
      00895A 7E 00            [12] 1082 	mov	r6,#0x00
      00895C EF               [12] 1083 	mov	a,r7
      00895D 42 03            [12] 1084 	orl	ar3,a
      00895F EE               [12] 1085 	mov	a,r6
      008960 42 02            [12] 1086 	orl	ar2,a
                                   1087 ;	quantum/dynamic_keymap.c:236: return keycode;
      008962 8B 82            [24] 1088 	mov	dpl, r3
      008964 8A 83            [24] 1089 	mov	dph, r2
                                   1090 ;	quantum/dynamic_keymap.c:237: }
      008966 22               [24] 1091 	ret
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1094 ;------------------------------------------------------------
                                   1095 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1096 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1097 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1098 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1099 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_382'
                                   1100 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_385'
                                   1101 ;------------------------------------------------------------
                                   1102 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1103 ;	-----------------------------------------
                                   1104 ;	 function dynamic_keymap_set_encoder
                                   1105 ;	-----------------------------------------
      008967                       1106 _dynamic_keymap_set_encoder:
      008967 E5 82            [12] 1107 	mov	a,dpl
      008969 90 0B 13         [24] 1108 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_382
      00896C F0               [24] 1109 	movx	@dptr,a
                                   1110 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      00896D E0               [24] 1111 	movx	a,@dptr
      00896E FF               [12] 1112 	mov	r7,a
      00896F BF 06 00         [24] 1113 	cjne	r7,#0x06,00131$
      008972                       1114 00131$:
      008972 50 0A            [24] 1115 	jnc	00101$
      008974 90 0B 0F         [24] 1116 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008977 E0               [24] 1117 	movx	a,@dptr
      008978 FE               [12] 1118 	mov	r6,a
      008979 BE 01 00         [24] 1119 	cjne	r6,#0x01,00133$
      00897C                       1120 00133$:
      00897C 40 01            [24] 1121 	jc	00102$
      00897E                       1122 00101$:
      00897E 22               [24] 1123 	ret
      00897F                       1124 00102$:
                                   1125 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00897F 90 0B 0A         [24] 1126 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008982 12 7B 97         [24] 1127 	lcall	_ak820_outline_0184
      008985 11 DA            [12] 1128 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008987 12 92 A6         [24] 1129 	lcall	_ak820_outline_0112
                                   1130 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      00898A 90 0B 10         [24] 1131 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00898D E0               [24] 1132 	movx	a,@dptr
      00898E FC               [12] 1133 	mov	r4,a
      00898F E0               [24] 1134 	movx	a,@dptr
      008990 60 04            [24] 1135 	jz	00106$
      008992 7B 00            [12] 1136 	mov	r3,#0x00
      008994 80 02            [24] 1137 	sjmp	00107$
      008996                       1138 00106$:
      008996 7B 02            [12] 1139 	mov	r3,#0x02
      008998                       1140 00107$:
      008998 EB               [12] 1141 	mov	a,r3
      008999 12 92 B8         [24] 1142 	lcall	_ak820_outline_0133
      00899C 8F 03            [24] 1143 	mov	ar3,r7
      00899E 90 0B 11         [24] 1144 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0089A1 E0               [24] 1145 	movx	a,@dptr
      0089A2 F5 29            [12] 1146 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      0089A4 A3               [24] 1147 	inc	dptr
      0089A5 E0               [24] 1148 	movx	a,@dptr
      0089A6 F5 2A            [12] 1149 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      0089A8 90 06 AA         [24] 1150 	mov	dptr,#_eeprom_update_byte_PARM_2
      0089AB F0               [24] 1151 	movx	@dptr,a
      0089AC 12 45 97         [24] 1152 	lcall	_ak820_outline_0179
      0089AF 8B F0            [24] 1153 	mov	b, r3
      0089B1 12 4F FF         [24] 1154 	lcall	_eeprom_update_byte
                                   1155 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0089B4 EC               [12] 1156 	mov	a,r4
      0089B5 60 04            [24] 1157 	jz	00108$
      0089B7 7C 00            [12] 1158 	mov	r4,#0x00
      0089B9 80 02            [24] 1159 	sjmp	00109$
      0089BB                       1160 00108$:
      0089BB 7C 02            [12] 1161 	mov	r4,#0x02
      0089BD                       1162 00109$:
      0089BD EC               [12] 1163 	mov	a,r4
      0089BE 12 3A BA         [24] 1164 	lcall	_ak820_outline_0157
      0089C1 0D               [12] 1165 	inc	r5
      0089C2 BD 00 01         [24] 1166 	cjne	r5,#0x00,00137$
      0089C5 0E               [12] 1167 	inc	r6
      0089C6                       1168 00137$:
      0089C6 90 06 AA         [24] 1169 	mov	dptr,#_eeprom_update_byte_PARM_2
      0089C9 E5 29            [12] 1170 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      0089CB F0               [24] 1171 	movx	@dptr,a
      0089CC 12 51 15         [24] 1172 	lcall	_ak820_outline_0043
                                   1173 ;	quantum/dynamic_keymap.c:245: }
      0089CF 02 4F FF         [24] 1174 	ljmp	_eeprom_update_byte
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1179 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1180 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_386'
                                   1181 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_387'
                                   1182 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_389'
                                   1183 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_390'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function dynamic_keymap_get_combo
                                   1188 ;	-----------------------------------------
      0089D2                       1189 _dynamic_keymap_get_combo:
      0089D2 E5 82            [12] 1190 	mov	a,dpl
      0089D4 90 0B 17         [24] 1191 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_386
      0089D7 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0089D8 90 0B 14         [24] 1194 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      0089DB 12 3A 40         [24] 1195 	lcall	_ak820_outline_0050
                                   1196 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      0089DE 90 0B 17         [24] 1197 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_386
      0089E1 E0               [24] 1198 	movx	a,@dptr
      0089E2 FD               [12] 1199 	mov	r5,a
      0089E3 BD 08 00         [24] 1200 	cjne	r5,#0x08,00132$
      0089E6                       1201 00132$:
      0089E6 40 04            [24] 1202 	jc	00102$
                                   1203 ;	quantum/dynamic_keymap.c:315: return -1;
      0089E8 90 FF FF         [24] 1204 	mov	dptr,#0xffff
      0089EB 22               [24] 1205 	ret
      0089EC                       1206 00102$:
                                   1207 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0089EC 12 92 85         [24] 1208 	lcall	_ak820_outline_0077
                                   1209 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      0089EF 8E 02            [24] 1210 	mov	ar2,r6
      0089F1 8F 03            [24] 1211 	mov	ar3,r7
      0089F3 90 05 91         [24] 1212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0089F6 12 3A 65         [24] 1213 	lcall	_ak820_outline_0070
      0089F9 E4               [12] 1214 	clr	a
      0089FA A3               [24] 1215 	inc	dptr
      0089FB F0               [24] 1216 	movx	@dptr,a
      0089FC 90 05 94         [24] 1217 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0089FF 74 0A            [12] 1218 	mov	a,#0x0a
      008A01 12 3A A5         [24] 1219 	lcall	_ak820_outline_0123
      008A04 12 45 7C         [24] 1220 	lcall	_ak820_outline_0142
      008A07 C0 07            [24] 1221 	push	ar7
      008A09 C0 06            [24] 1222 	push	ar6
      008A0B 12 42 BA         [24] 1223 	lcall	_ak820_eeprom_read_block_xdata
      008A0E D0 06            [24] 1224 	pop	ar6
      008A10 D0 07            [24] 1225 	pop	ar7
                                   1226 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008A12 74 04            [12] 1227 	mov	a,#0x04
      008A14 12 4A 35         [24] 1228 	lcall	_ak820_outline_0011
      008A17 FA               [12] 1229 	mov	r2,a
      008A18 A3               [24] 1230 	inc	dptr
      008A19 E0               [24] 1231 	movx	a,@dptr
      008A1A FB               [12] 1232 	mov	r3,a
      008A1B BA 20 14         [24] 1233 	cjne	r2,#0x20,00108$
      008A1E BB 08 11         [24] 1234 	cjne	r3,#0x08,00108$
      008A21 74 06            [12] 1235 	mov	a,#0x06
      008A23 12 3A 27         [24] 1236 	lcall	_ak820_outline_0016
      008A26 FA               [12] 1237 	mov	r2,a
      008A27 A3               [24] 1238 	inc	dptr
      008A28 E0               [24] 1239 	movx	a,@dptr
      008A29 FB               [12] 1240 	mov	r3,a
      008A2A BA 01 05         [24] 1241 	cjne	r2,#0x01,00136$
      008A2D BB 00 02         [24] 1242 	cjne	r3,#0x00,00136$
      008A30 80 05            [24] 1243 	sjmp	00109$
      008A32                       1244 00136$:
      008A32                       1245 00108$:
      008A32 75 2B 00         [24] 1246 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008A35 80 03            [24] 1247 	sjmp	00110$
      008A37                       1248 00109$:
      008A37 75 2B 01         [24] 1249 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008A3A                       1250 00110$:
                                   1251 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008A3A 74 06            [12] 1252 	mov	a,#0x06
      008A3C 12 3A 30         [24] 1253 	lcall	_ak820_outline_0030
      008A3F E4               [12] 1254 	clr	a
      008A40 F0               [24] 1255 	movx	@dptr,a
      008A41 A3               [24] 1256 	inc	dptr
      008A42 12 3A 71         [24] 1257 	lcall	_ak820_outline_0095
      008A45 F0               [24] 1258 	movx	@dptr,a
      008A46 A3               [24] 1259 	inc	dptr
      008A47 F0               [24] 1260 	movx	@dptr,a
                                   1261 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008A48 E5 2B            [12] 1262 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008A4A 60 12            [24] 1263 	jz	00103$
      008A4C 12 45 60         [24] 1264 	lcall	_ak820_outline_0116
      008A4F C0 07            [24] 1265 	push	ar7
      008A51 C0 06            [24] 1266 	push	ar6
      008A53 12 36 AE         [24] 1267 	lcall	_ak820_combo_valid
      008A56 E5 82            [12] 1268 	mov	a, dpl
      008A58 D0 06            [24] 1269 	pop	ar6
      008A5A D0 07            [24] 1270 	pop	ar7
      008A5C 70 17            [24] 1271 	jnz	00104$
      008A5E                       1272 00103$:
      008A5E 7D 00            [12] 1273 	mov	r5,#0x00
      008A60 90 0D A9         [24] 1274 	mov	dptr,#_memset_PARM_2
      008A63 E4               [12] 1275 	clr	a
      008A64 F0               [24] 1276 	movx	@dptr,a
      008A65 90 0D AA         [24] 1277 	mov	dptr,#_memset_PARM_3
      008A68 74 0A            [12] 1278 	mov	a,#0x0a
      008A6A F0               [24] 1279 	movx	@dptr,a
      008A6B E4               [12] 1280 	clr	a
      008A6C A3               [24] 1281 	inc	dptr
      008A6D 12 45 42         [24] 1282 	lcall	_ak820_outline_0060
      008A70 8D F0            [24] 1283 	mov	b, r5
      008A72 12 BB 4F         [24] 1284 	lcall	_memset
      008A75                       1285 00104$:
                                   1286 ;	quantum/dynamic_keymap.c:329: return 0;
      008A75 90 00 00         [24] 1287 	mov	dptr,#0x0000
                                   1288 ;	quantum/dynamic_keymap.c:330: }
      008A78 22               [24] 1289 	ret
                                   1290 ;------------------------------------------------------------
                                   1291 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1292 ;------------------------------------------------------------
                                   1293 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1294 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_392'
                                   1295 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_393'
                                   1296 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_396'
                                   1297 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_397'
                                   1298 ;------------------------------------------------------------
                                   1299 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1300 ;	-----------------------------------------
                                   1301 ;	 function dynamic_keymap_set_combo
                                   1302 ;	-----------------------------------------
      008A79                       1303 _dynamic_keymap_set_combo:
      008A79 E5 82            [12] 1304 	mov	a,dpl
      008A7B 90 0B 1B         [24] 1305 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_392
      008A7E F0               [24] 1306 	movx	@dptr,a
                                   1307 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008A7F 90 0B 18         [24] 1308 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008A82 12 39 E0         [24] 1309 	lcall	_ak820_outline_0004
                                   1310 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008A85 C0 07            [24] 1311 	push	ar7
      008A87 C0 06            [24] 1312 	push	ar6
      008A89 12 36 AE         [24] 1313 	lcall	_ak820_combo_valid
      008A8C E5 82            [12] 1314 	mov	a, dpl
      008A8E D0 06            [24] 1315 	pop	ar6
      008A90 D0 07            [24] 1316 	pop	ar7
      008A92 60 07            [24] 1317 	jz	00101$
      008A94 12 40 25         [24] 1318 	lcall	_ak820_nvm_ok
      008A97 E5 82            [12] 1319 	mov	a, dpl
      008A99 70 04            [24] 1320 	jnz	00102$
      008A9B                       1321 00101$:
      008A9B 90 FF FF         [24] 1322 	mov	dptr,#0xffff
      008A9E 22               [24] 1323 	ret
      008A9F                       1324 00102$:
                                   1325 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008A9F 90 0B 1B         [24] 1326 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_392
      008AA2 E0               [24] 1327 	movx	a,@dptr
      008AA3 FD               [12] 1328 	mov	r5,a
      008AA4 BD 08 00         [24] 1329 	cjne	r5,#0x08,00133$
      008AA7                       1330 00133$:
      008AA7 40 04            [24] 1331 	jc	00105$
                                   1332 ;	quantum/dynamic_keymap.c:342: return -1;
      008AA9 90 FF FF         [24] 1333 	mov	dptr,#0xffff
      008AAC 22               [24] 1334 	ret
      008AAD                       1335 00105$:
                                   1336 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008AAD 12 92 85         [24] 1337 	lcall	_ak820_outline_0077
                                   1338 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008AB0 C0 07            [24] 1339 	push	ar7
      008AB2 C0 06            [24] 1340 	push	ar6
      008AB4 C0 05            [24] 1341 	push	ar5
      008AB6 C0 04            [24] 1342 	push	ar4
      008AB8 12 7A ED         [24] 1343 	lcall	_clear_keyboard
      008ABB D0 04            [24] 1344 	pop	ar4
      008ABD D0 05            [24] 1345 	pop	ar5
      008ABF D0 06            [24] 1346 	pop	ar6
      008AC1 D0 07            [24] 1347 	pop	ar7
                                   1348 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008AC3 90 0D A1         [24] 1349 	mov	dptr,#___memcpy_PARM_2
      008AC6 12 4A 8E         [24] 1350 	lcall	_ak820_outline_0058
      008AC9 E4               [12] 1351 	clr	a
      008ACA A3               [24] 1352 	inc	dptr
      008ACB F0               [24] 1353 	movx	@dptr,a
      008ACC 90 0D A4         [24] 1354 	mov	dptr,#___memcpy_PARM_3
      008ACF 74 0A            [12] 1355 	mov	a,#0x0a
      008AD1 12 3A A5         [24] 1356 	lcall	_ak820_outline_0123
      008AD4 90 0B 1C         [24] 1357 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_397
      008AD7 F5 F0            [12] 1358 	mov	b,a
      008AD9 C0 05            [24] 1359 	push	ar5
      008ADB C0 04            [24] 1360 	push	ar4
      008ADD 12 BA D9         [24] 1361 	lcall	___memcpy
      008AE0 D0 04            [24] 1362 	pop	ar4
      008AE2 D0 05            [24] 1363 	pop	ar5
                                   1364 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008AE4 90 0B 20         [24] 1365 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_397 + 0x0004)
      008AE7 74 20            [12] 1366 	mov	a,#0x20
      008AE9 F0               [24] 1367 	movx	@dptr,a
      008AEA 74 08            [12] 1368 	mov	a,#0x08
      008AEC A3               [24] 1369 	inc	dptr
      008AED F0               [24] 1370 	movx	@dptr,a
                                   1371 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008AEE 90 0B 22         [24] 1372 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_397 + 0x0006)
      008AF1 74 01            [12] 1373 	mov	a,#0x01
      008AF3 12 3A A5         [24] 1374 	lcall	_ak820_outline_0123
                                   1375 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008AF6 90 05 9A         [24] 1376 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008AF9 12 3A 65         [24] 1377 	lcall	_ak820_outline_0070
      008AFC E4               [12] 1378 	clr	a
      008AFD A3               [24] 1379 	inc	dptr
      008AFE F0               [24] 1380 	movx	@dptr,a
      008AFF 90 05 9D         [24] 1381 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008B02 74 0A            [12] 1382 	mov	a,#0x0a
      008B04 12 3A A5         [24] 1383 	lcall	_ak820_outline_0123
      008B07 90 0B 1C         [24] 1384 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_397
      008B0A 12 43 46         [24] 1385 	lcall	_ak820_eeprom_write_block_xdata
                                   1386 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008B0D 12 40 34         [24] 1387 	lcall	_ak820_nvm_flush
                                   1388 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008B10 12 40 25         [24] 1389 	lcall	_ak820_nvm_ok
      008B13 E5 82            [12] 1390 	mov	a, dpl
      008B15 70 04            [24] 1391 	jnz	00107$
      008B17 90 FF FF         [24] 1392 	mov	dptr,#0xffff
      008B1A 22               [24] 1393 	ret
      008B1B                       1394 00107$:
                                   1395 ;	quantum/dynamic_keymap.c:360: return 0;
      008B1B 90 00 00         [24] 1396 	mov	dptr,#0x0000
                                   1397 ;	quantum/dynamic_keymap.c:361: }
      008B1E 22               [24] 1398 	ret
                                   1399 ;------------------------------------------------------------
                                   1400 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1401 ;------------------------------------------------------------
                                   1402 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_400'
                                   1403 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_401'
                                   1404 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_403'
                                   1405 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_405'
                                   1406 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_407'
                                   1407 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_409'
                                   1408 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_410'
                                   1409 ;------------------------------------------------------------
                                   1410 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1411 ;	-----------------------------------------
                                   1412 ;	 function dynamic_keymap_reset
                                   1413 ;	-----------------------------------------
      008B1F                       1414 _dynamic_keymap_reset:
                                   1415 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008B1F 90 0E 22         [24] 1416 	mov	dptr,#_vial_unlocked
      008B22 E0               [24] 1417 	movx	a,@dptr
      008B23 90 0B 26         [24] 1418 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_400
      008B26 F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008B27 90 0E 22         [24] 1421 	mov	dptr,#_vial_unlocked
      008B2A 74 01            [12] 1422 	mov	a,#0x01
      008B2C F0               [24] 1423 	movx	@dptr,a
                                   1424 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008B2D 7F 00            [12] 1425 	mov	r7,#0x00
      008B2F                       1426 00116$:
      008B2F BF 06 00         [24] 1427 	cjne	r7,#0x06,00198$
      008B32                       1428 00198$:
      008B32 40 02            [24] 1429 	jc	00199$
      008B34 61 DD            [12] 1430 	ajmp	00104$
      008B36                       1431 00199$:
                                   1432 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008B36 7E 00            [12] 1433 	mov	r6,#0x00
      008B38                       1434 00110$:
      008B38 BE 10 00         [24] 1435 	cjne	r6,#0x10,00200$
      008B3B                       1436 00200$:
      008B3B 50 4C            [24] 1437 	jnc	00102$
                                   1438 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008B3D 7D 00            [12] 1439 	mov	r5,#0x00
      008B3F                       1440 00107$:
      008B3F BD 08 00         [24] 1441 	cjne	r5,#0x08,00202$
      008B42                       1442 00202$:
      008B42 50 42            [24] 1443 	jnc	00111$
                                   1444 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008B44 90 0B C2         [24] 1445 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008B47 EE               [12] 1446 	mov	a,r6
      008B48 F0               [24] 1447 	movx	@dptr,a
      008B49 90 0B C3         [24] 1448 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008B4C ED               [12] 1449 	mov	a,r5
      008B4D F0               [24] 1450 	movx	@dptr,a
      008B4E 8F 82            [24] 1451 	mov	dpl, r7
      008B50 C0 07            [24] 1452 	push	ar7
      008B52 C0 06            [24] 1453 	push	ar6
      008B54 C0 05            [24] 1454 	push	ar5
      008B56 12 9A BD         [24] 1455 	lcall	_keycode_at_keymap_location_raw
      008B59 AB 82            [24] 1456 	mov	r3, dpl
      008B5B AC 83            [24] 1457 	mov	r4, dph
      008B5D D0 05            [24] 1458 	pop	ar5
      008B5F D0 06            [24] 1459 	pop	ar6
      008B61 D0 07            [24] 1460 	pop	ar7
      008B63 90 0B 05         [24] 1461 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008B66 EE               [12] 1462 	mov	a,r6
      008B67 F0               [24] 1463 	movx	@dptr,a
      008B68 90 0B 06         [24] 1464 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008B6B ED               [12] 1465 	mov	a,r5
      008B6C F0               [24] 1466 	movx	@dptr,a
      008B6D 90 0B 07         [24] 1467 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008B70 12 3A 6B         [24] 1468 	lcall	_ak820_outline_0075
      008B73 8F 82            [24] 1469 	mov	dpl, r7
      008B75 C0 07            [24] 1470 	push	ar7
      008B77 C0 06            [24] 1471 	push	ar6
      008B79 C0 05            [24] 1472 	push	ar5
      008B7B 11 8F            [12] 1473 	acall	_dynamic_keymap_set_keycode
      008B7D D0 05            [24] 1474 	pop	ar5
      008B7F D0 06            [24] 1475 	pop	ar6
      008B81 D0 07            [24] 1476 	pop	ar7
                                   1477 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008B83 0D               [12] 1478 	inc	r5
      008B84 80 B9            [24] 1479 	sjmp	00107$
      008B86                       1480 00111$:
                                   1481 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008B86 0E               [12] 1482 	inc	r6
      008B87 80 AF            [24] 1483 	sjmp	00110$
      008B89                       1484 00102$:
                                   1485 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008B89 7E 00            [12] 1486 	mov	r6,#0x00
      008B8B                       1487 00113$:
      008B8B BE 01 00         [24] 1488 	cjne	r6,#0x01,00204$
      008B8E                       1489 00204$:
      008B8E 50 4A            [24] 1490 	jnc	00117$
                                   1491 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008B90 12 92 D4         [24] 1492 	lcall	_ak820_outline_0174
      008B93 04               [12] 1493 	inc	a
      008B94 F0               [24] 1494 	movx	@dptr,a
      008B95 8F 82            [24] 1495 	mov	dpl, r7
      008B97 C0 07            [24] 1496 	push	ar7
      008B99 12 9B 02         [24] 1497 	lcall	_keycode_at_encodermap_location_raw
      008B9C 12 45 81         [24] 1498 	lcall	_ak820_outline_0148
      008B9F D0 07            [24] 1499 	pop	ar7
      008BA1 12 92 CB         [24] 1500 	lcall	_ak820_outline_0173
      008BA4 04               [12] 1501 	inc	a
      008BA5 F0               [24] 1502 	movx	@dptr,a
      008BA6 90 0B 11         [24] 1503 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008BA9 12 3A 65         [24] 1504 	lcall	_ak820_outline_0070
      008BAC 8F 82            [24] 1505 	mov	dpl, r7
      008BAE C0 07            [24] 1506 	push	ar7
      008BB0 31 67            [24] 1507 	acall	_dynamic_keymap_set_encoder
      008BB2 D0 07            [24] 1508 	pop	ar7
                                   1509 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008BB4 12 92 D4         [24] 1510 	lcall	_ak820_outline_0174
      008BB7 F0               [24] 1511 	movx	@dptr,a
      008BB8 8F 82            [24] 1512 	mov	dpl, r7
      008BBA C0 07            [24] 1513 	push	ar7
      008BBC 12 9B 02         [24] 1514 	lcall	_keycode_at_encodermap_location_raw
      008BBF 12 45 81         [24] 1515 	lcall	_ak820_outline_0148
      008BC2 D0 07            [24] 1516 	pop	ar7
      008BC4 12 92 CB         [24] 1517 	lcall	_ak820_outline_0173
      008BC7 F0               [24] 1518 	movx	@dptr,a
      008BC8 90 0B 11         [24] 1519 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008BCB 12 3A 65         [24] 1520 	lcall	_ak820_outline_0070
      008BCE 8F 82            [24] 1521 	mov	dpl, r7
      008BD0 C0 07            [24] 1522 	push	ar7
      008BD2 31 67            [24] 1523 	acall	_dynamic_keymap_set_encoder
      008BD4 D0 07            [24] 1524 	pop	ar7
                                   1525 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008BD6 7E 01            [12] 1526 	mov	r6,#0x01
      008BD8 80 B1            [24] 1527 	sjmp	00113$
      008BDA                       1528 00117$:
                                   1529 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008BDA 0F               [12] 1530 	inc	r7
      008BDB 61 2F            [12] 1531 	ajmp	00116$
      008BDD                       1532 00104$:
                                   1533 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008BDD 90 0B 27         [24] 1534 	mov	dptr,#_dynamic_keymap_reset_combo_10001_409
      008BE0 12 51 5E         [24] 1535 	lcall	_ak820_outline_0178
      008BE3 90 0B 29         [24] 1536 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0002)
      008BE6 F0               [24] 1537 	movx	@dptr,a
      008BE7 A3               [24] 1538 	inc	dptr
      008BE8 F0               [24] 1539 	movx	@dptr,a
      008BE9 90 0B 2B         [24] 1540 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0004)
      008BEC F0               [24] 1541 	movx	@dptr,a
      008BED A3               [24] 1542 	inc	dptr
      008BEE F0               [24] 1543 	movx	@dptr,a
      008BEF 90 0B 2D         [24] 1544 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0006)
      008BF2 F0               [24] 1545 	movx	@dptr,a
      008BF3 A3               [24] 1546 	inc	dptr
      008BF4 F0               [24] 1547 	movx	@dptr,a
      008BF5 90 0B 2F         [24] 1548 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0008)
      008BF8 F0               [24] 1549 	movx	@dptr,a
      008BF9 A3               [24] 1550 	inc	dptr
      008BFA F0               [24] 1551 	movx	@dptr,a
                                   1552 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008BFB FF               [12] 1553 	mov	r7,a
      008BFC                       1554 00119$:
      008BFC BF 08 00         [24] 1555 	cjne	r7,#0x08,00206$
      008BFF                       1556 00206$:
      008BFF 50 16            [24] 1557 	jnc	00105$
                                   1558 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008C01 90 0B 18         [24] 1559 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008C04 74 27            [12] 1560 	mov	a,#_dynamic_keymap_reset_combo_10001_409
      008C06 F0               [24] 1561 	movx	@dptr,a
      008C07 74 0B            [12] 1562 	mov	a,#(_dynamic_keymap_reset_combo_10001_409 >> 8)
      008C09 12 3A 94         [24] 1563 	lcall	_ak820_outline_0117
      008C0C 8F 82            [24] 1564 	mov	dpl, r7
      008C0E C0 07            [24] 1565 	push	ar7
      008C10 51 79            [24] 1566 	acall	_dynamic_keymap_set_combo
      008C12 D0 07            [24] 1567 	pop	ar7
                                   1568 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008C14 0F               [12] 1569 	inc	r7
      008C15 80 E5            [24] 1570 	sjmp	00119$
      008C17                       1571 00105$:
                                   1572 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008C17 90 0B 26         [24] 1573 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_400
      008C1A E0               [24] 1574 	movx	a,@dptr
      008C1B 90 0E 22         [24] 1575 	mov	dptr,#_vial_unlocked
      008C1E F0               [24] 1576 	movx	@dptr,a
                                   1577 ;	quantum/dynamic_keymap.c:468: }
      008C1F 22               [24] 1578 	ret
                                   1579 ;------------------------------------------------------------
                                   1580 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1581 ;------------------------------------------------------------
                                   1582 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1583 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1584 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1585 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1586 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1587 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_411'
                                   1588 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_412'
                                   1589 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_412'
                                   1590 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_415'
                                   1591 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_417'
                                   1592 ;------------------------------------------------------------
                                   1593 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1594 ;	-----------------------------------------
                                   1595 ;	 function ak820_dynamic_read_buffer
                                   1596 ;	-----------------------------------------
      008C20                       1597 _ak820_dynamic_read_buffer:
      008C20 12 3A 83         [24] 1598 	lcall	_ak820_outline_0103
      008C23 90 0B 3A         [24] 1599 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_411
      008C26 12 3A 88         [24] 1600 	lcall	_ak820_outline_0104
                                   1601 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008C29 90 0B 37         [24] 1602 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008C2C 12 3A 40         [24] 1603 	lcall	_ak820_outline_0050
                                   1604 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008C2F 90 0B 3C         [24] 1605 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
      008C32 E4               [12] 1606 	clr	a
      008C33 F0               [24] 1607 	movx	@dptr,a
                                   1608 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008C34 90 0B 35         [24] 1609 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008C37 12 3A 5F         [24] 1610 	lcall	_ak820_outline_0059
      008C3A 8C 02            [24] 1611 	mov	ar2,r4
      008C3C 8D 03            [24] 1612 	mov	ar3,r5
      008C3E C3               [12] 1613 	clr	c
      008C3F 74 1C            [12] 1614 	mov	a,#0x1c
      008C41 9A               [12] 1615 	subb	a,r2
      008C42 E4               [12] 1616 	clr	a
      008C43 9B               [12] 1617 	subb	a,r3
      008C44 50 01            [24] 1618 	jnc	00102$
                                   1619 ;	free result
      008C46 22               [24] 1620 	ret
      008C47                       1621 00102$:
                                   1622 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008C47 90 0B 33         [24] 1623 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008C4A 12 45 65         [24] 1624 	lcall	_ak820_outline_0119
      008C4D 90 0B 31         [24] 1625 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008C50 12 3A 7D         [24] 1626 	lcall	_ak820_outline_0099
      008C53 C3               [12] 1627 	clr	c
      008C54 EA               [12] 1628 	mov	a,r2
      008C55 98               [12] 1629 	subb	a,r0
      008C56 EB               [12] 1630 	mov	a,r3
      008C57 99               [12] 1631 	subb	a,r1
      008C58 50 17            [24] 1632 	jnc	00104$
                                   1633 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008C5A E8               [12] 1634 	mov	a,r0
      008C5B C3               [12] 1635 	clr	c
      008C5C 9A               [12] 1636 	subb	a,r2
      008C5D F8               [12] 1637 	mov	r0,a
      008C5E E9               [12] 1638 	mov	a,r1
      008C5F 9B               [12] 1639 	subb	a,r3
      008C60 F9               [12] 1640 	mov	r1,a
                                   1641 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008C61 C3               [12] 1642 	clr	c
      008C62 E8               [12] 1643 	mov	a,r0
      008C63 9C               [12] 1644 	subb	a,r4
      008C64 E9               [12] 1645 	mov	a,r1
      008C65 9D               [12] 1646 	subb	a,r5
      008C66 40 04            [24] 1647 	jc	00114$
      008C68 8C 00            [24] 1648 	mov	ar0,r4
      008C6A 8D 01            [24] 1649 	mov	ar1,r5
      008C6C                       1650 00114$:
      008C6C 90 0B 3C         [24] 1651 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
      008C6F E8               [12] 1652 	mov	a,r0
      008C70 F0               [24] 1653 	movx	@dptr,a
      008C71                       1654 00104$:
                                   1655 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008C71 90 0B 3C         [24] 1656 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
      008C74 E0               [24] 1657 	movx	a,@dptr
      008C75 F5 2C            [12] 1658 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008C77 E0               [24] 1659 	movx	a,@dptr
      008C78 60 42            [24] 1660 	jz	00106$
      008C7A C0 04            [24] 1661 	push	ar4
      008C7C C0 05            [24] 1662 	push	ar5
      008C7E 8E 00            [24] 1663 	mov	ar0,r6
      008C80 8F 05            [24] 1664 	mov	ar5,r7
      008C82 90 0B 3A         [24] 1665 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_411
      008C85 E0               [24] 1666 	movx	a,@dptr
      008C86 F9               [12] 1667 	mov	r1,a
      008C87 A3               [24] 1668 	inc	dptr
      008C88 E0               [24] 1669 	movx	a,@dptr
      008C89 FC               [12] 1670 	mov	r4,a
      008C8A EA               [12] 1671 	mov	a,r2
      008C8B 29               [12] 1672 	add	a, r1
      008C8C FA               [12] 1673 	mov	r2,a
      008C8D EB               [12] 1674 	mov	a,r3
      008C8E 3C               [12] 1675 	addc	a, r4
      008C8F FB               [12] 1676 	mov	r3,a
      008C90 90 05 91         [24] 1677 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008C93 EA               [12] 1678 	mov	a,r2
      008C94 F0               [24] 1679 	movx	@dptr,a
      008C95 EB               [12] 1680 	mov	a,r3
      008C96 12 3A 94         [24] 1681 	lcall	_ak820_outline_0117
      008C99 90 05 94         [24] 1682 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008C9C E5 2C            [12] 1683 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008C9E 12 3A A5         [24] 1684 	lcall	_ak820_outline_0123
      008CA1 88 82            [24] 1685 	mov	dpl, r0
      008CA3 8D 83            [24] 1686 	mov	dph, r5
      008CA5 C0 07            [24] 1687 	push	ar7
      008CA7 C0 06            [24] 1688 	push	ar6
      008CA9 C0 05            [24] 1689 	push	ar5
      008CAB C0 04            [24] 1690 	push	ar4
      008CAD 12 42 BA         [24] 1691 	lcall	_ak820_eeprom_read_block_xdata
      008CB0 D0 04            [24] 1692 	pop	ar4
      008CB2 D0 05            [24] 1693 	pop	ar5
      008CB4 D0 06            [24] 1694 	pop	ar6
      008CB6 D0 07            [24] 1695 	pop	ar7
                                   1696 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008CB8 D0 05            [24] 1697 	pop	ar5
      008CBA D0 04            [24] 1698 	pop	ar4
                                   1699 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008CBC                       1700 00106$:
                                   1701 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008CBC 90 0B 3C         [24] 1702 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
      008CBF E0               [24] 1703 	movx	a,@dptr
      008CC0 FB               [12] 1704 	mov	r3,a
      008CC1                       1705 00109$:
      008CC1 8B 01            [24] 1706 	mov	ar1,r3
      008CC3 7A 00            [12] 1707 	mov	r2,#0x00
      008CC5 C3               [12] 1708 	clr	c
      008CC6 E9               [12] 1709 	mov	a,r1
      008CC7 9C               [12] 1710 	subb	a,r4
      008CC8 EA               [12] 1711 	mov	a,r2
      008CC9 9D               [12] 1712 	subb	a,r5
      008CCA 50 09            [24] 1713 	jnc	00111$
      008CCC EB               [12] 1714 	mov	a,r3
      008CCD 12 3A 30         [24] 1715 	lcall	_ak820_outline_0030
      008CD0 E4               [12] 1716 	clr	a
      008CD1 F0               [24] 1717 	movx	@dptr,a
      008CD2 0B               [12] 1718 	inc	r3
      008CD3 80 EC            [24] 1719 	sjmp	00109$
      008CD5                       1720 00111$:
                                   1721 ;	quantum/dynamic_keymap.c:483: }
      008CD5 22               [24] 1722 	ret
                                   1723 ;------------------------------------------------------------
                                   1724 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1725 ;------------------------------------------------------------
                                   1726 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1727 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1728 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_418'
                                   1729 ;------------------------------------------------------------
                                   1730 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1731 ;	-----------------------------------------
                                   1732 ;	 function dynamic_keymap_get_buffer
                                   1733 ;	-----------------------------------------
      008CD6                       1734 _dynamic_keymap_get_buffer:
      008CD6 12 3A 83         [24] 1735 	lcall	_ak820_outline_0103
      008CD9 90 0B 42         [24] 1736 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_418
      008CDC 12 3A 88         [24] 1737 	lcall	_ak820_outline_0104
                                   1738 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008CDF 90 0B 42         [24] 1739 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_418
      008CE2 12 3A 40         [24] 1740 	lcall	_ak820_outline_0050
      008CE5 90 0B 3D         [24] 1741 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008CE8 12 3A 5F         [24] 1742 	lcall	_ak820_outline_0059
      008CEB 90 0B 3F         [24] 1743 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008CEE 12 51 3E         [24] 1744 	lcall	_ak820_outline_0086
      008CF1 90 0B 31         [24] 1745 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008CF4 E4               [12] 1746 	clr	a
      008CF5 F0               [24] 1747 	movx	@dptr,a
      008CF6 74 06            [12] 1748 	mov	a,#0x06
      008CF8 A3               [24] 1749 	inc	dptr
      008CF9 F0               [24] 1750 	movx	@dptr,a
      008CFA 90 0B 33         [24] 1751 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008CFD 12 4A 8E         [24] 1752 	lcall	_ak820_outline_0058
      008D00 90 0B 35         [24] 1753 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008D03 12 3A 65         [24] 1754 	lcall	_ak820_outline_0070
      008D06 90 0B 37         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008D09 E9               [12] 1756 	mov	a,r1
      008D0A 12 51 57         [24] 1757 	lcall	_ak820_outline_0154
      008D0D F0               [24] 1758 	movx	@dptr,a
      008D0E 90 00 40         [24] 1759 	mov	dptr,#0x0040
                                   1760 ;	quantum/dynamic_keymap.c:511: }
      008D11 81 20            [12] 1761 	ajmp	_ak820_dynamic_read_buffer
                                   1762 ;------------------------------------------------------------
                                   1763 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1764 ;------------------------------------------------------------
                                   1765 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1766 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1767 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1768 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1769 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1770 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_420'
                                   1771 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_421'
                                   1772 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_421'
                                   1773 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_421'
                                   1774 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_424'
                                   1775 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_427'
                                   1776 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_427'
                                   1777 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_429'
                                   1778 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_432'
                                   1779 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_434'
                                   1780 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_435'
                                   1781 ;------------------------------------------------------------
                                   1782 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1783 ;	-----------------------------------------
                                   1784 ;	 function dynamic_keymap_set_buffer
                                   1785 ;	-----------------------------------------
      008D13                       1786 _dynamic_keymap_set_buffer:
      008D13 12 3A 83         [24] 1787 	lcall	_ak820_outline_0103
      008D16 90 0B 49         [24] 1788 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
      008D19 12 3A 88         [24] 1789 	lcall	_ak820_outline_0104
                                   1790 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008D1C 90 0B 49         [24] 1791 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
      008D1F 12 3A 0B         [24] 1792 	lcall	_ak820_outline_0010
      008D22 74 40            [12] 1793 	mov	a,#0x40
      008D24 2C               [12] 1794 	add	a, r4
      008D25 FA               [12] 1795 	mov	r2,a
      008D26 E4               [12] 1796 	clr	a
      008D27 3D               [12] 1797 	addc	a, r5
      008D28 FB               [12] 1798 	mov	r3,a
                                   1799 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008D29 90 0B 46         [24] 1800 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008D2C 12 3A 7D         [24] 1801 	lcall	_ak820_outline_0099
                                   1802 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008D2F 90 0B 44         [24] 1803 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008D32 E0               [24] 1804 	movx	a,@dptr
      008D33 F5 2D            [12] 1805 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008D35 A3               [24] 1806 	inc	dptr
      008D36 E0               [24] 1807 	movx	a,@dptr
      008D37 F5 2E            [12] 1808 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008D39 E5 2D            [12] 1809 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008D3B 45 2E            [12] 1810 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008D3D 70 01            [24] 1811 	jnz	00102$
      008D3F 22               [24] 1812 	ret
      008D40                       1813 00102$:
                                   1814 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008D40 85 2D 2F         [24] 1815 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008D43 85 2E 30         [24] 1816 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008D46 C3               [12] 1817 	clr	c
      008D47 74 1C            [12] 1818 	mov	a,#0x1c
      008D49 95 2F            [12] 1819 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008D4B E4               [12] 1820 	clr	a
      008D4C 95 30            [12] 1821 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008D4E 50 01            [24] 1822 	jnc	00104$
                                   1823 ;	free result
      008D50 22               [24] 1824 	ret
      008D51                       1825 00104$:
                                   1826 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008D51 85 2D 31         [24] 1827 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1828 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008D54 74 FA            [12] 1829 	mov	a,#0x100 - 0x06
      008D56 2F               [12] 1830 	add	a,r7
      008D57 40 11            [24] 1831 	jc	00105$
      008D59 E4               [12] 1832 	clr	a
      008D5A C3               [12] 1833 	clr	c
      008D5B 9E               [12] 1834 	subb	a,r6
      008D5C FE               [12] 1835 	mov	r6,a
      008D5D 74 06            [12] 1836 	mov	a,#0x06
      008D5F 9F               [12] 1837 	subb	a,r7
      008D60 FF               [12] 1838 	mov	r7,a
      008D61 C3               [12] 1839 	clr	c
      008D62 EE               [12] 1840 	mov	a,r6
      008D63 95 2D            [12] 1841 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008D65 EF               [12] 1842 	mov	a,r7
      008D66 95 2E            [12] 1843 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008D68 50 01            [24] 1844 	jnc	00106$
      008D6A                       1845 00105$:
                                   1846 ;	quantum/dynamic_keymap.c:529: return;
      008D6A 22               [24] 1847 	ret
      008D6B                       1848 00106$:
                                   1849 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008D6B 90 0E 22         [24] 1850 	mov	dptr,#_vial_unlocked
      008D6E E0               [24] 1851 	movx	a,@dptr
      008D6F 60 02            [24] 1852 	jz	00207$
      008D71 C1 7E            [12] 1853 	ajmp	00120$
      008D73                       1854 00207$:
                                   1855 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008D73 90 0B 4B         [24] 1856 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_427
      008D76 E4               [12] 1857 	clr	a
      008D77 F0               [24] 1858 	movx	@dptr,a
                                   1859 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008D78 90 0B 4C         [24] 1860 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_427
      008D7B E5 31            [12] 1861 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008D7D F0               [24] 1862 	movx	@dptr,a
                                   1863 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008D7E EC               [12] 1864 	mov	a,r4
      008D7F 30 E0 33         [24] 1865 	jnb	acc.0,00111$
                                   1866 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008D82 EA               [12] 1867 	mov	a,r2
      008D83 24 FF            [12] 1868 	add	a,#0xff
      008D85 FE               [12] 1869 	mov	r6,a
      008D86 EB               [12] 1870 	mov	a,r3
      008D87 34 FF            [12] 1871 	addc	a,#0xff
      008D89 FF               [12] 1872 	mov	r7,a
      008D8A 7D 00            [12] 1873 	mov	r5,#0x00
      008D8C 12 45 60         [24] 1874 	lcall	_ak820_outline_0116
      008D8F 8D F0            [24] 1875 	mov	b, r5
      008D91 12 42 7F         [24] 1876 	lcall	_eeprom_read_byte
      008D94 AE 82            [24] 1877 	mov	r6,dpl
      008D96 7F 00            [12] 1878 	mov	r7,#0x00
      008D98 12 3A B5         [24] 1879 	lcall	_ak820_outline_0155
      008D9B E0               [24] 1880 	movx	a,@dptr
      008D9C 7C 00            [12] 1881 	mov	r4,#0x00
      008D9E 42 07            [12] 1882 	orl	ar7,a
      008DA0 EC               [12] 1883 	mov	a,r4
      008DA1 42 06            [12] 1884 	orl	ar6,a
                                   1885 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008DA3 BF 00 09         [24] 1886 	cjne	r7,#0x00,00109$
      008DA6 BE 7C 06         [24] 1887 	cjne	r6,#0x7c,00109$
                                   1888 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008DA9 12 3A B5         [24] 1889 	lcall	_ak820_outline_0155
      008DAC 74 FF            [12] 1890 	mov	a,#0xff
      008DAE F0               [24] 1891 	movx	@dptr,a
      008DAF                       1892 00109$:
                                   1893 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008DAF 90 0B 4B         [24] 1894 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_427
      008DB2 74 01            [12] 1895 	mov	a,#0x01
      008DB4 F0               [24] 1896 	movx	@dptr,a
      008DB5                       1897 00111$:
                                   1898 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008DB5 90 0B 49         [24] 1899 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
      008DB8 12 3A 40         [24] 1900 	lcall	_ak820_outline_0050
      008DBB E5 2D            [12] 1901 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008DBD 2E               [12] 1902 	add	a, r6
      008DBE FE               [12] 1903 	mov	r6,a
      008DBF E5 2E            [12] 1904 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008DC1 3F               [12] 1905 	addc	a, r7
      008DC2 EE               [12] 1906 	mov	a,r6
      008DC3 30 E0 5A         [24] 1907 	jnb	acc.0,00115$
                                   1908 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008DC6 AE 31            [24] 1909 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008DC8 7F 00            [12] 1910 	mov	r7,#0x00
      008DCA EE               [12] 1911 	mov	a,r6
      008DCB 24 FF            [12] 1912 	add	a,#0xff
      008DCD FC               [12] 1913 	mov	r4,a
      008DCE EF               [12] 1914 	mov	a,r7
      008DCF 34 FF            [12] 1915 	addc	a,#0xff
      008DD1 FD               [12] 1916 	mov	r5,a
      008DD2 EC               [12] 1917 	mov	a,r4
      008DD3 28               [12] 1918 	add	a, r0
      008DD4 F5 82            [12] 1919 	mov	dpl,a
      008DD6 ED               [12] 1920 	mov	a,r5
      008DD7 39               [12] 1921 	addc	a, r1
      008DD8 F5 83            [12] 1922 	mov	dph,a
      008DDA E0               [24] 1923 	movx	a,@dptr
      008DDB FC               [12] 1924 	mov	r4,a
      008DDC 7D 00            [12] 1925 	mov	r5,#0x00
      008DDE E5 31            [12] 1926 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008DE0 2A               [12] 1927 	add	a, r2
      008DE1 FA               [12] 1928 	mov	r2,a
      008DE2 E4               [12] 1929 	clr	a
      008DE3 3B               [12] 1930 	addc	a, r3
      008DE4 FB               [12] 1931 	mov	r3,a
      008DE5 C0 00            [24] 1932 	push	ar0
      008DE7 C0 01            [24] 1933 	push	ar1
      008DE9 8B 01            [24] 1934 	mov	ar1,r3
      008DEB 7B 00            [12] 1935 	mov	r3,#0x00
      008DED 8A 82            [24] 1936 	mov	dpl, r2
      008DEF 89 83            [24] 1937 	mov	dph, r1
      008DF1 8B F0            [24] 1938 	mov	b, r3
      008DF3 12 42 7F         [24] 1939 	lcall	_eeprom_read_byte
      008DF6 AB 82            [24] 1940 	mov	r3, dpl
      008DF8 7A 00            [12] 1941 	mov	r2,#0x00
      008DFA EB               [12] 1942 	mov	a,r3
      008DFB 12 45 76         [24] 1943 	lcall	_ak820_outline_0141
                                   1944 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008DFE BD 00 05         [24] 1945 	cjne	r5,#0x00,00212$
      008E01 BC 7C 02         [24] 1946 	cjne	r4,#0x7c,00212$
      008E04 80 06            [24] 1947 	sjmp	00213$
      008E06                       1948 00212$:
      008E06 D0 01            [24] 1949 	pop	ar1
      008E08 D0 00            [24] 1950 	pop	ar0
      008E0A 80 0D            [24] 1951 	sjmp	00113$
      008E0C                       1952 00213$:
      008E0C D0 01            [24] 1953 	pop	ar1
      008E0E D0 00            [24] 1954 	pop	ar0
                                   1955 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008E10 1E               [12] 1956 	dec	r6
      008E11 BE FF 01         [24] 1957 	cjne	r6,#0xff,00214$
      008E14 1F               [12] 1958 	dec	r7
      008E15                       1959 00214$:
      008E15 EE               [12] 1960 	mov	a,r6
      008E16 12 92 AD         [24] 1961 	lcall	_ak820_outline_0127
      008E19                       1962 00113$:
                                   1963 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008E19 E5 31            [12] 1964 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008E1B 14               [12] 1965 	dec	a
      008E1C 90 0B 4C         [24] 1966 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_427
      008E1F F0               [24] 1967 	movx	@dptr,a
      008E20                       1968 00115$:
                                   1969 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008E20 90 0B 4B         [24] 1970 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_427
      008E23 E0               [24] 1971 	movx	a,@dptr
      008E24 90 0B 4D         [24] 1972 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_434
      008E27 F0               [24] 1973 	movx	@dptr,a
      008E28                       1974 00122$:
      008E28 90 0B 4D         [24] 1975 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_434
      008E2B E0               [24] 1976 	movx	a,@dptr
      008E2C FF               [12] 1977 	mov	r7,a
      008E2D 90 0B 4C         [24] 1978 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_427
      008E30 E0               [24] 1979 	movx	a,@dptr
      008E31 FE               [12] 1980 	mov	r6,a
      008E32 C3               [12] 1981 	clr	c
      008E33 EF               [12] 1982 	mov	a,r7
      008E34 9E               [12] 1983 	subb	a,r6
      008E35 50 47            [24] 1984 	jnc	00120$
                                   1985 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008E37 EF               [12] 1986 	mov	a,r7
      008E38 28               [12] 1987 	add	a, r0
      008E39 FD               [12] 1988 	mov	r5,a
      008E3A E4               [12] 1989 	clr	a
      008E3B 39               [12] 1990 	addc	a, r1
      008E3C 12 4A 86         [24] 1991 	lcall	_ak820_outline_0056
      008E3F 7B 00            [12] 1992 	mov	r3,#0x00
      008E41 8C 2E            [24] 1993 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008E43 8B 2D            [24] 1994 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008E45 8F 02            [24] 1995 	mov	ar2,r7
      008E47 7F 00            [12] 1996 	mov	r7,#0x00
      008E49 74 01            [12] 1997 	mov	a,#0x01
      008E4B 2A               [12] 1998 	add	a, r2
      008E4C FB               [12] 1999 	mov	r3,a
      008E4D E4               [12] 2000 	clr	a
      008E4E 3F               [12] 2001 	addc	a, r7
      008E4F FC               [12] 2002 	mov	r4,a
      008E50 EB               [12] 2003 	mov	a,r3
      008E51 28               [12] 2004 	add	a, r0
      008E52 F5 82            [12] 2005 	mov	dpl,a
      008E54 EC               [12] 2006 	mov	a,r4
      008E55 39               [12] 2007 	addc	a, r1
      008E56 F5 83            [12] 2008 	mov	dph,a
      008E58 E0               [24] 2009 	movx	a,@dptr
      008E59 FC               [12] 2010 	mov	r4,a
      008E5A 7B 00            [12] 2011 	mov	r3,#0x00
      008E5C E5 2E            [12] 2012 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E5E 42 03            [12] 2013 	orl	ar3,a
                                   2014 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008E60 BC 00 12         [24] 2015 	cjne	r4,#0x00,00123$
      008E63 BB 7C 0F         [24] 2016 	cjne	r3,#0x7c,00123$
                                   2017 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008E66 12 3A AA         [24] 2018 	lcall	_ak820_outline_0131
      008E69 74 FF            [12] 2019 	mov	a,#0xff
      008E6B F0               [24] 2020 	movx	@dptr,a
                                   2021 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008E6C 0A               [12] 2022 	inc	r2
      008E6D BA 00 01         [24] 2023 	cjne	r2,#0x00,00218$
      008E70 0F               [12] 2024 	inc	r7
      008E71                       2025 00218$:
      008E71 EA               [12] 2026 	mov	a,r2
      008E72 12 92 AD         [24] 2027 	lcall	_ak820_outline_0127
      008E75                       2028 00123$:
                                   2029 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008E75 90 0B 4D         [24] 2030 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_434
      008E78 E0               [24] 2031 	movx	a,@dptr
      008E79 24 02            [12] 2032 	add	a,#0x02
      008E7B F0               [24] 2033 	movx	@dptr,a
      008E7C 80 AA            [24] 2034 	sjmp	00122$
      008E7E                       2035 00120$:
                                   2036 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008E7E 90 0B 49         [24] 2037 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
      008E81 12 3A 40         [24] 2038 	lcall	_ak820_outline_0050
      008E84 74 40            [12] 2039 	mov	a,#0x40
      008E86 12 45 70         [24] 2040 	lcall	_ak820_outline_0134
      008E89 90 05 9A         [24] 2041 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008E8C 12 4A 8E         [24] 2042 	lcall	_ak820_outline_0058
      008E8F E4               [12] 2043 	clr	a
      008E90 A3               [24] 2044 	inc	dptr
      008E91 F0               [24] 2045 	movx	@dptr,a
      008E92 90 05 9D         [24] 2046 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008E95 E5 2F            [12] 2047 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008E97 F0               [24] 2048 	movx	@dptr,a
      008E98 E5 30            [12] 2049 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008E9A A3               [24] 2050 	inc	dptr
      008E9B F0               [24] 2051 	movx	@dptr,a
      008E9C 12 3A B5         [24] 2052 	lcall	_ak820_outline_0155
                                   2053 ;	quantum/dynamic_keymap.c:584: }
      008E9F 02 43 46         [24] 2054 	ljmp	_ak820_eeprom_write_block_xdata
                                   2055 ;------------------------------------------------------------
                                   2056 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2057 ;------------------------------------------------------------
                                   2058 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2059 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2060 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_438'
                                   2061 ;------------------------------------------------------------
                                   2062 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2063 ;	-----------------------------------------
                                   2064 ;	 function keycode_at_keymap_location
                                   2065 ;	-----------------------------------------
      008EA2                       2066 _keycode_at_keymap_location:
      008EA2 E5 82            [12] 2067 	mov	a,dpl
      008EA4 90 0B 50         [24] 2068 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_438
      008EA7 F0               [24] 2069 	movx	@dptr,a
                                   2070 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008EA8 E0               [24] 2071 	movx	a,@dptr
      008EA9 FF               [12] 2072 	mov	r7,a
      008EAA BF 06 00         [24] 2073 	cjne	r7,#0x06,00128$
      008EAD                       2074 00128$:
      008EAD 50 22            [24] 2075 	jnc	00102$
      008EAF 90 0B 4E         [24] 2076 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008EB2 E0               [24] 2077 	movx	a,@dptr
      008EB3 FE               [12] 2078 	mov	r6,a
      008EB4 BE 10 00         [24] 2079 	cjne	r6,#0x10,00130$
      008EB7                       2080 00130$:
      008EB7 50 18            [24] 2081 	jnc	00102$
      008EB9 90 0B 4F         [24] 2082 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008EBC E0               [24] 2083 	movx	a,@dptr
      008EBD FD               [12] 2084 	mov	r5,a
      008EBE BD 08 00         [24] 2085 	cjne	r5,#0x08,00132$
      008EC1                       2086 00132$:
      008EC1 50 0E            [24] 2087 	jnc	00102$
                                   2088 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008EC3 90 0B 02         [24] 2089 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008EC6 EE               [12] 2090 	mov	a,r6
      008EC7 F0               [24] 2091 	movx	@dptr,a
      008EC8 90 0B 03         [24] 2092 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008ECB ED               [12] 2093 	mov	a,r5
      008ECC F0               [24] 2094 	movx	@dptr,a
      008ECD 8F 82            [24] 2095 	mov	dpl, r7
      008ECF 01 42            [12] 2096 	ajmp	_dynamic_keymap_get_keycode
      008ED1                       2097 00102$:
                                   2098 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008ED1 90 00 00         [24] 2099 	mov	dptr,#0x0000
                                   2100 ;	quantum/dynamic_keymap.c:591: }
      008ED4 22               [24] 2101 	ret
                                   2102 ;------------------------------------------------------------
                                   2103 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2104 ;------------------------------------------------------------
                                   2105 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2106 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2107 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_442'
                                   2108 ;------------------------------------------------------------
                                   2109 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2110 ;	-----------------------------------------
                                   2111 ;	 function keycode_at_encodermap_location
                                   2112 ;	-----------------------------------------
      008ED5                       2113 _keycode_at_encodermap_location:
      008ED5 E5 82            [12] 2114 	mov	a,dpl
      008ED7 90 0B 53         [24] 2115 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_442
      008EDA F0               [24] 2116 	movx	@dptr,a
                                   2117 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008EDB E0               [24] 2118 	movx	a,@dptr
      008EDC FF               [12] 2119 	mov	r7,a
      008EDD BF 06 00         [24] 2120 	cjne	r7,#0x06,00120$
      008EE0                       2121 00120$:
      008EE0 50 1D            [24] 2122 	jnc	00102$
      008EE2 90 0B 51         [24] 2123 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008EE5 E0               [24] 2124 	movx	a,@dptr
      008EE6 FE               [12] 2125 	mov	r6,a
      008EE7 BE 01 00         [24] 2126 	cjne	r6,#0x01,00122$
      008EEA                       2127 00122$:
      008EEA 50 13            [24] 2128 	jnc	00102$
                                   2129 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008EEC 90 0B 52         [24] 2130 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008EEF E0               [24] 2131 	movx	a,@dptr
      008EF0 FE               [12] 2132 	mov	r6,a
      008EF1 90 0B 0C         [24] 2133 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008EF4 E4               [12] 2134 	clr	a
      008EF5 F0               [24] 2135 	movx	@dptr,a
      008EF6 90 0B 0D         [24] 2136 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008EF9 EE               [12] 2137 	mov	a,r6
      008EFA F0               [24] 2138 	movx	@dptr,a
      008EFB 8F 82            [24] 2139 	mov	dpl, r7
      008EFD 21 01            [12] 2140 	ajmp	_dynamic_keymap_get_encoder
      008EFF                       2141 00102$:
                                   2142 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008EFF 90 00 00         [24] 2143 	mov	dptr,#0x0000
                                   2144 ;	quantum/dynamic_keymap.c:599: }
      008F02 22               [24] 2145 	ret
                                   2146 ;------------------------------------------------------------
                                   2147 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2148 ;------------------------------------------------------------
                                   2149 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2150 ;	-----------------------------------------
                                   2151 ;	 function dynamic_keymap_macro_get_count
                                   2152 ;	-----------------------------------------
      008F03                       2153 _dynamic_keymap_macro_get_count:
                                   2154 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008F03 75 82 10         [24] 2155 	mov	dpl, #0x10
                                   2156 ;	quantum/dynamic_keymap.c:604: }
      008F06 22               [24] 2157 	ret
                                   2158 ;------------------------------------------------------------
                                   2159 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2160 ;------------------------------------------------------------
                                   2161 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2162 ;	-----------------------------------------
                                   2163 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2164 ;	-----------------------------------------
      008F07                       2165 _dynamic_keymap_macro_get_buffer_size:
                                   2166 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008F07 90 20 00         [24] 2167 	mov	dptr,#0x2000
                                   2168 ;	quantum/dynamic_keymap.c:608: }
      008F0A 22               [24] 2169 	ret
                                   2170 ;------------------------------------------------------------
                                   2171 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2172 ;------------------------------------------------------------
                                   2173 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2174 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2175 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2176 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_450'
                                   2177 ;------------------------------------------------------------
                                   2178 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2179 ;	-----------------------------------------
                                   2180 ;	 function dynamic_keymap_macro_get_buffer
                                   2181 ;	-----------------------------------------
      008F0B                       2182 _dynamic_keymap_macro_get_buffer:
      008F0B 12 3A 83         [24] 2183 	lcall	_ak820_outline_0103
      008F0E 90 0B 59         [24] 2184 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_450
      008F11 12 3A 88         [24] 2185 	lcall	_ak820_outline_0104
                                   2186 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008F14 12 2B 2B         [24] 2187 	lcall	_ak820_macro_length
      008F17 12 45 6B         [24] 2188 	lcall	_ak820_outline_0132
      008F1A 90 0B 59         [24] 2189 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_450
      008F1D 12 3A 5F         [24] 2190 	lcall	_ak820_outline_0059
      008F20 90 0B 54         [24] 2191 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008F23 E0               [24] 2192 	movx	a,@dptr
      008F24 F5 32            [12] 2193 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008F26 A3               [24] 2194 	inc	dptr
      008F27 E0               [24] 2195 	movx	a,@dptr
      008F28 F5 33            [12] 2196 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008F2A 90 0B 56         [24] 2197 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008F2D 12 3A 7D         [24] 2198 	lcall	_ak820_outline_0099
      008F30 A3               [24] 2199 	inc	dptr
      008F31 E0               [24] 2200 	movx	a,@dptr
      008F32 FB               [12] 2201 	mov	r3,a
      008F33 90 0B 31         [24] 2202 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008F36 12 4A 8E         [24] 2203 	lcall	_ak820_outline_0058
      008F39 90 0B 33         [24] 2204 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008F3C 12 3A 65         [24] 2205 	lcall	_ak820_outline_0070
      008F3F 90 0B 35         [24] 2206 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008F42 E5 32            [12] 2207 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008F44 F0               [24] 2208 	movx	@dptr,a
      008F45 E5 33            [12] 2209 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008F47 A3               [24] 2210 	inc	dptr
      008F48 F0               [24] 2211 	movx	@dptr,a
      008F49 90 0B 37         [24] 2212 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008F4C E8               [12] 2213 	mov	a,r0
      008F4D F0               [24] 2214 	movx	@dptr,a
      008F4E E9               [12] 2215 	mov	a,r1
      008F4F A3               [24] 2216 	inc	dptr
      008F50 F0               [24] 2217 	movx	@dptr,a
      008F51 EB               [12] 2218 	mov	a,r3
      008F52 A3               [24] 2219 	inc	dptr
      008F53 F0               [24] 2220 	movx	@dptr,a
      008F54 90 08 00         [24] 2221 	mov	dptr,#0x0800
                                   2222 ;	quantum/dynamic_keymap.c:635: }
      008F57 81 20            [12] 2223 	ajmp	_ak820_dynamic_read_buffer
                                   2224 ;------------------------------------------------------------
                                   2225 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2226 ;------------------------------------------------------------
                                   2227 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2228 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2229 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_452'
                                   2230 ;------------------------------------------------------------
                                   2231 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2232 ;	-----------------------------------------
                                   2233 ;	 function dynamic_keymap_macro_set_buffer
                                   2234 ;	-----------------------------------------
      008F59                       2235 _dynamic_keymap_macro_set_buffer:
      008F59 12 3A 83         [24] 2236 	lcall	_ak820_outline_0103
      008F5C 90 0B 60         [24] 2237 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_452
      008F5F 12 3A 88         [24] 2238 	lcall	_ak820_outline_0104
                                   2239 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      008F62 90 0B 60         [24] 2240 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_452
      008F65 12 3A 40         [24] 2241 	lcall	_ak820_outline_0050
      008F68 90 0B 5B         [24] 2242 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008F6B 12 3A 5F         [24] 2243 	lcall	_ak820_outline_0059
      008F6E 90 0B 5D         [24] 2244 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008F71 12 51 3E         [24] 2245 	lcall	_ak820_outline_0086
      008F74 90 05 20         [24] 2246 	mov	dptr,#_ak820_macro_write_PARM_2
      008F77 12 3A 65         [24] 2247 	lcall	_ak820_outline_0070
      008F7A 90 05 22         [24] 2248 	mov	dptr,#_ak820_macro_write_PARM_3
      008F7D E9               [12] 2249 	mov	a,r1
      008F7E 12 51 57         [24] 2250 	lcall	_ak820_outline_0154
      008F81 12 45 42         [24] 2251 	lcall	_ak820_outline_0060
                                   2252 ;	quantum/dynamic_keymap.c:640: }
      008F84 02 2B 45         [24] 2253 	ljmp	_ak820_macro_write
                                   2254 ;------------------------------------------------------------
                                   2255 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2256 ;------------------------------------------------------------
                                   2257 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2258 ;	-----------------------------------------
                                   2259 ;	 function dynamic_keymap_macro_reset
                                   2260 ;	-----------------------------------------
      008F87                       2261 _dynamic_keymap_macro_reset:
                                   2262 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2263 ;	quantum/dynamic_keymap.c:666: }
      008F87 02 2E 64         [24] 2264 	ljmp	_ak820_macro_reset
                                   2265 ;------------------------------------------------------------
                                   2266 ;Allocation info for local variables in function 'decode_keycode'
                                   2267 ;------------------------------------------------------------
                                   2268 ;kc            Allocated with name '_decode_keycode_kc_10000_456'
                                   2269 ;------------------------------------------------------------
                                   2270 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2271 ;	-----------------------------------------
                                   2272 ;	 function decode_keycode
                                   2273 ;	-----------------------------------------
      008F8A                       2274 _decode_keycode:
      008F8A 12 3A 83         [24] 2275 	lcall	_ak820_outline_0103
      008F8D 90 0B 62         [24] 2276 	mov	dptr,#_decode_keycode_kc_10000_456
      008F90 12 3A 88         [24] 2277 	lcall	_ak820_outline_0104
                                   2278 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      008F93 90 0B 62         [24] 2279 	mov	dptr,#_decode_keycode_kc_10000_456
      008F96 12 3A 0B         [24] 2280 	lcall	_ak820_outline_0010
      008F99 C3               [12] 2281 	clr	c
      008F9A E4               [12] 2282 	clr	a
      008F9B 9C               [12] 2283 	subb	a,r4
      008F9C 74 FF            [12] 2284 	mov	a,#0xff
      008F9E 9D               [12] 2285 	subb	a,r5
      008F9F 50 08            [24] 2286 	jnc	00102$
                                   2287 ;	free result
                                   2288 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      008FA1 8C 05            [24] 2289 	mov	ar5,r4
      008FA3 7C 00            [12] 2290 	mov	r4,#0x00
      008FA5 12 3A A0         [24] 2291 	lcall	_ak820_outline_0121
      008FA8 22               [24] 2292 	ret
      008FA9                       2293 00102$:
                                   2294 ;	quantum/dynamic_keymap.c:672: return kc;
      008FA9 12 45 60         [24] 2295 	lcall	_ak820_outline_0116
                                   2296 ;	quantum/dynamic_keymap.c:673: }
      008FAC 22               [24] 2297 	ret
                                   2298 ;------------------------------------------------------------
                                   2299 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2300 ;------------------------------------------------------------
                                   2301 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_459'
                                   2302 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_460'
                                   2303 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_465'
                                   2304 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_466'
                                   2305 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_472'
                                   2306 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_490'
                                   2307 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_494'
                                   2308 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_494'
                                   2309 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_496'
                                   2310 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_498'
                                   2311 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_502'
                                   2312 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_504'
                                   2313 ;------------------------------------------------------------
                                   2314 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2315 ;	-----------------------------------------
                                   2316 ;	 function dynamic_keymap_macro_send
                                   2317 ;	-----------------------------------------
      008FAD                       2318 _dynamic_keymap_macro_send:
      008FAD E5 82            [12] 2319 	mov	a,dpl
      008FAF 90 0B 64         [24] 2320 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_459
      008FB2 F0               [24] 2321 	movx	@dptr,a
                                   2322 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      008FB3 90 0B 65         [24] 2323 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_460
      008FB6 E0               [24] 2324 	movx	a,@dptr
      008FB7 60 01            [24] 2325 	jz	00102$
      008FB9 22               [24] 2326 	ret
      008FBA                       2327 00102$:
                                   2328 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008FBA 90 0B 64         [24] 2329 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_459
      008FBD E0               [24] 2330 	movx	a,@dptr
      008FBE FF               [12] 2331 	mov	r7,a
      008FBF BF 10 00         [24] 2332 	cjne	r7,#0x10,00422$
      008FC2                       2333 00422$:
      008FC2 40 01            [24] 2334 	jc	00104$
                                   2335 ;	quantum/dynamic_keymap.c:683: return;
      008FC4 22               [24] 2336 	ret
      008FC5                       2337 00104$:
                                   2338 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      008FC5 C0 07            [24] 2339 	push	ar7
      008FC7 12 2A F2         [24] 2340 	lcall	_ak820_macro_ready
      008FCA E5 82            [12] 2341 	mov	a, dpl
      008FCC D0 07            [24] 2342 	pop	ar7
      008FCE 70 01            [24] 2343 	jnz	00106$
      008FD0 22               [24] 2344 	ret
      008FD1                       2345 00106$:
                                   2346 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008FD1 90 0B 66         [24] 2347 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      008FD4 E4               [12] 2348 	clr	a
      008FD5 F0               [24] 2349 	movx	@dptr,a
      008FD6 74 08            [12] 2350 	mov	a,#0x08
      008FD8 A3               [24] 2351 	inc	dptr
      008FD9 F0               [24] 2352 	movx	@dptr,a
                                   2353 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008FDA C0 07            [24] 2354 	push	ar7
      008FDC 12 2B 2B         [24] 2355 	lcall	_ak820_macro_length
      008FDF AD 82            [24] 2356 	mov	r5, dpl
      008FE1 AE 83            [24] 2357 	mov	r6, dph
      008FE3 D0 07            [24] 2358 	pop	ar7
      008FE5 74 08            [12] 2359 	mov	a,#0x08
      008FE7 2E               [12] 2360 	add	a, r6
      008FE8 FE               [12] 2361 	mov	r6,a
                                   2362 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      008FE9 7B 00            [12] 2363 	mov	r3,#0x00
      008FEB 7C 08            [12] 2364 	mov	r4,#0x08
      008FED                       2365 00111$:
      008FED EF               [12] 2366 	mov	a,r7
      008FEE 60 31            [24] 2367 	jz	00113$
                                   2368 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008FF0 EB               [12] 2369 	mov	a,r3
      008FF1 B5 05 05         [24] 2370 	cjne	a,ar5,00108$
      008FF4 EC               [12] 2371 	mov	a,r4
      008FF5 B5 06 01         [24] 2372 	cjne	a,ar6,00108$
                                   2373 ;	quantum/dynamic_keymap.c:717: return;
      008FF8 22               [24] 2374 	ret
      008FF9                       2375 00108$:
                                   2376 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008FF9 8B 01            [24] 2377 	mov	ar1,r3
      008FFB 8C 02            [24] 2378 	mov	ar2,r4
      008FFD 8A 00            [24] 2379 	mov	ar0,r2
      008FFF 7A 00            [12] 2380 	mov	r2,#0x00
      009001 89 82            [24] 2381 	mov	dpl, r1
      009003 88 83            [24] 2382 	mov	dph, r0
      009005 8A F0            [24] 2383 	mov	b, r2
      009007 12 42 7F         [24] 2384 	lcall	_eeprom_read_byte
      00900A E5 82            [12] 2385 	mov	a, dpl
      00900C 70 06            [24] 2386 	jnz	00110$
                                   2387 ;	quantum/dynamic_keymap.c:720: --id;
      00900E 1F               [12] 2388 	dec	r7
      00900F 90 0B 64         [24] 2389 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_459
      009012 EF               [12] 2390 	mov	a,r7
      009013 F0               [24] 2391 	movx	@dptr,a
      009014                       2392 00110$:
                                   2393 ;	quantum/dynamic_keymap.c:722: ++p;
      009014 0B               [12] 2394 	inc	r3
      009015 BB 00 01         [24] 2395 	cjne	r3,#0x00,00429$
      009018 0C               [12] 2396 	inc	r4
      009019                       2397 00429$:
      009019 90 0B 66         [24] 2398 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      00901C 12 3A 6B         [24] 2399 	lcall	_ak820_outline_0075
      00901F 80 CC            [24] 2400 	sjmp	00111$
      009021                       2401 00113$:
                                   2402 ;	quantum/dynamic_keymap.c:728: sending = true;
      009021 90 0B 65         [24] 2403 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_460
      009024 74 01            [12] 2404 	mov	a,#0x01
      009026 F0               [24] 2405 	movx	@dptr,a
                                   2406 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      009027 12 92 C5         [24] 2407 	lcall	_ak820_outline_0162
      00902A 90 09 AE         [24] 2408 	mov	dptr,#_ak820_macro_cancelled
      00902D F0               [24] 2409 	movx	@dptr,a
                                   2410 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      00902E 90 0B 68         [24] 2411 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      009031 F0               [24] 2412 	movx	@dptr,a
      009032 90 0B 69         [24] 2413 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      009035 F0               [24] 2414 	movx	@dptr,a
      009036 90 0B 6A         [24] 2415 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0002)
      009039 F0               [24] 2416 	movx	@dptr,a
      00903A 90 0B 6B         [24] 2417 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0003)
      00903D F0               [24] 2418 	movx	@dptr,a
                                   2419 ;	quantum/dynamic_keymap.c:738: while (p < end
      00903E                       2420 00167$:
                                   2421 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      00903E 90 0B 66         [24] 2422 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      009041 E0               [24] 2423 	movx	a,@dptr
      009042 FC               [12] 2424 	mov	r4,a
      009043 A3               [24] 2425 	inc	dptr
      009044 E0               [24] 2426 	movx	a,@dptr
      009045 FF               [12] 2427 	mov	r7,a
      009046 C3               [12] 2428 	clr	c
      009047 EC               [12] 2429 	mov	a,r4
      009048 9D               [12] 2430 	subb	a,r5
      009049 EF               [12] 2431 	mov	a,r7
      00904A 9E               [12] 2432 	subb	a,r6
      00904B 40 02            [24] 2433 	jc	00430$
      00904D 41 53            [12] 2434 	ajmp	00169$
      00904F                       2435 00430$:
      00904F 90 09 AE         [24] 2436 	mov	dptr,#_ak820_macro_cancelled
      009052 E0               [24] 2437 	movx	a,@dptr
      009053 60 02            [24] 2438 	jz	00431$
      009055 41 53            [12] 2439 	ajmp	00169$
      009057                       2440 00431$:
                                   2441 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009057 8C 02            [24] 2442 	mov	ar2,r4
      009059 8F 03            [24] 2443 	mov	ar3,r7
      00905B 90 0B 66         [24] 2444 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      00905E 74 01            [12] 2445 	mov	a,#0x01
      009060 2C               [12] 2446 	add	a, r4
      009061 F0               [24] 2447 	movx	@dptr,a
      009062 E4               [12] 2448 	clr	a
      009063 3F               [12] 2449 	addc	a, r7
      009064 A3               [24] 2450 	inc	dptr
      009065 F0               [24] 2451 	movx	@dptr,a
      009066 7F 00            [12] 2452 	mov	r7,#0x00
      009068 12 45 7C         [24] 2453 	lcall	_ak820_outline_0142
      00906B 8F F0            [24] 2454 	mov	b, r7
      00906D 12 42 7F         [24] 2455 	lcall	_eeprom_read_byte
      009070 AF 82            [24] 2456 	mov	r7, dpl
      009072 90 0B 68         [24] 2457 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      009075 EF               [12] 2458 	mov	a,r7
      009076 F0               [24] 2459 	movx	@dptr,a
                                   2460 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      009077 90 0B 69         [24] 2461 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      00907A E4               [12] 2462 	clr	a
      00907B F0               [24] 2463 	movx	@dptr,a
                                   2464 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      00907C 90 0B 68         [24] 2465 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      00907F E0               [24] 2466 	movx	a,@dptr
      009080 70 02            [24] 2467 	jnz	00432$
      009082 41 53            [12] 2468 	ajmp	00169$
      009084                       2469 00432$:
                                   2470 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      009084 90 0B 68         [24] 2471 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      009087 E0               [24] 2472 	movx	a,@dptr
      009088 FF               [12] 2473 	mov	r7,a
      009089 BF 01 02         [24] 2474 	cjne	r7,#0x01,00433$
      00908C 80 02            [24] 2475 	sjmp	00434$
      00908E                       2476 00433$:
      00908E 41 36            [12] 2477 	ajmp	00164$
      009090                       2478 00434$:
                                   2479 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009090 12 92 5B         [24] 2480 	lcall	_ak820_outline_0000
      009093 12 42 7F         [24] 2481 	lcall	_eeprom_read_byte
      009096 AF 82            [24] 2482 	mov	r7, dpl
      009098 90 0B 69         [24] 2483 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      00909B EF               [12] 2484 	mov	a,r7
      00909C F0               [24] 2485 	movx	@dptr,a
                                   2486 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      00909D EF               [12] 2487 	mov	a,r7
      00909E 70 02            [24] 2488 	jnz	00435$
      0090A0 41 53            [12] 2489 	ajmp	00169$
      0090A2                       2490 00435$:
                                   2491 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      0090A2 12 92 93         [24] 2492 	lcall	_ak820_outline_0088
      0090A5 BF 01 02         [24] 2493 	cjne	r7,#0x01,00436$
      0090A8 80 12            [24] 2494 	sjmp	00151$
      0090AA                       2495 00436$:
      0090AA 12 92 93         [24] 2496 	lcall	_ak820_outline_0088
      0090AD BF 02 02         [24] 2497 	cjne	r7,#0x02,00437$
      0090B0 80 0A            [24] 2498 	sjmp	00151$
      0090B2                       2499 00437$:
      0090B2 12 92 93         [24] 2500 	lcall	_ak820_outline_0088
      0090B5 BF 03 02         [24] 2501 	cjne	r7,#0x03,00438$
      0090B8 80 02            [24] 2502 	sjmp	00439$
      0090BA                       2503 00438$:
      0090BA 21 1B            [12] 2504 	ajmp	00152$
      0090BC                       2505 00439$:
      0090BC                       2506 00151$:
                                   2507 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0090BC 12 92 5B         [24] 2508 	lcall	_ak820_outline_0000
      0090BF 12 42 7F         [24] 2509 	lcall	_eeprom_read_byte
      0090C2 12 92 DD         [24] 2510 	lcall	_ak820_outline_0177
                                   2511 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      0090C5 70 02            [24] 2512 	jnz	00440$
      0090C7 01 3E            [12] 2513 	ajmp	00167$
      0090C9                       2514 00440$:
                                   2515 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      0090C9 12 92 93         [24] 2516 	lcall	_ak820_outline_0088
      0090CC BF 01 03         [24] 2517 	cjne	r7,#0x01,00441$
      0090CF D3               [12] 2518 	setb	c
      0090D0 80 01            [24] 2519 	sjmp	00442$
      0090D2                       2520 00441$:
      0090D2 C3               [12] 2521 	clr	c
      0090D3                       2522 00442$:
      0090D3 92 25            [24] 2523 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0090D5 90 09 AD         [24] 2524 	mov	dptr,#_ak820_macro_primitive
      0090D8 B3               [12] 2525 	cpl	c
      0090D9 E4               [12] 2526 	clr	a
      0090DA 33               [12] 2527 	rlc	a
      0090DB F0               [24] 2528 	movx	@dptr,a
                                   2529 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      0090DC 12 92 93         [24] 2530 	lcall	_ak820_outline_0088
      0090DF BF 01 10         [24] 2531 	cjne	r7,#0x01,00122$
      0090E2 12 92 BE         [24] 2532 	lcall	_ak820_outline_0150
      0090E5 C0 06            [24] 2533 	push	ar6
      0090E7 C0 05            [24] 2534 	push	ar5
      0090E9 12 7A 81         [24] 2535 	lcall	_tap_code
      0090EC D0 05            [24] 2536 	pop	ar5
      0090EE D0 06            [24] 2537 	pop	ar6
      0090F0 80 24            [24] 2538 	sjmp	00123$
      0090F2                       2539 00122$:
                                   2540 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      0090F2 12 92 93         [24] 2541 	lcall	_ak820_outline_0088
      0090F5 BF 02 10         [24] 2542 	cjne	r7,#0x02,00119$
      0090F8 12 92 BE         [24] 2543 	lcall	_ak820_outline_0150
      0090FB C0 06            [24] 2544 	push	ar6
      0090FD C0 05            [24] 2545 	push	ar5
      0090FF 12 79 50         [24] 2546 	lcall	_register_code
      009102 D0 05            [24] 2547 	pop	ar5
      009104 D0 06            [24] 2548 	pop	ar6
      009106 80 0E            [24] 2549 	sjmp	00123$
      009108                       2550 00119$:
                                   2551 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      009108 12 92 BE         [24] 2552 	lcall	_ak820_outline_0150
      00910B C0 06            [24] 2553 	push	ar6
      00910D C0 05            [24] 2554 	push	ar5
      00910F 12 79 D5         [24] 2555 	lcall	_unregister_code
      009112 D0 05            [24] 2556 	pop	ar5
      009114 D0 06            [24] 2557 	pop	ar6
      009116                       2558 00123$:
                                   2559 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      009116 12 92 C5         [24] 2560 	lcall	_ak820_outline_0162
      009119 01 3E            [12] 2561 	ajmp	00167$
      00911B                       2562 00152$:
                                   2563 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      00911B 12 92 93         [24] 2564 	lcall	_ak820_outline_0088
      00911E BF 05 02         [24] 2565 	cjne	r7,#0x05,00447$
      009121 80 12            [24] 2566 	sjmp	00146$
      009123                       2567 00447$:
      009123 12 92 93         [24] 2568 	lcall	_ak820_outline_0088
      009126 BF 06 02         [24] 2569 	cjne	r7,#0x06,00448$
      009129 80 0A            [24] 2570 	sjmp	00146$
      00912B                       2571 00448$:
      00912B 12 92 93         [24] 2572 	lcall	_ak820_outline_0088
      00912E BF 07 02         [24] 2573 	cjne	r7,#0x07,00449$
      009131 80 02            [24] 2574 	sjmp	00450$
      009133                       2575 00449$:
      009133 21 D8            [12] 2576 	ajmp	00147$
      009135                       2577 00450$:
      009135                       2578 00146$:
                                   2579 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009135 12 92 5B         [24] 2580 	lcall	_ak820_outline_0000
      009138 12 42 7F         [24] 2581 	lcall	_eeprom_read_byte
      00913B 12 92 DD         [24] 2582 	lcall	_ak820_outline_0177
                                   2583 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      00913E 70 02            [24] 2584 	jnz	00451$
      009140 01 3E            [12] 2585 	ajmp	00167$
      009142                       2586 00451$:
                                   2587 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009142 12 92 5B         [24] 2588 	lcall	_ak820_outline_0000
      009145 12 42 7F         [24] 2589 	lcall	_eeprom_read_byte
      009148 AF 82            [24] 2590 	mov	r7, dpl
      00914A 90 0B 6B         [24] 2591 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0003)
      00914D EF               [12] 2592 	mov	a,r7
      00914E F0               [24] 2593 	movx	@dptr,a
                                   2594 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      00914F EF               [12] 2595 	mov	a,r7
      009150 70 02            [24] 2596 	jnz	00452$
      009152 01 3E            [12] 2597 	ajmp	00167$
      009154                       2598 00452$:
                                   2599 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      009154 90 0B 6A         [24] 2600 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0002)
      009157 E0               [24] 2601 	movx	a,@dptr
      009158 FF               [12] 2602 	mov	r7,a
      009159 90 0B 6B         [24] 2603 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0003)
      00915C E0               [24] 2604 	movx	a,@dptr
      00915D FB               [12] 2605 	mov	r3,a
      00915E E4               [12] 2606 	clr	a
      00915F FC               [12] 2607 	mov	r4,a
      009160 FA               [12] 2608 	mov	r2,a
      009161 EF               [12] 2609 	mov	a,r7
      009162 42 04            [12] 2610 	orl	ar4,a
      009164 EA               [12] 2611 	mov	a,r2
      009165 42 03            [12] 2612 	orl	ar3,a
                                   2613 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      009167 12 45 9C         [24] 2614 	lcall	_ak820_outline_0180
      00916A C0 06            [24] 2615 	push	ar6
      00916C C0 05            [24] 2616 	push	ar5
      00916E 12 8F 8A         [24] 2617 	lcall	_decode_keycode
      009171 AC 82            [24] 2618 	mov	r4, dpl
      009173 AF 83            [24] 2619 	mov	r7, dph
      009175 D0 05            [24] 2620 	pop	ar5
      009177 D0 06            [24] 2621 	pop	ar6
                                   2622 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      009179 90 0B 69         [24] 2623 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      00917C E0               [24] 2624 	movx	a,@dptr
      00917D FB               [12] 2625 	mov	r3,a
      00917E BB 05 03         [24] 2626 	cjne	r3,#0x05,00453$
      009181 D3               [12] 2627 	setb	c
      009182 80 01            [24] 2628 	sjmp	00454$
      009184                       2629 00453$:
      009184 C3               [12] 2630 	clr	c
      009185                       2631 00454$:
      009185 92 25            [24] 2632 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      009187 90 09 AD         [24] 2633 	mov	dptr,#_ak820_macro_primitive
      00918A B3               [12] 2634 	cpl	c
      00918B E4               [12] 2635 	clr	a
      00918C 33               [12] 2636 	rlc	a
      00918D F0               [24] 2637 	movx	@dptr,a
                                   2638 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      00918E 90 0B 69         [24] 2639 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      009191 E0               [24] 2640 	movx	a,@dptr
      009192 FB               [12] 2641 	mov	r3,a
      009193 BB 05 02         [24] 2642 	cjne	r3,#0x05,00455$
      009196 80 0A            [24] 2643 	sjmp	00126$
      009198                       2644 00455$:
      009198 BB 06 02         [24] 2645 	cjne	r3,#0x06,00456$
      00919B 80 16            [24] 2646 	sjmp	00127$
      00919D                       2647 00456$:
                                   2648 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      00919D BB 07 33         [24] 2649 	cjne	r3,#0x07,00129$
      0091A0 80 22            [24] 2650 	sjmp	00128$
      0091A2                       2651 00126$:
                                   2652 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      0091A2 8C 82            [24] 2653 	mov	dpl, r4
      0091A4 8F 83            [24] 2654 	mov	dph, r7
      0091A6 C0 06            [24] 2655 	push	ar6
      0091A8 C0 05            [24] 2656 	push	ar5
      0091AA 12 B4 DD         [24] 2657 	lcall	_vial_keycode_tap
      0091AD D0 05            [24] 2658 	pop	ar5
      0091AF D0 06            [24] 2659 	pop	ar6
                                   2660 ;	quantum/dynamic_keymap.c:795: break;
                                   2661 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      0091B1 80 20            [24] 2662 	sjmp	00129$
      0091B3                       2663 00127$:
                                   2664 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      0091B3 8C 82            [24] 2665 	mov	dpl, r4
      0091B5 8F 83            [24] 2666 	mov	dph, r7
      0091B7 C0 06            [24] 2667 	push	ar6
      0091B9 C0 05            [24] 2668 	push	ar5
      0091BB 12 B4 12         [24] 2669 	lcall	_vial_keycode_down
      0091BE D0 05            [24] 2670 	pop	ar5
      0091C0 D0 06            [24] 2671 	pop	ar6
                                   2672 ;	quantum/dynamic_keymap.c:798: break;
                                   2673 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      0091C2 80 0F            [24] 2674 	sjmp	00129$
      0091C4                       2675 00128$:
                                   2676 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      0091C4 8C 82            [24] 2677 	mov	dpl, r4
      0091C6 8F 83            [24] 2678 	mov	dph, r7
      0091C8 C0 06            [24] 2679 	push	ar6
      0091CA C0 05            [24] 2680 	push	ar5
      0091CC 12 B4 78         [24] 2681 	lcall	_vial_keycode_up
      0091CF D0 05            [24] 2682 	pop	ar5
      0091D1 D0 06            [24] 2683 	pop	ar6
                                   2684 ;	quantum/dynamic_keymap.c:802: }
      0091D3                       2685 00129$:
                                   2686 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      0091D3 12 92 C5         [24] 2687 	lcall	_ak820_outline_0162
      0091D6 01 3E            [12] 2688 	ajmp	00167$
      0091D8                       2689 00147$:
                                   2690 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      0091D8 12 92 93         [24] 2691 	lcall	_ak820_outline_0088
      0091DB BF 04 02         [24] 2692 	cjne	r7,#0x04,00458$
      0091DE 80 02            [24] 2693 	sjmp	00459$
      0091E0                       2694 00458$:
      0091E0 01 3E            [12] 2695 	ajmp	00167$
      0091E2                       2696 00459$:
                                   2697 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0091E2 12 92 5B         [24] 2698 	lcall	_ak820_outline_0000
      0091E5 12 42 7F         [24] 2699 	lcall	_eeprom_read_byte
      0091E8 AF 82            [24] 2700 	mov	r7, dpl
                                   2701 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0091EA 90 0B 66         [24] 2702 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      0091ED 12 3A 9A         [24] 2703 	lcall	_ak820_outline_0120
      0091F0 90 0B 66         [24] 2704 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      0091F3 74 01            [12] 2705 	mov	a,#0x01
      0091F5 2B               [12] 2706 	add	a, r3
      0091F6 F0               [24] 2707 	movx	@dptr,a
      0091F7 E4               [12] 2708 	clr	a
      0091F8 3C               [12] 2709 	addc	a, r4
      0091F9 A3               [24] 2710 	inc	dptr
      0091FA F0               [24] 2711 	movx	@dptr,a
      0091FB 7A 00            [12] 2712 	mov	r2,#0x00
      0091FD 12 36 42         [24] 2713 	lcall	_ak820_outline_0122
      009200 8A F0            [24] 2714 	mov	b, r2
      009202 12 42 7F         [24] 2715 	lcall	_eeprom_read_byte
      009205 AC 82            [24] 2716 	mov	r4, dpl
                                   2717 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      009207 EF               [12] 2718 	mov	a,r7
      009208 60 49            [24] 2719 	jz	00169$
      00920A EC               [12] 2720 	mov	a,r4
      00920B 60 46            [24] 2721 	jz	00169$
                                   2722 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      00920D 1F               [12] 2723 	dec	r7
      00920E 1C               [12] 2724 	dec	r4
      00920F EC               [12] 2725 	mov	a,r4
      009210 75 F0 FF         [24] 2726 	mov	b,#0xff
      009213 A4               [48] 2727 	mul	ab
      009214 FC               [12] 2728 	mov	r4,a
      009215 AB F0            [24] 2729 	mov	r3,b
      009217 7A 00            [12] 2730 	mov	r2,#0x00
      009219 EC               [12] 2731 	mov	a,r4
      00921A 2F               [12] 2732 	add	a, r7
      00921B FC               [12] 2733 	mov	r4,a
      00921C EB               [12] 2734 	mov	a,r3
      00921D 3A               [12] 2735 	addc	a, r2
      00921E FB               [12] 2736 	mov	r3,a
                                   2737 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      00921F                       2738 00141$:
      00921F 8C 02            [24] 2739 	mov	ar2,r4
      009221 8B 07            [24] 2740 	mov	ar7,r3
      009223 1C               [12] 2741 	dec	r4
      009224 BC FF 01         [24] 2742 	cjne	r4,#0xff,00462$
      009227 1B               [12] 2743 	dec	r3
      009228                       2744 00462$:
      009228 EA               [12] 2745 	mov	a,r2
      009229 4F               [12] 2746 	orl	a,r7
      00922A 70 02            [24] 2747 	jnz	00463$
      00922C 01 3E            [12] 2748 	ajmp	00167$
      00922E                       2749 00463$:
      00922E 90 00 01         [24] 2750 	mov	dptr,#0x0001
      009231 12 5D 2B         [24] 2751 	lcall	_mDelaymS
      009234 80 E9            [24] 2752 	sjmp	00141$
      009236                       2753 00164$:
                                   2754 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      009236 90 0B 68         [24] 2755 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      009239 E0               [24] 2756 	movx	a,@dptr
      00923A FF               [12] 2757 	mov	r7,a
      00923B BF 80 00         [24] 2758 	cjne	r7,#0x80,00464$
      00923E                       2759 00464$:
      00923E 50 13            [24] 2760 	jnc	00169$
                                   2761 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      009240 90 0B 68         [24] 2762 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      009243 E0               [24] 2763 	movx	a,@dptr
      009244 F5 82            [12] 2764 	mov	dpl,a
      009246 C0 06            [24] 2765 	push	ar6
      009248 C0 05            [24] 2766 	push	ar5
      00924A 12 A7 B6         [24] 2767 	lcall	_send_char
      00924D D0 05            [24] 2768 	pop	ar5
      00924F D0 06            [24] 2769 	pop	ar6
                                   2770 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009251 01 3E            [12] 2771 	ajmp	00167$
      009253                       2772 00169$:
                                   2773 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      009253 12 92 C5         [24] 2774 	lcall	_ak820_outline_0162
                                   2775 ;	quantum/dynamic_keymap.c:837: sending = false;
      009256 90 0B 65         [24] 2776 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_460
      009259 F0               [24] 2777 	movx	@dptr,a
                                   2778 ;	quantum/dynamic_keymap.c:839: }
      00925A 22               [24] 2779 	ret
                                   2780 	.area CSEG    (CODE)
                                   2781 	.area CONST   (CODE)
                                   2782 	.area XINIT   (CODE)
                                   2783 	.area CABS    (ABS,CODE)
                                   2784 
                                   2785 ; Experimental exact instruction outlining.
                                   2786 	.globl _ak820_outline_0000
                                   2787 	.globl _ak820_outline_0004
                                   2788 	.globl _ak820_outline_0010
                                   2789 	.globl _ak820_outline_0011
                                   2790 	.globl _ak820_outline_0016
                                   2791 	.globl _ak820_outline_0024
                                   2792 	.globl _ak820_outline_0030
                                   2793 	.globl _ak820_outline_0043
                                   2794 	.globl _ak820_outline_0050
                                   2795 	.globl _ak820_outline_0056
                                   2796 	.globl _ak820_outline_0058
                                   2797 	.globl _ak820_outline_0059
                                   2798 	.globl _ak820_outline_0060
                                   2799 	.globl _ak820_outline_0070
                                   2800 	.globl _ak820_outline_0075
                                   2801 	.globl _ak820_outline_0077
                                   2802 	.globl _ak820_outline_0086
                                   2803 	.globl _ak820_outline_0088
                                   2804 	.globl _ak820_outline_0094
                                   2805 	.globl _ak820_outline_0095
                                   2806 	.globl _ak820_outline_0099
                                   2807 	.globl _ak820_outline_0103
                                   2808 	.globl _ak820_outline_0104
                                   2809 	.globl _ak820_outline_0112
                                   2810 	.globl _ak820_outline_0116
                                   2811 	.globl _ak820_outline_0117
                                   2812 	.globl _ak820_outline_0119
                                   2813 	.globl _ak820_outline_0120
                                   2814 	.globl _ak820_outline_0121
                                   2815 	.globl _ak820_outline_0122
                                   2816 	.globl _ak820_outline_0123
                                   2817 	.globl _ak820_outline_0127
                                   2818 	.globl _ak820_outline_0131
                                   2819 	.globl _ak820_outline_0132
                                   2820 	.globl _ak820_outline_0133
                                   2821 	.globl _ak820_outline_0134
                                   2822 	.globl _ak820_outline_0141
                                   2823 	.globl _ak820_outline_0142
                                   2824 	.globl _ak820_outline_0148
                                   2825 	.globl _ak820_outline_0150
                                   2826 	.globl _ak820_outline_0154
                                   2827 	.globl _ak820_outline_0155
                                   2828 	.globl _ak820_outline_0157
                                   2829 	.globl _ak820_outline_0162
                                   2830 	.globl _ak820_outline_0173
                                   2831 	.globl _ak820_outline_0174
                                   2832 	.globl _ak820_outline_0177
                                   2833 	.globl _ak820_outline_0178
                                   2834 	.globl _ak820_outline_0179
                                   2835 	.globl _ak820_outline_0180
                                   2836 	.globl _ak820_outline_0184
                                   2837 
                                   2838 	.area CSEG (CODE)
                                   2839 ; function ak820_outline_0000
      00925B                       2840 _ak820_outline_0000:
      00925B 90 0B 66         [24] 2841 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      00925E E0               [24] 2842 	movx	a,@dptr
      00925F FC               [12] 2843 	mov	r4,a
      009260 A3               [24] 2844 	inc	dptr
      009261 E0               [24] 2845 	movx	a,@dptr
      009262 FF               [12] 2846 	mov	r7,a
      009263 90 0B 66         [24] 2847 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      009266 74 01            [12] 2848 	mov	a,#0x01
      009268 2C               [12] 2849 	add	a,r4
      009269 F0               [24] 2850 	movx	@dptr,a
      00926A E4               [12] 2851 	clr	a
      00926B 3F               [12] 2852 	addc	a,r7
      00926C A3               [24] 2853 	inc	dptr
      00926D F0               [24] 2854 	movx	@dptr,a
      00926E 7B 00            [12] 2855 	mov	r3,#0x00
      009270 8C 82            [24] 2856 	mov	dpl,r4
      009272 8F 83            [24] 2857 	mov	dph,r7
      009274 8B F0            [24] 2858 	mov	b,r3
      009276 22               [24] 2859 	ret
                                   2860 
                                   2861 	.area CSEG (CODE)
                                   2862 ; function ak820_outline_0024
      009277                       2863 _ak820_outline_0024:
      009277 2D               [12] 2864 	add	a,r5
      009278 F9               [12] 2865 	mov	r1,a
      009279 E4               [12] 2866 	clr	a
      00927A 3E               [12] 2867 	addc	a,r6
      00927B FA               [12] 2868 	mov	r2,a
      00927C 8F 03            [24] 2869 	mov	ar3,r7
      00927E 89 82            [24] 2870 	mov	dpl,r1
      009280 8A 83            [24] 2871 	mov	dph,r2
      009282 8B F0            [24] 2872 	mov	b,r3
      009284 22               [24] 2873 	ret
                                   2874 
                                   2875 	.area CSEG (CODE)
                                   2876 ; function ak820_outline_0077
      009285                       2877 _ak820_outline_0077:
      009285 ED               [12] 2878 	mov	a,r5
      009286 75 F0 0A         [24] 2879 	mov	b,#0x0a
      009289 A4               [48] 2880 	mul	ab
      00928A 24 58            [12] 2881 	add	a,#0x58
      00928C FC               [12] 2882 	mov	r4,a
      00928D 74 06            [12] 2883 	mov	a,#0x06
      00928F 35 F0            [12] 2884 	addc	a,b
      009291 FD               [12] 2885 	mov	r5,a
      009292 22               [24] 2886 	ret
                                   2887 
                                   2888 	.area CSEG (CODE)
                                   2889 ; function ak820_outline_0088
      009293                       2890 _ak820_outline_0088:
      009293 90 0B 69         [24] 2891 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472+0x0001)
      009296 E0               [24] 2892 	movx	a,@dptr
      009297 FF               [12] 2893 	mov	r7,a
      009298 22               [24] 2894 	ret
                                   2895 
                                   2896 	.area CSEG (CODE)
                                   2897 ; function ak820_outline_0094
      009299                       2898 _ak820_outline_0094:
      009299 90 0A FF         [24] 2899 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00929C EE               [12] 2900 	mov	a,r6
      00929D F0               [24] 2901 	movx	@dptr,a
      00929E 90 0B 00         [24] 2902 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0092A1 ED               [12] 2903 	mov	a,r5
      0092A2 F0               [24] 2904 	movx	@dptr,a
      0092A3 8F 82            [24] 2905 	mov	dpl,r7
      0092A5 22               [24] 2906 	ret
                                   2907 
                                   2908 	.area CSEG (CODE)
                                   2909 ; function ak820_outline_0112
      0092A6                       2910 _ak820_outline_0112:
      0092A6 AD 82            [24] 2911 	mov	r5,dpl
      0092A8 AE 83            [24] 2912 	mov	r6,dph
      0092AA AF F0            [24] 2913 	mov	r7,b
      0092AC 22               [24] 2914 	ret
                                   2915 
                                   2916 	.area CSEG (CODE)
                                   2917 ; function ak820_outline_0127
      0092AD                       2918 _ak820_outline_0127:
      0092AD 28               [12] 2919 	add	a,r0
      0092AE F5 82            [12] 2920 	mov	dpl,a
      0092B0 EF               [12] 2921 	mov	a,r7
      0092B1 39               [12] 2922 	addc	a,r1
      0092B2 F5 83            [12] 2923 	mov	dph,a
      0092B4 74 FF            [12] 2924 	mov	a,#0xff
      0092B6 F0               [24] 2925 	movx	@dptr,a
      0092B7 22               [24] 2926 	ret
                                   2927 
                                   2928 	.area CSEG (CODE)
                                   2929 ; function ak820_outline_0133
      0092B8                       2930 _ak820_outline_0133:
      0092B8 2D               [12] 2931 	add	a,r5
      0092B9 F9               [12] 2932 	mov	r1,a
      0092BA E4               [12] 2933 	clr	a
      0092BB 3E               [12] 2934 	addc	a,r6
      0092BC FA               [12] 2935 	mov	r2,a
      0092BD 22               [24] 2936 	ret
                                   2937 
                                   2938 	.area CSEG (CODE)
                                   2939 ; function ak820_outline_0150
      0092BE                       2940 _ak820_outline_0150:
      0092BE 90 0B 6A         [24] 2941 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472+0x0002)
      0092C1 E0               [24] 2942 	movx	a,@dptr
      0092C2 F5 82            [12] 2943 	mov	dpl,a
      0092C4 22               [24] 2944 	ret
                                   2945 
                                   2946 	.area CSEG (CODE)
                                   2947 ; function ak820_outline_0162
      0092C5                       2948 _ak820_outline_0162:
      0092C5 90 09 AD         [24] 2949 	mov	dptr,#_ak820_macro_primitive
      0092C8 E4               [12] 2950 	clr	a
      0092C9 F0               [24] 2951 	movx	@dptr,a
      0092CA 22               [24] 2952 	ret
                                   2953 
                                   2954 	.area CSEG (CODE)
                                   2955 ; function ak820_outline_0173
      0092CB                       2956 _ak820_outline_0173:
      0092CB 90 0B 0F         [24] 2957 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0092CE E4               [12] 2958 	clr	a
      0092CF F0               [24] 2959 	movx	@dptr,a
      0092D0 90 0B 10         [24] 2960 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0092D3 22               [24] 2961 	ret
                                   2962 
                                   2963 	.area CSEG (CODE)
                                   2964 ; function ak820_outline_0174
      0092D4                       2965 _ak820_outline_0174:
      0092D4 90 0B C5         [24] 2966 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0092D7 E4               [12] 2967 	clr	a
      0092D8 F0               [24] 2968 	movx	@dptr,a
      0092D9 90 0B C6         [24] 2969 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0092DC 22               [24] 2970 	ret
                                   2971 
                                   2972 	.area CSEG (CODE)
                                   2973 ; function ak820_outline_0177
      0092DD                       2974 _ak820_outline_0177:
      0092DD AF 82            [24] 2975 	mov	r7,dpl
      0092DF 90 0B 6A         [24] 2976 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472+0x0002)
      0092E2 EF               [12] 2977 	mov	a,r7
      0092E3 F0               [24] 2978 	movx	@dptr,a
      0092E4 EF               [12] 2979 	mov	a,r7
      0092E5 22               [24] 2980 	ret
