                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_descriptor
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _SerialNumberString
                                     12 	.globl _ProductString
                                     13 	.globl _ManufacturerString
                                     14 	.globl _LanguageString
                                     15 	.globl _ConfigurationDescriptor
                                     16 	.globl _DeviceDescriptor
                                     17 	.globl _RawReport_size
                                     18 	.globl _RawReport
                                     19 	.globl _SharedReport_size
                                     20 	.globl _SharedReport
                                     21 	.globl _KeyboardReport_size
                                     22 	.globl _KeyboardReport
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 ;--------------------------------------------------------
                                    267 ; special function registers
                                    268 ;--------------------------------------------------------
                                    269 	.area RSEG    (ABS,DATA)
      000000                        270 	.org 0x0000
                           0000D0   271 _PSW	=	0x00d0
                           0000E0   272 _ACC	=	0x00e0
                           0000F0   273 _B	=	0x00f0
                           0000FD   274 _A_INV	=	0x00fd
                           000081   275 _SP	=	0x0081
                           000082   276 _DPL	=	0x0082
                           000083   277 _DPH	=	0x0083
                           0000A1   278 _SAFE_MOD	=	0x00a1
                           0000B1   279 _GLOBAL_CFG	=	0x00b1
                           000087   280 _PCON	=	0x0087
                           0000BA   281 _POWER_CFG	=	0x00ba
                           0000B9   282 _CLOCK_CFG	=	0x00b9
                           0000A9   283 _WAKE_CTRL	=	0x00a9
                           0000FE   284 _RESET_KEEP	=	0x00fe
                           0000FF   285 _WDOG_COUNT	=	0x00ff
                           0000A8   286 _IE	=	0x00a8
                           0000B8   287 _IP	=	0x00b8
                           0000E8   288 _IE_EX	=	0x00e8
                           0000E9   289 _IP_EX	=	0x00e9
                           0000B2   290 _GPIO_IE	=	0x00b2
                           008584   291 _ROM_ADDR	=	0x8584
                           000084   292 _ROM_ADDR_L	=	0x0084
                           000085   293 _ROM_ADDR_H	=	0x0085
                           008F8E   294 _ROM_DATA_HI	=	0x8f8e
                           00008E   295 _ROM_DATA_HL	=	0x008e
                           00008F   296 _ROM_DATA_HH	=	0x008f
                           000086   297 _ROM_CTRL	=	0x0086
                           000080   298 _P0	=	0x0080
                           0000C4   299 _P0_MOD_OC	=	0x00c4
                           0000C5   300 _P0_DIR_PU	=	0x00c5
                           000090   301 _P1	=	0x0090
                           000092   302 _P1_MOD_OC	=	0x0092
                           000093   303 _P1_DIR_PU	=	0x0093
                           0000A0   304 _P2	=	0x00a0
                           000094   305 _P2_MOD_OC	=	0x0094
                           000095   306 _P2_DIR_PU	=	0x0095
                           0000B0   307 _P3	=	0x00b0
                           000096   308 _P3_MOD_OC	=	0x0096
                           000097   309 _P3_DIR_PU	=	0x0097
                           0000C0   310 _P4	=	0x00c0
                           0000C2   311 _P4_MOD_OC	=	0x00c2
                           0000C3   312 _P4_DIR_PU	=	0x00c3
                           0000C1   313 _P4_LED_KEY	=	0x00c1
                           0000AA   314 _P5_IN	=	0x00aa
                           0000AB   315 _P5_OUT_PU	=	0x00ab
                           0000AC   316 _P5_DIR	=	0x00ac
                           0000AD   317 _P6_IN	=	0x00ad
                           0000AE   318 _P6_OUT_PU	=	0x00ae
                           0000AF   319 _P6_DIR	=	0x00af
                           0000F1   320 _P7	=	0x00f1
                           0000A2   321 _XBUS_AUX	=	0x00a2
                           000088   322 _TCON	=	0x0088
                           000089   323 _TMOD	=	0x0089
                           00008A   324 _TL0	=	0x008a
                           00008B   325 _TL1	=	0x008b
                           00008C   326 _TH0	=	0x008c
                           00008D   327 _TH1	=	0x008d
                           000098   328 _SCON	=	0x0098
                           000099   329 _SBUF	=	0x0099
                           0000C8   330 _T2CON	=	0x00c8
                           0000C9   331 _T2MOD	=	0x00c9
                           00CBCA   332 _RCAP2	=	0xcbca
                           0000CA   333 _RCAP2L	=	0x00ca
                           0000CB   334 _RCAP2H	=	0x00cb
                           00CDCC   335 _T2COUNT	=	0xcdcc
                           0000CC   336 _TL2	=	0x00cc
                           0000CD   337 _TH2	=	0x00cd
                           00CFCE   338 _T2CAP1	=	0xcfce
                           0000CE   339 _T2CAP1L	=	0x00ce
                           0000CF   340 _T2CAP1H	=	0x00cf
                           0000F8   341 _SPI0_STAT	=	0x00f8
                           0000F9   342 _SPI0_DATA	=	0x00f9
                           0000FA   343 _SPI0_CTRL	=	0x00fa
                           0000FB   344 _SPI0_CK_SE	=	0x00fb
                           0000FC   345 _SPI0_SETUP	=	0x00fc
                           0000BC   346 _SCON1	=	0x00bc
                           0000BD   347 _SBUF1	=	0x00bd
                           0000BE   348 _SBAUD1	=	0x00be
                           0000BF   349 _SIF1	=	0x00bf
                           0000B4   350 _SPI1_STAT	=	0x00b4
                           0000B5   351 _SPI1_DATA	=	0x00b5
                           0000B6   352 _SPI1_CTRL	=	0x00b6
                           0000B7   353 _SPI1_CK_SE	=	0x00b7
                           0000F3   354 _ADC_CTRL	=	0x00f3
                           00F5F4   355 _ADC_DAT	=	0xf5f4
                           0000F4   356 _ADC_DAT_L	=	0x00f4
                           0000F5   357 _ADC_DAT_H	=	0x00f5
                           0000F6   358 _ADC_CHAN	=	0x00f6
                           0000A6   359 _LED_COMMON	=	0x00a6
                           0000A7   360 _LED_PWM_OE	=	0x00a7
                           00C7C6   361 _LED_DMA	=	0xc7c6
                           0000C6   362 _LED_DMA_L	=	0x00c6
                           0000C7   363 _LED_DMA_H	=	0x00c7
                           0000F7   364 _LED_STATUS	=	0x00f7
                           0000B3   365 _I2CX_INT	=	0x00b3
                           0000BB   366 _I2CS_INT_ST	=	0x00bb
                                    367 ;--------------------------------------------------------
                                    368 ; special function bits
                                    369 ;--------------------------------------------------------
                                    370 	.area RSEG    (ABS,DATA)
      000000                        371 	.org 0x0000
                           0000D7   372 _CY	=	0x00d7
                           0000D6   373 _AC	=	0x00d6
                           0000D5   374 _F0	=	0x00d5
                           0000D4   375 _RS1	=	0x00d4
                           0000D3   376 _RS0	=	0x00d3
                           0000D2   377 _OV	=	0x00d2
                           0000D1   378 _F1	=	0x00d1
                           0000D0   379 _P	=	0x00d0
                           0000AF   380 _EA	=	0x00af
                           0000AE   381 _E_DIS	=	0x00ae
                           0000AD   382 _ET2	=	0x00ad
                           0000AC   383 _ES	=	0x00ac
                           0000AB   384 _ET1	=	0x00ab
                           0000AA   385 _EX1	=	0x00aa
                           0000A9   386 _ET0	=	0x00a9
                           0000A8   387 _EX0	=	0x00a8
                           0000BF   388 _PH_FLAG	=	0x00bf
                           0000BE   389 _PL_FLAG	=	0x00be
                           0000BD   390 _PT2	=	0x00bd
                           0000BC   391 _PS	=	0x00bc
                           0000BB   392 _PT1	=	0x00bb
                           0000BA   393 _PX1	=	0x00ba
                           0000B9   394 _PT0	=	0x00b9
                           0000B8   395 _PX0	=	0x00b8
                           0000EF   396 _IE_WDOG	=	0x00ef
                           0000EE   397 _IE_GPIO	=	0x00ee
                           0000ED   398 _IE_PWM_I2C	=	0x00ed
                           0000EC   399 _IE_UART1	=	0x00ec
                           0000EB   400 _IE_ADC	=	0x00eb
                           0000E9   401 _IE_USB	=	0x00e9
                           0000E8   402 _IE_SPI0	=	0x00e8
                           000087   403 _P0_7	=	0x0087
                           000086   404 _P0_6	=	0x0086
                           000085   405 _P0_5	=	0x0085
                           000084   406 _P0_4	=	0x0084
                           000083   407 _P0_3	=	0x0083
                           000082   408 _P0_2	=	0x0082
                           000081   409 _P0_1	=	0x0081
                           000080   410 _P0_0	=	0x0080
                           000081   411 _SDA0	=	0x0081
                           000080   412 _SCL0	=	0x0080
                           000083   413 _TXD_	=	0x0083
                           000082   414 _RXD_	=	0x0082
                           000085   415 _AIN13	=	0x0085
                           000084   416 _AIN12	=	0x0084
                           000083   417 _AIN11	=	0x0083
                           000082   418 _AIN10	=	0x0082
                           000081   419 _AIN9	=	0x0081
                           000080   420 _AIN8	=	0x0080
                           000097   421 _P1_7	=	0x0097
                           000096   422 _P1_6	=	0x0096
                           000095   423 _P1_5	=	0x0095
                           000094   424 _P1_4	=	0x0094
                           000093   425 _P1_3	=	0x0093
                           000092   426 _P1_2	=	0x0092
                           000091   427 _P1_1	=	0x0091
                           000090   428 _P1_0	=	0x0090
                           000097   429 _TXD1_	=	0x0097
                           000096   430 _RXD1_	=	0x0096
                           000097   431 _SCK	=	0x0097
                           000096   432 _MISO	=	0x0096
                           000095   433 _MOSI	=	0x0095
                           000094   434 _SCS	=	0x0094
                           000092   435 _INT0_	=	0x0092
                           000091   436 _T2EX	=	0x0091
                           000091   437 _CAP2	=	0x0091
                           000090   438 _T2	=	0x0090
                           000090   439 _CAP1	=	0x0090
                           000097   440 _AIN7	=	0x0097
                           000096   441 _AIN6	=	0x0096
                           000095   442 _AIN5	=	0x0095
                           000094   443 _AIN4	=	0x0094
                           000093   444 _AIN3	=	0x0093
                           000092   445 _AIN2	=	0x0092
                           000091   446 _AIN1	=	0x0091
                           000090   447 _AIN0	=	0x0090
                           0000A7   448 _P2_7	=	0x00a7
                           0000A6   449 _P2_6	=	0x00a6
                           0000A5   450 _P2_5	=	0x00a5
                           0000A4   451 _P2_4	=	0x00a4
                           0000A3   452 _P2_3	=	0x00a3
                           0000A2   453 _P2_2	=	0x00a2
                           0000A1   454 _P2_1	=	0x00a1
                           0000A0   455 _P2_0	=	0x00a0
                           0000A7   456 _TXD1	=	0x00a7
                           0000A6   457 _RXD1	=	0x00a6
                           0000A5   458 _T2EX_	=	0x00a5
                           0000A5   459 _CAP2_	=	0x00a5
                           0000A4   460 _T2_	=	0x00a4
                           0000A4   461 _CAP1_	=	0x00a4
                           0000B7   462 _P3_7	=	0x00b7
                           0000B6   463 _P3_6	=	0x00b6
                           0000B5   464 _P3_5	=	0x00b5
                           0000B4   465 _P3_4	=	0x00b4
                           0000B3   466 _P3_3	=	0x00b3
                           0000B2   467 _P3_2	=	0x00b2
                           0000B1   468 _P3_1	=	0x00b1
                           0000B0   469 _P3_0	=	0x00b0
                           0000B7   470 _SCK1	=	0x00b7
                           0000B6   471 _MISO1	=	0x00b6
                           0000B5   472 _MOSI1	=	0x00b5
                           0000B5   473 _T1	=	0x00b5
                           0000B4   474 _T0	=	0x00b4
                           0000B3   475 _INT1	=	0x00b3
                           0000B2   476 _INT0	=	0x00b2
                           0000B1   477 _TXD	=	0x00b1
                           0000B0   478 _RXD	=	0x00b0
                           0000C6   479 _P4_6	=	0x00c6
                           0000C5   480 _P4_5	=	0x00c5
                           0000C4   481 _P4_4	=	0x00c4
                           0000C3   482 _P4_3	=	0x00c3
                           0000C2   483 _P4_2	=	0x00c2
                           0000C1   484 _P4_1	=	0x00c1
                           0000C0   485 _P4_0	=	0x00c0
                           00008F   486 _TF1	=	0x008f
                           00008E   487 _TR1	=	0x008e
                           00008D   488 _TF0	=	0x008d
                           00008C   489 _TR0	=	0x008c
                           00008B   490 _IE1	=	0x008b
                           00008A   491 _IT1	=	0x008a
                           000089   492 _IE0	=	0x0089
                           000088   493 _IT0	=	0x0088
                           00009F   494 _SM0	=	0x009f
                           00009E   495 _SM1	=	0x009e
                           00009D   496 _SM2	=	0x009d
                           00009C   497 _REN	=	0x009c
                           00009B   498 _TB8	=	0x009b
                           00009A   499 _RB8	=	0x009a
                           000099   500 _TI	=	0x0099
                           000098   501 _RI	=	0x0098
                           0000CF   502 _TF2	=	0x00cf
                           0000CF   503 _CAP1F	=	0x00cf
                           0000CE   504 _EXF2	=	0x00ce
                           0000CD   505 _RCLK	=	0x00cd
                           0000CC   506 _TCLK	=	0x00cc
                           0000CB   507 _EXEN2	=	0x00cb
                           0000CA   508 _TR2	=	0x00ca
                           0000C9   509 _C_T2	=	0x00c9
                           0000C8   510 _CP_RL2	=	0x00c8
                           0000FF   511 _S0_FST_ACT	=	0x00ff
                           0000FE   512 _S0_IF_OV	=	0x00fe
                           0000FD   513 _S0_IF_FIRST	=	0x00fd
                           0000FC   514 _S0_IF_BYTE	=	0x00fc
                           0000FB   515 _S0_FREE	=	0x00fb
                           0000FA   516 _S0_T_FIFO	=	0x00fa
                           0000F8   517 _S0_R_FIFO	=	0x00f8
                           0000F7   518 _ADC_START	=	0x00f7
                                    519 ;--------------------------------------------------------
                                    520 ; overlayable register banks
                                    521 ;--------------------------------------------------------
                                    522 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        523 	.ds 8
                                    524 ;--------------------------------------------------------
                                    525 ; internal ram data
                                    526 ;--------------------------------------------------------
                                    527 	.area DSEG    (DATA)
                                    528 ;--------------------------------------------------------
                                    529 ; overlayable items in internal ram
                                    530 ;--------------------------------------------------------
                                    531 ;--------------------------------------------------------
                                    532 ; indirectly addressable internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area ISEG    (DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; absolute internal ram data
                                    537 ;--------------------------------------------------------
                                    538 	.area IABS    (ABS,DATA)
                                    539 	.area IABS    (ABS,DATA)
                                    540 ;--------------------------------------------------------
                                    541 ; bit data
                                    542 ;--------------------------------------------------------
                                    543 	.area BSEG    (BIT)
                                    544 ;--------------------------------------------------------
                                    545 ; paged external ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area PSEG    (PAG,XDATA)
                                    548 ;--------------------------------------------------------
                                    549 ; uninitialized external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area XSEG    (XDATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute external ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area XABS    (ABS,XDATA)
                                    556 ;--------------------------------------------------------
                                    557 ; initialized external ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area XISEG   (XDATA)
                                    560 	.area HOME    (CODE)
                                    561 	.area GSINIT0 (CODE)
                                    562 	.area GSINIT1 (CODE)
                                    563 	.area GSINIT2 (CODE)
                                    564 	.area GSINIT3 (CODE)
                                    565 	.area GSINIT4 (CODE)
                                    566 	.area GSINIT5 (CODE)
                                    567 	.area GSINIT  (CODE)
                                    568 	.area GSFINAL (CODE)
                                    569 	.area CSEG    (CODE)
                                    570 ;--------------------------------------------------------
                                    571 ; global & static initialisations
                                    572 ;--------------------------------------------------------
                                    573 	.area HOME    (CODE)
                                    574 	.area GSINIT  (CODE)
                                    575 	.area GSFINAL (CODE)
                                    576 	.area GSINIT  (CODE)
                                    577 ;--------------------------------------------------------
                                    578 ; Home
                                    579 ;--------------------------------------------------------
                                    580 	.area HOME    (CODE)
                                    581 	.area HOME    (CODE)
                                    582 ;--------------------------------------------------------
                                    583 ; code
                                    584 ;--------------------------------------------------------
                                    585 	.area CSEG    (CODE)
                                    586 ;------------------------------------------------------------
                                    587 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    588 ;------------------------------------------------------------
                                    589 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_49'
                                    590 ;------------------------------------------------------------
                                    591 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    592 ;	-----------------------------------------
                           000007   593 	ar7 = 0x07
                           000006   594 	ar6 = 0x06
                           000005   595 	ar5 = 0x05
                           000004   596 	ar4 = 0x04
                           000003   597 	ar3 = 0x03
                           000002   598 	ar2 = 0x02
                           000001   599 	ar1 = 0x01
                           000000   600 	ar0 = 0x00
                                    601 	.area CSEG    (CODE)
                                    602 	.area CONST   (CODE)
                                    603 	.area CONST   (CODE)
      00C1F1                        604 __str_0:
      00C1F1 41 00                  605 	.byte 65,0
      00C1F3 00 00                  606 	.byte 0,0
                                    607 	.area CSEG    (CODE)
                                    608 	.area CONST   (CODE)
      00C1F5                        609 _KeyboardReport:
      00C1F5 05                     610 	.db #0x05	; 5
      00C1F6 01                     611 	.db #0x01	; 1
      00C1F7 09                     612 	.db #0x09	; 9
      00C1F8 06                     613 	.db #0x06	; 6
      00C1F9 A1                     614 	.db #0xa1	; 161
      00C1FA 01                     615 	.db #0x01	; 1
      00C1FB 05                     616 	.db #0x05	; 5
      00C1FC 07                     617 	.db #0x07	; 7
      00C1FD 19                     618 	.db #0x19	; 25
      00C1FE E0                     619 	.db #0xe0	; 224
      00C1FF 29                     620 	.db #0x29	; 41
      00C200 E7                     621 	.db #0xe7	; 231
      00C201 15                     622 	.db #0x15	; 21
      00C202 00                     623 	.db #0x00	; 0
      00C203 25                     624 	.db #0x25	; 37
      00C204 01                     625 	.db #0x01	; 1
      00C205 95                     626 	.db #0x95	; 149
      00C206 08                     627 	.db #0x08	; 8
      00C207 75                     628 	.db #0x75	; 117	'u'
      00C208 01                     629 	.db #0x01	; 1
      00C209 81                     630 	.db #0x81	; 129
      00C20A 02                     631 	.db #0x02	; 2
      00C20B 95                     632 	.db #0x95	; 149
      00C20C 01                     633 	.db #0x01	; 1
      00C20D 75                     634 	.db #0x75	; 117	'u'
      00C20E 08                     635 	.db #0x08	; 8
      00C20F 81                     636 	.db #0x81	; 129
      00C210 01                     637 	.db #0x01	; 1
      00C211 05                     638 	.db #0x05	; 5
      00C212 07                     639 	.db #0x07	; 7
      00C213 19                     640 	.db #0x19	; 25
      00C214 00                     641 	.db #0x00	; 0
      00C215 29                     642 	.db #0x29	; 41
      00C216 FF                     643 	.db #0xff	; 255
      00C217 15                     644 	.db #0x15	; 21
      00C218 00                     645 	.db #0x00	; 0
      00C219 26                     646 	.db #0x26	; 38
      00C21A FF                     647 	.db #0xff	; 255
      00C21B 00                     648 	.db #0x00	; 0
      00C21C 95                     649 	.db #0x95	; 149
      00C21D 06                     650 	.db #0x06	; 6
      00C21E 75                     651 	.db #0x75	; 117	'u'
      00C21F 08                     652 	.db #0x08	; 8
      00C220 81                     653 	.db #0x81	; 129
      00C221 00                     654 	.db #0x00	; 0
      00C222 05                     655 	.db #0x05	; 5
      00C223 08                     656 	.db #0x08	; 8
      00C224 19                     657 	.db #0x19	; 25
      00C225 01                     658 	.db #0x01	; 1
      00C226 29                     659 	.db #0x29	; 41
      00C227 05                     660 	.db #0x05	; 5
      00C228 15                     661 	.db #0x15	; 21
      00C229 00                     662 	.db #0x00	; 0
      00C22A 25                     663 	.db #0x25	; 37
      00C22B 01                     664 	.db #0x01	; 1
      00C22C 95                     665 	.db #0x95	; 149
      00C22D 05                     666 	.db #0x05	; 5
      00C22E 75                     667 	.db #0x75	; 117	'u'
      00C22F 01                     668 	.db #0x01	; 1
      00C230 91                     669 	.db #0x91	; 145
      00C231 02                     670 	.db #0x02	; 2
      00C232 95                     671 	.db #0x95	; 149
      00C233 01                     672 	.db #0x01	; 1
      00C234 75                     673 	.db #0x75	; 117	'u'
      00C235 03                     674 	.db #0x03	; 3
      00C236 91                     675 	.db #0x91	; 145
      00C237 01                     676 	.db #0x01	; 1
      00C238 C0                     677 	.db #0xc0	; 192
                                    678 	.area CSEG    (CODE)
                                    679 	.area CONST   (CODE)
      00C239                        680 _KeyboardReport_size:
      00C239 44                     681 	.db #0x44	; 68	'D'
                                    682 	.area CSEG    (CODE)
                                    683 	.area CONST   (CODE)
      00C23A                        684 _SharedReport:
      00C23A 05                     685 	.db #0x05	; 5
      00C23B 01                     686 	.db #0x01	; 1
      00C23C 09                     687 	.db #0x09	; 9
      00C23D 02                     688 	.db #0x02	; 2
      00C23E A1                     689 	.db #0xa1	; 161
      00C23F 01                     690 	.db #0x01	; 1
      00C240 85                     691 	.db #0x85	; 133
      00C241 02                     692 	.db #0x02	; 2
      00C242 09                     693 	.db #0x09	; 9
      00C243 01                     694 	.db #0x01	; 1
      00C244 A1                     695 	.db #0xa1	; 161
      00C245 00                     696 	.db #0x00	; 0
      00C246 05                     697 	.db #0x05	; 5
      00C247 09                     698 	.db #0x09	; 9
      00C248 19                     699 	.db #0x19	; 25
      00C249 01                     700 	.db #0x01	; 1
      00C24A 29                     701 	.db #0x29	; 41
      00C24B 08                     702 	.db #0x08	; 8
      00C24C 15                     703 	.db #0x15	; 21
      00C24D 00                     704 	.db #0x00	; 0
      00C24E 25                     705 	.db #0x25	; 37
      00C24F 01                     706 	.db #0x01	; 1
      00C250 95                     707 	.db #0x95	; 149
      00C251 08                     708 	.db #0x08	; 8
      00C252 75                     709 	.db #0x75	; 117	'u'
      00C253 01                     710 	.db #0x01	; 1
      00C254 81                     711 	.db #0x81	; 129
      00C255 02                     712 	.db #0x02	; 2
      00C256 05                     713 	.db #0x05	; 5
      00C257 01                     714 	.db #0x01	; 1
      00C258 09                     715 	.db #0x09	; 9
      00C259 30                     716 	.db #0x30	; 48	'0'
      00C25A 09                     717 	.db #0x09	; 9
      00C25B 31                     718 	.db #0x31	; 49	'1'
      00C25C 15                     719 	.db #0x15	; 21
      00C25D 81                     720 	.db #0x81	; 129
      00C25E 25                     721 	.db #0x25	; 37
      00C25F 7F                     722 	.db #0x7f	; 127
      00C260 95                     723 	.db #0x95	; 149
      00C261 02                     724 	.db #0x02	; 2
      00C262 75                     725 	.db #0x75	; 117	'u'
      00C263 08                     726 	.db #0x08	; 8
      00C264 81                     727 	.db #0x81	; 129
      00C265 06                     728 	.db #0x06	; 6
      00C266 09                     729 	.db #0x09	; 9
      00C267 38                     730 	.db #0x38	; 56	'8'
      00C268 15                     731 	.db #0x15	; 21
      00C269 81                     732 	.db #0x81	; 129
      00C26A 25                     733 	.db #0x25	; 37
      00C26B 7F                     734 	.db #0x7f	; 127
      00C26C 95                     735 	.db #0x95	; 149
      00C26D 01                     736 	.db #0x01	; 1
      00C26E 75                     737 	.db #0x75	; 117	'u'
      00C26F 08                     738 	.db #0x08	; 8
      00C270 81                     739 	.db #0x81	; 129
      00C271 06                     740 	.db #0x06	; 6
      00C272 05                     741 	.db #0x05	; 5
      00C273 0C                     742 	.db #0x0c	; 12
      00C274 0A                     743 	.db #0x0a	; 10
      00C275 38                     744 	.db #0x38	; 56	'8'
      00C276 02                     745 	.db #0x02	; 2
      00C277 15                     746 	.db #0x15	; 21
      00C278 81                     747 	.db #0x81	; 129
      00C279 25                     748 	.db #0x25	; 37
      00C27A 7F                     749 	.db #0x7f	; 127
      00C27B 95                     750 	.db #0x95	; 149
      00C27C 01                     751 	.db #0x01	; 1
      00C27D 75                     752 	.db #0x75	; 117	'u'
      00C27E 08                     753 	.db #0x08	; 8
      00C27F 81                     754 	.db #0x81	; 129
      00C280 06                     755 	.db #0x06	; 6
      00C281 C0                     756 	.db #0xc0	; 192
      00C282 C0                     757 	.db #0xc0	; 192
      00C283 05                     758 	.db #0x05	; 5
      00C284 01                     759 	.db #0x01	; 1
      00C285 09                     760 	.db #0x09	; 9
      00C286 80                     761 	.db #0x80	; 128
      00C287 A1                     762 	.db #0xa1	; 161
      00C288 01                     763 	.db #0x01	; 1
      00C289 85                     764 	.db #0x85	; 133
      00C28A 03                     765 	.db #0x03	; 3
      00C28B 19                     766 	.db #0x19	; 25
      00C28C 01                     767 	.db #0x01	; 1
      00C28D 2A                     768 	.db #0x2a	; 42
      00C28E B7                     769 	.db #0xb7	; 183
      00C28F 00                     770 	.db #0x00	; 0
      00C290 15                     771 	.db #0x15	; 21
      00C291 01                     772 	.db #0x01	; 1
      00C292 26                     773 	.db #0x26	; 38
      00C293 B7                     774 	.db #0xb7	; 183
      00C294 00                     775 	.db #0x00	; 0
      00C295 95                     776 	.db #0x95	; 149
      00C296 01                     777 	.db #0x01	; 1
      00C297 75                     778 	.db #0x75	; 117	'u'
      00C298 10                     779 	.db #0x10	; 16
      00C299 81                     780 	.db #0x81	; 129
      00C29A 00                     781 	.db #0x00	; 0
      00C29B C0                     782 	.db #0xc0	; 192
      00C29C 05                     783 	.db #0x05	; 5
      00C29D 0C                     784 	.db #0x0c	; 12
      00C29E 09                     785 	.db #0x09	; 9
      00C29F 01                     786 	.db #0x01	; 1
      00C2A0 A1                     787 	.db #0xa1	; 161
      00C2A1 01                     788 	.db #0x01	; 1
      00C2A2 85                     789 	.db #0x85	; 133
      00C2A3 04                     790 	.db #0x04	; 4
      00C2A4 19                     791 	.db #0x19	; 25
      00C2A5 01                     792 	.db #0x01	; 1
      00C2A6 2A                     793 	.db #0x2a	; 42
      00C2A7 A0                     794 	.db #0xa0	; 160
      00C2A8 02                     795 	.db #0x02	; 2
      00C2A9 15                     796 	.db #0x15	; 21
      00C2AA 01                     797 	.db #0x01	; 1
      00C2AB 26                     798 	.db #0x26	; 38
      00C2AC A0                     799 	.db #0xa0	; 160
      00C2AD 02                     800 	.db #0x02	; 2
      00C2AE 95                     801 	.db #0x95	; 149
      00C2AF 01                     802 	.db #0x01	; 1
      00C2B0 75                     803 	.db #0x75	; 117	'u'
      00C2B1 10                     804 	.db #0x10	; 16
      00C2B2 81                     805 	.db #0x81	; 129
      00C2B3 00                     806 	.db #0x00	; 0
      00C2B4 C0                     807 	.db #0xc0	; 192
      00C2B5 05                     808 	.db #0x05	; 5
      00C2B6 01                     809 	.db #0x01	; 1
      00C2B7 09                     810 	.db #0x09	; 9
      00C2B8 06                     811 	.db #0x06	; 6
      00C2B9 A1                     812 	.db #0xa1	; 161
      00C2BA 01                     813 	.db #0x01	; 1
      00C2BB 85                     814 	.db #0x85	; 133
      00C2BC 06                     815 	.db #0x06	; 6
      00C2BD 05                     816 	.db #0x05	; 5
      00C2BE 07                     817 	.db #0x07	; 7
      00C2BF 19                     818 	.db #0x19	; 25
      00C2C0 E0                     819 	.db #0xe0	; 224
      00C2C1 29                     820 	.db #0x29	; 41
      00C2C2 E7                     821 	.db #0xe7	; 231
      00C2C3 15                     822 	.db #0x15	; 21
      00C2C4 00                     823 	.db #0x00	; 0
      00C2C5 25                     824 	.db #0x25	; 37
      00C2C6 01                     825 	.db #0x01	; 1
      00C2C7 95                     826 	.db #0x95	; 149
      00C2C8 08                     827 	.db #0x08	; 8
      00C2C9 75                     828 	.db #0x75	; 117	'u'
      00C2CA 01                     829 	.db #0x01	; 1
      00C2CB 81                     830 	.db #0x81	; 129
      00C2CC 02                     831 	.db #0x02	; 2
      00C2CD 05                     832 	.db #0x05	; 5
      00C2CE 07                     833 	.db #0x07	; 7
      00C2CF 19                     834 	.db #0x19	; 25
      00C2D0 00                     835 	.db #0x00	; 0
      00C2D1 29                     836 	.db #0x29	; 41
      00C2D2 EF                     837 	.db #0xef	; 239
      00C2D3 15                     838 	.db #0x15	; 21
      00C2D4 00                     839 	.db #0x00	; 0
      00C2D5 25                     840 	.db #0x25	; 37
      00C2D6 01                     841 	.db #0x01	; 1
      00C2D7 95                     842 	.db #0x95	; 149
      00C2D8 F0                     843 	.db #0xf0	; 240
      00C2D9 75                     844 	.db #0x75	; 117	'u'
      00C2DA 01                     845 	.db #0x01	; 1
      00C2DB 81                     846 	.db #0x81	; 129
      00C2DC 02                     847 	.db #0x02	; 2
      00C2DD 05                     848 	.db #0x05	; 5
      00C2DE 08                     849 	.db #0x08	; 8
      00C2DF 19                     850 	.db #0x19	; 25
      00C2E0 01                     851 	.db #0x01	; 1
      00C2E1 29                     852 	.db #0x29	; 41
      00C2E2 05                     853 	.db #0x05	; 5
      00C2E3 95                     854 	.db #0x95	; 149
      00C2E4 05                     855 	.db #0x05	; 5
      00C2E5 75                     856 	.db #0x75	; 117	'u'
      00C2E6 01                     857 	.db #0x01	; 1
      00C2E7 91                     858 	.db #0x91	; 145
      00C2E8 02                     859 	.db #0x02	; 2
      00C2E9 95                     860 	.db #0x95	; 149
      00C2EA 01                     861 	.db #0x01	; 1
      00C2EB 75                     862 	.db #0x75	; 117	'u'
      00C2EC 03                     863 	.db #0x03	; 3
      00C2ED 91                     864 	.db #0x91	; 145
      00C2EE 01                     865 	.db #0x01	; 1
      00C2EF C0                     866 	.db #0xc0	; 192
                                    867 	.area CSEG    (CODE)
                                    868 	.area CONST   (CODE)
      00C2F0                        869 _SharedReport_size:
      00C2F0 B6                     870 	.db #0xb6	; 182
                                    871 	.area CSEG    (CODE)
                                    872 	.area CONST   (CODE)
      00C2F1                        873 _RawReport:
      00C2F1 06                     874 	.db #0x06	; 6
      00C2F2 60                     875 	.db #0x60	; 96
      00C2F3 FF                     876 	.db #0xff	; 255
      00C2F4 09                     877 	.db #0x09	; 9
      00C2F5 61                     878 	.db #0x61	; 97	'a'
      00C2F6 A1                     879 	.db #0xa1	; 161
      00C2F7 01                     880 	.db #0x01	; 1
      00C2F8 09                     881 	.db #0x09	; 9
      00C2F9 62                     882 	.db #0x62	; 98	'b'
      00C2FA 15                     883 	.db #0x15	; 21
      00C2FB 00                     884 	.db #0x00	; 0
      00C2FC 26                     885 	.db #0x26	; 38
      00C2FD FF                     886 	.db #0xff	; 255
      00C2FE 00                     887 	.db #0x00	; 0
      00C2FF 95                     888 	.db #0x95	; 149
      00C300 20                     889 	.db #0x20	; 32
      00C301 75                     890 	.db #0x75	; 117	'u'
      00C302 08                     891 	.db #0x08	; 8
      00C303 81                     892 	.db #0x81	; 129
      00C304 02                     893 	.db #0x02	; 2
      00C305 09                     894 	.db #0x09	; 9
      00C306 63                     895 	.db #0x63	; 99	'c'
      00C307 15                     896 	.db #0x15	; 21
      00C308 00                     897 	.db #0x00	; 0
      00C309 26                     898 	.db #0x26	; 38
      00C30A FF                     899 	.db #0xff	; 255
      00C30B 00                     900 	.db #0x00	; 0
      00C30C 95                     901 	.db #0x95	; 149
      00C30D 20                     902 	.db #0x20	; 32
      00C30E 75                     903 	.db #0x75	; 117	'u'
      00C30F 08                     904 	.db #0x08	; 8
      00C310 91                     905 	.db #0x91	; 145
      00C311 02                     906 	.db #0x02	; 2
      00C312 09                     907 	.db #0x09	; 9
      00C313 64                     908 	.db #0x64	; 100	'd'
      00C314 95                     909 	.db #0x95	; 149
      00C315 08                     910 	.db #0x08	; 8
      00C316 B1                     911 	.db #0xb1	; 177
      00C317 02                     912 	.db #0x02	; 2
      00C318 C0                     913 	.db #0xc0	; 192
                                    914 	.area CSEG    (CODE)
                                    915 	.area CONST   (CODE)
      00C319                        916 _RawReport_size:
      00C319 28                     917 	.db #0x28	; 40
                                    918 	.area CSEG    (CODE)
                                    919 	.area CONST   (CODE)
      00C31A                        920 _DeviceDescriptor:
      00C31A 12                     921 	.db #0x12	; 18
      00C31B 01                     922 	.db #0x01	; 1
      00C31C 00 02                  923 	.byte #0x00, #0x02	; 512
      00C31E 00                     924 	.db #0x00	; 0
      00C31F 00                     925 	.db #0x00	; 0
      00C320 00                     926 	.db #0x00	; 0
      00C321 40                     927 	.db #0x40	; 64
      00C322 0F 32                  928 	.byte #0x0f, #0x32	; 12815
      00C324 5B 50                  929 	.byte #0x5b, #0x50	; 20571
      00C326 00 01                  930 	.byte #0x00, #0x01	; 256
      00C328 01                     931 	.db #0x01	; 1
      00C329 02                     932 	.db #0x02	; 2
      00C32A 03                     933 	.db #0x03	; 3
      00C32B 01                     934 	.db #0x01	; 1
                                    935 	.area CSEG    (CODE)
                                    936 	.area CONST   (CODE)
      00C32C                        937 _ConfigurationDescriptor:
      00C32C 09                     938 	.db #0x09	; 9
      00C32D 02                     939 	.db #0x02	; 2
      00C32E 54 00                  940 	.byte #0x54, #0x00	; 84
      00C330 03                     941 	.db #0x03	; 3
      00C331 01                     942 	.db #0x01	; 1
      00C332 00                     943 	.db #0x00	; 0
      00C333 A0                     944 	.db #0xa0	; 160
      00C334 FA                     945 	.db #0xfa	; 250
      00C335 09                     946 	.db #0x09	; 9
      00C336 04                     947 	.db #0x04	; 4
      00C337 00                     948 	.db #0x00	; 0
      00C338 00                     949 	.db #0x00	; 0
      00C339 01                     950 	.db #0x01	; 1
      00C33A 03                     951 	.db #0x03	; 3
      00C33B 01                     952 	.db #0x01	; 1
      00C33C 01                     953 	.db #0x01	; 1
      00C33D 00                     954 	.db #0x00	; 0
      00C33E 09                     955 	.db #0x09	; 9
      00C33F 21                     956 	.db #0x21	; 33
      00C340 11 01                  957 	.byte #0x11, #0x01	; 273
      00C342 00                     958 	.db #0x00	; 0
      00C343 01                     959 	.db #0x01	; 1
      00C344 22                     960 	.db #0x22	; 34
      00C345 44 00                  961 	.byte #0x44, #0x00	; 68
      00C347 07                     962 	.db #0x07	; 7
      00C348 05                     963 	.db #0x05	; 5
      00C349 81                     964 	.db #0x81	; 129
      00C34A 03                     965 	.db #0x03	; 3
      00C34B 08 00                  966 	.byte #0x08, #0x00	; 8
      00C34D 01                     967 	.db #0x01	; 1
      00C34E 09                     968 	.db #0x09	; 9
      00C34F 04                     969 	.db #0x04	; 4
      00C350 01                     970 	.db #0x01	; 1
      00C351 00                     971 	.db #0x00	; 0
      00C352 01                     972 	.db #0x01	; 1
      00C353 03                     973 	.db #0x03	; 3
      00C354 00                     974 	.db #0x00	; 0
      00C355 00                     975 	.db #0x00	; 0
      00C356 00                     976 	.db #0x00	; 0
      00C357 09                     977 	.db #0x09	; 9
      00C358 21                     978 	.db #0x21	; 33
      00C359 11 01                  979 	.byte #0x11, #0x01	; 273
      00C35B 00                     980 	.db #0x00	; 0
      00C35C 01                     981 	.db #0x01	; 1
      00C35D 22                     982 	.db #0x22	; 34
      00C35E 28 00                  983 	.byte #0x28, #0x00	; 40
      00C360 07                     984 	.db #0x07	; 7
      00C361 05                     985 	.db #0x05	; 5
      00C362 83                     986 	.db #0x83	; 131
      00C363 03                     987 	.db #0x03	; 3
      00C364 20 00                  988 	.byte #0x20, #0x00	; 32
      00C366 01                     989 	.db #0x01	; 1
      00C367 09                     990 	.db #0x09	; 9
      00C368 04                     991 	.db #0x04	; 4
      00C369 02                     992 	.db #0x02	; 2
      00C36A 00                     993 	.db #0x00	; 0
      00C36B 01                     994 	.db #0x01	; 1
      00C36C 03                     995 	.db #0x03	; 3
      00C36D 00                     996 	.db #0x00	; 0
      00C36E 00                     997 	.db #0x00	; 0
      00C36F 00                     998 	.db #0x00	; 0
      00C370 09                     999 	.db #0x09	; 9
      00C371 21                    1000 	.db #0x21	; 33
      00C372 11 01                 1001 	.byte #0x11, #0x01	; 273
      00C374 00                    1002 	.db #0x00	; 0
      00C375 01                    1003 	.db #0x01	; 1
      00C376 22                    1004 	.db #0x22	; 34
      00C377 B6 00                 1005 	.byte #0xb6, #0x00	; 182
      00C379 07                    1006 	.db #0x07	; 7
      00C37A 05                    1007 	.db #0x05	; 5
      00C37B 82                    1008 	.db #0x82	; 130
      00C37C 03                    1009 	.db #0x03	; 3
      00C37D 20 00                 1010 	.byte #0x20, #0x00	; 32
      00C37F 01                    1011 	.db #0x01	; 1
                                   1012 	.area CSEG    (CODE)
                                   1013 	.area CONST   (CODE)
      00C380                       1014 _LanguageString:
      00C380 04                    1015 	.db #0x04	; 4
      00C381 03                    1016 	.db #0x03	; 3
      00C382 09 04                 1017 	.byte #0x09, #0x04	; 1033
                                   1018 	.area CSEG    (CODE)
                                   1019 	.area CONST   (CODE)
      00C384                       1020 _ManufacturerString:
      00C384 0C                    1021 	.db #0x0c	; 12
      00C385 03                    1022 	.db #0x03	; 3
      00C386 41 00                 1023 	.byte 65,0
      00C388 4A 00                 1024 	.byte 74,0
      00C38A 41 00                 1025 	.byte 65,0
      00C38C 5A 00                 1026 	.byte 90,0
      00C38E 5A 00                 1027 	.byte 90,0
      00C390 00 00                 1028 	.byte 0,0
                                   1029 	.area CSEG    (CODE)
                                   1030 	.area CONST   (CODE)
      00C392                       1031 _ProductString:
      00C392 36                    1032 	.db #0x36	; 54	'6'
      00C393 03                    1033 	.db #0x03	; 3
      00C394 41 00                 1034 	.byte 65,0
      00C396 4B 00                 1035 	.byte 75,0
      00C398 38 00                 1036 	.byte 56,0
      00C39A 32 00                 1037 	.byte 50,0
      00C39C 30 00                 1038 	.byte 48,0
      00C39E 20 00                 1039 	.byte 32,0
      00C3A0 77 00                 1040 	.byte 119,0
      00C3A2 69 00                 1041 	.byte 105,0
      00C3A4 72 00                 1042 	.byte 114,0
      00C3A6 65 00                 1043 	.byte 101,0
      00C3A8 64 00                 1044 	.byte 100,0
      00C3AA 20 00                 1045 	.byte 32,0
      00C3AC 52 00                 1046 	.byte 82,0
      00C3AE 47 00                 1047 	.byte 71,0
      00C3B0 42 00                 1048 	.byte 66,0
      00C3B2 20 00                 1049 	.byte 32,0
      00C3B4 28 00                 1050 	.byte 40,0
      00C3B6 56 00                 1051 	.byte 86,0
      00C3B8 53 00                 1052 	.byte 83,0
      00C3BA 31 00                 1053 	.byte 49,0
      00C3BC 31 00                 1054 	.byte 49,0
      00C3BE 4B 00                 1055 	.byte 75,0
      00C3C0 32 00                 1056 	.byte 50,0
      00C3C2 38 00                 1057 	.byte 56,0
      00C3C4 41 00                 1058 	.byte 65,0
      00C3C6 29 00                 1059 	.byte 41,0
      00C3C8 00 00                 1060 	.byte 0,0
                                   1061 	.area CSEG    (CODE)
                                   1062 	.area CONST   (CODE)
      00C3CA                       1063 _SerialNumberString:
      00C3CA 1C                    1064 	.db #0x1c	; 28
      00C3CB 03                    1065 	.db #0x03	; 3
      00C3CC 76 00                 1066 	.byte 118,0
      00C3CE 69 00                 1067 	.byte 105,0
      00C3D0 61 00                 1068 	.byte 97,0
      00C3D2 6C 00                 1069 	.byte 108,0
      00C3D4 3A 00                 1070 	.byte 58,0
      00C3D6 66 00                 1071 	.byte 102,0
      00C3D8 36 00                 1072 	.byte 54,0
      00C3DA 34 00                 1073 	.byte 52,0
      00C3DC 63 00                 1074 	.byte 99,0
      00C3DE 32 00                 1075 	.byte 50,0
      00C3E0 62 00                 1076 	.byte 98,0
      00C3E2 33 00                 1077 	.byte 51,0
      00C3E4 63 00                 1078 	.byte 99,0
      00C3E6 00 00                 1079 	.byte 0,0
                                   1080 	.area CSEG    (CODE)
                                   1081 	.area XINIT   (CODE)
                                   1082 	.area CABS    (ABS,CODE)
