                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000008                         91 _page_valid:
      000008                         92 	.ds 1
      000009                         93 _page_dirty:
      000009                         94 	.ds 1
      00000A                         95 _storage_failed:
      00000A                         96 	.ds 1
      00000B                         97 _ak820_nvm_ok_sloc0_1_0:
      00000B                         98 	.ds 1
      00000C                         99 _load_page_sloc0_1_0:
      00000C                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000529                        109 _page_data:
      000529                        110 	.ds 64
      000569                        111 _cached_page:
      000569                        112 	.ds 1
      00056A                        113 _batch_depth:
      00056A                        114 	.ds 1
      00056B                        115 _first_failure_stage:
      00056B                        116 	.ds 1
      00056C                        117 _nvm_fail_stage_10000_20:
      00056C                        118 	.ds 1
      00056D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00056D                        120 	.ds 2
      00056F                        121 _crc_byte_PARM_2:
      00056F                        122 	.ds 1
      000570                        123 _crc_byte_crc_10000_25:
      000570                        124 	.ds 2
      000572                        125 _page_crc_crc_10000_30:
      000572                        126 	.ds 2
      000574                        127 _write_page_address_10000_32:
      000574                        128 	.ds 2
      000576                        129 _journal_header_valid_header_10000_39:
      000576                        130 	.ds 2
      000578                        131 _recover_journal_header_10000_46:
      000578                        132 	.ds 9
      000581                        133 _ak820_nvm_flush_header_10000_62:
      000581                        134 	.ds 9
      00058A                        135 _ak820_nvm_flush_stage_10000_62:
      00058A                        136 	.ds 1
      00058B                        137 _load_page_page_10000_87:
      00058B                        138 	.ds 1
      00058C                        139 _read_offset_offset_10000_93:
      00058C                        140 	.ds 2
      00058E                        141 _eeprom_read_byte_addr_10000_97:
      00058E                        142 	.ds 3
      000591                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000591                        144 	.ds 3
      000594                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000594                        146 	.ds 2
      000596                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000596                        148 	.ds 2
      000598                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000598                        150 	.ds 2
      00059A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00059A                        152 	.ds 3
      00059D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00059D                        154 	.ds 2
      00059F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00059F                        156 	.ds 2
      0005A1                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005A1                        158 	.ds 3
      0005A4                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005A4                        160 	.ds 2
      0005A6                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005A6                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003D8D                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003D8D E5 82            [12]  215 	mov	a,dpl
      003D8F 90 05 6C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003D92 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003D93 20 0A 08         [24]  219 	jb	_storage_failed,00102$
      003D96 90 05 6C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003D99 E0               [24]  221 	movx	a,@dptr
      003D9A 90 05 6B         [24]  222 	mov	dptr,#_first_failure_stage
      003D9D F0               [24]  223 	movx	@dptr,a
      003D9E                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003D9E D2 0A            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003DA0 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003DA1                        239 _ak820_nvm_diagnostic:
      003DA1 12 3A 83         [24]  240 	lcall	_ak820_outline_0103
      003DA4 90 05 6D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003DA7 12 3A 88         [24]  242 	lcall	_ak820_outline_0104
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003DAA 90 05 6D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003DAD 12 3A 40         [24]  245 	lcall	_ak820_outline_0050
      003DB0 A2 0A            [12]  246 	mov	c,_storage_failed
      003DB2 E4               [12]  247 	clr	a
      003DB3 33               [12]  248 	rlc	a
      003DB4 12 45 60         [24]  249 	lcall	_ak820_outline_0116
      003DB7 12 45 42         [24]  250 	lcall	_ak820_outline_0060
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003DBA A3               [24]  252 	inc	dptr
      003DBB A2 08            [12]  253 	mov	c,_page_valid
      003DBD E4               [12]  254 	clr	a
      003DBE 33               [12]  255 	rlc	a
      003DBF 12 45 16         [24]  256 	lcall	_ak820_outline_0029
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003DC2 A2 09            [12]  258 	mov	c,_page_dirty
      003DC4 E4               [12]  259 	clr	a
      003DC5 33               [12]  260 	rlc	a
      003DC6 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003DC7 74 03            [12]  263 	mov	a,#0x03
      003DC9 12 45 8B         [24]  264 	lcall	_ak820_outline_0158
      003DCC 90 05 6A         [24]  265 	mov	dptr,#_batch_depth
      003DCF E0               [24]  266 	movx	a,@dptr
      003DD0 12 3A A0         [24]  267 	lcall	_ak820_outline_0121
      003DD3 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003DD4 74 04            [12]  270 	mov	a,#0x04
      003DD6 12 45 8B         [24]  271 	lcall	_ak820_outline_0158
      003DD9 90 05 69         [24]  272 	mov	dptr,#_cached_page
      003DDC E0               [24]  273 	movx	a,@dptr
      003DDD 12 3A A0         [24]  274 	lcall	_ak820_outline_0121
      003DE0 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003DE1 12 45 0C         [24]  277 	lcall	_ak820_outline_0009
      003DE4 E4               [12]  278 	clr	a
      003DE5 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003DE6 74 06            [12]  281 	mov	a,#0x06
      003DE8 12 45 70         [24]  282 	lcall	_ak820_outline_0134
      003DEB 90 05 6B         [24]  283 	mov	dptr,#_first_failure_stage
      003DEE E0               [24]  284 	movx	a,@dptr
      003DEF 12 45 60         [24]  285 	lcall	_ak820_outline_0116
      003DF2 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003DF3 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003DF4                        300 _crc_byte:
      003DF4 12 3A 83         [24]  301 	lcall	_ak820_outline_0103
      003DF7 90 05 70         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003DFA 12 3A 88         [24]  303 	lcall	_ak820_outline_0104
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003DFD 90 05 6F         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003E00 E0               [24]  306 	movx	a,@dptr
      003E01 FF               [12]  307 	mov	r7,a
      003E02 7E 00            [12]  308 	mov	r6,#0x00
      003E04 90 05 70         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003E07 E0               [24]  310 	movx	a,@dptr
      003E08 6E               [12]  311 	xrl	a,r6
      003E09 F0               [24]  312 	movx	@dptr,a
      003E0A A3               [24]  313 	inc	dptr
      003E0B E0               [24]  314 	movx	a,@dptr
      003E0C 6F               [12]  315 	xrl	a,r7
      003E0D F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E0E 7F 00            [12]  318 	mov	r7,#0x00
      003E10                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003E10 90 05 70         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003E13 12 45 4E         [24]  322 	lcall	_ak820_outline_0096
      003E16 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003E19 ED               [12]  324 	mov	a,r5
      003E1A 2D               [12]  325 	add	a,r5
      003E1B FB               [12]  326 	mov	r3,a
      003E1C EE               [12]  327 	mov	a,r6
      003E1D 33               [12]  328 	rlc	a
      003E1E FC               [12]  329 	mov	r4,a
      003E1F 63 03 21         [24]  330 	xrl	ar3,#0x21
      003E22 63 04 10         [24]  331 	xrl	ar4,#0x10
      003E25 80 06            [24]  332 	sjmp	00107$
      003E27                        333 00106$:
      003E27 ED               [12]  334 	mov	a,r5
      003E28 2D               [12]  335 	add	a,r5
      003E29 FB               [12]  336 	mov	r3,a
      003E2A EE               [12]  337 	mov	a,r6
      003E2B 33               [12]  338 	rlc	a
      003E2C FC               [12]  339 	mov	r4,a
      003E2D                        340 00107$:
      003E2D 90 05 70         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003E30 12 3A 6B         [24]  342 	lcall	_ak820_outline_0075
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E33 0F               [12]  344 	inc	r7
      003E34 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003E37 12 36 42         [24]  347 	lcall	_ak820_outline_0122
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003E3A 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003E3B                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003E3B 90 05 72         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003E3E 74 FF            [12]  363 	mov	a,#0xff
      003E40 F0               [24]  364 	movx	@dptr,a
      003E41 A3               [24]  365 	inc	dptr
      003E42 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003E43 7F 00            [12]  368 	mov	r7,#0x00
      003E45                        369 00102$:
      003E45 90 05 72         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003E48 12 45 4E         [24]  371 	lcall	_ak820_outline_0096
      003E4B 12 45 54         [24]  372 	lcall	_ak820_outline_0101
      003E4E 90 05 6F         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003E51 F0               [24]  374 	movx	@dptr,a
      003E52 12 3A AA         [24]  375 	lcall	_ak820_outline_0131
      003E55 C0 07            [24]  376 	push	ar7
      003E57 12 3D F4         [24]  377 	lcall	_crc_byte
      003E5A AD 82            [24]  378 	mov	r5, dpl
      003E5C AE 83            [24]  379 	mov	r6, dph
      003E5E D0 07            [24]  380 	pop	ar7
      003E60 90 05 72         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003E63 12 45 91         [24]  382 	lcall	_ak820_outline_0159
      003E66 0F               [12]  383 	inc	r7
      003E67 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003E6A 12 3A AA         [24]  386 	lcall	_ak820_outline_0131
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003E6D 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003E6E                        399 _write_page:
      003E6E 12 3A 83         [24]  400 	lcall	_ak820_outline_0103
      003E71 90 05 74         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003E74 12 3A 88         [24]  402 	lcall	_ak820_outline_0104
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003E77 90 05 74         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003E7A 12 39 E0         [24]  405 	lcall	_ak820_outline_0004
      003E7D C0 07            [24]  406 	push	ar7
      003E7F C0 06            [24]  407 	push	ar6
      003E81 12 3C 06         [24]  408 	lcall	_ak820_flash_erase
      003E84 E5 82            [12]  409 	mov	a, dpl
      003E86 D0 06            [24]  410 	pop	ar6
      003E88 D0 07            [24]  411 	pop	ar7
      003E8A 70 03            [24]  412 	jnz	00102$
      003E8C F5 82            [12]  413 	mov	dpl,a
      003E8E 22               [24]  414 	ret
      003E8F                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003E8F 90 05 05         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003E92 74 29            [12]  418 	mov	a,#_page_data
      003E94 F0               [24]  419 	movx	@dptr,a
      003E95 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003E97 A3               [24]  421 	inc	dptr
      003E98 12 45 42         [24]  422 	lcall	_ak820_outline_0060
      003E9B 12 3D 1A         [24]  423 	lcall	_ak820_flash_program_page
      003E9E E5 82            [12]  424 	mov	a, dpl
      003EA0 70 03            [24]  425 	jnz	00120$
      003EA2 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EA4 22               [24]  428 	ret
      003EA5                        429 00120$:
      003EA5 7F 00            [12]  430 	mov	r7,#0x00
      003EA7                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003EA7 8F 05            [24]  433 	mov	ar5,r7
      003EA9 7E 00            [12]  434 	mov	r6,#0x00
      003EAB 90 05 74         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003EAE 12 3A 9A         [24]  436 	lcall	_ak820_outline_0120
      003EB1 ED               [12]  437 	mov	a,r5
      003EB2 2B               [12]  438 	add	a, r3
      003EB3 FB               [12]  439 	mov	r3,a
      003EB4 EE               [12]  440 	mov	a,r6
      003EB5 3C               [12]  441 	addc	a, r4
      003EB6 FC               [12]  442 	mov	r4,a
      003EB7 12 36 42         [24]  443 	lcall	_ak820_outline_0122
      003EBA 12 3A F9         [24]  444 	lcall	_ak820_flash_read
      003EBD AE 82            [24]  445 	mov	r6, dpl
      003EBF 12 45 54         [24]  446 	lcall	_ak820_outline_0101
      003EC2 FD               [12]  447 	mov	r5,a
      003EC3 EE               [12]  448 	mov	a,r6
      003EC4 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003EC7 80 04            [24]  450 	sjmp	00109$
      003EC9                        451 00149$:
      003EC9 75 82 00         [24]  452 	mov	dpl, #0x00
      003ECC 22               [24]  453 	ret
      003ECD                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003ECD 0F               [12]  456 	inc	r7
      003ECE BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003ED1 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003ED4 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003ED5                        472 _journal_header_valid:
      003ED5 12 3A 83         [24]  473 	lcall	_ak820_outline_0103
      003ED8 90 05 76         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003EDB 12 3A 88         [24]  475 	lcall	_ak820_outline_0104
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003EDE 90 05 76         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003EE1 12 39 E0         [24]  478 	lcall	_ak820_outline_0004
      003EE4 E0               [24]  479 	movx	a,@dptr
      003EE5 FD               [12]  480 	mov	r5,a
      003EE6 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003EE9 80 04            [24]  482 	sjmp	00116$
      003EEB                        483 00138$:
      003EEB 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003EEE 22               [24]  486 	ret
      003EEF                        487 00116$:
      003EEF 7D 01            [12]  488 	mov	r5,#0x01
      003EF1                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003EF1 ED               [12]  491 	mov	a,r5
      003EF2 12 3A 27         [24]  492 	lcall	_ak820_outline_0016
      003EF5 FC               [12]  493 	mov	r4,a
      003EF6 8D 02            [24]  494 	mov	ar2,r5
      003EF8 7B 00            [12]  495 	mov	r3,#0x00
      003EFA 74 04            [12]  496 	mov	a,#0x04
      003EFC 2A               [12]  497 	add	a, r2
      003EFD FA               [12]  498 	mov	r2,a
      003EFE E4               [12]  499 	clr	a
      003EFF 3B               [12]  500 	addc	a, r3
      003F00 FB               [12]  501 	mov	r3,a
      003F01 EA               [12]  502 	mov	a,r2
      003F02 2E               [12]  503 	add	a, r6
      003F03 F5 82            [12]  504 	mov	dpl,a
      003F05 EB               [12]  505 	mov	a,r3
      003F06 3F               [12]  506 	addc	a, r7
      003F07 F5 83            [12]  507 	mov	dph,a
      003F09 E0               [24]  508 	movx	a,@dptr
      003F0A 62 04            [12]  509 	xrl	ar4,a
      003F0C BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      003F0F 80 04            [24]  511 	sjmp	00107$
      003F11                        512 00139$:
      003F11 75 82 00         [24]  513 	mov	dpl, #0x00
      003F14 22               [24]  514 	ret
      003F15                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F15 0D               [12]  517 	inc	r5
      003F16 BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003F19 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003F1C 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      003F1D                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003F1D 7F 00            [12]  537 	mov	r7,#0x00
      003F1F                        538 00115$:
      003F1F EF               [12]  539 	mov	a,r7
      003F20 24 78            [12]  540 	add	a, #_recover_journal_header_10000_46
      003F22 FD               [12]  541 	mov	r5,a
      003F23 E4               [12]  542 	clr	a
      003F24 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003F26 FE               [12]  544 	mov	r6,a
      003F27 8F 04            [24]  545 	mov	ar4,r7
      003F29 7B 00            [12]  546 	mov	r3,#0x00
      003F2B 74 40            [12]  547 	mov	a,#0x40
      003F2D 2C               [12]  548 	add	a, r4
      003F2E FC               [12]  549 	mov	r4,a
      003F2F 74 EF            [12]  550 	mov	a,#0xef
      003F31 3B               [12]  551 	addc	a, r3
      003F32 FB               [12]  552 	mov	r3,a
      003F33 12 45 9C         [24]  553 	lcall	_ak820_outline_0180
      003F36 12 3A F9         [24]  554 	lcall	_ak820_flash_read
      003F39 AC 82            [24]  555 	mov	r4, dpl
      003F3B 12 3A AA         [24]  556 	lcall	_ak820_outline_0131
      003F3E EC               [12]  557 	mov	a,r4
      003F3F F0               [24]  558 	movx	@dptr,a
      003F40 0F               [12]  559 	inc	r7
      003F41 BF 09 DB         [24]  560 	cjne	r7,#0x09,00115$
                                    561 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003F44 90 05 78         [24]  562 	mov	dptr,#_recover_journal_header_10000_46
      003F47 12 3E D5         [24]  563 	lcall	_journal_header_valid
      003F4A E5 82            [12]  564 	mov	a, dpl
      003F4C 70 01            [24]  565 	jnz	00103$
      003F4E 22               [24]  566 	ret
      003F4F                        567 00103$:
                                    568 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003F4F 90 05 79         [24]  569 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003F52 E0               [24]  570 	movx	a,@dptr
      003F53 FF               [12]  571 	mov	r7,a
      003F54 7E 00            [12]  572 	mov	r6,#0x00
      003F56 90 05 7A         [24]  573 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003F59 E0               [24]  574 	movx	a,@dptr
      003F5A FC               [12]  575 	mov	r4,a
      003F5B E4               [12]  576 	clr	a
      003F5C 42 07            [12]  577 	orl	ar7,a
      003F5E EC               [12]  578 	mov	a,r4
      003F5F 42 06            [12]  579 	orl	ar6,a
                                    580 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003F61 90 05 7B         [24]  581 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003F64 E0               [24]  582 	movx	a,@dptr
      003F65 FD               [12]  583 	mov	r5,a
      003F66 7C 00            [12]  584 	mov	r4,#0x00
      003F68 90 05 7C         [24]  585 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003F6B E0               [24]  586 	movx	a,@dptr
      003F6C FA               [12]  587 	mov	r2,a
      003F6D E4               [12]  588 	clr	a
      003F6E 12 45 76         [24]  589 	lcall	_ak820_outline_0141
                                    590 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003F71 C3               [12]  591 	clr	c
      003F72 EF               [12]  592 	mov	a,r7
      003F73 94 A0            [12]  593 	subb	a,#0xa0
      003F75 EE               [12]  594 	mov	a,r6
      003F76 94 00            [12]  595 	subb	a,#0x00
      003F78 40 06            [24]  596 	jc	00134$
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003F7A 75 82 01         [24]  598 	mov	dpl, #0x01
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003F7D 02 3D 8D         [24]  600 	ljmp	_nvm_fail
                                    601 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003F80                        602 00134$:
      003F80 7B 00            [12]  603 	mov	r3,#0x00
      003F82                        604 00117$:
      003F82 C0 05            [24]  605 	push	ar5
      003F84 C0 04            [24]  606 	push	ar4
      003F86 EB               [12]  607 	mov	a,r3
      003F87 24 29            [12]  608 	add	a, #_page_data
      003F89 F9               [12]  609 	mov	r1,a
      003F8A E4               [12]  610 	clr	a
      003F8B 34 05            [12]  611 	addc	a, #(_page_data >> 8)
      003F8D FA               [12]  612 	mov	r2,a
      003F8E 8B 00            [24]  613 	mov	ar0,r3
      003F90 7D 00            [12]  614 	mov	r5,#0x00
      003F92 74 EF            [12]  615 	mov	a,#0xef
      003F94 2D               [12]  616 	add	a, r5
      003F95 FD               [12]  617 	mov	r5,a
      003F96 88 82            [24]  618 	mov	dpl, r0
      003F98 8D 83            [24]  619 	mov	dph, r5
      003F9A 12 3A F9         [24]  620 	lcall	_ak820_flash_read
      003F9D AD 82            [24]  621 	mov	r5, dpl
      003F9F 12 45 97         [24]  622 	lcall	_ak820_outline_0179
      003FA2 ED               [12]  623 	mov	a,r5
      003FA3 F0               [24]  624 	movx	@dptr,a
      003FA4 0B               [12]  625 	inc	r3
      003FA5 BB 40 02         [24]  626 	cjne	r3,#0x40,00190$
      003FA8 80 06            [24]  627 	sjmp	00191$
      003FAA                        628 00190$:
      003FAA D0 04            [24]  629 	pop	ar4
      003FAC D0 05            [24]  630 	pop	ar5
      003FAE 80 D2            [24]  631 	sjmp	00117$
      003FB0                        632 00191$:
      003FB0 D0 04            [24]  633 	pop	ar4
      003FB2 D0 05            [24]  634 	pop	ar5
                                    635 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003FB4 C0 07            [24]  636 	push	ar7
      003FB6 C0 06            [24]  637 	push	ar6
      003FB8 C0 05            [24]  638 	push	ar5
      003FBA C0 04            [24]  639 	push	ar4
      003FBC 12 3E 3B         [24]  640 	lcall	_page_crc
      003FBF AA 82            [24]  641 	mov	r2, dpl
      003FC1 AB 83            [24]  642 	mov	r3, dph
      003FC3 D0 04            [24]  643 	pop	ar4
      003FC5 D0 05            [24]  644 	pop	ar5
      003FC7 D0 06            [24]  645 	pop	ar6
      003FC9 D0 07            [24]  646 	pop	ar7
      003FCB EA               [12]  647 	mov	a,r2
      003FCC B5 05 06         [24]  648 	cjne	a,ar5,00192$
      003FCF EB               [12]  649 	mov	a,r3
      003FD0 B5 04 02         [24]  650 	cjne	a,ar4,00192$
      003FD3 80 06            [24]  651 	sjmp	00113$
      003FD5                        652 00192$:
      003FD5 75 82 02         [24]  653 	mov	dpl, #0x02
      003FD8 02 3D 8D         [24]  654 	ljmp	_nvm_fail
      003FDB                        655 00113$:
                                    656 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003FDB EE               [12]  657 	mov	a,r6
      003FDC 54 03            [12]  658 	anl	a,#0x03
      003FDE A2 E0            [12]  659 	mov	c,acc.0
      003FE0 CF               [12]  660 	xch	a,r7
      003FE1 13               [12]  661 	rrc	a
      003FE2 CF               [12]  662 	xch	a,r7
      003FE3 13               [12]  663 	rrc	a
      003FE4 A2 E0            [12]  664 	mov	c,acc.0
      003FE6 CF               [12]  665 	xch	a,r7
      003FE7 13               [12]  666 	rrc	a
      003FE8 CF               [12]  667 	xch	a,r7
      003FE9 13               [12]  668 	rrc	a
      003FEA CF               [12]  669 	xch	a,r7
      003FEB 24 C7            [12]  670 	add	a,#0xc7
      003FED FE               [12]  671 	mov	r6,a
      003FEE 12 45 86         [24]  672 	lcall	_ak820_outline_0156
      003FF1 12 3E 6E         [24]  673 	lcall	_write_page
      003FF4 E5 82            [12]  674 	mov	a, dpl
      003FF6 70 06            [24]  675 	jnz	00110$
      003FF8 75 82 03         [24]  676 	mov	dpl, #0x03
      003FFB 02 3D 8D         [24]  677 	ljmp	_nvm_fail
      003FFE                        678 00110$:
                                    679 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003FFE 90 EF 40         [24]  680 	mov	dptr,#0xef40
      004001 12 3C 06         [24]  681 	lcall	_ak820_flash_erase
      004004 E5 82            [12]  682 	mov	a, dpl
      004006 70 06            [24]  683 	jnz	00119$
      004008 75 82 04         [24]  684 	mov	dpl, #0x04
                                    685 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      00400B 02 3D 8D         [24]  686 	ljmp	_nvm_fail
      00400E                        687 00119$:
      00400E 22               [24]  688 	ret
                                    689 ;------------------------------------------------------------
                                    690 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    691 ;------------------------------------------------------------
                                    692 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    693 ;	-----------------------------------------
                                    694 ;	 function eeprom_driver_init
                                    695 ;	-----------------------------------------
      00400F                        696 _eeprom_driver_init:
                                    697 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    698 ;	assignBit
      00400F C2 0A            [12]  699 	clr	_storage_failed
                                    700 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      004011 90 05 6B         [24]  701 	mov	dptr,#_first_failure_stage
      004014 E4               [12]  702 	clr	a
      004015 F0               [24]  703 	movx	@dptr,a
                                    704 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    705 ;	assignBit
      004016 C2 09            [12]  706 	clr	_page_dirty
                                    707 ;	assignBit
      004018 C2 08            [12]  708 	clr	_page_valid
                                    709 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      00401A 90 05 6A         [24]  710 	mov	dptr,#_batch_depth
      00401D E4               [12]  711 	clr	a
      00401E F0               [24]  712 	movx	@dptr,a
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      00401F 12 3F 1D         [24]  714 	lcall	_recover_journal
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    716 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      004022 02 2A B7         [24]  717 	ljmp	_ak820_macro_init
                                    718 ;------------------------------------------------------------
                                    719 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    720 ;------------------------------------------------------------
                                    721 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    722 ;	-----------------------------------------
                                    723 ;	 function ak820_nvm_ok
                                    724 ;	-----------------------------------------
      004025                        725 _ak820_nvm_ok:
      004025 A2 0A            [12]  726 	mov	c,_storage_failed
      004027 B3               [12]  727 	cpl	c
      004028 92 0B            [24]  728 	mov  _ak820_nvm_ok_sloc0_1_0,c
      00402A 12 3A C6         [24]  729 	lcall	_ak820_outline_0166
      00402D 22               [24]  730 	ret
                                    731 ;------------------------------------------------------------
                                    732 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    733 ;------------------------------------------------------------
                                    734 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    735 ;	-----------------------------------------
                                    736 ;	 function ak820_nvm_schema_fault
                                    737 ;	-----------------------------------------
      00402E                        738 _ak820_nvm_schema_fault:
      00402E 75 82 10         [24]  739 	mov	dpl, #0x10
      004031 02 3D 8D         [24]  740 	ljmp	_nvm_fail
                                    741 ;------------------------------------------------------------
                                    742 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    743 ;------------------------------------------------------------
                                    744 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    745 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    746 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    747 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    748 ;------------------------------------------------------------
                                    749 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    750 ;	-----------------------------------------
                                    751 ;	 function ak820_nvm_flush
                                    752 ;	-----------------------------------------
      004034                        753 _ak820_nvm_flush:
                                    754 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      004034 30 09 03         [24]  755 	jnb	_page_dirty,00101$
      004037 30 0A 01         [24]  756 	jnb	_storage_failed,00102$
      00403A                        757 00101$:
      00403A 22               [24]  758 	ret
      00403B                        759 00102$:
                                    760 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      00403B 12 3E 3B         [24]  761 	lcall	_page_crc
      00403E 12 45 6B         [24]  762 	lcall	_ak820_outline_0132
                                    763 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      004041 90 05 81         [24]  764 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004044 74 A5            [12]  765 	mov	a,#0xa5
      004046 F0               [24]  766 	movx	@dptr,a
                                    767 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      004047 90 05 69         [24]  768 	mov	dptr,#_cached_page
      00404A E0               [24]  769 	movx	a,@dptr
      00404B 90 05 82         [24]  770 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      00404E F0               [24]  771 	movx	@dptr,a
                                    772 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      00404F 90 05 83         [24]  773 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      004052 E4               [12]  774 	clr	a
      004053 F0               [24]  775 	movx	@dptr,a
                                    776 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      004054 8E 05            [24]  777 	mov	ar5,r6
      004056 90 05 84         [24]  778 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      004059 ED               [12]  779 	mov	a,r5
      00405A F0               [24]  780 	movx	@dptr,a
                                    781 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      00405B 8F 06            [24]  782 	mov	ar6,r7
      00405D 90 05 85         [24]  783 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      004060 EE               [12]  784 	mov	a,r6
      004061 F0               [24]  785 	movx	@dptr,a
                                    786 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      004062 7F 01            [12]  787 	mov	r7,#0x01
      004064                        788 00128$:
      004064 8F 06            [24]  789 	mov	ar6,r7
      004066 EE               [12]  790 	mov	a,r6
      004067 24 04            [12]  791 	add	a,#0x04
      004069 FE               [12]  792 	mov	r6,a
      00406A 33               [12]  793 	rlc	a
      00406B 95 E0            [12]  794 	subb	a,acc
      00406D FD               [12]  795 	mov	r5,a
      00406E EE               [12]  796 	mov	a,r6
      00406F 24 81            [12]  797 	add	a, #_ak820_nvm_flush_header_10000_62
      004071 FE               [12]  798 	mov	r6,a
      004072 ED               [12]  799 	mov	a,r5
      004073 34 05            [12]  800 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      004075 FD               [12]  801 	mov	r5,a
      004076 12 45 25         [24]  802 	lcall	_ak820_outline_0039
      004079 FC               [12]  803 	mov	r4,a
      00407A 63 04 FF         [24]  804 	xrl	ar4,#0xff
      00407D 8E 82            [24]  805 	mov	dpl,r6
      00407F 8D 83            [24]  806 	mov	dph,r5
      004081 EC               [12]  807 	mov	a,r4
      004082 F0               [24]  808 	movx	@dptr,a
      004083 0F               [12]  809 	inc	r7
      004084 BF 05 DD         [24]  810 	cjne	r7,#0x05,00128$
                                    811 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      004087 90 05 8A         [24]  812 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00408A 74 05            [12]  813 	mov	a,#0x05
      00408C F0               [24]  814 	movx	@dptr,a
                                    815 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      00408D 90 EF 40         [24]  816 	mov	dptr,#0xef40
      004090 12 3C 06         [24]  817 	lcall	_ak820_flash_erase
      004093 E5 82            [12]  818 	mov	a, dpl
      004095 70 03            [24]  819 	jnz	00269$
      004097 02 41 7E         [24]  820 	ljmp	00127$
      00409A                        821 00269$:
                                    822 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      00409A 90 05 8A         [24]  823 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00409D 74 06            [12]  824 	mov	a,#0x06
      00409F F0               [24]  825 	movx	@dptr,a
                                    826 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0040A0 7F 00            [12]  827 	mov	r7,#0x00
      0040A2                        828 00130$:
                                    829 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      0040A2 12 45 31         [24]  830 	lcall	_ak820_outline_0051
      0040A5 12 3A F9         [24]  831 	lcall	_ak820_flash_read
      0040A8 E5 82            [12]  832 	mov	a, dpl
      0040AA 60 03            [24]  833 	jz	00270$
      0040AC 02 41 7E         [24]  834 	ljmp	00127$
      0040AF                        835 00270$:
                                    836 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0040AF 0F               [12]  837 	inc	r7
      0040B0 BF 40 EF         [24]  838 	cjne	r7,#0x40,00130$
                                    839 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      0040B3 90 05 8A         [24]  840 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040B6 74 07            [12]  841 	mov	a,#0x07
      0040B8 F0               [24]  842 	movx	@dptr,a
                                    843 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      0040B9 90 EF 00         [24]  844 	mov	dptr,#0xef00
      0040BC 12 3E 6E         [24]  845 	lcall	_write_page
      0040BF E5 82            [12]  846 	mov	a, dpl
      0040C1 70 03            [24]  847 	jnz	00273$
      0040C3 02 41 7E         [24]  848 	ljmp	00127$
      0040C6                        849 00273$:
                                    850 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      0040C6 90 05 8A         [24]  851 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040C9 74 08            [12]  852 	mov	a,#0x08
      0040CB F0               [24]  853 	movx	@dptr,a
                                    854 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0040CC 7F 01            [12]  855 	mov	r7,#0x01
      0040CE                        856 00132$:
                                    857 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      0040CE 12 45 25         [24]  858 	lcall	_ak820_outline_0039
      0040D1 FE               [12]  859 	mov	r6,a
      0040D2 60 23            [24]  860 	jz	00133$
      0040D4 8F 05            [24]  861 	mov	ar5,r7
      0040D6 7C 00            [12]  862 	mov	r4,#0x00
      0040D8 74 40            [12]  863 	mov	a,#0x40
      0040DA 2D               [12]  864 	add	a, r5
      0040DB FD               [12]  865 	mov	r5,a
      0040DC 74 EF            [12]  866 	mov	a,#0xef
      0040DE 3C               [12]  867 	addc	a, r4
      0040DF FC               [12]  868 	mov	r4,a
      0040E0 90 05 02         [24]  869 	mov	dptr,#_ak820_flash_program_PARM_2
      0040E3 EE               [12]  870 	mov	a,r6
      0040E4 F0               [24]  871 	movx	@dptr,a
      0040E5 8D 82            [24]  872 	mov	dpl, r5
      0040E7 8C 83            [24]  873 	mov	dph, r4
      0040E9 C0 07            [24]  874 	push	ar7
      0040EB 12 3C 66         [24]  875 	lcall	_ak820_flash_program
      0040EE E5 82            [12]  876 	mov	a, dpl
      0040F0 D0 07            [24]  877 	pop	ar7
      0040F2 70 03            [24]  878 	jnz	00275$
      0040F4 02 41 7E         [24]  879 	ljmp	00127$
      0040F7                        880 00275$:
      0040F7                        881 00133$:
                                    882 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0040F7 0F               [12]  883 	inc	r7
      0040F8 BF 09 D3         [24]  884 	cjne	r7,#0x09,00132$
                                    885 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      0040FB 90 05 8A         [24]  886 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040FE 74 09            [12]  887 	mov	a,#0x09
      004100 F0               [24]  888 	movx	@dptr,a
                                    889 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004101 7F 01            [12]  890 	mov	r7,#0x01
      004103                        891 00134$:
                                    892 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      004103 12 45 31         [24]  893 	lcall	_ak820_outline_0051
      004106 12 3A F9         [24]  894 	lcall	_ak820_flash_read
      004109 AE 82            [24]  895 	mov	r6, dpl
      00410B 12 45 25         [24]  896 	lcall	_ak820_outline_0039
      00410E FD               [12]  897 	mov	r5,a
      00410F EE               [12]  898 	mov	a,r6
      004110 B5 05 6B         [24]  899 	cjne	a,ar5,00127$
                                    900 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004113 0F               [12]  901 	inc	r7
      004114 BF 09 EC         [24]  902 	cjne	r7,#0x09,00134$
                                    903 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      004117 90 05 8A         [24]  904 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00411A 74 0A            [12]  905 	mov	a,#0x0a
      00411C F0               [24]  906 	movx	@dptr,a
                                    907 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      00411D 90 05 81         [24]  908 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004120 E0               [24]  909 	movx	a,@dptr
      004121 90 05 02         [24]  910 	mov	dptr,#_ak820_flash_program_PARM_2
      004124 F0               [24]  911 	movx	@dptr,a
      004125 90 EF 40         [24]  912 	mov	dptr,#0xef40
      004128 12 3C 66         [24]  913 	lcall	_ak820_flash_program
      00412B E5 82            [12]  914 	mov	a, dpl
      00412D 60 4F            [24]  915 	jz	00127$
                                    916 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      00412F 90 05 8A         [24]  917 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004132 74 0B            [12]  918 	mov	a,#0x0b
      004134 F0               [24]  919 	movx	@dptr,a
                                    920 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      004135 90 EF 40         [24]  921 	mov	dptr,#0xef40
      004138 12 3A F9         [24]  922 	lcall	_ak820_flash_read
      00413B AF 82            [24]  923 	mov	r7, dpl
      00413D 90 05 81         [24]  924 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004140 E0               [24]  925 	movx	a,@dptr
      004141 FE               [12]  926 	mov	r6,a
      004142 EF               [12]  927 	mov	a,r7
      004143 B5 06 38         [24]  928 	cjne	a,ar6,00127$
                                    929 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      004146 90 05 8A         [24]  930 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004149 74 0C            [12]  931 	mov	a,#0x0c
      00414B F0               [24]  932 	movx	@dptr,a
                                    933 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      00414C 90 05 69         [24]  934 	mov	dptr,#_cached_page
      00414F E0               [24]  935 	movx	a,@dptr
      004150 FE               [12]  936 	mov	r6,a
      004151 E4               [12]  937 	clr	a
      004152 C3               [12]  938 	clr	c
      004153 CE               [12]  939 	xch	a,r6
      004154 13               [12]  940 	rrc	a
      004155 CE               [12]  941 	xch	a,r6
      004156 13               [12]  942 	rrc	a
      004157 A2 E0            [12]  943 	mov	c,acc.0
      004159 CE               [12]  944 	xch	a,r6
      00415A 13               [12]  945 	rrc	a
      00415B CE               [12]  946 	xch	a,r6
      00415C 13               [12]  947 	rrc	a
      00415D CE               [12]  948 	xch	a,r6
      00415E 24 C7            [12]  949 	add	a,#0xc7
      004160 FF               [12]  950 	mov	r7,a
      004161 12 45 60         [24]  951 	lcall	_ak820_outline_0116
      004164 12 3E 6E         [24]  952 	lcall	_write_page
      004167 E5 82            [12]  953 	mov	a, dpl
      004169 60 13            [24]  954 	jz	00127$
                                    955 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      00416B 90 05 8A         [24]  956 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00416E 74 0D            [12]  957 	mov	a,#0x0d
      004170 F0               [24]  958 	movx	@dptr,a
                                    959 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      004171 90 EF 40         [24]  960 	mov	dptr,#0xef40
      004174 12 3C 06         [24]  961 	lcall	_ak820_flash_erase
      004177 E5 82            [12]  962 	mov	a, dpl
      004179 60 03            [24]  963 	jz	00127$
                                    964 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    965 ;	assignBit
      00417B C2 09            [12]  966 	clr	_page_dirty
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    968 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      00417D 22               [24]  969 	ret
      00417E                        970 00127$:
                                    971 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      00417E 90 05 8A         [24]  972 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004181 E0               [24]  973 	movx	a,@dptr
      004182 F5 82            [12]  974 	mov	dpl,a
                                    975 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      004184 02 3D 8D         [24]  976 	ljmp	_nvm_fail
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    979 ;------------------------------------------------------------
                                    980 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    981 ;	-----------------------------------------
                                    982 ;	 function ak820_nvm_begin
                                    983 ;	-----------------------------------------
      004187                        984 _ak820_nvm_begin:
                                    985 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      004187 90 05 6A         [24]  986 	mov	dptr,#_batch_depth
      00418A E0               [24]  987 	movx	a,@dptr
      00418B FF               [12]  988 	mov	r7,a
      00418C BF FF 06         [24]  989 	cjne	r7,#0xff,00102$
      00418F 75 82 0F         [24]  990 	mov	dpl, #0x0f
      004192 02 3D 8D         [24]  991 	ljmp	_nvm_fail
      004195                        992 00102$:
                                    993 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      004195 90 05 6A         [24]  994 	mov	dptr,#_batch_depth
      004198 EF               [12]  995 	mov	a,r7
      004199 04               [12]  996 	inc	a
      00419A F0               [24]  997 	movx	@dptr,a
                                    998 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      00419B 22               [24]  999 	ret
                                   1000 ;------------------------------------------------------------
                                   1001 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1002 ;------------------------------------------------------------
                                   1003 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1004 ;	-----------------------------------------
                                   1005 ;	 function ak820_nvm_end
                                   1006 ;	-----------------------------------------
      00419C                       1007 _ak820_nvm_end:
                                   1008 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      00419C 90 05 6A         [24] 1009 	mov	dptr,#_batch_depth
      00419F E0               [24] 1010 	movx	a,@dptr
      0041A0 FF               [12] 1011 	mov	r7,a
      0041A1 E0               [24] 1012 	movx	a,@dptr
      0041A2 60 06            [24] 1013 	jz	00102$
      0041A4 EF               [12] 1014 	mov	a,r7
      0041A5 14               [12] 1015 	dec	a
      0041A6 90 05 6A         [24] 1016 	mov	dptr,#_batch_depth
      0041A9 F0               [24] 1017 	movx	@dptr,a
      0041AA                       1018 00102$:
                                   1019 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      0041AA 90 05 6A         [24] 1020 	mov	dptr,#_batch_depth
      0041AD E0               [24] 1021 	movx	a,@dptr
      0041AE 70 03            [24] 1022 	jnz	00105$
                                   1023 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      0041B0 02 40 34         [24] 1024 	ljmp	_ak820_nvm_flush
      0041B3                       1025 00105$:
      0041B3 22               [24] 1026 	ret
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'load_page'
                                   1029 ;------------------------------------------------------------
                                   1030 ;page          Allocated with name '_load_page_page_10000_87'
                                   1031 ;i             Allocated with name '_load_page_i_10000_88'
                                   1032 ;------------------------------------------------------------
                                   1033 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1034 ;	-----------------------------------------
                                   1035 ;	 function load_page
                                   1036 ;	-----------------------------------------
      0041B4                       1037 _load_page:
      0041B4 E5 82            [12] 1038 	mov	a,dpl
      0041B6 90 05 8B         [24] 1039 	mov	dptr,#_load_page_page_10000_87
      0041B9 F0               [24] 1040 	movx	@dptr,a
                                   1041 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      0041BA 30 08 17         [24] 1042 	jnb	_page_valid,00102$
      0041BD 90 05 69         [24] 1043 	mov	dptr,#_cached_page
      0041C0 E0               [24] 1044 	movx	a,@dptr
      0041C1 FF               [12] 1045 	mov	r7,a
      0041C2 90 05 8B         [24] 1046 	mov	dptr,#_load_page_page_10000_87
      0041C5 E0               [24] 1047 	movx	a,@dptr
      0041C6 FE               [12] 1048 	mov	r6,a
      0041C7 EF               [12] 1049 	mov	a,r7
      0041C8 B5 06 09         [24] 1050 	cjne	a,ar6,00102$
      0041CB A2 0A            [12] 1051 	mov	c,_storage_failed
      0041CD B3               [12] 1052 	cpl	c
      0041CE 92 0C            [24] 1053 	mov  _load_page_sloc0_1_0,c
      0041D0 12 3A C6         [24] 1054 	lcall	_ak820_outline_0166
      0041D3 22               [24] 1055 	ret
      0041D4                       1056 00102$:
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      0041D4 12 40 34         [24] 1058 	lcall	_ak820_nvm_flush
                                   1059 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      0041D7 30 0A 04         [24] 1060 	jnb	_storage_failed,00119$
      0041DA 75 82 00         [24] 1061 	mov	dpl, #0x00
                                   1062 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0041DD 22               [24] 1063 	ret
      0041DE                       1064 00119$:
      0041DE 7F 00            [12] 1065 	mov	r7,#0x00
      0041E0                       1066 00107$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      0041E0 EF               [12] 1068 	mov	a,r7
      0041E1 24 29            [12] 1069 	add	a, #_page_data
      0041E3 FD               [12] 1070 	mov	r5,a
      0041E4 E4               [12] 1071 	clr	a
      0041E5 34 05            [12] 1072 	addc	a, #(_page_data >> 8)
      0041E7 FE               [12] 1073 	mov	r6,a
      0041E8 90 05 8B         [24] 1074 	mov	dptr,#_load_page_page_10000_87
      0041EB E0               [24] 1075 	movx	a,@dptr
      0041EC FC               [12] 1076 	mov	r4,a
      0041ED FA               [12] 1077 	mov	r2,a
      0041EE E4               [12] 1078 	clr	a
      0041EF C3               [12] 1079 	clr	c
      0041F0 CA               [12] 1080 	xch	a,r2
      0041F1 13               [12] 1081 	rrc	a
      0041F2 CA               [12] 1082 	xch	a,r2
      0041F3 13               [12] 1083 	rrc	a
      0041F4 A2 E0            [12] 1084 	mov	c,acc.0
      0041F6 CA               [12] 1085 	xch	a,r2
      0041F7 13               [12] 1086 	rrc	a
      0041F8 CA               [12] 1087 	xch	a,r2
      0041F9 13               [12] 1088 	rrc	a
      0041FA CA               [12] 1089 	xch	a,r2
      0041FB 24 C7            [12] 1090 	add	a,#0xc7
      0041FD FB               [12] 1091 	mov	r3,a
      0041FE 8F 01            [24] 1092 	mov	ar1,r7
      004200 89 00            [24] 1093 	mov	ar0,r1
      004202 79 00            [12] 1094 	mov	r1,#0x00
      004204 E8               [12] 1095 	mov	a,r0
      004205 2A               [12] 1096 	add	a, r2
      004206 FA               [12] 1097 	mov	r2,a
      004207 E9               [12] 1098 	mov	a,r1
      004208 3B               [12] 1099 	addc	a, r3
      004209 FB               [12] 1100 	mov	r3,a
      00420A 12 45 7C         [24] 1101 	lcall	_ak820_outline_0142
      00420D 12 3A F9         [24] 1102 	lcall	_ak820_flash_read
      004210 AB 82            [24] 1103 	mov	r3, dpl
      004212 12 3A AA         [24] 1104 	lcall	_ak820_outline_0131
      004215 EB               [12] 1105 	mov	a,r3
      004216 F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004217 0F               [12] 1108 	inc	r7
      004218 BF 40 C5         [24] 1109 	cjne	r7,#0x40,00107$
                                   1110 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00421B 90 05 69         [24] 1111 	mov	dptr,#_cached_page
      00421E EC               [12] 1112 	mov	a,r4
      00421F F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1115 ;	assignBit
      004220 D2 08            [12] 1116 	setb	_page_valid
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004222 75 82 01         [24] 1118 	mov	dpl, #0x01
                                   1119 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004225 22               [24] 1120 	ret
                                   1121 ;------------------------------------------------------------
                                   1122 ;Allocation info for local variables in function 'read_offset'
                                   1123 ;------------------------------------------------------------
                                   1124 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1125 ;------------------------------------------------------------
                                   1126 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1127 ;	-----------------------------------------
                                   1128 ;	 function read_offset
                                   1129 ;	-----------------------------------------
      004226                       1130 _read_offset:
      004226 12 3A 83         [24] 1131 	lcall	_ak820_outline_0103
      004229 90 05 8C         [24] 1132 	mov	dptr,#_read_offset_offset_10000_93
      00422C 12 3A 88         [24] 1133 	lcall	_ak820_outline_0104
                                   1134 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      00422F 90 05 8C         [24] 1135 	mov	dptr,#_read_offset_offset_10000_93
      004232 12 3A 40         [24] 1136 	lcall	_ak820_outline_0050
      004235 C3               [12] 1137 	clr	c
      004236 94 28            [12] 1138 	subb	a,#0x28
      004238 40 04            [24] 1139 	jc	00102$
      00423A 75 82 00         [24] 1140 	mov	dpl, #0x00
      00423D 22               [24] 1141 	ret
      00423E                       1142 00102$:
                                   1143 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      00423E 30 08 34         [24] 1144 	jnb	_page_valid,00104$
      004241 8E 04            [24] 1145 	mov	ar4,r6
      004243 EF               [12] 1146 	mov	a,r7
      004244 A2 E7            [12] 1147 	mov	c,acc.7
      004246 CC               [12] 1148 	xch	a,r4
      004247 33               [12] 1149 	rlc	a
      004248 CC               [12] 1150 	xch	a,r4
      004249 33               [12] 1151 	rlc	a
      00424A A2 E7            [12] 1152 	mov	c,acc.7
      00424C CC               [12] 1153 	xch	a,r4
      00424D 33               [12] 1154 	rlc	a
      00424E CC               [12] 1155 	xch	a,r4
      00424F 33               [12] 1156 	rlc	a
      004250 CC               [12] 1157 	xch	a,r4
      004251 54 03            [12] 1158 	anl	a,#0x03
      004253 FD               [12] 1159 	mov	r5,a
      004254 90 05 69         [24] 1160 	mov	dptr,#_cached_page
      004257 E0               [24] 1161 	movx	a,@dptr
      004258 FA               [12] 1162 	mov	r2,a
      004259 7B 00            [12] 1163 	mov	r3,#0x00
      00425B EC               [12] 1164 	mov	a,r4
      00425C B5 02 16         [24] 1165 	cjne	a,ar2,00104$
      00425F ED               [12] 1166 	mov	a,r5
      004260 B5 03 12         [24] 1167 	cjne	a,ar3,00104$
                                   1168 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004263 74 3F            [12] 1169 	mov	a,#0x3f
      004265 5E               [12] 1170 	anl	a,r6
      004266 7D 00            [12] 1171 	mov	r5,#0x00
      004268 24 29            [12] 1172 	add	a, #_page_data
      00426A F5 82            [12] 1173 	mov	dpl,a
      00426C ED               [12] 1174 	mov	a,r5
      00426D 34 05            [12] 1175 	addc	a, #(_page_data >> 8)
      00426F F5 83            [12] 1176 	mov	dph,a
      004271 E0               [24] 1177 	movx	a,@dptr
      004272 F5 82            [12] 1178 	mov	dpl,a
      004274 22               [24] 1179 	ret
      004275                       1180 00104$:
                                   1181 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004275 74 C7            [12] 1182 	mov	a,#0xc7
      004277 2F               [12] 1183 	add	a, r7
      004278 FF               [12] 1184 	mov	r7,a
      004279 12 45 60         [24] 1185 	lcall	_ak820_outline_0116
                                   1186 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      00427C 02 3A F9         [24] 1187 	ljmp	_ak820_flash_read
                                   1188 ;------------------------------------------------------------
                                   1189 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1190 ;------------------------------------------------------------
                                   1191 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1192 ;------------------------------------------------------------
                                   1193 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1194 ;	-----------------------------------------
                                   1195 ;	 function eeprom_read_byte
                                   1196 ;	-----------------------------------------
      00427F                       1197 _eeprom_read_byte:
      00427F C0 07            [24] 1198 	push	ar7
      004281 C0 06            [24] 1199 	push	ar6
      004283 12 45 1E         [24] 1200 	lcall	_ak820_outline_0036
      004286 90 05 8E         [24] 1201 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004289 12 3A 1F         [24] 1202 	lcall	_ak820_outline_0015
                                   1203 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00428C 90 05 8E         [24] 1204 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00428F 12 39 E0         [24] 1205 	lcall	_ak820_outline_0004
      004292 C0 06            [24] 1206 	push	ar6
      004294 C0 05            [24] 1207 	push	ar5
      004296 C0 04            [24] 1208 	push	ar4
      004298 C0 03            [24] 1209 	push	ar3
      00429A C0 02            [24] 1210 	push	ar2
      00429C C0 01            [24] 1211 	push	ar1
      00429E C0 00            [24] 1212 	push	ar0
      0042A0 12 42 26         [24] 1213 	lcall	_read_offset
      0042A3 AF 82            [24] 1214 	mov	r7, dpl
      0042A5 D0 00            [24] 1215 	pop	ar0
      0042A7 D0 01            [24] 1216 	pop	ar1
      0042A9 D0 02            [24] 1217 	pop	ar2
      0042AB D0 03            [24] 1218 	pop	ar3
      0042AD D0 04            [24] 1219 	pop	ar4
      0042AF D0 05            [24] 1220 	pop	ar5
      0042B1 D0 06            [24] 1221 	pop	ar6
      0042B3 8F 82            [24] 1222 	mov	dpl, r7
                                   1223 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0042B5 D0 06            [24] 1224 	pop	ar6
      0042B7 D0 07            [24] 1225 	pop	ar7
      0042B9 22               [24] 1226 	ret
                                   1227 ;------------------------------------------------------------
                                   1228 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1229 ;------------------------------------------------------------
                                   1230 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1231 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1232 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1233 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1234 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1235 ;------------------------------------------------------------
                                   1236 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1237 ;	-----------------------------------------
                                   1238 ;	 function ak820_eeprom_read_block_xdata
                                   1239 ;	-----------------------------------------
      0042BA                       1240 _ak820_eeprom_read_block_xdata:
      0042BA 12 3A 83         [24] 1241 	lcall	_ak820_outline_0103
      0042BD 90 05 96         [24] 1242 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0042C0 12 3A 88         [24] 1243 	lcall	_ak820_outline_0104
                                   1244 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0042C3 90 05 91         [24] 1245 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0042C6 12 3A 40         [24] 1246 	lcall	_ak820_outline_0050
                                   1247 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0042C9 90 05 96         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0042CC 12 3A 5F         [24] 1249 	lcall	_ak820_outline_0059
      0042CF 90 05 98         [24] 1250 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0042D2 12 3A 65         [24] 1251 	lcall	_ak820_outline_0070
                                   1252 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0042D5 90 05 94         [24] 1253 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0042D8 12 3A 5F         [24] 1254 	lcall	_ak820_outline_0059
      0042DB                       1255 00103$:
      0042DB 8C 02            [24] 1256 	mov	ar2,r4
      0042DD 8D 03            [24] 1257 	mov	ar3,r5
      0042DF 1C               [12] 1258 	dec	r4
      0042E0 BC FF 01         [24] 1259 	cjne	r4,#0xff,00130$
      0042E3 1D               [12] 1260 	dec	r5
      0042E4                       1261 00130$:
      0042E4 EA               [12] 1262 	mov	a,r2
      0042E5 4B               [12] 1263 	orl	a,r3
      0042E6 60 5D            [24] 1264 	jz	00106$
                                   1265 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0042E8 8E 02            [24] 1266 	mov	ar2,r6
      0042EA 8F 03            [24] 1267 	mov	ar3,r7
      0042EC 74 D8            [12] 1268 	mov	a,#0x100 - 0x28
      0042EE 2B               [12] 1269 	add	a,r3
      0042EF 50 17            [24] 1270 	jnc	00102$
      0042F1 90 05 98         [24] 1271 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0042F4 12 45 65         [24] 1272 	lcall	_ak820_outline_0119
      0042F7 12 45 7C         [24] 1273 	lcall	_ak820_outline_0142
      0042FA E4               [12] 1274 	clr	a
      0042FB F0               [24] 1275 	movx	@dptr,a
      0042FC 90 05 98         [24] 1276 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0042FF 04               [12] 1277 	inc	a
      004300 2A               [12] 1278 	add	a, r2
      004301 F0               [24] 1279 	movx	@dptr,a
      004302 E4               [12] 1280 	clr	a
      004303 3B               [12] 1281 	addc	a, r3
      004304 A3               [24] 1282 	inc	dptr
      004305 F0               [24] 1283 	movx	@dptr,a
      004306 80 D3            [24] 1284 	sjmp	00103$
      004308                       1285 00102$:
                                   1286 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004308 90 05 98         [24] 1287 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00430B 12 45 65         [24] 1288 	lcall	_ak820_outline_0119
      00430E 12 45 60         [24] 1289 	lcall	_ak820_outline_0116
      004311 C0 07            [24] 1290 	push	ar7
      004313 C0 06            [24] 1291 	push	ar6
      004315 C0 05            [24] 1292 	push	ar5
      004317 C0 04            [24] 1293 	push	ar4
      004319 C0 03            [24] 1294 	push	ar3
      00431B C0 02            [24] 1295 	push	ar2
      00431D 12 42 26         [24] 1296 	lcall	_read_offset
      004320 A9 82            [24] 1297 	mov	r1, dpl
      004322 D0 02            [24] 1298 	pop	ar2
      004324 D0 03            [24] 1299 	pop	ar3
      004326 D0 04            [24] 1300 	pop	ar4
      004328 D0 05            [24] 1301 	pop	ar5
      00432A D0 06            [24] 1302 	pop	ar6
      00432C D0 07            [24] 1303 	pop	ar7
      00432E 12 45 7C         [24] 1304 	lcall	_ak820_outline_0142
      004331 E9               [12] 1305 	mov	a,r1
      004332 F0               [24] 1306 	movx	@dptr,a
      004333 90 05 98         [24] 1307 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004336 74 01            [12] 1308 	mov	a,#0x01
      004338 2A               [12] 1309 	add	a, r2
      004339 F0               [24] 1310 	movx	@dptr,a
      00433A E4               [12] 1311 	clr	a
      00433B 3B               [12] 1312 	addc	a, r3
      00433C A3               [24] 1313 	inc	dptr
      00433D F0               [24] 1314 	movx	@dptr,a
                                   1315 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      00433E 0E               [12] 1316 	inc	r6
      00433F BE 00 99         [24] 1317 	cjne	r6,#0x00,00103$
      004342 0F               [12] 1318 	inc	r7
      004343 80 96            [24] 1319 	sjmp	00103$
      004345                       1320 00106$:
                                   1321 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004345 22               [24] 1322 	ret
                                   1323 ;------------------------------------------------------------
                                   1324 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1325 ;------------------------------------------------------------
                                   1326 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1327 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1328 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1329 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1330 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1331 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1332 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1333 ;------------------------------------------------------------
                                   1334 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1335 ;	-----------------------------------------
                                   1336 ;	 function ak820_eeprom_write_block_xdata
                                   1337 ;	-----------------------------------------
      004346                       1338 _ak820_eeprom_write_block_xdata:
      004346 12 3A 83         [24] 1339 	lcall	_ak820_outline_0103
      004349 90 05 9F         [24] 1340 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00434C 12 3A 88         [24] 1341 	lcall	_ak820_outline_0104
                                   1342 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00434F 90 05 9A         [24] 1343 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004352 12 3A 40         [24] 1344 	lcall	_ak820_outline_0050
                                   1345 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004355 90 05 9F         [24] 1346 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004358 12 3A 5F         [24] 1347 	lcall	_ak820_outline_0059
                                   1348 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00435B 8E 02            [24] 1349 	mov	ar2,r6
      00435D 8F 03            [24] 1350 	mov	ar3,r7
      00435F C3               [12] 1351 	clr	c
      004360 E4               [12] 1352 	clr	a
      004361 9A               [12] 1353 	subb	a,r2
      004362 74 28            [12] 1354 	mov	a,#0x28
      004364 9B               [12] 1355 	subb	a,r3
      004365 40 15            [24] 1356 	jc	00101$
                                   1357 ;	free result
      004367 E4               [12] 1358 	clr	a
      004368 C3               [12] 1359 	clr	c
      004369 9E               [12] 1360 	subb	a,r6
      00436A FA               [12] 1361 	mov	r2,a
      00436B 74 28            [12] 1362 	mov	a,#0x28
      00436D 9F               [12] 1363 	subb	a,r7
      00436E FB               [12] 1364 	mov	r3,a
      00436F 90 05 9D         [24] 1365 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004372 12 3A 7D         [24] 1366 	lcall	_ak820_outline_0099
      004375 C3               [12] 1367 	clr	c
      004376 EA               [12] 1368 	mov	a,r2
      004377 98               [12] 1369 	subb	a,r0
      004378 EB               [12] 1370 	mov	a,r3
      004379 99               [12] 1371 	subb	a,r1
      00437A 50 06            [24] 1372 	jnc	00125$
                                   1373 ;	free result
      00437C                       1374 00101$:
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      00437C 75 82 0E         [24] 1376 	mov	dpl, #0x0e
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      00437F 02 3D 8D         [24] 1378 	ljmp	_nvm_fail
                                   1379 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004382                       1380 00125$:
      004382 90 05 9D         [24] 1381 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004385 12 45 65         [24] 1382 	lcall	_ak820_outline_0119
      004388                       1383 00108$:
      004388 8A 00            [24] 1384 	mov	ar0,r2
      00438A 8B 01            [24] 1385 	mov	ar1,r3
      00438C 1A               [12] 1386 	dec	r2
      00438D BA FF 01         [24] 1387 	cjne	r2,#0xff,00159$
      004390 1B               [12] 1388 	dec	r3
      004391                       1389 00159$:
      004391 E8               [12] 1390 	mov	a,r0
      004392 49               [12] 1391 	orl	a,r1
      004393 70 03            [24] 1392 	jnz	00160$
      004395 02 44 1F         [24] 1393 	ljmp	00110$
      004398                       1394 00160$:
                                   1395 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004398 C0 02            [24] 1396 	push	ar2
      00439A C0 03            [24] 1397 	push	ar3
      00439C 12 45 48         [24] 1398 	lcall	_ak820_outline_0091
      00439F F9               [12] 1399 	mov	r1,a
      0043A0 A3               [24] 1400 	inc	dptr
      0043A1 12 45 81         [24] 1401 	lcall	_ak820_outline_0148
                                   1402 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0043A4 8E 0C            [24] 1403 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0043A6 8F 0D            [24] 1404 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0043A8 A8 0C            [24] 1405 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0043AA E5 0D            [12] 1406 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0043AC A2 E7            [12] 1407 	mov	c,acc.7
      0043AE C8               [12] 1408 	xch	a,r0
      0043AF 33               [12] 1409 	rlc	a
      0043B0 C8               [12] 1410 	xch	a,r0
      0043B1 33               [12] 1411 	rlc	a
      0043B2 A2 E7            [12] 1412 	mov	c,acc.7
      0043B4 C8               [12] 1413 	xch	a,r0
      0043B5 33               [12] 1414 	rlc	a
      0043B6 C8               [12] 1415 	xch	a,r0
      0043B7 33               [12] 1416 	rlc	a
      0043B8 C8               [12] 1417 	xch	a,r0
      0043B9 54 03            [12] 1418 	anl	a,#0x03
      0043BB FB               [12] 1419 	mov	r3,a
      0043BC 88 82            [24] 1420 	mov	dpl, r0
      0043BE C0 07            [24] 1421 	push	ar7
      0043C0 C0 06            [24] 1422 	push	ar6
      0043C2 C0 05            [24] 1423 	push	ar5
      0043C4 C0 04            [24] 1424 	push	ar4
      0043C6 C0 03            [24] 1425 	push	ar3
      0043C8 C0 02            [24] 1426 	push	ar2
      0043CA C0 01            [24] 1427 	push	ar1
      0043CC 12 41 B4         [24] 1428 	lcall	_load_page
      0043CF E5 82            [12] 1429 	mov	a, dpl
      0043D1 D0 01            [24] 1430 	pop	ar1
      0043D3 D0 02            [24] 1431 	pop	ar2
      0043D5 D0 03            [24] 1432 	pop	ar3
      0043D7 D0 04            [24] 1433 	pop	ar4
      0043D9 D0 05            [24] 1434 	pop	ar5
      0043DB D0 06            [24] 1435 	pop	ar6
      0043DD D0 07            [24] 1436 	pop	ar7
      0043DF D0 03            [24] 1437 	pop	ar3
      0043E1 D0 02            [24] 1438 	pop	ar2
      0043E3 70 01            [24] 1439 	jnz	00105$
      0043E5 22               [24] 1440 	ret
      0043E6                       1441 00105$:
                                   1442 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0043E6 C0 06            [24] 1443 	push	ar6
      0043E8 C0 07            [24] 1444 	push	ar7
      0043EA 74 3F            [12] 1445 	mov	a,#0x3f
      0043EC 55 0C            [12] 1446 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0043EE 7F 00            [12] 1447 	mov	r7,#0x00
      0043F0 24 29            [12] 1448 	add	a, #_page_data
      0043F2 F5 0C            [12] 1449 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0043F4 EF               [12] 1450 	mov	a,r7
      0043F5 34 05            [12] 1451 	addc	a, #(_page_data >> 8)
      0043F7 F5 0D            [12] 1452 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0043F9 85 0C 82         [24] 1453 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0043FC 85 0D 83         [24] 1454 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0043FF E0               [24] 1455 	movx	a,@dptr
      004400 B5 01 06         [24] 1456 	cjne	a,ar1,00162$
      004403 D0 07            [24] 1457 	pop	ar7
      004405 D0 06            [24] 1458 	pop	ar6
      004407 80 0E            [24] 1459 	sjmp	00107$
      004409                       1460 00162$:
      004409 D0 07            [24] 1461 	pop	ar7
      00440B D0 06            [24] 1462 	pop	ar6
                                   1463 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00440D 85 0C 82         [24] 1464 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004410 85 0D 83         [24] 1465 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004413 E9               [12] 1466 	mov	a,r1
      004414 F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1469 ;	assignBit
      004415 D2 09            [12] 1470 	setb	_page_dirty
      004417                       1471 00107$:
                                   1472 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004417 0E               [12] 1473 	inc	r6
      004418 BE 00 01         [24] 1474 	cjne	r6,#0x00,00163$
      00441B 0F               [12] 1475 	inc	r7
      00441C                       1476 00163$:
      00441C 02 43 88         [24] 1477 	ljmp	00108$
      00441F                       1478 00110$:
                                   1479 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00441F 90 05 6A         [24] 1480 	mov	dptr,#_batch_depth
      004422 E0               [24] 1481 	movx	a,@dptr
      004423 70 03            [24] 1482 	jnz	00113$
                                   1483 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004425 02 40 34         [24] 1484 	ljmp	_ak820_nvm_flush
      004428                       1485 00113$:
      004428 22               [24] 1486 	ret
                                   1487 ;------------------------------------------------------------
                                   1488 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1489 ;------------------------------------------------------------
                                   1490 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1491 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1492 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1493 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1494 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1495 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1496 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1497 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1498 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1499 ;------------------------------------------------------------
                                   1500 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1501 ;	-----------------------------------------
                                   1502 ;	 function ak820_eeprom_update_block_xdata
                                   1503 ;	-----------------------------------------
      004429                       1504 _ak820_eeprom_update_block_xdata:
      004429 12 3A 83         [24] 1505 	lcall	_ak820_outline_0103
      00442C 90 05 A6         [24] 1506 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00442F 12 3A 88         [24] 1507 	lcall	_ak820_outline_0104
                                   1508 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004432 90 05 A6         [24] 1509 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004435 12 3A 40         [24] 1510 	lcall	_ak820_outline_0050
                                   1511 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004438 90 05 A1         [24] 1512 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00443B E0               [24] 1513 	movx	a,@dptr
      00443C F5 12            [12] 1514 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      00443E A3               [24] 1515 	inc	dptr
      00443F E0               [24] 1516 	movx	a,@dptr
      004440 F5 13            [12] 1517 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004442 A3               [24] 1518 	inc	dptr
      004443 E0               [24] 1519 	movx	a,@dptr
      004444 F5 14            [12] 1520 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004446 A9 12            [24] 1521 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004448 AA 13            [24] 1522 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1523 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00444A E4               [12] 1524 	clr	a
      00444B F5 0E            [12] 1525 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      00444D F5 0F            [12] 1526 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00444F                       1527 00105$:
      00444F 90 05 A4         [24] 1528 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004452 E0               [24] 1529 	movx	a,@dptr
      004453 F5 10            [12] 1530 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004455 A3               [24] 1531 	inc	dptr
      004456 E0               [24] 1532 	movx	a,@dptr
      004457 F5 11            [12] 1533 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004459 C3               [12] 1534 	clr	c
      00445A E5 0E            [12] 1535 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00445C 95 10            [12] 1536 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00445E E5 0F            [12] 1537 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004460 95 11            [12] 1538 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004462 50 68            [24] 1539 	jnc	00107$
                                   1540 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004464 89 00            [24] 1541 	mov	ar0,r1
      004466 8A 05            [24] 1542 	mov	ar5,r2
      004468 E5 0E            [12] 1543 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00446A 28               [12] 1544 	add	a, r0
      00446B F8               [12] 1545 	mov	r0,a
      00446C E5 0F            [12] 1546 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00446E 3D               [12] 1547 	addc	a, r5
      00446F FD               [12] 1548 	mov	r5,a
      004470 88 82            [24] 1549 	mov	dpl, r0
      004472 8D 83            [24] 1550 	mov	dph, r5
      004474 C0 07            [24] 1551 	push	ar7
      004476 C0 06            [24] 1552 	push	ar6
      004478 C0 02            [24] 1553 	push	ar2
      00447A C0 01            [24] 1554 	push	ar1
      00447C 12 42 26         [24] 1555 	lcall	_read_offset
      00447F AD 82            [24] 1556 	mov	r5, dpl
      004481 D0 01            [24] 1557 	pop	ar1
      004483 D0 02            [24] 1558 	pop	ar2
      004485 D0 06            [24] 1559 	pop	ar6
      004487 D0 07            [24] 1560 	pop	ar7
      004489 E5 0E            [12] 1561 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00448B 2E               [12] 1562 	add	a, r6
      00448C F5 82            [12] 1563 	mov	dpl,a
      00448E E5 0F            [12] 1564 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004490 3F               [12] 1565 	addc	a, r7
      004491 F5 83            [12] 1566 	mov	dph,a
      004493 E0               [24] 1567 	movx	a,@dptr
      004494 FC               [12] 1568 	mov	r4,a
      004495 ED               [12] 1569 	mov	a,r5
      004496 B5 04 02         [24] 1570 	cjne	a,ar4,00131$
      004499 80 27            [24] 1571 	sjmp	00106$
      00449B                       1572 00131$:
                                   1573 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00449B 90 05 A6         [24] 1574 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00449E E0               [24] 1575 	movx	a,@dptr
      00449F F8               [12] 1576 	mov	r0,a
      0044A0 A3               [24] 1577 	inc	dptr
      0044A1 E0               [24] 1578 	movx	a,@dptr
      0044A2 FD               [12] 1579 	mov	r5,a
      0044A3 90 05 9A         [24] 1580 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0044A6 E5 12            [12] 1581 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0044A8 F0               [24] 1582 	movx	@dptr,a
      0044A9 E5 13            [12] 1583 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0044AB A3               [24] 1584 	inc	dptr
      0044AC F0               [24] 1585 	movx	@dptr,a
      0044AD E5 14            [12] 1586 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0044AF A3               [24] 1587 	inc	dptr
      0044B0 F0               [24] 1588 	movx	@dptr,a
      0044B1 90 05 9D         [24] 1589 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0044B4 E5 10            [12] 1590 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0044B6 F0               [24] 1591 	movx	@dptr,a
      0044B7 E5 11            [12] 1592 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0044B9 A3               [24] 1593 	inc	dptr
      0044BA F0               [24] 1594 	movx	@dptr,a
      0044BB 88 82            [24] 1595 	mov	dpl, r0
      0044BD 8D 83            [24] 1596 	mov	dph, r5
                                   1597 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0044BF 02 43 46         [24] 1598 	ljmp	_ak820_eeprom_write_block_xdata
      0044C2                       1599 00106$:
                                   1600 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0044C2 05 0E            [12] 1601 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044C4 E4               [12] 1602 	clr	a
      0044C5 B5 0E 87         [24] 1603 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0044C8 05 0F            [12] 1604 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044CA 80 83            [24] 1605 	sjmp	00105$
      0044CC                       1606 00107$:
                                   1607 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0044CC 22               [24] 1608 	ret
                                   1609 ;------------------------------------------------------------
                                   1610 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1611 ;------------------------------------------------------------
                                   1612 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1613 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1614 ;------------------------------------------------------------
                                   1615 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1616 ;	-----------------------------------------
                                   1617 ;	 function eeprom_driver_erase
                                   1618 ;	-----------------------------------------
      0044CD                       1619 _eeprom_driver_erase:
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0044CD 12 40 34         [24] 1621 	lcall	_ak820_nvm_flush
                                   1622 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0044D0 7F 00            [12] 1623 	mov	r7,#0x00
      0044D2                       1624 00111$:
      0044D2 BF A0 01         [24] 1625 	cjne	r7,#0xa0,00165$
      0044D5 22               [24] 1626 	ret
      0044D6                       1627 00165$:
      0044D6 20 0A 32         [24] 1628 	jb	_storage_failed,00113$
                                   1629 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0044D9 8F 82            [24] 1630 	mov	dpl, r7
      0044DB C0 07            [24] 1631 	push	ar7
      0044DD 12 41 B4         [24] 1632 	lcall	_load_page
      0044E0 E5 82            [12] 1633 	mov	a, dpl
      0044E2 D0 07            [24] 1634 	pop	ar7
      0044E4 70 01            [24] 1635 	jnz	00126$
                                   1636 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0044E6 22               [24] 1637 	ret
      0044E7                       1638 00126$:
      0044E7 7E 00            [12] 1639 	mov	r6,#0x00
      0044E9                       1640 00107$:
                                   1641 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0044E9 EE               [12] 1642 	mov	a,r6
      0044EA 24 29            [12] 1643 	add	a, #_page_data
      0044EC FC               [12] 1644 	mov	r4,a
      0044ED E4               [12] 1645 	clr	a
      0044EE 34 05            [12] 1646 	addc	a, #(_page_data >> 8)
      0044F0 FD               [12] 1647 	mov	r5,a
      0044F1 12 45 48         [24] 1648 	lcall	_ak820_outline_0091
      0044F4 60 07            [24] 1649 	jz	00108$
      0044F6 12 3A A0         [24] 1650 	lcall	_ak820_outline_0121
      0044F9 E4               [12] 1651 	clr	a
      0044FA F0               [24] 1652 	movx	@dptr,a
                                   1653 ;	assignBit
      0044FB D2 09            [12] 1654 	setb	_page_dirty
      0044FD                       1655 00108$:
                                   1656 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0044FD 0E               [12] 1657 	inc	r6
      0044FE BE 40 E8         [24] 1658 	cjne	r6,#0x40,00107$
                                   1659 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004501 C0 07            [24] 1660 	push	ar7
      004503 12 40 34         [24] 1661 	lcall	_ak820_nvm_flush
      004506 D0 07            [24] 1662 	pop	ar7
                                   1663 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004508 0F               [12] 1664 	inc	r7
      004509 80 C7            [24] 1665 	sjmp	00111$
      00450B                       1666 00113$:
                                   1667 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      00450B 22               [24] 1668 	ret
                                   1669 	.area CSEG    (CODE)
                                   1670 	.area CONST   (CODE)
                                   1671 	.area XINIT   (CODE)
                                   1672 	.area CABS    (ABS,CODE)
                                   1673 
                                   1674 ; Experimental exact instruction outlining.
                                   1675 	.globl _ak820_outline_0004
                                   1676 	.globl _ak820_outline_0009
                                   1677 	.globl _ak820_outline_0015
                                   1678 	.globl _ak820_outline_0016
                                   1679 	.globl _ak820_outline_0029
                                   1680 	.globl _ak820_outline_0036
                                   1681 	.globl _ak820_outline_0039
                                   1682 	.globl _ak820_outline_0050
                                   1683 	.globl _ak820_outline_0051
                                   1684 	.globl _ak820_outline_0059
                                   1685 	.globl _ak820_outline_0060
                                   1686 	.globl _ak820_outline_0070
                                   1687 	.globl _ak820_outline_0075
                                   1688 	.globl _ak820_outline_0091
                                   1689 	.globl _ak820_outline_0096
                                   1690 	.globl _ak820_outline_0099
                                   1691 	.globl _ak820_outline_0101
                                   1692 	.globl _ak820_outline_0103
                                   1693 	.globl _ak820_outline_0104
                                   1694 	.globl _ak820_outline_0116
                                   1695 	.globl _ak820_outline_0119
                                   1696 	.globl _ak820_outline_0120
                                   1697 	.globl _ak820_outline_0121
                                   1698 	.globl _ak820_outline_0122
                                   1699 	.globl _ak820_outline_0131
                                   1700 	.globl _ak820_outline_0132
                                   1701 	.globl _ak820_outline_0134
                                   1702 	.globl _ak820_outline_0141
                                   1703 	.globl _ak820_outline_0142
                                   1704 	.globl _ak820_outline_0148
                                   1705 	.globl _ak820_outline_0156
                                   1706 	.globl _ak820_outline_0158
                                   1707 	.globl _ak820_outline_0159
                                   1708 	.globl _ak820_outline_0166
                                   1709 	.globl _ak820_outline_0179
                                   1710 	.globl _ak820_outline_0180
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0009
      00450C                       1714 _ak820_outline_0009:
      00450C 8E 82            [24] 1715 	mov	dpl,r6
      00450E 8F 83            [24] 1716 	mov	dph,r7
      004510 A3               [24] 1717 	inc	dptr
      004511 A3               [24] 1718 	inc	dptr
      004512 A3               [24] 1719 	inc	dptr
      004513 A3               [24] 1720 	inc	dptr
      004514 A3               [24] 1721 	inc	dptr
      004515 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0029
      004516                       1726 _ak820_outline_0029:
      004516 F0               [24] 1727 	movx	@dptr,a
      004517 8E 82            [24] 1728 	mov	dpl,r6
      004519 8F 83            [24] 1729 	mov	dph,r7
      00451B A3               [24] 1730 	inc	dptr
      00451C A3               [24] 1731 	inc	dptr
      00451D 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0036
      00451E                       1736 _ak820_outline_0036:
      00451E AF F0            [24] 1737 	mov	r7,b
      004520 AE 83            [24] 1738 	mov	r6,dph
      004522 E5 82            [12] 1739 	mov	a,dpl
      004524 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0039
      004525                       1744 _ak820_outline_0039:
      004525 EF               [12] 1745 	mov	a,r7
      004526 24 81            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      004528 F5 82            [12] 1747 	mov	dpl,a
      00452A E4               [12] 1748 	clr	a
      00452B 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00452D F5 83            [12] 1750 	mov	dph,a
      00452F E0               [24] 1751 	movx	a,@dptr
      004530 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0051
      004531                       1756 _ak820_outline_0051:
      004531 8F 06            [24] 1757 	mov	ar6,r7
      004533 7D 00            [12] 1758 	mov	r5,#0x00
      004535 74 40            [12] 1759 	mov	a,#0x40
      004537 2E               [12] 1760 	add	a,r6
      004538 FE               [12] 1761 	mov	r6,a
      004539 74 EF            [12] 1762 	mov	a,#0xef
      00453B 3D               [12] 1763 	addc	a,r5
      00453C FD               [12] 1764 	mov	r5,a
      00453D 8E 82            [24] 1765 	mov	dpl,r6
      00453F 8D 83            [24] 1766 	mov	dph,r5
      004541 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0060
      004542                       1771 _ak820_outline_0060:
      004542 F0               [24] 1772 	movx	@dptr,a
      004543 8E 82            [24] 1773 	mov	dpl,r6
      004545 8F 83            [24] 1774 	mov	dph,r7
      004547 22               [24] 1775 	ret
                                   1776 
                                   1777 	.area CSEG (CODE)
                                   1778 ; function ak820_outline_0091
      004548                       1779 _ak820_outline_0091:
      004548 8C 82            [24] 1780 	mov	dpl,r4
      00454A 8D 83            [24] 1781 	mov	dph,r5
      00454C E0               [24] 1782 	movx	a,@dptr
      00454D 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0096
      00454E                       1787 _ak820_outline_0096:
      00454E E0               [24] 1788 	movx	a,@dptr
      00454F FD               [12] 1789 	mov	r5,a
      004550 A3               [24] 1790 	inc	dptr
      004551 E0               [24] 1791 	movx	a,@dptr
      004552 FE               [12] 1792 	mov	r6,a
      004553 22               [24] 1793 	ret
                                   1794 
                                   1795 	.area CSEG (CODE)
                                   1796 ; function ak820_outline_0101
      004554                       1797 _ak820_outline_0101:
      004554 EF               [12] 1798 	mov	a,r7
      004555 24 29            [12] 1799 	add	a,#_page_data
      004557 F5 82            [12] 1800 	mov	dpl,a
      004559 E4               [12] 1801 	clr	a
      00455A 34 05            [12] 1802 	addc	a,#(_page_data>>8)
      00455C F5 83            [12] 1803 	mov	dph,a
      00455E E0               [24] 1804 	movx	a,@dptr
      00455F 22               [24] 1805 	ret
                                   1806 
                                   1807 	.area CSEG (CODE)
                                   1808 ; function ak820_outline_0116
      004560                       1809 _ak820_outline_0116:
      004560 8E 82            [24] 1810 	mov	dpl,r6
      004562 8F 83            [24] 1811 	mov	dph,r7
      004564 22               [24] 1812 	ret
                                   1813 
                                   1814 	.area CSEG (CODE)
                                   1815 ; function ak820_outline_0119
      004565                       1816 _ak820_outline_0119:
      004565 E0               [24] 1817 	movx	a,@dptr
      004566 FA               [12] 1818 	mov	r2,a
      004567 A3               [24] 1819 	inc	dptr
      004568 E0               [24] 1820 	movx	a,@dptr
      004569 FB               [12] 1821 	mov	r3,a
      00456A 22               [24] 1822 	ret
                                   1823 
                                   1824 	.area CSEG (CODE)
                                   1825 ; function ak820_outline_0132
      00456B                       1826 _ak820_outline_0132:
      00456B AE 82            [24] 1827 	mov	r6,dpl
      00456D AF 83            [24] 1828 	mov	r7,dph
      00456F 22               [24] 1829 	ret
                                   1830 
                                   1831 	.area CSEG (CODE)
                                   1832 ; function ak820_outline_0134
      004570                       1833 _ak820_outline_0134:
      004570 2E               [12] 1834 	add	a,r6
      004571 FE               [12] 1835 	mov	r6,a
      004572 E4               [12] 1836 	clr	a
      004573 3F               [12] 1837 	addc	a,r7
      004574 FF               [12] 1838 	mov	r7,a
      004575 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0141
      004576                       1843 _ak820_outline_0141:
      004576 42 05            [12] 1844 	orl	ar5,a
      004578 EA               [12] 1845 	mov	a,r2
      004579 42 04            [12] 1846 	orl	ar4,a
      00457B 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0142
      00457C                       1851 _ak820_outline_0142:
      00457C 8A 82            [24] 1852 	mov	dpl,r2
      00457E 8B 83            [24] 1853 	mov	dph,r3
      004580 22               [24] 1854 	ret
                                   1855 
                                   1856 	.area CSEG (CODE)
                                   1857 ; function ak820_outline_0148
      004581                       1858 _ak820_outline_0148:
      004581 AC 82            [24] 1859 	mov	r4,dpl
      004583 AD 83            [24] 1860 	mov	r5,dph
      004585 22               [24] 1861 	ret
                                   1862 
                                   1863 	.area CSEG (CODE)
                                   1864 ; function ak820_outline_0156
      004586                       1865 _ak820_outline_0156:
      004586 8F 82            [24] 1866 	mov	dpl,r7
      004588 8E 83            [24] 1867 	mov	dph,r6
      00458A 22               [24] 1868 	ret
                                   1869 
                                   1870 	.area CSEG (CODE)
                                   1871 ; function ak820_outline_0158
      00458B                       1872 _ak820_outline_0158:
      00458B 2E               [12] 1873 	add	a,r6
      00458C FC               [12] 1874 	mov	r4,a
      00458D E4               [12] 1875 	clr	a
      00458E 3F               [12] 1876 	addc	a,r7
      00458F FD               [12] 1877 	mov	r5,a
      004590 22               [24] 1878 	ret
                                   1879 
                                   1880 	.area CSEG (CODE)
                                   1881 ; function ak820_outline_0159
      004591                       1882 _ak820_outline_0159:
      004591 ED               [12] 1883 	mov	a,r5
      004592 F0               [24] 1884 	movx	@dptr,a
      004593 EE               [12] 1885 	mov	a,r6
      004594 A3               [24] 1886 	inc	dptr
      004595 F0               [24] 1887 	movx	@dptr,a
      004596 22               [24] 1888 	ret
                                   1889 
                                   1890 	.area CSEG (CODE)
                                   1891 ; function ak820_outline_0179
      004597                       1892 _ak820_outline_0179:
      004597 89 82            [24] 1893 	mov	dpl,r1
      004599 8A 83            [24] 1894 	mov	dph,r2
      00459B 22               [24] 1895 	ret
                                   1896 
                                   1897 	.area CSEG (CODE)
                                   1898 ; function ak820_outline_0180
      00459C                       1899 _ak820_outline_0180:
      00459C 8C 82            [24] 1900 	mov	dpl,r4
      00459E 8B 83            [24] 1901 	mov	dph,r3
      0045A0 22               [24] 1902 	ret
