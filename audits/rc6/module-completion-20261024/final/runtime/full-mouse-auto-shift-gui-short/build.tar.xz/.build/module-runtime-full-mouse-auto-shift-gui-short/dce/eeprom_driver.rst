                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00068E                         85 _eeprom_read_word_addr_10000_91:
      00068E                         86 	.ds 3
      000691                         87 _eeprom_read_word_ret_10000_92:
      000691                         88 	.ds 2
      000693                         89 _eeprom_read_dword_addr_10000_93:
      000693                         90 	.ds 3
      000696                         91 _eeprom_read_dword_ret_10000_94:
      000696                         92 	.ds 4
      00069A                         93 _eeprom_write_byte_PARM_2:
      00069A                         94 	.ds 1
      00069B                         95 _eeprom_write_byte_addr_10000_95:
      00069B                         96 	.ds 3
      00069E                         97 _eeprom_write_word_PARM_2:
      00069E                         98 	.ds 2
      0006A0                         99 _eeprom_write_word_addr_10000_97:
      0006A0                        100 	.ds 3
      0006A3                        101 _eeprom_write_dword_PARM_2:
      0006A3                        102 	.ds 4
      0006A7                        103 _eeprom_write_dword_addr_10000_99:
      0006A7                        104 	.ds 3
      0006AA                        105 _eeprom_update_byte_PARM_2:
      0006AA                        106 	.ds 1
      0006AB                        107 _eeprom_update_byte_addr_10000_107:
      0006AB                        108 	.ds 3
      0006AE                        109 _eeprom_update_word_PARM_2:
      0006AE                        110 	.ds 2
      0006B0                        111 _eeprom_update_word_addr_10000_111:
      0006B0                        112 	.ds 3
      0006B3                        113 _eeprom_update_dword_PARM_2:
      0006B3                        114 	.ds 4
      0006B7                        115 _eeprom_update_dword_addr_10000_115:
      0006B7                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004F53                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004F53 12 45 1E         [24]  170 	lcall	_ak820_outline_0036
      004F56 90 06 8E         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004F59 12 3A 1F         [24]  172 	lcall	_ak820_outline_0015
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004F5C 90 06 91         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004F5F 12 51 5E         [24]  175 	lcall	_ak820_outline_0178
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004F62 90 06 8E         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004F65 12 51 0C         [24]  178 	lcall	_ak820_outline_0020
      004F68 90 05 91         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004F6B ED               [12]  180 	mov	a,r5
      004F6C 12 3A 1F         [24]  181 	lcall	_ak820_outline_0015
      004F6F 90 05 94         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004F72 12 51 50         [24]  183 	lcall	_ak820_outline_0106
      004F75 90 06 91         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004F78 12 42 BA         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004F7B 90 06 91         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004F7E 12 51 47         [24]  188 	lcall	_ak820_outline_0087
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004F81 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004F82                        201 _eeprom_read_dword:
      004F82 12 45 1E         [24]  202 	lcall	_ak820_outline_0036
      004F85 90 06 93         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004F88 12 3A 1F         [24]  204 	lcall	_ak820_outline_0015
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004F8B 90 06 96         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004F8E 12 51 1C         [24]  207 	lcall	_ak820_outline_0048
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004F91 90 06 93         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004F94 12 51 0C         [24]  210 	lcall	_ak820_outline_0020
      004F97 90 05 91         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004F9A ED               [12]  212 	mov	a,r5
      004F9B 12 3A 1F         [24]  213 	lcall	_ak820_outline_0015
      004F9E 90 05 94         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004FA1 74 04            [12]  215 	mov	a,#0x04
      004FA3 12 3A A5         [24]  216 	lcall	_ak820_outline_0123
      004FA6 90 06 96         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004FA9 12 42 BA         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004FAC 90 06 96         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004FAF 12 51 25         [24]  221 	lcall	_ak820_outline_0053
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004FB2 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004FB3                        234 _eeprom_write_byte:
      004FB3 12 45 1E         [24]  235 	lcall	_ak820_outline_0036
      004FB6 90 06 9B         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004FB9 12 3A 1F         [24]  237 	lcall	_ak820_outline_0015
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004FBC 90 06 9B         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004FBF 12 50 E6         [24]  240 	lcall	_ak820_outline_0002
      004FC2 74 01            [12]  241 	mov	a,#0x01
      004FC4 12 3A A5         [24]  242 	lcall	_ak820_outline_0123
      004FC7 90 06 9A         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004FCA 02 43 46         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004FCD                        256 _eeprom_write_word:
      004FCD 12 45 1E         [24]  257 	lcall	_ak820_outline_0036
      004FD0 90 06 A0         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004FD3 12 3A 1F         [24]  259 	lcall	_ak820_outline_0015
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004FD6 90 06 A0         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004FD9 12 50 E6         [24]  262 	lcall	_ak820_outline_0002
      004FDC 12 51 50         [24]  263 	lcall	_ak820_outline_0106
      004FDF 90 06 9E         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004FE2 02 43 46         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004FE5                        277 _eeprom_write_dword:
      004FE5 12 45 1E         [24]  278 	lcall	_ak820_outline_0036
      004FE8 90 06 A7         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004FEB 12 3A 1F         [24]  280 	lcall	_ak820_outline_0015
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004FEE 90 06 A7         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004FF1 12 50 E6         [24]  283 	lcall	_ak820_outline_0002
      004FF4 74 04            [12]  284 	mov	a,#0x04
      004FF6 12 3A A5         [24]  285 	lcall	_ak820_outline_0123
      004FF9 90 06 A3         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004FFC 02 43 46         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004FFF                        307 _eeprom_update_byte:
      004FFF C0 07            [24]  308 	push	ar7
      005001 C0 06            [24]  309 	push	ar6
      005003 C0 05            [24]  310 	push	ar5
      005005 C0 04            [24]  311 	push	ar4
      005007 12 45 1E         [24]  312 	lcall	_ak820_outline_0036
      00500A 90 06 AB         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00500D 12 3A 1F         [24]  314 	lcall	_ak820_outline_0015
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      005010 90 06 AB         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005013 12 50 FD         [24]  317 	lcall	_ak820_outline_0003
      005016 12 42 7F         [24]  318 	lcall	_eeprom_read_byte
      005019 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      00501B 90 06 AA         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      00501E E0               [24]  322 	movx	a,@dptr
      00501F FE               [12]  323 	mov	r6,a
      005020 EF               [12]  324 	mov	a,r7
      005021 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      005024 80 35            [24]  326 	sjmp	00103$
      005026                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      005026 90 06 AB         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005029 12 3A 5F         [24]  330 	lcall	_ak820_outline_0059
      00502C A3               [24]  331 	inc	dptr
      00502D E0               [24]  332 	movx	a,@dptr
      00502E FF               [12]  333 	mov	r7,a
      00502F 90 06 9A         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      005032 EE               [12]  335 	mov	a,r6
      005033 12 3A 71         [24]  336 	lcall	_ak820_outline_0095
      005036 8F F0            [24]  337 	mov	b, r7
      005038 C0 07            [24]  338 	push	ar7
      00503A C0 06            [24]  339 	push	ar6
      00503C C0 05            [24]  340 	push	ar5
      00503E C0 04            [24]  341 	push	ar4
      005040 C0 03            [24]  342 	push	ar3
      005042 C0 02            [24]  343 	push	ar2
      005044 C0 01            [24]  344 	push	ar1
      005046 C0 00            [24]  345 	push	ar0
      005048 12 4F B3         [24]  346 	lcall	_eeprom_write_byte
      00504B D0 00            [24]  347 	pop	ar0
      00504D D0 01            [24]  348 	pop	ar1
      00504F D0 02            [24]  349 	pop	ar2
      005051 D0 03            [24]  350 	pop	ar3
      005053 D0 04            [24]  351 	pop	ar4
      005055 D0 05            [24]  352 	pop	ar5
      005057 D0 06            [24]  353 	pop	ar6
      005059 D0 07            [24]  354 	pop	ar7
      00505B                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      00505B D0 04            [24]  357 	pop	ar4
      00505D D0 05            [24]  358 	pop	ar5
      00505F D0 06            [24]  359 	pop	ar6
      005061 D0 07            [24]  360 	pop	ar7
      005063 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      005064                        373 _eeprom_update_word:
      005064 12 45 1E         [24]  374 	lcall	_ak820_outline_0036
      005067 90 06 B0         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      00506A 12 3A 1F         [24]  376 	lcall	_ak820_outline_0015
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      00506D 90 06 B0         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005070 12 50 FD         [24]  379 	lcall	_ak820_outline_0003
      005073 12 4F 53         [24]  380 	lcall	_eeprom_read_word
      005076 12 45 6B         [24]  381 	lcall	_ak820_outline_0132
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      005079 90 06 AE         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      00507C 12 3A 5F         [24]  384 	lcall	_ak820_outline_0059
      00507F EE               [12]  385 	mov	a,r6
      005080 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      005083 EF               [12]  387 	mov	a,r7
      005084 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      005087 22               [24]  389 	ret
      005088                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      005088 90 06 B0         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      00508B E0               [24]  393 	movx	a,@dptr
      00508C FB               [12]  394 	mov	r3,a
      00508D A3               [24]  395 	inc	dptr
      00508E 12 3A 40         [24]  396 	lcall	_ak820_outline_0050
      005091 90 06 9E         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      005094 12 3A 65         [24]  398 	lcall	_ak820_outline_0070
      005097 8B 82            [24]  399 	mov	dpl, r3
      005099 8E 83            [24]  400 	mov	dph, r6
      00509B 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      00509D 02 4F CD         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      0050A0                        415 _eeprom_update_dword:
      0050A0 12 45 1E         [24]  416 	lcall	_ak820_outline_0036
      0050A3 90 06 B7         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0050A6 12 3A 1F         [24]  418 	lcall	_ak820_outline_0015
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      0050A9 90 06 B7         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0050AC 12 50 FD         [24]  421 	lcall	_ak820_outline_0003
      0050AF 12 4F 82         [24]  422 	lcall	_eeprom_read_dword
      0050B2 12 51 36         [24]  423 	lcall	_ak820_outline_0055
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      0050B5 90 06 B3         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      0050B8 E0               [24]  426 	movx	a,@dptr
      0050B9 F8               [12]  427 	mov	r0,a
      0050BA A3               [24]  428 	inc	dptr
      0050BB 12 51 3E         [24]  429 	lcall	_ak820_outline_0086
      0050BE EC               [12]  430 	mov	a,r4
      0050BF B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      0050C2 ED               [12]  432 	mov	a,r5
      0050C3 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      0050C6 EE               [12]  434 	mov	a,r6
      0050C7 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      0050CA EF               [12]  436 	mov	a,r7
      0050CB B5 03 01         [24]  437 	cjne	a,ar3,00112$
      0050CE 22               [24]  438 	ret
      0050CF                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      0050CF 90 06 B7         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0050D2 12 51 0C         [24]  442 	lcall	_ak820_outline_0020
      0050D5 90 06 A3         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      0050D8 E8               [12]  444 	mov	a,r0
      0050D9 F0               [24]  445 	movx	@dptr,a
      0050DA E9               [12]  446 	mov	a,r1
      0050DB A3               [24]  447 	inc	dptr
      0050DC 12 51 57         [24]  448 	lcall	_ak820_outline_0154
      0050DF F0               [24]  449 	movx	@dptr,a
      0050E0 12 51 15         [24]  450 	lcall	_ak820_outline_0043
                                    451 ;	drivers/eeprom/eeprom_driver.c:101: }
      0050E3 02 4F E5         [24]  452 	ljmp	_eeprom_write_dword
                                    453 	.area CSEG    (CODE)
                                    454 	.area CONST   (CODE)
                                    455 	.area XINIT   (CODE)
                                    456 	.area CABS    (ABS,CODE)
                                    457 
                                    458 ; Experimental exact instruction outlining.
                                    459 	.globl _ak820_outline_0002
                                    460 	.globl _ak820_outline_0003
                                    461 	.globl _ak820_outline_0015
                                    462 	.globl _ak820_outline_0020
                                    463 	.globl _ak820_outline_0036
                                    464 	.globl _ak820_outline_0043
                                    465 	.globl _ak820_outline_0048
                                    466 	.globl _ak820_outline_0050
                                    467 	.globl _ak820_outline_0053
                                    468 	.globl _ak820_outline_0055
                                    469 	.globl _ak820_outline_0059
                                    470 	.globl _ak820_outline_0070
                                    471 	.globl _ak820_outline_0086
                                    472 	.globl _ak820_outline_0087
                                    473 	.globl _ak820_outline_0095
                                    474 	.globl _ak820_outline_0106
                                    475 	.globl _ak820_outline_0123
                                    476 	.globl _ak820_outline_0132
                                    477 	.globl _ak820_outline_0154
                                    478 	.globl _ak820_outline_0178
                                    479 
                                    480 	.area CSEG (CODE)
                                    481 ; function ak820_outline_0002
      0050E6                        482 _ak820_outline_0002:
      0050E6 E0               [24]  483 	movx	a,@dptr
      0050E7 FD               [12]  484 	mov	r5,a
      0050E8 A3               [24]  485 	inc	dptr
      0050E9 E0               [24]  486 	movx	a,@dptr
      0050EA FE               [12]  487 	mov	r6,a
      0050EB A3               [24]  488 	inc	dptr
      0050EC E0               [24]  489 	movx	a,@dptr
      0050ED FF               [12]  490 	mov	r7,a
      0050EE 90 05 9A         [24]  491 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0050F1 ED               [12]  492 	mov	a,r5
      0050F2 F0               [24]  493 	movx	@dptr,a
      0050F3 EE               [12]  494 	mov	a,r6
      0050F4 A3               [24]  495 	inc	dptr
      0050F5 F0               [24]  496 	movx	@dptr,a
      0050F6 EF               [12]  497 	mov	a,r7
      0050F7 A3               [24]  498 	inc	dptr
      0050F8 F0               [24]  499 	movx	@dptr,a
      0050F9 90 05 9D         [24]  500 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0050FC 22               [24]  501 	ret
                                    502 
                                    503 	.area CSEG (CODE)
                                    504 ; function ak820_outline_0003
      0050FD                        505 _ak820_outline_0003:
      0050FD E0               [24]  506 	movx	a,@dptr
      0050FE FD               [12]  507 	mov	r5,a
      0050FF A3               [24]  508 	inc	dptr
      005100 E0               [24]  509 	movx	a,@dptr
      005101 FE               [12]  510 	mov	r6,a
      005102 A3               [24]  511 	inc	dptr
      005103 E0               [24]  512 	movx	a,@dptr
      005104 FF               [12]  513 	mov	r7,a
      005105 8D 82            [24]  514 	mov	dpl,r5
      005107 8E 83            [24]  515 	mov	dph,r6
      005109 8F F0            [24]  516 	mov	b,r7
      00510B 22               [24]  517 	ret
                                    518 
                                    519 	.area CSEG (CODE)
                                    520 ; function ak820_outline_0020
      00510C                        521 _ak820_outline_0020:
      00510C E0               [24]  522 	movx	a,@dptr
      00510D FD               [12]  523 	mov	r5,a
      00510E A3               [24]  524 	inc	dptr
      00510F E0               [24]  525 	movx	a,@dptr
      005110 FE               [12]  526 	mov	r6,a
      005111 A3               [24]  527 	inc	dptr
      005112 E0               [24]  528 	movx	a,@dptr
      005113 FF               [12]  529 	mov	r7,a
      005114 22               [24]  530 	ret
                                    531 
                                    532 	.area CSEG (CODE)
                                    533 ; function ak820_outline_0043
      005115                        534 _ak820_outline_0043:
      005115 8D 82            [24]  535 	mov	dpl,r5
      005117 8E 83            [24]  536 	mov	dph,r6
      005119 8F F0            [24]  537 	mov	b,r7
      00511B 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0048
      00511C                        542 _ak820_outline_0048:
      00511C E4               [12]  543 	clr	a
      00511D F0               [24]  544 	movx	@dptr,a
      00511E A3               [24]  545 	inc	dptr
      00511F F0               [24]  546 	movx	@dptr,a
      005120 A3               [24]  547 	inc	dptr
      005121 F0               [24]  548 	movx	@dptr,a
      005122 A3               [24]  549 	inc	dptr
      005123 F0               [24]  550 	movx	@dptr,a
      005124 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0053
      005125                        555 _ak820_outline_0053:
      005125 E0               [24]  556 	movx	a,@dptr
      005126 FC               [12]  557 	mov	r4,a
      005127 A3               [24]  558 	inc	dptr
      005128 E0               [24]  559 	movx	a,@dptr
      005129 FD               [12]  560 	mov	r5,a
      00512A A3               [24]  561 	inc	dptr
      00512B E0               [24]  562 	movx	a,@dptr
      00512C FE               [12]  563 	mov	r6,a
      00512D A3               [24]  564 	inc	dptr
      00512E E0               [24]  565 	movx	a,@dptr
      00512F 8C 82            [24]  566 	mov	dpl,r4
      005131 8D 83            [24]  567 	mov	dph,r5
      005133 8E F0            [24]  568 	mov	b,r6
      005135 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0055
      005136                        573 _ak820_outline_0055:
      005136 AC 82            [24]  574 	mov	r4,dpl
      005138 AD 83            [24]  575 	mov	r5,dph
      00513A AE F0            [24]  576 	mov	r6,b
      00513C FF               [12]  577 	mov	r7,a
      00513D 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0086
      00513E                        582 _ak820_outline_0086:
      00513E E0               [24]  583 	movx	a,@dptr
      00513F F9               [12]  584 	mov	r1,a
      005140 A3               [24]  585 	inc	dptr
      005141 E0               [24]  586 	movx	a,@dptr
      005142 FA               [12]  587 	mov	r2,a
      005143 A3               [24]  588 	inc	dptr
      005144 E0               [24]  589 	movx	a,@dptr
      005145 FB               [12]  590 	mov	r3,a
      005146 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0087
      005147                        595 _ak820_outline_0087:
      005147 E0               [24]  596 	movx	a,@dptr
      005148 FE               [12]  597 	mov	r6,a
      005149 A3               [24]  598 	inc	dptr
      00514A E0               [24]  599 	movx	a,@dptr
      00514B 8E 82            [24]  600 	mov	dpl,r6
      00514D F5 83            [12]  601 	mov	dph,a
      00514F 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0106
      005150                        606 _ak820_outline_0106:
      005150 74 02            [12]  607 	mov	a,#0x02
      005152 F0               [24]  608 	movx	@dptr,a
      005153 E4               [12]  609 	clr	a
      005154 A3               [24]  610 	inc	dptr
      005155 F0               [24]  611 	movx	@dptr,a
      005156 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0154
      005157                        616 _ak820_outline_0154:
      005157 F0               [24]  617 	movx	@dptr,a
      005158 EA               [12]  618 	mov	a,r2
      005159 A3               [24]  619 	inc	dptr
      00515A F0               [24]  620 	movx	@dptr,a
      00515B EB               [12]  621 	mov	a,r3
      00515C A3               [24]  622 	inc	dptr
      00515D 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0178
      00515E                        627 _ak820_outline_0178:
      00515E E4               [12]  628 	clr	a
      00515F F0               [24]  629 	movx	@dptr,a
      005160 A3               [24]  630 	inc	dptr
      005161 F0               [24]  631 	movx	@dptr,a
      005162 22               [24]  632 	ret
