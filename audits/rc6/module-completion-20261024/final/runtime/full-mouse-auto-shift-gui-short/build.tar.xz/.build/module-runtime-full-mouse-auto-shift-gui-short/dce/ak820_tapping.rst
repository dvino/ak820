                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000D                        552 _ak820_tapping_before_sloc0_1_0:
      00000D                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005AA                        562 _source_state:
      0005AA                        563 	.ds 130
      00062C                        564 _pending_time:
      00062C                        565 	.ds 2
      00062E                        566 _pending_code:
      00062E                        567 	.ds 2
      000630                        568 _ak820_tapping_source_PARM_1:
      000630                        569 	.ds 2
      000632                        570 _hold_PARM_2:
      000632                        571 	.ds 1
      000633                        572 _hold_code_10000_603:
      000633                        573 	.ds 2
      000635                        574 _hold_mods_30000_606:
      000635                        575 	.ds 1
      000636                        576 _commit_pending_id_10000_612:
      000636                        577 	.ds 1
      000637                        578 _ak820_tapping_before_event_10000_613:
      000637                        579 	.ds 2
      000639                        580 _ak820_tapping_process_record_10000_624:
      000639                        581 	.ds 2
      00063B                        582 _ak820_tapping_process_code_10000_625:
      00063B                        583 	.ds 2
      00063D                        584 _ak820_tapping_process_sc_mods_10000_625:
      00063D                        585 	.ds 1
      00063E                        586 _ak820_oneshot_mods::
      00063E                        587 	.ds 1
      00063F                        588 _ak820_oneshot_consumed::
      00063F                        589 	.ds 1
      000640                        590 _ak820_oneshot_process_PARM_2:
      000640                        591 	.ds 1
      000641                        592 _ak820_oneshot_process_PARM_3:
      000641                        593 	.ds 1
      000642                        594 _ak820_oneshot_process_code_10000_650:
      000642                        595 	.ds 2
      000644                        596 _ak820_oneshot_process_mods_10000_651:
      000644                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000DB2                        606 _pending:
      000DB2                        607 	.ds 1
      000DB3                        608 _ak820_oneshot_target::
      000DB3                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0045A1                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0045A1 90 06 31         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0045A4 E0               [24]  656 	movx	a,@dptr
      0045A5 FF               [12]  657 	mov	r7,a
      0045A6 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0045A9                        659 00147$:
      0045A9 50 14            [24]  660 	jnc	00102$
      0045AB 90 06 30         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0045AE E0               [24]  662 	movx	a,@dptr
      0045AF FE               [12]  663 	mov	r6,a
      0045B0 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0045B3                        665 00149$:
      0045B3 50 0A            [24]  666 	jnc	00102$
      0045B5 8F 05            [24]  667 	mov	ar5,r7
      0045B7 ED               [12]  668 	mov	a,r5
      0045B8 12 3A D0         [24]  669 	lcall	_ak820_outline_0186
      0045BB 2E               [12]  670 	add	a,r6
      0045BC F5 82            [12]  671 	mov	dpl,a
      0045BE 22               [24]  672 	ret
      0045BF                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      0045BF 90 06 30         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0045C2 E0               [24]  676 	movx	a,@dptr
      0045C3 FE               [12]  677 	mov	r6,a
      0045C4 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0045C7                        679 00151$:
      0045C7 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0045C9 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0045CC 75 82 80         [24]  683 	mov	dpl, #0x80
      0045CF 22               [24]  684 	ret
      0045D0                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0045D0 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      0045D3 75 82 81         [24]  688 	mov	dpl, #0x81
      0045D6 22               [24]  689 	ret
      0045D7                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      0045D7 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      0045DA 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_603'
                                    700 ;mods          Allocated with name '_hold_mods_30000_606'
                                    701 ;layer         Allocated with name '_hold_layer_30000_609'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      0045DB                        707 _hold:
      0045DB 12 3A 83         [24]  708 	lcall	_ak820_outline_0103
      0045DE 90 06 33         [24]  709 	mov	dptr,#_hold_code_10000_603
      0045E1 12 3A 88         [24]  710 	lcall	_ak820_outline_0104
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      0045E4 90 06 33         [24]  712 	mov	dptr,#_hold_code_10000_603
      0045E7 12 3A 0B         [24]  713 	lcall	_ak820_outline_0010
      0045EA 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      0045EC 2D               [12]  715 	add	a,r5
      0045ED 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      0045EF 8F 05            [24]  718 	mov	ar5,r7
      0045F1 53 05 1F         [24]  719 	anl	ar5,#0x1f
      0045F4 90 06 35         [24]  720 	mov	dptr,#_hold_mods_30000_606
      0045F7 ED               [12]  721 	mov	a,r5
      0045F8 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      0045F9 ED               [12]  724 	mov	a,r5
      0045FA 30 E4 08         [24]  725 	jnb	acc.4,00102$
      0045FD ED               [12]  726 	mov	a,r5
      0045FE C4               [12]  727 	swap	a
      0045FF 54 F0            [12]  728 	anl	a,#0xf0
      004601 90 06 35         [24]  729 	mov	dptr,#_hold_mods_30000_606
      004604 F0               [24]  730 	movx	@dptr,a
      004605                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004605 90 06 32         [24]  733 	mov	dptr,#_hold_PARM_2
      004608 E0               [24]  734 	movx	a,@dptr
      004609 60 09            [24]  735 	jz	00104$
      00460B 90 06 35         [24]  736 	mov	dptr,#_hold_mods_30000_606
      00460E E0               [24]  737 	movx	a,@dptr
      00460F F5 82            [12]  738 	mov	dpl,a
      004611 02 7A 9D         [24]  739 	ljmp	_register_mods
      004614                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004614 90 06 35         [24]  742 	mov	dptr,#_hold_mods_30000_606
      004617 E0               [24]  743 	movx	a,@dptr
      004618 F5 82            [12]  744 	mov	dpl,a
      00461A 02 7A B1         [24]  745 	ljmp	_unregister_mods
      00461D                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      00461D 8F 06            [24]  748 	mov	ar6,r7
      00461F 74 0F            [12]  749 	mov	a,#0x0f
      004621 5E               [12]  750 	anl	a,r6
      004622 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004623 90 06 32         [24]  753 	mov	dptr,#_hold_PARM_2
      004626 E0               [24]  754 	movx	a,@dptr
      004627 60 05            [24]  755 	jz	00107$
      004629 8F 82            [24]  756 	mov	dpl, r7
      00462B 02 7C 64         [24]  757 	ljmp	_layer_hold_on
      00462E                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      00462E 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004630 02 7C 9B         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_612'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004633                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004633 90 0D B2         [24]  774 	mov	dptr,#_pending
      004636 E0               [24]  775 	movx	a,@dptr
      004637 90 06 36         [24]  776 	mov	dptr,#_commit_pending_id_10000_612
      00463A F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      00463B 12 4A B0         [24]  779 	lcall	_ak820_outline_0153
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      00463E 90 06 36         [24]  781 	mov	dptr,#_commit_pending_id_10000_612
      004641 E0               [24]  782 	movx	a,@dptr
      004642 24 AA            [12]  783 	add	a,#_source_state
      004644 FF               [12]  784 	mov	r7,a
      004645 E4               [12]  785 	clr	a
      004646 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      004648 FE               [12]  787 	mov	r6,a
      004649 12 45 86         [24]  788 	lcall	_ak820_outline_0156
      00464C E0               [24]  789 	movx	a,@dptr
      00464D FD               [12]  790 	mov	r5,a
      00464E 43 05 04         [24]  791 	orl	ar5,#0x04
      004651 12 45 86         [24]  792 	lcall	_ak820_outline_0156
      004654 ED               [12]  793 	mov	a,r5
      004655 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      004656 90 06 2E         [24]  796 	mov	dptr,#_pending_code
      004659 12 3A 40         [24]  797 	lcall	_ak820_outline_0050
      00465C 90 06 32         [24]  798 	mov	dptr,#_hold_PARM_2
      00465F 12 4A 7E         [24]  799 	lcall	_ak820_outline_0054
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004662 A1 DB            [12]  801 	ajmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_613'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_614'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      004664                        812 _ak820_tapping_before:
      004664 12 3A 83         [24]  813 	lcall	_ak820_outline_0103
      004667 90 06 37         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_613
      00466A 12 3A 88         [24]  815 	lcall	_ak820_outline_0104
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      00466D 90 06 37         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004670 12 3A 0B         [24]  818 	lcall	_ak820_outline_0010
      004673 12 4A 4B         [24]  819 	lcall	_ak820_outline_0021
      004676 C0 07            [24]  820 	push	ar7
      004678 C0 06            [24]  821 	push	ar6
      00467A 12 BA D9         [24]  822 	lcall	___memcpy
      00467D B1 A1            [12]  823 	acall	_ak820_tapping_source
      00467F AD 82            [24]  824 	mov	r5, dpl
      004681 D0 06            [24]  825 	pop	ar6
      004683 D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004685 90 0E 23         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      004688 E0               [24]  829 	movx	a,@dptr
      004689 60 21            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00468B 74 04            [12]  832 	mov	a,#0x04
      00468D 12 4A 40         [24]  833 	lcall	_ak820_outline_0012
      004690 60 16            [24]  834 	jz	00102$
      004692 BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      004695 80 11            [24]  836 	sjmp	00102$
      004697                        837 00218$:
      004697 74 05            [12]  838 	mov	a,#0x05
      004699 12 4A 40         [24]  839 	lcall	_ak820_outline_0012
      00469C 70 0A            [24]  840 	jnz	00102$
      00469E ED               [12]  841 	mov	a,r5
      00469F 12 4A 65         [24]  842 	lcall	_ak820_outline_0023
      0046A2 53 02 FD         [24]  843 	anl	ar2,#0xfd
      0046A5 12 4A A9         [24]  844 	lcall	_ak820_outline_0090
      0046A8                        845 00102$:
                                    846 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      0046A8 75 82 00         [24]  847 	mov	dpl, #0x00
      0046AB 22               [24]  848 	ret
      0046AC                        849 00106$:
                                    850 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      0046AC 90 0D B2         [24]  851 	mov	dptr,#_pending
      0046AF E0               [24]  852 	movx	a,@dptr
      0046B0 FC               [12]  853 	mov	r4,a
      0046B1 BC FF 02         [24]  854 	cjne	r4,#0xff,00220$
      0046B4 80 3A            [24]  855 	sjmp	00108$
      0046B6                        856 00220$:
      0046B6 12 3A 38         [24]  857 	lcall	_ak820_outline_0033
      0046B9 FA               [12]  858 	mov	r2,a
      0046BA A3               [24]  859 	inc	dptr
      0046BB E0               [24]  860 	movx	a,@dptr
      0046BC FB               [12]  861 	mov	r3,a
      0046BD 90 06 2C         [24]  862 	mov	dptr,#_pending_time
      0046C0 12 3A 7D         [24]  863 	lcall	_ak820_outline_0099
      0046C3 EA               [12]  864 	mov	a,r2
      0046C4 C3               [12]  865 	clr	c
      0046C5 98               [12]  866 	subb	a,r0
      0046C6 FA               [12]  867 	mov	r2,a
      0046C7 EB               [12]  868 	mov	a,r3
      0046C8 99               [12]  869 	subb	a,r1
      0046C9 FB               [12]  870 	mov	r3,a
      0046CA C3               [12]  871 	clr	c
      0046CB EA               [12]  872 	mov	a,r2
      0046CC 94 C8            [12]  873 	subb	a,#0xc8
      0046CE EB               [12]  874 	mov	a,r3
      0046CF 94 00            [12]  875 	subb	a,#0x00
      0046D1 50 17            [24]  876 	jnc	00107$
                                    877 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0046D3 74 04            [12]  878 	mov	a,#0x04
      0046D5 12 4A 73         [24]  879 	lcall	_ak820_outline_0045
      0046D8 60 16            [24]  880 	jz	00108$
      0046DA 12 39 EA         [24]  881 	lcall	_ak820_outline_0005
      0046DD 60 11            [24]  882 	jz	00108$
      0046DF BD FF 02         [24]  883 	cjne	r5,#0xff,00224$
      0046E2 80 06            [24]  884 	sjmp	00107$
      0046E4                        885 00224$:
      0046E4 ED               [12]  886 	mov	a,r5
      0046E5 B5 04 02         [24]  887 	cjne	a,ar4,00225$
      0046E8 80 06            [24]  888 	sjmp	00108$
      0046EA                        889 00225$:
      0046EA                        890 00107$:
      0046EA C0 05            [24]  891 	push	ar5
      0046EC D1 33            [12]  892 	acall	_commit_pending
      0046EE D0 05            [24]  893 	pop	ar5
      0046F0                        894 00108$:
                                    895 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      0046F0 90 06 37         [24]  896 	mov	dptr,#_ak820_tapping_before_event_10000_613
      0046F3 12 3A 40         [24]  897 	lcall	_ak820_outline_0050
      0046F6 74 04            [12]  898 	mov	a,#0x04
      0046F8 12 4A 40         [24]  899 	lcall	_ak820_outline_0012
      0046FB 60 03            [24]  900 	jz	00114$
      0046FD BD FF 04         [24]  901 	cjne	r5,#0xff,00115$
      004700                        902 00114$:
      004700 75 82 01         [24]  903 	mov	dpl, #0x01
      004703 22               [24]  904 	ret
      004704                        905 00115$:
                                    906 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004704 ED               [12]  907 	mov	a,r5
      004705 12 4A 9B         [24]  908 	lcall	_ak820_outline_0076
      004708 30 E1 13         [24]  909 	jnb	acc.1,00120$
                                    910 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00470B 74 05            [12]  911 	mov	a,#0x05
      00470D 2E               [12]  912 	add	a, r6
      00470E 12 3A 15         [24]  913 	lcall	_ak820_outline_0013
      004711 70 07            [24]  914 	jnz	00118$
      004713 74 FD            [12]  915 	mov	a,#0xfd
      004715 5B               [12]  916 	anl	a,r3
      004716 12 3A A0         [24]  917 	lcall	_ak820_outline_0121
      004719 F0               [24]  918 	movx	@dptr,a
      00471A                        919 00118$:
                                    920 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      00471A 75 82 00         [24]  921 	mov	dpl, #0x00
      00471D 22               [24]  922 	ret
      00471E                        923 00120$:
                                    924 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      00471E 12 45 0C         [24]  925 	lcall	_ak820_outline_0009
      004721 E0               [24]  926 	movx	a,@dptr
      004722 FF               [12]  927 	mov	r7,a
      004723 8B 06            [24]  928 	mov	ar6,r3
      004725 53 06 01         [24]  929 	anl	ar6,#0x01
      004728 EE               [12]  930 	mov	a,r6
      004729 B4 01 00         [24]  931 	cjne	a,#0x01,00231$
      00472C                        932 00231$:
      00472C B3               [12]  933 	cpl	c
      00472D 92 0D            [24]  934 	mov	_ak820_tapping_before_sloc0_1_0,c
      00472F 8F F0            [24]  935 	mov	b,r7
      004731 E4               [12]  936 	clr	a
      004732 33               [12]  937 	rlc	a
      004733 B5 F0 04         [24]  938 	cjne	a,b,00122$
      004736 75 82 00         [24]  939 	mov	dpl, #0x00
      004739 22               [24]  940 	ret
      00473A                        941 00122$:
                                    942 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      00473A 63 03 01         [24]  943 	xrl	ar3,#0x01
      00473D 12 3A A0         [24]  944 	lcall	_ak820_outline_0121
      004740 EB               [12]  945 	mov	a,r3
      004741 F0               [24]  946 	movx	@dptr,a
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004742 75 82 01         [24]  948 	mov	dpl, #0x01
                                    949 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004745 22               [24]  950 	ret
                                    951 ;------------------------------------------------------------
                                    952 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    953 ;------------------------------------------------------------
                                    954 ;record        Allocated with name '_ak820_tapping_process_record_10000_624'
                                    955 ;id            Allocated with name '_ak820_tapping_process_id_10000_625'
                                    956 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_625'
                                    957 ;code          Allocated with name '_ak820_tapping_process_code_10000_625'
                                    958 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_625'
                                    959 ;------------------------------------------------------------
                                    960 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function ak820_tapping_process
                                    963 ;	-----------------------------------------
      004746                        964 _ak820_tapping_process:
      004746 12 3A 83         [24]  965 	lcall	_ak820_outline_0103
      004749 90 06 39         [24]  966 	mov	dptr,#_ak820_tapping_process_record_10000_624
      00474C 12 3A 88         [24]  967 	lcall	_ak820_outline_0104
                                    968 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      00474F 90 06 3D         [24]  969 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004752 E4               [12]  970 	clr	a
      004753 F0               [24]  971 	movx	@dptr,a
                                    972 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004754 90 06 39         [24]  973 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004757 12 3A 40         [24]  974 	lcall	_ak820_outline_0050
      00475A 74 04            [12]  975 	mov	a,#0x04
      00475C 12 4A 35         [24]  976 	lcall	_ak820_outline_0011
      00475F 70 04            [24]  977 	jnz	00102$
      004761 75 82 01         [24]  978 	mov	dpl, #0x01
      004764 22               [24]  979 	ret
      004765                        980 00102$:
                                    981 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004765 8E 04            [24]  982 	mov	ar4,r6
      004767 8F 05            [24]  983 	mov	ar5,r7
      004769 12 4A 4B         [24]  984 	lcall	_ak820_outline_0021
      00476C C0 07            [24]  985 	push	ar7
      00476E C0 06            [24]  986 	push	ar6
      004770 12 BA D9         [24]  987 	lcall	___memcpy
      004773 B1 A1            [12]  988 	acall	_ak820_tapping_source
      004775 AD 82            [24]  989 	mov	r5, dpl
      004777 D0 06            [24]  990 	pop	ar6
      004779 D0 07            [24]  991 	pop	ar7
                                    992 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      00477B BD FF 04         [24]  993 	cjne	r5,#0xff,00104$
      00477E 75 82 01         [24]  994 	mov	dpl, #0x01
      004781 22               [24]  995 	ret
      004782                        996 00104$:
                                    997 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004782 74 07            [12]  998 	mov	a,#0x07
      004784 12 3A 27         [24]  999 	lcall	_ak820_outline_0016
      004787 FE               [12] 1000 	mov	r6,a
      004788 A3               [24] 1001 	inc	dptr
      004789 E0               [24] 1002 	movx	a,@dptr
      00478A FF               [12] 1003 	mov	r7,a
      00478B 90 06 3B         [24] 1004 	mov	dptr,#_ak820_tapping_process_code_10000_625
      00478E 12 4A 8E         [24] 1005 	lcall	_ak820_outline_0058
                                   1006 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004791 BE 1A 15         [24] 1007 	cjne	r6,#0x1a,00111$
      004794 BF 7C 12         [24] 1008 	cjne	r7,#0x7c,00111$
      004797 90 06 3B         [24] 1009 	mov	dptr,#_ak820_tapping_process_code_10000_625
      00479A 74 26            [12] 1010 	mov	a,#0x26
      00479C F0               [24] 1011 	movx	@dptr,a
      00479D 74 22            [12] 1012 	mov	a,#0x22
      00479F A3               [24] 1013 	inc	dptr
      0047A0 F0               [24] 1014 	movx	@dptr,a
      0047A1 90 06 3D         [24] 1015 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      0047A4 74 02            [12] 1016 	mov	a,#0x02
      0047A6 F0               [24] 1017 	movx	@dptr,a
      0047A7 80 28            [24] 1018 	sjmp	00112$
      0047A9                       1019 00111$:
                                   1020 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0047A9 BE 1B 15         [24] 1021 	cjne	r6,#0x1b,00108$
      0047AC BF 7C 12         [24] 1022 	cjne	r7,#0x7c,00108$
      0047AF 90 06 3B         [24] 1023 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0047B2 74 27            [12] 1024 	mov	a,#0x27
      0047B4 F0               [24] 1025 	movx	@dptr,a
      0047B5 74 32            [12] 1026 	mov	a,#0x32
      0047B7 A3               [24] 1027 	inc	dptr
      0047B8 F0               [24] 1028 	movx	@dptr,a
      0047B9 90 06 3D         [24] 1029 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      0047BC 74 20            [12] 1030 	mov	a,#0x20
      0047BE F0               [24] 1031 	movx	@dptr,a
      0047BF 80 10            [24] 1032 	sjmp	00112$
      0047C1                       1033 00108$:
                                   1034 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0047C1 BE 1E 0D         [24] 1035 	cjne	r6,#0x1e,00112$
      0047C4 BF 7C 0A         [24] 1036 	cjne	r7,#0x7c,00112$
      0047C7 90 06 3B         [24] 1037 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0047CA 74 28            [12] 1038 	mov	a,#0x28
      0047CC F0               [24] 1039 	movx	@dptr,a
      0047CD 74 32            [12] 1040 	mov	a,#0x32
      0047CF A3               [24] 1041 	inc	dptr
      0047D0 F0               [24] 1042 	movx	@dptr,a
      0047D1                       1043 00112$:
                                   1044 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      0047D1 90 06 3B         [24] 1045 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0047D4 E0               [24] 1046 	movx	a,@dptr
      0047D5 A3               [24] 1047 	inc	dptr
      0047D6 E0               [24] 1048 	movx	a,@dptr
      0047D7 FF               [12] 1049 	mov	r7,a
                                   1050 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      0047D8 BF 20 00         [24] 1051 	cjne	r7,#0x20,00242$
      0047DB                       1052 00242$:
      0047DB 40 05            [24] 1053 	jc	00113$
      0047DD BF 50 00         [24] 1054 	cjne	r7,#0x50,00244$
      0047E0                       1055 00244$:
      0047E0 40 04            [24] 1056 	jc	00114$
      0047E2                       1057 00113$:
      0047E2 75 82 01         [24] 1058 	mov	dpl, #0x01
      0047E5 22               [24] 1059 	ret
      0047E6                       1060 00114$:
                                   1061 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      0047E6 BF 40 00         [24] 1062 	cjne	r7,#0x40,00246$
      0047E9                       1063 00246$:
      0047E9 40 0C            [24] 1064 	jc	00117$
      0047EB 53 07 0F         [24] 1065 	anl	ar7,#0x0f
      0047EE BF 06 00         [24] 1066 	cjne	r7,#0x06,00248$
      0047F1                       1067 00248$:
      0047F1 40 04            [24] 1068 	jc	00117$
      0047F3 75 82 00         [24] 1069 	mov	dpl, #0x00
      0047F6 22               [24] 1070 	ret
      0047F7                       1071 00117$:
                                   1072 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      0047F7 90 06 39         [24] 1073 	mov	dptr,#_ak820_tapping_process_record_10000_624
      0047FA 12 3A 40         [24] 1074 	lcall	_ak820_outline_0050
      0047FD 74 05            [12] 1075 	mov	a,#0x05
      0047FF 12 4A 40         [24] 1076 	lcall	_ak820_outline_0012
      004802 60 1E            [24] 1077 	jz	00131$
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004804 90 0D B2         [24] 1079 	mov	dptr,#_pending
      004807 ED               [12] 1080 	mov	a,r5
      004808 12 45 16         [24] 1081 	lcall	_ak820_outline_0029
                                   1082 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      00480B 12 3A 40         [24] 1083 	lcall	_ak820_outline_0050
      00480E 90 06 2C         [24] 1084 	mov	dptr,#_pending_time
      004811 12 4A 8E         [24] 1085 	lcall	_ak820_outline_0058
                                   1086 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004814 90 06 3B         [24] 1087 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004817 12 3A 40         [24] 1088 	lcall	_ak820_outline_0050
      00481A 90 06 2E         [24] 1089 	mov	dptr,#_pending_code
      00481D 12 4A 8E         [24] 1090 	lcall	_ak820_outline_0058
      004820 01 BE            [12] 1091 	ajmp	00132$
      004822                       1092 00131$:
                                   1093 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004822 90 0D B2         [24] 1094 	mov	dptr,#_pending
      004825 E0               [24] 1095 	movx	a,@dptr
      004826 FF               [12] 1096 	mov	r7,a
      004827 ED               [12] 1097 	mov	a,r5
      004828 B5 07 02         [24] 1098 	cjne	a,ar7,00251$
      00482B 80 02            [24] 1099 	sjmp	00252$
      00482D                       1100 00251$:
      00482D 01 97            [24] 1101 	ajmp	00128$
      00482F                       1102 00252$:
                                   1103 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      00482F 12 4A B0         [24] 1104 	lcall	_ak820_outline_0153
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004832 90 06 3D         [24] 1106 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004835 E0               [24] 1107 	movx	a,@dptr
      004836 FF               [12] 1108 	mov	r7,a
      004837 E0               [24] 1109 	movx	a,@dptr
      004838 60 05            [24] 1110 	jz	00120$
      00483A 8F 82            [24] 1111 	mov	dpl, r7
      00483C 12 81 26         [24] 1112 	lcall	_add_owned_mods
      00483F                       1113 00120$:
                                   1114 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      00483F 90 06 39         [24] 1115 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004842 12 3A 40         [24] 1116 	lcall	_ak820_outline_0050
      004845 74 07            [12] 1117 	mov	a,#0x07
      004847 2E               [12] 1118 	add	a, r6
      004848 FB               [12] 1119 	mov	r3,a
      004849 E4               [12] 1120 	clr	a
      00484A 3F               [12] 1121 	addc	a, r7
      00484B FC               [12] 1122 	mov	r4,a
      00484C 90 06 3B         [24] 1123 	mov	dptr,#_ak820_tapping_process_code_10000_625
      00484F E0               [24] 1124 	movx	a,@dptr
      004850 F9               [12] 1125 	mov	r1,a
      004851 7A 00            [12] 1126 	mov	r2,#0x00
      004853 12 36 42         [24] 1127 	lcall	_ak820_outline_0122
      004856 E9               [12] 1128 	mov	a,r1
      004857 F0               [24] 1129 	movx	@dptr,a
      004858 EA               [12] 1130 	mov	a,r2
      004859 A3               [24] 1131 	inc	dptr
      00485A F0               [24] 1132 	movx	@dptr,a
                                   1133 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      00485B C3               [12] 1134 	clr	c
      00485C 04               [12] 1135 	inc	a
      00485D 99               [12] 1136 	subb	a,r1
      00485E 50 25            [24] 1137 	jnc	00122$
                                   1138 ;	free result
                                   1139 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004860 74 06            [12] 1140 	mov	a,#0x06
      004862 12 3A 27         [24] 1141 	lcall	_ak820_outline_0016
      004865 54 0F            [12] 1142 	anl	a,#0x0f
      004867 44 10            [12] 1143 	orl	a,#0x10
      004869 F0               [24] 1144 	movx	@dptr,a
                                   1145 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      00486A 12 45 0C         [24] 1146 	lcall	_ak820_outline_0009
      00486D 12 4A 7E         [24] 1147 	lcall	_ak820_outline_0054
                                   1148 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004870 12 75 0C         [24] 1149 	lcall	_process_record
                                   1150 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004873 90 06 39         [24] 1151 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004876 12 39 E0         [24] 1152 	lcall	_ak820_outline_0004
      004879 A3               [24] 1153 	inc	dptr
      00487A A3               [24] 1154 	inc	dptr
      00487B A3               [24] 1155 	inc	dptr
      00487C A3               [24] 1156 	inc	dptr
      00487D A3               [24] 1157 	inc	dptr
      00487E E4               [12] 1158 	clr	a
      00487F 12 45 42         [24] 1159 	lcall	_ak820_outline_0060
                                   1160 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004882 12 75 0C         [24] 1161 	lcall	_process_record
      004885                       1162 00122$:
                                   1163 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004885 90 06 3D         [24] 1164 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004888 E0               [24] 1165 	movx	a,@dptr
      004889 FF               [12] 1166 	mov	r7,a
      00488A E0               [24] 1167 	movx	a,@dptr
      00488B 60 31            [24] 1168 	jz	00132$
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      00488D 8F 82            [24] 1170 	mov	dpl, r7
      00488F 12 81 35         [24] 1171 	lcall	_del_owned_mods
                                   1172 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004892 12 84 5C         [24] 1173 	lcall	_send_keyboard_report
      004895 80 27            [24] 1174 	sjmp	00132$
      004897                       1175 00128$:
                                   1176 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004897 ED               [12] 1177 	mov	a,r5
      004898 24 AA            [12] 1178 	add	a, #_source_state
      00489A FE               [12] 1179 	mov	r6,a
      00489B E4               [12] 1180 	clr	a
      00489C 34 05            [12] 1181 	addc	a, #(_source_state >> 8)
      00489E FF               [12] 1182 	mov	r7,a
      00489F 12 3A 77         [24] 1183 	lcall	_ak820_outline_0097
      0048A2 FD               [12] 1184 	mov	r5,a
      0048A3 30 E2 18         [24] 1185 	jnb	acc.2,00132$
                                   1186 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      0048A6 53 05 FB         [24] 1187 	anl	ar5,#0xfb
      0048A9 12 45 60         [24] 1188 	lcall	_ak820_outline_0116
      0048AC ED               [12] 1189 	mov	a,r5
      0048AD F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      0048AE 90 06 3B         [24] 1192 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0048B1 12 3A 40         [24] 1193 	lcall	_ak820_outline_0050
      0048B4 90 06 32         [24] 1194 	mov	dptr,#_hold_PARM_2
      0048B7 E4               [12] 1195 	clr	a
      0048B8 12 45 42         [24] 1196 	lcall	_ak820_outline_0060
      0048BB 12 45 DB         [24] 1197 	lcall	_hold
      0048BE                       1198 00132$:
                                   1199 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      0048BE 75 82 00         [24] 1200 	mov	dpl, #0x00
                                   1201 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      0048C1 22               [24] 1202 	ret
                                   1203 ;------------------------------------------------------------
                                   1204 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1205 ;------------------------------------------------------------
                                   1206 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_648'
                                   1207 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_649'
                                   1208 ;------------------------------------------------------------
                                   1209 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1210 ;	-----------------------------------------
                                   1211 ;	 function ak820_tapping_cancel
                                   1212 ;	-----------------------------------------
      0048C2                       1213 _ak820_tapping_cancel:
                                   1214 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      0048C2 12 4A B0         [24] 1215 	lcall	_ak820_outline_0153
                                   1216 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0048C5 7F 00            [12] 1217 	mov	r7,#0x00
      0048C7                       1218 00103$:
      0048C7 BF 82 00         [24] 1219 	cjne	r7,#0x82,00122$
      0048CA                       1220 00122$:
      0048CA 50 1D            [24] 1221 	jnc	00105$
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      0048CC EF               [12] 1223 	mov	a,r7
      0048CD 24 AA            [12] 1224 	add	a, #_source_state
      0048CF FD               [12] 1225 	mov	r5,a
      0048D0 E4               [12] 1226 	clr	a
      0048D1 34 05            [12] 1227 	addc	a, #(_source_state >> 8)
      0048D3 12 4A 86         [24] 1228 	lcall	_ak820_outline_0056
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      0048D6 74 02            [12] 1230 	mov	a,#0x02
      0048D8 5C               [12] 1231 	anl	a,r4
      0048D9 FB               [12] 1232 	mov	r3,a
      0048DA 53 04 01         [24] 1233 	anl	ar4,#0x01
      0048DD EC               [12] 1234 	mov	a,r4
      0048DE 2C               [12] 1235 	add	a,r4
      0048DF 42 03            [12] 1236 	orl	ar3,a
      0048E1 12 3A AA         [24] 1237 	lcall	_ak820_outline_0131
      0048E4 EB               [12] 1238 	mov	a,r3
      0048E5 F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0048E6 0F               [12] 1241 	inc	r7
      0048E7 80 DE            [24] 1242 	sjmp	00103$
      0048E9                       1243 00105$:
                                   1244 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      0048E9 22               [24] 1245 	ret
                                   1246 ;------------------------------------------------------------
                                   1247 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1248 ;------------------------------------------------------------
                                   1249 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1250 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1251 ;code          Allocated with name '_ak820_oneshot_process_code_10000_650'
                                   1252 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_651'
                                   1253 ;i             Allocated with name '_ak820_oneshot_process_i_40000_666'
                                   1254 ;------------------------------------------------------------
                                   1255 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1256 ;	-----------------------------------------
                                   1257 ;	 function ak820_oneshot_process
                                   1258 ;	-----------------------------------------
      0048EA                       1259 _ak820_oneshot_process:
      0048EA 12 3A 83         [24] 1260 	lcall	_ak820_outline_0103
      0048ED 90 06 42         [24] 1261 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      0048F0 12 3A 88         [24] 1262 	lcall	_ak820_outline_0104
                                   1263 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      0048F3 90 06 40         [24] 1264 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0048F6 E0               [24] 1265 	movx	a,@dptr
      0048F7 FF               [12] 1266 	mov	r7,a
      0048F8 BF FF 02         [24] 1267 	cjne	r7,#0xff,00265$
      0048FB 80 07            [24] 1268 	sjmp	00101$
      0048FD                       1269 00265$:
      0048FD 12 A5 18         [24] 1270 	lcall	_get_repeat_key_count
      004900 E5 82            [12] 1271 	mov	a, dpl
      004902 60 04            [24] 1272 	jz	00102$
      004904                       1273 00101$:
      004904 75 82 01         [24] 1274 	mov	dpl, #0x01
      004907 22               [24] 1275 	ret
      004908                       1276 00102$:
                                   1277 ;	keyboards/ajazz/ak820/ak820_tapping.c:154: if (code >= QK_MAGIC_GUI_ON && code <= QK_MAGIC_TOGGLE_GUI) return true;
      004908 90 06 42         [24] 1278 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      00490B 12 45 4E         [24] 1279 	lcall	_ak820_outline_0096
      00490E C3               [12] 1280 	clr	c
      00490F ED               [12] 1281 	mov	a,r5
      004910 94 09            [12] 1282 	subb	a,#0x09
      004912 EE               [12] 1283 	mov	a,r6
      004913 94 70            [12] 1284 	subb	a,#0x70
      004915 40 0C            [24] 1285 	jc	00105$
      004917 74 0B            [12] 1286 	mov	a,#0x0b
      004919 9D               [12] 1287 	subb	a,r5
      00491A 74 70            [12] 1288 	mov	a,#0x70
      00491C 9E               [12] 1289 	subb	a,r6
      00491D 40 04            [24] 1290 	jc	00105$
                                   1291 ;	free result
      00491F 75 82 01         [24] 1292 	mov	dpl, #0x01
      004922 22               [24] 1293 	ret
      004923                       1294 00105$:
                                   1295 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004923 90 06 42         [24] 1296 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004926 E0               [24] 1297 	movx	a,@dptr
      004927 FB               [12] 1298 	mov	r3,a
      004928 A3               [24] 1299 	inc	dptr
      004929 E0               [24] 1300 	movx	a,@dptr
      00492A F9               [12] 1301 	mov	r1,a
      00492B B9 52 02         [24] 1302 	cjne	r1,#0x52,00269$
      00492E 80 02            [24] 1303 	sjmp	00270$
      004930                       1304 00269$:
      004930 21 D5            [12] 1305 	ajmp	00119$
      004932                       1306 00270$:
      004932 8B 02            [24] 1307 	mov	ar2,r3
      004934 53 02 E0         [24] 1308 	anl	ar2,#0xe0
      004937 BA A0 02         [24] 1309 	cjne	r2,#0xa0,00271$
      00493A 80 02            [24] 1310 	sjmp	00272$
      00493C                       1311 00271$:
      00493C 21 D5            [12] 1312 	ajmp	00119$
      00493E                       1313 00272$:
                                   1314 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      00493E 8B 02            [24] 1315 	mov	ar2,r3
      004940 53 02 0F         [24] 1316 	anl	ar2,#0x0f
      004943 90 06 44         [24] 1317 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004946 EA               [12] 1318 	mov	a,r2
      004947 F0               [24] 1319 	movx	@dptr,a
                                   1320 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004948 EB               [12] 1321 	mov	a,r3
      004949 30 E4 08         [24] 1322 	jnb	acc.4,00108$
      00494C EA               [12] 1323 	mov	a,r2
      00494D C4               [12] 1324 	swap	a
      00494E 54 F0            [12] 1325 	anl	a,#0xf0
      004950 90 06 44         [24] 1326 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004953 F0               [24] 1327 	movx	@dptr,a
      004954                       1328 00108$:
                                   1329 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004954 90 06 41         [24] 1330 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004957 E0               [24] 1331 	movx	a,@dptr
      004958 60 2E            [24] 1332 	jz	00116$
                                   1333 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      00495A EF               [12] 1334 	mov	a,r7
      00495B 12 4A 65         [24] 1335 	lcall	_ak820_outline_0023
      00495E 43 02 08         [24] 1336 	orl	ar2,#0x08
      004961 12 4A A9         [24] 1337 	lcall	_ak820_outline_0090
                                   1338 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004964 53 02 EF         [24] 1339 	anl	ar2,#0xef
      004967 12 4A A9         [24] 1340 	lcall	_ak820_outline_0090
                                   1341 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      00496A 90 0D B3         [24] 1342 	mov	dptr,#_ak820_oneshot_target
      00496D E0               [24] 1343 	movx	a,@dptr
      00496E FA               [12] 1344 	mov	r2,a
      00496F BA FF 02         [24] 1345 	cjne	r2,#0xff,00275$
      004972 80 09            [24] 1346 	sjmp	00110$
      004974                       1347 00275$:
      004974 12 4A 94         [24] 1348 	lcall	_ak820_outline_0064
      004977 43 02 10         [24] 1349 	orl	ar2,#0x10
      00497A 12 4A A9         [24] 1350 	lcall	_ak820_outline_0090
      00497D                       1351 00110$:
                                   1352 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      00497D 90 06 44         [24] 1353 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004980 E0               [24] 1354 	movx	a,@dptr
      004981 F5 82            [12] 1355 	mov	dpl,a
      004983 12 7A 9D         [24] 1356 	lcall	_register_mods
      004986 80 49            [24] 1357 	sjmp	00117$
      004988                       1358 00116$:
                                   1359 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004988 EF               [12] 1360 	mov	a,r7
      004989 12 4A 65         [24] 1361 	lcall	_ak820_outline_0023
      00498C 30 E3 42         [24] 1362 	jnb	acc.3,00117$
                                   1363 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      00498F EA               [12] 1364 	mov	a,r2
      004990 20 E4 24         [24] 1365 	jb	acc.4,00112$
                                   1366 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004993 90 06 3E         [24] 1367 	mov	dptr,#_ak820_oneshot_mods
      004996 E0               [24] 1368 	movx	a,@dptr
      004997 F4               [12] 1369 	cpl	a
      004998 FA               [12] 1370 	mov	r2,a
      004999 90 06 44         [24] 1371 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      00499C E0               [24] 1372 	movx	a,@dptr
      00499D F9               [12] 1373 	mov	r1,a
      00499E 52 02            [12] 1374 	anl	ar2,a
      0049A0 8A 82            [24] 1375 	mov	dpl, r2
      0049A2 C0 04            [24] 1376 	push	ar4
      0049A4 C0 03            [24] 1377 	push	ar3
      0049A6 C0 01            [24] 1378 	push	ar1
      0049A8 12 81 26         [24] 1379 	lcall	_add_owned_mods
      0049AB D0 01            [24] 1380 	pop	ar1
      0049AD D0 03            [24] 1381 	pop	ar3
      0049AF D0 04            [24] 1382 	pop	ar4
                                   1383 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      0049B1 90 06 3E         [24] 1384 	mov	dptr,#_ak820_oneshot_mods
      0049B4 E0               [24] 1385 	movx	a,@dptr
      0049B5 49               [12] 1386 	orl	a,r1
      0049B6 F0               [24] 1387 	movx	@dptr,a
      0049B7                       1388 00112$:
                                   1389 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      0049B7 90 06 44         [24] 1390 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      0049BA E0               [24] 1391 	movx	a,@dptr
      0049BB F5 82            [12] 1392 	mov	dpl,a
      0049BD C0 04            [24] 1393 	push	ar4
      0049BF C0 03            [24] 1394 	push	ar3
      0049C1 12 7A B1         [24] 1395 	lcall	_unregister_mods
      0049C4 D0 03            [24] 1396 	pop	ar3
      0049C6 D0 04            [24] 1397 	pop	ar4
                                   1398 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      0049C8 12 4A 94         [24] 1399 	lcall	_ak820_outline_0064
      0049CB 53 02 E7         [24] 1400 	anl	ar2,#0xe7
      0049CE 12 4A A9         [24] 1401 	lcall	_ak820_outline_0090
      0049D1                       1402 00117$:
                                   1403 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      0049D1 75 82 00         [24] 1404 	mov	dpl, #0x00
      0049D4 22               [24] 1405 	ret
      0049D5                       1406 00119$:
                                   1407 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      0049D5 90 06 41         [24] 1408 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0049D8 E0               [24] 1409 	movx	a,@dptr
      0049D9 60 56            [24] 1410 	jz	00127$
      0049DB C3               [12] 1411 	clr	c
      0049DC 74 01            [12] 1412 	mov	a,#0x01
      0049DE 9D               [12] 1413 	subb	a,r5
      0049DF E4               [12] 1414 	clr	a
      0049E0 9E               [12] 1415 	subb	a,r6
      0049E1 50 4E            [24] 1416 	jnc	00127$
                                   1417 ;	free result
                                   1418 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      0049E3 C3               [12] 1419 	clr	c
      0049E4 ED               [12] 1420 	mov	a,r5
      0049E5 94 E0            [12] 1421 	subb	a,#0xe0
      0049E7 EE               [12] 1422 	mov	a,r6
      0049E8 94 00            [12] 1423 	subb	a,#0x00
      0049EA 40 07            [24] 1424 	jc	00132$
      0049EC 74 E7            [12] 1425 	mov	a,#0xe7
      0049EE 9D               [12] 1426 	subb	a,r5
      0049EF E4               [12] 1427 	clr	a
      0049F0 9E               [12] 1428 	subb	a,r6
      0049F1 50 3E            [24] 1429 	jnc	00127$
                                   1430 ;	free result
      0049F3                       1431 00132$:
                                   1432 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      0049F3 74 AE            [12] 1433 	mov	a,#0x100 - 0x52
      0049F5 2E               [12] 1434 	add	a,r6
      0049F6 50 09            [24] 1435 	jnc	00172$
      0049F8 C3               [12] 1436 	clr	c
      0049F9 74 DF            [12] 1437 	mov	a,#0xdf
      0049FB 9D               [12] 1438 	subb	a,r5
      0049FC 74 52            [12] 1439 	mov	a,#0x52
      0049FE 9E               [12] 1440 	subb	a,r6
      0049FF 50 30            [24] 1441 	jnc	00127$
                                   1442 ;	free result
                                   1443 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004A01                       1444 00172$:
      004A01 7E 00            [12] 1445 	mov	r6,#0x00
      004A03                       1446 00134$:
      004A03 BE 82 00         [24] 1447 	cjne	r6,#0x82,00284$
      004A06                       1448 00284$:
      004A06 50 12            [24] 1449 	jnc	00123$
                                   1450 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004A08 EE               [12] 1451 	mov	a,r6
      004A09 12 4A 9B         [24] 1452 	lcall	_ak820_outline_0076
      004A0C 30 E3 08         [24] 1453 	jnb	acc.3,00135$
      004A0F 43 03 10         [24] 1454 	orl	ar3,#0x10
      004A12 12 3A A0         [24] 1455 	lcall	_ak820_outline_0121
      004A15 EB               [12] 1456 	mov	a,r3
      004A16 F0               [24] 1457 	movx	@dptr,a
      004A17                       1458 00135$:
                                   1459 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004A17 0E               [12] 1460 	inc	r6
      004A18 80 E9            [24] 1461 	sjmp	00134$
      004A1A                       1462 00123$:
                                   1463 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004A1A 90 06 3E         [24] 1464 	mov	dptr,#_ak820_oneshot_mods
      004A1D E0               [24] 1465 	movx	a,@dptr
      004A1E FE               [12] 1466 	mov	r6,a
      004A1F E0               [24] 1467 	movx	a,@dptr
      004A20 60 0F            [24] 1468 	jz	00127$
                                   1469 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004A22 90 06 3F         [24] 1470 	mov	dptr,#_ak820_oneshot_consumed
      004A25 EE               [12] 1471 	mov	a,r6
      004A26 F0               [24] 1472 	movx	@dptr,a
                                   1473 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004A27 90 0D B3         [24] 1474 	mov	dptr,#_ak820_oneshot_target
      004A2A EF               [12] 1475 	mov	a,r7
      004A2B F0               [24] 1476 	movx	@dptr,a
                                   1477 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004A2C 90 06 3E         [24] 1478 	mov	dptr,#_ak820_oneshot_mods
      004A2F E4               [12] 1479 	clr	a
      004A30 F0               [24] 1480 	movx	@dptr,a
      004A31                       1481 00127$:
                                   1482 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004A31 75 82 01         [24] 1483 	mov	dpl, #0x01
                                   1484 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004A34 22               [24] 1485 	ret
                                   1486 	.area CSEG    (CODE)
                                   1487 	.area CONST   (CODE)
                                   1488 	.area XINIT   (CODE)
      00C3EB                       1489 __xinit__pending:
      00C3EB FF                    1490 	.db #0xff	; 255
      00C3EC                       1491 __xinit__ak820_oneshot_target:
      00C3EC FF                    1492 	.db #0xff	; 255
                                   1493 	.area CABS    (ABS,CODE)
                                   1494 
                                   1495 ; Experimental exact instruction outlining.
                                   1496 	.globl _ak820_outline_0004
                                   1497 	.globl _ak820_outline_0005
                                   1498 	.globl _ak820_outline_0009
                                   1499 	.globl _ak820_outline_0010
                                   1500 	.globl _ak820_outline_0011
                                   1501 	.globl _ak820_outline_0012
                                   1502 	.globl _ak820_outline_0013
                                   1503 	.globl _ak820_outline_0016
                                   1504 	.globl _ak820_outline_0021
                                   1505 	.globl _ak820_outline_0023
                                   1506 	.globl _ak820_outline_0029
                                   1507 	.globl _ak820_outline_0033
                                   1508 	.globl _ak820_outline_0045
                                   1509 	.globl _ak820_outline_0050
                                   1510 	.globl _ak820_outline_0054
                                   1511 	.globl _ak820_outline_0056
                                   1512 	.globl _ak820_outline_0058
                                   1513 	.globl _ak820_outline_0060
                                   1514 	.globl _ak820_outline_0064
                                   1515 	.globl _ak820_outline_0076
                                   1516 	.globl _ak820_outline_0090
                                   1517 	.globl _ak820_outline_0096
                                   1518 	.globl _ak820_outline_0097
                                   1519 	.globl _ak820_outline_0099
                                   1520 	.globl _ak820_outline_0103
                                   1521 	.globl _ak820_outline_0104
                                   1522 	.globl _ak820_outline_0116
                                   1523 	.globl _ak820_outline_0121
                                   1524 	.globl _ak820_outline_0122
                                   1525 	.globl _ak820_outline_0131
                                   1526 	.globl _ak820_outline_0153
                                   1527 	.globl _ak820_outline_0156
                                   1528 	.globl _ak820_outline_0186
                                   1529 
                                   1530 	.area CSEG (CODE)
                                   1531 ; function ak820_outline_0011
      004A35                       1532 _ak820_outline_0011:
      004A35 2E               [12] 1533 	add	a,r6
      004A36 FC               [12] 1534 	mov	r4,a
      004A37 E4               [12] 1535 	clr	a
      004A38 3F               [12] 1536 	addc	a,r7
      004A39 FD               [12] 1537 	mov	r5,a
      004A3A 8C 82            [24] 1538 	mov	dpl,r4
      004A3C 8D 83            [24] 1539 	mov	dph,r5
      004A3E E0               [24] 1540 	movx	a,@dptr
      004A3F 22               [24] 1541 	ret
                                   1542 
                                   1543 	.area CSEG (CODE)
                                   1544 ; function ak820_outline_0012
      004A40                       1545 _ak820_outline_0012:
      004A40 2E               [12] 1546 	add	a,r6
      004A41 FB               [12] 1547 	mov	r3,a
      004A42 E4               [12] 1548 	clr	a
      004A43 3F               [12] 1549 	addc	a,r7
      004A44 FC               [12] 1550 	mov	r4,a
      004A45 8B 82            [24] 1551 	mov	dpl,r3
      004A47 8C 83            [24] 1552 	mov	dph,r4
      004A49 E0               [24] 1553 	movx	a,@dptr
      004A4A 22               [24] 1554 	ret
                                   1555 
                                   1556 	.area CSEG (CODE)
                                   1557 ; function ak820_outline_0021
      004A4B                       1558 _ak820_outline_0021:
      004A4B 90 0D A1         [24] 1559 	mov	dptr,#___memcpy_PARM_2
      004A4E EC               [12] 1560 	mov	a,r4
      004A4F F0               [24] 1561 	movx	@dptr,a
      004A50 ED               [12] 1562 	mov	a,r5
      004A51 A3               [24] 1563 	inc	dptr
      004A52 F0               [24] 1564 	movx	@dptr,a
      004A53 E4               [12] 1565 	clr	a
      004A54 A3               [24] 1566 	inc	dptr
      004A55 F0               [24] 1567 	movx	@dptr,a
      004A56 90 0D A4         [24] 1568 	mov	dptr,#___memcpy_PARM_3
      004A59 74 02            [12] 1569 	mov	a,#0x02
      004A5B F0               [24] 1570 	movx	@dptr,a
      004A5C E4               [12] 1571 	clr	a
      004A5D A3               [24] 1572 	inc	dptr
      004A5E F0               [24] 1573 	movx	@dptr,a
      004A5F 90 06 30         [24] 1574 	mov	dptr,#_ak820_tapping_source_PARM_1
      004A62 F5 F0            [12] 1575 	mov	b,a
      004A64 22               [24] 1576 	ret
                                   1577 
                                   1578 	.area CSEG (CODE)
                                   1579 ; function ak820_outline_0023
      004A65                       1580 _ak820_outline_0023:
      004A65 24 AA            [12] 1581 	add	a,#_source_state
      004A67 FB               [12] 1582 	mov	r3,a
      004A68 E4               [12] 1583 	clr	a
      004A69 34 05            [12] 1584 	addc	a,#(_source_state>>8)
      004A6B FC               [12] 1585 	mov	r4,a
      004A6C 8B 82            [24] 1586 	mov	dpl,r3
      004A6E 8C 83            [24] 1587 	mov	dph,r4
      004A70 E0               [24] 1588 	movx	a,@dptr
      004A71 FA               [12] 1589 	mov	r2,a
      004A72 22               [24] 1590 	ret
                                   1591 
                                   1592 	.area CSEG (CODE)
                                   1593 ; function ak820_outline_0045
      004A73                       1594 _ak820_outline_0045:
      004A73 2E               [12] 1595 	add	a,r6
      004A74 FA               [12] 1596 	mov	r2,a
      004A75 E4               [12] 1597 	clr	a
      004A76 3F               [12] 1598 	addc	a,r7
      004A77 FB               [12] 1599 	mov	r3,a
      004A78 8A 82            [24] 1600 	mov	dpl,r2
      004A7A 8B 83            [24] 1601 	mov	dph,r3
      004A7C E0               [24] 1602 	movx	a,@dptr
      004A7D 22               [24] 1603 	ret
                                   1604 
                                   1605 	.area CSEG (CODE)
                                   1606 ; function ak820_outline_0054
      004A7E                       1607 _ak820_outline_0054:
      004A7E 74 01            [12] 1608 	mov	a,#0x01
      004A80 F0               [24] 1609 	movx	@dptr,a
      004A81 8E 82            [24] 1610 	mov	dpl,r6
      004A83 8F 83            [24] 1611 	mov	dph,r7
      004A85 22               [24] 1612 	ret
                                   1613 
                                   1614 	.area CSEG (CODE)
                                   1615 ; function ak820_outline_0056
      004A86                       1616 _ak820_outline_0056:
      004A86 FE               [12] 1617 	mov	r6,a
      004A87 8D 82            [24] 1618 	mov	dpl,r5
      004A89 8E 83            [24] 1619 	mov	dph,r6
      004A8B E0               [24] 1620 	movx	a,@dptr
      004A8C FC               [12] 1621 	mov	r4,a
      004A8D 22               [24] 1622 	ret
                                   1623 
                                   1624 	.area CSEG (CODE)
                                   1625 ; function ak820_outline_0058
      004A8E                       1626 _ak820_outline_0058:
      004A8E EE               [12] 1627 	mov	a,r6
      004A8F F0               [24] 1628 	movx	@dptr,a
      004A90 EF               [12] 1629 	mov	a,r7
      004A91 A3               [24] 1630 	inc	dptr
      004A92 F0               [24] 1631 	movx	@dptr,a
      004A93 22               [24] 1632 	ret
                                   1633 
                                   1634 	.area CSEG (CODE)
                                   1635 ; function ak820_outline_0064
      004A94                       1636 _ak820_outline_0064:
      004A94 8B 82            [24] 1637 	mov	dpl,r3
      004A96 8C 83            [24] 1638 	mov	dph,r4
      004A98 E0               [24] 1639 	movx	a,@dptr
      004A99 FA               [12] 1640 	mov	r2,a
      004A9A 22               [24] 1641 	ret
                                   1642 
                                   1643 	.area CSEG (CODE)
                                   1644 ; function ak820_outline_0076
      004A9B                       1645 _ak820_outline_0076:
      004A9B 24 AA            [12] 1646 	add	a,#_source_state
      004A9D FC               [12] 1647 	mov	r4,a
      004A9E E4               [12] 1648 	clr	a
      004A9F 34 05            [12] 1649 	addc	a,#(_source_state>>8)
      004AA1 FD               [12] 1650 	mov	r5,a
      004AA2 8C 82            [24] 1651 	mov	dpl,r4
      004AA4 8D 83            [24] 1652 	mov	dph,r5
      004AA6 E0               [24] 1653 	movx	a,@dptr
      004AA7 FB               [12] 1654 	mov	r3,a
      004AA8 22               [24] 1655 	ret
                                   1656 
                                   1657 	.area CSEG (CODE)
                                   1658 ; function ak820_outline_0090
      004AA9                       1659 _ak820_outline_0090:
      004AA9 8B 82            [24] 1660 	mov	dpl,r3
      004AAB 8C 83            [24] 1661 	mov	dph,r4
      004AAD EA               [12] 1662 	mov	a,r2
      004AAE F0               [24] 1663 	movx	@dptr,a
      004AAF 22               [24] 1664 	ret
                                   1665 
                                   1666 	.area CSEG (CODE)
                                   1667 ; function ak820_outline_0153
      004AB0                       1668 _ak820_outline_0153:
      004AB0 90 0D B2         [24] 1669 	mov	dptr,#_pending
      004AB3 74 FF            [12] 1670 	mov	a,#0xff
      004AB5 F0               [24] 1671 	movx	@dptr,a
      004AB6 22               [24] 1672 	ret
