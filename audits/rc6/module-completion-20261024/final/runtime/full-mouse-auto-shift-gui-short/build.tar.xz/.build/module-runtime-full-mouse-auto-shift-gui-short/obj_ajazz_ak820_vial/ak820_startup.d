ak820_startup.o: keyboards/ajazz/ak820/ak820_startup.c \
 keyboards/ajazz/ak820/config.h \
 .build/module-runtime-full-mouse-auto-shift-gui-short/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h
