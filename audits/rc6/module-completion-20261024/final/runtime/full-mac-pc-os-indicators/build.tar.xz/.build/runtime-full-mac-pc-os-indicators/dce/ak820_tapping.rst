                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000C                        552 _ak820_tapping_before_sloc0_1_0:
      00000C                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005A2                        562 _source_state:
      0005A2                        563 	.ds 130
      000624                        564 _pending_time:
      000624                        565 	.ds 2
      000626                        566 _pending_code:
      000626                        567 	.ds 2
      000628                        568 _ak820_tapping_source_PARM_1:
      000628                        569 	.ds 2
      00062A                        570 _hold_PARM_2:
      00062A                        571 	.ds 1
      00062B                        572 _hold_code_10000_602:
      00062B                        573 	.ds 2
      00062D                        574 _hold_mods_30000_605:
      00062D                        575 	.ds 1
      00062E                        576 _commit_pending_id_10000_611:
      00062E                        577 	.ds 1
      00062F                        578 _ak820_tapping_before_event_10000_612:
      00062F                        579 	.ds 2
      000631                        580 _ak820_tapping_process_record_10000_623:
      000631                        581 	.ds 2
      000633                        582 _ak820_tapping_process_code_10000_624:
      000633                        583 	.ds 2
      000635                        584 _ak820_tapping_process_sc_mods_10000_624:
      000635                        585 	.ds 1
      000636                        586 _ak820_oneshot_mods::
      000636                        587 	.ds 1
      000637                        588 _ak820_oneshot_consumed::
      000637                        589 	.ds 1
      000638                        590 _ak820_oneshot_process_PARM_2:
      000638                        591 	.ds 1
      000639                        592 _ak820_oneshot_process_PARM_3:
      000639                        593 	.ds 1
      00063A                        594 _ak820_oneshot_process_code_10000_649:
      00063A                        595 	.ds 2
      00063C                        596 _ak820_oneshot_process_mods_10000_650:
      00063C                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000D8C                        606 _pending:
      000D8C                        607 	.ds 1
      000D8D                        608 _ak820_oneshot_target::
      000D8D                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      004498                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004498 90 06 29         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      00449B E0               [24]  656 	movx	a,@dptr
      00449C FF               [12]  657 	mov	r7,a
      00449D BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0044A0                        659 00147$:
      0044A0 50 14            [24]  660 	jnc	00102$
      0044A2 90 06 28         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0044A5 E0               [24]  662 	movx	a,@dptr
      0044A6 FE               [12]  663 	mov	r6,a
      0044A7 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0044AA                        665 00149$:
      0044AA 50 0A            [24]  666 	jnc	00102$
      0044AC 8F 05            [24]  667 	mov	ar5,r7
      0044AE ED               [12]  668 	mov	a,r5
      0044AF 12 38 90         [24]  669 	lcall	_ak820_outline_0187
      0044B2 2E               [12]  670 	add	a,r6
      0044B3 F5 82            [12]  671 	mov	dpl,a
      0044B5 22               [24]  672 	ret
      0044B6                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      0044B6 90 06 28         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0044B9 E0               [24]  676 	movx	a,@dptr
      0044BA FE               [12]  677 	mov	r6,a
      0044BB BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0044BE                        679 00151$:
      0044BE 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0044C0 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0044C3 75 82 80         [24]  683 	mov	dpl, #0x80
      0044C6 22               [24]  684 	ret
      0044C7                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0044C7 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      0044CA 75 82 81         [24]  688 	mov	dpl, #0x81
      0044CD 22               [24]  689 	ret
      0044CE                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      0044CE 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      0044D1 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_602'
                                    700 ;mods          Allocated with name '_hold_mods_30000_605'
                                    701 ;layer         Allocated with name '_hold_layer_30000_608'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      0044D2                        707 _hold:
      0044D2 12 38 43         [24]  708 	lcall	_ak820_outline_0103
      0044D5 90 06 2B         [24]  709 	mov	dptr,#_hold_code_10000_602
      0044D8 12 38 48         [24]  710 	lcall	_ak820_outline_0104
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      0044DB 90 06 2B         [24]  712 	mov	dptr,#_hold_code_10000_602
      0044DE 12 37 CB         [24]  713 	lcall	_ak820_outline_0011
      0044E1 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      0044E3 2D               [12]  715 	add	a,r5
      0044E4 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      0044E6 8F 05            [24]  718 	mov	ar5,r7
      0044E8 53 05 1F         [24]  719 	anl	ar5,#0x1f
      0044EB 90 06 2D         [24]  720 	mov	dptr,#_hold_mods_30000_605
      0044EE ED               [12]  721 	mov	a,r5
      0044EF F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      0044F0 ED               [12]  724 	mov	a,r5
      0044F1 30 E4 08         [24]  725 	jnb	acc.4,00102$
      0044F4 ED               [12]  726 	mov	a,r5
      0044F5 C4               [12]  727 	swap	a
      0044F6 54 F0            [12]  728 	anl	a,#0xf0
      0044F8 90 06 2D         [24]  729 	mov	dptr,#_hold_mods_30000_605
      0044FB F0               [24]  730 	movx	@dptr,a
      0044FC                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      0044FC 90 06 2A         [24]  733 	mov	dptr,#_hold_PARM_2
      0044FF E0               [24]  734 	movx	a,@dptr
      004500 60 09            [24]  735 	jz	00104$
      004502 90 06 2D         [24]  736 	mov	dptr,#_hold_mods_30000_605
      004505 E0               [24]  737 	movx	a,@dptr
      004506 F5 82            [12]  738 	mov	dpl,a
      004508 02 77 9C         [24]  739 	ljmp	_register_mods
      00450B                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      00450B 90 06 2D         [24]  742 	mov	dptr,#_hold_mods_30000_605
      00450E E0               [24]  743 	movx	a,@dptr
      00450F F5 82            [12]  744 	mov	dpl,a
      004511 02 77 B0         [24]  745 	ljmp	_unregister_mods
      004514                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      004514 8F 06            [24]  748 	mov	ar6,r7
      004516 74 0F            [12]  749 	mov	a,#0x0f
      004518 5E               [12]  750 	anl	a,r6
      004519 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      00451A 90 06 2A         [24]  753 	mov	dptr,#_hold_PARM_2
      00451D E0               [24]  754 	movx	a,@dptr
      00451E 60 05            [24]  755 	jz	00107$
      004520 8F 82            [24]  756 	mov	dpl, r7
      004522 02 79 60         [24]  757 	ljmp	_layer_hold_on
      004525                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      004525 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004527 02 79 98         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_611'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      00452A                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      00452A 90 0D 8C         [24]  774 	mov	dptr,#_pending
      00452D E0               [24]  775 	movx	a,@dptr
      00452E 90 06 2E         [24]  776 	mov	dptr,#_commit_pending_id_10000_611
      004531 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004532 12 49 B1         [24]  779 	lcall	_ak820_outline_0151
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      004535 90 06 2E         [24]  781 	mov	dptr,#_commit_pending_id_10000_611
      004538 E0               [24]  782 	movx	a,@dptr
      004539 24 A2            [12]  783 	add	a,#_source_state
      00453B FF               [12]  784 	mov	r7,a
      00453C E4               [12]  785 	clr	a
      00453D 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      00453F FE               [12]  787 	mov	r6,a
      004540 12 43 B8         [24]  788 	lcall	_ak820_outline_0154
      004543 E0               [24]  789 	movx	a,@dptr
      004544 FD               [12]  790 	mov	r5,a
      004545 43 05 04         [24]  791 	orl	ar5,#0x04
      004548 12 43 B8         [24]  792 	lcall	_ak820_outline_0154
      00454B ED               [12]  793 	mov	a,r5
      00454C F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      00454D 90 06 26         [24]  796 	mov	dptr,#_pending_code
      004550 12 38 00         [24]  797 	lcall	_ak820_outline_0051
      004553 90 06 2A         [24]  798 	mov	dptr,#_hold_PARM_2
      004556 12 49 86         [24]  799 	lcall	_ak820_outline_0055
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004559 02 44 D2         [24]  801 	ljmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_612'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_613'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      00455C                        812 _ak820_tapping_before:
      00455C 12 38 43         [24]  813 	lcall	_ak820_outline_0103
      00455F 90 06 2F         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_612
      004562 12 38 48         [24]  815 	lcall	_ak820_outline_0104
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004565 90 06 2F         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_612
      004568 12 37 CB         [24]  818 	lcall	_ak820_outline_0011
      00456B 12 49 61         [24]  819 	lcall	_ak820_outline_0023
      00456E C0 07            [24]  820 	push	ar7
      004570 C0 06            [24]  821 	push	ar6
      004572 12 B8 A0         [24]  822 	lcall	___memcpy
      004575 12 44 98         [24]  823 	lcall	_ak820_tapping_source
      004578 AD 82            [24]  824 	mov	r5, dpl
      00457A D0 06            [24]  825 	pop	ar6
      00457C D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      00457E 90 0D FD         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      004581 E0               [24]  829 	movx	a,@dptr
      004582 60 29            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004584 74 04            [12]  832 	mov	a,#0x04
      004586 12 49 47         [24]  833 	lcall	_ak820_outline_0013
      004589 60 1E            [24]  834 	jz	00102$
      00458B BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      00458E 80 19            [24]  836 	sjmp	00102$
      004590                        837 00218$:
      004590 74 05            [12]  838 	mov	a,#0x05
      004592 12 49 47         [24]  839 	lcall	_ak820_outline_0013
      004595 70 12            [24]  840 	jnz	00102$
      004597 ED               [12]  841 	mov	a,r5
      004598 24 A2            [12]  842 	add	a, #_source_state
      00459A FB               [12]  843 	mov	r3,a
      00459B E4               [12]  844 	clr	a
      00459C 34 05            [12]  845 	addc	a, #(_source_state >> 8)
      00459E 12 49 8E         [24]  846 	lcall	_ak820_outline_0056
      0045A1 53 02 FD         [24]  847 	anl	ar2,#0xfd
      0045A4 12 33 FC         [24]  848 	lcall	_ak820_outline_0123
      0045A7 EA               [12]  849 	mov	a,r2
      0045A8 F0               [24]  850 	movx	@dptr,a
      0045A9                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      0045A9 75 82 00         [24]  853 	mov	dpl, #0x00
      0045AC 22               [24]  854 	ret
      0045AD                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      0045AD 90 0D 8C         [24]  857 	mov	dptr,#_pending
      0045B0 E0               [24]  858 	movx	a,@dptr
      0045B1 FC               [12]  859 	mov	r4,a
      0045B2 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      0045B5 80 3B            [24]  861 	sjmp	00108$
      0045B7                        862 00220$:
      0045B7 12 37 F8         [24]  863 	lcall	_ak820_outline_0034
      0045BA FA               [12]  864 	mov	r2,a
      0045BB A3               [24]  865 	inc	dptr
      0045BC E0               [24]  866 	movx	a,@dptr
      0045BD FB               [12]  867 	mov	r3,a
      0045BE 90 06 24         [24]  868 	mov	dptr,#_pending_time
      0045C1 12 38 3D         [24]  869 	lcall	_ak820_outline_0100
      0045C4 EA               [12]  870 	mov	a,r2
      0045C5 C3               [12]  871 	clr	c
      0045C6 98               [12]  872 	subb	a,r0
      0045C7 FA               [12]  873 	mov	r2,a
      0045C8 EB               [12]  874 	mov	a,r3
      0045C9 99               [12]  875 	subb	a,r1
      0045CA FB               [12]  876 	mov	r3,a
      0045CB C3               [12]  877 	clr	c
      0045CC EA               [12]  878 	mov	a,r2
      0045CD 94 C8            [12]  879 	subb	a,#0xc8
      0045CF EB               [12]  880 	mov	a,r3
      0045D0 94 00            [12]  881 	subb	a,#0x00
      0045D2 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0045D4 74 04            [12]  884 	mov	a,#0x04
      0045D6 12 49 7B         [24]  885 	lcall	_ak820_outline_0046
      0045D9 60 17            [24]  886 	jz	00108$
      0045DB 12 37 AA         [24]  887 	lcall	_ak820_outline_0005
      0045DE 60 12            [24]  888 	jz	00108$
      0045E0 BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      0045E3 80 06            [24]  890 	sjmp	00107$
      0045E5                        891 00224$:
      0045E5 ED               [12]  892 	mov	a,r5
      0045E6 B5 04 02         [24]  893 	cjne	a,ar4,00225$
      0045E9 80 07            [24]  894 	sjmp	00108$
      0045EB                        895 00225$:
      0045EB                        896 00107$:
      0045EB C0 05            [24]  897 	push	ar5
      0045ED 12 45 2A         [24]  898 	lcall	_commit_pending
      0045F0 D0 05            [24]  899 	pop	ar5
      0045F2                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      0045F2 90 06 2F         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_612
      0045F5 12 38 00         [24]  903 	lcall	_ak820_outline_0051
      0045F8 74 04            [12]  904 	mov	a,#0x04
      0045FA 12 49 47         [24]  905 	lcall	_ak820_outline_0013
      0045FD 60 03            [24]  906 	jz	00114$
      0045FF BD FF 04         [24]  907 	cjne	r5,#0xff,00115$
      004602                        908 00114$:
      004602 75 82 01         [24]  909 	mov	dpl, #0x01
      004605 22               [24]  910 	ret
      004606                        911 00115$:
                                    912 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004606 ED               [12]  913 	mov	a,r5
      004607 12 49 A3         [24]  914 	lcall	_ak820_outline_0078
      00460A 30 E1 13         [24]  915 	jnb	acc.1,00120$
                                    916 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00460D 74 05            [12]  917 	mov	a,#0x05
      00460F 2E               [12]  918 	add	a, r6
      004610 12 37 D5         [24]  919 	lcall	_ak820_outline_0014
      004613 70 07            [24]  920 	jnz	00118$
      004615 74 FD            [12]  921 	mov	a,#0xfd
      004617 5B               [12]  922 	anl	a,r3
      004618 12 38 60         [24]  923 	lcall	_ak820_outline_0122
      00461B F0               [24]  924 	movx	@dptr,a
      00461C                        925 00118$:
                                    926 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      00461C 75 82 00         [24]  927 	mov	dpl, #0x00
      00461F 22               [24]  928 	ret
      004620                        929 00120$:
                                    930 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004620 12 43 37         [24]  931 	lcall	_ak820_outline_0010
      004623 E0               [24]  932 	movx	a,@dptr
      004624 FF               [12]  933 	mov	r7,a
      004625 8B 06            [24]  934 	mov	ar6,r3
      004627 53 06 01         [24]  935 	anl	ar6,#0x01
      00462A EE               [12]  936 	mov	a,r6
      00462B B4 01 00         [24]  937 	cjne	a,#0x01,00231$
      00462E                        938 00231$:
      00462E B3               [12]  939 	cpl	c
      00462F 92 0C            [24]  940 	mov	_ak820_tapping_before_sloc0_1_0,c
      004631 8F F0            [24]  941 	mov	b,r7
      004633 E4               [12]  942 	clr	a
      004634 33               [12]  943 	rlc	a
      004635 B5 F0 04         [24]  944 	cjne	a,b,00122$
      004638 75 82 00         [24]  945 	mov	dpl, #0x00
      00463B 22               [24]  946 	ret
      00463C                        947 00122$:
                                    948 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      00463C 63 03 01         [24]  949 	xrl	ar3,#0x01
      00463F 12 38 60         [24]  950 	lcall	_ak820_outline_0122
      004642 EB               [12]  951 	mov	a,r3
      004643 F0               [24]  952 	movx	@dptr,a
                                    953 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004644 75 82 01         [24]  954 	mov	dpl, #0x01
                                    955 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004647 22               [24]  956 	ret
                                    957 ;------------------------------------------------------------
                                    958 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    959 ;------------------------------------------------------------
                                    960 ;record        Allocated with name '_ak820_tapping_process_record_10000_623'
                                    961 ;id            Allocated with name '_ak820_tapping_process_id_10000_624'
                                    962 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_624'
                                    963 ;code          Allocated with name '_ak820_tapping_process_code_10000_624'
                                    964 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_624'
                                    965 ;------------------------------------------------------------
                                    966 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    967 ;	-----------------------------------------
                                    968 ;	 function ak820_tapping_process
                                    969 ;	-----------------------------------------
      004648                        970 _ak820_tapping_process:
      004648 12 38 43         [24]  971 	lcall	_ak820_outline_0103
      00464B 90 06 31         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00464E 12 38 48         [24]  973 	lcall	_ak820_outline_0104
                                    974 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004651 90 06 35         [24]  975 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004654 E4               [12]  976 	clr	a
      004655 F0               [24]  977 	movx	@dptr,a
                                    978 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004656 90 06 31         [24]  979 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004659 12 38 00         [24]  980 	lcall	_ak820_outline_0051
      00465C 74 04            [12]  981 	mov	a,#0x04
      00465E 12 49 3C         [24]  982 	lcall	_ak820_outline_0012
      004661 70 04            [24]  983 	jnz	00102$
      004663 75 82 01         [24]  984 	mov	dpl, #0x01
      004666 22               [24]  985 	ret
      004667                        986 00102$:
                                    987 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004667 8E 04            [24]  988 	mov	ar4,r6
      004669 8F 05            [24]  989 	mov	ar5,r7
      00466B 12 49 61         [24]  990 	lcall	_ak820_outline_0023
      00466E C0 07            [24]  991 	push	ar7
      004670 C0 06            [24]  992 	push	ar6
      004672 12 B8 A0         [24]  993 	lcall	___memcpy
      004675 12 44 98         [24]  994 	lcall	_ak820_tapping_source
      004678 AD 82            [24]  995 	mov	r5, dpl
      00467A D0 06            [24]  996 	pop	ar6
      00467C D0 07            [24]  997 	pop	ar7
                                    998 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      00467E BD FF 04         [24]  999 	cjne	r5,#0xff,00104$
      004681 75 82 01         [24] 1000 	mov	dpl, #0x01
      004684 22               [24] 1001 	ret
      004685                       1002 00104$:
                                   1003 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004685 74 07            [12] 1004 	mov	a,#0x07
      004687 12 37 E7         [24] 1005 	lcall	_ak820_outline_0017
      00468A FE               [12] 1006 	mov	r6,a
      00468B A3               [24] 1007 	inc	dptr
      00468C E0               [24] 1008 	movx	a,@dptr
      00468D FF               [12] 1009 	mov	r7,a
      00468E 90 06 33         [24] 1010 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004691 12 49 96         [24] 1011 	lcall	_ak820_outline_0059
                                   1012 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004694 BE 1A 15         [24] 1013 	cjne	r6,#0x1a,00111$
      004697 BF 7C 12         [24] 1014 	cjne	r7,#0x7c,00111$
      00469A 90 06 33         [24] 1015 	mov	dptr,#_ak820_tapping_process_code_10000_624
      00469D 74 26            [12] 1016 	mov	a,#0x26
      00469F F0               [24] 1017 	movx	@dptr,a
      0046A0 74 22            [12] 1018 	mov	a,#0x22
      0046A2 A3               [24] 1019 	inc	dptr
      0046A3 F0               [24] 1020 	movx	@dptr,a
      0046A4 90 06 35         [24] 1021 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0046A7 74 02            [12] 1022 	mov	a,#0x02
      0046A9 F0               [24] 1023 	movx	@dptr,a
      0046AA 80 28            [24] 1024 	sjmp	00112$
      0046AC                       1025 00111$:
                                   1026 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0046AC BE 1B 15         [24] 1027 	cjne	r6,#0x1b,00108$
      0046AF BF 7C 12         [24] 1028 	cjne	r7,#0x7c,00108$
      0046B2 90 06 33         [24] 1029 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0046B5 74 27            [12] 1030 	mov	a,#0x27
      0046B7 F0               [24] 1031 	movx	@dptr,a
      0046B8 74 32            [12] 1032 	mov	a,#0x32
      0046BA A3               [24] 1033 	inc	dptr
      0046BB F0               [24] 1034 	movx	@dptr,a
      0046BC 90 06 35         [24] 1035 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0046BF 74 20            [12] 1036 	mov	a,#0x20
      0046C1 F0               [24] 1037 	movx	@dptr,a
      0046C2 80 10            [24] 1038 	sjmp	00112$
      0046C4                       1039 00108$:
                                   1040 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0046C4 BE 1E 0D         [24] 1041 	cjne	r6,#0x1e,00112$
      0046C7 BF 7C 0A         [24] 1042 	cjne	r7,#0x7c,00112$
      0046CA 90 06 33         [24] 1043 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0046CD 74 28            [12] 1044 	mov	a,#0x28
      0046CF F0               [24] 1045 	movx	@dptr,a
      0046D0 74 32            [12] 1046 	mov	a,#0x32
      0046D2 A3               [24] 1047 	inc	dptr
      0046D3 F0               [24] 1048 	movx	@dptr,a
      0046D4                       1049 00112$:
                                   1050 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      0046D4 90 06 33         [24] 1051 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0046D7 E0               [24] 1052 	movx	a,@dptr
      0046D8 A3               [24] 1053 	inc	dptr
      0046D9 E0               [24] 1054 	movx	a,@dptr
      0046DA FF               [12] 1055 	mov	r7,a
                                   1056 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      0046DB BF 20 00         [24] 1057 	cjne	r7,#0x20,00242$
      0046DE                       1058 00242$:
      0046DE 40 05            [24] 1059 	jc	00113$
      0046E0 BF 50 00         [24] 1060 	cjne	r7,#0x50,00244$
      0046E3                       1061 00244$:
      0046E3 40 04            [24] 1062 	jc	00114$
      0046E5                       1063 00113$:
      0046E5 75 82 01         [24] 1064 	mov	dpl, #0x01
      0046E8 22               [24] 1065 	ret
      0046E9                       1066 00114$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      0046E9 BF 40 00         [24] 1068 	cjne	r7,#0x40,00246$
      0046EC                       1069 00246$:
      0046EC 40 0C            [24] 1070 	jc	00117$
      0046EE 53 07 0F         [24] 1071 	anl	ar7,#0x0f
      0046F1 BF 06 00         [24] 1072 	cjne	r7,#0x06,00248$
      0046F4                       1073 00248$:
      0046F4 40 04            [24] 1074 	jc	00117$
      0046F6 75 82 00         [24] 1075 	mov	dpl, #0x00
      0046F9 22               [24] 1076 	ret
      0046FA                       1077 00117$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      0046FA 90 06 31         [24] 1079 	mov	dptr,#_ak820_tapping_process_record_10000_623
      0046FD 12 38 00         [24] 1080 	lcall	_ak820_outline_0051
      004700 74 05            [12] 1081 	mov	a,#0x05
      004702 12 49 47         [24] 1082 	lcall	_ak820_outline_0013
      004705 60 1F            [24] 1083 	jz	00131$
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004707 90 0D 8C         [24] 1085 	mov	dptr,#_pending
      00470A ED               [12] 1086 	mov	a,r5
      00470B 12 43 41         [24] 1087 	lcall	_ak820_outline_0030
                                   1088 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      00470E 12 38 00         [24] 1089 	lcall	_ak820_outline_0051
      004711 90 06 24         [24] 1090 	mov	dptr,#_pending_time
      004714 12 49 96         [24] 1091 	lcall	_ak820_outline_0059
                                   1092 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004717 90 06 33         [24] 1093 	mov	dptr,#_ak820_tapping_process_code_10000_624
      00471A 12 38 00         [24] 1094 	lcall	_ak820_outline_0051
      00471D 90 06 26         [24] 1095 	mov	dptr,#_pending_code
      004720 12 49 96         [24] 1096 	lcall	_ak820_outline_0059
      004723 02 47 C3         [24] 1097 	ljmp	00132$
      004726                       1098 00131$:
                                   1099 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004726 90 0D 8C         [24] 1100 	mov	dptr,#_pending
      004729 E0               [24] 1101 	movx	a,@dptr
      00472A FF               [12] 1102 	mov	r7,a
      00472B ED               [12] 1103 	mov	a,r5
      00472C B5 07 02         [24] 1104 	cjne	a,ar7,00251$
      00472F 80 03            [24] 1105 	sjmp	00252$
      004731                       1106 00251$:
      004731 02 47 9C         [24] 1107 	ljmp	00128$
      004734                       1108 00252$:
                                   1109 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004734 12 49 B1         [24] 1110 	lcall	_ak820_outline_0151
                                   1111 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004737 90 06 35         [24] 1112 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00473A E0               [24] 1113 	movx	a,@dptr
      00473B FF               [12] 1114 	mov	r7,a
      00473C E0               [24] 1115 	movx	a,@dptr
      00473D 60 05            [24] 1116 	jz	00120$
      00473F 8F 82            [24] 1117 	mov	dpl, r7
      004741 12 7E 35         [24] 1118 	lcall	_add_owned_mods
      004744                       1119 00120$:
                                   1120 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004744 90 06 31         [24] 1121 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004747 12 38 00         [24] 1122 	lcall	_ak820_outline_0051
      00474A 74 07            [12] 1123 	mov	a,#0x07
      00474C 2E               [12] 1124 	add	a, r6
      00474D FB               [12] 1125 	mov	r3,a
      00474E E4               [12] 1126 	clr	a
      00474F 3F               [12] 1127 	addc	a, r7
      004750 FC               [12] 1128 	mov	r4,a
      004751 90 06 33         [24] 1129 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004754 E0               [24] 1130 	movx	a,@dptr
      004755 F9               [12] 1131 	mov	r1,a
      004756 7A 00            [12] 1132 	mov	r2,#0x00
      004758 12 33 FC         [24] 1133 	lcall	_ak820_outline_0123
      00475B E9               [12] 1134 	mov	a,r1
      00475C F0               [24] 1135 	movx	@dptr,a
      00475D EA               [12] 1136 	mov	a,r2
      00475E A3               [24] 1137 	inc	dptr
      00475F F0               [24] 1138 	movx	@dptr,a
                                   1139 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004760 C3               [12] 1140 	clr	c
      004761 04               [12] 1141 	inc	a
      004762 99               [12] 1142 	subb	a,r1
      004763 50 25            [24] 1143 	jnc	00122$
                                   1144 ;	free result
                                   1145 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004765 74 06            [12] 1146 	mov	a,#0x06
      004767 12 37 E7         [24] 1147 	lcall	_ak820_outline_0017
      00476A 54 0F            [12] 1148 	anl	a,#0x0f
      00476C 44 10            [12] 1149 	orl	a,#0x10
      00476E F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      00476F 12 43 37         [24] 1152 	lcall	_ak820_outline_0010
      004772 12 49 86         [24] 1153 	lcall	_ak820_outline_0055
                                   1154 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004775 12 72 6B         [24] 1155 	lcall	_process_record
                                   1156 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004778 90 06 31         [24] 1157 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00477B 12 37 A0         [24] 1158 	lcall	_ak820_outline_0004
      00477E A3               [24] 1159 	inc	dptr
      00477F A3               [24] 1160 	inc	dptr
      004780 A3               [24] 1161 	inc	dptr
      004781 A3               [24] 1162 	inc	dptr
      004782 A3               [24] 1163 	inc	dptr
      004783 E4               [12] 1164 	clr	a
      004784 12 43 6D         [24] 1165 	lcall	_ak820_outline_0061
                                   1166 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004787 12 72 6B         [24] 1167 	lcall	_process_record
      00478A                       1168 00122$:
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      00478A 90 06 35         [24] 1170 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00478D E0               [24] 1171 	movx	a,@dptr
      00478E FF               [12] 1172 	mov	r7,a
      00478F E0               [24] 1173 	movx	a,@dptr
      004790 60 31            [24] 1174 	jz	00132$
                                   1175 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004792 8F 82            [24] 1176 	mov	dpl, r7
      004794 12 7E 45         [24] 1177 	lcall	_del_owned_mods
                                   1178 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004797 12 81 6F         [24] 1179 	lcall	_send_keyboard_report
      00479A 80 27            [24] 1180 	sjmp	00132$
      00479C                       1181 00128$:
                                   1182 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      00479C ED               [12] 1183 	mov	a,r5
      00479D 24 A2            [12] 1184 	add	a, #_source_state
      00479F FE               [12] 1185 	mov	r6,a
      0047A0 E4               [12] 1186 	clr	a
      0047A1 34 05            [12] 1187 	addc	a, #(_source_state >> 8)
      0047A3 FF               [12] 1188 	mov	r7,a
      0047A4 12 38 37         [24] 1189 	lcall	_ak820_outline_0098
      0047A7 FD               [12] 1190 	mov	r5,a
      0047A8 30 E2 18         [24] 1191 	jnb	acc.2,00132$
                                   1192 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      0047AB 53 05 FB         [24] 1193 	anl	ar5,#0xfb
      0047AE 12 43 92         [24] 1194 	lcall	_ak820_outline_0116
      0047B1 ED               [12] 1195 	mov	a,r5
      0047B2 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      0047B3 90 06 33         [24] 1198 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0047B6 12 38 00         [24] 1199 	lcall	_ak820_outline_0051
      0047B9 90 06 2A         [24] 1200 	mov	dptr,#_hold_PARM_2
      0047BC E4               [12] 1201 	clr	a
      0047BD 12 43 6D         [24] 1202 	lcall	_ak820_outline_0061
      0047C0 12 44 D2         [24] 1203 	lcall	_hold
      0047C3                       1204 00132$:
                                   1205 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      0047C3 75 82 00         [24] 1206 	mov	dpl, #0x00
                                   1207 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      0047C6 22               [24] 1208 	ret
                                   1209 ;------------------------------------------------------------
                                   1210 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1211 ;------------------------------------------------------------
                                   1212 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_647'
                                   1213 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_648'
                                   1214 ;------------------------------------------------------------
                                   1215 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1216 ;	-----------------------------------------
                                   1217 ;	 function ak820_tapping_cancel
                                   1218 ;	-----------------------------------------
      0047C7                       1219 _ak820_tapping_cancel:
                                   1220 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      0047C7 12 49 B1         [24] 1221 	lcall	_ak820_outline_0151
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0047CA 7F 00            [12] 1223 	mov	r7,#0x00
      0047CC                       1224 00103$:
      0047CC BF 82 00         [24] 1225 	cjne	r7,#0x82,00122$
      0047CF                       1226 00122$:
      0047CF 50 16            [24] 1227 	jnc	00105$
                                   1228 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      0047D1 12 49 52         [24] 1229 	lcall	_ak820_outline_0019
                                   1230 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      0047D4 74 02            [12] 1231 	mov	a,#0x02
      0047D6 5C               [12] 1232 	anl	a,r4
      0047D7 FB               [12] 1233 	mov	r3,a
      0047D8 53 04 01         [24] 1234 	anl	ar4,#0x01
      0047DB EC               [12] 1235 	mov	a,r4
      0047DC 2C               [12] 1236 	add	a,r4
      0047DD 42 03            [12] 1237 	orl	ar3,a
      0047DF 12 38 6A         [24] 1238 	lcall	_ak820_outline_0133
      0047E2 EB               [12] 1239 	mov	a,r3
      0047E3 F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0047E4 0F               [12] 1242 	inc	r7
      0047E5 80 E5            [24] 1243 	sjmp	00103$
      0047E7                       1244 00105$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      0047E7 22               [24] 1246 	ret
                                   1247 ;------------------------------------------------------------
                                   1248 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1249 ;------------------------------------------------------------
                                   1250 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1251 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1252 ;code          Allocated with name '_ak820_oneshot_process_code_10000_649'
                                   1253 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_650'
                                   1254 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1255 ;------------------------------------------------------------
                                   1256 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1257 ;	-----------------------------------------
                                   1258 ;	 function ak820_oneshot_process
                                   1259 ;	-----------------------------------------
      0047E8                       1260 _ak820_oneshot_process:
      0047E8 12 38 43         [24] 1261 	lcall	_ak820_outline_0103
      0047EB 90 06 3A         [24] 1262 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      0047EE 12 38 48         [24] 1263 	lcall	_ak820_outline_0104
                                   1264 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      0047F1 90 06 38         [24] 1265 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0047F4 E0               [24] 1266 	movx	a,@dptr
      0047F5 FF               [12] 1267 	mov	r7,a
      0047F6 BF FF 02         [24] 1268 	cjne	r7,#0xff,00266$
      0047F9 80 07            [24] 1269 	sjmp	00101$
      0047FB                       1270 00266$:
      0047FB 12 A2 96         [24] 1271 	lcall	_get_repeat_key_count
      0047FE E5 82            [12] 1272 	mov	a, dpl
      004800 60 04            [24] 1273 	jz	00102$
      004802                       1274 00101$:
      004802 75 82 01         [24] 1275 	mov	dpl, #0x01
      004805 22               [24] 1276 	ret
      004806                       1277 00102$:
                                   1278 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: if (code == QK_MAGIC_SWAP_ALT_GUI || code == QK_MAGIC_UNSWAP_ALT_GUI || code == QK_MAGIC_TOGGLE_ALT_GUI) return true;
      004806 90 06 3A         [24] 1279 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      004809 12 43 7A         [24] 1280 	lcall	_ak820_outline_0091
      00480C 8D 03            [24] 1281 	mov	ar3,r5
      00480E 8E 04            [24] 1282 	mov	ar4,r6
      004810 BB 14 05         [24] 1283 	cjne	r3,#0x14,00268$
      004813 BC 70 02         [24] 1284 	cjne	r4,#0x70,00268$
      004816 80 0E            [24] 1285 	sjmp	00104$
      004818                       1286 00268$:
      004818 BB 15 05         [24] 1287 	cjne	r3,#0x15,00269$
      00481B BC 70 02         [24] 1288 	cjne	r4,#0x70,00269$
      00481E 80 06            [24] 1289 	sjmp	00104$
      004820                       1290 00269$:
      004820 BB 16 07         [24] 1291 	cjne	r3,#0x16,00105$
      004823 BC 70 04         [24] 1292 	cjne	r4,#0x70,00105$
      004826                       1293 00104$:
      004826 75 82 01         [24] 1294 	mov	dpl, #0x01
      004829 22               [24] 1295 	ret
      00482A                       1296 00105$:
                                   1297 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      00482A 8E 03            [24] 1298 	mov	ar3,r6
      00482C BB 52 02         [24] 1299 	cjne	r3,#0x52,00272$
      00482F 80 03            [24] 1300 	sjmp	00273$
      004831                       1301 00272$:
      004831 02 48 D6         [24] 1302 	ljmp	00120$
      004834                       1303 00273$:
      004834 8D 04            [24] 1304 	mov	ar4,r5
      004836 53 04 E0         [24] 1305 	anl	ar4,#0xe0
      004839 BC A0 02         [24] 1306 	cjne	r4,#0xa0,00274$
      00483C 80 03            [24] 1307 	sjmp	00275$
      00483E                       1308 00274$:
      00483E 02 48 D6         [24] 1309 	ljmp	00120$
      004841                       1310 00275$:
                                   1311 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004841 8D 04            [24] 1312 	mov	ar4,r5
      004843 53 04 0F         [24] 1313 	anl	ar4,#0x0f
      004846 90 06 3C         [24] 1314 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004849 EC               [12] 1315 	mov	a,r4
      00484A F0               [24] 1316 	movx	@dptr,a
                                   1317 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      00484B ED               [12] 1318 	mov	a,r5
      00484C 30 E4 08         [24] 1319 	jnb	acc.4,00109$
      00484F EC               [12] 1320 	mov	a,r4
      004850 C4               [12] 1321 	swap	a
      004851 54 F0            [12] 1322 	anl	a,#0xf0
      004853 90 06 3C         [24] 1323 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004856 F0               [24] 1324 	movx	@dptr,a
      004857                       1325 00109$:
                                   1326 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004857 90 06 39         [24] 1327 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00485A E0               [24] 1328 	movx	a,@dptr
      00485B 60 2D            [24] 1329 	jz	00117$
                                   1330 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      00485D 12 49 52         [24] 1331 	lcall	_ak820_outline_0019
      004860 43 04 08         [24] 1332 	orl	ar4,#0x08
      004863 12 43 73         [24] 1333 	lcall	_ak820_outline_0065
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004866 53 04 EF         [24] 1335 	anl	ar4,#0xef
      004869 12 43 73         [24] 1336 	lcall	_ak820_outline_0065
                                   1337 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      00486C 90 0D 8D         [24] 1338 	mov	dptr,#_ak820_oneshot_target
      00486F E0               [24] 1339 	movx	a,@dptr
      004870 FC               [12] 1340 	mov	r4,a
      004871 BC FF 02         [24] 1341 	cjne	r4,#0xff,00278$
      004874 80 09            [24] 1342 	sjmp	00111$
      004876                       1343 00278$:
      004876 12 49 9C         [24] 1344 	lcall	_ak820_outline_0075
      004879 43 04 10         [24] 1345 	orl	ar4,#0x10
      00487C 12 43 73         [24] 1346 	lcall	_ak820_outline_0065
      00487F                       1347 00111$:
                                   1348 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      00487F 90 06 3C         [24] 1349 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004882 E0               [24] 1350 	movx	a,@dptr
      004883 F5 82            [12] 1351 	mov	dpl,a
      004885 12 77 9C         [24] 1352 	lcall	_register_mods
      004888 80 48            [24] 1353 	sjmp	00118$
      00488A                       1354 00117$:
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      00488A 12 49 52         [24] 1356 	lcall	_ak820_outline_0019
      00488D 30 E3 42         [24] 1357 	jnb	acc.3,00118$
                                   1358 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004890 EC               [12] 1359 	mov	a,r4
      004891 20 E4 24         [24] 1360 	jb	acc.4,00113$
                                   1361 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004894 90 06 36         [24] 1362 	mov	dptr,#_ak820_oneshot_mods
      004897 E0               [24] 1363 	movx	a,@dptr
      004898 F4               [12] 1364 	cpl	a
      004899 FC               [12] 1365 	mov	r4,a
      00489A 90 06 3C         [24] 1366 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      00489D E0               [24] 1367 	movx	a,@dptr
      00489E FB               [12] 1368 	mov	r3,a
      00489F 52 04            [12] 1369 	anl	ar4,a
      0048A1 8C 82            [24] 1370 	mov	dpl, r4
      0048A3 C0 06            [24] 1371 	push	ar6
      0048A5 C0 05            [24] 1372 	push	ar5
      0048A7 C0 03            [24] 1373 	push	ar3
      0048A9 12 7E 35         [24] 1374 	lcall	_add_owned_mods
      0048AC D0 03            [24] 1375 	pop	ar3
      0048AE D0 05            [24] 1376 	pop	ar5
      0048B0 D0 06            [24] 1377 	pop	ar6
                                   1378 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      0048B2 90 06 36         [24] 1379 	mov	dptr,#_ak820_oneshot_mods
      0048B5 E0               [24] 1380 	movx	a,@dptr
      0048B6 4B               [12] 1381 	orl	a,r3
      0048B7 F0               [24] 1382 	movx	@dptr,a
      0048B8                       1383 00113$:
                                   1384 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      0048B8 90 06 3C         [24] 1385 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0048BB E0               [24] 1386 	movx	a,@dptr
      0048BC F5 82            [12] 1387 	mov	dpl,a
      0048BE C0 06            [24] 1388 	push	ar6
      0048C0 C0 05            [24] 1389 	push	ar5
      0048C2 12 77 B0         [24] 1390 	lcall	_unregister_mods
      0048C5 D0 05            [24] 1391 	pop	ar5
      0048C7 D0 06            [24] 1392 	pop	ar6
                                   1393 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      0048C9 12 49 9C         [24] 1394 	lcall	_ak820_outline_0075
      0048CC 53 04 E7         [24] 1395 	anl	ar4,#0xe7
      0048CF 12 43 73         [24] 1396 	lcall	_ak820_outline_0065
      0048D2                       1397 00118$:
                                   1398 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      0048D2 75 82 00         [24] 1399 	mov	dpl, #0x00
      0048D5 22               [24] 1400 	ret
      0048D6                       1401 00120$:
                                   1402 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      0048D6 90 06 39         [24] 1403 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0048D9 E0               [24] 1404 	movx	a,@dptr
      0048DA 60 5C            [24] 1405 	jz	00128$
      0048DC 90 06 3A         [24] 1406 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      0048DF 12 43 7A         [24] 1407 	lcall	_ak820_outline_0091
      0048E2 C3               [12] 1408 	clr	c
      0048E3 74 01            [12] 1409 	mov	a,#0x01
      0048E5 9D               [12] 1410 	subb	a,r5
      0048E6 E4               [12] 1411 	clr	a
      0048E7 9E               [12] 1412 	subb	a,r6
      0048E8 50 4E            [24] 1413 	jnc	00128$
                                   1414 ;	free result
                                   1415 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      0048EA C3               [12] 1416 	clr	c
      0048EB ED               [12] 1417 	mov	a,r5
      0048EC 94 E0            [12] 1418 	subb	a,#0xe0
      0048EE EE               [12] 1419 	mov	a,r6
      0048EF 94 00            [12] 1420 	subb	a,#0x00
      0048F1 40 07            [24] 1421 	jc	00133$
      0048F3 74 E7            [12] 1422 	mov	a,#0xe7
      0048F5 9D               [12] 1423 	subb	a,r5
      0048F6 E4               [12] 1424 	clr	a
      0048F7 9E               [12] 1425 	subb	a,r6
      0048F8 50 3E            [24] 1426 	jnc	00128$
                                   1427 ;	free result
      0048FA                       1428 00133$:
                                   1429 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      0048FA 74 AE            [12] 1430 	mov	a,#0x100 - 0x52
      0048FC 2E               [12] 1431 	add	a,r6
      0048FD 50 09            [24] 1432 	jnc	00173$
      0048FF C3               [12] 1433 	clr	c
      004900 74 DF            [12] 1434 	mov	a,#0xdf
      004902 9D               [12] 1435 	subb	a,r5
      004903 74 52            [12] 1436 	mov	a,#0x52
      004905 9E               [12] 1437 	subb	a,r6
      004906 50 30            [24] 1438 	jnc	00128$
                                   1439 ;	free result
                                   1440 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004908                       1441 00173$:
      004908 7E 00            [12] 1442 	mov	r6,#0x00
      00490A                       1443 00135$:
      00490A BE 82 00         [24] 1444 	cjne	r6,#0x82,00287$
      00490D                       1445 00287$:
      00490D 50 12            [24] 1446 	jnc	00124$
                                   1447 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      00490F EE               [12] 1448 	mov	a,r6
      004910 12 49 A3         [24] 1449 	lcall	_ak820_outline_0078
      004913 30 E3 08         [24] 1450 	jnb	acc.3,00136$
      004916 43 03 10         [24] 1451 	orl	ar3,#0x10
      004919 12 38 60         [24] 1452 	lcall	_ak820_outline_0122
      00491C EB               [12] 1453 	mov	a,r3
      00491D F0               [24] 1454 	movx	@dptr,a
      00491E                       1455 00136$:
                                   1456 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      00491E 0E               [12] 1457 	inc	r6
      00491F 80 E9            [24] 1458 	sjmp	00135$
      004921                       1459 00124$:
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004921 90 06 36         [24] 1461 	mov	dptr,#_ak820_oneshot_mods
      004924 E0               [24] 1462 	movx	a,@dptr
      004925 FE               [12] 1463 	mov	r6,a
      004926 E0               [24] 1464 	movx	a,@dptr
      004927 60 0F            [24] 1465 	jz	00128$
                                   1466 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004929 90 06 37         [24] 1467 	mov	dptr,#_ak820_oneshot_consumed
      00492C EE               [12] 1468 	mov	a,r6
      00492D F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      00492E 90 0D 8D         [24] 1471 	mov	dptr,#_ak820_oneshot_target
      004931 EF               [12] 1472 	mov	a,r7
      004932 F0               [24] 1473 	movx	@dptr,a
                                   1474 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004933 90 06 36         [24] 1475 	mov	dptr,#_ak820_oneshot_mods
      004936 E4               [12] 1476 	clr	a
      004937 F0               [24] 1477 	movx	@dptr,a
      004938                       1478 00128$:
                                   1479 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004938 75 82 01         [24] 1480 	mov	dpl, #0x01
                                   1481 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      00493B 22               [24] 1482 	ret
                                   1483 	.area CSEG    (CODE)
                                   1484 	.area CONST   (CODE)
                                   1485 	.area XINIT   (CODE)
      00C160                       1486 __xinit__pending:
      00C160 FF                    1487 	.db #0xff	; 255
      00C161                       1488 __xinit__ak820_oneshot_target:
      00C161 FF                    1489 	.db #0xff	; 255
                                   1490 	.area CABS    (ABS,CODE)
                                   1491 
                                   1492 ; Experimental exact instruction outlining.
                                   1493 	.globl _ak820_outline_0004
                                   1494 	.globl _ak820_outline_0005
                                   1495 	.globl _ak820_outline_0010
                                   1496 	.globl _ak820_outline_0011
                                   1497 	.globl _ak820_outline_0012
                                   1498 	.globl _ak820_outline_0013
                                   1499 	.globl _ak820_outline_0014
                                   1500 	.globl _ak820_outline_0017
                                   1501 	.globl _ak820_outline_0019
                                   1502 	.globl _ak820_outline_0023
                                   1503 	.globl _ak820_outline_0030
                                   1504 	.globl _ak820_outline_0034
                                   1505 	.globl _ak820_outline_0046
                                   1506 	.globl _ak820_outline_0051
                                   1507 	.globl _ak820_outline_0055
                                   1508 	.globl _ak820_outline_0056
                                   1509 	.globl _ak820_outline_0059
                                   1510 	.globl _ak820_outline_0061
                                   1511 	.globl _ak820_outline_0065
                                   1512 	.globl _ak820_outline_0075
                                   1513 	.globl _ak820_outline_0078
                                   1514 	.globl _ak820_outline_0091
                                   1515 	.globl _ak820_outline_0098
                                   1516 	.globl _ak820_outline_0100
                                   1517 	.globl _ak820_outline_0103
                                   1518 	.globl _ak820_outline_0104
                                   1519 	.globl _ak820_outline_0116
                                   1520 	.globl _ak820_outline_0122
                                   1521 	.globl _ak820_outline_0123
                                   1522 	.globl _ak820_outline_0133
                                   1523 	.globl _ak820_outline_0151
                                   1524 	.globl _ak820_outline_0154
                                   1525 	.globl _ak820_outline_0187
                                   1526 
                                   1527 	.area CSEG (CODE)
                                   1528 ; function ak820_outline_0012
      00493C                       1529 _ak820_outline_0012:
      00493C 2E               [12] 1530 	add	a,r6
      00493D FC               [12] 1531 	mov	r4,a
      00493E E4               [12] 1532 	clr	a
      00493F 3F               [12] 1533 	addc	a,r7
      004940 FD               [12] 1534 	mov	r5,a
      004941 8C 82            [24] 1535 	mov	dpl,r4
      004943 8D 83            [24] 1536 	mov	dph,r5
      004945 E0               [24] 1537 	movx	a,@dptr
      004946 22               [24] 1538 	ret
                                   1539 
                                   1540 	.area CSEG (CODE)
                                   1541 ; function ak820_outline_0013
      004947                       1542 _ak820_outline_0013:
      004947 2E               [12] 1543 	add	a,r6
      004948 FB               [12] 1544 	mov	r3,a
      004949 E4               [12] 1545 	clr	a
      00494A 3F               [12] 1546 	addc	a,r7
      00494B FC               [12] 1547 	mov	r4,a
      00494C 8B 82            [24] 1548 	mov	dpl,r3
      00494E 8C 83            [24] 1549 	mov	dph,r4
      004950 E0               [24] 1550 	movx	a,@dptr
      004951 22               [24] 1551 	ret
                                   1552 
                                   1553 	.area CSEG (CODE)
                                   1554 ; function ak820_outline_0019
      004952                       1555 _ak820_outline_0019:
      004952 EF               [12] 1556 	mov	a,r7
      004953 24 A2            [12] 1557 	add	a,#_source_state
      004955 FD               [12] 1558 	mov	r5,a
      004956 E4               [12] 1559 	clr	a
      004957 34 05            [12] 1560 	addc	a,#(_source_state>>8)
      004959 FE               [12] 1561 	mov	r6,a
      00495A 8D 82            [24] 1562 	mov	dpl,r5
      00495C 8E 83            [24] 1563 	mov	dph,r6
      00495E E0               [24] 1564 	movx	a,@dptr
      00495F FC               [12] 1565 	mov	r4,a
      004960 22               [24] 1566 	ret
                                   1567 
                                   1568 	.area CSEG (CODE)
                                   1569 ; function ak820_outline_0023
      004961                       1570 _ak820_outline_0023:
      004961 90 0D 7C         [24] 1571 	mov	dptr,#___memcpy_PARM_2
      004964 EC               [12] 1572 	mov	a,r4
      004965 F0               [24] 1573 	movx	@dptr,a
      004966 ED               [12] 1574 	mov	a,r5
      004967 A3               [24] 1575 	inc	dptr
      004968 F0               [24] 1576 	movx	@dptr,a
      004969 E4               [12] 1577 	clr	a
      00496A A3               [24] 1578 	inc	dptr
      00496B F0               [24] 1579 	movx	@dptr,a
      00496C 90 0D 7F         [24] 1580 	mov	dptr,#___memcpy_PARM_3
      00496F 74 02            [12] 1581 	mov	a,#0x02
      004971 F0               [24] 1582 	movx	@dptr,a
      004972 E4               [12] 1583 	clr	a
      004973 A3               [24] 1584 	inc	dptr
      004974 F0               [24] 1585 	movx	@dptr,a
      004975 90 06 28         [24] 1586 	mov	dptr,#_ak820_tapping_source_PARM_1
      004978 F5 F0            [12] 1587 	mov	b,a
      00497A 22               [24] 1588 	ret
                                   1589 
                                   1590 	.area CSEG (CODE)
                                   1591 ; function ak820_outline_0046
      00497B                       1592 _ak820_outline_0046:
      00497B 2E               [12] 1593 	add	a,r6
      00497C FA               [12] 1594 	mov	r2,a
      00497D E4               [12] 1595 	clr	a
      00497E 3F               [12] 1596 	addc	a,r7
      00497F FB               [12] 1597 	mov	r3,a
      004980 8A 82            [24] 1598 	mov	dpl,r2
      004982 8B 83            [24] 1599 	mov	dph,r3
      004984 E0               [24] 1600 	movx	a,@dptr
      004985 22               [24] 1601 	ret
                                   1602 
                                   1603 	.area CSEG (CODE)
                                   1604 ; function ak820_outline_0055
      004986                       1605 _ak820_outline_0055:
      004986 74 01            [12] 1606 	mov	a,#0x01
      004988 F0               [24] 1607 	movx	@dptr,a
      004989 8E 82            [24] 1608 	mov	dpl,r6
      00498B 8F 83            [24] 1609 	mov	dph,r7
      00498D 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0056
      00498E                       1614 _ak820_outline_0056:
      00498E FC               [12] 1615 	mov	r4,a
      00498F 8B 82            [24] 1616 	mov	dpl,r3
      004991 8C 83            [24] 1617 	mov	dph,r4
      004993 E0               [24] 1618 	movx	a,@dptr
      004994 FA               [12] 1619 	mov	r2,a
      004995 22               [24] 1620 	ret
                                   1621 
                                   1622 	.area CSEG (CODE)
                                   1623 ; function ak820_outline_0059
      004996                       1624 _ak820_outline_0059:
      004996 EE               [12] 1625 	mov	a,r6
      004997 F0               [24] 1626 	movx	@dptr,a
      004998 EF               [12] 1627 	mov	a,r7
      004999 A3               [24] 1628 	inc	dptr
      00499A F0               [24] 1629 	movx	@dptr,a
      00499B 22               [24] 1630 	ret
                                   1631 
                                   1632 	.area CSEG (CODE)
                                   1633 ; function ak820_outline_0075
      00499C                       1634 _ak820_outline_0075:
      00499C 8D 82            [24] 1635 	mov	dpl,r5
      00499E 8E 83            [24] 1636 	mov	dph,r6
      0049A0 E0               [24] 1637 	movx	a,@dptr
      0049A1 FC               [12] 1638 	mov	r4,a
      0049A2 22               [24] 1639 	ret
                                   1640 
                                   1641 	.area CSEG (CODE)
                                   1642 ; function ak820_outline_0078
      0049A3                       1643 _ak820_outline_0078:
      0049A3 24 A2            [12] 1644 	add	a,#_source_state
      0049A5 FC               [12] 1645 	mov	r4,a
      0049A6 E4               [12] 1646 	clr	a
      0049A7 34 05            [12] 1647 	addc	a,#(_source_state>>8)
      0049A9 FD               [12] 1648 	mov	r5,a
      0049AA 8C 82            [24] 1649 	mov	dpl,r4
      0049AC 8D 83            [24] 1650 	mov	dph,r5
      0049AE E0               [24] 1651 	movx	a,@dptr
      0049AF FB               [12] 1652 	mov	r3,a
      0049B0 22               [24] 1653 	ret
                                   1654 
                                   1655 	.area CSEG (CODE)
                                   1656 ; function ak820_outline_0151
      0049B1                       1657 _ak820_outline_0151:
      0049B1 90 0D 8C         [24] 1658 	mov	dptr,#_pending
      0049B4 74 FF            [12] 1659 	mov	a,#0xff
      0049B6 F0               [24] 1660 	movx	@dptr,a
      0049B7 22               [24] 1661 	ret
