                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000519                        109 _page_data:
      000519                        110 	.ds 64
      000559                        111 _cached_page:
      000559                        112 	.ds 1
      00055A                        113 _batch_depth:
      00055A                        114 	.ds 1
      00055B                        115 _first_failure_stage:
      00055B                        116 	.ds 1
      00055C                        117 _nvm_fail_stage_10000_20:
      00055C                        118 	.ds 1
      00055D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055D                        120 	.ds 2
      00055F                        121 _crc_byte_PARM_2:
      00055F                        122 	.ds 1
      000560                        123 _crc_byte_crc_10000_25:
      000560                        124 	.ds 2
      000562                        125 _page_crc_crc_10000_30:
      000562                        126 	.ds 2
      000564                        127 _write_page_address_10000_32:
      000564                        128 	.ds 2
      000566                        129 _journal_header_valid_header_10000_39:
      000566                        130 	.ds 2
      000568                        131 _recover_journal_header_10000_46:
      000568                        132 	.ds 9
      000571                        133 _ak820_nvm_flush_header_10000_62:
      000571                        134 	.ds 9
      00057A                        135 _ak820_nvm_flush_stage_10000_62:
      00057A                        136 	.ds 1
      00057B                        137 _load_page_page_10000_87:
      00057B                        138 	.ds 1
      00057C                        139 _read_offset_offset_10000_93:
      00057C                        140 	.ds 2
      00057E                        141 _eeprom_read_byte_addr_10000_97:
      00057E                        142 	.ds 3
      000581                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000584                        146 	.ds 2
      000586                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000586                        148 	.ds 2
      000588                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000588                        150 	.ds 2
      00058A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058A                        152 	.ds 3
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058D                        154 	.ds 2
      00058F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058F                        156 	.ds 2
      000591                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000591                        158 	.ds 3
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000594                        160 	.ds 2
      000596                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000596                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003BBB                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003BBB E5 82            [12]  215 	mov	a,dpl
      003BBD 90 05 5C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003BC0 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003BC1 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003BC4 90 05 5C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003BC7 E0               [24]  221 	movx	a,@dptr
      003BC8 90 05 5B         [24]  222 	mov	dptr,#_first_failure_stage
      003BCB F0               [24]  223 	movx	@dptr,a
      003BCC                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003BCC D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003BCE 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003BCF                        239 _ak820_nvm_diagnostic:
      003BCF 12 38 43         [24]  240 	lcall	_ak820_outline_0103
      003BD2 90 05 5D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BD5 12 38 48         [24]  242 	lcall	_ak820_outline_0104
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003BD8 90 05 5D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BDB 12 38 00         [24]  245 	lcall	_ak820_outline_0051
      003BDE A2 09            [12]  246 	mov	c,_storage_failed
      003BE0 E4               [12]  247 	clr	a
      003BE1 33               [12]  248 	rlc	a
      003BE2 12 43 92         [24]  249 	lcall	_ak820_outline_0116
      003BE5 12 43 6D         [24]  250 	lcall	_ak820_outline_0061
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003BE8 A3               [24]  252 	inc	dptr
      003BE9 A2 07            [12]  253 	mov	c,_page_valid
      003BEB E4               [12]  254 	clr	a
      003BEC 33               [12]  255 	rlc	a
      003BED 12 43 41         [24]  256 	lcall	_ak820_outline_0030
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003BF0 A2 08            [12]  258 	mov	c,_page_dirty
      003BF2 E4               [12]  259 	clr	a
      003BF3 33               [12]  260 	rlc	a
      003BF4 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003BF5 74 03            [12]  263 	mov	a,#0x03
      003BF7 12 43 BD         [24]  264 	lcall	_ak820_outline_0157
      003BFA 90 05 5A         [24]  265 	mov	dptr,#_batch_depth
      003BFD E0               [24]  266 	movx	a,@dptr
      003BFE 12 38 60         [24]  267 	lcall	_ak820_outline_0122
      003C01 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003C02 74 04            [12]  270 	mov	a,#0x04
      003C04 12 43 BD         [24]  271 	lcall	_ak820_outline_0157
      003C07 90 05 59         [24]  272 	mov	dptr,#_cached_page
      003C0A E0               [24]  273 	movx	a,@dptr
      003C0B 12 38 60         [24]  274 	lcall	_ak820_outline_0122
      003C0E F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003C0F 12 43 37         [24]  277 	lcall	_ak820_outline_0010
      003C12 E4               [12]  278 	clr	a
      003C13 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003C14 74 06            [12]  281 	mov	a,#0x06
      003C16 12 43 A2         [24]  282 	lcall	_ak820_outline_0135
      003C19 90 05 5B         [24]  283 	mov	dptr,#_first_failure_stage
      003C1C E0               [24]  284 	movx	a,@dptr
      003C1D 12 43 92         [24]  285 	lcall	_ak820_outline_0116
      003C20 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003C21 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003C22                        300 _crc_byte:
      003C22 12 38 43         [24]  301 	lcall	_ak820_outline_0103
      003C25 90 05 60         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003C28 12 38 48         [24]  303 	lcall	_ak820_outline_0104
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003C2B 90 05 5F         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003C2E E0               [24]  306 	movx	a,@dptr
      003C2F FF               [12]  307 	mov	r7,a
      003C30 7E 00            [12]  308 	mov	r6,#0x00
      003C32 90 05 60         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003C35 E0               [24]  310 	movx	a,@dptr
      003C36 6E               [12]  311 	xrl	a,r6
      003C37 F0               [24]  312 	movx	@dptr,a
      003C38 A3               [24]  313 	inc	dptr
      003C39 E0               [24]  314 	movx	a,@dptr
      003C3A 6F               [12]  315 	xrl	a,r7
      003C3B F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C3C 7F 00            [12]  318 	mov	r7,#0x00
      003C3E                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C3E 90 05 60         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003C41 12 43 7A         [24]  322 	lcall	_ak820_outline_0091
      003C44 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003C47 ED               [12]  324 	mov	a,r5
      003C48 2D               [12]  325 	add	a,r5
      003C49 FB               [12]  326 	mov	r3,a
      003C4A EE               [12]  327 	mov	a,r6
      003C4B 33               [12]  328 	rlc	a
      003C4C FC               [12]  329 	mov	r4,a
      003C4D 63 03 21         [24]  330 	xrl	ar3,#0x21
      003C50 63 04 10         [24]  331 	xrl	ar4,#0x10
      003C53 80 06            [24]  332 	sjmp	00107$
      003C55                        333 00106$:
      003C55 ED               [12]  334 	mov	a,r5
      003C56 2D               [12]  335 	add	a,r5
      003C57 FB               [12]  336 	mov	r3,a
      003C58 EE               [12]  337 	mov	a,r6
      003C59 33               [12]  338 	rlc	a
      003C5A FC               [12]  339 	mov	r4,a
      003C5B                        340 00107$:
      003C5B 90 05 60         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003C5E 12 38 2B         [24]  342 	lcall	_ak820_outline_0077
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C61 0F               [12]  344 	inc	r7
      003C62 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C65 12 33 FC         [24]  347 	lcall	_ak820_outline_0123
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C68 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003C69                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C69 90 05 62         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003C6C 74 FF            [12]  363 	mov	a,#0xff
      003C6E F0               [24]  364 	movx	@dptr,a
      003C6F A3               [24]  365 	inc	dptr
      003C70 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C71 7F 00            [12]  368 	mov	r7,#0x00
      003C73                        369 00102$:
      003C73 90 05 62         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003C76 12 43 7A         [24]  371 	lcall	_ak820_outline_0091
      003C79 12 43 86         [24]  372 	lcall	_ak820_outline_0101
      003C7C 90 05 5F         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003C7F F0               [24]  374 	movx	@dptr,a
      003C80 12 38 6A         [24]  375 	lcall	_ak820_outline_0133
      003C83 C0 07            [24]  376 	push	ar7
      003C85 12 3C 22         [24]  377 	lcall	_crc_byte
      003C88 AD 82            [24]  378 	mov	r5, dpl
      003C8A AE 83            [24]  379 	mov	r6, dph
      003C8C D0 07            [24]  380 	pop	ar7
      003C8E 90 05 62         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003C91 12 43 C3         [24]  382 	lcall	_ak820_outline_0158
      003C94 0F               [12]  383 	inc	r7
      003C95 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C98 12 38 6A         [24]  386 	lcall	_ak820_outline_0133
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C9B 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003C9C                        399 _write_page:
      003C9C 12 38 43         [24]  400 	lcall	_ak820_outline_0103
      003C9F 90 05 64         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003CA2 12 38 48         [24]  402 	lcall	_ak820_outline_0104
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003CA5 90 05 64         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003CA8 12 37 A0         [24]  405 	lcall	_ak820_outline_0004
      003CAB C0 07            [24]  406 	push	ar7
      003CAD C0 06            [24]  407 	push	ar6
      003CAF 12 39 C6         [24]  408 	lcall	_ak820_flash_erase
      003CB2 E5 82            [12]  409 	mov	a, dpl
      003CB4 D0 06            [24]  410 	pop	ar6
      003CB6 D0 07            [24]  411 	pop	ar7
      003CB8 70 03            [24]  412 	jnz	00102$
      003CBA F5 82            [12]  413 	mov	dpl,a
      003CBC 22               [24]  414 	ret
      003CBD                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003CBD 90 04 F5         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003CC0 74 19            [12]  418 	mov	a,#_page_data
      003CC2 F0               [24]  419 	movx	@dptr,a
      003CC3 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003CC5 A3               [24]  421 	inc	dptr
      003CC6 12 43 6D         [24]  422 	lcall	_ak820_outline_0061
      003CC9 12 3A DA         [24]  423 	lcall	_ak820_flash_program_page
      003CCC E5 82            [12]  424 	mov	a, dpl
      003CCE 70 03            [24]  425 	jnz	00120$
      003CD0 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CD2 22               [24]  428 	ret
      003CD3                        429 00120$:
      003CD3 7F 00            [12]  430 	mov	r7,#0x00
      003CD5                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003CD5 8F 05            [24]  433 	mov	ar5,r7
      003CD7 7E 00            [12]  434 	mov	r6,#0x00
      003CD9 90 05 64         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003CDC 12 38 5A         [24]  436 	lcall	_ak820_outline_0121
      003CDF ED               [12]  437 	mov	a,r5
      003CE0 2B               [12]  438 	add	a, r3
      003CE1 FB               [12]  439 	mov	r3,a
      003CE2 EE               [12]  440 	mov	a,r6
      003CE3 3C               [12]  441 	addc	a, r4
      003CE4 FC               [12]  442 	mov	r4,a
      003CE5 12 33 FC         [24]  443 	lcall	_ak820_outline_0123
      003CE8 12 38 B9         [24]  444 	lcall	_ak820_flash_read
      003CEB AE 82            [24]  445 	mov	r6, dpl
      003CED 12 43 86         [24]  446 	lcall	_ak820_outline_0101
      003CF0 FD               [12]  447 	mov	r5,a
      003CF1 EE               [12]  448 	mov	a,r6
      003CF2 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003CF5 80 04            [24]  450 	sjmp	00109$
      003CF7                        451 00149$:
      003CF7 75 82 00         [24]  452 	mov	dpl, #0x00
      003CFA 22               [24]  453 	ret
      003CFB                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CFB 0F               [12]  456 	inc	r7
      003CFC BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003CFF 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003D02 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003D03                        472 _journal_header_valid:
      003D03 12 38 43         [24]  473 	lcall	_ak820_outline_0103
      003D06 90 05 66         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003D09 12 38 48         [24]  475 	lcall	_ak820_outline_0104
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003D0C 90 05 66         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003D0F 12 37 A0         [24]  478 	lcall	_ak820_outline_0004
      003D12 E0               [24]  479 	movx	a,@dptr
      003D13 FD               [12]  480 	mov	r5,a
      003D14 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003D17 80 04            [24]  482 	sjmp	00116$
      003D19                        483 00138$:
      003D19 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D1C 22               [24]  486 	ret
      003D1D                        487 00116$:
      003D1D 7D 01            [12]  488 	mov	r5,#0x01
      003D1F                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003D1F ED               [12]  491 	mov	a,r5
      003D20 12 37 E7         [24]  492 	lcall	_ak820_outline_0017
      003D23 FC               [12]  493 	mov	r4,a
      003D24 8D 02            [24]  494 	mov	ar2,r5
      003D26 7B 00            [12]  495 	mov	r3,#0x00
      003D28 74 04            [12]  496 	mov	a,#0x04
      003D2A 2A               [12]  497 	add	a, r2
      003D2B FA               [12]  498 	mov	r2,a
      003D2C E4               [12]  499 	clr	a
      003D2D 3B               [12]  500 	addc	a, r3
      003D2E FB               [12]  501 	mov	r3,a
      003D2F EA               [12]  502 	mov	a,r2
      003D30 2E               [12]  503 	add	a, r6
      003D31 F5 82            [12]  504 	mov	dpl,a
      003D33 EB               [12]  505 	mov	a,r3
      003D34 3F               [12]  506 	addc	a, r7
      003D35 F5 83            [12]  507 	mov	dph,a
      003D37 E0               [24]  508 	movx	a,@dptr
      003D38 62 04            [12]  509 	xrl	ar4,a
      003D3A BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      003D3D 80 04            [24]  511 	sjmp	00107$
      003D3F                        512 00139$:
      003D3F 75 82 00         [24]  513 	mov	dpl, #0x00
      003D42 22               [24]  514 	ret
      003D43                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D43 0D               [12]  517 	inc	r5
      003D44 BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D47 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D4A 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      003D4B                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D4B 7F 00            [12]  537 	mov	r7,#0x00
      003D4D                        538 00115$:
      003D4D EF               [12]  539 	mov	a,r7
      003D4E 24 68            [12]  540 	add	a, #_recover_journal_header_10000_46
      003D50 FD               [12]  541 	mov	r5,a
      003D51 E4               [12]  542 	clr	a
      003D52 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D54 FE               [12]  544 	mov	r6,a
      003D55 8F 04            [24]  545 	mov	ar4,r7
      003D57 7B 00            [12]  546 	mov	r3,#0x00
      003D59 74 40            [12]  547 	mov	a,#0x40
      003D5B 2C               [12]  548 	add	a, r4
      003D5C FC               [12]  549 	mov	r4,a
      003D5D 74 EF            [12]  550 	mov	a,#0xef
      003D5F 3B               [12]  551 	addc	a, r3
      003D60 FB               [12]  552 	mov	r3,a
      003D61 12 43 CE         [24]  553 	lcall	_ak820_outline_0181
      003D64 12 38 B9         [24]  554 	lcall	_ak820_flash_read
      003D67 AC 82            [24]  555 	mov	r4, dpl
      003D69 12 43 73         [24]  556 	lcall	_ak820_outline_0065
      003D6C 0F               [12]  557 	inc	r7
      003D6D BF 09 DD         [24]  558 	cjne	r7,#0x09,00115$
                                    559 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D70 90 05 68         [24]  560 	mov	dptr,#_recover_journal_header_10000_46
      003D73 12 3D 03         [24]  561 	lcall	_journal_header_valid
      003D76 E5 82            [12]  562 	mov	a, dpl
      003D78 70 01            [24]  563 	jnz	00103$
      003D7A 22               [24]  564 	ret
      003D7B                        565 00103$:
                                    566 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D7B 90 05 69         [24]  567 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D7E E0               [24]  568 	movx	a,@dptr
      003D7F FF               [12]  569 	mov	r7,a
      003D80 7E 00            [12]  570 	mov	r6,#0x00
      003D82 90 05 6A         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D85 E0               [24]  572 	movx	a,@dptr
      003D86 FC               [12]  573 	mov	r4,a
      003D87 E4               [12]  574 	clr	a
      003D88 42 07            [12]  575 	orl	ar7,a
      003D8A EC               [12]  576 	mov	a,r4
      003D8B 42 06            [12]  577 	orl	ar6,a
                                    578 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D8D 90 05 6B         [24]  579 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D90 E0               [24]  580 	movx	a,@dptr
      003D91 FD               [12]  581 	mov	r5,a
      003D92 7C 00            [12]  582 	mov	r4,#0x00
      003D94 90 05 6C         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D97 E0               [24]  584 	movx	a,@dptr
      003D98 FA               [12]  585 	mov	r2,a
      003D99 E4               [12]  586 	clr	a
      003D9A 12 43 A8         [24]  587 	lcall	_ak820_outline_0140
                                    588 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D9D C3               [12]  589 	clr	c
      003D9E EF               [12]  590 	mov	a,r7
      003D9F 94 A0            [12]  591 	subb	a,#0xa0
      003DA1 EE               [12]  592 	mov	a,r6
      003DA2 94 00            [12]  593 	subb	a,#0x00
      003DA4 40 06            [24]  594 	jc	00134$
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003DA6 75 82 01         [24]  596 	mov	dpl, #0x01
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003DA9 02 3B BB         [24]  598 	ljmp	_nvm_fail
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003DAC                        600 00134$:
      003DAC 7B 00            [12]  601 	mov	r3,#0x00
      003DAE                        602 00117$:
      003DAE C0 05            [24]  603 	push	ar5
      003DB0 C0 04            [24]  604 	push	ar4
      003DB2 EB               [12]  605 	mov	a,r3
      003DB3 24 19            [12]  606 	add	a, #_page_data
      003DB5 F9               [12]  607 	mov	r1,a
      003DB6 E4               [12]  608 	clr	a
      003DB7 34 05            [12]  609 	addc	a, #(_page_data >> 8)
      003DB9 FA               [12]  610 	mov	r2,a
      003DBA 8B 00            [24]  611 	mov	ar0,r3
      003DBC 7D 00            [12]  612 	mov	r5,#0x00
      003DBE 74 EF            [12]  613 	mov	a,#0xef
      003DC0 2D               [12]  614 	add	a, r5
      003DC1 FD               [12]  615 	mov	r5,a
      003DC2 88 82            [24]  616 	mov	dpl, r0
      003DC4 8D 83            [24]  617 	mov	dph, r5
      003DC6 12 38 B9         [24]  618 	lcall	_ak820_flash_read
      003DC9 AD 82            [24]  619 	mov	r5, dpl
      003DCB 12 43 C9         [24]  620 	lcall	_ak820_outline_0180
      003DCE ED               [12]  621 	mov	a,r5
      003DCF F0               [24]  622 	movx	@dptr,a
      003DD0 0B               [12]  623 	inc	r3
      003DD1 BB 40 02         [24]  624 	cjne	r3,#0x40,00190$
      003DD4 80 06            [24]  625 	sjmp	00191$
      003DD6                        626 00190$:
      003DD6 D0 04            [24]  627 	pop	ar4
      003DD8 D0 05            [24]  628 	pop	ar5
      003DDA 80 D2            [24]  629 	sjmp	00117$
      003DDC                        630 00191$:
      003DDC D0 04            [24]  631 	pop	ar4
      003DDE D0 05            [24]  632 	pop	ar5
                                    633 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003DE0 C0 07            [24]  634 	push	ar7
      003DE2 C0 06            [24]  635 	push	ar6
      003DE4 C0 05            [24]  636 	push	ar5
      003DE6 C0 04            [24]  637 	push	ar4
      003DE8 12 3C 69         [24]  638 	lcall	_page_crc
      003DEB AA 82            [24]  639 	mov	r2, dpl
      003DED AB 83            [24]  640 	mov	r3, dph
      003DEF D0 04            [24]  641 	pop	ar4
      003DF1 D0 05            [24]  642 	pop	ar5
      003DF3 D0 06            [24]  643 	pop	ar6
      003DF5 D0 07            [24]  644 	pop	ar7
      003DF7 EA               [12]  645 	mov	a,r2
      003DF8 B5 05 06         [24]  646 	cjne	a,ar5,00192$
      003DFB EB               [12]  647 	mov	a,r3
      003DFC B5 04 02         [24]  648 	cjne	a,ar4,00192$
      003DFF 80 06            [24]  649 	sjmp	00113$
      003E01                        650 00192$:
      003E01 75 82 02         [24]  651 	mov	dpl, #0x02
      003E04 02 3B BB         [24]  652 	ljmp	_nvm_fail
      003E07                        653 00113$:
                                    654 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003E07 EE               [12]  655 	mov	a,r6
      003E08 54 03            [12]  656 	anl	a,#0x03
      003E0A A2 E0            [12]  657 	mov	c,acc.0
      003E0C CF               [12]  658 	xch	a,r7
      003E0D 13               [12]  659 	rrc	a
      003E0E CF               [12]  660 	xch	a,r7
      003E0F 13               [12]  661 	rrc	a
      003E10 A2 E0            [12]  662 	mov	c,acc.0
      003E12 CF               [12]  663 	xch	a,r7
      003E13 13               [12]  664 	rrc	a
      003E14 CF               [12]  665 	xch	a,r7
      003E15 13               [12]  666 	rrc	a
      003E16 CF               [12]  667 	xch	a,r7
      003E17 24 C7            [12]  668 	add	a,#0xc7
      003E19 FE               [12]  669 	mov	r6,a
      003E1A 12 43 B8         [24]  670 	lcall	_ak820_outline_0154
      003E1D 12 3C 9C         [24]  671 	lcall	_write_page
      003E20 E5 82            [12]  672 	mov	a, dpl
      003E22 70 06            [24]  673 	jnz	00110$
      003E24 75 82 03         [24]  674 	mov	dpl, #0x03
      003E27 02 3B BB         [24]  675 	ljmp	_nvm_fail
      003E2A                        676 00110$:
                                    677 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003E2A 90 EF 40         [24]  678 	mov	dptr,#0xef40
      003E2D 12 39 C6         [24]  679 	lcall	_ak820_flash_erase
      003E30 E5 82            [12]  680 	mov	a, dpl
      003E32 70 06            [24]  681 	jnz	00119$
      003E34 75 82 04         [24]  682 	mov	dpl, #0x04
                                    683 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003E37 02 3B BB         [24]  684 	ljmp	_nvm_fail
      003E3A                        685 00119$:
      003E3A 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    689 ;------------------------------------------------------------
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    691 ;	-----------------------------------------
                                    692 ;	 function eeprom_driver_init
                                    693 ;	-----------------------------------------
      003E3B                        694 _eeprom_driver_init:
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    696 ;	assignBit
      003E3B C2 09            [12]  697 	clr	_storage_failed
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E3D 90 05 5B         [24]  699 	mov	dptr,#_first_failure_stage
      003E40 E4               [12]  700 	clr	a
      003E41 F0               [24]  701 	movx	@dptr,a
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    703 ;	assignBit
      003E42 C2 08            [12]  704 	clr	_page_dirty
                                    705 ;	assignBit
      003E44 C2 07            [12]  706 	clr	_page_valid
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E46 90 05 5A         [24]  708 	mov	dptr,#_batch_depth
      003E49 E4               [12]  709 	clr	a
      003E4A F0               [24]  710 	movx	@dptr,a
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E4B 12 3D 4B         [24]  712 	lcall	_recover_journal
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E4E 02 2A 6B         [24]  715 	ljmp	_ak820_macro_init
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_nvm_ok
                                    722 ;	-----------------------------------------
      003E51                        723 _ak820_nvm_ok:
      003E51 A2 09            [12]  724 	mov	c,_storage_failed
      003E53 B3               [12]  725 	cpl	c
      003E54 92 0A            [24]  726 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E56 12 38 86         [24]  727 	lcall	_ak820_outline_0167
      003E59 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    731 ;------------------------------------------------------------
                                    732 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    733 ;	-----------------------------------------
                                    734 ;	 function ak820_nvm_schema_fault
                                    735 ;	-----------------------------------------
      003E5A                        736 _ak820_nvm_schema_fault:
      003E5A 75 82 10         [24]  737 	mov	dpl, #0x10
      003E5D 02 3B BB         [24]  738 	ljmp	_nvm_fail
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    741 ;------------------------------------------------------------
                                    742 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    743 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    744 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    745 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_flush
                                    750 ;	-----------------------------------------
      003E60                        751 _ak820_nvm_flush:
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E60 30 08 03         [24]  753 	jnb	_page_dirty,00101$
      003E63 30 09 01         [24]  754 	jnb	_storage_failed,00102$
      003E66                        755 00101$:
      003E66 22               [24]  756 	ret
      003E67                        757 00102$:
                                    758 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E67 12 3C 69         [24]  759 	lcall	_page_crc
      003E6A 12 43 9D         [24]  760 	lcall	_ak820_outline_0132
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E6D 90 05 71         [24]  762 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E70 74 A5            [12]  763 	mov	a,#0xa5
      003E72 F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E73 90 05 59         [24]  766 	mov	dptr,#_cached_page
      003E76 E0               [24]  767 	movx	a,@dptr
      003E77 90 05 72         [24]  768 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E7A F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E7B 90 05 73         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E7E E4               [12]  772 	clr	a
      003E7F F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E80 8E 05            [24]  775 	mov	ar5,r6
      003E82 90 05 74         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E85 ED               [12]  777 	mov	a,r5
      003E86 F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E87 8F 06            [24]  780 	mov	ar6,r7
      003E89 90 05 75         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E8C EE               [12]  782 	mov	a,r6
      003E8D F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E8E 7F 01            [12]  785 	mov	r7,#0x01
      003E90                        786 00128$:
      003E90 8F 06            [24]  787 	mov	ar6,r7
      003E92 EE               [12]  788 	mov	a,r6
      003E93 24 04            [12]  789 	add	a,#0x04
      003E95 FE               [12]  790 	mov	r6,a
      003E96 33               [12]  791 	rlc	a
      003E97 95 E0            [12]  792 	subb	a,acc
      003E99 FD               [12]  793 	mov	r5,a
      003E9A EE               [12]  794 	mov	a,r6
      003E9B 24 71            [12]  795 	add	a, #_ak820_nvm_flush_header_10000_62
      003E9D FE               [12]  796 	mov	r6,a
      003E9E ED               [12]  797 	mov	a,r5
      003E9F 34 05            [12]  798 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003EA1 FD               [12]  799 	mov	r5,a
      003EA2 12 43 50         [24]  800 	lcall	_ak820_outline_0041
      003EA5 FC               [12]  801 	mov	r4,a
      003EA6 63 04 FF         [24]  802 	xrl	ar4,#0xff
      003EA9 8E 82            [24]  803 	mov	dpl,r6
      003EAB 8D 83            [24]  804 	mov	dph,r5
      003EAD EC               [12]  805 	mov	a,r4
      003EAE F0               [24]  806 	movx	@dptr,a
      003EAF 0F               [12]  807 	inc	r7
      003EB0 BF 05 DD         [24]  808 	cjne	r7,#0x05,00128$
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003EB3 90 05 7A         [24]  810 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EB6 74 05            [12]  811 	mov	a,#0x05
      003EB8 F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003EB9 90 EF 40         [24]  814 	mov	dptr,#0xef40
      003EBC 12 39 C6         [24]  815 	lcall	_ak820_flash_erase
      003EBF E5 82            [12]  816 	mov	a, dpl
      003EC1 70 03            [24]  817 	jnz	00269$
      003EC3 02 3F A9         [24]  818 	ljmp	00127$
      003EC6                        819 00269$:
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003EC6 90 05 7A         [24]  821 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EC9 74 06            [12]  822 	mov	a,#0x06
      003ECB F0               [24]  823 	movx	@dptr,a
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003ECC 7F 00            [12]  825 	mov	r7,#0x00
      003ECE                        826 00130$:
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003ECE 12 43 5C         [24]  828 	lcall	_ak820_outline_0052
      003ED1 12 38 B9         [24]  829 	lcall	_ak820_flash_read
      003ED4 E5 82            [12]  830 	mov	a, dpl
      003ED6 60 03            [24]  831 	jz	00270$
      003ED8 02 3F A9         [24]  832 	ljmp	00127$
      003EDB                        833 00270$:
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EDB 0F               [12]  835 	inc	r7
      003EDC BF 40 EF         [24]  836 	cjne	r7,#0x40,00130$
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003EDF 90 05 7A         [24]  838 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EE2 74 07            [12]  839 	mov	a,#0x07
      003EE4 F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003EE5 90 EF 00         [24]  842 	mov	dptr,#0xef00
      003EE8 12 3C 9C         [24]  843 	lcall	_write_page
      003EEB E5 82            [12]  844 	mov	a, dpl
      003EED 70 03            [24]  845 	jnz	00273$
      003EEF 02 3F A9         [24]  846 	ljmp	00127$
      003EF2                        847 00273$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003EF2 90 05 7A         [24]  849 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EF5 74 08            [12]  850 	mov	a,#0x08
      003EF7 F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EF8 7F 01            [12]  853 	mov	r7,#0x01
      003EFA                        854 00132$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003EFA 12 43 50         [24]  856 	lcall	_ak820_outline_0041
      003EFD FE               [12]  857 	mov	r6,a
      003EFE 60 22            [24]  858 	jz	00133$
      003F00 8F 05            [24]  859 	mov	ar5,r7
      003F02 7C 00            [12]  860 	mov	r4,#0x00
      003F04 74 40            [12]  861 	mov	a,#0x40
      003F06 2D               [12]  862 	add	a, r5
      003F07 FD               [12]  863 	mov	r5,a
      003F08 74 EF            [12]  864 	mov	a,#0xef
      003F0A 3C               [12]  865 	addc	a, r4
      003F0B FC               [12]  866 	mov	r4,a
      003F0C 90 04 F2         [24]  867 	mov	dptr,#_ak820_flash_program_PARM_2
      003F0F EE               [12]  868 	mov	a,r6
      003F10 F0               [24]  869 	movx	@dptr,a
      003F11 12 43 D3         [24]  870 	lcall	_ak820_outline_0185
      003F14 C0 07            [24]  871 	push	ar7
      003F16 12 3A 26         [24]  872 	lcall	_ak820_flash_program
      003F19 E5 82            [12]  873 	mov	a, dpl
      003F1B D0 07            [24]  874 	pop	ar7
      003F1D 70 03            [24]  875 	jnz	00275$
      003F1F 02 3F A9         [24]  876 	ljmp	00127$
      003F22                        877 00275$:
      003F22                        878 00133$:
                                    879 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003F22 0F               [12]  880 	inc	r7
      003F23 BF 09 D4         [24]  881 	cjne	r7,#0x09,00132$
                                    882 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003F26 90 05 7A         [24]  883 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F29 74 09            [12]  884 	mov	a,#0x09
      003F2B F0               [24]  885 	movx	@dptr,a
                                    886 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F2C 7F 01            [12]  887 	mov	r7,#0x01
      003F2E                        888 00134$:
                                    889 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003F2E 12 43 5C         [24]  890 	lcall	_ak820_outline_0052
      003F31 12 38 B9         [24]  891 	lcall	_ak820_flash_read
      003F34 AE 82            [24]  892 	mov	r6, dpl
      003F36 12 43 50         [24]  893 	lcall	_ak820_outline_0041
      003F39 FD               [12]  894 	mov	r5,a
      003F3A EE               [12]  895 	mov	a,r6
      003F3B B5 05 6B         [24]  896 	cjne	a,ar5,00127$
                                    897 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F3E 0F               [12]  898 	inc	r7
      003F3F BF 09 EC         [24]  899 	cjne	r7,#0x09,00134$
                                    900 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F42 90 05 7A         [24]  901 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F45 74 0A            [12]  902 	mov	a,#0x0a
      003F47 F0               [24]  903 	movx	@dptr,a
                                    904 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F48 90 05 71         [24]  905 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F4B E0               [24]  906 	movx	a,@dptr
      003F4C 90 04 F2         [24]  907 	mov	dptr,#_ak820_flash_program_PARM_2
      003F4F F0               [24]  908 	movx	@dptr,a
      003F50 90 EF 40         [24]  909 	mov	dptr,#0xef40
      003F53 12 3A 26         [24]  910 	lcall	_ak820_flash_program
      003F56 E5 82            [12]  911 	mov	a, dpl
      003F58 60 4F            [24]  912 	jz	00127$
                                    913 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F5A 90 05 7A         [24]  914 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F5D 74 0B            [12]  915 	mov	a,#0x0b
      003F5F F0               [24]  916 	movx	@dptr,a
                                    917 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F60 90 EF 40         [24]  918 	mov	dptr,#0xef40
      003F63 12 38 B9         [24]  919 	lcall	_ak820_flash_read
      003F66 AF 82            [24]  920 	mov	r7, dpl
      003F68 90 05 71         [24]  921 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F6B E0               [24]  922 	movx	a,@dptr
      003F6C FE               [12]  923 	mov	r6,a
      003F6D EF               [12]  924 	mov	a,r7
      003F6E B5 06 38         [24]  925 	cjne	a,ar6,00127$
                                    926 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F71 90 05 7A         [24]  927 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F74 74 0C            [12]  928 	mov	a,#0x0c
      003F76 F0               [24]  929 	movx	@dptr,a
                                    930 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F77 90 05 59         [24]  931 	mov	dptr,#_cached_page
      003F7A E0               [24]  932 	movx	a,@dptr
      003F7B FE               [12]  933 	mov	r6,a
      003F7C E4               [12]  934 	clr	a
      003F7D C3               [12]  935 	clr	c
      003F7E CE               [12]  936 	xch	a,r6
      003F7F 13               [12]  937 	rrc	a
      003F80 CE               [12]  938 	xch	a,r6
      003F81 13               [12]  939 	rrc	a
      003F82 A2 E0            [12]  940 	mov	c,acc.0
      003F84 CE               [12]  941 	xch	a,r6
      003F85 13               [12]  942 	rrc	a
      003F86 CE               [12]  943 	xch	a,r6
      003F87 13               [12]  944 	rrc	a
      003F88 CE               [12]  945 	xch	a,r6
      003F89 24 C7            [12]  946 	add	a,#0xc7
      003F8B FF               [12]  947 	mov	r7,a
      003F8C 12 43 92         [24]  948 	lcall	_ak820_outline_0116
      003F8F 12 3C 9C         [24]  949 	lcall	_write_page
      003F92 E5 82            [12]  950 	mov	a, dpl
      003F94 60 13            [24]  951 	jz	00127$
                                    952 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F96 90 05 7A         [24]  953 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F99 74 0D            [12]  954 	mov	a,#0x0d
      003F9B F0               [24]  955 	movx	@dptr,a
                                    956 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F9C 90 EF 40         [24]  957 	mov	dptr,#0xef40
      003F9F 12 39 C6         [24]  958 	lcall	_ak820_flash_erase
      003FA2 E5 82            [12]  959 	mov	a, dpl
      003FA4 60 03            [24]  960 	jz	00127$
                                    961 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    962 ;	assignBit
      003FA6 C2 08            [12]  963 	clr	_page_dirty
                                    964 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003FA8 22               [24]  966 	ret
      003FA9                        967 00127$:
                                    968 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003FA9 90 05 7A         [24]  969 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FAC E0               [24]  970 	movx	a,@dptr
      003FAD F5 82            [12]  971 	mov	dpl,a
                                    972 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003FAF 02 3B BB         [24]  973 	ljmp	_nvm_fail
                                    974 ;------------------------------------------------------------
                                    975 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    976 ;------------------------------------------------------------
                                    977 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    978 ;	-----------------------------------------
                                    979 ;	 function ak820_nvm_begin
                                    980 ;	-----------------------------------------
      003FB2                        981 _ak820_nvm_begin:
                                    982 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003FB2 90 05 5A         [24]  983 	mov	dptr,#_batch_depth
      003FB5 E0               [24]  984 	movx	a,@dptr
      003FB6 FF               [12]  985 	mov	r7,a
      003FB7 BF FF 06         [24]  986 	cjne	r7,#0xff,00102$
      003FBA 75 82 0F         [24]  987 	mov	dpl, #0x0f
      003FBD 02 3B BB         [24]  988 	ljmp	_nvm_fail
      003FC0                        989 00102$:
                                    990 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003FC0 90 05 5A         [24]  991 	mov	dptr,#_batch_depth
      003FC3 EF               [12]  992 	mov	a,r7
      003FC4 04               [12]  993 	inc	a
      003FC5 F0               [24]  994 	movx	@dptr,a
                                    995 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003FC6 22               [24]  996 	ret
                                    997 ;------------------------------------------------------------
                                    998 ;Allocation info for local variables in function 'ak820_nvm_end'
                                    999 ;------------------------------------------------------------
                                   1000 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1001 ;	-----------------------------------------
                                   1002 ;	 function ak820_nvm_end
                                   1003 ;	-----------------------------------------
      003FC7                       1004 _ak820_nvm_end:
                                   1005 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003FC7 90 05 5A         [24] 1006 	mov	dptr,#_batch_depth
      003FCA E0               [24] 1007 	movx	a,@dptr
      003FCB FF               [12] 1008 	mov	r7,a
      003FCC E0               [24] 1009 	movx	a,@dptr
      003FCD 60 06            [24] 1010 	jz	00102$
      003FCF EF               [12] 1011 	mov	a,r7
      003FD0 14               [12] 1012 	dec	a
      003FD1 90 05 5A         [24] 1013 	mov	dptr,#_batch_depth
      003FD4 F0               [24] 1014 	movx	@dptr,a
      003FD5                       1015 00102$:
                                   1016 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003FD5 90 05 5A         [24] 1017 	mov	dptr,#_batch_depth
      003FD8 E0               [24] 1018 	movx	a,@dptr
      003FD9 70 03            [24] 1019 	jnz	00105$
                                   1020 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003FDB 02 3E 60         [24] 1021 	ljmp	_ak820_nvm_flush
      003FDE                       1022 00105$:
      003FDE 22               [24] 1023 	ret
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'load_page'
                                   1026 ;------------------------------------------------------------
                                   1027 ;page          Allocated with name '_load_page_page_10000_87'
                                   1028 ;i             Allocated with name '_load_page_i_10000_88'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function load_page
                                   1033 ;	-----------------------------------------
      003FDF                       1034 _load_page:
      003FDF E5 82            [12] 1035 	mov	a,dpl
      003FE1 90 05 7B         [24] 1036 	mov	dptr,#_load_page_page_10000_87
      003FE4 F0               [24] 1037 	movx	@dptr,a
                                   1038 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003FE5 30 07 17         [24] 1039 	jnb	_page_valid,00102$
      003FE8 90 05 59         [24] 1040 	mov	dptr,#_cached_page
      003FEB E0               [24] 1041 	movx	a,@dptr
      003FEC FF               [12] 1042 	mov	r7,a
      003FED 90 05 7B         [24] 1043 	mov	dptr,#_load_page_page_10000_87
      003FF0 E0               [24] 1044 	movx	a,@dptr
      003FF1 FE               [12] 1045 	mov	r6,a
      003FF2 EF               [12] 1046 	mov	a,r7
      003FF3 B5 06 09         [24] 1047 	cjne	a,ar6,00102$
      003FF6 A2 09            [12] 1048 	mov	c,_storage_failed
      003FF8 B3               [12] 1049 	cpl	c
      003FF9 92 0B            [24] 1050 	mov  _load_page_sloc0_1_0,c
      003FFB 12 38 86         [24] 1051 	lcall	_ak820_outline_0167
      003FFE 22               [24] 1052 	ret
      003FFF                       1053 00102$:
                                   1054 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003FFF 12 3E 60         [24] 1055 	lcall	_ak820_nvm_flush
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      004002 30 09 04         [24] 1057 	jnb	_storage_failed,00119$
      004005 75 82 00         [24] 1058 	mov	dpl, #0x00
                                   1059 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004008 22               [24] 1060 	ret
      004009                       1061 00119$:
      004009 7F 00            [12] 1062 	mov	r7,#0x00
      00400B                       1063 00107$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      00400B EF               [12] 1065 	mov	a,r7
      00400C 24 19            [12] 1066 	add	a, #_page_data
      00400E FD               [12] 1067 	mov	r5,a
      00400F E4               [12] 1068 	clr	a
      004010 34 05            [12] 1069 	addc	a, #(_page_data >> 8)
      004012 FE               [12] 1070 	mov	r6,a
      004013 90 05 7B         [24] 1071 	mov	dptr,#_load_page_page_10000_87
      004016 E0               [24] 1072 	movx	a,@dptr
      004017 FC               [12] 1073 	mov	r4,a
      004018 FA               [12] 1074 	mov	r2,a
      004019 E4               [12] 1075 	clr	a
      00401A C3               [12] 1076 	clr	c
      00401B CA               [12] 1077 	xch	a,r2
      00401C 13               [12] 1078 	rrc	a
      00401D CA               [12] 1079 	xch	a,r2
      00401E 13               [12] 1080 	rrc	a
      00401F A2 E0            [12] 1081 	mov	c,acc.0
      004021 CA               [12] 1082 	xch	a,r2
      004022 13               [12] 1083 	rrc	a
      004023 CA               [12] 1084 	xch	a,r2
      004024 13               [12] 1085 	rrc	a
      004025 CA               [12] 1086 	xch	a,r2
      004026 24 C7            [12] 1087 	add	a,#0xc7
      004028 FB               [12] 1088 	mov	r3,a
      004029 8F 01            [24] 1089 	mov	ar1,r7
      00402B 89 00            [24] 1090 	mov	ar0,r1
      00402D 79 00            [12] 1091 	mov	r1,#0x00
      00402F E8               [12] 1092 	mov	a,r0
      004030 2A               [12] 1093 	add	a, r2
      004031 FA               [12] 1094 	mov	r2,a
      004032 E9               [12] 1095 	mov	a,r1
      004033 3B               [12] 1096 	addc	a, r3
      004034 FB               [12] 1097 	mov	r3,a
      004035 12 43 AE         [24] 1098 	lcall	_ak820_outline_0141
      004038 12 38 B9         [24] 1099 	lcall	_ak820_flash_read
      00403B AB 82            [24] 1100 	mov	r3, dpl
      00403D 12 38 6A         [24] 1101 	lcall	_ak820_outline_0133
      004040 EB               [12] 1102 	mov	a,r3
      004041 F0               [24] 1103 	movx	@dptr,a
                                   1104 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004042 0F               [12] 1105 	inc	r7
      004043 BF 40 C5         [24] 1106 	cjne	r7,#0x40,00107$
                                   1107 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004046 90 05 59         [24] 1108 	mov	dptr,#_cached_page
      004049 EC               [12] 1109 	mov	a,r4
      00404A F0               [24] 1110 	movx	@dptr,a
                                   1111 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1112 ;	assignBit
      00404B D2 07            [12] 1113 	setb	_page_valid
                                   1114 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      00404D 75 82 01         [24] 1115 	mov	dpl, #0x01
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004050 22               [24] 1117 	ret
                                   1118 ;------------------------------------------------------------
                                   1119 ;Allocation info for local variables in function 'read_offset'
                                   1120 ;------------------------------------------------------------
                                   1121 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1122 ;------------------------------------------------------------
                                   1123 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1124 ;	-----------------------------------------
                                   1125 ;	 function read_offset
                                   1126 ;	-----------------------------------------
      004051                       1127 _read_offset:
      004051 12 38 43         [24] 1128 	lcall	_ak820_outline_0103
      004054 90 05 7C         [24] 1129 	mov	dptr,#_read_offset_offset_10000_93
      004057 12 38 48         [24] 1130 	lcall	_ak820_outline_0104
                                   1131 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      00405A 90 05 7C         [24] 1132 	mov	dptr,#_read_offset_offset_10000_93
      00405D 12 38 00         [24] 1133 	lcall	_ak820_outline_0051
      004060 C3               [12] 1134 	clr	c
      004061 94 28            [12] 1135 	subb	a,#0x28
      004063 40 04            [24] 1136 	jc	00102$
      004065 75 82 00         [24] 1137 	mov	dpl, #0x00
      004068 22               [24] 1138 	ret
      004069                       1139 00102$:
                                   1140 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004069 30 07 34         [24] 1141 	jnb	_page_valid,00104$
      00406C 8E 04            [24] 1142 	mov	ar4,r6
      00406E EF               [12] 1143 	mov	a,r7
      00406F A2 E7            [12] 1144 	mov	c,acc.7
      004071 CC               [12] 1145 	xch	a,r4
      004072 33               [12] 1146 	rlc	a
      004073 CC               [12] 1147 	xch	a,r4
      004074 33               [12] 1148 	rlc	a
      004075 A2 E7            [12] 1149 	mov	c,acc.7
      004077 CC               [12] 1150 	xch	a,r4
      004078 33               [12] 1151 	rlc	a
      004079 CC               [12] 1152 	xch	a,r4
      00407A 33               [12] 1153 	rlc	a
      00407B CC               [12] 1154 	xch	a,r4
      00407C 54 03            [12] 1155 	anl	a,#0x03
      00407E FD               [12] 1156 	mov	r5,a
      00407F 90 05 59         [24] 1157 	mov	dptr,#_cached_page
      004082 E0               [24] 1158 	movx	a,@dptr
      004083 FA               [12] 1159 	mov	r2,a
      004084 7B 00            [12] 1160 	mov	r3,#0x00
      004086 EC               [12] 1161 	mov	a,r4
      004087 B5 02 16         [24] 1162 	cjne	a,ar2,00104$
      00408A ED               [12] 1163 	mov	a,r5
      00408B B5 03 12         [24] 1164 	cjne	a,ar3,00104$
                                   1165 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      00408E 74 3F            [12] 1166 	mov	a,#0x3f
      004090 5E               [12] 1167 	anl	a,r6
      004091 7D 00            [12] 1168 	mov	r5,#0x00
      004093 24 19            [12] 1169 	add	a, #_page_data
      004095 F5 82            [12] 1170 	mov	dpl,a
      004097 ED               [12] 1171 	mov	a,r5
      004098 34 05            [12] 1172 	addc	a, #(_page_data >> 8)
      00409A F5 83            [12] 1173 	mov	dph,a
      00409C E0               [24] 1174 	movx	a,@dptr
      00409D F5 82            [12] 1175 	mov	dpl,a
      00409F 22               [24] 1176 	ret
      0040A0                       1177 00104$:
                                   1178 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0040A0 74 C7            [12] 1179 	mov	a,#0xc7
      0040A2 2F               [12] 1180 	add	a, r7
      0040A3 FF               [12] 1181 	mov	r7,a
      0040A4 12 43 92         [24] 1182 	lcall	_ak820_outline_0116
                                   1183 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0040A7 02 38 B9         [24] 1184 	ljmp	_ak820_flash_read
                                   1185 ;------------------------------------------------------------
                                   1186 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1187 ;------------------------------------------------------------
                                   1188 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function eeprom_read_byte
                                   1193 ;	-----------------------------------------
      0040AA                       1194 _eeprom_read_byte:
      0040AA C0 07            [24] 1195 	push	ar7
      0040AC C0 06            [24] 1196 	push	ar6
      0040AE 12 43 49         [24] 1197 	lcall	_ak820_outline_0037
      0040B1 90 05 7E         [24] 1198 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040B4 12 37 DF         [24] 1199 	lcall	_ak820_outline_0016
                                   1200 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0040B7 90 05 7E         [24] 1201 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040BA 12 37 A0         [24] 1202 	lcall	_ak820_outline_0004
      0040BD C0 06            [24] 1203 	push	ar6
      0040BF C0 05            [24] 1204 	push	ar5
      0040C1 C0 04            [24] 1205 	push	ar4
      0040C3 C0 03            [24] 1206 	push	ar3
      0040C5 C0 02            [24] 1207 	push	ar2
      0040C7 C0 01            [24] 1208 	push	ar1
      0040C9 C0 00            [24] 1209 	push	ar0
      0040CB 12 40 51         [24] 1210 	lcall	_read_offset
      0040CE AF 82            [24] 1211 	mov	r7, dpl
      0040D0 D0 00            [24] 1212 	pop	ar0
      0040D2 D0 01            [24] 1213 	pop	ar1
      0040D4 D0 02            [24] 1214 	pop	ar2
      0040D6 D0 03            [24] 1215 	pop	ar3
      0040D8 D0 04            [24] 1216 	pop	ar4
      0040DA D0 05            [24] 1217 	pop	ar5
      0040DC D0 06            [24] 1218 	pop	ar6
      0040DE 8F 82            [24] 1219 	mov	dpl, r7
                                   1220 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0040E0 D0 06            [24] 1221 	pop	ar6
      0040E2 D0 07            [24] 1222 	pop	ar7
      0040E4 22               [24] 1223 	ret
                                   1224 ;------------------------------------------------------------
                                   1225 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1226 ;------------------------------------------------------------
                                   1227 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1228 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1229 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1230 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1231 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1232 ;------------------------------------------------------------
                                   1233 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1234 ;	-----------------------------------------
                                   1235 ;	 function ak820_eeprom_read_block_xdata
                                   1236 ;	-----------------------------------------
      0040E5                       1237 _ak820_eeprom_read_block_xdata:
      0040E5 12 38 43         [24] 1238 	lcall	_ak820_outline_0103
      0040E8 90 05 86         [24] 1239 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040EB 12 38 48         [24] 1240 	lcall	_ak820_outline_0104
                                   1241 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040EE 90 05 81         [24] 1242 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0040F1 12 38 00         [24] 1243 	lcall	_ak820_outline_0051
                                   1244 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0040F4 90 05 86         [24] 1245 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040F7 12 38 1F         [24] 1246 	lcall	_ak820_outline_0060
      0040FA 90 05 88         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040FD 12 38 25         [24] 1248 	lcall	_ak820_outline_0071
                                   1249 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004100 90 05 84         [24] 1250 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004103 12 38 1F         [24] 1251 	lcall	_ak820_outline_0060
      004106                       1252 00103$:
      004106 8C 02            [24] 1253 	mov	ar2,r4
      004108 8D 03            [24] 1254 	mov	ar3,r5
      00410A 1C               [12] 1255 	dec	r4
      00410B BC FF 01         [24] 1256 	cjne	r4,#0xff,00130$
      00410E 1D               [12] 1257 	dec	r5
      00410F                       1258 00130$:
      00410F EA               [12] 1259 	mov	a,r2
      004110 4B               [12] 1260 	orl	a,r3
      004111 60 5D            [24] 1261 	jz	00106$
                                   1262 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      004113 8E 02            [24] 1263 	mov	ar2,r6
      004115 8F 03            [24] 1264 	mov	ar3,r7
      004117 74 D8            [12] 1265 	mov	a,#0x100 - 0x28
      004119 2B               [12] 1266 	add	a,r3
      00411A 50 17            [24] 1267 	jnc	00102$
      00411C 90 05 88         [24] 1268 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00411F 12 43 97         [24] 1269 	lcall	_ak820_outline_0120
      004122 12 43 AE         [24] 1270 	lcall	_ak820_outline_0141
      004125 E4               [12] 1271 	clr	a
      004126 F0               [24] 1272 	movx	@dptr,a
      004127 90 05 88         [24] 1273 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00412A 04               [12] 1274 	inc	a
      00412B 2A               [12] 1275 	add	a, r2
      00412C F0               [24] 1276 	movx	@dptr,a
      00412D E4               [12] 1277 	clr	a
      00412E 3B               [12] 1278 	addc	a, r3
      00412F A3               [24] 1279 	inc	dptr
      004130 F0               [24] 1280 	movx	@dptr,a
      004131 80 D3            [24] 1281 	sjmp	00103$
      004133                       1282 00102$:
                                   1283 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004133 90 05 88         [24] 1284 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004136 12 43 97         [24] 1285 	lcall	_ak820_outline_0120
      004139 12 43 92         [24] 1286 	lcall	_ak820_outline_0116
      00413C C0 07            [24] 1287 	push	ar7
      00413E C0 06            [24] 1288 	push	ar6
      004140 C0 05            [24] 1289 	push	ar5
      004142 C0 04            [24] 1290 	push	ar4
      004144 C0 03            [24] 1291 	push	ar3
      004146 C0 02            [24] 1292 	push	ar2
      004148 12 40 51         [24] 1293 	lcall	_read_offset
      00414B A9 82            [24] 1294 	mov	r1, dpl
      00414D D0 02            [24] 1295 	pop	ar2
      00414F D0 03            [24] 1296 	pop	ar3
      004151 D0 04            [24] 1297 	pop	ar4
      004153 D0 05            [24] 1298 	pop	ar5
      004155 D0 06            [24] 1299 	pop	ar6
      004157 D0 07            [24] 1300 	pop	ar7
      004159 12 43 AE         [24] 1301 	lcall	_ak820_outline_0141
      00415C E9               [12] 1302 	mov	a,r1
      00415D F0               [24] 1303 	movx	@dptr,a
      00415E 90 05 88         [24] 1304 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004161 74 01            [12] 1305 	mov	a,#0x01
      004163 2A               [12] 1306 	add	a, r2
      004164 F0               [24] 1307 	movx	@dptr,a
      004165 E4               [12] 1308 	clr	a
      004166 3B               [12] 1309 	addc	a, r3
      004167 A3               [24] 1310 	inc	dptr
      004168 F0               [24] 1311 	movx	@dptr,a
                                   1312 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004169 0E               [12] 1313 	inc	r6
      00416A BE 00 99         [24] 1314 	cjne	r6,#0x00,00103$
      00416D 0F               [12] 1315 	inc	r7
      00416E 80 96            [24] 1316 	sjmp	00103$
      004170                       1317 00106$:
                                   1318 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004170 22               [24] 1319 	ret
                                   1320 ;------------------------------------------------------------
                                   1321 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1322 ;------------------------------------------------------------
                                   1323 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1324 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1325 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1326 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1327 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1328 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1329 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1330 ;------------------------------------------------------------
                                   1331 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1332 ;	-----------------------------------------
                                   1333 ;	 function ak820_eeprom_write_block_xdata
                                   1334 ;	-----------------------------------------
      004171                       1335 _ak820_eeprom_write_block_xdata:
      004171 12 38 43         [24] 1336 	lcall	_ak820_outline_0103
      004174 90 05 8F         [24] 1337 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004177 12 38 48         [24] 1338 	lcall	_ak820_outline_0104
                                   1339 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00417A 90 05 8A         [24] 1340 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00417D 12 38 00         [24] 1341 	lcall	_ak820_outline_0051
                                   1342 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004180 90 05 8F         [24] 1343 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004183 12 38 1F         [24] 1344 	lcall	_ak820_outline_0060
                                   1345 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004186 8E 02            [24] 1346 	mov	ar2,r6
      004188 8F 03            [24] 1347 	mov	ar3,r7
      00418A C3               [12] 1348 	clr	c
      00418B E4               [12] 1349 	clr	a
      00418C 9A               [12] 1350 	subb	a,r2
      00418D 74 28            [12] 1351 	mov	a,#0x28
      00418F 9B               [12] 1352 	subb	a,r3
      004190 40 15            [24] 1353 	jc	00101$
                                   1354 ;	free result
      004192 E4               [12] 1355 	clr	a
      004193 C3               [12] 1356 	clr	c
      004194 9E               [12] 1357 	subb	a,r6
      004195 FA               [12] 1358 	mov	r2,a
      004196 74 28            [12] 1359 	mov	a,#0x28
      004198 9F               [12] 1360 	subb	a,r7
      004199 FB               [12] 1361 	mov	r3,a
      00419A 90 05 8D         [24] 1362 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00419D 12 38 3D         [24] 1363 	lcall	_ak820_outline_0100
      0041A0 C3               [12] 1364 	clr	c
      0041A1 EA               [12] 1365 	mov	a,r2
      0041A2 98               [12] 1366 	subb	a,r0
      0041A3 EB               [12] 1367 	mov	a,r3
      0041A4 99               [12] 1368 	subb	a,r1
      0041A5 50 06            [24] 1369 	jnc	00125$
                                   1370 ;	free result
      0041A7                       1371 00101$:
                                   1372 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0041A7 75 82 0E         [24] 1373 	mov	dpl, #0x0e
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0041AA 02 3B BB         [24] 1375 	ljmp	_nvm_fail
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0041AD                       1377 00125$:
      0041AD 90 05 8D         [24] 1378 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0041B0 12 43 97         [24] 1379 	lcall	_ak820_outline_0120
      0041B3                       1380 00108$:
      0041B3 8A 00            [24] 1381 	mov	ar0,r2
      0041B5 8B 01            [24] 1382 	mov	ar1,r3
      0041B7 1A               [12] 1383 	dec	r2
      0041B8 BA FF 01         [24] 1384 	cjne	r2,#0xff,00159$
      0041BB 1B               [12] 1385 	dec	r3
      0041BC                       1386 00159$:
      0041BC E8               [12] 1387 	mov	a,r0
      0041BD 49               [12] 1388 	orl	a,r1
      0041BE 70 03            [24] 1389 	jnz	00160$
      0041C0 02 42 4A         [24] 1390 	ljmp	00110$
      0041C3                       1391 00160$:
                                   1392 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0041C3 C0 02            [24] 1393 	push	ar2
      0041C5 C0 03            [24] 1394 	push	ar3
      0041C7 12 43 80         [24] 1395 	lcall	_ak820_outline_0093
      0041CA F9               [12] 1396 	mov	r1,a
      0041CB A3               [24] 1397 	inc	dptr
      0041CC 12 43 B3         [24] 1398 	lcall	_ak820_outline_0146
                                   1399 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0041CF 8E 0C            [24] 1400 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0041D1 8F 0D            [24] 1401 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0041D3 A8 0C            [24] 1402 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041D5 E5 0D            [12] 1403 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041D7 A2 E7            [12] 1404 	mov	c,acc.7
      0041D9 C8               [12] 1405 	xch	a,r0
      0041DA 33               [12] 1406 	rlc	a
      0041DB C8               [12] 1407 	xch	a,r0
      0041DC 33               [12] 1408 	rlc	a
      0041DD A2 E7            [12] 1409 	mov	c,acc.7
      0041DF C8               [12] 1410 	xch	a,r0
      0041E0 33               [12] 1411 	rlc	a
      0041E1 C8               [12] 1412 	xch	a,r0
      0041E2 33               [12] 1413 	rlc	a
      0041E3 C8               [12] 1414 	xch	a,r0
      0041E4 54 03            [12] 1415 	anl	a,#0x03
      0041E6 FB               [12] 1416 	mov	r3,a
      0041E7 88 82            [24] 1417 	mov	dpl, r0
      0041E9 C0 07            [24] 1418 	push	ar7
      0041EB C0 06            [24] 1419 	push	ar6
      0041ED C0 05            [24] 1420 	push	ar5
      0041EF C0 04            [24] 1421 	push	ar4
      0041F1 C0 03            [24] 1422 	push	ar3
      0041F3 C0 02            [24] 1423 	push	ar2
      0041F5 C0 01            [24] 1424 	push	ar1
      0041F7 12 3F DF         [24] 1425 	lcall	_load_page
      0041FA E5 82            [12] 1426 	mov	a, dpl
      0041FC D0 01            [24] 1427 	pop	ar1
      0041FE D0 02            [24] 1428 	pop	ar2
      004200 D0 03            [24] 1429 	pop	ar3
      004202 D0 04            [24] 1430 	pop	ar4
      004204 D0 05            [24] 1431 	pop	ar5
      004206 D0 06            [24] 1432 	pop	ar6
      004208 D0 07            [24] 1433 	pop	ar7
      00420A D0 03            [24] 1434 	pop	ar3
      00420C D0 02            [24] 1435 	pop	ar2
      00420E 70 01            [24] 1436 	jnz	00105$
      004210 22               [24] 1437 	ret
      004211                       1438 00105$:
                                   1439 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004211 C0 06            [24] 1440 	push	ar6
      004213 C0 07            [24] 1441 	push	ar7
      004215 74 3F            [12] 1442 	mov	a,#0x3f
      004217 55 0C            [12] 1443 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004219 7F 00            [12] 1444 	mov	r7,#0x00
      00421B 24 19            [12] 1445 	add	a, #_page_data
      00421D F5 0C            [12] 1446 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      00421F EF               [12] 1447 	mov	a,r7
      004220 34 05            [12] 1448 	addc	a, #(_page_data >> 8)
      004222 F5 0D            [12] 1449 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      004224 85 0C 82         [24] 1450 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004227 85 0D 83         [24] 1451 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00422A E0               [24] 1452 	movx	a,@dptr
      00422B B5 01 06         [24] 1453 	cjne	a,ar1,00162$
      00422E D0 07            [24] 1454 	pop	ar7
      004230 D0 06            [24] 1455 	pop	ar6
      004232 80 0E            [24] 1456 	sjmp	00107$
      004234                       1457 00162$:
      004234 D0 07            [24] 1458 	pop	ar7
      004236 D0 06            [24] 1459 	pop	ar6
                                   1460 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004238 85 0C 82         [24] 1461 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00423B 85 0D 83         [24] 1462 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00423E E9               [12] 1463 	mov	a,r1
      00423F F0               [24] 1464 	movx	@dptr,a
                                   1465 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1466 ;	assignBit
      004240 D2 08            [12] 1467 	setb	_page_dirty
      004242                       1468 00107$:
                                   1469 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004242 0E               [12] 1470 	inc	r6
      004243 BE 00 01         [24] 1471 	cjne	r6,#0x00,00163$
      004246 0F               [12] 1472 	inc	r7
      004247                       1473 00163$:
      004247 02 41 B3         [24] 1474 	ljmp	00108$
      00424A                       1475 00110$:
                                   1476 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00424A 90 05 5A         [24] 1477 	mov	dptr,#_batch_depth
      00424D E0               [24] 1478 	movx	a,@dptr
      00424E 70 03            [24] 1479 	jnz	00113$
                                   1480 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004250 02 3E 60         [24] 1481 	ljmp	_ak820_nvm_flush
      004253                       1482 00113$:
      004253 22               [24] 1483 	ret
                                   1484 ;------------------------------------------------------------
                                   1485 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1486 ;------------------------------------------------------------
                                   1487 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1488 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1489 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1490 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1491 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1492 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1493 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1494 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1495 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1496 ;------------------------------------------------------------
                                   1497 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1498 ;	-----------------------------------------
                                   1499 ;	 function ak820_eeprom_update_block_xdata
                                   1500 ;	-----------------------------------------
      004254                       1501 _ak820_eeprom_update_block_xdata:
      004254 12 38 43         [24] 1502 	lcall	_ak820_outline_0103
      004257 90 05 96         [24] 1503 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00425A 12 38 48         [24] 1504 	lcall	_ak820_outline_0104
                                   1505 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      00425D 90 05 96         [24] 1506 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004260 12 38 00         [24] 1507 	lcall	_ak820_outline_0051
                                   1508 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004263 90 05 91         [24] 1509 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004266 E0               [24] 1510 	movx	a,@dptr
      004267 F5 12            [12] 1511 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004269 A3               [24] 1512 	inc	dptr
      00426A E0               [24] 1513 	movx	a,@dptr
      00426B F5 13            [12] 1514 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      00426D A3               [24] 1515 	inc	dptr
      00426E E0               [24] 1516 	movx	a,@dptr
      00426F F5 14            [12] 1517 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004271 A9 12            [24] 1518 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004273 AA 13            [24] 1519 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1520 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004275 E4               [12] 1521 	clr	a
      004276 F5 0E            [12] 1522 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004278 F5 0F            [12] 1523 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00427A                       1524 00105$:
      00427A 90 05 94         [24] 1525 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00427D E0               [24] 1526 	movx	a,@dptr
      00427E F5 10            [12] 1527 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004280 A3               [24] 1528 	inc	dptr
      004281 E0               [24] 1529 	movx	a,@dptr
      004282 F5 11            [12] 1530 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004284 C3               [12] 1531 	clr	c
      004285 E5 0E            [12] 1532 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004287 95 10            [12] 1533 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004289 E5 0F            [12] 1534 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00428B 95 11            [12] 1535 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00428D 50 68            [24] 1536 	jnc	00107$
                                   1537 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      00428F 89 00            [24] 1538 	mov	ar0,r1
      004291 8A 05            [24] 1539 	mov	ar5,r2
      004293 E5 0E            [12] 1540 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004295 28               [12] 1541 	add	a, r0
      004296 F8               [12] 1542 	mov	r0,a
      004297 E5 0F            [12] 1543 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004299 3D               [12] 1544 	addc	a, r5
      00429A FD               [12] 1545 	mov	r5,a
      00429B 88 82            [24] 1546 	mov	dpl, r0
      00429D 8D 83            [24] 1547 	mov	dph, r5
      00429F C0 07            [24] 1548 	push	ar7
      0042A1 C0 06            [24] 1549 	push	ar6
      0042A3 C0 02            [24] 1550 	push	ar2
      0042A5 C0 01            [24] 1551 	push	ar1
      0042A7 12 40 51         [24] 1552 	lcall	_read_offset
      0042AA AD 82            [24] 1553 	mov	r5, dpl
      0042AC D0 01            [24] 1554 	pop	ar1
      0042AE D0 02            [24] 1555 	pop	ar2
      0042B0 D0 06            [24] 1556 	pop	ar6
      0042B2 D0 07            [24] 1557 	pop	ar7
      0042B4 E5 0E            [12] 1558 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042B6 2E               [12] 1559 	add	a, r6
      0042B7 F5 82            [12] 1560 	mov	dpl,a
      0042B9 E5 0F            [12] 1561 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042BB 3F               [12] 1562 	addc	a, r7
      0042BC F5 83            [12] 1563 	mov	dph,a
      0042BE E0               [24] 1564 	movx	a,@dptr
      0042BF FC               [12] 1565 	mov	r4,a
      0042C0 ED               [12] 1566 	mov	a,r5
      0042C1 B5 04 02         [24] 1567 	cjne	a,ar4,00131$
      0042C4 80 27            [24] 1568 	sjmp	00106$
      0042C6                       1569 00131$:
                                   1570 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      0042C6 90 05 96         [24] 1571 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0042C9 E0               [24] 1572 	movx	a,@dptr
      0042CA F8               [12] 1573 	mov	r0,a
      0042CB A3               [24] 1574 	inc	dptr
      0042CC E0               [24] 1575 	movx	a,@dptr
      0042CD FD               [12] 1576 	mov	r5,a
      0042CE 90 05 8A         [24] 1577 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0042D1 E5 12            [12] 1578 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0042D3 F0               [24] 1579 	movx	@dptr,a
      0042D4 E5 13            [12] 1580 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0042D6 A3               [24] 1581 	inc	dptr
      0042D7 F0               [24] 1582 	movx	@dptr,a
      0042D8 E5 14            [12] 1583 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0042DA A3               [24] 1584 	inc	dptr
      0042DB F0               [24] 1585 	movx	@dptr,a
      0042DC 90 05 8D         [24] 1586 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0042DF E5 10            [12] 1587 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042E1 F0               [24] 1588 	movx	@dptr,a
      0042E2 E5 11            [12] 1589 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042E4 A3               [24] 1590 	inc	dptr
      0042E5 F0               [24] 1591 	movx	@dptr,a
      0042E6 88 82            [24] 1592 	mov	dpl, r0
      0042E8 8D 83            [24] 1593 	mov	dph, r5
                                   1594 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0042EA 02 41 71         [24] 1595 	ljmp	_ak820_eeprom_write_block_xdata
      0042ED                       1596 00106$:
                                   1597 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042ED 05 0E            [12] 1598 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042EF E4               [12] 1599 	clr	a
      0042F0 B5 0E 87         [24] 1600 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0042F3 05 0F            [12] 1601 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042F5 80 83            [24] 1602 	sjmp	00105$
      0042F7                       1603 00107$:
                                   1604 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0042F7 22               [24] 1605 	ret
                                   1606 ;------------------------------------------------------------
                                   1607 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1608 ;------------------------------------------------------------
                                   1609 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1610 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1611 ;------------------------------------------------------------
                                   1612 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1613 ;	-----------------------------------------
                                   1614 ;	 function eeprom_driver_erase
                                   1615 ;	-----------------------------------------
      0042F8                       1616 _eeprom_driver_erase:
                                   1617 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0042F8 12 3E 60         [24] 1618 	lcall	_ak820_nvm_flush
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042FB 7F 00            [12] 1620 	mov	r7,#0x00
      0042FD                       1621 00111$:
      0042FD BF A0 01         [24] 1622 	cjne	r7,#0xa0,00165$
      004300 22               [24] 1623 	ret
      004301                       1624 00165$:
      004301 20 09 32         [24] 1625 	jb	_storage_failed,00113$
                                   1626 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004304 8F 82            [24] 1627 	mov	dpl, r7
      004306 C0 07            [24] 1628 	push	ar7
      004308 12 3F DF         [24] 1629 	lcall	_load_page
      00430B E5 82            [12] 1630 	mov	a, dpl
      00430D D0 07            [24] 1631 	pop	ar7
      00430F 70 01            [24] 1632 	jnz	00126$
                                   1633 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004311 22               [24] 1634 	ret
      004312                       1635 00126$:
      004312 7E 00            [12] 1636 	mov	r6,#0x00
      004314                       1637 00107$:
                                   1638 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      004314 EE               [12] 1639 	mov	a,r6
      004315 24 19            [12] 1640 	add	a, #_page_data
      004317 FC               [12] 1641 	mov	r4,a
      004318 E4               [12] 1642 	clr	a
      004319 34 05            [12] 1643 	addc	a, #(_page_data >> 8)
      00431B FD               [12] 1644 	mov	r5,a
      00431C 12 43 80         [24] 1645 	lcall	_ak820_outline_0093
      00431F 60 07            [24] 1646 	jz	00108$
      004321 12 38 60         [24] 1647 	lcall	_ak820_outline_0122
      004324 E4               [12] 1648 	clr	a
      004325 F0               [24] 1649 	movx	@dptr,a
                                   1650 ;	assignBit
      004326 D2 08            [12] 1651 	setb	_page_dirty
      004328                       1652 00108$:
                                   1653 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004328 0E               [12] 1654 	inc	r6
      004329 BE 40 E8         [24] 1655 	cjne	r6,#0x40,00107$
                                   1656 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      00432C C0 07            [24] 1657 	push	ar7
      00432E 12 3E 60         [24] 1658 	lcall	_ak820_nvm_flush
      004331 D0 07            [24] 1659 	pop	ar7
                                   1660 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004333 0F               [12] 1661 	inc	r7
      004334 80 C7            [24] 1662 	sjmp	00111$
      004336                       1663 00113$:
                                   1664 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004336 22               [24] 1665 	ret
                                   1666 	.area CSEG    (CODE)
                                   1667 	.area CONST   (CODE)
                                   1668 	.area XINIT   (CODE)
                                   1669 	.area CABS    (ABS,CODE)
                                   1670 
                                   1671 ; Experimental exact instruction outlining.
                                   1672 	.globl _ak820_outline_0004
                                   1673 	.globl _ak820_outline_0010
                                   1674 	.globl _ak820_outline_0016
                                   1675 	.globl _ak820_outline_0017
                                   1676 	.globl _ak820_outline_0030
                                   1677 	.globl _ak820_outline_0037
                                   1678 	.globl _ak820_outline_0041
                                   1679 	.globl _ak820_outline_0051
                                   1680 	.globl _ak820_outline_0052
                                   1681 	.globl _ak820_outline_0060
                                   1682 	.globl _ak820_outline_0061
                                   1683 	.globl _ak820_outline_0065
                                   1684 	.globl _ak820_outline_0071
                                   1685 	.globl _ak820_outline_0077
                                   1686 	.globl _ak820_outline_0091
                                   1687 	.globl _ak820_outline_0093
                                   1688 	.globl _ak820_outline_0100
                                   1689 	.globl _ak820_outline_0101
                                   1690 	.globl _ak820_outline_0103
                                   1691 	.globl _ak820_outline_0104
                                   1692 	.globl _ak820_outline_0116
                                   1693 	.globl _ak820_outline_0120
                                   1694 	.globl _ak820_outline_0121
                                   1695 	.globl _ak820_outline_0122
                                   1696 	.globl _ak820_outline_0123
                                   1697 	.globl _ak820_outline_0132
                                   1698 	.globl _ak820_outline_0133
                                   1699 	.globl _ak820_outline_0135
                                   1700 	.globl _ak820_outline_0140
                                   1701 	.globl _ak820_outline_0141
                                   1702 	.globl _ak820_outline_0146
                                   1703 	.globl _ak820_outline_0154
                                   1704 	.globl _ak820_outline_0157
                                   1705 	.globl _ak820_outline_0158
                                   1706 	.globl _ak820_outline_0167
                                   1707 	.globl _ak820_outline_0180
                                   1708 	.globl _ak820_outline_0181
                                   1709 	.globl _ak820_outline_0185
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0010
      004337                       1713 _ak820_outline_0010:
      004337 8E 82            [24] 1714 	mov	dpl,r6
      004339 8F 83            [24] 1715 	mov	dph,r7
      00433B A3               [24] 1716 	inc	dptr
      00433C A3               [24] 1717 	inc	dptr
      00433D A3               [24] 1718 	inc	dptr
      00433E A3               [24] 1719 	inc	dptr
      00433F A3               [24] 1720 	inc	dptr
      004340 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0030
      004341                       1725 _ak820_outline_0030:
      004341 F0               [24] 1726 	movx	@dptr,a
      004342 8E 82            [24] 1727 	mov	dpl,r6
      004344 8F 83            [24] 1728 	mov	dph,r7
      004346 A3               [24] 1729 	inc	dptr
      004347 A3               [24] 1730 	inc	dptr
      004348 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0037
      004349                       1735 _ak820_outline_0037:
      004349 AF F0            [24] 1736 	mov	r7,b
      00434B AE 83            [24] 1737 	mov	r6,dph
      00434D E5 82            [12] 1738 	mov	a,dpl
      00434F 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0041
      004350                       1743 _ak820_outline_0041:
      004350 EF               [12] 1744 	mov	a,r7
      004351 24 71            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      004353 F5 82            [12] 1746 	mov	dpl,a
      004355 E4               [12] 1747 	clr	a
      004356 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004358 F5 83            [12] 1749 	mov	dph,a
      00435A E0               [24] 1750 	movx	a,@dptr
      00435B 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0052
      00435C                       1755 _ak820_outline_0052:
      00435C 8F 06            [24] 1756 	mov	ar6,r7
      00435E 7D 00            [12] 1757 	mov	r5,#0x00
      004360 74 40            [12] 1758 	mov	a,#0x40
      004362 2E               [12] 1759 	add	a,r6
      004363 FE               [12] 1760 	mov	r6,a
      004364 74 EF            [12] 1761 	mov	a,#0xef
      004366 3D               [12] 1762 	addc	a,r5
      004367 FD               [12] 1763 	mov	r5,a
      004368 8E 82            [24] 1764 	mov	dpl,r6
      00436A 8D 83            [24] 1765 	mov	dph,r5
      00436C 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0061
      00436D                       1770 _ak820_outline_0061:
      00436D F0               [24] 1771 	movx	@dptr,a
      00436E 8E 82            [24] 1772 	mov	dpl,r6
      004370 8F 83            [24] 1773 	mov	dph,r7
      004372 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0065
      004373                       1778 _ak820_outline_0065:
      004373 8D 82            [24] 1779 	mov	dpl,r5
      004375 8E 83            [24] 1780 	mov	dph,r6
      004377 EC               [12] 1781 	mov	a,r4
      004378 F0               [24] 1782 	movx	@dptr,a
      004379 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0091
      00437A                       1787 _ak820_outline_0091:
      00437A E0               [24] 1788 	movx	a,@dptr
      00437B FD               [12] 1789 	mov	r5,a
      00437C A3               [24] 1790 	inc	dptr
      00437D E0               [24] 1791 	movx	a,@dptr
      00437E FE               [12] 1792 	mov	r6,a
      00437F 22               [24] 1793 	ret
                                   1794 
                                   1795 	.area CSEG (CODE)
                                   1796 ; function ak820_outline_0093
      004380                       1797 _ak820_outline_0093:
      004380 8C 82            [24] 1798 	mov	dpl,r4
      004382 8D 83            [24] 1799 	mov	dph,r5
      004384 E0               [24] 1800 	movx	a,@dptr
      004385 22               [24] 1801 	ret
                                   1802 
                                   1803 	.area CSEG (CODE)
                                   1804 ; function ak820_outline_0101
      004386                       1805 _ak820_outline_0101:
      004386 EF               [12] 1806 	mov	a,r7
      004387 24 19            [12] 1807 	add	a,#_page_data
      004389 F5 82            [12] 1808 	mov	dpl,a
      00438B E4               [12] 1809 	clr	a
      00438C 34 05            [12] 1810 	addc	a,#(_page_data>>8)
      00438E F5 83            [12] 1811 	mov	dph,a
      004390 E0               [24] 1812 	movx	a,@dptr
      004391 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0116
      004392                       1817 _ak820_outline_0116:
      004392 8E 82            [24] 1818 	mov	dpl,r6
      004394 8F 83            [24] 1819 	mov	dph,r7
      004396 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0120
      004397                       1824 _ak820_outline_0120:
      004397 E0               [24] 1825 	movx	a,@dptr
      004398 FA               [12] 1826 	mov	r2,a
      004399 A3               [24] 1827 	inc	dptr
      00439A E0               [24] 1828 	movx	a,@dptr
      00439B FB               [12] 1829 	mov	r3,a
      00439C 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0132
      00439D                       1834 _ak820_outline_0132:
      00439D AE 82            [24] 1835 	mov	r6,dpl
      00439F AF 83            [24] 1836 	mov	r7,dph
      0043A1 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0135
      0043A2                       1841 _ak820_outline_0135:
      0043A2 2E               [12] 1842 	add	a,r6
      0043A3 FE               [12] 1843 	mov	r6,a
      0043A4 E4               [12] 1844 	clr	a
      0043A5 3F               [12] 1845 	addc	a,r7
      0043A6 FF               [12] 1846 	mov	r7,a
      0043A7 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0140
      0043A8                       1851 _ak820_outline_0140:
      0043A8 42 05            [12] 1852 	orl	ar5,a
      0043AA EA               [12] 1853 	mov	a,r2
      0043AB 42 04            [12] 1854 	orl	ar4,a
      0043AD 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0141
      0043AE                       1859 _ak820_outline_0141:
      0043AE 8A 82            [24] 1860 	mov	dpl,r2
      0043B0 8B 83            [24] 1861 	mov	dph,r3
      0043B2 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0146
      0043B3                       1866 _ak820_outline_0146:
      0043B3 AC 82            [24] 1867 	mov	r4,dpl
      0043B5 AD 83            [24] 1868 	mov	r5,dph
      0043B7 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0154
      0043B8                       1873 _ak820_outline_0154:
      0043B8 8F 82            [24] 1874 	mov	dpl,r7
      0043BA 8E 83            [24] 1875 	mov	dph,r6
      0043BC 22               [24] 1876 	ret
                                   1877 
                                   1878 	.area CSEG (CODE)
                                   1879 ; function ak820_outline_0157
      0043BD                       1880 _ak820_outline_0157:
      0043BD 2E               [12] 1881 	add	a,r6
      0043BE FC               [12] 1882 	mov	r4,a
      0043BF E4               [12] 1883 	clr	a
      0043C0 3F               [12] 1884 	addc	a,r7
      0043C1 FD               [12] 1885 	mov	r5,a
      0043C2 22               [24] 1886 	ret
                                   1887 
                                   1888 	.area CSEG (CODE)
                                   1889 ; function ak820_outline_0158
      0043C3                       1890 _ak820_outline_0158:
      0043C3 ED               [12] 1891 	mov	a,r5
      0043C4 F0               [24] 1892 	movx	@dptr,a
      0043C5 EE               [12] 1893 	mov	a,r6
      0043C6 A3               [24] 1894 	inc	dptr
      0043C7 F0               [24] 1895 	movx	@dptr,a
      0043C8 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0180
      0043C9                       1900 _ak820_outline_0180:
      0043C9 89 82            [24] 1901 	mov	dpl,r1
      0043CB 8A 83            [24] 1902 	mov	dph,r2
      0043CD 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0181
      0043CE                       1907 _ak820_outline_0181:
      0043CE 8C 82            [24] 1908 	mov	dpl,r4
      0043D0 8B 83            [24] 1909 	mov	dph,r3
      0043D2 22               [24] 1910 	ret
                                   1911 
                                   1912 	.area CSEG (CODE)
                                   1913 ; function ak820_outline_0185
      0043D3                       1914 _ak820_outline_0185:
      0043D3 8D 82            [24] 1915 	mov	dpl,r5
      0043D5 8C 83            [24] 1916 	mov	dph,r4
      0043D7 22               [24] 1917 	ret
