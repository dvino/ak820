                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _process_record_quantum
                                     53 	.globl _action_for_keycode
                                     54 	.globl _mDelaymS
                                     55 	.globl _host_consumer_send
                                     56 	.globl _host_system_send
                                     57 	.globl _host_keyboard_leds
                                     58 	.globl _led_set
                                     59 	.globl _clear_keys_from_report
                                     60 	.globl ___memcpy
                                     61 	.globl _ADC_START
                                     62 	.globl _S0_R_FIFO
                                     63 	.globl _S0_T_FIFO
                                     64 	.globl _S0_FREE
                                     65 	.globl _S0_IF_BYTE
                                     66 	.globl _S0_IF_FIRST
                                     67 	.globl _S0_IF_OV
                                     68 	.globl _S0_FST_ACT
                                     69 	.globl _CP_RL2
                                     70 	.globl _C_T2
                                     71 	.globl _TR2
                                     72 	.globl _EXEN2
                                     73 	.globl _TCLK
                                     74 	.globl _RCLK
                                     75 	.globl _EXF2
                                     76 	.globl _CAP1F
                                     77 	.globl _TF2
                                     78 	.globl _RI
                                     79 	.globl _TI
                                     80 	.globl _RB8
                                     81 	.globl _TB8
                                     82 	.globl _REN
                                     83 	.globl _SM2
                                     84 	.globl _SM1
                                     85 	.globl _SM0
                                     86 	.globl _IT0
                                     87 	.globl _IE0
                                     88 	.globl _IT1
                                     89 	.globl _IE1
                                     90 	.globl _TR0
                                     91 	.globl _TF0
                                     92 	.globl _TR1
                                     93 	.globl _TF1
                                     94 	.globl _P4_0
                                     95 	.globl _P4_1
                                     96 	.globl _P4_2
                                     97 	.globl _P4_3
                                     98 	.globl _P4_4
                                     99 	.globl _P4_5
                                    100 	.globl _P4_6
                                    101 	.globl _RXD
                                    102 	.globl _TXD
                                    103 	.globl _INT0
                                    104 	.globl _INT1
                                    105 	.globl _T0
                                    106 	.globl _T1
                                    107 	.globl _MOSI1
                                    108 	.globl _MISO1
                                    109 	.globl _SCK1
                                    110 	.globl _P3_0
                                    111 	.globl _P3_1
                                    112 	.globl _P3_2
                                    113 	.globl _P3_3
                                    114 	.globl _P3_4
                                    115 	.globl _P3_5
                                    116 	.globl _P3_6
                                    117 	.globl _P3_7
                                    118 	.globl _CAP1_
                                    119 	.globl _T2_
                                    120 	.globl _CAP2_
                                    121 	.globl _T2EX_
                                    122 	.globl _RXD1
                                    123 	.globl _TXD1
                                    124 	.globl _P2_0
                                    125 	.globl _P2_1
                                    126 	.globl _P2_2
                                    127 	.globl _P2_3
                                    128 	.globl _P2_4
                                    129 	.globl _P2_5
                                    130 	.globl _P2_6
                                    131 	.globl _P2_7
                                    132 	.globl _AIN0
                                    133 	.globl _AIN1
                                    134 	.globl _AIN2
                                    135 	.globl _AIN3
                                    136 	.globl _AIN4
                                    137 	.globl _AIN5
                                    138 	.globl _AIN6
                                    139 	.globl _AIN7
                                    140 	.globl _CAP1
                                    141 	.globl _T2
                                    142 	.globl _CAP2
                                    143 	.globl _T2EX
                                    144 	.globl _INT0_
                                    145 	.globl _SCS
                                    146 	.globl _MOSI
                                    147 	.globl _MISO
                                    148 	.globl _SCK
                                    149 	.globl _RXD1_
                                    150 	.globl _TXD1_
                                    151 	.globl _P1_0
                                    152 	.globl _P1_1
                                    153 	.globl _P1_2
                                    154 	.globl _P1_3
                                    155 	.globl _P1_4
                                    156 	.globl _P1_5
                                    157 	.globl _P1_6
                                    158 	.globl _P1_7
                                    159 	.globl _AIN8
                                    160 	.globl _AIN9
                                    161 	.globl _AIN10
                                    162 	.globl _AIN11
                                    163 	.globl _AIN12
                                    164 	.globl _AIN13
                                    165 	.globl _RXD_
                                    166 	.globl _TXD_
                                    167 	.globl _SCL0
                                    168 	.globl _SDA0
                                    169 	.globl _P0_0
                                    170 	.globl _P0_1
                                    171 	.globl _P0_2
                                    172 	.globl _P0_3
                                    173 	.globl _P0_4
                                    174 	.globl _P0_5
                                    175 	.globl _P0_6
                                    176 	.globl _P0_7
                                    177 	.globl _IE_SPI0
                                    178 	.globl _IE_USB
                                    179 	.globl _IE_ADC
                                    180 	.globl _IE_UART1
                                    181 	.globl _IE_PWM_I2C
                                    182 	.globl _IE_GPIO
                                    183 	.globl _IE_WDOG
                                    184 	.globl _PX0
                                    185 	.globl _PT0
                                    186 	.globl _PX1
                                    187 	.globl _PT1
                                    188 	.globl _PS
                                    189 	.globl _PT2
                                    190 	.globl _PL_FLAG
                                    191 	.globl _PH_FLAG
                                    192 	.globl _EX0
                                    193 	.globl _ET0
                                    194 	.globl _EX1
                                    195 	.globl _ET1
                                    196 	.globl _ES
                                    197 	.globl _ET2
                                    198 	.globl _E_DIS
                                    199 	.globl _EA
                                    200 	.globl _P
                                    201 	.globl _F1
                                    202 	.globl _OV
                                    203 	.globl _RS0
                                    204 	.globl _RS1
                                    205 	.globl _F0
                                    206 	.globl _AC
                                    207 	.globl _CY
                                    208 	.globl _I2CS_INT_ST
                                    209 	.globl _I2CX_INT
                                    210 	.globl _LED_STATUS
                                    211 	.globl _LED_DMA_H
                                    212 	.globl _LED_DMA_L
                                    213 	.globl _LED_DMA
                                    214 	.globl _LED_PWM_OE
                                    215 	.globl _LED_COMMON
                                    216 	.globl _ADC_CHAN
                                    217 	.globl _ADC_DAT_H
                                    218 	.globl _ADC_DAT_L
                                    219 	.globl _ADC_DAT
                                    220 	.globl _ADC_CTRL
                                    221 	.globl _SPI1_CK_SE
                                    222 	.globl _SPI1_CTRL
                                    223 	.globl _SPI1_DATA
                                    224 	.globl _SPI1_STAT
                                    225 	.globl _SIF1
                                    226 	.globl _SBAUD1
                                    227 	.globl _SBUF1
                                    228 	.globl _SCON1
                                    229 	.globl _SPI0_SETUP
                                    230 	.globl _SPI0_CK_SE
                                    231 	.globl _SPI0_CTRL
                                    232 	.globl _SPI0_DATA
                                    233 	.globl _SPI0_STAT
                                    234 	.globl _T2CAP1H
                                    235 	.globl _T2CAP1L
                                    236 	.globl _T2CAP1
                                    237 	.globl _TH2
                                    238 	.globl _TL2
                                    239 	.globl _T2COUNT
                                    240 	.globl _RCAP2H
                                    241 	.globl _RCAP2L
                                    242 	.globl _RCAP2
                                    243 	.globl _T2MOD
                                    244 	.globl _T2CON
                                    245 	.globl _SBUF
                                    246 	.globl _SCON
                                    247 	.globl _TH1
                                    248 	.globl _TH0
                                    249 	.globl _TL1
                                    250 	.globl _TL0
                                    251 	.globl _TMOD
                                    252 	.globl _TCON
                                    253 	.globl _XBUS_AUX
                                    254 	.globl _P7
                                    255 	.globl _P6_DIR
                                    256 	.globl _P6_OUT_PU
                                    257 	.globl _P6_IN
                                    258 	.globl _P5_DIR
                                    259 	.globl _P5_OUT_PU
                                    260 	.globl _P5_IN
                                    261 	.globl _P4_LED_KEY
                                    262 	.globl _P4_DIR_PU
                                    263 	.globl _P4_MOD_OC
                                    264 	.globl _P4
                                    265 	.globl _P3_DIR_PU
                                    266 	.globl _P3_MOD_OC
                                    267 	.globl _P3
                                    268 	.globl _P2_DIR_PU
                                    269 	.globl _P2_MOD_OC
                                    270 	.globl _P2
                                    271 	.globl _P1_DIR_PU
                                    272 	.globl _P1_MOD_OC
                                    273 	.globl _P1
                                    274 	.globl _P0_DIR_PU
                                    275 	.globl _P0_MOD_OC
                                    276 	.globl _P0
                                    277 	.globl _ROM_CTRL
                                    278 	.globl _ROM_DATA_HH
                                    279 	.globl _ROM_DATA_HL
                                    280 	.globl _ROM_DATA_HI
                                    281 	.globl _ROM_ADDR_H
                                    282 	.globl _ROM_ADDR_L
                                    283 	.globl _ROM_ADDR
                                    284 	.globl _GPIO_IE
                                    285 	.globl _IP_EX
                                    286 	.globl _IE_EX
                                    287 	.globl _IP
                                    288 	.globl _IE
                                    289 	.globl _WDOG_COUNT
                                    290 	.globl _RESET_KEEP
                                    291 	.globl _WAKE_CTRL
                                    292 	.globl _CLOCK_CFG
                                    293 	.globl _POWER_CFG
                                    294 	.globl _PCON
                                    295 	.globl _GLOBAL_CFG
                                    296 	.globl _SAFE_MOD
                                    297 	.globl _DPH
                                    298 	.globl _DPL
                                    299 	.globl _SP
                                    300 	.globl _A_INV
                                    301 	.globl _B
                                    302 	.globl _ACC
                                    303 	.globl _PSW
                                    304 	.globl _disable_action_cache
                                    305 	.globl _tap_code_delay_PARM_2
                                    306 	.globl _process_action_PARM_2
                                    307 	.globl _action_exec_PARM_1
                                    308 	.globl _tp_buttons
                                    309 	.globl _action_exec
                                    310 	.globl _ak820_action_exec
                                    311 	.globl _process_record
                                    312 	.globl _process_record_handler
                                    313 	.globl _process_action
                                    314 	.globl _register_code
                                    315 	.globl _unregister_code
                                    316 	.globl _tap_code_delay
                                    317 	.globl _tap_code
                                    318 	.globl _register_mods
                                    319 	.globl _unregister_mods
                                    320 	.globl _register_weak_mods
                                    321 	.globl _unregister_weak_mods
                                    322 	.globl _clear_keyboard
                                    323 	.globl _clear_keyboard_but_mods
                                    324 	.globl _clear_keyboard_but_mods_and_keys
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000027                        587 _process_action_sloc0_1_0:
      000027                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; overlayable items in internal ram
                                    591 ;--------------------------------------------------------
                                    592 ;--------------------------------------------------------
                                    593 ; indirectly addressable internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area ISEG    (DATA)
                                    596 ;--------------------------------------------------------
                                    597 ; absolute internal ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area IABS    (ABS,DATA)
                                    600 	.area IABS    (ABS,DATA)
                                    601 ;--------------------------------------------------------
                                    602 ; bit data
                                    603 ;--------------------------------------------------------
                                    604 	.area BSEG    (BIT)
      00001D                        605 _process_action_sloc1_1_0:
      00001D                        606 	.ds 1
                                    607 ;--------------------------------------------------------
                                    608 ; paged external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area PSEG    (PAG,XDATA)
                                    611 ;--------------------------------------------------------
                                    612 ; uninitialized external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area XSEG    (XDATA)
      000813                        615 _tp_buttons::
      000813                        616 	.ds 2
      000815                        617 _action_exec_PARM_1:
      000815                        618 	.ds 6
      00081B                        619 _action_exec_record_10001_625:
      00081B                        620 	.ds 9
      000824                        621 _ak820_action_exec_event_10000_629:
      000824                        622 	.ds 2
      000826                        623 _ak820_action_exec_snapshot_10000_630:
      000826                        624 	.ds 6
      00082C                        625 _process_record_record_argument_10000_633:
      00082C                        626 	.ds 2
      00082E                        627 _process_record_handler_record_argument_10000_641:
      00082E                        628 	.ds 2
      000830                        629 _process_record_handler_action_10000_642:
      000830                        630 	.ds 2
      000832                        631 _process_action_PARM_2:
      000832                        632 	.ds 2
      000834                        633 _process_action_record_argument_10000_653:
      000834                        634 	.ds 2
      000836                        635 _process_action_on_40000_676:
      000836                        636 	.ds 1
      000837                        637 _register_code_code_10000_710:
      000837                        638 	.ds 1
      000838                        639 _unregister_code_code_10000_724:
      000838                        640 	.ds 1
      000839                        641 _tap_code_delay_PARM_2:
      000839                        642 	.ds 2
      00083B                        643 _tap_code_delay_code_10000_737:
      00083B                        644 	.ds 1
      00083C                        645 _tap_code_code_10000_744:
      00083C                        646 	.ds 1
      00083D                        647 _register_mods_mods_10000_746:
      00083D                        648 	.ds 1
      00083E                        649 _unregister_mods_mods_10000_750:
      00083E                        650 	.ds 1
      00083F                        651 _register_weak_mods_mods_10000_754:
      00083F                        652 	.ds 1
      000840                        653 _unregister_weak_mods_mods_10000_758:
      000840                        654 	.ds 1
                                    655 ;--------------------------------------------------------
                                    656 ; absolute external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XABS    (ABS,XDATA)
                                    659 ;--------------------------------------------------------
                                    660 ; initialized external ram data
                                    661 ;--------------------------------------------------------
                                    662 	.area XISEG   (XDATA)
      000D9C                        663 _disable_action_cache::
      000D9C                        664 	.ds 1
                                    665 	.area HOME    (CODE)
                                    666 	.area GSINIT0 (CODE)
                                    667 	.area GSINIT1 (CODE)
                                    668 	.area GSINIT2 (CODE)
                                    669 	.area GSINIT3 (CODE)
                                    670 	.area GSINIT4 (CODE)
                                    671 	.area GSINIT5 (CODE)
                                    672 	.area GSINIT  (CODE)
                                    673 	.area GSFINAL (CODE)
                                    674 	.area CSEG    (CODE)
                                    675 ;--------------------------------------------------------
                                    676 ; global & static initialisations
                                    677 ;--------------------------------------------------------
                                    678 	.area HOME    (CODE)
                                    679 	.area GSINIT  (CODE)
                                    680 	.area GSFINAL (CODE)
                                    681 	.area GSINIT  (CODE)
                                    682 ;--------------------------------------------------------
                                    683 ; Home
                                    684 ;--------------------------------------------------------
                                    685 	.area HOME    (CODE)
                                    686 	.area HOME    (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; code
                                    689 ;--------------------------------------------------------
                                    690 	.area CSEG    (CODE)
                                    691 ;------------------------------------------------------------
                                    692 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    693 ;------------------------------------------------------------
                                    694 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    695 ;------------------------------------------------------------
                                    696 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    697 ;	-----------------------------------------
                           000007   698 	ar7 = 0x07
                           000006   699 	ar6 = 0x06
                           000005   700 	ar5 = 0x05
                           000004   701 	ar4 = 0x04
                           000003   702 	ar3 = 0x03
                           000002   703 	ar2 = 0x02
                           000001   704 	ar1 = 0x01
                           000000   705 	ar0 = 0x00
                                    706 ;	 function action_exec
                                    707 ;	-----------------------------------------
      0071CC                        708 _action_exec:
                                    709 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      0071CC 90 08 17         [24]  710 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0071CF 12 37 A0         [24]  711 	lcall	_ak820_outline_0004
      0071D2 12 35 B8         [24]  712 	lcall	_ak820_combo_tick
                                    713 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      0071D5 90 08 15         [24]  714 	mov	dptr,#_action_exec_PARM_1
      0071D8 12 45 5C         [24]  715 	lcall	_ak820_tapping_before
      0071DB E5 82            [12]  716 	mov	a, dpl
      0071DD 70 01            [24]  717 	jnz	00102$
      0071DF 22               [24]  718 	ret
      0071E0                        719 00102$:
                                    720 ;	quantum/action.c:126: if (event.pressed) {
      0071E0 90 08 1A         [24]  721 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0071E3 E0               [24]  722 	movx	a,@dptr
      0071E4 60 03            [24]  723 	jz	00104$
                                    724 ;	quantum/action.c:128: clear_weak_mods();
      0071E6 12 82 46         [24]  725 	lcall	_clear_weak_mods
      0071E9                        726 00104$:
                                    727 ;	quantum/action.c:140: record.event = event;
      0071E9 90 0D 7C         [24]  728 	mov	dptr,#___memcpy_PARM_2
      0071EC 74 15            [12]  729 	mov	a,#_action_exec_PARM_1
      0071EE F0               [24]  730 	movx	@dptr,a
      0071EF 74 08            [12]  731 	mov	a,#(_action_exec_PARM_1 >> 8)
      0071F1 12 78 46         [24]  732 	lcall	_ak820_outline_0050
      0071F4 12 78 66         [24]  733 	lcall	_ak820_outline_0107
      0071F7 90 08 1B         [24]  734 	mov	dptr,#_action_exec_record_10001_625
      0071FA F5 F0            [12]  735 	mov	b,a
      0071FC 12 B8 A0         [24]  736 	lcall	___memcpy
                                    737 ;	quantum/action.c:142: record.tap.count = 0;
      0071FF 90 08 21         [24]  738 	mov	dptr,#(_action_exec_record_10001_625 + 0x0006)
      007202 E0               [24]  739 	movx	a,@dptr
      007203 54 0F            [12]  740 	anl	a,#0x0f
      007205 F0               [24]  741 	movx	@dptr,a
                                    742 ;	quantum/action.c:147: record.keycode = 0;
      007206 90 08 22         [24]  743 	mov	dptr,#(_action_exec_record_10001_625 + 0x0007)
      007209 12 50 34         [24]  744 	lcall	_ak820_outline_0179
                                    745 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00720C 90 08 1F         [24]  746 	mov	dptr,#(_action_exec_record_10001_625 + 0x0004)
      00720F E0               [24]  747 	movx	a,@dptr
      007210 60 0A            [24]  748 	jz	00107$
      007212 90 08 1B         [24]  749 	mov	dptr,#_action_exec_record_10001_625
      007215 12 9F A8         [24]  750 	lcall	_pre_process_record_quantum
      007218 E5 82            [12]  751 	mov	a, dpl
      00721A 60 11            [24]  752 	jz	00110$
      00721C                        753 00107$:
                                    754 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      00721C 90 08 1B         [24]  755 	mov	dptr,#_action_exec_record_10001_625
      00721F 12 46 48         [24]  756 	lcall	_ak820_tapping_process
      007222 E5 82            [12]  757 	mov	a, dpl
      007224 70 01            [24]  758 	jnz	00106$
      007226 22               [24]  759 	ret
      007227                        760 00106$:
                                    761 ;	quantum/action.c:185: process_record(&record);
      007227 90 08 1B         [24]  762 	mov	dptr,#_action_exec_record_10001_625
                                    763 ;	quantum/action.c:200: }
      00722A 02 72 6B         [24]  764 	ljmp	_process_record
      00722D                        765 00110$:
      00722D 22               [24]  766 	ret
                                    767 ;------------------------------------------------------------
                                    768 ;Allocation info for local variables in function 'ak820_action_exec'
                                    769 ;------------------------------------------------------------
                                    770 ;event         Allocated with name '_ak820_action_exec_event_10000_629'
                                    771 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_630'
                                    772 ;------------------------------------------------------------
                                    773 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    774 ;	-----------------------------------------
                                    775 ;	 function ak820_action_exec
                                    776 ;	-----------------------------------------
      00722E                        777 _ak820_action_exec:
      00722E 12 38 43         [24]  778 	lcall	_ak820_outline_0103
      007231 90 08 24         [24]  779 	mov	dptr,#_ak820_action_exec_event_10000_629
      007234 12 38 48         [24]  780 	lcall	_ak820_outline_0104
                                    781 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007237 90 08 24         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_629
      00723A 12 38 17         [24]  783 	lcall	_ak820_outline_0058
      00723D 90 0D 7C         [24]  784 	mov	dptr,#___memcpy_PARM_2
      007240 ED               [12]  785 	mov	a,r5
      007241 12 37 DF         [24]  786 	lcall	_ak820_outline_0016
      007244 90 0D 7F         [24]  787 	mov	dptr,#___memcpy_PARM_3
      007247 12 78 66         [24]  788 	lcall	_ak820_outline_0107
      00724A 90 08 26         [24]  789 	mov	dptr,#_ak820_action_exec_snapshot_10000_630
      00724D F5 F0            [12]  790 	mov	b,a
      00724F 12 B8 A0         [24]  791 	lcall	___memcpy
                                    792 ;	quantum/action.c:207: action_exec(snapshot);
      007252 90 0D 7C         [24]  793 	mov	dptr,#___memcpy_PARM_2
      007255 74 26            [12]  794 	mov	a,#_ak820_action_exec_snapshot_10000_630
      007257 F0               [24]  795 	movx	@dptr,a
      007258 74 08            [12]  796 	mov	a,#(_ak820_action_exec_snapshot_10000_630 >> 8)
      00725A 12 78 46         [24]  797 	lcall	_ak820_outline_0050
      00725D 12 78 66         [24]  798 	lcall	_ak820_outline_0107
      007260 90 08 15         [24]  799 	mov	dptr,#_action_exec_PARM_1
      007263 F5 F0            [12]  800 	mov	b,a
      007265 12 B8 A0         [24]  801 	lcall	___memcpy
                                    802 ;	quantum/action.c:208: }
      007268 02 71 CC         [24]  803 	ljmp	_action_exec
                                    804 ;------------------------------------------------------------
                                    805 ;Allocation info for local variables in function 'process_record_nocache'
                                    806 ;------------------------------------------------------------
                                    807 ;record        Allocated with name '_process_record_nocache_record_10000_631'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function process_record
                                    812 ;	-----------------------------------------
      00726B                        813 _process_record:
      00726B 12 38 43         [24]  814 	lcall	_ak820_outline_0103
      00726E 90 08 2C         [24]  815 	mov	dptr,#_process_record_record_argument_10000_633
      007271 12 38 48         [24]  816 	lcall	_ak820_outline_0104
                                    817 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007274 90 08 2C         [24]  818 	mov	dptr,#_process_record_record_argument_10000_633
      007277 12 38 00         [24]  819 	lcall	_ak820_outline_0051
                                    820 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      00727A 74 04            [12]  821 	mov	a,#0x04
      00727C 12 49 3C         [24]  822 	lcall	_ak820_outline_0012
      00727F 70 01            [24]  823 	jnz	00102$
                                    824 ;	quantum/action.c:354: return;
      007281 22               [24]  825 	ret
      007282                        826 00102$:
                                    827 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007282 8E 04            [24]  828 	mov	ar4,r6
      007284 8F 05            [24]  829 	mov	ar5,r7
      007286 90 0D 7C         [24]  830 	mov	dptr,#___memcpy_PARM_2
      007289 EC               [12]  831 	mov	a,r4
      00728A F0               [24]  832 	movx	@dptr,a
      00728B ED               [12]  833 	mov	a,r5
      00728C 12 78 46         [24]  834 	lcall	_ak820_outline_0050
      00728F 12 50 26         [24]  835 	lcall	_ak820_outline_0106
      007292 90 06 28         [24]  836 	mov	dptr,#_ak820_tapping_source_PARM_1
      007295 F5 F0            [12]  837 	mov	b,a
      007297 C0 07            [24]  838 	push	ar7
      007299 C0 06            [24]  839 	push	ar6
      00729B 12 B8 A0         [24]  840 	lcall	___memcpy
      00729E 12 44 98         [24]  841 	lcall	_ak820_tapping_source
      0072A1 AD 82            [24]  842 	mov	r5, dpl
      0072A3 D0 06            [24]  843 	pop	ar6
      0072A5 D0 07            [24]  844 	pop	ar7
                                    845 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      0072A7 12 43 37         [24]  846 	lcall	_ak820_outline_0010
      0072AA E0               [24]  847 	movx	a,@dptr
      0072AB FC               [12]  848 	mov	r4,a
                                    849 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      0072AC 74 07            [12]  850 	mov	a,#0x07
      0072AE 2E               [12]  851 	add	a, r6
      0072AF FA               [12]  852 	mov	r2,a
      0072B0 E4               [12]  853 	clr	a
      0072B1 3F               [12]  854 	addc	a, r7
      0072B2 FB               [12]  855 	mov	r3,a
      0072B3 90 0B DE         [24]  856 	mov	dptr,#_get_record_keycode_PARM_2
      0072B6 12 49 86         [24]  857 	lcall	_ak820_outline_0055
      0072B9 C0 07            [24]  858 	push	ar7
      0072BB C0 06            [24]  859 	push	ar6
      0072BD C0 05            [24]  860 	push	ar5
      0072BF C0 04            [24]  861 	push	ar4
      0072C1 C0 03            [24]  862 	push	ar3
      0072C3 C0 02            [24]  863 	push	ar2
      0072C5 12 9F 6B         [24]  864 	lcall	_get_record_keycode
      0072C8 A8 82            [24]  865 	mov	r0, dpl
      0072CA A9 83            [24]  866 	mov	r1, dph
      0072CC D0 02            [24]  867 	pop	ar2
      0072CE D0 03            [24]  868 	pop	ar3
      0072D0 D0 04            [24]  869 	pop	ar4
      0072D2 D0 05            [24]  870 	pop	ar5
      0072D4 D0 06            [24]  871 	pop	ar6
      0072D6 D0 07            [24]  872 	pop	ar7
      0072D8 12 43 AE         [24]  873 	lcall	_ak820_outline_0141
      0072DB E8               [12]  874 	mov	a,r0
      0072DC F0               [24]  875 	movx	@dptr,a
      0072DD E9               [12]  876 	mov	a,r1
      0072DE A3               [24]  877 	inc	dptr
      0072DF F0               [24]  878 	movx	@dptr,a
                                    879 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0072E0 74 07            [12]  880 	mov	a,#0x07
      0072E2 12 37 E7         [24]  881 	lcall	_ak820_outline_0017
      0072E5 FA               [12]  882 	mov	r2,a
      0072E6 A3               [24]  883 	inc	dptr
      0072E7 E0               [24]  884 	movx	a,@dptr
      0072E8 FB               [12]  885 	mov	r3,a
      0072E9 90 06 38         [24]  886 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0072EC ED               [12]  887 	mov	a,r5
      0072ED F0               [24]  888 	movx	@dptr,a
      0072EE 90 06 39         [24]  889 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0072F1 EC               [12]  890 	mov	a,r4
      0072F2 F0               [24]  891 	movx	@dptr,a
      0072F3 12 43 AE         [24]  892 	lcall	_ak820_outline_0141
      0072F6 C0 07            [24]  893 	push	ar7
      0072F8 C0 06            [24]  894 	push	ar6
      0072FA C0 05            [24]  895 	push	ar5
      0072FC C0 04            [24]  896 	push	ar4
      0072FE 12 47 E8         [24]  897 	lcall	_ak820_oneshot_process
      007301 E5 82            [12]  898 	mov	a, dpl
      007303 D0 04            [24]  899 	pop	ar4
      007305 D0 05            [24]  900 	pop	ar5
      007307 D0 06            [24]  901 	pop	ar6
      007309 D0 07            [24]  902 	pop	ar7
      00730B 70 01            [24]  903 	jnz	00104$
      00730D 22               [24]  904 	ret
      00730E                        905 00104$:
                                    906 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      00730E 12 43 92         [24]  907 	lcall	_ak820_outline_0116
      007311 C0 07            [24]  908 	push	ar7
      007313 C0 06            [24]  909 	push	ar6
      007315 C0 05            [24]  910 	push	ar5
      007317 C0 04            [24]  911 	push	ar4
      007319 12 9F EA         [24]  912 	lcall	_process_record_quantum
      00731C E5 82            [12]  913 	mov	a, dpl
      00731E D0 04            [24]  914 	pop	ar4
      007320 D0 05            [24]  915 	pop	ar5
      007322 D0 06            [24]  916 	pop	ar6
      007324 D0 07            [24]  917 	pop	ar7
      007326 70 0A            [24]  918 	jnz	00106$
                                    919 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007328 90 05 98         [24]  920 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00732B EC               [12]  921 	mov	a,r4
      00732C F0               [24]  922 	movx	@dptr,a
      00732D 8D 82            [24]  923 	mov	dpl, r5
                                    924 ;	quantum/action.c:376: return;
      00732F 02 2E 6F         [24]  925 	ljmp	_ak820_oneshot_post
      007332                        926 00106$:
                                    927 ;	quantum/action.c:382: process_record_handler(record);
      007332 12 43 92         [24]  928 	lcall	_ak820_outline_0116
      007335 C0 05            [24]  929 	push	ar5
      007337 C0 04            [24]  930 	push	ar4
      007339 12 73 4A         [24]  931 	lcall	_process_record_handler
      00733C D0 04            [24]  932 	pop	ar4
      00733E D0 05            [24]  933 	pop	ar5
                                    934 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007340 90 05 98         [24]  935 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007343 EC               [12]  936 	mov	a,r4
      007344 F0               [24]  937 	movx	@dptr,a
      007345 8D 82            [24]  938 	mov	dpl, r5
                                    939 ;	quantum/action.c:392: }
      007347 02 2E 6F         [24]  940 	ljmp	_ak820_oneshot_post
                                    941 ;------------------------------------------------------------
                                    942 ;Allocation info for local variables in function 'process_record_handler'
                                    943 ;------------------------------------------------------------
                                    944 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_641'
                                    945 ;record        Allocated with name '_process_record_handler_record_10000_642'
                                    946 ;action        Allocated with name '_process_record_handler_action_10000_642'
                                    947 ;------------------------------------------------------------
                                    948 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    949 ;	-----------------------------------------
                                    950 ;	 function process_record_handler
                                    951 ;	-----------------------------------------
      00734A                        952 _process_record_handler:
      00734A 12 38 43         [24]  953 	lcall	_ak820_outline_0103
      00734D 90 08 2E         [24]  954 	mov	dptr,#_process_record_handler_record_argument_10000_641
      007350 12 38 48         [24]  955 	lcall	_ak820_outline_0104
                                    956 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007353 90 08 2E         [24]  957 	mov	dptr,#_process_record_handler_record_argument_10000_641
      007356 12 37 B7         [24]  958 	lcall	_ak820_outline_0009
                                    959 ;	quantum/action.c:405: if (record->keycode) {
      007359 4C               [12]  960 	orl	a,r4
      00735A 60 19            [24]  961 	jz	00102$
                                    962 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      00735C 12 38 60         [24]  963 	lcall	_ak820_outline_0122
      00735F C0 07            [24]  964 	push	ar7
      007361 C0 06            [24]  965 	push	ar6
      007363 12 96 3D         [24]  966 	lcall	_action_for_keycode
      007366 12 43 B3         [24]  967 	lcall	_ak820_outline_0146
      007369 D0 06            [24]  968 	pop	ar6
      00736B D0 07            [24]  969 	pop	ar7
      00736D 90 08 30         [24]  970 	mov	dptr,#_process_record_handler_action_10000_642
      007370 12 38 25         [24]  971 	lcall	_ak820_outline_0071
      007373 80 2A            [24]  972 	sjmp	00104$
      007375                        973 00102$:
                                    974 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007375 12 78 2E         [24]  975 	lcall	_ak820_outline_0020
      007378 7A 00            [12]  976 	mov	r2,#0x00
      00737A 12 43 A8         [24]  977 	lcall	_ak820_outline_0140
      00737D 12 43 37         [24]  978 	lcall	_ak820_outline_0010
      007380 E0               [24]  979 	movx	a,@dptr
      007381 90 09 6B         [24]  980 	mov	dptr,#_ak820_resolve_key_PARM_2
      007384 F0               [24]  981 	movx	@dptr,a
      007385 12 43 D3         [24]  982 	lcall	_ak820_outline_0185
      007388 C0 07            [24]  983 	push	ar7
      00738A C0 06            [24]  984 	push	ar6
      00738C 12 7B CB         [24]  985 	lcall	_ak820_resolve_key
      00738F 12 96 3D         [24]  986 	lcall	_action_for_keycode
      007392 12 43 B3         [24]  987 	lcall	_ak820_outline_0146
      007395 D0 06            [24]  988 	pop	ar6
      007397 D0 07            [24]  989 	pop	ar7
      007399 90 08 30         [24]  990 	mov	dptr,#_process_record_handler_action_10000_642
      00739C 12 38 25         [24]  991 	lcall	_ak820_outline_0071
                                    992 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      00739F                        993 00104$:
                                    994 ;	quantum/action.c:429: process_action(record, action);
      00739F 90 0D 7C         [24]  995 	mov	dptr,#___memcpy_PARM_2
      0073A2 74 30            [12]  996 	mov	a,#_process_record_handler_action_10000_642
      0073A4 F0               [24]  997 	movx	@dptr,a
      0073A5 74 08            [12]  998 	mov	a,#(_process_record_handler_action_10000_642 >> 8)
      0073A7 12 78 46         [24]  999 	lcall	_ak820_outline_0050
      0073AA 12 50 26         [24] 1000 	lcall	_ak820_outline_0106
      0073AD 90 08 32         [24] 1001 	mov	dptr,#_process_action_PARM_2
      0073B0 F5 F0            [12] 1002 	mov	b,a
      0073B2 C0 07            [24] 1003 	push	ar7
      0073B4 C0 06            [24] 1004 	push	ar6
      0073B6 12 B8 A0         [24] 1005 	lcall	___memcpy
      0073B9 D0 06            [24] 1006 	pop	ar6
      0073BB D0 07            [24] 1007 	pop	ar7
      0073BD 12 43 92         [24] 1008 	lcall	_ak820_outline_0116
                                   1009 ;	quantum/action.c:430: }
      0073C0 02 73 C3         [24] 1010 	ljmp	_process_action
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'register_mouse'
                                   1013 ;------------------------------------------------------------
                                   1014 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1015 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_650'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function process_action
                                   1020 ;	-----------------------------------------
      0073C3                       1021 _process_action:
      0073C3 12 38 43         [24] 1022 	lcall	_ak820_outline_0103
      0073C6 90 08 34         [24] 1023 	mov	dptr,#_process_action_record_argument_10000_653
      0073C9 12 38 48         [24] 1024 	lcall	_ak820_outline_0104
                                   1025 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0073CC 90 08 34         [24] 1026 	mov	dptr,#_process_action_record_argument_10000_653
      0073CF 12 37 A0         [24] 1027 	lcall	_ak820_outline_0004
                                   1028 ;	quantum/action.c:501: pressed = record->event.pressed;
      0073D2 A3               [24] 1029 	inc	dptr
      0073D3 A3               [24] 1030 	inc	dptr
      0073D4 A3               [24] 1031 	inc	dptr
      0073D5 A3               [24] 1032 	inc	dptr
      0073D6 A3               [24] 1033 	inc	dptr
      0073D7 E0               [24] 1034 	movx	a,@dptr
      0073D8 F5 27            [12] 1035 	mov	_process_action_sloc0_1_0,a
                                   1036 ;	quantum/action.c:525: switch (action.kind.id) {
      0073DA 90 08 33         [24] 1037 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0073DD E0               [24] 1038 	movx	a,@dptr
      0073DE C4               [12] 1039 	swap	a
      0073DF 54 0F            [12] 1040 	anl	a,#0x0f
      0073E1 FD               [12] 1041 	mov  r5,a
      0073E2 24 F4            [12] 1042 	add	a,#0xff - 0x0b
      0073E4 50 03            [24] 1043 	jnc	00434$
      0073E6 02 76 62         [24] 1044 	ljmp	00181$
      0073E9                       1045 00434$:
                                   1046 ;	free result
      0073E9 ED               [12] 1047 	mov	a,r5
      0073EA 24 0A            [12] 1048 	add	a,#(00435$-3-.)
      0073EC 83               [24] 1049 	movc	a,@a+pc
      0073ED F5 82            [12] 1050 	mov	dpl,a
      0073EF ED               [12] 1051 	mov	a,r5
      0073F0 24 10            [12] 1052 	add	a,#(00436$-3-.)
      0073F2 83               [24] 1053 	movc	a,@a+pc
      0073F3 F5 83            [12] 1054 	mov	dph,a
      0073F5 E4               [12] 1055 	clr	a
      0073F6 73               [24] 1056 	jmp	@a+dptr
      0073F7                       1057 00435$:
      0073F7 0F                    1058 	.db	00102$
      0073F8 0F                    1059 	.db	00102$
      0073F9 62                    1060 	.db	00181$
      0073FA 62                    1061 	.db	00181$
      0073FB 97                    1062 	.db	00123$
      0073FC 62                    1063 	.db	00181$
      0073FD 62                    1064 	.db	00181$
      0073FE 62                    1065 	.db	00181$
      0073FF F7                    1066 	.db	00131$
      007400 C9                    1067 	.db	00147$
      007401 EF                    1068 	.db	00152$
      007402 EF                    1069 	.db	00152$
      007403                       1070 00436$:
      007403 74                    1071 	.db	00102$>>8
      007404 74                    1072 	.db	00102$>>8
      007405 76                    1073 	.db	00181$>>8
      007406 76                    1074 	.db	00181$>>8
      007407 74                    1075 	.db	00123$>>8
      007408 76                    1076 	.db	00181$>>8
      007409 76                    1077 	.db	00181$>>8
      00740A 76                    1078 	.db	00181$>>8
      00740B 74                    1079 	.db	00131$>>8
      00740C 75                    1080 	.db	00147$>>8
      00740D 75                    1081 	.db	00152$>>8
      00740E 75                    1082 	.db	00152$>>8
                                   1083 ;	quantum/action.c:528: case ACT_RMODS: {
      00740F                       1084 00102$:
                                   1085 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00740F 90 08 33         [24] 1086 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007412 E0               [24] 1087 	movx	a,@dptr
      007413 54 F0            [12] 1088 	anl	a,#0xf0
      007415 70 06            [24] 1089 	jnz	00194$
      007417 12 78 6D         [24] 1090 	lcall	_ak820_outline_0109
      00741A FD               [12] 1091 	mov	r5,a
      00741B 80 07            [24] 1092 	sjmp	00195$
      00741D                       1093 00194$:
      00741D 12 78 6D         [24] 1094 	lcall	_ak820_outline_0109
      007420 C4               [12] 1095 	swap	a
      007421 54 F0            [12] 1096 	anl	a,#0xf0
      007423 FD               [12] 1097 	mov	r5,a
      007424                       1098 00195$:
                                   1099 ;	quantum/action.c:531: if (pressed) {
      007424 E5 27            [12] 1100 	mov	a,_process_action_sloc0_1_0
      007426 60 34            [24] 1101 	jz	00119$
                                   1102 ;	quantum/action.c:532: if (mods) {
      007428 ED               [12] 1103 	mov	a,r5
      007429 60 28            [24] 1104 	jz	00110$
                                   1105 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00742B 12 78 7F         [24] 1106 	lcall	_ak820_outline_0155
      00742E FC               [12] 1107 	mov	r4,a
      00742F BC E0 00         [24] 1108 	cjne	r4,#0xe0,00440$
      007432                       1109 00440$:
      007432 40 07            [24] 1110 	jc	00108$
      007434 12 78 7F         [24] 1111 	lcall	_ak820_outline_0155
      007437 24 18            [12] 1112 	add	a,#0xff - 0xe7
      007439 50 09            [24] 1113 	jnc	00104$
                                   1114 ;	free result
      00743B                       1115 00108$:
      00743B 7B 32            [12] 1116 	mov	r3,#_process_action_PARM_2
      00743D 7C 08            [12] 1117 	mov	r4,#(_process_action_PARM_2 >> 8)
      00743F 12 6D FD         [24] 1118 	lcall	_ak820_outline_0118
      007442 70 07            [24] 1119 	jnz	00105$
      007444                       1120 00104$:
                                   1121 ;	quantum/action.c:537: add_owned_mods(mods);
      007444 8D 82            [24] 1122 	mov	dpl, r5
      007446 12 7E 35         [24] 1123 	lcall	_add_owned_mods
      007449 80 05            [24] 1124 	sjmp	00106$
      00744B                       1125 00105$:
                                   1126 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      00744B 8D 82            [24] 1127 	mov	dpl, r5
      00744D 12 7E 54         [24] 1128 	lcall	_add_owned_weak_mods
      007450                       1129 00106$:
                                   1130 ;	quantum/action.c:541: send_keyboard_report();
      007450 12 81 6F         [24] 1131 	lcall	_send_keyboard_report
      007453                       1132 00110$:
                                   1133 ;	quantum/action.c:543: register_code(action.key.code);
      007453 12 78 56         [24] 1134 	lcall	_ak820_outline_0076
      007456 12 76 79         [24] 1135 	lcall	_register_code
      007459 02 76 62         [24] 1136 	ljmp	00181$
      00745C                       1137 00119$:
                                   1138 ;	quantum/action.c:545: unregister_code(action.key.code);
      00745C 12 78 56         [24] 1139 	lcall	_ak820_outline_0076
      00745F C0 05            [24] 1140 	push	ar5
      007461 12 76 E6         [24] 1141 	lcall	_unregister_code
      007464 D0 05            [24] 1142 	pop	ar5
                                   1143 ;	quantum/action.c:546: if (mods) {
      007466 ED               [12] 1144 	mov	a,r5
      007467 70 03            [24] 1145 	jnz	00444$
      007469 02 76 62         [24] 1146 	ljmp	00181$
      00746C                       1147 00444$:
                                   1148 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00746C 12 78 7F         [24] 1149 	lcall	_ak820_outline_0155
      00746F FC               [12] 1150 	mov	r4,a
      007470 BC E0 00         [24] 1151 	cjne	r4,#0xe0,00445$
      007473                       1152 00445$:
      007473 40 07            [24] 1153 	jc	00115$
      007475 12 78 7F         [24] 1154 	lcall	_ak820_outline_0155
      007478 24 18            [12] 1155 	add	a,#0xff - 0xe7
      00747A 50 09            [24] 1156 	jnc	00111$
                                   1157 ;	free result
      00747C                       1158 00115$:
      00747C 7B 32            [12] 1159 	mov	r3,#_process_action_PARM_2
      00747E 7C 08            [12] 1160 	mov	r4,#(_process_action_PARM_2 >> 8)
      007480 12 6D FD         [24] 1161 	lcall	_ak820_outline_0118
      007483 70 07            [24] 1162 	jnz	00112$
      007485                       1163 00111$:
                                   1164 ;	quantum/action.c:548: del_owned_mods(mods);
      007485 8D 82            [24] 1165 	mov	dpl, r5
      007487 12 7E 45         [24] 1166 	lcall	_del_owned_mods
      00748A 80 05            [24] 1167 	sjmp	00113$
      00748C                       1168 00112$:
                                   1169 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      00748C 8D 82            [24] 1170 	mov	dpl, r5
      00748E 12 7E 64         [24] 1171 	lcall	_del_owned_weak_mods
      007491                       1172 00113$:
                                   1173 ;	quantum/action.c:552: send_keyboard_report();
      007491 12 81 6F         [24] 1174 	lcall	_send_keyboard_report
                                   1175 ;	quantum/action.c:555: } break;
      007494 02 76 62         [24] 1176 	ljmp	00181$
                                   1177 ;	quantum/action.c:632: case ACT_USAGE:
      007497                       1178 00123$:
                                   1179 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007497 74 07            [12] 1180 	mov	a,#0x07
      007499 12 37 F0         [24] 1181 	lcall	_ak820_outline_0031
      00749C 12 37 CB         [24] 1182 	lcall	_ak820_outline_0011
      00749F C3               [12] 1183 	clr	c
      0074A0 EC               [12] 1184 	mov	a,r4
      0074A1 94 A5            [12] 1185 	subb	a,#0xa5
      0074A3 ED               [12] 1186 	mov	a,r5
      0074A4 94 00            [12] 1187 	subb	a,#0x00
      0074A6 40 15            [24] 1188 	jc	00125$
      0074A8 74 C2            [12] 1189 	mov	a,#0xc2
      0074AA 9C               [12] 1190 	subb	a,r4
      0074AB E4               [12] 1191 	clr	a
      0074AC 9D               [12] 1192 	subb	a,r5
      0074AD 40 0E            [24] 1193 	jc	00125$
                                   1194 ;	free result
                                   1195 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      0074AF 90 0A 95         [24] 1196 	mov	dptr,#_owned_usage_key_PARM_2
      0074B2 E5 27            [12] 1197 	mov	a,_process_action_sloc0_1_0
      0074B4 F0               [24] 1198 	movx	@dptr,a
      0074B5 8E 82            [24] 1199 	mov	dpl, r6
      0074B7 12 80 1A         [24] 1200 	lcall	_owned_usage_key
                                   1201 ;	quantum/action.c:640: break;
      0074BA 02 76 62         [24] 1202 	ljmp	00181$
      0074BD                       1203 00125$:
                                   1204 ;	quantum/action.c:643: switch (action.usage.page) {
      0074BD 12 78 5D         [24] 1205 	lcall	_ak820_outline_0086
      0074C0 FF               [12] 1206 	mov	r7,a
      0074C1 60 08            [24] 1207 	jz	00127$
      0074C3 BF 01 02         [24] 1208 	cjne	r7,#0x01,00452$
      0074C6 80 19            [24] 1209 	sjmp	00128$
      0074C8                       1210 00452$:
      0074C8 02 76 62         [24] 1211 	ljmp	00181$
                                   1212 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0074CB                       1213 00127$:
                                   1214 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0074CB E5 27            [12] 1215 	mov	a,_process_action_sloc0_1_0
      0074CD 60 05            [24] 1216 	jz	00196$
      0074CF 12 78 74         [24] 1217 	lcall	_ak820_outline_0130
      0074D2 80 04            [24] 1218 	sjmp	00197$
      0074D4                       1219 00196$:
      0074D4 7E 00            [12] 1220 	mov	r6,#0x00
      0074D6 7F 00            [12] 1221 	mov	r7,#0x00
      0074D8                       1222 00197$:
      0074D8 12 43 92         [24] 1223 	lcall	_ak820_outline_0116
      0074DB 12 6E C6         [24] 1224 	lcall	_host_system_send
                                   1225 ;	quantum/action.c:646: break;
      0074DE 02 76 62         [24] 1226 	ljmp	00181$
                                   1227 ;	quantum/action.c:647: case PAGE_CONSUMER:
      0074E1                       1228 00128$:
                                   1229 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      0074E1 E5 27            [12] 1230 	mov	a,_process_action_sloc0_1_0
      0074E3 60 05            [24] 1231 	jz	00198$
      0074E5 12 78 74         [24] 1232 	lcall	_ak820_outline_0130
      0074E8 80 04            [24] 1233 	sjmp	00199$
      0074EA                       1234 00198$:
      0074EA 7E 00            [12] 1235 	mov	r6,#0x00
      0074EC 7F 00            [12] 1236 	mov	r7,#0x00
      0074EE                       1237 00199$:
      0074EE 12 43 92         [24] 1238 	lcall	_ak820_outline_0116
      0074F1 12 6E F6         [24] 1239 	lcall	_host_consumer_send
                                   1240 ;	quantum/action.c:651: break;
      0074F4 02 76 62         [24] 1241 	ljmp	00181$
                                   1242 ;	quantum/action.c:658: case ACT_LAYER: {
      0074F7                       1243 00131$:
                                   1244 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      0074F7 90 08 33         [24] 1245 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074FA E0               [24] 1246 	movx	a,@dptr
      0074FB 54 03            [12] 1247 	anl	a,#0x03
      0074FD 90 08 36         [24] 1248 	mov	dptr,#_process_action_on_40000_676
      007500 F0               [24] 1249 	movx	@dptr,a
                                   1250 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007501 E0               [24] 1251 	movx	a,@dptr
      007502 FF               [12] 1252 	mov	r7,a
      007503 60 11            [24] 1253 	jz	00200$
      007505 E5 27            [12] 1254 	mov	a,_process_action_sloc0_1_0
      007507 60 07            [24] 1255 	jz	00202$
      007509 8F 06            [24] 1256 	mov	ar6,r7
      00750B 53 06 01         [24] 1257 	anl	ar6,#0x01
      00750E 80 10            [24] 1258 	sjmp	00201$
      007510                       1259 00202$:
      007510 74 02            [12] 1260 	mov	a,#0x02
      007512 5F               [12] 1261 	anl	a,r7
      007513 FE               [12] 1262 	mov	r6,a
      007514 80 0A            [24] 1263 	sjmp	00201$
      007516                       1264 00200$:
      007516 E5 27            [12] 1265 	mov	a,_process_action_sloc0_1_0
      007518 B4 01 00         [24] 1266 	cjne	a,#0x01,00457$
      00751B                       1267 00457$:
      00751B 92 1D            [24] 1268 	mov  _process_action_sloc1_1_0,c
      00751D E4               [12] 1269 	clr	a
      00751E 33               [12] 1270 	rlc	a
      00751F FE               [12] 1271 	mov	r6,a
      007520                       1272 00201$:
      007520 EE               [12] 1273 	mov	a,r6
      007521 70 03            [24] 1274 	jnz	00458$
      007523 02 76 62         [24] 1275 	ljmp	00181$
      007526                       1276 00458$:
                                   1277 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007526 12 78 7F         [24] 1278 	lcall	_ak820_outline_0155
      007529 C4               [12] 1279 	swap	a
      00752A 03               [12] 1280 	rr	a
      00752B 54 07            [12] 1281 	anl	a,#0x07
      00752D 25 E0            [12] 1282 	add	a,acc
      00752F 25 E0            [12] 1283 	add	a,acc
      007531 FF               [12] 1284 	mov	r7,a
                                   1285 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007532 12 78 7F         [24] 1286 	lcall	_ak820_outline_0155
      007535 54 0F            [12] 1287 	anl	a,#0x0f
      007537 FE               [12] 1288 	mov	r6,a
      007538 8F F0            [24] 1289 	mov	b,r7
      00753A 05 F0            [12] 1290 	inc	b
      00753C EE               [12] 1291 	mov	a,r6
      00753D 80 02            [24] 1292 	sjmp	00460$
      00753F                       1293 00459$:
      00753F 25 E0            [12] 1294 	add	a,acc
      007541                       1295 00460$:
      007541 D5 F0 FB         [24] 1296 	djnz	b,00459$
      007544 FE               [12] 1297 	mov	r6,a
                                   1298 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007545 12 78 7F         [24] 1299 	lcall	_ak820_outline_0155
      007548 30 E4 11         [24] 1300 	jnb	acc.4,00204$
      00754B 8F F0            [24] 1301 	mov	b,r7
      00754D 05 F0            [12] 1302 	inc	b
      00754F 74 0F            [12] 1303 	mov	a,#0x0f
      007551 80 02            [24] 1304 	sjmp	00463$
      007553                       1305 00462$:
      007553 25 E0            [12] 1306 	add	a,acc
      007555                       1307 00463$:
      007555 D5 F0 FB         [24] 1308 	djnz	b,00462$
      007558 F4               [12] 1309 	cpl	a
      007559 FF               [12] 1310 	mov	r7,a
      00755A 80 02            [24] 1311 	sjmp	00205$
      00755C                       1312 00204$:
      00755C 7F 00            [12] 1313 	mov	r7,#0x00
      00755E                       1314 00205$:
                                   1315 ;	quantum/action.c:666: bits |= mask;
      00755E EE               [12] 1316 	mov	a,r6
      00755F 42 07            [12] 1317 	orl	ar7,a
                                   1318 ;	quantum/action.c:667: if (!on) {
      007561 90 08 36         [24] 1319 	mov	dptr,#_process_action_on_40000_676
      007564 E0               [24] 1320 	movx	a,@dptr
      007565 70 31            [24] 1321 	jnz	00143$
                                   1322 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      007567 12 78 5D         [24] 1323 	lcall	_ak820_outline_0086
      00756A FE               [12] 1324 	mov	r6,a
      00756B 2E               [12] 1325 	add	a,r6
                                   1326 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      00756C 90 75 70         [24] 1327 	mov	dptr,#00465$
      00756F 73               [24] 1328 	jmp	@a+dptr
      007570                       1329 00465$:
      007570 80 06            [24] 1330 	sjmp	00132$
      007572 80 0C            [24] 1331 	sjmp	00133$
      007574 80 12            [24] 1332 	sjmp	00134$
      007576 80 18            [24] 1333 	sjmp	00135$
      007578                       1334 00132$:
      007578 8F 82            [24] 1335 	mov	dpl, r7
      00757A 12 78 DA         [24] 1336 	lcall	_default_layer_and
      00757D 02 76 62         [24] 1337 	ljmp	00181$
                                   1338 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      007580                       1339 00133$:
      007580 8F 82            [24] 1340 	mov	dpl, r7
      007582 12 78 C9         [24] 1341 	lcall	_default_layer_or
      007585 02 76 62         [24] 1342 	ljmp	00181$
                                   1343 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      007588                       1344 00134$:
      007588 8F 82            [24] 1345 	mov	dpl, r7
      00758A 12 78 F0         [24] 1346 	lcall	_default_layer_xor
      00758D 02 76 62         [24] 1347 	ljmp	00181$
                                   1348 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      007590                       1349 00135$:
      007590 8F 82            [24] 1350 	mov	dpl, r7
      007592 12 78 BE         [24] 1351 	lcall	_default_layer_set
                                   1352 ;	quantum/action.c:673: }
      007595 02 76 62         [24] 1353 	ljmp	00181$
      007598                       1354 00143$:
                                   1355 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      007598 12 78 5D         [24] 1356 	lcall	_ak820_outline_0086
      00759B FE               [12] 1357 	mov	r6,a
      00759C 2E               [12] 1358 	add	a,r6
                                   1359 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      00759D 90 75 A1         [24] 1360 	mov	dptr,#00466$
      0075A0 73               [24] 1361 	jmp	@a+dptr
      0075A1                       1362 00466$:
      0075A1 80 06            [24] 1363 	sjmp	00137$
      0075A3 80 0C            [24] 1364 	sjmp	00138$
      0075A5 80 12            [24] 1365 	sjmp	00139$
      0075A7 80 18            [24] 1366 	sjmp	00140$
      0075A9                       1367 00137$:
      0075A9 8F 82            [24] 1368 	mov	dpl, r7
      0075AB 12 7A 73         [24] 1369 	lcall	_layer_and
      0075AE 02 76 62         [24] 1370 	ljmp	00181$
                                   1371 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      0075B1                       1372 00138$:
      0075B1 8F 82            [24] 1373 	mov	dpl, r7
      0075B3 12 7A 62         [24] 1374 	lcall	_layer_or
      0075B6 02 76 62         [24] 1375 	ljmp	00181$
                                   1376 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      0075B9                       1377 00139$:
      0075B9 8F 82            [24] 1378 	mov	dpl, r7
      0075BB 12 7A 89         [24] 1379 	lcall	_layer_xor
      0075BE 02 76 62         [24] 1380 	ljmp	00181$
                                   1381 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      0075C1                       1382 00140$:
      0075C1 8F 82            [24] 1383 	mov	dpl, r7
      0075C3 12 79 FF         [24] 1384 	lcall	_layer_state_set
                                   1385 ;	quantum/action.c:683: break;
      0075C6 02 76 62         [24] 1386 	ljmp	00181$
                                   1387 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      0075C9                       1388 00147$:
                                   1389 ;	quantum/action.c:686: if (pressed) {
      0075C9 E5 27            [12] 1390 	mov	a,_process_action_sloc0_1_0
      0075CB 60 11            [24] 1391 	jz	00149$
                                   1392 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      0075CD 12 78 6D         [24] 1393 	lcall	_ak820_outline_0109
      0075D0 F5 82            [12] 1394 	mov	dpl,a
      0075D2 12 79 60         [24] 1395 	lcall	_layer_hold_on
                                   1396 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      0075D5 12 78 56         [24] 1397 	lcall	_ak820_outline_0076
      0075D8 12 77 9C         [24] 1398 	lcall	_register_mods
      0075DB 02 76 62         [24] 1399 	ljmp	00181$
      0075DE                       1400 00149$:
                                   1401 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      0075DE 12 78 56         [24] 1402 	lcall	_ak820_outline_0076
      0075E1 12 77 B0         [24] 1403 	lcall	_unregister_mods
                                   1404 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      0075E4 12 78 6D         [24] 1405 	lcall	_ak820_outline_0109
      0075E7 F5 82            [12] 1406 	mov	dpl,a
      0075E9 12 79 98         [24] 1407 	lcall	_layer_hold_off
                                   1408 ;	quantum/action.c:693: break;
      0075EC 02 76 62         [24] 1409 	ljmp	00181$
                                   1410 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      0075EF                       1411 00152$:
                                   1412 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      0075EF 12 78 7F         [24] 1413 	lcall	_ak820_outline_0155
      0075F2 FF               [12] 1414 	mov	r7,a
      0075F3 BF F1 02         [24] 1415 	cjne	r7,#0xf1,00468$
      0075F6 80 0A            [24] 1416 	sjmp	00154$
      0075F8                       1417 00468$:
      0075F8 BF F2 02         [24] 1418 	cjne	r7,#0xf2,00469$
      0075FB 80 19            [24] 1419 	sjmp	00155$
      0075FD                       1420 00469$:
                                   1421 ;	quantum/action.c:712: momentary_layer_action:
      0075FD BF F3 3B         [24] 1422 	cjne	r7,#0xf3,00160$
      007600 80 28            [24] 1423 	sjmp	00156$
      007602                       1424 00154$:
                                   1425 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007602 E5 27            [12] 1426 	mov	a,_process_action_sloc0_1_0
      007604 60 08            [24] 1427 	jz	00206$
      007606 12 78 3D         [24] 1428 	lcall	_ak820_outline_0039
      007609 12 79 60         [24] 1429 	lcall	_layer_hold_on
      00760C 80 54            [24] 1430 	sjmp	00181$
      00760E                       1431 00206$:
      00760E 12 78 3D         [24] 1432 	lcall	_ak820_outline_0039
      007611 12 79 98         [24] 1433 	lcall	_layer_hold_off
                                   1434 ;	quantum/action.c:714: break;
                                   1435 ;	quantum/action.c:715: case OP_OFF_ON:
      007614 80 4C            [24] 1436 	sjmp	00181$
      007616                       1437 00155$:
                                   1438 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007616 E5 27            [12] 1439 	mov	a,_process_action_sloc0_1_0
      007618 60 08            [24] 1440 	jz	00208$
      00761A 12 78 3D         [24] 1441 	lcall	_ak820_outline_0039
      00761D 12 7A 44         [24] 1442 	lcall	_layer_off
      007620 80 40            [24] 1443 	sjmp	00181$
      007622                       1444 00208$:
      007622 12 78 3D         [24] 1445 	lcall	_ak820_outline_0039
      007625 12 7A 29         [24] 1446 	lcall	_layer_on
                                   1447 ;	quantum/action.c:717: break;
                                   1448 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007628 80 38            [24] 1449 	sjmp	00181$
      00762A                       1450 00156$:
                                   1451 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00762A E5 27            [12] 1452 	mov	a,_process_action_sloc0_1_0
      00762C 60 08            [24] 1453 	jz	00210$
      00762E 12 78 3D         [24] 1454 	lcall	_ak820_outline_0039
      007631 12 7A 13         [24] 1455 	lcall	_layer_move
      007634 80 2C            [24] 1456 	sjmp	00181$
      007636                       1457 00210$:
      007636 12 7A 0D         [24] 1458 	lcall	_layer_clear
                                   1459 ;	quantum/action.c:720: break;
                                   1460 ;	quantum/action.c:766: default:
      007639 80 27            [24] 1461 	sjmp	00181$
      00763B                       1462 00160$:
                                   1463 ;	quantum/action.c:773: if (pressed) {
      00763B E5 27            [12] 1464 	mov	a,_process_action_sloc0_1_0
      00763D 60 08            [24] 1465 	jz	00163$
                                   1466 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      00763F 12 78 56         [24] 1467 	lcall	_ak820_outline_0076
      007642 12 76 79         [24] 1468 	lcall	_register_code
                                   1469 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007645 80 1B            [24] 1470 	sjmp	00181$
      007647                       1471 00163$:
                                   1472 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007647 12 78 7F         [24] 1473 	lcall	_ak820_outline_0155
      00764A FF               [12] 1474 	mov	r7,a
      00764B BF 39 0E         [24] 1475 	cjne	r7,#0x39,00175$
                                   1476 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      00764E 7F 50            [12] 1477 	mov	r7,#0x50
      007650                       1478 00187$:
      007650 EF               [12] 1479 	mov	a,r7
      007651 60 09            [24] 1480 	jz	00175$
      007653 90 00 01         [24] 1481 	mov	dptr,#0x0001
      007656 12 59 B5         [24] 1482 	lcall	_mDelaymS
      007659 1F               [12] 1483 	dec	r7
                                   1484 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      00765A 80 F4            [24] 1485 	sjmp	00187$
      00765C                       1486 00175$:
                                   1487 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      00765C 12 78 56         [24] 1488 	lcall	_ak820_outline_0076
      00765F 12 76 E6         [24] 1489 	lcall	_unregister_code
                                   1490 ;	quantum/action.c:866: }
      007662                       1491 00181$:
                                   1492 ;	quantum/action.c:887: switch (action.kind.id) {
      007662 90 08 33         [24] 1493 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007665 E0               [24] 1494 	movx	a,@dptr
      007666 C4               [12] 1495 	swap	a
      007667 54 0F            [12] 1496 	anl	a,#0x0f
      007669 FF               [12] 1497 	mov	r7,a
      00766A BF 08 02         [24] 1498 	cjne	r7,#0x08,00478$
      00766D 80 03            [24] 1499 	sjmp	00183$
      00766F                       1500 00478$:
      00766F BF 09 06         [24] 1501 	cjne	r7,#0x09,00192$
                                   1502 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007672                       1503 00183$:
                                   1504 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007672 12 6E 2B         [24] 1505 	lcall	_host_keyboard_leds
                                   1506 ;	quantum/action.c:898: }
                                   1507 ;	quantum/action.c:951: }
      007675 02 98 F2         [24] 1508 	ljmp	_led_set
      007678                       1509 00192$:
      007678 22               [24] 1510 	ret
                                   1511 ;------------------------------------------------------------
                                   1512 ;Allocation info for local variables in function 'register_code'
                                   1513 ;------------------------------------------------------------
                                   1514 ;code          Allocated with name '_register_code_code_10000_710'
                                   1515 ;------------------------------------------------------------
                                   1516 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1517 ;	-----------------------------------------
                                   1518 ;	 function register_code
                                   1519 ;	-----------------------------------------
      007679                       1520 _register_code:
      007679 E5 82            [12] 1521 	mov	a,dpl
      00767B 90 08 37         [24] 1522 	mov	dptr,#_register_code_code_10000_710
      00767E F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action.c:958: if (code == KC_NO) {
      00767F E0               [24] 1525 	movx	a,@dptr
      007680 FF               [12] 1526 	mov	r7,a
      007681 70 01            [24] 1527 	jnz	00123$
                                   1528 ;	quantum/action.c:959: return;
      007683 22               [24] 1529 	ret
      007684                       1530 00123$:
                                   1531 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007684 BF 04 00         [24] 1532 	cjne	r7,#0x04,00186$
      007687                       1533 00186$:
      007687 40 12            [24] 1534 	jc	00119$
      007689 EF               [12] 1535 	mov	a,r7
      00768A 24 5B            [12] 1536 	add	a,#0xff - 0xa4
      00768C 40 0D            [24] 1537 	jc	00119$
                                   1538 ;	free result
                                   1539 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      00768E 8F 82            [24] 1540 	mov	dpl, r7
      007690 12 7E D9         [24] 1541 	lcall	_add_owned_key
      007693 E5 82            [12] 1542 	mov	a, dpl
      007695 70 01            [24] 1543 	jnz	00104$
      007697 22               [24] 1544 	ret
      007698                       1545 00104$:
                                   1546 ;	quantum/action.c:1013: send_keyboard_report();
      007698 02 81 6F         [24] 1547 	ljmp	_send_keyboard_report
      00769B                       1548 00119$:
                                   1549 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      00769B 12 78 84         [24] 1550 	lcall	_ak820_outline_0163
      00769E BF E0 00         [24] 1551 	cjne	r7,#0xe0,00190$
      0076A1                       1552 00190$:
      0076A1 40 1A            [24] 1553 	jc	00115$
      0076A3 EF               [12] 1554 	mov	a,r7
      0076A4 24 18            [12] 1555 	add	a,#0xff - 0xe7
      0076A6 40 15            [24] 1556 	jc	00115$
                                   1557 ;	free result
                                   1558 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      0076A8 74 07            [12] 1559 	mov	a,#0x07
      0076AA 5F               [12] 1560 	anl	a,r7
      0076AB 12 78 4F         [24] 1561 	lcall	_ak820_outline_0063
      0076AE 80 02            [24] 1562 	sjmp	00194$
      0076B0                       1563 00193$:
      0076B0 25 E0            [12] 1564 	add	a,acc
      0076B2                       1565 00194$:
      0076B2 D5 F0 FB         [24] 1566 	djnz	b,00193$
      0076B5 F5 82            [12] 1567 	mov	dpl,a
      0076B7 12 7E 35         [24] 1568 	lcall	_add_owned_mods
                                   1569 ;	quantum/action.c:1016: send_keyboard_report();
      0076BA 02 81 6F         [24] 1570 	ljmp	_send_keyboard_report
      0076BD                       1571 00115$:
                                   1572 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0076BD 12 78 84         [24] 1573 	lcall	_ak820_outline_0163
      0076C0 BF A5 00         [24] 1574 	cjne	r7,#0xa5,00195$
      0076C3                       1575 00195$:
      0076C3 40 05            [24] 1576 	jc	00113$
      0076C5 EF               [12] 1577 	mov	a,r7
      0076C6 24 58            [12] 1578 	add	a,#0xff - 0xa7
      0076C8 50 0D            [24] 1579 	jnc	00108$
                                   1580 ;	free result
      0076CA                       1581 00113$:
      0076CA 12 78 84         [24] 1582 	lcall	_ak820_outline_0163
      0076CD BF A8 00         [24] 1583 	cjne	r7,#0xa8,00198$
      0076D0                       1584 00198$:
      0076D0 40 13            [24] 1585 	jc	00125$
      0076D2 EF               [12] 1586 	mov	a,r7
      0076D3 24 3D            [12] 1587 	add	a,#0xff - 0xc2
      0076D5 40 0E            [24] 1588 	jc	00125$
                                   1589 ;	free result
      0076D7                       1590 00108$:
                                   1591 ;	quantum/action.c:1021: owned_usage_key(code, true);
      0076D7 12 78 84         [24] 1592 	lcall	_ak820_outline_0163
      0076DA 90 0A 95         [24] 1593 	mov	dptr,#_owned_usage_key_PARM_2
      0076DD 74 01            [12] 1594 	mov	a,#0x01
      0076DF F0               [24] 1595 	movx	@dptr,a
      0076E0 8F 82            [24] 1596 	mov	dpl, r7
                                   1597 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1598 ;	quantum/action.c:1031: }
      0076E2 02 80 1A         [24] 1599 	ljmp	_owned_usage_key
      0076E5                       1600 00125$:
      0076E5 22               [24] 1601 	ret
                                   1602 ;------------------------------------------------------------
                                   1603 ;Allocation info for local variables in function 'unregister_code'
                                   1604 ;------------------------------------------------------------
                                   1605 ;code          Allocated with name '_unregister_code_code_10000_724'
                                   1606 ;------------------------------------------------------------
                                   1607 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1608 ;	-----------------------------------------
                                   1609 ;	 function unregister_code
                                   1610 ;	-----------------------------------------
      0076E6                       1611 _unregister_code:
      0076E6 E5 82            [12] 1612 	mov	a,dpl
      0076E8 90 08 38         [24] 1613 	mov	dptr,#_unregister_code_code_10000_724
      0076EB F0               [24] 1614 	movx	@dptr,a
                                   1615 ;	quantum/action.c:1038: if (code == KC_NO) {
      0076EC E0               [24] 1616 	movx	a,@dptr
      0076ED FF               [12] 1617 	mov	r7,a
      0076EE 70 01            [24] 1618 	jnz	00121$
                                   1619 ;	quantum/action.c:1039: return;
      0076F0 22               [24] 1620 	ret
      0076F1                       1621 00121$:
                                   1622 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      0076F1 BF 04 00         [24] 1623 	cjne	r7,#0x04,00184$
      0076F4                       1624 00184$:
      0076F4 40 12            [24] 1625 	jc	00117$
      0076F6 EF               [12] 1626 	mov	a,r7
      0076F7 24 5B            [12] 1627 	add	a,#0xff - 0xa4
      0076F9 40 0D            [24] 1628 	jc	00117$
                                   1629 ;	free result
                                   1630 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      0076FB 8F 82            [24] 1631 	mov	dpl, r7
      0076FD 12 7F 53         [24] 1632 	lcall	_del_owned_key
      007700 E5 82            [12] 1633 	mov	a, dpl
      007702 70 01            [24] 1634 	jnz	00102$
      007704 22               [24] 1635 	ret
      007705                       1636 00102$:
                                   1637 ;	quantum/action.c:1080: send_keyboard_report();
      007705 02 81 6F         [24] 1638 	ljmp	_send_keyboard_report
      007708                       1639 00117$:
                                   1640 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007708 12 78 8A         [24] 1641 	lcall	_ak820_outline_0164
      00770B BF E0 00         [24] 1642 	cjne	r7,#0xe0,00188$
      00770E                       1643 00188$:
      00770E 40 1A            [24] 1644 	jc	00113$
      007710 EF               [12] 1645 	mov	a,r7
      007711 24 18            [12] 1646 	add	a,#0xff - 0xe7
      007713 40 15            [24] 1647 	jc	00113$
                                   1648 ;	free result
                                   1649 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007715 74 07            [12] 1650 	mov	a,#0x07
      007717 5F               [12] 1651 	anl	a,r7
      007718 12 78 4F         [24] 1652 	lcall	_ak820_outline_0063
      00771B 80 02            [24] 1653 	sjmp	00192$
      00771D                       1654 00191$:
      00771D 25 E0            [12] 1655 	add	a,acc
      00771F                       1656 00192$:
      00771F D5 F0 FB         [24] 1657 	djnz	b,00191$
      007722 F5 82            [12] 1658 	mov	dpl,a
      007724 12 7E 45         [24] 1659 	lcall	_del_owned_mods
                                   1660 ;	quantum/action.c:1083: send_keyboard_report();
      007727 02 81 6F         [24] 1661 	ljmp	_send_keyboard_report
      00772A                       1662 00113$:
                                   1663 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00772A 12 78 8A         [24] 1664 	lcall	_ak820_outline_0164
      00772D BF A5 00         [24] 1665 	cjne	r7,#0xa5,00193$
      007730                       1666 00193$:
      007730 40 05            [24] 1667 	jc	00111$
      007732 EF               [12] 1668 	mov	a,r7
      007733 24 58            [12] 1669 	add	a,#0xff - 0xa7
      007735 50 0D            [24] 1670 	jnc	00106$
                                   1671 ;	free result
      007737                       1672 00111$:
      007737 12 78 8A         [24] 1673 	lcall	_ak820_outline_0164
      00773A BF A8 00         [24] 1674 	cjne	r7,#0xa8,00196$
      00773D                       1675 00196$:
      00773D 40 12            [24] 1676 	jc	00123$
      00773F EF               [12] 1677 	mov	a,r7
      007740 24 3D            [12] 1678 	add	a,#0xff - 0xc2
      007742 40 0D            [24] 1679 	jc	00123$
                                   1680 ;	free result
      007744                       1681 00106$:
                                   1682 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007744 12 78 8A         [24] 1683 	lcall	_ak820_outline_0164
      007747 90 0A 95         [24] 1684 	mov	dptr,#_owned_usage_key_PARM_2
      00774A E4               [12] 1685 	clr	a
      00774B F0               [24] 1686 	movx	@dptr,a
      00774C 8F 82            [24] 1687 	mov	dpl, r7
                                   1688 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1689 ;	quantum/action.c:1098: }
      00774E 02 80 1A         [24] 1690 	ljmp	_owned_usage_key
      007751                       1691 00123$:
      007751 22               [24] 1692 	ret
                                   1693 ;------------------------------------------------------------
                                   1694 ;Allocation info for local variables in function 'tap_code_delay'
                                   1695 ;------------------------------------------------------------
                                   1696 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1697 ;code          Allocated with name '_tap_code_delay_code_10000_737'
                                   1698 ;i             Allocated with name '_tap_code_delay_i_20000_739'
                                   1699 ;i             Allocated with name '_tap_code_delay_i_50000_742'
                                   1700 ;------------------------------------------------------------
                                   1701 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1702 ;	-----------------------------------------
                                   1703 ;	 function tap_code_delay
                                   1704 ;	-----------------------------------------
      007752                       1705 _tap_code_delay:
      007752 E5 82            [12] 1706 	mov	a,dpl
      007754 90 08 3B         [24] 1707 	mov	dptr,#_tap_code_delay_code_10000_737
      007757 F0               [24] 1708 	movx	@dptr,a
                                   1709 ;	quantum/action.c:1106: register_code(code);
      007758 E0               [24] 1710 	movx	a,@dptr
      007759 FF               [12] 1711 	mov	r7,a
      00775A F5 82            [12] 1712 	mov	dpl,a
      00775C C0 07            [24] 1713 	push	ar7
      00775E 12 76 79         [24] 1714 	lcall	_register_code
      007761 D0 07            [24] 1715 	pop	ar7
                                   1716 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007763 90 08 39         [24] 1717 	mov	dptr,#_tap_code_delay_PARM_2
      007766 12 43 7A         [24] 1718 	lcall	_ak820_outline_0091
      007769                       1719 00110$:
      007769 ED               [12] 1720 	mov	a,r5
      00776A 4E               [12] 1721 	orl	a,r6
      00776B 60 0D            [24] 1722 	jz	00105$
                                   1723 ;	quantum/action.c:1108: wait_ms(1);
      00776D 90 00 01         [24] 1724 	mov	dptr,#0x0001
      007770 12 59 B5         [24] 1725 	lcall	_mDelaymS
                                   1726 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007773 1D               [12] 1727 	dec	r5
      007774 BD FF 01         [24] 1728 	cjne	r5,#0xff,00141$
      007777 1E               [12] 1729 	dec	r6
      007778                       1730 00141$:
      007778 80 EF            [24] 1731 	sjmp	00110$
      00777A                       1732 00105$:
                                   1733 ;	quantum/action.c:1110: unregister_code(code);
      00777A 8F 82            [24] 1734 	mov	dpl, r7
                                   1735 ;	quantum/action.c:1111: }
      00777C 02 76 E6         [24] 1736 	ljmp	_unregister_code
                                   1737 ;------------------------------------------------------------
                                   1738 ;Allocation info for local variables in function 'tap_code'
                                   1739 ;------------------------------------------------------------
                                   1740 ;code          Allocated with name '_tap_code_code_10000_744'
                                   1741 ;------------------------------------------------------------
                                   1742 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1743 ;	-----------------------------------------
                                   1744 ;	 function tap_code
                                   1745 ;	-----------------------------------------
      00777F                       1746 _tap_code:
      00777F E5 82            [12] 1747 	mov	a,dpl
      007781 90 08 3C         [24] 1748 	mov	dptr,#_tap_code_code_10000_744
      007784 F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007785 E0               [24] 1751 	movx	a,@dptr
      007786 FF               [12] 1752 	mov	r7,a
      007787 BF 39 04         [24] 1753 	cjne	r7,#0x39,00103$
      00778A 7E 50            [12] 1754 	mov	r6,#0x50
      00778C 80 02            [24] 1755 	sjmp	00104$
      00778E                       1756 00103$:
      00778E 7E 00            [12] 1757 	mov	r6,#0x00
      007790                       1758 00104$:
      007790 90 08 39         [24] 1759 	mov	dptr,#_tap_code_delay_PARM_2
      007793 EE               [12] 1760 	mov	a,r6
      007794 12 38 65         [24] 1761 	lcall	_ak820_outline_0124
      007797 8F 82            [24] 1762 	mov	dpl, r7
                                   1763 ;	quantum/action.c:1119: }
      007799 02 77 52         [24] 1764 	ljmp	_tap_code_delay
                                   1765 ;------------------------------------------------------------
                                   1766 ;Allocation info for local variables in function 'register_mods'
                                   1767 ;------------------------------------------------------------
                                   1768 ;mods          Allocated with name '_register_mods_mods_10000_746'
                                   1769 ;------------------------------------------------------------
                                   1770 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1771 ;	-----------------------------------------
                                   1772 ;	 function register_mods
                                   1773 ;	-----------------------------------------
      00779C                       1774 _register_mods:
      00779C E5 82            [12] 1775 	mov	a,dpl
      00779E 90 08 3D         [24] 1776 	mov	dptr,#_register_mods_mods_10000_746
      0077A1 F0               [24] 1777 	movx	@dptr,a
                                   1778 ;	quantum/action.c:1126: if (mods) {
      0077A2 E0               [24] 1779 	movx	a,@dptr
      0077A3 FF               [12] 1780 	mov	r7,a
      0077A4 E0               [24] 1781 	movx	a,@dptr
      0077A5 60 08            [24] 1782 	jz	00103$
                                   1783 ;	quantum/action.c:1127: add_owned_mods(mods);
      0077A7 8F 82            [24] 1784 	mov	dpl, r7
      0077A9 12 7E 35         [24] 1785 	lcall	_add_owned_mods
                                   1786 ;	quantum/action.c:1128: send_keyboard_report();
                                   1787 ;	quantum/action.c:1130: }
      0077AC 02 81 6F         [24] 1788 	ljmp	_send_keyboard_report
      0077AF                       1789 00103$:
      0077AF 22               [24] 1790 	ret
                                   1791 ;------------------------------------------------------------
                                   1792 ;Allocation info for local variables in function 'unregister_mods'
                                   1793 ;------------------------------------------------------------
                                   1794 ;mods          Allocated with name '_unregister_mods_mods_10000_750'
                                   1795 ;------------------------------------------------------------
                                   1796 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1797 ;	-----------------------------------------
                                   1798 ;	 function unregister_mods
                                   1799 ;	-----------------------------------------
      0077B0                       1800 _unregister_mods:
      0077B0 E5 82            [12] 1801 	mov	a,dpl
      0077B2 90 08 3E         [24] 1802 	mov	dptr,#_unregister_mods_mods_10000_750
      0077B5 F0               [24] 1803 	movx	@dptr,a
                                   1804 ;	quantum/action.c:1137: if (mods) {
      0077B6 E0               [24] 1805 	movx	a,@dptr
      0077B7 FF               [12] 1806 	mov	r7,a
      0077B8 E0               [24] 1807 	movx	a,@dptr
      0077B9 60 08            [24] 1808 	jz	00103$
                                   1809 ;	quantum/action.c:1138: del_owned_mods(mods);
      0077BB 8F 82            [24] 1810 	mov	dpl, r7
      0077BD 12 7E 45         [24] 1811 	lcall	_del_owned_mods
                                   1812 ;	quantum/action.c:1139: send_keyboard_report();
                                   1813 ;	quantum/action.c:1141: }
      0077C0 02 81 6F         [24] 1814 	ljmp	_send_keyboard_report
      0077C3                       1815 00103$:
      0077C3 22               [24] 1816 	ret
                                   1817 ;------------------------------------------------------------
                                   1818 ;Allocation info for local variables in function 'register_weak_mods'
                                   1819 ;------------------------------------------------------------
                                   1820 ;mods          Allocated with name '_register_weak_mods_mods_10000_754'
                                   1821 ;------------------------------------------------------------
                                   1822 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1823 ;	-----------------------------------------
                                   1824 ;	 function register_weak_mods
                                   1825 ;	-----------------------------------------
      0077C4                       1826 _register_weak_mods:
      0077C4 E5 82            [12] 1827 	mov	a,dpl
      0077C6 90 08 3F         [24] 1828 	mov	dptr,#_register_weak_mods_mods_10000_754
      0077C9 F0               [24] 1829 	movx	@dptr,a
                                   1830 ;	quantum/action.c:1148: if (mods) {
      0077CA E0               [24] 1831 	movx	a,@dptr
      0077CB FF               [12] 1832 	mov	r7,a
      0077CC E0               [24] 1833 	movx	a,@dptr
      0077CD 60 08            [24] 1834 	jz	00103$
                                   1835 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      0077CF 8F 82            [24] 1836 	mov	dpl, r7
      0077D1 12 7E 54         [24] 1837 	lcall	_add_owned_weak_mods
                                   1838 ;	quantum/action.c:1150: send_keyboard_report();
                                   1839 ;	quantum/action.c:1152: }
      0077D4 02 81 6F         [24] 1840 	ljmp	_send_keyboard_report
      0077D7                       1841 00103$:
      0077D7 22               [24] 1842 	ret
                                   1843 ;------------------------------------------------------------
                                   1844 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1845 ;------------------------------------------------------------
                                   1846 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_758'
                                   1847 ;------------------------------------------------------------
                                   1848 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1849 ;	-----------------------------------------
                                   1850 ;	 function unregister_weak_mods
                                   1851 ;	-----------------------------------------
      0077D8                       1852 _unregister_weak_mods:
      0077D8 E5 82            [12] 1853 	mov	a,dpl
      0077DA 90 08 40         [24] 1854 	mov	dptr,#_unregister_weak_mods_mods_10000_758
      0077DD F0               [24] 1855 	movx	@dptr,a
                                   1856 ;	quantum/action.c:1159: if (mods) {
      0077DE E0               [24] 1857 	movx	a,@dptr
      0077DF FF               [12] 1858 	mov	r7,a
      0077E0 E0               [24] 1859 	movx	a,@dptr
      0077E1 60 08            [24] 1860 	jz	00103$
                                   1861 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      0077E3 8F 82            [24] 1862 	mov	dpl, r7
      0077E5 12 7E 64         [24] 1863 	lcall	_del_owned_weak_mods
                                   1864 ;	quantum/action.c:1161: send_keyboard_report();
                                   1865 ;	quantum/action.c:1163: }
      0077E8 02 81 6F         [24] 1866 	ljmp	_send_keyboard_report
      0077EB                       1867 00103$:
      0077EB 22               [24] 1868 	ret
                                   1869 ;------------------------------------------------------------
                                   1870 ;Allocation info for local variables in function 'clear_keyboard'
                                   1871 ;------------------------------------------------------------
                                   1872 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1873 ;	-----------------------------------------
                                   1874 ;	 function clear_keyboard
                                   1875 ;	-----------------------------------------
      0077EC                       1876 _clear_keyboard:
                                   1877 ;	quantum/action.c:1170: clear_mods();
      0077EC 12 82 11         [24] 1878 	lcall	_clear_mods
                                   1879 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1880 ;	quantum/action.c:1172: }
      0077EF 02 77 F2         [24] 1881 	ljmp	_clear_keyboard_but_mods
                                   1882 ;------------------------------------------------------------
                                   1883 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1884 ;------------------------------------------------------------
                                   1885 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1886 ;	-----------------------------------------
                                   1887 ;	 function clear_keyboard_but_mods
                                   1888 ;	-----------------------------------------
      0077F2                       1889 _clear_keyboard_but_mods:
                                   1890 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0077F2 90 0D A1         [24] 1891 	mov	dptr,#_actual_keyboard_report
      0077F5 12 70 EA         [24] 1892 	lcall	_clear_keys_from_report
                                   1893 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1894 ;	quantum/action.c:1181: }
      0077F8 02 77 FB         [24] 1895 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1896 ;------------------------------------------------------------
                                   1897 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1898 ;------------------------------------------------------------
                                   1899 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1900 ;	-----------------------------------------
                                   1901 ;	 function clear_keyboard_but_mods_and_keys
                                   1902 ;	-----------------------------------------
      0077FB                       1903 _clear_keyboard_but_mods_and_keys:
                                   1904 ;	quantum/action.c:1189: ak820_tapping_cancel();
      0077FB 12 47 C7         [24] 1905 	lcall	_ak820_tapping_cancel
                                   1906 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      0077FE 12 2E A4         [24] 1907 	lcall	_ak820_oneshot_cancel
                                   1908 ;	quantum/action.c:1209: ak820_combo_cancel();
      007801 12 35 27         [24] 1909 	lcall	_ak820_combo_cancel
                                   1910 ;	quantum/action.c:1212: repeat_key_cancel();
      007804 12 A2 02         [24] 1911 	lcall	_repeat_key_cancel
                                   1912 ;	quantum/action.c:1214: clear_owned_mods();
      007807 12 7E 74         [24] 1913 	lcall	_clear_owned_mods
                                   1914 ;	quantum/action.c:1215: clear_owned_keys();
      00780A 12 7E AC         [24] 1915 	lcall	_clear_owned_keys
                                   1916 ;	quantum/action.c:1216: clear_owned_usages();
      00780D 12 7F E2         [24] 1917 	lcall	_clear_owned_usages
                                   1918 ;	quantum/action.c:1217: layer_hold_clear();
      007810 12 79 D0         [24] 1919 	lcall	_layer_hold_clear
                                   1920 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007813 12 9D 81         [24] 1921 	lcall	_clear_macro_tri_layer
                                   1922 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007816 90 0D A1         [24] 1923 	mov	dptr,#_actual_keyboard_report
      007819 12 70 EA         [24] 1924 	lcall	_clear_keys_from_report
                                   1925 ;	quantum/action.c:1224: host_system_send(0);
      00781C 90 00 00         [24] 1926 	mov	dptr,#0x0000
      00781F 12 6E C6         [24] 1927 	lcall	_host_system_send
                                   1928 ;	quantum/action.c:1225: host_consumer_send(0);
      007822 90 00 00         [24] 1929 	mov	dptr,#0x0000
      007825 12 6E F6         [24] 1930 	lcall	_host_consumer_send
                                   1931 ;	quantum/action.c:1227: clear_weak_mods();
      007828 12 82 46         [24] 1932 	lcall	_clear_weak_mods
                                   1933 ;	quantum/action.c:1228: send_keyboard_report();
                                   1934 ;	quantum/action.c:1236: }
      00782B 02 81 6F         [24] 1935 	ljmp	_send_keyboard_report
                                   1936 ;------------------------------------------------------------
                                   1937 ;Allocation info for local variables in function 'is_tap_record'
                                   1938 ;------------------------------------------------------------
                                   1939 ;record        Allocated with name '_is_tap_record_record_10000_774'
                                   1940 ;action        Allocated with name '_is_tap_record_action_10001_778'
                                   1941 ;------------------------------------------------------------
                                   1942 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1943 ;	-----------------------------------------
                                   1944 	.area CSEG    (CODE)
                                   1945 	.area CONST   (CODE)
                                   1946 	.area XINIT   (CODE)
      00C170                       1947 __xinit__disable_action_cache:
      00C170 00                    1948 	.db #0x00	;  0
                                   1949 	.area CABS    (ABS,CODE)
                                   1950 
                                   1951 ; Experimental exact instruction outlining.
                                   1952 	.globl _ak820_outline_0004
                                   1953 	.globl _ak820_outline_0009
                                   1954 	.globl _ak820_outline_0010
                                   1955 	.globl _ak820_outline_0011
                                   1956 	.globl _ak820_outline_0012
                                   1957 	.globl _ak820_outline_0016
                                   1958 	.globl _ak820_outline_0017
                                   1959 	.globl _ak820_outline_0020
                                   1960 	.globl _ak820_outline_0031
                                   1961 	.globl _ak820_outline_0039
                                   1962 	.globl _ak820_outline_0050
                                   1963 	.globl _ak820_outline_0051
                                   1964 	.globl _ak820_outline_0055
                                   1965 	.globl _ak820_outline_0058
                                   1966 	.globl _ak820_outline_0063
                                   1967 	.globl _ak820_outline_0071
                                   1968 	.globl _ak820_outline_0076
                                   1969 	.globl _ak820_outline_0086
                                   1970 	.globl _ak820_outline_0091
                                   1971 	.globl _ak820_outline_0103
                                   1972 	.globl _ak820_outline_0104
                                   1973 	.globl _ak820_outline_0106
                                   1974 	.globl _ak820_outline_0107
                                   1975 	.globl _ak820_outline_0109
                                   1976 	.globl _ak820_outline_0116
                                   1977 	.globl _ak820_outline_0118
                                   1978 	.globl _ak820_outline_0122
                                   1979 	.globl _ak820_outline_0124
                                   1980 	.globl _ak820_outline_0130
                                   1981 	.globl _ak820_outline_0140
                                   1982 	.globl _ak820_outline_0141
                                   1983 	.globl _ak820_outline_0146
                                   1984 	.globl _ak820_outline_0155
                                   1985 	.globl _ak820_outline_0163
                                   1986 	.globl _ak820_outline_0164
                                   1987 	.globl _ak820_outline_0179
                                   1988 	.globl _ak820_outline_0185
                                   1989 
                                   1990 	.area CSEG (CODE)
                                   1991 ; function ak820_outline_0020
      00782E                       1992 _ak820_outline_0020:
      00782E 8E 82            [24] 1993 	mov	dpl,r6
      007830 8F 83            [24] 1994 	mov	dph,r7
      007832 A3               [24] 1995 	inc	dptr
      007833 E0               [24] 1996 	movx	a,@dptr
      007834 FC               [12] 1997 	mov	r4,a
      007835 7D 00            [12] 1998 	mov	r5,#0x00
      007837 8E 82            [24] 1999 	mov	dpl,r6
      007839 8F 83            [24] 2000 	mov	dph,r7
      00783B E0               [24] 2001 	movx	a,@dptr
      00783C 22               [24] 2002 	ret
                                   2003 
                                   2004 	.area CSEG (CODE)
                                   2005 ; function ak820_outline_0039
      00783D                       2006 _ak820_outline_0039:
      00783D 90 08 33         [24] 2007 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007840 E0               [24] 2008 	movx	a,@dptr
      007841 54 1F            [12] 2009 	anl	a,#0x1f
      007843 F5 82            [12] 2010 	mov	dpl,a
      007845 22               [24] 2011 	ret
                                   2012 
                                   2013 	.area CSEG (CODE)
                                   2014 ; function ak820_outline_0050
      007846                       2015 _ak820_outline_0050:
      007846 A3               [24] 2016 	inc	dptr
      007847 F0               [24] 2017 	movx	@dptr,a
      007848 E4               [12] 2018 	clr	a
      007849 A3               [24] 2019 	inc	dptr
      00784A F0               [24] 2020 	movx	@dptr,a
      00784B 90 0D 7F         [24] 2021 	mov	dptr,#___memcpy_PARM_3
      00784E 22               [24] 2022 	ret
                                   2023 
                                   2024 	.area CSEG (CODE)
                                   2025 ; function ak820_outline_0063
      00784F                       2026 _ak820_outline_0063:
      00784F F5 F0            [12] 2027 	mov	b,a
      007851 05 F0            [12] 2028 	inc	b
      007853 74 01            [12] 2029 	mov	a,#0x01
      007855 22               [24] 2030 	ret
                                   2031 
                                   2032 	.area CSEG (CODE)
                                   2033 ; function ak820_outline_0076
      007856                       2034 _ak820_outline_0076:
      007856 90 08 32         [24] 2035 	mov	dptr,#_process_action_PARM_2
      007859 E0               [24] 2036 	movx	a,@dptr
      00785A F5 82            [12] 2037 	mov	dpl,a
      00785C 22               [24] 2038 	ret
                                   2039 
                                   2040 	.area CSEG (CODE)
                                   2041 ; function ak820_outline_0086
      00785D                       2042 _ak820_outline_0086:
      00785D 90 08 33         [24] 2043 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007860 E0               [24] 2044 	movx	a,@dptr
      007861 03               [12] 2045 	rr	a
      007862 03               [12] 2046 	rr	a
      007863 54 03            [12] 2047 	anl	a,#0x03
      007865 22               [24] 2048 	ret
                                   2049 
                                   2050 	.area CSEG (CODE)
                                   2051 ; function ak820_outline_0107
      007866                       2052 _ak820_outline_0107:
      007866 74 06            [12] 2053 	mov	a,#0x06
      007868 F0               [24] 2054 	movx	@dptr,a
      007869 E4               [12] 2055 	clr	a
      00786A A3               [24] 2056 	inc	dptr
      00786B F0               [24] 2057 	movx	@dptr,a
      00786C 22               [24] 2058 	ret
                                   2059 
                                   2060 	.area CSEG (CODE)
                                   2061 ; function ak820_outline_0109
      00786D                       2062 _ak820_outline_0109:
      00786D 90 08 33         [24] 2063 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007870 E0               [24] 2064 	movx	a,@dptr
      007871 54 0F            [12] 2065 	anl	a,#0x0f
      007873 22               [24] 2066 	ret
                                   2067 
                                   2068 	.area CSEG (CODE)
                                   2069 ; function ak820_outline_0130
      007874                       2070 _ak820_outline_0130:
      007874 90 08 32         [24] 2071 	mov	dptr,#_process_action_PARM_2
      007877 E0               [24] 2072 	movx	a,@dptr
      007878 FE               [12] 2073 	mov	r6,a
      007879 A3               [24] 2074 	inc	dptr
      00787A E0               [24] 2075 	movx	a,@dptr
      00787B 54 03            [12] 2076 	anl	a,#0x03
      00787D FF               [12] 2077 	mov	r7,a
      00787E 22               [24] 2078 	ret
                                   2079 
                                   2080 	.area CSEG (CODE)
                                   2081 ; function ak820_outline_0155
      00787F                       2082 _ak820_outline_0155:
      00787F 90 08 32         [24] 2083 	mov	dptr,#_process_action_PARM_2
      007882 E0               [24] 2084 	movx	a,@dptr
      007883 22               [24] 2085 	ret
                                   2086 
                                   2087 	.area CSEG (CODE)
                                   2088 ; function ak820_outline_0163
      007884                       2089 _ak820_outline_0163:
      007884 90 08 37         [24] 2090 	mov	dptr,#_register_code_code_10000_710
      007887 E0               [24] 2091 	movx	a,@dptr
      007888 FF               [12] 2092 	mov	r7,a
      007889 22               [24] 2093 	ret
                                   2094 
                                   2095 	.area CSEG (CODE)
                                   2096 ; function ak820_outline_0164
      00788A                       2097 _ak820_outline_0164:
      00788A 90 08 38         [24] 2098 	mov	dptr,#_unregister_code_code_10000_724
      00788D E0               [24] 2099 	movx	a,@dptr
      00788E FF               [12] 2100 	mov	r7,a
      00788F 22               [24] 2101 	ret
