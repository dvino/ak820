                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      000038                        553 _raw_hid_receive_sloc0_1_0:
      000038                        554 	.ds 4
      00003C                        555 _raw_hid_receive_sloc1_1_0:
      00003C                        556 	.ds 1
      00003D                        557 _raw_hid_receive_sloc2_1_0:
      00003D                        558 	.ds 1
      00003E                        559 _raw_hid_receive_sloc3_1_0:
      00003E                        560 	.ds 2
      000040                        561 _raw_hid_receive_sloc4_1_0:
      000040                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      000029                        579 _via_eeprom_is_valid_sloc0_1_0:
      000029                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000C20                        589 _via_eeprom_set_valid_valid_10000_610:
      000C20                        590 	.ds 1
      000C21                        591 _via_set_layout_options_value_10000_626:
      000C21                        592 	.ds 4
      000C25                        593 _process_record_via_PARM_2:
      000C25                        594 	.ds 3
      000C28                        595 _process_record_via_keycode_10000_628:
      000C28                        596 	.ds 2
      000C2A                        597 _raw_hid_receive_kb_PARM_2:
      000C2A                        598 	.ds 1
      000C2B                        599 _raw_hid_receive_kb_data_10000_634:
      000C2B                        600 	.ds 3
      000C2E                        601 _raw_hid_receive_PARM_2:
      000C2E                        602 	.ds 1
      000C2F                        603 _raw_hid_receive_packet_10000_636:
      000C2F                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00A5FD                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00A5FD 90 00 25         [24]  658 	mov	dptr,#0x0025
      00A600 75 F0 00         [24]  659 	mov	b, #0x00
      00A603 12 40 AA         [24]  660 	lcall	_eeprom_read_byte
      00A606 AF 82            [24]  661 	mov	r7, dpl
      00A608 BF 02 1E         [24]  662 	cjne	r7,#0x02,00103$
      00A60B 90 00 26         [24]  663 	mov	dptr,#0x0026
      00A60E 75 F0 00         [24]  664 	mov	b, #0x00
      00A611 12 40 AA         [24]  665 	lcall	_eeprom_read_byte
      00A614 AF 82            [24]  666 	mov	r7, dpl
      00A616 BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00A619 90 00 27         [24]  668 	mov	dptr,#0x0027
      00A61C 75 F0 00         [24]  669 	mov	b, #0x00
      00A61F 12 40 AA         [24]  670 	lcall	_eeprom_read_byte
      00A622 AF 82            [24]  671 	mov	r7, dpl
      00A624 BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00A627 80 04            [24]  673 	sjmp	00104$
      00A629                        674 00126$:
      00A629                        675 00103$:
                                    676 ;	assignBit
      00A629 C2 29            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00A62B 80 02            [24]  678 	sjmp	00105$
      00A62D                        679 00104$:
                                    680 ;	assignBit
      00A62D D2 29            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00A62F                        682 00105$:
      00A62F A2 29            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00A631 12 38 86         [24]  684 	lcall	_ak820_outline_0167
                                    685 ;	quantum/via.c:104: }
      00A634 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_610'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_611'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_611'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_611'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00A635                        699 _via_eeprom_set_valid:
      00A635 E5 82            [12]  700 	mov	a,dpl
      00A637 90 0C 20         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_610
      00A63A F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00A63B E0               [24]  704 	movx	a,@dptr
      00A63C 60 04            [24]  705 	jz	00103$
      00A63E 7F 02            [12]  706 	mov	r7,#0x02
      00A640 80 02            [24]  707 	sjmp	00104$
      00A642                        708 00103$:
      00A642 7F FF            [12]  709 	mov	r7,#0xff
      00A644                        710 00104$:
      00A644 90 06 9F         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A647 EF               [12]  712 	mov	a,r7
      00A648 F0               [24]  713 	movx	@dptr,a
      00A649 90 00 25         [24]  714 	mov	dptr,#0x0025
      00A64C 75 F0 00         [24]  715 	mov	b, #0x00
      00A64F 12 4E D5         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00A652 90 0C 20         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_610
      00A655 E0               [24]  719 	movx	a,@dptr
      00A656 60 04            [24]  720 	jz	00105$
      00A658 7F 20            [12]  721 	mov	r7,#0x20
      00A65A 80 02            [24]  722 	sjmp	00106$
      00A65C                        723 00105$:
      00A65C 7F FF            [12]  724 	mov	r7,#0xff
      00A65E                        725 00106$:
      00A65E 90 06 9F         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A661 EF               [12]  727 	mov	a,r7
      00A662 F0               [24]  728 	movx	@dptr,a
      00A663 90 00 26         [24]  729 	mov	dptr,#0x0026
      00A666 75 F0 00         [24]  730 	mov	b, #0x00
      00A669 12 4E D5         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00A66C 90 0C 20         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_610
      00A66F E0               [24]  734 	movx	a,@dptr
      00A670 60 04            [24]  735 	jz	00107$
      00A672 7F 08            [12]  736 	mov	r7,#0x08
      00A674 80 02            [24]  737 	sjmp	00108$
      00A676                        738 00107$:
      00A676 7F FF            [12]  739 	mov	r7,#0xff
      00A678                        740 00108$:
      00A678 90 06 9F         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A67B EF               [12]  742 	mov	a,r7
      00A67C F0               [24]  743 	movx	@dptr,a
      00A67D 90 00 27         [24]  744 	mov	dptr,#0x0027
      00A680 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00A683 02 4E D5         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00A686                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00A686 12 A6 AF         [24]  757 	lcall	_via_get_layout_options
      00A689 12 A6 C7         [24]  758 	lcall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00A68C 12 A5 FD         [24]  760 	lcall	_via_eeprom_is_valid
      00A68F E5 82            [12]  761 	mov	a, dpl
      00A691 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00A693 02 3E 5A         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00A696                        766 00103$:
      00A696 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00A697                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00A697 75 82 00         [24]  777 	mov	dpl, #0x00
      00A69A 12 A6 35         [24]  778 	lcall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00A69D 12 91 DB         [24]  780 	lcall	_ak820_outline_0149
      00A6A0 12 A6 C8         [24]  781 	lcall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00A6A3 12 88 59         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00A6A6 12 8C CD         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00A6A9 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00A6AC 02 A6 35         [24]  789 	ljmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00A6AF                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00A6AF 90 00 28         [24]  799 	mov	dptr,#0x0028
      00A6B2 75 F0 00         [24]  800 	mov	b, #0x00
      00A6B5 12 40 AA         [24]  801 	lcall	_eeprom_read_byte
      00A6B8 AF 82            [24]  802 	mov	r7, dpl
      00A6BA 7E 00            [12]  803 	mov	r6,#0x00
      00A6BC 7D 00            [12]  804 	mov	r5,#0x00
      00A6BE 7C 00            [12]  805 	mov	r4,#0x00
      00A6C0 12 43 B8         [24]  806 	lcall	_ak820_outline_0154
      00A6C3 8D F0            [24]  807 	mov	b, r5
      00A6C5 EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00A6C6 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_623'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00A6C7                        820 _via_set_layout_options_kb:
      00A6C7 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_626'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00A6C8                        831 _via_set_layout_options:
      00A6C8 12 91 D3         [24]  832 	lcall	_ak820_outline_0115
      00A6CB 90 0C 21         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_626
      00A6CE 12 91 C1         [24]  834 	lcall	_ak820_outline_0042
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00A6D1 90 0C 21         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_626
      00A6D4 E0               [24]  837 	movx	a,@dptr
      00A6D5 90 06 9F         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A6D8 F0               [24]  839 	movx	@dptr,a
      00A6D9 90 00 28         [24]  840 	mov	dptr,#0x0028
      00A6DC 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00A6DF 02 4E D5         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_628'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_633'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00A6E2                        855 _process_record_via:
      00A6E2 12 38 43         [24]  856 	lcall	_ak820_outline_0103
      00A6E5 90 0C 28         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_628
      00A6E8 12 38 48         [24]  858 	lcall	_ak820_outline_0104
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00A6EB 90 0C 25         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00A6EE 12 4F E2         [24]  861 	lcall	_ak820_outline_0022
      00A6F1 74 05            [12]  862 	mov	a,#0x05
      00A6F3 12 38 7A         [24]  863 	lcall	_ak820_outline_0156
      00A6F6 12 4F EB         [24]  864 	lcall	_ak820_outline_0044
      00A6F9 12 B9 79         [24]  865 	lcall	__gptrget
      00A6FC 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00A6FE 90 0C 28         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_628
      00A701 12 37 CB         [24]  869 	lcall	_ak820_outline_0011
      00A704 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00A706 2D               [12]  871 	add	a,r5
      00A707 50 12            [24]  872 	jnc	00105$
      00A709 C3               [12]  873 	clr	c
      00A70A 74 7F            [12]  874 	mov	a,#0x7f
      00A70C 9C               [12]  875 	subb	a,r4
      00A70D 74 77            [12]  876 	mov	a,#0x77
      00A70F 9D               [12]  877 	subb	a,r5
      00A710 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00A712 8E 82            [24]  882 	mov	dpl, r6
      00A714 12 8C F3         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00A717 75 82 00         [24]  885 	mov	dpl, #0x00
      00A71A 22               [24]  886 	ret
      00A71B                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00A71B 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00A71E 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_634'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_635'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00A71F                        903 _raw_hid_receive_kb:
      00A71F 12 43 49         [24]  904 	lcall	_ak820_outline_0037
      00A722 90 0C 2B         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_634
      00A725 12 37 DF         [24]  906 	lcall	_ak820_outline_0016
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00A728 90 0C 2B         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_634
      00A72B 12 4F D3         [24]  909 	lcall	_ak820_outline_0003
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00A72E 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00A730 02 B9 3E         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_636'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_637'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_637'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_637'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_643'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_651'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_652'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_655'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_656'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_657'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_662'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_664'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_673'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_674'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_674'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_679'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_679'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_684'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_684'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_686'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_686'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_691'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00A733                        950 _raw_hid_receive:
      00A733 12 43 49         [24]  951 	lcall	_ak820_outline_0037
      00A736 90 0C 2F         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_636
      00A739 12 37 DF         [24]  953 	lcall	_ak820_outline_0016
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00A73C 90 0C 2F         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_636
      00A73F 12 38 00         [24]  956 	lcall	_ak820_outline_0051
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00A742 74 01            [12]  958 	mov	a,#0x01
      00A744 12 43 BD         [24]  959 	lcall	_ak820_outline_0157
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00A747 90 0C 2E         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00A74A E0               [24]  962 	movx	a,@dptr
      00A74B FB               [12]  963 	mov	r3,a
      00A74C BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00A74F 80 01            [24]  965 	sjmp	00102$
      00A751                        966 00520$:
      00A751 22               [24]  967 	ret
      00A752                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00A752 90 0D FD         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00A755 E0               [24]  971 	movx	a,@dptr
      00A756 60 31            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00A758 12 38 37         [24]  974 	lcall	_ak820_outline_0098
      00A75B FA               [12]  975 	mov	r2,a
      00A75C BA FE 02         [24]  976 	cjne	r2,#0xfe,00522$
      00A75F 80 01            [24]  977 	sjmp	00104$
      00A761                        978 00522$:
                                    979 ;	quantum/via.c:252: return;
      00A761 22               [24]  980 	ret
      00A762                        981 00104$:
                                    982 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00A762 12 43 80         [24]  983 	lcall	_ak820_outline_0093
                                    984 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00A765 FA               [12]  985 	mov	r2,a
      00A766 60 21            [24]  986 	jz	00114$
      00A768 BA 01 02         [24]  987 	cjne	r2,#0x01,00524$
      00A76B 80 1C            [24]  988 	sjmp	00114$
      00A76D                        989 00524$:
      00A76D BA 02 02         [24]  990 	cjne	r2,#0x02,00525$
      00A770 80 17            [24]  991 	sjmp	00114$
      00A772                        992 00525$:
      00A772 BA 05 02         [24]  993 	cjne	r2,#0x05,00526$
      00A775 80 12            [24]  994 	sjmp	00114$
      00A777                        995 00526$:
      00A777 BA 06 02         [24]  996 	cjne	r2,#0x06,00527$
      00A77A 80 0D            [24]  997 	sjmp	00114$
      00A77C                        998 00527$:
      00A77C BA 07 02         [24]  999 	cjne	r2,#0x07,00528$
      00A77F 80 08            [24] 1000 	sjmp	00114$
      00A781                       1001 00528$:
      00A781 BA 08 02         [24] 1002 	cjne	r2,#0x08,00529$
      00A784 80 03            [24] 1003 	sjmp	00530$
      00A786                       1004 00529$:
      00A786 02 AC C1         [24] 1005 	ljmp	00171$
      00A789                       1006 00530$:
                                   1007 ;	quantum/via.c:259: goto skip;
      00A789                       1008 00114$:
                                   1009 ;	quantum/via.c:263: switch (*command_id) {
      00A789 12 38 37         [24] 1010 	lcall	_ak820_outline_0098
      00A78C FA               [12] 1011 	mov	r2,a
      00A78D BA 01 02         [24] 1012 	cjne	r2,#0x01,00531$
      00A790 80 6E            [24] 1013 	sjmp	00115$
      00A792                       1014 00531$:
      00A792 BA 02 02         [24] 1015 	cjne	r2,#0x02,00532$
      00A795 80 76            [24] 1016 	sjmp	00116$
      00A797                       1017 00532$:
      00A797 BA 03 03         [24] 1018 	cjne	r2,#0x03,00533$
      00A79A 02 A8 CF         [24] 1019 	ljmp	00125$
      00A79D                       1020 00533$:
      00A79D BA 04 03         [24] 1021 	cjne	r2,#0x04,00534$
      00A7A0 02 A9 66         [24] 1022 	ljmp	00129$
      00A7A3                       1023 00534$:
      00A7A3 BA 05 03         [24] 1024 	cjne	r2,#0x05,00535$
      00A7A6 02 A9 A0         [24] 1025 	ljmp	00130$
      00A7A9                       1026 00535$:
      00A7A9 BA 06 03         [24] 1027 	cjne	r2,#0x06,00536$
      00A7AC 02 AA 0D         [24] 1028 	ljmp	00135$
      00A7AF                       1029 00536$:
      00A7AF BA 07 03         [24] 1030 	cjne	r2,#0x07,00537$
      00A7B2 02 AA 1F         [24] 1031 	ljmp	00136$
      00A7B5                       1032 00537$:
      00A7B5 BA 08 03         [24] 1033 	cjne	r2,#0x08,00538$
      00A7B8 02 AA 3A         [24] 1034 	ljmp	00137$
      00A7BB                       1035 00538$:
      00A7BB BA 09 03         [24] 1036 	cjne	r2,#0x09,00539$
      00A7BE 02 AA 55         [24] 1037 	ljmp	00138$
      00A7C1                       1038 00539$:
      00A7C1 BA 0B 03         [24] 1039 	cjne	r2,#0x0b,00540$
      00A7C4 02 AC 4F         [24] 1040 	ljmp	00161$
      00A7C7                       1041 00540$:
      00A7C7 BA 0C 03         [24] 1042 	cjne	r2,#0x0c,00541$
      00A7CA 02 AA 70         [24] 1043 	ljmp	00139$
      00A7CD                       1044 00541$:
      00A7CD BA 0D 03         [24] 1045 	cjne	r2,#0x0d,00542$
      00A7D0 02 AA 91         [24] 1046 	ljmp	00140$
      00A7D3                       1047 00542$:
      00A7D3 BA 0E 03         [24] 1048 	cjne	r2,#0x0e,00543$
      00A7D6 02 AA BA         [24] 1049 	ljmp	00141$
      00A7D9                       1050 00543$:
      00A7D9 BA 0F 03         [24] 1051 	cjne	r2,#0x0f,00544$
      00A7DC 02 AB 02         [24] 1052 	ljmp	00144$
      00A7DF                       1053 00544$:
      00A7DF BA 10 03         [24] 1054 	cjne	r2,#0x10,00545$
      00A7E2 02 AB 71         [24] 1055 	ljmp	00151$
      00A7E5                       1056 00545$:
      00A7E5 BA 11 03         [24] 1057 	cjne	r2,#0x11,00546$
      00A7E8 02 AB 8A         [24] 1058 	ljmp	00154$
      00A7EB                       1059 00546$:
      00A7EB BA 12 03         [24] 1060 	cjne	r2,#0x12,00547$
      00A7EE 02 AB AB         [24] 1061 	ljmp	00155$
      00A7F1                       1062 00547$:
      00A7F1 BA 13 03         [24] 1063 	cjne	r2,#0x13,00548$
      00A7F4 02 AB F3         [24] 1064 	ljmp	00158$
      00A7F7                       1065 00548$:
      00A7F7 BA FE 03         [24] 1066 	cjne	r2,#0xfe,00549$
      00A7FA 02 AC 8F         [24] 1067 	ljmp	00168$
      00A7FD                       1068 00549$:
      00A7FD 02 AC A9         [24] 1069 	ljmp	00169$
                                   1070 ;	quantum/via.c:264: case id_get_protocol_version: {
      00A800                       1071 00115$:
                                   1072 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00A800 12 38 60         [24] 1073 	lcall	_ak820_outline_0122
      00A803 E4               [12] 1074 	clr	a
      00A804 12 43 41         [24] 1075 	lcall	_ak820_outline_0030
                                   1076 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00A807 74 09            [12] 1077 	mov	a,#0x09
      00A809 F0               [24] 1078 	movx	@dptr,a
                                   1079 ;	quantum/via.c:267: break;
      00A80A 02 AC C1         [24] 1080 	ljmp	00171$
                                   1081 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00A80D                       1082 00116$:
                                   1083 ;	quantum/via.c:270: switch (command_data[0]) {
      00A80D 12 43 80         [24] 1084 	lcall	_ak820_outline_0093
      00A810 FA               [12] 1085 	mov	r2,a
      00A811 BA 01 02         [24] 1086 	cjne	r2,#0x01,00550$
      00A814 80 0E            [24] 1087 	sjmp	00117$
      00A816                       1088 00550$:
      00A816 BA 02 02         [24] 1089 	cjne	r2,#0x02,00551$
      00A819 80 34            [24] 1090 	sjmp	00118$
      00A81B                       1091 00551$:
      00A81B BA 03 03         [24] 1092 	cjne	r2,#0x03,00552$
      00A81E 02 A8 8A         [24] 1093 	ljmp	00119$
      00A821                       1094 00552$:
      00A821 02 A8 B4         [24] 1095 	ljmp	00123$
                                   1096 ;	quantum/via.c:271: case id_uptime: {
      00A824                       1097 00117$:
                                   1098 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00A824 12 49 FD         [24] 1099 	lcall	_timer_read32
      00A827 85 82 38         [24] 1100 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00A82A 85 83 39         [24] 1101 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00A82D 85 F0 3A         [24] 1102 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00A830 F5 3B            [12] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1104 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00A832 12 43 92         [24] 1105 	lcall	_ak820_outline_0116
      00A835 A3               [24] 1106 	inc	dptr
      00A836 A3               [24] 1107 	inc	dptr
      00A837 E5 3B            [12] 1108 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A839 12 43 41         [24] 1109 	lcall	_ak820_outline_0030
                                   1110 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00A83C A3               [24] 1111 	inc	dptr
      00A83D E5 3A            [12] 1112 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A83F F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00A840 12 AC EF         [24] 1115 	lcall	_ak820_outline_0021
      00A843 E5 39            [12] 1116 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A845 F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00A846 12 43 37         [24] 1119 	lcall	_ak820_outline_0010
      00A849 E5 38            [12] 1120 	mov	a,_raw_hid_receive_sloc0_1_0
      00A84B F0               [24] 1121 	movx	@dptr,a
                                   1122 ;	quantum/via.c:277: break;
      00A84C 02 AC C1         [24] 1123 	ljmp	00171$
                                   1124 ;	quantum/via.c:279: case id_layout_options: {
      00A84F                       1125 00118$:
                                   1126 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00A84F C0 03            [24] 1127 	push	ar3
      00A851 C0 07            [24] 1128 	push	ar7
      00A853 C0 06            [24] 1129 	push	ar6
      00A855 C0 03            [24] 1130 	push	ar3
      00A857 12 A6 AF         [24] 1131 	lcall	_via_get_layout_options
      00A85A 85 82 38         [24] 1132 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00A85D 85 83 39         [24] 1133 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00A860 85 F0 3A         [24] 1134 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00A863 F5 3B            [12] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A865 D0 03            [24] 1136 	pop	ar3
      00A867 D0 06            [24] 1137 	pop	ar6
      00A869 D0 07            [24] 1138 	pop	ar7
                                   1139 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00A86B 12 43 92         [24] 1140 	lcall	_ak820_outline_0116
      00A86E A3               [24] 1141 	inc	dptr
      00A86F A3               [24] 1142 	inc	dptr
      00A870 E5 3B            [12] 1143 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A872 12 43 41         [24] 1144 	lcall	_ak820_outline_0030
                                   1145 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00A875 A3               [24] 1146 	inc	dptr
      00A876 E5 3A            [12] 1147 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A878 F0               [24] 1148 	movx	@dptr,a
                                   1149 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00A879 12 AC EF         [24] 1150 	lcall	_ak820_outline_0021
      00A87C E5 39            [12] 1151 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A87E F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00A87F 12 43 37         [24] 1154 	lcall	_ak820_outline_0010
      00A882 E5 38            [12] 1155 	mov	a,_raw_hid_receive_sloc0_1_0
      00A884 F0               [24] 1156 	movx	@dptr,a
                                   1157 ;	quantum/via.c:285: break;
      00A885 D0 03            [24] 1158 	pop	ar3
      00A887 02 AC C1         [24] 1159 	ljmp	00171$
                                   1160 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00A88A                       1161 00119$:
                                   1162 ;	quantum/via.c:290: if (!vial_unlocked)
      00A88A 90 0D FC         [24] 1163 	mov	dptr,#_vial_unlocked
      00A88D E0               [24] 1164 	movx	a,@dptr
      00A88E 70 03            [24] 1165 	jnz	00553$
      00A890 02 AC C1         [24] 1166 	ljmp	00171$
      00A893                       1167 00553$:
                                   1168 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00A893 7A 01            [12] 1169 	mov	r2,#0x01
      00A895 79 00            [12] 1170 	mov	r1,#0x00
      00A897                       1171 00173$:
      00A897 B9 10 00         [24] 1172 	cjne	r1,#0x10,00554$
      00A89A                       1173 00554$:
      00A89A 40 03            [24] 1174 	jc	00555$
      00A89C 02 AC C1         [24] 1175 	ljmp	00171$
      00A89F                       1176 00555$:
                                   1177 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00A89F 89 82            [24] 1178 	mov	dpl, r1
      00A8A1 12 5A 76         [24] 1179 	lcall	_matrix_get_row
      00A8A4 A8 82            [24] 1180 	mov	r0, dpl
                                   1181 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00A8A6 EA               [12] 1182 	mov	a,r2
      00A8A7 2C               [12] 1183 	add	a, r4
      00A8A8 F5 82            [12] 1184 	mov	dpl,a
      00A8AA E4               [12] 1185 	clr	a
      00A8AB 3D               [12] 1186 	addc	a, r5
      00A8AC F5 83            [12] 1187 	mov	dph,a
      00A8AE 0A               [12] 1188 	inc	r2
      00A8AF E8               [12] 1189 	mov	a,r0
      00A8B0 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00A8B1 09               [12] 1192 	inc	r1
                                   1193 ;	quantum/via.c:312: default: {
      00A8B2 80 E3            [24] 1194 	sjmp	00173$
      00A8B4                       1195 00123$:
                                   1196 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00A8B4 12 AD 1D         [24] 1197 	lcall	_ak820_outline_0092
      00A8B7 90 0C 2A         [24] 1198 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00A8BA 12 AC F8         [24] 1199 	lcall	_ak820_outline_0038
      00A8BD C0 07            [24] 1200 	push	ar7
      00A8BF C0 06            [24] 1201 	push	ar6
      00A8C1 C0 03            [24] 1202 	push	ar3
      00A8C3 12 A7 1F         [24] 1203 	lcall	_raw_hid_receive_kb
      00A8C6 D0 03            [24] 1204 	pop	ar3
      00A8C8 D0 06            [24] 1205 	pop	ar6
      00A8CA D0 07            [24] 1206 	pop	ar7
                                   1207 ;	quantum/via.c:317: break;
      00A8CC 02 AC C1         [24] 1208 	ljmp	00171$
                                   1209 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00A8CF                       1210 00125$:
                                   1211 ;	quantum/via.c:320: switch (command_data[0]) {
      00A8CF 12 43 80         [24] 1212 	lcall	_ak820_outline_0093
      00A8D2 FA               [12] 1213 	mov	r2,a
      00A8D3 BA 02 02         [24] 1214 	cjne	r2,#0x02,00556$
      00A8D6 80 03            [24] 1215 	sjmp	00557$
      00A8D8                       1216 00556$:
      00A8D8 02 A9 4B         [24] 1217 	ljmp	00127$
      00A8DB                       1218 00557$:
                                   1219 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00A8DB C0 03            [24] 1220 	push	ar3
      00A8DD 12 37 F8         [24] 1221 	lcall	_ak820_outline_0034
      00A8E0 F8               [12] 1222 	mov	r0,a
      00A8E1 79 00            [12] 1223 	mov	r1,#0x00
      00A8E3 7B 00            [12] 1224 	mov	r3,#0x00
      00A8E5 88 3B            [24] 1225 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00A8E7 8B 38            [24] 1226 	mov	_raw_hid_receive_sloc0_1_0,r3
      00A8E9 8B 39            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00A8EB 8B 3A            [24] 1228 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00A8ED 12 AC E6         [24] 1229 	lcall	_ak820_outline_0015
      00A8F0 F8               [12] 1230 	mov	r0,a
      00A8F1 89 03            [24] 1231 	mov	ar3,r1
      00A8F3 88 02            [24] 1232 	mov	ar2,r0
      00A8F5 E4               [12] 1233 	clr	a
      00A8F6 42 38            [12] 1234 	orl	_raw_hid_receive_sloc0_1_0,a
      00A8F8 E9               [12] 1235 	mov	a,r1
      00A8F9 42 39            [12] 1236 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00A8FB EA               [12] 1237 	mov	a,r2
      00A8FC 42 3A            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00A8FE EB               [12] 1239 	mov	a,r3
      00A8FF 42 3B            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A901 12 AC EF         [24] 1241 	lcall	_ak820_outline_0021
      00A904 E0               [24] 1242 	movx	a,@dptr
      00A905 F8               [12] 1243 	mov	r0,a
      00A906 79 00            [12] 1244 	mov	r1,#0x00
      00A908 7A 00            [12] 1245 	mov	r2,#0x00
      00A90A 8A 03            [24] 1246 	mov	ar3,r2
      00A90C 89 02            [24] 1247 	mov	ar2,r1
      00A90E 88 01            [24] 1248 	mov	ar1,r0
      00A910 E4               [12] 1249 	clr	a
      00A911 42 38            [12] 1250 	orl	_raw_hid_receive_sloc0_1_0,a
      00A913 E9               [12] 1251 	mov	a,r1
      00A914 42 39            [12] 1252 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00A916 EA               [12] 1253 	mov	a,r2
      00A917 42 3A            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00A919 EB               [12] 1255 	mov	a,r3
      00A91A 42 3B            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A91C 12 43 37         [24] 1257 	lcall	_ak820_outline_0010
      00A91F E0               [24] 1258 	movx	a,@dptr
      00A920 F8               [12] 1259 	mov	r0,a
      00A921 E4               [12] 1260 	clr	a
      00A922 F9               [12] 1261 	mov	r1,a
      00A923 FA               [12] 1262 	mov	r2,a
      00A924 FB               [12] 1263 	mov	r3,a
      00A925 E5 39            [12] 1264 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A927 42 01            [12] 1265 	orl	ar1,a
      00A929 E5 3A            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A92B 42 02            [12] 1267 	orl	ar2,a
      00A92D E5 3B            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A92F 42 03            [12] 1269 	orl	ar3,a
                                   1270 ;	quantum/via.c:323: via_set_layout_options(value);
      00A931 12 38 75         [24] 1271 	lcall	_ak820_outline_0153
      00A934 8A F0            [24] 1272 	mov	b, r2
      00A936 EB               [12] 1273 	mov	a, r3
      00A937 C0 07            [24] 1274 	push	ar7
      00A939 C0 06            [24] 1275 	push	ar6
      00A93B C0 03            [24] 1276 	push	ar3
      00A93D 12 A6 C8         [24] 1277 	lcall	_via_set_layout_options
      00A940 D0 03            [24] 1278 	pop	ar3
      00A942 D0 06            [24] 1279 	pop	ar6
      00A944 D0 07            [24] 1280 	pop	ar7
                                   1281 ;	quantum/via.c:324: break;
      00A946 D0 03            [24] 1282 	pop	ar3
      00A948 02 AC C1         [24] 1283 	ljmp	00171$
                                   1284 ;	quantum/via.c:326: default: {
      00A94B                       1285 00127$:
                                   1286 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00A94B 12 AD 1D         [24] 1287 	lcall	_ak820_outline_0092
      00A94E 90 0C 2A         [24] 1288 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00A951 12 AC F8         [24] 1289 	lcall	_ak820_outline_0038
      00A954 C0 07            [24] 1290 	push	ar7
      00A956 C0 06            [24] 1291 	push	ar6
      00A958 C0 03            [24] 1292 	push	ar3
      00A95A 12 A7 1F         [24] 1293 	lcall	_raw_hid_receive_kb
      00A95D D0 03            [24] 1294 	pop	ar3
      00A95F D0 06            [24] 1295 	pop	ar6
      00A961 D0 07            [24] 1296 	pop	ar7
                                   1297 ;	quantum/via.c:331: break;
      00A963 02 AC C1         [24] 1298 	ljmp	00171$
                                   1299 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00A966                       1300 00129$:
                                   1301 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00A966 12 43 80         [24] 1302 	lcall	_ak820_outline_0093
      00A969 FA               [12] 1303 	mov	r2,a
      00A96A 12 37 F8         [24] 1304 	lcall	_ak820_outline_0034
      00A96D F9               [12] 1305 	mov	r1,a
      00A96E 12 AC E6         [24] 1306 	lcall	_ak820_outline_0015
      00A971 F8               [12] 1307 	mov	r0,a
      00A972 90 0A DD         [24] 1308 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00A975 E9               [12] 1309 	mov	a,r1
      00A976 F0               [24] 1310 	movx	@dptr,a
      00A977 90 0A DE         [24] 1311 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00A97A E8               [12] 1312 	mov	a,r0
      00A97B F0               [24] 1313 	movx	@dptr,a
      00A97C 8A 82            [24] 1314 	mov	dpl, r2
      00A97E C0 07            [24] 1315 	push	ar7
      00A980 C0 06            [24] 1316 	push	ar6
      00A982 C0 03            [24] 1317 	push	ar3
      00A984 12 85 76         [24] 1318 	lcall	_dynamic_keymap_get_keycode
      00A987 A9 82            [24] 1319 	mov	r1, dpl
      00A989 AA 83            [24] 1320 	mov	r2, dph
      00A98B D0 03            [24] 1321 	pop	ar3
      00A98D D0 06            [24] 1322 	pop	ar6
      00A98F D0 07            [24] 1323 	pop	ar7
                                   1324 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00A991 12 AC EF         [24] 1325 	lcall	_ak820_outline_0021
      00A994 8A 00            [24] 1326 	mov	ar0,r2
      00A996 E8               [12] 1327 	mov	a,r0
      00A997 F0               [24] 1328 	movx	@dptr,a
                                   1329 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00A998 12 43 37         [24] 1330 	lcall	_ak820_outline_0010
      00A99B E9               [12] 1331 	mov	a,r1
      00A99C F0               [24] 1332 	movx	@dptr,a
                                   1333 ;	quantum/via.c:337: break;
      00A99D 02 AC C1         [24] 1334 	ljmp	00171$
                                   1335 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00A9A0                       1336 00130$:
                                   1337 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00A9A0 90 0D FC         [24] 1338 	mov	dptr,#_vial_unlocked
      00A9A3 E0               [24] 1339 	movx	a,@dptr
      00A9A4 70 19            [24] 1340 	jnz	00132$
      00A9A6 12 AC EF         [24] 1341 	lcall	_ak820_outline_0021
      00A9A9 E0               [24] 1342 	movx	a,@dptr
      00A9AA FA               [12] 1343 	mov	r2,a
      00A9AB BA 7C 11         [24] 1344 	cjne	r2,#0x7c,00132$
      00A9AE 74 05            [12] 1345 	mov	a,#0x05
      00A9B0 2E               [12] 1346 	add	a, r6
      00A9B1 12 37 D5         [24] 1347 	lcall	_ak820_outline_0014
      00A9B4 70 09            [24] 1348 	jnz	00132$
                                   1349 ;	quantum/via.c:344: *command_id = id_unhandled;
      00A9B6 12 43 92         [24] 1350 	lcall	_ak820_outline_0116
      00A9B9 74 FF            [12] 1351 	mov	a,#0xff
      00A9BB F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/via.c:345: break;
      00A9BC 02 AC C1         [24] 1354 	ljmp	00171$
      00A9BF                       1355 00132$:
                                   1356 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00A9BF C0 03            [24] 1357 	push	ar3
      00A9C1 12 43 80         [24] 1358 	lcall	_ak820_outline_0093
      00A9C4 F5 3D            [12] 1359 	mov	_raw_hid_receive_sloc2_1_0,a
      00A9C6 12 37 F8         [24] 1360 	lcall	_ak820_outline_0034
      00A9C9 F5 3C            [12] 1361 	mov	_raw_hid_receive_sloc1_1_0,a
      00A9CB 12 AC E6         [24] 1362 	lcall	_ak820_outline_0015
      00A9CE F5 38            [12] 1363 	mov	_raw_hid_receive_sloc0_1_0,a
      00A9D0 12 AC EF         [24] 1364 	lcall	_ak820_outline_0021
      00A9D3 E0               [24] 1365 	movx	a,@dptr
      00A9D4 FB               [12] 1366 	mov	r3,a
      00A9D5 78 00            [12] 1367 	mov	r0,#0x00
      00A9D7 12 43 37         [24] 1368 	lcall	_ak820_outline_0010
      00A9DA E0               [24] 1369 	movx	a,@dptr
      00A9DB 7A 00            [12] 1370 	mov	r2,#0x00
      00A9DD 42 00            [12] 1371 	orl	ar0,a
      00A9DF EA               [12] 1372 	mov	a,r2
      00A9E0 42 03            [12] 1373 	orl	ar3,a
      00A9E2 90 0A E0         [24] 1374 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00A9E5 E5 3C            [12] 1375 	mov	a,_raw_hid_receive_sloc1_1_0
      00A9E7 F0               [24] 1376 	movx	@dptr,a
      00A9E8 90 0A E1         [24] 1377 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00A9EB E5 38            [12] 1378 	mov	a,_raw_hid_receive_sloc0_1_0
      00A9ED F0               [24] 1379 	movx	@dptr,a
      00A9EE 90 0A E2         [24] 1380 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00A9F1 E8               [12] 1381 	mov	a,r0
      00A9F2 F0               [24] 1382 	movx	@dptr,a
      00A9F3 EB               [12] 1383 	mov	a,r3
      00A9F4 A3               [24] 1384 	inc	dptr
      00A9F5 F0               [24] 1385 	movx	@dptr,a
      00A9F6 85 3D 82         [24] 1386 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00A9F9 C0 07            [24] 1387 	push	ar7
      00A9FB C0 06            [24] 1388 	push	ar6
      00A9FD C0 03            [24] 1389 	push	ar3
      00A9FF 12 85 C4         [24] 1390 	lcall	_dynamic_keymap_set_keycode
      00AA02 D0 03            [24] 1391 	pop	ar3
      00AA04 D0 06            [24] 1392 	pop	ar6
      00AA06 D0 07            [24] 1393 	pop	ar7
                                   1394 ;	quantum/via.c:349: break;
      00AA08 D0 03            [24] 1395 	pop	ar3
      00AA0A 02 AC C1         [24] 1396 	ljmp	00171$
                                   1397 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00AA0D                       1398 00135$:
                                   1399 ;	quantum/via.c:352: dynamic_keymap_reset();
      00AA0D C0 07            [24] 1400 	push	ar7
      00AA0F C0 06            [24] 1401 	push	ar6
      00AA11 C0 03            [24] 1402 	push	ar3
      00AA13 12 88 59         [24] 1403 	lcall	_dynamic_keymap_reset
      00AA16 D0 03            [24] 1404 	pop	ar3
      00AA18 D0 06            [24] 1405 	pop	ar6
      00AA1A D0 07            [24] 1406 	pop	ar7
                                   1407 ;	quantum/via.c:353: break;
      00AA1C 02 AC C1         [24] 1408 	ljmp	00171$
                                   1409 ;	quantum/via.c:355: case id_lighting_set_value: {
      00AA1F                       1410 00136$:
                                   1411 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00AA1F 12 AD 1D         [24] 1412 	lcall	_ak820_outline_0092
      00AA22 90 0D 75         [24] 1413 	mov	dptr,#_vialrgb_set_value_PARM_2
      00AA25 12 AC F8         [24] 1414 	lcall	_ak820_outline_0038
      00AA28 C0 07            [24] 1415 	push	ar7
      00AA2A C0 06            [24] 1416 	push	ar6
      00AA2C C0 03            [24] 1417 	push	ar3
      00AA2E 12 B7 14         [24] 1418 	lcall	_vialrgb_set_value
      00AA31 D0 03            [24] 1419 	pop	ar3
      00AA33 D0 06            [24] 1420 	pop	ar6
      00AA35 D0 07            [24] 1421 	pop	ar7
                                   1422 ;	quantum/via.c:375: break;
      00AA37 02 AC C1         [24] 1423 	ljmp	00171$
                                   1424 ;	quantum/via.c:377: case id_lighting_get_value: {
      00AA3A                       1425 00137$:
                                   1426 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00AA3A 12 AD 1D         [24] 1427 	lcall	_ak820_outline_0092
      00AA3D 90 0D 71         [24] 1428 	mov	dptr,#_vialrgb_get_value_PARM_2
      00AA40 12 AC F8         [24] 1429 	lcall	_ak820_outline_0038
      00AA43 C0 07            [24] 1430 	push	ar7
      00AA45 C0 06            [24] 1431 	push	ar6
      00AA47 C0 03            [24] 1432 	push	ar3
      00AA49 12 B5 A9         [24] 1433 	lcall	_vialrgb_get_value
      00AA4C D0 03            [24] 1434 	pop	ar3
      00AA4E D0 06            [24] 1435 	pop	ar6
      00AA50 D0 07            [24] 1436 	pop	ar7
                                   1437 ;	quantum/via.c:397: break;
      00AA52 02 AC C1         [24] 1438 	ljmp	00171$
                                   1439 ;	quantum/via.c:399: case id_lighting_save: {
      00AA55                       1440 00138$:
                                   1441 ;	quantum/via.c:407: vialrgb_save(data, length);
      00AA55 12 AD 1D         [24] 1442 	lcall	_ak820_outline_0092
      00AA58 90 0D 79         [24] 1443 	mov	dptr,#_vialrgb_save_PARM_2
      00AA5B 12 AC F8         [24] 1444 	lcall	_ak820_outline_0038
      00AA5E C0 07            [24] 1445 	push	ar7
      00AA60 C0 06            [24] 1446 	push	ar6
      00AA62 C0 03            [24] 1447 	push	ar3
      00AA64 12 B7 A2         [24] 1448 	lcall	_vialrgb_save
      00AA67 D0 03            [24] 1449 	pop	ar3
      00AA69 D0 06            [24] 1450 	pop	ar6
      00AA6B D0 07            [24] 1451 	pop	ar7
                                   1452 ;	quantum/via.c:419: break;
      00AA6D 02 AC C1         [24] 1453 	ljmp	00171$
                                   1454 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00AA70                       1455 00139$:
                                   1456 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00AA70 C0 07            [24] 1457 	push	ar7
      00AA72 C0 06            [24] 1458 	push	ar6
      00AA74 C0 05            [24] 1459 	push	ar5
      00AA76 C0 04            [24] 1460 	push	ar4
      00AA78 C0 03            [24] 1461 	push	ar3
      00AA7A 12 8C 48         [24] 1462 	lcall	_dynamic_keymap_macro_get_count
      00AA7D AA 82            [24] 1463 	mov	r2, dpl
      00AA7F D0 03            [24] 1464 	pop	ar3
      00AA81 D0 04            [24] 1465 	pop	ar4
      00AA83 D0 05            [24] 1466 	pop	ar5
      00AA85 D0 06            [24] 1467 	pop	ar6
      00AA87 D0 07            [24] 1468 	pop	ar7
      00AA89 12 38 60         [24] 1469 	lcall	_ak820_outline_0122
      00AA8C EA               [12] 1470 	mov	a,r2
      00AA8D F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	quantum/via.c:430: break;
      00AA8E 02 AC C1         [24] 1473 	ljmp	00171$
                                   1474 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00AA91                       1475 00140$:
                                   1476 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00AA91 C0 07            [24] 1477 	push	ar7
      00AA93 C0 06            [24] 1478 	push	ar6
      00AA95 C0 05            [24] 1479 	push	ar5
      00AA97 C0 04            [24] 1480 	push	ar4
      00AA99 C0 03            [24] 1481 	push	ar3
      00AA9B 12 8C 4C         [24] 1482 	lcall	_dynamic_keymap_macro_get_buffer_size
      00AA9E A9 82            [24] 1483 	mov	r1, dpl
      00AAA0 AA 83            [24] 1484 	mov	r2, dph
      00AAA2 D0 03            [24] 1485 	pop	ar3
      00AAA4 D0 04            [24] 1486 	pop	ar4
      00AAA6 D0 05            [24] 1487 	pop	ar5
      00AAA8 D0 06            [24] 1488 	pop	ar6
      00AAAA D0 07            [24] 1489 	pop	ar7
                                   1490 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00AAAC 8A 00            [24] 1491 	mov	ar0,r2
      00AAAE 12 38 60         [24] 1492 	lcall	_ak820_outline_0122
      00AAB1 E8               [12] 1493 	mov	a,r0
      00AAB2 12 43 41         [24] 1494 	lcall	_ak820_outline_0030
                                   1495 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00AAB5 E9               [12] 1496 	mov	a,r1
      00AAB6 F0               [24] 1497 	movx	@dptr,a
                                   1498 ;	quantum/via.c:436: break;
      00AAB7 02 AC C1         [24] 1499 	ljmp	00171$
                                   1500 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00AABA                       1501 00141$:
                                   1502 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AABA C0 03            [24] 1503 	push	ar3
      00AABC 12 AC CF         [24] 1504 	lcall	_ak820_outline_0001
      00AABF 89 38            [24] 1505 	mov	_raw_hid_receive_sloc0_1_0,r1
      00AAC1 8A 39            [24] 1506 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1507 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00AAC3 12 AC E6         [24] 1508 	lcall	_ak820_outline_0015
      00AAC6 FB               [12] 1509 	mov	r3,a
                                   1510 ;	quantum/via.c:441: if (size <= 28)
      00AAC7 8B 3E            [24] 1511 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AAC9 75 3F 00         [24] 1512 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AACC C3               [12] 1513 	clr	c
      00AACD 74 1C            [12] 1514 	mov	a,#0x1c
      00AACF 9B               [12] 1515 	subb	a,r3
      00AAD0 D0 03            [24] 1516 	pop	ar3
      00AAD2 50 03            [24] 1517 	jnc	00562$
      00AAD4 02 AC C1         [24] 1518 	ljmp	00171$
      00AAD7                       1519 00562$:
                                   1520 ;	free result
                                   1521 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00AAD7 12 AD 01         [24] 1522 	lcall	_ak820_outline_0069
      00AADA 90 0B 2F         [24] 1523 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00AADD E5 3E            [12] 1524 	mov	a,_raw_hid_receive_sloc3_1_0
      00AADF F0               [24] 1525 	movx	@dptr,a
      00AAE0 E5 3F            [12] 1526 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AAE2 A3               [24] 1527 	inc	dptr
      00AAE3 F0               [24] 1528 	movx	@dptr,a
      00AAE4 90 0B 31         [24] 1529 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00AAE7 12 AD 0B         [24] 1530 	lcall	_ak820_outline_0084
      00AAEA 85 38 82         [24] 1531 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00AAED 85 39 83         [24] 1532 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00AAF0 C0 07            [24] 1533 	push	ar7
      00AAF2 C0 06            [24] 1534 	push	ar6
      00AAF4 C0 03            [24] 1535 	push	ar3
      00AAF6 12 8C 50         [24] 1536 	lcall	_dynamic_keymap_macro_get_buffer
      00AAF9 D0 03            [24] 1537 	pop	ar3
      00AAFB D0 06            [24] 1538 	pop	ar6
      00AAFD D0 07            [24] 1539 	pop	ar7
                                   1540 ;	quantum/via.c:443: break;
      00AAFF 02 AC C1         [24] 1541 	ljmp	00171$
                                   1542 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00AB02                       1543 00144$:
                                   1544 ;	quantum/via.c:448: if (!vial_unlocked) {
      00AB02 90 0D FC         [24] 1545 	mov	dptr,#_vial_unlocked
      00AB05 E0               [24] 1546 	movx	a,@dptr
      00AB06 70 01            [24] 1547 	jnz	00146$
                                   1548 ;	quantum/via.c:450: return;
      00AB08 22               [24] 1549 	ret
      00AB09                       1550 00146$:
                                   1551 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AB09 C0 03            [24] 1552 	push	ar3
      00AB0B 12 AC CF         [24] 1553 	lcall	_ak820_outline_0001
      00AB0E 89 3E            [24] 1554 	mov	_raw_hid_receive_sloc3_1_0,r1
      00AB10 8A 3F            [24] 1555 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1556 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00AB12 12 AC E6         [24] 1557 	lcall	_ak820_outline_0015
      00AB15 F5 38            [12] 1558 	mov	_raw_hid_receive_sloc0_1_0, a
      00AB17 75 39 00         [24] 1559 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1560 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00AB1A 85 38 40         [24] 1561 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00AB1D 85 39 41         [24] 1562 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00AB20 C3               [12] 1563 	clr	c
      00AB21 74 1C            [12] 1564 	mov	a,#0x1c
      00AB23 95 40            [12] 1565 	subb	a,_raw_hid_receive_sloc4_1_0
      00AB25 E4               [12] 1566 	clr	a
      00AB26 95 41            [12] 1567 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AB28 D0 03            [24] 1568 	pop	ar3
      00AB2A 40 44            [24] 1569 	jc	00147$
                                   1570 ;	free result
      00AB2C 8B 01            [24] 1571 	mov	ar1,r3
      00AB2E 7A 00            [12] 1572 	mov	r2,#0x00
      00AB30 E9               [12] 1573 	mov	a,r1
      00AB31 24 FC            [12] 1574 	add	a,#0xfc
      00AB33 F9               [12] 1575 	mov	r1,a
      00AB34 EA               [12] 1576 	mov	a,r2
      00AB35 34 FF            [12] 1577 	addc	a,#0xff
      00AB37 FA               [12] 1578 	mov	r2,a
      00AB38 C3               [12] 1579 	clr	c
      00AB39 E9               [12] 1580 	mov	a,r1
      00AB3A 95 40            [12] 1581 	subb	a,_raw_hid_receive_sloc4_1_0
      00AB3C EA               [12] 1582 	mov	a,r2
      00AB3D 95 41            [12] 1583 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AB3F 40 2F            [24] 1584 	jc	00147$
                                   1585 ;	free result
      00AB41 12 AD 01         [24] 1586 	lcall	_ak820_outline_0069
      00AB44 90 0B 36         [24] 1587 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00AB47 E5 38            [12] 1588 	mov	a,_raw_hid_receive_sloc0_1_0
      00AB49 F0               [24] 1589 	movx	@dptr,a
      00AB4A E5 39            [12] 1590 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AB4C A3               [24] 1591 	inc	dptr
      00AB4D F0               [24] 1592 	movx	@dptr,a
      00AB4E 90 0B 38         [24] 1593 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00AB51 12 AD 0B         [24] 1594 	lcall	_ak820_outline_0084
      00AB54 85 3E 82         [24] 1595 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00AB57 85 3F 83         [24] 1596 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00AB5A C0 07            [24] 1597 	push	ar7
      00AB5C C0 06            [24] 1598 	push	ar6
      00AB5E C0 03            [24] 1599 	push	ar3
      00AB60 12 8C 9F         [24] 1600 	lcall	_dynamic_keymap_macro_set_buffer
      00AB63 E5 82            [12] 1601 	mov	a, dpl
      00AB65 D0 03            [24] 1602 	pop	ar3
      00AB67 D0 06            [24] 1603 	pop	ar6
      00AB69 D0 07            [24] 1604 	pop	ar7
      00AB6B 60 03            [24] 1605 	jz	00566$
      00AB6D 02 AC C1         [24] 1606 	ljmp	00171$
      00AB70                       1607 00566$:
      00AB70                       1608 00147$:
      00AB70 22               [24] 1609 	ret
                                   1610 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00AB71                       1611 00151$:
                                   1612 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00AB71 90 0D FC         [24] 1613 	mov	dptr,#_vial_unlocked
      00AB74 E0               [24] 1614 	movx	a,@dptr
      00AB75 70 01            [24] 1615 	jnz	00153$
      00AB77 22               [24] 1616 	ret
      00AB78                       1617 00153$:
                                   1618 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00AB78 C0 07            [24] 1619 	push	ar7
      00AB7A C0 06            [24] 1620 	push	ar6
      00AB7C C0 03            [24] 1621 	push	ar3
      00AB7E 12 8C CD         [24] 1622 	lcall	_dynamic_keymap_macro_reset
      00AB81 D0 03            [24] 1623 	pop	ar3
      00AB83 D0 06            [24] 1624 	pop	ar6
      00AB85 D0 07            [24] 1625 	pop	ar7
                                   1626 ;	quantum/via.c:473: break;
      00AB87 02 AC C1         [24] 1627 	ljmp	00171$
                                   1628 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00AB8A                       1629 00154$:
                                   1630 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00AB8A C0 07            [24] 1631 	push	ar7
      00AB8C C0 06            [24] 1632 	push	ar6
      00AB8E C0 05            [24] 1633 	push	ar5
      00AB90 C0 04            [24] 1634 	push	ar4
      00AB92 C0 03            [24] 1635 	push	ar3
      00AB94 12 85 3B         [24] 1636 	lcall	_dynamic_keymap_get_layer_count
      00AB97 AA 82            [24] 1637 	mov	r2, dpl
      00AB99 D0 03            [24] 1638 	pop	ar3
      00AB9B D0 04            [24] 1639 	pop	ar4
      00AB9D D0 05            [24] 1640 	pop	ar5
      00AB9F D0 06            [24] 1641 	pop	ar6
      00ABA1 D0 07            [24] 1642 	pop	ar7
      00ABA3 12 38 60         [24] 1643 	lcall	_ak820_outline_0122
      00ABA6 EA               [12] 1644 	mov	a,r2
      00ABA7 F0               [24] 1645 	movx	@dptr,a
                                   1646 ;	quantum/via.c:477: break;
      00ABA8 02 AC C1         [24] 1647 	ljmp	00171$
                                   1648 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00ABAB                       1649 00155$:
                                   1650 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00ABAB C0 03            [24] 1651 	push	ar3
      00ABAD 12 AC CF         [24] 1652 	lcall	_ak820_outline_0001
      00ABB0 89 40            [24] 1653 	mov	_raw_hid_receive_sloc4_1_0,r1
      00ABB2 8A 41            [24] 1654 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1655 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00ABB4 12 AC E6         [24] 1656 	lcall	_ak820_outline_0015
      00ABB7 FB               [12] 1657 	mov	r3,a
                                   1658 ;	quantum/via.c:482: if (size <= 28)
      00ABB8 8B 3E            [24] 1659 	mov	_raw_hid_receive_sloc3_1_0,r3
      00ABBA 75 3F 00         [24] 1660 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00ABBD C3               [12] 1661 	clr	c
      00ABBE 74 1C            [12] 1662 	mov	a,#0x1c
      00ABC0 9B               [12] 1663 	subb	a,r3
      00ABC1 D0 03            [24] 1664 	pop	ar3
      00ABC3 50 03            [24] 1665 	jnc	00568$
      00ABC5 02 AC C1         [24] 1666 	ljmp	00171$
      00ABC8                       1667 00568$:
                                   1668 ;	free result
                                   1669 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00ABC8 12 AD 01         [24] 1670 	lcall	_ak820_outline_0069
      00ABCB 90 0B 18         [24] 1671 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00ABCE E5 3E            [12] 1672 	mov	a,_raw_hid_receive_sloc3_1_0
      00ABD0 F0               [24] 1673 	movx	@dptr,a
      00ABD1 E5 3F            [12] 1674 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00ABD3 A3               [24] 1675 	inc	dptr
      00ABD4 F0               [24] 1676 	movx	@dptr,a
      00ABD5 90 0B 1A         [24] 1677 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00ABD8 12 AD 0B         [24] 1678 	lcall	_ak820_outline_0084
      00ABDB 85 40 82         [24] 1679 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00ABDE 85 41 83         [24] 1680 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00ABE1 C0 07            [24] 1681 	push	ar7
      00ABE3 C0 06            [24] 1682 	push	ar6
      00ABE5 C0 03            [24] 1683 	push	ar3
      00ABE7 12 8A 16         [24] 1684 	lcall	_dynamic_keymap_get_buffer
      00ABEA D0 03            [24] 1685 	pop	ar3
      00ABEC D0 06            [24] 1686 	pop	ar6
      00ABEE D0 07            [24] 1687 	pop	ar7
                                   1688 ;	quantum/via.c:484: break;
      00ABF0 02 AC C1         [24] 1689 	ljmp	00171$
                                   1690 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00ABF3                       1691 00158$:
                                   1692 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00ABF3 12 43 80         [24] 1693 	lcall	_ak820_outline_0093
      00ABF6 FD               [12] 1694 	mov	r5,a
      00ABF7 7C 00            [12] 1695 	mov	r4,#0x00
      00ABF9 12 37 F8         [24] 1696 	lcall	_ak820_outline_0034
      00ABFC 7A 00            [12] 1697 	mov	r2,#0x00
      00ABFE 42 04            [12] 1698 	orl	ar4,a
      00AC00 EA               [12] 1699 	mov	a,r2
      00AC01 42 05            [12] 1700 	orl	ar5,a
      00AC03 8C 40            [24] 1701 	mov	_raw_hid_receive_sloc4_1_0,r4
      00AC05 8D 41            [24] 1702 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1703 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00AC07 12 AC E6         [24] 1704 	lcall	_ak820_outline_0015
      00AC0A F9               [12] 1705 	mov	r1,a
      00AC0B 7A 00            [12] 1706 	mov	r2,#0x00
                                   1707 ;	quantum/via.c:489: if (size <= 28)
      00AC0D 89 00            [24] 1708 	mov	ar0,r1
      00AC0F E8               [12] 1709 	mov	a,r0
      00AC10 24 E3            [12] 1710 	add	a,#0xff - 0x1c
      00AC12 50 03            [24] 1711 	jnc	00569$
      00AC14 02 AC C1         [24] 1712 	ljmp	00171$
      00AC17                       1713 00569$:
                                   1714 ;	free result
                                   1715 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00AC17 C0 03            [24] 1716 	push	ar3
      00AC19 74 04            [12] 1717 	mov	a,#0x04
      00AC1B 2E               [12] 1718 	add	a, r6
      00AC1C F8               [12] 1719 	mov	r0,a
      00AC1D E4               [12] 1720 	clr	a
      00AC1E 3F               [12] 1721 	addc	a, r7
      00AC1F FB               [12] 1722 	mov	r3,a
      00AC20 7D 00            [12] 1723 	mov	r5,#0x00
      00AC22 90 0B 1F         [24] 1724 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00AC25 E9               [12] 1725 	mov	a,r1
      00AC26 F0               [24] 1726 	movx	@dptr,a
      00AC27 EA               [12] 1727 	mov	a,r2
      00AC28 A3               [24] 1728 	inc	dptr
      00AC29 F0               [24] 1729 	movx	@dptr,a
      00AC2A 90 0B 21         [24] 1730 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00AC2D E8               [12] 1731 	mov	a,r0
      00AC2E F0               [24] 1732 	movx	@dptr,a
      00AC2F EB               [12] 1733 	mov	a,r3
      00AC30 A3               [24] 1734 	inc	dptr
      00AC31 F0               [24] 1735 	movx	@dptr,a
      00AC32 ED               [12] 1736 	mov	a,r5
      00AC33 A3               [24] 1737 	inc	dptr
      00AC34 F0               [24] 1738 	movx	@dptr,a
      00AC35 85 40 82         [24] 1739 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AC38 85 41 83         [24] 1740 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AC3B C0 07            [24] 1741 	push	ar7
      00AC3D C0 06            [24] 1742 	push	ar6
      00AC3F C0 03            [24] 1743 	push	ar3
      00AC41 12 8A 54         [24] 1744 	lcall	_dynamic_keymap_set_buffer
      00AC44 D0 03            [24] 1745 	pop	ar3
      00AC46 D0 06            [24] 1746 	pop	ar6
      00AC48 D0 07            [24] 1747 	pop	ar7
                                   1748 ;	quantum/via.c:491: break;
      00AC4A D0 03            [24] 1749 	pop	ar3
      00AC4C 02 AC C1         [24] 1750 	ljmp	00171$
                                   1751 ;	quantum/via.c:495: case id_bootloader_jump: {
      00AC4F                       1752 00161$:
                                   1753 ;	quantum/via.c:497: if (!vial_unlocked)
      00AC4F 90 0D FC         [24] 1754 	mov	dptr,#_vial_unlocked
      00AC52 E0               [24] 1755 	movx	a,@dptr
      00AC53 70 03            [24] 1756 	jnz	00570$
      00AC55 02 AC C1         [24] 1757 	ljmp	00171$
      00AC58                       1758 00570$:
                                   1759 ;	quantum/via.c:501: raw_hid_send(data, length);
      00AC58 12 AD 24         [24] 1760 	lcall	_ak820_outline_0147
      00AC5B 90 06 79         [24] 1761 	mov	dptr,#_raw_hid_send_PARM_2
      00AC5E 12 AD 14         [24] 1762 	lcall	_ak820_outline_0085
      00AC61 C0 07            [24] 1763 	push	ar7
      00AC63 C0 06            [24] 1764 	push	ar6
      00AC65 C0 03            [24] 1765 	push	ar3
      00AC67 12 4B E9         [24] 1766 	lcall	_raw_hid_send
      00AC6A D0 03            [24] 1767 	pop	ar3
      00AC6C D0 06            [24] 1768 	pop	ar6
      00AC6E D0 07            [24] 1769 	pop	ar7
                                   1770 ;	quantum/via.c:503: wait_ms(100);
      00AC70 7D 64            [12] 1771 	mov	r5,#0x64
      00AC72                       1772 00176$:
      00AC72 ED               [12] 1773 	mov	a,r5
      00AC73 60 09            [24] 1774 	jz	00166$
      00AC75 90 00 01         [24] 1775 	mov	dptr,#0x0001
      00AC78 12 59 B5         [24] 1776 	lcall	_mDelaymS
      00AC7B 1D               [12] 1777 	dec	r5
      00AC7C 80 F4            [24] 1778 	sjmp	00176$
      00AC7E                       1779 00166$:
                                   1780 ;	quantum/via.c:504: bootloader_jump();
      00AC7E C0 07            [24] 1781 	push	ar7
      00AC80 C0 06            [24] 1782 	push	ar6
      00AC82 C0 03            [24] 1783 	push	ar3
      00AC84 12 34 0E         [24] 1784 	lcall	_bootloader_jump
      00AC87 D0 03            [24] 1785 	pop	ar3
      00AC89 D0 06            [24] 1786 	pop	ar6
      00AC8B D0 07            [24] 1787 	pop	ar7
                                   1788 ;	quantum/via.c:505: break;
                                   1789 ;	quantum/via.c:509: case id_vial_prefix: {
      00AC8D 80 32            [24] 1790 	sjmp	00171$
      00AC8F                       1791 00168$:
                                   1792 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00AC8F 12 AD 24         [24] 1793 	lcall	_ak820_outline_0147
      00AC92 90 0C 3C         [24] 1794 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AC95 12 AD 14         [24] 1795 	lcall	_ak820_outline_0085
      00AC98 C0 07            [24] 1796 	push	ar7
      00AC9A C0 06            [24] 1797 	push	ar6
      00AC9C C0 03            [24] 1798 	push	ar3
      00AC9E 12 AE 11         [24] 1799 	lcall	_vial_handle_cmd
      00ACA1 D0 03            [24] 1800 	pop	ar3
      00ACA3 D0 06            [24] 1801 	pop	ar6
      00ACA5 D0 07            [24] 1802 	pop	ar7
                                   1803 ;	quantum/via.c:511: break;
                                   1804 ;	quantum/via.c:514: default: {
      00ACA7 80 18            [24] 1805 	sjmp	00171$
      00ACA9                       1806 00169$:
                                   1807 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00ACA9 12 AD 24         [24] 1808 	lcall	_ak820_outline_0147
      00ACAC 90 0C 2A         [24] 1809 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00ACAF 12 AD 14         [24] 1810 	lcall	_ak820_outline_0085
      00ACB2 C0 07            [24] 1811 	push	ar7
      00ACB4 C0 06            [24] 1812 	push	ar6
      00ACB6 C0 03            [24] 1813 	push	ar3
      00ACB8 12 A7 1F         [24] 1814 	lcall	_raw_hid_receive_kb
      00ACBB D0 03            [24] 1815 	pop	ar3
      00ACBD D0 06            [24] 1816 	pop	ar6
      00ACBF D0 07            [24] 1817 	pop	ar7
                                   1818 ;	quantum/via.c:521: skip:
      00ACC1                       1819 00171$:
                                   1820 ;	quantum/via.c:525: raw_hid_send(data, length);
      00ACC1 7D 00            [12] 1821 	mov	r5,#0x00
      00ACC3 90 06 79         [24] 1822 	mov	dptr,#_raw_hid_send_PARM_2
      00ACC6 EB               [12] 1823 	mov	a,r3
      00ACC7 12 43 6D         [24] 1824 	lcall	_ak820_outline_0061
      00ACCA 8D F0            [24] 1825 	mov	b, r5
                                   1826 ;	quantum/via.c:526: }
      00ACCC 02 4B E9         [24] 1827 	ljmp	_raw_hid_send
                                   1828 	.area CSEG    (CODE)
                                   1829 	.area CONST   (CODE)
                                   1830 	.area XINIT   (CODE)
                                   1831 	.area CABS    (ABS,CODE)
                                   1832 
                                   1833 ; Experimental exact instruction outlining.
                                   1834 	.globl _ak820_outline_0001
                                   1835 	.globl _ak820_outline_0003
                                   1836 	.globl _ak820_outline_0010
                                   1837 	.globl _ak820_outline_0011
                                   1838 	.globl _ak820_outline_0014
                                   1839 	.globl _ak820_outline_0015
                                   1840 	.globl _ak820_outline_0016
                                   1841 	.globl _ak820_outline_0021
                                   1842 	.globl _ak820_outline_0022
                                   1843 	.globl _ak820_outline_0030
                                   1844 	.globl _ak820_outline_0034
                                   1845 	.globl _ak820_outline_0037
                                   1846 	.globl _ak820_outline_0038
                                   1847 	.globl _ak820_outline_0042
                                   1848 	.globl _ak820_outline_0044
                                   1849 	.globl _ak820_outline_0051
                                   1850 	.globl _ak820_outline_0061
                                   1851 	.globl _ak820_outline_0069
                                   1852 	.globl _ak820_outline_0084
                                   1853 	.globl _ak820_outline_0085
                                   1854 	.globl _ak820_outline_0092
                                   1855 	.globl _ak820_outline_0093
                                   1856 	.globl _ak820_outline_0098
                                   1857 	.globl _ak820_outline_0103
                                   1858 	.globl _ak820_outline_0104
                                   1859 	.globl _ak820_outline_0115
                                   1860 	.globl _ak820_outline_0116
                                   1861 	.globl _ak820_outline_0122
                                   1862 	.globl _ak820_outline_0147
                                   1863 	.globl _ak820_outline_0149
                                   1864 	.globl _ak820_outline_0153
                                   1865 	.globl _ak820_outline_0154
                                   1866 	.globl _ak820_outline_0156
                                   1867 	.globl _ak820_outline_0157
                                   1868 	.globl _ak820_outline_0167
                                   1869 
                                   1870 	.area CSEG (CODE)
                                   1871 ; function ak820_outline_0001
      00ACCF                       1872 _ak820_outline_0001:
      00ACCF 8C 82            [24] 1873 	mov	dpl,r4
      00ACD1 8D 83            [24] 1874 	mov	dph,r5
      00ACD3 E0               [24] 1875 	movx	a,@dptr
      00ACD4 FA               [12] 1876 	mov	r2,a
      00ACD5 79 00            [12] 1877 	mov	r1,#0x00
      00ACD7 8E 82            [24] 1878 	mov	dpl,r6
      00ACD9 8F 83            [24] 1879 	mov	dph,r7
      00ACDB A3               [24] 1880 	inc	dptr
      00ACDC A3               [24] 1881 	inc	dptr
      00ACDD E0               [24] 1882 	movx	a,@dptr
      00ACDE 7B 00            [12] 1883 	mov	r3,#0x00
      00ACE0 42 01            [12] 1884 	orl	ar1,a
      00ACE2 EB               [12] 1885 	mov	a,r3
      00ACE3 42 02            [12] 1886 	orl	ar2,a
      00ACE5 22               [24] 1887 	ret
                                   1888 
                                   1889 	.area CSEG (CODE)
                                   1890 ; function ak820_outline_0015
      00ACE6                       1891 _ak820_outline_0015:
      00ACE6 8E 82            [24] 1892 	mov	dpl,r6
      00ACE8 8F 83            [24] 1893 	mov	dph,r7
      00ACEA A3               [24] 1894 	inc	dptr
      00ACEB A3               [24] 1895 	inc	dptr
      00ACEC A3               [24] 1896 	inc	dptr
      00ACED E0               [24] 1897 	movx	a,@dptr
      00ACEE 22               [24] 1898 	ret
                                   1899 
                                   1900 	.area CSEG (CODE)
                                   1901 ; function ak820_outline_0021
      00ACEF                       1902 _ak820_outline_0021:
      00ACEF 8E 82            [24] 1903 	mov	dpl,r6
      00ACF1 8F 83            [24] 1904 	mov	dph,r7
      00ACF3 A3               [24] 1905 	inc	dptr
      00ACF4 A3               [24] 1906 	inc	dptr
      00ACF5 A3               [24] 1907 	inc	dptr
      00ACF6 A3               [24] 1908 	inc	dptr
      00ACF7 22               [24] 1909 	ret
                                   1910 
                                   1911 	.area CSEG (CODE)
                                   1912 ; function ak820_outline_0038
      00ACF8                       1913 _ak820_outline_0038:
      00ACF8 EB               [12] 1914 	mov	a,r3
      00ACF9 F0               [24] 1915 	movx	@dptr,a
      00ACFA 88 82            [24] 1916 	mov	dpl,r0
      00ACFC 89 83            [24] 1917 	mov	dph,r1
      00ACFE 8A F0            [24] 1918 	mov	b,r2
      00AD00 22               [24] 1919 	ret
                                   1920 
                                   1921 	.area CSEG (CODE)
                                   1922 ; function ak820_outline_0069
      00AD01                       1923 _ak820_outline_0069:
      00AD01 74 04            [12] 1924 	mov	a,#0x04
      00AD03 2E               [12] 1925 	add	a,r6
      00AD04 F9               [12] 1926 	mov	r1,a
      00AD05 E4               [12] 1927 	clr	a
      00AD06 3F               [12] 1928 	addc	a,r7
      00AD07 F8               [12] 1929 	mov	r0,a
      00AD08 7A 00            [12] 1930 	mov	r2,#0x00
      00AD0A 22               [24] 1931 	ret
                                   1932 
                                   1933 	.area CSEG (CODE)
                                   1934 ; function ak820_outline_0084
      00AD0B                       1935 _ak820_outline_0084:
      00AD0B E9               [12] 1936 	mov	a,r1
      00AD0C F0               [24] 1937 	movx	@dptr,a
      00AD0D E8               [12] 1938 	mov	a,r0
      00AD0E A3               [24] 1939 	inc	dptr
      00AD0F F0               [24] 1940 	movx	@dptr,a
      00AD10 EA               [12] 1941 	mov	a,r2
      00AD11 A3               [24] 1942 	inc	dptr
      00AD12 F0               [24] 1943 	movx	@dptr,a
      00AD13 22               [24] 1944 	ret
                                   1945 
                                   1946 	.area CSEG (CODE)
                                   1947 ; function ak820_outline_0085
      00AD14                       1948 _ak820_outline_0085:
      00AD14 EB               [12] 1949 	mov	a,r3
      00AD15 F0               [24] 1950 	movx	@dptr,a
      00AD16 8A 82            [24] 1951 	mov	dpl,r2
      00AD18 8C 83            [24] 1952 	mov	dph,r4
      00AD1A 8D F0            [24] 1953 	mov	b,r5
      00AD1C 22               [24] 1954 	ret
                                   1955 
                                   1956 	.area CSEG (CODE)
                                   1957 ; function ak820_outline_0092
      00AD1D                       1958 _ak820_outline_0092:
      00AD1D 8E 00            [24] 1959 	mov	ar0,r6
      00AD1F 8F 01            [24] 1960 	mov	ar1,r7
      00AD21 7A 00            [12] 1961 	mov	r2,#0x00
      00AD23 22               [24] 1962 	ret
                                   1963 
                                   1964 	.area CSEG (CODE)
                                   1965 ; function ak820_outline_0147
      00AD24                       1966 _ak820_outline_0147:
      00AD24 8E 02            [24] 1967 	mov	ar2,r6
      00AD26 8F 04            [24] 1968 	mov	ar4,r7
      00AD28 7D 00            [12] 1969 	mov	r5,#0x00
      00AD2A 22               [24] 1970 	ret
