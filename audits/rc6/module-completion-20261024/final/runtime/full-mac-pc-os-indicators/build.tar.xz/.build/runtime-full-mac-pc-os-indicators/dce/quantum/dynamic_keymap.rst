                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000024                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000024                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000ADA                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000ADA                        628 	.ds 1
      000ADB                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000ADB                        630 	.ds 1
      000ADC                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_365:
      000ADC                        632 	.ds 1
      000ADD                        633 _dynamic_keymap_get_keycode_PARM_2:
      000ADD                        634 	.ds 1
      000ADE                        635 _dynamic_keymap_get_keycode_PARM_3:
      000ADE                        636 	.ds 1
      000ADF                        637 _dynamic_keymap_get_keycode_layer_10000_367:
      000ADF                        638 	.ds 1
      000AE0                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AE0                        640 	.ds 1
      000AE1                        641 _dynamic_keymap_set_keycode_PARM_3:
      000AE1                        642 	.ds 1
      000AE2                        643 _dynamic_keymap_set_keycode_PARM_4:
      000AE2                        644 	.ds 2
      000AE4                        645 _dynamic_keymap_set_keycode_layer_10000_371:
      000AE4                        646 	.ds 1
      000AE5                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000AE5                        648 	.ds 1
      000AE6                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_375:
      000AE6                        650 	.ds 1
      000AE7                        651 _dynamic_keymap_get_encoder_PARM_2:
      000AE7                        652 	.ds 1
      000AE8                        653 _dynamic_keymap_get_encoder_PARM_3:
      000AE8                        654 	.ds 1
      000AE9                        655 _dynamic_keymap_get_encoder_layer_10000_377:
      000AE9                        656 	.ds 1
      000AEA                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AEA                        658 	.ds 1
      000AEB                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AEB                        660 	.ds 1
      000AEC                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AEC                        662 	.ds 2
      000AEE                        663 _dynamic_keymap_set_encoder_layer_10000_381:
      000AEE                        664 	.ds 1
      000AEF                        665 _dynamic_keymap_get_combo_PARM_2:
      000AEF                        666 	.ds 3
      000AF2                        667 _dynamic_keymap_get_combo_index_10000_385:
      000AF2                        668 	.ds 1
      000AF3                        669 _dynamic_keymap_set_combo_PARM_2:
      000AF3                        670 	.ds 3
      000AF6                        671 _dynamic_keymap_set_combo_index_10000_391:
      000AF6                        672 	.ds 1
      000AF7                        673 _dynamic_keymap_set_combo_stored_10002_396:
      000AF7                        674 	.ds 10
      000B01                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_399:
      000B01                        676 	.ds 1
      000B02                        677 _dynamic_keymap_reset_combo_10001_408:
      000B02                        678 	.ds 10
      000B0C                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B0C                        680 	.ds 2
      000B0E                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B0E                        682 	.ds 2
      000B10                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B10                        684 	.ds 2
      000B12                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B12                        686 	.ds 3
      000B15                        687 _ak820_dynamic_read_buffer_base_10000_410:
      000B15                        688 	.ds 2
      000B17                        689 _ak820_dynamic_read_buffer_available_10000_411:
      000B17                        690 	.ds 1
      000B18                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B18                        692 	.ds 2
      000B1A                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B1A                        694 	.ds 3
      000B1D                        695 _dynamic_keymap_get_buffer_offset_10000_417:
      000B1D                        696 	.ds 2
      000B1F                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B1F                        698 	.ds 2
      000B21                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B21                        700 	.ds 3
      000B24                        701 _dynamic_keymap_set_buffer_offset_10000_419:
      000B24                        702 	.ds 2
      000B26                        703 _dynamic_keymap_set_buffer_chk_offset_30001_426:
      000B26                        704 	.ds 1
      000B27                        705 _dynamic_keymap_set_buffer_chk_sz_30001_426:
      000B27                        706 	.ds 1
      000B28                        707 _dynamic_keymap_set_buffer_i_40001_433:
      000B28                        708 	.ds 1
      000B29                        709 _keycode_at_keymap_location_PARM_2:
      000B29                        710 	.ds 1
      000B2A                        711 _keycode_at_keymap_location_PARM_3:
      000B2A                        712 	.ds 1
      000B2B                        713 _keycode_at_keymap_location_layer_num_10000_437:
      000B2B                        714 	.ds 1
      000B2C                        715 _keycode_at_encodermap_location_PARM_2:
      000B2C                        716 	.ds 1
      000B2D                        717 _keycode_at_encodermap_location_PARM_3:
      000B2D                        718 	.ds 1
      000B2E                        719 _keycode_at_encodermap_location_layer_num_10000_441:
      000B2E                        720 	.ds 1
      000B2F                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B2F                        722 	.ds 2
      000B31                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B31                        724 	.ds 3
      000B34                        725 _dynamic_keymap_macro_get_buffer_offset_10000_449:
      000B34                        726 	.ds 2
      000B36                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B36                        728 	.ds 2
      000B38                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B38                        730 	.ds 3
      000B3B                        731 _dynamic_keymap_macro_set_buffer_offset_10000_451:
      000B3B                        732 	.ds 2
      000B3D                        733 _decode_keycode_kc_10000_455:
      000B3D                        734 	.ds 2
      000B3F                        735 _dynamic_keymap_macro_send_id_10000_458:
      000B3F                        736 	.ds 1
      000B40                        737 _dynamic_keymap_macro_send_sending_10000_459:
      000B40                        738 	.ds 1
      000B41                        739 _dynamic_keymap_macro_send_p_10001_464:
      000B41                        740 	.ds 2
      000B43                        741 _dynamic_keymap_macro_send_data_10003_471:
      000B43                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      00853B                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      00853B 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      00853E 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_365'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      00853F                        810 _dynamic_keymap_key_to_eeprom_address:
      00853F E5 82            [12]  811 	mov	a,dpl
      008541 90 0A DC         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_365
      008544 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008545 E0               [24]  815 	movx	a,@dptr
      008546 FF               [12]  816 	mov	r7,a
      008547 7E 00            [12]  817 	mov	r6,#0x00
      008549 74 40            [12]  818 	mov	a,#0x40
      00854B 12 43 A2         [24]  819 	lcall	_ak820_outline_0135
      00854E 7D 00            [12]  820 	mov	r5,#0x00
      008550 90 0A DA         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008553 E0               [24]  822 	movx	a,@dptr
      008554 75 F0 10         [24]  823 	mov	b,#0x10
      008557 A4               [48]  824 	mul	ab
      008558 2E               [12]  825 	add	a, r6
      008559 FE               [12]  826 	mov	r6,a
      00855A EF               [12]  827 	mov	a,r7
      00855B 35 F0            [12]  828 	addc	a, b
      00855D FF               [12]  829 	mov	r7,a
      00855E 90 0A DB         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008561 E0               [24]  831 	movx	a,@dptr
      008562 7C 00            [12]  832 	mov	r4,#0x00
      008564 25 E0            [12]  833 	add	a,acc
      008566 FB               [12]  834 	mov	r3,a
      008567 EC               [12]  835 	mov	a,r4
      008568 33               [12]  836 	rlc	a
      008569 FC               [12]  837 	mov	r4,a
      00856A EB               [12]  838 	mov	a,r3
      00856B 2E               [12]  839 	add	a, r6
      00856C FE               [12]  840 	mov	r6,a
      00856D EC               [12]  841 	mov	a,r4
      00856E 3F               [12]  842 	addc	a, r7
      00856F FF               [12]  843 	mov	r7,a
      008570 12 43 92         [24]  844 	lcall	_ak820_outline_0116
      008573 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      008575 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_367'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_370'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_370'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      008576                        861 _dynamic_keymap_get_keycode:
      008576 E5 82            [12]  862 	mov	a,dpl
      008578 90 0A DF         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_367
      00857B F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      00857C E0               [24]  866 	movx	a,@dptr
      00857D FF               [12]  867 	mov	r7,a
      00857E BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      008581                        869 00121$:
      008581 50 14            [24]  870 	jnc	00101$
      008583 90 0A DD         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008586 E0               [24]  872 	movx	a,@dptr
      008587 FE               [12]  873 	mov	r6,a
      008588 BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      00858B                        875 00123$:
      00858B 50 0A            [24]  876 	jnc	00101$
      00858D 90 0A DE         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008590 E0               [24]  878 	movx	a,@dptr
      008591 FD               [12]  879 	mov	r5,a
      008592 BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      008595                        881 00125$:
      008595 40 04            [24]  882 	jc	00102$
      008597                        883 00101$:
      008597 90 00 00         [24]  884 	mov	dptr,#0x0000
      00859A 22               [24]  885 	ret
      00859B                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00859B 12 8F EE         [24]  888 	lcall	_ak820_outline_0096
      00859E 12 85 3F         [24]  889 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      0085A1 12 8F FB         [24]  891 	lcall	_ak820_outline_0112
      0085A4 12 40 AA         [24]  892 	lcall	_eeprom_read_byte
      0085A7 AB 82            [24]  893 	mov	r3,dpl
      0085A9 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      0085AB 0D               [12]  896 	inc	r5
      0085AC BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      0085AF 0E               [12]  898 	inc	r6
      0085B0                        899 00127$:
      0085B0 12 4F EB         [24]  900 	lcall	_ak820_outline_0044
      0085B3 12 40 AA         [24]  901 	lcall	_eeprom_read_byte
      0085B6 AF 82            [24]  902 	mov	r7, dpl
      0085B8 7E 00            [12]  903 	mov	r6,#0x00
      0085BA EF               [12]  904 	mov	a,r7
      0085BB 42 04            [12]  905 	orl	ar4,a
      0085BD EE               [12]  906 	mov	a,r6
      0085BE 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      0085C0 12 43 CE         [24]  909 	lcall	_ak820_outline_0181
                                    910 ;	quantum/dynamic_keymap.c:215: }
      0085C3 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_371'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_374'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      0085C4                        925 _dynamic_keymap_set_keycode:
      0085C4 E5 82            [12]  926 	mov	a,dpl
      0085C6 90 0A E4         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_371
      0085C9 F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      0085CA E0               [24]  930 	movx	a,@dptr
      0085CB FF               [12]  931 	mov	r7,a
      0085CC BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      0085CF                        933 00121$:
      0085CF 50 14            [24]  934 	jnc	00101$
      0085D1 90 0A E0         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0085D4 E0               [24]  936 	movx	a,@dptr
      0085D5 FE               [12]  937 	mov	r6,a
      0085D6 BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      0085D9                        939 00123$:
      0085D9 50 0A            [24]  940 	jnc	00101$
      0085DB 90 0A E1         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0085DE E0               [24]  942 	movx	a,@dptr
      0085DF FD               [12]  943 	mov	r5,a
      0085E0 BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      0085E3                        945 00125$:
      0085E3 40 01            [24]  946 	jc	00102$
      0085E5                        947 00101$:
      0085E5 22               [24]  948 	ret
      0085E6                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0085E6 12 8F EE         [24]  951 	lcall	_ak820_outline_0096
      0085E9 12 85 3F         [24]  952 	lcall	_dynamic_keymap_key_to_eeprom_address
      0085EC 12 8F FB         [24]  953 	lcall	_ak820_outline_0112
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0085EF 90 0A E2         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0085F2 E0               [24]  956 	movx	a,@dptr
      0085F3 FB               [12]  957 	mov	r3,a
      0085F4 A3               [24]  958 	inc	dptr
      0085F5 E0               [24]  959 	movx	a,@dptr
      0085F6 90 06 9F         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      0085F9 F0               [24]  961 	movx	@dptr,a
      0085FA 12 4F EB         [24]  962 	lcall	_ak820_outline_0044
      0085FD 12 4E D5         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008600 0D               [12]  965 	inc	r5
      008601 BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      008604 0E               [12]  967 	inc	r6
      008605                        968 00127$:
      008605 90 06 9F         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      008608 EB               [12]  970 	mov	a,r3
      008609 F0               [24]  971 	movx	@dptr,a
      00860A 12 4F EB         [24]  972 	lcall	_ak820_outline_0044
                                    973 ;	quantum/dynamic_keymap.c:223: }
      00860D 02 4E D5         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      008610                        985 _dynamic_keymap_encoder_to_eeprom_address:
      008610 E5 82            [12]  986 	mov	a,dpl
      008612 90 0A E6         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375
      008615 F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008616 E0               [24]  990 	movx	a,@dptr
      008617 75 F0 04         [24]  991 	mov	b,#0x04
      00861A A4               [48]  992 	mul	ab
      00861B 24 40            [12]  993 	add	a, #0x40
      00861D FD               [12]  994 	mov	r5,a
      00861E 74 06            [12]  995 	mov	a,#0x06
      008620 35 F0            [12]  996 	addc	a, b
      008622 FE               [12]  997 	mov	r6,a
      008623 7F 00            [12]  998 	mov	r7,#0x00
      008625 90 0A E5         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008628 E0               [24] 1000 	movx	a,@dptr
      008629 75 F0 04         [24] 1001 	mov	b,#0x04
      00862C A4               [48] 1002 	mul	ab
      00862D 2D               [12] 1003 	add	a, r5
      00862E FD               [12] 1004 	mov	r5,a
      00862F EE               [12] 1005 	mov	a,r6
      008630 35 F0            [12] 1006 	addc	a, b
      008632 FE               [12] 1007 	mov	r6,a
      008633 12 4F EB         [24] 1008 	lcall	_ak820_outline_0044
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      008636 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_377'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_380'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_380'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      008637                       1024 _dynamic_keymap_get_encoder:
      008637 E5 82            [12] 1025 	mov	a,dpl
      008639 90 0A E9         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_377
      00863C F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      00863D E0               [24] 1029 	movx	a,@dptr
      00863E FF               [12] 1030 	mov	r7,a
      00863F BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      008642                       1032 00131$:
      008642 50 0A            [24] 1033 	jnc	00101$
      008644 90 0A E7         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008647 E0               [24] 1035 	movx	a,@dptr
      008648 FE               [12] 1036 	mov	r6,a
      008649 BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      00864C                       1038 00133$:
      00864C 40 04            [24] 1039 	jc	00102$
      00864E                       1040 00101$:
      00864E 90 00 00         [24] 1041 	mov	dptr,#0x0000
      008651 22               [24] 1042 	ret
      008652                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008652 90 0A E5         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008655 E4               [12] 1046 	clr	a
      008656 F0               [24] 1047 	movx	@dptr,a
      008657 8F 82            [24] 1048 	mov	dpl, r7
      008659 12 86 10         [24] 1049 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      00865C 12 8F FB         [24] 1050 	lcall	_ak820_outline_0112
                                   1051 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      00865F 90 0A E8         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008662 E0               [24] 1053 	movx	a,@dptr
      008663 FC               [12] 1054 	mov	r4,a
      008664 E0               [24] 1055 	movx	a,@dptr
      008665 60 04            [24] 1056 	jz	00106$
      008667 7B 00            [12] 1057 	mov	r3,#0x00
      008669 80 02            [24] 1058 	sjmp	00107$
      00866B                       1059 00106$:
      00866B 7B 02            [12] 1060 	mov	r3,#0x02
      00866D                       1061 00107$:
      00866D EB               [12] 1062 	mov	a,r3
      00866E 12 8F CC         [24] 1063 	lcall	_ak820_outline_0025
      008671 12 40 AA         [24] 1064 	lcall	_eeprom_read_byte
      008674 AA 82            [24] 1065 	mov	r2,dpl
      008676 7B 00            [12] 1066 	mov	r3,#0x00
                                   1067 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008678 EC               [12] 1068 	mov	a,r4
      008679 60 04            [24] 1069 	jz	00108$
      00867B 7C 00            [12] 1070 	mov	r4,#0x00
      00867D 80 02            [24] 1071 	sjmp	00109$
      00867F                       1072 00108$:
      00867F 7C 02            [12] 1073 	mov	r4,#0x02
      008681                       1074 00109$:
      008681 EC               [12] 1075 	mov	a,r4
      008682 12 38 7A         [24] 1076 	lcall	_ak820_outline_0156
      008685 0D               [12] 1077 	inc	r5
      008686 BD 00 01         [24] 1078 	cjne	r5,#0x00,00137$
      008689 0E               [12] 1079 	inc	r6
      00868A                       1080 00137$:
      00868A 12 4F EB         [24] 1081 	lcall	_ak820_outline_0044
      00868D 12 40 AA         [24] 1082 	lcall	_eeprom_read_byte
      008690 AF 82            [24] 1083 	mov	r7, dpl
      008692 7E 00            [12] 1084 	mov	r6,#0x00
      008694 EF               [12] 1085 	mov	a,r7
      008695 42 03            [12] 1086 	orl	ar3,a
      008697 EE               [12] 1087 	mov	a,r6
      008698 42 02            [12] 1088 	orl	ar2,a
                                   1089 ;	quantum/dynamic_keymap.c:236: return keycode;
      00869A 8B 82            [24] 1090 	mov	dpl, r3
      00869C 8A 83            [24] 1091 	mov	dph, r2
                                   1092 ;	quantum/dynamic_keymap.c:237: }
      00869E 22               [24] 1093 	ret
                                   1094 ;------------------------------------------------------------
                                   1095 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1096 ;------------------------------------------------------------
                                   1097 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1098 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1099 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1100 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1101 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_381'
                                   1102 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_384'
                                   1103 ;------------------------------------------------------------
                                   1104 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1105 ;	-----------------------------------------
                                   1106 ;	 function dynamic_keymap_set_encoder
                                   1107 ;	-----------------------------------------
      00869F                       1108 _dynamic_keymap_set_encoder:
      00869F E5 82            [12] 1109 	mov	a,dpl
      0086A1 90 0A EE         [24] 1110 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_381
      0086A4 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      0086A5 E0               [24] 1113 	movx	a,@dptr
      0086A6 FF               [12] 1114 	mov	r7,a
      0086A7 BF 06 00         [24] 1115 	cjne	r7,#0x06,00131$
      0086AA                       1116 00131$:
      0086AA 50 0A            [24] 1117 	jnc	00101$
      0086AC 90 0A EA         [24] 1118 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0086AF E0               [24] 1119 	movx	a,@dptr
      0086B0 FE               [12] 1120 	mov	r6,a
      0086B1 BE 01 00         [24] 1121 	cjne	r6,#0x01,00133$
      0086B4                       1122 00133$:
      0086B4 40 01            [24] 1123 	jc	00102$
      0086B6                       1124 00101$:
      0086B6 22               [24] 1125 	ret
      0086B7                       1126 00102$:
                                   1127 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0086B7 90 0A E5         [24] 1128 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0086BA E4               [12] 1129 	clr	a
      0086BB F0               [24] 1130 	movx	@dptr,a
      0086BC 8F 82            [24] 1131 	mov	dpl, r7
      0086BE 12 86 10         [24] 1132 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0086C1 12 8F FB         [24] 1133 	lcall	_ak820_outline_0112
                                   1134 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      0086C4 90 0A EB         [24] 1135 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0086C7 E0               [24] 1136 	movx	a,@dptr
      0086C8 FC               [12] 1137 	mov	r4,a
      0086C9 E0               [24] 1138 	movx	a,@dptr
      0086CA 60 04            [24] 1139 	jz	00106$
      0086CC 7B 00            [12] 1140 	mov	r3,#0x00
      0086CE 80 02            [24] 1141 	sjmp	00107$
      0086D0                       1142 00106$:
      0086D0 7B 02            [12] 1143 	mov	r3,#0x02
      0086D2                       1144 00107$:
      0086D2 EB               [12] 1145 	mov	a,r3
      0086D3 12 90 0D         [24] 1146 	lcall	_ak820_outline_0134
      0086D6 8F 03            [24] 1147 	mov	ar3,r7
      0086D8 90 0A EC         [24] 1148 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0086DB E0               [24] 1149 	movx	a,@dptr
      0086DC F5 29            [12] 1150 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      0086DE A3               [24] 1151 	inc	dptr
      0086DF E0               [24] 1152 	movx	a,@dptr
      0086E0 F5 2A            [12] 1153 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      0086E2 90 06 9F         [24] 1154 	mov	dptr,#_eeprom_update_byte_PARM_2
      0086E5 F0               [24] 1155 	movx	@dptr,a
      0086E6 12 43 C9         [24] 1156 	lcall	_ak820_outline_0180
      0086E9 8B F0            [24] 1157 	mov	b, r3
      0086EB 12 4E D5         [24] 1158 	lcall	_eeprom_update_byte
                                   1159 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0086EE EC               [12] 1160 	mov	a,r4
      0086EF 60 04            [24] 1161 	jz	00108$
      0086F1 7C 00            [12] 1162 	mov	r4,#0x00
      0086F3 80 02            [24] 1163 	sjmp	00109$
      0086F5                       1164 00108$:
      0086F5 7C 02            [12] 1165 	mov	r4,#0x02
      0086F7                       1166 00109$:
      0086F7 EC               [12] 1167 	mov	a,r4
      0086F8 12 38 7A         [24] 1168 	lcall	_ak820_outline_0156
      0086FB 0D               [12] 1169 	inc	r5
      0086FC BD 00 01         [24] 1170 	cjne	r5,#0x00,00137$
      0086FF 0E               [12] 1171 	inc	r6
      008700                       1172 00137$:
      008700 90 06 9F         [24] 1173 	mov	dptr,#_eeprom_update_byte_PARM_2
      008703 E5 29            [12] 1174 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008705 F0               [24] 1175 	movx	@dptr,a
      008706 12 4F EB         [24] 1176 	lcall	_ak820_outline_0044
                                   1177 ;	quantum/dynamic_keymap.c:245: }
      008709 02 4E D5         [24] 1178 	ljmp	_eeprom_update_byte
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1183 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1184 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_385'
                                   1185 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_386'
                                   1186 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_388'
                                   1187 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_389'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function dynamic_keymap_get_combo
                                   1192 ;	-----------------------------------------
      00870C                       1193 _dynamic_keymap_get_combo:
      00870C E5 82            [12] 1194 	mov	a,dpl
      00870E 90 0A F2         [24] 1195 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008711 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008712 90 0A EF         [24] 1198 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008715 12 38 00         [24] 1199 	lcall	_ak820_outline_0051
                                   1200 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008718 90 0A F2         [24] 1201 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      00871B E0               [24] 1202 	movx	a,@dptr
      00871C FD               [12] 1203 	mov	r5,a
      00871D BD 08 00         [24] 1204 	cjne	r5,#0x08,00132$
      008720                       1205 00132$:
      008720 40 04            [24] 1206 	jc	00102$
                                   1207 ;	quantum/dynamic_keymap.c:315: return -1;
      008722 90 FF FF         [24] 1208 	mov	dptr,#0xffff
      008725 22               [24] 1209 	ret
      008726                       1210 00102$:
                                   1211 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008726 12 8F DA         [24] 1212 	lcall	_ak820_outline_0079
                                   1213 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008729 8E 02            [24] 1214 	mov	ar2,r6
      00872B 8F 03            [24] 1215 	mov	ar3,r7
      00872D 90 05 81         [24] 1216 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008730 12 38 25         [24] 1217 	lcall	_ak820_outline_0071
      008733 E4               [12] 1218 	clr	a
      008734 A3               [24] 1219 	inc	dptr
      008735 F0               [24] 1220 	movx	@dptr,a
      008736 90 05 84         [24] 1221 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008739 74 0A            [12] 1222 	mov	a,#0x0a
      00873B 12 38 65         [24] 1223 	lcall	_ak820_outline_0124
      00873E 12 43 AE         [24] 1224 	lcall	_ak820_outline_0141
      008741 C0 07            [24] 1225 	push	ar7
      008743 C0 06            [24] 1226 	push	ar6
      008745 12 40 E5         [24] 1227 	lcall	_ak820_eeprom_read_block_xdata
      008748 D0 06            [24] 1228 	pop	ar6
      00874A D0 07            [24] 1229 	pop	ar7
                                   1230 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      00874C 74 04            [12] 1231 	mov	a,#0x04
      00874E 12 49 3C         [24] 1232 	lcall	_ak820_outline_0012
      008751 FA               [12] 1233 	mov	r2,a
      008752 A3               [24] 1234 	inc	dptr
      008753 E0               [24] 1235 	movx	a,@dptr
      008754 FB               [12] 1236 	mov	r3,a
      008755 BA 20 14         [24] 1237 	cjne	r2,#0x20,00108$
      008758 BB 08 11         [24] 1238 	cjne	r3,#0x08,00108$
      00875B 74 06            [12] 1239 	mov	a,#0x06
      00875D 12 37 E7         [24] 1240 	lcall	_ak820_outline_0017
      008760 FA               [12] 1241 	mov	r2,a
      008761 A3               [24] 1242 	inc	dptr
      008762 E0               [24] 1243 	movx	a,@dptr
      008763 FB               [12] 1244 	mov	r3,a
      008764 BA 01 05         [24] 1245 	cjne	r2,#0x01,00136$
      008767 BB 00 02         [24] 1246 	cjne	r3,#0x00,00136$
      00876A 80 05            [24] 1247 	sjmp	00109$
      00876C                       1248 00136$:
      00876C                       1249 00108$:
      00876C 75 2B 00         [24] 1250 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      00876F 80 03            [24] 1251 	sjmp	00110$
      008771                       1252 00109$:
      008771 75 2B 01         [24] 1253 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008774                       1254 00110$:
                                   1255 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008774 74 06            [12] 1256 	mov	a,#0x06
      008776 12 37 F0         [24] 1257 	lcall	_ak820_outline_0031
      008779 E4               [12] 1258 	clr	a
      00877A F0               [24] 1259 	movx	@dptr,a
      00877B A3               [24] 1260 	inc	dptr
      00877C 12 38 31         [24] 1261 	lcall	_ak820_outline_0097
      00877F F0               [24] 1262 	movx	@dptr,a
      008780 A3               [24] 1263 	inc	dptr
      008781 F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008782 E5 2B            [12] 1266 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008784 60 12            [24] 1267 	jz	00103$
      008786 12 43 92         [24] 1268 	lcall	_ak820_outline_0116
      008789 C0 07            [24] 1269 	push	ar7
      00878B C0 06            [24] 1270 	push	ar6
      00878D 12 34 68         [24] 1271 	lcall	_ak820_combo_valid
      008790 E5 82            [12] 1272 	mov	a, dpl
      008792 D0 06            [24] 1273 	pop	ar6
      008794 D0 07            [24] 1274 	pop	ar7
      008796 70 17            [24] 1275 	jnz	00104$
      008798                       1276 00103$:
      008798 7D 00            [12] 1277 	mov	r5,#0x00
      00879A 90 0D 84         [24] 1278 	mov	dptr,#_memset_PARM_2
      00879D E4               [12] 1279 	clr	a
      00879E F0               [24] 1280 	movx	@dptr,a
      00879F 90 0D 85         [24] 1281 	mov	dptr,#_memset_PARM_3
      0087A2 74 0A            [12] 1282 	mov	a,#0x0a
      0087A4 F0               [24] 1283 	movx	@dptr,a
      0087A5 E4               [12] 1284 	clr	a
      0087A6 A3               [24] 1285 	inc	dptr
      0087A7 12 43 6D         [24] 1286 	lcall	_ak820_outline_0061
      0087AA 8D F0            [24] 1287 	mov	b, r5
      0087AC 12 B9 16         [24] 1288 	lcall	_memset
      0087AF                       1289 00104$:
                                   1290 ;	quantum/dynamic_keymap.c:329: return 0;
      0087AF 90 00 00         [24] 1291 	mov	dptr,#0x0000
                                   1292 ;	quantum/dynamic_keymap.c:330: }
      0087B2 22               [24] 1293 	ret
                                   1294 ;------------------------------------------------------------
                                   1295 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1296 ;------------------------------------------------------------
                                   1297 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1298 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_391'
                                   1299 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_392'
                                   1300 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_395'
                                   1301 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_396'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1304 ;	-----------------------------------------
                                   1305 ;	 function dynamic_keymap_set_combo
                                   1306 ;	-----------------------------------------
      0087B3                       1307 _dynamic_keymap_set_combo:
      0087B3 E5 82            [12] 1308 	mov	a,dpl
      0087B5 90 0A F6         [24] 1309 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      0087B8 F0               [24] 1310 	movx	@dptr,a
                                   1311 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0087B9 90 0A F3         [24] 1312 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0087BC 12 37 A0         [24] 1313 	lcall	_ak820_outline_0004
                                   1314 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      0087BF C0 07            [24] 1315 	push	ar7
      0087C1 C0 06            [24] 1316 	push	ar6
      0087C3 12 34 68         [24] 1317 	lcall	_ak820_combo_valid
      0087C6 E5 82            [12] 1318 	mov	a, dpl
      0087C8 D0 06            [24] 1319 	pop	ar6
      0087CA D0 07            [24] 1320 	pop	ar7
      0087CC 60 07            [24] 1321 	jz	00101$
      0087CE 12 3E 51         [24] 1322 	lcall	_ak820_nvm_ok
      0087D1 E5 82            [12] 1323 	mov	a, dpl
      0087D3 70 04            [24] 1324 	jnz	00102$
      0087D5                       1325 00101$:
      0087D5 90 FF FF         [24] 1326 	mov	dptr,#0xffff
      0087D8 22               [24] 1327 	ret
      0087D9                       1328 00102$:
                                   1329 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      0087D9 90 0A F6         [24] 1330 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      0087DC E0               [24] 1331 	movx	a,@dptr
      0087DD FD               [12] 1332 	mov	r5,a
      0087DE BD 08 00         [24] 1333 	cjne	r5,#0x08,00133$
      0087E1                       1334 00133$:
      0087E1 40 04            [24] 1335 	jc	00105$
                                   1336 ;	quantum/dynamic_keymap.c:342: return -1;
      0087E3 90 FF FF         [24] 1337 	mov	dptr,#0xffff
      0087E6 22               [24] 1338 	ret
      0087E7                       1339 00105$:
                                   1340 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0087E7 12 8F DA         [24] 1341 	lcall	_ak820_outline_0079
                                   1342 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      0087EA C0 07            [24] 1343 	push	ar7
      0087EC C0 06            [24] 1344 	push	ar6
      0087EE C0 05            [24] 1345 	push	ar5
      0087F0 C0 04            [24] 1346 	push	ar4
      0087F2 12 77 EC         [24] 1347 	lcall	_clear_keyboard
      0087F5 D0 04            [24] 1348 	pop	ar4
      0087F7 D0 05            [24] 1349 	pop	ar5
      0087F9 D0 06            [24] 1350 	pop	ar6
      0087FB D0 07            [24] 1351 	pop	ar7
                                   1352 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      0087FD 90 0D 7C         [24] 1353 	mov	dptr,#___memcpy_PARM_2
      008800 12 49 96         [24] 1354 	lcall	_ak820_outline_0059
      008803 E4               [12] 1355 	clr	a
      008804 A3               [24] 1356 	inc	dptr
      008805 F0               [24] 1357 	movx	@dptr,a
      008806 90 0D 7F         [24] 1358 	mov	dptr,#___memcpy_PARM_3
      008809 74 0A            [12] 1359 	mov	a,#0x0a
      00880B 12 38 65         [24] 1360 	lcall	_ak820_outline_0124
      00880E 90 0A F7         [24] 1361 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008811 F5 F0            [12] 1362 	mov	b,a
      008813 C0 05            [24] 1363 	push	ar5
      008815 C0 04            [24] 1364 	push	ar4
      008817 12 B8 A0         [24] 1365 	lcall	___memcpy
      00881A D0 04            [24] 1366 	pop	ar4
      00881C D0 05            [24] 1367 	pop	ar5
                                   1368 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      00881E 90 0A FB         [24] 1369 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0004)
      008821 74 20            [12] 1370 	mov	a,#0x20
      008823 F0               [24] 1371 	movx	@dptr,a
      008824 74 08            [12] 1372 	mov	a,#0x08
      008826 A3               [24] 1373 	inc	dptr
      008827 F0               [24] 1374 	movx	@dptr,a
                                   1375 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008828 90 0A FD         [24] 1376 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0006)
      00882B 74 01            [12] 1377 	mov	a,#0x01
      00882D 12 38 65         [24] 1378 	lcall	_ak820_outline_0124
                                   1379 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008830 90 05 8A         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008833 12 38 25         [24] 1381 	lcall	_ak820_outline_0071
      008836 E4               [12] 1382 	clr	a
      008837 A3               [24] 1383 	inc	dptr
      008838 F0               [24] 1384 	movx	@dptr,a
      008839 90 05 8D         [24] 1385 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00883C 74 0A            [12] 1386 	mov	a,#0x0a
      00883E 12 38 65         [24] 1387 	lcall	_ak820_outline_0124
      008841 90 0A F7         [24] 1388 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008844 12 41 71         [24] 1389 	lcall	_ak820_eeprom_write_block_xdata
                                   1390 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008847 12 3E 60         [24] 1391 	lcall	_ak820_nvm_flush
                                   1392 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      00884A 12 3E 51         [24] 1393 	lcall	_ak820_nvm_ok
      00884D E5 82            [12] 1394 	mov	a, dpl
      00884F 70 04            [24] 1395 	jnz	00107$
      008851 90 FF FF         [24] 1396 	mov	dptr,#0xffff
      008854 22               [24] 1397 	ret
      008855                       1398 00107$:
                                   1399 ;	quantum/dynamic_keymap.c:360: return 0;
      008855 90 00 00         [24] 1400 	mov	dptr,#0x0000
                                   1401 ;	quantum/dynamic_keymap.c:361: }
      008858 22               [24] 1402 	ret
                                   1403 ;------------------------------------------------------------
                                   1404 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1405 ;------------------------------------------------------------
                                   1406 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_399'
                                   1407 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_400'
                                   1408 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_402'
                                   1409 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_404'
                                   1410 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_406'
                                   1411 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_408'
                                   1412 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_409'
                                   1413 ;------------------------------------------------------------
                                   1414 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1415 ;	-----------------------------------------
                                   1416 ;	 function dynamic_keymap_reset
                                   1417 ;	-----------------------------------------
      008859                       1418 _dynamic_keymap_reset:
                                   1419 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008859 90 0D FC         [24] 1420 	mov	dptr,#_vial_unlocked
      00885C E0               [24] 1421 	movx	a,@dptr
      00885D 90 0B 01         [24] 1422 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008860 F0               [24] 1423 	movx	@dptr,a
                                   1424 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008861 90 0D FC         [24] 1425 	mov	dptr,#_vial_unlocked
      008864 74 01            [12] 1426 	mov	a,#0x01
      008866 F0               [24] 1427 	movx	@dptr,a
                                   1428 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008867 7F 00            [12] 1429 	mov	r7,#0x00
      008869                       1430 00116$:
      008869 BF 06 00         [24] 1431 	cjne	r7,#0x06,00198$
      00886C                       1432 00198$:
      00886C 40 03            [24] 1433 	jc	00199$
      00886E 02 89 1C         [24] 1434 	ljmp	00104$
      008871                       1435 00199$:
                                   1436 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008871 7E 00            [12] 1437 	mov	r6,#0x00
      008873                       1438 00110$:
      008873 BE 10 00         [24] 1439 	cjne	r6,#0x10,00200$
      008876                       1440 00200$:
      008876 50 4D            [24] 1441 	jnc	00102$
                                   1442 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008878 7D 00            [12] 1443 	mov	r5,#0x00
      00887A                       1444 00107$:
      00887A BD 08 00         [24] 1445 	cjne	r5,#0x08,00202$
      00887D                       1446 00202$:
      00887D 50 43            [24] 1447 	jnc	00111$
                                   1448 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      00887F 90 0B 9D         [24] 1449 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008882 EE               [12] 1450 	mov	a,r6
      008883 F0               [24] 1451 	movx	@dptr,a
      008884 90 0B 9E         [24] 1452 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008887 ED               [12] 1453 	mov	a,r5
      008888 F0               [24] 1454 	movx	@dptr,a
      008889 8F 82            [24] 1455 	mov	dpl, r7
      00888B C0 07            [24] 1456 	push	ar7
      00888D C0 06            [24] 1457 	push	ar6
      00888F C0 05            [24] 1458 	push	ar5
      008891 12 98 20         [24] 1459 	lcall	_keycode_at_keymap_location_raw
      008894 AB 82            [24] 1460 	mov	r3, dpl
      008896 AC 83            [24] 1461 	mov	r4, dph
      008898 D0 05            [24] 1462 	pop	ar5
      00889A D0 06            [24] 1463 	pop	ar6
      00889C D0 07            [24] 1464 	pop	ar7
      00889E 90 0A E0         [24] 1465 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0088A1 EE               [12] 1466 	mov	a,r6
      0088A2 F0               [24] 1467 	movx	@dptr,a
      0088A3 90 0A E1         [24] 1468 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0088A6 ED               [12] 1469 	mov	a,r5
      0088A7 F0               [24] 1470 	movx	@dptr,a
      0088A8 90 0A E2         [24] 1471 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0088AB 12 38 2B         [24] 1472 	lcall	_ak820_outline_0077
      0088AE 8F 82            [24] 1473 	mov	dpl, r7
      0088B0 C0 07            [24] 1474 	push	ar7
      0088B2 C0 06            [24] 1475 	push	ar6
      0088B4 C0 05            [24] 1476 	push	ar5
      0088B6 12 85 C4         [24] 1477 	lcall	_dynamic_keymap_set_keycode
      0088B9 D0 05            [24] 1478 	pop	ar5
      0088BB D0 06            [24] 1479 	pop	ar6
      0088BD D0 07            [24] 1480 	pop	ar7
                                   1481 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0088BF 0D               [12] 1482 	inc	r5
      0088C0 80 B8            [24] 1483 	sjmp	00107$
      0088C2                       1484 00111$:
                                   1485 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0088C2 0E               [12] 1486 	inc	r6
      0088C3 80 AE            [24] 1487 	sjmp	00110$
      0088C5                       1488 00102$:
                                   1489 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0088C5 7E 00            [12] 1490 	mov	r6,#0x00
      0088C7                       1491 00113$:
      0088C7 BE 01 00         [24] 1492 	cjne	r6,#0x01,00204$
      0088CA                       1493 00204$:
      0088CA 50 4C            [24] 1494 	jnc	00117$
                                   1495 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      0088CC 12 90 29         [24] 1496 	lcall	_ak820_outline_0175
      0088CF 04               [12] 1497 	inc	a
      0088D0 F0               [24] 1498 	movx	@dptr,a
      0088D1 8F 82            [24] 1499 	mov	dpl, r7
      0088D3 C0 07            [24] 1500 	push	ar7
      0088D5 12 98 65         [24] 1501 	lcall	_keycode_at_encodermap_location_raw
      0088D8 12 43 B3         [24] 1502 	lcall	_ak820_outline_0146
      0088DB D0 07            [24] 1503 	pop	ar7
      0088DD 12 90 20         [24] 1504 	lcall	_ak820_outline_0174
      0088E0 04               [12] 1505 	inc	a
      0088E1 F0               [24] 1506 	movx	@dptr,a
      0088E2 90 0A EC         [24] 1507 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0088E5 12 38 25         [24] 1508 	lcall	_ak820_outline_0071
      0088E8 8F 82            [24] 1509 	mov	dpl, r7
      0088EA C0 07            [24] 1510 	push	ar7
      0088EC 12 86 9F         [24] 1511 	lcall	_dynamic_keymap_set_encoder
      0088EF D0 07            [24] 1512 	pop	ar7
                                   1513 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      0088F1 12 90 29         [24] 1514 	lcall	_ak820_outline_0175
      0088F4 F0               [24] 1515 	movx	@dptr,a
      0088F5 8F 82            [24] 1516 	mov	dpl, r7
      0088F7 C0 07            [24] 1517 	push	ar7
      0088F9 12 98 65         [24] 1518 	lcall	_keycode_at_encodermap_location_raw
      0088FC 12 43 B3         [24] 1519 	lcall	_ak820_outline_0146
      0088FF D0 07            [24] 1520 	pop	ar7
      008901 12 90 20         [24] 1521 	lcall	_ak820_outline_0174
      008904 F0               [24] 1522 	movx	@dptr,a
      008905 90 0A EC         [24] 1523 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008908 12 38 25         [24] 1524 	lcall	_ak820_outline_0071
      00890B 8F 82            [24] 1525 	mov	dpl, r7
      00890D C0 07            [24] 1526 	push	ar7
      00890F 12 86 9F         [24] 1527 	lcall	_dynamic_keymap_set_encoder
      008912 D0 07            [24] 1528 	pop	ar7
                                   1529 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008914 7E 01            [12] 1530 	mov	r6,#0x01
      008916 80 AF            [24] 1531 	sjmp	00113$
      008918                       1532 00117$:
                                   1533 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008918 0F               [12] 1534 	inc	r7
      008919 02 88 69         [24] 1535 	ljmp	00116$
      00891C                       1536 00104$:
                                   1537 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      00891C 90 0B 02         [24] 1538 	mov	dptr,#_dynamic_keymap_reset_combo_10001_408
      00891F 12 50 34         [24] 1539 	lcall	_ak820_outline_0179
      008922 90 0B 04         [24] 1540 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0002)
      008925 F0               [24] 1541 	movx	@dptr,a
      008926 A3               [24] 1542 	inc	dptr
      008927 F0               [24] 1543 	movx	@dptr,a
      008928 90 0B 06         [24] 1544 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0004)
      00892B F0               [24] 1545 	movx	@dptr,a
      00892C A3               [24] 1546 	inc	dptr
      00892D F0               [24] 1547 	movx	@dptr,a
      00892E 90 0B 08         [24] 1548 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0006)
      008931 F0               [24] 1549 	movx	@dptr,a
      008932 A3               [24] 1550 	inc	dptr
      008933 F0               [24] 1551 	movx	@dptr,a
      008934 90 0B 0A         [24] 1552 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0008)
      008937 F0               [24] 1553 	movx	@dptr,a
      008938 A3               [24] 1554 	inc	dptr
      008939 F0               [24] 1555 	movx	@dptr,a
                                   1556 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      00893A FF               [12] 1557 	mov	r7,a
      00893B                       1558 00119$:
      00893B BF 08 00         [24] 1559 	cjne	r7,#0x08,00206$
      00893E                       1560 00206$:
      00893E 50 17            [24] 1561 	jnc	00105$
                                   1562 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008940 90 0A F3         [24] 1563 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008943 74 02            [12] 1564 	mov	a,#_dynamic_keymap_reset_combo_10001_408
      008945 F0               [24] 1565 	movx	@dptr,a
      008946 74 0B            [12] 1566 	mov	a,#(_dynamic_keymap_reset_combo_10001_408 >> 8)
      008948 12 38 54         [24] 1567 	lcall	_ak820_outline_0117
      00894B 8F 82            [24] 1568 	mov	dpl, r7
      00894D C0 07            [24] 1569 	push	ar7
      00894F 12 87 B3         [24] 1570 	lcall	_dynamic_keymap_set_combo
      008952 D0 07            [24] 1571 	pop	ar7
                                   1572 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008954 0F               [12] 1573 	inc	r7
      008955 80 E4            [24] 1574 	sjmp	00119$
      008957                       1575 00105$:
                                   1576 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008957 90 0B 01         [24] 1577 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      00895A E0               [24] 1578 	movx	a,@dptr
      00895B 90 0D FC         [24] 1579 	mov	dptr,#_vial_unlocked
      00895E F0               [24] 1580 	movx	@dptr,a
                                   1581 ;	quantum/dynamic_keymap.c:468: }
      00895F 22               [24] 1582 	ret
                                   1583 ;------------------------------------------------------------
                                   1584 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1585 ;------------------------------------------------------------
                                   1586 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1587 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1588 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1589 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1590 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1591 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_410'
                                   1592 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_411'
                                   1593 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_411'
                                   1594 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_414'
                                   1595 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_416'
                                   1596 ;------------------------------------------------------------
                                   1597 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1598 ;	-----------------------------------------
                                   1599 ;	 function ak820_dynamic_read_buffer
                                   1600 ;	-----------------------------------------
      008960                       1601 _ak820_dynamic_read_buffer:
      008960 12 38 43         [24] 1602 	lcall	_ak820_outline_0103
      008963 90 0B 15         [24] 1603 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008966 12 38 48         [24] 1604 	lcall	_ak820_outline_0104
                                   1605 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008969 90 0B 12         [24] 1606 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      00896C 12 38 00         [24] 1607 	lcall	_ak820_outline_0051
                                   1608 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      00896F 90 0B 17         [24] 1609 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008972 E4               [12] 1610 	clr	a
      008973 F0               [24] 1611 	movx	@dptr,a
                                   1612 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008974 90 0B 10         [24] 1613 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008977 12 38 1F         [24] 1614 	lcall	_ak820_outline_0060
      00897A 8C 02            [24] 1615 	mov	ar2,r4
      00897C 8D 03            [24] 1616 	mov	ar3,r5
      00897E C3               [12] 1617 	clr	c
      00897F 74 1C            [12] 1618 	mov	a,#0x1c
      008981 9A               [12] 1619 	subb	a,r2
      008982 E4               [12] 1620 	clr	a
      008983 9B               [12] 1621 	subb	a,r3
      008984 50 01            [24] 1622 	jnc	00102$
                                   1623 ;	free result
      008986 22               [24] 1624 	ret
      008987                       1625 00102$:
                                   1626 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008987 90 0B 0E         [24] 1627 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      00898A 12 43 97         [24] 1628 	lcall	_ak820_outline_0120
      00898D 90 0B 0C         [24] 1629 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008990 12 38 3D         [24] 1630 	lcall	_ak820_outline_0100
      008993 C3               [12] 1631 	clr	c
      008994 EA               [12] 1632 	mov	a,r2
      008995 98               [12] 1633 	subb	a,r0
      008996 EB               [12] 1634 	mov	a,r3
      008997 99               [12] 1635 	subb	a,r1
      008998 50 17            [24] 1636 	jnc	00104$
                                   1637 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      00899A E8               [12] 1638 	mov	a,r0
      00899B C3               [12] 1639 	clr	c
      00899C 9A               [12] 1640 	subb	a,r2
      00899D F8               [12] 1641 	mov	r0,a
      00899E E9               [12] 1642 	mov	a,r1
      00899F 9B               [12] 1643 	subb	a,r3
      0089A0 F9               [12] 1644 	mov	r1,a
                                   1645 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      0089A1 C3               [12] 1646 	clr	c
      0089A2 E8               [12] 1647 	mov	a,r0
      0089A3 9C               [12] 1648 	subb	a,r4
      0089A4 E9               [12] 1649 	mov	a,r1
      0089A5 9D               [12] 1650 	subb	a,r5
      0089A6 40 04            [24] 1651 	jc	00114$
      0089A8 8C 00            [24] 1652 	mov	ar0,r4
      0089AA 8D 01            [24] 1653 	mov	ar1,r5
      0089AC                       1654 00114$:
      0089AC 90 0B 17         [24] 1655 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      0089AF E8               [12] 1656 	mov	a,r0
      0089B0 F0               [24] 1657 	movx	@dptr,a
      0089B1                       1658 00104$:
                                   1659 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0089B1 90 0B 17         [24] 1660 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      0089B4 E0               [24] 1661 	movx	a,@dptr
      0089B5 F5 2C            [12] 1662 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      0089B7 E0               [24] 1663 	movx	a,@dptr
      0089B8 60 42            [24] 1664 	jz	00106$
      0089BA C0 04            [24] 1665 	push	ar4
      0089BC C0 05            [24] 1666 	push	ar5
      0089BE 8E 00            [24] 1667 	mov	ar0,r6
      0089C0 8F 05            [24] 1668 	mov	ar5,r7
      0089C2 90 0B 15         [24] 1669 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      0089C5 E0               [24] 1670 	movx	a,@dptr
      0089C6 F9               [12] 1671 	mov	r1,a
      0089C7 A3               [24] 1672 	inc	dptr
      0089C8 E0               [24] 1673 	movx	a,@dptr
      0089C9 FC               [12] 1674 	mov	r4,a
      0089CA EA               [12] 1675 	mov	a,r2
      0089CB 29               [12] 1676 	add	a, r1
      0089CC FA               [12] 1677 	mov	r2,a
      0089CD EB               [12] 1678 	mov	a,r3
      0089CE 3C               [12] 1679 	addc	a, r4
      0089CF FB               [12] 1680 	mov	r3,a
      0089D0 90 05 81         [24] 1681 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0089D3 EA               [12] 1682 	mov	a,r2
      0089D4 F0               [24] 1683 	movx	@dptr,a
      0089D5 EB               [12] 1684 	mov	a,r3
      0089D6 12 38 54         [24] 1685 	lcall	_ak820_outline_0117
      0089D9 90 05 84         [24] 1686 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0089DC E5 2C            [12] 1687 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      0089DE 12 38 65         [24] 1688 	lcall	_ak820_outline_0124
      0089E1 88 82            [24] 1689 	mov	dpl, r0
      0089E3 8D 83            [24] 1690 	mov	dph, r5
      0089E5 C0 07            [24] 1691 	push	ar7
      0089E7 C0 06            [24] 1692 	push	ar6
      0089E9 C0 05            [24] 1693 	push	ar5
      0089EB C0 04            [24] 1694 	push	ar4
      0089ED 12 40 E5         [24] 1695 	lcall	_ak820_eeprom_read_block_xdata
      0089F0 D0 04            [24] 1696 	pop	ar4
      0089F2 D0 05            [24] 1697 	pop	ar5
      0089F4 D0 06            [24] 1698 	pop	ar6
      0089F6 D0 07            [24] 1699 	pop	ar7
                                   1700 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0089F8 D0 05            [24] 1701 	pop	ar5
      0089FA D0 04            [24] 1702 	pop	ar4
                                   1703 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0089FC                       1704 00106$:
                                   1705 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0089FC 90 0B 17         [24] 1706 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      0089FF E0               [24] 1707 	movx	a,@dptr
      008A00 FB               [12] 1708 	mov	r3,a
      008A01                       1709 00109$:
      008A01 8B 01            [24] 1710 	mov	ar1,r3
      008A03 7A 00            [12] 1711 	mov	r2,#0x00
      008A05 C3               [12] 1712 	clr	c
      008A06 E9               [12] 1713 	mov	a,r1
      008A07 9C               [12] 1714 	subb	a,r4
      008A08 EA               [12] 1715 	mov	a,r2
      008A09 9D               [12] 1716 	subb	a,r5
      008A0A 50 09            [24] 1717 	jnc	00111$
      008A0C EB               [12] 1718 	mov	a,r3
      008A0D 12 37 F0         [24] 1719 	lcall	_ak820_outline_0031
      008A10 E4               [12] 1720 	clr	a
      008A11 F0               [24] 1721 	movx	@dptr,a
      008A12 0B               [12] 1722 	inc	r3
      008A13 80 EC            [24] 1723 	sjmp	00109$
      008A15                       1724 00111$:
                                   1725 ;	quantum/dynamic_keymap.c:483: }
      008A15 22               [24] 1726 	ret
                                   1727 ;------------------------------------------------------------
                                   1728 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1729 ;------------------------------------------------------------
                                   1730 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1731 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1732 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_417'
                                   1733 ;------------------------------------------------------------
                                   1734 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1735 ;	-----------------------------------------
                                   1736 ;	 function dynamic_keymap_get_buffer
                                   1737 ;	-----------------------------------------
      008A16                       1738 _dynamic_keymap_get_buffer:
      008A16 12 38 43         [24] 1739 	lcall	_ak820_outline_0103
      008A19 90 0B 1D         [24] 1740 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008A1C 12 38 48         [24] 1741 	lcall	_ak820_outline_0104
                                   1742 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008A1F 90 0B 1D         [24] 1743 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008A22 12 38 00         [24] 1744 	lcall	_ak820_outline_0051
      008A25 90 0B 18         [24] 1745 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008A28 12 38 1F         [24] 1746 	lcall	_ak820_outline_0060
      008A2B 90 0B 1A         [24] 1747 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008A2E 12 50 14         [24] 1748 	lcall	_ak820_outline_0088
      008A31 90 0B 0C         [24] 1749 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008A34 E4               [12] 1750 	clr	a
      008A35 F0               [24] 1751 	movx	@dptr,a
      008A36 74 06            [12] 1752 	mov	a,#0x06
      008A38 A3               [24] 1753 	inc	dptr
      008A39 F0               [24] 1754 	movx	@dptr,a
      008A3A 90 0B 0E         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008A3D 12 49 96         [24] 1756 	lcall	_ak820_outline_0059
      008A40 90 0B 10         [24] 1757 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008A43 12 38 25         [24] 1758 	lcall	_ak820_outline_0071
      008A46 90 0B 12         [24] 1759 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008A49 E9               [12] 1760 	mov	a,r1
      008A4A 12 50 2D         [24] 1761 	lcall	_ak820_outline_0152
      008A4D F0               [24] 1762 	movx	@dptr,a
      008A4E 90 00 40         [24] 1763 	mov	dptr,#0x0040
                                   1764 ;	quantum/dynamic_keymap.c:511: }
      008A51 02 89 60         [24] 1765 	ljmp	_ak820_dynamic_read_buffer
                                   1766 ;------------------------------------------------------------
                                   1767 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1768 ;------------------------------------------------------------
                                   1769 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1770 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1771 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1772 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1773 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1774 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_419'
                                   1775 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_420'
                                   1776 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_420'
                                   1777 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_420'
                                   1778 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_423'
                                   1779 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_426'
                                   1780 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_426'
                                   1781 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_428'
                                   1782 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_431'
                                   1783 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_433'
                                   1784 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_434'
                                   1785 ;------------------------------------------------------------
                                   1786 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1787 ;	-----------------------------------------
                                   1788 ;	 function dynamic_keymap_set_buffer
                                   1789 ;	-----------------------------------------
      008A54                       1790 _dynamic_keymap_set_buffer:
      008A54 12 38 43         [24] 1791 	lcall	_ak820_outline_0103
      008A57 90 0B 24         [24] 1792 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008A5A 12 38 48         [24] 1793 	lcall	_ak820_outline_0104
                                   1794 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008A5D 90 0B 24         [24] 1795 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008A60 12 37 CB         [24] 1796 	lcall	_ak820_outline_0011
      008A63 74 40            [12] 1797 	mov	a,#0x40
      008A65 2C               [12] 1798 	add	a, r4
      008A66 FA               [12] 1799 	mov	r2,a
      008A67 E4               [12] 1800 	clr	a
      008A68 3D               [12] 1801 	addc	a, r5
      008A69 FB               [12] 1802 	mov	r3,a
                                   1803 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008A6A 90 0B 21         [24] 1804 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008A6D 12 38 3D         [24] 1805 	lcall	_ak820_outline_0100
                                   1806 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008A70 90 0B 1F         [24] 1807 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008A73 E0               [24] 1808 	movx	a,@dptr
      008A74 F5 2D            [12] 1809 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008A76 A3               [24] 1810 	inc	dptr
      008A77 E0               [24] 1811 	movx	a,@dptr
      008A78 F5 2E            [12] 1812 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008A7A E5 2D            [12] 1813 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008A7C 45 2E            [12] 1814 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008A7E 70 01            [24] 1815 	jnz	00102$
      008A80 22               [24] 1816 	ret
      008A81                       1817 00102$:
                                   1818 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008A81 85 2D 2F         [24] 1819 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008A84 85 2E 30         [24] 1820 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008A87 C3               [12] 1821 	clr	c
      008A88 74 1C            [12] 1822 	mov	a,#0x1c
      008A8A 95 2F            [12] 1823 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008A8C E4               [12] 1824 	clr	a
      008A8D 95 30            [12] 1825 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008A8F 50 01            [24] 1826 	jnc	00104$
                                   1827 ;	free result
      008A91 22               [24] 1828 	ret
      008A92                       1829 00104$:
                                   1830 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008A92 85 2D 31         [24] 1831 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1832 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008A95 74 FA            [12] 1833 	mov	a,#0x100 - 0x06
      008A97 2F               [12] 1834 	add	a,r7
      008A98 40 11            [24] 1835 	jc	00105$
      008A9A E4               [12] 1836 	clr	a
      008A9B C3               [12] 1837 	clr	c
      008A9C 9E               [12] 1838 	subb	a,r6
      008A9D FE               [12] 1839 	mov	r6,a
      008A9E 74 06            [12] 1840 	mov	a,#0x06
      008AA0 9F               [12] 1841 	subb	a,r7
      008AA1 FF               [12] 1842 	mov	r7,a
      008AA2 C3               [12] 1843 	clr	c
      008AA3 EE               [12] 1844 	mov	a,r6
      008AA4 95 2D            [12] 1845 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008AA6 EF               [12] 1846 	mov	a,r7
      008AA7 95 2E            [12] 1847 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008AA9 50 01            [24] 1848 	jnc	00106$
      008AAB                       1849 00105$:
                                   1850 ;	quantum/dynamic_keymap.c:529: return;
      008AAB 22               [24] 1851 	ret
      008AAC                       1852 00106$:
                                   1853 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008AAC 90 0D FC         [24] 1854 	mov	dptr,#_vial_unlocked
      008AAF E0               [24] 1855 	movx	a,@dptr
      008AB0 60 03            [24] 1856 	jz	00207$
      008AB2 02 8B C1         [24] 1857 	ljmp	00120$
      008AB5                       1858 00207$:
                                   1859 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008AB5 90 0B 26         [24] 1860 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008AB8 E4               [12] 1861 	clr	a
      008AB9 F0               [24] 1862 	movx	@dptr,a
                                   1863 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008ABA 90 0B 27         [24] 1864 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008ABD E5 31            [12] 1865 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008ABF F0               [24] 1866 	movx	@dptr,a
                                   1867 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008AC0 EC               [12] 1868 	mov	a,r4
      008AC1 30 E0 33         [24] 1869 	jnb	acc.0,00111$
                                   1870 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008AC4 EA               [12] 1871 	mov	a,r2
      008AC5 24 FF            [12] 1872 	add	a,#0xff
      008AC7 FE               [12] 1873 	mov	r6,a
      008AC8 EB               [12] 1874 	mov	a,r3
      008AC9 34 FF            [12] 1875 	addc	a,#0xff
      008ACB FF               [12] 1876 	mov	r7,a
      008ACC 7D 00            [12] 1877 	mov	r5,#0x00
      008ACE 12 43 92         [24] 1878 	lcall	_ak820_outline_0116
      008AD1 8D F0            [24] 1879 	mov	b, r5
      008AD3 12 40 AA         [24] 1880 	lcall	_eeprom_read_byte
      008AD6 AE 82            [24] 1881 	mov	r6,dpl
      008AD8 7F 00            [12] 1882 	mov	r7,#0x00
      008ADA 12 38 75         [24] 1883 	lcall	_ak820_outline_0153
      008ADD E0               [24] 1884 	movx	a,@dptr
      008ADE 7C 00            [12] 1885 	mov	r4,#0x00
      008AE0 42 07            [12] 1886 	orl	ar7,a
      008AE2 EC               [12] 1887 	mov	a,r4
      008AE3 42 06            [12] 1888 	orl	ar6,a
                                   1889 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008AE5 BF 00 09         [24] 1890 	cjne	r7,#0x00,00109$
      008AE8 BE 7C 06         [24] 1891 	cjne	r6,#0x7c,00109$
                                   1892 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008AEB 12 38 75         [24] 1893 	lcall	_ak820_outline_0153
      008AEE 74 FF            [12] 1894 	mov	a,#0xff
      008AF0 F0               [24] 1895 	movx	@dptr,a
      008AF1                       1896 00109$:
                                   1897 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008AF1 90 0B 26         [24] 1898 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008AF4 74 01            [12] 1899 	mov	a,#0x01
      008AF6 F0               [24] 1900 	movx	@dptr,a
      008AF7                       1901 00111$:
                                   1902 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008AF7 90 0B 24         [24] 1903 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008AFA 12 38 00         [24] 1904 	lcall	_ak820_outline_0051
      008AFD E5 2D            [12] 1905 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008AFF 2E               [12] 1906 	add	a, r6
      008B00 FE               [12] 1907 	mov	r6,a
      008B01 E5 2E            [12] 1908 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008B03 3F               [12] 1909 	addc	a, r7
      008B04 EE               [12] 1910 	mov	a,r6
      008B05 30 E0 5A         [24] 1911 	jnb	acc.0,00115$
                                   1912 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008B08 AE 31            [24] 1913 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008B0A 7F 00            [12] 1914 	mov	r7,#0x00
      008B0C EE               [12] 1915 	mov	a,r6
      008B0D 24 FF            [12] 1916 	add	a,#0xff
      008B0F FC               [12] 1917 	mov	r4,a
      008B10 EF               [12] 1918 	mov	a,r7
      008B11 34 FF            [12] 1919 	addc	a,#0xff
      008B13 FD               [12] 1920 	mov	r5,a
      008B14 EC               [12] 1921 	mov	a,r4
      008B15 28               [12] 1922 	add	a, r0
      008B16 F5 82            [12] 1923 	mov	dpl,a
      008B18 ED               [12] 1924 	mov	a,r5
      008B19 39               [12] 1925 	addc	a, r1
      008B1A F5 83            [12] 1926 	mov	dph,a
      008B1C E0               [24] 1927 	movx	a,@dptr
      008B1D FC               [12] 1928 	mov	r4,a
      008B1E 7D 00            [12] 1929 	mov	r5,#0x00
      008B20 E5 31            [12] 1930 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008B22 2A               [12] 1931 	add	a, r2
      008B23 FA               [12] 1932 	mov	r2,a
      008B24 E4               [12] 1933 	clr	a
      008B25 3B               [12] 1934 	addc	a, r3
      008B26 FB               [12] 1935 	mov	r3,a
      008B27 C0 00            [24] 1936 	push	ar0
      008B29 C0 01            [24] 1937 	push	ar1
      008B2B 8B 01            [24] 1938 	mov	ar1,r3
      008B2D 7B 00            [12] 1939 	mov	r3,#0x00
      008B2F 8A 82            [24] 1940 	mov	dpl, r2
      008B31 89 83            [24] 1941 	mov	dph, r1
      008B33 8B F0            [24] 1942 	mov	b, r3
      008B35 12 40 AA         [24] 1943 	lcall	_eeprom_read_byte
      008B38 AB 82            [24] 1944 	mov	r3, dpl
      008B3A 7A 00            [12] 1945 	mov	r2,#0x00
      008B3C EB               [12] 1946 	mov	a,r3
      008B3D 12 43 A8         [24] 1947 	lcall	_ak820_outline_0140
                                   1948 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008B40 BD 00 05         [24] 1949 	cjne	r5,#0x00,00212$
      008B43 BC 7C 02         [24] 1950 	cjne	r4,#0x7c,00212$
      008B46 80 06            [24] 1951 	sjmp	00213$
      008B48                       1952 00212$:
      008B48 D0 01            [24] 1953 	pop	ar1
      008B4A D0 00            [24] 1954 	pop	ar0
      008B4C 80 0D            [24] 1955 	sjmp	00113$
      008B4E                       1956 00213$:
      008B4E D0 01            [24] 1957 	pop	ar1
      008B50 D0 00            [24] 1958 	pop	ar0
                                   1959 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008B52 1E               [12] 1960 	dec	r6
      008B53 BE FF 01         [24] 1961 	cjne	r6,#0xff,00214$
      008B56 1F               [12] 1962 	dec	r7
      008B57                       1963 00214$:
      008B57 EE               [12] 1964 	mov	a,r6
      008B58 12 90 02         [24] 1965 	lcall	_ak820_outline_0128
      008B5B                       1966 00113$:
                                   1967 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008B5B E5 31            [12] 1968 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008B5D 14               [12] 1969 	dec	a
      008B5E 90 0B 27         [24] 1970 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008B61 F0               [24] 1971 	movx	@dptr,a
      008B62                       1972 00115$:
                                   1973 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008B62 90 0B 26         [24] 1974 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008B65 E0               [24] 1975 	movx	a,@dptr
      008B66 90 0B 28         [24] 1976 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008B69 F0               [24] 1977 	movx	@dptr,a
      008B6A                       1978 00122$:
      008B6A 90 0B 28         [24] 1979 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008B6D E0               [24] 1980 	movx	a,@dptr
      008B6E FF               [12] 1981 	mov	r7,a
      008B6F 90 0B 27         [24] 1982 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008B72 E0               [24] 1983 	movx	a,@dptr
      008B73 FE               [12] 1984 	mov	r6,a
      008B74 C3               [12] 1985 	clr	c
      008B75 EF               [12] 1986 	mov	a,r7
      008B76 9E               [12] 1987 	subb	a,r6
      008B77 50 48            [24] 1988 	jnc	00120$
                                   1989 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008B79 EF               [12] 1990 	mov	a,r7
      008B7A 28               [12] 1991 	add	a, r0
      008B7B FD               [12] 1992 	mov	r5,a
      008B7C E4               [12] 1993 	clr	a
      008B7D 39               [12] 1994 	addc	a, r1
      008B7E FE               [12] 1995 	mov	r6,a
      008B7F 12 49 9C         [24] 1996 	lcall	_ak820_outline_0075
      008B82 7B 00            [12] 1997 	mov	r3,#0x00
      008B84 8C 2E            [24] 1998 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008B86 8B 2D            [24] 1999 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008B88 8F 02            [24] 2000 	mov	ar2,r7
      008B8A 7F 00            [12] 2001 	mov	r7,#0x00
      008B8C 74 01            [12] 2002 	mov	a,#0x01
      008B8E 2A               [12] 2003 	add	a, r2
      008B8F FB               [12] 2004 	mov	r3,a
      008B90 E4               [12] 2005 	clr	a
      008B91 3F               [12] 2006 	addc	a, r7
      008B92 FC               [12] 2007 	mov	r4,a
      008B93 EB               [12] 2008 	mov	a,r3
      008B94 28               [12] 2009 	add	a, r0
      008B95 F5 82            [12] 2010 	mov	dpl,a
      008B97 EC               [12] 2011 	mov	a,r4
      008B98 39               [12] 2012 	addc	a, r1
      008B99 F5 83            [12] 2013 	mov	dph,a
      008B9B E0               [24] 2014 	movx	a,@dptr
      008B9C FC               [12] 2015 	mov	r4,a
      008B9D 7B 00            [12] 2016 	mov	r3,#0x00
      008B9F E5 2E            [12] 2017 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008BA1 42 03            [12] 2018 	orl	ar3,a
                                   2019 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008BA3 BC 00 12         [24] 2020 	cjne	r4,#0x00,00123$
      008BA6 BB 7C 0F         [24] 2021 	cjne	r3,#0x7c,00123$
                                   2022 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008BA9 12 38 6A         [24] 2023 	lcall	_ak820_outline_0133
      008BAC 74 FF            [12] 2024 	mov	a,#0xff
      008BAE F0               [24] 2025 	movx	@dptr,a
                                   2026 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008BAF 0A               [12] 2027 	inc	r2
      008BB0 BA 00 01         [24] 2028 	cjne	r2,#0x00,00218$
      008BB3 0F               [12] 2029 	inc	r7
      008BB4                       2030 00218$:
      008BB4 EA               [12] 2031 	mov	a,r2
      008BB5 12 90 02         [24] 2032 	lcall	_ak820_outline_0128
      008BB8                       2033 00123$:
                                   2034 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008BB8 90 0B 28         [24] 2035 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008BBB E0               [24] 2036 	movx	a,@dptr
      008BBC 24 02            [12] 2037 	add	a,#0x02
      008BBE F0               [24] 2038 	movx	@dptr,a
      008BBF 80 A9            [24] 2039 	sjmp	00122$
      008BC1                       2040 00120$:
                                   2041 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008BC1 90 0B 24         [24] 2042 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008BC4 12 38 00         [24] 2043 	lcall	_ak820_outline_0051
      008BC7 74 40            [12] 2044 	mov	a,#0x40
      008BC9 12 43 A2         [24] 2045 	lcall	_ak820_outline_0135
      008BCC 90 05 8A         [24] 2046 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008BCF 12 49 96         [24] 2047 	lcall	_ak820_outline_0059
      008BD2 E4               [12] 2048 	clr	a
      008BD3 A3               [24] 2049 	inc	dptr
      008BD4 F0               [24] 2050 	movx	@dptr,a
      008BD5 90 05 8D         [24] 2051 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008BD8 E5 2F            [12] 2052 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008BDA F0               [24] 2053 	movx	@dptr,a
      008BDB E5 30            [12] 2054 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008BDD A3               [24] 2055 	inc	dptr
      008BDE F0               [24] 2056 	movx	@dptr,a
      008BDF 12 38 75         [24] 2057 	lcall	_ak820_outline_0153
                                   2058 ;	quantum/dynamic_keymap.c:584: }
      008BE2 02 41 71         [24] 2059 	ljmp	_ak820_eeprom_write_block_xdata
                                   2060 ;------------------------------------------------------------
                                   2061 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2062 ;------------------------------------------------------------
                                   2063 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2064 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2065 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_437'
                                   2066 ;------------------------------------------------------------
                                   2067 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2068 ;	-----------------------------------------
                                   2069 ;	 function keycode_at_keymap_location
                                   2070 ;	-----------------------------------------
      008BE5                       2071 _keycode_at_keymap_location:
      008BE5 E5 82            [12] 2072 	mov	a,dpl
      008BE7 90 0B 2B         [24] 2073 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_437
      008BEA F0               [24] 2074 	movx	@dptr,a
                                   2075 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008BEB E0               [24] 2076 	movx	a,@dptr
      008BEC FF               [12] 2077 	mov	r7,a
      008BED BF 06 00         [24] 2078 	cjne	r7,#0x06,00128$
      008BF0                       2079 00128$:
      008BF0 50 23            [24] 2080 	jnc	00102$
      008BF2 90 0B 29         [24] 2081 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008BF5 E0               [24] 2082 	movx	a,@dptr
      008BF6 FE               [12] 2083 	mov	r6,a
      008BF7 BE 10 00         [24] 2084 	cjne	r6,#0x10,00130$
      008BFA                       2085 00130$:
      008BFA 50 19            [24] 2086 	jnc	00102$
      008BFC 90 0B 2A         [24] 2087 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008BFF E0               [24] 2088 	movx	a,@dptr
      008C00 FD               [12] 2089 	mov	r5,a
      008C01 BD 08 00         [24] 2090 	cjne	r5,#0x08,00132$
      008C04                       2091 00132$:
      008C04 50 0F            [24] 2092 	jnc	00102$
                                   2093 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008C06 90 0A DD         [24] 2094 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008C09 EE               [12] 2095 	mov	a,r6
      008C0A F0               [24] 2096 	movx	@dptr,a
      008C0B 90 0A DE         [24] 2097 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008C0E ED               [12] 2098 	mov	a,r5
      008C0F F0               [24] 2099 	movx	@dptr,a
      008C10 8F 82            [24] 2100 	mov	dpl, r7
      008C12 02 85 76         [24] 2101 	ljmp	_dynamic_keymap_get_keycode
      008C15                       2102 00102$:
                                   2103 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008C15 90 00 00         [24] 2104 	mov	dptr,#0x0000
                                   2105 ;	quantum/dynamic_keymap.c:591: }
      008C18 22               [24] 2106 	ret
                                   2107 ;------------------------------------------------------------
                                   2108 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2109 ;------------------------------------------------------------
                                   2110 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2111 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2112 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_441'
                                   2113 ;------------------------------------------------------------
                                   2114 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2115 ;	-----------------------------------------
                                   2116 ;	 function keycode_at_encodermap_location
                                   2117 ;	-----------------------------------------
      008C19                       2118 _keycode_at_encodermap_location:
      008C19 E5 82            [12] 2119 	mov	a,dpl
      008C1B 90 0B 2E         [24] 2120 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_441
      008C1E F0               [24] 2121 	movx	@dptr,a
                                   2122 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008C1F E0               [24] 2123 	movx	a,@dptr
      008C20 FF               [12] 2124 	mov	r7,a
      008C21 BF 06 00         [24] 2125 	cjne	r7,#0x06,00120$
      008C24                       2126 00120$:
      008C24 50 1E            [24] 2127 	jnc	00102$
      008C26 90 0B 2C         [24] 2128 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008C29 E0               [24] 2129 	movx	a,@dptr
      008C2A FE               [12] 2130 	mov	r6,a
      008C2B BE 01 00         [24] 2131 	cjne	r6,#0x01,00122$
      008C2E                       2132 00122$:
      008C2E 50 14            [24] 2133 	jnc	00102$
                                   2134 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008C30 90 0B 2D         [24] 2135 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008C33 E0               [24] 2136 	movx	a,@dptr
      008C34 FE               [12] 2137 	mov	r6,a
      008C35 90 0A E7         [24] 2138 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008C38 E4               [12] 2139 	clr	a
      008C39 F0               [24] 2140 	movx	@dptr,a
      008C3A 90 0A E8         [24] 2141 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008C3D EE               [12] 2142 	mov	a,r6
      008C3E F0               [24] 2143 	movx	@dptr,a
      008C3F 8F 82            [24] 2144 	mov	dpl, r7
      008C41 02 86 37         [24] 2145 	ljmp	_dynamic_keymap_get_encoder
      008C44                       2146 00102$:
                                   2147 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008C44 90 00 00         [24] 2148 	mov	dptr,#0x0000
                                   2149 ;	quantum/dynamic_keymap.c:599: }
      008C47 22               [24] 2150 	ret
                                   2151 ;------------------------------------------------------------
                                   2152 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2153 ;------------------------------------------------------------
                                   2154 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2155 ;	-----------------------------------------
                                   2156 ;	 function dynamic_keymap_macro_get_count
                                   2157 ;	-----------------------------------------
      008C48                       2158 _dynamic_keymap_macro_get_count:
                                   2159 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008C48 75 82 10         [24] 2160 	mov	dpl, #0x10
                                   2161 ;	quantum/dynamic_keymap.c:604: }
      008C4B 22               [24] 2162 	ret
                                   2163 ;------------------------------------------------------------
                                   2164 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2165 ;------------------------------------------------------------
                                   2166 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2167 ;	-----------------------------------------
                                   2168 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2169 ;	-----------------------------------------
      008C4C                       2170 _dynamic_keymap_macro_get_buffer_size:
                                   2171 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008C4C 90 20 00         [24] 2172 	mov	dptr,#0x2000
                                   2173 ;	quantum/dynamic_keymap.c:608: }
      008C4F 22               [24] 2174 	ret
                                   2175 ;------------------------------------------------------------
                                   2176 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2177 ;------------------------------------------------------------
                                   2178 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2179 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2180 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2181 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_449'
                                   2182 ;------------------------------------------------------------
                                   2183 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2184 ;	-----------------------------------------
                                   2185 ;	 function dynamic_keymap_macro_get_buffer
                                   2186 ;	-----------------------------------------
      008C50                       2187 _dynamic_keymap_macro_get_buffer:
      008C50 12 38 43         [24] 2188 	lcall	_ak820_outline_0103
      008C53 90 0B 34         [24] 2189 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008C56 12 38 48         [24] 2190 	lcall	_ak820_outline_0104
                                   2191 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008C59 12 2A DF         [24] 2192 	lcall	_ak820_macro_length
      008C5C 12 43 9D         [24] 2193 	lcall	_ak820_outline_0132
      008C5F 90 0B 34         [24] 2194 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008C62 12 38 1F         [24] 2195 	lcall	_ak820_outline_0060
      008C65 90 0B 2F         [24] 2196 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008C68 E0               [24] 2197 	movx	a,@dptr
      008C69 F5 32            [12] 2198 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008C6B A3               [24] 2199 	inc	dptr
      008C6C E0               [24] 2200 	movx	a,@dptr
      008C6D F5 33            [12] 2201 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008C6F 90 0B 31         [24] 2202 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008C72 12 38 3D         [24] 2203 	lcall	_ak820_outline_0100
      008C75 A3               [24] 2204 	inc	dptr
      008C76 E0               [24] 2205 	movx	a,@dptr
      008C77 FB               [12] 2206 	mov	r3,a
      008C78 90 0B 0C         [24] 2207 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008C7B 12 49 96         [24] 2208 	lcall	_ak820_outline_0059
      008C7E 90 0B 0E         [24] 2209 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008C81 12 38 25         [24] 2210 	lcall	_ak820_outline_0071
      008C84 90 0B 10         [24] 2211 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008C87 E5 32            [12] 2212 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008C89 F0               [24] 2213 	movx	@dptr,a
      008C8A E5 33            [12] 2214 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008C8C A3               [24] 2215 	inc	dptr
      008C8D F0               [24] 2216 	movx	@dptr,a
      008C8E 90 0B 12         [24] 2217 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008C91 E8               [12] 2218 	mov	a,r0
      008C92 F0               [24] 2219 	movx	@dptr,a
      008C93 E9               [12] 2220 	mov	a,r1
      008C94 A3               [24] 2221 	inc	dptr
      008C95 F0               [24] 2222 	movx	@dptr,a
      008C96 EB               [12] 2223 	mov	a,r3
      008C97 A3               [24] 2224 	inc	dptr
      008C98 F0               [24] 2225 	movx	@dptr,a
      008C99 90 08 00         [24] 2226 	mov	dptr,#0x0800
                                   2227 ;	quantum/dynamic_keymap.c:635: }
      008C9C 02 89 60         [24] 2228 	ljmp	_ak820_dynamic_read_buffer
                                   2229 ;------------------------------------------------------------
                                   2230 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2231 ;------------------------------------------------------------
                                   2232 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2233 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2234 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_451'
                                   2235 ;------------------------------------------------------------
                                   2236 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2237 ;	-----------------------------------------
                                   2238 ;	 function dynamic_keymap_macro_set_buffer
                                   2239 ;	-----------------------------------------
      008C9F                       2240 _dynamic_keymap_macro_set_buffer:
      008C9F 12 38 43         [24] 2241 	lcall	_ak820_outline_0103
      008CA2 90 0B 3B         [24] 2242 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008CA5 12 38 48         [24] 2243 	lcall	_ak820_outline_0104
                                   2244 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      008CA8 90 0B 3B         [24] 2245 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008CAB 12 38 00         [24] 2246 	lcall	_ak820_outline_0051
      008CAE 90 0B 36         [24] 2247 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008CB1 12 38 1F         [24] 2248 	lcall	_ak820_outline_0060
      008CB4 90 0B 38         [24] 2249 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008CB7 12 50 14         [24] 2250 	lcall	_ak820_outline_0088
      008CBA 90 05 10         [24] 2251 	mov	dptr,#_ak820_macro_write_PARM_2
      008CBD 12 38 25         [24] 2252 	lcall	_ak820_outline_0071
      008CC0 90 05 12         [24] 2253 	mov	dptr,#_ak820_macro_write_PARM_3
      008CC3 E9               [12] 2254 	mov	a,r1
      008CC4 12 50 2D         [24] 2255 	lcall	_ak820_outline_0152
      008CC7 12 43 6D         [24] 2256 	lcall	_ak820_outline_0061
                                   2257 ;	quantum/dynamic_keymap.c:640: }
      008CCA 02 2A F9         [24] 2258 	ljmp	_ak820_macro_write
                                   2259 ;------------------------------------------------------------
                                   2260 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2261 ;------------------------------------------------------------
                                   2262 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2263 ;	-----------------------------------------
                                   2264 ;	 function dynamic_keymap_macro_reset
                                   2265 ;	-----------------------------------------
      008CCD                       2266 _dynamic_keymap_macro_reset:
                                   2267 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2268 ;	quantum/dynamic_keymap.c:666: }
      008CCD 02 2E 18         [24] 2269 	ljmp	_ak820_macro_reset
                                   2270 ;------------------------------------------------------------
                                   2271 ;Allocation info for local variables in function 'decode_keycode'
                                   2272 ;------------------------------------------------------------
                                   2273 ;kc            Allocated with name '_decode_keycode_kc_10000_455'
                                   2274 ;------------------------------------------------------------
                                   2275 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2276 ;	-----------------------------------------
                                   2277 ;	 function decode_keycode
                                   2278 ;	-----------------------------------------
      008CD0                       2279 _decode_keycode:
      008CD0 12 38 43         [24] 2280 	lcall	_ak820_outline_0103
      008CD3 90 0B 3D         [24] 2281 	mov	dptr,#_decode_keycode_kc_10000_455
      008CD6 12 38 48         [24] 2282 	lcall	_ak820_outline_0104
                                   2283 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      008CD9 90 0B 3D         [24] 2284 	mov	dptr,#_decode_keycode_kc_10000_455
      008CDC 12 37 CB         [24] 2285 	lcall	_ak820_outline_0011
      008CDF C3               [12] 2286 	clr	c
      008CE0 E4               [12] 2287 	clr	a
      008CE1 9C               [12] 2288 	subb	a,r4
      008CE2 74 FF            [12] 2289 	mov	a,#0xff
      008CE4 9D               [12] 2290 	subb	a,r5
      008CE5 50 08            [24] 2291 	jnc	00102$
                                   2292 ;	free result
                                   2293 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      008CE7 8C 05            [24] 2294 	mov	ar5,r4
      008CE9 7C 00            [12] 2295 	mov	r4,#0x00
      008CEB 12 38 60         [24] 2296 	lcall	_ak820_outline_0122
      008CEE 22               [24] 2297 	ret
      008CEF                       2298 00102$:
                                   2299 ;	quantum/dynamic_keymap.c:672: return kc;
      008CEF 12 43 92         [24] 2300 	lcall	_ak820_outline_0116
                                   2301 ;	quantum/dynamic_keymap.c:673: }
      008CF2 22               [24] 2302 	ret
                                   2303 ;------------------------------------------------------------
                                   2304 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2305 ;------------------------------------------------------------
                                   2306 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_458'
                                   2307 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_459'
                                   2308 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_464'
                                   2309 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_465'
                                   2310 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_471'
                                   2311 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_489'
                                   2312 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_493'
                                   2313 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_493'
                                   2314 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_495'
                                   2315 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_497'
                                   2316 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_501'
                                   2317 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_503'
                                   2318 ;------------------------------------------------------------
                                   2319 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2320 ;	-----------------------------------------
                                   2321 ;	 function dynamic_keymap_macro_send
                                   2322 ;	-----------------------------------------
      008CF3                       2323 _dynamic_keymap_macro_send:
      008CF3 E5 82            [12] 2324 	mov	a,dpl
      008CF5 90 0B 3F         [24] 2325 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008CF8 F0               [24] 2326 	movx	@dptr,a
                                   2327 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      008CF9 90 0B 40         [24] 2328 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008CFC E0               [24] 2329 	movx	a,@dptr
      008CFD 60 01            [24] 2330 	jz	00102$
      008CFF 22               [24] 2331 	ret
      008D00                       2332 00102$:
                                   2333 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008D00 90 0B 3F         [24] 2334 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008D03 E0               [24] 2335 	movx	a,@dptr
      008D04 FF               [12] 2336 	mov	r7,a
      008D05 BF 10 00         [24] 2337 	cjne	r7,#0x10,00422$
      008D08                       2338 00422$:
      008D08 40 01            [24] 2339 	jc	00104$
                                   2340 ;	quantum/dynamic_keymap.c:683: return;
      008D0A 22               [24] 2341 	ret
      008D0B                       2342 00104$:
                                   2343 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      008D0B C0 07            [24] 2344 	push	ar7
      008D0D 12 2A A6         [24] 2345 	lcall	_ak820_macro_ready
      008D10 E5 82            [12] 2346 	mov	a, dpl
      008D12 D0 07            [24] 2347 	pop	ar7
      008D14 70 01            [24] 2348 	jnz	00106$
      008D16 22               [24] 2349 	ret
      008D17                       2350 00106$:
                                   2351 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008D17 90 0B 41         [24] 2352 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008D1A E4               [12] 2353 	clr	a
      008D1B F0               [24] 2354 	movx	@dptr,a
      008D1C 74 08            [12] 2355 	mov	a,#0x08
      008D1E A3               [24] 2356 	inc	dptr
      008D1F F0               [24] 2357 	movx	@dptr,a
                                   2358 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008D20 C0 07            [24] 2359 	push	ar7
      008D22 12 2A DF         [24] 2360 	lcall	_ak820_macro_length
      008D25 AD 82            [24] 2361 	mov	r5, dpl
      008D27 AE 83            [24] 2362 	mov	r6, dph
      008D29 D0 07            [24] 2363 	pop	ar7
      008D2B 74 08            [12] 2364 	mov	a,#0x08
      008D2D 2E               [12] 2365 	add	a, r6
      008D2E FE               [12] 2366 	mov	r6,a
                                   2367 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      008D2F 7B 00            [12] 2368 	mov	r3,#0x00
      008D31 7C 08            [12] 2369 	mov	r4,#0x08
      008D33                       2370 00111$:
      008D33 EF               [12] 2371 	mov	a,r7
      008D34 60 31            [24] 2372 	jz	00113$
                                   2373 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008D36 EB               [12] 2374 	mov	a,r3
      008D37 B5 05 05         [24] 2375 	cjne	a,ar5,00108$
      008D3A EC               [12] 2376 	mov	a,r4
      008D3B B5 06 01         [24] 2377 	cjne	a,ar6,00108$
                                   2378 ;	quantum/dynamic_keymap.c:717: return;
      008D3E 22               [24] 2379 	ret
      008D3F                       2380 00108$:
                                   2381 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008D3F 8B 01            [24] 2382 	mov	ar1,r3
      008D41 8C 02            [24] 2383 	mov	ar2,r4
      008D43 8A 00            [24] 2384 	mov	ar0,r2
      008D45 7A 00            [12] 2385 	mov	r2,#0x00
      008D47 89 82            [24] 2386 	mov	dpl, r1
      008D49 88 83            [24] 2387 	mov	dph, r0
      008D4B 8A F0            [24] 2388 	mov	b, r2
      008D4D 12 40 AA         [24] 2389 	lcall	_eeprom_read_byte
      008D50 E5 82            [12] 2390 	mov	a, dpl
      008D52 70 06            [24] 2391 	jnz	00110$
                                   2392 ;	quantum/dynamic_keymap.c:720: --id;
      008D54 1F               [12] 2393 	dec	r7
      008D55 90 0B 3F         [24] 2394 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008D58 EF               [12] 2395 	mov	a,r7
      008D59 F0               [24] 2396 	movx	@dptr,a
      008D5A                       2397 00110$:
                                   2398 ;	quantum/dynamic_keymap.c:722: ++p;
      008D5A 0B               [12] 2399 	inc	r3
      008D5B BB 00 01         [24] 2400 	cjne	r3,#0x00,00429$
      008D5E 0C               [12] 2401 	inc	r4
      008D5F                       2402 00429$:
      008D5F 90 0B 41         [24] 2403 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008D62 12 38 2B         [24] 2404 	lcall	_ak820_outline_0077
      008D65 80 CC            [24] 2405 	sjmp	00111$
      008D67                       2406 00113$:
                                   2407 ;	quantum/dynamic_keymap.c:728: sending = true;
      008D67 90 0B 40         [24] 2408 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008D6A 74 01            [12] 2409 	mov	a,#0x01
      008D6C F0               [24] 2410 	movx	@dptr,a
                                   2411 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      008D6D 12 90 1A         [24] 2412 	lcall	_ak820_outline_0161
      008D70 90 09 89         [24] 2413 	mov	dptr,#_ak820_macro_cancelled
      008D73 F0               [24] 2414 	movx	@dptr,a
                                   2415 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      008D74 90 0B 43         [24] 2416 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008D77 F0               [24] 2417 	movx	@dptr,a
      008D78 90 0B 44         [24] 2418 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008D7B F0               [24] 2419 	movx	@dptr,a
      008D7C 90 0B 45         [24] 2420 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008D7F F0               [24] 2421 	movx	@dptr,a
      008D80 90 0B 46         [24] 2422 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008D83 F0               [24] 2423 	movx	@dptr,a
                                   2424 ;	quantum/dynamic_keymap.c:738: while (p < end
      008D84                       2425 00167$:
                                   2426 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      008D84 90 0B 41         [24] 2427 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008D87 E0               [24] 2428 	movx	a,@dptr
      008D88 FC               [12] 2429 	mov	r4,a
      008D89 A3               [24] 2430 	inc	dptr
      008D8A E0               [24] 2431 	movx	a,@dptr
      008D8B FF               [12] 2432 	mov	r7,a
      008D8C C3               [12] 2433 	clr	c
      008D8D EC               [12] 2434 	mov	a,r4
      008D8E 9D               [12] 2435 	subb	a,r5
      008D8F EF               [12] 2436 	mov	a,r7
      008D90 9E               [12] 2437 	subb	a,r6
      008D91 40 03            [24] 2438 	jc	00430$
      008D93 02 8F A8         [24] 2439 	ljmp	00169$
      008D96                       2440 00430$:
      008D96 90 09 89         [24] 2441 	mov	dptr,#_ak820_macro_cancelled
      008D99 E0               [24] 2442 	movx	a,@dptr
      008D9A 60 03            [24] 2443 	jz	00431$
      008D9C 02 8F A8         [24] 2444 	ljmp	00169$
      008D9F                       2445 00431$:
                                   2446 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008D9F 8C 02            [24] 2447 	mov	ar2,r4
      008DA1 8F 03            [24] 2448 	mov	ar3,r7
      008DA3 90 0B 41         [24] 2449 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008DA6 74 01            [12] 2450 	mov	a,#0x01
      008DA8 2C               [12] 2451 	add	a, r4
      008DA9 F0               [24] 2452 	movx	@dptr,a
      008DAA E4               [12] 2453 	clr	a
      008DAB 3F               [12] 2454 	addc	a, r7
      008DAC A3               [24] 2455 	inc	dptr
      008DAD F0               [24] 2456 	movx	@dptr,a
      008DAE 7F 00            [12] 2457 	mov	r7,#0x00
      008DB0 12 43 AE         [24] 2458 	lcall	_ak820_outline_0141
      008DB3 8F F0            [24] 2459 	mov	b, r7
      008DB5 12 40 AA         [24] 2460 	lcall	_eeprom_read_byte
      008DB8 AF 82            [24] 2461 	mov	r7, dpl
      008DBA 90 0B 43         [24] 2462 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008DBD EF               [12] 2463 	mov	a,r7
      008DBE F0               [24] 2464 	movx	@dptr,a
                                   2465 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      008DBF 90 0B 44         [24] 2466 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008DC2 E4               [12] 2467 	clr	a
      008DC3 F0               [24] 2468 	movx	@dptr,a
                                   2469 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      008DC4 90 0B 43         [24] 2470 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008DC7 E0               [24] 2471 	movx	a,@dptr
      008DC8 70 03            [24] 2472 	jnz	00432$
      008DCA 02 8F A8         [24] 2473 	ljmp	00169$
      008DCD                       2474 00432$:
                                   2475 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      008DCD 90 0B 43         [24] 2476 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008DD0 E0               [24] 2477 	movx	a,@dptr
      008DD1 FF               [12] 2478 	mov	r7,a
      008DD2 BF 01 02         [24] 2479 	cjne	r7,#0x01,00433$
      008DD5 80 03            [24] 2480 	sjmp	00434$
      008DD7                       2481 00433$:
      008DD7 02 8F 8A         [24] 2482 	ljmp	00164$
      008DDA                       2483 00434$:
                                   2484 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008DDA 12 8F B0         [24] 2485 	lcall	_ak820_outline_0000
      008DDD 12 40 AA         [24] 2486 	lcall	_eeprom_read_byte
      008DE0 AF 82            [24] 2487 	mov	r7, dpl
      008DE2 90 0B 44         [24] 2488 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008DE5 EF               [12] 2489 	mov	a,r7
      008DE6 F0               [24] 2490 	movx	@dptr,a
                                   2491 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      008DE7 EF               [12] 2492 	mov	a,r7
      008DE8 70 03            [24] 2493 	jnz	00435$
      008DEA 02 8F A8         [24] 2494 	ljmp	00169$
      008DED                       2495 00435$:
                                   2496 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008DED 12 8F E8         [24] 2497 	lcall	_ak820_outline_0090
      008DF0 BF 01 02         [24] 2498 	cjne	r7,#0x01,00436$
      008DF3 80 13            [24] 2499 	sjmp	00151$
      008DF5                       2500 00436$:
      008DF5 12 8F E8         [24] 2501 	lcall	_ak820_outline_0090
      008DF8 BF 02 02         [24] 2502 	cjne	r7,#0x02,00437$
      008DFB 80 0B            [24] 2503 	sjmp	00151$
      008DFD                       2504 00437$:
      008DFD 12 8F E8         [24] 2505 	lcall	_ak820_outline_0090
      008E00 BF 03 02         [24] 2506 	cjne	r7,#0x03,00438$
      008E03 80 03            [24] 2507 	sjmp	00439$
      008E05                       2508 00438$:
      008E05 02 8E 69         [24] 2509 	ljmp	00152$
      008E08                       2510 00439$:
      008E08                       2511 00151$:
                                   2512 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E08 12 8F B0         [24] 2513 	lcall	_ak820_outline_0000
      008E0B 12 40 AA         [24] 2514 	lcall	_eeprom_read_byte
      008E0E 12 90 32         [24] 2515 	lcall	_ak820_outline_0178
                                   2516 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      008E11 70 03            [24] 2517 	jnz	00440$
      008E13 02 8D 84         [24] 2518 	ljmp	00167$
      008E16                       2519 00440$:
                                   2520 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008E16 12 8F E8         [24] 2521 	lcall	_ak820_outline_0090
      008E19 BF 01 03         [24] 2522 	cjne	r7,#0x01,00441$
      008E1C D3               [12] 2523 	setb	c
      008E1D 80 01            [24] 2524 	sjmp	00442$
      008E1F                       2525 00441$:
      008E1F C3               [12] 2526 	clr	c
      008E20                       2527 00442$:
      008E20 92 24            [24] 2528 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008E22 90 09 88         [24] 2529 	mov	dptr,#_ak820_macro_primitive
      008E25 B3               [12] 2530 	cpl	c
      008E26 E4               [12] 2531 	clr	a
      008E27 33               [12] 2532 	rlc	a
      008E28 F0               [24] 2533 	movx	@dptr,a
                                   2534 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008E29 12 8F E8         [24] 2535 	lcall	_ak820_outline_0090
      008E2C BF 01 10         [24] 2536 	cjne	r7,#0x01,00122$
      008E2F 12 90 13         [24] 2537 	lcall	_ak820_outline_0148
      008E32 C0 06            [24] 2538 	push	ar6
      008E34 C0 05            [24] 2539 	push	ar5
      008E36 12 77 7F         [24] 2540 	lcall	_tap_code
      008E39 D0 05            [24] 2541 	pop	ar5
      008E3B D0 06            [24] 2542 	pop	ar6
      008E3D 80 24            [24] 2543 	sjmp	00123$
      008E3F                       2544 00122$:
                                   2545 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008E3F 12 8F E8         [24] 2546 	lcall	_ak820_outline_0090
      008E42 BF 02 10         [24] 2547 	cjne	r7,#0x02,00119$
      008E45 12 90 13         [24] 2548 	lcall	_ak820_outline_0148
      008E48 C0 06            [24] 2549 	push	ar6
      008E4A C0 05            [24] 2550 	push	ar5
      008E4C 12 76 79         [24] 2551 	lcall	_register_code
      008E4F D0 05            [24] 2552 	pop	ar5
      008E51 D0 06            [24] 2553 	pop	ar6
      008E53 80 0E            [24] 2554 	sjmp	00123$
      008E55                       2555 00119$:
                                   2556 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      008E55 12 90 13         [24] 2557 	lcall	_ak820_outline_0148
      008E58 C0 06            [24] 2558 	push	ar6
      008E5A C0 05            [24] 2559 	push	ar5
      008E5C 12 76 E6         [24] 2560 	lcall	_unregister_code
      008E5F D0 05            [24] 2561 	pop	ar5
      008E61 D0 06            [24] 2562 	pop	ar6
      008E63                       2563 00123$:
                                   2564 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      008E63 12 90 1A         [24] 2565 	lcall	_ak820_outline_0161
      008E66 02 8D 84         [24] 2566 	ljmp	00167$
      008E69                       2567 00152$:
                                   2568 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008E69 12 8F E8         [24] 2569 	lcall	_ak820_outline_0090
      008E6C BF 05 02         [24] 2570 	cjne	r7,#0x05,00447$
      008E6F 80 13            [24] 2571 	sjmp	00146$
      008E71                       2572 00447$:
      008E71 12 8F E8         [24] 2573 	lcall	_ak820_outline_0090
      008E74 BF 06 02         [24] 2574 	cjne	r7,#0x06,00448$
      008E77 80 0B            [24] 2575 	sjmp	00146$
      008E79                       2576 00448$:
      008E79 12 8F E8         [24] 2577 	lcall	_ak820_outline_0090
      008E7C BF 07 02         [24] 2578 	cjne	r7,#0x07,00449$
      008E7F 80 03            [24] 2579 	sjmp	00450$
      008E81                       2580 00449$:
      008E81 02 8F 2A         [24] 2581 	ljmp	00147$
      008E84                       2582 00450$:
      008E84                       2583 00146$:
                                   2584 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E84 12 8F B0         [24] 2585 	lcall	_ak820_outline_0000
      008E87 12 40 AA         [24] 2586 	lcall	_eeprom_read_byte
      008E8A 12 90 32         [24] 2587 	lcall	_ak820_outline_0178
                                   2588 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      008E8D 70 03            [24] 2589 	jnz	00451$
      008E8F 02 8D 84         [24] 2590 	ljmp	00167$
      008E92                       2591 00451$:
                                   2592 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E92 12 8F B0         [24] 2593 	lcall	_ak820_outline_0000
      008E95 12 40 AA         [24] 2594 	lcall	_eeprom_read_byte
      008E98 AF 82            [24] 2595 	mov	r7, dpl
      008E9A 90 0B 46         [24] 2596 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008E9D EF               [12] 2597 	mov	a,r7
      008E9E F0               [24] 2598 	movx	@dptr,a
                                   2599 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      008E9F EF               [12] 2600 	mov	a,r7
      008EA0 70 03            [24] 2601 	jnz	00452$
      008EA2 02 8D 84         [24] 2602 	ljmp	00167$
      008EA5                       2603 00452$:
                                   2604 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008EA5 90 0B 45         [24] 2605 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008EA8 E0               [24] 2606 	movx	a,@dptr
      008EA9 FF               [12] 2607 	mov	r7,a
      008EAA 90 0B 46         [24] 2608 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008EAD E0               [24] 2609 	movx	a,@dptr
      008EAE FB               [12] 2610 	mov	r3,a
      008EAF E4               [12] 2611 	clr	a
      008EB0 FC               [12] 2612 	mov	r4,a
      008EB1 FA               [12] 2613 	mov	r2,a
      008EB2 EF               [12] 2614 	mov	a,r7
      008EB3 42 04            [12] 2615 	orl	ar4,a
      008EB5 EA               [12] 2616 	mov	a,r2
      008EB6 42 03            [12] 2617 	orl	ar3,a
                                   2618 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      008EB8 12 43 CE         [24] 2619 	lcall	_ak820_outline_0181
      008EBB C0 06            [24] 2620 	push	ar6
      008EBD C0 05            [24] 2621 	push	ar5
      008EBF 12 8C D0         [24] 2622 	lcall	_decode_keycode
      008EC2 AC 82            [24] 2623 	mov	r4, dpl
      008EC4 AF 83            [24] 2624 	mov	r7, dph
      008EC6 D0 05            [24] 2625 	pop	ar5
      008EC8 D0 06            [24] 2626 	pop	ar6
                                   2627 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008ECA 90 0B 44         [24] 2628 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008ECD E0               [24] 2629 	movx	a,@dptr
      008ECE FB               [12] 2630 	mov	r3,a
      008ECF BB 05 03         [24] 2631 	cjne	r3,#0x05,00453$
      008ED2 D3               [12] 2632 	setb	c
      008ED3 80 01            [24] 2633 	sjmp	00454$
      008ED5                       2634 00453$:
      008ED5 C3               [12] 2635 	clr	c
      008ED6                       2636 00454$:
      008ED6 92 24            [24] 2637 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008ED8 90 09 88         [24] 2638 	mov	dptr,#_ak820_macro_primitive
      008EDB B3               [12] 2639 	cpl	c
      008EDC E4               [12] 2640 	clr	a
      008EDD 33               [12] 2641 	rlc	a
      008EDE F0               [24] 2642 	movx	@dptr,a
                                   2643 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      008EDF 90 0B 44         [24] 2644 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008EE2 E0               [24] 2645 	movx	a,@dptr
      008EE3 FB               [12] 2646 	mov	r3,a
      008EE4 BB 05 02         [24] 2647 	cjne	r3,#0x05,00455$
      008EE7 80 0A            [24] 2648 	sjmp	00126$
      008EE9                       2649 00455$:
      008EE9 BB 06 02         [24] 2650 	cjne	r3,#0x06,00456$
      008EEC 80 16            [24] 2651 	sjmp	00127$
      008EEE                       2652 00456$:
                                   2653 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      008EEE BB 07 33         [24] 2654 	cjne	r3,#0x07,00129$
      008EF1 80 22            [24] 2655 	sjmp	00128$
      008EF3                       2656 00126$:
                                   2657 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      008EF3 8C 82            [24] 2658 	mov	dpl, r4
      008EF5 8F 83            [24] 2659 	mov	dph, r7
      008EF7 C0 06            [24] 2660 	push	ar6
      008EF9 C0 05            [24] 2661 	push	ar5
      008EFB 12 B2 9D         [24] 2662 	lcall	_vial_keycode_tap
      008EFE D0 05            [24] 2663 	pop	ar5
      008F00 D0 06            [24] 2664 	pop	ar6
                                   2665 ;	quantum/dynamic_keymap.c:795: break;
                                   2666 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      008F02 80 20            [24] 2667 	sjmp	00129$
      008F04                       2668 00127$:
                                   2669 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      008F04 8C 82            [24] 2670 	mov	dpl, r4
      008F06 8F 83            [24] 2671 	mov	dph, r7
      008F08 C0 06            [24] 2672 	push	ar6
      008F0A C0 05            [24] 2673 	push	ar5
      008F0C 12 B1 D2         [24] 2674 	lcall	_vial_keycode_down
      008F0F D0 05            [24] 2675 	pop	ar5
      008F11 D0 06            [24] 2676 	pop	ar6
                                   2677 ;	quantum/dynamic_keymap.c:798: break;
                                   2678 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      008F13 80 0F            [24] 2679 	sjmp	00129$
      008F15                       2680 00128$:
                                   2681 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      008F15 8C 82            [24] 2682 	mov	dpl, r4
      008F17 8F 83            [24] 2683 	mov	dph, r7
      008F19 C0 06            [24] 2684 	push	ar6
      008F1B C0 05            [24] 2685 	push	ar5
      008F1D 12 B2 38         [24] 2686 	lcall	_vial_keycode_up
      008F20 D0 05            [24] 2687 	pop	ar5
      008F22 D0 06            [24] 2688 	pop	ar6
                                   2689 ;	quantum/dynamic_keymap.c:802: }
      008F24                       2690 00129$:
                                   2691 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      008F24 12 90 1A         [24] 2692 	lcall	_ak820_outline_0161
      008F27 02 8D 84         [24] 2693 	ljmp	00167$
      008F2A                       2694 00147$:
                                   2695 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      008F2A 12 8F E8         [24] 2696 	lcall	_ak820_outline_0090
      008F2D BF 04 02         [24] 2697 	cjne	r7,#0x04,00458$
      008F30 80 03            [24] 2698 	sjmp	00459$
      008F32                       2699 00458$:
      008F32 02 8D 84         [24] 2700 	ljmp	00167$
      008F35                       2701 00459$:
                                   2702 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F35 12 8F B0         [24] 2703 	lcall	_ak820_outline_0000
      008F38 12 40 AA         [24] 2704 	lcall	_eeprom_read_byte
      008F3B AF 82            [24] 2705 	mov	r7, dpl
                                   2706 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F3D 90 0B 41         [24] 2707 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008F40 12 38 5A         [24] 2708 	lcall	_ak820_outline_0121
      008F43 90 0B 41         [24] 2709 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008F46 74 01            [12] 2710 	mov	a,#0x01
      008F48 2B               [12] 2711 	add	a, r3
      008F49 F0               [24] 2712 	movx	@dptr,a
      008F4A E4               [12] 2713 	clr	a
      008F4B 3C               [12] 2714 	addc	a, r4
      008F4C A3               [24] 2715 	inc	dptr
      008F4D F0               [24] 2716 	movx	@dptr,a
      008F4E 7A 00            [12] 2717 	mov	r2,#0x00
      008F50 12 33 FC         [24] 2718 	lcall	_ak820_outline_0123
      008F53 8A F0            [24] 2719 	mov	b, r2
      008F55 12 40 AA         [24] 2720 	lcall	_eeprom_read_byte
      008F58 AC 82            [24] 2721 	mov	r4, dpl
                                   2722 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      008F5A EF               [12] 2723 	mov	a,r7
      008F5B 60 4B            [24] 2724 	jz	00169$
      008F5D EC               [12] 2725 	mov	a,r4
      008F5E 60 48            [24] 2726 	jz	00169$
                                   2727 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008F60 1F               [12] 2728 	dec	r7
      008F61 1C               [12] 2729 	dec	r4
      008F62 EC               [12] 2730 	mov	a,r4
      008F63 75 F0 FF         [24] 2731 	mov	b,#0xff
      008F66 A4               [48] 2732 	mul	ab
      008F67 FC               [12] 2733 	mov	r4,a
      008F68 AB F0            [24] 2734 	mov	r3,b
      008F6A 7A 00            [12] 2735 	mov	r2,#0x00
      008F6C EC               [12] 2736 	mov	a,r4
      008F6D 2F               [12] 2737 	add	a, r7
      008F6E FC               [12] 2738 	mov	r4,a
      008F6F EB               [12] 2739 	mov	a,r3
      008F70 3A               [12] 2740 	addc	a, r2
      008F71 FB               [12] 2741 	mov	r3,a
                                   2742 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      008F72                       2743 00141$:
      008F72 8C 02            [24] 2744 	mov	ar2,r4
      008F74 8B 07            [24] 2745 	mov	ar7,r3
      008F76 1C               [12] 2746 	dec	r4
      008F77 BC FF 01         [24] 2747 	cjne	r4,#0xff,00462$
      008F7A 1B               [12] 2748 	dec	r3
      008F7B                       2749 00462$:
      008F7B EA               [12] 2750 	mov	a,r2
      008F7C 4F               [12] 2751 	orl	a,r7
      008F7D 70 03            [24] 2752 	jnz	00463$
      008F7F 02 8D 84         [24] 2753 	ljmp	00167$
      008F82                       2754 00463$:
      008F82 90 00 01         [24] 2755 	mov	dptr,#0x0001
      008F85 12 59 B5         [24] 2756 	lcall	_mDelaymS
      008F88 80 E8            [24] 2757 	sjmp	00141$
      008F8A                       2758 00164$:
                                   2759 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      008F8A 90 0B 43         [24] 2760 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008F8D E0               [24] 2761 	movx	a,@dptr
      008F8E FF               [12] 2762 	mov	r7,a
      008F8F BF 80 00         [24] 2763 	cjne	r7,#0x80,00464$
      008F92                       2764 00464$:
      008F92 50 14            [24] 2765 	jnc	00169$
                                   2766 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      008F94 90 0B 43         [24] 2767 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008F97 E0               [24] 2768 	movx	a,@dptr
      008F98 F5 82            [12] 2769 	mov	dpl,a
      008F9A C0 06            [24] 2770 	push	ar6
      008F9C C0 05            [24] 2771 	push	ar5
      008F9E 12 A5 3A         [24] 2772 	lcall	_send_char
      008FA1 D0 05            [24] 2773 	pop	ar5
      008FA3 D0 06            [24] 2774 	pop	ar6
                                   2775 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008FA5 02 8D 84         [24] 2776 	ljmp	00167$
      008FA8                       2777 00169$:
                                   2778 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      008FA8 12 90 1A         [24] 2779 	lcall	_ak820_outline_0161
                                   2780 ;	quantum/dynamic_keymap.c:837: sending = false;
      008FAB 90 0B 40         [24] 2781 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008FAE F0               [24] 2782 	movx	@dptr,a
                                   2783 ;	quantum/dynamic_keymap.c:839: }
      008FAF 22               [24] 2784 	ret
                                   2785 	.area CSEG    (CODE)
                                   2786 	.area CONST   (CODE)
                                   2787 	.area XINIT   (CODE)
                                   2788 	.area CABS    (ABS,CODE)
                                   2789 
                                   2790 ; Experimental exact instruction outlining.
                                   2791 	.globl _ak820_outline_0000
                                   2792 	.globl _ak820_outline_0004
                                   2793 	.globl _ak820_outline_0011
                                   2794 	.globl _ak820_outline_0012
                                   2795 	.globl _ak820_outline_0017
                                   2796 	.globl _ak820_outline_0025
                                   2797 	.globl _ak820_outline_0031
                                   2798 	.globl _ak820_outline_0044
                                   2799 	.globl _ak820_outline_0051
                                   2800 	.globl _ak820_outline_0059
                                   2801 	.globl _ak820_outline_0060
                                   2802 	.globl _ak820_outline_0061
                                   2803 	.globl _ak820_outline_0071
                                   2804 	.globl _ak820_outline_0075
                                   2805 	.globl _ak820_outline_0077
                                   2806 	.globl _ak820_outline_0079
                                   2807 	.globl _ak820_outline_0088
                                   2808 	.globl _ak820_outline_0090
                                   2809 	.globl _ak820_outline_0096
                                   2810 	.globl _ak820_outline_0097
                                   2811 	.globl _ak820_outline_0100
                                   2812 	.globl _ak820_outline_0103
                                   2813 	.globl _ak820_outline_0104
                                   2814 	.globl _ak820_outline_0112
                                   2815 	.globl _ak820_outline_0116
                                   2816 	.globl _ak820_outline_0117
                                   2817 	.globl _ak820_outline_0120
                                   2818 	.globl _ak820_outline_0121
                                   2819 	.globl _ak820_outline_0122
                                   2820 	.globl _ak820_outline_0123
                                   2821 	.globl _ak820_outline_0124
                                   2822 	.globl _ak820_outline_0128
                                   2823 	.globl _ak820_outline_0132
                                   2824 	.globl _ak820_outline_0133
                                   2825 	.globl _ak820_outline_0134
                                   2826 	.globl _ak820_outline_0135
                                   2827 	.globl _ak820_outline_0140
                                   2828 	.globl _ak820_outline_0141
                                   2829 	.globl _ak820_outline_0146
                                   2830 	.globl _ak820_outline_0148
                                   2831 	.globl _ak820_outline_0152
                                   2832 	.globl _ak820_outline_0153
                                   2833 	.globl _ak820_outline_0156
                                   2834 	.globl _ak820_outline_0161
                                   2835 	.globl _ak820_outline_0174
                                   2836 	.globl _ak820_outline_0175
                                   2837 	.globl _ak820_outline_0178
                                   2838 	.globl _ak820_outline_0179
                                   2839 	.globl _ak820_outline_0180
                                   2840 	.globl _ak820_outline_0181
                                   2841 
                                   2842 	.area CSEG (CODE)
                                   2843 ; function ak820_outline_0000
      008FB0                       2844 _ak820_outline_0000:
      008FB0 90 0B 41         [24] 2845 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008FB3 E0               [24] 2846 	movx	a,@dptr
      008FB4 FC               [12] 2847 	mov	r4,a
      008FB5 A3               [24] 2848 	inc	dptr
      008FB6 E0               [24] 2849 	movx	a,@dptr
      008FB7 FF               [12] 2850 	mov	r7,a
      008FB8 90 0B 41         [24] 2851 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008FBB 74 01            [12] 2852 	mov	a,#0x01
      008FBD 2C               [12] 2853 	add	a,r4
      008FBE F0               [24] 2854 	movx	@dptr,a
      008FBF E4               [12] 2855 	clr	a
      008FC0 3F               [12] 2856 	addc	a,r7
      008FC1 A3               [24] 2857 	inc	dptr
      008FC2 F0               [24] 2858 	movx	@dptr,a
      008FC3 7B 00            [12] 2859 	mov	r3,#0x00
      008FC5 8C 82            [24] 2860 	mov	dpl,r4
      008FC7 8F 83            [24] 2861 	mov	dph,r7
      008FC9 8B F0            [24] 2862 	mov	b,r3
      008FCB 22               [24] 2863 	ret
                                   2864 
                                   2865 	.area CSEG (CODE)
                                   2866 ; function ak820_outline_0025
      008FCC                       2867 _ak820_outline_0025:
      008FCC 2D               [12] 2868 	add	a,r5
      008FCD F9               [12] 2869 	mov	r1,a
      008FCE E4               [12] 2870 	clr	a
      008FCF 3E               [12] 2871 	addc	a,r6
      008FD0 FA               [12] 2872 	mov	r2,a
      008FD1 8F 03            [24] 2873 	mov	ar3,r7
      008FD3 89 82            [24] 2874 	mov	dpl,r1
      008FD5 8A 83            [24] 2875 	mov	dph,r2
      008FD7 8B F0            [24] 2876 	mov	b,r3
      008FD9 22               [24] 2877 	ret
                                   2878 
                                   2879 	.area CSEG (CODE)
                                   2880 ; function ak820_outline_0079
      008FDA                       2881 _ak820_outline_0079:
      008FDA ED               [12] 2882 	mov	a,r5
      008FDB 75 F0 0A         [24] 2883 	mov	b,#0x0a
      008FDE A4               [48] 2884 	mul	ab
      008FDF 24 58            [12] 2885 	add	a,#0x58
      008FE1 FC               [12] 2886 	mov	r4,a
      008FE2 74 06            [12] 2887 	mov	a,#0x06
      008FE4 35 F0            [12] 2888 	addc	a,b
      008FE6 FD               [12] 2889 	mov	r5,a
      008FE7 22               [24] 2890 	ret
                                   2891 
                                   2892 	.area CSEG (CODE)
                                   2893 ; function ak820_outline_0090
      008FE8                       2894 _ak820_outline_0090:
      008FE8 90 0B 44         [24] 2895 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0001)
      008FEB E0               [24] 2896 	movx	a,@dptr
      008FEC FF               [12] 2897 	mov	r7,a
      008FED 22               [24] 2898 	ret
                                   2899 
                                   2900 	.area CSEG (CODE)
                                   2901 ; function ak820_outline_0096
      008FEE                       2902 _ak820_outline_0096:
      008FEE 90 0A DA         [24] 2903 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008FF1 EE               [12] 2904 	mov	a,r6
      008FF2 F0               [24] 2905 	movx	@dptr,a
      008FF3 90 0A DB         [24] 2906 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008FF6 ED               [12] 2907 	mov	a,r5
      008FF7 F0               [24] 2908 	movx	@dptr,a
      008FF8 8F 82            [24] 2909 	mov	dpl,r7
      008FFA 22               [24] 2910 	ret
                                   2911 
                                   2912 	.area CSEG (CODE)
                                   2913 ; function ak820_outline_0112
      008FFB                       2914 _ak820_outline_0112:
      008FFB AD 82            [24] 2915 	mov	r5,dpl
      008FFD AE 83            [24] 2916 	mov	r6,dph
      008FFF AF F0            [24] 2917 	mov	r7,b
      009001 22               [24] 2918 	ret
                                   2919 
                                   2920 	.area CSEG (CODE)
                                   2921 ; function ak820_outline_0128
      009002                       2922 _ak820_outline_0128:
      009002 28               [12] 2923 	add	a,r0
      009003 F5 82            [12] 2924 	mov	dpl,a
      009005 EF               [12] 2925 	mov	a,r7
      009006 39               [12] 2926 	addc	a,r1
      009007 F5 83            [12] 2927 	mov	dph,a
      009009 74 FF            [12] 2928 	mov	a,#0xff
      00900B F0               [24] 2929 	movx	@dptr,a
      00900C 22               [24] 2930 	ret
                                   2931 
                                   2932 	.area CSEG (CODE)
                                   2933 ; function ak820_outline_0134
      00900D                       2934 _ak820_outline_0134:
      00900D 2D               [12] 2935 	add	a,r5
      00900E F9               [12] 2936 	mov	r1,a
      00900F E4               [12] 2937 	clr	a
      009010 3E               [12] 2938 	addc	a,r6
      009011 FA               [12] 2939 	mov	r2,a
      009012 22               [24] 2940 	ret
                                   2941 
                                   2942 	.area CSEG (CODE)
                                   2943 ; function ak820_outline_0148
      009013                       2944 _ak820_outline_0148:
      009013 90 0B 45         [24] 2945 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      009016 E0               [24] 2946 	movx	a,@dptr
      009017 F5 82            [12] 2947 	mov	dpl,a
      009019 22               [24] 2948 	ret
                                   2949 
                                   2950 	.area CSEG (CODE)
                                   2951 ; function ak820_outline_0161
      00901A                       2952 _ak820_outline_0161:
      00901A 90 09 88         [24] 2953 	mov	dptr,#_ak820_macro_primitive
      00901D E4               [12] 2954 	clr	a
      00901E F0               [24] 2955 	movx	@dptr,a
      00901F 22               [24] 2956 	ret
                                   2957 
                                   2958 	.area CSEG (CODE)
                                   2959 ; function ak820_outline_0174
      009020                       2960 _ak820_outline_0174:
      009020 90 0A EA         [24] 2961 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      009023 E4               [12] 2962 	clr	a
      009024 F0               [24] 2963 	movx	@dptr,a
      009025 90 0A EB         [24] 2964 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      009028 22               [24] 2965 	ret
                                   2966 
                                   2967 	.area CSEG (CODE)
                                   2968 ; function ak820_outline_0175
      009029                       2969 _ak820_outline_0175:
      009029 90 0B A0         [24] 2970 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      00902C E4               [12] 2971 	clr	a
      00902D F0               [24] 2972 	movx	@dptr,a
      00902E 90 0B A1         [24] 2973 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      009031 22               [24] 2974 	ret
                                   2975 
                                   2976 	.area CSEG (CODE)
                                   2977 ; function ak820_outline_0178
      009032                       2978 _ak820_outline_0178:
      009032 AF 82            [24] 2979 	mov	r7,dpl
      009034 90 0B 45         [24] 2980 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      009037 EF               [12] 2981 	mov	a,r7
      009038 F0               [24] 2982 	movx	@dptr,a
      009039 EF               [12] 2983 	mov	a,r7
      00903A 22               [24] 2984 	ret
