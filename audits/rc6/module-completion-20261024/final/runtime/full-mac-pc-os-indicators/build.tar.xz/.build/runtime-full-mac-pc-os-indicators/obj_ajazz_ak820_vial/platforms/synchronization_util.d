synchronization_util.o: platforms/synchronization_util.c \
 keyboards/ajazz/ak820/config.h \
 .build/runtime-full-mac-pc-os-indicators/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h platforms/synchronization_util.h
