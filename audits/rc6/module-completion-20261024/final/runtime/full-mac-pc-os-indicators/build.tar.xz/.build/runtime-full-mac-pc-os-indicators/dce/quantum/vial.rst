                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000042                        541 _vial_handle_cmd_sloc0_1_0:
      000042                        542 	.ds 2
      000044                        543 _vial_handle_cmd_sloc1_1_0:
      000044                        544 	.ds 2
      000046                        545 _vial_handle_cmd_sloc2_1_0:
      000046                        546 	.ds 2
      000048                        547 _vial_handle_cmd_sloc3_1_0:
      000048                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C32                        573 _vial_unlock_timer:
      000C32                        574 	.ds 4
      000C36                        575 _vial_unlock_holding:
      000C36                        576 	.ds 1
      000C37                        577 _vial_keycode_firewall_in_10000_610:
      000C37                        578 	.ds 2
      000C39                        579 _vial_fill_packet_PARM_2:
      000C39                        580 	.ds 1
      000C3A                        581 _vial_fill_packet_msg_10000_613:
      000C3A                        582 	.ds 2
      000C3C                        583 _vial_handle_cmd_PARM_2:
      000C3C                        584 	.ds 1
      000C3D                        585 _vial_handle_cmd_data_10000_618:
      000C3D                        586 	.ds 3
      000C40                        587 _vial_handle_cmd_entry_70000_646:
      000C40                        588 	.ds 10
      000C4A                        589 _vial_handle_cmd_entry_70000_647:
      000C4A                        590 	.ds 10
      000C54                        591 _g_vial_magic_keycode_override::
      000C54                        592 	.ds 2
      000C56                        593 _vial_keycode_down_keycode_10000_649:
      000C56                        594 	.ds 2
      000C58                        595 _vial_keycode_down_dummy_event_30000_656:
      000C58                        596 	.ds 6
      000C5E                        597 _vial_keycode_up_keycode_10000_657:
      000C5E                        598 	.ds 2
      000C60                        599 _vial_keycode_up_dummy_event_30000_664:
      000C60                        600 	.ds 6
      000C66                        601 _vial_keycode_tap_keycode_10000_665:
      000C66                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000DFC                        611 _vial_unlocked::
      000DFC                        612 	.ds 1
      000DFD                        613 _vial_unlock_in_progress::
      000DFD                        614 	.ds 1
      000DFE                        615 _vial_unlock_counter:
      000DFE                        616 	.ds 1
      000DFF                        617 _vial_unlock_combo_rows:
      000DFF                        618 	.ds 2
      000E01                        619 _vial_unlock_combo_cols:
      000E01                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00AD2B                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00AD2B 90 0D FD         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00AD2E E0               [24]  667 	movx	a,@dptr
      00AD2F 70 01            [24]  668 	jnz	00131$
      00AD31 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AD32                        671 00131$:
      00AD32 7F 00            [12]  672 	mov	r7,#0x00
      00AD34                        673 00115$:
      00AD34 BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00AD37                        675 00184$:
      00AD37 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00AD39 EF               [12]  678 	mov	a,r7
      00AD3A 12 B2 F0         [24]  679 	lcall	_ak820_outline_0127
      00AD3D FE               [12]  680 	mov	r6,a
      00AD3E EF               [12]  681 	mov	a,r7
      00AD3F 12 B2 E5         [24]  682 	lcall	_ak820_outline_0126
      00AD42 90 07 63         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00AD45 F0               [24]  684 	movx	@dptr,a
      00AD46 8E 82            [24]  685 	mov	dpl, r6
      00AD48 C0 07            [24]  686 	push	ar7
      00AD4A 12 5A 27         [24]  687 	lcall	_matrix_is_on
      00AD4D E5 82            [12]  688 	mov	a, dpl
      00AD4F D0 07            [24]  689 	pop	ar7
      00AD51 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00AD53 90 0C 36         [24]  692 	mov	dptr,#_vial_unlock_holding
      00AD56 E4               [12]  693 	clr	a
      00AD57 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AD58 90 0D FE         [24]  696 	mov	dptr,#_vial_unlock_counter
      00AD5B 74 1E            [12]  697 	mov	a,#0x1e
      00AD5D F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00AD5E 22               [24]  700 	ret
      00AD5F                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AD5F 0F               [12]  703 	inc	r7
      00AD60 80 D2            [24]  704 	sjmp	00115$
      00AD62                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00AD62 90 0C 36         [24]  707 	mov	dptr,#_vial_unlock_holding
      00AD65 E0               [24]  708 	movx	a,@dptr
      00AD66 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00AD68 90 0C 36         [24]  711 	mov	dptr,#_vial_unlock_holding
      00AD6B 74 01            [12]  712 	mov	a,#0x01
      00AD6D F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00AD6E 12 49 FD         [24]  715 	lcall	_timer_read32
      00AD71 12 50 0C         [24]  716 	lcall	_ak820_outline_0057
      00AD74 90 0C 32         [24]  717 	mov	dptr,#_vial_unlock_timer
      00AD77 12 91 B5         [24]  718 	lcall	_ak820_outline_0007
      00AD7A                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00AD7A 90 0C 32         [24]  721 	mov	dptr,#_vial_unlock_timer
      00AD7D 12 4F FB         [24]  722 	lcall	_ak820_outline_0054
      00AD80 12 4A 56         [24]  723 	lcall	_timer_elapsed32
      00AD83 12 50 0C         [24]  724 	lcall	_ak820_outline_0057
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00AD86 7B 1E            [12]  726 	mov	r3,#0x1e
      00AD88                        727 00109$:
      00AD88 EB               [12]  728 	mov	a,r3
      00AD89 60 22            [24]  729 	jz	00111$
      00AD8B C3               [12]  730 	clr	c
      00AD8C EC               [12]  731 	mov	a,r4
      00AD8D 94 64            [12]  732 	subb	a,#0x64
      00AD8F ED               [12]  733 	mov	a,r5
      00AD90 94 00            [12]  734 	subb	a,#0x00
      00AD92 EE               [12]  735 	mov	a,r6
      00AD93 94 00            [12]  736 	subb	a,#0x00
      00AD95 EF               [12]  737 	mov	a,r7
      00AD96 94 00            [12]  738 	subb	a,#0x00
      00AD98 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00AD9A EC               [12]  741 	mov	a,r4
      00AD9B 24 9C            [12]  742 	add	a,#0x9c
      00AD9D FC               [12]  743 	mov	r4,a
      00AD9E ED               [12]  744 	mov	a,r5
      00AD9F 34 FF            [12]  745 	addc	a,#0xff
      00ADA1 FD               [12]  746 	mov	r5,a
      00ADA2 EE               [12]  747 	mov	a,r6
      00ADA3 34 FF            [12]  748 	addc	a,#0xff
      00ADA5 FE               [12]  749 	mov	r6,a
      00ADA6 EF               [12]  750 	mov	a,r7
      00ADA7 34 FF            [12]  751 	addc	a,#0xff
      00ADA9 FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00ADAA 1B               [12]  754 	dec	r3
      00ADAB 80 DB            [24]  755 	sjmp	00109$
      00ADAD                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00ADAD 90 0D FE         [24]  758 	mov	dptr,#_vial_unlock_counter
      00ADB0 EB               [12]  759 	mov	a,r3
      00ADB1 F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00ADB2 EB               [12]  762 	mov	a,r3
      00ADB3 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00ADB5 90 0D FD         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00ADB8 E4               [12]  766 	clr	a
      00ADB9 F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00ADBA 90 0D FC         [24]  769 	mov	dptr,#_vial_unlocked
      00ADBD 04               [12]  770 	inc	a
      00ADBE F0               [24]  771 	movx	@dptr,a
      00ADBF                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00ADBF 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:117: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00ADC0                        782 _vial_init:
                                    783 ;	quantum/vial.c:125: reload_combo();
                                    784 ;	quantum/vial.c:130: }
      00ADC0 02 35 37         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_610'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00ADC3                        795 _vial_keycode_firewall:
      00ADC3 12 38 43         [24]  796 	lcall	_ak820_outline_0103
      00ADC6 90 0C 37         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_610
      00ADC9 12 38 48         [24]  798 	lcall	_ak820_outline_0104
                                    799 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00ADCC 90 0C 37         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_610
      00ADCF 12 37 CB         [24]  801 	lcall	_ak820_outline_0011
      00ADD2 BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00ADD5 BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00ADD8 90 0D FC         [24]  804 	mov	dptr,#_vial_unlocked
      00ADDB E0               [24]  805 	movx	a,@dptr
      00ADDC 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:134: return 0;
      00ADDE 90 00 00         [24]  808 	mov	dptr,#0x0000
      00ADE1 22               [24]  809 	ret
      00ADE2                        810 00102$:
                                    811 ;	quantum/vial.c:135: return in;
      00ADE2 12 43 92         [24]  812 	lcall	_ak820_outline_0116
                                    813 ;	quantum/vial.c:136: }
      00ADE5 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_613'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_615'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00ADE6                        826 _vial_fill_packet:
      00ADE6 12 38 43         [24]  827 	lcall	_ak820_outline_0103
      00ADE9 90 0C 3A         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_613
      00ADEC 12 38 48         [24]  829 	lcall	_ak820_outline_0104
                                    830 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00ADEF 90 0C 3A         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_613
      00ADF2 12 38 00         [24]  832 	lcall	_ak820_outline_0051
      00ADF5 90 0C 39         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00ADF8 E0               [24]  834 	movx	a,@dptr
      00ADF9 FD               [12]  835 	mov	r5,a
      00ADFA 7C 00            [12]  836 	mov	r4,#0x00
      00ADFC                        837 00103$:
      00ADFC BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00ADFF                        839 00122$:
      00ADFF 50 09            [24]  840 	jnc	00105$
      00AE01 EC               [12]  841 	mov	a,r4
      00AE02 12 37 F0         [24]  842 	lcall	_ak820_outline_0031
      00AE05 ED               [12]  843 	mov	a,r5
      00AE06 F0               [24]  844 	movx	@dptr,a
      00AE07 0C               [12]  845 	inc	r4
      00AE08 80 F2            [24]  846 	sjmp	00103$
      00AE0A                        847 00105$:
                                    848 ;	quantum/vial.c:141: }
      00AE0A 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00AE0B                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:174: repeat_key_cancel();
      00AE0B 12 A2 02         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:176: clear_keyboard();
                                    861 ;	quantum/vial.c:177: }
      00AE0E 02 77 EC         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_618'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_619'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_624'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_625'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_628'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_630'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_630'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_630'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_631'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_632'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_632'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_632'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_635'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_647'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_647'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00AE11                        893 _vial_handle_cmd:
      00AE11 12 43 49         [24]  894 	lcall	_ak820_outline_0037
      00AE14 90 0C 3D         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_618
      00AE17 12 37 DF         [24]  896 	lcall	_ak820_outline_0016
                                    897 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00AE1A 90 0C 3D         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_618
      00AE1D 12 38 00         [24]  899 	lcall	_ak820_outline_0051
                                    900 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00AE20 90 0C 3C         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AE23 E0               [24]  902 	movx	a,@dptr
      00AE24 FD               [12]  903 	mov	r5,a
      00AE25 BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00AE28 80 01            [24]  905 	sjmp	00102$
      00AE2A                        906 00258$:
                                    907 ;	quantum/vial.c:190: return;
      00AE2A 22               [24]  908 	ret
      00AE2B                        909 00102$:
                                    910 ;	quantum/vial.c:193: switch (msg[1]) {
      00AE2B 74 01            [12]  911 	mov	a,#0x01
      00AE2D 12 49 3C         [24]  912 	lcall	_ak820_outline_0012
      00AE30 FB               [12]  913 	mov  r3,a
      00AE31 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00AE33 50 01            [24]  915 	jnc	00259$
      00AE35 22               [24]  916 	ret
      00AE36                        917 00259$:
                                    918 ;	free result
      00AE36 EB               [12]  919 	mov	a,r3
      00AE37 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00AE39 83               [24]  921 	movc	a,@a+pc
      00AE3A F5 82            [12]  922 	mov	dpl,a
      00AE3C EB               [12]  923 	mov	a,r3
      00AE3D 24 12            [12]  924 	add	a,#(00261$-3-.)
      00AE3F 83               [24]  925 	movc	a,@a+pc
      00AE40 F5 83            [12]  926 	mov	dph,a
      00AE42 E4               [12]  927 	clr	a
      00AE43 73               [24]  928 	jmp	@a+dptr
      00AE44                        929 00260$:
      00AE44 60                     930 	.db	00103$
      00AE45 A8                     931 	.db	00105$
      00AE46 BC                     932 	.db	00106$
      00AE47 48                     933 	.db	00112$
      00AE48 CE                     934 	.db	00113$
      00AE49 19                     935 	.db	00114$
      00AE4A 88                     936 	.db	00116$
      00AE4B A3                     937 	.db	00119$
      00AE4C C3                     938 	.db	00120$
      00AE4D D1                     939 	.db	00121$
      00AE4E D1                     940 	.db	00139$
      00AE4F D1                     941 	.db	00139$
      00AE50 D1                     942 	.db	00139$
      00AE51 DC                     943 	.db	00122$
      00AE52                        944 00261$:
      00AE52 AE                     945 	.db	00103$>>8
      00AE53 AE                     946 	.db	00105$>>8
      00AE54 AE                     947 	.db	00106$>>8
      00AE55 AF                     948 	.db	00112$>>8
      00AE56 AF                     949 	.db	00113$>>8
      00AE57 B0                     950 	.db	00114$>>8
      00AE58 B0                     951 	.db	00116$>>8
      00AE59 B0                     952 	.db	00119$>>8
      00AE5A B0                     953 	.db	00120$>>8
      00AE5B B0                     954 	.db	00121$>>8
      00AE5C B1                     955 	.db	00139$>>8
      00AE5D B1                     956 	.db	00139$>>8
      00AE5E B1                     957 	.db	00139$>>8
      00AE5F B0                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00AE60                        960 00103$:
                                    961 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00AE60 90 0C 39         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00AE63 E4               [12]  963 	clr	a
      00AE64 12 43 6D         [24]  964 	lcall	_ak820_outline_0061
      00AE67 C0 07            [24]  965 	push	ar7
      00AE69 C0 06            [24]  966 	push	ar6
      00AE6B 12 AD E6         [24]  967 	lcall	_vial_fill_packet
      00AE6E D0 06            [24]  968 	pop	ar6
      00AE70 D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00AE72 12 43 92         [24]  971 	lcall	_ak820_outline_0116
      00AE75 74 06            [12]  972 	mov	a,#0x06
      00AE77 12 43 6D         [24]  973 	lcall	_ak820_outline_0061
                                    974 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00AE7A A3               [24]  975 	inc	dptr
      00AE7B E4               [12]  976 	clr	a
      00AE7C 12 43 41         [24]  977 	lcall	_ak820_outline_0030
                                    978 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00AE7F 12 43 41         [24]  979 	lcall	_ak820_outline_0030
                                    980 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00AE82 A3               [24]  981 	inc	dptr
      00AE83 F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00AE84 FB               [12]  984 	mov	r3,a
      00AE85                        985 00131$:
      00AE85 BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00AE88                        987 00262$:
      00AE88 50 15            [24]  988 	jnc	00104$
      00AE8A 8B 02            [24]  989 	mov	ar2,r3
      00AE8C 74 04            [12]  990 	mov	a,#0x04
      00AE8E 2A               [12]  991 	add	a, r2
      00AE8F 2E               [12]  992 	add	a, r6
      00AE90 F9               [12]  993 	mov	r1,a
      00AE91 E4               [12]  994 	clr	a
      00AE92 3F               [12]  995 	addc	a,r7
      00AE93 FA               [12]  996 	mov	r2,a
      00AE94 EB               [12]  997 	mov	a,r3
      00AE95 90 BF 9A         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_623
      00AE98 93               [24]  999 	movc	a,@a+dptr
      00AE99 12 6E 03         [24] 1000 	lcall	_ak820_outline_0137
      00AE9C 0B               [12] 1001 	inc	r3
      00AE9D 80 E6            [24] 1002 	sjmp	00131$
      00AE9F                       1003 00104$:
                                   1004 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00AE9F 74 0C            [12] 1005 	mov	a,#0x0c
      00AEA1 12 37 F0         [24] 1006 	lcall	_ak820_outline_0031
      00AEA4 74 01            [12] 1007 	mov	a,#0x01
      00AEA6 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:207: break;
      00AEA7 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:210: case vial_get_size: {
      00AEA8                       1012 00105$:
                                   1013 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00AEA8 12 43 92         [24] 1014 	lcall	_ak820_outline_0116
      00AEAB 74 7C            [12] 1015 	mov	a,#0x7c
      00AEAD 12 38 31         [24] 1016 	lcall	_ak820_outline_0097
                                   1017 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00AEB0 74 01            [12] 1018 	mov	a,#0x01
      00AEB2 12 43 41         [24] 1019 	lcall	_ak820_outline_0030
                                   1020 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00AEB5 E4               [12] 1021 	clr	a
      00AEB6 12 43 41         [24] 1022 	lcall	_ak820_outline_0030
                                   1023 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00AEB9 A3               [24] 1024 	inc	dptr
      00AEBA F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	quantum/vial.c:216: break;
      00AEBB 22               [24] 1027 	ret
                                   1028 ;	quantum/vial.c:219: case vial_get_def: {
      00AEBC                       1029 00106$:
                                   1030 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00AEBC 12 AC EF         [24] 1031 	lcall	_ak820_outline_0021
      00AEBF E0               [24] 1032 	movx	a,@dptr
      00AEC0 FB               [12] 1033 	mov	r3,a
      00AEC1 12 43 37         [24] 1034 	lcall	_ak820_outline_0010
      00AEC4 E0               [24] 1035 	movx	a,@dptr
      00AEC5 4B               [12] 1036 	orl	a,r3
      00AEC6 60 01            [24] 1037 	jz	00108$
      00AEC8 22               [24] 1038 	ret
      00AEC9                       1039 00108$:
                                   1040 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00AEC9 12 37 F8         [24] 1041 	lcall	_ak820_outline_0034
      00AECC FB               [12] 1042 	mov	r3,a
      00AECD 7A 00            [12] 1043 	mov	r2,#0x00
      00AECF 12 AC E6         [24] 1044 	lcall	_ak820_outline_0015
      00AED2 F9               [12] 1045 	mov	r1,a
      00AED3 E4               [12] 1046 	clr	a
      00AED4 42 03            [12] 1047 	orl	ar3,a
      00AED6 E9               [12] 1048 	mov	a,r1
      00AED7 42 02            [12] 1049 	orl	ar2,a
                                   1050 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00AED9 C3               [12] 1051 	clr	c
      00AEDA EB               [12] 1052 	mov	a,r3
      00AEDB 94 0C            [12] 1053 	subb	a,#0x0c
      00AEDD EA               [12] 1054 	mov	a,r2
      00AEDE 94 00            [12] 1055 	subb	a,#0x00
      00AEE0 40 01            [24] 1056 	jc	00110$
      00AEE2 22               [24] 1057 	ret
      00AEE3                       1058 00110$:
                                   1059 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00AEE3 EA               [12] 1060 	mov	a,r2
      00AEE4 C4               [12] 1061 	swap	a
      00AEE5 23               [12] 1062 	rl	a
      00AEE6 54 E0            [12] 1063 	anl	a,#0xe0
      00AEE8 CB               [12] 1064 	xch	a,r3
      00AEE9 C4               [12] 1065 	swap	a
      00AEEA 23               [12] 1066 	rl	a
      00AEEB CB               [12] 1067 	xch	a,r3
      00AEEC 6B               [12] 1068 	xrl	a,r3
      00AEED CB               [12] 1069 	xch	a,r3
      00AEEE 54 E0            [12] 1070 	anl	a,#0xe0
      00AEF0 CB               [12] 1071 	xch	a,r3
      00AEF1 6B               [12] 1072 	xrl	a,r3
      00AEF2 FA               [12] 1073 	mov	r2,a
      00AEF3 8B 42            [24] 1074 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00AEF5 8A 43            [24] 1075 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1076 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00AEF7 74 7C            [12] 1077 	mov	a,#0x7c
      00AEF9 C3               [12] 1078 	clr	c
      00AEFA 95 42            [12] 1079 	subb	a,_vial_handle_cmd_sloc0_1_0
      00AEFC F8               [12] 1080 	mov	r0,a
      00AEFD 74 01            [12] 1081 	mov	a,#0x01
      00AEFF 95 43            [12] 1082 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00AF01 F9               [12] 1083 	mov	r1,a
                                   1084 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00AF02 C3               [12] 1085 	clr	c
      00AF03 E8               [12] 1086 	mov	a,r0
      00AF04 94 20            [12] 1087 	subb	a,#0x20
      00AF06 E9               [12] 1088 	mov	a,r1
      00AF07 94 00            [12] 1089 	subb	a,#0x00
      00AF09 40 02            [24] 1090 	jc	00142$
      00AF0B 78 20            [12] 1091 	mov	r0,#0x20
      00AF0D                       1092 00142$:
                                   1093 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00AF0D 79 00            [12] 1094 	mov	r1,#0x00
      00AF0F                       1095 00134$:
      00AF0F C3               [12] 1096 	clr	c
      00AF10 E9               [12] 1097 	mov	a,r1
      00AF11 98               [12] 1098 	subb	a,r0
      00AF12 40 01            [24] 1099 	jc	00267$
      00AF14 22               [24] 1100 	ret
      00AF15                       1101 00267$:
      00AF15 C0 00            [24] 1102 	push	ar0
      00AF17 E9               [12] 1103 	mov	a,r1
      00AF18 2E               [12] 1104 	add	a, r6
      00AF19 F5 44            [12] 1105 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AF1B E4               [12] 1106 	clr	a
      00AF1C 3F               [12] 1107 	addc	a, r7
      00AF1D F5 45            [12] 1108 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00AF1F 89 46            [24] 1109 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00AF21 75 47 00         [24] 1110 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00AF24 A8 42            [24] 1111 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00AF26 AB 43            [24] 1112 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00AF28 E5 46            [12] 1113 	mov	a,_vial_handle_cmd_sloc2_1_0
      00AF2A 28               [12] 1114 	add	a, r0
      00AF2B F8               [12] 1115 	mov	r0,a
      00AF2C E5 47            [12] 1116 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00AF2E 3B               [12] 1117 	addc	a, r3
      00AF2F FB               [12] 1118 	mov	r3,a
      00AF30 E8               [12] 1119 	mov	a,r0
      00AF31 24 1E            [12] 1120 	add	a, #_keyboard_definition
      00AF33 F5 82            [12] 1121 	mov	dpl,a
      00AF35 EB               [12] 1122 	mov	a,r3
      00AF36 34 BE            [12] 1123 	addc	a, #(_keyboard_definition >> 8)
      00AF38 F5 83            [12] 1124 	mov	dph,a
      00AF3A E4               [12] 1125 	clr	a
      00AF3B 93               [24] 1126 	movc	a,@a+dptr
      00AF3C 85 44 82         [24] 1127 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AF3F 85 45 83         [24] 1128 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AF42 F0               [24] 1129 	movx	@dptr,a
      00AF43 09               [12] 1130 	inc	r1
      00AF44 D0 00            [24] 1131 	pop	ar0
                                   1132 ;	quantum/vial.c:246: case vial_get_encoder: {
      00AF46 80 C7            [24] 1133 	sjmp	00134$
      00AF48                       1134 00112$:
                                   1135 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00AF48 74 02            [12] 1136 	mov	a,#0x02
      00AF4A 12 49 7B         [24] 1137 	lcall	_ak820_outline_0046
      00AF4D F5 46            [12] 1138 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1139 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00AF4F 74 03            [12] 1140 	mov	a,#0x03
      00AF51 2E               [12] 1141 	add	a, r6
      00AF52 F5 44            [12] 1142 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AF54 E4               [12] 1143 	clr	a
      00AF55 3F               [12] 1144 	addc	a, r7
      00AF56 F5 45            [12] 1145 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00AF58 85 44 82         [24] 1146 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AF5B 85 45 83         [24] 1147 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AF5E E0               [24] 1148 	movx	a,@dptr
                                   1149 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00AF5F F5 42            [12] 1150 	mov	_vial_handle_cmd_sloc0_1_0,a
      00AF61 90 0A E7         [24] 1151 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00AF64 F0               [24] 1152 	movx	@dptr,a
      00AF65 90 0A E8         [24] 1153 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AF68 E4               [12] 1154 	clr	a
      00AF69 F0               [24] 1155 	movx	@dptr,a
      00AF6A 85 46 82         [24] 1156 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AF6D C0 07            [24] 1157 	push	ar7
      00AF6F C0 06            [24] 1158 	push	ar6
      00AF71 C0 05            [24] 1159 	push	ar5
      00AF73 C0 04            [24] 1160 	push	ar4
      00AF75 C0 03            [24] 1161 	push	ar3
      00AF77 C0 02            [24] 1162 	push	ar2
      00AF79 12 86 37         [24] 1163 	lcall	_dynamic_keymap_get_encoder
      00AF7C 85 82 48         [24] 1164 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AF7F 85 83 49         [24] 1165 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AF82 D0 02            [24] 1166 	pop	ar2
      00AF84 D0 03            [24] 1167 	pop	ar3
      00AF86 D0 04            [24] 1168 	pop	ar4
      00AF88 D0 05            [24] 1169 	pop	ar5
      00AF8A D0 06            [24] 1170 	pop	ar6
      00AF8C D0 07            [24] 1171 	pop	ar7
                                   1172 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00AF8E A9 49            [24] 1173 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AF90 12 43 92         [24] 1174 	lcall	_ak820_outline_0116
      00AF93 E9               [12] 1175 	mov	a,r1
      00AF94 F0               [24] 1176 	movx	@dptr,a
                                   1177 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00AF95 A8 48            [24] 1178 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AF97 12 38 60         [24] 1179 	lcall	_ak820_outline_0122
      00AF9A E8               [12] 1180 	mov	a,r0
      00AF9B F0               [24] 1181 	movx	@dptr,a
                                   1182 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00AF9C 90 0A E7         [24] 1183 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00AF9F E5 42            [12] 1184 	mov	a,_vial_handle_cmd_sloc0_1_0
      00AFA1 F0               [24] 1185 	movx	@dptr,a
      00AFA2 90 0A E8         [24] 1186 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AFA5 74 01            [12] 1187 	mov	a,#0x01
      00AFA7 F0               [24] 1188 	movx	@dptr,a
      00AFA8 85 46 82         [24] 1189 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AFAB C0 03            [24] 1190 	push	ar3
      00AFAD C0 02            [24] 1191 	push	ar2
      00AFAF 12 86 37         [24] 1192 	lcall	_dynamic_keymap_get_encoder
      00AFB2 85 82 48         [24] 1193 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AFB5 85 83 49         [24] 1194 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AFB8 D0 02            [24] 1195 	pop	ar2
      00AFBA D0 03            [24] 1196 	pop	ar3
                                   1197 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00AFBC A9 49            [24] 1198 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AFBE 12 43 AE         [24] 1199 	lcall	_ak820_outline_0141
      00AFC1 E9               [12] 1200 	mov	a,r1
      00AFC2 F0               [24] 1201 	movx	@dptr,a
                                   1202 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00AFC3 A8 48            [24] 1203 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AFC5 85 44 82         [24] 1204 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AFC8 85 45 83         [24] 1205 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AFCB E8               [12] 1206 	mov	a,r0
      00AFCC F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	quantum/vial.c:255: break;
      00AFCD 22               [24] 1209 	ret
                                   1210 ;	quantum/vial.c:257: case vial_set_encoder: {
      00AFCE                       1211 00113$:
                                   1212 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00AFCE 12 37 F8         [24] 1213 	lcall	_ak820_outline_0034
      00AFD1 F5 44            [12] 1214 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AFD3 12 AC E6         [24] 1215 	lcall	_ak820_outline_0015
      00AFD6 F5 46            [12] 1216 	mov	_vial_handle_cmd_sloc2_1_0,a
      00AFD8 12 AC EF         [24] 1217 	lcall	_ak820_outline_0021
      00AFDB E0               [24] 1218 	movx	a,@dptr
                                   1219 ;	assignBit
      00AFDC 24 FF            [12] 1220 	add	a,#0xff
      00AFDE E4               [12] 1221 	clr	a
      00AFDF 33               [12] 1222 	rlc	a
      00AFE0 F5 48            [12] 1223 	mov	_vial_handle_cmd_sloc3_1_0,a
      00AFE2 12 43 37         [24] 1224 	lcall	_ak820_outline_0010
      00AFE5 E0               [24] 1225 	movx	a,@dptr
      00AFE6 F9               [12] 1226 	mov	r1,a
      00AFE7 78 00            [12] 1227 	mov	r0,#0x00
      00AFE9 74 06            [12] 1228 	mov	a,#0x06
      00AFEB 12 37 E7         [24] 1229 	lcall	_ak820_outline_0017
      00AFEE 7B 00            [12] 1230 	mov	r3,#0x00
      00AFF0 42 00            [12] 1231 	orl	ar0,a
      00AFF2 EB               [12] 1232 	mov	a,r3
      00AFF3 42 01            [12] 1233 	orl	ar1,a
      00AFF5 12 38 75         [24] 1234 	lcall	_ak820_outline_0153
      00AFF8 12 AD C3         [24] 1235 	lcall	_vial_keycode_firewall
      00AFFB AA 82            [24] 1236 	mov	r2, dpl
      00AFFD AB 83            [24] 1237 	mov	r3, dph
      00AFFF 90 0A EA         [24] 1238 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B002 E5 46            [12] 1239 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B004 F0               [24] 1240 	movx	@dptr,a
      00B005 90 0A EB         [24] 1241 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B008 E5 48            [12] 1242 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B00A F0               [24] 1243 	movx	@dptr,a
      00B00B 90 0A EC         [24] 1244 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B00E EA               [12] 1245 	mov	a,r2
      00B00F F0               [24] 1246 	movx	@dptr,a
      00B010 EB               [12] 1247 	mov	a,r3
      00B011 A3               [24] 1248 	inc	dptr
      00B012 F0               [24] 1249 	movx	@dptr,a
      00B013 85 44 82         [24] 1250 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1251 ;	quantum/vial.c:259: break;
      00B016 02 86 9F         [24] 1252 	ljmp	_dynamic_keymap_set_encoder
                                   1253 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B019                       1254 00114$:
                                   1255 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B019 90 0C 39         [24] 1256 	mov	dptr,#_vial_fill_packet_PARM_2
      00B01C 74 FF            [12] 1257 	mov	a,#0xff
      00B01E 12 43 6D         [24] 1258 	lcall	_ak820_outline_0061
      00B021 C0 07            [24] 1259 	push	ar7
      00B023 C0 06            [24] 1260 	push	ar6
      00B025 12 AD E6         [24] 1261 	lcall	_vial_fill_packet
      00B028 D0 06            [24] 1262 	pop	ar6
      00B02A D0 07            [24] 1263 	pop	ar7
                                   1264 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B02C 90 0D FC         [24] 1265 	mov	dptr,#_vial_unlocked
      00B02F E0               [24] 1266 	movx	a,@dptr
      00B030 12 43 92         [24] 1267 	lcall	_ak820_outline_0116
      00B033 F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B034 74 01            [12] 1270 	mov	a,#0x01
      00B036 2E               [12] 1271 	add	a, r6
      00B037 FA               [12] 1272 	mov	r2,a
      00B038 E4               [12] 1273 	clr	a
      00B039 3F               [12] 1274 	addc	a, r7
      00B03A FB               [12] 1275 	mov	r3,a
      00B03B 90 0D FD         [24] 1276 	mov	dptr,#_vial_unlock_in_progress
      00B03E E0               [24] 1277 	movx	a,@dptr
      00B03F 12 43 AE         [24] 1278 	lcall	_ak820_outline_0141
      00B042 F0               [24] 1279 	movx	@dptr,a
                                   1280 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B043 7B 00            [12] 1281 	mov	r3,#0x00
      00B045                       1282 00137$:
      00B045 BB 02 00         [24] 1283 	cjne	r3,#0x02,00268$
      00B048                       1284 00268$:
      00B048 40 01            [24] 1285 	jc	00269$
      00B04A 22               [24] 1286 	ret
      00B04B                       1287 00269$:
                                   1288 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B04B 8B 01            [24] 1289 	mov	ar1,r3
      00B04D 7A 00            [12] 1290 	mov	r2,#0x00
      00B04F E9               [12] 1291 	mov	a,r1
      00B050 29               [12] 1292 	add	a,r1
      00B051 F5 48            [12] 1293 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B053 EA               [12] 1294 	mov	a,r2
      00B054 33               [12] 1295 	rlc	a
      00B055 F5 49            [12] 1296 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B057 74 02            [12] 1297 	mov	a,#0x02
      00B059 25 48            [12] 1298 	add	a, _vial_handle_cmd_sloc3_1_0
      00B05B F8               [12] 1299 	mov	r0,a
      00B05C E4               [12] 1300 	clr	a
      00B05D 35 49            [12] 1301 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B05F FA               [12] 1302 	mov	r2,a
      00B060 E8               [12] 1303 	mov	a,r0
      00B061 2E               [12] 1304 	add	a, r6
      00B062 F8               [12] 1305 	mov	r0,a
      00B063 EA               [12] 1306 	mov	a,r2
      00B064 3F               [12] 1307 	addc	a, r7
      00B065 FA               [12] 1308 	mov	r2,a
      00B066 EB               [12] 1309 	mov	a,r3
      00B067 12 B2 F0         [24] 1310 	lcall	_ak820_outline_0127
      00B06A 88 82            [24] 1311 	mov	dpl,r0
      00B06C 8A 83            [24] 1312 	mov	dph,r2
      00B06E F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B06F 74 03            [12] 1315 	mov	a,#0x03
      00B071 25 48            [12] 1316 	add	a, _vial_handle_cmd_sloc3_1_0
      00B073 F9               [12] 1317 	mov	r1,a
      00B074 E4               [12] 1318 	clr	a
      00B075 35 49            [12] 1319 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B077 FA               [12] 1320 	mov	r2,a
      00B078 E9               [12] 1321 	mov	a,r1
      00B079 2E               [12] 1322 	add	a, r6
      00B07A F9               [12] 1323 	mov	r1,a
      00B07B EA               [12] 1324 	mov	a,r2
      00B07C 3F               [12] 1325 	addc	a, r7
      00B07D FA               [12] 1326 	mov	r2,a
      00B07E EB               [12] 1327 	mov	a,r3
      00B07F 12 B2 E5         [24] 1328 	lcall	_ak820_outline_0126
      00B082 12 6E 03         [24] 1329 	lcall	_ak820_outline_0137
                                   1330 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B085 0B               [12] 1331 	inc	r3
                                   1332 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B086 80 BD            [24] 1333 	sjmp	00137$
      00B088                       1334 00116$:
                                   1335 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B088 90 0D FD         [24] 1336 	mov	dptr,#_vial_unlock_in_progress
      00B08B E0               [24] 1337 	movx	a,@dptr
      00B08C 70 03            [24] 1338 	jnz	00118$
      00B08E 12 AE 0B         [24] 1339 	lcall	_vial_release_held_state
      00B091                       1340 00118$:
                                   1341 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B091 90 0D FD         [24] 1342 	mov	dptr,#_vial_unlock_in_progress
      00B094 74 01            [12] 1343 	mov	a,#0x01
      00B096 F0               [24] 1344 	movx	@dptr,a
                                   1345 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B097 90 0D FE         [24] 1346 	mov	dptr,#_vial_unlock_counter
      00B09A 74 1E            [12] 1347 	mov	a,#0x1e
      00B09C F0               [24] 1348 	movx	@dptr,a
                                   1349 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B09D 90 0C 36         [24] 1350 	mov	dptr,#_vial_unlock_holding
      00B0A0 E4               [12] 1351 	clr	a
      00B0A1 F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/vial.c:287: break;
      00B0A2 22               [24] 1354 	ret
                                   1355 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B0A3                       1356 00119$:
                                   1357 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B0A3 90 0D FC         [24] 1358 	mov	dptr,#_vial_unlocked
      00B0A6 E0               [24] 1359 	movx	a,@dptr
      00B0A7 12 43 92         [24] 1360 	lcall	_ak820_outline_0116
      00B0AA F0               [24] 1361 	movx	@dptr,a
                                   1362 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B0AB 90 0D FD         [24] 1363 	mov	dptr,#_vial_unlock_in_progress
      00B0AE E0               [24] 1364 	movx	a,@dptr
      00B0AF 12 38 60         [24] 1365 	lcall	_ak820_outline_0122
      00B0B2 F0               [24] 1366 	movx	@dptr,a
                                   1367 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B0B3 74 02            [12] 1368 	mov	a,#0x02
      00B0B5 2E               [12] 1369 	add	a, r6
      00B0B6 FA               [12] 1370 	mov	r2,a
      00B0B7 E4               [12] 1371 	clr	a
      00B0B8 3F               [12] 1372 	addc	a, r7
      00B0B9 FB               [12] 1373 	mov	r3,a
      00B0BA 90 0D FE         [24] 1374 	mov	dptr,#_vial_unlock_counter
      00B0BD E0               [24] 1375 	movx	a,@dptr
      00B0BE 12 43 AE         [24] 1376 	lcall	_ak820_outline_0141
      00B0C1 F0               [24] 1377 	movx	@dptr,a
                                   1378 ;	quantum/vial.c:293: break;
      00B0C2 22               [24] 1379 	ret
                                   1380 ;	quantum/vial.c:295: case vial_lock: {
      00B0C3                       1381 00120$:
                                   1382 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B0C3 90 0D FC         [24] 1383 	mov	dptr,#_vial_unlocked
      00B0C6 E4               [12] 1384 	clr	a
      00B0C7 F0               [24] 1385 	movx	@dptr,a
                                   1386 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B0C8 90 0D FD         [24] 1387 	mov	dptr,#_vial_unlock_in_progress
      00B0CB F0               [24] 1388 	movx	@dptr,a
                                   1389 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B0CC 90 0C 36         [24] 1390 	mov	dptr,#_vial_unlock_holding
      00B0CF F0               [24] 1391 	movx	@dptr,a
                                   1392 ;	quantum/vial.c:301: break;
      00B0D0 22               [24] 1393 	ret
                                   1394 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B0D1                       1395 00121$:
                                   1396 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B0D1 90 0C 39         [24] 1397 	mov	dptr,#_vial_fill_packet_PARM_2
      00B0D4 74 FF            [12] 1398 	mov	a,#0xff
      00B0D6 12 43 6D         [24] 1399 	lcall	_ak820_outline_0061
                                   1400 ;	quantum/vial.c:314: break;
      00B0D9 02 AD E6         [24] 1401 	ljmp	_vial_fill_packet
                                   1402 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B0DC                       1403 00122$:
                                   1404 ;	quantum/vial.c:347: switch (msg[2]) {
      00B0DC 12 37 F8         [24] 1405 	lcall	_ak820_outline_0034
      00B0DF FB               [12] 1406 	mov	r3,a
      00B0E0 60 0C            [24] 1407 	jz	00123$
      00B0E2 BB 03 02         [24] 1408 	cjne	r3,#0x03,00272$
      00B0E5 80 31            [24] 1409 	sjmp	00124$
      00B0E7                       1410 00272$:
      00B0E7 BB 04 03         [24] 1411 	cjne	r3,#0x04,00273$
      00B0EA 02 B1 76         [24] 1412 	ljmp	00125$
      00B0ED                       1413 00273$:
      00B0ED 22               [24] 1414 	ret
                                   1415 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B0EE                       1416 00123$:
                                   1417 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B0EE 90 0C 39         [24] 1418 	mov	dptr,#_vial_fill_packet_PARM_2
      00B0F1 E4               [12] 1419 	clr	a
      00B0F2 12 43 6D         [24] 1420 	lcall	_ak820_outline_0061
      00B0F5 C0 07            [24] 1421 	push	ar7
      00B0F7 C0 06            [24] 1422 	push	ar6
      00B0F9 12 AD E6         [24] 1423 	lcall	_vial_fill_packet
      00B0FC D0 06            [24] 1424 	pop	ar6
      00B0FE D0 07            [24] 1425 	pop	ar7
                                   1426 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B100 12 43 92         [24] 1427 	lcall	_ak820_outline_0116
      00B103 E4               [12] 1428 	clr	a
      00B104 12 43 6D         [24] 1429 	lcall	_ak820_outline_0061
                                   1430 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B107 A3               [24] 1431 	inc	dptr
      00B108 74 08            [12] 1432 	mov	a,#0x08
      00B10A 12 43 41         [24] 1433 	lcall	_ak820_outline_0030
                                   1434 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B10D E4               [12] 1435 	clr	a
      00B10E F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B10F 74 1F            [12] 1438 	mov	a,#0x1f
      00B111 12 37 F0         [24] 1439 	lcall	_ak820_outline_0031
      00B114 74 01            [12] 1440 	mov	a,#0x01
      00B116 F0               [24] 1441 	movx	@dptr,a
                                   1442 ;	quantum/vial.c:356: break;
      00B117 22               [24] 1443 	ret
                                   1444 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B118                       1445 00124$:
                                   1446 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B118 12 AC E6         [24] 1447 	lcall	_ak820_outline_0015
      00B11B FB               [12] 1448 	mov	r3,a
                                   1449 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B11C 90 0C 40         [24] 1450 	mov	dptr,#_vial_handle_cmd_entry_70000_646
      00B11F 12 50 34         [24] 1451 	lcall	_ak820_outline_0179
      00B122 90 0C 42         [24] 1452 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0002)
      00B125 F0               [24] 1453 	movx	@dptr,a
      00B126 A3               [24] 1454 	inc	dptr
      00B127 F0               [24] 1455 	movx	@dptr,a
      00B128 90 0C 44         [24] 1456 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0004)
      00B12B F0               [24] 1457 	movx	@dptr,a
      00B12C A3               [24] 1458 	inc	dptr
      00B12D F0               [24] 1459 	movx	@dptr,a
      00B12E 90 0C 46         [24] 1460 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0006)
      00B131 F0               [24] 1461 	movx	@dptr,a
      00B132 A3               [24] 1462 	inc	dptr
      00B133 F0               [24] 1463 	movx	@dptr,a
      00B134 90 0C 48         [24] 1464 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00B137 F0               [24] 1465 	movx	@dptr,a
      00B138 A3               [24] 1466 	inc	dptr
      00B139 F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B13A 90 0A EF         [24] 1469 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B13D 74 40            [12] 1470 	mov	a,#_vial_handle_cmd_entry_70000_646
      00B13F F0               [24] 1471 	movx	@dptr,a
      00B140 74 0C            [12] 1472 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00B142 12 38 54         [24] 1473 	lcall	_ak820_outline_0117
      00B145 8B 82            [24] 1474 	mov	dpl, r3
      00B147 C0 07            [24] 1475 	push	ar7
      00B149 C0 06            [24] 1476 	push	ar6
      00B14B C0 05            [24] 1477 	push	ar5
      00B14D C0 04            [24] 1478 	push	ar4
      00B14F 12 87 0C         [24] 1479 	lcall	_dynamic_keymap_get_combo
      00B152 AA 82            [24] 1480 	mov	r2, dpl
      00B154 D0 04            [24] 1481 	pop	ar4
      00B156 D0 05            [24] 1482 	pop	ar5
      00B158 D0 06            [24] 1483 	pop	ar6
      00B15A D0 07            [24] 1484 	pop	ar7
      00B15C 12 43 92         [24] 1485 	lcall	_ak820_outline_0116
      00B15F EA               [12] 1486 	mov	a,r2
      00B160 F0               [24] 1487 	movx	@dptr,a
                                   1488 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B161 7B 00            [12] 1489 	mov	r3,#0x00
      00B163 90 0D 7C         [24] 1490 	mov	dptr,#___memcpy_PARM_2
      00B166 74 40            [12] 1491 	mov	a,#_vial_handle_cmd_entry_70000_646
      00B168 F0               [24] 1492 	movx	@dptr,a
      00B169 74 0C            [12] 1493 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00B16B 12 B2 D6         [24] 1494 	lcall	_ak820_outline_0073
      00B16E 12 38 60         [24] 1495 	lcall	_ak820_outline_0122
      00B171 8B F0            [24] 1496 	mov	b, r3
                                   1497 ;	quantum/vial.c:387: break;
      00B173 02 B8 A0         [24] 1498 	ljmp	___memcpy
                                   1499 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B176                       1500 00125$:
                                   1501 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B176 12 AC E6         [24] 1502 	lcall	_ak820_outline_0015
      00B179 FD               [12] 1503 	mov	r5,a
                                   1504 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B17A 74 04            [12] 1505 	mov	a,#0x04
      00B17C 2E               [12] 1506 	add	a, r6
      00B17D FB               [12] 1507 	mov	r3,a
      00B17E E4               [12] 1508 	clr	a
      00B17F 3F               [12] 1509 	addc	a, r7
      00B180 FC               [12] 1510 	mov	r4,a
      00B181 90 0D 7C         [24] 1511 	mov	dptr,#___memcpy_PARM_2
      00B184 EB               [12] 1512 	mov	a,r3
      00B185 F0               [24] 1513 	movx	@dptr,a
      00B186 EC               [12] 1514 	mov	a,r4
      00B187 12 B2 D6         [24] 1515 	lcall	_ak820_outline_0073
      00B18A 90 0C 4A         [24] 1516 	mov	dptr,#_vial_handle_cmd_entry_70000_647
      00B18D F5 F0            [12] 1517 	mov	b,a
      00B18F C0 07            [24] 1518 	push	ar7
      00B191 C0 06            [24] 1519 	push	ar6
      00B193 C0 05            [24] 1520 	push	ar5
      00B195 12 B8 A0         [24] 1521 	lcall	___memcpy
                                   1522 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B198 90 0C 52         [24] 1523 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00B19B 12 38 5A         [24] 1524 	lcall	_ak820_outline_0121
      00B19E 12 33 FC         [24] 1525 	lcall	_ak820_outline_0123
      00B1A1 12 AD C3         [24] 1526 	lcall	_vial_keycode_firewall
      00B1A4 AB 82            [24] 1527 	mov	r3, dpl
      00B1A6 AC 83            [24] 1528 	mov	r4, dph
      00B1A8 D0 05            [24] 1529 	pop	ar5
      00B1AA 90 0C 52         [24] 1530 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00B1AD 12 38 2B         [24] 1531 	lcall	_ak820_outline_0077
                                   1532 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B1B0 90 0A F3         [24] 1533 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B1B3 74 4A            [12] 1534 	mov	a,#_vial_handle_cmd_entry_70000_647
      00B1B5 F0               [24] 1535 	movx	@dptr,a
      00B1B6 74 0C            [12] 1536 	mov	a,#(_vial_handle_cmd_entry_70000_647 >> 8)
      00B1B8 12 38 54         [24] 1537 	lcall	_ak820_outline_0117
      00B1BB 8D 82            [24] 1538 	mov	dpl, r5
      00B1BD 12 87 B3         [24] 1539 	lcall	_dynamic_keymap_set_combo
      00B1C0 AC 82            [24] 1540 	mov	r4, dpl
      00B1C2 D0 06            [24] 1541 	pop	ar6
      00B1C4 D0 07            [24] 1542 	pop	ar7
      00B1C6 12 43 92         [24] 1543 	lcall	_ak820_outline_0116
      00B1C9 EC               [12] 1544 	mov	a,r4
      00B1CA F0               [24] 1545 	movx	@dptr,a
                                   1546 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B1CB EC               [12] 1547 	mov	a,r4
      00B1CC 70 03            [24] 1548 	jnz	00139$
                                   1549 ;	quantum/vial.c:423: }
                                   1550 ;	quantum/vial.c:424: }
      00B1CE 02 35 37         [24] 1551 	ljmp	_ak820_combo_reload
      00B1D1                       1552 00139$:
      00B1D1 22               [24] 1553 	ret
                                   1554 ;------------------------------------------------------------
                                   1555 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1556 ;------------------------------------------------------------
                                   1557 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_649'
                                   1558 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_656'
                                   1559 ;------------------------------------------------------------
                                   1560 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1561 ;	-----------------------------------------
                                   1562 ;	 function vial_keycode_down
                                   1563 ;	-----------------------------------------
      00B1D2                       1564 _vial_keycode_down:
      00B1D2 12 38 43         [24] 1565 	lcall	_ak820_outline_0103
      00B1D5 90 0C 56         [24] 1566 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B1D8 12 38 48         [24] 1567 	lcall	_ak820_outline_0104
                                   1568 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B1DB 90 0C 56         [24] 1569 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B1DE 12 37 CB         [24] 1570 	lcall	_ak820_outline_0011
      00B1E1 74 E0            [12] 1571 	mov	a,#0x100 - 0x20
      00B1E3 2D               [12] 1572 	add	a,r5
      00B1E4 50 19            [24] 1573 	jnc	00104$
      00B1E6 C3               [12] 1574 	clr	c
      00B1E7 74 FF            [12] 1575 	mov	a,#0xff
      00B1E9 9C               [12] 1576 	subb	a,r4
      00B1EA 74 4F            [12] 1577 	mov	a,#0x4f
      00B1EC 9D               [12] 1578 	subb	a,r5
      00B1ED 40 10            [24] 1579 	jc	00104$
                                   1580 ;	free result
                                   1581 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B1EF 90 0C 56         [24] 1582 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B1F2 EE               [12] 1583 	mov	a,r6
      00B1F3 12 38 65         [24] 1584 	lcall	_ak820_outline_0124
                                   1585 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B1F6 90 0C 56         [24] 1586 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B1F9 E0               [24] 1587 	movx	a,@dptr
      00B1FA 24 FE            [12] 1588 	add	a,#0xff - 0x01
      00B1FC 40 01            [24] 1589 	jc	00104$
                                   1590 ;	free result
      00B1FE 22               [24] 1591 	ret
      00B1FF                       1592 00104$:
                                   1593 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B1FF 90 0C 56         [24] 1594 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B202 12 B2 BD         [24] 1595 	lcall	_ak820_outline_0024
                                   1596 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B205 40 06            [24] 1597 	jc	00107$
                                   1598 ;	free result
                                   1599 ;	quantum/vial.c:440: register_code16(keycode);
      00B207 12 43 92         [24] 1600 	lcall	_ak820_outline_0116
      00B20A 02 9E BC         [24] 1601 	ljmp	_register_code16
      00B20D                       1602 00107$:
                                   1603 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B20D 90 0C 5C         [24] 1604 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0004)
      00B210 74 01            [12] 1605 	mov	a,#0x01
      00B212 F0               [24] 1606 	movx	@dptr,a
      00B213 90 0C 59         [24] 1607 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0001)
      00B216 74 F0            [12] 1608 	mov	a,#0xf0
      00B218 F0               [24] 1609 	movx	@dptr,a
      00B219 90 0C 58         [24] 1610 	mov	dptr,#_vial_keycode_down_dummy_event_30000_656
      00B21C F0               [24] 1611 	movx	@dptr,a
      00B21D 90 0C 5D         [24] 1612 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0005)
      00B220 74 01            [12] 1613 	mov	a,#0x01
      00B222 F0               [24] 1614 	movx	@dptr,a
      00B223 12 4A 2E         [24] 1615 	lcall	_timer_read
      00B226 12 43 9D         [24] 1616 	lcall	_ak820_outline_0132
      00B229 43 06 01         [24] 1617 	orl	ar6,#0x01
      00B22C 90 0C 5A         [24] 1618 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0002)
      00B22F 12 49 96         [24] 1619 	lcall	_ak820_outline_0059
                                   1620 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B232 90 0C 58         [24] 1621 	mov	dptr,#_vial_keycode_down_dummy_event_30000_656
                                   1622 ;	quantum/vial.c:448: }
      00B235 02 72 2E         [24] 1623 	ljmp	_ak820_action_exec
                                   1624 ;------------------------------------------------------------
                                   1625 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1626 ;------------------------------------------------------------
                                   1627 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_657'
                                   1628 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_664'
                                   1629 ;------------------------------------------------------------
                                   1630 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1631 ;	-----------------------------------------
                                   1632 ;	 function vial_keycode_up
                                   1633 ;	-----------------------------------------
      00B238                       1634 _vial_keycode_up:
      00B238 12 38 43         [24] 1635 	lcall	_ak820_outline_0103
      00B23B 90 0C 5E         [24] 1636 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B23E 12 38 48         [24] 1637 	lcall	_ak820_outline_0104
                                   1638 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B241 90 0C 5E         [24] 1639 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B244 12 37 CB         [24] 1640 	lcall	_ak820_outline_0011
      00B247 74 E0            [12] 1641 	mov	a,#0x100 - 0x20
      00B249 2D               [12] 1642 	add	a,r5
      00B24A 50 19            [24] 1643 	jnc	00104$
      00B24C C3               [12] 1644 	clr	c
      00B24D 74 FF            [12] 1645 	mov	a,#0xff
      00B24F 9C               [12] 1646 	subb	a,r4
      00B250 74 4F            [12] 1647 	mov	a,#0x4f
      00B252 9D               [12] 1648 	subb	a,r5
      00B253 40 10            [24] 1649 	jc	00104$
                                   1650 ;	free result
                                   1651 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B255 90 0C 5E         [24] 1652 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B258 EE               [12] 1653 	mov	a,r6
      00B259 12 38 65         [24] 1654 	lcall	_ak820_outline_0124
                                   1655 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B25C 90 0C 5E         [24] 1656 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B25F E0               [24] 1657 	movx	a,@dptr
      00B260 24 FE            [12] 1658 	add	a,#0xff - 0x01
      00B262 40 01            [24] 1659 	jc	00104$
                                   1660 ;	free result
      00B264 22               [24] 1661 	ret
      00B265                       1662 00104$:
                                   1663 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B265 90 0C 5E         [24] 1664 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B268 12 B2 BD         [24] 1665 	lcall	_ak820_outline_0024
                                   1666 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B26B 40 06            [24] 1667 	jc	00107$
                                   1668 ;	free result
                                   1669 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B26D 12 43 92         [24] 1670 	lcall	_ak820_outline_0116
      00B270 02 9F 01         [24] 1671 	ljmp	_unregister_code16
      00B273                       1672 00107$:
                                   1673 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B273 90 0C 64         [24] 1674 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0004)
      00B276 74 01            [12] 1675 	mov	a,#0x01
      00B278 F0               [24] 1676 	movx	@dptr,a
      00B279 90 0C 61         [24] 1677 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0001)
      00B27C 74 F0            [12] 1678 	mov	a,#0xf0
      00B27E F0               [24] 1679 	movx	@dptr,a
      00B27F 90 0C 60         [24] 1680 	mov	dptr,#_vial_keycode_up_dummy_event_30000_664
      00B282 F0               [24] 1681 	movx	@dptr,a
      00B283 90 0C 65         [24] 1682 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0005)
      00B286 E4               [12] 1683 	clr	a
      00B287 F0               [24] 1684 	movx	@dptr,a
      00B288 12 4A 2E         [24] 1685 	lcall	_timer_read
      00B28B 12 43 9D         [24] 1686 	lcall	_ak820_outline_0132
      00B28E 43 06 01         [24] 1687 	orl	ar6,#0x01
      00B291 90 0C 62         [24] 1688 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0002)
      00B294 12 49 96         [24] 1689 	lcall	_ak820_outline_0059
                                   1690 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B297 90 0C 60         [24] 1691 	mov	dptr,#_vial_keycode_up_dummy_event_30000_664
                                   1692 ;	quantum/vial.c:470: }
      00B29A 02 72 2E         [24] 1693 	ljmp	_ak820_action_exec
                                   1694 ;------------------------------------------------------------
                                   1695 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1696 ;------------------------------------------------------------
                                   1697 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_665'
                                   1698 ;i             Allocated with name '_vial_keycode_tap_i_30000_668'
                                   1699 ;------------------------------------------------------------
                                   1700 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1701 ;	-----------------------------------------
                                   1702 ;	 function vial_keycode_tap
                                   1703 ;	-----------------------------------------
      00B29D                       1704 _vial_keycode_tap:
      00B29D 12 38 43         [24] 1705 	lcall	_ak820_outline_0103
      00B2A0 90 0C 66         [24] 1706 	mov	dptr,#_vial_keycode_tap_keycode_10000_665
      00B2A3 12 38 48         [24] 1707 	lcall	_ak820_outline_0104
                                   1708 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B2A6 90 0C 66         [24] 1709 	mov	dptr,#_vial_keycode_tap_keycode_10000_665
      00B2A9 12 37 A0         [24] 1710 	lcall	_ak820_outline_0004
      00B2AC C0 07            [24] 1711 	push	ar7
      00B2AE C0 06            [24] 1712 	push	ar6
      00B2B0 12 B1 D2         [24] 1713 	lcall	_vial_keycode_down
      00B2B3 D0 06            [24] 1714 	pop	ar6
      00B2B5 D0 07            [24] 1715 	pop	ar7
                                   1716 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B2B7 12 43 92         [24] 1717 	lcall	_ak820_outline_0116
                                   1718 ;	quantum/vial.c:476: }
      00B2BA 02 B2 38         [24] 1719 	ljmp	_vial_keycode_up
                                   1720 ;------------------------------------------------------------
                                   1721 ;Allocation info for local variables in function 'process_record_vial'
                                   1722 ;------------------------------------------------------------
                                   1723 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1724 ;keycode       Allocated with name '_process_record_vial_keycode_10000_670'
                                   1725 ;------------------------------------------------------------
                                   1726 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1727 ;	-----------------------------------------
                                   1728 	.area CSEG    (CODE)
                                   1729 	.area CONST   (CODE)
                                   1730 	.area CONST   (CODE)
      00BE1E                       1731 _keyboard_definition:
      00BE1E FD                    1732 	.db #0xfd	; 253
      00BE1F 37                    1733 	.db #0x37	; 55	'7'
      00BE20 7A                    1734 	.db #0x7a	; 122	'z'
      00BE21 58                    1735 	.db #0x58	; 88	'X'
      00BE22 5A                    1736 	.db #0x5a	; 90	'Z'
      00BE23 00                    1737 	.db #0x00	; 0
      00BE24 00                    1738 	.db #0x00	; 0
      00BE25 04                    1739 	.db #0x04	; 4
      00BE26 E6                    1740 	.db #0xe6	; 230
      00BE27 D6                    1741 	.db #0xd6	; 214
      00BE28 B4                    1742 	.db #0xb4	; 180
      00BE29 46                    1743 	.db #0x46	; 70	'F'
      00BE2A 02                    1744 	.db #0x02	; 2
      00BE2B 00                    1745 	.db #0x00	; 0
      00BE2C 21                    1746 	.db #0x21	; 33
      00BE2D 01                    1747 	.db #0x01	; 1
      00BE2E 00                    1748 	.db #0x00	; 0
      00BE2F 00                    1749 	.db #0x00	; 0
      00BE30 00                    1750 	.db #0x00	; 0
      00BE31 00                    1751 	.db #0x00	; 0
      00BE32 37                    1752 	.db #0x37	; 55	'7'
      00BE33 27                    1753 	.db #0x27	; 39
      00BE34 97                    1754 	.db #0x97	; 151
      00BE35 D6                    1755 	.db #0xd6	; 214
      00BE36 E0                    1756 	.db #0xe0	; 224
      00BE37 03                    1757 	.db #0x03	; 3
      00BE38 CB                    1758 	.db #0xcb	; 203
      00BE39 01                    1759 	.db #0x01	; 1
      00BE3A 3C                    1760 	.db #0x3c	; 60
      00BE3B 00                    1761 	.db #0x00	; 0
      00BE3C 00                    1762 	.db #0x00	; 0
      00BE3D 3D                    1763 	.db #0x3d	; 61
      00BE3E 88                    1764 	.db #0x88	; 136
      00BE3F CD                    1765 	.db #0xcd	; 205
      00BE40 A5                    1766 	.db #0xa5	; 165
      00BE41 AA                    1767 	.db #0xaa	; 170
      00BE42 E5                    1768 	.db #0xe5	; 229
      00BE43 A8                    1769 	.db #0xa8	; 168
      00BE44 76                    1770 	.db #0x76	; 118	'v'
      00BE45 F6                    1771 	.db #0xf6	; 246
      00BE46 43                    1772 	.db #0x43	; 67	'C'
      00BE47 0E                    1773 	.db #0x0e	; 14
      00BE48 D2                    1774 	.db #0xd2	; 210
      00BE49 90                    1775 	.db #0x90	; 144
      00BE4A 7D                    1776 	.db #0x7d	; 125
      00BE4B 94                    1777 	.db #0x94	; 148
      00BE4C 79                    1778 	.db #0x79	; 121	'y'
      00BE4D 78                    1779 	.db #0x78	; 120	'x'
      00BE4E EF                    1780 	.db #0xef	; 239
      00BE4F 49                    1781 	.db #0x49	; 73	'I'
      00BE50 3E                    1782 	.db #0x3e	; 62
      00BE51 EF                    1783 	.db #0xef	; 239
      00BE52 FD                    1784 	.db #0xfd	; 253
      00BE53 8F                    1785 	.db #0x8f	; 143
      00BE54 EF                    1786 	.db #0xef	; 239
      00BE55 00                    1787 	.db #0x00	; 0
      00BE56 C6                    1788 	.db #0xc6	; 198
      00BE57 D1                    1789 	.db #0xd1	; 209
      00BE58 DB                    1790 	.db #0xdb	; 219
      00BE59 FB                    1791 	.db #0xfb	; 251
      00BE5A EB                    1792 	.db #0xeb	; 235
      00BE5B DE                    1793 	.db #0xde	; 222
      00BE5C 66                    1794 	.db #0x66	; 102	'f'
      00BE5D 63                    1795 	.db #0x63	; 99	'c'
      00BE5E 0C                    1796 	.db #0x0c	; 12
      00BE5F 92                    1797 	.db #0x92	; 146
      00BE60 7B                    1798 	.db #0x7b	; 123
      00BE61 F9                    1799 	.db #0xf9	; 249
      00BE62 D4                    1800 	.db #0xd4	; 212
      00BE63 7A                    1801 	.db #0x7a	; 122	'z'
      00BE64 4F                    1802 	.db #0x4f	; 79	'O'
      00BE65 83                    1803 	.db #0x83	; 131
      00BE66 4B                    1804 	.db #0x4b	; 75	'K'
      00BE67 86                    1805 	.db #0x86	; 134
      00BE68 0E                    1806 	.db #0x0e	; 14
      00BE69 6A                    1807 	.db #0x6a	; 106	'j'
      00BE6A F2                    1808 	.db #0xf2	; 242
      00BE6B 22                    1809 	.db #0x22	; 34
      00BE6C 22                    1810 	.db #0x22	; 34
      00BE6D 0B                    1811 	.db #0x0b	; 11
      00BE6E 03                    1812 	.db #0x03	; 3
      00BE6F BA                    1813 	.db #0xba	; 186
      00BE70 67                    1814 	.db #0x67	; 103	'g'
      00BE71 9B                    1815 	.db #0x9b	; 155
      00BE72 7A                    1816 	.db #0x7a	; 122	'z'
      00BE73 E1                    1817 	.db #0xe1	; 225
      00BE74 BC                    1818 	.db #0xbc	; 188
      00BE75 37                    1819 	.db #0x37	; 55	'7'
      00BE76 26                    1820 	.db #0x26	; 38
      00BE77 46                    1821 	.db #0x46	; 70	'F'
      00BE78 78                    1822 	.db #0x78	; 120	'x'
      00BE79 05                    1823 	.db #0x05	; 5
      00BE7A 0D                    1824 	.db #0x0d	; 13
      00BE7B 95                    1825 	.db #0x95	; 149
      00BE7C 02                    1826 	.db #0x02	; 2
      00BE7D E4                    1827 	.db #0xe4	; 228
      00BE7E 18                    1828 	.db #0x18	; 24
      00BE7F CA                    1829 	.db #0xca	; 202
      00BE80 33                    1830 	.db #0x33	; 51	'3'
      00BE81 EA                    1831 	.db #0xea	; 234
      00BE82 24                    1832 	.db #0x24	; 36
      00BE83 C8                    1833 	.db #0xc8	; 200
      00BE84 81                    1834 	.db #0x81	; 129
      00BE85 4E                    1835 	.db #0x4e	; 78	'N'
      00BE86 47                    1836 	.db #0x47	; 71	'G'
      00BE87 A8                    1837 	.db #0xa8	; 168
      00BE88 44                    1838 	.db #0x44	; 68	'D'
      00BE89 DD                    1839 	.db #0xdd	; 221
      00BE8A 91                    1840 	.db #0x91	; 145
      00BE8B 6D                    1841 	.db #0x6d	; 109	'm'
      00BE8C 69                    1842 	.db #0x69	; 105	'i'
      00BE8D DB                    1843 	.db #0xdb	; 219
      00BE8E 4F                    1844 	.db #0x4f	; 79	'O'
      00BE8F 3A                    1845 	.db #0x3a	; 58
      00BE90 43                    1846 	.db #0x43	; 67	'C'
      00BE91 9D                    1847 	.db #0x9d	; 157
      00BE92 26                    1848 	.db #0x26	; 38
      00BE93 49                    1849 	.db #0x49	; 73	'I'
      00BE94 4C                    1850 	.db #0x4c	; 76	'L'
      00BE95 EF                    1851 	.db #0xef	; 239
      00BE96 2B                    1852 	.db #0x2b	; 43
      00BE97 D8                    1853 	.db #0xd8	; 216
      00BE98 55                    1854 	.db #0x55	; 85	'U'
      00BE99 95                    1855 	.db #0x95	; 149
      00BE9A 70                    1856 	.db #0x70	; 112	'p'
      00BE9B B1                    1857 	.db #0xb1	; 177
      00BE9C CC                    1858 	.db #0xcc	; 204
      00BE9D CF                    1859 	.db #0xcf	; 207
      00BE9E 13                    1860 	.db #0x13	; 19
      00BE9F 32                    1861 	.db #0x32	; 50	'2'
      00BEA0 6A                    1862 	.db #0x6a	; 106	'j'
      00BEA1 A1                    1863 	.db #0xa1	; 161
      00BEA2 FF                    1864 	.db #0xff	; 255
      00BEA3 99                    1865 	.db #0x99	; 153
      00BEA4 61                    1866 	.db #0x61	; 97	'a'
      00BEA5 95                    1867 	.db #0x95	; 149
      00BEA6 B1                    1868 	.db #0xb1	; 177
      00BEA7 89                    1869 	.db #0x89	; 137
      00BEA8 9B                    1870 	.db #0x9b	; 155
      00BEA9 11                    1871 	.db #0x11	; 17
      00BEAA D9                    1872 	.db #0xd9	; 217
      00BEAB 35                    1873 	.db #0x35	; 53	'5'
      00BEAC 78                    1874 	.db #0x78	; 120	'x'
      00BEAD ED                    1875 	.db #0xed	; 237
      00BEAE CD                    1876 	.db #0xcd	; 205
      00BEAF 94                    1877 	.db #0x94	; 148
      00BEB0 6E                    1878 	.db #0x6e	; 110	'n'
      00BEB1 60                    1879 	.db #0x60	; 96
      00BEB2 8E                    1880 	.db #0x8e	; 142
      00BEB3 63                    1881 	.db #0x63	; 99	'c'
      00BEB4 8B                    1882 	.db #0x8b	; 139
      00BEB5 FF                    1883 	.db #0xff	; 255
      00BEB6 4E                    1884 	.db #0x4e	; 78	'N'
      00BEB7 20                    1885 	.db #0x20	; 32
      00BEB8 7A                    1886 	.db #0x7a	; 122	'z'
      00BEB9 B5                    1887 	.db #0xb5	; 181
      00BEBA 87                    1888 	.db #0x87	; 135
      00BEBB C2                    1889 	.db #0xc2	; 194
      00BEBC 35                    1890 	.db #0x35	; 53	'5'
      00BEBD A4                    1891 	.db #0xa4	; 164
      00BEBE 6D                    1892 	.db #0x6d	; 109	'm'
      00BEBF 18                    1893 	.db #0x18	; 24
      00BEC0 C1                    1894 	.db #0xc1	; 193
      00BEC1 A3                    1895 	.db #0xa3	; 163
      00BEC2 DB                    1896 	.db #0xdb	; 219
      00BEC3 53                    1897 	.db #0x53	; 83	'S'
      00BEC4 1D                    1898 	.db #0x1d	; 29
      00BEC5 EC                    1899 	.db #0xec	; 236
      00BEC6 F0                    1900 	.db #0xf0	; 240
      00BEC7 BF                    1901 	.db #0xbf	; 191
      00BEC8 4A                    1902 	.db #0x4a	; 74	'J'
      00BEC9 4C                    1903 	.db #0x4c	; 76	'L'
      00BECA 4A                    1904 	.db #0x4a	; 74	'J'
      00BECB C4                    1905 	.db #0xc4	; 196
      00BECC AA                    1906 	.db #0xaa	; 170
      00BECD 37                    1907 	.db #0x37	; 55	'7'
      00BECE 19                    1908 	.db #0x19	; 25
      00BECF 34                    1909 	.db #0x34	; 52	'4'
      00BED0 3F                    1910 	.db #0x3f	; 63
      00BED1 A1                    1911 	.db #0xa1	; 161
      00BED2 D3                    1912 	.db #0xd3	; 211
      00BED3 1A                    1913 	.db #0x1a	; 26
      00BED4 5C                    1914 	.db #0x5c	; 92
      00BED5 03                    1915 	.db #0x03	; 3
      00BED6 4D                    1916 	.db #0x4d	; 77	'M'
      00BED7 BC                    1917 	.db #0xbc	; 188
      00BED8 10                    1918 	.db #0x10	; 16
      00BED9 2E                    1919 	.db #0x2e	; 46
      00BEDA 80                    1920 	.db #0x80	; 128
      00BEDB F7                    1921 	.db #0xf7	; 247
      00BEDC D6                    1922 	.db #0xd6	; 214
      00BEDD 82                    1923 	.db #0x82	; 130
      00BEDE 24                    1924 	.db #0x24	; 36
      00BEDF 4C                    1925 	.db #0x4c	; 76	'L'
      00BEE0 87                    1926 	.db #0x87	; 135
      00BEE1 B9                    1927 	.db #0xb9	; 185
      00BEE2 F8                    1928 	.db #0xf8	; 248
      00BEE3 BE                    1929 	.db #0xbe	; 190
      00BEE4 67                    1930 	.db #0x67	; 103	'g'
      00BEE5 96                    1931 	.db #0x96	; 150
      00BEE6 89                    1932 	.db #0x89	; 137
      00BEE7 30                    1933 	.db #0x30	; 48	'0'
      00BEE8 C8                    1934 	.db #0xc8	; 200
      00BEE9 8D                    1935 	.db #0x8d	; 141
      00BEEA 2C                    1936 	.db #0x2c	; 44
      00BEEB F5                    1937 	.db #0xf5	; 245
      00BEEC 06                    1938 	.db #0x06	; 6
      00BEED 05                    1939 	.db #0x05	; 5
      00BEEE 7C                    1940 	.db #0x7c	; 124
      00BEEF 48                    1941 	.db #0x48	; 72	'H'
      00BEF0 1B                    1942 	.db #0x1b	; 27
      00BEF1 76                    1943 	.db #0x76	; 118	'v'
      00BEF2 AA                    1944 	.db #0xaa	; 170
      00BEF3 3D                    1945 	.db #0x3d	; 61
      00BEF4 28                    1946 	.db #0x28	; 40
      00BEF5 FC                    1947 	.db #0xfc	; 252
      00BEF6 80                    1948 	.db #0x80	; 128
      00BEF7 75                    1949 	.db #0x75	; 117	'u'
      00BEF8 EB                    1950 	.db #0xeb	; 235
      00BEF9 78                    1951 	.db #0x78	; 120	'x'
      00BEFA D0                    1952 	.db #0xd0	; 208
      00BEFB 8A                    1953 	.db #0x8a	; 138
      00BEFC 8F                    1954 	.db #0x8f	; 143
      00BEFD 27                    1955 	.db #0x27	; 39
      00BEFE F7                    1956 	.db #0xf7	; 247
      00BEFF F2                    1957 	.db #0xf2	; 242
      00BF00 EB                    1958 	.db #0xeb	; 235
      00BF01 58                    1959 	.db #0x58	; 88	'X'
      00BF02 37                    1960 	.db #0x37	; 55	'7'
      00BF03 3C                    1961 	.db #0x3c	; 60
      00BF04 2B                    1962 	.db #0x2b	; 43
      00BF05 6F                    1963 	.db #0x6f	; 111	'o'
      00BF06 0E                    1964 	.db #0x0e	; 14
      00BF07 C7                    1965 	.db #0xc7	; 199
      00BF08 E2                    1966 	.db #0xe2	; 226
      00BF09 A0                    1967 	.db #0xa0	; 160
      00BF0A 97                    1968 	.db #0x97	; 151
      00BF0B EE                    1969 	.db #0xee	; 238
      00BF0C FD                    1970 	.db #0xfd	; 253
      00BF0D 9F                    1971 	.db #0x9f	; 159
      00BF0E 45                    1972 	.db #0x45	; 69	'E'
      00BF0F 17                    1973 	.db #0x17	; 23
      00BF10 94                    1974 	.db #0x94	; 148
      00BF11 E6                    1975 	.db #0xe6	; 230
      00BF12 E7                    1976 	.db #0xe7	; 231
      00BF13 FA                    1977 	.db #0xfa	; 250
      00BF14 4C                    1978 	.db #0x4c	; 76	'L'
      00BF15 7A                    1979 	.db #0x7a	; 122	'z'
      00BF16 D6                    1980 	.db #0xd6	; 214
      00BF17 7A                    1981 	.db #0x7a	; 122	'z'
      00BF18 7B                    1982 	.db #0x7b	; 123
      00BF19 ED                    1983 	.db #0xed	; 237
      00BF1A 10                    1984 	.db #0x10	; 16
      00BF1B C5                    1985 	.db #0xc5	; 197
      00BF1C BC                    1986 	.db #0xbc	; 188
      00BF1D E3                    1987 	.db #0xe3	; 227
      00BF1E A9                    1988 	.db #0xa9	; 169
      00BF1F 1F                    1989 	.db #0x1f	; 31
      00BF20 CF                    1990 	.db #0xcf	; 207
      00BF21 C4                    1991 	.db #0xc4	; 196
      00BF22 9D                    1992 	.db #0x9d	; 157
      00BF23 DC                    1993 	.db #0xdc	; 220
      00BF24 45                    1994 	.db #0x45	; 69	'E'
      00BF25 2A                    1995 	.db #0x2a	; 42
      00BF26 69                    1996 	.db #0x69	; 105	'i'
      00BF27 57                    1997 	.db #0x57	; 87	'W'
      00BF28 8F                    1998 	.db #0x8f	; 143
      00BF29 EC                    1999 	.db #0xec	; 236
      00BF2A 85                    2000 	.db #0x85	; 133
      00BF2B 6C                    2001 	.db #0x6c	; 108	'l'
      00BF2C 43                    2002 	.db #0x43	; 67	'C'
      00BF2D 1C                    2003 	.db #0x1c	; 28
      00BF2E BA                    2004 	.db #0xba	; 186
      00BF2F 89                    2005 	.db #0x89	; 137
      00BF30 68                    2006 	.db #0x68	; 104	'h'
      00BF31 4A                    2007 	.db #0x4a	; 74	'J'
      00BF32 1C                    2008 	.db #0x1c	; 28
      00BF33 91                    2009 	.db #0x91	; 145
      00BF34 3F                    2010 	.db #0x3f	; 63
      00BF35 D1                    2011 	.db #0xd1	; 209
      00BF36 B3                    2012 	.db #0xb3	; 179
      00BF37 96                    2013 	.db #0x96	; 150
      00BF38 1D                    2014 	.db #0x1d	; 29
      00BF39 7C                    2015 	.db #0x7c	; 124
      00BF3A 14                    2016 	.db #0x14	; 20
      00BF3B 77                    2017 	.db #0x77	; 119	'w'
      00BF3C 9C                    2018 	.db #0x9c	; 156
      00BF3D 74                    2019 	.db #0x74	; 116	't'
      00BF3E 36                    2020 	.db #0x36	; 54	'6'
      00BF3F FF                    2021 	.db #0xff	; 255
      00BF40 2C                    2022 	.db #0x2c	; 44
      00BF41 66                    2023 	.db #0x66	; 102	'f'
      00BF42 AF                    2024 	.db #0xaf	; 175
      00BF43 0F                    2025 	.db #0x0f	; 15
      00BF44 3C                    2026 	.db #0x3c	; 60
      00BF45 A2                    2027 	.db #0xa2	; 162
      00BF46 23                    2028 	.db #0x23	; 35
      00BF47 85                    2029 	.db #0x85	; 133
      00BF48 05                    2030 	.db #0x05	; 5
      00BF49 87                    2031 	.db #0x87	; 135
      00BF4A DA                    2032 	.db #0xda	; 218
      00BF4B 61                    2033 	.db #0x61	; 97	'a'
      00BF4C 5E                    2034 	.db #0x5e	; 94
      00BF4D 42                    2035 	.db #0x42	; 66	'B'
      00BF4E 54                    2036 	.db #0x54	; 84	'T'
      00BF4F 60                    2037 	.db #0x60	; 96
      00BF50 23                    2038 	.db #0x23	; 35
      00BF51 CA                    2039 	.db #0xca	; 202
      00BF52 BC                    2040 	.db #0xbc	; 188
      00BF53 B3                    2041 	.db #0xb3	; 179
      00BF54 18                    2042 	.db #0x18	; 24
      00BF55 1D                    2043 	.db #0x1d	; 29
      00BF56 F8                    2044 	.db #0xf8	; 248
      00BF57 0A                    2045 	.db #0x0a	; 10
      00BF58 55                    2046 	.db #0x55	; 85	'U'
      00BF59 CD                    2047 	.db #0xcd	; 205
      00BF5A A3                    2048 	.db #0xa3	; 163
      00BF5B DE                    2049 	.db #0xde	; 222
      00BF5C FF                    2050 	.db #0xff	; 255
      00BF5D B2                    2051 	.db #0xb2	; 178
      00BF5E 2A                    2052 	.db #0x2a	; 42
      00BF5F 35                    2053 	.db #0x35	; 53	'5'
      00BF60 00                    2054 	.db #0x00	; 0
      00BF61 D6                    2055 	.db #0xd6	; 214
      00BF62 7B                    2056 	.db #0x7b	; 123
      00BF63 E8                    2057 	.db #0xe8	; 232
      00BF64 F2                    2058 	.db #0xf2	; 242
      00BF65 1A                    2059 	.db #0x1a	; 26
      00BF66 BC                    2060 	.db #0xbc	; 188
      00BF67 F5                    2061 	.db #0xf5	; 245
      00BF68 7E                    2062 	.db #0x7e	; 126
      00BF69 48                    2063 	.db #0x48	; 72	'H'
      00BF6A 72                    2064 	.db #0x72	; 114	'r'
      00BF6B E0                    2065 	.db #0xe0	; 224
      00BF6C E4                    2066 	.db #0xe4	; 228
      00BF6D E0                    2067 	.db #0xe0	; 224
      00BF6E 27                    2068 	.db #0x27	; 39
      00BF6F 87                    2069 	.db #0x87	; 135
      00BF70 9A                    2070 	.db #0x9a	; 154
      00BF71 51                    2071 	.db #0x51	; 81	'Q'
      00BF72 D4                    2072 	.db #0xd4	; 212
      00BF73 DD                    2073 	.db #0xdd	; 221
      00BF74 C3                    2074 	.db #0xc3	; 195
      00BF75 AA                    2075 	.db #0xaa	; 170
      00BF76 49                    2076 	.db #0x49	; 73	'I'
      00BF77 5A                    2077 	.db #0x5a	; 90	'Z'
      00BF78 2A                    2078 	.db #0x2a	; 42
      00BF79 00                    2079 	.db #0x00	; 0
      00BF7A A0                    2080 	.db #0xa0	; 160
      00BF7B 8C                    2081 	.db #0x8c	; 140
      00BF7C FF                    2082 	.db #0xff	; 255
      00BF7D 74                    2083 	.db #0x74	; 116	't'
      00BF7E BF                    2084 	.db #0xbf	; 191
      00BF7F EC                    2085 	.db #0xec	; 236
      00BF80 1D                    2086 	.db #0x1d	; 29
      00BF81 F1                    2087 	.db #0xf1	; 241
      00BF82 00                    2088 	.db #0x00	; 0
      00BF83 01                    2089 	.db #0x01	; 1
      00BF84 D8                    2090 	.db #0xd8	; 216
      00BF85 02                    2091 	.db #0x02	; 2
      00BF86 CC                    2092 	.db #0xcc	; 204
      00BF87 07                    2093 	.db #0x07	; 7
      00BF88 00                    2094 	.db #0x00	; 0
      00BF89 00                    2095 	.db #0x00	; 0
      00BF8A C4                    2096 	.db #0xc4	; 196
      00BF8B 5E                    2097 	.db #0x5e	; 94
      00BF8C 2C                    2098 	.db #0x2c	; 44
      00BF8D 7E                    2099 	.db #0x7e	; 126
      00BF8E B1                    2100 	.db #0xb1	; 177
      00BF8F C4                    2101 	.db #0xc4	; 196
      00BF90 67                    2102 	.db #0x67	; 103	'g'
      00BF91 FB                    2103 	.db #0xfb	; 251
      00BF92 02                    2104 	.db #0x02	; 2
      00BF93 00                    2105 	.db #0x00	; 0
      00BF94 00                    2106 	.db #0x00	; 0
      00BF95 00                    2107 	.db #0x00	; 0
      00BF96 00                    2108 	.db #0x00	; 0
      00BF97 04                    2109 	.db #0x04	; 4
      00BF98 59                    2110 	.db #0x59	; 89	'Y'
      00BF99 5A                    2111 	.db #0x5a	; 90	'Z'
                                   2112 	.area CSEG    (CODE)
                                   2113 	.area CONST   (CODE)
      00BF9A                       2114 _vial_handle_cmd_keyboard_uid_40000_623:
      00BF9A 04                    2115 	.db #0x04	; 4
      00BF9B 70                    2116 	.db #0x70	; 112	'p'
      00BF9C FF                    2117 	.db #0xff	; 255
      00BF9D 90                    2118 	.db #0x90	; 144
      00BF9E 01                    2119 	.db #0x01	; 1
      00BF9F B9                    2120 	.db #0xb9	; 185
      00BFA0 15                    2121 	.db #0x15	; 21
      00BFA1 D3                    2122 	.db #0xd3	; 211
                                   2123 	.area CSEG    (CODE)
                                   2124 	.area XINIT   (CODE)
      00C1D0                       2125 __xinit__vial_unlocked:
      00C1D0 00                    2126 	.db #0x00	;  0
      00C1D1                       2127 __xinit__vial_unlock_in_progress:
      00C1D1 00                    2128 	.db #0x00	;  0
      00C1D2                       2129 __xinit__vial_unlock_counter:
      00C1D2 00                    2130 	.db #0x00	; 0
      00C1D3                       2131 __xinit__vial_unlock_combo_rows:
      00C1D3 00                    2132 	.db #0x00	; 0
      00C1D4 00                    2133 	.db #0x00	; 0
      00C1D5                       2134 __xinit__vial_unlock_combo_cols:
      00C1D5 00                    2135 	.db #0x00	; 0
      00C1D6 05                    2136 	.db #0x05	; 5
                                   2137 	.area CABS    (ABS,CODE)
                                   2138 
                                   2139 ; Experimental exact instruction outlining.
                                   2140 	.globl _ak820_outline_0004
                                   2141 	.globl _ak820_outline_0007
                                   2142 	.globl _ak820_outline_0010
                                   2143 	.globl _ak820_outline_0011
                                   2144 	.globl _ak820_outline_0012
                                   2145 	.globl _ak820_outline_0015
                                   2146 	.globl _ak820_outline_0016
                                   2147 	.globl _ak820_outline_0017
                                   2148 	.globl _ak820_outline_0021
                                   2149 	.globl _ak820_outline_0024
                                   2150 	.globl _ak820_outline_0030
                                   2151 	.globl _ak820_outline_0031
                                   2152 	.globl _ak820_outline_0034
                                   2153 	.globl _ak820_outline_0037
                                   2154 	.globl _ak820_outline_0046
                                   2155 	.globl _ak820_outline_0051
                                   2156 	.globl _ak820_outline_0054
                                   2157 	.globl _ak820_outline_0057
                                   2158 	.globl _ak820_outline_0059
                                   2159 	.globl _ak820_outline_0061
                                   2160 	.globl _ak820_outline_0073
                                   2161 	.globl _ak820_outline_0077
                                   2162 	.globl _ak820_outline_0097
                                   2163 	.globl _ak820_outline_0103
                                   2164 	.globl _ak820_outline_0104
                                   2165 	.globl _ak820_outline_0116
                                   2166 	.globl _ak820_outline_0117
                                   2167 	.globl _ak820_outline_0121
                                   2168 	.globl _ak820_outline_0122
                                   2169 	.globl _ak820_outline_0123
                                   2170 	.globl _ak820_outline_0124
                                   2171 	.globl _ak820_outline_0126
                                   2172 	.globl _ak820_outline_0127
                                   2173 	.globl _ak820_outline_0132
                                   2174 	.globl _ak820_outline_0137
                                   2175 	.globl _ak820_outline_0141
                                   2176 	.globl _ak820_outline_0153
                                   2177 	.globl _ak820_outline_0179
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0024
      00B2BD                       2181 _ak820_outline_0024:
      00B2BD E0               [24] 2182 	movx	a,@dptr
      00B2BE FE               [12] 2183 	mov	r6,a
      00B2BF A3               [24] 2184 	inc	dptr
      00B2C0 E0               [24] 2185 	movx	a,@dptr
      00B2C1 FF               [12] 2186 	mov	r7,a
      00B2C2 90 0C 54         [24] 2187 	mov	dptr,#_g_vial_magic_keycode_override
      00B2C5 EE               [12] 2188 	mov	a,r6
      00B2C6 F0               [24] 2189 	movx	@dptr,a
      00B2C7 EF               [12] 2190 	mov	a,r7
      00B2C8 A3               [24] 2191 	inc	dptr
      00B2C9 F0               [24] 2192 	movx	@dptr,a
      00B2CA 8E 04            [24] 2193 	mov	ar4,r6
      00B2CC 8F 05            [24] 2194 	mov	ar5,r7
      00B2CE C3               [12] 2195 	clr	c
      00B2CF 74 FF            [12] 2196 	mov	a,#0xff
      00B2D1 9C               [12] 2197 	subb	a,r4
      00B2D2 74 1F            [12] 2198 	mov	a,#0x1f
      00B2D4 9D               [12] 2199 	subb	a,r5
      00B2D5 22               [24] 2200 	ret
                                   2201 
                                   2202 	.area CSEG (CODE)
                                   2203 ; function ak820_outline_0073
      00B2D6                       2204 _ak820_outline_0073:
      00B2D6 A3               [24] 2205 	inc	dptr
      00B2D7 F0               [24] 2206 	movx	@dptr,a
      00B2D8 E4               [12] 2207 	clr	a
      00B2D9 A3               [24] 2208 	inc	dptr
      00B2DA F0               [24] 2209 	movx	@dptr,a
      00B2DB 90 0D 7F         [24] 2210 	mov	dptr,#___memcpy_PARM_3
      00B2DE 74 0A            [12] 2211 	mov	a,#0x0a
      00B2E0 F0               [24] 2212 	movx	@dptr,a
      00B2E1 E4               [12] 2213 	clr	a
      00B2E2 A3               [24] 2214 	inc	dptr
      00B2E3 F0               [24] 2215 	movx	@dptr,a
      00B2E4 22               [24] 2216 	ret
                                   2217 
                                   2218 	.area CSEG (CODE)
                                   2219 ; function ak820_outline_0126
      00B2E5                       2220 _ak820_outline_0126:
      00B2E5 24 01            [12] 2221 	add	a,#_vial_unlock_combo_cols
      00B2E7 F5 82            [12] 2222 	mov	dpl,a
      00B2E9 E4               [12] 2223 	clr	a
      00B2EA 34 0E            [12] 2224 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B2EC F5 83            [12] 2225 	mov	dph,a
      00B2EE E0               [24] 2226 	movx	a,@dptr
      00B2EF 22               [24] 2227 	ret
                                   2228 
                                   2229 	.area CSEG (CODE)
                                   2230 ; function ak820_outline_0127
      00B2F0                       2231 _ak820_outline_0127:
      00B2F0 24 FF            [12] 2232 	add	a,#_vial_unlock_combo_rows
      00B2F2 F5 82            [12] 2233 	mov	dpl,a
      00B2F4 E4               [12] 2234 	clr	a
      00B2F5 34 0D            [12] 2235 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B2F7 F5 83            [12] 2236 	mov	dph,a
      00B2F9 E0               [24] 2237 	movx	a,@dptr
      00B2FA 22               [24] 2238 	ret
