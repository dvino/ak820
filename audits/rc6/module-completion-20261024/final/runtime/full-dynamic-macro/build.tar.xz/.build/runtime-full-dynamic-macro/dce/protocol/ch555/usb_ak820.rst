                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_keyboard_blocked
                                    286 	.globl _ak820_usb_take_keyboard_reset
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
      000016                        549 _control_setup_sloc1_1_0:
      000016                        550 	.ds 1
      000017                        551 _control_setup_sloc3_1_0:
      000017                        552 	.ds 2
      000019                        553 _control_setup_sloc4_1_0:
      000019                        554 	.ds 2
      00001B                        555 _ak820_usb_send_sloc0_1_0:
      00001B                        556 	.ds 2
      00001D                        557 _ak820_usb_send_sloc1_1_0:
      00001D                        558 	.ds 1
      00001E                        559 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        560 	.ds 2
                                    561 ;--------------------------------------------------------
                                    562 ; overlayable items in internal ram
                                    563 ;--------------------------------------------------------
                                    564 ;--------------------------------------------------------
                                    565 ; indirectly addressable internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area ISEG    (DATA)
                                    568 ;--------------------------------------------------------
                                    569 ; absolute internal ram data
                                    570 ;--------------------------------------------------------
                                    571 	.area IABS    (ABS,DATA)
                                    572 	.area IABS    (ABS,DATA)
                                    573 ;--------------------------------------------------------
                                    574 ; bit data
                                    575 ;--------------------------------------------------------
                                    576 	.area BSEG    (BIT)
      000015                        577 _control_setup_valid_interface_10000_287:
      000015                        578 	.ds 1
      000016                        579 _control_setup_zero_index_10000_287:
      000016                        580 	.ds 1
      000017                        581 _control_setup_zero_value_10000_287:
      000017                        582 	.ds 1
      000018                        583 _control_setup_zero_length_10000_287:
      000018                        584 	.ds 1
      000019                        585 _control_setup_sloc0_1_0:
      000019                        586 	.ds 1
      00001A                        587 _control_setup_sloc2_1_0:
      00001A                        588 	.ds 1
      00001B                        589 _ak820_usb_try_send_sloc0_1_0:
      00001B                        590 	.ds 1
      00001C                        591 _ak820_usb_raw_task_sloc1_1_0:
      00001C                        592 	.ds 1
      00001D                        593 _ak820_usb_keyboard_blocked_sloc0_1_0:
      00001D                        594 	.ds 1
      00001E                        595 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001E                        596 	.ds 1
                                    597 ;--------------------------------------------------------
                                    598 ; paged external ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area PSEG    (PAG,XDATA)
                                    601 ;--------------------------------------------------------
                                    602 ; uninitialized external ram data
                                    603 ;--------------------------------------------------------
                                    604 	.area XSEG    (XDATA)
      0007B7                        605 _D0SetupReqCode::
      0007B7                        606 	.ds 1
      0007B8                        607 _D0SetupLen::
      0007B8                        608 	.ds 2
      0007BA                        609 _pD0Descr::
      0007BA                        610 	.ds 3
      0007BD                        611 _D0UsbConfig::
      0007BD                        612 	.ds 1
      0007BE                        613 _USB_EnumStatus::
      0007BE                        614 	.ds 1
      0007BF                        615 _USB_SleepStatus::
      0007BF                        616 	.ds 1
      0007C0                        617 _MCU_Sleep_Operate::
      0007C0                        618 	.ds 1
      0007C1                        619 _KB_USB_UpStatus::
      0007C1                        620 	.ds 1
      0007C2                        621 _KB_USB_SetReport::
      0007C2                        622 	.ds 1
      0007C3                        623 _ak820_boot_stage::
      0007C3                        624 	.ds 1
      0007C4                        625 _ak820_main_heartbeat::
      0007C4                        626 	.ds 1
      0007C5                        627 _raw_state:
      0007C5                        628 	.ds 1
      0007C6                        629 _raw_buffer:
      0007C6                        630 	.ds 32
      0007E6                        631 _raw_reply_without_nvm:
      0007E6                        632 	.ds 1
      0007E7                        633 _keyboard_reset:
      0007E7                        634 	.ds 1
      0007E8                        635 _input_snapshot:
      0007E8                        636 	.ds 46
      000816                        637 _control_phase:
      000816                        638 	.ds 1
      000817                        639 _output_kind:
      000817                        640 	.ds 1
      000818                        641 _output_report_id:
      000818                        642 	.ds 1
      000819                        643 _control_zlp:
      000819                        644 	.ds 1
      00081A                        645 _control_pointer:
      00081A                        646 	.ds 2
      00081C                        647 _descriptor_select_PARM_2:
      00081C                        648 	.ds 1
      00081D                        649 _descriptor_select_PARM_3:
      00081D                        650 	.ds 2
      00081F                        651 _descriptor_select_type_10000_269:
      00081F                        652 	.ds 1
      000820                        653 _control_setup_length_10000_287:
      000820                        654 	.ds 2
      000822                        655 _control_setup_offset_10000_287:
      000822                        656 	.ds 1
      000823                        657 _ak820_usb_send_PARM_2:
      000823                        658 	.ds 2
      000825                        659 _ak820_usb_send_PARM_3:
      000825                        660 	.ds 1
      000826                        661 _ak820_usb_send_endpoint_10000_423:
      000826                        662 	.ds 1
      000827                        663 _ak820_usb_send_offset_10000_424:
      000827                        664 	.ds 1
      000828                        665 _ak820_usb_try_send_PARM_2:
      000828                        666 	.ds 2
      00082A                        667 _ak820_usb_try_send_PARM_3:
      00082A                        668 	.ds 1
      00082B                        669 _ak820_usb_try_send_endpoint_10000_444:
      00082B                        670 	.ds 1
      00082C                        671 _ak820_usb_try_send_sent_10000_445:
      00082C                        672 	.ds 1
      00082D                        673 _ak820_usb_raw_send_PARM_2:
      00082D                        674 	.ds 1
      00082E                        675 _ak820_usb_raw_send_report_10000_460:
      00082E                        676 	.ds 3
                                    677 ;--------------------------------------------------------
                                    678 ; absolute external ram data
                                    679 ;--------------------------------------------------------
                                    680 	.area XABS    (ABS,XDATA)
                                    681 ;--------------------------------------------------------
                                    682 ; initialized external ram data
                                    683 ;--------------------------------------------------------
                                    684 	.area XISEG   (XDATA)
                                    685 	.area HOME    (CODE)
                                    686 	.area GSINIT0 (CODE)
                                    687 	.area GSINIT1 (CODE)
                                    688 	.area GSINIT2 (CODE)
                                    689 	.area GSINIT3 (CODE)
                                    690 	.area GSINIT4 (CODE)
                                    691 	.area GSINIT5 (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 	.area GSFINAL (CODE)
                                    694 	.area CSEG    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; global & static initialisations
                                    697 ;--------------------------------------------------------
                                    698 	.area HOME    (CODE)
                                    699 	.area GSINIT  (CODE)
                                    700 	.area GSFINAL (CODE)
                                    701 	.area GSINIT  (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; Home
                                    704 ;--------------------------------------------------------
                                    705 	.area HOME    (CODE)
                                    706 	.area HOME    (CODE)
                                    707 ;--------------------------------------------------------
                                    708 ; code
                                    709 ;--------------------------------------------------------
                                    710 	.area CSEG    (CODE)
                                    711 ;------------------------------------------------------------
                                    712 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    713 ;------------------------------------------------------------
                                    714 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_46'
                                    715 ;------------------------------------------------------------
                                    716 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    717 ;	-----------------------------------------
                           000007   718 	ar7 = 0x07
                           000006   719 	ar6 = 0x06
                           000005   720 	ar5 = 0x05
                           000004   721 	ar4 = 0x04
                           000003   722 	ar3 = 0x03
                           000002   723 	ar2 = 0x02
                           000001   724 	ar1 = 0x01
                           000000   725 	ar0 = 0x00
                                    726 ;	 function raw_abort
                                    727 ;	-----------------------------------------
      005D21                        728 _raw_abort:
                                    729 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005D21 90 07 C5         [24]  730 	mov	dptr,#_raw_state
      005D24 E0               [24]  731 	movx	a,@dptr
      005D25 FF               [12]  732 	mov	r7,a
      005D26 BF 03 02         [24]  733 	cjne	r7,#0x03,00130$
      005D29 80 1C            [24]  734 	sjmp	00101$
      005D2B                        735 00130$:
      005D2B 90 07 C5         [24]  736 	mov	dptr,#_raw_state
      005D2E E0               [24]  737 	movx	a,@dptr
      005D2F FF               [12]  738 	mov	r7,a
      005D30 BF 04 02         [24]  739 	cjne	r7,#0x04,00131$
      005D33 80 12            [24]  740 	sjmp	00101$
      005D35                        741 00131$:
                                    742 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005D35 90 07 C5         [24]  743 	mov	dptr,#_raw_state
      005D38 E0               [24]  744 	movx	a,@dptr
      005D39 FF               [12]  745 	mov	r7,a
      005D3A BF 06 02         [24]  746 	cjne	r7,#0x06,00132$
      005D3D 80 08            [24]  747 	sjmp	00101$
      005D3F                        748 00132$:
      005D3F 90 07 C5         [24]  749 	mov	dptr,#_raw_state
      005D42 E0               [24]  750 	movx	a,@dptr
      005D43 FF               [12]  751 	mov	r7,a
      005D44 BF 07 08         [24]  752 	cjne	r7,#0x07,00102$
      005D47                        753 00101$:
                                    754 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      005D47 90 07 C5         [24]  755 	mov	dptr,#_raw_state
      005D4A 74 07            [12]  756 	mov	a,#0x07
      005D4C F0               [24]  757 	movx	@dptr,a
      005D4D 80 05            [24]  758 	sjmp	00103$
      005D4F                        759 00102$:
                                    760 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      005D4F 90 07 C5         [24]  761 	mov	dptr,#_raw_state
      005D52 E4               [12]  762 	clr	a
      005D53 F0               [24]  763 	movx	@dptr,a
      005D54                        764 00103$:
                                    765 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      005D54 90 08 17         [24]  766 	mov	dptr,#_output_kind
      005D57 E4               [12]  767 	clr	a
      005D58 F0               [24]  768 	movx	@dptr,a
                                    769 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      005D59 22               [24]  770 	ret
                                    771 ;------------------------------------------------------------
                                    772 ;Allocation info for local variables in function 'raw_complete'
                                    773 ;------------------------------------------------------------
                                    774 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    775 ;	-----------------------------------------
                                    776 ;	 function raw_complete
                                    777 ;	-----------------------------------------
      005D5A                        778 _raw_complete:
                                    779 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005D5A 90 07 C5         [24]  780 	mov	dptr,#_raw_state
      005D5D E0               [24]  781 	movx	a,@dptr
      005D5E FF               [12]  782 	mov	r7,a
      005D5F BF 04 07         [24]  783 	cjne	r7,#0x04,00104$
      005D62 90 07 C5         [24]  784 	mov	dptr,#_raw_state
      005D65 74 06            [12]  785 	mov	a,#0x06
      005D67 F0               [24]  786 	movx	@dptr,a
      005D68 22               [24]  787 	ret
      005D69                        788 00104$:
                                    789 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005D69 90 07 C5         [24]  790 	mov	dptr,#_raw_state
      005D6C E0               [24]  791 	movx	a,@dptr
      005D6D FF               [12]  792 	mov	r7,a
      005D6E BF 05 05         [24]  793 	cjne	r7,#0x05,00106$
      005D71 90 07 C5         [24]  794 	mov	dptr,#_raw_state
      005D74 E4               [12]  795 	clr	a
      005D75 F0               [24]  796 	movx	@dptr,a
      005D76                        797 00106$:
                                    798 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      005D76 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'endpoints_reset'
                                    802 ;------------------------------------------------------------
                                    803 ;i             Allocated with name '_endpoints_reset_i_10000_259'
                                    804 ;------------------------------------------------------------
                                    805 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    806 ;	-----------------------------------------
                                    807 ;	 function endpoints_reset
                                    808 ;	-----------------------------------------
      005D77                        809 _endpoints_reset:
                                    810 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      005D77 90 22 0C         [24]  811 	mov	dptr,#0x220c
      005D7A 74 01            [12]  812 	mov	a,#0x01
      005D7C F0               [24]  813 	movx	@dptr,a
                                    814 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005D7D F5 82            [12]  815 	mov	dpl,a
      005D7F 74 12            [12]  816 	mov	a,#0x12
      005D81 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005D82 A3               [24]  819 	inc	dptr
      005D83 F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005D84 A3               [24]  822 	inc	dptr
      005D85 F0               [24]  823 	movx	@dptr,a
                                    824 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005D86 90 22 0B         [24]  825 	mov	dptr,#0x220b
      005D89 E4               [12]  826 	clr	a
      005D8A F0               [24]  827 	movx	@dptr,a
      005D8B 15 82            [12]  828 	dec	dpl
      005D8D F0               [24]  829 	movx	@dptr,a
      005D8E 15 82            [12]  830 	dec	dpl
      005D90 F0               [24]  831 	movx	@dptr,a
                                    832 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005D91 FF               [12]  833 	mov	r7,a
      005D92                        834 00103$:
      005D92 EF               [12]  835 	mov	a,r7
      005D93 24 E8            [12]  836 	add	a, #_input_snapshot
      005D95 F5 82            [12]  837 	mov	dpl,a
      005D97 E4               [12]  838 	clr	a
      005D98 34 07            [12]  839 	addc	a, #(_input_snapshot >> 8)
      005D9A F5 83            [12]  840 	mov	dph,a
      005D9C E4               [12]  841 	clr	a
      005D9D F0               [24]  842 	movx	@dptr,a
      005D9E 0F               [12]  843 	inc	r7
      005D9F BF 2E 00         [24]  844 	cjne	r7,#0x2e,00139$
      005DA2                        845 00139$:
      005DA2 40 EE            [24]  846 	jc	00103$
                                    847 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005DA4 90 07 F0         [24]  848 	mov	dptr,#(_input_snapshot + 0x0008)
      005DA7 74 06            [12]  849 	mov	a,#0x06
      005DA9 F0               [24]  850 	movx	@dptr,a
                                    851 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005DAA 90 08 10         [24]  852 	mov	dptr,#(_input_snapshot + 0x0028)
      005DAD 03               [12]  853 	rr	a
      005DAE F0               [24]  854 	movx	@dptr,a
                                    855 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005DAF 90 08 13         [24]  856 	mov	dptr,#(_input_snapshot + 0x002b)
      005DB2 04               [12]  857 	inc	a
      005DB3 F0               [24]  858 	movx	@dptr,a
                                    859 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005DB4 7F 00            [12]  860 	mov	r7,#0x00
      005DB6                        861 00105$:
      005DB6 8F 06            [24]  862 	mov	ar6,r7
      005DB8 74 C0            [12]  863 	mov	a,#0xc0
      005DBA 2E               [12]  864 	add	a, r6
      005DBB F5 82            [12]  865 	mov	dpl,a
      005DBD 74 10            [12]  866 	mov	a,#0x10
      005DBF 24 00            [12]  867 	add	a, #0x00
      005DC1 F5 83            [12]  868 	mov	dph,a
      005DC3 E4               [12]  869 	clr	a
      005DC4 F0               [24]  870 	movx	@dptr,a
      005DC5 0F               [12]  871 	inc	r7
      005DC6 BF 20 00         [24]  872 	cjne	r7,#0x20,00141$
      005DC9                        873 00141$:
      005DC9 40 EB            [24]  874 	jc	00105$
                                    875 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    876 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      005DCB 02 5D 21         [24]  877 	ljmp	_raw_abort
                                    878 ;------------------------------------------------------------
                                    879 ;Allocation info for local variables in function 'control_stall'
                                    880 ;------------------------------------------------------------
                                    881 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    882 ;	-----------------------------------------
                                    883 ;	 function control_stall
                                    884 ;	-----------------------------------------
      005DCE                        885 _control_stall:
                                    886 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005DCE 90 07 C5         [24]  887 	mov	dptr,#_raw_state
      005DD1 E0               [24]  888 	movx	a,@dptr
      005DD2 FF               [12]  889 	mov	r7,a
      005DD3 BF 01 05         [24]  890 	cjne	r7,#0x01,00102$
      005DD6 90 07 C5         [24]  891 	mov	dptr,#_raw_state
      005DD9 E4               [12]  892 	clr	a
      005DDA F0               [24]  893 	movx	@dptr,a
      005DDB                        894 00102$:
                                    895 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      005DDB 90 08 17         [24]  896 	mov	dptr,#_output_kind
      005DDE E4               [12]  897 	clr	a
      005DDF F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      005DE0 90 08 16         [24]  900 	mov	dptr,#_control_phase
      005DE3 F0               [24]  901 	movx	@dptr,a
                                    902 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      005DE4 90 07 B7         [24]  903 	mov	dptr,#_D0SetupReqCode
      005DE7 14               [12]  904 	dec	a
      005DE8 F0               [24]  905 	movx	@dptr,a
                                    906 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005DE9 90 22 00         [24]  907 	mov	dptr,#0x2200
      005DEC 74 CF            [12]  908 	mov	a,#0xcf
      005DEE F0               [24]  909 	movx	@dptr,a
                                    910 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      005DEF 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'control_next'
                                    914 ;------------------------------------------------------------
                                    915 ;i             Allocated with name '_control_next_i_10000_266'
                                    916 ;length        Allocated with name '_control_next_length_10000_266'
                                    917 ;------------------------------------------------------------
                                    918 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function control_next
                                    921 ;	-----------------------------------------
      005DF0                        922 _control_next:
                                    923 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005DF0 90 07 B8         [24]  924 	mov	dptr,#_D0SetupLen
      005DF3 E0               [24]  925 	movx	a,@dptr
      005DF4 FE               [12]  926 	mov	r6,a
      005DF5 A3               [24]  927 	inc	dptr
      005DF6 E0               [24]  928 	movx	a,@dptr
      005DF7 FF               [12]  929 	mov	r7,a
      005DF8 C3               [12]  930 	clr	c
      005DF9 74 40            [12]  931 	mov	a,#0x40
      005DFB 9E               [12]  932 	subb	a,r6
      005DFC E4               [12]  933 	clr	a
      005DFD 9F               [12]  934 	subb	a,r7
      005DFE 50 04            [24]  935 	jnc	00109$
                                    936 ;	free result
      005E00 7E 40            [12]  937 	mov	r6,#0x40
      005E02 80 07            [24]  938 	sjmp	00110$
      005E04                        939 00109$:
      005E04 90 07 B8         [24]  940 	mov	dptr,#_D0SetupLen
      005E07 E0               [24]  941 	movx	a,@dptr
      005E08 FE               [12]  942 	mov	r6,a
      005E09 A3               [24]  943 	inc	dptr
      005E0A E0               [24]  944 	movx	a,@dptr
      005E0B                        945 00110$:
                                    946 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005E0B 7F 00            [12]  947 	mov	r7,#0x00
      005E0D                        948 00105$:
      005E0D C3               [12]  949 	clr	c
      005E0E EF               [12]  950 	mov	a,r7
      005E0F 9E               [12]  951 	subb	a,r6
      005E10 50 2A            [24]  952 	jnc	00101$
      005E12 8F 04            [24]  953 	mov	ar4,r7
      005E14 74 10            [12]  954 	mov	a,#0x10
      005E16 24 00            [12]  955 	add	a, #0x00
      005E18 FD               [12]  956 	mov	r5,a
      005E19 90 08 1A         [24]  957 	mov	dptr,#_control_pointer
      005E1C E0               [24]  958 	movx	a,@dptr
      005E1D FA               [12]  959 	mov	r2,a
      005E1E A3               [24]  960 	inc	dptr
      005E1F E0               [24]  961 	movx	a,@dptr
      005E20 FB               [12]  962 	mov	r3,a
      005E21 8A 82            [24]  963 	mov	dpl,r2
      005E23 8B 83            [24]  964 	mov	dph,r3
      005E25 E4               [12]  965 	clr	a
      005E26 93               [24]  966 	movc	a,@a+dptr
      005E27 F9               [12]  967 	mov	r1,a
      005E28 90 08 1A         [24]  968 	mov	dptr,#_control_pointer
      005E2B 74 01            [12]  969 	mov	a,#0x01
      005E2D 2A               [12]  970 	add	a, r2
      005E2E F0               [24]  971 	movx	@dptr,a
      005E2F E4               [12]  972 	clr	a
      005E30 3B               [12]  973 	addc	a, r3
      005E31 A3               [24]  974 	inc	dptr
      005E32 F0               [24]  975 	movx	@dptr,a
      005E33 8C 82            [24]  976 	mov	dpl,r4
      005E35 8D 83            [24]  977 	mov	dph,r5
      005E37 E9               [12]  978 	mov	a,r1
      005E38 F0               [24]  979 	movx	@dptr,a
      005E39 0F               [12]  980 	inc	r7
      005E3A 80 D1            [24]  981 	sjmp	00105$
      005E3C                        982 00101$:
                                    983 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      005E3C 8E 05            [24]  984 	mov	ar5,r6
      005E3E 7F 00            [12]  985 	mov	r7,#0x00
      005E40 90 07 B8         [24]  986 	mov	dptr,#_D0SetupLen
      005E43 E0               [24]  987 	movx	a,@dptr
      005E44 FB               [12]  988 	mov	r3,a
      005E45 A3               [24]  989 	inc	dptr
      005E46 E0               [24]  990 	movx	a,@dptr
      005E47 FC               [12]  991 	mov	r4,a
      005E48 EB               [12]  992 	mov	a,r3
      005E49 C3               [12]  993 	clr	c
      005E4A 9D               [12]  994 	subb	a,r5
      005E4B FB               [12]  995 	mov	r3,a
      005E4C EC               [12]  996 	mov	a,r4
      005E4D 9F               [12]  997 	subb	a,r7
      005E4E FC               [12]  998 	mov	r4,a
      005E4F 90 07 B8         [24]  999 	mov	dptr,#_D0SetupLen
      005E52 EB               [12] 1000 	mov	a,r3
      005E53 F0               [24] 1001 	movx	@dptr,a
      005E54 EC               [12] 1002 	mov	a,r4
      005E55 A3               [24] 1003 	inc	dptr
      005E56 F0               [24] 1004 	movx	@dptr,a
                                   1005 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      005E57 EE               [12] 1006 	mov	a,r6
      005E58 70 05            [24] 1007 	jnz	00103$
      005E5A 90 08 19         [24] 1008 	mov	dptr,#_control_zlp
      005E5D E4               [12] 1009 	clr	a
      005E5E F0               [24] 1010 	movx	@dptr,a
      005E5F                       1011 00103$:
                                   1012 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      005E5F 90 22 08         [24] 1013 	mov	dptr,#0x2208
      005E62 EE               [12] 1014 	mov	a,r6
      005E63 F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005E64 90 22 00         [24] 1017 	mov	dptr,#0x2200
      005E67 E0               [24] 1018 	movx	a,@dptr
      005E68 54 C0            [12] 1019 	anl	a,#0xc0
      005E6A F0               [24] 1020 	movx	@dptr,a
                                   1021 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      005E6B 22               [24] 1022 	ret
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'descriptor_select'
                                   1025 ;------------------------------------------------------------
                                   1026 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1027 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1028 ;type          Allocated with name '_descriptor_select_type_10000_269'
                                   1029 ;hid           Allocated with name '_descriptor_select_hid_30000_282'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function descriptor_select
                                   1034 ;	-----------------------------------------
      005E6C                       1035 _descriptor_select:
      005E6C E5 82            [12] 1036 	mov	a,dpl
      005E6E 90 08 1F         [24] 1037 	mov	dptr,#_descriptor_select_type_10000_269
      005E71 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005E72 E0               [24] 1040 	movx	a,@dptr
      005E73 FF               [12] 1041 	mov	r7,a
      005E74 BF 01 20         [24] 1042 	cjne	r7,#0x01,00102$
      005E77 90 08 1C         [24] 1043 	mov	dptr,#_descriptor_select_PARM_2
      005E7A E0               [24] 1044 	movx	a,@dptr
      005E7B 70 1A            [24] 1045 	jnz	00102$
      005E7D 90 08 1D         [24] 1046 	mov	dptr,#_descriptor_select_PARM_3
      005E80 E0               [24] 1047 	movx	a,@dptr
      005E81 F5 F0            [12] 1048 	mov	b,a
      005E83 A3               [24] 1049 	inc	dptr
      005E84 E0               [24] 1050 	movx	a,@dptr
      005E85 45 F0            [12] 1051 	orl	a,b
      005E87 70 0E            [24] 1052 	jnz	00102$
                                   1053 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005E89 90 08 1A         [24] 1054 	mov	dptr,#_control_pointer
      005E8C 74 DD            [12] 1055 	mov	a,#_DeviceDescriptor
      005E8E F0               [24] 1056 	movx	@dptr,a
      005E8F 74 C1            [12] 1057 	mov	a,#(_DeviceDescriptor >> 8)
      005E91 A3               [24] 1058 	inc	dptr
      005E92 F0               [24] 1059 	movx	@dptr,a
                                   1060 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      005E93 90 00 12         [24] 1061 	mov	dptr,#0x0012
      005E96 22               [24] 1062 	ret
      005E97                       1063 00102$:
                                   1064 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005E97 90 08 1F         [24] 1065 	mov	dptr,#_descriptor_select_type_10000_269
      005E9A E0               [24] 1066 	movx	a,@dptr
      005E9B FF               [12] 1067 	mov	r7,a
      005E9C BF 02 20         [24] 1068 	cjne	r7,#0x02,00106$
      005E9F 90 08 1C         [24] 1069 	mov	dptr,#_descriptor_select_PARM_2
      005EA2 E0               [24] 1070 	movx	a,@dptr
      005EA3 70 1A            [24] 1071 	jnz	00106$
      005EA5 90 08 1D         [24] 1072 	mov	dptr,#_descriptor_select_PARM_3
      005EA8 E0               [24] 1073 	movx	a,@dptr
      005EA9 F5 F0            [12] 1074 	mov	b,a
      005EAB A3               [24] 1075 	inc	dptr
      005EAC E0               [24] 1076 	movx	a,@dptr
      005EAD 45 F0            [12] 1077 	orl	a,b
      005EAF 70 0E            [24] 1078 	jnz	00106$
                                   1079 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005EB1 90 08 1A         [24] 1080 	mov	dptr,#_control_pointer
      005EB4 74 EF            [12] 1081 	mov	a,#_ConfigurationDescriptor
      005EB6 F0               [24] 1082 	movx	@dptr,a
      005EB7 74 C1            [12] 1083 	mov	a,#(_ConfigurationDescriptor >> 8)
      005EB9 A3               [24] 1084 	inc	dptr
      005EBA F0               [24] 1085 	movx	@dptr,a
                                   1086 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      005EBB 90 00 54         [24] 1087 	mov	dptr,#0x0054
      005EBE 22               [24] 1088 	ret
      005EBF                       1089 00106$:
                                   1090 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      005EBF 90 08 1F         [24] 1091 	mov	dptr,#_descriptor_select_type_10000_269
      005EC2 E0               [24] 1092 	movx	a,@dptr
      005EC3 FF               [12] 1093 	mov	r7,a
      005EC4 BF 03 02         [24] 1094 	cjne	r7,#0x03,00238$
      005EC7 80 03            [24] 1095 	sjmp	00239$
      005EC9                       1096 00238$:
      005EC9 02 5F 63         [24] 1097 	ljmp	00119$
      005ECC                       1098 00239$:
                                   1099 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      005ECC 90 08 1D         [24] 1100 	mov	dptr,#_descriptor_select_PARM_3
      005ECF E0               [24] 1101 	movx	a,@dptr
      005ED0 FD               [12] 1102 	mov	r5,a
      005ED1 A3               [24] 1103 	inc	dptr
      005ED2 E0               [24] 1104 	movx	a,@dptr
      005ED3 FE               [12] 1105 	mov	r6,a
      005ED4 90 08 1D         [24] 1106 	mov	dptr,#_descriptor_select_PARM_3
      005ED7 E0               [24] 1107 	movx	a,@dptr
      005ED8 F5 F0            [12] 1108 	mov	b,a
      005EDA A3               [24] 1109 	inc	dptr
      005EDB E0               [24] 1110 	movx	a,@dptr
      005EDC 45 F0            [12] 1111 	orl	a,b
      005EDE 60 0C            [24] 1112 	jz	00110$
      005EE0 BD 09 05         [24] 1113 	cjne	r5,#0x09,00241$
      005EE3 BE 04 02         [24] 1114 	cjne	r6,#0x04,00241$
      005EE6 80 04            [24] 1115 	sjmp	00110$
      005EE8                       1116 00241$:
      005EE8 90 00 00         [24] 1117 	mov	dptr,#0x0000
      005EEB 22               [24] 1118 	ret
      005EEC                       1119 00110$:
                                   1120 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      005EEC 90 08 1C         [24] 1121 	mov	dptr,#_descriptor_select_PARM_2
      005EEF E0               [24] 1122 	movx	a,@dptr
      005EF0 FE               [12] 1123 	mov  r6,a
      005EF1 24 FC            [12] 1124 	add	a,#0xff - 0x03
      005EF3 40 6A            [24] 1125 	jc	00116$
                                   1126 ;	free result
      005EF5 EE               [12] 1127 	mov	a,r6
      005EF6 2E               [12] 1128 	add	a,r6
                                   1129 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005EF7 90 5E FB         [24] 1130 	mov	dptr,#00243$
      005EFA 73               [24] 1131 	jmp	@a+dptr
      005EFB                       1132 00243$:
      005EFB 80 06            [24] 1133 	sjmp	00112$
      005EFD 80 1B            [24] 1134 	sjmp	00113$
      005EFF 80 30            [24] 1135 	sjmp	00114$
      005F01 80 45            [24] 1136 	sjmp	00115$
      005F03                       1137 00112$:
      005F03 90 08 1A         [24] 1138 	mov	dptr,#_control_pointer
      005F06 74 43            [12] 1139 	mov	a,#_LanguageString
      005F08 F0               [24] 1140 	movx	@dptr,a
      005F09 74 C2            [12] 1141 	mov	a,#(_LanguageString >> 8)
      005F0B A3               [24] 1142 	inc	dptr
      005F0C F0               [24] 1143 	movx	@dptr,a
      005F0D 90 C2 43         [24] 1144 	mov	dptr,#_LanguageString
      005F10 E4               [12] 1145 	clr	a
      005F11 93               [24] 1146 	movc	a,@a+dptr
      005F12 FE               [12] 1147 	mov	r6,a
      005F13 7D 00            [12] 1148 	mov	r5,#0x00
      005F15 8E 82            [24] 1149 	mov	dpl, r6
      005F17 8D 83            [24] 1150 	mov	dph, r5
      005F19 22               [24] 1151 	ret
                                   1152 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005F1A                       1153 00113$:
      005F1A 90 08 1A         [24] 1154 	mov	dptr,#_control_pointer
      005F1D 74 47            [12] 1155 	mov	a,#_ManufacturerString
      005F1F F0               [24] 1156 	movx	@dptr,a
      005F20 74 C2            [12] 1157 	mov	a,#(_ManufacturerString >> 8)
      005F22 A3               [24] 1158 	inc	dptr
      005F23 F0               [24] 1159 	movx	@dptr,a
      005F24 90 C2 47         [24] 1160 	mov	dptr,#_ManufacturerString
      005F27 E4               [12] 1161 	clr	a
      005F28 93               [24] 1162 	movc	a,@a+dptr
      005F29 FE               [12] 1163 	mov	r6,a
      005F2A 7D 00            [12] 1164 	mov	r5,#0x00
      005F2C 8E 82            [24] 1165 	mov	dpl, r6
      005F2E 8D 83            [24] 1166 	mov	dph, r5
      005F30 22               [24] 1167 	ret
                                   1168 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005F31                       1169 00114$:
      005F31 90 08 1A         [24] 1170 	mov	dptr,#_control_pointer
      005F34 74 55            [12] 1171 	mov	a,#_ProductString
      005F36 F0               [24] 1172 	movx	@dptr,a
      005F37 74 C2            [12] 1173 	mov	a,#(_ProductString >> 8)
      005F39 A3               [24] 1174 	inc	dptr
      005F3A F0               [24] 1175 	movx	@dptr,a
      005F3B 90 C2 55         [24] 1176 	mov	dptr,#_ProductString
      005F3E E4               [12] 1177 	clr	a
      005F3F 93               [24] 1178 	movc	a,@a+dptr
      005F40 FE               [12] 1179 	mov	r6,a
      005F41 7D 00            [12] 1180 	mov	r5,#0x00
      005F43 8E 82            [24] 1181 	mov	dpl, r6
      005F45 8D 83            [24] 1182 	mov	dph, r5
      005F47 22               [24] 1183 	ret
                                   1184 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005F48                       1185 00115$:
      005F48 90 08 1A         [24] 1186 	mov	dptr,#_control_pointer
      005F4B 74 8D            [12] 1187 	mov	a,#_SerialNumberString
      005F4D F0               [24] 1188 	movx	@dptr,a
      005F4E 74 C2            [12] 1189 	mov	a,#(_SerialNumberString >> 8)
      005F50 A3               [24] 1190 	inc	dptr
      005F51 F0               [24] 1191 	movx	@dptr,a
      005F52 90 C2 8D         [24] 1192 	mov	dptr,#_SerialNumberString
      005F55 E4               [12] 1193 	clr	a
      005F56 93               [24] 1194 	movc	a,@a+dptr
      005F57 FE               [12] 1195 	mov	r6,a
      005F58 7D 00            [12] 1196 	mov	r5,#0x00
      005F5A 8E 82            [24] 1197 	mov	dpl, r6
      005F5C 8D 83            [24] 1198 	mov	dph, r5
      005F5E 22               [24] 1199 	ret
                                   1200 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      005F5F                       1201 00116$:
      005F5F 90 00 00         [24] 1202 	mov	dptr,#0x0000
      005F62 22               [24] 1203 	ret
                                   1204 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      005F63                       1205 00119$:
                                   1206 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      005F63 90 08 1C         [24] 1207 	mov	dptr,#_descriptor_select_PARM_2
      005F66 E0               [24] 1208 	movx	a,@dptr
      005F67 70 11            [24] 1209 	jnz	00120$
      005F69 90 08 1D         [24] 1210 	mov	dptr,#_descriptor_select_PARM_3
      005F6C E0               [24] 1211 	movx	a,@dptr
      005F6D FD               [12] 1212 	mov	r5,a
      005F6E A3               [24] 1213 	inc	dptr
      005F6F E0               [24] 1214 	movx	a,@dptr
      005F70 FE               [12] 1215 	mov	r6,a
      005F71 C3               [12] 1216 	clr	c
      005F72 ED               [12] 1217 	mov	a,r5
      005F73 94 03            [12] 1218 	subb	a,#0x03
      005F75 EE               [12] 1219 	mov	a,r6
      005F76 94 00            [12] 1220 	subb	a,#0x00
      005F78 40 04            [24] 1221 	jc	00121$
      005F7A                       1222 00120$:
      005F7A 90 00 00         [24] 1223 	mov	dptr,#0x0000
      005F7D 22               [24] 1224 	ret
      005F7E                       1225 00121$:
                                   1226 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005F7E BF 22 02         [24] 1227 	cjne	r7,#0x22,00246$
      005F81 80 03            [24] 1228 	sjmp	00127$
      005F83                       1229 00246$:
      005F83 BF 21 5D         [24] 1230 	cjne	r7,#0x21,00128$
      005F86                       1231 00127$:
                                   1232 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005F86 ED               [12] 1233 	mov	a,r5
      005F87 75 F0 04         [24] 1234 	mov	b,#0x04
      005F8A A4               [48] 1235 	mul	ab
      005F8B 24 66            [12] 1236 	add	a, #_interface_descriptors
      005F8D FE               [12] 1237 	mov	r6,a
      005F8E 74 BB            [12] 1238 	mov	a,#(_interface_descriptors >> 8)
      005F90 35 F0            [12] 1239 	addc	a, b
      005F92 FF               [12] 1240 	mov	r7,a
      005F93 8E 82            [24] 1241 	mov	dpl,r6
      005F95 8F 83            [24] 1242 	mov	dph,r7
      005F97 A3               [24] 1243 	inc	dptr
      005F98 A3               [24] 1244 	inc	dptr
      005F99 E4               [12] 1245 	clr	a
      005F9A 93               [24] 1246 	movc	a,@a+dptr
      005F9B FC               [12] 1247 	mov	r4,a
      005F9C A3               [24] 1248 	inc	dptr
      005F9D E4               [12] 1249 	clr	a
      005F9E 93               [24] 1250 	movc	a,@a+dptr
                                   1251 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      005F9F FD               [12] 1252 	mov	r5,a
      005FA0 4C               [12] 1253 	orl	a,r4
      005FA1 70 04            [24] 1254 	jnz	00124$
      005FA3 90 00 00         [24] 1255 	mov	dptr,#0x0000
      005FA6 22               [24] 1256 	ret
      005FA7                       1257 00124$:
                                   1258 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      005FA7 90 08 1F         [24] 1259 	mov	dptr,#_descriptor_select_type_10000_269
      005FAA E0               [24] 1260 	movx	a,@dptr
      005FAB FB               [12] 1261 	mov	r3,a
      005FAC BB 22 28         [24] 1262 	cjne	r3,#0x22,00126$
                                   1263 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      005FAF 8E 82            [24] 1264 	mov	dpl,r6
      005FB1 8F 83            [24] 1265 	mov	dph,r7
      005FB3 E4               [12] 1266 	clr	a
      005FB4 93               [24] 1267 	movc	a,@a+dptr
      005FB5 FE               [12] 1268 	mov	r6,a
      005FB6 A3               [24] 1269 	inc	dptr
      005FB7 E4               [12] 1270 	clr	a
      005FB8 93               [24] 1271 	movc	a,@a+dptr
      005FB9 FF               [12] 1272 	mov	r7,a
      005FBA 90 08 1A         [24] 1273 	mov	dptr,#_control_pointer
      005FBD EE               [12] 1274 	mov	a,r6
      005FBE F0               [24] 1275 	movx	@dptr,a
      005FBF EF               [12] 1276 	mov	a,r7
      005FC0 A3               [24] 1277 	inc	dptr
      005FC1 F0               [24] 1278 	movx	@dptr,a
                                   1279 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      005FC2 74 07            [12] 1280 	mov	a,#0x07
      005FC4 2C               [12] 1281 	add	a, r4
      005FC5 F5 82            [12] 1282 	mov	dpl,a
      005FC7 E4               [12] 1283 	clr	a
      005FC8 3D               [12] 1284 	addc	a, r5
      005FC9 F5 83            [12] 1285 	mov	dph,a
      005FCB E4               [12] 1286 	clr	a
      005FCC 93               [24] 1287 	movc	a,@a+dptr
      005FCD FE               [12] 1288 	mov	r6,a
      005FCE A3               [24] 1289 	inc	dptr
      005FCF E4               [12] 1290 	clr	a
      005FD0 93               [24] 1291 	movc	a,@a+dptr
      005FD1 FF               [12] 1292 	mov	r7,a
      005FD2 8E 82            [24] 1293 	mov	dpl, r6
      005FD4 8F 83            [24] 1294 	mov	dph, r7
      005FD6 22               [24] 1295 	ret
      005FD7                       1296 00126$:
                                   1297 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      005FD7 90 08 1A         [24] 1298 	mov	dptr,#_control_pointer
      005FDA EC               [12] 1299 	mov	a,r4
      005FDB F0               [24] 1300 	movx	@dptr,a
      005FDC ED               [12] 1301 	mov	a,r5
      005FDD A3               [24] 1302 	inc	dptr
      005FDE F0               [24] 1303 	movx	@dptr,a
                                   1304 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      005FDF 90 00 09         [24] 1305 	mov	dptr,#0x0009
      005FE2 22               [24] 1306 	ret
      005FE3                       1307 00128$:
                                   1308 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      005FE3 90 00 00         [24] 1309 	mov	dptr,#0x0000
                                   1310 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      005FE6 22               [24] 1311 	ret
                                   1312 ;------------------------------------------------------------
                                   1313 ;Allocation info for local variables in function 'control_setup'
                                   1314 ;------------------------------------------------------------
                                   1315 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1316 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1317 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1318 ;type          Allocated with name '_control_setup_type_10000_287'
                                   1319 ;value         Allocated with name '_control_setup_value_10000_287'
                                   1320 ;index         Allocated with name '_control_setup_index_10000_287'
                                   1321 ;length        Allocated with name '_control_setup_length_10000_287'
                                   1322 ;endpoint      Allocated with name '_control_setup_endpoint_10000_287'
                                   1323 ;i             Allocated with name '_control_setup_i_10000_287'
                                   1324 ;offset        Allocated with name '_control_setup_offset_10000_287'
                                   1325 ;report_id     Allocated with name '_control_setup_report_id_10000_287'
                                   1326 ;------------------------------------------------------------
                                   1327 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1328 ;	-----------------------------------------
                                   1329 ;	 function control_setup
                                   1330 ;	-----------------------------------------
      005FE7                       1331 _control_setup:
                                   1332 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      005FE7 90 10 00         [24] 1333 	mov	dptr,#0x1000
      005FEA E0               [24] 1334 	movx	a,@dptr
      005FEB FF               [12] 1335 	mov	r7,a
                                   1336 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      005FEC A3               [24] 1337 	inc	dptr
      005FED A3               [24] 1338 	inc	dptr
      005FEE E0               [24] 1339 	movx	a,@dptr
      005FEF FE               [12] 1340 	mov	r6,a
      005FF0 A3               [24] 1341 	inc	dptr
      005FF1 E0               [24] 1342 	movx	a,@dptr
      005FF2 FC               [12] 1343 	mov	r4,a
      005FF3 7D 00            [12] 1344 	mov	r5,#0x00
      005FF5 8E 03            [24] 1345 	mov	ar3,r6
      005FF7 7E 00            [12] 1346 	mov	r6,#0x00
      005FF9 ED               [12] 1347 	mov	a,r5
      005FFA 4B               [12] 1348 	orl	a,r3
      005FFB FD               [12] 1349 	mov	r5,a
      005FFC EC               [12] 1350 	mov	a,r4
      005FFD 4E               [12] 1351 	orl	a,r6
      005FFE FE               [12] 1352 	mov	r6,a
                                   1353 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      005FFF A3               [24] 1354 	inc	dptr
      006000 E0               [24] 1355 	movx	a,@dptr
      006001 FC               [12] 1356 	mov	r4,a
      006002 A3               [24] 1357 	inc	dptr
      006003 E0               [24] 1358 	movx	a,@dptr
      006004 FA               [12] 1359 	mov	r2,a
      006005 7B 00            [12] 1360 	mov	r3,#0x00
      006007 8C 01            [24] 1361 	mov	ar1,r4
      006009 7C 00            [12] 1362 	mov	r4,#0x00
      00600B EB               [12] 1363 	mov	a,r3
      00600C 49               [12] 1364 	orl	a,r1
      00600D FB               [12] 1365 	mov	r3,a
      00600E EA               [12] 1366 	mov	a,r2
      00600F 4C               [12] 1367 	orl	a,r4
      006010 FC               [12] 1368 	mov	r4,a
                                   1369 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      006011 C3               [12] 1370 	clr	c
      006012 EB               [12] 1371 	mov	a,r3
      006013 94 03            [12] 1372 	subb	a,#0x03
      006015 EC               [12] 1373 	mov	a,r4
      006016 94 00            [12] 1374 	subb	a,#0x00
      006018 92 15            [24] 1375 	mov	_control_setup_valid_interface_10000_287,c
                                   1376 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      00601A EB               [12] 1377 	mov	a,r3
      00601B 4C               [12] 1378 	orl	a,r4
      00601C B4 01 00         [24] 1379 	cjne	a,#0x01,01201$
      00601F                       1380 01201$:
      00601F 92 16            [24] 1381 	mov	_control_setup_zero_index_10000_287,c
                                   1382 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      006021 ED               [12] 1383 	mov	a,r5
      006022 4E               [12] 1384 	orl	a,r6
      006023 B4 01 00         [24] 1385 	cjne	a,#0x01,01202$
      006026                       1386 01202$:
                                   1387 ;	assignBit
      006026 92 19            [24] 1388 	mov  _control_setup_sloc0_1_0,c
      006028 92 17            [24] 1389 	mov	_control_setup_zero_value_10000_287,c
                                   1390 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      00602A 90 08 22         [24] 1391 	mov	dptr,#_control_setup_offset_10000_287
      00602D E4               [12] 1392 	clr	a
      00602E F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      00602F 90 07 C5         [24] 1395 	mov	dptr,#_raw_state
      006032 E0               [24] 1396 	movx	a,@dptr
      006033 FA               [12] 1397 	mov	r2,a
      006034 BA 01 05         [24] 1398 	cjne	r2,#0x01,00102$
      006037 90 07 C5         [24] 1399 	mov	dptr,#_raw_state
      00603A E4               [12] 1400 	clr	a
      00603B F0               [24] 1401 	movx	@dptr,a
      00603C                       1402 00102$:
                                   1403 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      00603C C0 07            [24] 1404 	push	ar7
      00603E 90 08 17         [24] 1405 	mov	dptr,#_output_kind
      006041 E4               [12] 1406 	clr	a
      006042 F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      006043 90 08 16         [24] 1409 	mov	dptr,#_control_phase
      006046 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      006047 90 08 19         [24] 1412 	mov	dptr,#_control_zlp
      00604A F0               [24] 1413 	movx	@dptr,a
                                   1414 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      00604B 90 10 01         [24] 1415 	mov	dptr,#0x1001
      00604E E0               [24] 1416 	movx	a,@dptr
      00604F 90 07 B7         [24] 1417 	mov	dptr,#_D0SetupReqCode
      006052 F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      006053 90 10 06         [24] 1420 	mov	dptr,#0x1006
      006056 E0               [24] 1421 	movx	a,@dptr
      006057 FA               [12] 1422 	mov	r2,a
      006058 A3               [24] 1423 	inc	dptr
      006059 E0               [24] 1424 	movx	a,@dptr
      00605A F9               [12] 1425 	mov	r1,a
      00605B 78 00            [12] 1426 	mov	r0,#0x00
      00605D 7F 00            [12] 1427 	mov	r7,#0x00
      00605F 90 07 B8         [24] 1428 	mov	dptr,#_D0SetupLen
      006062 E8               [12] 1429 	mov	a,r0
      006063 4A               [12] 1430 	orl	a,r2
      006064 F0               [24] 1431 	movx	@dptr,a
      006065 E9               [12] 1432 	mov	a,r1
      006066 4F               [12] 1433 	orl	a,r7
      006067 A3               [24] 1434 	inc	dptr
      006068 F0               [24] 1435 	movx	@dptr,a
                                   1436 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      006069 90 07 B8         [24] 1437 	mov	dptr,#_D0SetupLen
      00606C E0               [24] 1438 	movx	a,@dptr
      00606D FA               [12] 1439 	mov	r2,a
      00606E A3               [24] 1440 	inc	dptr
      00606F E0               [24] 1441 	movx	a,@dptr
      006070 4A               [12] 1442 	orl	a,r2
      006071 B4 01 00         [24] 1443 	cjne	a,#0x01,01205$
      006074                       1444 01205$:
      006074 92 18            [24] 1445 	mov	_control_setup_zero_length_10000_287,c
                                   1446 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006076 90 22 00         [24] 1447 	mov	dptr,#0x2200
      006079 74 C2            [12] 1448 	mov	a,#0xc2
      00607B F0               [24] 1449 	movx	@dptr,a
                                   1450 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      00607C 90 22 08         [24] 1451 	mov	dptr,#0x2208
      00607F E4               [12] 1452 	clr	a
      006080 F0               [24] 1453 	movx	@dptr,a
                                   1454 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      006081 90 07 B7         [24] 1455 	mov	dptr,#_D0SetupReqCode
      006084 E0               [24] 1456 	movx	a,@dptr
      006085 F5 16            [12] 1457 	mov	_control_setup_sloc1_1_0,a
      006087 C3               [12] 1458 	clr	c
      006088 74 0B            [12] 1459 	mov	a,#0x0b
      00608A 95 16            [12] 1460 	subb	a,_control_setup_sloc1_1_0
      00608C D0 07            [24] 1461 	pop	ar7
      00608E 50 03            [24] 1462 	jnc	01206$
      006090 02 5D CE         [24] 1463 	ljmp	_control_stall
      006093                       1464 01206$:
                                   1465 ;	free result
      006093 E5 16            [12] 1466 	mov	a,_control_setup_sloc1_1_0
      006095 F5 F0            [12] 1467 	mov	b,a
      006097 24 0B            [12] 1468 	add	a,#(01207$-3-.)
      006099 83               [24] 1469 	movc	a,@a+pc
      00609A F5 82            [12] 1470 	mov	dpl,a
      00609C E5 F0            [12] 1471 	mov	a,b
      00609E 24 10            [12] 1472 	add	a,#(01208$-3-.)
      0060A0 83               [24] 1473 	movc	a,@a+pc
      0060A1 F5 83            [12] 1474 	mov	dph,a
      0060A3 E4               [12] 1475 	clr	a
      0060A4 73               [24] 1476 	jmp	@a+dptr
      0060A5                       1477 01207$:
      0060A5 4D                    1478 	.db	00188$
      0060A6 F3                    1479 	.db	00205$
      0060A7 36                    1480 	.db	00282$
      0060A8 F3                    1481 	.db	00205$
      0060A9 7A                    1482 	.db	00290$
      0060AA 77                    1483 	.db	00116$
      0060AB BD                    1484 	.db	00103$
      0060AC 7A                    1485 	.db	00290$
      0060AD 7C                    1486 	.db	00150$
      0060AE A0                    1487 	.db	00123$
      0060AF AC                    1488 	.db	00157$
      0060B0 FF                    1489 	.db	00173$
      0060B1                       1490 01208$:
      0060B1 63                    1491 	.db	00188$>>8
      0060B2 63                    1492 	.db	00205$>>8
      0060B3 67                    1493 	.db	00282$>>8
      0060B4 63                    1494 	.db	00205$>>8
      0060B5 67                    1495 	.db	00290$>>8
      0060B6 61                    1496 	.db	00116$>>8
      0060B7 60                    1497 	.db	00103$>>8
      0060B8 67                    1498 	.db	00290$>>8
      0060B9 62                    1499 	.db	00150$>>8
      0060BA 61                    1500 	.db	00123$>>8
      0060BB 62                    1501 	.db	00157$>>8
      0060BC 62                    1502 	.db	00173$>>8
                                   1503 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      0060BD                       1504 00103$:
                                   1505 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      0060BD BF 80 02         [24] 1506 	cjne	r7,#0x80,01209$
      0060C0 80 08            [24] 1507 	sjmp	00112$
      0060C2                       1508 01209$:
      0060C2 BF 81 02         [24] 1509 	cjne	r7,#0x81,01210$
      0060C5 80 03            [24] 1510 	sjmp	01211$
      0060C7                       1511 01210$:
      0060C7 02 5D CE         [24] 1512 	ljmp	_control_stall
      0060CA                       1513 01211$:
      0060CA                       1514 00112$:
                                   1515 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      0060CA 8E 01            [24] 1516 	mov	ar1,r6
      0060CC B9 21 02         [24] 1517 	cjne	r1,#0x21,01212$
      0060CF 80 09            [24] 1518 	sjmp	00301$
      0060D1                       1519 01212$:
      0060D1 B9 22 02         [24] 1520 	cjne	r1,#0x22,01213$
      0060D4 80 04            [24] 1521 	sjmp	00301$
      0060D6                       1522 01213$:
                                   1523 ;	assignBit
      0060D6 C2 1A            [12] 1524 	clr	_control_setup_sloc2_1_0
      0060D8 80 02            [24] 1525 	sjmp	00302$
      0060DA                       1526 00301$:
                                   1527 ;	assignBit
      0060DA D2 1A            [12] 1528 	setb	_control_setup_sloc2_1_0
      0060DC                       1529 00302$:
      0060DC E4               [12] 1530 	clr	a
      0060DD BF 81 01         [24] 1531 	cjne	r7,#0x81,01214$
      0060E0 04               [12] 1532 	inc	a
      0060E1                       1533 01214$:
      0060E1 FA               [12] 1534 	mov	r2,a
      0060E2 A2 1A            [12] 1535 	mov	c,_control_setup_sloc2_1_0
      0060E4 E4               [12] 1536 	clr	a
      0060E5 33               [12] 1537 	rlc	a
      0060E6 B5 02 02         [24] 1538 	cjne	a,ar2,01216$
      0060E9 80 03            [24] 1539 	sjmp	00105$
      0060EB                       1540 01216$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      0060EB 02 5D CE         [24] 1542 	ljmp	_control_stall
      0060EE                       1543 00105$:
                                   1544 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      0060EE 8E 02            [24] 1545 	mov	ar2,r6
      0060F0 90 08 1C         [24] 1546 	mov	dptr,#_descriptor_select_PARM_2
      0060F3 ED               [12] 1547 	mov	a,r5
      0060F4 F0               [24] 1548 	movx	@dptr,a
      0060F5 90 08 1D         [24] 1549 	mov	dptr,#_descriptor_select_PARM_3
      0060F8 EB               [12] 1550 	mov	a,r3
      0060F9 F0               [24] 1551 	movx	@dptr,a
      0060FA EC               [12] 1552 	mov	a,r4
      0060FB A3               [24] 1553 	inc	dptr
      0060FC F0               [24] 1554 	movx	@dptr,a
      0060FD 8A 82            [24] 1555 	mov	dpl, r2
      0060FF 12 5E 6C         [24] 1556 	lcall	_descriptor_select
      006102 85 82 17         [24] 1557 	mov	_control_setup_sloc3_1_0,dpl
      006105 85 83 18         [24] 1558 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1559 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      006108 E5 17            [12] 1560 	mov	a,_control_setup_sloc3_1_0
      00610A 45 18            [12] 1561 	orl	a,(_control_setup_sloc3_1_0 + 1)
      00610C 70 03            [24] 1562 	jnz	00107$
      00610E 02 5D CE         [24] 1563 	ljmp	_control_stall
      006111                       1564 00107$:
                                   1565 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      006111 90 07 B8         [24] 1566 	mov	dptr,#_D0SetupLen
      006114 E0               [24] 1567 	movx	a,@dptr
      006115 F8               [12] 1568 	mov	r0,a
      006116 A3               [24] 1569 	inc	dptr
      006117 E0               [24] 1570 	movx	a,@dptr
      006118 FA               [12] 1571 	mov	r2,a
      006119 C3               [12] 1572 	clr	c
      00611A E5 17            [12] 1573 	mov	a,_control_setup_sloc3_1_0
      00611C 98               [12] 1574 	subb	a,r0
      00611D E5 18            [12] 1575 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00611F 9A               [12] 1576 	subb	a,r2
      006120 50 06            [24] 1577 	jnc	00303$
      006122 E5 17            [12] 1578 	mov	a,_control_setup_sloc3_1_0
      006124 54 3F            [12] 1579 	anl	a,#0x3f
      006126 60 04            [24] 1580 	jz	00304$
      006128                       1581 00303$:
                                   1582 ;	assignBit
      006128 C2 1A            [12] 1583 	clr	_control_setup_sloc2_1_0
      00612A 80 02            [24] 1584 	sjmp	00305$
      00612C                       1585 00304$:
                                   1586 ;	assignBit
      00612C D2 1A            [12] 1587 	setb	_control_setup_sloc2_1_0
      00612E                       1588 00305$:
      00612E 90 08 19         [24] 1589 	mov	dptr,#_control_zlp
      006131 A2 1A            [12] 1590 	mov	c,_control_setup_sloc2_1_0
      006133 E4               [12] 1591 	clr	a
      006134 33               [12] 1592 	rlc	a
      006135 F0               [24] 1593 	movx	@dptr,a
                                   1594 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      006136 90 07 B8         [24] 1595 	mov	dptr,#_D0SetupLen
      006139 E0               [24] 1596 	movx	a,@dptr
      00613A F9               [12] 1597 	mov	r1,a
      00613B A3               [24] 1598 	inc	dptr
      00613C E0               [24] 1599 	movx	a,@dptr
      00613D FA               [12] 1600 	mov	r2,a
      00613E C3               [12] 1601 	clr	c
      00613F E5 17            [12] 1602 	mov	a,_control_setup_sloc3_1_0
      006141 99               [12] 1603 	subb	a,r1
      006142 E5 18            [12] 1604 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006144 9A               [12] 1605 	subb	a,r2
      006145 50 0A            [24] 1606 	jnc	00109$
                                   1607 ;	free result
      006147 90 07 B8         [24] 1608 	mov	dptr,#_D0SetupLen
      00614A E5 17            [12] 1609 	mov	a,_control_setup_sloc3_1_0
      00614C F0               [24] 1610 	movx	@dptr,a
      00614D E5 18            [12] 1611 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00614F A3               [24] 1612 	inc	dptr
      006150 F0               [24] 1613 	movx	@dptr,a
      006151                       1614 00109$:
                                   1615 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      006151 90 07 B8         [24] 1616 	mov	dptr,#_D0SetupLen
      006154 E0               [24] 1617 	movx	a,@dptr
      006155 F9               [12] 1618 	mov	r1,a
      006156 A3               [24] 1619 	inc	dptr
      006157 E0               [24] 1620 	movx	a,@dptr
      006158 49               [12] 1621 	orl	a,r1
      006159 60 04            [24] 1622 	jz	00306$
      00615B 7A 01            [12] 1623 	mov	r2,#0x01
      00615D 80 02            [24] 1624 	sjmp	00307$
      00615F                       1625 00306$:
      00615F 7A 02            [12] 1626 	mov	r2,#0x02
      006161                       1627 00307$:
      006161 90 08 16         [24] 1628 	mov	dptr,#_control_phase
      006164 EA               [12] 1629 	mov	a,r2
      006165 F0               [24] 1630 	movx	@dptr,a
                                   1631 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      006166 90 07 B8         [24] 1632 	mov	dptr,#_D0SetupLen
      006169 E0               [24] 1633 	movx	a,@dptr
      00616A F9               [12] 1634 	mov	r1,a
      00616B A3               [24] 1635 	inc	dptr
      00616C E0               [24] 1636 	movx	a,@dptr
      00616D 49               [12] 1637 	orl	a,r1
      00616E 60 03            [24] 1638 	jz	00111$
                                   1639 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      006170 02 5D F0         [24] 1640 	ljmp	_control_next
      006173                       1641 00111$:
      006173 22               [24] 1642 	ret
                                   1643 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      006174 02 5D CE         [24] 1644 	ljmp	_control_stall
                                   1645 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      006177                       1646 00116$:
                                   1647 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      006177 EF               [12] 1648 	mov	a,r7
      006178 70 23            [24] 1649 	jnz	00118$
      00617A 30 16 20         [24] 1650 	jnb	_control_setup_zero_index_10000_287,00118$
      00617D 30 18 1D         [24] 1651 	jnb	_control_setup_zero_length_10000_287,00118$
      006180 8D 01            [24] 1652 	mov	ar1,r5
      006182 8E 02            [24] 1653 	mov	ar2,r6
      006184 C3               [12] 1654 	clr	c
      006185 74 7F            [12] 1655 	mov	a,#0x7f
      006187 99               [12] 1656 	subb	a,r1
      006188 E4               [12] 1657 	clr	a
      006189 9A               [12] 1658 	subb	a,r2
      00618A 40 11            [24] 1659 	jc	00118$
                                   1660 ;	free result
                                   1661 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      00618C 90 07 B8         [24] 1662 	mov	dptr,#_D0SetupLen
      00618F ED               [12] 1663 	mov	a,r5
      006190 F0               [24] 1664 	movx	@dptr,a
      006191 EE               [12] 1665 	mov	a,r6
      006192 A3               [24] 1666 	inc	dptr
      006193 F0               [24] 1667 	movx	@dptr,a
                                   1668 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      006194 90 08 16         [24] 1669 	mov	dptr,#_control_phase
      006197 74 03            [12] 1670 	mov	a,#0x03
      006199 F0               [24] 1671 	movx	@dptr,a
      00619A 02 67 7D         [24] 1672 	ljmp	00291$
      00619D                       1673 00118$:
                                   1674 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      00619D 02 5D CE         [24] 1675 	ljmp	_control_stall
                                   1676 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      0061A0                       1677 00123$:
                                   1678 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      0061A0 EF               [12] 1679 	mov	a,r7
      0061A1 70 3C            [24] 1680 	jnz	00145$
      0061A3 30 16 39         [24] 1681 	jnb	_control_setup_zero_index_10000_287,00145$
      0061A6 30 18 36         [24] 1682 	jnb	_control_setup_zero_length_10000_287,00145$
      0061A9 8D 01            [24] 1683 	mov	ar1,r5
      0061AB 8E 02            [24] 1684 	mov	ar2,r6
      0061AD C3               [12] 1685 	clr	c
      0061AE 74 01            [12] 1686 	mov	a,#0x01
      0061B0 99               [12] 1687 	subb	a,r1
      0061B1 E4               [12] 1688 	clr	a
      0061B2 9A               [12] 1689 	subb	a,r2
      0061B3 40 2A            [24] 1690 	jc	00145$
                                   1691 ;	free result
                                   1692 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      0061B5 C0 06            [24] 1693 	push	ar6
      0061B7 C0 05            [24] 1694 	push	ar5
      0061B9 12 5D 77         [24] 1695 	lcall	_endpoints_reset
      0061BC D0 05            [24] 1696 	pop	ar5
      0061BE D0 06            [24] 1697 	pop	ar6
                                   1698 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      0061C0 90 07 BD         [24] 1699 	mov	dptr,#_D0UsbConfig
      0061C3 ED               [12] 1700 	mov	a,r5
      0061C4 F0               [24] 1701 	movx	@dptr,a
                                   1702 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      0061C5 A2 19            [12] 1703 	mov	c,_control_setup_sloc0_1_0
      0061C7 B3               [12] 1704 	cpl	c
      0061C8 92 1A            [24] 1705 	mov	_control_setup_sloc2_1_0,c
      0061CA 90 07 BE         [24] 1706 	mov	dptr,#_USB_EnumStatus
      0061CD E4               [12] 1707 	clr	a
      0061CE 33               [12] 1708 	rlc	a
      0061CF F0               [24] 1709 	movx	@dptr,a
                                   1710 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      0061D0 90 07 E7         [24] 1711 	mov	dptr,#_keyboard_reset
      0061D3 74 01            [12] 1712 	mov	a,#0x01
      0061D5 F0               [24] 1713 	movx	@dptr,a
                                   1714 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      0061D6 90 08 16         [24] 1715 	mov	dptr,#_control_phase
      0061D9 74 03            [12] 1716 	mov	a,#0x03
      0061DB F0               [24] 1717 	movx	@dptr,a
      0061DC 02 67 7D         [24] 1718 	ljmp	00291$
      0061DF                       1719 00145$:
                                   1720 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      0061DF BF 21 02         [24] 1721 	cjne	r7,#0x21,01231$
      0061E2 80 03            [24] 1722 	sjmp	01232$
      0061E4                       1723 01231$:
      0061E4 02 5D CE         [24] 1724 	ljmp	_control_stall
      0061E7                       1725 01232$:
      0061E7 90 07 BD         [24] 1726 	mov	dptr,#_D0UsbConfig
      0061EA E0               [24] 1727 	movx	a,@dptr
      0061EB 70 03            [24] 1728 	jnz	01233$
      0061ED 02 5D CE         [24] 1729 	ljmp	_control_stall
      0061F0                       1730 01233$:
                                   1731 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      0061F0 BB 01 2D         [24] 1732 	cjne	r3,#0x01,00135$
      0061F3 BC 00 2A         [24] 1733 	cjne	r4,#0x00,00135$
      0061F6 8D 01            [24] 1734 	mov	ar1,r5
      0061F8 8E 02            [24] 1735 	mov	ar2,r6
      0061FA B9 00 23         [24] 1736 	cjne	r1,#0x00,00135$
      0061FD BA 02 20         [24] 1737 	cjne	r2,#0x02,00135$
      006200 90 07 B8         [24] 1738 	mov	dptr,#_D0SetupLen
      006203 E0               [24] 1739 	movx	a,@dptr
      006204 F9               [12] 1740 	mov	r1,a
      006205 A3               [24] 1741 	inc	dptr
      006206 E0               [24] 1742 	movx	a,@dptr
      006207 FA               [12] 1743 	mov	r2,a
      006208 B9 20 15         [24] 1744 	cjne	r1,#0x20,00135$
      00620B BA 00 12         [24] 1745 	cjne	r2,#0x00,00135$
      00620E 90 07 C5         [24] 1746 	mov	dptr,#_raw_state
      006211 E0               [24] 1747 	movx	a,@dptr
      006212 70 0C            [24] 1748 	jnz	00135$
                                   1749 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      006214 90 07 C5         [24] 1750 	mov	dptr,#_raw_state
      006217 74 01            [12] 1751 	mov	a,#0x01
      006219 F0               [24] 1752 	movx	@dptr,a
                                   1753 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      00621A 90 08 17         [24] 1754 	mov	dptr,#_output_kind
      00621D F0               [24] 1755 	movx	@dptr,a
      00621E 80 52            [24] 1756 	sjmp	00136$
      006220                       1757 00135$:
                                   1758 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      006220 EB               [12] 1759 	mov	a,r3
      006221 4C               [12] 1760 	orl	a,r4
      006222 70 20            [24] 1761 	jnz	00130$
      006224 8D 01            [24] 1762 	mov	ar1,r5
      006226 8E 02            [24] 1763 	mov	ar2,r6
      006228 B9 00 19         [24] 1764 	cjne	r1,#0x00,00130$
      00622B BA 02 16         [24] 1765 	cjne	r2,#0x02,00130$
      00622E 90 07 B8         [24] 1766 	mov	dptr,#_D0SetupLen
      006231 E0               [24] 1767 	movx	a,@dptr
      006232 F9               [12] 1768 	mov	r1,a
      006233 A3               [24] 1769 	inc	dptr
      006234 E0               [24] 1770 	movx	a,@dptr
      006235 FA               [12] 1771 	mov	r2,a
      006236 B9 01 0B         [24] 1772 	cjne	r1,#0x01,00130$
      006239 BA 00 08         [24] 1773 	cjne	r2,#0x00,00130$
                                   1774 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      00623C 90 08 17         [24] 1775 	mov	dptr,#_output_kind
      00623F 74 02            [12] 1776 	mov	a,#0x02
      006241 F0               [24] 1777 	movx	@dptr,a
      006242 80 2E            [24] 1778 	sjmp	00136$
      006244                       1779 00130$:
                                   1780 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      006244 BB 02 28         [24] 1781 	cjne	r3,#0x02,00125$
      006247 BC 00 25         [24] 1782 	cjne	r4,#0x00,00125$
      00624A 8D 01            [24] 1783 	mov	ar1,r5
      00624C 8E 02            [24] 1784 	mov	ar2,r6
      00624E B9 06 1E         [24] 1785 	cjne	r1,#0x06,00125$
      006251 BA 02 1B         [24] 1786 	cjne	r2,#0x02,00125$
      006254 90 07 B8         [24] 1787 	mov	dptr,#_D0SetupLen
      006257 E0               [24] 1788 	movx	a,@dptr
      006258 F9               [12] 1789 	mov	r1,a
      006259 A3               [24] 1790 	inc	dptr
      00625A E0               [24] 1791 	movx	a,@dptr
      00625B FA               [12] 1792 	mov	r2,a
      00625C B9 02 10         [24] 1793 	cjne	r1,#0x02,00125$
      00625F BA 00 0D         [24] 1794 	cjne	r2,#0x00,00125$
                                   1795 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      006262 90 08 17         [24] 1796 	mov	dptr,#_output_kind
      006265 74 03            [12] 1797 	mov	a,#0x03
      006267 F0               [24] 1798 	movx	@dptr,a
                                   1799 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      006268 90 08 18         [24] 1800 	mov	dptr,#_output_report_id
      00626B 23               [12] 1801 	rl	a
      00626C F0               [24] 1802 	movx	@dptr,a
      00626D 80 03            [24] 1803 	sjmp	00136$
      00626F                       1804 00125$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      00626F 02 5D CE         [24] 1806 	ljmp	_control_stall
      006272                       1807 00136$:
                                   1808 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      006272 90 08 16         [24] 1809 	mov	dptr,#_control_phase
      006275 74 04            [12] 1810 	mov	a,#0x04
      006277 F0               [24] 1811 	movx	@dptr,a
                                   1812 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      006278 22               [24] 1813 	ret
                                   1814 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      006279 02 5D CE         [24] 1815 	ljmp	_control_stall
                                   1816 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      00627C                       1817 00150$:
                                   1818 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      00627C BF 80 2A         [24] 1819 	cjne	r7,#0x80,00152$
      00627F 30 16 27         [24] 1820 	jnb	_control_setup_zero_index_10000_287,00152$
      006282 30 17 24         [24] 1821 	jnb	_control_setup_zero_value_10000_287,00152$
      006285 90 07 B8         [24] 1822 	mov	dptr,#_D0SetupLen
      006288 E0               [24] 1823 	movx	a,@dptr
      006289 F9               [12] 1824 	mov	r1,a
      00628A A3               [24] 1825 	inc	dptr
      00628B E0               [24] 1826 	movx	a,@dptr
      00628C FA               [12] 1827 	mov	r2,a
      00628D B9 01 19         [24] 1828 	cjne	r1,#0x01,00152$
      006290 BA 00 16         [24] 1829 	cjne	r2,#0x00,00152$
                                   1830 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      006293 90 07 BD         [24] 1831 	mov	dptr,#_D0UsbConfig
      006296 E0               [24] 1832 	movx	a,@dptr
      006297 90 10 00         [24] 1833 	mov	dptr,#0x1000
      00629A F0               [24] 1834 	movx	@dptr,a
                                   1835 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      00629B 90 22 08         [24] 1836 	mov	dptr,#0x2208
      00629E 74 01            [12] 1837 	mov	a,#0x01
      0062A0 F0               [24] 1838 	movx	@dptr,a
                                   1839 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      0062A1 90 08 16         [24] 1840 	mov	dptr,#_control_phase
      0062A4 04               [12] 1841 	inc	a
      0062A5 F0               [24] 1842 	movx	@dptr,a
      0062A6 02 67 7D         [24] 1843 	ljmp	00291$
      0062A9                       1844 00152$:
                                   1845 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      0062A9 02 5D CE         [24] 1846 	ljmp	_control_stall
                                   1847 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      0062AC                       1848 00157$:
                                   1849 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      0062AC BF 81 2C         [24] 1850 	cjne	r7,#0x81,00167$
      0062AF 30 15 29         [24] 1851 	jnb	_control_setup_valid_interface_10000_287,00167$
      0062B2 30 17 26         [24] 1852 	jnb	_control_setup_zero_value_10000_287,00167$
      0062B5 90 07 B8         [24] 1853 	mov	dptr,#_D0SetupLen
      0062B8 E0               [24] 1854 	movx	a,@dptr
      0062B9 F9               [12] 1855 	mov	r1,a
      0062BA A3               [24] 1856 	inc	dptr
      0062BB E0               [24] 1857 	movx	a,@dptr
      0062BC FA               [12] 1858 	mov	r2,a
      0062BD B9 01 1B         [24] 1859 	cjne	r1,#0x01,00167$
      0062C0 BA 00 18         [24] 1860 	cjne	r2,#0x00,00167$
      0062C3 90 07 BD         [24] 1861 	mov	dptr,#_D0UsbConfig
      0062C6 E0               [24] 1862 	movx	a,@dptr
      0062C7 60 12            [24] 1863 	jz	00167$
                                   1864 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      0062C9 90 10 00         [24] 1865 	mov	dptr,#0x1000
      0062CC E4               [12] 1866 	clr	a
      0062CD F0               [24] 1867 	movx	@dptr,a
                                   1868 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      0062CE 90 22 08         [24] 1869 	mov	dptr,#0x2208
      0062D1 04               [12] 1870 	inc	a
      0062D2 F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      0062D3 90 08 16         [24] 1873 	mov	dptr,#_control_phase
      0062D6 04               [12] 1874 	inc	a
      0062D7 F0               [24] 1875 	movx	@dptr,a
      0062D8 02 67 7D         [24] 1876 	ljmp	00291$
      0062DB                       1877 00167$:
                                   1878 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      0062DB 30 15 1E         [24] 1879 	jnb	_control_setup_valid_interface_10000_287,00161$
      0062DE 90 07 BD         [24] 1880 	mov	dptr,#_D0UsbConfig
      0062E1 E0               [24] 1881 	movx	a,@dptr
      0062E2 60 18            [24] 1882 	jz	00161$
      0062E4 BF 21 15         [24] 1883 	cjne	r7,#0x21,00161$
      0062E7 30 18 12         [24] 1884 	jnb	_control_setup_zero_length_10000_287,00161$
                                   1885 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      0062EA EB               [12] 1886 	mov	a,r3
      0062EB 4C               [12] 1887 	orl	a,r4
      0062EC 70 05            [24] 1888 	jnz	00159$
      0062EE 90 06 95         [24] 1889 	mov	dptr,#_keyboard_idle
      0062F1 EE               [12] 1890 	mov	a,r6
      0062F2 F0               [24] 1891 	movx	@dptr,a
      0062F3                       1892 00159$:
                                   1893 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      0062F3 90 08 16         [24] 1894 	mov	dptr,#_control_phase
      0062F6 74 03            [12] 1895 	mov	a,#0x03
      0062F8 F0               [24] 1896 	movx	@dptr,a
      0062F9 02 67 7D         [24] 1897 	ljmp	00291$
      0062FC                       1898 00161$:
                                   1899 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      0062FC 02 5D CE         [24] 1900 	ljmp	_control_stall
                                   1901 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      0062FF                       1902 00173$:
                                   1903 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      0062FF BF 01 18         [24] 1904 	cjne	r7,#0x01,00182$
      006302 30 15 15         [24] 1905 	jnb	_control_setup_valid_interface_10000_287,00182$
      006305 30 17 12         [24] 1906 	jnb	_control_setup_zero_value_10000_287,00182$
      006308 30 18 0F         [24] 1907 	jnb	_control_setup_zero_length_10000_287,00182$
      00630B 90 07 BD         [24] 1908 	mov	dptr,#_D0UsbConfig
      00630E E0               [24] 1909 	movx	a,@dptr
      00630F 60 09            [24] 1910 	jz	00182$
                                   1911 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      006311 90 08 16         [24] 1912 	mov	dptr,#_control_phase
      006314 74 03            [12] 1913 	mov	a,#0x03
      006316 F0               [24] 1914 	movx	@dptr,a
      006317 02 67 7D         [24] 1915 	ljmp	00291$
      00631A                       1916 00182$:
                                   1917 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      00631A EB               [12] 1918 	mov	a,r3
      00631B 4C               [12] 1919 	orl	a,r4
      00631C 70 2C            [24] 1920 	jnz	00175$
      00631E 90 07 BD         [24] 1921 	mov	dptr,#_D0UsbConfig
      006321 E0               [24] 1922 	movx	a,@dptr
      006322 60 26            [24] 1923 	jz	00175$
      006324 BF 21 23         [24] 1924 	cjne	r7,#0x21,00175$
      006327 30 18 20         [24] 1925 	jnb	_control_setup_zero_length_10000_287,00175$
      00632A 8D 01            [24] 1926 	mov	ar1,r5
      00632C 8E 02            [24] 1927 	mov	ar2,r6
      00632E C3               [12] 1928 	clr	c
      00632F 74 01            [12] 1929 	mov	a,#0x01
      006331 99               [12] 1930 	subb	a,r1
      006332 E4               [12] 1931 	clr	a
      006333 9A               [12] 1932 	subb	a,r2
      006334 40 14            [24] 1933 	jc	00175$
                                   1934 ;	free result
                                   1935 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      006336 90 0D D8         [24] 1936 	mov	dptr,#_keyboard_protocol
      006339 ED               [12] 1937 	mov	a,r5
      00633A F0               [24] 1938 	movx	@dptr,a
                                   1939 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      00633B 90 07 E7         [24] 1940 	mov	dptr,#_keyboard_reset
      00633E 74 01            [12] 1941 	mov	a,#0x01
      006340 F0               [24] 1942 	movx	@dptr,a
                                   1943 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      006341 90 08 16         [24] 1944 	mov	dptr,#_control_phase
      006344 74 03            [12] 1945 	mov	a,#0x03
      006346 F0               [24] 1946 	movx	@dptr,a
      006347 02 67 7D         [24] 1947 	ljmp	00291$
      00634A                       1948 00175$:
                                   1949 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      00634A 02 5D CE         [24] 1950 	ljmp	_control_stall
                                   1951 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      00634D                       1952 00188$:
                                   1953 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      00634D 20 17 03         [24] 1954 	jb	_control_setup_zero_value_10000_287,01283$
      006350 02 5D CE         [24] 1955 	ljmp	_control_stall
      006353                       1956 01283$:
      006353 90 07 B8         [24] 1957 	mov	dptr,#_D0SetupLen
      006356 E0               [24] 1958 	movx	a,@dptr
      006357 F9               [12] 1959 	mov	r1,a
      006358 A3               [24] 1960 	inc	dptr
      006359 E0               [24] 1961 	movx	a,@dptr
      00635A FA               [12] 1962 	mov	r2,a
      00635B B9 02 05         [24] 1963 	cjne	r1,#0x02,01284$
      00635E BA 00 02         [24] 1964 	cjne	r2,#0x00,01284$
      006361 80 03            [24] 1965 	sjmp	01285$
      006363                       1966 01284$:
      006363 02 5D CE         [24] 1967 	ljmp	_control_stall
      006366                       1968 01285$:
                                   1969 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      006366 E4               [12] 1970 	clr	a
      006367 BF 80 01         [24] 1971 	cjne	r7,#0x80,01286$
      00636A 04               [12] 1972 	inc	a
      00636B                       1973 01286$:
      00636B FA               [12] 1974 	mov	r2,a
      00636C 60 03            [24] 1975 	jz	00196$
      00636E 20 16 35         [24] 1976 	jb	_control_setup_zero_index_10000_287,00189$
      006371                       1977 00196$:
      006371 BF 81 09         [24] 1978 	cjne	r7,#0x81,00202$
      006374 30 15 06         [24] 1979 	jnb	_control_setup_valid_interface_10000_287,00202$
      006377 90 07 BD         [24] 1980 	mov	dptr,#_D0UsbConfig
      00637A E0               [24] 1981 	movx	a,@dptr
      00637B 70 29            [24] 1982 	jnz	00189$
      00637D                       1983 00202$:
                                   1984 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      00637D BF 82 70         [24] 1985 	cjne	r7,#0x82,00190$
      006380 90 07 BD         [24] 1986 	mov	dptr,#_D0UsbConfig
      006383 E0               [24] 1987 	movx	a,@dptr
      006384 60 6A            [24] 1988 	jz	00190$
      006386 EB               [12] 1989 	mov	a,r3
      006387 4C               [12] 1990 	orl	a,r4
      006388 60 1C            [24] 1991 	jz	00189$
      00638A 8B 00            [24] 1992 	mov	ar0,r3
      00638C 8C 01            [24] 1993 	mov	ar1,r4
      00638E B8 80 05         [24] 1994 	cjne	r0,#0x80,01298$
      006391 B9 00 02         [24] 1995 	cjne	r1,#0x00,01298$
      006394 80 10            [24] 1996 	sjmp	00189$
      006396                       1997 01298$:
      006396 C3               [12] 1998 	clr	c
      006397 E8               [12] 1999 	mov	a,r0
      006398 94 81            [12] 2000 	subb	a,#0x81
      00639A E9               [12] 2001 	mov	a,r1
      00639B 94 00            [12] 2002 	subb	a,#0x00
      00639D 40 51            [24] 2003 	jc	00190$
      00639F 74 83            [12] 2004 	mov	a,#0x83
      0063A1 98               [12] 2005 	subb	a,r0
      0063A2 E4               [12] 2006 	clr	a
      0063A3 99               [12] 2007 	subb	a,r1
      0063A4 40 4A            [24] 2008 	jc	00190$
                                   2009 ;	free result
      0063A6                       2010 00189$:
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      0063A6 8B 01            [24] 2012 	mov	ar1,r3
      0063A8 53 01 07         [24] 2013 	anl	ar1,#0x07
                                   2014 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0063AB EA               [12] 2015 	mov	a,r2
      0063AC 60 0B            [24] 2016 	jz	00308$
      0063AE 90 07 BF         [24] 2017 	mov	dptr,#_USB_SleepStatus
      0063B1 E0               [24] 2018 	movx	a,@dptr
      0063B2 54 01            [12] 2019 	anl	a,#0x01
      0063B4 25 E0            [12] 2020 	add	a,acc
      0063B6 FA               [12] 2021 	mov	r2,a
      0063B7 80 22            [24] 2022 	sjmp	00309$
      0063B9                       2023 00308$:
                                   2024 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0063B9 BF 82 1B         [24] 2025 	cjne	r7,#0x82,00310$
      0063BC E9               [12] 2026 	mov	a,r1
      0063BD 60 18            [24] 2027 	jz	00310$
      0063BF 89 00            [24] 2028 	mov	ar0,r1
      0063C1 79 00            [12] 2029 	mov	r1,#0x00
      0063C3 74 22            [12] 2030 	mov	a,#0x22
      0063C5 29               [12] 2031 	add	a, r1
      0063C6 F9               [12] 2032 	mov	r1,a
      0063C7 88 82            [24] 2033 	mov	dpl,r0
      0063C9 89 83            [24] 2034 	mov	dph,r1
      0063CB E0               [24] 2035 	movx	a,@dptr
      0063CC F9               [12] 2036 	mov	r1,a
      0063CD 53 01 03         [24] 2037 	anl	ar1,#0x03
      0063D0 B9 03 04         [24] 2038 	cjne	r1,#0x03,00310$
      0063D3 79 01            [12] 2039 	mov	r1,#0x01
      0063D5 80 02            [24] 2040 	sjmp	00311$
      0063D7                       2041 00310$:
      0063D7 79 00            [12] 2042 	mov	r1,#0x00
      0063D9                       2043 00311$:
      0063D9 89 02            [24] 2044 	mov	ar2,r1
      0063DB                       2045 00309$:
      0063DB 90 10 00         [24] 2046 	mov	dptr,#0x1000
      0063DE EA               [12] 2047 	mov	a,r2
      0063DF F0               [24] 2048 	movx	@dptr,a
                                   2049 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      0063E0 A3               [24] 2050 	inc	dptr
      0063E1 E4               [12] 2051 	clr	a
      0063E2 F0               [24] 2052 	movx	@dptr,a
                                   2053 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      0063E3 90 22 08         [24] 2054 	mov	dptr,#0x2208
      0063E6 74 02            [12] 2055 	mov	a,#0x02
      0063E8 F0               [24] 2056 	movx	@dptr,a
                                   2057 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      0063E9 90 08 16         [24] 2058 	mov	dptr,#_control_phase
      0063EC F0               [24] 2059 	movx	@dptr,a
      0063ED 02 67 7D         [24] 2060 	ljmp	00291$
      0063F0                       2061 00190$:
                                   2062 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      0063F0 02 5D CE         [24] 2063 	ljmp	_control_stall
                                   2064 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      0063F3                       2065 00205$:
                                   2066 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      0063F3 20 18 03         [24] 2067 	jb	_control_setup_zero_length_10000_287,01307$
      0063F6 02 64 86         [24] 2068 	ljmp	00279$
      0063F9                       2069 01307$:
      0063F9 90 07 BD         [24] 2070 	mov	dptr,#_D0UsbConfig
      0063FC E0               [24] 2071 	movx	a,@dptr
      0063FD 70 03            [24] 2072 	jnz	01308$
      0063FF 02 64 86         [24] 2073 	ljmp	00279$
      006402                       2074 01308$:
                                   2075 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      006402 EF               [12] 2076 	mov	a,r7
      006403 70 29            [24] 2077 	jnz	00218$
      006405 8D 01            [24] 2078 	mov	ar1,r5
      006407 8E 02            [24] 2079 	mov	ar2,r6
      006409 B9 01 22         [24] 2080 	cjne	r1,#0x01,00218$
      00640C BA 00 1F         [24] 2081 	cjne	r2,#0x00,00218$
      00640F 30 16 1C         [24] 2082 	jnb	_control_setup_zero_index_10000_287,00218$
                                   2083 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006412 90 07 B7         [24] 2084 	mov	dptr,#_D0SetupReqCode
      006415 E0               [24] 2085 	movx	a,@dptr
      006416 FA               [12] 2086 	mov	r2,a
      006417 BA 03 0A         [24] 2087 	cjne	r2,#0x03,00207$
      00641A 90 07 BF         [24] 2088 	mov	dptr,#_USB_SleepStatus
      00641D E0               [24] 2089 	movx	a,@dptr
      00641E 43 E0 01         [24] 2090 	orl	acc,#0x01
      006421 F0               [24] 2091 	movx	@dptr,a
      006422 80 59            [24] 2092 	sjmp	00219$
      006424                       2093 00207$:
                                   2094 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      006424 90 07 BF         [24] 2095 	mov	dptr,#_USB_SleepStatus
      006427 E0               [24] 2096 	movx	a,@dptr
      006428 53 E0 FE         [24] 2097 	anl	acc,#0xfe
      00642B F0               [24] 2098 	movx	@dptr,a
      00642C 80 4F            [24] 2099 	sjmp	00219$
      00642E                       2100 00218$:
                                   2101 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      00642E BF 02 49         [24] 2102 	cjne	r7,#0x02,00212$
      006431 30 17 46         [24] 2103 	jnb	_control_setup_zero_value_10000_287,00212$
      006434 8B 01            [24] 2104 	mov	ar1,r3
      006436 8C 02            [24] 2105 	mov	ar2,r4
      006438 C3               [12] 2106 	clr	c
      006439 E9               [12] 2107 	mov	a,r1
      00643A 94 81            [12] 2108 	subb	a,#0x81
      00643C EA               [12] 2109 	mov	a,r2
      00643D 94 00            [12] 2110 	subb	a,#0x00
      00643F 40 39            [24] 2111 	jc	00212$
      006441 74 83            [12] 2112 	mov	a,#0x83
      006443 99               [12] 2113 	subb	a,r1
      006444 E4               [12] 2114 	clr	a
      006445 9A               [12] 2115 	subb	a,r2
      006446 40 32            [24] 2116 	jc	00212$
                                   2117 ;	free result
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      006448 8B 02            [24] 2119 	mov	ar2,r3
      00644A 53 02 07         [24] 2120 	anl	ar2,#0x07
                                   2121 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      00644D 8A 00            [24] 2122 	mov	ar0,r2
      00644F 79 00            [12] 2123 	mov	r1,#0x00
      006451 74 22            [12] 2124 	mov	a,#0x22
      006453 29               [12] 2125 	add	a, r1
      006454 F9               [12] 2126 	mov	r1,a
      006455 88 17            [24] 2127 	mov	_control_setup_sloc3_1_0,r0
      006457 89 18            [24] 2128 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006459 90 07 B7         [24] 2129 	mov	dptr,#_D0SetupReqCode
      00645C E0               [24] 2130 	movx	a,@dptr
      00645D F9               [12] 2131 	mov	r1,a
      00645E B9 03 04         [24] 2132 	cjne	r1,#0x03,00318$
      006461 79 03            [12] 2133 	mov	r1,#0x03
      006463 80 02            [24] 2134 	sjmp	00319$
      006465                       2135 00318$:
      006465 79 02            [12] 2136 	mov	r1,#0x02
      006467                       2137 00319$:
      006467 43 01 10         [24] 2138 	orl	ar1,#0x10
      00646A 85 17 82         [24] 2139 	mov	dpl,_control_setup_sloc3_1_0
      00646D 85 18 83         [24] 2140 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006470 E9               [12] 2141 	mov	a,r1
      006471 F0               [24] 2142 	movx	@dptr,a
                                   2143 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006472 BA 03 08         [24] 2144 	cjne	r2,#0x03,00219$
      006475 12 5D 5A         [24] 2145 	lcall	_raw_complete
      006478 80 03            [24] 2146 	sjmp	00219$
      00647A                       2147 00212$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      00647A 02 5D CE         [24] 2149 	ljmp	_control_stall
      00647D                       2150 00219$:
                                   2151 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      00647D 90 08 16         [24] 2152 	mov	dptr,#_control_phase
      006480 74 03            [12] 2153 	mov	a,#0x03
      006482 F0               [24] 2154 	movx	@dptr,a
      006483 02 67 7D         [24] 2155 	ljmp	00291$
      006486                       2156 00279$:
                                   2157 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      006486 E4               [12] 2158 	clr	a
      006487 BF A1 01         [24] 2159 	cjne	r7,#0xa1,01324$
      00648A 04               [12] 2160 	inc	a
      00648B                       2161 01324$:
      00648B FA               [12] 2162 	mov	r2,a
      00648C 70 03            [24] 2163 	jnz	01326$
      00648E 02 66 F8         [24] 2164 	ljmp	00273$
      006491                       2165 01326$:
      006491 90 07 B7         [24] 2166 	mov	dptr,#_D0SetupReqCode
      006494 E0               [24] 2167 	movx	a,@dptr
      006495 F9               [12] 2168 	mov	r1,a
      006496 B9 01 02         [24] 2169 	cjne	r1,#0x01,01327$
      006499 80 03            [24] 2170 	sjmp	01328$
      00649B                       2171 01327$:
      00649B 02 66 F8         [24] 2172 	ljmp	00273$
      00649E                       2173 01328$:
      00649E 90 07 BD         [24] 2174 	mov	dptr,#_D0UsbConfig
      0064A1 E0               [24] 2175 	movx	a,@dptr
      0064A2 70 03            [24] 2176 	jnz	01329$
      0064A4 02 66 F8         [24] 2177 	ljmp	00273$
      0064A7                       2178 01329$:
      0064A7 90 07 B8         [24] 2179 	mov	dptr,#_D0SetupLen
      0064AA E0               [24] 2180 	movx	a,@dptr
      0064AB F8               [12] 2181 	mov	r0,a
      0064AC A3               [24] 2182 	inc	dptr
      0064AD E0               [24] 2183 	movx	a,@dptr
      0064AE 48               [12] 2184 	orl	a,r0
      0064AF 70 03            [24] 2185 	jnz	01330$
      0064B1 02 66 F8         [24] 2186 	ljmp	00273$
      0064B4                       2187 01330$:
                                   2188 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      0064B4 C0 03            [24] 2189 	push	ar3
      0064B6 C0 04            [24] 2190 	push	ar4
      0064B8 8D 01            [24] 2191 	mov	ar1,r5
                                   2192 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      0064BA 8E 00            [24] 2193 	mov	ar0,r6
      0064BC B8 01 03         [24] 2194 	cjne	r0,#0x01,01331$
      0064BF E8               [12] 2195 	mov	a,r0
      0064C0 80 01            [24] 2196 	sjmp	01332$
      0064C2                       2197 01331$:
      0064C2 E4               [12] 2198 	clr	a
      0064C3                       2199 01332$:
      0064C3 F5 17            [12] 2200 	mov	_control_setup_sloc3_1_0,a
      0064C5 D0 04            [24] 2201 	pop	ar4
      0064C7 D0 03            [24] 2202 	pop	ar3
      0064C9 E5 17            [12] 2203 	mov	a,_control_setup_sloc3_1_0
      0064CB 60 17            [24] 2204 	jz	00251$
      0064CD EB               [12] 2205 	mov	a,r3
      0064CE 4C               [12] 2206 	orl	a,r4
      0064CF 70 13            [24] 2207 	jnz	00251$
      0064D1 E9               [12] 2208 	mov	a,r1
      0064D2 70 10            [24] 2209 	jnz	00251$
                                   2210 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      0064D4 90 08 20         [24] 2211 	mov	dptr,#_control_setup_length_10000_287
      0064D7 74 08            [12] 2212 	mov	a,#0x08
      0064D9 F0               [24] 2213 	movx	@dptr,a
      0064DA E4               [12] 2214 	clr	a
      0064DB A3               [24] 2215 	inc	dptr
      0064DC F0               [24] 2216 	movx	@dptr,a
                                   2217 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      0064DD 90 08 22         [24] 2218 	mov	dptr,#_control_setup_offset_10000_287
      0064E0 F0               [24] 2219 	movx	@dptr,a
      0064E1 02 66 68         [24] 2220 	ljmp	00252$
      0064E4                       2221 00251$:
                                   2222 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      0064E4 E5 17            [12] 2223 	mov	a,_control_setup_sloc3_1_0
      0064E6 60 27            [24] 2224 	jz	00245$
      0064E8 BB 02 24         [24] 2225 	cjne	r3,#0x02,00245$
      0064EB BC 00 21         [24] 2226 	cjne	r4,#0x00,00245$
                                   2227 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      0064EE B9 07 00         [24] 2228 	cjne	r1,#0x07,01339$
      0064F1                       2229 01339$:
      0064F1 50 1C            [24] 2230 	jnc	00245$
      0064F3 E9               [12] 2231 	mov	a,r1
      0064F4 90 BB 5F         [24] 2232 	mov	dptr,#_shared_lengths
      0064F7 93               [24] 2233 	movc	a,@a+dptr
      0064F8 F8               [12] 2234 	mov	r0,a
      0064F9 60 14            [24] 2235 	jz	00245$
                                   2236 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      0064FB 90 08 20         [24] 2237 	mov	dptr,#_control_setup_length_10000_287
      0064FE E8               [12] 2238 	mov	a,r0
      0064FF F0               [24] 2239 	movx	@dptr,a
      006500 E4               [12] 2240 	clr	a
      006501 A3               [24] 2241 	inc	dptr
      006502 F0               [24] 2242 	movx	@dptr,a
                                   2243 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      006503 E9               [12] 2244 	mov	a,r1
      006504 90 BB 58         [24] 2245 	mov	dptr,#_shared_offsets
      006507 93               [24] 2246 	movc	a,@a+dptr
      006508 90 08 22         [24] 2247 	mov	dptr,#_control_setup_offset_10000_287
      00650B F0               [24] 2248 	movx	@dptr,a
      00650C 02 66 68         [24] 2249 	ljmp	00252$
      00650F                       2250 00245$:
                                   2251 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      00650F E5 17            [12] 2252 	mov	a,_control_setup_sloc3_1_0
      006511 60 7A            [24] 2253 	jz	00240$
      006513 BB 01 77         [24] 2254 	cjne	r3,#0x01,00240$
      006516 BC 00 74         [24] 2255 	cjne	r4,#0x00,00240$
      006519 E9               [12] 2256 	mov	a,r1
      00651A 70 71            [24] 2257 	jnz	00240$
                                   2258 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      00651C 90 07 B8         [24] 2259 	mov	dptr,#_D0SetupLen
      00651F E0               [24] 2260 	movx	a,@dptr
      006520 F8               [12] 2261 	mov	r0,a
      006521 A3               [24] 2262 	inc	dptr
      006522 E0               [24] 2263 	movx	a,@dptr
      006523 F9               [12] 2264 	mov	r1,a
      006524 C3               [12] 2265 	clr	c
      006525 E8               [12] 2266 	mov	a,r0
      006526 94 20            [12] 2267 	subb	a,#0x20
      006528 E9               [12] 2268 	mov	a,r1
      006529 94 00            [12] 2269 	subb	a,#0x00
      00652B 50 0A            [24] 2270 	jnc	00320$
      00652D 90 07 B8         [24] 2271 	mov	dptr,#_D0SetupLen
      006530 E0               [24] 2272 	movx	a,@dptr
      006531 F8               [12] 2273 	mov	r0,a
      006532 A3               [24] 2274 	inc	dptr
      006533 E0               [24] 2275 	movx	a,@dptr
      006534 F9               [12] 2276 	mov	r1,a
      006535 80 04            [24] 2277 	sjmp	00321$
      006537                       2278 00320$:
      006537 78 20            [12] 2279 	mov	r0,#0x20
      006539 79 00            [12] 2280 	mov	r1,#0x00
      00653B                       2281 00321$:
                                   2282 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      00653B 75 17 00         [24] 2283 	mov	_control_setup_sloc3_1_0,#0x00
      00653E                       2284 00293$:
      00653E C0 03            [24] 2285 	push	ar3
      006540 C0 04            [24] 2286 	push	ar4
      006542 AB 17            [24] 2287 	mov	r3,_control_setup_sloc3_1_0
      006544 7C 00            [12] 2288 	mov	r4,#0x00
      006546 C3               [12] 2289 	clr	c
      006547 EB               [12] 2290 	mov	a,r3
      006548 98               [12] 2291 	subb	a,r0
      006549 EC               [12] 2292 	mov	a,r4
      00654A 99               [12] 2293 	subb	a,r1
      00654B D0 04            [24] 2294 	pop	ar4
      00654D D0 03            [24] 2295 	pop	ar3
      00654F 50 32            [24] 2296 	jnc	00222$
      006551 C0 00            [24] 2297 	push	ar0
      006553 C0 01            [24] 2298 	push	ar1
      006555 85 17 19         [24] 2299 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006558 74 10            [12] 2300 	mov	a,#0x10
      00655A 24 00            [12] 2301 	add	a, #0x00
      00655C F5 1A            [12] 2302 	mov	(_control_setup_sloc4_1_0 + 1),a
      00655E A8 17            [24] 2303 	mov	r0,_control_setup_sloc3_1_0
      006560 79 00            [12] 2304 	mov	r1,#0x00
      006562 74 C0            [12] 2305 	mov	a,#0xc0
      006564 28               [12] 2306 	add	a, r0
      006565 F8               [12] 2307 	mov	r0,a
      006566 E4               [12] 2308 	clr	a
      006567 39               [12] 2309 	addc	a, r1
      006568 F9               [12] 2310 	mov	r1,a
      006569 88 82            [24] 2311 	mov	dpl,r0
      00656B 74 10            [12] 2312 	mov	a,#0x10
      00656D 29               [12] 2313 	add	a, r1
      00656E F5 83            [12] 2314 	mov	dph,a
      006570 E0               [24] 2315 	movx	a,@dptr
      006571 85 19 82         [24] 2316 	mov	dpl,_control_setup_sloc4_1_0
      006574 85 1A 83         [24] 2317 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006577 F0               [24] 2318 	movx	@dptr,a
      006578 E5 17            [12] 2319 	mov	a,_control_setup_sloc3_1_0
      00657A 04               [12] 2320 	inc	a
      00657B F5 17            [12] 2321 	mov	_control_setup_sloc3_1_0,a
      00657D D0 01            [24] 2322 	pop	ar1
      00657F D0 00            [24] 2323 	pop	ar0
      006581 80 BB            [24] 2324 	sjmp	00293$
      006583                       2325 00222$:
                                   2326 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      006583 90 08 20         [24] 2327 	mov	dptr,#_control_setup_length_10000_287
      006586 E4               [12] 2328 	clr	a
      006587 F0               [24] 2329 	movx	@dptr,a
      006588 A3               [24] 2330 	inc	dptr
      006589 F0               [24] 2331 	movx	@dptr,a
      00658A 02 66 68         [24] 2332 	ljmp	00252$
      00658D                       2333 00240$:
                                   2334 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      00658D 8D 00            [24] 2335 	mov	ar0,r5
      00658F 8E 01            [24] 2336 	mov	ar1,r6
      006591 B8 00 21         [24] 2337 	cjne	r0,#0x00,00236$
      006594 B9 02 1E         [24] 2338 	cjne	r1,#0x02,00236$
      006597 EB               [12] 2339 	mov	a,r3
      006598 4C               [12] 2340 	orl	a,r4
      006599 70 1A            [24] 2341 	jnz	00236$
                                   2342 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      00659B 90 07 C2         [24] 2343 	mov	dptr,#_KB_USB_SetReport
      00659E E0               [24] 2344 	movx	a,@dptr
      00659F 90 10 00         [24] 2345 	mov	dptr,#0x1000
      0065A2 F0               [24] 2346 	movx	@dptr,a
                                   2347 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      0065A3 90 08 20         [24] 2348 	mov	dptr,#_control_setup_length_10000_287
      0065A6 E4               [12] 2349 	clr	a
      0065A7 F0               [24] 2350 	movx	@dptr,a
      0065A8 A3               [24] 2351 	inc	dptr
      0065A9 F0               [24] 2352 	movx	@dptr,a
                                   2353 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      0065AA 90 07 B8         [24] 2354 	mov	dptr,#_D0SetupLen
      0065AD 04               [12] 2355 	inc	a
      0065AE F0               [24] 2356 	movx	@dptr,a
      0065AF E4               [12] 2357 	clr	a
      0065B0 A3               [24] 2358 	inc	dptr
      0065B1 F0               [24] 2359 	movx	@dptr,a
      0065B2 02 66 68         [24] 2360 	ljmp	00252$
      0065B5                       2361 00236$:
                                   2362 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      0065B5 B8 06 41         [24] 2363 	cjne	r0,#0x06,00232$
      0065B8 B9 02 3E         [24] 2364 	cjne	r1,#0x02,00232$
      0065BB BB 02 3B         [24] 2365 	cjne	r3,#0x02,00232$
      0065BE BC 00 38         [24] 2366 	cjne	r4,#0x00,00232$
                                   2367 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      0065C1 C0 03            [24] 2368 	push	ar3
      0065C3 C0 04            [24] 2369 	push	ar4
      0065C5 90 10 00         [24] 2370 	mov	dptr,#0x1000
      0065C8 74 06            [12] 2371 	mov	a,#0x06
      0065CA F0               [24] 2372 	movx	@dptr,a
                                   2373 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      0065CB 90 07 C2         [24] 2374 	mov	dptr,#_KB_USB_SetReport
      0065CE E0               [24] 2375 	movx	a,@dptr
      0065CF 90 10 01         [24] 2376 	mov	dptr,#0x1001
      0065D2 F0               [24] 2377 	movx	@dptr,a
                                   2378 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      0065D3 90 08 20         [24] 2379 	mov	dptr,#_control_setup_length_10000_287
      0065D6 E4               [12] 2380 	clr	a
      0065D7 F0               [24] 2381 	movx	@dptr,a
      0065D8 A3               [24] 2382 	inc	dptr
      0065D9 F0               [24] 2383 	movx	@dptr,a
                                   2384 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      0065DA 90 07 B8         [24] 2385 	mov	dptr,#_D0SetupLen
      0065DD E0               [24] 2386 	movx	a,@dptr
      0065DE FB               [12] 2387 	mov	r3,a
      0065DF A3               [24] 2388 	inc	dptr
      0065E0 E0               [24] 2389 	movx	a,@dptr
      0065E1 FC               [12] 2390 	mov	r4,a
      0065E2 C3               [12] 2391 	clr	c
      0065E3 74 02            [12] 2392 	mov	a,#0x02
      0065E5 9B               [12] 2393 	subb	a,r3
      0065E6 E4               [12] 2394 	clr	a
      0065E7 9C               [12] 2395 	subb	a,r4
      0065E8 D0 04            [24] 2396 	pop	ar4
      0065EA D0 03            [24] 2397 	pop	ar3
      0065EC 50 7A            [24] 2398 	jnc	00252$
                                   2399 ;	free result
      0065EE 90 07 B8         [24] 2400 	mov	dptr,#_D0SetupLen
      0065F1 74 02            [12] 2401 	mov	a,#0x02
      0065F3 F0               [24] 2402 	movx	@dptr,a
      0065F4 E4               [12] 2403 	clr	a
      0065F5 A3               [24] 2404 	inc	dptr
      0065F6 F0               [24] 2405 	movx	@dptr,a
      0065F7 80 6F            [24] 2406 	sjmp	00252$
      0065F9                       2407 00232$:
                                   2408 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      0065F9 B8 00 69         [24] 2409 	cjne	r0,#0x00,00228$
      0065FC B9 03 66         [24] 2410 	cjne	r1,#0x03,00228$
      0065FF BB 01 63         [24] 2411 	cjne	r3,#0x01,00228$
      006602 BC 00 60         [24] 2412 	cjne	r4,#0x00,00228$
                                   2413 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      006605 90 10 00         [24] 2414 	mov	dptr,#0x1000
      006608 74 41            [12] 2415 	mov	a,#0x41
      00660A F0               [24] 2416 	movx	@dptr,a
                                   2417 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      00660B A3               [24] 2418 	inc	dptr
      00660C 74 4B            [12] 2419 	mov	a,#0x4b
      00660E F0               [24] 2420 	movx	@dptr,a
                                   2421 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      00660F A3               [24] 2422 	inc	dptr
      006610 74 42            [12] 2423 	mov	a,#0x42
      006612 F0               [24] 2424 	movx	@dptr,a
                                   2425 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      006613 A3               [24] 2426 	inc	dptr
      006614 74 54            [12] 2427 	mov	a,#0x54
      006616 F0               [24] 2428 	movx	@dptr,a
                                   2429 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      006617 A3               [24] 2430 	inc	dptr
      006618 74 01            [12] 2431 	mov	a,#0x01
      00661A F0               [24] 2432 	movx	@dptr,a
                                   2433 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      00661B 90 07 C3         [24] 2434 	mov	dptr,#_ak820_boot_stage
      00661E E0               [24] 2435 	movx	a,@dptr
      00661F 90 10 05         [24] 2436 	mov	dptr,#0x1005
      006622 F0               [24] 2437 	movx	@dptr,a
                                   2438 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006623 90 07 C4         [24] 2439 	mov	dptr,#_ak820_main_heartbeat
      006626 E0               [24] 2440 	movx	a,@dptr
      006627 90 10 06         [24] 2441 	mov	dptr,#0x1006
      00662A F0               [24] 2442 	movx	@dptr,a
                                   2443 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      00662B 90 07 BE         [24] 2444 	mov	dptr,#_USB_EnumStatus
      00662E E0               [24] 2445 	movx	a,@dptr
      00662F 60 02            [24] 2446 	jz	00322$
      006631 74 01            [12] 2447 	mov	a,#0x01
      006633                       2448 00322$:
      006633 F9               [12] 2449 	mov	r1,a
      006634 90 07 BF         [24] 2450 	mov	dptr,#_USB_SleepStatus
      006637 E0               [24] 2451 	movx	a,@dptr
      006638 54 02            [12] 2452 	anl	a,#0x02
      00663A F8               [12] 2453 	mov	r0,a
      00663B E9               [12] 2454 	mov	a,r1
      00663C 42 00            [12] 2455 	orl	ar0,a
      00663E 90 10 07         [24] 2456 	mov	dptr,#0x1007
      006641 E8               [12] 2457 	mov	a,r0
      006642 F0               [24] 2458 	movx	@dptr,a
                                   2459 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      006643 90 08 20         [24] 2460 	mov	dptr,#_control_setup_length_10000_287
      006646 E4               [12] 2461 	clr	a
      006647 F0               [24] 2462 	movx	@dptr,a
      006648 A3               [24] 2463 	inc	dptr
      006649 F0               [24] 2464 	movx	@dptr,a
                                   2465 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      00664A 90 07 B8         [24] 2466 	mov	dptr,#_D0SetupLen
      00664D E0               [24] 2467 	movx	a,@dptr
      00664E F8               [12] 2468 	mov	r0,a
      00664F A3               [24] 2469 	inc	dptr
      006650 E0               [24] 2470 	movx	a,@dptr
      006651 F9               [12] 2471 	mov	r1,a
      006652 C3               [12] 2472 	clr	c
      006653 74 08            [12] 2473 	mov	a,#0x08
      006655 98               [12] 2474 	subb	a,r0
      006656 E4               [12] 2475 	clr	a
      006657 99               [12] 2476 	subb	a,r1
      006658 50 0E            [24] 2477 	jnc	00252$
                                   2478 ;	free result
      00665A 90 07 B8         [24] 2479 	mov	dptr,#_D0SetupLen
      00665D 74 08            [12] 2480 	mov	a,#0x08
      00665F F0               [24] 2481 	movx	@dptr,a
      006660 E4               [12] 2482 	clr	a
      006661 A3               [24] 2483 	inc	dptr
      006662 F0               [24] 2484 	movx	@dptr,a
      006663 80 03            [24] 2485 	sjmp	00252$
      006665                       2486 00228$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      006665 02 5D CE         [24] 2488 	ljmp	_control_stall
      006668                       2489 00252$:
                                   2490 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      006668 90 08 20         [24] 2491 	mov	dptr,#_control_setup_length_10000_287
      00666B E0               [24] 2492 	movx	a,@dptr
      00666C F5 19            [12] 2493 	mov	_control_setup_sloc4_1_0,a
      00666E A3               [24] 2494 	inc	dptr
      00666F E0               [24] 2495 	movx	a,@dptr
      006670 F5 1A            [12] 2496 	mov	(_control_setup_sloc4_1_0 + 1),a
      006672 E5 19            [12] 2497 	mov	a,_control_setup_sloc4_1_0
      006674 45 1A            [12] 2498 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006676 60 50            [24] 2499 	jz	00262$
                                   2500 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      006678 90 07 B8         [24] 2501 	mov	dptr,#_D0SetupLen
      00667B E0               [24] 2502 	movx	a,@dptr
      00667C F8               [12] 2503 	mov	r0,a
      00667D A3               [24] 2504 	inc	dptr
      00667E E0               [24] 2505 	movx	a,@dptr
      00667F F9               [12] 2506 	mov	r1,a
      006680 C3               [12] 2507 	clr	c
      006681 E5 19            [12] 2508 	mov	a,_control_setup_sloc4_1_0
      006683 98               [12] 2509 	subb	a,r0
      006684 E5 1A            [12] 2510 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006686 99               [12] 2511 	subb	a,r1
      006687 50 0A            [24] 2512 	jnc	00559$
                                   2513 ;	free result
      006689 90 07 B8         [24] 2514 	mov	dptr,#_D0SetupLen
      00668C E5 19            [12] 2515 	mov	a,_control_setup_sloc4_1_0
      00668E F0               [24] 2516 	movx	@dptr,a
      00668F E5 1A            [12] 2517 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006691 A3               [24] 2518 	inc	dptr
      006692 F0               [24] 2519 	movx	@dptr,a
                                   2520 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      006693                       2521 00559$:
      006693 75 19 00         [24] 2522 	mov	_control_setup_sloc4_1_0,#0x00
      006696                       2523 00296$:
      006696 90 07 B8         [24] 2524 	mov	dptr,#_D0SetupLen
      006699 E0               [24] 2525 	movx	a,@dptr
      00669A F8               [12] 2526 	mov	r0,a
      00669B C3               [12] 2527 	clr	c
      00669C E5 19            [12] 2528 	mov	a,_control_setup_sloc4_1_0
      00669E 98               [12] 2529 	subb	a,r0
      00669F 50 46            [24] 2530 	jnc	00263$
      0066A1 85 19 17         [24] 2531 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      0066A4 74 10            [12] 2532 	mov	a,#0x10
      0066A6 24 00            [12] 2533 	add	a, #0x00
      0066A8 F5 18            [12] 2534 	mov	(_control_setup_sloc3_1_0 + 1),a
      0066AA 90 08 22         [24] 2535 	mov	dptr,#_control_setup_offset_10000_287
      0066AD E0               [24] 2536 	movx	a,@dptr
      0066AE 25 19            [12] 2537 	add	a, _control_setup_sloc4_1_0
      0066B0 24 E8            [12] 2538 	add	a, #_input_snapshot
      0066B2 F5 82            [12] 2539 	mov	dpl,a
      0066B4 E4               [12] 2540 	clr	a
      0066B5 34 07            [12] 2541 	addc	a,#(_input_snapshot >> 8)
      0066B7 F5 83            [12] 2542 	mov	dph,a
      0066B9 E0               [24] 2543 	movx	a,@dptr
      0066BA 85 17 82         [24] 2544 	mov	dpl,_control_setup_sloc3_1_0
      0066BD 85 18 83         [24] 2545 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0066C0 F0               [24] 2546 	movx	@dptr,a
      0066C1 E5 19            [12] 2547 	mov	a,_control_setup_sloc4_1_0
      0066C3 04               [12] 2548 	inc	a
      0066C4 F5 19            [12] 2549 	mov	_control_setup_sloc4_1_0,a
      0066C6 80 CE            [24] 2550 	sjmp	00296$
      0066C8                       2551 00262$:
                                   2552 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      0066C8 BB 01 1C         [24] 2553 	cjne	r3,#0x01,00263$
      0066CB BC 00 19         [24] 2554 	cjne	r4,#0x00,00263$
      0066CE 90 07 B8         [24] 2555 	mov	dptr,#_D0SetupLen
      0066D1 E0               [24] 2556 	movx	a,@dptr
      0066D2 F8               [12] 2557 	mov	r0,a
      0066D3 A3               [24] 2558 	inc	dptr
      0066D4 E0               [24] 2559 	movx	a,@dptr
      0066D5 F9               [12] 2560 	mov	r1,a
      0066D6 C3               [12] 2561 	clr	c
      0066D7 74 20            [12] 2562 	mov	a,#0x20
      0066D9 98               [12] 2563 	subb	a,r0
      0066DA E4               [12] 2564 	clr	a
      0066DB 99               [12] 2565 	subb	a,r1
      0066DC 50 09            [24] 2566 	jnc	00263$
                                   2567 ;	free result
      0066DE 90 07 B8         [24] 2568 	mov	dptr,#_D0SetupLen
      0066E1 74 20            [12] 2569 	mov	a,#0x20
      0066E3 F0               [24] 2570 	movx	@dptr,a
      0066E4 E4               [12] 2571 	clr	a
      0066E5 A3               [24] 2572 	inc	dptr
      0066E6 F0               [24] 2573 	movx	@dptr,a
      0066E7                       2574 00263$:
                                   2575 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      0066E7 90 07 B8         [24] 2576 	mov	dptr,#_D0SetupLen
      0066EA E0               [24] 2577 	movx	a,@dptr
      0066EB 90 22 08         [24] 2578 	mov	dptr,#0x2208
      0066EE F0               [24] 2579 	movx	@dptr,a
                                   2580 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      0066EF 90 08 16         [24] 2581 	mov	dptr,#_control_phase
      0066F2 74 02            [12] 2582 	mov	a,#0x02
      0066F4 F0               [24] 2583 	movx	@dptr,a
      0066F5 02 67 7D         [24] 2584 	ljmp	00291$
      0066F8                       2585 00273$:
                                   2586 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      0066F8 EB               [12] 2587 	mov	a,r3
      0066F9 4C               [12] 2588 	orl	a,r4
      0066FA 70 37            [24] 2589 	jnz	00265$
      0066FC 90 07 BD         [24] 2590 	mov	dptr,#_D0UsbConfig
      0066FF E0               [24] 2591 	movx	a,@dptr
      006700 60 31            [24] 2592 	jz	00265$
      006702 EA               [12] 2593 	mov	a,r2
      006703 60 2E            [24] 2594 	jz	00265$
      006705 90 07 B7         [24] 2595 	mov	dptr,#_D0SetupReqCode
      006708 E0               [24] 2596 	movx	a,@dptr
      006709 FA               [12] 2597 	mov	r2,a
      00670A BA 03 26         [24] 2598 	cjne	r2,#0x03,00265$
      00670D 30 17 23         [24] 2599 	jnb	_control_setup_zero_value_10000_287,00265$
      006710 90 07 B8         [24] 2600 	mov	dptr,#_D0SetupLen
      006713 E0               [24] 2601 	movx	a,@dptr
      006714 F9               [12] 2602 	mov	r1,a
      006715 A3               [24] 2603 	inc	dptr
      006716 E0               [24] 2604 	movx	a,@dptr
      006717 FA               [12] 2605 	mov	r2,a
      006718 B9 01 18         [24] 2606 	cjne	r1,#0x01,00265$
      00671B BA 00 15         [24] 2607 	cjne	r2,#0x00,00265$
                                   2608 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      00671E 90 0D D8         [24] 2609 	mov	dptr,#_keyboard_protocol
      006721 E0               [24] 2610 	movx	a,@dptr
      006722 90 10 00         [24] 2611 	mov	dptr,#0x1000
      006725 F0               [24] 2612 	movx	@dptr,a
                                   2613 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      006726 90 22 08         [24] 2614 	mov	dptr,#0x2208
      006729 74 01            [12] 2615 	mov	a,#0x01
      00672B F0               [24] 2616 	movx	@dptr,a
                                   2617 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      00672C 90 08 16         [24] 2618 	mov	dptr,#_control_phase
      00672F 04               [12] 2619 	inc	a
      006730 F0               [24] 2620 	movx	@dptr,a
      006731 80 4A            [24] 2621 	sjmp	00291$
      006733                       2622 00265$:
                                   2623 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      006733 02 5D CE         [24] 2625 	ljmp	_control_stall
      006736                       2626 00282$:
                                   2627 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006736 30 15 3E         [24] 2628 	jnb	_control_setup_valid_interface_10000_287,00284$
      006739 90 07 BD         [24] 2629 	mov	dptr,#_D0UsbConfig
      00673C E0               [24] 2630 	movx	a,@dptr
      00673D 60 38            [24] 2631 	jz	00284$
      00673F BF A1 35         [24] 2632 	cjne	r7,#0xa1,00284$
      006742 8E 05            [24] 2633 	mov	ar5,r6
      006744 7E 00            [12] 2634 	mov	r6,#0x00
      006746 ED               [12] 2635 	mov	a,r5
      006747 4E               [12] 2636 	orl	a,r6
      006748 70 2D            [24] 2637 	jnz	00284$
      00674A 90 07 B8         [24] 2638 	mov	dptr,#_D0SetupLen
      00674D E0               [24] 2639 	movx	a,@dptr
      00674E FE               [12] 2640 	mov	r6,a
      00674F A3               [24] 2641 	inc	dptr
      006750 E0               [24] 2642 	movx	a,@dptr
      006751 FF               [12] 2643 	mov	r7,a
      006752 BE 01 22         [24] 2644 	cjne	r6,#0x01,00284$
      006755 BF 00 1F         [24] 2645 	cjne	r7,#0x00,00284$
                                   2646 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006758 EB               [12] 2647 	mov	a,r3
      006759 4C               [12] 2648 	orl	a,r4
      00675A 70 07            [24] 2649 	jnz	00324$
      00675C 90 06 95         [24] 2650 	mov	dptr,#_keyboard_idle
      00675F E0               [24] 2651 	movx	a,@dptr
      006760 FF               [12] 2652 	mov	r7,a
      006761 80 02            [24] 2653 	sjmp	00325$
      006763                       2654 00324$:
      006763 7F 00            [12] 2655 	mov	r7,#0x00
      006765                       2656 00325$:
      006765 90 10 00         [24] 2657 	mov	dptr,#0x1000
      006768 EF               [12] 2658 	mov	a,r7
      006769 F0               [24] 2659 	movx	@dptr,a
                                   2660 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      00676A 90 22 08         [24] 2661 	mov	dptr,#0x2208
      00676D 74 01            [12] 2662 	mov	a,#0x01
      00676F F0               [24] 2663 	movx	@dptr,a
                                   2664 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      006770 90 08 16         [24] 2665 	mov	dptr,#_control_phase
      006773 04               [12] 2666 	inc	a
      006774 F0               [24] 2667 	movx	@dptr,a
      006775 80 06            [24] 2668 	sjmp	00291$
      006777                       2669 00284$:
                                   2670 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      006777 02 5D CE         [24] 2672 	ljmp	_control_stall
      00677A                       2673 00290$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      00677A 02 5D CE         [24] 2675 	ljmp	_control_stall
      00677D                       2676 00291$:
                                   2677 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      00677D 90 22 00         [24] 2678 	mov	dptr,#0x2200
      006780 74 C0            [12] 2679 	mov	a,#0xc0
      006782 F0               [24] 2680 	movx	@dptr,a
                                   2681 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      006783 22               [24] 2682 	ret
                                   2683 ;------------------------------------------------------------
                                   2684 ;Allocation info for local variables in function 'control_out'
                                   2685 ;------------------------------------------------------------
                                   2686 ;i             Allocated with name '_control_out_i_10000_371'
                                   2687 ;------------------------------------------------------------
                                   2688 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2689 ;	-----------------------------------------
                                   2690 ;	 function control_out
                                   2691 ;	-----------------------------------------
      006784                       2692 _control_out:
                                   2693 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006784 90 22 0F         [24] 2694 	mov	dptr,#0x220f
      006787 E0               [24] 2695 	movx	a,@dptr
      006788 20 E6 01         [24] 2696 	jb	acc.6,00102$
      00678B 22               [24] 2697 	ret
      00678C                       2698 00102$:
                                   2699 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      00678C 90 08 16         [24] 2700 	mov	dptr,#_control_phase
      00678F E0               [24] 2701 	movx	a,@dptr
      006790 FF               [12] 2702 	mov	r7,a
      006791 BF 02 12         [24] 2703 	cjne	r7,#0x02,00104$
      006794 90 22 0E         [24] 2704 	mov	dptr,#0x220e
      006797 E0               [24] 2705 	movx	a,@dptr
      006798 70 0C            [24] 2706 	jnz	00104$
                                   2707 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      00679A 90 08 16         [24] 2708 	mov	dptr,#_control_phase
      00679D E4               [12] 2709 	clr	a
      00679E F0               [24] 2710 	movx	@dptr,a
                                   2711 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00679F 90 22 00         [24] 2712 	mov	dptr,#0x2200
      0067A2 74 02            [12] 2713 	mov	a,#0x02
      0067A4 F0               [24] 2714 	movx	@dptr,a
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      0067A5 22               [24] 2716 	ret
      0067A6                       2717 00104$:
                                   2718 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      0067A6 BF 04 19         [24] 2719 	cjne	r7,#0x04,00106$
      0067A9 90 22 0E         [24] 2720 	mov	dptr,#0x220e
      0067AC E0               [24] 2721 	movx	a,@dptr
      0067AD FF               [12] 2722 	mov	r7,a
      0067AE 90 07 B8         [24] 2723 	mov	dptr,#_D0SetupLen
      0067B1 E0               [24] 2724 	movx	a,@dptr
      0067B2 FD               [12] 2725 	mov	r5,a
      0067B3 A3               [24] 2726 	inc	dptr
      0067B4 E0               [24] 2727 	movx	a,@dptr
      0067B5 FE               [12] 2728 	mov	r6,a
      0067B6 7C 00            [12] 2729 	mov	r4,#0x00
      0067B8 EF               [12] 2730 	mov	a,r7
      0067B9 B5 05 06         [24] 2731 	cjne	a,ar5,00209$
      0067BC EC               [12] 2732 	mov	a,r4
      0067BD B5 06 02         [24] 2733 	cjne	a,ar6,00209$
      0067C0 80 03            [24] 2734 	sjmp	00107$
      0067C2                       2735 00209$:
      0067C2                       2736 00106$:
      0067C2 02 5D CE         [24] 2737 	ljmp	_control_stall
      0067C5                       2738 00107$:
                                   2739 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      0067C5 90 08 17         [24] 2740 	mov	dptr,#_output_kind
      0067C8 E0               [24] 2741 	movx	a,@dptr
      0067C9 FF               [12] 2742 	mov	r7,a
      0067CA BF 01 2E         [24] 2743 	cjne	r7,#0x01,00118$
      0067CD 90 07 C5         [24] 2744 	mov	dptr,#_raw_state
      0067D0 E0               [24] 2745 	movx	a,@dptr
      0067D1 FE               [12] 2746 	mov	r6,a
      0067D2 BE 01 26         [24] 2747 	cjne	r6,#0x01,00118$
                                   2748 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      0067D5 7E 00            [12] 2749 	mov	r6,#0x00
      0067D7                       2750 00121$:
      0067D7 EE               [12] 2751 	mov	a,r6
      0067D8 24 C6            [12] 2752 	add	a, #_raw_buffer
      0067DA FC               [12] 2753 	mov	r4,a
      0067DB E4               [12] 2754 	clr	a
      0067DC 34 07            [12] 2755 	addc	a, #(_raw_buffer >> 8)
      0067DE FD               [12] 2756 	mov	r5,a
      0067DF 8E 82            [24] 2757 	mov	dpl,r6
      0067E1 74 10            [12] 2758 	mov	a,#0x10
      0067E3 24 00            [12] 2759 	add	a, #0x00
      0067E5 F5 83            [12] 2760 	mov	dph,a
      0067E7 E0               [24] 2761 	movx	a,@dptr
      0067E8 8C 82            [24] 2762 	mov	dpl,r4
      0067EA 8D 83            [24] 2763 	mov	dph,r5
      0067EC F0               [24] 2764 	movx	@dptr,a
      0067ED 0E               [12] 2765 	inc	r6
      0067EE BE 20 00         [24] 2766 	cjne	r6,#0x20,00214$
      0067F1                       2767 00214$:
      0067F1 40 E4            [24] 2768 	jc	00121$
                                   2769 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      0067F3 90 07 C5         [24] 2770 	mov	dptr,#_raw_state
      0067F6 74 02            [12] 2771 	mov	a,#0x02
      0067F8 F0               [24] 2772 	movx	@dptr,a
      0067F9 80 2B            [24] 2773 	sjmp	00119$
      0067FB                       2774 00118$:
                                   2775 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      0067FB BF 02 0A         [24] 2776 	cjne	r7,#0x02,00115$
                                   2777 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      0067FE 90 10 00         [24] 2778 	mov	dptr,#0x1000
      006801 E0               [24] 2779 	movx	a,@dptr
      006802 90 07 C2         [24] 2780 	mov	dptr,#_KB_USB_SetReport
      006805 F0               [24] 2781 	movx	@dptr,a
      006806 80 1E            [24] 2782 	sjmp	00119$
      006808                       2783 00115$:
                                   2784 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006808 BF 03 18         [24] 2785 	cjne	r7,#0x03,00111$
      00680B 90 10 00         [24] 2786 	mov	dptr,#0x1000
      00680E E0               [24] 2787 	movx	a,@dptr
      00680F FF               [12] 2788 	mov	r7,a
      006810 90 08 18         [24] 2789 	mov	dptr,#_output_report_id
      006813 E0               [24] 2790 	movx	a,@dptr
      006814 FE               [12] 2791 	mov	r6,a
      006815 EF               [12] 2792 	mov	a,r7
      006816 B5 06 0A         [24] 2793 	cjne	a,ar6,00111$
                                   2794 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      006819 90 10 01         [24] 2795 	mov	dptr,#0x1001
      00681C E0               [24] 2796 	movx	a,@dptr
      00681D 90 07 C2         [24] 2797 	mov	dptr,#_KB_USB_SetReport
      006820 F0               [24] 2798 	movx	@dptr,a
      006821 80 03            [24] 2799 	sjmp	00119$
      006823                       2800 00111$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      006823 02 5D CE         [24] 2802 	ljmp	_control_stall
      006826                       2803 00119$:
                                   2804 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006826 90 08 17         [24] 2805 	mov	dptr,#_output_kind
      006829 E4               [12] 2806 	clr	a
      00682A F0               [24] 2807 	movx	@dptr,a
                                   2808 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      00682B 90 07 B8         [24] 2809 	mov	dptr,#_D0SetupLen
      00682E F0               [24] 2810 	movx	@dptr,a
      00682F A3               [24] 2811 	inc	dptr
      006830 F0               [24] 2812 	movx	@dptr,a
                                   2813 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      006831 90 08 16         [24] 2814 	mov	dptr,#_control_phase
      006834 74 03            [12] 2815 	mov	a,#0x03
      006836 F0               [24] 2816 	movx	@dptr,a
                                   2817 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      006837 90 22 08         [24] 2818 	mov	dptr,#0x2208
      00683A E4               [12] 2819 	clr	a
      00683B F0               [24] 2820 	movx	@dptr,a
                                   2821 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      00683C F5 82            [12] 2822 	mov	dpl,a
      00683E 74 48            [12] 2823 	mov	a,#0x48
      006840 F0               [24] 2824 	movx	@dptr,a
                                   2825 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      006841 22               [24] 2826 	ret
                                   2827 ;------------------------------------------------------------
                                   2828 ;Allocation info for local variables in function 'control_in'
                                   2829 ;------------------------------------------------------------
                                   2830 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2831 ;	-----------------------------------------
                                   2832 ;	 function control_in
                                   2833 ;	-----------------------------------------
      006842                       2834 _control_in:
                                   2835 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      006842 90 08 16         [24] 2836 	mov	dptr,#_control_phase
      006845 E0               [24] 2837 	movx	a,@dptr
      006846 FF               [12] 2838 	mov	r7,a
      006847 BF 01 22         [24] 2839 	cjne	r7,#0x01,00109$
                                   2840 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      00684A 90 07 B8         [24] 2841 	mov	dptr,#_D0SetupLen
      00684D E0               [24] 2842 	movx	a,@dptr
      00684E FD               [12] 2843 	mov	r5,a
      00684F A3               [24] 2844 	inc	dptr
      006850 E0               [24] 2845 	movx	a,@dptr
      006851 4D               [12] 2846 	orl	a,r5
      006852 70 06            [24] 2847 	jnz	00101$
      006854 90 08 19         [24] 2848 	mov	dptr,#_control_zlp
      006857 E0               [24] 2849 	movx	a,@dptr
      006858 60 0A            [24] 2850 	jz	00102$
      00685A                       2851 00101$:
                                   2852 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      00685A 90 22 00         [24] 2853 	mov	dptr,#0x2200
      00685D E0               [24] 2854 	movx	a,@dptr
      00685E 64 40            [12] 2855 	xrl	a,#0x40
      006860 F0               [24] 2856 	movx	@dptr,a
                                   2857 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      006861 02 5D F0         [24] 2859 	ljmp	_control_next
      006864                       2860 00102$:
                                   2861 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      006864 90 08 16         [24] 2862 	mov	dptr,#_control_phase
      006867 74 02            [12] 2863 	mov	a,#0x02
      006869 F0               [24] 2864 	movx	@dptr,a
      00686A 80 18            [24] 2865 	sjmp	00110$
      00686C                       2866 00109$:
                                   2867 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      00686C BF 03 15         [24] 2868 	cjne	r7,#0x03,00110$
                                   2869 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      00686F 90 07 B7         [24] 2870 	mov	dptr,#_D0SetupReqCode
      006872 E0               [24] 2871 	movx	a,@dptr
      006873 FF               [12] 2872 	mov	r7,a
      006874 BF 05 08         [24] 2873 	cjne	r7,#0x05,00105$
      006877 90 07 B8         [24] 2874 	mov	dptr,#_D0SetupLen
      00687A E0               [24] 2875 	movx	a,@dptr
      00687B 90 22 07         [24] 2876 	mov	dptr,#0x2207
      00687E F0               [24] 2877 	movx	@dptr,a
      00687F                       2878 00105$:
                                   2879 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      00687F 90 08 16         [24] 2880 	mov	dptr,#_control_phase
      006882 E4               [12] 2881 	clr	a
      006883 F0               [24] 2882 	movx	@dptr,a
      006884                       2883 00110$:
                                   2884 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006884 90 22 00         [24] 2885 	mov	dptr,#0x2200
      006887 74 82            [12] 2886 	mov	a,#0x82
      006889 F0               [24] 2887 	movx	@dptr,a
                                   2888 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      00688A 22               [24] 2889 	ret
                                   2890 ;------------------------------------------------------------
                                   2891 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2892 ;------------------------------------------------------------
                                   2893 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_395'
                                   2894 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_395'
                                   2895 ;------------------------------------------------------------
                                   2896 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2897 ;	-----------------------------------------
                                   2898 ;	 function USB_DeviceInterrupt
                                   2899 ;	-----------------------------------------
      00688B                       2900 _USB_DeviceInterrupt:
                                   2901 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      00688B                       2902 00129$:
                                   2903 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      00688B 90 22 3D         [24] 2904 	mov	dptr,#0x223d
      00688E E0               [24] 2905 	movx	a,@dptr
      00688F 30 E0 4B         [24] 2906 	jnb	acc.0,00127$
                                   2907 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      006892 12 5D 77         [24] 2908 	lcall	_endpoints_reset
                                   2909 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006895 90 22 07         [24] 2910 	mov	dptr,#0x2207
      006898 E4               [12] 2911 	clr	a
      006899 F0               [24] 2912 	movx	@dptr,a
                                   2913 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      00689A 90 07 BF         [24] 2914 	mov	dptr,#_USB_SleepStatus
      00689D F0               [24] 2915 	movx	@dptr,a
      00689E 90 07 BE         [24] 2916 	mov	dptr,#_USB_EnumStatus
      0068A1 F0               [24] 2917 	movx	@dptr,a
      0068A2 90 07 BD         [24] 2918 	mov	dptr,#_D0UsbConfig
      0068A5 F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      0068A6 90 07 C2         [24] 2921 	mov	dptr,#_KB_USB_SetReport
      0068A9 F0               [24] 2922 	movx	@dptr,a
                                   2923 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      0068AA 90 0D D8         [24] 2924 	mov	dptr,#_keyboard_protocol
      0068AD 04               [12] 2925 	inc	a
      0068AE F0               [24] 2926 	movx	@dptr,a
                                   2927 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      0068AF 90 06 95         [24] 2928 	mov	dptr,#_keyboard_idle
      0068B2 E4               [12] 2929 	clr	a
      0068B3 F0               [24] 2930 	movx	@dptr,a
                                   2931 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      0068B4 90 07 E7         [24] 2932 	mov	dptr,#_keyboard_reset
      0068B7 04               [12] 2933 	inc	a
      0068B8 F0               [24] 2934 	movx	@dptr,a
                                   2935 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      0068B9 90 07 B7         [24] 2936 	mov	dptr,#_D0SetupReqCode
      0068BC 74 FF            [12] 2937 	mov	a,#0xff
      0068BE F0               [24] 2938 	movx	@dptr,a
                                   2939 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      0068BF 90 07 B8         [24] 2940 	mov	dptr,#_D0SetupLen
      0068C2 E4               [12] 2941 	clr	a
      0068C3 F0               [24] 2942 	movx	@dptr,a
      0068C4 A3               [24] 2943 	inc	dptr
      0068C5 F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      0068C6 90 08 16         [24] 2946 	mov	dptr,#_control_phase
      0068C9 F0               [24] 2947 	movx	@dptr,a
                                   2948 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0068CA 90 22 00         [24] 2949 	mov	dptr,#0x2200
      0068CD 74 02            [12] 2950 	mov	a,#0x02
      0068CF F0               [24] 2951 	movx	@dptr,a
                                   2952 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      0068D0 90 22 0F         [24] 2953 	mov	dptr,#0x220f
      0068D3 E4               [12] 2954 	clr	a
      0068D4 F0               [24] 2955 	movx	@dptr,a
                                   2956 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      0068D5 90 22 3D         [24] 2957 	mov	dptr,#0x223d
      0068D8 04               [12] 2958 	inc	a
      0068D9 F0               [24] 2959 	movx	@dptr,a
      0068DA 02 69 70         [24] 2960 	ljmp	00130$
      0068DD                       2961 00127$:
                                   2962 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      0068DD 90 22 3D         [24] 2963 	mov	dptr,#0x223d
      0068E0 E0               [24] 2964 	movx	a,@dptr
      0068E1 30 E5 60         [24] 2965 	jnb	acc.5,00124$
                                   2966 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      0068E4 90 22 0F         [24] 2967 	mov	dptr,#0x220f
      0068E7 E0               [24] 2968 	movx	a,@dptr
      0068E8 FF               [12] 2969 	mov	r7,a
                                   2970 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      0068E9 74 07            [12] 2971 	mov	a,#0x07
      0068EB 5F               [12] 2972 	anl	a,r7
      0068EC FE               [12] 2973 	mov	r6,a
                                   2974 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      0068ED EF               [12] 2975 	mov	a,r7
      0068EE 54 18            [12] 2976 	anl	a,#0x18
      0068F0 70 08            [24] 2977 	jnz	00115$
      0068F2 EE               [12] 2978 	mov	a,r6
      0068F3 70 05            [24] 2979 	jnz	00115$
                                   2980 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      0068F5 12 67 84         [24] 2981 	lcall	_control_out
      0068F8 80 43            [24] 2982 	sjmp	00116$
      0068FA                       2983 00115$:
                                   2984 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      0068FA 8F 05            [24] 2985 	mov	ar5,r7
      0068FC 74 18            [12] 2986 	mov	a,#0x18
      0068FE 5D               [12] 2987 	anl	a,r5
      0068FF FC               [12] 2988 	mov	r4,a
      006900 BC 10 2D         [24] 2989 	cjne	r4,#0x10,00112$
                                   2990 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      006903 EE               [12] 2991 	mov	a,r6
      006904 70 05            [24] 2992 	jnz	00106$
      006906 12 68 42         [24] 2993 	lcall	_control_in
      006909 80 32            [24] 2994 	sjmp	00116$
      00690B                       2995 00106$:
                                   2996 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      00690B EE               [12] 2997 	mov	a,r6
      00690C 24 FC            [12] 2998 	add	a,#0xff - 0x03
      00690E 40 2D            [24] 2999 	jc	00116$
                                   3000 ;	free result
                                   3001 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006910 8E 04            [24] 3002 	mov	ar4,r6
      006912 7B 00            [12] 3003 	mov	r3,#0x00
      006914 74 22            [12] 3004 	mov	a,#0x22
      006916 2B               [12] 3005 	add	a, r3
      006917 FB               [12] 3006 	mov	r3,a
      006918 8C 82            [24] 3007 	mov	dpl,r4
      00691A 8B 83            [24] 3008 	mov	dph,r3
      00691C E0               [24] 3009 	movx	a,@dptr
      00691D FA               [12] 3010 	mov	r2,a
      00691E 74 FC            [12] 3011 	mov	a,#0xfc
      006920 5A               [12] 3012 	anl	a,r2
      006921 44 02            [12] 3013 	orl	a,#0x02
      006923 8C 82            [24] 3014 	mov	dpl,r4
      006925 8B 83            [24] 3015 	mov	dph,r3
      006927 F0               [24] 3016 	movx	@dptr,a
                                   3017 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006928 BE 03 12         [24] 3018 	cjne	r6,#0x03,00116$
      00692B 12 5D 5A         [24] 3019 	lcall	_raw_complete
      00692E 80 0D            [24] 3020 	sjmp	00116$
      006930                       3021 00112$:
                                   3022 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006930 53 05 18         [24] 3023 	anl	ar5,#0x18
      006933 BD 18 07         [24] 3024 	cjne	r5,#0x18,00116$
      006936 EF               [12] 3025 	mov	a,r7
      006937 30 E5 03         [24] 3026 	jnb	acc.5,00116$
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      00693A 12 5F E7         [24] 3028 	lcall	_control_setup
      00693D                       3029 00116$:
                                   3030 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      00693D 90 22 0F         [24] 3031 	mov	dptr,#0x220f
      006940 E4               [12] 3032 	clr	a
      006941 F0               [24] 3033 	movx	@dptr,a
      006942 80 2C            [24] 3034 	sjmp	00130$
      006944                       3035 00124$:
                                   3036 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006944 90 22 3D         [24] 3037 	mov	dptr,#0x223d
      006947 E0               [24] 3038 	movx	a,@dptr
      006948 30 E2 25         [24] 3039 	jnb	acc.2,00130$
                                   3040 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      00694B 90 22 3D         [24] 3041 	mov	dptr,#0x223d
      00694E E0               [24] 3042 	movx	a,@dptr
      00694F 30 E3 0A         [24] 3043 	jnb	acc.3,00119$
      006952 90 07 BF         [24] 3044 	mov	dptr,#_USB_SleepStatus
      006955 E0               [24] 3045 	movx	a,@dptr
      006956 43 E0 02         [24] 3046 	orl	acc,#0x02
      006959 F0               [24] 3047 	movx	@dptr,a
      00695A 80 0E            [24] 3048 	sjmp	00120$
      00695C                       3049 00119$:
                                   3050 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      00695C 90 07 BF         [24] 3051 	mov	dptr,#_USB_SleepStatus
      00695F E0               [24] 3052 	movx	a,@dptr
      006960 53 E0 FD         [24] 3053 	anl	acc,#0xfd
      006963 F0               [24] 3054 	movx	@dptr,a
                                   3055 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006964 90 07 E7         [24] 3056 	mov	dptr,#_keyboard_reset
      006967 74 01            [12] 3057 	mov	a,#0x01
      006969 F0               [24] 3058 	movx	@dptr,a
      00696A                       3059 00120$:
                                   3060 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      00696A 90 22 3D         [24] 3061 	mov	dptr,#0x223d
      00696D 74 04            [12] 3062 	mov	a,#0x04
      00696F F0               [24] 3063 	movx	@dptr,a
      006970                       3064 00130$:
                                   3065 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006970 90 22 3D         [24] 3066 	mov	dptr,#0x223d
      006973 E0               [24] 3067 	movx	a,@dptr
      006974 54 25            [12] 3068 	anl	a,#0x25
      006976 60 03            [24] 3069 	jz	00242$
      006978 02 68 8B         [24] 3070 	ljmp	00129$
      00697B                       3071 00242$:
                                   3072 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      00697B 22               [24] 3073 	ret
                                   3074 ;------------------------------------------------------------
                                   3075 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3076 ;------------------------------------------------------------
                                   3077 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3078 ;	-----------------------------------------
                                   3079 ;	 function USB_Device_Init
                                   3080 ;	-----------------------------------------
      00697C                       3081 _USB_Device_Init:
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3083 ;	assignBit
      00697C C2 E9            [12] 3084 	clr	_IE_USB
                                   3085 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      00697E 90 22 3C         [24] 3086 	mov	dptr,#0x223c
      006981 E4               [12] 3087 	clr	a
      006982 F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      006983 90 07 C5         [24] 3090 	mov	dptr,#_raw_state
      006986 F0               [24] 3091 	movx	@dptr,a
                                   3092 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      006987 12 5D 77         [24] 3093 	lcall	_endpoints_reset
                                   3094 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      00698A 90 07 BF         [24] 3095 	mov	dptr,#_USB_SleepStatus
      00698D E4               [12] 3096 	clr	a
      00698E F0               [24] 3097 	movx	@dptr,a
      00698F 90 07 BE         [24] 3098 	mov	dptr,#_USB_EnumStatus
      006992 F0               [24] 3099 	movx	@dptr,a
      006993 90 07 BD         [24] 3100 	mov	dptr,#_D0UsbConfig
      006996 F0               [24] 3101 	movx	@dptr,a
      006997 90 22 07         [24] 3102 	mov	dptr,#0x2207
      00699A F0               [24] 3103 	movx	@dptr,a
                                   3104 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      00699B 90 07 C0         [24] 3105 	mov	dptr,#_MCU_Sleep_Operate
      00699E F0               [24] 3106 	movx	@dptr,a
      00699F 90 07 C1         [24] 3107 	mov	dptr,#_KB_USB_UpStatus
      0069A2 F0               [24] 3108 	movx	@dptr,a
      0069A3 90 07 C2         [24] 3109 	mov	dptr,#_KB_USB_SetReport
      0069A6 F0               [24] 3110 	movx	@dptr,a
                                   3111 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      0069A7 90 0D D8         [24] 3112 	mov	dptr,#_keyboard_protocol
      0069AA 04               [12] 3113 	inc	a
      0069AB F0               [24] 3114 	movx	@dptr,a
                                   3115 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      0069AC 90 06 95         [24] 3116 	mov	dptr,#_keyboard_idle
      0069AF E4               [12] 3117 	clr	a
      0069B0 F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      0069B1 90 07 E7         [24] 3120 	mov	dptr,#_keyboard_reset
      0069B4 F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      0069B5 90 08 16         [24] 3123 	mov	dptr,#_control_phase
      0069B8 F0               [24] 3124 	movx	@dptr,a
                                   3125 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      0069B9 90 07 B7         [24] 3126 	mov	dptr,#_D0SetupReqCode
      0069BC 14               [12] 3127 	dec	a
      0069BD F0               [24] 3128 	movx	@dptr,a
                                   3129 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      0069BE 90 07 B8         [24] 3130 	mov	dptr,#_D0SetupLen
      0069C1 E4               [12] 3131 	clr	a
      0069C2 F0               [24] 3132 	movx	@dptr,a
      0069C3 A3               [24] 3133 	inc	dptr
      0069C4 F0               [24] 3134 	movx	@dptr,a
                                   3135 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0069C5 90 22 00         [24] 3136 	mov	dptr,#0x2200
      0069C8 74 02            [12] 3137 	mov	a,#0x02
      0069CA F0               [24] 3138 	movx	@dptr,a
                                   3139 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      0069CB 90 22 37         [24] 3140 	mov	dptr,#0x2237
      0069CE 74 7F            [12] 3141 	mov	a,#0x7f
      0069D0 F0               [24] 3142 	movx	@dptr,a
                                   3143 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      0069D1 90 22 3D         [24] 3144 	mov	dptr,#0x223d
      0069D4 74 FF            [12] 3145 	mov	a,#0xff
      0069D6 F0               [24] 3146 	movx	@dptr,a
                                   3147 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      0069D7 90 22 3B         [24] 3148 	mov	dptr,#0x223b
      0069DA 74 07            [12] 3149 	mov	a,#0x07
      0069DC F0               [24] 3150 	movx	@dptr,a
                                   3151 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      0069DD A3               [24] 3152 	inc	dptr
      0069DE 74 80            [12] 3153 	mov	a,#0x80
      0069E0 F0               [24] 3154 	movx	@dptr,a
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3156 ;	assignBit
      0069E1 D2 E9            [12] 3157 	setb	_IE_USB
                                   3158 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      0069E3 22               [24] 3159 	ret
                                   3160 ;------------------------------------------------------------
                                   3161 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3162 ;------------------------------------------------------------
                                   3163 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_418'
                                   3164 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_421'
                                   3165 ;------------------------------------------------------------
                                   3166 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3167 ;	-----------------------------------------
                                   3168 ;	 function USB_WakeUp_PC
                                   3169 ;	-----------------------------------------
      0069E4                       3170 _USB_WakeUp_PC:
                                   3171 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      0069E4 90 07 BF         [24] 3172 	mov	dptr,#_USB_SleepStatus
      0069E7 E0               [24] 3173 	movx	a,@dptr
      0069E8 FF               [12] 3174 	mov	r7,a
      0069E9 BF 03 22         [24] 3175 	cjne	r7,#0x03,00110$
                                   3176 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      0069EC 90 22 3C         [24] 3177 	mov	dptr,#0x223c
      0069EF E0               [24] 3178 	movx	a,@dptr
      0069F0 FF               [12] 3179 	mov	r7,a
                                   3180 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      0069F1 E0               [24] 3181 	movx	a,@dptr
      0069F2 FE               [12] 3182 	mov	r6,a
      0069F3 63 06 C0         [24] 3183 	xrl	ar6,#0xc0
      0069F6 90 22 3C         [24] 3184 	mov	dptr,#0x223c
      0069F9 EE               [12] 3185 	mov	a,r6
      0069FA F0               [24] 3186 	movx	@dptr,a
                                   3187 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      0069FB 7E 0A            [12] 3188 	mov	r6,#0x0a
      0069FD                       3189 00108$:
      0069FD EE               [12] 3190 	mov	a,r6
      0069FE 60 09            [24] 3191 	jz	00105$
      006A00 90 00 01         [24] 3192 	mov	dptr,#0x0001
      006A03 12 5B BE         [24] 3193 	lcall	_mDelaymS
      006A06 1E               [12] 3194 	dec	r6
      006A07 80 F4            [24] 3195 	sjmp	00108$
      006A09                       3196 00105$:
                                   3197 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006A09 90 22 3C         [24] 3198 	mov	dptr,#0x223c
      006A0C EF               [12] 3199 	mov	a,r7
      006A0D F0               [24] 3200 	movx	@dptr,a
      006A0E                       3201 00110$:
                                   3202 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006A0E 22               [24] 3203 	ret
                                   3204 ;------------------------------------------------------------
                                   3205 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3206 ;------------------------------------------------------------
                                   3207 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3208 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3209 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3210 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3211 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_423'
                                   3212 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_424'
                                   3213 ;i             Allocated with name '_ak820_usb_send_i_10000_424'
                                   3214 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_424'
                                   3215 ;offset        Allocated with name '_ak820_usb_send_offset_10000_424'
                                   3216 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_424'
                                   3217 ;i             Allocated with name '_ak820_usb_send_i_30000_436'
                                   3218 ;------------------------------------------------------------
                                   3219 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3220 ;	-----------------------------------------
                                   3221 ;	 function ak820_usb_send
                                   3222 ;	-----------------------------------------
      006A0F                       3223 _ak820_usb_send:
      006A0F E5 82            [12] 3224 	mov	a,dpl
      006A11 90 08 26         [24] 3225 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006A14 F0               [24] 3226 	movx	@dptr,a
                                   3227 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      006A15 90 08 27         [24] 3228 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006A18 74 2E            [12] 3229 	mov	a,#0x2e
      006A1A F0               [24] 3230 	movx	@dptr,a
                                   3231 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006A1B 90 08 26         [24] 3232 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006A1E E0               [24] 3233 	movx	a,@dptr
      006A1F FF               [12] 3234 	mov	r7,a
      006A20 BF 01 00         [24] 3235 	cjne	r7,#0x01,00306$
      006A23                       3236 00306$:
      006A23 40 14            [24] 3237 	jc	00101$
      006A25 EF               [12] 3238 	mov	a,r7
      006A26 24 FC            [12] 3239 	add	a,#0xff - 0x03
      006A28 40 0F            [24] 3240 	jc	00101$
                                   3241 ;	free result
      006A2A 90 08 25         [24] 3242 	mov	dptr,#_ak820_usb_send_PARM_3
      006A2D E0               [24] 3243 	movx	a,@dptr
      006A2E FE               [12] 3244 	mov  r6,a
      006A2F 24 BF            [12] 3245 	add	a,#0xff - 0x40
      006A31 40 06            [24] 3246 	jc	00101$
                                   3247 ;	free result
      006A33 90 07 BE         [24] 3248 	mov	dptr,#_USB_EnumStatus
      006A36 E0               [24] 3249 	movx	a,@dptr
      006A37 70 04            [24] 3250 	jnz	00102$
      006A39                       3251 00101$:
      006A39 75 82 00         [24] 3252 	mov	dpl, #0x00
      006A3C 22               [24] 3253 	ret
      006A3D                       3254 00102$:
                                   3255 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006A3D BF 01 10         [24] 3256 	cjne	r7,#0x01,00118$
                                   3257 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006A40 BE 08 02         [24] 3258 	cjne	r6,#0x08,00313$
      006A43 80 04            [24] 3259 	sjmp	00107$
      006A45                       3260 00313$:
      006A45 75 82 00         [24] 3261 	mov	dpl, #0x00
      006A48 22               [24] 3262 	ret
      006A49                       3263 00107$:
                                   3264 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006A49 90 08 27         [24] 3265 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006A4C E4               [12] 3266 	clr	a
      006A4D F0               [24] 3267 	movx	@dptr,a
      006A4E 80 3C            [24] 3268 	sjmp	00119$
      006A50                       3269 00118$:
                                   3270 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006A50 BF 02 30         [24] 3271 	cjne	r7,#0x02,00115$
                                   3272 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006A53 90 08 23         [24] 3273 	mov	dptr,#_ak820_usb_send_PARM_2
      006A56 E0               [24] 3274 	movx	a,@dptr
      006A57 FD               [12] 3275 	mov	r5,a
      006A58 A3               [24] 3276 	inc	dptr
      006A59 E0               [24] 3277 	movx	a,@dptr
      006A5A FF               [12] 3278 	mov	r7,a
      006A5B 8D 82            [24] 3279 	mov	dpl,r5
      006A5D 8F 83            [24] 3280 	mov	dph,r7
      006A5F E0               [24] 3281 	movx	a,@dptr
      006A60 FF               [12] 3282 	mov	r7,a
                                   3283 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006A61 BF 07 00         [24] 3284 	cjne	r7,#0x07,00316$
      006A64                       3285 00316$:
      006A64 50 0E            [24] 3286 	jnc	00108$
      006A66 EF               [12] 3287 	mov	a,r7
      006A67 90 BB 5F         [24] 3288 	mov	dptr,#_shared_lengths
      006A6A 93               [24] 3289 	movc	a,@a+dptr
      006A6B FD               [12] 3290 	mov	r5,a
      006A6C 60 06            [24] 3291 	jz	00108$
      006A6E EE               [12] 3292 	mov	a,r6
      006A6F B5 05 02         [24] 3293 	cjne	a,ar5,00319$
      006A72 80 04            [24] 3294 	sjmp	00109$
      006A74                       3295 00319$:
      006A74                       3296 00108$:
      006A74 75 82 00         [24] 3297 	mov	dpl, #0x00
      006A77 22               [24] 3298 	ret
      006A78                       3299 00109$:
                                   3300 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006A78 EF               [12] 3301 	mov	a,r7
      006A79 90 BB 58         [24] 3302 	mov	dptr,#_shared_offsets
      006A7C 93               [24] 3303 	movc	a,@a+dptr
      006A7D 90 08 27         [24] 3304 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006A80 F0               [24] 3305 	movx	@dptr,a
      006A81 80 09            [24] 3306 	sjmp	00119$
      006A83                       3307 00115$:
                                   3308 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006A83 BE 20 02         [24] 3309 	cjne	r6,#0x20,00320$
      006A86 80 04            [24] 3310 	sjmp	00119$
      006A88                       3311 00320$:
      006A88 75 82 00         [24] 3312 	mov	dpl, #0x00
      006A8B 22               [24] 3313 	ret
      006A8C                       3314 00119$:
                                   3315 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006A8C 90 07 BF         [24] 3316 	mov	dptr,#_USB_SleepStatus
      006A8F E0               [24] 3317 	movx	a,@dptr
      006A90 30 E1 07         [24] 3318 	jnb	acc.1,00184$
      006A93 12 69 E4         [24] 3319 	lcall	_USB_WakeUp_PC
      006A96 75 82 00         [24] 3320 	mov	dpl, #0x00
      006A99 22               [24] 3321 	ret
                                   3322 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006A9A                       3323 00184$:
      006A9A 7F FA            [12] 3324 	mov	r7,#0xfa
      006A9C                       3325 00127$:
      006A9C 90 08 26         [24] 3326 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006A9F E0               [24] 3327 	movx	a,@dptr
      006AA0 FC               [12] 3328 	mov	r4,a
      006AA1 7D 00            [12] 3329 	mov	r5,#0x00
      006AA3 8C 02            [24] 3330 	mov	ar2,r4
      006AA5 74 22            [12] 3331 	mov	a,#0x22
      006AA7 2D               [12] 3332 	add	a, r5
      006AA8 FB               [12] 3333 	mov	r3,a
      006AA9 8A 82            [24] 3334 	mov	dpl,r2
      006AAB 8B 83            [24] 3335 	mov	dph,r3
      006AAD E0               [24] 3336 	movx	a,@dptr
      006AAE 54 03            [12] 3337 	anl	a,#0x03
      006AB0 70 14            [24] 3338 	jnz	00129$
      006AB2 8F 03            [24] 3339 	mov	ar3,r7
      006AB4 1F               [12] 3340 	dec	r7
      006AB5 EB               [12] 3341 	mov	a,r3
      006AB6 60 0E            [24] 3342 	jz	00129$
      006AB8 7B 28            [12] 3343 	mov	r3,#0x28
      006ABA                       3344 00141$:
      006ABA EB               [12] 3345 	mov	a,r3
      006ABB 60 DF            [24] 3346 	jz	00127$
      006ABD 90 00 01         [24] 3347 	mov	dptr,#0x0001
      006AC0 12 5B 7A         [24] 3348 	lcall	_mDelayuS
      006AC3 1B               [12] 3349 	dec	r3
      006AC4 80 F4            [24] 3350 	sjmp	00141$
      006AC6                       3351 00129$:
                                   3352 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      006AC6 A2 AF            [12] 3353 	mov	c,_EA
      006AC8 E4               [12] 3354 	clr	a
      006AC9 33               [12] 3355 	rlc	a
      006ACA FF               [12] 3356 	mov	r7,a
                                   3357 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3358 ;	assignBit
      006ACB C2 AF            [12] 3359 	clr	_EA
                                   3360 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006ACD 90 07 BE         [24] 3361 	mov	dptr,#_USB_EnumStatus
      006AD0 E0               [24] 3362 	movx	a,@dptr
      006AD1 60 25            [24] 3363 	jz	00130$
      006AD3 90 08 26         [24] 3364 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006AD6 E0               [24] 3365 	movx	a,@dptr
      006AD7 FB               [12] 3366 	mov	r3,a
      006AD8 F9               [12] 3367 	mov	r1,a
      006AD9 7A 00            [12] 3368 	mov	r2,#0x00
      006ADB 74 22            [12] 3369 	mov	a,#0x22
      006ADD 2A               [12] 3370 	add	a, r2
      006ADE FA               [12] 3371 	mov	r2,a
      006ADF 89 82            [24] 3372 	mov	dpl,r1
      006AE1 8A 83            [24] 3373 	mov	dph,r2
      006AE3 E0               [24] 3374 	movx	a,@dptr
      006AE4 FA               [12] 3375 	mov	r2,a
      006AE5 53 02 03         [24] 3376 	anl	ar2,#0x03
      006AE8 BA 02 0D         [24] 3377 	cjne	r2,#0x02,00130$
                                   3378 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006AEB BB 03 13         [24] 3379 	cjne	r3,#0x03,00192$
      006AEE 90 07 C5         [24] 3380 	mov	dptr,#_raw_state
      006AF1 E0               [24] 3381 	movx	a,@dptr
      006AF2 FB               [12] 3382 	mov	r3,a
      006AF3 BB 03 02         [24] 3383 	cjne	r3,#0x03,00331$
      006AF6 80 09            [24] 3384 	sjmp	00192$
      006AF8                       3385 00331$:
      006AF8                       3386 00130$:
                                   3387 ;	assignBit
      006AF8 EF               [12] 3388 	mov	a,r7
      006AF9 24 FF            [12] 3389 	add	a,#0xff
      006AFB 92 AF            [24] 3390 	mov	_EA,c
      006AFD 75 82 00         [24] 3391 	mov	dpl, #0x00
      006B00 22               [24] 3392 	ret
                                   3393 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006B01                       3394 00192$:
      006B01 7B 00            [12] 3395 	mov	r3,#0x00
      006B03                       3396 00144$:
      006B03 C3               [12] 3397 	clr	c
      006B04 EB               [12] 3398 	mov	a,r3
      006B05 9E               [12] 3399 	subb	a,r6
      006B06 50 67            [24] 3400 	jnc	00137$
                                   3401 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006B08 C0 07            [24] 3402 	push	ar7
      006B0A 90 08 26         [24] 3403 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006B0D E0               [24] 3404 	movx	a,@dptr
      006B0E F9               [12] 3405 	mov	r1,a
      006B0F E4               [12] 3406 	clr	a
      006B10 C3               [12] 3407 	clr	c
      006B11 C9               [12] 3408 	xch	a,r1
      006B12 13               [12] 3409 	rrc	a
      006B13 C9               [12] 3410 	xch	a,r1
      006B14 13               [12] 3411 	rrc	a
      006B15 A2 E0            [12] 3412 	mov	c,acc.0
      006B17 C9               [12] 3413 	xch	a,r1
      006B18 13               [12] 3414 	rrc	a
      006B19 C9               [12] 3415 	xch	a,r1
      006B1A 13               [12] 3416 	rrc	a
      006B1B C9               [12] 3417 	xch	a,r1
      006B1C FA               [12] 3418 	mov	r2,a
      006B1D 8B 00            [24] 3419 	mov	ar0,r3
      006B1F 7F 00            [12] 3420 	mov	r7,#0x00
      006B21 E8               [12] 3421 	mov	a,r0
      006B22 29               [12] 3422 	add	a, r1
      006B23 F9               [12] 3423 	mov	r1,a
      006B24 EF               [12] 3424 	mov	a,r7
      006B25 3A               [12] 3425 	addc	a, r2
      006B26 24 10            [12] 3426 	add	a,#0x10
      006B28 FA               [12] 3427 	mov	r2,a
      006B29 90 08 23         [24] 3428 	mov	dptr,#_ak820_usb_send_PARM_2
      006B2C E0               [24] 3429 	movx	a,@dptr
      006B2D F8               [12] 3430 	mov	r0,a
      006B2E A3               [24] 3431 	inc	dptr
      006B2F E0               [24] 3432 	movx	a,@dptr
      006B30 FF               [12] 3433 	mov	r7,a
      006B31 EB               [12] 3434 	mov	a,r3
      006B32 28               [12] 3435 	add	a, r0
      006B33 F5 1B            [12] 3436 	mov	_ak820_usb_send_sloc0_1_0,a
      006B35 E4               [12] 3437 	clr	a
      006B36 3F               [12] 3438 	addc	a, r7
      006B37 F5 1C            [12] 3439 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006B39 85 1B 82         [24] 3440 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006B3C 85 1C 83         [24] 3441 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006B3F E0               [24] 3442 	movx	a,@dptr
      006B40 89 82            [24] 3443 	mov	dpl,r1
      006B42 8A 83            [24] 3444 	mov	dph,r2
      006B44 F0               [24] 3445 	movx	@dptr,a
                                   3446 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006B45 90 08 27         [24] 3447 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006B48 E0               [24] 3448 	movx	a,@dptr
      006B49 F5 1D            [12] 3449 	mov	_ak820_usb_send_sloc1_1_0,a
      006B4B 74 2E            [12] 3450 	mov	a,#0x2e
      006B4D B5 1D 04         [24] 3451 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006B50 D0 07            [24] 3452 	pop	ar7
      006B52 80 18            [24] 3453 	sjmp	00145$
      006B54                       3454 00333$:
      006B54 D0 07            [24] 3455 	pop	ar7
      006B56 EB               [12] 3456 	mov	a,r3
      006B57 25 1D            [12] 3457 	add	a, _ak820_usb_send_sloc1_1_0
      006B59 24 E8            [12] 3458 	add	a, #_input_snapshot
      006B5B F9               [12] 3459 	mov	r1,a
      006B5C E4               [12] 3460 	clr	a
      006B5D 34 07            [12] 3461 	addc	a,#(_input_snapshot >> 8)
      006B5F FA               [12] 3462 	mov	r2,a
      006B60 85 1B 82         [24] 3463 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006B63 85 1C 83         [24] 3464 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006B66 E0               [24] 3465 	movx	a,@dptr
      006B67 89 82            [24] 3466 	mov	dpl,r1
      006B69 8A 83            [24] 3467 	mov	dph,r2
      006B6B F0               [24] 3468 	movx	@dptr,a
      006B6C                       3469 00145$:
                                   3470 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006B6C 0B               [12] 3471 	inc	r3
      006B6D 80 94            [24] 3472 	sjmp	00144$
      006B6F                       3473 00137$:
                                   3474 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006B6F 90 08 26         [24] 3475 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006B72 E0               [24] 3476 	movx	a,@dptr
      006B73 FB               [12] 3477 	mov	r3,a
      006B74 F9               [12] 3478 	mov	r1,a
      006B75 7A 00            [12] 3479 	mov	r2,#0x00
      006B77 74 08            [12] 3480 	mov	a,#0x08
      006B79 29               [12] 3481 	add	a, r1
      006B7A F9               [12] 3482 	mov	r1,a
      006B7B 74 22            [12] 3483 	mov	a,#0x22
      006B7D 3A               [12] 3484 	addc	a, r2
      006B7E FA               [12] 3485 	mov	r2,a
      006B7F 89 82            [24] 3486 	mov	dpl,r1
      006B81 8A 83            [24] 3487 	mov	dph,r2
      006B83 EE               [12] 3488 	mov	a,r6
      006B84 F0               [24] 3489 	movx	@dptr,a
                                   3490 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006B85 BB 03 06         [24] 3491 	cjne	r3,#0x03,00139$
      006B88 90 07 C5         [24] 3492 	mov	dptr,#_raw_state
      006B8B 74 04            [12] 3493 	mov	a,#0x04
      006B8D F0               [24] 3494 	movx	@dptr,a
      006B8E                       3495 00139$:
                                   3496 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006B8E 74 22            [12] 3497 	mov	a,#0x22
      006B90 2D               [12] 3498 	add	a, r5
      006B91 FD               [12] 3499 	mov	r5,a
      006B92 8C 82            [24] 3500 	mov	dpl,r4
      006B94 8D 83            [24] 3501 	mov	dph,r5
      006B96 E0               [24] 3502 	movx	a,@dptr
      006B97 FE               [12] 3503 	mov	r6,a
      006B98 53 06 FC         [24] 3504 	anl	ar6,#0xfc
      006B9B 8C 82            [24] 3505 	mov	dpl,r4
      006B9D 8D 83            [24] 3506 	mov	dph,r5
      006B9F EE               [12] 3507 	mov	a,r6
      006BA0 F0               [24] 3508 	movx	@dptr,a
                                   3509 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3510 ;	assignBit
      006BA1 EF               [12] 3511 	mov	a,r7
      006BA2 24 FF            [12] 3512 	add	a,#0xff
      006BA4 92 AF            [24] 3513 	mov	_EA,c
                                   3514 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006BA6 75 82 01         [24] 3515 	mov	dpl, #0x01
                                   3516 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006BA9 22               [24] 3517 	ret
                                   3518 ;------------------------------------------------------------
                                   3519 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3520 ;------------------------------------------------------------
                                   3521 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3522 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3523 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_444'
                                   3524 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_445'
                                   3525 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_445'
                                   3526 ;------------------------------------------------------------
                                   3527 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3528 ;	-----------------------------------------
                                   3529 ;	 function ak820_usb_try_send
                                   3530 ;	-----------------------------------------
      006BAA                       3531 _ak820_usb_try_send:
      006BAA E5 82            [12] 3532 	mov	a,dpl
      006BAC 90 08 2B         [24] 3533 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006BAF F0               [24] 3534 	movx	@dptr,a
                                   3535 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3536 ;	assignBit
      006BB0 A2 AF            [12] 3537 	mov	c,_EA
      006BB2 92 1B            [24] 3538 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3539 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006BB4 90 08 2C         [24] 3540 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006BB7 E4               [12] 3541 	clr	a
      006BB8 F0               [24] 3542 	movx	@dptr,a
                                   3543 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3544 ;	assignBit
      006BB9 C2 AF            [12] 3545 	clr	_EA
                                   3546 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006BBB 90 08 2B         [24] 3547 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006BBE E0               [24] 3548 	movx	a,@dptr
      006BBF FF               [12] 3549 	mov	r7,a
      006BC0 BF 01 00         [24] 3550 	cjne	r7,#0x01,00152$
      006BC3                       3551 00152$:
      006BC3 40 4E            [24] 3552 	jc	00102$
      006BC5 EF               [12] 3553 	mov	a,r7
      006BC6 24 FD            [12] 3554 	add	a,#0xff - 0x02
      006BC8 40 49            [24] 3555 	jc	00102$
                                   3556 ;	free result
      006BCA 90 07 BE         [24] 3557 	mov	dptr,#_USB_EnumStatus
      006BCD E0               [24] 3558 	movx	a,@dptr
      006BCE 60 43            [24] 3559 	jz	00102$
                                   3560 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006BD0 90 07 BF         [24] 3561 	mov	dptr,#_USB_SleepStatus
      006BD3 E0               [24] 3562 	movx	a,@dptr
      006BD4 20 E1 3C         [24] 3563 	jb	acc.1,00102$
      006BD7 90 07 E7         [24] 3564 	mov	dptr,#_keyboard_reset
      006BDA E0               [24] 3565 	movx	a,@dptr
                                   3566 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006BDB 70 36            [24] 3567 	jnz	00102$
      006BDD 8F 06            [24] 3568 	mov	ar6,r7
      006BDF 24 22            [12] 3569 	add	a,#0x22
      006BE1 FD               [12] 3570 	mov	r5,a
      006BE2 8E 82            [24] 3571 	mov	dpl,r6
      006BE4 8D 83            [24] 3572 	mov	dph,r5
      006BE6 E0               [24] 3573 	movx	a,@dptr
      006BE7 FE               [12] 3574 	mov	r6,a
      006BE8 53 06 03         [24] 3575 	anl	ar6,#0x03
      006BEB BE 02 25         [24] 3576 	cjne	r6,#0x02,00102$
                                   3577 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006BEE 90 08 28         [24] 3578 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006BF1 E0               [24] 3579 	movx	a,@dptr
      006BF2 FD               [12] 3580 	mov	r5,a
      006BF3 A3               [24] 3581 	inc	dptr
      006BF4 E0               [24] 3582 	movx	a,@dptr
      006BF5 FE               [12] 3583 	mov	r6,a
      006BF6 90 08 2A         [24] 3584 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006BF9 E0               [24] 3585 	movx	a,@dptr
      006BFA FC               [12] 3586 	mov	r4,a
      006BFB 90 08 23         [24] 3587 	mov	dptr,#_ak820_usb_send_PARM_2
      006BFE ED               [12] 3588 	mov	a,r5
      006BFF F0               [24] 3589 	movx	@dptr,a
      006C00 EE               [12] 3590 	mov	a,r6
      006C01 A3               [24] 3591 	inc	dptr
      006C02 F0               [24] 3592 	movx	@dptr,a
      006C03 90 08 25         [24] 3593 	mov	dptr,#_ak820_usb_send_PARM_3
      006C06 EC               [12] 3594 	mov	a,r4
      006C07 F0               [24] 3595 	movx	@dptr,a
      006C08 8F 82            [24] 3596 	mov	dpl, r7
      006C0A 12 6A 0F         [24] 3597 	lcall	_ak820_usb_send
      006C0D E5 82            [12] 3598 	mov	a, dpl
      006C0F 90 08 2C         [24] 3599 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006C12 F0               [24] 3600 	movx	@dptr,a
      006C13                       3601 00102$:
                                   3602 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3603 ;	assignBit
      006C13 A2 1B            [12] 3604 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006C15 92 AF            [24] 3605 	mov	_EA,c
                                   3606 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006C17 90 08 2C         [24] 3607 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006C1A E0               [24] 3608 	movx	a,@dptr
                                   3609 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006C1B F5 82            [12] 3610 	mov	dpl,a
      006C1D 22               [24] 3611 	ret
                                   3612 ;------------------------------------------------------------
                                   3613 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3614 ;------------------------------------------------------------
                                   3615 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3616 ;	-----------------------------------------
                                   3617 ;	 function raw_request_is_nonpersistent
                                   3618 ;	-----------------------------------------
      006C1E                       3619 _raw_request_is_nonpersistent:
                                   3620 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006C1E 90 07 C6         [24] 3621 	mov	dptr,#_raw_buffer
      006C21 E0               [24] 3622 	movx	a,@dptr
      006C22 FF               [12] 3623 	mov	r7,a
      006C23 BF 01 02         [24] 3624 	cjne	r7,#0x01,00302$
      006C26 80 35            [24] 3625 	sjmp	00108$
      006C28                       3626 00302$:
      006C28 BF 02 02         [24] 3627 	cjne	r7,#0x02,00303$
      006C2B 80 34            [24] 3628 	sjmp	00109$
      006C2D                       3629 00303$:
      006C2D BF 04 02         [24] 3630 	cjne	r7,#0x04,00304$
      006C30 80 2B            [24] 3631 	sjmp	00108$
      006C32                       3632 00304$:
      006C32 BF 08 02         [24] 3633 	cjne	r7,#0x08,00305$
      006C35 80 47            [24] 3634 	sjmp	00116$
      006C37                       3635 00305$:
      006C37 BF 0B 02         [24] 3636 	cjne	r7,#0x0b,00306$
      006C3A 80 21            [24] 3637 	sjmp	00108$
      006C3C                       3638 00306$:
      006C3C BF 0C 02         [24] 3639 	cjne	r7,#0x0c,00307$
      006C3F 80 1C            [24] 3640 	sjmp	00108$
      006C41                       3641 00307$:
      006C41 BF 0D 02         [24] 3642 	cjne	r7,#0x0d,00308$
      006C44 80 17            [24] 3643 	sjmp	00108$
      006C46                       3644 00308$:
      006C46 BF 0E 02         [24] 3645 	cjne	r7,#0x0e,00309$
      006C49 80 12            [24] 3646 	sjmp	00108$
      006C4B                       3647 00309$:
      006C4B BF 11 02         [24] 3648 	cjne	r7,#0x11,00310$
      006C4E 80 0D            [24] 3649 	sjmp	00108$
      006C50                       3650 00310$:
      006C50 BF 12 02         [24] 3651 	cjne	r7,#0x12,00311$
      006C53 80 08            [24] 3652 	sjmp	00108$
      006C55                       3653 00311$:
      006C55 BF FE 02         [24] 3654 	cjne	r7,#0xfe,00312$
      006C58 80 46            [24] 3655 	sjmp	00124$
      006C5A                       3656 00312$:
      006C5A 02 6C F5         [24] 3657 	ljmp	00144$
                                   3658 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006C5D                       3659 00108$:
                                   3660 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006C5D 75 82 01         [24] 3661 	mov	dpl, #0x01
      006C60 22               [24] 3662 	ret
                                   3663 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006C61                       3664 00109$:
                                   3665 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006C61 12 6F 49         [24] 3666 	lcall	_ak820_outline_0159
      006C64 BF 01 02         [24] 3667 	cjne	r7,#0x01,00313$
      006C67 80 0D            [24] 3668 	sjmp	00113$
      006C69                       3669 00313$:
      006C69 BF 02 02         [24] 3670 	cjne	r7,#0x02,00314$
      006C6C 80 08            [24] 3671 	sjmp	00113$
      006C6E                       3672 00314$:
      006C6E BF 03 02         [24] 3673 	cjne	r7,#0x03,00315$
      006C71 80 03            [24] 3674 	sjmp	00113$
      006C73                       3675 00315$:
      006C73 BF 04 04         [24] 3676 	cjne	r7,#0x04,00114$
                                   3677 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006C76                       3678 00113$:
                                   3679 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006C76 75 82 01         [24] 3680 	mov	dpl, #0x01
      006C79 22               [24] 3681 	ret
                                   3682 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006C7A                       3683 00114$:
      006C7A 75 82 00         [24] 3684 	mov	dpl, #0x00
      006C7D 22               [24] 3685 	ret
                                   3686 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006C7E                       3687 00116$:
                                   3688 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006C7E 12 6F 49         [24] 3689 	lcall	_ak820_outline_0159
      006C81 BF 40 02         [24] 3690 	cjne	r7,#0x40,00318$
      006C84 80 12            [24] 3691 	sjmp	00121$
      006C86                       3692 00318$:
      006C86 BF 41 02         [24] 3693 	cjne	r7,#0x41,00319$
      006C89 80 0D            [24] 3694 	sjmp	00121$
      006C8B                       3695 00319$:
      006C8B BF 42 02         [24] 3696 	cjne	r7,#0x42,00320$
      006C8E 80 08            [24] 3697 	sjmp	00121$
      006C90                       3698 00320$:
      006C90 BF 43 02         [24] 3699 	cjne	r7,#0x43,00321$
      006C93 80 03            [24] 3700 	sjmp	00121$
      006C95                       3701 00321$:
      006C95 BF 44 04         [24] 3702 	cjne	r7,#0x44,00122$
                                   3703 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006C98                       3704 00121$:
                                   3705 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006C98 75 82 01         [24] 3706 	mov	dpl, #0x01
                                   3707 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006C9B 22               [24] 3708 	ret
      006C9C                       3709 00122$:
      006C9C 75 82 00         [24] 3710 	mov	dpl, #0x00
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006C9F 22               [24] 3712 	ret
      006CA0                       3713 00124$:
                                   3714 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006CA0 12 6F 49         [24] 3715 	lcall	_ak820_outline_0159
      006CA3 24 F2            [12] 3716 	add	a,#0xff - 0x0d
      006CA5 40 4A            [24] 3717 	jc	00142$
                                   3718 ;	free result
      006CA7 EF               [12] 3719 	mov	a,r7
      006CA8 24 0A            [12] 3720 	add	a,#(00325$-3-.)
      006CAA 83               [24] 3721 	movc	a,@a+pc
      006CAB F5 82            [12] 3722 	mov	dpl,a
      006CAD EF               [12] 3723 	mov	a,r7
      006CAE 24 12            [12] 3724 	add	a,#(00326$-3-.)
      006CB0 83               [24] 3725 	movc	a,@a+pc
      006CB1 F5 83            [12] 3726 	mov	dph,a
      006CB3 E4               [12] 3727 	clr	a
      006CB4 73               [24] 3728 	jmp	@a+dptr
      006CB5                       3729 00325$:
      006CB5 D1                    3730 	.db	00134$
      006CB6 D1                    3731 	.db	00134$
      006CB7 D1                    3732 	.db	00134$
      006CB8 D1                    3733 	.db	00134$
      006CB9 F1                    3734 	.db	00142$
      006CBA D1                    3735 	.db	00134$
      006CBB D1                    3736 	.db	00134$
      006CBC D1                    3737 	.db	00134$
      006CBD D1                    3738 	.db	00134$
      006CBE D1                    3739 	.db	00134$
      006CBF D1                    3740 	.db	00134$
      006CC0 F1                    3741 	.db	00142$
      006CC1 F1                    3742 	.db	00142$
      006CC2 D5                    3743 	.db	00135$
      006CC3                       3744 00326$:
      006CC3 6C                    3745 	.db	00134$>>8
      006CC4 6C                    3746 	.db	00134$>>8
      006CC5 6C                    3747 	.db	00134$>>8
      006CC6 6C                    3748 	.db	00134$>>8
      006CC7 6C                    3749 	.db	00142$>>8
      006CC8 6C                    3750 	.db	00134$>>8
      006CC9 6C                    3751 	.db	00134$>>8
      006CCA 6C                    3752 	.db	00134$>>8
      006CCB 6C                    3753 	.db	00134$>>8
      006CCC 6C                    3754 	.db	00134$>>8
      006CCD 6C                    3755 	.db	00134$>>8
      006CCE 6C                    3756 	.db	00142$>>8
      006CCF 6C                    3757 	.db	00142$>>8
      006CD0 6C                    3758 	.db	00135$>>8
                                   3759 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006CD1                       3760 00134$:
                                   3761 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006CD1 75 82 01         [24] 3762 	mov	dpl, #0x01
                                   3763 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006CD4 22               [24] 3764 	ret
      006CD5                       3765 00135$:
                                   3766 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006CD5 90 07 C8         [24] 3767 	mov	dptr,#(_raw_buffer + 0x0002)
      006CD8 E0               [24] 3768 	movx	a,@dptr
      006CD9 FF               [12] 3769 	mov	r7,a
      006CDA 60 0D            [24] 3770 	jz	00139$
      006CDC BF 01 02         [24] 3771 	cjne	r7,#0x01,00328$
      006CDF 80 08            [24] 3772 	sjmp	00139$
      006CE1                       3773 00328$:
      006CE1 BF 03 02         [24] 3774 	cjne	r7,#0x03,00329$
      006CE4 80 03            [24] 3775 	sjmp	00139$
      006CE6                       3776 00329$:
      006CE6 BF 05 04         [24] 3777 	cjne	r7,#0x05,00140$
                                   3778 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006CE9                       3779 00139$:
                                   3780 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006CE9 75 82 01         [24] 3781 	mov	dpl, #0x01
                                   3782 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006CEC 22               [24] 3783 	ret
      006CED                       3784 00140$:
      006CED 75 82 00         [24] 3785 	mov	dpl, #0x00
                                   3786 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006CF0 22               [24] 3787 	ret
      006CF1                       3788 00142$:
      006CF1 75 82 00         [24] 3789 	mov	dpl, #0x00
                                   3790 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006CF4 22               [24] 3791 	ret
      006CF5                       3792 00144$:
      006CF5 75 82 00         [24] 3793 	mov	dpl, #0x00
                                   3794 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3795 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      006CF8 22               [24] 3796 	ret
                                   3797 ;------------------------------------------------------------
                                   3798 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3799 ;------------------------------------------------------------
                                   3800 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3801 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_460'
                                   3802 ;------------------------------------------------------------
                                   3803 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3804 ;	-----------------------------------------
                                   3805 ;	 function ak820_usb_raw_send
                                   3806 ;	-----------------------------------------
      006CF9                       3807 _ak820_usb_raw_send:
      006CF9 12 46 19         [24] 3808 	lcall	_ak820_outline_0036
      006CFC 90 08 2E         [24] 3809 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006CFF 12 37 DF         [24] 3810 	lcall	_ak820_outline_0015
                                   3811 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      006D02 90 08 2D         [24] 3812 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006D05 E0               [24] 3813 	movx	a,@dptr
      006D06 FF               [12] 3814 	mov	r7,a
      006D07 BF 20 2B         [24] 3815 	cjne	r7,#0x20,00106$
                                   3816 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      006D0A C0 07            [24] 3817 	push	ar7
      006D0C 12 41 2F         [24] 3818 	lcall	_ak820_nvm_flush
      006D0F D0 07            [24] 3819 	pop	ar7
                                   3820 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006D11 90 07 E6         [24] 3821 	mov	dptr,#_raw_reply_without_nvm
      006D14 E0               [24] 3822 	movx	a,@dptr
      006D15 70 07            [24] 3823 	jnz	00103$
      006D17 12 41 20         [24] 3824 	lcall	_ak820_nvm_ok
      006D1A E5 82            [12] 3825 	mov	a, dpl
      006D1C 60 17            [24] 3826 	jz	00106$
      006D1E                       3827 00103$:
      006D1E 90 08 2E         [24] 3828 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006D21 12 46 50         [24] 3829 	lcall	_ak820_outline_0094
      006D24 90 08 23         [24] 3830 	mov	dptr,#_ak820_usb_send_PARM_2
      006D27 12 46 93         [24] 3831 	lcall	_ak820_outline_0157
      006D2A 90 08 25         [24] 3832 	mov	dptr,#_ak820_usb_send_PARM_3
      006D2D EF               [12] 3833 	mov	a,r7
      006D2E F0               [24] 3834 	movx	@dptr,a
      006D2F 75 82 03         [24] 3835 	mov	dpl, #0x03
                                   3836 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      006D32 02 6A 0F         [24] 3837 	ljmp	_ak820_usb_send
      006D35                       3838 00106$:
      006D35 22               [24] 3839 	ret
                                   3840 ;------------------------------------------------------------
                                   3841 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3842 ;------------------------------------------------------------
                                   3843 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3844 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_465'
                                   3845 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_465'
                                   3846 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_465'
                                   3847 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_465'
                                   3848 ;------------------------------------------------------------
                                   3849 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3850 ;	-----------------------------------------
                                   3851 ;	 function ak820_usb_raw_task
                                   3852 ;	-----------------------------------------
      006D36                       3853 _ak820_usb_raw_task:
                                   3854 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      006D36 A2 AF            [12] 3855 	mov	c,_EA
      006D38 E4               [12] 3856 	clr	a
      006D39 33               [12] 3857 	rlc	a
      006D3A FF               [12] 3858 	mov	r7,a
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3860 ;	assignBit
      006D3B C2 AF            [12] 3861 	clr	_EA
                                   3862 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006D3D 90 07 BE         [24] 3863 	mov	dptr,#_USB_EnumStatus
      006D40 E0               [24] 3864 	movx	a,@dptr
      006D41 60 0A            [24] 3865 	jz	00101$
      006D43 90 07 C5         [24] 3866 	mov	dptr,#_raw_state
      006D46 E0               [24] 3867 	movx	a,@dptr
      006D47 FE               [12] 3868 	mov	r6,a
      006D48 BE 02 02         [24] 3869 	cjne	r6,#0x02,00270$
      006D4B 80 06            [24] 3870 	sjmp	00102$
      006D4D                       3871 00270$:
      006D4D                       3872 00101$:
                                   3873 ;	assignBit
      006D4D EF               [12] 3874 	mov	a,r7
      006D4E 24 FF            [12] 3875 	add	a,#0xff
      006D50 92 AF            [24] 3876 	mov	_EA,c
      006D52 22               [24] 3877 	ret
      006D53                       3878 00102$:
                                   3879 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      006D53 90 07 C5         [24] 3880 	mov	dptr,#_raw_state
      006D56 74 03            [12] 3881 	mov	a,#0x03
      006D58 F0               [24] 3882 	movx	@dptr,a
                                   3883 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3884 ;	assignBit
      006D59 EF               [12] 3885 	mov	a,r7
      006D5A 24 FF            [12] 3886 	add	a,#0xff
      006D5C 92 AF            [24] 3887 	mov	_EA,c
                                   3888 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006D5E 90 07 C6         [24] 3889 	mov	dptr,#_raw_buffer
      006D61 E0               [24] 3890 	movx	a,@dptr
      006D62 FF               [12] 3891 	mov	r7,a
      006D63 E4               [12] 3892 	clr	a
      006D64 BF FD 01         [24] 3893 	cjne	r7,#0xfd,00271$
      006D67 04               [12] 3894 	inc	a
      006D68                       3895 00271$:
      006D68 FF               [12] 3896 	mov	r7,a
      006D69 70 03            [24] 3897 	jnz	00273$
      006D6B 02 6E 0B         [24] 3898 	ljmp	00118$
      006D6E                       3899 00273$:
      006D6E 90 07 C7         [24] 3900 	mov	dptr,#(_raw_buffer + 0x0001)
      006D71 E0               [24] 3901 	movx	a,@dptr
      006D72 60 03            [24] 3902 	jz	00274$
      006D74 02 6E 0B         [24] 3903 	ljmp	00118$
      006D77                       3904 00274$:
                                   3905 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006D77 90 07 C8         [24] 3906 	mov	dptr,#(_raw_buffer + 0x0002)
      006D7A E0               [24] 3907 	movx	a,@dptr
      006D7B FD               [12] 3908 	mov	r5,a
      006D7C 7E 00            [12] 3909 	mov	r6,#0x00
      006D7E 90 07 C9         [24] 3910 	mov	dptr,#(_raw_buffer + 0x0003)
      006D81 E0               [24] 3911 	movx	a,@dptr
      006D82 7B 00            [12] 3912 	mov	r3,#0x00
      006D84 42 06            [12] 3913 	orl	ar6,a
      006D86 EB               [12] 3914 	mov	a,r3
      006D87 42 05            [12] 3915 	orl	ar5,a
                                   3916 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      006D89 90 07 CA         [24] 3917 	mov	dptr,#(_raw_buffer + 0x0004)
      006D8C E0               [24] 3918 	movx	a,@dptr
      006D8D FC               [12] 3919 	mov	r4,a
                                   3920 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006D8E 7B 05            [12] 3921 	mov	r3,#0x05
      006D90                       3922 00128$:
      006D90 EB               [12] 3923 	mov	a,r3
      006D91 12 6F 37         [24] 3924 	lcall	_ak820_outline_0101
      006D94 0B               [12] 3925 	inc	r3
      006D95 BB 20 00         [24] 3926 	cjne	r3,#0x20,00275$
      006D98                       3927 00275$:
      006D98 40 F6            [24] 3928 	jc	00128$
                                   3929 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006D9A EC               [12] 3930 	mov	a,r4
      006D9B 24 E4            [12] 3931 	add	a,#0xff - 0x1b
      006D9D 40 1C            [24] 3932 	jc	00106$
                                   3933 ;	free result
      006D9F EC               [12] 3934 	mov	a,r4
      006DA0 60 26            [24] 3935 	jz	00165$
      006DA2 8C 03            [24] 3936 	mov	ar3,r4
      006DA4 1B               [12] 3937 	dec	r3
      006DA5 7A 00            [12] 3938 	mov	r2,#0x00
      006DA7 74 FF            [12] 3939 	mov	a,#0xff
      006DA9 C3               [12] 3940 	clr	c
      006DAA 9B               [12] 3941 	subb	a,r3
      006DAB FB               [12] 3942 	mov	r3,a
      006DAC 74 FF            [12] 3943 	mov	a,#0xff
      006DAE 9A               [12] 3944 	subb	a,r2
      006DAF FA               [12] 3945 	mov	r2,a
      006DB0 8E 00            [24] 3946 	mov	ar0,r6
      006DB2 8D 01            [24] 3947 	mov	ar1,r5
      006DB4 C3               [12] 3948 	clr	c
      006DB5 EB               [12] 3949 	mov	a,r3
      006DB6 98               [12] 3950 	subb	a,r0
      006DB7 EA               [12] 3951 	mov	a,r2
      006DB8 99               [12] 3952 	subb	a,r1
      006DB9 50 0D            [24] 3953 	jnc	00165$
                                   3954 ;	free result
      006DBB                       3955 00106$:
                                   3956 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      006DBB 90 07 C7         [24] 3957 	mov	dptr,#(_raw_buffer + 0x0001)
      006DBE 74 FF            [12] 3958 	mov	a,#0xff
      006DC0 F0               [24] 3959 	movx	@dptr,a
                                   3960 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      006DC1 90 07 CA         [24] 3961 	mov	dptr,#(_raw_buffer + 0x0004)
      006DC4 E4               [12] 3962 	clr	a
      006DC5 F0               [24] 3963 	movx	@dptr,a
                                   3964 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006DC6 80 3A            [24] 3965 	sjmp	00108$
      006DC8                       3966 00165$:
      006DC8 7B 00            [12] 3967 	mov	r3,#0x00
      006DCA                       3968 00131$:
      006DCA C3               [12] 3969 	clr	c
      006DCB EB               [12] 3970 	mov	a,r3
      006DCC 9C               [12] 3971 	subb	a,r4
      006DCD 50 33            [24] 3972 	jnc	00108$
      006DCF C0 04            [24] 3973 	push	ar4
      006DD1 8B 02            [24] 3974 	mov	ar2,r3
      006DD3 74 05            [12] 3975 	mov	a,#0x05
      006DD5 2A               [12] 3976 	add	a, r2
      006DD6 F9               [12] 3977 	mov	r1,a
      006DD7 33               [12] 3978 	rlc	a
      006DD8 95 E0            [12] 3979 	subb	a,acc
      006DDA FA               [12] 3980 	mov	r2,a
      006DDB E9               [12] 3981 	mov	a,r1
      006DDC 24 C6            [12] 3982 	add	a, #_raw_buffer
      006DDE F9               [12] 3983 	mov	r1,a
      006DDF EA               [12] 3984 	mov	a,r2
      006DE0 34 07            [12] 3985 	addc	a, #(_raw_buffer >> 8)
      006DE2 FA               [12] 3986 	mov	r2,a
      006DE3 8B 1E            [24] 3987 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006DE5 75 1F 00         [24] 3988 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006DE8 8E 00            [24] 3989 	mov	ar0,r6
      006DEA 8D 04            [24] 3990 	mov	ar4,r5
      006DEC E5 1E            [12] 3991 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006DEE 28               [12] 3992 	add	a, r0
      006DEF F8               [12] 3993 	mov	r0,a
      006DF0 E5 1F            [12] 3994 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006DF2 3C               [12] 3995 	addc	a, r4
      006DF3 FC               [12] 3996 	mov	r4,a
      006DF4 88 82            [24] 3997 	mov	dpl,r0
      006DF6 8C 83            [24] 3998 	mov	dph,r4
      006DF8 E4               [12] 3999 	clr	a
      006DF9 93               [24] 4000 	movc	a,@a+dptr
      006DFA 12 6F 43         [24] 4001 	lcall	_ak820_outline_0136
      006DFD 0B               [12] 4002 	inc	r3
      006DFE D0 04            [24] 4003 	pop	ar4
      006E00 80 C8            [24] 4004 	sjmp	00131$
      006E02                       4005 00108$:
                                   4006 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006E02 12 6F 23         [24] 4007 	lcall	_ak820_outline_0041
      006E05 12 6A 0F         [24] 4008 	lcall	_ak820_usb_send
      006E08 02 6E B1         [24] 4009 	ljmp	00119$
      006E0B                       4010 00118$:
                                   4011 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006E0B EF               [12] 4012 	mov	a,r7
      006E0C 70 03            [24] 4013 	jnz	00281$
      006E0E 02 6E 8E         [24] 4014 	ljmp	00114$
      006E11                       4015 00281$:
      006E11 12 6F 49         [24] 4016 	lcall	_ak820_outline_0159
      006E14 BF 01 02         [24] 4017 	cjne	r7,#0x01,00282$
      006E17 80 03            [24] 4018 	sjmp	00283$
      006E19                       4019 00282$:
      006E19 02 6E 8E         [24] 4020 	ljmp	00114$
      006E1C                       4021 00283$:
                                   4022 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006E1C 7F 02            [12] 4023 	mov	r7,#0x02
      006E1E                       4024 00133$:
      006E1E EF               [12] 4025 	mov	a,r7
      006E1F 12 6F 37         [24] 4026 	lcall	_ak820_outline_0101
      006E22 0F               [12] 4027 	inc	r7
      006E23 BF 20 00         [24] 4028 	cjne	r7,#0x20,00284$
      006E26                       4029 00284$:
      006E26 40 F6            [24] 4030 	jc	00133$
                                   4031 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      006E28 90 07 C8         [24] 4032 	mov	dptr,#(_raw_buffer + 0x0002)
      006E2B 74 01            [12] 4033 	mov	a,#0x01
      006E2D F0               [24] 4034 	movx	@dptr,a
                                   4035 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      006E2E 90 07 C9         [24] 4036 	mov	dptr,#(_raw_buffer + 0x0003)
      006E31 74 A8            [12] 4037 	mov	a,#0xa8
      006E33 F0               [24] 4038 	movx	@dptr,a
                                   4039 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      006E34 90 07 CA         [24] 4040 	mov	dptr,#(_raw_buffer + 0x0004)
      006E37 12 3E 9E         [24] 4041 	lcall	_ak820_nvm_diagnostic
                                   4042 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006E3A 7F 00            [12] 4043 	mov	r7,#0x00
      006E3C                       4044 00135$:
      006E3C 8F 06            [24] 4045 	mov	ar6,r7
      006E3E 74 0B            [12] 4046 	mov	a,#0x0b
      006E40 2E               [12] 4047 	add	a, r6
      006E41 24 C6            [12] 4048 	add	a,#_raw_buffer
      006E43 FE               [12] 4049 	mov	r6,a
      006E44 E4               [12] 4050 	clr	a
      006E45 34 07            [12] 4051 	addc	a, #(_raw_buffer >> 8)
      006E47 FD               [12] 4052 	mov	r5,a
      006E48 EF               [12] 4053 	mov	a,r7
      006E49 24 B6            [12] 4054 	add	a, #_ak820_flash_diagnostic
      006E4B F5 82            [12] 4055 	mov	dpl,a
      006E4D E4               [12] 4056 	clr	a
      006E4E 34 04            [12] 4057 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006E50 F5 83            [12] 4058 	mov	dph,a
      006E52 E0               [24] 4059 	movx	a,@dptr
      006E53 8E 82            [24] 4060 	mov	dpl,r6
      006E55 8D 83            [24] 4061 	mov	dph,r5
      006E57 F0               [24] 4062 	movx	@dptr,a
      006E58 0F               [12] 4063 	inc	r7
      006E59 BF 06 00         [24] 4064 	cjne	r7,#0x06,00286$
      006E5C                       4065 00286$:
      006E5C 40 DE            [24] 4066 	jc	00135$
                                   4067 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      006E5E 90 0E 46         [24] 4068 	mov	dptr,#_vial_unlocked
      006E61 E0               [24] 4069 	movx	a,@dptr
      006E62 90 07 D7         [24] 4070 	mov	dptr,#(_raw_buffer + 0x0011)
      006E65 F0               [24] 4071 	movx	@dptr,a
                                   4072 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      006E66 90 0E 47         [24] 4073 	mov	dptr,#_vial_unlock_in_progress
      006E69 E0               [24] 4074 	movx	a,@dptr
      006E6A 90 07 D8         [24] 4075 	mov	dptr,#(_raw_buffer + 0x0012)
      006E6D F0               [24] 4076 	movx	@dptr,a
                                   4077 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      006E6E 90 07 BE         [24] 4078 	mov	dptr,#_USB_EnumStatus
      006E71 E0               [24] 4079 	movx	a,@dptr
      006E72 90 07 D9         [24] 4080 	mov	dptr,#(_raw_buffer + 0x0013)
      006E75 F0               [24] 4081 	movx	@dptr,a
                                   4082 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      006E76 90 07 BF         [24] 4083 	mov	dptr,#_USB_SleepStatus
      006E79 E0               [24] 4084 	movx	a,@dptr
      006E7A 90 07 DA         [24] 4085 	mov	dptr,#(_raw_buffer + 0x0014)
      006E7D F0               [24] 4086 	movx	@dptr,a
                                   4087 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      006E7E 90 07 C5         [24] 4088 	mov	dptr,#_raw_state
      006E81 E0               [24] 4089 	movx	a,@dptr
      006E82 90 07 DB         [24] 4090 	mov	dptr,#(_raw_buffer + 0x0015)
      006E85 F0               [24] 4091 	movx	@dptr,a
                                   4092 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006E86 12 6F 23         [24] 4093 	lcall	_ak820_outline_0041
      006E89 12 6A 0F         [24] 4094 	lcall	_ak820_usb_send
      006E8C 80 23            [24] 4095 	sjmp	00119$
      006E8E                       4096 00114$:
                                   4097 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006E8E 12 6C 1E         [24] 4098 	lcall	_raw_request_is_nonpersistent
      006E91 E5 82            [12] 4099 	mov	a, dpl
      006E93 90 07 E6         [24] 4100 	mov	dptr,#_raw_reply_without_nvm
      006E96 F0               [24] 4101 	movx	@dptr,a
                                   4102 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      006E97 12 42 82         [24] 4103 	lcall	_ak820_nvm_begin
                                   4104 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006E9A 90 0C 78         [24] 4105 	mov	dptr,#_raw_hid_receive_PARM_2
      006E9D 74 20            [12] 4106 	mov	a,#0x20
      006E9F F0               [24] 4107 	movx	@dptr,a
      006EA0 90 07 C6         [24] 4108 	mov	dptr,#_raw_buffer
      006EA3 75 F0 00         [24] 4109 	mov	b, #0x00
      006EA6 12 A8 7E         [24] 4110 	lcall	_raw_hid_receive
                                   4111 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      006EA9 12 42 97         [24] 4112 	lcall	_ak820_nvm_end
                                   4113 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      006EAC 90 07 E6         [24] 4114 	mov	dptr,#_raw_reply_without_nvm
      006EAF E4               [12] 4115 	clr	a
      006EB0 F0               [24] 4116 	movx	@dptr,a
      006EB1                       4117 00119$:
                                   4118 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4119 ;	assignBit
      006EB1 A2 AF            [12] 4120 	mov	c,_EA
      006EB3 92 1C            [24] 4121 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4123 ;	assignBit
      006EB5 C2 AF            [12] 4124 	clr	_EA
                                   4125 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006EB7 12 6F 4F         [24] 4126 	lcall	_ak820_outline_0161
      006EBA BF 04 08         [24] 4127 	cjne	r7,#0x04,00126$
      006EBD 90 07 C5         [24] 4128 	mov	dptr,#_raw_state
      006EC0 74 05            [12] 4129 	mov	a,#0x05
      006EC2 F0               [24] 4130 	movx	@dptr,a
      006EC3 80 1B            [24] 4131 	sjmp	00127$
      006EC5                       4132 00126$:
                                   4133 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006EC5 12 6F 4F         [24] 4134 	lcall	_ak820_outline_0161
      006EC8 BF 03 02         [24] 4135 	cjne	r7,#0x03,00290$
      006ECB 80 0E            [24] 4136 	sjmp	00121$
      006ECD                       4137 00290$:
      006ECD 12 6F 4F         [24] 4138 	lcall	_ak820_outline_0161
      006ED0 BF 06 02         [24] 4139 	cjne	r7,#0x06,00291$
      006ED3 80 06            [24] 4140 	sjmp	00121$
      006ED5                       4141 00291$:
      006ED5 12 6F 4F         [24] 4142 	lcall	_ak820_outline_0161
      006ED8 BF 07 05         [24] 4143 	cjne	r7,#0x07,00127$
      006EDB                       4144 00121$:
      006EDB 90 07 C5         [24] 4145 	mov	dptr,#_raw_state
      006EDE E4               [12] 4146 	clr	a
      006EDF F0               [24] 4147 	movx	@dptr,a
      006EE0                       4148 00127$:
                                   4149 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4150 ;	assignBit
      006EE0 A2 1C            [12] 4151 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006EE2 92 AF            [24] 4152 	mov	_EA,c
                                   4153 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      006EE4 22               [24] 4154 	ret
                                   4155 ;------------------------------------------------------------
                                   4156 ;Allocation info for local variables in function 'ak820_usb_keyboard_blocked'
                                   4157 ;------------------------------------------------------------
                                   4158 ;	tmk_core/protocol/ch555/usb_ak820.c:707: bool ak820_usb_keyboard_blocked(void) {
                                   4159 ;	-----------------------------------------
                                   4160 ;	 function ak820_usb_keyboard_blocked
                                   4161 ;	-----------------------------------------
      006EE5                       4162 _ak820_usb_keyboard_blocked:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:708: return !USB_EnumStatus || (USB_SleepStatus & 2) || keyboard_reset;
      006EE5 90 07 BE         [24] 4164 	mov	dptr,#_USB_EnumStatus
      006EE8 E0               [24] 4165 	movx	a,@dptr
      006EE9 60 13            [24] 4166 	jz	00104$
      006EEB 90 07 BF         [24] 4167 	mov	dptr,#_USB_SleepStatus
      006EEE E0               [24] 4168 	movx	a,@dptr
      006EEF 03               [12] 4169 	rr	a
      006EF0 54 01            [12] 4170 	anl	a,#0x01
      006EF2 70 0A            [24] 4171 	jnz	00104$
      006EF4 90 07 E7         [24] 4172 	mov	dptr,#_keyboard_reset
      006EF7 E0               [24] 4173 	movx	a,@dptr
      006EF8 70 04            [24] 4174 	jnz	00104$
                                   4175 ;	assignBit
      006EFA C2 1D            [12] 4176 	clr	_ak820_usb_keyboard_blocked_sloc0_1_0
      006EFC 80 02            [24] 4177 	sjmp	00105$
      006EFE                       4178 00104$:
                                   4179 ;	assignBit
      006EFE D2 1D            [12] 4180 	setb	_ak820_usb_keyboard_blocked_sloc0_1_0
      006F00                       4181 00105$:
      006F00 A2 1D            [12] 4182 	mov	c,_ak820_usb_keyboard_blocked_sloc0_1_0
      006F02 E4               [12] 4183 	clr	a
      006F03 33               [12] 4184 	rlc	a
      006F04 F5 82            [12] 4185 	mov	dpl, a
                                   4186 ;	tmk_core/protocol/ch555/usb_ak820.c:709: }
      006F06 22               [24] 4187 	ret
                                   4188 ;------------------------------------------------------------
                                   4189 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4190 ;------------------------------------------------------------
                                   4191 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_485'
                                   4192 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_485'
                                   4193 ;------------------------------------------------------------
                                   4194 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4195 ;	-----------------------------------------
                                   4196 ;	 function ak820_usb_take_keyboard_reset
                                   4197 ;	-----------------------------------------
      006F07                       4198 _ak820_usb_take_keyboard_reset:
                                   4199 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4200 ;	assignBit
      006F07 A2 AF            [12] 4201 	mov	c,_EA
      006F09 92 1E            [24] 4202 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4203 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4204 ;	assignBit
      006F0B C2 AF            [12] 4205 	clr	_EA
                                   4206 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      006F0D 90 07 E7         [24] 4207 	mov	dptr,#_keyboard_reset
      006F10 E0               [24] 4208 	movx	a,@dptr
      006F11 FF               [12] 4209 	mov	r7,a
                                   4210 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      006F12 E4               [12] 4211 	clr	a
      006F13 F0               [24] 4212 	movx	@dptr,a
                                   4213 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4214 ;	assignBit
      006F14 A2 1E            [12] 4215 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006F16 92 AF            [24] 4216 	mov	_EA,c
                                   4217 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      006F18 EF               [12] 4218 	mov	a,r7
      006F19 B4 01 00         [24] 4219 	cjne	a,#0x01,00103$
      006F1C                       4220 00103$:
      006F1C B3               [12] 4221 	cpl	c
      006F1D 92 1E            [24] 4222 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006F1F 12 38 86         [24] 4223 	lcall	_ak820_outline_0166
                                   4224 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      006F22 22               [24] 4225 	ret
                                   4226 	.area CSEG    (CODE)
                                   4227 	.area CONST   (CODE)
                                   4228 	.area CONST   (CODE)
      00BB58                       4229 _shared_offsets:
      00BB58 00                    4230 	.db #0x00	; 0
      00BB59 00                    4231 	.db #0x00	; 0
      00BB5A 28                    4232 	.db #0x28	; 40
      00BB5B 28                    4233 	.db #0x28	; 40
      00BB5C 2B                    4234 	.db #0x2b	; 43
      00BB5D 00                    4235 	.db #0x00	; 0
      00BB5E 08                    4236 	.db #0x08	; 8
                                   4237 	.area CSEG    (CODE)
                                   4238 	.area CONST   (CODE)
      00BB5F                       4239 _shared_lengths:
      00BB5F 00                    4240 	.db #0x00	; 0
      00BB60 00                    4241 	.db #0x00	; 0
      00BB61 00                    4242 	.db #0x00	; 0
      00BB62 03                    4243 	.db #0x03	; 3
      00BB63 03                    4244 	.db #0x03	; 3
      00BB64 00                    4245 	.db #0x00	; 0
      00BB65 20                    4246 	.db #0x20	; 32
                                   4247 	.area CSEG    (CODE)
                                   4248 	.area CONST   (CODE)
      00BB66                       4249 _interface_descriptors:
      00BB66 01 C1                 4250 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BB68 01 C2                 4251 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BB6A B4 C1                 4252 	.byte _RawReport, (_RawReport >> 8)
      00BB6C 1A C2                 4253 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BB6E 46 C1                 4254 	.byte _SharedReport, (_SharedReport >> 8)
      00BB70 33 C2                 4255 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4256 	.area CSEG    (CODE)
                                   4257 	.area XINIT   (CODE)
                                   4258 	.area CABS    (ABS,CODE)
                                   4259 
                                   4260 ; Experimental exact instruction outlining.
                                   4261 	.globl _ak820_outline_0015
                                   4262 	.globl _ak820_outline_0036
                                   4263 	.globl _ak820_outline_0041
                                   4264 	.globl _ak820_outline_0094
                                   4265 	.globl _ak820_outline_0101
                                   4266 	.globl _ak820_outline_0136
                                   4267 	.globl _ak820_outline_0157
                                   4268 	.globl _ak820_outline_0159
                                   4269 	.globl _ak820_outline_0161
                                   4270 	.globl _ak820_outline_0166
                                   4271 
                                   4272 	.area CSEG (CODE)
                                   4273 ; function ak820_outline_0041
      006F23                       4274 _ak820_outline_0041:
      006F23 90 08 23         [24] 4275 	mov	dptr,#_ak820_usb_send_PARM_2
      006F26 74 C6            [12] 4276 	mov	a,#_raw_buffer
      006F28 F0               [24] 4277 	movx	@dptr,a
      006F29 74 07            [12] 4278 	mov	a,#(_raw_buffer>>8)
      006F2B A3               [24] 4279 	inc	dptr
      006F2C F0               [24] 4280 	movx	@dptr,a
      006F2D 90 08 25         [24] 4281 	mov	dptr,#_ak820_usb_send_PARM_3
      006F30 74 20            [12] 4282 	mov	a,#0x20
      006F32 F0               [24] 4283 	movx	@dptr,a
      006F33 75 82 03         [24] 4284 	mov	dpl,#0x03
      006F36 22               [24] 4285 	ret
                                   4286 
                                   4287 	.area CSEG (CODE)
                                   4288 ; function ak820_outline_0101
      006F37                       4289 _ak820_outline_0101:
      006F37 24 C6            [12] 4290 	add	a,#_raw_buffer
      006F39 F5 82            [12] 4291 	mov	dpl,a
      006F3B E4               [12] 4292 	clr	a
      006F3C 34 07            [12] 4293 	addc	a,#(_raw_buffer>>8)
      006F3E F5 83            [12] 4294 	mov	dph,a
      006F40 E4               [12] 4295 	clr	a
      006F41 F0               [24] 4296 	movx	@dptr,a
      006F42 22               [24] 4297 	ret
                                   4298 
                                   4299 	.area CSEG (CODE)
                                   4300 ; function ak820_outline_0136
      006F43                       4301 _ak820_outline_0136:
      006F43 89 82            [24] 4302 	mov	dpl,r1
      006F45 8A 83            [24] 4303 	mov	dph,r2
      006F47 F0               [24] 4304 	movx	@dptr,a
      006F48 22               [24] 4305 	ret
                                   4306 
                                   4307 	.area CSEG (CODE)
                                   4308 ; function ak820_outline_0159
      006F49                       4309 _ak820_outline_0159:
      006F49 90 07 C7         [24] 4310 	mov	dptr,#(_raw_buffer+0x0001)
      006F4C E0               [24] 4311 	movx	a,@dptr
      006F4D FF               [12] 4312 	mov	r7,a
      006F4E 22               [24] 4313 	ret
                                   4314 
                                   4315 	.area CSEG (CODE)
                                   4316 ; function ak820_outline_0161
      006F4F                       4317 _ak820_outline_0161:
      006F4F 90 07 C5         [24] 4318 	mov	dptr,#_raw_state
      006F52 E0               [24] 4319 	movx	a,@dptr
      006F53 FF               [12] 4320 	mov	r7,a
      006F54 22               [24] 4321 	ret
