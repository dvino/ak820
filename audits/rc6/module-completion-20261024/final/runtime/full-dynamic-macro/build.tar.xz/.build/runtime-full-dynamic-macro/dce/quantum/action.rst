                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_dynamic_macro_cancel
                                     21 	.globl _ak820_dynamic_macro_task
                                     22 	.globl _ak820_dynamic_macro_observe
                                     23 	.globl _ak820_dynamic_macro_process
                                     24 	.globl _pre_process_record_quantum
                                     25 	.globl _get_record_keycode
                                     26 	.globl _get_repeat_key_count
                                     27 	.globl _repeat_key_cancel
                                     28 	.globl _clear_owned_usages
                                     29 	.globl _owned_usage_key
                                     30 	.globl _clear_owned_keys
                                     31 	.globl _del_owned_key
                                     32 	.globl _add_owned_key
                                     33 	.globl _clear_owned_mods
                                     34 	.globl _del_owned_weak_mods
                                     35 	.globl _add_owned_weak_mods
                                     36 	.globl _del_owned_mods
                                     37 	.globl _add_owned_mods
                                     38 	.globl _clear_weak_mods
                                     39 	.globl _clear_mods
                                     40 	.globl _send_keyboard_report
                                     41 	.globl _layer_hold_clear
                                     42 	.globl _layer_hold_off
                                     43 	.globl _layer_hold_on
                                     44 	.globl _ak820_resolve_key
                                     45 	.globl _layer_xor
                                     46 	.globl _layer_and
                                     47 	.globl _layer_or
                                     48 	.globl _layer_off
                                     49 	.globl _layer_on
                                     50 	.globl _layer_move
                                     51 	.globl _layer_clear
                                     52 	.globl _layer_state_set
                                     53 	.globl _default_layer_xor
                                     54 	.globl _default_layer_and
                                     55 	.globl _default_layer_or
                                     56 	.globl _default_layer_set
                                     57 	.globl _process_record_quantum
                                     58 	.globl _action_for_keycode
                                     59 	.globl _mDelaymS
                                     60 	.globl _host_consumer_send
                                     61 	.globl _host_system_send
                                     62 	.globl _host_keyboard_leds
                                     63 	.globl _led_set
                                     64 	.globl _clear_keys_from_report
                                     65 	.globl ___memcpy
                                     66 	.globl _ADC_START
                                     67 	.globl _S0_R_FIFO
                                     68 	.globl _S0_T_FIFO
                                     69 	.globl _S0_FREE
                                     70 	.globl _S0_IF_BYTE
                                     71 	.globl _S0_IF_FIRST
                                     72 	.globl _S0_IF_OV
                                     73 	.globl _S0_FST_ACT
                                     74 	.globl _CP_RL2
                                     75 	.globl _C_T2
                                     76 	.globl _TR2
                                     77 	.globl _EXEN2
                                     78 	.globl _TCLK
                                     79 	.globl _RCLK
                                     80 	.globl _EXF2
                                     81 	.globl _CAP1F
                                     82 	.globl _TF2
                                     83 	.globl _RI
                                     84 	.globl _TI
                                     85 	.globl _RB8
                                     86 	.globl _TB8
                                     87 	.globl _REN
                                     88 	.globl _SM2
                                     89 	.globl _SM1
                                     90 	.globl _SM0
                                     91 	.globl _IT0
                                     92 	.globl _IE0
                                     93 	.globl _IT1
                                     94 	.globl _IE1
                                     95 	.globl _TR0
                                     96 	.globl _TF0
                                     97 	.globl _TR1
                                     98 	.globl _TF1
                                     99 	.globl _P4_0
                                    100 	.globl _P4_1
                                    101 	.globl _P4_2
                                    102 	.globl _P4_3
                                    103 	.globl _P4_4
                                    104 	.globl _P4_5
                                    105 	.globl _P4_6
                                    106 	.globl _RXD
                                    107 	.globl _TXD
                                    108 	.globl _INT0
                                    109 	.globl _INT1
                                    110 	.globl _T0
                                    111 	.globl _T1
                                    112 	.globl _MOSI1
                                    113 	.globl _MISO1
                                    114 	.globl _SCK1
                                    115 	.globl _P3_0
                                    116 	.globl _P3_1
                                    117 	.globl _P3_2
                                    118 	.globl _P3_3
                                    119 	.globl _P3_4
                                    120 	.globl _P3_5
                                    121 	.globl _P3_6
                                    122 	.globl _P3_7
                                    123 	.globl _CAP1_
                                    124 	.globl _T2_
                                    125 	.globl _CAP2_
                                    126 	.globl _T2EX_
                                    127 	.globl _RXD1
                                    128 	.globl _TXD1
                                    129 	.globl _P2_0
                                    130 	.globl _P2_1
                                    131 	.globl _P2_2
                                    132 	.globl _P2_3
                                    133 	.globl _P2_4
                                    134 	.globl _P2_5
                                    135 	.globl _P2_6
                                    136 	.globl _P2_7
                                    137 	.globl _AIN0
                                    138 	.globl _AIN1
                                    139 	.globl _AIN2
                                    140 	.globl _AIN3
                                    141 	.globl _AIN4
                                    142 	.globl _AIN5
                                    143 	.globl _AIN6
                                    144 	.globl _AIN7
                                    145 	.globl _CAP1
                                    146 	.globl _T2
                                    147 	.globl _CAP2
                                    148 	.globl _T2EX
                                    149 	.globl _INT0_
                                    150 	.globl _SCS
                                    151 	.globl _MOSI
                                    152 	.globl _MISO
                                    153 	.globl _SCK
                                    154 	.globl _RXD1_
                                    155 	.globl _TXD1_
                                    156 	.globl _P1_0
                                    157 	.globl _P1_1
                                    158 	.globl _P1_2
                                    159 	.globl _P1_3
                                    160 	.globl _P1_4
                                    161 	.globl _P1_5
                                    162 	.globl _P1_6
                                    163 	.globl _P1_7
                                    164 	.globl _AIN8
                                    165 	.globl _AIN9
                                    166 	.globl _AIN10
                                    167 	.globl _AIN11
                                    168 	.globl _AIN12
                                    169 	.globl _AIN13
                                    170 	.globl _RXD_
                                    171 	.globl _TXD_
                                    172 	.globl _SCL0
                                    173 	.globl _SDA0
                                    174 	.globl _P0_0
                                    175 	.globl _P0_1
                                    176 	.globl _P0_2
                                    177 	.globl _P0_3
                                    178 	.globl _P0_4
                                    179 	.globl _P0_5
                                    180 	.globl _P0_6
                                    181 	.globl _P0_7
                                    182 	.globl _IE_SPI0
                                    183 	.globl _IE_USB
                                    184 	.globl _IE_ADC
                                    185 	.globl _IE_UART1
                                    186 	.globl _IE_PWM_I2C
                                    187 	.globl _IE_GPIO
                                    188 	.globl _IE_WDOG
                                    189 	.globl _PX0
                                    190 	.globl _PT0
                                    191 	.globl _PX1
                                    192 	.globl _PT1
                                    193 	.globl _PS
                                    194 	.globl _PT2
                                    195 	.globl _PL_FLAG
                                    196 	.globl _PH_FLAG
                                    197 	.globl _EX0
                                    198 	.globl _ET0
                                    199 	.globl _EX1
                                    200 	.globl _ET1
                                    201 	.globl _ES
                                    202 	.globl _ET2
                                    203 	.globl _E_DIS
                                    204 	.globl _EA
                                    205 	.globl _P
                                    206 	.globl _F1
                                    207 	.globl _OV
                                    208 	.globl _RS0
                                    209 	.globl _RS1
                                    210 	.globl _F0
                                    211 	.globl _AC
                                    212 	.globl _CY
                                    213 	.globl _I2CS_INT_ST
                                    214 	.globl _I2CX_INT
                                    215 	.globl _LED_STATUS
                                    216 	.globl _LED_DMA_H
                                    217 	.globl _LED_DMA_L
                                    218 	.globl _LED_DMA
                                    219 	.globl _LED_PWM_OE
                                    220 	.globl _LED_COMMON
                                    221 	.globl _ADC_CHAN
                                    222 	.globl _ADC_DAT_H
                                    223 	.globl _ADC_DAT_L
                                    224 	.globl _ADC_DAT
                                    225 	.globl _ADC_CTRL
                                    226 	.globl _SPI1_CK_SE
                                    227 	.globl _SPI1_CTRL
                                    228 	.globl _SPI1_DATA
                                    229 	.globl _SPI1_STAT
                                    230 	.globl _SIF1
                                    231 	.globl _SBAUD1
                                    232 	.globl _SBUF1
                                    233 	.globl _SCON1
                                    234 	.globl _SPI0_SETUP
                                    235 	.globl _SPI0_CK_SE
                                    236 	.globl _SPI0_CTRL
                                    237 	.globl _SPI0_DATA
                                    238 	.globl _SPI0_STAT
                                    239 	.globl _T2CAP1H
                                    240 	.globl _T2CAP1L
                                    241 	.globl _T2CAP1
                                    242 	.globl _TH2
                                    243 	.globl _TL2
                                    244 	.globl _T2COUNT
                                    245 	.globl _RCAP2H
                                    246 	.globl _RCAP2L
                                    247 	.globl _RCAP2
                                    248 	.globl _T2MOD
                                    249 	.globl _T2CON
                                    250 	.globl _SBUF
                                    251 	.globl _SCON
                                    252 	.globl _TH1
                                    253 	.globl _TH0
                                    254 	.globl _TL1
                                    255 	.globl _TL0
                                    256 	.globl _TMOD
                                    257 	.globl _TCON
                                    258 	.globl _XBUS_AUX
                                    259 	.globl _P7
                                    260 	.globl _P6_DIR
                                    261 	.globl _P6_OUT_PU
                                    262 	.globl _P6_IN
                                    263 	.globl _P5_DIR
                                    264 	.globl _P5_OUT_PU
                                    265 	.globl _P5_IN
                                    266 	.globl _P4_LED_KEY
                                    267 	.globl _P4_DIR_PU
                                    268 	.globl _P4_MOD_OC
                                    269 	.globl _P4
                                    270 	.globl _P3_DIR_PU
                                    271 	.globl _P3_MOD_OC
                                    272 	.globl _P3
                                    273 	.globl _P2_DIR_PU
                                    274 	.globl _P2_MOD_OC
                                    275 	.globl _P2
                                    276 	.globl _P1_DIR_PU
                                    277 	.globl _P1_MOD_OC
                                    278 	.globl _P1
                                    279 	.globl _P0_DIR_PU
                                    280 	.globl _P0_MOD_OC
                                    281 	.globl _P0
                                    282 	.globl _ROM_CTRL
                                    283 	.globl _ROM_DATA_HH
                                    284 	.globl _ROM_DATA_HL
                                    285 	.globl _ROM_DATA_HI
                                    286 	.globl _ROM_ADDR_H
                                    287 	.globl _ROM_ADDR_L
                                    288 	.globl _ROM_ADDR
                                    289 	.globl _GPIO_IE
                                    290 	.globl _IP_EX
                                    291 	.globl _IE_EX
                                    292 	.globl _IP
                                    293 	.globl _IE
                                    294 	.globl _WDOG_COUNT
                                    295 	.globl _RESET_KEEP
                                    296 	.globl _WAKE_CTRL
                                    297 	.globl _CLOCK_CFG
                                    298 	.globl _POWER_CFG
                                    299 	.globl _PCON
                                    300 	.globl _GLOBAL_CFG
                                    301 	.globl _SAFE_MOD
                                    302 	.globl _DPH
                                    303 	.globl _DPL
                                    304 	.globl _SP
                                    305 	.globl _A_INV
                                    306 	.globl _B
                                    307 	.globl _ACC
                                    308 	.globl _PSW
                                    309 	.globl _disable_action_cache
                                    310 	.globl _tap_code_delay_PARM_2
                                    311 	.globl _process_action_PARM_2
                                    312 	.globl _action_exec_PARM_1
                                    313 	.globl _tp_buttons
                                    314 	.globl _action_exec
                                    315 	.globl _ak820_action_exec
                                    316 	.globl _process_record
                                    317 	.globl _process_record_handler
                                    318 	.globl _process_action
                                    319 	.globl _register_code
                                    320 	.globl _unregister_code
                                    321 	.globl _tap_code_delay
                                    322 	.globl _tap_code
                                    323 	.globl _register_mods
                                    324 	.globl _unregister_mods
                                    325 	.globl _register_weak_mods
                                    326 	.globl _unregister_weak_mods
                                    327 	.globl _clear_keyboard
                                    328 	.globl _clear_keyboard_but_mods
                                    329 	.globl _clear_keyboard_but_mods_and_keys
                                    330 ;--------------------------------------------------------
                                    331 ; special function registers
                                    332 ;--------------------------------------------------------
                                    333 	.area RSEG    (ABS,DATA)
      000000                        334 	.org 0x0000
                           0000D0   335 _PSW	=	0x00d0
                           0000E0   336 _ACC	=	0x00e0
                           0000F0   337 _B	=	0x00f0
                           0000FD   338 _A_INV	=	0x00fd
                           000081   339 _SP	=	0x0081
                           000082   340 _DPL	=	0x0082
                           000083   341 _DPH	=	0x0083
                           0000A1   342 _SAFE_MOD	=	0x00a1
                           0000B1   343 _GLOBAL_CFG	=	0x00b1
                           000087   344 _PCON	=	0x0087
                           0000BA   345 _POWER_CFG	=	0x00ba
                           0000B9   346 _CLOCK_CFG	=	0x00b9
                           0000A9   347 _WAKE_CTRL	=	0x00a9
                           0000FE   348 _RESET_KEEP	=	0x00fe
                           0000FF   349 _WDOG_COUNT	=	0x00ff
                           0000A8   350 _IE	=	0x00a8
                           0000B8   351 _IP	=	0x00b8
                           0000E8   352 _IE_EX	=	0x00e8
                           0000E9   353 _IP_EX	=	0x00e9
                           0000B2   354 _GPIO_IE	=	0x00b2
                           008584   355 _ROM_ADDR	=	0x8584
                           000084   356 _ROM_ADDR_L	=	0x0084
                           000085   357 _ROM_ADDR_H	=	0x0085
                           008F8E   358 _ROM_DATA_HI	=	0x8f8e
                           00008E   359 _ROM_DATA_HL	=	0x008e
                           00008F   360 _ROM_DATA_HH	=	0x008f
                           000086   361 _ROM_CTRL	=	0x0086
                           000080   362 _P0	=	0x0080
                           0000C4   363 _P0_MOD_OC	=	0x00c4
                           0000C5   364 _P0_DIR_PU	=	0x00c5
                           000090   365 _P1	=	0x0090
                           000092   366 _P1_MOD_OC	=	0x0092
                           000093   367 _P1_DIR_PU	=	0x0093
                           0000A0   368 _P2	=	0x00a0
                           000094   369 _P2_MOD_OC	=	0x0094
                           000095   370 _P2_DIR_PU	=	0x0095
                           0000B0   371 _P3	=	0x00b0
                           000096   372 _P3_MOD_OC	=	0x0096
                           000097   373 _P3_DIR_PU	=	0x0097
                           0000C0   374 _P4	=	0x00c0
                           0000C2   375 _P4_MOD_OC	=	0x00c2
                           0000C3   376 _P4_DIR_PU	=	0x00c3
                           0000C1   377 _P4_LED_KEY	=	0x00c1
                           0000AA   378 _P5_IN	=	0x00aa
                           0000AB   379 _P5_OUT_PU	=	0x00ab
                           0000AC   380 _P5_DIR	=	0x00ac
                           0000AD   381 _P6_IN	=	0x00ad
                           0000AE   382 _P6_OUT_PU	=	0x00ae
                           0000AF   383 _P6_DIR	=	0x00af
                           0000F1   384 _P7	=	0x00f1
                           0000A2   385 _XBUS_AUX	=	0x00a2
                           000088   386 _TCON	=	0x0088
                           000089   387 _TMOD	=	0x0089
                           00008A   388 _TL0	=	0x008a
                           00008B   389 _TL1	=	0x008b
                           00008C   390 _TH0	=	0x008c
                           00008D   391 _TH1	=	0x008d
                           000098   392 _SCON	=	0x0098
                           000099   393 _SBUF	=	0x0099
                           0000C8   394 _T2CON	=	0x00c8
                           0000C9   395 _T2MOD	=	0x00c9
                           00CBCA   396 _RCAP2	=	0xcbca
                           0000CA   397 _RCAP2L	=	0x00ca
                           0000CB   398 _RCAP2H	=	0x00cb
                           00CDCC   399 _T2COUNT	=	0xcdcc
                           0000CC   400 _TL2	=	0x00cc
                           0000CD   401 _TH2	=	0x00cd
                           00CFCE   402 _T2CAP1	=	0xcfce
                           0000CE   403 _T2CAP1L	=	0x00ce
                           0000CF   404 _T2CAP1H	=	0x00cf
                           0000F8   405 _SPI0_STAT	=	0x00f8
                           0000F9   406 _SPI0_DATA	=	0x00f9
                           0000FA   407 _SPI0_CTRL	=	0x00fa
                           0000FB   408 _SPI0_CK_SE	=	0x00fb
                           0000FC   409 _SPI0_SETUP	=	0x00fc
                           0000BC   410 _SCON1	=	0x00bc
                           0000BD   411 _SBUF1	=	0x00bd
                           0000BE   412 _SBAUD1	=	0x00be
                           0000BF   413 _SIF1	=	0x00bf
                           0000B4   414 _SPI1_STAT	=	0x00b4
                           0000B5   415 _SPI1_DATA	=	0x00b5
                           0000B6   416 _SPI1_CTRL	=	0x00b6
                           0000B7   417 _SPI1_CK_SE	=	0x00b7
                           0000F3   418 _ADC_CTRL	=	0x00f3
                           00F5F4   419 _ADC_DAT	=	0xf5f4
                           0000F4   420 _ADC_DAT_L	=	0x00f4
                           0000F5   421 _ADC_DAT_H	=	0x00f5
                           0000F6   422 _ADC_CHAN	=	0x00f6
                           0000A6   423 _LED_COMMON	=	0x00a6
                           0000A7   424 _LED_PWM_OE	=	0x00a7
                           00C7C6   425 _LED_DMA	=	0xc7c6
                           0000C6   426 _LED_DMA_L	=	0x00c6
                           0000C7   427 _LED_DMA_H	=	0x00c7
                           0000F7   428 _LED_STATUS	=	0x00f7
                           0000B3   429 _I2CX_INT	=	0x00b3
                           0000BB   430 _I2CS_INT_ST	=	0x00bb
                                    431 ;--------------------------------------------------------
                                    432 ; special function bits
                                    433 ;--------------------------------------------------------
                                    434 	.area RSEG    (ABS,DATA)
      000000                        435 	.org 0x0000
                           0000D7   436 _CY	=	0x00d7
                           0000D6   437 _AC	=	0x00d6
                           0000D5   438 _F0	=	0x00d5
                           0000D4   439 _RS1	=	0x00d4
                           0000D3   440 _RS0	=	0x00d3
                           0000D2   441 _OV	=	0x00d2
                           0000D1   442 _F1	=	0x00d1
                           0000D0   443 _P	=	0x00d0
                           0000AF   444 _EA	=	0x00af
                           0000AE   445 _E_DIS	=	0x00ae
                           0000AD   446 _ET2	=	0x00ad
                           0000AC   447 _ES	=	0x00ac
                           0000AB   448 _ET1	=	0x00ab
                           0000AA   449 _EX1	=	0x00aa
                           0000A9   450 _ET0	=	0x00a9
                           0000A8   451 _EX0	=	0x00a8
                           0000BF   452 _PH_FLAG	=	0x00bf
                           0000BE   453 _PL_FLAG	=	0x00be
                           0000BD   454 _PT2	=	0x00bd
                           0000BC   455 _PS	=	0x00bc
                           0000BB   456 _PT1	=	0x00bb
                           0000BA   457 _PX1	=	0x00ba
                           0000B9   458 _PT0	=	0x00b9
                           0000B8   459 _PX0	=	0x00b8
                           0000EF   460 _IE_WDOG	=	0x00ef
                           0000EE   461 _IE_GPIO	=	0x00ee
                           0000ED   462 _IE_PWM_I2C	=	0x00ed
                           0000EC   463 _IE_UART1	=	0x00ec
                           0000EB   464 _IE_ADC	=	0x00eb
                           0000E9   465 _IE_USB	=	0x00e9
                           0000E8   466 _IE_SPI0	=	0x00e8
                           000087   467 _P0_7	=	0x0087
                           000086   468 _P0_6	=	0x0086
                           000085   469 _P0_5	=	0x0085
                           000084   470 _P0_4	=	0x0084
                           000083   471 _P0_3	=	0x0083
                           000082   472 _P0_2	=	0x0082
                           000081   473 _P0_1	=	0x0081
                           000080   474 _P0_0	=	0x0080
                           000081   475 _SDA0	=	0x0081
                           000080   476 _SCL0	=	0x0080
                           000083   477 _TXD_	=	0x0083
                           000082   478 _RXD_	=	0x0082
                           000085   479 _AIN13	=	0x0085
                           000084   480 _AIN12	=	0x0084
                           000083   481 _AIN11	=	0x0083
                           000082   482 _AIN10	=	0x0082
                           000081   483 _AIN9	=	0x0081
                           000080   484 _AIN8	=	0x0080
                           000097   485 _P1_7	=	0x0097
                           000096   486 _P1_6	=	0x0096
                           000095   487 _P1_5	=	0x0095
                           000094   488 _P1_4	=	0x0094
                           000093   489 _P1_3	=	0x0093
                           000092   490 _P1_2	=	0x0092
                           000091   491 _P1_1	=	0x0091
                           000090   492 _P1_0	=	0x0090
                           000097   493 _TXD1_	=	0x0097
                           000096   494 _RXD1_	=	0x0096
                           000097   495 _SCK	=	0x0097
                           000096   496 _MISO	=	0x0096
                           000095   497 _MOSI	=	0x0095
                           000094   498 _SCS	=	0x0094
                           000092   499 _INT0_	=	0x0092
                           000091   500 _T2EX	=	0x0091
                           000091   501 _CAP2	=	0x0091
                           000090   502 _T2	=	0x0090
                           000090   503 _CAP1	=	0x0090
                           000097   504 _AIN7	=	0x0097
                           000096   505 _AIN6	=	0x0096
                           000095   506 _AIN5	=	0x0095
                           000094   507 _AIN4	=	0x0094
                           000093   508 _AIN3	=	0x0093
                           000092   509 _AIN2	=	0x0092
                           000091   510 _AIN1	=	0x0091
                           000090   511 _AIN0	=	0x0090
                           0000A7   512 _P2_7	=	0x00a7
                           0000A6   513 _P2_6	=	0x00a6
                           0000A5   514 _P2_5	=	0x00a5
                           0000A4   515 _P2_4	=	0x00a4
                           0000A3   516 _P2_3	=	0x00a3
                           0000A2   517 _P2_2	=	0x00a2
                           0000A1   518 _P2_1	=	0x00a1
                           0000A0   519 _P2_0	=	0x00a0
                           0000A7   520 _TXD1	=	0x00a7
                           0000A6   521 _RXD1	=	0x00a6
                           0000A5   522 _T2EX_	=	0x00a5
                           0000A5   523 _CAP2_	=	0x00a5
                           0000A4   524 _T2_	=	0x00a4
                           0000A4   525 _CAP1_	=	0x00a4
                           0000B7   526 _P3_7	=	0x00b7
                           0000B6   527 _P3_6	=	0x00b6
                           0000B5   528 _P3_5	=	0x00b5
                           0000B4   529 _P3_4	=	0x00b4
                           0000B3   530 _P3_3	=	0x00b3
                           0000B2   531 _P3_2	=	0x00b2
                           0000B1   532 _P3_1	=	0x00b1
                           0000B0   533 _P3_0	=	0x00b0
                           0000B7   534 _SCK1	=	0x00b7
                           0000B6   535 _MISO1	=	0x00b6
                           0000B5   536 _MOSI1	=	0x00b5
                           0000B5   537 _T1	=	0x00b5
                           0000B4   538 _T0	=	0x00b4
                           0000B3   539 _INT1	=	0x00b3
                           0000B2   540 _INT0	=	0x00b2
                           0000B1   541 _TXD	=	0x00b1
                           0000B0   542 _RXD	=	0x00b0
                           0000C6   543 _P4_6	=	0x00c6
                           0000C5   544 _P4_5	=	0x00c5
                           0000C4   545 _P4_4	=	0x00c4
                           0000C3   546 _P4_3	=	0x00c3
                           0000C2   547 _P4_2	=	0x00c2
                           0000C1   548 _P4_1	=	0x00c1
                           0000C0   549 _P4_0	=	0x00c0
                           00008F   550 _TF1	=	0x008f
                           00008E   551 _TR1	=	0x008e
                           00008D   552 _TF0	=	0x008d
                           00008C   553 _TR0	=	0x008c
                           00008B   554 _IE1	=	0x008b
                           00008A   555 _IT1	=	0x008a
                           000089   556 _IE0	=	0x0089
                           000088   557 _IT0	=	0x0088
                           00009F   558 _SM0	=	0x009f
                           00009E   559 _SM1	=	0x009e
                           00009D   560 _SM2	=	0x009d
                           00009C   561 _REN	=	0x009c
                           00009B   562 _TB8	=	0x009b
                           00009A   563 _RB8	=	0x009a
                           000099   564 _TI	=	0x0099
                           000098   565 _RI	=	0x0098
                           0000CF   566 _TF2	=	0x00cf
                           0000CF   567 _CAP1F	=	0x00cf
                           0000CE   568 _EXF2	=	0x00ce
                           0000CD   569 _RCLK	=	0x00cd
                           0000CC   570 _TCLK	=	0x00cc
                           0000CB   571 _EXEN2	=	0x00cb
                           0000CA   572 _TR2	=	0x00ca
                           0000C9   573 _C_T2	=	0x00c9
                           0000C8   574 _CP_RL2	=	0x00c8
                           0000FF   575 _S0_FST_ACT	=	0x00ff
                           0000FE   576 _S0_IF_OV	=	0x00fe
                           0000FD   577 _S0_IF_FIRST	=	0x00fd
                           0000FC   578 _S0_IF_BYTE	=	0x00fc
                           0000FB   579 _S0_FREE	=	0x00fb
                           0000FA   580 _S0_T_FIFO	=	0x00fa
                           0000F8   581 _S0_R_FIFO	=	0x00f8
                           0000F7   582 _ADC_START	=	0x00f7
                                    583 ;--------------------------------------------------------
                                    584 ; overlayable register banks
                                    585 ;--------------------------------------------------------
                                    586 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        587 	.ds 8
                                    588 ;--------------------------------------------------------
                                    589 ; internal ram data
                                    590 ;--------------------------------------------------------
                                    591 	.area DSEG    (DATA)
      000027                        592 _process_record_sloc0_1_0:
      000027                        593 	.ds 1
      000028                        594 _process_action_sloc0_1_0:
      000028                        595 	.ds 1
                                    596 ;--------------------------------------------------------
                                    597 ; overlayable items in internal ram
                                    598 ;--------------------------------------------------------
                                    599 ;--------------------------------------------------------
                                    600 ; indirectly addressable internal ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area ISEG    (DATA)
                                    603 ;--------------------------------------------------------
                                    604 ; absolute internal ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area IABS    (ABS,DATA)
                                    607 	.area IABS    (ABS,DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; bit data
                                    610 ;--------------------------------------------------------
                                    611 	.area BSEG    (BIT)
      00001F                        612 _process_action_sloc1_1_0:
      00001F                        613 	.ds 1
                                    614 ;--------------------------------------------------------
                                    615 ; paged external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area PSEG    (PAG,XDATA)
                                    618 ;--------------------------------------------------------
                                    619 ; uninitialized external ram data
                                    620 ;--------------------------------------------------------
                                    621 	.area XSEG    (XDATA)
      000860                        622 _tp_buttons::
      000860                        623 	.ds 2
      000862                        624 _action_exec_PARM_1:
      000862                        625 	.ds 6
      000868                        626 _action_exec_record_10001_629:
      000868                        627 	.ds 9
      000871                        628 _ak820_action_exec_event_10000_633:
      000871                        629 	.ds 2
      000873                        630 _ak820_action_exec_snapshot_10000_634:
      000873                        631 	.ds 6
      000879                        632 _process_record_record_argument_10000_637:
      000879                        633 	.ds 2
      00087B                        634 _process_record_handler_record_argument_10000_646:
      00087B                        635 	.ds 2
      00087D                        636 _process_record_handler_action_10000_647:
      00087D                        637 	.ds 2
      00087F                        638 _process_action_PARM_2:
      00087F                        639 	.ds 2
      000881                        640 _process_action_record_argument_10000_658:
      000881                        641 	.ds 2
      000883                        642 _process_action_on_40000_681:
      000883                        643 	.ds 1
      000884                        644 _register_code_code_10000_715:
      000884                        645 	.ds 1
      000885                        646 _unregister_code_code_10000_729:
      000885                        647 	.ds 1
      000886                        648 _tap_code_delay_PARM_2:
      000886                        649 	.ds 2
      000888                        650 _tap_code_delay_code_10000_742:
      000888                        651 	.ds 1
      000889                        652 _tap_code_code_10000_749:
      000889                        653 	.ds 1
      00088A                        654 _register_mods_mods_10000_751:
      00088A                        655 	.ds 1
      00088B                        656 _unregister_mods_mods_10000_755:
      00088B                        657 	.ds 1
      00088C                        658 _register_weak_mods_mods_10000_759:
      00088C                        659 	.ds 1
      00088D                        660 _unregister_weak_mods_mods_10000_763:
      00088D                        661 	.ds 1
                                    662 ;--------------------------------------------------------
                                    663 ; absolute external ram data
                                    664 ;--------------------------------------------------------
                                    665 	.area XABS    (ABS,XDATA)
                                    666 ;--------------------------------------------------------
                                    667 ; initialized external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XISEG   (XDATA)
      000DE6                        670 _disable_action_cache::
      000DE6                        671 	.ds 1
                                    672 	.area HOME    (CODE)
                                    673 	.area GSINIT0 (CODE)
                                    674 	.area GSINIT1 (CODE)
                                    675 	.area GSINIT2 (CODE)
                                    676 	.area GSINIT3 (CODE)
                                    677 	.area GSINIT4 (CODE)
                                    678 	.area GSINIT5 (CODE)
                                    679 	.area GSINIT  (CODE)
                                    680 	.area GSFINAL (CODE)
                                    681 	.area CSEG    (CODE)
                                    682 ;--------------------------------------------------------
                                    683 ; global & static initialisations
                                    684 ;--------------------------------------------------------
                                    685 	.area HOME    (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 	.area GSFINAL (CODE)
                                    688 	.area GSINIT  (CODE)
                                    689 ;--------------------------------------------------------
                                    690 ; Home
                                    691 ;--------------------------------------------------------
                                    692 	.area HOME    (CODE)
                                    693 	.area HOME    (CODE)
                                    694 ;--------------------------------------------------------
                                    695 ; code
                                    696 ;--------------------------------------------------------
                                    697 	.area CSEG    (CODE)
                                    698 ;------------------------------------------------------------
                                    699 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    700 ;------------------------------------------------------------
                                    701 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    702 ;------------------------------------------------------------
                                    703 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    704 ;	-----------------------------------------
                           000007   705 	ar7 = 0x07
                           000006   706 	ar6 = 0x06
                           000005   707 	ar5 = 0x05
                           000004   708 	ar4 = 0x04
                           000003   709 	ar3 = 0x03
                           000002   710 	ar2 = 0x02
                           000001   711 	ar1 = 0x01
                           000000   712 	ar0 = 0x00
                                    713 ;	 function action_exec
                                    714 ;	-----------------------------------------
      00730D                        715 _action_exec:
                                    716 ;	quantum/action.c:98: ak820_dynamic_macro_task(event.time);
      00730D 90 08 64         [24]  717 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007310 12 37 A0         [24]  718 	lcall	_ak820_outline_0004
      007313 12 3A E0         [24]  719 	lcall	_ak820_dynamic_macro_task
                                    720 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      007316 90 08 64         [24]  721 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007319 12 37 A0         [24]  722 	lcall	_ak820_outline_0004
      00731C 12 35 B8         [24]  723 	lcall	_ak820_combo_tick
                                    724 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      00731F 90 08 62         [24]  725 	mov	dptr,#_action_exec_PARM_1
      007322 12 47 67         [24]  726 	lcall	_ak820_tapping_before
      007325 E5 82            [12]  727 	mov	a, dpl
      007327 70 01            [24]  728 	jnz	00102$
      007329 22               [24]  729 	ret
      00732A                        730 00102$:
                                    731 ;	quantum/action.c:126: if (event.pressed) {
      00732A 90 08 67         [24]  732 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00732D E0               [24]  733 	movx	a,@dptr
      00732E 60 03            [24]  734 	jz	00104$
                                    735 ;	quantum/action.c:128: clear_weak_mods();
      007330 12 83 B5         [24]  736 	lcall	_clear_weak_mods
      007333                        737 00104$:
                                    738 ;	quantum/action.c:140: record.event = event;
      007333 90 0D C6         [24]  739 	mov	dptr,#___memcpy_PARM_2
      007336 74 62            [12]  740 	mov	a,#_action_exec_PARM_1
      007338 F0               [24]  741 	movx	@dptr,a
      007339 74 08            [12]  742 	mov	a,#(_action_exec_PARM_1 >> 8)
      00733B 12 7A 28         [24]  743 	lcall	_ak820_outline_0050
      00733E 12 7A 48         [24]  744 	lcall	_ak820_outline_0108
      007341 90 08 68         [24]  745 	mov	dptr,#_action_exec_record_10001_629
      007344 F5 F0            [12]  746 	mov	b,a
      007346 12 B9 ED         [24]  747 	lcall	___memcpy
                                    748 ;	quantum/action.c:142: record.tap.count = 0;
      007349 90 08 6E         [24]  749 	mov	dptr,#(_action_exec_record_10001_629 + 0x0006)
      00734C E0               [24]  750 	movx	a,@dptr
      00734D 54 0F            [12]  751 	anl	a,#0x0f
      00734F F0               [24]  752 	movx	@dptr,a
                                    753 ;	quantum/action.c:147: record.keycode = 0;
      007350 90 08 6F         [24]  754 	mov	dptr,#(_action_exec_record_10001_629 + 0x0007)
      007353 12 52 3D         [24]  755 	lcall	_ak820_outline_0178
                                    756 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007356 90 08 6C         [24]  757 	mov	dptr,#(_action_exec_record_10001_629 + 0x0004)
      007359 E0               [24]  758 	movx	a,@dptr
      00735A 60 0A            [24]  759 	jz	00107$
      00735C 90 08 68         [24]  760 	mov	dptr,#_action_exec_record_10001_629
      00735F 12 A1 17         [24]  761 	lcall	_pre_process_record_quantum
      007362 E5 82            [12]  762 	mov	a, dpl
      007364 60 11            [24]  763 	jz	00110$
      007366                        764 00107$:
                                    765 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      007366 90 08 68         [24]  766 	mov	dptr,#_action_exec_record_10001_629
      007369 12 48 53         [24]  767 	lcall	_ak820_tapping_process
      00736C E5 82            [12]  768 	mov	a, dpl
      00736E 70 01            [24]  769 	jnz	00106$
      007370 22               [24]  770 	ret
      007371                        771 00106$:
                                    772 ;	quantum/action.c:185: process_record(&record);
      007371 90 08 68         [24]  773 	mov	dptr,#_action_exec_record_10001_629
                                    774 ;	quantum/action.c:200: }
      007374 02 73 B5         [24]  775 	ljmp	_process_record
      007377                        776 00110$:
      007377 22               [24]  777 	ret
                                    778 ;------------------------------------------------------------
                                    779 ;Allocation info for local variables in function 'ak820_action_exec'
                                    780 ;------------------------------------------------------------
                                    781 ;event         Allocated with name '_ak820_action_exec_event_10000_633'
                                    782 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_634'
                                    783 ;------------------------------------------------------------
                                    784 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    785 ;	-----------------------------------------
                                    786 ;	 function ak820_action_exec
                                    787 ;	-----------------------------------------
      007378                        788 _ak820_action_exec:
      007378 12 38 4A         [24]  789 	lcall	_ak820_outline_0104
      00737B 90 08 71         [24]  790 	mov	dptr,#_ak820_action_exec_event_10000_633
      00737E 12 38 4F         [24]  791 	lcall	_ak820_outline_0105
                                    792 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007381 90 08 71         [24]  793 	mov	dptr,#_ak820_action_exec_event_10000_633
      007384 12 38 17         [24]  794 	lcall	_ak820_outline_0057
      007387 90 0D C6         [24]  795 	mov	dptr,#___memcpy_PARM_2
      00738A ED               [12]  796 	mov	a,r5
      00738B 12 37 DF         [24]  797 	lcall	_ak820_outline_0015
      00738E 90 0D C9         [24]  798 	mov	dptr,#___memcpy_PARM_3
      007391 12 7A 48         [24]  799 	lcall	_ak820_outline_0108
      007394 90 08 73         [24]  800 	mov	dptr,#_ak820_action_exec_snapshot_10000_634
      007397 F5 F0            [12]  801 	mov	b,a
      007399 12 B9 ED         [24]  802 	lcall	___memcpy
                                    803 ;	quantum/action.c:207: action_exec(snapshot);
      00739C 90 0D C6         [24]  804 	mov	dptr,#___memcpy_PARM_2
      00739F 74 73            [12]  805 	mov	a,#_ak820_action_exec_snapshot_10000_634
      0073A1 F0               [24]  806 	movx	@dptr,a
      0073A2 74 08            [12]  807 	mov	a,#(_ak820_action_exec_snapshot_10000_634 >> 8)
      0073A4 12 7A 28         [24]  808 	lcall	_ak820_outline_0050
      0073A7 12 7A 48         [24]  809 	lcall	_ak820_outline_0108
      0073AA 90 08 62         [24]  810 	mov	dptr,#_action_exec_PARM_1
      0073AD F5 F0            [12]  811 	mov	b,a
      0073AF 12 B9 ED         [24]  812 	lcall	___memcpy
                                    813 ;	quantum/action.c:208: }
      0073B2 02 73 0D         [24]  814 	ljmp	_action_exec
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'process_record_nocache'
                                    817 ;------------------------------------------------------------
                                    818 ;record        Allocated with name '_process_record_nocache_record_10000_635'
                                    819 ;------------------------------------------------------------
                                    820 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    821 ;	-----------------------------------------
                                    822 ;	 function process_record
                                    823 ;	-----------------------------------------
      0073B5                        824 _process_record:
      0073B5 12 38 4A         [24]  825 	lcall	_ak820_outline_0104
      0073B8 90 08 79         [24]  826 	mov	dptr,#_process_record_record_argument_10000_637
      0073BB 12 38 4F         [24]  827 	lcall	_ak820_outline_0105
                                    828 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0073BE 90 08 79         [24]  829 	mov	dptr,#_process_record_record_argument_10000_637
      0073C1 12 38 00         [24]  830 	lcall	_ak820_outline_0051
                                    831 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      0073C4 74 04            [12]  832 	mov	a,#0x04
      0073C6 12 4B 29         [24]  833 	lcall	_ak820_outline_0011
      0073C9 70 01            [24]  834 	jnz	00102$
                                    835 ;	quantum/action.c:354: return;
      0073CB 22               [24]  836 	ret
      0073CC                        837 00102$:
                                    838 ;	quantum/action.c:358: if (record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !ak820_macro_primitive &&
      0073CC 12 38 2B         [24]  839 	lcall	_ak820_outline_0075
      0073CF FD               [12]  840 	mov	r5,a
      0073D0 BD 10 00         [24]  841 	cjne	r5,#0x10,00192$
      0073D3                        842 00192$:
      0073D3 50 3D            [24]  843 	jnc	00104$
      0073D5 12 38 38         [24]  844 	lcall	_ak820_outline_0093
      0073D8 FD               [12]  845 	mov	r5,a
      0073D9 BD 08 00         [24]  846 	cjne	r5,#0x08,00194$
      0073DC                        847 00194$:
      0073DC 50 34            [24]  848 	jnc	00104$
      0073DE 90 09 D2         [24]  849 	mov	dptr,#_ak820_macro_primitive
      0073E1 E0               [24]  850 	movx	a,@dptr
      0073E2 70 2E            [24]  851 	jnz	00104$
                                    852 ;	quantum/action.c:359: !ak820_dynamic_macro_process(get_record_keycode(record, true), record->event.pressed)) return;
      0073E4 90 0C 28         [24]  853 	mov	dptr,#_get_record_keycode_PARM_2
      0073E7 12 4B 68         [24]  854 	lcall	_ak820_outline_0043
      0073EA C0 07            [24]  855 	push	ar7
      0073EC C0 06            [24]  856 	push	ar6
      0073EE 12 A0 D9         [24]  857 	lcall	_get_record_keycode
      0073F1 12 46 83         [24]  858 	lcall	_ak820_outline_0141
      0073F4 D0 06            [24]  859 	pop	ar6
      0073F6 D0 07            [24]  860 	pop	ar7
      0073F8 12 46 07         [24]  861 	lcall	_ak820_outline_0009
      0073FB E0               [24]  862 	movx	a,@dptr
      0073FC 90 04 AA         [24]  863 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      0073FF 12 38 3E         [24]  864 	lcall	_ak820_outline_0098
      007402 C0 07            [24]  865 	push	ar7
      007404 C0 06            [24]  866 	push	ar6
      007406 12 39 47         [24]  867 	lcall	_ak820_dynamic_macro_process
      007409 E5 82            [12]  868 	mov	a, dpl
      00740B D0 06            [24]  869 	pop	ar6
      00740D D0 07            [24]  870 	pop	ar7
      00740F 70 01            [24]  871 	jnz	00104$
      007411 22               [24]  872 	ret
      007412                        873 00104$:
                                    874 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007412 8E 04            [24]  875 	mov	ar4,r6
      007414 8F 05            [24]  876 	mov	ar5,r7
      007416 90 0D C6         [24]  877 	mov	dptr,#___memcpy_PARM_2
      007419 EC               [12]  878 	mov	a,r4
      00741A F0               [24]  879 	movx	@dptr,a
      00741B ED               [12]  880 	mov	a,r5
      00741C 12 7A 28         [24]  881 	lcall	_ak820_outline_0050
      00741F 12 52 2F         [24]  882 	lcall	_ak820_outline_0107
      007422 90 06 76         [24]  883 	mov	dptr,#_ak820_tapping_source_PARM_1
      007425 F5 F0            [12]  884 	mov	b,a
      007427 C0 07            [24]  885 	push	ar7
      007429 C0 06            [24]  886 	push	ar6
      00742B 12 B9 ED         [24]  887 	lcall	___memcpy
      00742E 12 46 A3         [24]  888 	lcall	_ak820_tapping_source
      007431 AD 82            [24]  889 	mov	r5, dpl
      007433 D0 06            [24]  890 	pop	ar6
      007435 D0 07            [24]  891 	pop	ar7
                                    892 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      007437 12 46 07         [24]  893 	lcall	_ak820_outline_0009
      00743A E0               [24]  894 	movx	a,@dptr
      00743B FC               [12]  895 	mov	r4,a
                                    896 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      00743C 74 07            [12]  897 	mov	a,#0x07
      00743E 2E               [12]  898 	add	a, r6
      00743F FA               [12]  899 	mov	r2,a
      007440 E4               [12]  900 	clr	a
      007441 3F               [12]  901 	addc	a, r7
      007442 FB               [12]  902 	mov	r3,a
      007443 90 0C 28         [24]  903 	mov	dptr,#_get_record_keycode_PARM_2
      007446 12 4B 68         [24]  904 	lcall	_ak820_outline_0043
      007449 C0 07            [24]  905 	push	ar7
      00744B C0 06            [24]  906 	push	ar6
      00744D C0 05            [24]  907 	push	ar5
      00744F C0 04            [24]  908 	push	ar4
      007451 C0 03            [24]  909 	push	ar3
      007453 C0 02            [24]  910 	push	ar2
      007455 12 A0 D9         [24]  911 	lcall	_get_record_keycode
      007458 A8 82            [24]  912 	mov	r0, dpl
      00745A A9 83            [24]  913 	mov	r1, dph
      00745C D0 02            [24]  914 	pop	ar2
      00745E D0 03            [24]  915 	pop	ar3
      007460 D0 04            [24]  916 	pop	ar4
      007462 D0 05            [24]  917 	pop	ar5
      007464 D0 06            [24]  918 	pop	ar6
      007466 D0 07            [24]  919 	pop	ar7
      007468 12 46 7E         [24]  920 	lcall	_ak820_outline_0140
      00746B E8               [12]  921 	mov	a,r0
      00746C F0               [24]  922 	movx	@dptr,a
      00746D E9               [12]  923 	mov	a,r1
      00746E A3               [24]  924 	inc	dptr
      00746F F0               [24]  925 	movx	@dptr,a
                                    926 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007470 74 07            [12]  927 	mov	a,#0x07
      007472 12 37 E7         [24]  928 	lcall	_ak820_outline_0016
      007475 FA               [12]  929 	mov	r2,a
      007476 A3               [24]  930 	inc	dptr
      007477 E0               [24]  931 	movx	a,@dptr
      007478 FB               [12]  932 	mov	r3,a
      007479 90 06 86         [24]  933 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00747C ED               [12]  934 	mov	a,r5
      00747D F0               [24]  935 	movx	@dptr,a
      00747E 90 06 87         [24]  936 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007481 EC               [12]  937 	mov	a,r4
      007482 F0               [24]  938 	movx	@dptr,a
      007483 12 46 7E         [24]  939 	lcall	_ak820_outline_0140
      007486 C0 07            [24]  940 	push	ar7
      007488 C0 06            [24]  941 	push	ar6
      00748A C0 05            [24]  942 	push	ar5
      00748C C0 04            [24]  943 	push	ar4
      00748E 12 49 F3         [24]  944 	lcall	_ak820_oneshot_process
      007491 E5 82            [12]  945 	mov	a, dpl
      007493 D0 04            [24]  946 	pop	ar4
      007495 D0 05            [24]  947 	pop	ar5
      007497 D0 06            [24]  948 	pop	ar6
      007499 D0 07            [24]  949 	pop	ar7
      00749B 70 01            [24]  950 	jnz	00109$
      00749D 22               [24]  951 	ret
      00749E                        952 00109$:
                                    953 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      00749E 12 46 62         [24]  954 	lcall	_ak820_outline_0116
      0074A1 C0 07            [24]  955 	push	ar7
      0074A3 C0 06            [24]  956 	push	ar6
      0074A5 C0 05            [24]  957 	push	ar5
      0074A7 C0 04            [24]  958 	push	ar4
      0074A9 12 A1 59         [24]  959 	lcall	_process_record_quantum
      0074AC E5 82            [12]  960 	mov	a, dpl
      0074AE D0 04            [24]  961 	pop	ar4
      0074B0 D0 05            [24]  962 	pop	ar5
      0074B2 D0 06            [24]  963 	pop	ar6
      0074B4 D0 07            [24]  964 	pop	ar7
      0074B6 70 0A            [24]  965 	jnz	00111$
                                    966 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0074B8 90 05 EE         [24]  967 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0074BB EC               [12]  968 	mov	a,r4
      0074BC F0               [24]  969 	movx	@dptr,a
      0074BD 8D 82            [24]  970 	mov	dpl, r5
                                    971 ;	quantum/action.c:376: return;
      0074BF 02 2E BB         [24]  972 	ljmp	_ak820_oneshot_post
      0074C2                        973 00111$:
                                    974 ;	quantum/action.c:380: ak820_dynamic_macro_source = record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !get_repeat_key_count() && !ak820_macro_primitive;
      0074C2 12 38 2B         [24]  975 	lcall	_ak820_outline_0075
      0074C5 FB               [12]  976 	mov	r3,a
      0074C6 BB 10 00         [24]  977 	cjne	r3,#0x10,00200$
      0074C9                        978 00200$:
      0074C9 50 16            [24]  979 	jnc	00114$
      0074CB 12 38 38         [24]  980 	lcall	_ak820_outline_0093
      0074CE FB               [12]  981 	mov	r3,a
      0074CF BB 08 00         [24]  982 	cjne	r3,#0x08,00202$
      0074D2                        983 00202$:
      0074D2 50 0D            [24]  984 	jnc	00114$
      0074D4 12 A3 E1         [24]  985 	lcall	_get_repeat_key_count
      0074D7 E5 82            [12]  986 	mov	a, dpl
      0074D9 70 06            [24]  987 	jnz	00114$
      0074DB 90 09 D2         [24]  988 	mov	dptr,#_ak820_macro_primitive
      0074DE E0               [24]  989 	movx	a,@dptr
      0074DF 60 05            [24]  990 	jz	00115$
      0074E1                        991 00114$:
      0074E1 75 27 00         [24]  992 	mov	_process_record_sloc0_1_0,#0x00
      0074E4 80 03            [24]  993 	sjmp	00116$
      0074E6                        994 00115$:
      0074E6 75 27 01         [24]  995 	mov	_process_record_sloc0_1_0,#0x01
      0074E9                        996 00116$:
      0074E9 90 04 A9         [24]  997 	mov	dptr,#_ak820_dynamic_macro_source
      0074EC E5 27            [12]  998 	mov	a,_process_record_sloc0_1_0
      0074EE 12 46 3D         [24]  999 	lcall	_ak820_outline_0060
                                   1000 ;	quantum/action.c:382: process_record_handler(record);
      0074F1 C0 05            [24] 1001 	push	ar5
      0074F3 C0 04            [24] 1002 	push	ar4
      0074F5 12 75 0B         [24] 1003 	lcall	_process_record_handler
      0074F8 D0 04            [24] 1004 	pop	ar4
      0074FA D0 05            [24] 1005 	pop	ar5
                                   1006 ;	quantum/action.c:384: ak820_dynamic_macro_source = false;
      0074FC 90 04 A9         [24] 1007 	mov	dptr,#_ak820_dynamic_macro_source
      0074FF E4               [12] 1008 	clr	a
      007500 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007501 90 05 EE         [24] 1011 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007504 EC               [12] 1012 	mov	a,r4
      007505 F0               [24] 1013 	movx	@dptr,a
      007506 8D 82            [24] 1014 	mov	dpl, r5
                                   1015 ;	quantum/action.c:392: }
      007508 02 2E BB         [24] 1016 	ljmp	_ak820_oneshot_post
                                   1017 ;------------------------------------------------------------
                                   1018 ;Allocation info for local variables in function 'process_record_handler'
                                   1019 ;------------------------------------------------------------
                                   1020 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_646'
                                   1021 ;record        Allocated with name '_process_record_handler_record_10000_647'
                                   1022 ;action        Allocated with name '_process_record_handler_action_10000_647'
                                   1023 ;------------------------------------------------------------
                                   1024 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1025 ;	-----------------------------------------
                                   1026 ;	 function process_record_handler
                                   1027 ;	-----------------------------------------
      00750B                       1028 _process_record_handler:
      00750B 12 38 4A         [24] 1029 	lcall	_ak820_outline_0104
      00750E 90 08 7B         [24] 1030 	mov	dptr,#_process_record_handler_record_argument_10000_646
      007511 12 38 4F         [24] 1031 	lcall	_ak820_outline_0105
                                   1032 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007514 90 08 7B         [24] 1033 	mov	dptr,#_process_record_handler_record_argument_10000_646
      007517 12 37 B7         [24] 1034 	lcall	_ak820_outline_0008
                                   1035 ;	quantum/action.c:405: if (record->keycode) {
      00751A 4C               [12] 1036 	orl	a,r4
      00751B 60 19            [24] 1037 	jz	00102$
                                   1038 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      00751D 12 38 60         [24] 1039 	lcall	_ak820_outline_0121
      007520 C0 07            [24] 1040 	push	ar7
      007522 C0 06            [24] 1041 	push	ar6
      007524 12 97 A9         [24] 1042 	lcall	_action_for_keycode
      007527 12 46 83         [24] 1043 	lcall	_ak820_outline_0141
      00752A D0 06            [24] 1044 	pop	ar6
      00752C D0 07            [24] 1045 	pop	ar7
      00752E 90 08 7D         [24] 1046 	mov	dptr,#_process_record_handler_action_10000_647
      007531 12 38 25         [24] 1047 	lcall	_ak820_outline_0070
      007534 80 2B            [24] 1048 	sjmp	00104$
      007536                       1049 00102$:
                                   1050 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007536 12 7A 10         [24] 1051 	lcall	_ak820_outline_0019
      007539 7A 00            [12] 1052 	mov	r2,#0x00
      00753B 12 46 78         [24] 1053 	lcall	_ak820_outline_0139
      00753E 12 46 07         [24] 1054 	lcall	_ak820_outline_0009
      007541 E0               [24] 1055 	movx	a,@dptr
      007542 90 09 B8         [24] 1056 	mov	dptr,#_ak820_resolve_key_PARM_2
      007545 F0               [24] 1057 	movx	@dptr,a
      007546 8D 82            [24] 1058 	mov	dpl, r5
      007548 8C 83            [24] 1059 	mov	dph, r4
      00754A C0 07            [24] 1060 	push	ar7
      00754C C0 06            [24] 1061 	push	ar6
      00754E 12 7D B2         [24] 1062 	lcall	_ak820_resolve_key
      007551 12 97 A9         [24] 1063 	lcall	_action_for_keycode
      007554 12 46 83         [24] 1064 	lcall	_ak820_outline_0141
      007557 D0 06            [24] 1065 	pop	ar6
      007559 D0 07            [24] 1066 	pop	ar7
      00755B 90 08 7D         [24] 1067 	mov	dptr,#_process_record_handler_action_10000_647
      00755E 12 38 25         [24] 1068 	lcall	_ak820_outline_0070
                                   1069 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      007561                       1070 00104$:
                                   1071 ;	quantum/action.c:429: process_action(record, action);
      007561 90 0D C6         [24] 1072 	mov	dptr,#___memcpy_PARM_2
      007564 74 7D            [12] 1073 	mov	a,#_process_record_handler_action_10000_647
      007566 F0               [24] 1074 	movx	@dptr,a
      007567 74 08            [12] 1075 	mov	a,#(_process_record_handler_action_10000_647 >> 8)
      007569 12 7A 28         [24] 1076 	lcall	_ak820_outline_0050
      00756C 12 52 2F         [24] 1077 	lcall	_ak820_outline_0107
      00756F 90 08 7F         [24] 1078 	mov	dptr,#_process_action_PARM_2
      007572 F5 F0            [12] 1079 	mov	b,a
      007574 C0 07            [24] 1080 	push	ar7
      007576 C0 06            [24] 1081 	push	ar6
      007578 12 B9 ED         [24] 1082 	lcall	___memcpy
      00757B D0 06            [24] 1083 	pop	ar6
      00757D D0 07            [24] 1084 	pop	ar7
      00757F 12 46 62         [24] 1085 	lcall	_ak820_outline_0116
                                   1086 ;	quantum/action.c:430: }
      007582 02 75 85         [24] 1087 	ljmp	_process_action
                                   1088 ;------------------------------------------------------------
                                   1089 ;Allocation info for local variables in function 'register_mouse'
                                   1090 ;------------------------------------------------------------
                                   1091 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1092 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_655'
                                   1093 ;------------------------------------------------------------
                                   1094 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1095 ;	-----------------------------------------
                                   1096 ;	 function process_action
                                   1097 ;	-----------------------------------------
      007585                       1098 _process_action:
      007585 12 38 4A         [24] 1099 	lcall	_ak820_outline_0104
      007588 90 08 81         [24] 1100 	mov	dptr,#_process_action_record_argument_10000_658
      00758B 12 38 4F         [24] 1101 	lcall	_ak820_outline_0105
                                   1102 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00758E 90 08 81         [24] 1103 	mov	dptr,#_process_action_record_argument_10000_658
      007591 12 37 A0         [24] 1104 	lcall	_ak820_outline_0004
                                   1105 ;	quantum/action.c:501: pressed = record->event.pressed;
      007594 A3               [24] 1106 	inc	dptr
      007595 A3               [24] 1107 	inc	dptr
      007596 A3               [24] 1108 	inc	dptr
      007597 A3               [24] 1109 	inc	dptr
      007598 A3               [24] 1110 	inc	dptr
      007599 E0               [24] 1111 	movx	a,@dptr
      00759A F5 28            [12] 1112 	mov	_process_action_sloc0_1_0,a
                                   1113 ;	quantum/action.c:525: switch (action.kind.id) {
      00759C 90 08 80         [24] 1114 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00759F E0               [24] 1115 	movx	a,@dptr
      0075A0 C4               [12] 1116 	swap	a
      0075A1 54 0F            [12] 1117 	anl	a,#0x0f
      0075A3 FD               [12] 1118 	mov  r5,a
      0075A4 24 F4            [12] 1119 	add	a,#0xff - 0x0b
      0075A6 50 03            [24] 1120 	jnc	00434$
      0075A8 02 78 26         [24] 1121 	ljmp	00181$
      0075AB                       1122 00434$:
                                   1123 ;	free result
      0075AB ED               [12] 1124 	mov	a,r5
      0075AC 24 0A            [12] 1125 	add	a,#(00435$-3-.)
      0075AE 83               [24] 1126 	movc	a,@a+pc
      0075AF F5 82            [12] 1127 	mov	dpl,a
      0075B1 ED               [12] 1128 	mov	a,r5
      0075B2 24 10            [12] 1129 	add	a,#(00436$-3-.)
      0075B4 83               [24] 1130 	movc	a,@a+pc
      0075B5 F5 83            [12] 1131 	mov	dph,a
      0075B7 E4               [12] 1132 	clr	a
      0075B8 73               [24] 1133 	jmp	@a+dptr
      0075B9                       1134 00435$:
      0075B9 D1                    1135 	.db	00102$
      0075BA D1                    1136 	.db	00102$
      0075BB 26                    1137 	.db	00181$
      0075BC 26                    1138 	.db	00181$
      0075BD 5B                    1139 	.db	00123$
      0075BE 26                    1140 	.db	00181$
      0075BF 26                    1141 	.db	00181$
      0075C0 26                    1142 	.db	00181$
      0075C1 BB                    1143 	.db	00131$
      0075C2 8D                    1144 	.db	00147$
      0075C3 B3                    1145 	.db	00152$
      0075C4 B3                    1146 	.db	00152$
      0075C5                       1147 00436$:
      0075C5 75                    1148 	.db	00102$>>8
      0075C6 75                    1149 	.db	00102$>>8
      0075C7 78                    1150 	.db	00181$>>8
      0075C8 78                    1151 	.db	00181$>>8
      0075C9 76                    1152 	.db	00123$>>8
      0075CA 78                    1153 	.db	00181$>>8
      0075CB 78                    1154 	.db	00181$>>8
      0075CC 78                    1155 	.db	00181$>>8
      0075CD 76                    1156 	.db	00131$>>8
      0075CE 77                    1157 	.db	00147$>>8
      0075CF 77                    1158 	.db	00152$>>8
      0075D0 77                    1159 	.db	00152$>>8
                                   1160 ;	quantum/action.c:528: case ACT_RMODS: {
      0075D1                       1161 00102$:
                                   1162 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0075D1 90 08 80         [24] 1163 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0075D4 E0               [24] 1164 	movx	a,@dptr
      0075D5 54 F0            [12] 1165 	anl	a,#0xf0
      0075D7 70 06            [24] 1166 	jnz	00194$
      0075D9 12 7A 4F         [24] 1167 	lcall	_ak820_outline_0109
      0075DC FD               [12] 1168 	mov	r5,a
      0075DD 80 07            [24] 1169 	sjmp	00195$
      0075DF                       1170 00194$:
      0075DF 12 7A 4F         [24] 1171 	lcall	_ak820_outline_0109
      0075E2 C4               [12] 1172 	swap	a
      0075E3 54 F0            [12] 1173 	anl	a,#0xf0
      0075E5 FD               [12] 1174 	mov	r5,a
      0075E6                       1175 00195$:
                                   1176 ;	quantum/action.c:531: if (pressed) {
      0075E6 E5 28            [12] 1177 	mov	a,_process_action_sloc0_1_0
      0075E8 60 35            [24] 1178 	jz	00119$
                                   1179 ;	quantum/action.c:532: if (mods) {
      0075EA ED               [12] 1180 	mov	a,r5
      0075EB 60 29            [24] 1181 	jz	00110$
                                   1182 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0075ED 12 7A 61         [24] 1183 	lcall	_ak820_outline_0154
      0075F0 FC               [12] 1184 	mov	r4,a
      0075F1 BC E0 00         [24] 1185 	cjne	r4,#0xe0,00440$
      0075F4                       1186 00440$:
      0075F4 40 07            [24] 1187 	jc	00108$
      0075F6 12 7A 61         [24] 1188 	lcall	_ak820_outline_0154
      0075F9 24 18            [12] 1189 	add	a,#0xff - 0xe7
      0075FB 50 0A            [24] 1190 	jnc	00104$
                                   1191 ;	free result
      0075FD                       1192 00108$:
      0075FD 7B 7F            [12] 1193 	mov	r3,#_process_action_PARM_2
      0075FF 7C 08            [12] 1194 	mov	r4,#(_process_action_PARM_2 >> 8)
      007601 12 33 FC         [24] 1195 	lcall	_ak820_outline_0122
      007604 E0               [24] 1196 	movx	a,@dptr
      007605 70 07            [24] 1197 	jnz	00105$
      007607                       1198 00104$:
                                   1199 ;	quantum/action.c:537: add_owned_mods(mods);
      007607 8D 82            [24] 1200 	mov	dpl, r5
      007609 12 7F CC         [24] 1201 	lcall	_add_owned_mods
      00760C 80 05            [24] 1202 	sjmp	00106$
      00760E                       1203 00105$:
                                   1204 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      00760E 8D 82            [24] 1205 	mov	dpl, r5
      007610 12 7F EA         [24] 1206 	lcall	_add_owned_weak_mods
      007613                       1207 00106$:
                                   1208 ;	quantum/action.c:541: send_keyboard_report();
      007613 12 83 05         [24] 1209 	lcall	_send_keyboard_report
      007616                       1210 00110$:
                                   1211 ;	quantum/action.c:543: register_code(action.key.code);
      007616 12 7A 38         [24] 1212 	lcall	_ak820_outline_0076
      007619 12 78 3D         [24] 1213 	lcall	_register_code
      00761C 02 78 26         [24] 1214 	ljmp	00181$
      00761F                       1215 00119$:
                                   1216 ;	quantum/action.c:545: unregister_code(action.key.code);
      00761F 12 7A 38         [24] 1217 	lcall	_ak820_outline_0076
      007622 C0 05            [24] 1218 	push	ar5
      007624 12 78 B9         [24] 1219 	lcall	_unregister_code
      007627 D0 05            [24] 1220 	pop	ar5
                                   1221 ;	quantum/action.c:546: if (mods) {
      007629 ED               [12] 1222 	mov	a,r5
      00762A 70 03            [24] 1223 	jnz	00444$
      00762C 02 78 26         [24] 1224 	ljmp	00181$
      00762F                       1225 00444$:
                                   1226 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00762F 12 7A 61         [24] 1227 	lcall	_ak820_outline_0154
      007632 FC               [12] 1228 	mov	r4,a
      007633 BC E0 00         [24] 1229 	cjne	r4,#0xe0,00445$
      007636                       1230 00445$:
      007636 40 07            [24] 1231 	jc	00115$
      007638 12 7A 61         [24] 1232 	lcall	_ak820_outline_0154
      00763B 24 18            [12] 1233 	add	a,#0xff - 0xe7
      00763D 50 0A            [24] 1234 	jnc	00111$
                                   1235 ;	free result
      00763F                       1236 00115$:
      00763F 7B 7F            [12] 1237 	mov	r3,#_process_action_PARM_2
      007641 7C 08            [12] 1238 	mov	r4,#(_process_action_PARM_2 >> 8)
      007643 12 33 FC         [24] 1239 	lcall	_ak820_outline_0122
      007646 E0               [24] 1240 	movx	a,@dptr
      007647 70 07            [24] 1241 	jnz	00112$
      007649                       1242 00111$:
                                   1243 ;	quantum/action.c:548: del_owned_mods(mods);
      007649 8D 82            [24] 1244 	mov	dpl, r5
      00764B 12 7F DC         [24] 1245 	lcall	_del_owned_mods
      00764E 80 05            [24] 1246 	sjmp	00113$
      007650                       1247 00112$:
                                   1248 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      007650 8D 82            [24] 1249 	mov	dpl, r5
      007652 12 7F FA         [24] 1250 	lcall	_del_owned_weak_mods
      007655                       1251 00113$:
                                   1252 ;	quantum/action.c:552: send_keyboard_report();
      007655 12 83 05         [24] 1253 	lcall	_send_keyboard_report
                                   1254 ;	quantum/action.c:555: } break;
      007658 02 78 26         [24] 1255 	ljmp	00181$
                                   1256 ;	quantum/action.c:632: case ACT_USAGE:
      00765B                       1257 00123$:
                                   1258 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      00765B 74 07            [12] 1259 	mov	a,#0x07
      00765D 12 37 F0         [24] 1260 	lcall	_ak820_outline_0030
      007660 12 37 CB         [24] 1261 	lcall	_ak820_outline_0010
      007663 C3               [12] 1262 	clr	c
      007664 EC               [12] 1263 	mov	a,r4
      007665 94 A5            [12] 1264 	subb	a,#0xa5
      007667 ED               [12] 1265 	mov	a,r5
      007668 94 00            [12] 1266 	subb	a,#0x00
      00766A 40 15            [24] 1267 	jc	00125$
      00766C 74 C2            [12] 1268 	mov	a,#0xc2
      00766E 9C               [12] 1269 	subb	a,r4
      00766F E4               [12] 1270 	clr	a
      007670 9D               [12] 1271 	subb	a,r5
      007671 40 0E            [24] 1272 	jc	00125$
                                   1273 ;	free result
                                   1274 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      007673 90 0A DF         [24] 1275 	mov	dptr,#_owned_usage_key_PARM_2
      007676 E5 28            [12] 1276 	mov	a,_process_action_sloc0_1_0
      007678 F0               [24] 1277 	movx	@dptr,a
      007679 8E 82            [24] 1278 	mov	dpl, r6
      00767B 12 81 B0         [24] 1279 	lcall	_owned_usage_key
                                   1280 ;	quantum/action.c:640: break;
      00767E 02 78 26         [24] 1281 	ljmp	00181$
      007681                       1282 00125$:
                                   1283 ;	quantum/action.c:643: switch (action.usage.page) {
      007681 12 7A 3F         [24] 1284 	lcall	_ak820_outline_0086
      007684 FF               [12] 1285 	mov	r7,a
      007685 60 08            [24] 1286 	jz	00127$
      007687 BF 01 02         [24] 1287 	cjne	r7,#0x01,00452$
      00768A 80 19            [24] 1288 	sjmp	00128$
      00768C                       1289 00452$:
      00768C 02 78 26         [24] 1290 	ljmp	00181$
                                   1291 ;	quantum/action.c:644: case PAGE_SYSTEM:
      00768F                       1292 00127$:
                                   1293 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      00768F E5 28            [12] 1294 	mov	a,_process_action_sloc0_1_0
      007691 60 05            [24] 1295 	jz	00196$
      007693 12 7A 56         [24] 1296 	lcall	_ak820_outline_0129
      007696 80 04            [24] 1297 	sjmp	00197$
      007698                       1298 00196$:
      007698 7E 00            [12] 1299 	mov	r6,#0x00
      00769A 7F 00            [12] 1300 	mov	r7,#0x00
      00769C                       1301 00197$:
      00769C 12 46 62         [24] 1302 	lcall	_ak820_outline_0116
      00769F 12 70 06         [24] 1303 	lcall	_host_system_send
                                   1304 ;	quantum/action.c:646: break;
      0076A2 02 78 26         [24] 1305 	ljmp	00181$
                                   1306 ;	quantum/action.c:647: case PAGE_CONSUMER:
      0076A5                       1307 00128$:
                                   1308 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      0076A5 E5 28            [12] 1309 	mov	a,_process_action_sloc0_1_0
      0076A7 60 05            [24] 1310 	jz	00198$
      0076A9 12 7A 56         [24] 1311 	lcall	_ak820_outline_0129
      0076AC 80 04            [24] 1312 	sjmp	00199$
      0076AE                       1313 00198$:
      0076AE 7E 00            [12] 1314 	mov	r6,#0x00
      0076B0 7F 00            [12] 1315 	mov	r7,#0x00
      0076B2                       1316 00199$:
      0076B2 12 46 62         [24] 1317 	lcall	_ak820_outline_0116
      0076B5 12 70 36         [24] 1318 	lcall	_host_consumer_send
                                   1319 ;	quantum/action.c:651: break;
      0076B8 02 78 26         [24] 1320 	ljmp	00181$
                                   1321 ;	quantum/action.c:658: case ACT_LAYER: {
      0076BB                       1322 00131$:
                                   1323 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      0076BB 90 08 80         [24] 1324 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076BE E0               [24] 1325 	movx	a,@dptr
      0076BF 54 03            [12] 1326 	anl	a,#0x03
      0076C1 90 08 83         [24] 1327 	mov	dptr,#_process_action_on_40000_681
      0076C4 F0               [24] 1328 	movx	@dptr,a
                                   1329 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0076C5 E0               [24] 1330 	movx	a,@dptr
      0076C6 FF               [12] 1331 	mov	r7,a
      0076C7 60 11            [24] 1332 	jz	00200$
      0076C9 E5 28            [12] 1333 	mov	a,_process_action_sloc0_1_0
      0076CB 60 07            [24] 1334 	jz	00202$
      0076CD 8F 06            [24] 1335 	mov	ar6,r7
      0076CF 53 06 01         [24] 1336 	anl	ar6,#0x01
      0076D2 80 10            [24] 1337 	sjmp	00201$
      0076D4                       1338 00202$:
      0076D4 74 02            [12] 1339 	mov	a,#0x02
      0076D6 5F               [12] 1340 	anl	a,r7
      0076D7 FE               [12] 1341 	mov	r6,a
      0076D8 80 0A            [24] 1342 	sjmp	00201$
      0076DA                       1343 00200$:
      0076DA E5 28            [12] 1344 	mov	a,_process_action_sloc0_1_0
      0076DC B4 01 00         [24] 1345 	cjne	a,#0x01,00457$
      0076DF                       1346 00457$:
      0076DF 92 1F            [24] 1347 	mov  _process_action_sloc1_1_0,c
      0076E1 E4               [12] 1348 	clr	a
      0076E2 33               [12] 1349 	rlc	a
      0076E3 FE               [12] 1350 	mov	r6,a
      0076E4                       1351 00201$:
      0076E4 EE               [12] 1352 	mov	a,r6
      0076E5 70 03            [24] 1353 	jnz	00458$
      0076E7 02 78 26         [24] 1354 	ljmp	00181$
      0076EA                       1355 00458$:
                                   1356 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      0076EA 12 7A 61         [24] 1357 	lcall	_ak820_outline_0154
      0076ED C4               [12] 1358 	swap	a
      0076EE 03               [12] 1359 	rr	a
      0076EF 54 07            [12] 1360 	anl	a,#0x07
      0076F1 25 E0            [12] 1361 	add	a,acc
      0076F3 25 E0            [12] 1362 	add	a,acc
      0076F5 FF               [12] 1363 	mov	r7,a
                                   1364 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0076F6 12 7A 61         [24] 1365 	lcall	_ak820_outline_0154
      0076F9 54 0F            [12] 1366 	anl	a,#0x0f
      0076FB FE               [12] 1367 	mov	r6,a
      0076FC 8F F0            [24] 1368 	mov	b,r7
      0076FE 05 F0            [12] 1369 	inc	b
      007700 EE               [12] 1370 	mov	a,r6
      007701 80 02            [24] 1371 	sjmp	00460$
      007703                       1372 00459$:
      007703 25 E0            [12] 1373 	add	a,acc
      007705                       1374 00460$:
      007705 D5 F0 FB         [24] 1375 	djnz	b,00459$
      007708 FE               [12] 1376 	mov	r6,a
                                   1377 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007709 12 7A 61         [24] 1378 	lcall	_ak820_outline_0154
      00770C 30 E4 11         [24] 1379 	jnb	acc.4,00204$
      00770F 8F F0            [24] 1380 	mov	b,r7
      007711 05 F0            [12] 1381 	inc	b
      007713 74 0F            [12] 1382 	mov	a,#0x0f
      007715 80 02            [24] 1383 	sjmp	00463$
      007717                       1384 00462$:
      007717 25 E0            [12] 1385 	add	a,acc
      007719                       1386 00463$:
      007719 D5 F0 FB         [24] 1387 	djnz	b,00462$
      00771C F4               [12] 1388 	cpl	a
      00771D FF               [12] 1389 	mov	r7,a
      00771E 80 02            [24] 1390 	sjmp	00205$
      007720                       1391 00204$:
      007720 7F 00            [12] 1392 	mov	r7,#0x00
      007722                       1393 00205$:
                                   1394 ;	quantum/action.c:666: bits |= mask;
      007722 EE               [12] 1395 	mov	a,r6
      007723 42 07            [12] 1396 	orl	ar7,a
                                   1397 ;	quantum/action.c:667: if (!on) {
      007725 90 08 83         [24] 1398 	mov	dptr,#_process_action_on_40000_681
      007728 E0               [24] 1399 	movx	a,@dptr
      007729 70 31            [24] 1400 	jnz	00143$
                                   1401 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      00772B 12 7A 3F         [24] 1402 	lcall	_ak820_outline_0086
      00772E FE               [12] 1403 	mov	r6,a
      00772F 2E               [12] 1404 	add	a,r6
                                   1405 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      007730 90 77 34         [24] 1406 	mov	dptr,#00465$
      007733 73               [24] 1407 	jmp	@a+dptr
      007734                       1408 00465$:
      007734 80 06            [24] 1409 	sjmp	00132$
      007736 80 0C            [24] 1410 	sjmp	00133$
      007738 80 12            [24] 1411 	sjmp	00134$
      00773A 80 18            [24] 1412 	sjmp	00135$
      00773C                       1413 00132$:
      00773C 8F 82            [24] 1414 	mov	dpl, r7
      00773E 12 7A C1         [24] 1415 	lcall	_default_layer_and
      007741 02 78 26         [24] 1416 	ljmp	00181$
                                   1417 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      007744                       1418 00133$:
      007744 8F 82            [24] 1419 	mov	dpl, r7
      007746 12 7A B0         [24] 1420 	lcall	_default_layer_or
      007749 02 78 26         [24] 1421 	ljmp	00181$
                                   1422 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      00774C                       1423 00134$:
      00774C 8F 82            [24] 1424 	mov	dpl, r7
      00774E 12 7A D7         [24] 1425 	lcall	_default_layer_xor
      007751 02 78 26         [24] 1426 	ljmp	00181$
                                   1427 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      007754                       1428 00135$:
      007754 8F 82            [24] 1429 	mov	dpl, r7
      007756 12 7A A5         [24] 1430 	lcall	_default_layer_set
                                   1431 ;	quantum/action.c:673: }
      007759 02 78 26         [24] 1432 	ljmp	00181$
      00775C                       1433 00143$:
                                   1434 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      00775C 12 7A 3F         [24] 1435 	lcall	_ak820_outline_0086
      00775F FE               [12] 1436 	mov	r6,a
      007760 2E               [12] 1437 	add	a,r6
                                   1438 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      007761 90 77 65         [24] 1439 	mov	dptr,#00466$
      007764 73               [24] 1440 	jmp	@a+dptr
      007765                       1441 00466$:
      007765 80 06            [24] 1442 	sjmp	00137$
      007767 80 0C            [24] 1443 	sjmp	00138$
      007769 80 12            [24] 1444 	sjmp	00139$
      00776B 80 18            [24] 1445 	sjmp	00140$
      00776D                       1446 00137$:
      00776D 8F 82            [24] 1447 	mov	dpl, r7
      00776F 12 7C 5A         [24] 1448 	lcall	_layer_and
      007772 02 78 26         [24] 1449 	ljmp	00181$
                                   1450 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      007775                       1451 00138$:
      007775 8F 82            [24] 1452 	mov	dpl, r7
      007777 12 7C 49         [24] 1453 	lcall	_layer_or
      00777A 02 78 26         [24] 1454 	ljmp	00181$
                                   1455 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      00777D                       1456 00139$:
      00777D 8F 82            [24] 1457 	mov	dpl, r7
      00777F 12 7C 70         [24] 1458 	lcall	_layer_xor
      007782 02 78 26         [24] 1459 	ljmp	00181$
                                   1460 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      007785                       1461 00140$:
      007785 8F 82            [24] 1462 	mov	dpl, r7
      007787 12 7B E6         [24] 1463 	lcall	_layer_state_set
                                   1464 ;	quantum/action.c:683: break;
      00778A 02 78 26         [24] 1465 	ljmp	00181$
                                   1466 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      00778D                       1467 00147$:
                                   1468 ;	quantum/action.c:686: if (pressed) {
      00778D E5 28            [12] 1469 	mov	a,_process_action_sloc0_1_0
      00778F 60 11            [24] 1470 	jz	00149$
                                   1471 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      007791 12 7A 4F         [24] 1472 	lcall	_ak820_outline_0109
      007794 F5 82            [12] 1473 	mov	dpl,a
      007796 12 7B 47         [24] 1474 	lcall	_layer_hold_on
                                   1475 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      007799 12 7A 38         [24] 1476 	lcall	_ak820_outline_0076
      00779C 12 79 7B         [24] 1477 	lcall	_register_mods
      00779F 02 78 26         [24] 1478 	ljmp	00181$
      0077A2                       1479 00149$:
                                   1480 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      0077A2 12 7A 38         [24] 1481 	lcall	_ak820_outline_0076
      0077A5 12 79 8F         [24] 1482 	lcall	_unregister_mods
                                   1483 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      0077A8 12 7A 4F         [24] 1484 	lcall	_ak820_outline_0109
      0077AB F5 82            [12] 1485 	mov	dpl,a
      0077AD 12 7B 7F         [24] 1486 	lcall	_layer_hold_off
                                   1487 ;	quantum/action.c:693: break;
      0077B0 02 78 26         [24] 1488 	ljmp	00181$
                                   1489 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      0077B3                       1490 00152$:
                                   1491 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      0077B3 12 7A 61         [24] 1492 	lcall	_ak820_outline_0154
      0077B6 FF               [12] 1493 	mov	r7,a
      0077B7 BF F1 02         [24] 1494 	cjne	r7,#0xf1,00468$
      0077BA 80 0A            [24] 1495 	sjmp	00154$
      0077BC                       1496 00468$:
      0077BC BF F2 02         [24] 1497 	cjne	r7,#0xf2,00469$
      0077BF 80 19            [24] 1498 	sjmp	00155$
      0077C1                       1499 00469$:
                                   1500 ;	quantum/action.c:712: momentary_layer_action:
      0077C1 BF F3 3B         [24] 1501 	cjne	r7,#0xf3,00160$
      0077C4 80 28            [24] 1502 	sjmp	00156$
      0077C6                       1503 00154$:
                                   1504 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0077C6 E5 28            [12] 1505 	mov	a,_process_action_sloc0_1_0
      0077C8 60 08            [24] 1506 	jz	00206$
      0077CA 12 7A 1F         [24] 1507 	lcall	_ak820_outline_0038
      0077CD 12 7B 47         [24] 1508 	lcall	_layer_hold_on
      0077D0 80 54            [24] 1509 	sjmp	00181$
      0077D2                       1510 00206$:
      0077D2 12 7A 1F         [24] 1511 	lcall	_ak820_outline_0038
      0077D5 12 7B 7F         [24] 1512 	lcall	_layer_hold_off
                                   1513 ;	quantum/action.c:714: break;
                                   1514 ;	quantum/action.c:715: case OP_OFF_ON:
      0077D8 80 4C            [24] 1515 	sjmp	00181$
      0077DA                       1516 00155$:
                                   1517 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0077DA E5 28            [12] 1518 	mov	a,_process_action_sloc0_1_0
      0077DC 60 08            [24] 1519 	jz	00208$
      0077DE 12 7A 1F         [24] 1520 	lcall	_ak820_outline_0038
      0077E1 12 7C 2B         [24] 1521 	lcall	_layer_off
      0077E4 80 40            [24] 1522 	sjmp	00181$
      0077E6                       1523 00208$:
      0077E6 12 7A 1F         [24] 1524 	lcall	_ak820_outline_0038
      0077E9 12 7C 10         [24] 1525 	lcall	_layer_on
                                   1526 ;	quantum/action.c:717: break;
                                   1527 ;	quantum/action.c:718: case OP_SET_CLEAR:
      0077EC 80 38            [24] 1528 	sjmp	00181$
      0077EE                       1529 00156$:
                                   1530 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0077EE E5 28            [12] 1531 	mov	a,_process_action_sloc0_1_0
      0077F0 60 08            [24] 1532 	jz	00210$
      0077F2 12 7A 1F         [24] 1533 	lcall	_ak820_outline_0038
      0077F5 12 7B FA         [24] 1534 	lcall	_layer_move
      0077F8 80 2C            [24] 1535 	sjmp	00181$
      0077FA                       1536 00210$:
      0077FA 12 7B F4         [24] 1537 	lcall	_layer_clear
                                   1538 ;	quantum/action.c:720: break;
                                   1539 ;	quantum/action.c:766: default:
      0077FD 80 27            [24] 1540 	sjmp	00181$
      0077FF                       1541 00160$:
                                   1542 ;	quantum/action.c:773: if (pressed) {
      0077FF E5 28            [12] 1543 	mov	a,_process_action_sloc0_1_0
      007801 60 08            [24] 1544 	jz	00163$
                                   1545 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007803 12 7A 38         [24] 1546 	lcall	_ak820_outline_0076
      007806 12 78 3D         [24] 1547 	lcall	_register_code
                                   1548 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007809 80 1B            [24] 1549 	sjmp	00181$
      00780B                       1550 00163$:
                                   1551 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      00780B 12 7A 61         [24] 1552 	lcall	_ak820_outline_0154
      00780E FF               [12] 1553 	mov	r7,a
      00780F BF 39 0E         [24] 1554 	cjne	r7,#0x39,00175$
                                   1555 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      007812 7F 50            [12] 1556 	mov	r7,#0x50
      007814                       1557 00187$:
      007814 EF               [12] 1558 	mov	a,r7
      007815 60 09            [24] 1559 	jz	00175$
      007817 90 00 01         [24] 1560 	mov	dptr,#0x0001
      00781A 12 5B BE         [24] 1561 	lcall	_mDelaymS
      00781D 1F               [12] 1562 	dec	r7
                                   1563 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      00781E 80 F4            [24] 1564 	sjmp	00187$
      007820                       1565 00175$:
                                   1566 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      007820 12 7A 38         [24] 1567 	lcall	_ak820_outline_0076
      007823 12 78 B9         [24] 1568 	lcall	_unregister_code
                                   1569 ;	quantum/action.c:866: }
      007826                       1570 00181$:
                                   1571 ;	quantum/action.c:887: switch (action.kind.id) {
      007826 90 08 80         [24] 1572 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007829 E0               [24] 1573 	movx	a,@dptr
      00782A C4               [12] 1574 	swap	a
      00782B 54 0F            [12] 1575 	anl	a,#0x0f
      00782D FF               [12] 1576 	mov	r7,a
      00782E BF 08 02         [24] 1577 	cjne	r7,#0x08,00478$
      007831 80 03            [24] 1578 	sjmp	00183$
      007833                       1579 00478$:
      007833 BF 09 06         [24] 1580 	cjne	r7,#0x09,00192$
                                   1581 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007836                       1582 00183$:
                                   1583 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007836 12 6F 6B         [24] 1584 	lcall	_host_keyboard_leds
                                   1585 ;	quantum/action.c:898: }
                                   1586 ;	quantum/action.c:951: }
      007839 02 9A 5E         [24] 1587 	ljmp	_led_set
      00783C                       1588 00192$:
      00783C 22               [24] 1589 	ret
                                   1590 ;------------------------------------------------------------
                                   1591 ;Allocation info for local variables in function 'register_code'
                                   1592 ;------------------------------------------------------------
                                   1593 ;code          Allocated with name '_register_code_code_10000_715'
                                   1594 ;------------------------------------------------------------
                                   1595 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1596 ;	-----------------------------------------
                                   1597 ;	 function register_code
                                   1598 ;	-----------------------------------------
      00783D                       1599 _register_code:
      00783D E5 82            [12] 1600 	mov	a,dpl
      00783F 90 08 84         [24] 1601 	mov	dptr,#_register_code_code_10000_715
      007842 F0               [24] 1602 	movx	@dptr,a
                                   1603 ;	quantum/action.c:958: if (code == KC_NO) {
      007843 E0               [24] 1604 	movx	a,@dptr
      007844 FF               [12] 1605 	mov	r7,a
      007845 70 01            [24] 1606 	jnz	00123$
                                   1607 ;	quantum/action.c:959: return;
      007847 22               [24] 1608 	ret
      007848                       1609 00123$:
                                   1610 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007848 BF 04 00         [24] 1611 	cjne	r7,#0x04,00186$
      00784B                       1612 00186$:
      00784B 40 21            [24] 1613 	jc	00119$
      00784D EF               [12] 1614 	mov	a,r7
      00784E 24 5B            [12] 1615 	add	a,#0xff - 0xa4
      007850 40 1C            [24] 1616 	jc	00119$
                                   1617 ;	free result
                                   1618 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      007852 8F 82            [24] 1619 	mov	dpl, r7
      007854 C0 07            [24] 1620 	push	ar7
      007856 12 80 6F         [24] 1621 	lcall	_add_owned_key
      007859 E5 82            [12] 1622 	mov	a, dpl
      00785B D0 07            [24] 1623 	pop	ar7
      00785D 70 01            [24] 1624 	jnz	00104$
      00785F 22               [24] 1625 	ret
      007860                       1626 00104$:
                                   1627 ;	quantum/action.c:1001: ak820_dynamic_macro_observe(code, true);
      007860 90 04 AD         [24] 1628 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007863 74 01            [12] 1629 	mov	a,#0x01
      007865 F0               [24] 1630 	movx	@dptr,a
      007866 8F 82            [24] 1631 	mov	dpl, r7
      007868 12 39 F5         [24] 1632 	lcall	_ak820_dynamic_macro_observe
                                   1633 ;	quantum/action.c:1013: send_keyboard_report();
      00786B 02 83 05         [24] 1634 	ljmp	_send_keyboard_report
      00786E                       1635 00119$:
                                   1636 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      00786E 12 7A 66         [24] 1637 	lcall	_ak820_outline_0162
      007871 BF E0 00         [24] 1638 	cjne	r7,#0xe0,00190$
      007874                       1639 00190$:
      007874 40 1A            [24] 1640 	jc	00115$
      007876 EF               [12] 1641 	mov	a,r7
      007877 24 18            [12] 1642 	add	a,#0xff - 0xe7
      007879 40 15            [24] 1643 	jc	00115$
                                   1644 ;	free result
                                   1645 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      00787B 74 07            [12] 1646 	mov	a,#0x07
      00787D 5F               [12] 1647 	anl	a,r7
      00787E 12 7A 31         [24] 1648 	lcall	_ak820_outline_0062
      007881 80 02            [24] 1649 	sjmp	00194$
      007883                       1650 00193$:
      007883 25 E0            [12] 1651 	add	a,acc
      007885                       1652 00194$:
      007885 D5 F0 FB         [24] 1653 	djnz	b,00193$
      007888 F5 82            [12] 1654 	mov	dpl,a
      00788A 12 7F CC         [24] 1655 	lcall	_add_owned_mods
                                   1656 ;	quantum/action.c:1016: send_keyboard_report();
      00788D 02 83 05         [24] 1657 	ljmp	_send_keyboard_report
      007890                       1658 00115$:
                                   1659 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007890 12 7A 66         [24] 1660 	lcall	_ak820_outline_0162
      007893 BF A5 00         [24] 1661 	cjne	r7,#0xa5,00195$
      007896                       1662 00195$:
      007896 40 05            [24] 1663 	jc	00113$
      007898 EF               [12] 1664 	mov	a,r7
      007899 24 58            [12] 1665 	add	a,#0xff - 0xa7
      00789B 50 0D            [24] 1666 	jnc	00108$
                                   1667 ;	free result
      00789D                       1668 00113$:
      00789D 12 7A 66         [24] 1669 	lcall	_ak820_outline_0162
      0078A0 BF A8 00         [24] 1670 	cjne	r7,#0xa8,00198$
      0078A3                       1671 00198$:
      0078A3 40 13            [24] 1672 	jc	00125$
      0078A5 EF               [12] 1673 	mov	a,r7
      0078A6 24 3D            [12] 1674 	add	a,#0xff - 0xc2
      0078A8 40 0E            [24] 1675 	jc	00125$
                                   1676 ;	free result
      0078AA                       1677 00108$:
                                   1678 ;	quantum/action.c:1021: owned_usage_key(code, true);
      0078AA 12 7A 66         [24] 1679 	lcall	_ak820_outline_0162
      0078AD 90 0A DF         [24] 1680 	mov	dptr,#_owned_usage_key_PARM_2
      0078B0 74 01            [12] 1681 	mov	a,#0x01
      0078B2 F0               [24] 1682 	movx	@dptr,a
      0078B3 8F 82            [24] 1683 	mov	dpl, r7
                                   1684 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1685 ;	quantum/action.c:1031: }
      0078B5 02 81 B0         [24] 1686 	ljmp	_owned_usage_key
      0078B8                       1687 00125$:
      0078B8 22               [24] 1688 	ret
                                   1689 ;------------------------------------------------------------
                                   1690 ;Allocation info for local variables in function 'unregister_code'
                                   1691 ;------------------------------------------------------------
                                   1692 ;code          Allocated with name '_unregister_code_code_10000_729'
                                   1693 ;------------------------------------------------------------
                                   1694 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1695 ;	-----------------------------------------
                                   1696 ;	 function unregister_code
                                   1697 ;	-----------------------------------------
      0078B9                       1698 _unregister_code:
      0078B9 E5 82            [12] 1699 	mov	a,dpl
      0078BB 90 08 85         [24] 1700 	mov	dptr,#_unregister_code_code_10000_729
      0078BE F0               [24] 1701 	movx	@dptr,a
                                   1702 ;	quantum/action.c:1038: if (code == KC_NO) {
      0078BF E0               [24] 1703 	movx	a,@dptr
      0078C0 FF               [12] 1704 	mov	r7,a
      0078C1 70 01            [24] 1705 	jnz	00121$
                                   1706 ;	quantum/action.c:1039: return;
      0078C3 22               [24] 1707 	ret
      0078C4                       1708 00121$:
                                   1709 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      0078C4 BF 04 00         [24] 1710 	cjne	r7,#0x04,00184$
      0078C7                       1711 00184$:
      0078C7 40 1F            [24] 1712 	jc	00117$
      0078C9 EF               [12] 1713 	mov	a,r7
      0078CA 24 5B            [12] 1714 	add	a,#0xff - 0xa4
      0078CC 40 1A            [24] 1715 	jc	00117$
                                   1716 ;	free result
                                   1717 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      0078CE 8F 82            [24] 1718 	mov	dpl, r7
      0078D0 C0 07            [24] 1719 	push	ar7
      0078D2 12 80 E9         [24] 1720 	lcall	_del_owned_key
      0078D5 E5 82            [12] 1721 	mov	a, dpl
      0078D7 D0 07            [24] 1722 	pop	ar7
      0078D9 70 01            [24] 1723 	jnz	00102$
      0078DB 22               [24] 1724 	ret
      0078DC                       1725 00102$:
                                   1726 ;	quantum/action.c:1075: ak820_dynamic_macro_observe(code, false);
      0078DC 90 04 AD         [24] 1727 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      0078DF 12 7A 72         [24] 1728 	lcall	_ak820_outline_0184
      0078E2 12 39 F5         [24] 1729 	lcall	_ak820_dynamic_macro_observe
                                   1730 ;	quantum/action.c:1080: send_keyboard_report();
      0078E5 02 83 05         [24] 1731 	ljmp	_send_keyboard_report
      0078E8                       1732 00117$:
                                   1733 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      0078E8 12 7A 6C         [24] 1734 	lcall	_ak820_outline_0163
      0078EB BF E0 00         [24] 1735 	cjne	r7,#0xe0,00188$
      0078EE                       1736 00188$:
      0078EE 40 1A            [24] 1737 	jc	00113$
      0078F0 EF               [12] 1738 	mov	a,r7
      0078F1 24 18            [12] 1739 	add	a,#0xff - 0xe7
      0078F3 40 15            [24] 1740 	jc	00113$
                                   1741 ;	free result
                                   1742 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      0078F5 74 07            [12] 1743 	mov	a,#0x07
      0078F7 5F               [12] 1744 	anl	a,r7
      0078F8 12 7A 31         [24] 1745 	lcall	_ak820_outline_0062
      0078FB 80 02            [24] 1746 	sjmp	00192$
      0078FD                       1747 00191$:
      0078FD 25 E0            [12] 1748 	add	a,acc
      0078FF                       1749 00192$:
      0078FF D5 F0 FB         [24] 1750 	djnz	b,00191$
      007902 F5 82            [12] 1751 	mov	dpl,a
      007904 12 7F DC         [24] 1752 	lcall	_del_owned_mods
                                   1753 ;	quantum/action.c:1083: send_keyboard_report();
      007907 02 83 05         [24] 1754 	ljmp	_send_keyboard_report
      00790A                       1755 00113$:
                                   1756 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00790A 12 7A 6C         [24] 1757 	lcall	_ak820_outline_0163
      00790D BF A5 00         [24] 1758 	cjne	r7,#0xa5,00193$
      007910                       1759 00193$:
      007910 40 05            [24] 1760 	jc	00111$
      007912 EF               [12] 1761 	mov	a,r7
      007913 24 58            [12] 1762 	add	a,#0xff - 0xa7
      007915 50 0D            [24] 1763 	jnc	00106$
                                   1764 ;	free result
      007917                       1765 00111$:
      007917 12 7A 6C         [24] 1766 	lcall	_ak820_outline_0163
      00791A BF A8 00         [24] 1767 	cjne	r7,#0xa8,00196$
      00791D                       1768 00196$:
      00791D 40 11            [24] 1769 	jc	00123$
      00791F EF               [12] 1770 	mov	a,r7
      007920 24 3D            [12] 1771 	add	a,#0xff - 0xc2
      007922 40 0C            [24] 1772 	jc	00123$
                                   1773 ;	free result
      007924                       1774 00106$:
                                   1775 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007924 12 7A 6C         [24] 1776 	lcall	_ak820_outline_0163
      007927 90 0A DF         [24] 1777 	mov	dptr,#_owned_usage_key_PARM_2
      00792A 12 7A 72         [24] 1778 	lcall	_ak820_outline_0184
                                   1779 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1780 ;	quantum/action.c:1098: }
      00792D 02 81 B0         [24] 1781 	ljmp	_owned_usage_key
      007930                       1782 00123$:
      007930 22               [24] 1783 	ret
                                   1784 ;------------------------------------------------------------
                                   1785 ;Allocation info for local variables in function 'tap_code_delay'
                                   1786 ;------------------------------------------------------------
                                   1787 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1788 ;code          Allocated with name '_tap_code_delay_code_10000_742'
                                   1789 ;i             Allocated with name '_tap_code_delay_i_20000_744'
                                   1790 ;i             Allocated with name '_tap_code_delay_i_50000_747'
                                   1791 ;------------------------------------------------------------
                                   1792 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1793 ;	-----------------------------------------
                                   1794 ;	 function tap_code_delay
                                   1795 ;	-----------------------------------------
      007931                       1796 _tap_code_delay:
      007931 E5 82            [12] 1797 	mov	a,dpl
      007933 90 08 88         [24] 1798 	mov	dptr,#_tap_code_delay_code_10000_742
      007936 F0               [24] 1799 	movx	@dptr,a
                                   1800 ;	quantum/action.c:1106: register_code(code);
      007937 E0               [24] 1801 	movx	a,@dptr
      007938 FF               [12] 1802 	mov	r7,a
      007939 F5 82            [12] 1803 	mov	dpl,a
      00793B C0 07            [24] 1804 	push	ar7
      00793D 12 78 3D         [24] 1805 	lcall	_register_code
      007940 D0 07            [24] 1806 	pop	ar7
                                   1807 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007942 90 08 86         [24] 1808 	mov	dptr,#_tap_code_delay_PARM_2
      007945 12 46 50         [24] 1809 	lcall	_ak820_outline_0094
      007948                       1810 00110$:
      007948 ED               [12] 1811 	mov	a,r5
      007949 4E               [12] 1812 	orl	a,r6
      00794A 60 0D            [24] 1813 	jz	00105$
                                   1814 ;	quantum/action.c:1108: wait_ms(1);
      00794C 90 00 01         [24] 1815 	mov	dptr,#0x0001
      00794F 12 5B BE         [24] 1816 	lcall	_mDelaymS
                                   1817 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007952 1D               [12] 1818 	dec	r5
      007953 BD FF 01         [24] 1819 	cjne	r5,#0xff,00141$
      007956 1E               [12] 1820 	dec	r6
      007957                       1821 00141$:
      007957 80 EF            [24] 1822 	sjmp	00110$
      007959                       1823 00105$:
                                   1824 ;	quantum/action.c:1110: unregister_code(code);
      007959 8F 82            [24] 1825 	mov	dpl, r7
                                   1826 ;	quantum/action.c:1111: }
      00795B 02 78 B9         [24] 1827 	ljmp	_unregister_code
                                   1828 ;------------------------------------------------------------
                                   1829 ;Allocation info for local variables in function 'tap_code'
                                   1830 ;------------------------------------------------------------
                                   1831 ;code          Allocated with name '_tap_code_code_10000_749'
                                   1832 ;------------------------------------------------------------
                                   1833 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1834 ;	-----------------------------------------
                                   1835 ;	 function tap_code
                                   1836 ;	-----------------------------------------
      00795E                       1837 _tap_code:
      00795E E5 82            [12] 1838 	mov	a,dpl
      007960 90 08 89         [24] 1839 	mov	dptr,#_tap_code_code_10000_749
      007963 F0               [24] 1840 	movx	@dptr,a
                                   1841 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007964 E0               [24] 1842 	movx	a,@dptr
      007965 FF               [12] 1843 	mov	r7,a
      007966 BF 39 04         [24] 1844 	cjne	r7,#0x39,00103$
      007969 7E 50            [12] 1845 	mov	r6,#0x50
      00796B 80 02            [24] 1846 	sjmp	00104$
      00796D                       1847 00103$:
      00796D 7E 00            [12] 1848 	mov	r6,#0x00
      00796F                       1849 00104$:
      00796F 90 08 86         [24] 1850 	mov	dptr,#_tap_code_delay_PARM_2
      007972 EE               [12] 1851 	mov	a,r6
      007973 12 38 65         [24] 1852 	lcall	_ak820_outline_0123
      007976 8F 82            [24] 1853 	mov	dpl, r7
                                   1854 ;	quantum/action.c:1119: }
      007978 02 79 31         [24] 1855 	ljmp	_tap_code_delay
                                   1856 ;------------------------------------------------------------
                                   1857 ;Allocation info for local variables in function 'register_mods'
                                   1858 ;------------------------------------------------------------
                                   1859 ;mods          Allocated with name '_register_mods_mods_10000_751'
                                   1860 ;------------------------------------------------------------
                                   1861 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1862 ;	-----------------------------------------
                                   1863 ;	 function register_mods
                                   1864 ;	-----------------------------------------
      00797B                       1865 _register_mods:
      00797B E5 82            [12] 1866 	mov	a,dpl
      00797D 90 08 8A         [24] 1867 	mov	dptr,#_register_mods_mods_10000_751
      007980 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	quantum/action.c:1126: if (mods) {
      007981 E0               [24] 1870 	movx	a,@dptr
      007982 FF               [12] 1871 	mov	r7,a
      007983 E0               [24] 1872 	movx	a,@dptr
      007984 60 08            [24] 1873 	jz	00103$
                                   1874 ;	quantum/action.c:1127: add_owned_mods(mods);
      007986 8F 82            [24] 1875 	mov	dpl, r7
      007988 12 7F CC         [24] 1876 	lcall	_add_owned_mods
                                   1877 ;	quantum/action.c:1128: send_keyboard_report();
                                   1878 ;	quantum/action.c:1130: }
      00798B 02 83 05         [24] 1879 	ljmp	_send_keyboard_report
      00798E                       1880 00103$:
      00798E 22               [24] 1881 	ret
                                   1882 ;------------------------------------------------------------
                                   1883 ;Allocation info for local variables in function 'unregister_mods'
                                   1884 ;------------------------------------------------------------
                                   1885 ;mods          Allocated with name '_unregister_mods_mods_10000_755'
                                   1886 ;------------------------------------------------------------
                                   1887 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1888 ;	-----------------------------------------
                                   1889 ;	 function unregister_mods
                                   1890 ;	-----------------------------------------
      00798F                       1891 _unregister_mods:
      00798F E5 82            [12] 1892 	mov	a,dpl
      007991 90 08 8B         [24] 1893 	mov	dptr,#_unregister_mods_mods_10000_755
      007994 F0               [24] 1894 	movx	@dptr,a
                                   1895 ;	quantum/action.c:1137: if (mods) {
      007995 E0               [24] 1896 	movx	a,@dptr
      007996 FF               [12] 1897 	mov	r7,a
      007997 E0               [24] 1898 	movx	a,@dptr
      007998 60 08            [24] 1899 	jz	00103$
                                   1900 ;	quantum/action.c:1138: del_owned_mods(mods);
      00799A 8F 82            [24] 1901 	mov	dpl, r7
      00799C 12 7F DC         [24] 1902 	lcall	_del_owned_mods
                                   1903 ;	quantum/action.c:1139: send_keyboard_report();
                                   1904 ;	quantum/action.c:1141: }
      00799F 02 83 05         [24] 1905 	ljmp	_send_keyboard_report
      0079A2                       1906 00103$:
      0079A2 22               [24] 1907 	ret
                                   1908 ;------------------------------------------------------------
                                   1909 ;Allocation info for local variables in function 'register_weak_mods'
                                   1910 ;------------------------------------------------------------
                                   1911 ;mods          Allocated with name '_register_weak_mods_mods_10000_759'
                                   1912 ;------------------------------------------------------------
                                   1913 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1914 ;	-----------------------------------------
                                   1915 ;	 function register_weak_mods
                                   1916 ;	-----------------------------------------
      0079A3                       1917 _register_weak_mods:
      0079A3 E5 82            [12] 1918 	mov	a,dpl
      0079A5 90 08 8C         [24] 1919 	mov	dptr,#_register_weak_mods_mods_10000_759
      0079A8 F0               [24] 1920 	movx	@dptr,a
                                   1921 ;	quantum/action.c:1148: if (mods) {
      0079A9 E0               [24] 1922 	movx	a,@dptr
      0079AA FF               [12] 1923 	mov	r7,a
      0079AB E0               [24] 1924 	movx	a,@dptr
      0079AC 60 08            [24] 1925 	jz	00103$
                                   1926 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      0079AE 8F 82            [24] 1927 	mov	dpl, r7
      0079B0 12 7F EA         [24] 1928 	lcall	_add_owned_weak_mods
                                   1929 ;	quantum/action.c:1150: send_keyboard_report();
                                   1930 ;	quantum/action.c:1152: }
      0079B3 02 83 05         [24] 1931 	ljmp	_send_keyboard_report
      0079B6                       1932 00103$:
      0079B6 22               [24] 1933 	ret
                                   1934 ;------------------------------------------------------------
                                   1935 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1936 ;------------------------------------------------------------
                                   1937 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_763'
                                   1938 ;------------------------------------------------------------
                                   1939 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1940 ;	-----------------------------------------
                                   1941 ;	 function unregister_weak_mods
                                   1942 ;	-----------------------------------------
      0079B7                       1943 _unregister_weak_mods:
      0079B7 E5 82            [12] 1944 	mov	a,dpl
      0079B9 90 08 8D         [24] 1945 	mov	dptr,#_unregister_weak_mods_mods_10000_763
      0079BC F0               [24] 1946 	movx	@dptr,a
                                   1947 ;	quantum/action.c:1159: if (mods) {
      0079BD E0               [24] 1948 	movx	a,@dptr
      0079BE FF               [12] 1949 	mov	r7,a
      0079BF E0               [24] 1950 	movx	a,@dptr
      0079C0 60 08            [24] 1951 	jz	00103$
                                   1952 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      0079C2 8F 82            [24] 1953 	mov	dpl, r7
      0079C4 12 7F FA         [24] 1954 	lcall	_del_owned_weak_mods
                                   1955 ;	quantum/action.c:1161: send_keyboard_report();
                                   1956 ;	quantum/action.c:1163: }
      0079C7 02 83 05         [24] 1957 	ljmp	_send_keyboard_report
      0079CA                       1958 00103$:
      0079CA 22               [24] 1959 	ret
                                   1960 ;------------------------------------------------------------
                                   1961 ;Allocation info for local variables in function 'clear_keyboard'
                                   1962 ;------------------------------------------------------------
                                   1963 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1964 ;	-----------------------------------------
                                   1965 ;	 function clear_keyboard
                                   1966 ;	-----------------------------------------
      0079CB                       1967 _clear_keyboard:
                                   1968 ;	quantum/action.c:1170: clear_mods();
      0079CB 12 83 80         [24] 1969 	lcall	_clear_mods
                                   1970 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1971 ;	quantum/action.c:1172: }
      0079CE 02 79 D1         [24] 1972 	ljmp	_clear_keyboard_but_mods
                                   1973 ;------------------------------------------------------------
                                   1974 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1975 ;------------------------------------------------------------
                                   1976 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1977 ;	-----------------------------------------
                                   1978 ;	 function clear_keyboard_but_mods
                                   1979 ;	-----------------------------------------
      0079D1                       1980 _clear_keyboard_but_mods:
                                   1981 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0079D1 90 0D EB         [24] 1982 	mov	dptr,#_actual_keyboard_report
      0079D4 12 72 2B         [24] 1983 	lcall	_clear_keys_from_report
                                   1984 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1985 ;	quantum/action.c:1181: }
      0079D7 02 79 DA         [24] 1986 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1987 ;------------------------------------------------------------
                                   1988 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1989 ;------------------------------------------------------------
                                   1990 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1991 ;	-----------------------------------------
                                   1992 ;	 function clear_keyboard_but_mods_and_keys
                                   1993 ;	-----------------------------------------
      0079DA                       1994 _clear_keyboard_but_mods_and_keys:
                                   1995 ;	quantum/action.c:1189: ak820_tapping_cancel();
      0079DA 12 49 D2         [24] 1996 	lcall	_ak820_tapping_cancel
                                   1997 ;	quantum/action.c:1200: ak820_dynamic_macro_cancel();
      0079DD 12 39 36         [24] 1998 	lcall	_ak820_dynamic_macro_cancel
                                   1999 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      0079E0 12 2E F0         [24] 2000 	lcall	_ak820_oneshot_cancel
                                   2001 ;	quantum/action.c:1209: ak820_combo_cancel();
      0079E3 12 35 27         [24] 2002 	lcall	_ak820_combo_cancel
                                   2003 ;	quantum/action.c:1212: repeat_key_cancel();
      0079E6 12 A3 4D         [24] 2004 	lcall	_repeat_key_cancel
                                   2005 ;	quantum/action.c:1214: clear_owned_mods();
      0079E9 12 80 0A         [24] 2006 	lcall	_clear_owned_mods
                                   2007 ;	quantum/action.c:1215: clear_owned_keys();
      0079EC 12 80 42         [24] 2008 	lcall	_clear_owned_keys
                                   2009 ;	quantum/action.c:1216: clear_owned_usages();
      0079EF 12 81 78         [24] 2010 	lcall	_clear_owned_usages
                                   2011 ;	quantum/action.c:1217: layer_hold_clear();
      0079F2 12 7B B7         [24] 2012 	lcall	_layer_hold_clear
                                   2013 ;	quantum/action.c:1219: clear_macro_tri_layer();
      0079F5 12 9E ED         [24] 2014 	lcall	_clear_macro_tri_layer
                                   2015 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0079F8 90 0D EB         [24] 2016 	mov	dptr,#_actual_keyboard_report
      0079FB 12 72 2B         [24] 2017 	lcall	_clear_keys_from_report
                                   2018 ;	quantum/action.c:1224: host_system_send(0);
      0079FE 90 00 00         [24] 2019 	mov	dptr,#0x0000
      007A01 12 70 06         [24] 2020 	lcall	_host_system_send
                                   2021 ;	quantum/action.c:1225: host_consumer_send(0);
      007A04 90 00 00         [24] 2022 	mov	dptr,#0x0000
      007A07 12 70 36         [24] 2023 	lcall	_host_consumer_send
                                   2024 ;	quantum/action.c:1227: clear_weak_mods();
      007A0A 12 83 B5         [24] 2025 	lcall	_clear_weak_mods
                                   2026 ;	quantum/action.c:1228: send_keyboard_report();
                                   2027 ;	quantum/action.c:1236: }
      007A0D 02 83 05         [24] 2028 	ljmp	_send_keyboard_report
                                   2029 ;------------------------------------------------------------
                                   2030 ;Allocation info for local variables in function 'is_tap_record'
                                   2031 ;------------------------------------------------------------
                                   2032 ;record        Allocated with name '_is_tap_record_record_10000_779'
                                   2033 ;action        Allocated with name '_is_tap_record_action_10001_783'
                                   2034 ;------------------------------------------------------------
                                   2035 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   2036 ;	-----------------------------------------
                                   2037 	.area CSEG    (CODE)
                                   2038 	.area CONST   (CODE)
                                   2039 	.area XINIT   (CODE)
      00C2BD                       2040 __xinit__disable_action_cache:
      00C2BD 00                    2041 	.db #0x00	;  0
                                   2042 	.area CABS    (ABS,CODE)
                                   2043 
                                   2044 ; Experimental exact instruction outlining.
                                   2045 	.globl _ak820_outline_0004
                                   2046 	.globl _ak820_outline_0008
                                   2047 	.globl _ak820_outline_0009
                                   2048 	.globl _ak820_outline_0010
                                   2049 	.globl _ak820_outline_0011
                                   2050 	.globl _ak820_outline_0015
                                   2051 	.globl _ak820_outline_0016
                                   2052 	.globl _ak820_outline_0019
                                   2053 	.globl _ak820_outline_0030
                                   2054 	.globl _ak820_outline_0038
                                   2055 	.globl _ak820_outline_0043
                                   2056 	.globl _ak820_outline_0050
                                   2057 	.globl _ak820_outline_0051
                                   2058 	.globl _ak820_outline_0057
                                   2059 	.globl _ak820_outline_0060
                                   2060 	.globl _ak820_outline_0062
                                   2061 	.globl _ak820_outline_0070
                                   2062 	.globl _ak820_outline_0075
                                   2063 	.globl _ak820_outline_0076
                                   2064 	.globl _ak820_outline_0086
                                   2065 	.globl _ak820_outline_0093
                                   2066 	.globl _ak820_outline_0094
                                   2067 	.globl _ak820_outline_0098
                                   2068 	.globl _ak820_outline_0104
                                   2069 	.globl _ak820_outline_0105
                                   2070 	.globl _ak820_outline_0107
                                   2071 	.globl _ak820_outline_0108
                                   2072 	.globl _ak820_outline_0109
                                   2073 	.globl _ak820_outline_0116
                                   2074 	.globl _ak820_outline_0121
                                   2075 	.globl _ak820_outline_0122
                                   2076 	.globl _ak820_outline_0123
                                   2077 	.globl _ak820_outline_0129
                                   2078 	.globl _ak820_outline_0139
                                   2079 	.globl _ak820_outline_0140
                                   2080 	.globl _ak820_outline_0141
                                   2081 	.globl _ak820_outline_0154
                                   2082 	.globl _ak820_outline_0162
                                   2083 	.globl _ak820_outline_0163
                                   2084 	.globl _ak820_outline_0178
                                   2085 	.globl _ak820_outline_0184
                                   2086 
                                   2087 	.area CSEG (CODE)
                                   2088 ; function ak820_outline_0019
      007A10                       2089 _ak820_outline_0019:
      007A10 8E 82            [24] 2090 	mov	dpl,r6
      007A12 8F 83            [24] 2091 	mov	dph,r7
      007A14 A3               [24] 2092 	inc	dptr
      007A15 E0               [24] 2093 	movx	a,@dptr
      007A16 FC               [12] 2094 	mov	r4,a
      007A17 7D 00            [12] 2095 	mov	r5,#0x00
      007A19 8E 82            [24] 2096 	mov	dpl,r6
      007A1B 8F 83            [24] 2097 	mov	dph,r7
      007A1D E0               [24] 2098 	movx	a,@dptr
      007A1E 22               [24] 2099 	ret
                                   2100 
                                   2101 	.area CSEG (CODE)
                                   2102 ; function ak820_outline_0038
      007A1F                       2103 _ak820_outline_0038:
      007A1F 90 08 80         [24] 2104 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007A22 E0               [24] 2105 	movx	a,@dptr
      007A23 54 1F            [12] 2106 	anl	a,#0x1f
      007A25 F5 82            [12] 2107 	mov	dpl,a
      007A27 22               [24] 2108 	ret
                                   2109 
                                   2110 	.area CSEG (CODE)
                                   2111 ; function ak820_outline_0050
      007A28                       2112 _ak820_outline_0050:
      007A28 A3               [24] 2113 	inc	dptr
      007A29 F0               [24] 2114 	movx	@dptr,a
      007A2A E4               [12] 2115 	clr	a
      007A2B A3               [24] 2116 	inc	dptr
      007A2C F0               [24] 2117 	movx	@dptr,a
      007A2D 90 0D C9         [24] 2118 	mov	dptr,#___memcpy_PARM_3
      007A30 22               [24] 2119 	ret
                                   2120 
                                   2121 	.area CSEG (CODE)
                                   2122 ; function ak820_outline_0062
      007A31                       2123 _ak820_outline_0062:
      007A31 F5 F0            [12] 2124 	mov	b,a
      007A33 05 F0            [12] 2125 	inc	b
      007A35 74 01            [12] 2126 	mov	a,#0x01
      007A37 22               [24] 2127 	ret
                                   2128 
                                   2129 	.area CSEG (CODE)
                                   2130 ; function ak820_outline_0076
      007A38                       2131 _ak820_outline_0076:
      007A38 90 08 7F         [24] 2132 	mov	dptr,#_process_action_PARM_2
      007A3B E0               [24] 2133 	movx	a,@dptr
      007A3C F5 82            [12] 2134 	mov	dpl,a
      007A3E 22               [24] 2135 	ret
                                   2136 
                                   2137 	.area CSEG (CODE)
                                   2138 ; function ak820_outline_0086
      007A3F                       2139 _ak820_outline_0086:
      007A3F 90 08 80         [24] 2140 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007A42 E0               [24] 2141 	movx	a,@dptr
      007A43 03               [12] 2142 	rr	a
      007A44 03               [12] 2143 	rr	a
      007A45 54 03            [12] 2144 	anl	a,#0x03
      007A47 22               [24] 2145 	ret
                                   2146 
                                   2147 	.area CSEG (CODE)
                                   2148 ; function ak820_outline_0108
      007A48                       2149 _ak820_outline_0108:
      007A48 74 06            [12] 2150 	mov	a,#0x06
      007A4A F0               [24] 2151 	movx	@dptr,a
      007A4B E4               [12] 2152 	clr	a
      007A4C A3               [24] 2153 	inc	dptr
      007A4D F0               [24] 2154 	movx	@dptr,a
      007A4E 22               [24] 2155 	ret
                                   2156 
                                   2157 	.area CSEG (CODE)
                                   2158 ; function ak820_outline_0109
      007A4F                       2159 _ak820_outline_0109:
      007A4F 90 08 80         [24] 2160 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007A52 E0               [24] 2161 	movx	a,@dptr
      007A53 54 0F            [12] 2162 	anl	a,#0x0f
      007A55 22               [24] 2163 	ret
                                   2164 
                                   2165 	.area CSEG (CODE)
                                   2166 ; function ak820_outline_0129
      007A56                       2167 _ak820_outline_0129:
      007A56 90 08 7F         [24] 2168 	mov	dptr,#_process_action_PARM_2
      007A59 E0               [24] 2169 	movx	a,@dptr
      007A5A FE               [12] 2170 	mov	r6,a
      007A5B A3               [24] 2171 	inc	dptr
      007A5C E0               [24] 2172 	movx	a,@dptr
      007A5D 54 03            [12] 2173 	anl	a,#0x03
      007A5F FF               [12] 2174 	mov	r7,a
      007A60 22               [24] 2175 	ret
                                   2176 
                                   2177 	.area CSEG (CODE)
                                   2178 ; function ak820_outline_0154
      007A61                       2179 _ak820_outline_0154:
      007A61 90 08 7F         [24] 2180 	mov	dptr,#_process_action_PARM_2
      007A64 E0               [24] 2181 	movx	a,@dptr
      007A65 22               [24] 2182 	ret
                                   2183 
                                   2184 	.area CSEG (CODE)
                                   2185 ; function ak820_outline_0162
      007A66                       2186 _ak820_outline_0162:
      007A66 90 08 84         [24] 2187 	mov	dptr,#_register_code_code_10000_715
      007A69 E0               [24] 2188 	movx	a,@dptr
      007A6A FF               [12] 2189 	mov	r7,a
      007A6B 22               [24] 2190 	ret
                                   2191 
                                   2192 	.area CSEG (CODE)
                                   2193 ; function ak820_outline_0163
      007A6C                       2194 _ak820_outline_0163:
      007A6C 90 08 85         [24] 2195 	mov	dptr,#_unregister_code_code_10000_729
      007A6F E0               [24] 2196 	movx	a,@dptr
      007A70 FF               [12] 2197 	mov	r7,a
      007A71 22               [24] 2198 	ret
                                   2199 
                                   2200 	.area CSEG (CODE)
                                   2201 ; function ak820_outline_0184
      007A72                       2202 _ak820_outline_0184:
      007A72 E4               [12] 2203 	clr	a
      007A73 F0               [24] 2204 	movx	@dptr,a
      007A74 8F 82            [24] 2205 	mov	dpl,r7
      007A76 22               [24] 2206 	ret
