                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000043                        541 _vial_handle_cmd_sloc0_1_0:
      000043                        542 	.ds 2
      000045                        543 _vial_handle_cmd_sloc1_1_0:
      000045                        544 	.ds 2
      000047                        545 _vial_handle_cmd_sloc2_1_0:
      000047                        546 	.ds 2
      000049                        547 _vial_handle_cmd_sloc3_1_0:
      000049                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C7C                        573 _vial_unlock_timer:
      000C7C                        574 	.ds 4
      000C80                        575 _vial_unlock_holding:
      000C80                        576 	.ds 1
      000C81                        577 _vial_keycode_firewall_in_10000_609:
      000C81                        578 	.ds 2
      000C83                        579 _vial_fill_packet_PARM_2:
      000C83                        580 	.ds 1
      000C84                        581 _vial_fill_packet_msg_10000_612:
      000C84                        582 	.ds 2
      000C86                        583 _vial_handle_cmd_PARM_2:
      000C86                        584 	.ds 1
      000C87                        585 _vial_handle_cmd_data_10000_617:
      000C87                        586 	.ds 3
      000C8A                        587 _vial_handle_cmd_entry_70000_645:
      000C8A                        588 	.ds 10
      000C94                        589 _vial_handle_cmd_entry_70000_646:
      000C94                        590 	.ds 10
      000C9E                        591 _g_vial_magic_keycode_override::
      000C9E                        592 	.ds 2
      000CA0                        593 _vial_keycode_down_keycode_10000_648:
      000CA0                        594 	.ds 2
      000CA2                        595 _vial_keycode_down_dummy_event_30000_655:
      000CA2                        596 	.ds 6
      000CA8                        597 _vial_keycode_up_keycode_10000_656:
      000CA8                        598 	.ds 2
      000CAA                        599 _vial_keycode_up_dummy_event_30000_663:
      000CAA                        600 	.ds 6
      000CB0                        601 _vial_keycode_tap_keycode_10000_664:
      000CB0                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000E46                        611 _vial_unlocked::
      000E46                        612 	.ds 1
      000E47                        613 _vial_unlock_in_progress::
      000E47                        614 	.ds 1
      000E48                        615 _vial_unlock_counter:
      000E48                        616 	.ds 1
      000E49                        617 _vial_unlock_combo_rows:
      000E49                        618 	.ds 2
      000E4B                        619 _vial_unlock_combo_cols:
      000E4B                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00AE76                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00AE76 90 0E 47         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00AE79 E0               [24]  667 	movx	a,@dptr
      00AE7A 70 01            [24]  668 	jnz	00131$
      00AE7C 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AE7D                        671 00131$:
      00AE7D 7F 00            [12]  672 	mov	r7,#0x00
      00AE7F                        673 00115$:
      00AE7F BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00AE82                        675 00184$:
      00AE82 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00AE84 EF               [12]  678 	mov	a,r7
      00AE85 12 B4 3B         [24]  679 	lcall	_ak820_outline_0126
      00AE88 FE               [12]  680 	mov	r6,a
      00AE89 EF               [12]  681 	mov	a,r7
      00AE8A 12 B4 30         [24]  682 	lcall	_ak820_outline_0125
      00AE8D 90 07 B1         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00AE90 F0               [24]  684 	movx	@dptr,a
      00AE91 8E 82            [24]  685 	mov	dpl, r6
      00AE93 C0 07            [24]  686 	push	ar7
      00AE95 12 5C 30         [24]  687 	lcall	_matrix_is_on
      00AE98 E5 82            [12]  688 	mov	a, dpl
      00AE9A D0 07            [24]  689 	pop	ar7
      00AE9C 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00AE9E 90 0C 80         [24]  692 	mov	dptr,#_vial_unlock_holding
      00AEA1 E4               [12]  693 	clr	a
      00AEA2 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AEA3 90 0E 48         [24]  696 	mov	dptr,#_vial_unlock_counter
      00AEA6 74 1E            [12]  697 	mov	a,#0x1e
      00AEA8 F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00AEA9 22               [24]  700 	ret
      00AEAA                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AEAA 0F               [12]  703 	inc	r7
      00AEAB 80 D2            [24]  704 	sjmp	00115$
      00AEAD                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00AEAD 90 0C 80         [24]  707 	mov	dptr,#_vial_unlock_holding
      00AEB0 E0               [24]  708 	movx	a,@dptr
      00AEB1 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00AEB3 90 0C 80         [24]  711 	mov	dptr,#_vial_unlock_holding
      00AEB6 74 01            [12]  712 	mov	a,#0x01
      00AEB8 F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00AEB9 12 4B EA         [24]  715 	lcall	_timer_read32
      00AEBC 12 52 15         [24]  716 	lcall	_ak820_outline_0056
      00AEBF 90 0C 7C         [24]  717 	mov	dptr,#_vial_unlock_timer
      00AEC2 12 93 22         [24]  718 	lcall	_ak820_outline_0007
      00AEC5                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00AEC5 90 0C 7C         [24]  721 	mov	dptr,#_vial_unlock_timer
      00AEC8 12 52 04         [24]  722 	lcall	_ak820_outline_0054
      00AECB 12 4C 43         [24]  723 	lcall	_timer_elapsed32
      00AECE 12 52 15         [24]  724 	lcall	_ak820_outline_0056
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00AED1 7B 1E            [12]  726 	mov	r3,#0x1e
      00AED3                        727 00109$:
      00AED3 EB               [12]  728 	mov	a,r3
      00AED4 60 22            [24]  729 	jz	00111$
      00AED6 C3               [12]  730 	clr	c
      00AED7 EC               [12]  731 	mov	a,r4
      00AED8 94 64            [12]  732 	subb	a,#0x64
      00AEDA ED               [12]  733 	mov	a,r5
      00AEDB 94 00            [12]  734 	subb	a,#0x00
      00AEDD EE               [12]  735 	mov	a,r6
      00AEDE 94 00            [12]  736 	subb	a,#0x00
      00AEE0 EF               [12]  737 	mov	a,r7
      00AEE1 94 00            [12]  738 	subb	a,#0x00
      00AEE3 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00AEE5 EC               [12]  741 	mov	a,r4
      00AEE6 24 9C            [12]  742 	add	a,#0x9c
      00AEE8 FC               [12]  743 	mov	r4,a
      00AEE9 ED               [12]  744 	mov	a,r5
      00AEEA 34 FF            [12]  745 	addc	a,#0xff
      00AEEC FD               [12]  746 	mov	r5,a
      00AEED EE               [12]  747 	mov	a,r6
      00AEEE 34 FF            [12]  748 	addc	a,#0xff
      00AEF0 FE               [12]  749 	mov	r6,a
      00AEF1 EF               [12]  750 	mov	a,r7
      00AEF2 34 FF            [12]  751 	addc	a,#0xff
      00AEF4 FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00AEF5 1B               [12]  754 	dec	r3
      00AEF6 80 DB            [24]  755 	sjmp	00109$
      00AEF8                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00AEF8 90 0E 48         [24]  758 	mov	dptr,#_vial_unlock_counter
      00AEFB EB               [12]  759 	mov	a,r3
      00AEFC F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00AEFD EB               [12]  762 	mov	a,r3
      00AEFE 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00AF00 90 0E 47         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00AF03 E4               [12]  766 	clr	a
      00AF04 F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00AF05 90 0E 46         [24]  769 	mov	dptr,#_vial_unlocked
      00AF08 04               [12]  770 	inc	a
      00AF09 F0               [24]  771 	movx	@dptr,a
      00AF0A                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00AF0A 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:117: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00AF0B                        782 _vial_init:
                                    783 ;	quantum/vial.c:125: reload_combo();
                                    784 ;	quantum/vial.c:130: }
      00AF0B 02 35 37         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_609'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00AF0E                        795 _vial_keycode_firewall:
      00AF0E 12 38 4A         [24]  796 	lcall	_ak820_outline_0104
      00AF11 90 0C 81         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_609
      00AF14 12 38 4F         [24]  798 	lcall	_ak820_outline_0105
                                    799 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00AF17 90 0C 81         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_609
      00AF1A 12 37 CB         [24]  801 	lcall	_ak820_outline_0010
      00AF1D BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00AF20 BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00AF23 90 0E 46         [24]  804 	mov	dptr,#_vial_unlocked
      00AF26 E0               [24]  805 	movx	a,@dptr
      00AF27 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:134: return 0;
      00AF29 90 00 00         [24]  808 	mov	dptr,#0x0000
      00AF2C 22               [24]  809 	ret
      00AF2D                        810 00102$:
                                    811 ;	quantum/vial.c:135: return in;
      00AF2D 12 46 62         [24]  812 	lcall	_ak820_outline_0116
                                    813 ;	quantum/vial.c:136: }
      00AF30 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_612'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_614'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00AF31                        826 _vial_fill_packet:
      00AF31 12 38 4A         [24]  827 	lcall	_ak820_outline_0104
      00AF34 90 0C 84         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_612
      00AF37 12 38 4F         [24]  829 	lcall	_ak820_outline_0105
                                    830 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00AF3A 90 0C 84         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_612
      00AF3D 12 38 00         [24]  832 	lcall	_ak820_outline_0051
      00AF40 90 0C 83         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00AF43 E0               [24]  834 	movx	a,@dptr
      00AF44 FD               [12]  835 	mov	r5,a
      00AF45 7C 00            [12]  836 	mov	r4,#0x00
      00AF47                        837 00103$:
      00AF47 BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00AF4A                        839 00122$:
      00AF4A 50 09            [24]  840 	jnc	00105$
      00AF4C EC               [12]  841 	mov	a,r4
      00AF4D 12 37 F0         [24]  842 	lcall	_ak820_outline_0030
      00AF50 ED               [12]  843 	mov	a,r5
      00AF51 F0               [24]  844 	movx	@dptr,a
      00AF52 0C               [12]  845 	inc	r4
      00AF53 80 F2            [24]  846 	sjmp	00103$
      00AF55                        847 00105$:
                                    848 ;	quantum/vial.c:141: }
      00AF55 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00AF56                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:174: repeat_key_cancel();
      00AF56 12 A3 4D         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:176: clear_keyboard();
                                    861 ;	quantum/vial.c:177: }
      00AF59 02 79 CB         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_617'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_618'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_623'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_624'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_627'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_629'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_629'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_629'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_630'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_631'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_631'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_631'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_634'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_645'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_645'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00AF5C                        893 _vial_handle_cmd:
      00AF5C 12 46 19         [24]  894 	lcall	_ak820_outline_0036
      00AF5F 90 0C 87         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_617
      00AF62 12 37 DF         [24]  896 	lcall	_ak820_outline_0015
                                    897 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00AF65 90 0C 87         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_617
      00AF68 12 38 00         [24]  899 	lcall	_ak820_outline_0051
                                    900 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00AF6B 90 0C 86         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AF6E E0               [24]  902 	movx	a,@dptr
      00AF6F FD               [12]  903 	mov	r5,a
      00AF70 BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00AF73 80 01            [24]  905 	sjmp	00102$
      00AF75                        906 00258$:
                                    907 ;	quantum/vial.c:190: return;
      00AF75 22               [24]  908 	ret
      00AF76                        909 00102$:
                                    910 ;	quantum/vial.c:193: switch (msg[1]) {
      00AF76 74 01            [12]  911 	mov	a,#0x01
      00AF78 12 4B 29         [24]  912 	lcall	_ak820_outline_0011
      00AF7B FB               [12]  913 	mov  r3,a
      00AF7C 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00AF7E 50 01            [24]  915 	jnc	00259$
      00AF80 22               [24]  916 	ret
      00AF81                        917 00259$:
                                    918 ;	free result
      00AF81 EB               [12]  919 	mov	a,r3
      00AF82 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00AF84 83               [24]  921 	movc	a,@a+pc
      00AF85 F5 82            [12]  922 	mov	dpl,a
      00AF87 EB               [12]  923 	mov	a,r3
      00AF88 24 12            [12]  924 	add	a,#(00261$-3-.)
      00AF8A 83               [24]  925 	movc	a,@a+pc
      00AF8B F5 83            [12]  926 	mov	dph,a
      00AF8D E4               [12]  927 	clr	a
      00AF8E 73               [24]  928 	jmp	@a+dptr
      00AF8F                        929 00260$:
      00AF8F AB                     930 	.db	00103$
      00AF90 F3                     931 	.db	00105$
      00AF91 07                     932 	.db	00106$
      00AF92 93                     933 	.db	00112$
      00AF93 19                     934 	.db	00113$
      00AF94 64                     935 	.db	00114$
      00AF95 D3                     936 	.db	00116$
      00AF96 EE                     937 	.db	00119$
      00AF97 0E                     938 	.db	00120$
      00AF98 1C                     939 	.db	00121$
      00AF99 1C                     940 	.db	00139$
      00AF9A 1C                     941 	.db	00139$
      00AF9B 1C                     942 	.db	00139$
      00AF9C 27                     943 	.db	00122$
      00AF9D                        944 00261$:
      00AF9D AF                     945 	.db	00103$>>8
      00AF9E AF                     946 	.db	00105$>>8
      00AF9F B0                     947 	.db	00106$>>8
      00AFA0 B0                     948 	.db	00112$>>8
      00AFA1 B1                     949 	.db	00113$>>8
      00AFA2 B1                     950 	.db	00114$>>8
      00AFA3 B1                     951 	.db	00116$>>8
      00AFA4 B1                     952 	.db	00119$>>8
      00AFA5 B2                     953 	.db	00120$>>8
      00AFA6 B2                     954 	.db	00121$>>8
      00AFA7 B3                     955 	.db	00139$>>8
      00AFA8 B3                     956 	.db	00139$>>8
      00AFA9 B3                     957 	.db	00139$>>8
      00AFAA B2                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00AFAB                        960 00103$:
                                    961 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00AFAB 90 0C 83         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00AFAE E4               [12]  963 	clr	a
      00AFAF 12 46 3D         [24]  964 	lcall	_ak820_outline_0060
      00AFB2 C0 07            [24]  965 	push	ar7
      00AFB4 C0 06            [24]  966 	push	ar6
      00AFB6 12 AF 31         [24]  967 	lcall	_vial_fill_packet
      00AFB9 D0 06            [24]  968 	pop	ar6
      00AFBB D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00AFBD 12 46 62         [24]  971 	lcall	_ak820_outline_0116
      00AFC0 74 06            [12]  972 	mov	a,#0x06
      00AFC2 12 46 3D         [24]  973 	lcall	_ak820_outline_0060
                                    974 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00AFC5 A3               [24]  975 	inc	dptr
      00AFC6 E4               [12]  976 	clr	a
      00AFC7 12 46 11         [24]  977 	lcall	_ak820_outline_0029
                                    978 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00AFCA 12 46 11         [24]  979 	lcall	_ak820_outline_0029
                                    980 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00AFCD A3               [24]  981 	inc	dptr
      00AFCE F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00AFCF FB               [12]  984 	mov	r3,a
      00AFD0                        985 00131$:
      00AFD0 BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00AFD3                        987 00262$:
      00AFD3 50 15            [24]  988 	jnc	00104$
      00AFD5 8B 02            [24]  989 	mov	ar2,r3
      00AFD7 74 04            [12]  990 	mov	a,#0x04
      00AFD9 2A               [12]  991 	add	a, r2
      00AFDA 2E               [12]  992 	add	a, r6
      00AFDB F9               [12]  993 	mov	r1,a
      00AFDC E4               [12]  994 	clr	a
      00AFDD 3F               [12]  995 	addc	a,r7
      00AFDE FA               [12]  996 	mov	r2,a
      00AFDF EB               [12]  997 	mov	a,r3
      00AFE0 90 C0 E7         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_622
      00AFE3 93               [24]  999 	movc	a,@a+dptr
      00AFE4 12 6F 43         [24] 1000 	lcall	_ak820_outline_0136
      00AFE7 0B               [12] 1001 	inc	r3
      00AFE8 80 E6            [24] 1002 	sjmp	00131$
      00AFEA                       1003 00104$:
                                   1004 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00AFEA 74 0C            [12] 1005 	mov	a,#0x0c
      00AFEC 12 37 F0         [24] 1006 	lcall	_ak820_outline_0030
      00AFEF 74 01            [12] 1007 	mov	a,#0x01
      00AFF1 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:207: break;
      00AFF2 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:210: case vial_get_size: {
      00AFF3                       1012 00105$:
                                   1013 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00AFF3 12 46 62         [24] 1014 	lcall	_ak820_outline_0116
      00AFF6 74 7C            [12] 1015 	mov	a,#0x7c
      00AFF8 12 38 3E         [24] 1016 	lcall	_ak820_outline_0098
                                   1017 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00AFFB 74 01            [12] 1018 	mov	a,#0x01
      00AFFD 12 46 11         [24] 1019 	lcall	_ak820_outline_0029
                                   1020 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B000 E4               [12] 1021 	clr	a
      00B001 12 46 11         [24] 1022 	lcall	_ak820_outline_0029
                                   1023 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B004 A3               [24] 1024 	inc	dptr
      00B005 F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	quantum/vial.c:216: break;
      00B006 22               [24] 1027 	ret
                                   1028 ;	quantum/vial.c:219: case vial_get_def: {
      00B007                       1029 00106$:
                                   1030 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B007 12 AE 3A         [24] 1031 	lcall	_ak820_outline_0020
      00B00A E0               [24] 1032 	movx	a,@dptr
      00B00B FB               [12] 1033 	mov	r3,a
      00B00C 12 46 07         [24] 1034 	lcall	_ak820_outline_0009
      00B00F E0               [24] 1035 	movx	a,@dptr
      00B010 4B               [12] 1036 	orl	a,r3
      00B011 60 01            [24] 1037 	jz	00108$
      00B013 22               [24] 1038 	ret
      00B014                       1039 00108$:
                                   1040 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B014 12 37 F8         [24] 1041 	lcall	_ak820_outline_0033
      00B017 FB               [12] 1042 	mov	r3,a
      00B018 7A 00            [12] 1043 	mov	r2,#0x00
      00B01A 12 AE 31         [24] 1044 	lcall	_ak820_outline_0014
      00B01D F9               [12] 1045 	mov	r1,a
      00B01E E4               [12] 1046 	clr	a
      00B01F 42 03            [12] 1047 	orl	ar3,a
      00B021 E9               [12] 1048 	mov	a,r1
      00B022 42 02            [12] 1049 	orl	ar2,a
                                   1050 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B024 C3               [12] 1051 	clr	c
      00B025 EB               [12] 1052 	mov	a,r3
      00B026 94 0C            [12] 1053 	subb	a,#0x0c
      00B028 EA               [12] 1054 	mov	a,r2
      00B029 94 00            [12] 1055 	subb	a,#0x00
      00B02B 40 01            [24] 1056 	jc	00110$
      00B02D 22               [24] 1057 	ret
      00B02E                       1058 00110$:
                                   1059 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B02E EA               [12] 1060 	mov	a,r2
      00B02F C4               [12] 1061 	swap	a
      00B030 23               [12] 1062 	rl	a
      00B031 54 E0            [12] 1063 	anl	a,#0xe0
      00B033 CB               [12] 1064 	xch	a,r3
      00B034 C4               [12] 1065 	swap	a
      00B035 23               [12] 1066 	rl	a
      00B036 CB               [12] 1067 	xch	a,r3
      00B037 6B               [12] 1068 	xrl	a,r3
      00B038 CB               [12] 1069 	xch	a,r3
      00B039 54 E0            [12] 1070 	anl	a,#0xe0
      00B03B CB               [12] 1071 	xch	a,r3
      00B03C 6B               [12] 1072 	xrl	a,r3
      00B03D FA               [12] 1073 	mov	r2,a
      00B03E 8B 43            [24] 1074 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B040 8A 44            [24] 1075 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1076 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B042 74 7C            [12] 1077 	mov	a,#0x7c
      00B044 C3               [12] 1078 	clr	c
      00B045 95 43            [12] 1079 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B047 F8               [12] 1080 	mov	r0,a
      00B048 74 01            [12] 1081 	mov	a,#0x01
      00B04A 95 44            [12] 1082 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B04C F9               [12] 1083 	mov	r1,a
                                   1084 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B04D C3               [12] 1085 	clr	c
      00B04E E8               [12] 1086 	mov	a,r0
      00B04F 94 20            [12] 1087 	subb	a,#0x20
      00B051 E9               [12] 1088 	mov	a,r1
      00B052 94 00            [12] 1089 	subb	a,#0x00
      00B054 40 02            [24] 1090 	jc	00142$
      00B056 78 20            [12] 1091 	mov	r0,#0x20
      00B058                       1092 00142$:
                                   1093 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B058 79 00            [12] 1094 	mov	r1,#0x00
      00B05A                       1095 00134$:
      00B05A C3               [12] 1096 	clr	c
      00B05B E9               [12] 1097 	mov	a,r1
      00B05C 98               [12] 1098 	subb	a,r0
      00B05D 40 01            [24] 1099 	jc	00267$
      00B05F 22               [24] 1100 	ret
      00B060                       1101 00267$:
      00B060 C0 00            [24] 1102 	push	ar0
      00B062 E9               [12] 1103 	mov	a,r1
      00B063 2E               [12] 1104 	add	a, r6
      00B064 F5 45            [12] 1105 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B066 E4               [12] 1106 	clr	a
      00B067 3F               [12] 1107 	addc	a, r7
      00B068 F5 46            [12] 1108 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B06A 89 47            [24] 1109 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B06C 75 48 00         [24] 1110 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B06F A8 43            [24] 1111 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B071 AB 44            [24] 1112 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B073 E5 47            [12] 1113 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B075 28               [12] 1114 	add	a, r0
      00B076 F8               [12] 1115 	mov	r0,a
      00B077 E5 48            [12] 1116 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B079 3B               [12] 1117 	addc	a, r3
      00B07A FB               [12] 1118 	mov	r3,a
      00B07B E8               [12] 1119 	mov	a,r0
      00B07C 24 6B            [12] 1120 	add	a, #_keyboard_definition
      00B07E F5 82            [12] 1121 	mov	dpl,a
      00B080 EB               [12] 1122 	mov	a,r3
      00B081 34 BF            [12] 1123 	addc	a, #(_keyboard_definition >> 8)
      00B083 F5 83            [12] 1124 	mov	dph,a
      00B085 E4               [12] 1125 	clr	a
      00B086 93               [24] 1126 	movc	a,@a+dptr
      00B087 85 45 82         [24] 1127 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B08A 85 46 83         [24] 1128 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B08D F0               [24] 1129 	movx	@dptr,a
      00B08E 09               [12] 1130 	inc	r1
      00B08F D0 00            [24] 1131 	pop	ar0
                                   1132 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B091 80 C7            [24] 1133 	sjmp	00134$
      00B093                       1134 00112$:
                                   1135 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B093 74 02            [12] 1136 	mov	a,#0x02
      00B095 12 4B 70         [24] 1137 	lcall	_ak820_outline_0046
      00B098 F5 47            [12] 1138 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1139 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B09A 74 03            [12] 1140 	mov	a,#0x03
      00B09C 2E               [12] 1141 	add	a, r6
      00B09D F5 45            [12] 1142 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B09F E4               [12] 1143 	clr	a
      00B0A0 3F               [12] 1144 	addc	a, r7
      00B0A1 F5 46            [12] 1145 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B0A3 85 45 82         [24] 1146 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B0A6 85 46 83         [24] 1147 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B0A9 E0               [24] 1148 	movx	a,@dptr
                                   1149 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B0AA F5 43            [12] 1150 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B0AC 90 0B 31         [24] 1151 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B0AF F0               [24] 1152 	movx	@dptr,a
      00B0B0 90 0B 32         [24] 1153 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B0B3 E4               [12] 1154 	clr	a
      00B0B4 F0               [24] 1155 	movx	@dptr,a
      00B0B5 85 47 82         [24] 1156 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B0B8 C0 07            [24] 1157 	push	ar7
      00B0BA C0 06            [24] 1158 	push	ar6
      00B0BC C0 05            [24] 1159 	push	ar5
      00B0BE C0 04            [24] 1160 	push	ar4
      00B0C0 C0 03            [24] 1161 	push	ar3
      00B0C2 C0 02            [24] 1162 	push	ar2
      00B0C4 12 87 A6         [24] 1163 	lcall	_dynamic_keymap_get_encoder
      00B0C7 85 82 49         [24] 1164 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B0CA 85 83 4A         [24] 1165 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B0CD D0 02            [24] 1166 	pop	ar2
      00B0CF D0 03            [24] 1167 	pop	ar3
      00B0D1 D0 04            [24] 1168 	pop	ar4
      00B0D3 D0 05            [24] 1169 	pop	ar5
      00B0D5 D0 06            [24] 1170 	pop	ar6
      00B0D7 D0 07            [24] 1171 	pop	ar7
                                   1172 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B0D9 A9 4A            [24] 1173 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B0DB 12 46 62         [24] 1174 	lcall	_ak820_outline_0116
      00B0DE E9               [12] 1175 	mov	a,r1
      00B0DF F0               [24] 1176 	movx	@dptr,a
                                   1177 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B0E0 A8 49            [24] 1178 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B0E2 12 38 60         [24] 1179 	lcall	_ak820_outline_0121
      00B0E5 E8               [12] 1180 	mov	a,r0
      00B0E6 F0               [24] 1181 	movx	@dptr,a
                                   1182 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B0E7 90 0B 31         [24] 1183 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B0EA E5 43            [12] 1184 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B0EC F0               [24] 1185 	movx	@dptr,a
      00B0ED 90 0B 32         [24] 1186 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B0F0 74 01            [12] 1187 	mov	a,#0x01
      00B0F2 F0               [24] 1188 	movx	@dptr,a
      00B0F3 85 47 82         [24] 1189 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B0F6 C0 03            [24] 1190 	push	ar3
      00B0F8 C0 02            [24] 1191 	push	ar2
      00B0FA 12 87 A6         [24] 1192 	lcall	_dynamic_keymap_get_encoder
      00B0FD 85 82 49         [24] 1193 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B100 85 83 4A         [24] 1194 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B103 D0 02            [24] 1195 	pop	ar2
      00B105 D0 03            [24] 1196 	pop	ar3
                                   1197 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B107 A9 4A            [24] 1198 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B109 12 46 7E         [24] 1199 	lcall	_ak820_outline_0140
      00B10C E9               [12] 1200 	mov	a,r1
      00B10D F0               [24] 1201 	movx	@dptr,a
                                   1202 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B10E A8 49            [24] 1203 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B110 85 45 82         [24] 1204 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B113 85 46 83         [24] 1205 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B116 E8               [12] 1206 	mov	a,r0
      00B117 F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	quantum/vial.c:255: break;
      00B118 22               [24] 1209 	ret
                                   1210 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B119                       1211 00113$:
                                   1212 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B119 12 37 F8         [24] 1213 	lcall	_ak820_outline_0033
      00B11C F5 45            [12] 1214 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B11E 12 AE 31         [24] 1215 	lcall	_ak820_outline_0014
      00B121 F5 47            [12] 1216 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B123 12 AE 3A         [24] 1217 	lcall	_ak820_outline_0020
      00B126 E0               [24] 1218 	movx	a,@dptr
                                   1219 ;	assignBit
      00B127 24 FF            [12] 1220 	add	a,#0xff
      00B129 E4               [12] 1221 	clr	a
      00B12A 33               [12] 1222 	rlc	a
      00B12B F5 49            [12] 1223 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B12D 12 46 07         [24] 1224 	lcall	_ak820_outline_0009
      00B130 E0               [24] 1225 	movx	a,@dptr
      00B131 F9               [12] 1226 	mov	r1,a
      00B132 78 00            [12] 1227 	mov	r0,#0x00
      00B134 74 06            [12] 1228 	mov	a,#0x06
      00B136 12 37 E7         [24] 1229 	lcall	_ak820_outline_0016
      00B139 7B 00            [12] 1230 	mov	r3,#0x00
      00B13B 42 00            [12] 1231 	orl	ar0,a
      00B13D EB               [12] 1232 	mov	a,r3
      00B13E 42 01            [12] 1233 	orl	ar1,a
      00B140 12 38 75         [24] 1234 	lcall	_ak820_outline_0152
      00B143 12 AF 0E         [24] 1235 	lcall	_vial_keycode_firewall
      00B146 AA 82            [24] 1236 	mov	r2, dpl
      00B148 AB 83            [24] 1237 	mov	r3, dph
      00B14A 90 0B 34         [24] 1238 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B14D E5 47            [12] 1239 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B14F F0               [24] 1240 	movx	@dptr,a
      00B150 90 0B 35         [24] 1241 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B153 E5 49            [12] 1242 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B155 F0               [24] 1243 	movx	@dptr,a
      00B156 90 0B 36         [24] 1244 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B159 EA               [12] 1245 	mov	a,r2
      00B15A F0               [24] 1246 	movx	@dptr,a
      00B15B EB               [12] 1247 	mov	a,r3
      00B15C A3               [24] 1248 	inc	dptr
      00B15D F0               [24] 1249 	movx	@dptr,a
      00B15E 85 45 82         [24] 1250 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1251 ;	quantum/vial.c:259: break;
      00B161 02 88 0D         [24] 1252 	ljmp	_dynamic_keymap_set_encoder
                                   1253 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B164                       1254 00114$:
                                   1255 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B164 90 0C 83         [24] 1256 	mov	dptr,#_vial_fill_packet_PARM_2
      00B167 74 FF            [12] 1257 	mov	a,#0xff
      00B169 12 46 3D         [24] 1258 	lcall	_ak820_outline_0060
      00B16C C0 07            [24] 1259 	push	ar7
      00B16E C0 06            [24] 1260 	push	ar6
      00B170 12 AF 31         [24] 1261 	lcall	_vial_fill_packet
      00B173 D0 06            [24] 1262 	pop	ar6
      00B175 D0 07            [24] 1263 	pop	ar7
                                   1264 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B177 90 0E 46         [24] 1265 	mov	dptr,#_vial_unlocked
      00B17A E0               [24] 1266 	movx	a,@dptr
      00B17B 12 46 62         [24] 1267 	lcall	_ak820_outline_0116
      00B17E F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B17F 74 01            [12] 1270 	mov	a,#0x01
      00B181 2E               [12] 1271 	add	a, r6
      00B182 FA               [12] 1272 	mov	r2,a
      00B183 E4               [12] 1273 	clr	a
      00B184 3F               [12] 1274 	addc	a, r7
      00B185 FB               [12] 1275 	mov	r3,a
      00B186 90 0E 47         [24] 1276 	mov	dptr,#_vial_unlock_in_progress
      00B189 E0               [24] 1277 	movx	a,@dptr
      00B18A 12 46 7E         [24] 1278 	lcall	_ak820_outline_0140
      00B18D F0               [24] 1279 	movx	@dptr,a
                                   1280 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B18E 7B 00            [12] 1281 	mov	r3,#0x00
      00B190                       1282 00137$:
      00B190 BB 02 00         [24] 1283 	cjne	r3,#0x02,00268$
      00B193                       1284 00268$:
      00B193 40 01            [24] 1285 	jc	00269$
      00B195 22               [24] 1286 	ret
      00B196                       1287 00269$:
                                   1288 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B196 8B 01            [24] 1289 	mov	ar1,r3
      00B198 7A 00            [12] 1290 	mov	r2,#0x00
      00B19A E9               [12] 1291 	mov	a,r1
      00B19B 29               [12] 1292 	add	a,r1
      00B19C F5 49            [12] 1293 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B19E EA               [12] 1294 	mov	a,r2
      00B19F 33               [12] 1295 	rlc	a
      00B1A0 F5 4A            [12] 1296 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B1A2 74 02            [12] 1297 	mov	a,#0x02
      00B1A4 25 49            [12] 1298 	add	a, _vial_handle_cmd_sloc3_1_0
      00B1A6 F8               [12] 1299 	mov	r0,a
      00B1A7 E4               [12] 1300 	clr	a
      00B1A8 35 4A            [12] 1301 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B1AA FA               [12] 1302 	mov	r2,a
      00B1AB E8               [12] 1303 	mov	a,r0
      00B1AC 2E               [12] 1304 	add	a, r6
      00B1AD F8               [12] 1305 	mov	r0,a
      00B1AE EA               [12] 1306 	mov	a,r2
      00B1AF 3F               [12] 1307 	addc	a, r7
      00B1B0 FA               [12] 1308 	mov	r2,a
      00B1B1 EB               [12] 1309 	mov	a,r3
      00B1B2 12 B4 3B         [24] 1310 	lcall	_ak820_outline_0126
      00B1B5 88 82            [24] 1311 	mov	dpl,r0
      00B1B7 8A 83            [24] 1312 	mov	dph,r2
      00B1B9 F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B1BA 74 03            [12] 1315 	mov	a,#0x03
      00B1BC 25 49            [12] 1316 	add	a, _vial_handle_cmd_sloc3_1_0
      00B1BE F9               [12] 1317 	mov	r1,a
      00B1BF E4               [12] 1318 	clr	a
      00B1C0 35 4A            [12] 1319 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B1C2 FA               [12] 1320 	mov	r2,a
      00B1C3 E9               [12] 1321 	mov	a,r1
      00B1C4 2E               [12] 1322 	add	a, r6
      00B1C5 F9               [12] 1323 	mov	r1,a
      00B1C6 EA               [12] 1324 	mov	a,r2
      00B1C7 3F               [12] 1325 	addc	a, r7
      00B1C8 FA               [12] 1326 	mov	r2,a
      00B1C9 EB               [12] 1327 	mov	a,r3
      00B1CA 12 B4 30         [24] 1328 	lcall	_ak820_outline_0125
      00B1CD 12 6F 43         [24] 1329 	lcall	_ak820_outline_0136
                                   1330 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B1D0 0B               [12] 1331 	inc	r3
                                   1332 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B1D1 80 BD            [24] 1333 	sjmp	00137$
      00B1D3                       1334 00116$:
                                   1335 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B1D3 90 0E 47         [24] 1336 	mov	dptr,#_vial_unlock_in_progress
      00B1D6 E0               [24] 1337 	movx	a,@dptr
      00B1D7 70 03            [24] 1338 	jnz	00118$
      00B1D9 12 AF 56         [24] 1339 	lcall	_vial_release_held_state
      00B1DC                       1340 00118$:
                                   1341 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B1DC 90 0E 47         [24] 1342 	mov	dptr,#_vial_unlock_in_progress
      00B1DF 74 01            [12] 1343 	mov	a,#0x01
      00B1E1 F0               [24] 1344 	movx	@dptr,a
                                   1345 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B1E2 90 0E 48         [24] 1346 	mov	dptr,#_vial_unlock_counter
      00B1E5 74 1E            [12] 1347 	mov	a,#0x1e
      00B1E7 F0               [24] 1348 	movx	@dptr,a
                                   1349 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B1E8 90 0C 80         [24] 1350 	mov	dptr,#_vial_unlock_holding
      00B1EB E4               [12] 1351 	clr	a
      00B1EC F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/vial.c:287: break;
      00B1ED 22               [24] 1354 	ret
                                   1355 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B1EE                       1356 00119$:
                                   1357 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B1EE 90 0E 46         [24] 1358 	mov	dptr,#_vial_unlocked
      00B1F1 E0               [24] 1359 	movx	a,@dptr
      00B1F2 12 46 62         [24] 1360 	lcall	_ak820_outline_0116
      00B1F5 F0               [24] 1361 	movx	@dptr,a
                                   1362 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B1F6 90 0E 47         [24] 1363 	mov	dptr,#_vial_unlock_in_progress
      00B1F9 E0               [24] 1364 	movx	a,@dptr
      00B1FA 12 38 60         [24] 1365 	lcall	_ak820_outline_0121
      00B1FD F0               [24] 1366 	movx	@dptr,a
                                   1367 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B1FE 74 02            [12] 1368 	mov	a,#0x02
      00B200 2E               [12] 1369 	add	a, r6
      00B201 FA               [12] 1370 	mov	r2,a
      00B202 E4               [12] 1371 	clr	a
      00B203 3F               [12] 1372 	addc	a, r7
      00B204 FB               [12] 1373 	mov	r3,a
      00B205 90 0E 48         [24] 1374 	mov	dptr,#_vial_unlock_counter
      00B208 E0               [24] 1375 	movx	a,@dptr
      00B209 12 46 7E         [24] 1376 	lcall	_ak820_outline_0140
      00B20C F0               [24] 1377 	movx	@dptr,a
                                   1378 ;	quantum/vial.c:293: break;
      00B20D 22               [24] 1379 	ret
                                   1380 ;	quantum/vial.c:295: case vial_lock: {
      00B20E                       1381 00120$:
                                   1382 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B20E 90 0E 46         [24] 1383 	mov	dptr,#_vial_unlocked
      00B211 E4               [12] 1384 	clr	a
      00B212 F0               [24] 1385 	movx	@dptr,a
                                   1386 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B213 90 0E 47         [24] 1387 	mov	dptr,#_vial_unlock_in_progress
      00B216 F0               [24] 1388 	movx	@dptr,a
                                   1389 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B217 90 0C 80         [24] 1390 	mov	dptr,#_vial_unlock_holding
      00B21A F0               [24] 1391 	movx	@dptr,a
                                   1392 ;	quantum/vial.c:301: break;
      00B21B 22               [24] 1393 	ret
                                   1394 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B21C                       1395 00121$:
                                   1396 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B21C 90 0C 83         [24] 1397 	mov	dptr,#_vial_fill_packet_PARM_2
      00B21F 74 FF            [12] 1398 	mov	a,#0xff
      00B221 12 46 3D         [24] 1399 	lcall	_ak820_outline_0060
                                   1400 ;	quantum/vial.c:314: break;
      00B224 02 AF 31         [24] 1401 	ljmp	_vial_fill_packet
                                   1402 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B227                       1403 00122$:
                                   1404 ;	quantum/vial.c:347: switch (msg[2]) {
      00B227 12 37 F8         [24] 1405 	lcall	_ak820_outline_0033
      00B22A FB               [12] 1406 	mov	r3,a
      00B22B 60 0C            [24] 1407 	jz	00123$
      00B22D BB 03 02         [24] 1408 	cjne	r3,#0x03,00272$
      00B230 80 31            [24] 1409 	sjmp	00124$
      00B232                       1410 00272$:
      00B232 BB 04 03         [24] 1411 	cjne	r3,#0x04,00273$
      00B235 02 B2 C1         [24] 1412 	ljmp	00125$
      00B238                       1413 00273$:
      00B238 22               [24] 1414 	ret
                                   1415 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B239                       1416 00123$:
                                   1417 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B239 90 0C 83         [24] 1418 	mov	dptr,#_vial_fill_packet_PARM_2
      00B23C E4               [12] 1419 	clr	a
      00B23D 12 46 3D         [24] 1420 	lcall	_ak820_outline_0060
      00B240 C0 07            [24] 1421 	push	ar7
      00B242 C0 06            [24] 1422 	push	ar6
      00B244 12 AF 31         [24] 1423 	lcall	_vial_fill_packet
      00B247 D0 06            [24] 1424 	pop	ar6
      00B249 D0 07            [24] 1425 	pop	ar7
                                   1426 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B24B 12 46 62         [24] 1427 	lcall	_ak820_outline_0116
      00B24E E4               [12] 1428 	clr	a
      00B24F 12 46 3D         [24] 1429 	lcall	_ak820_outline_0060
                                   1430 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B252 A3               [24] 1431 	inc	dptr
      00B253 74 08            [12] 1432 	mov	a,#0x08
      00B255 12 46 11         [24] 1433 	lcall	_ak820_outline_0029
                                   1434 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B258 E4               [12] 1435 	clr	a
      00B259 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B25A 74 1F            [12] 1438 	mov	a,#0x1f
      00B25C 12 37 F0         [24] 1439 	lcall	_ak820_outline_0030
      00B25F 74 01            [12] 1440 	mov	a,#0x01
      00B261 F0               [24] 1441 	movx	@dptr,a
                                   1442 ;	quantum/vial.c:356: break;
      00B262 22               [24] 1443 	ret
                                   1444 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B263                       1445 00124$:
                                   1446 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B263 12 AE 31         [24] 1447 	lcall	_ak820_outline_0014
      00B266 FB               [12] 1448 	mov	r3,a
                                   1449 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B267 90 0C 8A         [24] 1450 	mov	dptr,#_vial_handle_cmd_entry_70000_645
      00B26A 12 52 3D         [24] 1451 	lcall	_ak820_outline_0178
      00B26D 90 0C 8C         [24] 1452 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0002)
      00B270 F0               [24] 1453 	movx	@dptr,a
      00B271 A3               [24] 1454 	inc	dptr
      00B272 F0               [24] 1455 	movx	@dptr,a
      00B273 90 0C 8E         [24] 1456 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0004)
      00B276 F0               [24] 1457 	movx	@dptr,a
      00B277 A3               [24] 1458 	inc	dptr
      00B278 F0               [24] 1459 	movx	@dptr,a
      00B279 90 0C 90         [24] 1460 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0006)
      00B27C F0               [24] 1461 	movx	@dptr,a
      00B27D A3               [24] 1462 	inc	dptr
      00B27E F0               [24] 1463 	movx	@dptr,a
      00B27F 90 0C 92         [24] 1464 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0008)
      00B282 F0               [24] 1465 	movx	@dptr,a
      00B283 A3               [24] 1466 	inc	dptr
      00B284 F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B285 90 0B 39         [24] 1469 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B288 74 8A            [12] 1470 	mov	a,#_vial_handle_cmd_entry_70000_645
      00B28A F0               [24] 1471 	movx	@dptr,a
      00B28B 74 0C            [12] 1472 	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
      00B28D 12 38 54         [24] 1473 	lcall	_ak820_outline_0117
      00B290 8B 82            [24] 1474 	mov	dpl, r3
      00B292 C0 07            [24] 1475 	push	ar7
      00B294 C0 06            [24] 1476 	push	ar6
      00B296 C0 05            [24] 1477 	push	ar5
      00B298 C0 04            [24] 1478 	push	ar4
      00B29A 12 88 79         [24] 1479 	lcall	_dynamic_keymap_get_combo
      00B29D AA 82            [24] 1480 	mov	r2, dpl
      00B29F D0 04            [24] 1481 	pop	ar4
      00B2A1 D0 05            [24] 1482 	pop	ar5
      00B2A3 D0 06            [24] 1483 	pop	ar6
      00B2A5 D0 07            [24] 1484 	pop	ar7
      00B2A7 12 46 62         [24] 1485 	lcall	_ak820_outline_0116
      00B2AA EA               [12] 1486 	mov	a,r2
      00B2AB F0               [24] 1487 	movx	@dptr,a
                                   1488 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B2AC 7B 00            [12] 1489 	mov	r3,#0x00
      00B2AE 90 0D C6         [24] 1490 	mov	dptr,#___memcpy_PARM_2
      00B2B1 74 8A            [12] 1491 	mov	a,#_vial_handle_cmd_entry_70000_645
      00B2B3 F0               [24] 1492 	movx	@dptr,a
      00B2B4 74 0C            [12] 1493 	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
      00B2B6 12 B4 21         [24] 1494 	lcall	_ak820_outline_0072
      00B2B9 12 38 60         [24] 1495 	lcall	_ak820_outline_0121
      00B2BC 8B F0            [24] 1496 	mov	b, r3
                                   1497 ;	quantum/vial.c:387: break;
      00B2BE 02 B9 ED         [24] 1498 	ljmp	___memcpy
                                   1499 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B2C1                       1500 00125$:
                                   1501 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B2C1 12 AE 31         [24] 1502 	lcall	_ak820_outline_0014
      00B2C4 FD               [12] 1503 	mov	r5,a
                                   1504 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B2C5 74 04            [12] 1505 	mov	a,#0x04
      00B2C7 2E               [12] 1506 	add	a, r6
      00B2C8 FB               [12] 1507 	mov	r3,a
      00B2C9 E4               [12] 1508 	clr	a
      00B2CA 3F               [12] 1509 	addc	a, r7
      00B2CB FC               [12] 1510 	mov	r4,a
      00B2CC 90 0D C6         [24] 1511 	mov	dptr,#___memcpy_PARM_2
      00B2CF EB               [12] 1512 	mov	a,r3
      00B2D0 F0               [24] 1513 	movx	@dptr,a
      00B2D1 EC               [12] 1514 	mov	a,r4
      00B2D2 12 B4 21         [24] 1515 	lcall	_ak820_outline_0072
      00B2D5 90 0C 94         [24] 1516 	mov	dptr,#_vial_handle_cmd_entry_70000_646
      00B2D8 F5 F0            [12] 1517 	mov	b,a
      00B2DA C0 07            [24] 1518 	push	ar7
      00B2DC C0 06            [24] 1519 	push	ar6
      00B2DE C0 05            [24] 1520 	push	ar5
      00B2E0 12 B9 ED         [24] 1521 	lcall	___memcpy
                                   1522 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B2E3 90 0C 9C         [24] 1523 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00B2E6 12 38 5A         [24] 1524 	lcall	_ak820_outline_0120
      00B2E9 12 33 FC         [24] 1525 	lcall	_ak820_outline_0122
      00B2EC 12 AF 0E         [24] 1526 	lcall	_vial_keycode_firewall
      00B2EF AB 82            [24] 1527 	mov	r3, dpl
      00B2F1 AC 83            [24] 1528 	mov	r4, dph
      00B2F3 D0 05            [24] 1529 	pop	ar5
      00B2F5 90 0C 9C         [24] 1530 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00B2F8 12 38 32         [24] 1531 	lcall	_ak820_outline_0077
                                   1532 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B2FB 90 0B 3D         [24] 1533 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B2FE 74 94            [12] 1534 	mov	a,#_vial_handle_cmd_entry_70000_646
      00B300 F0               [24] 1535 	movx	@dptr,a
      00B301 74 0C            [12] 1536 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00B303 12 38 54         [24] 1537 	lcall	_ak820_outline_0117
      00B306 8D 82            [24] 1538 	mov	dpl, r5
      00B308 12 89 20         [24] 1539 	lcall	_dynamic_keymap_set_combo
      00B30B AC 82            [24] 1540 	mov	r4, dpl
      00B30D D0 06            [24] 1541 	pop	ar6
      00B30F D0 07            [24] 1542 	pop	ar7
      00B311 12 46 62         [24] 1543 	lcall	_ak820_outline_0116
      00B314 EC               [12] 1544 	mov	a,r4
      00B315 F0               [24] 1545 	movx	@dptr,a
                                   1546 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B316 EC               [12] 1547 	mov	a,r4
      00B317 70 03            [24] 1548 	jnz	00139$
                                   1549 ;	quantum/vial.c:423: }
                                   1550 ;	quantum/vial.c:424: }
      00B319 02 35 37         [24] 1551 	ljmp	_ak820_combo_reload
      00B31C                       1552 00139$:
      00B31C 22               [24] 1553 	ret
                                   1554 ;------------------------------------------------------------
                                   1555 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1556 ;------------------------------------------------------------
                                   1557 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_648'
                                   1558 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_655'
                                   1559 ;------------------------------------------------------------
                                   1560 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1561 ;	-----------------------------------------
                                   1562 ;	 function vial_keycode_down
                                   1563 ;	-----------------------------------------
      00B31D                       1564 _vial_keycode_down:
      00B31D 12 38 4A         [24] 1565 	lcall	_ak820_outline_0104
      00B320 90 0C A0         [24] 1566 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00B323 12 38 4F         [24] 1567 	lcall	_ak820_outline_0105
                                   1568 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B326 90 0C A0         [24] 1569 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00B329 12 37 CB         [24] 1570 	lcall	_ak820_outline_0010
      00B32C 74 E0            [12] 1571 	mov	a,#0x100 - 0x20
      00B32E 2D               [12] 1572 	add	a,r5
      00B32F 50 19            [24] 1573 	jnc	00104$
      00B331 C3               [12] 1574 	clr	c
      00B332 74 FF            [12] 1575 	mov	a,#0xff
      00B334 9C               [12] 1576 	subb	a,r4
      00B335 74 4F            [12] 1577 	mov	a,#0x4f
      00B337 9D               [12] 1578 	subb	a,r5
      00B338 40 10            [24] 1579 	jc	00104$
                                   1580 ;	free result
                                   1581 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B33A 90 0C A0         [24] 1582 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00B33D EE               [12] 1583 	mov	a,r6
      00B33E 12 38 65         [24] 1584 	lcall	_ak820_outline_0123
                                   1585 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B341 90 0C A0         [24] 1586 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00B344 E0               [24] 1587 	movx	a,@dptr
      00B345 24 FE            [12] 1588 	add	a,#0xff - 0x01
      00B347 40 01            [24] 1589 	jc	00104$
                                   1590 ;	free result
      00B349 22               [24] 1591 	ret
      00B34A                       1592 00104$:
                                   1593 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B34A 90 0C A0         [24] 1594 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00B34D 12 B4 08         [24] 1595 	lcall	_ak820_outline_0023
                                   1596 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B350 40 06            [24] 1597 	jc	00107$
                                   1598 ;	free result
                                   1599 ;	quantum/vial.c:440: register_code16(keycode);
      00B352 12 46 62         [24] 1600 	lcall	_ak820_outline_0116
      00B355 02 A0 2A         [24] 1601 	ljmp	_register_code16
      00B358                       1602 00107$:
                                   1603 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B358 90 0C A6         [24] 1604 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0004)
      00B35B 74 01            [12] 1605 	mov	a,#0x01
      00B35D F0               [24] 1606 	movx	@dptr,a
      00B35E 90 0C A3         [24] 1607 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0001)
      00B361 74 F0            [12] 1608 	mov	a,#0xf0
      00B363 F0               [24] 1609 	movx	@dptr,a
      00B364 90 0C A2         [24] 1610 	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
      00B367 F0               [24] 1611 	movx	@dptr,a
      00B368 90 0C A7         [24] 1612 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0005)
      00B36B 74 01            [12] 1613 	mov	a,#0x01
      00B36D F0               [24] 1614 	movx	@dptr,a
      00B36E 12 4C 1B         [24] 1615 	lcall	_timer_read
      00B371 12 46 6D         [24] 1616 	lcall	_ak820_outline_0131
      00B374 43 06 01         [24] 1617 	orl	ar6,#0x01
      00B377 90 0C A4         [24] 1618 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0002)
      00B37A 12 4B 83         [24] 1619 	lcall	_ak820_outline_0058
                                   1620 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B37D 90 0C A2         [24] 1621 	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
                                   1622 ;	quantum/vial.c:448: }
      00B380 02 73 78         [24] 1623 	ljmp	_ak820_action_exec
                                   1624 ;------------------------------------------------------------
                                   1625 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1626 ;------------------------------------------------------------
                                   1627 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_656'
                                   1628 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_663'
                                   1629 ;------------------------------------------------------------
                                   1630 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1631 ;	-----------------------------------------
                                   1632 ;	 function vial_keycode_up
                                   1633 ;	-----------------------------------------
      00B383                       1634 _vial_keycode_up:
      00B383 12 38 4A         [24] 1635 	lcall	_ak820_outline_0104
      00B386 90 0C A8         [24] 1636 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00B389 12 38 4F         [24] 1637 	lcall	_ak820_outline_0105
                                   1638 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B38C 90 0C A8         [24] 1639 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00B38F 12 37 CB         [24] 1640 	lcall	_ak820_outline_0010
      00B392 74 E0            [12] 1641 	mov	a,#0x100 - 0x20
      00B394 2D               [12] 1642 	add	a,r5
      00B395 50 19            [24] 1643 	jnc	00104$
      00B397 C3               [12] 1644 	clr	c
      00B398 74 FF            [12] 1645 	mov	a,#0xff
      00B39A 9C               [12] 1646 	subb	a,r4
      00B39B 74 4F            [12] 1647 	mov	a,#0x4f
      00B39D 9D               [12] 1648 	subb	a,r5
      00B39E 40 10            [24] 1649 	jc	00104$
                                   1650 ;	free result
                                   1651 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B3A0 90 0C A8         [24] 1652 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00B3A3 EE               [12] 1653 	mov	a,r6
      00B3A4 12 38 65         [24] 1654 	lcall	_ak820_outline_0123
                                   1655 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B3A7 90 0C A8         [24] 1656 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00B3AA E0               [24] 1657 	movx	a,@dptr
      00B3AB 24 FE            [12] 1658 	add	a,#0xff - 0x01
      00B3AD 40 01            [24] 1659 	jc	00104$
                                   1660 ;	free result
      00B3AF 22               [24] 1661 	ret
      00B3B0                       1662 00104$:
                                   1663 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B3B0 90 0C A8         [24] 1664 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00B3B3 12 B4 08         [24] 1665 	lcall	_ak820_outline_0023
                                   1666 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B3B6 40 06            [24] 1667 	jc	00107$
                                   1668 ;	free result
                                   1669 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B3B8 12 46 62         [24] 1670 	lcall	_ak820_outline_0116
      00B3BB 02 A0 6F         [24] 1671 	ljmp	_unregister_code16
      00B3BE                       1672 00107$:
                                   1673 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B3BE 90 0C AE         [24] 1674 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0004)
      00B3C1 74 01            [12] 1675 	mov	a,#0x01
      00B3C3 F0               [24] 1676 	movx	@dptr,a
      00B3C4 90 0C AB         [24] 1677 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0001)
      00B3C7 74 F0            [12] 1678 	mov	a,#0xf0
      00B3C9 F0               [24] 1679 	movx	@dptr,a
      00B3CA 90 0C AA         [24] 1680 	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
      00B3CD F0               [24] 1681 	movx	@dptr,a
      00B3CE 90 0C AF         [24] 1682 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0005)
      00B3D1 E4               [12] 1683 	clr	a
      00B3D2 F0               [24] 1684 	movx	@dptr,a
      00B3D3 12 4C 1B         [24] 1685 	lcall	_timer_read
      00B3D6 12 46 6D         [24] 1686 	lcall	_ak820_outline_0131
      00B3D9 43 06 01         [24] 1687 	orl	ar6,#0x01
      00B3DC 90 0C AC         [24] 1688 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0002)
      00B3DF 12 4B 83         [24] 1689 	lcall	_ak820_outline_0058
                                   1690 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B3E2 90 0C AA         [24] 1691 	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
                                   1692 ;	quantum/vial.c:470: }
      00B3E5 02 73 78         [24] 1693 	ljmp	_ak820_action_exec
                                   1694 ;------------------------------------------------------------
                                   1695 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1696 ;------------------------------------------------------------
                                   1697 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_664'
                                   1698 ;i             Allocated with name '_vial_keycode_tap_i_30000_667'
                                   1699 ;------------------------------------------------------------
                                   1700 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1701 ;	-----------------------------------------
                                   1702 ;	 function vial_keycode_tap
                                   1703 ;	-----------------------------------------
      00B3E8                       1704 _vial_keycode_tap:
      00B3E8 12 38 4A         [24] 1705 	lcall	_ak820_outline_0104
      00B3EB 90 0C B0         [24] 1706 	mov	dptr,#_vial_keycode_tap_keycode_10000_664
      00B3EE 12 38 4F         [24] 1707 	lcall	_ak820_outline_0105
                                   1708 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B3F1 90 0C B0         [24] 1709 	mov	dptr,#_vial_keycode_tap_keycode_10000_664
      00B3F4 12 37 A0         [24] 1710 	lcall	_ak820_outline_0004
      00B3F7 C0 07            [24] 1711 	push	ar7
      00B3F9 C0 06            [24] 1712 	push	ar6
      00B3FB 12 B3 1D         [24] 1713 	lcall	_vial_keycode_down
      00B3FE D0 06            [24] 1714 	pop	ar6
      00B400 D0 07            [24] 1715 	pop	ar7
                                   1716 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B402 12 46 62         [24] 1717 	lcall	_ak820_outline_0116
                                   1718 ;	quantum/vial.c:476: }
      00B405 02 B3 83         [24] 1719 	ljmp	_vial_keycode_up
                                   1720 ;------------------------------------------------------------
                                   1721 ;Allocation info for local variables in function 'process_record_vial'
                                   1722 ;------------------------------------------------------------
                                   1723 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1724 ;keycode       Allocated with name '_process_record_vial_keycode_10000_669'
                                   1725 ;------------------------------------------------------------
                                   1726 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1727 ;	-----------------------------------------
                                   1728 	.area CSEG    (CODE)
                                   1729 	.area CONST   (CODE)
                                   1730 	.area CONST   (CODE)
      00BF6B                       1731 _keyboard_definition:
      00BF6B FD                    1732 	.db #0xfd	; 253
      00BF6C 37                    1733 	.db #0x37	; 55	'7'
      00BF6D 7A                    1734 	.db #0x7a	; 122	'z'
      00BF6E 58                    1735 	.db #0x58	; 88	'X'
      00BF6F 5A                    1736 	.db #0x5a	; 90	'Z'
      00BF70 00                    1737 	.db #0x00	; 0
      00BF71 00                    1738 	.db #0x00	; 0
      00BF72 04                    1739 	.db #0x04	; 4
      00BF73 E6                    1740 	.db #0xe6	; 230
      00BF74 D6                    1741 	.db #0xd6	; 214
      00BF75 B4                    1742 	.db #0xb4	; 180
      00BF76 46                    1743 	.db #0x46	; 70	'F'
      00BF77 02                    1744 	.db #0x02	; 2
      00BF78 00                    1745 	.db #0x00	; 0
      00BF79 21                    1746 	.db #0x21	; 33
      00BF7A 01                    1747 	.db #0x01	; 1
      00BF7B 00                    1748 	.db #0x00	; 0
      00BF7C 00                    1749 	.db #0x00	; 0
      00BF7D 00                    1750 	.db #0x00	; 0
      00BF7E 00                    1751 	.db #0x00	; 0
      00BF7F 37                    1752 	.db #0x37	; 55	'7'
      00BF80 27                    1753 	.db #0x27	; 39
      00BF81 97                    1754 	.db #0x97	; 151
      00BF82 D6                    1755 	.db #0xd6	; 214
      00BF83 E0                    1756 	.db #0xe0	; 224
      00BF84 03                    1757 	.db #0x03	; 3
      00BF85 CB                    1758 	.db #0xcb	; 203
      00BF86 01                    1759 	.db #0x01	; 1
      00BF87 3C                    1760 	.db #0x3c	; 60
      00BF88 00                    1761 	.db #0x00	; 0
      00BF89 00                    1762 	.db #0x00	; 0
      00BF8A 3D                    1763 	.db #0x3d	; 61
      00BF8B 88                    1764 	.db #0x88	; 136
      00BF8C CD                    1765 	.db #0xcd	; 205
      00BF8D A5                    1766 	.db #0xa5	; 165
      00BF8E AA                    1767 	.db #0xaa	; 170
      00BF8F E5                    1768 	.db #0xe5	; 229
      00BF90 A8                    1769 	.db #0xa8	; 168
      00BF91 76                    1770 	.db #0x76	; 118	'v'
      00BF92 F6                    1771 	.db #0xf6	; 246
      00BF93 43                    1772 	.db #0x43	; 67	'C'
      00BF94 0E                    1773 	.db #0x0e	; 14
      00BF95 D2                    1774 	.db #0xd2	; 210
      00BF96 90                    1775 	.db #0x90	; 144
      00BF97 7D                    1776 	.db #0x7d	; 125
      00BF98 94                    1777 	.db #0x94	; 148
      00BF99 79                    1778 	.db #0x79	; 121	'y'
      00BF9A 78                    1779 	.db #0x78	; 120	'x'
      00BF9B EF                    1780 	.db #0xef	; 239
      00BF9C 49                    1781 	.db #0x49	; 73	'I'
      00BF9D 3E                    1782 	.db #0x3e	; 62
      00BF9E EF                    1783 	.db #0xef	; 239
      00BF9F FD                    1784 	.db #0xfd	; 253
      00BFA0 8F                    1785 	.db #0x8f	; 143
      00BFA1 EF                    1786 	.db #0xef	; 239
      00BFA2 00                    1787 	.db #0x00	; 0
      00BFA3 C6                    1788 	.db #0xc6	; 198
      00BFA4 D1                    1789 	.db #0xd1	; 209
      00BFA5 DB                    1790 	.db #0xdb	; 219
      00BFA6 FB                    1791 	.db #0xfb	; 251
      00BFA7 EB                    1792 	.db #0xeb	; 235
      00BFA8 DE                    1793 	.db #0xde	; 222
      00BFA9 66                    1794 	.db #0x66	; 102	'f'
      00BFAA 63                    1795 	.db #0x63	; 99	'c'
      00BFAB 0C                    1796 	.db #0x0c	; 12
      00BFAC 92                    1797 	.db #0x92	; 146
      00BFAD 7B                    1798 	.db #0x7b	; 123
      00BFAE F9                    1799 	.db #0xf9	; 249
      00BFAF D4                    1800 	.db #0xd4	; 212
      00BFB0 7A                    1801 	.db #0x7a	; 122	'z'
      00BFB1 4F                    1802 	.db #0x4f	; 79	'O'
      00BFB2 83                    1803 	.db #0x83	; 131
      00BFB3 4B                    1804 	.db #0x4b	; 75	'K'
      00BFB4 86                    1805 	.db #0x86	; 134
      00BFB5 0E                    1806 	.db #0x0e	; 14
      00BFB6 6A                    1807 	.db #0x6a	; 106	'j'
      00BFB7 F2                    1808 	.db #0xf2	; 242
      00BFB8 22                    1809 	.db #0x22	; 34
      00BFB9 22                    1810 	.db #0x22	; 34
      00BFBA 0B                    1811 	.db #0x0b	; 11
      00BFBB 03                    1812 	.db #0x03	; 3
      00BFBC BA                    1813 	.db #0xba	; 186
      00BFBD 67                    1814 	.db #0x67	; 103	'g'
      00BFBE 9B                    1815 	.db #0x9b	; 155
      00BFBF 7A                    1816 	.db #0x7a	; 122	'z'
      00BFC0 E1                    1817 	.db #0xe1	; 225
      00BFC1 BC                    1818 	.db #0xbc	; 188
      00BFC2 37                    1819 	.db #0x37	; 55	'7'
      00BFC3 26                    1820 	.db #0x26	; 38
      00BFC4 46                    1821 	.db #0x46	; 70	'F'
      00BFC5 78                    1822 	.db #0x78	; 120	'x'
      00BFC6 05                    1823 	.db #0x05	; 5
      00BFC7 0D                    1824 	.db #0x0d	; 13
      00BFC8 95                    1825 	.db #0x95	; 149
      00BFC9 02                    1826 	.db #0x02	; 2
      00BFCA E4                    1827 	.db #0xe4	; 228
      00BFCB 18                    1828 	.db #0x18	; 24
      00BFCC CA                    1829 	.db #0xca	; 202
      00BFCD 33                    1830 	.db #0x33	; 51	'3'
      00BFCE EA                    1831 	.db #0xea	; 234
      00BFCF 24                    1832 	.db #0x24	; 36
      00BFD0 C8                    1833 	.db #0xc8	; 200
      00BFD1 81                    1834 	.db #0x81	; 129
      00BFD2 4E                    1835 	.db #0x4e	; 78	'N'
      00BFD3 47                    1836 	.db #0x47	; 71	'G'
      00BFD4 A8                    1837 	.db #0xa8	; 168
      00BFD5 44                    1838 	.db #0x44	; 68	'D'
      00BFD6 DD                    1839 	.db #0xdd	; 221
      00BFD7 91                    1840 	.db #0x91	; 145
      00BFD8 6D                    1841 	.db #0x6d	; 109	'm'
      00BFD9 69                    1842 	.db #0x69	; 105	'i'
      00BFDA DB                    1843 	.db #0xdb	; 219
      00BFDB 4F                    1844 	.db #0x4f	; 79	'O'
      00BFDC 3A                    1845 	.db #0x3a	; 58
      00BFDD 43                    1846 	.db #0x43	; 67	'C'
      00BFDE 9D                    1847 	.db #0x9d	; 157
      00BFDF 26                    1848 	.db #0x26	; 38
      00BFE0 49                    1849 	.db #0x49	; 73	'I'
      00BFE1 4C                    1850 	.db #0x4c	; 76	'L'
      00BFE2 EF                    1851 	.db #0xef	; 239
      00BFE3 2B                    1852 	.db #0x2b	; 43
      00BFE4 D8                    1853 	.db #0xd8	; 216
      00BFE5 55                    1854 	.db #0x55	; 85	'U'
      00BFE6 95                    1855 	.db #0x95	; 149
      00BFE7 70                    1856 	.db #0x70	; 112	'p'
      00BFE8 B1                    1857 	.db #0xb1	; 177
      00BFE9 CC                    1858 	.db #0xcc	; 204
      00BFEA CF                    1859 	.db #0xcf	; 207
      00BFEB 13                    1860 	.db #0x13	; 19
      00BFEC 32                    1861 	.db #0x32	; 50	'2'
      00BFED 6A                    1862 	.db #0x6a	; 106	'j'
      00BFEE A1                    1863 	.db #0xa1	; 161
      00BFEF FF                    1864 	.db #0xff	; 255
      00BFF0 99                    1865 	.db #0x99	; 153
      00BFF1 61                    1866 	.db #0x61	; 97	'a'
      00BFF2 95                    1867 	.db #0x95	; 149
      00BFF3 B1                    1868 	.db #0xb1	; 177
      00BFF4 89                    1869 	.db #0x89	; 137
      00BFF5 9B                    1870 	.db #0x9b	; 155
      00BFF6 11                    1871 	.db #0x11	; 17
      00BFF7 D9                    1872 	.db #0xd9	; 217
      00BFF8 35                    1873 	.db #0x35	; 53	'5'
      00BFF9 78                    1874 	.db #0x78	; 120	'x'
      00BFFA ED                    1875 	.db #0xed	; 237
      00BFFB CD                    1876 	.db #0xcd	; 205
      00BFFC 94                    1877 	.db #0x94	; 148
      00BFFD 6E                    1878 	.db #0x6e	; 110	'n'
      00BFFE 60                    1879 	.db #0x60	; 96
      00BFFF 8E                    1880 	.db #0x8e	; 142
      00C000 63                    1881 	.db #0x63	; 99	'c'
      00C001 8B                    1882 	.db #0x8b	; 139
      00C002 FF                    1883 	.db #0xff	; 255
      00C003 4E                    1884 	.db #0x4e	; 78	'N'
      00C004 20                    1885 	.db #0x20	; 32
      00C005 7A                    1886 	.db #0x7a	; 122	'z'
      00C006 B5                    1887 	.db #0xb5	; 181
      00C007 87                    1888 	.db #0x87	; 135
      00C008 C2                    1889 	.db #0xc2	; 194
      00C009 35                    1890 	.db #0x35	; 53	'5'
      00C00A A4                    1891 	.db #0xa4	; 164
      00C00B 6D                    1892 	.db #0x6d	; 109	'm'
      00C00C 18                    1893 	.db #0x18	; 24
      00C00D C1                    1894 	.db #0xc1	; 193
      00C00E A3                    1895 	.db #0xa3	; 163
      00C00F DB                    1896 	.db #0xdb	; 219
      00C010 53                    1897 	.db #0x53	; 83	'S'
      00C011 1D                    1898 	.db #0x1d	; 29
      00C012 EC                    1899 	.db #0xec	; 236
      00C013 F0                    1900 	.db #0xf0	; 240
      00C014 BF                    1901 	.db #0xbf	; 191
      00C015 4A                    1902 	.db #0x4a	; 74	'J'
      00C016 4C                    1903 	.db #0x4c	; 76	'L'
      00C017 4A                    1904 	.db #0x4a	; 74	'J'
      00C018 C4                    1905 	.db #0xc4	; 196
      00C019 AA                    1906 	.db #0xaa	; 170
      00C01A 37                    1907 	.db #0x37	; 55	'7'
      00C01B 19                    1908 	.db #0x19	; 25
      00C01C 34                    1909 	.db #0x34	; 52	'4'
      00C01D 3F                    1910 	.db #0x3f	; 63
      00C01E A1                    1911 	.db #0xa1	; 161
      00C01F D3                    1912 	.db #0xd3	; 211
      00C020 1A                    1913 	.db #0x1a	; 26
      00C021 5C                    1914 	.db #0x5c	; 92
      00C022 03                    1915 	.db #0x03	; 3
      00C023 4D                    1916 	.db #0x4d	; 77	'M'
      00C024 BC                    1917 	.db #0xbc	; 188
      00C025 10                    1918 	.db #0x10	; 16
      00C026 2E                    1919 	.db #0x2e	; 46
      00C027 80                    1920 	.db #0x80	; 128
      00C028 F7                    1921 	.db #0xf7	; 247
      00C029 D6                    1922 	.db #0xd6	; 214
      00C02A 82                    1923 	.db #0x82	; 130
      00C02B 24                    1924 	.db #0x24	; 36
      00C02C 4C                    1925 	.db #0x4c	; 76	'L'
      00C02D 87                    1926 	.db #0x87	; 135
      00C02E B9                    1927 	.db #0xb9	; 185
      00C02F F8                    1928 	.db #0xf8	; 248
      00C030 BE                    1929 	.db #0xbe	; 190
      00C031 67                    1930 	.db #0x67	; 103	'g'
      00C032 96                    1931 	.db #0x96	; 150
      00C033 89                    1932 	.db #0x89	; 137
      00C034 30                    1933 	.db #0x30	; 48	'0'
      00C035 C8                    1934 	.db #0xc8	; 200
      00C036 8D                    1935 	.db #0x8d	; 141
      00C037 2C                    1936 	.db #0x2c	; 44
      00C038 F5                    1937 	.db #0xf5	; 245
      00C039 06                    1938 	.db #0x06	; 6
      00C03A 05                    1939 	.db #0x05	; 5
      00C03B 7C                    1940 	.db #0x7c	; 124
      00C03C 48                    1941 	.db #0x48	; 72	'H'
      00C03D 1B                    1942 	.db #0x1b	; 27
      00C03E 76                    1943 	.db #0x76	; 118	'v'
      00C03F AA                    1944 	.db #0xaa	; 170
      00C040 3D                    1945 	.db #0x3d	; 61
      00C041 28                    1946 	.db #0x28	; 40
      00C042 FC                    1947 	.db #0xfc	; 252
      00C043 80                    1948 	.db #0x80	; 128
      00C044 75                    1949 	.db #0x75	; 117	'u'
      00C045 EB                    1950 	.db #0xeb	; 235
      00C046 78                    1951 	.db #0x78	; 120	'x'
      00C047 D0                    1952 	.db #0xd0	; 208
      00C048 8A                    1953 	.db #0x8a	; 138
      00C049 8F                    1954 	.db #0x8f	; 143
      00C04A 27                    1955 	.db #0x27	; 39
      00C04B F7                    1956 	.db #0xf7	; 247
      00C04C F2                    1957 	.db #0xf2	; 242
      00C04D EB                    1958 	.db #0xeb	; 235
      00C04E 58                    1959 	.db #0x58	; 88	'X'
      00C04F 37                    1960 	.db #0x37	; 55	'7'
      00C050 3C                    1961 	.db #0x3c	; 60
      00C051 2B                    1962 	.db #0x2b	; 43
      00C052 6F                    1963 	.db #0x6f	; 111	'o'
      00C053 0E                    1964 	.db #0x0e	; 14
      00C054 C7                    1965 	.db #0xc7	; 199
      00C055 E2                    1966 	.db #0xe2	; 226
      00C056 A0                    1967 	.db #0xa0	; 160
      00C057 97                    1968 	.db #0x97	; 151
      00C058 EE                    1969 	.db #0xee	; 238
      00C059 FD                    1970 	.db #0xfd	; 253
      00C05A 9F                    1971 	.db #0x9f	; 159
      00C05B 45                    1972 	.db #0x45	; 69	'E'
      00C05C 17                    1973 	.db #0x17	; 23
      00C05D 94                    1974 	.db #0x94	; 148
      00C05E E6                    1975 	.db #0xe6	; 230
      00C05F E7                    1976 	.db #0xe7	; 231
      00C060 FA                    1977 	.db #0xfa	; 250
      00C061 4C                    1978 	.db #0x4c	; 76	'L'
      00C062 7A                    1979 	.db #0x7a	; 122	'z'
      00C063 D6                    1980 	.db #0xd6	; 214
      00C064 7A                    1981 	.db #0x7a	; 122	'z'
      00C065 7B                    1982 	.db #0x7b	; 123
      00C066 ED                    1983 	.db #0xed	; 237
      00C067 10                    1984 	.db #0x10	; 16
      00C068 C5                    1985 	.db #0xc5	; 197
      00C069 BC                    1986 	.db #0xbc	; 188
      00C06A E3                    1987 	.db #0xe3	; 227
      00C06B A9                    1988 	.db #0xa9	; 169
      00C06C 1F                    1989 	.db #0x1f	; 31
      00C06D CF                    1990 	.db #0xcf	; 207
      00C06E C4                    1991 	.db #0xc4	; 196
      00C06F 9D                    1992 	.db #0x9d	; 157
      00C070 DC                    1993 	.db #0xdc	; 220
      00C071 45                    1994 	.db #0x45	; 69	'E'
      00C072 2A                    1995 	.db #0x2a	; 42
      00C073 69                    1996 	.db #0x69	; 105	'i'
      00C074 57                    1997 	.db #0x57	; 87	'W'
      00C075 8F                    1998 	.db #0x8f	; 143
      00C076 EC                    1999 	.db #0xec	; 236
      00C077 85                    2000 	.db #0x85	; 133
      00C078 6C                    2001 	.db #0x6c	; 108	'l'
      00C079 43                    2002 	.db #0x43	; 67	'C'
      00C07A 1C                    2003 	.db #0x1c	; 28
      00C07B BA                    2004 	.db #0xba	; 186
      00C07C 89                    2005 	.db #0x89	; 137
      00C07D 68                    2006 	.db #0x68	; 104	'h'
      00C07E 4A                    2007 	.db #0x4a	; 74	'J'
      00C07F 1C                    2008 	.db #0x1c	; 28
      00C080 91                    2009 	.db #0x91	; 145
      00C081 3F                    2010 	.db #0x3f	; 63
      00C082 D1                    2011 	.db #0xd1	; 209
      00C083 B3                    2012 	.db #0xb3	; 179
      00C084 96                    2013 	.db #0x96	; 150
      00C085 1D                    2014 	.db #0x1d	; 29
      00C086 7C                    2015 	.db #0x7c	; 124
      00C087 14                    2016 	.db #0x14	; 20
      00C088 77                    2017 	.db #0x77	; 119	'w'
      00C089 9C                    2018 	.db #0x9c	; 156
      00C08A 74                    2019 	.db #0x74	; 116	't'
      00C08B 36                    2020 	.db #0x36	; 54	'6'
      00C08C FF                    2021 	.db #0xff	; 255
      00C08D 2C                    2022 	.db #0x2c	; 44
      00C08E 66                    2023 	.db #0x66	; 102	'f'
      00C08F AF                    2024 	.db #0xaf	; 175
      00C090 0F                    2025 	.db #0x0f	; 15
      00C091 3C                    2026 	.db #0x3c	; 60
      00C092 A2                    2027 	.db #0xa2	; 162
      00C093 23                    2028 	.db #0x23	; 35
      00C094 85                    2029 	.db #0x85	; 133
      00C095 05                    2030 	.db #0x05	; 5
      00C096 87                    2031 	.db #0x87	; 135
      00C097 DA                    2032 	.db #0xda	; 218
      00C098 61                    2033 	.db #0x61	; 97	'a'
      00C099 5E                    2034 	.db #0x5e	; 94
      00C09A 42                    2035 	.db #0x42	; 66	'B'
      00C09B 54                    2036 	.db #0x54	; 84	'T'
      00C09C 60                    2037 	.db #0x60	; 96
      00C09D 23                    2038 	.db #0x23	; 35
      00C09E CA                    2039 	.db #0xca	; 202
      00C09F BC                    2040 	.db #0xbc	; 188
      00C0A0 B3                    2041 	.db #0xb3	; 179
      00C0A1 18                    2042 	.db #0x18	; 24
      00C0A2 1D                    2043 	.db #0x1d	; 29
      00C0A3 F8                    2044 	.db #0xf8	; 248
      00C0A4 0A                    2045 	.db #0x0a	; 10
      00C0A5 55                    2046 	.db #0x55	; 85	'U'
      00C0A6 CD                    2047 	.db #0xcd	; 205
      00C0A7 A3                    2048 	.db #0xa3	; 163
      00C0A8 DE                    2049 	.db #0xde	; 222
      00C0A9 FF                    2050 	.db #0xff	; 255
      00C0AA B2                    2051 	.db #0xb2	; 178
      00C0AB 2A                    2052 	.db #0x2a	; 42
      00C0AC 35                    2053 	.db #0x35	; 53	'5'
      00C0AD 00                    2054 	.db #0x00	; 0
      00C0AE D6                    2055 	.db #0xd6	; 214
      00C0AF 7B                    2056 	.db #0x7b	; 123
      00C0B0 E8                    2057 	.db #0xe8	; 232
      00C0B1 F2                    2058 	.db #0xf2	; 242
      00C0B2 1A                    2059 	.db #0x1a	; 26
      00C0B3 BC                    2060 	.db #0xbc	; 188
      00C0B4 F5                    2061 	.db #0xf5	; 245
      00C0B5 7E                    2062 	.db #0x7e	; 126
      00C0B6 48                    2063 	.db #0x48	; 72	'H'
      00C0B7 72                    2064 	.db #0x72	; 114	'r'
      00C0B8 E0                    2065 	.db #0xe0	; 224
      00C0B9 E4                    2066 	.db #0xe4	; 228
      00C0BA E0                    2067 	.db #0xe0	; 224
      00C0BB 27                    2068 	.db #0x27	; 39
      00C0BC 87                    2069 	.db #0x87	; 135
      00C0BD 9A                    2070 	.db #0x9a	; 154
      00C0BE 51                    2071 	.db #0x51	; 81	'Q'
      00C0BF D4                    2072 	.db #0xd4	; 212
      00C0C0 DD                    2073 	.db #0xdd	; 221
      00C0C1 C3                    2074 	.db #0xc3	; 195
      00C0C2 AA                    2075 	.db #0xaa	; 170
      00C0C3 49                    2076 	.db #0x49	; 73	'I'
      00C0C4 5A                    2077 	.db #0x5a	; 90	'Z'
      00C0C5 2A                    2078 	.db #0x2a	; 42
      00C0C6 00                    2079 	.db #0x00	; 0
      00C0C7 A0                    2080 	.db #0xa0	; 160
      00C0C8 8C                    2081 	.db #0x8c	; 140
      00C0C9 FF                    2082 	.db #0xff	; 255
      00C0CA 74                    2083 	.db #0x74	; 116	't'
      00C0CB BF                    2084 	.db #0xbf	; 191
      00C0CC EC                    2085 	.db #0xec	; 236
      00C0CD 1D                    2086 	.db #0x1d	; 29
      00C0CE F1                    2087 	.db #0xf1	; 241
      00C0CF 00                    2088 	.db #0x00	; 0
      00C0D0 01                    2089 	.db #0x01	; 1
      00C0D1 D8                    2090 	.db #0xd8	; 216
      00C0D2 02                    2091 	.db #0x02	; 2
      00C0D3 CC                    2092 	.db #0xcc	; 204
      00C0D4 07                    2093 	.db #0x07	; 7
      00C0D5 00                    2094 	.db #0x00	; 0
      00C0D6 00                    2095 	.db #0x00	; 0
      00C0D7 C4                    2096 	.db #0xc4	; 196
      00C0D8 5E                    2097 	.db #0x5e	; 94
      00C0D9 2C                    2098 	.db #0x2c	; 44
      00C0DA 7E                    2099 	.db #0x7e	; 126
      00C0DB B1                    2100 	.db #0xb1	; 177
      00C0DC C4                    2101 	.db #0xc4	; 196
      00C0DD 67                    2102 	.db #0x67	; 103	'g'
      00C0DE FB                    2103 	.db #0xfb	; 251
      00C0DF 02                    2104 	.db #0x02	; 2
      00C0E0 00                    2105 	.db #0x00	; 0
      00C0E1 00                    2106 	.db #0x00	; 0
      00C0E2 00                    2107 	.db #0x00	; 0
      00C0E3 00                    2108 	.db #0x00	; 0
      00C0E4 04                    2109 	.db #0x04	; 4
      00C0E5 59                    2110 	.db #0x59	; 89	'Y'
      00C0E6 5A                    2111 	.db #0x5a	; 90	'Z'
                                   2112 	.area CSEG    (CODE)
                                   2113 	.area CONST   (CODE)
      00C0E7                       2114 _vial_handle_cmd_keyboard_uid_40000_622:
      00C0E7 04                    2115 	.db #0x04	; 4
      00C0E8 70                    2116 	.db #0x70	; 112	'p'
      00C0E9 FF                    2117 	.db #0xff	; 255
      00C0EA 90                    2118 	.db #0x90	; 144
      00C0EB 01                    2119 	.db #0x01	; 1
      00C0EC B9                    2120 	.db #0xb9	; 185
      00C0ED 15                    2121 	.db #0x15	; 21
      00C0EE D3                    2122 	.db #0xd3	; 211
                                   2123 	.area CSEG    (CODE)
                                   2124 	.area XINIT   (CODE)
      00C31D                       2125 __xinit__vial_unlocked:
      00C31D 00                    2126 	.db #0x00	;  0
      00C31E                       2127 __xinit__vial_unlock_in_progress:
      00C31E 00                    2128 	.db #0x00	;  0
      00C31F                       2129 __xinit__vial_unlock_counter:
      00C31F 00                    2130 	.db #0x00	; 0
      00C320                       2131 __xinit__vial_unlock_combo_rows:
      00C320 00                    2132 	.db #0x00	; 0
      00C321 00                    2133 	.db #0x00	; 0
      00C322                       2134 __xinit__vial_unlock_combo_cols:
      00C322 00                    2135 	.db #0x00	; 0
      00C323 05                    2136 	.db #0x05	; 5
                                   2137 	.area CABS    (ABS,CODE)
                                   2138 
                                   2139 ; Experimental exact instruction outlining.
                                   2140 	.globl _ak820_outline_0004
                                   2141 	.globl _ak820_outline_0007
                                   2142 	.globl _ak820_outline_0009
                                   2143 	.globl _ak820_outline_0010
                                   2144 	.globl _ak820_outline_0011
                                   2145 	.globl _ak820_outline_0014
                                   2146 	.globl _ak820_outline_0015
                                   2147 	.globl _ak820_outline_0016
                                   2148 	.globl _ak820_outline_0020
                                   2149 	.globl _ak820_outline_0023
                                   2150 	.globl _ak820_outline_0029
                                   2151 	.globl _ak820_outline_0030
                                   2152 	.globl _ak820_outline_0033
                                   2153 	.globl _ak820_outline_0036
                                   2154 	.globl _ak820_outline_0046
                                   2155 	.globl _ak820_outline_0051
                                   2156 	.globl _ak820_outline_0054
                                   2157 	.globl _ak820_outline_0056
                                   2158 	.globl _ak820_outline_0058
                                   2159 	.globl _ak820_outline_0060
                                   2160 	.globl _ak820_outline_0072
                                   2161 	.globl _ak820_outline_0077
                                   2162 	.globl _ak820_outline_0098
                                   2163 	.globl _ak820_outline_0104
                                   2164 	.globl _ak820_outline_0105
                                   2165 	.globl _ak820_outline_0116
                                   2166 	.globl _ak820_outline_0117
                                   2167 	.globl _ak820_outline_0120
                                   2168 	.globl _ak820_outline_0121
                                   2169 	.globl _ak820_outline_0122
                                   2170 	.globl _ak820_outline_0123
                                   2171 	.globl _ak820_outline_0125
                                   2172 	.globl _ak820_outline_0126
                                   2173 	.globl _ak820_outline_0131
                                   2174 	.globl _ak820_outline_0136
                                   2175 	.globl _ak820_outline_0140
                                   2176 	.globl _ak820_outline_0152
                                   2177 	.globl _ak820_outline_0178
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0023
      00B408                       2181 _ak820_outline_0023:
      00B408 E0               [24] 2182 	movx	a,@dptr
      00B409 FE               [12] 2183 	mov	r6,a
      00B40A A3               [24] 2184 	inc	dptr
      00B40B E0               [24] 2185 	movx	a,@dptr
      00B40C FF               [12] 2186 	mov	r7,a
      00B40D 90 0C 9E         [24] 2187 	mov	dptr,#_g_vial_magic_keycode_override
      00B410 EE               [12] 2188 	mov	a,r6
      00B411 F0               [24] 2189 	movx	@dptr,a
      00B412 EF               [12] 2190 	mov	a,r7
      00B413 A3               [24] 2191 	inc	dptr
      00B414 F0               [24] 2192 	movx	@dptr,a
      00B415 8E 04            [24] 2193 	mov	ar4,r6
      00B417 8F 05            [24] 2194 	mov	ar5,r7
      00B419 C3               [12] 2195 	clr	c
      00B41A 74 FF            [12] 2196 	mov	a,#0xff
      00B41C 9C               [12] 2197 	subb	a,r4
      00B41D 74 1F            [12] 2198 	mov	a,#0x1f
      00B41F 9D               [12] 2199 	subb	a,r5
      00B420 22               [24] 2200 	ret
                                   2201 
                                   2202 	.area CSEG (CODE)
                                   2203 ; function ak820_outline_0072
      00B421                       2204 _ak820_outline_0072:
      00B421 A3               [24] 2205 	inc	dptr
      00B422 F0               [24] 2206 	movx	@dptr,a
      00B423 E4               [12] 2207 	clr	a
      00B424 A3               [24] 2208 	inc	dptr
      00B425 F0               [24] 2209 	movx	@dptr,a
      00B426 90 0D C9         [24] 2210 	mov	dptr,#___memcpy_PARM_3
      00B429 74 0A            [12] 2211 	mov	a,#0x0a
      00B42B F0               [24] 2212 	movx	@dptr,a
      00B42C E4               [12] 2213 	clr	a
      00B42D A3               [24] 2214 	inc	dptr
      00B42E F0               [24] 2215 	movx	@dptr,a
      00B42F 22               [24] 2216 	ret
                                   2217 
                                   2218 	.area CSEG (CODE)
                                   2219 ; function ak820_outline_0125
      00B430                       2220 _ak820_outline_0125:
      00B430 24 4B            [12] 2221 	add	a,#_vial_unlock_combo_cols
      00B432 F5 82            [12] 2222 	mov	dpl,a
      00B434 E4               [12] 2223 	clr	a
      00B435 34 0E            [12] 2224 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B437 F5 83            [12] 2225 	mov	dph,a
      00B439 E0               [24] 2226 	movx	a,@dptr
      00B43A 22               [24] 2227 	ret
                                   2228 
                                   2229 	.area CSEG (CODE)
                                   2230 ; function ak820_outline_0126
      00B43B                       2231 _ak820_outline_0126:
      00B43B 24 49            [12] 2232 	add	a,#_vial_unlock_combo_rows
      00B43D F5 82            [12] 2233 	mov	dpl,a
      00B43F E4               [12] 2234 	clr	a
      00B440 34 0E            [12] 2235 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B442 F5 83            [12] 2236 	mov	dph,a
      00B444 E0               [24] 2237 	movx	a,@dptr
      00B445 22               [24] 2238 	ret
