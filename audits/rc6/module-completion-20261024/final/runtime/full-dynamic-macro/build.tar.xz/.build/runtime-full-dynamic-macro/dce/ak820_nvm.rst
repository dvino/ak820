                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00056F                        109 _page_data:
      00056F                        110 	.ds 64
      0005AF                        111 _cached_page:
      0005AF                        112 	.ds 1
      0005B0                        113 _batch_depth:
      0005B0                        114 	.ds 1
      0005B1                        115 _first_failure_stage:
      0005B1                        116 	.ds 1
      0005B2                        117 _nvm_fail_stage_10000_20:
      0005B2                        118 	.ds 1
      0005B3                        119 _ak820_nvm_diagnostic_out_10000_23:
      0005B3                        120 	.ds 2
      0005B5                        121 _crc_byte_PARM_2:
      0005B5                        122 	.ds 1
      0005B6                        123 _crc_byte_crc_10000_25:
      0005B6                        124 	.ds 2
      0005B8                        125 _page_crc_crc_10000_30:
      0005B8                        126 	.ds 2
      0005BA                        127 _write_page_address_10000_32:
      0005BA                        128 	.ds 2
      0005BC                        129 _journal_header_valid_header_10000_39:
      0005BC                        130 	.ds 2
      0005BE                        131 _recover_journal_header_10000_46:
      0005BE                        132 	.ds 9
      0005C7                        133 _ak820_nvm_flush_header_10000_62:
      0005C7                        134 	.ds 9
      0005D0                        135 _ak820_nvm_flush_stage_10000_62:
      0005D0                        136 	.ds 1
      0005D1                        137 _load_page_page_10000_87:
      0005D1                        138 	.ds 1
      0005D2                        139 _read_offset_offset_10000_93:
      0005D2                        140 	.ds 2
      0005D4                        141 _eeprom_read_byte_addr_10000_97:
      0005D4                        142 	.ds 3
      0005D7                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      0005D7                        144 	.ds 3
      0005DA                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      0005DA                        146 	.ds 2
      0005DC                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      0005DC                        148 	.ds 2
      0005DE                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      0005DE                        150 	.ds 2
      0005E0                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      0005E0                        152 	.ds 3
      0005E3                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005E3                        154 	.ds 2
      0005E5                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005E5                        156 	.ds 2
      0005E7                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005E7                        158 	.ds 3
      0005EA                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005EA                        160 	.ds 2
      0005EC                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005EC                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003E8A                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003E8A E5 82            [12]  215 	mov	a,dpl
      003E8C 90 05 B2         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003E8F F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003E90 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003E93 90 05 B2         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003E96 E0               [24]  221 	movx	a,@dptr
      003E97 90 05 B1         [24]  222 	mov	dptr,#_first_failure_stage
      003E9A F0               [24]  223 	movx	@dptr,a
      003E9B                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003E9B D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003E9D 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003E9E                        239 _ak820_nvm_diagnostic:
      003E9E 12 38 4A         [24]  240 	lcall	_ak820_outline_0104
      003EA1 90 05 B3         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003EA4 12 38 4F         [24]  242 	lcall	_ak820_outline_0105
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003EA7 90 05 B3         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003EAA 12 38 00         [24]  245 	lcall	_ak820_outline_0051
      003EAD A2 09            [12]  246 	mov	c,_storage_failed
      003EAF E4               [12]  247 	clr	a
      003EB0 33               [12]  248 	rlc	a
      003EB1 12 46 62         [24]  249 	lcall	_ak820_outline_0116
      003EB4 12 46 3D         [24]  250 	lcall	_ak820_outline_0060
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003EB7 A3               [24]  252 	inc	dptr
      003EB8 A2 07            [12]  253 	mov	c,_page_valid
      003EBA E4               [12]  254 	clr	a
      003EBB 33               [12]  255 	rlc	a
      003EBC 12 46 11         [24]  256 	lcall	_ak820_outline_0029
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003EBF A2 08            [12]  258 	mov	c,_page_dirty
      003EC1 E4               [12]  259 	clr	a
      003EC2 33               [12]  260 	rlc	a
      003EC3 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003EC4 74 03            [12]  263 	mov	a,#0x03
      003EC6 12 46 8D         [24]  264 	lcall	_ak820_outline_0156
      003EC9 90 05 B0         [24]  265 	mov	dptr,#_batch_depth
      003ECC E0               [24]  266 	movx	a,@dptr
      003ECD 12 38 60         [24]  267 	lcall	_ak820_outline_0121
      003ED0 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003ED1 74 04            [12]  270 	mov	a,#0x04
      003ED3 12 46 8D         [24]  271 	lcall	_ak820_outline_0156
      003ED6 90 05 AF         [24]  272 	mov	dptr,#_cached_page
      003ED9 E0               [24]  273 	movx	a,@dptr
      003EDA 12 38 60         [24]  274 	lcall	_ak820_outline_0121
      003EDD F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003EDE 12 46 07         [24]  277 	lcall	_ak820_outline_0009
      003EE1 E4               [12]  278 	clr	a
      003EE2 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003EE3 74 06            [12]  281 	mov	a,#0x06
      003EE5 12 46 72         [24]  282 	lcall	_ak820_outline_0134
      003EE8 90 05 B1         [24]  283 	mov	dptr,#_first_failure_stage
      003EEB E0               [24]  284 	movx	a,@dptr
      003EEC 12 46 62         [24]  285 	lcall	_ak820_outline_0116
      003EEF F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003EF0 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003EF1                        300 _crc_byte:
      003EF1 12 38 4A         [24]  301 	lcall	_ak820_outline_0104
      003EF4 90 05 B6         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003EF7 12 38 4F         [24]  303 	lcall	_ak820_outline_0105
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003EFA 90 05 B5         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003EFD E0               [24]  306 	movx	a,@dptr
      003EFE FF               [12]  307 	mov	r7,a
      003EFF 7E 00            [12]  308 	mov	r6,#0x00
      003F01 90 05 B6         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003F04 E0               [24]  310 	movx	a,@dptr
      003F05 6E               [12]  311 	xrl	a,r6
      003F06 F0               [24]  312 	movx	@dptr,a
      003F07 A3               [24]  313 	inc	dptr
      003F08 E0               [24]  314 	movx	a,@dptr
      003F09 6F               [12]  315 	xrl	a,r7
      003F0A F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003F0B 7F 00            [12]  318 	mov	r7,#0x00
      003F0D                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003F0D 90 05 B6         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003F10 12 46 50         [24]  322 	lcall	_ak820_outline_0094
      003F13 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003F16 ED               [12]  324 	mov	a,r5
      003F17 2D               [12]  325 	add	a,r5
      003F18 FB               [12]  326 	mov	r3,a
      003F19 EE               [12]  327 	mov	a,r6
      003F1A 33               [12]  328 	rlc	a
      003F1B FC               [12]  329 	mov	r4,a
      003F1C 63 03 21         [24]  330 	xrl	ar3,#0x21
      003F1F 63 04 10         [24]  331 	xrl	ar4,#0x10
      003F22 80 06            [24]  332 	sjmp	00107$
      003F24                        333 00106$:
      003F24 ED               [12]  334 	mov	a,r5
      003F25 2D               [12]  335 	add	a,r5
      003F26 FB               [12]  336 	mov	r3,a
      003F27 EE               [12]  337 	mov	a,r6
      003F28 33               [12]  338 	rlc	a
      003F29 FC               [12]  339 	mov	r4,a
      003F2A                        340 00107$:
      003F2A 90 05 B6         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003F2D 12 38 32         [24]  342 	lcall	_ak820_outline_0077
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003F30 0F               [12]  344 	inc	r7
      003F31 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003F34 12 33 FC         [24]  347 	lcall	_ak820_outline_0122
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003F37 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003F38                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003F38 90 05 B8         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003F3B 74 FF            [12]  363 	mov	a,#0xff
      003F3D F0               [24]  364 	movx	@dptr,a
      003F3E A3               [24]  365 	inc	dptr
      003F3F F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003F40 7F 00            [12]  368 	mov	r7,#0x00
      003F42                        369 00102$:
      003F42 90 05 B8         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003F45 12 46 50         [24]  371 	lcall	_ak820_outline_0094
      003F48 12 46 56         [24]  372 	lcall	_ak820_outline_0102
      003F4B 90 05 B5         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003F4E F0               [24]  374 	movx	@dptr,a
      003F4F 12 38 6A         [24]  375 	lcall	_ak820_outline_0132
      003F52 C0 07            [24]  376 	push	ar7
      003F54 12 3E F1         [24]  377 	lcall	_crc_byte
      003F57 AD 82            [24]  378 	mov	r5, dpl
      003F59 AE 83            [24]  379 	mov	r6, dph
      003F5B D0 07            [24]  380 	pop	ar7
      003F5D 90 05 B8         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003F60 12 46 93         [24]  382 	lcall	_ak820_outline_0157
      003F63 0F               [12]  383 	inc	r7
      003F64 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003F67 12 38 6A         [24]  386 	lcall	_ak820_outline_0132
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003F6A 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003F6B                        399 _write_page:
      003F6B 12 38 4A         [24]  400 	lcall	_ak820_outline_0104
      003F6E 90 05 BA         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003F71 12 38 4F         [24]  402 	lcall	_ak820_outline_0105
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003F74 90 05 BA         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003F77 12 37 A0         [24]  405 	lcall	_ak820_outline_0004
      003F7A C0 07            [24]  406 	push	ar7
      003F7C C0 06            [24]  407 	push	ar6
      003F7E 12 3D 03         [24]  408 	lcall	_ak820_flash_erase
      003F81 E5 82            [12]  409 	mov	a, dpl
      003F83 D0 06            [24]  410 	pop	ar6
      003F85 D0 07            [24]  411 	pop	ar7
      003F87 70 03            [24]  412 	jnz	00102$
      003F89 F5 82            [12]  413 	mov	dpl,a
      003F8B 22               [24]  414 	ret
      003F8C                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003F8C 90 05 4B         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003F8F 74 6F            [12]  418 	mov	a,#_page_data
      003F91 F0               [24]  419 	movx	@dptr,a
      003F92 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003F94 A3               [24]  421 	inc	dptr
      003F95 12 46 3D         [24]  422 	lcall	_ak820_outline_0060
      003F98 12 3E 17         [24]  423 	lcall	_ak820_flash_program_page
      003F9B E5 82            [12]  424 	mov	a, dpl
      003F9D 70 03            [24]  425 	jnz	00120$
      003F9F F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FA1 22               [24]  428 	ret
      003FA2                        429 00120$:
      003FA2 7F 00            [12]  430 	mov	r7,#0x00
      003FA4                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003FA4 8F 05            [24]  433 	mov	ar5,r7
      003FA6 7E 00            [12]  434 	mov	r6,#0x00
      003FA8 90 05 BA         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003FAB 12 38 5A         [24]  436 	lcall	_ak820_outline_0120
      003FAE ED               [12]  437 	mov	a,r5
      003FAF 2B               [12]  438 	add	a, r3
      003FB0 FB               [12]  439 	mov	r3,a
      003FB1 EE               [12]  440 	mov	a,r6
      003FB2 3C               [12]  441 	addc	a, r4
      003FB3 FC               [12]  442 	mov	r4,a
      003FB4 12 33 FC         [24]  443 	lcall	_ak820_outline_0122
      003FB7 12 3B F6         [24]  444 	lcall	_ak820_flash_read
      003FBA AE 82            [24]  445 	mov	r6, dpl
      003FBC 12 46 56         [24]  446 	lcall	_ak820_outline_0102
      003FBF FD               [12]  447 	mov	r5,a
      003FC0 EE               [12]  448 	mov	a,r6
      003FC1 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003FC4 80 04            [24]  450 	sjmp	00109$
      003FC6                        451 00149$:
      003FC6 75 82 00         [24]  452 	mov	dpl, #0x00
      003FC9 22               [24]  453 	ret
      003FCA                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FCA 0F               [12]  456 	inc	r7
      003FCB BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003FCE 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003FD1 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003FD2                        472 _journal_header_valid:
      003FD2 12 38 4A         [24]  473 	lcall	_ak820_outline_0104
      003FD5 90 05 BC         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003FD8 12 38 4F         [24]  475 	lcall	_ak820_outline_0105
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003FDB 90 05 BC         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003FDE 12 37 A0         [24]  478 	lcall	_ak820_outline_0004
      003FE1 E0               [24]  479 	movx	a,@dptr
      003FE2 FD               [12]  480 	mov	r5,a
      003FE3 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003FE6 80 04            [24]  482 	sjmp	00116$
      003FE8                        483 00138$:
      003FE8 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003FEB 22               [24]  486 	ret
      003FEC                        487 00116$:
      003FEC 7D 01            [12]  488 	mov	r5,#0x01
      003FEE                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003FEE ED               [12]  491 	mov	a,r5
      003FEF 12 37 E7         [24]  492 	lcall	_ak820_outline_0016
      003FF2 FC               [12]  493 	mov	r4,a
      003FF3 8D 02            [24]  494 	mov	ar2,r5
      003FF5 7B 00            [12]  495 	mov	r3,#0x00
      003FF7 74 04            [12]  496 	mov	a,#0x04
      003FF9 2A               [12]  497 	add	a, r2
      003FFA FA               [12]  498 	mov	r2,a
      003FFB E4               [12]  499 	clr	a
      003FFC 3B               [12]  500 	addc	a, r3
      003FFD FB               [12]  501 	mov	r3,a
      003FFE EA               [12]  502 	mov	a,r2
      003FFF 2E               [12]  503 	add	a, r6
      004000 F5 82            [12]  504 	mov	dpl,a
      004002 EB               [12]  505 	mov	a,r3
      004003 3F               [12]  506 	addc	a, r7
      004004 F5 83            [12]  507 	mov	dph,a
      004006 E0               [24]  508 	movx	a,@dptr
      004007 62 04            [12]  509 	xrl	ar4,a
      004009 BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      00400C 80 04            [24]  511 	sjmp	00107$
      00400E                        512 00139$:
      00400E 75 82 00         [24]  513 	mov	dpl, #0x00
      004011 22               [24]  514 	ret
      004012                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      004012 0D               [12]  517 	inc	r5
      004013 BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      004016 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      004019 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      00401A                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      00401A 7F 00            [12]  537 	mov	r7,#0x00
      00401C                        538 00115$:
      00401C EF               [12]  539 	mov	a,r7
      00401D 24 BE            [12]  540 	add	a, #_recover_journal_header_10000_46
      00401F FD               [12]  541 	mov	r5,a
      004020 E4               [12]  542 	clr	a
      004021 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      004023 FE               [12]  544 	mov	r6,a
      004024 8F 04            [24]  545 	mov	ar4,r7
      004026 7B 00            [12]  546 	mov	r3,#0x00
      004028 74 40            [12]  547 	mov	a,#0x40
      00402A 2C               [12]  548 	add	a, r4
      00402B FC               [12]  549 	mov	r4,a
      00402C 74 EF            [12]  550 	mov	a,#0xef
      00402E 3B               [12]  551 	addc	a, r3
      00402F FB               [12]  552 	mov	r3,a
      004030 12 46 9E         [24]  553 	lcall	_ak820_outline_0180
      004033 12 3B F6         [24]  554 	lcall	_ak820_flash_read
      004036 AC 82            [24]  555 	mov	r4, dpl
      004038 12 46 43         [24]  556 	lcall	_ak820_outline_0064
      00403B 0F               [12]  557 	inc	r7
      00403C BF 09 DD         [24]  558 	cjne	r7,#0x09,00115$
                                    559 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      00403F 90 05 BE         [24]  560 	mov	dptr,#_recover_journal_header_10000_46
      004042 12 3F D2         [24]  561 	lcall	_journal_header_valid
      004045 E5 82            [12]  562 	mov	a, dpl
      004047 70 01            [24]  563 	jnz	00103$
      004049 22               [24]  564 	ret
      00404A                        565 00103$:
                                    566 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      00404A 90 05 BF         [24]  567 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      00404D E0               [24]  568 	movx	a,@dptr
      00404E FF               [12]  569 	mov	r7,a
      00404F 7E 00            [12]  570 	mov	r6,#0x00
      004051 90 05 C0         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      004054 E0               [24]  572 	movx	a,@dptr
      004055 FC               [12]  573 	mov	r4,a
      004056 E4               [12]  574 	clr	a
      004057 42 07            [12]  575 	orl	ar7,a
      004059 EC               [12]  576 	mov	a,r4
      00405A 42 06            [12]  577 	orl	ar6,a
                                    578 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      00405C 90 05 C1         [24]  579 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      00405F E0               [24]  580 	movx	a,@dptr
      004060 FD               [12]  581 	mov	r5,a
      004061 7C 00            [12]  582 	mov	r4,#0x00
      004063 90 05 C2         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      004066 E0               [24]  584 	movx	a,@dptr
      004067 FA               [12]  585 	mov	r2,a
      004068 E4               [12]  586 	clr	a
      004069 12 46 78         [24]  587 	lcall	_ak820_outline_0139
                                    588 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      00406C C3               [12]  589 	clr	c
      00406D EF               [12]  590 	mov	a,r7
      00406E 94 A0            [12]  591 	subb	a,#0xa0
      004070 EE               [12]  592 	mov	a,r6
      004071 94 00            [12]  593 	subb	a,#0x00
      004073 40 06            [24]  594 	jc	00134$
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      004075 75 82 01         [24]  596 	mov	dpl, #0x01
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      004078 02 3E 8A         [24]  598 	ljmp	_nvm_fail
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      00407B                        600 00134$:
      00407B 7B 00            [12]  601 	mov	r3,#0x00
      00407D                        602 00117$:
      00407D C0 05            [24]  603 	push	ar5
      00407F C0 04            [24]  604 	push	ar4
      004081 EB               [12]  605 	mov	a,r3
      004082 24 6F            [12]  606 	add	a, #_page_data
      004084 F9               [12]  607 	mov	r1,a
      004085 E4               [12]  608 	clr	a
      004086 34 05            [12]  609 	addc	a, #(_page_data >> 8)
      004088 FA               [12]  610 	mov	r2,a
      004089 8B 00            [24]  611 	mov	ar0,r3
      00408B 7D 00            [12]  612 	mov	r5,#0x00
      00408D 74 EF            [12]  613 	mov	a,#0xef
      00408F 2D               [12]  614 	add	a, r5
      004090 FD               [12]  615 	mov	r5,a
      004091 88 82            [24]  616 	mov	dpl, r0
      004093 8D 83            [24]  617 	mov	dph, r5
      004095 12 3B F6         [24]  618 	lcall	_ak820_flash_read
      004098 AD 82            [24]  619 	mov	r5, dpl
      00409A 12 46 99         [24]  620 	lcall	_ak820_outline_0179
      00409D ED               [12]  621 	mov	a,r5
      00409E F0               [24]  622 	movx	@dptr,a
      00409F 0B               [12]  623 	inc	r3
      0040A0 BB 40 02         [24]  624 	cjne	r3,#0x40,00190$
      0040A3 80 06            [24]  625 	sjmp	00191$
      0040A5                        626 00190$:
      0040A5 D0 04            [24]  627 	pop	ar4
      0040A7 D0 05            [24]  628 	pop	ar5
      0040A9 80 D2            [24]  629 	sjmp	00117$
      0040AB                        630 00191$:
      0040AB D0 04            [24]  631 	pop	ar4
      0040AD D0 05            [24]  632 	pop	ar5
                                    633 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      0040AF C0 07            [24]  634 	push	ar7
      0040B1 C0 06            [24]  635 	push	ar6
      0040B3 C0 05            [24]  636 	push	ar5
      0040B5 C0 04            [24]  637 	push	ar4
      0040B7 12 3F 38         [24]  638 	lcall	_page_crc
      0040BA AA 82            [24]  639 	mov	r2, dpl
      0040BC AB 83            [24]  640 	mov	r3, dph
      0040BE D0 04            [24]  641 	pop	ar4
      0040C0 D0 05            [24]  642 	pop	ar5
      0040C2 D0 06            [24]  643 	pop	ar6
      0040C4 D0 07            [24]  644 	pop	ar7
      0040C6 EA               [12]  645 	mov	a,r2
      0040C7 B5 05 06         [24]  646 	cjne	a,ar5,00192$
      0040CA EB               [12]  647 	mov	a,r3
      0040CB B5 04 02         [24]  648 	cjne	a,ar4,00192$
      0040CE 80 06            [24]  649 	sjmp	00113$
      0040D0                        650 00192$:
      0040D0 75 82 02         [24]  651 	mov	dpl, #0x02
      0040D3 02 3E 8A         [24]  652 	ljmp	_nvm_fail
      0040D6                        653 00113$:
                                    654 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      0040D6 EE               [12]  655 	mov	a,r6
      0040D7 54 03            [12]  656 	anl	a,#0x03
      0040D9 A2 E0            [12]  657 	mov	c,acc.0
      0040DB CF               [12]  658 	xch	a,r7
      0040DC 13               [12]  659 	rrc	a
      0040DD CF               [12]  660 	xch	a,r7
      0040DE 13               [12]  661 	rrc	a
      0040DF A2 E0            [12]  662 	mov	c,acc.0
      0040E1 CF               [12]  663 	xch	a,r7
      0040E2 13               [12]  664 	rrc	a
      0040E3 CF               [12]  665 	xch	a,r7
      0040E4 13               [12]  666 	rrc	a
      0040E5 CF               [12]  667 	xch	a,r7
      0040E6 24 C7            [12]  668 	add	a,#0xc7
      0040E8 FE               [12]  669 	mov	r6,a
      0040E9 12 46 88         [24]  670 	lcall	_ak820_outline_0153
      0040EC 12 3F 6B         [24]  671 	lcall	_write_page
      0040EF E5 82            [12]  672 	mov	a, dpl
      0040F1 70 06            [24]  673 	jnz	00110$
      0040F3 75 82 03         [24]  674 	mov	dpl, #0x03
      0040F6 02 3E 8A         [24]  675 	ljmp	_nvm_fail
      0040F9                        676 00110$:
                                    677 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      0040F9 90 EF 40         [24]  678 	mov	dptr,#0xef40
      0040FC 12 3D 03         [24]  679 	lcall	_ak820_flash_erase
      0040FF E5 82            [12]  680 	mov	a, dpl
      004101 70 06            [24]  681 	jnz	00119$
      004103 75 82 04         [24]  682 	mov	dpl, #0x04
                                    683 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      004106 02 3E 8A         [24]  684 	ljmp	_nvm_fail
      004109                        685 00119$:
      004109 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    689 ;------------------------------------------------------------
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    691 ;	-----------------------------------------
                                    692 ;	 function eeprom_driver_init
                                    693 ;	-----------------------------------------
      00410A                        694 _eeprom_driver_init:
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    696 ;	assignBit
      00410A C2 09            [12]  697 	clr	_storage_failed
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      00410C 90 05 B1         [24]  699 	mov	dptr,#_first_failure_stage
      00410F E4               [12]  700 	clr	a
      004110 F0               [24]  701 	movx	@dptr,a
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    703 ;	assignBit
      004111 C2 08            [12]  704 	clr	_page_dirty
                                    705 ;	assignBit
      004113 C2 07            [12]  706 	clr	_page_valid
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      004115 90 05 B0         [24]  708 	mov	dptr,#_batch_depth
      004118 E4               [12]  709 	clr	a
      004119 F0               [24]  710 	movx	@dptr,a
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      00411A 12 40 1A         [24]  712 	lcall	_recover_journal
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      00411D 02 2A B7         [24]  715 	ljmp	_ak820_macro_init
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_nvm_ok
                                    722 ;	-----------------------------------------
      004120                        723 _ak820_nvm_ok:
      004120 A2 09            [12]  724 	mov	c,_storage_failed
      004122 B3               [12]  725 	cpl	c
      004123 92 0A            [24]  726 	mov  _ak820_nvm_ok_sloc0_1_0,c
      004125 12 38 86         [24]  727 	lcall	_ak820_outline_0166
      004128 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    731 ;------------------------------------------------------------
                                    732 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    733 ;	-----------------------------------------
                                    734 ;	 function ak820_nvm_schema_fault
                                    735 ;	-----------------------------------------
      004129                        736 _ak820_nvm_schema_fault:
      004129 75 82 10         [24]  737 	mov	dpl, #0x10
      00412C 02 3E 8A         [24]  738 	ljmp	_nvm_fail
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    741 ;------------------------------------------------------------
                                    742 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    743 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    744 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    745 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_flush
                                    750 ;	-----------------------------------------
      00412F                        751 _ak820_nvm_flush:
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      00412F 30 08 03         [24]  753 	jnb	_page_dirty,00101$
      004132 30 09 01         [24]  754 	jnb	_storage_failed,00102$
      004135                        755 00101$:
      004135 22               [24]  756 	ret
      004136                        757 00102$:
                                    758 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      004136 12 3F 38         [24]  759 	lcall	_page_crc
      004139 12 46 6D         [24]  760 	lcall	_ak820_outline_0131
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      00413C 90 05 C7         [24]  762 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      00413F 74 A5            [12]  763 	mov	a,#0xa5
      004141 F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      004142 90 05 AF         [24]  766 	mov	dptr,#_cached_page
      004145 E0               [24]  767 	movx	a,@dptr
      004146 90 05 C8         [24]  768 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      004149 F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      00414A 90 05 C9         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      00414D E4               [12]  772 	clr	a
      00414E F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      00414F 8E 05            [24]  775 	mov	ar5,r6
      004151 90 05 CA         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      004154 ED               [12]  777 	mov	a,r5
      004155 F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      004156 8F 06            [24]  780 	mov	ar6,r7
      004158 90 05 CB         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      00415B EE               [12]  782 	mov	a,r6
      00415C F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      00415D 7F 01            [12]  785 	mov	r7,#0x01
      00415F                        786 00128$:
      00415F 8F 06            [24]  787 	mov	ar6,r7
      004161 EE               [12]  788 	mov	a,r6
      004162 24 04            [12]  789 	add	a,#0x04
      004164 FE               [12]  790 	mov	r6,a
      004165 33               [12]  791 	rlc	a
      004166 95 E0            [12]  792 	subb	a,acc
      004168 FD               [12]  793 	mov	r5,a
      004169 EE               [12]  794 	mov	a,r6
      00416A 24 C7            [12]  795 	add	a, #_ak820_nvm_flush_header_10000_62
      00416C FE               [12]  796 	mov	r6,a
      00416D ED               [12]  797 	mov	a,r5
      00416E 34 05            [12]  798 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      004170 FD               [12]  799 	mov	r5,a
      004171 12 46 20         [24]  800 	lcall	_ak820_outline_0039
      004174 FC               [12]  801 	mov	r4,a
      004175 63 04 FF         [24]  802 	xrl	ar4,#0xff
      004178 8E 82            [24]  803 	mov	dpl,r6
      00417A 8D 83            [24]  804 	mov	dph,r5
      00417C EC               [12]  805 	mov	a,r4
      00417D F0               [24]  806 	movx	@dptr,a
      00417E 0F               [12]  807 	inc	r7
      00417F BF 05 DD         [24]  808 	cjne	r7,#0x05,00128$
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      004182 90 05 D0         [24]  810 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004185 74 05            [12]  811 	mov	a,#0x05
      004187 F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      004188 90 EF 40         [24]  814 	mov	dptr,#0xef40
      00418B 12 3D 03         [24]  815 	lcall	_ak820_flash_erase
      00418E E5 82            [12]  816 	mov	a, dpl
      004190 70 03            [24]  817 	jnz	00269$
      004192 02 42 79         [24]  818 	ljmp	00127$
      004195                        819 00269$:
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      004195 90 05 D0         [24]  821 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004198 74 06            [12]  822 	mov	a,#0x06
      00419A F0               [24]  823 	movx	@dptr,a
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00419B 7F 00            [12]  825 	mov	r7,#0x00
      00419D                        826 00130$:
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      00419D 12 46 2C         [24]  828 	lcall	_ak820_outline_0052
      0041A0 12 3B F6         [24]  829 	lcall	_ak820_flash_read
      0041A3 E5 82            [12]  830 	mov	a, dpl
      0041A5 60 03            [24]  831 	jz	00270$
      0041A7 02 42 79         [24]  832 	ljmp	00127$
      0041AA                        833 00270$:
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0041AA 0F               [12]  835 	inc	r7
      0041AB BF 40 EF         [24]  836 	cjne	r7,#0x40,00130$
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      0041AE 90 05 D0         [24]  838 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041B1 74 07            [12]  839 	mov	a,#0x07
      0041B3 F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      0041B4 90 EF 00         [24]  842 	mov	dptr,#0xef00
      0041B7 12 3F 6B         [24]  843 	lcall	_write_page
      0041BA E5 82            [12]  844 	mov	a, dpl
      0041BC 70 03            [24]  845 	jnz	00273$
      0041BE 02 42 79         [24]  846 	ljmp	00127$
      0041C1                        847 00273$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      0041C1 90 05 D0         [24]  849 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041C4 74 08            [12]  850 	mov	a,#0x08
      0041C6 F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0041C7 7F 01            [12]  853 	mov	r7,#0x01
      0041C9                        854 00132$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      0041C9 12 46 20         [24]  856 	lcall	_ak820_outline_0039
      0041CC FE               [12]  857 	mov	r6,a
      0041CD 60 23            [24]  858 	jz	00133$
      0041CF 8F 05            [24]  859 	mov	ar5,r7
      0041D1 7C 00            [12]  860 	mov	r4,#0x00
      0041D3 74 40            [12]  861 	mov	a,#0x40
      0041D5 2D               [12]  862 	add	a, r5
      0041D6 FD               [12]  863 	mov	r5,a
      0041D7 74 EF            [12]  864 	mov	a,#0xef
      0041D9 3C               [12]  865 	addc	a, r4
      0041DA FC               [12]  866 	mov	r4,a
      0041DB 90 05 48         [24]  867 	mov	dptr,#_ak820_flash_program_PARM_2
      0041DE EE               [12]  868 	mov	a,r6
      0041DF F0               [24]  869 	movx	@dptr,a
      0041E0 8D 82            [24]  870 	mov	dpl, r5
      0041E2 8C 83            [24]  871 	mov	dph, r4
      0041E4 C0 07            [24]  872 	push	ar7
      0041E6 12 3D 63         [24]  873 	lcall	_ak820_flash_program
      0041E9 E5 82            [12]  874 	mov	a, dpl
      0041EB D0 07            [24]  875 	pop	ar7
      0041ED 70 03            [24]  876 	jnz	00275$
      0041EF 02 42 79         [24]  877 	ljmp	00127$
      0041F2                        878 00275$:
      0041F2                        879 00133$:
                                    880 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0041F2 0F               [12]  881 	inc	r7
      0041F3 BF 09 D3         [24]  882 	cjne	r7,#0x09,00132$
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      0041F6 90 05 D0         [24]  884 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041F9 74 09            [12]  885 	mov	a,#0x09
      0041FB F0               [24]  886 	movx	@dptr,a
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      0041FC 7F 01            [12]  888 	mov	r7,#0x01
      0041FE                        889 00134$:
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      0041FE 12 46 2C         [24]  891 	lcall	_ak820_outline_0052
      004201 12 3B F6         [24]  892 	lcall	_ak820_flash_read
      004204 AE 82            [24]  893 	mov	r6, dpl
      004206 12 46 20         [24]  894 	lcall	_ak820_outline_0039
      004209 FD               [12]  895 	mov	r5,a
      00420A EE               [12]  896 	mov	a,r6
      00420B B5 05 6B         [24]  897 	cjne	a,ar5,00127$
                                    898 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      00420E 0F               [12]  899 	inc	r7
      00420F BF 09 EC         [24]  900 	cjne	r7,#0x09,00134$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      004212 90 05 D0         [24]  902 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004215 74 0A            [12]  903 	mov	a,#0x0a
      004217 F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      004218 90 05 C7         [24]  906 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      00421B E0               [24]  907 	movx	a,@dptr
      00421C 90 05 48         [24]  908 	mov	dptr,#_ak820_flash_program_PARM_2
      00421F F0               [24]  909 	movx	@dptr,a
      004220 90 EF 40         [24]  910 	mov	dptr,#0xef40
      004223 12 3D 63         [24]  911 	lcall	_ak820_flash_program
      004226 E5 82            [12]  912 	mov	a, dpl
      004228 60 4F            [24]  913 	jz	00127$
                                    914 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      00422A 90 05 D0         [24]  915 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00422D 74 0B            [12]  916 	mov	a,#0x0b
      00422F F0               [24]  917 	movx	@dptr,a
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      004230 90 EF 40         [24]  919 	mov	dptr,#0xef40
      004233 12 3B F6         [24]  920 	lcall	_ak820_flash_read
      004236 AF 82            [24]  921 	mov	r7, dpl
      004238 90 05 C7         [24]  922 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      00423B E0               [24]  923 	movx	a,@dptr
      00423C FE               [12]  924 	mov	r6,a
      00423D EF               [12]  925 	mov	a,r7
      00423E B5 06 38         [24]  926 	cjne	a,ar6,00127$
                                    927 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      004241 90 05 D0         [24]  928 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004244 74 0C            [12]  929 	mov	a,#0x0c
      004246 F0               [24]  930 	movx	@dptr,a
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      004247 90 05 AF         [24]  932 	mov	dptr,#_cached_page
      00424A E0               [24]  933 	movx	a,@dptr
      00424B FE               [12]  934 	mov	r6,a
      00424C E4               [12]  935 	clr	a
      00424D C3               [12]  936 	clr	c
      00424E CE               [12]  937 	xch	a,r6
      00424F 13               [12]  938 	rrc	a
      004250 CE               [12]  939 	xch	a,r6
      004251 13               [12]  940 	rrc	a
      004252 A2 E0            [12]  941 	mov	c,acc.0
      004254 CE               [12]  942 	xch	a,r6
      004255 13               [12]  943 	rrc	a
      004256 CE               [12]  944 	xch	a,r6
      004257 13               [12]  945 	rrc	a
      004258 CE               [12]  946 	xch	a,r6
      004259 24 C7            [12]  947 	add	a,#0xc7
      00425B FF               [12]  948 	mov	r7,a
      00425C 12 46 62         [24]  949 	lcall	_ak820_outline_0116
      00425F 12 3F 6B         [24]  950 	lcall	_write_page
      004262 E5 82            [12]  951 	mov	a, dpl
      004264 60 13            [24]  952 	jz	00127$
                                    953 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      004266 90 05 D0         [24]  954 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004269 74 0D            [12]  955 	mov	a,#0x0d
      00426B F0               [24]  956 	movx	@dptr,a
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      00426C 90 EF 40         [24]  958 	mov	dptr,#0xef40
      00426F 12 3D 03         [24]  959 	lcall	_ak820_flash_erase
      004272 E5 82            [12]  960 	mov	a, dpl
      004274 60 03            [24]  961 	jz	00127$
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    963 ;	assignBit
      004276 C2 08            [12]  964 	clr	_page_dirty
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      004278 22               [24]  967 	ret
      004279                        968 00127$:
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      004279 90 05 D0         [24]  970 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00427C E0               [24]  971 	movx	a,@dptr
      00427D F5 82            [12]  972 	mov	dpl,a
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      00427F 02 3E 8A         [24]  974 	ljmp	_nvm_fail
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    977 ;------------------------------------------------------------
                                    978 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function ak820_nvm_begin
                                    981 ;	-----------------------------------------
      004282                        982 _ak820_nvm_begin:
                                    983 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      004282 90 05 B0         [24]  984 	mov	dptr,#_batch_depth
      004285 E0               [24]  985 	movx	a,@dptr
      004286 FF               [12]  986 	mov	r7,a
      004287 BF FF 06         [24]  987 	cjne	r7,#0xff,00102$
      00428A 75 82 0F         [24]  988 	mov	dpl, #0x0f
      00428D 02 3E 8A         [24]  989 	ljmp	_nvm_fail
      004290                        990 00102$:
                                    991 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      004290 90 05 B0         [24]  992 	mov	dptr,#_batch_depth
      004293 EF               [12]  993 	mov	a,r7
      004294 04               [12]  994 	inc	a
      004295 F0               [24]  995 	movx	@dptr,a
                                    996 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      004296 22               [24]  997 	ret
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function ak820_nvm_end
                                   1004 ;	-----------------------------------------
      004297                       1005 _ak820_nvm_end:
                                   1006 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      004297 90 05 B0         [24] 1007 	mov	dptr,#_batch_depth
      00429A E0               [24] 1008 	movx	a,@dptr
      00429B FF               [12] 1009 	mov	r7,a
      00429C E0               [24] 1010 	movx	a,@dptr
      00429D 60 06            [24] 1011 	jz	00102$
      00429F EF               [12] 1012 	mov	a,r7
      0042A0 14               [12] 1013 	dec	a
      0042A1 90 05 B0         [24] 1014 	mov	dptr,#_batch_depth
      0042A4 F0               [24] 1015 	movx	@dptr,a
      0042A5                       1016 00102$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      0042A5 90 05 B0         [24] 1018 	mov	dptr,#_batch_depth
      0042A8 E0               [24] 1019 	movx	a,@dptr
      0042A9 70 03            [24] 1020 	jnz	00105$
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      0042AB 02 41 2F         [24] 1022 	ljmp	_ak820_nvm_flush
      0042AE                       1023 00105$:
      0042AE 22               [24] 1024 	ret
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'load_page'
                                   1027 ;------------------------------------------------------------
                                   1028 ;page          Allocated with name '_load_page_page_10000_87'
                                   1029 ;i             Allocated with name '_load_page_i_10000_88'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function load_page
                                   1034 ;	-----------------------------------------
      0042AF                       1035 _load_page:
      0042AF E5 82            [12] 1036 	mov	a,dpl
      0042B1 90 05 D1         [24] 1037 	mov	dptr,#_load_page_page_10000_87
      0042B4 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      0042B5 30 07 17         [24] 1040 	jnb	_page_valid,00102$
      0042B8 90 05 AF         [24] 1041 	mov	dptr,#_cached_page
      0042BB E0               [24] 1042 	movx	a,@dptr
      0042BC FF               [12] 1043 	mov	r7,a
      0042BD 90 05 D1         [24] 1044 	mov	dptr,#_load_page_page_10000_87
      0042C0 E0               [24] 1045 	movx	a,@dptr
      0042C1 FE               [12] 1046 	mov	r6,a
      0042C2 EF               [12] 1047 	mov	a,r7
      0042C3 B5 06 09         [24] 1048 	cjne	a,ar6,00102$
      0042C6 A2 09            [12] 1049 	mov	c,_storage_failed
      0042C8 B3               [12] 1050 	cpl	c
      0042C9 92 0B            [24] 1051 	mov  _load_page_sloc0_1_0,c
      0042CB 12 38 86         [24] 1052 	lcall	_ak820_outline_0166
      0042CE 22               [24] 1053 	ret
      0042CF                       1054 00102$:
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      0042CF 12 41 2F         [24] 1056 	lcall	_ak820_nvm_flush
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      0042D2 30 09 04         [24] 1058 	jnb	_storage_failed,00119$
      0042D5 75 82 00         [24] 1059 	mov	dpl, #0x00
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042D8 22               [24] 1061 	ret
      0042D9                       1062 00119$:
      0042D9 7F 00            [12] 1063 	mov	r7,#0x00
      0042DB                       1064 00107$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      0042DB EF               [12] 1066 	mov	a,r7
      0042DC 24 6F            [12] 1067 	add	a, #_page_data
      0042DE FD               [12] 1068 	mov	r5,a
      0042DF E4               [12] 1069 	clr	a
      0042E0 34 05            [12] 1070 	addc	a, #(_page_data >> 8)
      0042E2 FE               [12] 1071 	mov	r6,a
      0042E3 90 05 D1         [24] 1072 	mov	dptr,#_load_page_page_10000_87
      0042E6 E0               [24] 1073 	movx	a,@dptr
      0042E7 FC               [12] 1074 	mov	r4,a
      0042E8 FA               [12] 1075 	mov	r2,a
      0042E9 E4               [12] 1076 	clr	a
      0042EA C3               [12] 1077 	clr	c
      0042EB CA               [12] 1078 	xch	a,r2
      0042EC 13               [12] 1079 	rrc	a
      0042ED CA               [12] 1080 	xch	a,r2
      0042EE 13               [12] 1081 	rrc	a
      0042EF A2 E0            [12] 1082 	mov	c,acc.0
      0042F1 CA               [12] 1083 	xch	a,r2
      0042F2 13               [12] 1084 	rrc	a
      0042F3 CA               [12] 1085 	xch	a,r2
      0042F4 13               [12] 1086 	rrc	a
      0042F5 CA               [12] 1087 	xch	a,r2
      0042F6 24 C7            [12] 1088 	add	a,#0xc7
      0042F8 FB               [12] 1089 	mov	r3,a
      0042F9 8F 01            [24] 1090 	mov	ar1,r7
      0042FB 89 00            [24] 1091 	mov	ar0,r1
      0042FD 79 00            [12] 1092 	mov	r1,#0x00
      0042FF E8               [12] 1093 	mov	a,r0
      004300 2A               [12] 1094 	add	a, r2
      004301 FA               [12] 1095 	mov	r2,a
      004302 E9               [12] 1096 	mov	a,r1
      004303 3B               [12] 1097 	addc	a, r3
      004304 FB               [12] 1098 	mov	r3,a
      004305 12 46 7E         [24] 1099 	lcall	_ak820_outline_0140
      004308 12 3B F6         [24] 1100 	lcall	_ak820_flash_read
      00430B AB 82            [24] 1101 	mov	r3, dpl
      00430D 12 38 6A         [24] 1102 	lcall	_ak820_outline_0132
      004310 EB               [12] 1103 	mov	a,r3
      004311 F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004312 0F               [12] 1106 	inc	r7
      004313 BF 40 C5         [24] 1107 	cjne	r7,#0x40,00107$
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004316 90 05 AF         [24] 1109 	mov	dptr,#_cached_page
      004319 EC               [12] 1110 	mov	a,r4
      00431A F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1113 ;	assignBit
      00431B D2 07            [12] 1114 	setb	_page_valid
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      00431D 75 82 01         [24] 1116 	mov	dpl, #0x01
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004320 22               [24] 1118 	ret
                                   1119 ;------------------------------------------------------------
                                   1120 ;Allocation info for local variables in function 'read_offset'
                                   1121 ;------------------------------------------------------------
                                   1122 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1123 ;------------------------------------------------------------
                                   1124 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1125 ;	-----------------------------------------
                                   1126 ;	 function read_offset
                                   1127 ;	-----------------------------------------
      004321                       1128 _read_offset:
      004321 12 38 4A         [24] 1129 	lcall	_ak820_outline_0104
      004324 90 05 D2         [24] 1130 	mov	dptr,#_read_offset_offset_10000_93
      004327 12 38 4F         [24] 1131 	lcall	_ak820_outline_0105
                                   1132 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      00432A 90 05 D2         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      00432D 12 38 00         [24] 1134 	lcall	_ak820_outline_0051
      004330 C3               [12] 1135 	clr	c
      004331 94 28            [12] 1136 	subb	a,#0x28
      004333 40 04            [24] 1137 	jc	00102$
      004335 75 82 00         [24] 1138 	mov	dpl, #0x00
      004338 22               [24] 1139 	ret
      004339                       1140 00102$:
                                   1141 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004339 30 07 34         [24] 1142 	jnb	_page_valid,00104$
      00433C 8E 04            [24] 1143 	mov	ar4,r6
      00433E EF               [12] 1144 	mov	a,r7
      00433F A2 E7            [12] 1145 	mov	c,acc.7
      004341 CC               [12] 1146 	xch	a,r4
      004342 33               [12] 1147 	rlc	a
      004343 CC               [12] 1148 	xch	a,r4
      004344 33               [12] 1149 	rlc	a
      004345 A2 E7            [12] 1150 	mov	c,acc.7
      004347 CC               [12] 1151 	xch	a,r4
      004348 33               [12] 1152 	rlc	a
      004349 CC               [12] 1153 	xch	a,r4
      00434A 33               [12] 1154 	rlc	a
      00434B CC               [12] 1155 	xch	a,r4
      00434C 54 03            [12] 1156 	anl	a,#0x03
      00434E FD               [12] 1157 	mov	r5,a
      00434F 90 05 AF         [24] 1158 	mov	dptr,#_cached_page
      004352 E0               [24] 1159 	movx	a,@dptr
      004353 FA               [12] 1160 	mov	r2,a
      004354 7B 00            [12] 1161 	mov	r3,#0x00
      004356 EC               [12] 1162 	mov	a,r4
      004357 B5 02 16         [24] 1163 	cjne	a,ar2,00104$
      00435A ED               [12] 1164 	mov	a,r5
      00435B B5 03 12         [24] 1165 	cjne	a,ar3,00104$
                                   1166 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      00435E 74 3F            [12] 1167 	mov	a,#0x3f
      004360 5E               [12] 1168 	anl	a,r6
      004361 7D 00            [12] 1169 	mov	r5,#0x00
      004363 24 6F            [12] 1170 	add	a, #_page_data
      004365 F5 82            [12] 1171 	mov	dpl,a
      004367 ED               [12] 1172 	mov	a,r5
      004368 34 05            [12] 1173 	addc	a, #(_page_data >> 8)
      00436A F5 83            [12] 1174 	mov	dph,a
      00436C E0               [24] 1175 	movx	a,@dptr
      00436D F5 82            [12] 1176 	mov	dpl,a
      00436F 22               [24] 1177 	ret
      004370                       1178 00104$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004370 74 C7            [12] 1180 	mov	a,#0xc7
      004372 2F               [12] 1181 	add	a, r7
      004373 FF               [12] 1182 	mov	r7,a
      004374 12 46 62         [24] 1183 	lcall	_ak820_outline_0116
                                   1184 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      004377 02 3B F6         [24] 1185 	ljmp	_ak820_flash_read
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1188 ;------------------------------------------------------------
                                   1189 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function eeprom_read_byte
                                   1194 ;	-----------------------------------------
      00437A                       1195 _eeprom_read_byte:
      00437A C0 07            [24] 1196 	push	ar7
      00437C C0 06            [24] 1197 	push	ar6
      00437E 12 46 19         [24] 1198 	lcall	_ak820_outline_0036
      004381 90 05 D4         [24] 1199 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004384 12 37 DF         [24] 1200 	lcall	_ak820_outline_0015
                                   1201 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      004387 90 05 D4         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00438A 12 37 A0         [24] 1203 	lcall	_ak820_outline_0004
      00438D C0 06            [24] 1204 	push	ar6
      00438F C0 05            [24] 1205 	push	ar5
      004391 C0 04            [24] 1206 	push	ar4
      004393 C0 03            [24] 1207 	push	ar3
      004395 C0 02            [24] 1208 	push	ar2
      004397 C0 01            [24] 1209 	push	ar1
      004399 C0 00            [24] 1210 	push	ar0
      00439B 12 43 21         [24] 1211 	lcall	_read_offset
      00439E AF 82            [24] 1212 	mov	r7, dpl
      0043A0 D0 00            [24] 1213 	pop	ar0
      0043A2 D0 01            [24] 1214 	pop	ar1
      0043A4 D0 02            [24] 1215 	pop	ar2
      0043A6 D0 03            [24] 1216 	pop	ar3
      0043A8 D0 04            [24] 1217 	pop	ar4
      0043AA D0 05            [24] 1218 	pop	ar5
      0043AC D0 06            [24] 1219 	pop	ar6
      0043AE 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0043B0 D0 06            [24] 1222 	pop	ar6
      0043B2 D0 07            [24] 1223 	pop	ar7
      0043B4 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1227 ;------------------------------------------------------------
                                   1228 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1229 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1230 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1231 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1232 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1233 ;------------------------------------------------------------
                                   1234 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1235 ;	-----------------------------------------
                                   1236 ;	 function ak820_eeprom_read_block_xdata
                                   1237 ;	-----------------------------------------
      0043B5                       1238 _ak820_eeprom_read_block_xdata:
      0043B5 12 38 4A         [24] 1239 	lcall	_ak820_outline_0104
      0043B8 90 05 DC         [24] 1240 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0043BB 12 38 4F         [24] 1241 	lcall	_ak820_outline_0105
                                   1242 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0043BE 90 05 D7         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0043C1 12 38 00         [24] 1244 	lcall	_ak820_outline_0051
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0043C4 90 05 DC         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0043C7 12 38 1F         [24] 1247 	lcall	_ak820_outline_0059
      0043CA 90 05 DE         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0043CD 12 38 25         [24] 1249 	lcall	_ak820_outline_0070
                                   1250 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0043D0 90 05 DA         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0043D3 12 38 1F         [24] 1252 	lcall	_ak820_outline_0059
      0043D6                       1253 00103$:
      0043D6 8C 02            [24] 1254 	mov	ar2,r4
      0043D8 8D 03            [24] 1255 	mov	ar3,r5
      0043DA 1C               [12] 1256 	dec	r4
      0043DB BC FF 01         [24] 1257 	cjne	r4,#0xff,00130$
      0043DE 1D               [12] 1258 	dec	r5
      0043DF                       1259 00130$:
      0043DF EA               [12] 1260 	mov	a,r2
      0043E0 4B               [12] 1261 	orl	a,r3
      0043E1 60 5D            [24] 1262 	jz	00106$
                                   1263 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0043E3 8E 02            [24] 1264 	mov	ar2,r6
      0043E5 8F 03            [24] 1265 	mov	ar3,r7
      0043E7 74 D8            [12] 1266 	mov	a,#0x100 - 0x28
      0043E9 2B               [12] 1267 	add	a,r3
      0043EA 50 17            [24] 1268 	jnc	00102$
      0043EC 90 05 DE         [24] 1269 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0043EF 12 46 67         [24] 1270 	lcall	_ak820_outline_0119
      0043F2 12 46 7E         [24] 1271 	lcall	_ak820_outline_0140
      0043F5 E4               [12] 1272 	clr	a
      0043F6 F0               [24] 1273 	movx	@dptr,a
      0043F7 90 05 DE         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0043FA 04               [12] 1275 	inc	a
      0043FB 2A               [12] 1276 	add	a, r2
      0043FC F0               [24] 1277 	movx	@dptr,a
      0043FD E4               [12] 1278 	clr	a
      0043FE 3B               [12] 1279 	addc	a, r3
      0043FF A3               [24] 1280 	inc	dptr
      004400 F0               [24] 1281 	movx	@dptr,a
      004401 80 D3            [24] 1282 	sjmp	00103$
      004403                       1283 00102$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004403 90 05 DE         [24] 1285 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004406 12 46 67         [24] 1286 	lcall	_ak820_outline_0119
      004409 12 46 62         [24] 1287 	lcall	_ak820_outline_0116
      00440C C0 07            [24] 1288 	push	ar7
      00440E C0 06            [24] 1289 	push	ar6
      004410 C0 05            [24] 1290 	push	ar5
      004412 C0 04            [24] 1291 	push	ar4
      004414 C0 03            [24] 1292 	push	ar3
      004416 C0 02            [24] 1293 	push	ar2
      004418 12 43 21         [24] 1294 	lcall	_read_offset
      00441B A9 82            [24] 1295 	mov	r1, dpl
      00441D D0 02            [24] 1296 	pop	ar2
      00441F D0 03            [24] 1297 	pop	ar3
      004421 D0 04            [24] 1298 	pop	ar4
      004423 D0 05            [24] 1299 	pop	ar5
      004425 D0 06            [24] 1300 	pop	ar6
      004427 D0 07            [24] 1301 	pop	ar7
      004429 12 46 7E         [24] 1302 	lcall	_ak820_outline_0140
      00442C E9               [12] 1303 	mov	a,r1
      00442D F0               [24] 1304 	movx	@dptr,a
      00442E 90 05 DE         [24] 1305 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004431 74 01            [12] 1306 	mov	a,#0x01
      004433 2A               [12] 1307 	add	a, r2
      004434 F0               [24] 1308 	movx	@dptr,a
      004435 E4               [12] 1309 	clr	a
      004436 3B               [12] 1310 	addc	a, r3
      004437 A3               [24] 1311 	inc	dptr
      004438 F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004439 0E               [12] 1314 	inc	r6
      00443A BE 00 99         [24] 1315 	cjne	r6,#0x00,00103$
      00443D 0F               [12] 1316 	inc	r7
      00443E 80 96            [24] 1317 	sjmp	00103$
      004440                       1318 00106$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004440 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1325 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1326 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1327 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1328 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1329 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1330 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function ak820_eeprom_write_block_xdata
                                   1335 ;	-----------------------------------------
      004441                       1336 _ak820_eeprom_write_block_xdata:
      004441 12 38 4A         [24] 1337 	lcall	_ak820_outline_0104
      004444 90 05 E5         [24] 1338 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004447 12 38 4F         [24] 1339 	lcall	_ak820_outline_0105
                                   1340 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00444A 90 05 E0         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00444D 12 38 00         [24] 1342 	lcall	_ak820_outline_0051
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004450 90 05 E5         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004453 12 38 1F         [24] 1345 	lcall	_ak820_outline_0059
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004456 8E 02            [24] 1347 	mov	ar2,r6
      004458 8F 03            [24] 1348 	mov	ar3,r7
      00445A C3               [12] 1349 	clr	c
      00445B E4               [12] 1350 	clr	a
      00445C 9A               [12] 1351 	subb	a,r2
      00445D 74 28            [12] 1352 	mov	a,#0x28
      00445F 9B               [12] 1353 	subb	a,r3
      004460 40 15            [24] 1354 	jc	00101$
                                   1355 ;	free result
      004462 E4               [12] 1356 	clr	a
      004463 C3               [12] 1357 	clr	c
      004464 9E               [12] 1358 	subb	a,r6
      004465 FA               [12] 1359 	mov	r2,a
      004466 74 28            [12] 1360 	mov	a,#0x28
      004468 9F               [12] 1361 	subb	a,r7
      004469 FB               [12] 1362 	mov	r3,a
      00446A 90 05 E3         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00446D 12 38 44         [24] 1364 	lcall	_ak820_outline_0100
      004470 C3               [12] 1365 	clr	c
      004471 EA               [12] 1366 	mov	a,r2
      004472 98               [12] 1367 	subb	a,r0
      004473 EB               [12] 1368 	mov	a,r3
      004474 99               [12] 1369 	subb	a,r1
      004475 50 06            [24] 1370 	jnc	00125$
                                   1371 ;	free result
      004477                       1372 00101$:
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004477 75 82 0E         [24] 1374 	mov	dpl, #0x0e
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      00447A 02 3E 8A         [24] 1376 	ljmp	_nvm_fail
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      00447D                       1378 00125$:
      00447D 90 05 E3         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004480 12 46 67         [24] 1380 	lcall	_ak820_outline_0119
      004483                       1381 00108$:
      004483 8A 00            [24] 1382 	mov	ar0,r2
      004485 8B 01            [24] 1383 	mov	ar1,r3
      004487 1A               [12] 1384 	dec	r2
      004488 BA FF 01         [24] 1385 	cjne	r2,#0xff,00159$
      00448B 1B               [12] 1386 	dec	r3
      00448C                       1387 00159$:
      00448C E8               [12] 1388 	mov	a,r0
      00448D 49               [12] 1389 	orl	a,r1
      00448E 70 03            [24] 1390 	jnz	00160$
      004490 02 45 1A         [24] 1391 	ljmp	00110$
      004493                       1392 00160$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004493 C0 02            [24] 1394 	push	ar2
      004495 C0 03            [24] 1395 	push	ar3
      004497 12 46 4A         [24] 1396 	lcall	_ak820_outline_0092
      00449A F9               [12] 1397 	mov	r1,a
      00449B A3               [24] 1398 	inc	dptr
      00449C 12 46 83         [24] 1399 	lcall	_ak820_outline_0141
                                   1400 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      00449F 8E 0C            [24] 1401 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0044A1 8F 0D            [24] 1402 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0044A3 A8 0C            [24] 1403 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0044A5 E5 0D            [12] 1404 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0044A7 A2 E7            [12] 1405 	mov	c,acc.7
      0044A9 C8               [12] 1406 	xch	a,r0
      0044AA 33               [12] 1407 	rlc	a
      0044AB C8               [12] 1408 	xch	a,r0
      0044AC 33               [12] 1409 	rlc	a
      0044AD A2 E7            [12] 1410 	mov	c,acc.7
      0044AF C8               [12] 1411 	xch	a,r0
      0044B0 33               [12] 1412 	rlc	a
      0044B1 C8               [12] 1413 	xch	a,r0
      0044B2 33               [12] 1414 	rlc	a
      0044B3 C8               [12] 1415 	xch	a,r0
      0044B4 54 03            [12] 1416 	anl	a,#0x03
      0044B6 FB               [12] 1417 	mov	r3,a
      0044B7 88 82            [24] 1418 	mov	dpl, r0
      0044B9 C0 07            [24] 1419 	push	ar7
      0044BB C0 06            [24] 1420 	push	ar6
      0044BD C0 05            [24] 1421 	push	ar5
      0044BF C0 04            [24] 1422 	push	ar4
      0044C1 C0 03            [24] 1423 	push	ar3
      0044C3 C0 02            [24] 1424 	push	ar2
      0044C5 C0 01            [24] 1425 	push	ar1
      0044C7 12 42 AF         [24] 1426 	lcall	_load_page
      0044CA E5 82            [12] 1427 	mov	a, dpl
      0044CC D0 01            [24] 1428 	pop	ar1
      0044CE D0 02            [24] 1429 	pop	ar2
      0044D0 D0 03            [24] 1430 	pop	ar3
      0044D2 D0 04            [24] 1431 	pop	ar4
      0044D4 D0 05            [24] 1432 	pop	ar5
      0044D6 D0 06            [24] 1433 	pop	ar6
      0044D8 D0 07            [24] 1434 	pop	ar7
      0044DA D0 03            [24] 1435 	pop	ar3
      0044DC D0 02            [24] 1436 	pop	ar2
      0044DE 70 01            [24] 1437 	jnz	00105$
      0044E0 22               [24] 1438 	ret
      0044E1                       1439 00105$:
                                   1440 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0044E1 C0 06            [24] 1441 	push	ar6
      0044E3 C0 07            [24] 1442 	push	ar7
      0044E5 74 3F            [12] 1443 	mov	a,#0x3f
      0044E7 55 0C            [12] 1444 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0044E9 7F 00            [12] 1445 	mov	r7,#0x00
      0044EB 24 6F            [12] 1446 	add	a, #_page_data
      0044ED F5 0C            [12] 1447 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0044EF EF               [12] 1448 	mov	a,r7
      0044F0 34 05            [12] 1449 	addc	a, #(_page_data >> 8)
      0044F2 F5 0D            [12] 1450 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0044F4 85 0C 82         [24] 1451 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0044F7 85 0D 83         [24] 1452 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0044FA E0               [24] 1453 	movx	a,@dptr
      0044FB B5 01 06         [24] 1454 	cjne	a,ar1,00162$
      0044FE D0 07            [24] 1455 	pop	ar7
      004500 D0 06            [24] 1456 	pop	ar6
      004502 80 0E            [24] 1457 	sjmp	00107$
      004504                       1458 00162$:
      004504 D0 07            [24] 1459 	pop	ar7
      004506 D0 06            [24] 1460 	pop	ar6
                                   1461 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004508 85 0C 82         [24] 1462 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00450B 85 0D 83         [24] 1463 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00450E E9               [12] 1464 	mov	a,r1
      00450F F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1467 ;	assignBit
      004510 D2 08            [12] 1468 	setb	_page_dirty
      004512                       1469 00107$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004512 0E               [12] 1471 	inc	r6
      004513 BE 00 01         [24] 1472 	cjne	r6,#0x00,00163$
      004516 0F               [12] 1473 	inc	r7
      004517                       1474 00163$:
      004517 02 44 83         [24] 1475 	ljmp	00108$
      00451A                       1476 00110$:
                                   1477 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00451A 90 05 B0         [24] 1478 	mov	dptr,#_batch_depth
      00451D E0               [24] 1479 	movx	a,@dptr
      00451E 70 03            [24] 1480 	jnz	00113$
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004520 02 41 2F         [24] 1482 	ljmp	_ak820_nvm_flush
      004523                       1483 00113$:
      004523 22               [24] 1484 	ret
                                   1485 ;------------------------------------------------------------
                                   1486 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1487 ;------------------------------------------------------------
                                   1488 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1489 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1490 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1491 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1492 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1493 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1494 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1495 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1496 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1497 ;------------------------------------------------------------
                                   1498 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1499 ;	-----------------------------------------
                                   1500 ;	 function ak820_eeprom_update_block_xdata
                                   1501 ;	-----------------------------------------
      004524                       1502 _ak820_eeprom_update_block_xdata:
      004524 12 38 4A         [24] 1503 	lcall	_ak820_outline_0104
      004527 90 05 EC         [24] 1504 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00452A 12 38 4F         [24] 1505 	lcall	_ak820_outline_0105
                                   1506 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      00452D 90 05 EC         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004530 12 38 00         [24] 1508 	lcall	_ak820_outline_0051
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004533 90 05 E7         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004536 E0               [24] 1511 	movx	a,@dptr
      004537 F5 12            [12] 1512 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004539 A3               [24] 1513 	inc	dptr
      00453A E0               [24] 1514 	movx	a,@dptr
      00453B F5 13            [12] 1515 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      00453D A3               [24] 1516 	inc	dptr
      00453E E0               [24] 1517 	movx	a,@dptr
      00453F F5 14            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004541 A9 12            [24] 1519 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004543 AA 13            [24] 1520 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1521 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004545 E4               [12] 1522 	clr	a
      004546 F5 0E            [12] 1523 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004548 F5 0F            [12] 1524 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00454A                       1525 00105$:
      00454A 90 05 EA         [24] 1526 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00454D E0               [24] 1527 	movx	a,@dptr
      00454E F5 10            [12] 1528 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004550 A3               [24] 1529 	inc	dptr
      004551 E0               [24] 1530 	movx	a,@dptr
      004552 F5 11            [12] 1531 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004554 C3               [12] 1532 	clr	c
      004555 E5 0E            [12] 1533 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004557 95 10            [12] 1534 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004559 E5 0F            [12] 1535 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00455B 95 11            [12] 1536 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00455D 50 68            [24] 1537 	jnc	00107$
                                   1538 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      00455F 89 00            [24] 1539 	mov	ar0,r1
      004561 8A 05            [24] 1540 	mov	ar5,r2
      004563 E5 0E            [12] 1541 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004565 28               [12] 1542 	add	a, r0
      004566 F8               [12] 1543 	mov	r0,a
      004567 E5 0F            [12] 1544 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004569 3D               [12] 1545 	addc	a, r5
      00456A FD               [12] 1546 	mov	r5,a
      00456B 88 82            [24] 1547 	mov	dpl, r0
      00456D 8D 83            [24] 1548 	mov	dph, r5
      00456F C0 07            [24] 1549 	push	ar7
      004571 C0 06            [24] 1550 	push	ar6
      004573 C0 02            [24] 1551 	push	ar2
      004575 C0 01            [24] 1552 	push	ar1
      004577 12 43 21         [24] 1553 	lcall	_read_offset
      00457A AD 82            [24] 1554 	mov	r5, dpl
      00457C D0 01            [24] 1555 	pop	ar1
      00457E D0 02            [24] 1556 	pop	ar2
      004580 D0 06            [24] 1557 	pop	ar6
      004582 D0 07            [24] 1558 	pop	ar7
      004584 E5 0E            [12] 1559 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004586 2E               [12] 1560 	add	a, r6
      004587 F5 82            [12] 1561 	mov	dpl,a
      004589 E5 0F            [12] 1562 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00458B 3F               [12] 1563 	addc	a, r7
      00458C F5 83            [12] 1564 	mov	dph,a
      00458E E0               [24] 1565 	movx	a,@dptr
      00458F FC               [12] 1566 	mov	r4,a
      004590 ED               [12] 1567 	mov	a,r5
      004591 B5 04 02         [24] 1568 	cjne	a,ar4,00131$
      004594 80 27            [24] 1569 	sjmp	00106$
      004596                       1570 00131$:
                                   1571 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004596 90 05 EC         [24] 1572 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004599 E0               [24] 1573 	movx	a,@dptr
      00459A F8               [12] 1574 	mov	r0,a
      00459B A3               [24] 1575 	inc	dptr
      00459C E0               [24] 1576 	movx	a,@dptr
      00459D FD               [12] 1577 	mov	r5,a
      00459E 90 05 E0         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0045A1 E5 12            [12] 1579 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0045A3 F0               [24] 1580 	movx	@dptr,a
      0045A4 E5 13            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0045A6 A3               [24] 1582 	inc	dptr
      0045A7 F0               [24] 1583 	movx	@dptr,a
      0045A8 E5 14            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0045AA A3               [24] 1585 	inc	dptr
      0045AB F0               [24] 1586 	movx	@dptr,a
      0045AC 90 05 E3         [24] 1587 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0045AF E5 10            [12] 1588 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0045B1 F0               [24] 1589 	movx	@dptr,a
      0045B2 E5 11            [12] 1590 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0045B4 A3               [24] 1591 	inc	dptr
      0045B5 F0               [24] 1592 	movx	@dptr,a
      0045B6 88 82            [24] 1593 	mov	dpl, r0
      0045B8 8D 83            [24] 1594 	mov	dph, r5
                                   1595 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0045BA 02 44 41         [24] 1596 	ljmp	_ak820_eeprom_write_block_xdata
      0045BD                       1597 00106$:
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0045BD 05 0E            [12] 1599 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0045BF E4               [12] 1600 	clr	a
      0045C0 B5 0E 87         [24] 1601 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0045C3 05 0F            [12] 1602 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0045C5 80 83            [24] 1603 	sjmp	00105$
      0045C7                       1604 00107$:
                                   1605 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0045C7 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1609 ;------------------------------------------------------------
                                   1610 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1611 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function eeprom_driver_erase
                                   1616 ;	-----------------------------------------
      0045C8                       1617 _eeprom_driver_erase:
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0045C8 12 41 2F         [24] 1619 	lcall	_ak820_nvm_flush
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0045CB 7F 00            [12] 1621 	mov	r7,#0x00
      0045CD                       1622 00111$:
      0045CD BF A0 01         [24] 1623 	cjne	r7,#0xa0,00165$
      0045D0 22               [24] 1624 	ret
      0045D1                       1625 00165$:
      0045D1 20 09 32         [24] 1626 	jb	_storage_failed,00113$
                                   1627 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0045D4 8F 82            [24] 1628 	mov	dpl, r7
      0045D6 C0 07            [24] 1629 	push	ar7
      0045D8 12 42 AF         [24] 1630 	lcall	_load_page
      0045DB E5 82            [12] 1631 	mov	a, dpl
      0045DD D0 07            [24] 1632 	pop	ar7
      0045DF 70 01            [24] 1633 	jnz	00126$
                                   1634 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0045E1 22               [24] 1635 	ret
      0045E2                       1636 00126$:
      0045E2 7E 00            [12] 1637 	mov	r6,#0x00
      0045E4                       1638 00107$:
                                   1639 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0045E4 EE               [12] 1640 	mov	a,r6
      0045E5 24 6F            [12] 1641 	add	a, #_page_data
      0045E7 FC               [12] 1642 	mov	r4,a
      0045E8 E4               [12] 1643 	clr	a
      0045E9 34 05            [12] 1644 	addc	a, #(_page_data >> 8)
      0045EB FD               [12] 1645 	mov	r5,a
      0045EC 12 46 4A         [24] 1646 	lcall	_ak820_outline_0092
      0045EF 60 07            [24] 1647 	jz	00108$
      0045F1 12 38 60         [24] 1648 	lcall	_ak820_outline_0121
      0045F4 E4               [12] 1649 	clr	a
      0045F5 F0               [24] 1650 	movx	@dptr,a
                                   1651 ;	assignBit
      0045F6 D2 08            [12] 1652 	setb	_page_dirty
      0045F8                       1653 00108$:
                                   1654 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0045F8 0E               [12] 1655 	inc	r6
      0045F9 BE 40 E8         [24] 1656 	cjne	r6,#0x40,00107$
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0045FC C0 07            [24] 1658 	push	ar7
      0045FE 12 41 2F         [24] 1659 	lcall	_ak820_nvm_flush
      004601 D0 07            [24] 1660 	pop	ar7
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004603 0F               [12] 1662 	inc	r7
      004604 80 C7            [24] 1663 	sjmp	00111$
      004606                       1664 00113$:
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004606 22               [24] 1666 	ret
                                   1667 	.area CSEG    (CODE)
                                   1668 	.area CONST   (CODE)
                                   1669 	.area XINIT   (CODE)
                                   1670 	.area CABS    (ABS,CODE)
                                   1671 
                                   1672 ; Experimental exact instruction outlining.
                                   1673 	.globl _ak820_outline_0004
                                   1674 	.globl _ak820_outline_0009
                                   1675 	.globl _ak820_outline_0015
                                   1676 	.globl _ak820_outline_0016
                                   1677 	.globl _ak820_outline_0029
                                   1678 	.globl _ak820_outline_0036
                                   1679 	.globl _ak820_outline_0039
                                   1680 	.globl _ak820_outline_0051
                                   1681 	.globl _ak820_outline_0052
                                   1682 	.globl _ak820_outline_0059
                                   1683 	.globl _ak820_outline_0060
                                   1684 	.globl _ak820_outline_0064
                                   1685 	.globl _ak820_outline_0070
                                   1686 	.globl _ak820_outline_0077
                                   1687 	.globl _ak820_outline_0092
                                   1688 	.globl _ak820_outline_0094
                                   1689 	.globl _ak820_outline_0100
                                   1690 	.globl _ak820_outline_0102
                                   1691 	.globl _ak820_outline_0104
                                   1692 	.globl _ak820_outline_0105
                                   1693 	.globl _ak820_outline_0116
                                   1694 	.globl _ak820_outline_0119
                                   1695 	.globl _ak820_outline_0120
                                   1696 	.globl _ak820_outline_0121
                                   1697 	.globl _ak820_outline_0122
                                   1698 	.globl _ak820_outline_0131
                                   1699 	.globl _ak820_outline_0132
                                   1700 	.globl _ak820_outline_0134
                                   1701 	.globl _ak820_outline_0139
                                   1702 	.globl _ak820_outline_0140
                                   1703 	.globl _ak820_outline_0141
                                   1704 	.globl _ak820_outline_0153
                                   1705 	.globl _ak820_outline_0156
                                   1706 	.globl _ak820_outline_0157
                                   1707 	.globl _ak820_outline_0166
                                   1708 	.globl _ak820_outline_0179
                                   1709 	.globl _ak820_outline_0180
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0009
      004607                       1713 _ak820_outline_0009:
      004607 8E 82            [24] 1714 	mov	dpl,r6
      004609 8F 83            [24] 1715 	mov	dph,r7
      00460B A3               [24] 1716 	inc	dptr
      00460C A3               [24] 1717 	inc	dptr
      00460D A3               [24] 1718 	inc	dptr
      00460E A3               [24] 1719 	inc	dptr
      00460F A3               [24] 1720 	inc	dptr
      004610 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0029
      004611                       1725 _ak820_outline_0029:
      004611 F0               [24] 1726 	movx	@dptr,a
      004612 8E 82            [24] 1727 	mov	dpl,r6
      004614 8F 83            [24] 1728 	mov	dph,r7
      004616 A3               [24] 1729 	inc	dptr
      004617 A3               [24] 1730 	inc	dptr
      004618 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0036
      004619                       1735 _ak820_outline_0036:
      004619 AF F0            [24] 1736 	mov	r7,b
      00461B AE 83            [24] 1737 	mov	r6,dph
      00461D E5 82            [12] 1738 	mov	a,dpl
      00461F 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0039
      004620                       1743 _ak820_outline_0039:
      004620 EF               [12] 1744 	mov	a,r7
      004621 24 C7            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      004623 F5 82            [12] 1746 	mov	dpl,a
      004625 E4               [12] 1747 	clr	a
      004626 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004628 F5 83            [12] 1749 	mov	dph,a
      00462A E0               [24] 1750 	movx	a,@dptr
      00462B 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0052
      00462C                       1755 _ak820_outline_0052:
      00462C 8F 06            [24] 1756 	mov	ar6,r7
      00462E 7D 00            [12] 1757 	mov	r5,#0x00
      004630 74 40            [12] 1758 	mov	a,#0x40
      004632 2E               [12] 1759 	add	a,r6
      004633 FE               [12] 1760 	mov	r6,a
      004634 74 EF            [12] 1761 	mov	a,#0xef
      004636 3D               [12] 1762 	addc	a,r5
      004637 FD               [12] 1763 	mov	r5,a
      004638 8E 82            [24] 1764 	mov	dpl,r6
      00463A 8D 83            [24] 1765 	mov	dph,r5
      00463C 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0060
      00463D                       1770 _ak820_outline_0060:
      00463D F0               [24] 1771 	movx	@dptr,a
      00463E 8E 82            [24] 1772 	mov	dpl,r6
      004640 8F 83            [24] 1773 	mov	dph,r7
      004642 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0064
      004643                       1778 _ak820_outline_0064:
      004643 8D 82            [24] 1779 	mov	dpl,r5
      004645 8E 83            [24] 1780 	mov	dph,r6
      004647 EC               [12] 1781 	mov	a,r4
      004648 F0               [24] 1782 	movx	@dptr,a
      004649 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0092
      00464A                       1787 _ak820_outline_0092:
      00464A 8C 82            [24] 1788 	mov	dpl,r4
      00464C 8D 83            [24] 1789 	mov	dph,r5
      00464E E0               [24] 1790 	movx	a,@dptr
      00464F 22               [24] 1791 	ret
                                   1792 
                                   1793 	.area CSEG (CODE)
                                   1794 ; function ak820_outline_0094
      004650                       1795 _ak820_outline_0094:
      004650 E0               [24] 1796 	movx	a,@dptr
      004651 FD               [12] 1797 	mov	r5,a
      004652 A3               [24] 1798 	inc	dptr
      004653 E0               [24] 1799 	movx	a,@dptr
      004654 FE               [12] 1800 	mov	r6,a
      004655 22               [24] 1801 	ret
                                   1802 
                                   1803 	.area CSEG (CODE)
                                   1804 ; function ak820_outline_0102
      004656                       1805 _ak820_outline_0102:
      004656 EF               [12] 1806 	mov	a,r7
      004657 24 6F            [12] 1807 	add	a,#_page_data
      004659 F5 82            [12] 1808 	mov	dpl,a
      00465B E4               [12] 1809 	clr	a
      00465C 34 05            [12] 1810 	addc	a,#(_page_data>>8)
      00465E F5 83            [12] 1811 	mov	dph,a
      004660 E0               [24] 1812 	movx	a,@dptr
      004661 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0116
      004662                       1817 _ak820_outline_0116:
      004662 8E 82            [24] 1818 	mov	dpl,r6
      004664 8F 83            [24] 1819 	mov	dph,r7
      004666 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0119
      004667                       1824 _ak820_outline_0119:
      004667 E0               [24] 1825 	movx	a,@dptr
      004668 FA               [12] 1826 	mov	r2,a
      004669 A3               [24] 1827 	inc	dptr
      00466A E0               [24] 1828 	movx	a,@dptr
      00466B FB               [12] 1829 	mov	r3,a
      00466C 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0131
      00466D                       1834 _ak820_outline_0131:
      00466D AE 82            [24] 1835 	mov	r6,dpl
      00466F AF 83            [24] 1836 	mov	r7,dph
      004671 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0134
      004672                       1841 _ak820_outline_0134:
      004672 2E               [12] 1842 	add	a,r6
      004673 FE               [12] 1843 	mov	r6,a
      004674 E4               [12] 1844 	clr	a
      004675 3F               [12] 1845 	addc	a,r7
      004676 FF               [12] 1846 	mov	r7,a
      004677 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0139
      004678                       1851 _ak820_outline_0139:
      004678 42 05            [12] 1852 	orl	ar5,a
      00467A EA               [12] 1853 	mov	a,r2
      00467B 42 04            [12] 1854 	orl	ar4,a
      00467D 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0140
      00467E                       1859 _ak820_outline_0140:
      00467E 8A 82            [24] 1860 	mov	dpl,r2
      004680 8B 83            [24] 1861 	mov	dph,r3
      004682 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0141
      004683                       1866 _ak820_outline_0141:
      004683 AC 82            [24] 1867 	mov	r4,dpl
      004685 AD 83            [24] 1868 	mov	r5,dph
      004687 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0153
      004688                       1873 _ak820_outline_0153:
      004688 8F 82            [24] 1874 	mov	dpl,r7
      00468A 8E 83            [24] 1875 	mov	dph,r6
      00468C 22               [24] 1876 	ret
                                   1877 
                                   1878 	.area CSEG (CODE)
                                   1879 ; function ak820_outline_0156
      00468D                       1880 _ak820_outline_0156:
      00468D 2E               [12] 1881 	add	a,r6
      00468E FC               [12] 1882 	mov	r4,a
      00468F E4               [12] 1883 	clr	a
      004690 3F               [12] 1884 	addc	a,r7
      004691 FD               [12] 1885 	mov	r5,a
      004692 22               [24] 1886 	ret
                                   1887 
                                   1888 	.area CSEG (CODE)
                                   1889 ; function ak820_outline_0157
      004693                       1890 _ak820_outline_0157:
      004693 ED               [12] 1891 	mov	a,r5
      004694 F0               [24] 1892 	movx	@dptr,a
      004695 EE               [12] 1893 	mov	a,r6
      004696 A3               [24] 1894 	inc	dptr
      004697 F0               [24] 1895 	movx	@dptr,a
      004698 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0179
      004699                       1900 _ak820_outline_0179:
      004699 89 82            [24] 1901 	mov	dpl,r1
      00469B 8A 83            [24] 1902 	mov	dph,r2
      00469D 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0180
      00469E                       1907 _ak820_outline_0180:
      00469E 8C 82            [24] 1908 	mov	dpl,r4
      0046A0 8B 83            [24] 1909 	mov	dph,r3
      0046A2 22               [24] 1910 	ret
