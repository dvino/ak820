                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         47 bits:
      000025                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000672                         85 _eeprom_read_word_addr_10000_91:
      000672                         86 	.ds 3
      000675                         87 _eeprom_read_word_ret_10000_92:
      000675                         88 	.ds 2
      000677                         89 _eeprom_read_dword_addr_10000_93:
      000677                         90 	.ds 3
      00067A                         91 _eeprom_read_dword_ret_10000_94:
      00067A                         92 	.ds 4
      00067E                         93 _eeprom_write_byte_PARM_2:
      00067E                         94 	.ds 1
      00067F                         95 _eeprom_write_byte_addr_10000_95:
      00067F                         96 	.ds 3
      000682                         97 _eeprom_write_word_PARM_2:
      000682                         98 	.ds 2
      000684                         99 _eeprom_write_word_addr_10000_97:
      000684                        100 	.ds 3
      000687                        101 _eeprom_write_dword_PARM_2:
      000687                        102 	.ds 4
      00068B                        103 _eeprom_write_dword_addr_10000_99:
      00068B                        104 	.ds 3
      00068E                        105 _eeprom_update_byte_PARM_2:
      00068E                        106 	.ds 1
      00068F                        107 _eeprom_update_byte_addr_10000_107:
      00068F                        108 	.ds 3
      000692                        109 _eeprom_update_word_PARM_2:
      000692                        110 	.ds 2
      000694                        111 _eeprom_update_word_addr_10000_111:
      000694                        112 	.ds 3
      000697                        113 _eeprom_update_dword_PARM_2:
      000697                        114 	.ds 4
      00069B                        115 _eeprom_update_dword_addr_10000_115:
      00069B                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004B81                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004B81 12 42 D2         [24]  170 	lcall	_ak820_outline_0034
      004B84 90 06 72         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004B87 12 37 E1         [24]  172 	lcall	_ak820_outline_0015
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004B8A 90 06 75         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004B8D 12 4D 8A         [24]  175 	lcall	_ak820_outline_0157
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004B90 90 06 72         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004B93 12 4D 3F         [24]  178 	lcall	_ak820_outline_0020
      004B96 90 05 81         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004B99 ED               [12]  180 	mov	a,r5
      004B9A 12 37 E1         [24]  181 	lcall	_ak820_outline_0015
      004B9D 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004BA0 74 02            [12]  183 	mov	a,#0x02
      004BA2 12 38 58         [24]  184 	lcall	_ak820_outline_0114
      004BA5 90 06 75         [24]  185 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004BA8 12 40 6E         [24]  186 	lcall	_ak820_eeprom_read_block_xdata
                                    187 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004BAB 90 06 75         [24]  188 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004BAE 12 4D 7A         [24]  189 	lcall	_ak820_outline_0082
                                    190 ;	drivers/eeprom/eeprom_driver.c:48: }
      004BB1 22               [24]  191 	ret
                                    192 ;------------------------------------------------------------
                                    193 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    194 ;------------------------------------------------------------
                                    195 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    196 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    197 ;------------------------------------------------------------
                                    198 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    199 ;	-----------------------------------------
                                    200 ;	 function eeprom_read_dword
                                    201 ;	-----------------------------------------
      004BB2                        202 _eeprom_read_dword:
      004BB2 12 42 D2         [24]  203 	lcall	_ak820_outline_0034
      004BB5 90 06 77         [24]  204 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004BB8 12 37 E1         [24]  205 	lcall	_ak820_outline_0015
                                    206 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004BBB 90 06 7A         [24]  207 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004BBE 12 4D 4F         [24]  208 	lcall	_ak820_outline_0046
                                    209 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004BC1 90 06 77         [24]  210 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004BC4 12 4D 3F         [24]  211 	lcall	_ak820_outline_0020
      004BC7 90 05 81         [24]  212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004BCA ED               [12]  213 	mov	a,r5
      004BCB 12 37 E1         [24]  214 	lcall	_ak820_outline_0015
      004BCE 90 05 84         [24]  215 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004BD1 74 04            [12]  216 	mov	a,#0x04
      004BD3 12 38 58         [24]  217 	lcall	_ak820_outline_0114
      004BD6 90 06 7A         [24]  218 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004BD9 12 40 6E         [24]  219 	lcall	_ak820_eeprom_read_block_xdata
                                    220 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004BDC 90 06 7A         [24]  221 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004BDF 12 4D 58         [24]  222 	lcall	_ak820_outline_0050
                                    223 ;	drivers/eeprom/eeprom_driver.c:54: }
      004BE2 22               [24]  224 	ret
                                    225 ;------------------------------------------------------------
                                    226 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    227 ;------------------------------------------------------------
                                    228 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    229 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    230 ;------------------------------------------------------------
                                    231 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    232 ;	-----------------------------------------
                                    233 ;	 function eeprom_write_byte
                                    234 ;	-----------------------------------------
      004BE3                        235 _eeprom_write_byte:
      004BE3 12 42 D2         [24]  236 	lcall	_ak820_outline_0034
      004BE6 90 06 7F         [24]  237 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004BE9 12 37 E1         [24]  238 	lcall	_ak820_outline_0015
                                    239 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004BEC 90 06 7F         [24]  240 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004BEF 12 4D 19         [24]  241 	lcall	_ak820_outline_0002
      004BF2 74 01            [12]  242 	mov	a,#0x01
      004BF4 12 38 58         [24]  243 	lcall	_ak820_outline_0114
      004BF7 90 06 7E         [24]  244 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    245 ;	drivers/eeprom/eeprom_driver.c:58: }
      004BFA 02 40 FA         [24]  246 	ljmp	_ak820_eeprom_write_block_xdata
                                    247 ;------------------------------------------------------------
                                    248 ;Allocation info for local variables in function 'eeprom_write_word'
                                    249 ;------------------------------------------------------------
                                    250 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    251 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    252 ;------------------------------------------------------------
                                    253 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    254 ;	-----------------------------------------
                                    255 ;	 function eeprom_write_word
                                    256 ;	-----------------------------------------
      004BFD                        257 _eeprom_write_word:
      004BFD 12 42 D2         [24]  258 	lcall	_ak820_outline_0034
      004C00 90 06 84         [24]  259 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004C03 12 37 E1         [24]  260 	lcall	_ak820_outline_0015
                                    261 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004C06 90 06 84         [24]  262 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004C09 12 4D 19         [24]  263 	lcall	_ak820_outline_0002
      004C0C 74 02            [12]  264 	mov	a,#0x02
      004C0E 12 38 58         [24]  265 	lcall	_ak820_outline_0114
      004C11 90 06 82         [24]  266 	mov	dptr,#_eeprom_write_word_PARM_2
                                    267 ;	drivers/eeprom/eeprom_driver.c:62: }
      004C14 02 40 FA         [24]  268 	ljmp	_ak820_eeprom_write_block_xdata
                                    269 ;------------------------------------------------------------
                                    270 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    271 ;------------------------------------------------------------
                                    272 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    273 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    274 ;------------------------------------------------------------
                                    275 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    276 ;	-----------------------------------------
                                    277 ;	 function eeprom_write_dword
                                    278 ;	-----------------------------------------
      004C17                        279 _eeprom_write_dword:
      004C17 12 42 D2         [24]  280 	lcall	_ak820_outline_0034
      004C1A 90 06 8B         [24]  281 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004C1D 12 37 E1         [24]  282 	lcall	_ak820_outline_0015
                                    283 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004C20 90 06 8B         [24]  284 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004C23 12 4D 19         [24]  285 	lcall	_ak820_outline_0002
      004C26 74 04            [12]  286 	mov	a,#0x04
      004C28 12 38 58         [24]  287 	lcall	_ak820_outline_0114
      004C2B 90 06 87         [24]  288 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    289 ;	drivers/eeprom/eeprom_driver.c:66: }
      004C2E 02 40 FA         [24]  290 	ljmp	_ak820_eeprom_write_block_xdata
                                    291 ;------------------------------------------------------------
                                    292 ;Allocation info for local variables in function 'eeprom_update_block'
                                    293 ;------------------------------------------------------------
                                    294 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    295 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    296 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    297 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    298 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    299 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    300 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    301 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    302 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    303 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    304 ;------------------------------------------------------------
                                    305 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    306 ;	-----------------------------------------
                                    307 ;	 function eeprom_update_byte
                                    308 ;	-----------------------------------------
      004C31                        309 _eeprom_update_byte:
      004C31 C0 07            [24]  310 	push	ar7
      004C33 C0 06            [24]  311 	push	ar6
      004C35 C0 05            [24]  312 	push	ar5
      004C37 C0 04            [24]  313 	push	ar4
      004C39 12 42 D2         [24]  314 	lcall	_ak820_outline_0034
      004C3C 90 06 8F         [24]  315 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004C3F 12 37 E1         [24]  316 	lcall	_ak820_outline_0015
                                    317 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004C42 90 06 8F         [24]  318 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004C45 12 4D 30         [24]  319 	lcall	_ak820_outline_0003
      004C48 12 40 33         [24]  320 	lcall	_eeprom_read_byte
      004C4B AF 82            [24]  321 	mov	r7, dpl
                                    322 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004C4D 90 06 8E         [24]  323 	mov	dptr,#_eeprom_update_byte_PARM_2
      004C50 E0               [24]  324 	movx	a,@dptr
      004C51 FE               [12]  325 	mov	r6,a
      004C52 EF               [12]  326 	mov	a,r7
      004C53 B5 06 02         [24]  327 	cjne	a,ar6,00112$
      004C56 80 36            [24]  328 	sjmp	00103$
      004C58                        329 00112$:
                                    330 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004C58 90 06 8F         [24]  331 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004C5B 12 38 18         [24]  332 	lcall	_ak820_outline_0056
      004C5E A3               [24]  333 	inc	dptr
      004C5F E0               [24]  334 	movx	a,@dptr
      004C60 FF               [12]  335 	mov	r7,a
      004C61 90 06 7E         [24]  336 	mov	dptr,#_eeprom_write_byte_PARM_2
      004C64 EE               [12]  337 	mov	a,r6
      004C65 F0               [24]  338 	movx	@dptr,a
      004C66 12 38 4D         [24]  339 	lcall	_ak820_outline_0110
      004C69 8F F0            [24]  340 	mov	b, r7
      004C6B C0 07            [24]  341 	push	ar7
      004C6D C0 06            [24]  342 	push	ar6
      004C6F C0 05            [24]  343 	push	ar5
      004C71 C0 04            [24]  344 	push	ar4
      004C73 C0 03            [24]  345 	push	ar3
      004C75 C0 02            [24]  346 	push	ar2
      004C77 C0 01            [24]  347 	push	ar1
      004C79 C0 00            [24]  348 	push	ar0
      004C7B 12 4B E3         [24]  349 	lcall	_eeprom_write_byte
      004C7E D0 00            [24]  350 	pop	ar0
      004C80 D0 01            [24]  351 	pop	ar1
      004C82 D0 02            [24]  352 	pop	ar2
      004C84 D0 03            [24]  353 	pop	ar3
      004C86 D0 04            [24]  354 	pop	ar4
      004C88 D0 05            [24]  355 	pop	ar5
      004C8A D0 06            [24]  356 	pop	ar6
      004C8C D0 07            [24]  357 	pop	ar7
      004C8E                        358 00103$:
                                    359 ;	drivers/eeprom/eeprom_driver.c:87: }
      004C8E D0 04            [24]  360 	pop	ar4
      004C90 D0 05            [24]  361 	pop	ar5
      004C92 D0 06            [24]  362 	pop	ar6
      004C94 D0 07            [24]  363 	pop	ar7
      004C96 22               [24]  364 	ret
                                    365 ;------------------------------------------------------------
                                    366 ;Allocation info for local variables in function 'eeprom_update_word'
                                    367 ;------------------------------------------------------------
                                    368 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    369 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    370 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    371 ;------------------------------------------------------------
                                    372 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    373 ;	-----------------------------------------
                                    374 ;	 function eeprom_update_word
                                    375 ;	-----------------------------------------
      004C97                        376 _eeprom_update_word:
      004C97 12 42 D2         [24]  377 	lcall	_ak820_outline_0034
      004C9A 90 06 94         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004C9D 12 37 E1         [24]  379 	lcall	_ak820_outline_0015
                                    380 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004CA0 90 06 94         [24]  381 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004CA3 12 4D 30         [24]  382 	lcall	_ak820_outline_0003
      004CA6 12 4B 81         [24]  383 	lcall	_eeprom_read_word
      004CA9 12 43 1F         [24]  384 	lcall	_ak820_outline_0123
                                    385 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004CAC 90 06 92         [24]  386 	mov	dptr,#_eeprom_update_word_PARM_2
      004CAF 12 38 18         [24]  387 	lcall	_ak820_outline_0056
      004CB2 EE               [12]  388 	mov	a,r6
      004CB3 B5 04 05         [24]  389 	cjne	a,ar4,00112$
      004CB6 EF               [12]  390 	mov	a,r7
      004CB7 B5 05 01         [24]  391 	cjne	a,ar5,00112$
      004CBA 22               [24]  392 	ret
      004CBB                        393 00112$:
                                    394 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004CBB 90 06 94         [24]  395 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004CBE E0               [24]  396 	movx	a,@dptr
      004CBF FB               [12]  397 	mov	r3,a
      004CC0 A3               [24]  398 	inc	dptr
      004CC1 12 37 F9         [24]  399 	lcall	_ak820_outline_0047
      004CC4 90 06 82         [24]  400 	mov	dptr,#_eeprom_write_word_PARM_2
      004CC7 12 38 24         [24]  401 	lcall	_ak820_outline_0070
      004CCA 8B 82            [24]  402 	mov	dpl, r3
      004CCC 8E 83            [24]  403 	mov	dph, r6
      004CCE 8F F0            [24]  404 	mov	b, r7
                                    405 ;	drivers/eeprom/eeprom_driver.c:94: }
      004CD0 02 4B FD         [24]  406 	ljmp	_eeprom_write_word
                                    407 ;------------------------------------------------------------
                                    408 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    409 ;------------------------------------------------------------
                                    410 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    411 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    412 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    413 ;------------------------------------------------------------
                                    414 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    415 ;	-----------------------------------------
                                    416 ;	 function eeprom_update_dword
                                    417 ;	-----------------------------------------
      004CD3                        418 _eeprom_update_dword:
      004CD3 12 42 D2         [24]  419 	lcall	_ak820_outline_0034
      004CD6 90 06 9B         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004CD9 12 37 E1         [24]  421 	lcall	_ak820_outline_0015
                                    422 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004CDC 90 06 9B         [24]  423 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004CDF 12 4D 30         [24]  424 	lcall	_ak820_outline_0003
      004CE2 12 4B B2         [24]  425 	lcall	_eeprom_read_dword
      004CE5 12 4D 69         [24]  426 	lcall	_ak820_outline_0052
                                    427 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004CE8 90 06 97         [24]  428 	mov	dptr,#_eeprom_update_dword_PARM_2
      004CEB E0               [24]  429 	movx	a,@dptr
      004CEC F8               [12]  430 	mov	r0,a
      004CED A3               [24]  431 	inc	dptr
      004CEE 12 4D 71         [24]  432 	lcall	_ak820_outline_0081
      004CF1 EC               [12]  433 	mov	a,r4
      004CF2 B5 00 0D         [24]  434 	cjne	a,ar0,00112$
      004CF5 ED               [12]  435 	mov	a,r5
      004CF6 B5 01 09         [24]  436 	cjne	a,ar1,00112$
      004CF9 EE               [12]  437 	mov	a,r6
      004CFA B5 02 05         [24]  438 	cjne	a,ar2,00112$
      004CFD EF               [12]  439 	mov	a,r7
      004CFE B5 03 01         [24]  440 	cjne	a,ar3,00112$
      004D01 22               [24]  441 	ret
      004D02                        442 00112$:
                                    443 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004D02 90 06 9B         [24]  444 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004D05 12 4D 3F         [24]  445 	lcall	_ak820_outline_0020
      004D08 90 06 87         [24]  446 	mov	dptr,#_eeprom_write_dword_PARM_2
      004D0B E8               [12]  447 	mov	a,r0
      004D0C F0               [24]  448 	movx	@dptr,a
      004D0D E9               [12]  449 	mov	a,r1
      004D0E A3               [24]  450 	inc	dptr
      004D0F 12 4D 83         [24]  451 	lcall	_ak820_outline_0143
      004D12 F0               [24]  452 	movx	@dptr,a
      004D13 12 4D 48         [24]  453 	lcall	_ak820_outline_0041
                                    454 ;	drivers/eeprom/eeprom_driver.c:101: }
      004D16 02 4C 17         [24]  455 	ljmp	_eeprom_write_dword
                                    456 	.area CSEG    (CODE)
                                    457 	.area CONST   (CODE)
                                    458 	.area XINIT   (CODE)
                                    459 	.area CABS    (ABS,CODE)
                                    460 
                                    461 ; Experimental exact instruction outlining.
                                    462 	.globl _ak820_outline_0002
                                    463 	.globl _ak820_outline_0003
                                    464 	.globl _ak820_outline_0015
                                    465 	.globl _ak820_outline_0020
                                    466 	.globl _ak820_outline_0034
                                    467 	.globl _ak820_outline_0041
                                    468 	.globl _ak820_outline_0046
                                    469 	.globl _ak820_outline_0047
                                    470 	.globl _ak820_outline_0050
                                    471 	.globl _ak820_outline_0052
                                    472 	.globl _ak820_outline_0056
                                    473 	.globl _ak820_outline_0070
                                    474 	.globl _ak820_outline_0081
                                    475 	.globl _ak820_outline_0082
                                    476 	.globl _ak820_outline_0110
                                    477 	.globl _ak820_outline_0114
                                    478 	.globl _ak820_outline_0123
                                    479 	.globl _ak820_outline_0143
                                    480 	.globl _ak820_outline_0157
                                    481 
                                    482 	.area CSEG (CODE)
                                    483 ; function ak820_outline_0002
      004D19                        484 _ak820_outline_0002:
      004D19 E0               [24]  485 	movx	a,@dptr
      004D1A FD               [12]  486 	mov	r5,a
      004D1B A3               [24]  487 	inc	dptr
      004D1C E0               [24]  488 	movx	a,@dptr
      004D1D FE               [12]  489 	mov	r6,a
      004D1E A3               [24]  490 	inc	dptr
      004D1F E0               [24]  491 	movx	a,@dptr
      004D20 FF               [12]  492 	mov	r7,a
      004D21 90 05 8A         [24]  493 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004D24 ED               [12]  494 	mov	a,r5
      004D25 F0               [24]  495 	movx	@dptr,a
      004D26 EE               [12]  496 	mov	a,r6
      004D27 A3               [24]  497 	inc	dptr
      004D28 F0               [24]  498 	movx	@dptr,a
      004D29 EF               [12]  499 	mov	a,r7
      004D2A A3               [24]  500 	inc	dptr
      004D2B F0               [24]  501 	movx	@dptr,a
      004D2C 90 05 8D         [24]  502 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004D2F 22               [24]  503 	ret
                                    504 
                                    505 	.area CSEG (CODE)
                                    506 ; function ak820_outline_0003
      004D30                        507 _ak820_outline_0003:
      004D30 E0               [24]  508 	movx	a,@dptr
      004D31 FD               [12]  509 	mov	r5,a
      004D32 A3               [24]  510 	inc	dptr
      004D33 E0               [24]  511 	movx	a,@dptr
      004D34 FE               [12]  512 	mov	r6,a
      004D35 A3               [24]  513 	inc	dptr
      004D36 E0               [24]  514 	movx	a,@dptr
      004D37 FF               [12]  515 	mov	r7,a
      004D38 8D 82            [24]  516 	mov	dpl,r5
      004D3A 8E 83            [24]  517 	mov	dph,r6
      004D3C 8F F0            [24]  518 	mov	b,r7
      004D3E 22               [24]  519 	ret
                                    520 
                                    521 	.area CSEG (CODE)
                                    522 ; function ak820_outline_0020
      004D3F                        523 _ak820_outline_0020:
      004D3F E0               [24]  524 	movx	a,@dptr
      004D40 FD               [12]  525 	mov	r5,a
      004D41 A3               [24]  526 	inc	dptr
      004D42 E0               [24]  527 	movx	a,@dptr
      004D43 FE               [12]  528 	mov	r6,a
      004D44 A3               [24]  529 	inc	dptr
      004D45 E0               [24]  530 	movx	a,@dptr
      004D46 FF               [12]  531 	mov	r7,a
      004D47 22               [24]  532 	ret
                                    533 
                                    534 	.area CSEG (CODE)
                                    535 ; function ak820_outline_0041
      004D48                        536 _ak820_outline_0041:
      004D48 8D 82            [24]  537 	mov	dpl,r5
      004D4A 8E 83            [24]  538 	mov	dph,r6
      004D4C 8F F0            [24]  539 	mov	b,r7
      004D4E 22               [24]  540 	ret
                                    541 
                                    542 	.area CSEG (CODE)
                                    543 ; function ak820_outline_0046
      004D4F                        544 _ak820_outline_0046:
      004D4F E4               [12]  545 	clr	a
      004D50 F0               [24]  546 	movx	@dptr,a
      004D51 A3               [24]  547 	inc	dptr
      004D52 F0               [24]  548 	movx	@dptr,a
      004D53 A3               [24]  549 	inc	dptr
      004D54 F0               [24]  550 	movx	@dptr,a
      004D55 A3               [24]  551 	inc	dptr
      004D56 F0               [24]  552 	movx	@dptr,a
      004D57 22               [24]  553 	ret
                                    554 
                                    555 	.area CSEG (CODE)
                                    556 ; function ak820_outline_0050
      004D58                        557 _ak820_outline_0050:
      004D58 E0               [24]  558 	movx	a,@dptr
      004D59 FC               [12]  559 	mov	r4,a
      004D5A A3               [24]  560 	inc	dptr
      004D5B E0               [24]  561 	movx	a,@dptr
      004D5C FD               [12]  562 	mov	r5,a
      004D5D A3               [24]  563 	inc	dptr
      004D5E E0               [24]  564 	movx	a,@dptr
      004D5F FE               [12]  565 	mov	r6,a
      004D60 A3               [24]  566 	inc	dptr
      004D61 E0               [24]  567 	movx	a,@dptr
      004D62 8C 82            [24]  568 	mov	dpl,r4
      004D64 8D 83            [24]  569 	mov	dph,r5
      004D66 8E F0            [24]  570 	mov	b,r6
      004D68 22               [24]  571 	ret
                                    572 
                                    573 	.area CSEG (CODE)
                                    574 ; function ak820_outline_0052
      004D69                        575 _ak820_outline_0052:
      004D69 AC 82            [24]  576 	mov	r4,dpl
      004D6B AD 83            [24]  577 	mov	r5,dph
      004D6D AE F0            [24]  578 	mov	r6,b
      004D6F FF               [12]  579 	mov	r7,a
      004D70 22               [24]  580 	ret
                                    581 
                                    582 	.area CSEG (CODE)
                                    583 ; function ak820_outline_0081
      004D71                        584 _ak820_outline_0081:
      004D71 E0               [24]  585 	movx	a,@dptr
      004D72 F9               [12]  586 	mov	r1,a
      004D73 A3               [24]  587 	inc	dptr
      004D74 E0               [24]  588 	movx	a,@dptr
      004D75 FA               [12]  589 	mov	r2,a
      004D76 A3               [24]  590 	inc	dptr
      004D77 E0               [24]  591 	movx	a,@dptr
      004D78 FB               [12]  592 	mov	r3,a
      004D79 22               [24]  593 	ret
                                    594 
                                    595 	.area CSEG (CODE)
                                    596 ; function ak820_outline_0082
      004D7A                        597 _ak820_outline_0082:
      004D7A E0               [24]  598 	movx	a,@dptr
      004D7B FE               [12]  599 	mov	r6,a
      004D7C A3               [24]  600 	inc	dptr
      004D7D E0               [24]  601 	movx	a,@dptr
      004D7E 8E 82            [24]  602 	mov	dpl,r6
      004D80 F5 83            [12]  603 	mov	dph,a
      004D82 22               [24]  604 	ret
                                    605 
                                    606 	.area CSEG (CODE)
                                    607 ; function ak820_outline_0143
      004D83                        608 _ak820_outline_0143:
      004D83 F0               [24]  609 	movx	@dptr,a
      004D84 EA               [12]  610 	mov	a,r2
      004D85 A3               [24]  611 	inc	dptr
      004D86 F0               [24]  612 	movx	@dptr,a
      004D87 EB               [12]  613 	mov	a,r3
      004D88 A3               [24]  614 	inc	dptr
      004D89 22               [24]  615 	ret
                                    616 
                                    617 	.area CSEG (CODE)
                                    618 ; function ak820_outline_0157
      004D8A                        619 _ak820_outline_0157:
      004D8A E4               [12]  620 	clr	a
      004D8B F0               [24]  621 	movx	@dptr,a
      004D8C A3               [24]  622 	inc	dptr
      004D8D F0               [24]  623 	movx	@dptr,a
      004D8E 22               [24]  624 	ret
