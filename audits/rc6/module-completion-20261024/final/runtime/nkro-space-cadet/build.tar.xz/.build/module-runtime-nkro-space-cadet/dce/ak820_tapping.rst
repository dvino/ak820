                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _del_owned_mods
                                     12 	.globl _add_owned_mods
                                     13 	.globl _send_keyboard_report
                                     14 	.globl _layer_hold_off
                                     15 	.globl _layer_hold_on
                                     16 	.globl _unregister_mods
                                     17 	.globl _register_mods
                                     18 	.globl _process_record
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_tapping_before
                                    263 	.globl _ak820_tapping_process
                                    264 	.globl _ak820_tapping_cancel
                                    265 ;--------------------------------------------------------
                                    266 ; special function registers
                                    267 ;--------------------------------------------------------
                                    268 	.area RSEG    (ABS,DATA)
      000000                        269 	.org 0x0000
                           0000D0   270 _PSW	=	0x00d0
                           0000E0   271 _ACC	=	0x00e0
                           0000F0   272 _B	=	0x00f0
                           0000FD   273 _A_INV	=	0x00fd
                           000081   274 _SP	=	0x0081
                           000082   275 _DPL	=	0x0082
                           000083   276 _DPH	=	0x0083
                           0000A1   277 _SAFE_MOD	=	0x00a1
                           0000B1   278 _GLOBAL_CFG	=	0x00b1
                           000087   279 _PCON	=	0x0087
                           0000BA   280 _POWER_CFG	=	0x00ba
                           0000B9   281 _CLOCK_CFG	=	0x00b9
                           0000A9   282 _WAKE_CTRL	=	0x00a9
                           0000FE   283 _RESET_KEEP	=	0x00fe
                           0000FF   284 _WDOG_COUNT	=	0x00ff
                           0000A8   285 _IE	=	0x00a8
                           0000B8   286 _IP	=	0x00b8
                           0000E8   287 _IE_EX	=	0x00e8
                           0000E9   288 _IP_EX	=	0x00e9
                           0000B2   289 _GPIO_IE	=	0x00b2
                           008584   290 _ROM_ADDR	=	0x8584
                           000084   291 _ROM_ADDR_L	=	0x0084
                           000085   292 _ROM_ADDR_H	=	0x0085
                           008F8E   293 _ROM_DATA_HI	=	0x8f8e
                           00008E   294 _ROM_DATA_HL	=	0x008e
                           00008F   295 _ROM_DATA_HH	=	0x008f
                           000086   296 _ROM_CTRL	=	0x0086
                           000080   297 _P0	=	0x0080
                           0000C4   298 _P0_MOD_OC	=	0x00c4
                           0000C5   299 _P0_DIR_PU	=	0x00c5
                           000090   300 _P1	=	0x0090
                           000092   301 _P1_MOD_OC	=	0x0092
                           000093   302 _P1_DIR_PU	=	0x0093
                           0000A0   303 _P2	=	0x00a0
                           000094   304 _P2_MOD_OC	=	0x0094
                           000095   305 _P2_DIR_PU	=	0x0095
                           0000B0   306 _P3	=	0x00b0
                           000096   307 _P3_MOD_OC	=	0x0096
                           000097   308 _P3_DIR_PU	=	0x0097
                           0000C0   309 _P4	=	0x00c0
                           0000C2   310 _P4_MOD_OC	=	0x00c2
                           0000C3   311 _P4_DIR_PU	=	0x00c3
                           0000C1   312 _P4_LED_KEY	=	0x00c1
                           0000AA   313 _P5_IN	=	0x00aa
                           0000AB   314 _P5_OUT_PU	=	0x00ab
                           0000AC   315 _P5_DIR	=	0x00ac
                           0000AD   316 _P6_IN	=	0x00ad
                           0000AE   317 _P6_OUT_PU	=	0x00ae
                           0000AF   318 _P6_DIR	=	0x00af
                           0000F1   319 _P7	=	0x00f1
                           0000A2   320 _XBUS_AUX	=	0x00a2
                           000088   321 _TCON	=	0x0088
                           000089   322 _TMOD	=	0x0089
                           00008A   323 _TL0	=	0x008a
                           00008B   324 _TL1	=	0x008b
                           00008C   325 _TH0	=	0x008c
                           00008D   326 _TH1	=	0x008d
                           000098   327 _SCON	=	0x0098
                           000099   328 _SBUF	=	0x0099
                           0000C8   329 _T2CON	=	0x00c8
                           0000C9   330 _T2MOD	=	0x00c9
                           00CBCA   331 _RCAP2	=	0xcbca
                           0000CA   332 _RCAP2L	=	0x00ca
                           0000CB   333 _RCAP2H	=	0x00cb
                           00CDCC   334 _T2COUNT	=	0xcdcc
                           0000CC   335 _TL2	=	0x00cc
                           0000CD   336 _TH2	=	0x00cd
                           00CFCE   337 _T2CAP1	=	0xcfce
                           0000CE   338 _T2CAP1L	=	0x00ce
                           0000CF   339 _T2CAP1H	=	0x00cf
                           0000F8   340 _SPI0_STAT	=	0x00f8
                           0000F9   341 _SPI0_DATA	=	0x00f9
                           0000FA   342 _SPI0_CTRL	=	0x00fa
                           0000FB   343 _SPI0_CK_SE	=	0x00fb
                           0000FC   344 _SPI0_SETUP	=	0x00fc
                           0000BC   345 _SCON1	=	0x00bc
                           0000BD   346 _SBUF1	=	0x00bd
                           0000BE   347 _SBAUD1	=	0x00be
                           0000BF   348 _SIF1	=	0x00bf
                           0000B4   349 _SPI1_STAT	=	0x00b4
                           0000B5   350 _SPI1_DATA	=	0x00b5
                           0000B6   351 _SPI1_CTRL	=	0x00b6
                           0000B7   352 _SPI1_CK_SE	=	0x00b7
                           0000F3   353 _ADC_CTRL	=	0x00f3
                           00F5F4   354 _ADC_DAT	=	0xf5f4
                           0000F4   355 _ADC_DAT_L	=	0x00f4
                           0000F5   356 _ADC_DAT_H	=	0x00f5
                           0000F6   357 _ADC_CHAN	=	0x00f6
                           0000A6   358 _LED_COMMON	=	0x00a6
                           0000A7   359 _LED_PWM_OE	=	0x00a7
                           00C7C6   360 _LED_DMA	=	0xc7c6
                           0000C6   361 _LED_DMA_L	=	0x00c6
                           0000C7   362 _LED_DMA_H	=	0x00c7
                           0000F7   363 _LED_STATUS	=	0x00f7
                           0000B3   364 _I2CX_INT	=	0x00b3
                           0000BB   365 _I2CS_INT_ST	=	0x00bb
                                    366 ;--------------------------------------------------------
                                    367 ; special function bits
                                    368 ;--------------------------------------------------------
                                    369 	.area RSEG    (ABS,DATA)
      000000                        370 	.org 0x0000
                           0000D7   371 _CY	=	0x00d7
                           0000D6   372 _AC	=	0x00d6
                           0000D5   373 _F0	=	0x00d5
                           0000D4   374 _RS1	=	0x00d4
                           0000D3   375 _RS0	=	0x00d3
                           0000D2   376 _OV	=	0x00d2
                           0000D1   377 _F1	=	0x00d1
                           0000D0   378 _P	=	0x00d0
                           0000AF   379 _EA	=	0x00af
                           0000AE   380 _E_DIS	=	0x00ae
                           0000AD   381 _ET2	=	0x00ad
                           0000AC   382 _ES	=	0x00ac
                           0000AB   383 _ET1	=	0x00ab
                           0000AA   384 _EX1	=	0x00aa
                           0000A9   385 _ET0	=	0x00a9
                           0000A8   386 _EX0	=	0x00a8
                           0000BF   387 _PH_FLAG	=	0x00bf
                           0000BE   388 _PL_FLAG	=	0x00be
                           0000BD   389 _PT2	=	0x00bd
                           0000BC   390 _PS	=	0x00bc
                           0000BB   391 _PT1	=	0x00bb
                           0000BA   392 _PX1	=	0x00ba
                           0000B9   393 _PT0	=	0x00b9
                           0000B8   394 _PX0	=	0x00b8
                           0000EF   395 _IE_WDOG	=	0x00ef
                           0000EE   396 _IE_GPIO	=	0x00ee
                           0000ED   397 _IE_PWM_I2C	=	0x00ed
                           0000EC   398 _IE_UART1	=	0x00ec
                           0000EB   399 _IE_ADC	=	0x00eb
                           0000E9   400 _IE_USB	=	0x00e9
                           0000E8   401 _IE_SPI0	=	0x00e8
                           000087   402 _P0_7	=	0x0087
                           000086   403 _P0_6	=	0x0086
                           000085   404 _P0_5	=	0x0085
                           000084   405 _P0_4	=	0x0084
                           000083   406 _P0_3	=	0x0083
                           000082   407 _P0_2	=	0x0082
                           000081   408 _P0_1	=	0x0081
                           000080   409 _P0_0	=	0x0080
                           000081   410 _SDA0	=	0x0081
                           000080   411 _SCL0	=	0x0080
                           000083   412 _TXD_	=	0x0083
                           000082   413 _RXD_	=	0x0082
                           000085   414 _AIN13	=	0x0085
                           000084   415 _AIN12	=	0x0084
                           000083   416 _AIN11	=	0x0083
                           000082   417 _AIN10	=	0x0082
                           000081   418 _AIN9	=	0x0081
                           000080   419 _AIN8	=	0x0080
                           000097   420 _P1_7	=	0x0097
                           000096   421 _P1_6	=	0x0096
                           000095   422 _P1_5	=	0x0095
                           000094   423 _P1_4	=	0x0094
                           000093   424 _P1_3	=	0x0093
                           000092   425 _P1_2	=	0x0092
                           000091   426 _P1_1	=	0x0091
                           000090   427 _P1_0	=	0x0090
                           000097   428 _TXD1_	=	0x0097
                           000096   429 _RXD1_	=	0x0096
                           000097   430 _SCK	=	0x0097
                           000096   431 _MISO	=	0x0096
                           000095   432 _MOSI	=	0x0095
                           000094   433 _SCS	=	0x0094
                           000092   434 _INT0_	=	0x0092
                           000091   435 _T2EX	=	0x0091
                           000091   436 _CAP2	=	0x0091
                           000090   437 _T2	=	0x0090
                           000090   438 _CAP1	=	0x0090
                           000097   439 _AIN7	=	0x0097
                           000096   440 _AIN6	=	0x0096
                           000095   441 _AIN5	=	0x0095
                           000094   442 _AIN4	=	0x0094
                           000093   443 _AIN3	=	0x0093
                           000092   444 _AIN2	=	0x0092
                           000091   445 _AIN1	=	0x0091
                           000090   446 _AIN0	=	0x0090
                           0000A7   447 _P2_7	=	0x00a7
                           0000A6   448 _P2_6	=	0x00a6
                           0000A5   449 _P2_5	=	0x00a5
                           0000A4   450 _P2_4	=	0x00a4
                           0000A3   451 _P2_3	=	0x00a3
                           0000A2   452 _P2_2	=	0x00a2
                           0000A1   453 _P2_1	=	0x00a1
                           0000A0   454 _P2_0	=	0x00a0
                           0000A7   455 _TXD1	=	0x00a7
                           0000A6   456 _RXD1	=	0x00a6
                           0000A5   457 _T2EX_	=	0x00a5
                           0000A5   458 _CAP2_	=	0x00a5
                           0000A4   459 _T2_	=	0x00a4
                           0000A4   460 _CAP1_	=	0x00a4
                           0000B7   461 _P3_7	=	0x00b7
                           0000B6   462 _P3_6	=	0x00b6
                           0000B5   463 _P3_5	=	0x00b5
                           0000B4   464 _P3_4	=	0x00b4
                           0000B3   465 _P3_3	=	0x00b3
                           0000B2   466 _P3_2	=	0x00b2
                           0000B1   467 _P3_1	=	0x00b1
                           0000B0   468 _P3_0	=	0x00b0
                           0000B7   469 _SCK1	=	0x00b7
                           0000B6   470 _MISO1	=	0x00b6
                           0000B5   471 _MOSI1	=	0x00b5
                           0000B5   472 _T1	=	0x00b5
                           0000B4   473 _T0	=	0x00b4
                           0000B3   474 _INT1	=	0x00b3
                           0000B2   475 _INT0	=	0x00b2
                           0000B1   476 _TXD	=	0x00b1
                           0000B0   477 _RXD	=	0x00b0
                           0000C6   478 _P4_6	=	0x00c6
                           0000C5   479 _P4_5	=	0x00c5
                           0000C4   480 _P4_4	=	0x00c4
                           0000C3   481 _P4_3	=	0x00c3
                           0000C2   482 _P4_2	=	0x00c2
                           0000C1   483 _P4_1	=	0x00c1
                           0000C0   484 _P4_0	=	0x00c0
                           00008F   485 _TF1	=	0x008f
                           00008E   486 _TR1	=	0x008e
                           00008D   487 _TF0	=	0x008d
                           00008C   488 _TR0	=	0x008c
                           00008B   489 _IE1	=	0x008b
                           00008A   490 _IT1	=	0x008a
                           000089   491 _IE0	=	0x0089
                           000088   492 _IT0	=	0x0088
                           00009F   493 _SM0	=	0x009f
                           00009E   494 _SM1	=	0x009e
                           00009D   495 _SM2	=	0x009d
                           00009C   496 _REN	=	0x009c
                           00009B   497 _TB8	=	0x009b
                           00009A   498 _RB8	=	0x009a
                           000099   499 _TI	=	0x0099
                           000098   500 _RI	=	0x0098
                           0000CF   501 _TF2	=	0x00cf
                           0000CF   502 _CAP1F	=	0x00cf
                           0000CE   503 _EXF2	=	0x00ce
                           0000CD   504 _RCLK	=	0x00cd
                           0000CC   505 _TCLK	=	0x00cc
                           0000CB   506 _EXEN2	=	0x00cb
                           0000CA   507 _TR2	=	0x00ca
                           0000C9   508 _C_T2	=	0x00c9
                           0000C8   509 _CP_RL2	=	0x00c8
                           0000FF   510 _S0_FST_ACT	=	0x00ff
                           0000FE   511 _S0_IF_OV	=	0x00fe
                           0000FD   512 _S0_IF_FIRST	=	0x00fd
                           0000FC   513 _S0_IF_BYTE	=	0x00fc
                           0000FB   514 _S0_FREE	=	0x00fb
                           0000FA   515 _S0_T_FIFO	=	0x00fa
                           0000F8   516 _S0_R_FIFO	=	0x00f8
                           0000F7   517 _ADC_START	=	0x00f7
                                    518 ;--------------------------------------------------------
                                    519 ; overlayable register banks
                                    520 ;--------------------------------------------------------
                                    521 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        522 	.ds 8
                                    523 ;--------------------------------------------------------
                                    524 ; internal ram data
                                    525 ;--------------------------------------------------------
                                    526 	.area DSEG    (DATA)
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable items in internal ram
                                    529 ;--------------------------------------------------------
                                    530 ;--------------------------------------------------------
                                    531 ; indirectly addressable internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area ISEG    (DATA)
                                    534 ;--------------------------------------------------------
                                    535 ; absolute internal ram data
                                    536 ;--------------------------------------------------------
                                    537 	.area IABS    (ABS,DATA)
                                    538 	.area IABS    (ABS,DATA)
                                    539 ;--------------------------------------------------------
                                    540 ; bit data
                                    541 ;--------------------------------------------------------
                                    542 	.area BSEG    (BIT)
      00000C                        543 _ak820_tapping_before_sloc0_1_0:
      00000C                        544 	.ds 1
                                    545 ;--------------------------------------------------------
                                    546 ; paged external ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area PSEG    (PAG,XDATA)
                                    549 ;--------------------------------------------------------
                                    550 ; uninitialized external ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area XSEG    (XDATA)
      000598                        553 _source_state:
      000598                        554 	.ds 130
      00061A                        555 _pending_time:
      00061A                        556 	.ds 2
      00061C                        557 _pending_code:
      00061C                        558 	.ds 2
      00061E                        559 _source_PARM_1:
      00061E                        560 	.ds 2
      000620                        561 _hold_PARM_2:
      000620                        562 	.ds 1
      000621                        563 _hold_code_10000_597:
      000621                        564 	.ds 2
      000623                        565 _hold_mods_30000_600:
      000623                        566 	.ds 1
      000624                        567 _commit_pending_id_10000_606:
      000624                        568 	.ds 1
      000625                        569 _ak820_tapping_before_event_10000_607:
      000625                        570 	.ds 2
      000627                        571 _ak820_tapping_process_record_10000_618:
      000627                        572 	.ds 2
      000629                        573 _ak820_tapping_process_code_10000_619:
      000629                        574 	.ds 2
      00062B                        575 _ak820_tapping_process_sc_mods_10000_619:
      00062B                        576 	.ds 1
                                    577 ;--------------------------------------------------------
                                    578 ; absolute external ram data
                                    579 ;--------------------------------------------------------
                                    580 	.area XABS    (ABS,XDATA)
                                    581 ;--------------------------------------------------------
                                    582 ; initialized external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area XISEG   (XDATA)
      000D77                        585 _pending:
      000D77                        586 	.ds 1
                                    587 	.area HOME    (CODE)
                                    588 	.area GSINIT0 (CODE)
                                    589 	.area GSINIT1 (CODE)
                                    590 	.area GSINIT2 (CODE)
                                    591 	.area GSINIT3 (CODE)
                                    592 	.area GSINIT4 (CODE)
                                    593 	.area GSINIT5 (CODE)
                                    594 	.area GSINIT  (CODE)
                                    595 	.area GSFINAL (CODE)
                                    596 	.area CSEG    (CODE)
                                    597 ;--------------------------------------------------------
                                    598 ; global & static initialisations
                                    599 ;--------------------------------------------------------
                                    600 	.area HOME    (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 	.area GSFINAL (CODE)
                                    603 	.area GSINIT  (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; Home
                                    606 ;--------------------------------------------------------
                                    607 	.area HOME    (CODE)
                                    608 	.area HOME    (CODE)
                                    609 ;--------------------------------------------------------
                                    610 ; code
                                    611 ;--------------------------------------------------------
                                    612 	.area CSEG    (CODE)
                                    613 ;------------------------------------------------------------
                                    614 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    615 ;------------------------------------------------------------
                                    616 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    617 ;------------------------------------------------------------
                                    618 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    619 ;	-----------------------------------------
                           000007   620 	ar7 = 0x07
                           000006   621 	ar6 = 0x06
                           000005   622 	ar5 = 0x05
                           000004   623 	ar4 = 0x04
                           000003   624 	ar3 = 0x03
                           000002   625 	ar2 = 0x02
                           000001   626 	ar1 = 0x01
                           000000   627 	ar0 = 0x00
                                    628 ;	 function source
                                    629 ;	-----------------------------------------
      004355                        630 _source:
                                    631 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004355 90 06 1F         [24]  632 	mov	dptr,#(_source_PARM_1 + 0x0001)
      004358 E0               [24]  633 	movx	a,@dptr
      004359 FF               [12]  634 	mov	r7,a
      00435A BF 10 00         [24]  635 	cjne	r7,#0x10,00147$
      00435D                        636 00147$:
      00435D 50 14            [24]  637 	jnc	00102$
      00435F 90 06 1E         [24]  638 	mov	dptr,#_source_PARM_1
      004362 E0               [24]  639 	movx	a,@dptr
      004363 FE               [12]  640 	mov	r6,a
      004364 BE 08 00         [24]  641 	cjne	r6,#0x08,00149$
      004367                        642 00149$:
      004367 50 0A            [24]  643 	jnc	00102$
      004369 8F 05            [24]  644 	mov	ar5,r7
      00436B ED               [12]  645 	mov	a,r5
      00436C 12 38 83         [24]  646 	lcall	_ak820_outline_0176
      00436F 2E               [12]  647 	add	a,r6
      004370 F5 82            [12]  648 	mov	dpl,a
      004372 22               [24]  649 	ret
      004373                        650 00102$:
                                    651 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      004373 90 06 1E         [24]  652 	mov	dptr,#_source_PARM_1
      004376 E0               [24]  653 	movx	a,@dptr
      004377 FE               [12]  654 	mov	r6,a
      004378 BE 01 00         [24]  655 	cjne	r6,#0x01,00151$
      00437B                        656 00151$:
      00437B 50 0E            [24]  657 	jnc	00109$
                                    658 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      00437D BF FD 04         [24]  659 	cjne	r7,#0xfd,00105$
      004380 75 82 80         [24]  660 	mov	dpl, #0x80
      004383 22               [24]  661 	ret
      004384                        662 00105$:
                                    663 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004384 BF FC 04         [24]  664 	cjne	r7,#0xfc,00109$
      004387 75 82 81         [24]  665 	mov	dpl, #0x81
      00438A 22               [24]  666 	ret
      00438B                        667 00109$:
                                    668 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      00438B 75 82 FF         [24]  669 	mov	dpl, #0xff
                                    670 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      00438E 22               [24]  671 	ret
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'hold'
                                    674 ;------------------------------------------------------------
                                    675 ;pressed       Allocated with name '_hold_PARM_2'
                                    676 ;code          Allocated with name '_hold_code_10000_597'
                                    677 ;mods          Allocated with name '_hold_mods_30000_600'
                                    678 ;layer         Allocated with name '_hold_layer_30000_603'
                                    679 ;------------------------------------------------------------
                                    680 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    681 ;	-----------------------------------------
                                    682 ;	 function hold
                                    683 ;	-----------------------------------------
      00438F                        684 _hold:
      00438F 12 38 3C         [24]  685 	lcall	_ak820_outline_0098
      004392 90 06 21         [24]  686 	mov	dptr,#_hold_code_10000_597
      004395 12 38 41         [24]  687 	lcall	_ak820_outline_0099
                                    688 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004398 90 06 21         [24]  689 	mov	dptr,#_hold_code_10000_597
      00439B 12 37 CD         [24]  690 	lcall	_ak820_outline_0009
      00439E 74 C0            [12]  691 	mov	a,#0x100 - 0x40
      0043A0 2D               [12]  692 	add	a,r5
      0043A1 40 2E            [24]  693 	jc	00110$
                                    694 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      0043A3 8F 05            [24]  695 	mov	ar5,r7
      0043A5 53 05 1F         [24]  696 	anl	ar5,#0x1f
      0043A8 90 06 23         [24]  697 	mov	dptr,#_hold_mods_30000_600
      0043AB ED               [12]  698 	mov	a,r5
      0043AC F0               [24]  699 	movx	@dptr,a
                                    700 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      0043AD ED               [12]  701 	mov	a,r5
      0043AE 30 E4 08         [24]  702 	jnb	acc.4,00102$
      0043B1 ED               [12]  703 	mov	a,r5
      0043B2 C4               [12]  704 	swap	a
      0043B3 54 F0            [12]  705 	anl	a,#0xf0
      0043B5 90 06 23         [24]  706 	mov	dptr,#_hold_mods_30000_600
      0043B8 F0               [24]  707 	movx	@dptr,a
      0043B9                        708 00102$:
                                    709 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      0043B9 90 06 20         [24]  710 	mov	dptr,#_hold_PARM_2
      0043BC E0               [24]  711 	movx	a,@dptr
      0043BD 60 09            [24]  712 	jz	00104$
      0043BF 90 06 23         [24]  713 	mov	dptr,#_hold_mods_30000_600
      0043C2 E0               [24]  714 	movx	a,@dptr
      0043C3 F5 82            [12]  715 	mov	dpl,a
      0043C5 02 73 60         [24]  716 	ljmp	_register_mods
      0043C8                        717 00104$:
                                    718 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      0043C8 90 06 23         [24]  719 	mov	dptr,#_hold_mods_30000_600
      0043CB E0               [24]  720 	movx	a,@dptr
      0043CC F5 82            [12]  721 	mov	dpl,a
      0043CE 02 73 74         [24]  722 	ljmp	_unregister_mods
      0043D1                        723 00110$:
                                    724 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      0043D1 8F 06            [24]  725 	mov	ar6,r7
      0043D3 74 0F            [12]  726 	mov	a,#0x0f
      0043D5 5E               [12]  727 	anl	a,r6
      0043D6 FF               [12]  728 	mov	r7,a
                                    729 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      0043D7 90 06 20         [24]  730 	mov	dptr,#_hold_PARM_2
      0043DA E0               [24]  731 	movx	a,@dptr
      0043DB 60 05            [24]  732 	jz	00107$
      0043DD 8F 82            [24]  733 	mov	dpl, r7
      0043DF 02 75 1B         [24]  734 	ljmp	_layer_hold_on
      0043E2                        735 00107$:
                                    736 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      0043E2 8F 82            [24]  737 	mov	dpl, r7
                                    738 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0043E4 02 75 53         [24]  739 	ljmp	_layer_hold_off
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'commit_pending'
                                    742 ;------------------------------------------------------------
                                    743 ;id            Allocated with name '_commit_pending_id_10000_606'
                                    744 ;------------------------------------------------------------
                                    745 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    746 ;	-----------------------------------------
                                    747 ;	 function commit_pending
                                    748 ;	-----------------------------------------
      0043E7                        749 _commit_pending:
                                    750 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      0043E7 90 0D 77         [24]  751 	mov	dptr,#_pending
      0043EA E0               [24]  752 	movx	a,@dptr
      0043EB 90 06 24         [24]  753 	mov	dptr,#_commit_pending_id_10000_606
      0043EE F0               [24]  754 	movx	@dptr,a
                                    755 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      0043EF 12 47 09         [24]  756 	lcall	_ak820_outline_0142
                                    757 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      0043F2 90 06 24         [24]  758 	mov	dptr,#_commit_pending_id_10000_606
      0043F5 E0               [24]  759 	movx	a,@dptr
      0043F6 24 98            [12]  760 	add	a,#_source_state
      0043F8 FF               [12]  761 	mov	r7,a
      0043F9 E4               [12]  762 	clr	a
      0043FA 34 05            [12]  763 	addc	a, #(_source_state >> 8)
      0043FC FE               [12]  764 	mov	r6,a
      0043FD 12 43 3A         [24]  765 	lcall	_ak820_outline_0145
      004400 E0               [24]  766 	movx	a,@dptr
      004401 FD               [12]  767 	mov	r5,a
      004402 43 05 04         [24]  768 	orl	ar5,#0x04
      004405 12 43 3A         [24]  769 	lcall	_ak820_outline_0145
      004408 ED               [12]  770 	mov	a,r5
      004409 F0               [24]  771 	movx	@dptr,a
                                    772 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      00440A 90 06 1C         [24]  773 	mov	dptr,#_pending_code
      00440D 12 37 F9         [24]  774 	lcall	_ak820_outline_0047
      004410 90 06 20         [24]  775 	mov	dptr,#_hold_PARM_2
      004413 74 01            [12]  776 	mov	a,#0x01
      004415 12 42 F6         [24]  777 	lcall	_ak820_outline_0057
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004418 02 43 8F         [24]  779 	ljmp	_hold
                                    780 ;------------------------------------------------------------
                                    781 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    782 ;------------------------------------------------------------
                                    783 ;event         Allocated with name '_ak820_tapping_before_event_10000_607'
                                    784 ;id            Allocated with name '_ak820_tapping_before_id_10000_608'
                                    785 ;------------------------------------------------------------
                                    786 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    787 ;	-----------------------------------------
                                    788 ;	 function ak820_tapping_before
                                    789 ;	-----------------------------------------
      00441B                        790 _ak820_tapping_before:
      00441B 12 38 3C         [24]  791 	lcall	_ak820_outline_0098
      00441E 90 06 25         [24]  792 	mov	dptr,#_ak820_tapping_before_event_10000_607
      004421 12 38 41         [24]  793 	lcall	_ak820_outline_0099
                                    794 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004424 90 06 25         [24]  795 	mov	dptr,#_ak820_tapping_before_event_10000_607
      004427 12 37 CD         [24]  796 	lcall	_ak820_outline_0009
      00442A 12 46 CE         [24]  797 	lcall	_ak820_outline_0021
      00442D C0 07            [24]  798 	push	ar7
      00442F C0 06            [24]  799 	push	ar6
      004431 12 B3 DC         [24]  800 	lcall	___memcpy
      004434 12 43 55         [24]  801 	lcall	_source
      004437 AD 82            [24]  802 	mov	r5, dpl
      004439 D0 06            [24]  803 	pop	ar6
      00443B D0 07            [24]  804 	pop	ar7
                                    805 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      00443D 90 0D E7         [24]  806 	mov	dptr,#_vial_unlock_in_progress
      004440 E0               [24]  807 	movx	a,@dptr
      004441 60 29            [24]  808 	jz	00106$
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004443 74 04            [12]  810 	mov	a,#0x04
      004445 12 46 C3         [24]  811 	lcall	_ak820_outline_0012
      004448 60 1E            [24]  812 	jz	00102$
      00444A BD FF 02         [24]  813 	cjne	r5,#0xff,00218$
      00444D 80 19            [24]  814 	sjmp	00102$
      00444F                        815 00218$:
      00444F 74 05            [12]  816 	mov	a,#0x05
      004451 12 46 C3         [24]  817 	lcall	_ak820_outline_0012
      004454 70 12            [24]  818 	jnz	00102$
      004456 ED               [12]  819 	mov	a,r5
      004457 24 98            [12]  820 	add	a, #_source_state
      004459 FB               [12]  821 	mov	r3,a
      00445A E4               [12]  822 	clr	a
      00445B 34 05            [12]  823 	addc	a, #(_source_state >> 8)
      00445D 12 46 F3         [24]  824 	lcall	_ak820_outline_0051
      004460 53 02 FD         [24]  825 	anl	ar2,#0xfd
      004463 12 33 FC         [24]  826 	lcall	_ak820_outline_0113
      004466 EA               [12]  827 	mov	a,r2
      004467 F0               [24]  828 	movx	@dptr,a
      004468                        829 00102$:
                                    830 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004468 75 82 00         [24]  831 	mov	dpl, #0x00
      00446B 22               [24]  832 	ret
      00446C                        833 00106$:
                                    834 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      00446C 90 0D 77         [24]  835 	mov	dptr,#_pending
      00446F E0               [24]  836 	movx	a,@dptr
      004470 FC               [12]  837 	mov	r4,a
      004471 BC FF 02         [24]  838 	cjne	r4,#0xff,00220$
      004474 80 3B            [24]  839 	sjmp	00108$
      004476                        840 00220$:
      004476 12 37 F1         [24]  841 	lcall	_ak820_outline_0031
      004479 FA               [12]  842 	mov	r2,a
      00447A A3               [24]  843 	inc	dptr
      00447B E0               [24]  844 	movx	a,@dptr
      00447C FB               [12]  845 	mov	r3,a
      00447D 90 06 1A         [24]  846 	mov	dptr,#_pending_time
      004480 12 38 36         [24]  847 	lcall	_ak820_outline_0092
      004483 EA               [12]  848 	mov	a,r2
      004484 C3               [12]  849 	clr	c
      004485 98               [12]  850 	subb	a,r0
      004486 FA               [12]  851 	mov	r2,a
      004487 EB               [12]  852 	mov	a,r3
      004488 99               [12]  853 	subb	a,r1
      004489 FB               [12]  854 	mov	r3,a
      00448A C3               [12]  855 	clr	c
      00448B EA               [12]  856 	mov	a,r2
      00448C 94 C8            [12]  857 	subb	a,#0xc8
      00448E EB               [12]  858 	mov	a,r3
      00448F 94 00            [12]  859 	subb	a,#0x00
      004491 50 17            [24]  860 	jnc	00107$
                                    861 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004493 74 04            [12]  862 	mov	a,#0x04
      004495 12 46 E8         [24]  863 	lcall	_ak820_outline_0043
      004498 60 17            [24]  864 	jz	00108$
      00449A 12 37 AC         [24]  865 	lcall	_ak820_outline_0005
      00449D 60 12            [24]  866 	jz	00108$
      00449F BD FF 02         [24]  867 	cjne	r5,#0xff,00224$
      0044A2 80 06            [24]  868 	sjmp	00107$
      0044A4                        869 00224$:
      0044A4 ED               [12]  870 	mov	a,r5
      0044A5 B5 04 02         [24]  871 	cjne	a,ar4,00225$
      0044A8 80 07            [24]  872 	sjmp	00108$
      0044AA                        873 00225$:
      0044AA                        874 00107$:
      0044AA C0 05            [24]  875 	push	ar5
      0044AC 12 43 E7         [24]  876 	lcall	_commit_pending
      0044AF D0 05            [24]  877 	pop	ar5
      0044B1                        878 00108$:
                                    879 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      0044B1 90 06 25         [24]  880 	mov	dptr,#_ak820_tapping_before_event_10000_607
      0044B4 12 37 F9         [24]  881 	lcall	_ak820_outline_0047
      0044B7 74 04            [12]  882 	mov	a,#0x04
      0044B9 12 46 C3         [24]  883 	lcall	_ak820_outline_0012
      0044BC 60 03            [24]  884 	jz	00114$
      0044BE BD FF 04         [24]  885 	cjne	r5,#0xff,00115$
      0044C1                        886 00114$:
      0044C1 75 82 01         [24]  887 	mov	dpl, #0x01
      0044C4 22               [24]  888 	ret
      0044C5                        889 00115$:
                                    890 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      0044C5 ED               [12]  891 	mov	a,r5
      0044C6 24 98            [12]  892 	add	a, #_source_state
      0044C8 FC               [12]  893 	mov	r4,a
      0044C9 E4               [12]  894 	clr	a
      0044CA 34 05            [12]  895 	addc	a, #(_source_state >> 8)
      0044CC FD               [12]  896 	mov	r5,a
      0044CD 12 42 FC         [24]  897 	lcall	_ak820_outline_0083
      0044D0 FB               [12]  898 	mov	r3,a
      0044D1 30 E1 13         [24]  899 	jnb	acc.1,00120$
                                    900 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0044D4 74 05            [12]  901 	mov	a,#0x05
      0044D6 2E               [12]  902 	add	a, r6
      0044D7 12 37 D7         [24]  903 	lcall	_ak820_outline_0013
      0044DA 70 07            [24]  904 	jnz	00118$
      0044DC 74 FD            [12]  905 	mov	a,#0xfd
      0044DE 5B               [12]  906 	anl	a,r3
      0044DF 12 38 4D         [24]  907 	lcall	_ak820_outline_0110
      0044E2 F0               [24]  908 	movx	@dptr,a
      0044E3                        909 00118$:
                                    910 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      0044E3 75 82 00         [24]  911 	mov	dpl, #0x00
      0044E6 22               [24]  912 	ret
      0044E7                        913 00120$:
                                    914 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      0044E7 12 42 C0         [24]  915 	lcall	_ak820_outline_0010
      0044EA E0               [24]  916 	movx	a,@dptr
      0044EB FF               [12]  917 	mov	r7,a
      0044EC 8B 06            [24]  918 	mov	ar6,r3
      0044EE 53 06 01         [24]  919 	anl	ar6,#0x01
      0044F1 EE               [12]  920 	mov	a,r6
      0044F2 B4 01 00         [24]  921 	cjne	a,#0x01,00231$
      0044F5                        922 00231$:
      0044F5 B3               [12]  923 	cpl	c
      0044F6 92 0C            [24]  924 	mov	_ak820_tapping_before_sloc0_1_0,c
      0044F8 8F F0            [24]  925 	mov	b,r7
      0044FA E4               [12]  926 	clr	a
      0044FB 33               [12]  927 	rlc	a
      0044FC B5 F0 04         [24]  928 	cjne	a,b,00122$
      0044FF 75 82 00         [24]  929 	mov	dpl, #0x00
      004502 22               [24]  930 	ret
      004503                        931 00122$:
                                    932 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004503 63 03 01         [24]  933 	xrl	ar3,#0x01
      004506 12 38 4D         [24]  934 	lcall	_ak820_outline_0110
      004509 EB               [12]  935 	mov	a,r3
      00450A F0               [24]  936 	movx	@dptr,a
                                    937 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      00450B 75 82 01         [24]  938 	mov	dpl, #0x01
                                    939 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      00450E 22               [24]  940 	ret
                                    941 ;------------------------------------------------------------
                                    942 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    943 ;------------------------------------------------------------
                                    944 ;record        Allocated with name '_ak820_tapping_process_record_10000_618'
                                    945 ;id            Allocated with name '_ak820_tapping_process_id_10000_619'
                                    946 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_619'
                                    947 ;code          Allocated with name '_ak820_tapping_process_code_10000_619'
                                    948 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_619'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function ak820_tapping_process
                                    953 ;	-----------------------------------------
      00450F                        954 _ak820_tapping_process:
      00450F 12 38 3C         [24]  955 	lcall	_ak820_outline_0098
      004512 90 06 27         [24]  956 	mov	dptr,#_ak820_tapping_process_record_10000_618
      004515 12 38 41         [24]  957 	lcall	_ak820_outline_0099
                                    958 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004518 90 06 2B         [24]  959 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_619
      00451B E4               [12]  960 	clr	a
      00451C F0               [24]  961 	movx	@dptr,a
                                    962 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      00451D 90 06 27         [24]  963 	mov	dptr,#_ak820_tapping_process_record_10000_618
      004520 12 37 F9         [24]  964 	lcall	_ak820_outline_0047
      004523 74 04            [12]  965 	mov	a,#0x04
      004525 12 46 B8         [24]  966 	lcall	_ak820_outline_0011
      004528 70 04            [24]  967 	jnz	00102$
      00452A 75 82 01         [24]  968 	mov	dpl, #0x01
      00452D 22               [24]  969 	ret
      00452E                        970 00102$:
                                    971 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      00452E 8E 04            [24]  972 	mov	ar4,r6
      004530 8F 05            [24]  973 	mov	ar5,r7
      004532 12 46 CE         [24]  974 	lcall	_ak820_outline_0021
      004535 C0 07            [24]  975 	push	ar7
      004537 C0 06            [24]  976 	push	ar6
      004539 12 B3 DC         [24]  977 	lcall	___memcpy
      00453C 12 43 55         [24]  978 	lcall	_source
      00453F AD 82            [24]  979 	mov	r5, dpl
      004541 D0 06            [24]  980 	pop	ar6
      004543 D0 07            [24]  981 	pop	ar7
                                    982 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004545 BD FF 04         [24]  983 	cjne	r5,#0xff,00104$
      004548 75 82 01         [24]  984 	mov	dpl, #0x01
      00454B 22               [24]  985 	ret
      00454C                        986 00104$:
                                    987 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      00454C 74 07            [12]  988 	mov	a,#0x07
      00454E 12 37 E9         [24]  989 	lcall	_ak820_outline_0018
      004551 12 37 F9         [24]  990 	lcall	_ak820_outline_0047
      004554 90 06 29         [24]  991 	mov	dptr,#_ak820_tapping_process_code_10000_619
      004557 12 47 03         [24]  992 	lcall	_ak820_outline_0055
                                    993 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      00455A BE 1A 15         [24]  994 	cjne	r6,#0x1a,00111$
      00455D BF 7C 12         [24]  995 	cjne	r7,#0x7c,00111$
      004560 90 06 29         [24]  996 	mov	dptr,#_ak820_tapping_process_code_10000_619
      004563 74 26            [12]  997 	mov	a,#0x26
      004565 F0               [24]  998 	movx	@dptr,a
      004566 74 22            [12]  999 	mov	a,#0x22
      004568 A3               [24] 1000 	inc	dptr
      004569 F0               [24] 1001 	movx	@dptr,a
      00456A 90 06 2B         [24] 1002 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_619
      00456D 74 02            [12] 1003 	mov	a,#0x02
      00456F F0               [24] 1004 	movx	@dptr,a
      004570 80 28            [24] 1005 	sjmp	00112$
      004572                       1006 00111$:
                                   1007 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004572 BE 1B 15         [24] 1008 	cjne	r6,#0x1b,00108$
      004575 BF 7C 12         [24] 1009 	cjne	r7,#0x7c,00108$
      004578 90 06 29         [24] 1010 	mov	dptr,#_ak820_tapping_process_code_10000_619
      00457B 74 27            [12] 1011 	mov	a,#0x27
      00457D F0               [24] 1012 	movx	@dptr,a
      00457E 74 32            [12] 1013 	mov	a,#0x32
      004580 A3               [24] 1014 	inc	dptr
      004581 F0               [24] 1015 	movx	@dptr,a
      004582 90 06 2B         [24] 1016 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_619
      004585 74 20            [12] 1017 	mov	a,#0x20
      004587 F0               [24] 1018 	movx	@dptr,a
      004588 80 10            [24] 1019 	sjmp	00112$
      00458A                       1020 00108$:
                                   1021 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      00458A BE 1E 0D         [24] 1022 	cjne	r6,#0x1e,00112$
      00458D BF 7C 0A         [24] 1023 	cjne	r7,#0x7c,00112$
      004590 90 06 29         [24] 1024 	mov	dptr,#_ak820_tapping_process_code_10000_619
      004593 74 28            [12] 1025 	mov	a,#0x28
      004595 F0               [24] 1026 	movx	@dptr,a
      004596 74 32            [12] 1027 	mov	a,#0x32
      004598 A3               [24] 1028 	inc	dptr
      004599 F0               [24] 1029 	movx	@dptr,a
      00459A                       1030 00112$:
                                   1031 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      00459A 90 06 29         [24] 1032 	mov	dptr,#_ak820_tapping_process_code_10000_619
      00459D E0               [24] 1033 	movx	a,@dptr
      00459E A3               [24] 1034 	inc	dptr
      00459F E0               [24] 1035 	movx	a,@dptr
      0045A0 FF               [12] 1036 	mov	r7,a
                                   1037 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      0045A1 BF 20 00         [24] 1038 	cjne	r7,#0x20,00242$
      0045A4                       1039 00242$:
      0045A4 40 05            [24] 1040 	jc	00113$
      0045A6 BF 50 00         [24] 1041 	cjne	r7,#0x50,00244$
      0045A9                       1042 00244$:
      0045A9 40 04            [24] 1043 	jc	00114$
      0045AB                       1044 00113$:
      0045AB 75 82 01         [24] 1045 	mov	dpl, #0x01
      0045AE 22               [24] 1046 	ret
      0045AF                       1047 00114$:
                                   1048 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      0045AF BF 40 00         [24] 1049 	cjne	r7,#0x40,00246$
      0045B2                       1050 00246$:
      0045B2 40 0C            [24] 1051 	jc	00117$
      0045B4 53 07 0F         [24] 1052 	anl	ar7,#0x0f
      0045B7 BF 06 00         [24] 1053 	cjne	r7,#0x06,00248$
      0045BA                       1054 00248$:
      0045BA 40 04            [24] 1055 	jc	00117$
      0045BC 75 82 00         [24] 1056 	mov	dpl, #0x00
      0045BF 22               [24] 1057 	ret
      0045C0                       1058 00117$:
                                   1059 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      0045C0 90 06 27         [24] 1060 	mov	dptr,#_ak820_tapping_process_record_10000_618
      0045C3 12 37 F9         [24] 1061 	lcall	_ak820_outline_0047
      0045C6 74 05            [12] 1062 	mov	a,#0x05
      0045C8 12 46 C3         [24] 1063 	lcall	_ak820_outline_0012
      0045CB 60 1F            [24] 1064 	jz	00131$
                                   1065 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      0045CD 90 0D 77         [24] 1066 	mov	dptr,#_pending
      0045D0 ED               [12] 1067 	mov	a,r5
      0045D1 12 42 CA         [24] 1068 	lcall	_ak820_outline_0028
                                   1069 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      0045D4 12 37 F9         [24] 1070 	lcall	_ak820_outline_0047
      0045D7 90 06 1A         [24] 1071 	mov	dptr,#_pending_time
      0045DA 12 47 03         [24] 1072 	lcall	_ak820_outline_0055
                                   1073 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      0045DD 90 06 29         [24] 1074 	mov	dptr,#_ak820_tapping_process_code_10000_619
      0045E0 12 37 F9         [24] 1075 	lcall	_ak820_outline_0047
      0045E3 90 06 1C         [24] 1076 	mov	dptr,#_pending_code
      0045E6 12 47 03         [24] 1077 	lcall	_ak820_outline_0055
      0045E9 02 46 8C         [24] 1078 	ljmp	00132$
      0045EC                       1079 00131$:
                                   1080 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      0045EC 90 0D 77         [24] 1081 	mov	dptr,#_pending
      0045EF E0               [24] 1082 	movx	a,@dptr
      0045F0 FF               [12] 1083 	mov	r7,a
      0045F1 ED               [12] 1084 	mov	a,r5
      0045F2 B5 07 02         [24] 1085 	cjne	a,ar7,00251$
      0045F5 80 03            [24] 1086 	sjmp	00252$
      0045F7                       1087 00251$:
      0045F7 02 46 65         [24] 1088 	ljmp	00128$
      0045FA                       1089 00252$:
                                   1090 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      0045FA 12 47 09         [24] 1091 	lcall	_ak820_outline_0142
                                   1092 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      0045FD 90 06 2B         [24] 1093 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_619
      004600 E0               [24] 1094 	movx	a,@dptr
      004601 FF               [12] 1095 	mov	r7,a
      004602 E0               [24] 1096 	movx	a,@dptr
      004603 60 05            [24] 1097 	jz	00120$
      004605 8F 82            [24] 1098 	mov	dpl, r7
      004607 12 79 A0         [24] 1099 	lcall	_add_owned_mods
      00460A                       1100 00120$:
                                   1101 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      00460A 90 06 27         [24] 1102 	mov	dptr,#_ak820_tapping_process_record_10000_618
      00460D 12 37 F9         [24] 1103 	lcall	_ak820_outline_0047
      004610 74 07            [12] 1104 	mov	a,#0x07
      004612 2E               [12] 1105 	add	a, r6
      004613 FB               [12] 1106 	mov	r3,a
      004614 E4               [12] 1107 	clr	a
      004615 3F               [12] 1108 	addc	a, r7
      004616 FC               [12] 1109 	mov	r4,a
      004617 90 06 29         [24] 1110 	mov	dptr,#_ak820_tapping_process_code_10000_619
      00461A E0               [24] 1111 	movx	a,@dptr
      00461B F9               [12] 1112 	mov	r1,a
      00461C 7A 00            [12] 1113 	mov	r2,#0x00
      00461E 12 33 FC         [24] 1114 	lcall	_ak820_outline_0113
      004621 E9               [12] 1115 	mov	a,r1
      004622 F0               [24] 1116 	movx	@dptr,a
      004623 EA               [12] 1117 	mov	a,r2
      004624 A3               [24] 1118 	inc	dptr
      004625 F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004626 C3               [12] 1121 	clr	c
      004627 04               [12] 1122 	inc	a
      004628 99               [12] 1123 	subb	a,r1
      004629 50 28            [24] 1124 	jnc	00122$
                                   1125 ;	free result
                                   1126 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      00462B 74 06            [12] 1127 	mov	a,#0x06
      00462D 12 37 E9         [24] 1128 	lcall	_ak820_outline_0018
      004630 E0               [24] 1129 	movx	a,@dptr
      004631 54 0F            [12] 1130 	anl	a,#0x0f
      004633 44 10            [12] 1131 	orl	a,#0x10
      004635 F0               [24] 1132 	movx	@dptr,a
                                   1133 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004636 12 42 C0         [24] 1134 	lcall	_ak820_outline_0010
      004639 74 01            [12] 1135 	mov	a,#0x01
      00463B 12 42 F6         [24] 1136 	lcall	_ak820_outline_0057
                                   1137 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      00463E 12 6E D6         [24] 1138 	lcall	_process_record
                                   1139 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004641 90 06 27         [24] 1140 	mov	dptr,#_ak820_tapping_process_record_10000_618
      004644 12 37 A2         [24] 1141 	lcall	_ak820_outline_0004
      004647 A3               [24] 1142 	inc	dptr
      004648 A3               [24] 1143 	inc	dptr
      004649 A3               [24] 1144 	inc	dptr
      00464A A3               [24] 1145 	inc	dptr
      00464B A3               [24] 1146 	inc	dptr
      00464C E4               [12] 1147 	clr	a
      00464D 12 42 F6         [24] 1148 	lcall	_ak820_outline_0057
                                   1149 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004650 12 6E D6         [24] 1150 	lcall	_process_record
      004653                       1151 00122$:
                                   1152 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004653 90 06 2B         [24] 1153 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_619
      004656 E0               [24] 1154 	movx	a,@dptr
      004657 FF               [12] 1155 	mov	r7,a
      004658 E0               [24] 1156 	movx	a,@dptr
      004659 60 31            [24] 1157 	jz	00132$
                                   1158 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      00465B 8F 82            [24] 1159 	mov	dpl, r7
      00465D 12 79 B0         [24] 1160 	lcall	_del_owned_mods
                                   1161 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004660 12 7C DC         [24] 1162 	lcall	_send_keyboard_report
      004663 80 27            [24] 1163 	sjmp	00132$
      004665                       1164 00128$:
                                   1165 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004665 ED               [12] 1166 	mov	a,r5
      004666 24 98            [12] 1167 	add	a, #_source_state
      004668 FE               [12] 1168 	mov	r6,a
      004669 E4               [12] 1169 	clr	a
      00466A 34 05            [12] 1170 	addc	a, #(_source_state >> 8)
      00466C FF               [12] 1171 	mov	r7,a
      00466D 12 38 30         [24] 1172 	lcall	_ak820_outline_0090
      004670 FD               [12] 1173 	mov	r5,a
      004671 30 E2 18         [24] 1174 	jnb	acc.2,00132$
                                   1175 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004674 53 05 FB         [24] 1176 	anl	ar5,#0xfb
      004677 12 43 1A         [24] 1177 	lcall	_ak820_outline_0109
      00467A ED               [12] 1178 	mov	a,r5
      00467B F0               [24] 1179 	movx	@dptr,a
                                   1180 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      00467C 90 06 29         [24] 1181 	mov	dptr,#_ak820_tapping_process_code_10000_619
      00467F 12 37 F9         [24] 1182 	lcall	_ak820_outline_0047
      004682 90 06 20         [24] 1183 	mov	dptr,#_hold_PARM_2
      004685 E4               [12] 1184 	clr	a
      004686 12 42 F6         [24] 1185 	lcall	_ak820_outline_0057
      004689 12 43 8F         [24] 1186 	lcall	_hold
      00468C                       1187 00132$:
                                   1188 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      00468C 75 82 00         [24] 1189 	mov	dpl, #0x00
                                   1190 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      00468F 22               [24] 1191 	ret
                                   1192 ;------------------------------------------------------------
                                   1193 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1194 ;------------------------------------------------------------
                                   1195 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_642'
                                   1196 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_643'
                                   1197 ;------------------------------------------------------------
                                   1198 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1199 ;	-----------------------------------------
                                   1200 ;	 function ak820_tapping_cancel
                                   1201 ;	-----------------------------------------
      004690                       1202 _ak820_tapping_cancel:
                                   1203 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004690 12 47 09         [24] 1204 	lcall	_ak820_outline_0142
                                   1205 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004693 7F 00            [12] 1206 	mov	r7,#0x00
      004695                       1207 00103$:
      004695 BF 82 00         [24] 1208 	cjne	r7,#0x82,00122$
      004698                       1209 00122$:
      004698 50 1D            [24] 1210 	jnc	00105$
                                   1211 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      00469A EF               [12] 1212 	mov	a,r7
      00469B 24 98            [12] 1213 	add	a, #_source_state
      00469D FD               [12] 1214 	mov	r5,a
      00469E E4               [12] 1215 	clr	a
      00469F 34 05            [12] 1216 	addc	a, #(_source_state >> 8)
      0046A1 12 46 FB         [24] 1217 	lcall	_ak820_outline_0053
                                   1218 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      0046A4 74 02            [12] 1219 	mov	a,#0x02
      0046A6 5C               [12] 1220 	anl	a,r4
      0046A7 FB               [12] 1221 	mov	r3,a
      0046A8 53 04 01         [24] 1222 	anl	ar4,#0x01
      0046AB EC               [12] 1223 	mov	a,r4
      0046AC 2C               [12] 1224 	add	a,r4
      0046AD 42 03            [12] 1225 	orl	ar3,a
      0046AF 12 38 5D         [24] 1226 	lcall	_ak820_outline_0122
      0046B2 EB               [12] 1227 	mov	a,r3
      0046B3 F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0046B4 0F               [12] 1230 	inc	r7
      0046B5 80 DE            [24] 1231 	sjmp	00103$
      0046B7                       1232 00105$:
                                   1233 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      0046B7 22               [24] 1234 	ret
                                   1235 	.area CSEG    (CODE)
                                   1236 	.area CONST   (CODE)
                                   1237 	.area XINIT   (CODE)
      00BC9C                       1238 __xinit__pending:
      00BC9C FF                    1239 	.db #0xff	; 255
                                   1240 	.area CABS    (ABS,CODE)
                                   1241 
                                   1242 ; Experimental exact instruction outlining.
                                   1243 	.globl _ak820_outline_0004
                                   1244 	.globl _ak820_outline_0005
                                   1245 	.globl _ak820_outline_0009
                                   1246 	.globl _ak820_outline_0010
                                   1247 	.globl _ak820_outline_0011
                                   1248 	.globl _ak820_outline_0012
                                   1249 	.globl _ak820_outline_0013
                                   1250 	.globl _ak820_outline_0018
                                   1251 	.globl _ak820_outline_0021
                                   1252 	.globl _ak820_outline_0028
                                   1253 	.globl _ak820_outline_0031
                                   1254 	.globl _ak820_outline_0043
                                   1255 	.globl _ak820_outline_0047
                                   1256 	.globl _ak820_outline_0051
                                   1257 	.globl _ak820_outline_0053
                                   1258 	.globl _ak820_outline_0055
                                   1259 	.globl _ak820_outline_0057
                                   1260 	.globl _ak820_outline_0083
                                   1261 	.globl _ak820_outline_0090
                                   1262 	.globl _ak820_outline_0092
                                   1263 	.globl _ak820_outline_0098
                                   1264 	.globl _ak820_outline_0099
                                   1265 	.globl _ak820_outline_0109
                                   1266 	.globl _ak820_outline_0110
                                   1267 	.globl _ak820_outline_0113
                                   1268 	.globl _ak820_outline_0122
                                   1269 	.globl _ak820_outline_0142
                                   1270 	.globl _ak820_outline_0145
                                   1271 	.globl _ak820_outline_0176
                                   1272 
                                   1273 	.area CSEG (CODE)
                                   1274 ; function ak820_outline_0011
      0046B8                       1275 _ak820_outline_0011:
      0046B8 2E               [12] 1276 	add	a,r6
      0046B9 FC               [12] 1277 	mov	r4,a
      0046BA E4               [12] 1278 	clr	a
      0046BB 3F               [12] 1279 	addc	a,r7
      0046BC FD               [12] 1280 	mov	r5,a
      0046BD 8C 82            [24] 1281 	mov	dpl,r4
      0046BF 8D 83            [24] 1282 	mov	dph,r5
      0046C1 E0               [24] 1283 	movx	a,@dptr
      0046C2 22               [24] 1284 	ret
                                   1285 
                                   1286 	.area CSEG (CODE)
                                   1287 ; function ak820_outline_0012
      0046C3                       1288 _ak820_outline_0012:
      0046C3 2E               [12] 1289 	add	a,r6
      0046C4 FB               [12] 1290 	mov	r3,a
      0046C5 E4               [12] 1291 	clr	a
      0046C6 3F               [12] 1292 	addc	a,r7
      0046C7 FC               [12] 1293 	mov	r4,a
      0046C8 8B 82            [24] 1294 	mov	dpl,r3
      0046CA 8C 83            [24] 1295 	mov	dph,r4
      0046CC E0               [24] 1296 	movx	a,@dptr
      0046CD 22               [24] 1297 	ret
                                   1298 
                                   1299 	.area CSEG (CODE)
                                   1300 ; function ak820_outline_0021
      0046CE                       1301 _ak820_outline_0021:
      0046CE 90 0D 67         [24] 1302 	mov	dptr,#___memcpy_PARM_2
      0046D1 EC               [12] 1303 	mov	a,r4
      0046D2 F0               [24] 1304 	movx	@dptr,a
      0046D3 ED               [12] 1305 	mov	a,r5
      0046D4 A3               [24] 1306 	inc	dptr
      0046D5 F0               [24] 1307 	movx	@dptr,a
      0046D6 E4               [12] 1308 	clr	a
      0046D7 A3               [24] 1309 	inc	dptr
      0046D8 F0               [24] 1310 	movx	@dptr,a
      0046D9 90 0D 6A         [24] 1311 	mov	dptr,#___memcpy_PARM_3
      0046DC 74 02            [12] 1312 	mov	a,#0x02
      0046DE F0               [24] 1313 	movx	@dptr,a
      0046DF E4               [12] 1314 	clr	a
      0046E0 A3               [24] 1315 	inc	dptr
      0046E1 F0               [24] 1316 	movx	@dptr,a
      0046E2 90 06 1E         [24] 1317 	mov	dptr,#_source_PARM_1
      0046E5 F5 F0            [12] 1318 	mov	b,a
      0046E7 22               [24] 1319 	ret
                                   1320 
                                   1321 	.area CSEG (CODE)
                                   1322 ; function ak820_outline_0043
      0046E8                       1323 _ak820_outline_0043:
      0046E8 2E               [12] 1324 	add	a,r6
      0046E9 FA               [12] 1325 	mov	r2,a
      0046EA E4               [12] 1326 	clr	a
      0046EB 3F               [12] 1327 	addc	a,r7
      0046EC FB               [12] 1328 	mov	r3,a
      0046ED 8A 82            [24] 1329 	mov	dpl,r2
      0046EF 8B 83            [24] 1330 	mov	dph,r3
      0046F1 E0               [24] 1331 	movx	a,@dptr
      0046F2 22               [24] 1332 	ret
                                   1333 
                                   1334 	.area CSEG (CODE)
                                   1335 ; function ak820_outline_0051
      0046F3                       1336 _ak820_outline_0051:
      0046F3 FC               [12] 1337 	mov	r4,a
      0046F4 8B 82            [24] 1338 	mov	dpl,r3
      0046F6 8C 83            [24] 1339 	mov	dph,r4
      0046F8 E0               [24] 1340 	movx	a,@dptr
      0046F9 FA               [12] 1341 	mov	r2,a
      0046FA 22               [24] 1342 	ret
                                   1343 
                                   1344 	.area CSEG (CODE)
                                   1345 ; function ak820_outline_0053
      0046FB                       1346 _ak820_outline_0053:
      0046FB FE               [12] 1347 	mov	r6,a
      0046FC 8D 82            [24] 1348 	mov	dpl,r5
      0046FE 8E 83            [24] 1349 	mov	dph,r6
      004700 E0               [24] 1350 	movx	a,@dptr
      004701 FC               [12] 1351 	mov	r4,a
      004702 22               [24] 1352 	ret
                                   1353 
                                   1354 	.area CSEG (CODE)
                                   1355 ; function ak820_outline_0055
      004703                       1356 _ak820_outline_0055:
      004703 EE               [12] 1357 	mov	a,r6
      004704 F0               [24] 1358 	movx	@dptr,a
      004705 EF               [12] 1359 	mov	a,r7
      004706 A3               [24] 1360 	inc	dptr
      004707 F0               [24] 1361 	movx	@dptr,a
      004708 22               [24] 1362 	ret
                                   1363 
                                   1364 	.area CSEG (CODE)
                                   1365 ; function ak820_outline_0142
      004709                       1366 _ak820_outline_0142:
      004709 90 0D 77         [24] 1367 	mov	dptr,#_pending
      00470C 74 FF            [12] 1368 	mov	a,#0xff
      00470E F0               [24] 1369 	movx	@dptr,a
      00470F 22               [24] 1370 	ret
