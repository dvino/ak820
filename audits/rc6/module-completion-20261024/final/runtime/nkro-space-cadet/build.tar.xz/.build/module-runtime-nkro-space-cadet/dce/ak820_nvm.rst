                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         53 bits:
      000025                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000519                        109 _page_data:
      000519                        110 	.ds 64
      000559                        111 _cached_page:
      000559                        112 	.ds 1
      00055A                        113 _batch_depth:
      00055A                        114 	.ds 1
      00055B                        115 _first_failure_stage:
      00055B                        116 	.ds 1
      00055C                        117 _nvm_fail_stage_10000_20:
      00055C                        118 	.ds 1
      00055D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055D                        120 	.ds 2
      00055F                        121 _crc_byte_PARM_2:
      00055F                        122 	.ds 1
      000560                        123 _crc_byte_crc_10000_25:
      000560                        124 	.ds 2
      000562                        125 _page_crc_crc_10000_30:
      000562                        126 	.ds 2
      000564                        127 _write_page_address_10000_32:
      000564                        128 	.ds 2
      000566                        129 _journal_header_valid_header_10000_39:
      000566                        130 	.ds 2
      000568                        131 _recover_journal_header_10000_46:
      000568                        132 	.ds 9
      000571                        133 _ak820_nvm_flush_header_10000_62:
      000571                        134 	.ds 9
      00057A                        135 _ak820_nvm_flush_stage_10000_62:
      00057A                        136 	.ds 1
      00057B                        137 _load_page_page_10000_87:
      00057B                        138 	.ds 1
      00057C                        139 _read_offset_offset_10000_93:
      00057C                        140 	.ds 2
      00057E                        141 _eeprom_read_byte_addr_10000_97:
      00057E                        142 	.ds 3
      000581                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000584                        146 	.ds 2
      000586                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000586                        148 	.ds 2
      000588                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000588                        150 	.ds 2
      00058A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058A                        152 	.ds 3
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058D                        154 	.ds 2
      00058F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058F                        156 	.ds 2
      000591                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000591                        158 	.ds 3
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000594                        160 	.ds 2
      000596                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000596                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B40                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B40 E5 82            [12]  215 	mov	a,dpl
      003B42 90 05 5C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B45 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B46 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003B49 90 05 5C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B4C E0               [24]  221 	movx	a,@dptr
      003B4D 90 05 5B         [24]  222 	mov	dptr,#_first_failure_stage
      003B50 F0               [24]  223 	movx	@dptr,a
      003B51                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B51 D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B53 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B54                        239 _ak820_nvm_diagnostic:
      003B54 12 38 3C         [24]  240 	lcall	_ak820_outline_0098
      003B57 90 05 5D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B5A 12 38 41         [24]  242 	lcall	_ak820_outline_0099
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003B5D 90 05 5D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B60 12 37 F9         [24]  245 	lcall	_ak820_outline_0047
      003B63 A2 09            [12]  246 	mov	c,_storage_failed
      003B65 E4               [12]  247 	clr	a
      003B66 33               [12]  248 	rlc	a
      003B67 12 43 1A         [24]  249 	lcall	_ak820_outline_0109
      003B6A 12 42 F6         [24]  250 	lcall	_ak820_outline_0057
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003B6D A3               [24]  252 	inc	dptr
      003B6E A2 07            [12]  253 	mov	c,_page_valid
      003B70 E4               [12]  254 	clr	a
      003B71 33               [12]  255 	rlc	a
      003B72 12 42 CA         [24]  256 	lcall	_ak820_outline_0028
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003B75 A2 08            [12]  258 	mov	c,_page_dirty
      003B77 E4               [12]  259 	clr	a
      003B78 33               [12]  260 	rlc	a
      003B79 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003B7A 74 03            [12]  263 	mov	a,#0x03
      003B7C 12 43 3F         [24]  264 	lcall	_ak820_outline_0148
      003B7F 90 05 5A         [24]  265 	mov	dptr,#_batch_depth
      003B82 E0               [24]  266 	movx	a,@dptr
      003B83 12 38 4D         [24]  267 	lcall	_ak820_outline_0110
      003B86 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003B87 74 04            [12]  270 	mov	a,#0x04
      003B89 12 43 3F         [24]  271 	lcall	_ak820_outline_0148
      003B8C 90 05 59         [24]  272 	mov	dptr,#_cached_page
      003B8F E0               [24]  273 	movx	a,@dptr
      003B90 12 38 4D         [24]  274 	lcall	_ak820_outline_0110
      003B93 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003B94 12 42 C0         [24]  277 	lcall	_ak820_outline_0010
      003B97 E4               [12]  278 	clr	a
      003B98 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003B99 74 06            [12]  281 	mov	a,#0x06
      003B9B 12 43 24         [24]  282 	lcall	_ak820_outline_0125
      003B9E 90 05 5B         [24]  283 	mov	dptr,#_first_failure_stage
      003BA1 E0               [24]  284 	movx	a,@dptr
      003BA2 12 43 1A         [24]  285 	lcall	_ak820_outline_0109
      003BA5 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BA6 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003BA7                        300 _crc_byte:
      003BA7 12 38 3C         [24]  301 	lcall	_ak820_outline_0098
      003BAA 90 05 60         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003BAD 12 38 41         [24]  303 	lcall	_ak820_outline_0099
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BB0 90 05 5F         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003BB3 E0               [24]  306 	movx	a,@dptr
      003BB4 FF               [12]  307 	mov	r7,a
      003BB5 7E 00            [12]  308 	mov	r6,#0x00
      003BB7 90 05 60         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003BBA E0               [24]  310 	movx	a,@dptr
      003BBB 6E               [12]  311 	xrl	a,r6
      003BBC F0               [24]  312 	movx	@dptr,a
      003BBD A3               [24]  313 	inc	dptr
      003BBE E0               [24]  314 	movx	a,@dptr
      003BBF 6F               [12]  315 	xrl	a,r7
      003BC0 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BC1 7F 00            [12]  318 	mov	r7,#0x00
      003BC3                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003BC3 90 05 60         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003BC6 12 43 08         [24]  322 	lcall	_ak820_outline_0094
      003BC9 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003BCC ED               [12]  324 	mov	a,r5
      003BCD 2D               [12]  325 	add	a,r5
      003BCE FB               [12]  326 	mov	r3,a
      003BCF EE               [12]  327 	mov	a,r6
      003BD0 33               [12]  328 	rlc	a
      003BD1 FC               [12]  329 	mov	r4,a
      003BD2 63 03 21         [24]  330 	xrl	ar3,#0x21
      003BD5 63 04 10         [24]  331 	xrl	ar4,#0x10
      003BD8 80 06            [24]  332 	sjmp	00107$
      003BDA                        333 00106$:
      003BDA ED               [12]  334 	mov	a,r5
      003BDB 2D               [12]  335 	add	a,r5
      003BDC FB               [12]  336 	mov	r3,a
      003BDD EE               [12]  337 	mov	a,r6
      003BDE 33               [12]  338 	rlc	a
      003BDF FC               [12]  339 	mov	r4,a
      003BE0                        340 00107$:
      003BE0 90 05 60         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003BE3 12 38 2A         [24]  342 	lcall	_ak820_outline_0071
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BE6 0F               [12]  344 	inc	r7
      003BE7 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003BEA 12 33 FC         [24]  347 	lcall	_ak820_outline_0113
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003BED 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003BEE                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003BEE 90 05 62         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003BF1 74 FF            [12]  363 	mov	a,#0xff
      003BF3 F0               [24]  364 	movx	@dptr,a
      003BF4 A3               [24]  365 	inc	dptr
      003BF5 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003BF6 7F 00            [12]  368 	mov	r7,#0x00
      003BF8                        369 00102$:
      003BF8 90 05 62         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003BFB 12 43 08         [24]  371 	lcall	_ak820_outline_0094
      003BFE 12 43 0E         [24]  372 	lcall	_ak820_outline_0096
      003C01 90 05 5F         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003C04 F0               [24]  374 	movx	@dptr,a
      003C05 12 38 5D         [24]  375 	lcall	_ak820_outline_0122
      003C08 C0 07            [24]  376 	push	ar7
      003C0A 12 3B A7         [24]  377 	lcall	_crc_byte
      003C0D AD 82            [24]  378 	mov	r5, dpl
      003C0F AE 83            [24]  379 	mov	r6, dph
      003C11 D0 07            [24]  380 	pop	ar7
      003C13 90 05 62         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003C16 12 43 45         [24]  382 	lcall	_ak820_outline_0149
      003C19 0F               [12]  383 	inc	r7
      003C1A BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C1D 12 38 5D         [24]  386 	lcall	_ak820_outline_0122
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C20 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003C21                        399 _write_page:
      003C21 12 38 3C         [24]  400 	lcall	_ak820_outline_0098
      003C24 90 05 64         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003C27 12 38 41         [24]  402 	lcall	_ak820_outline_0099
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C2A 90 05 64         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003C2D 12 37 A2         [24]  405 	lcall	_ak820_outline_0004
      003C30 C0 07            [24]  406 	push	ar7
      003C32 C0 06            [24]  407 	push	ar6
      003C34 12 39 B9         [24]  408 	lcall	_ak820_flash_erase
      003C37 E5 82            [12]  409 	mov	a, dpl
      003C39 D0 06            [24]  410 	pop	ar6
      003C3B D0 07            [24]  411 	pop	ar7
      003C3D 70 03            [24]  412 	jnz	00102$
      003C3F F5 82            [12]  413 	mov	dpl,a
      003C41 22               [24]  414 	ret
      003C42                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C42 90 04 F5         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C45 74 19            [12]  418 	mov	a,#_page_data
      003C47 F0               [24]  419 	movx	@dptr,a
      003C48 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003C4A A3               [24]  421 	inc	dptr
      003C4B 12 42 F6         [24]  422 	lcall	_ak820_outline_0057
      003C4E 12 3A CD         [24]  423 	lcall	_ak820_flash_program_page
      003C51 E5 82            [12]  424 	mov	a, dpl
      003C53 70 03            [24]  425 	jnz	00120$
      003C55 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C57 22               [24]  428 	ret
      003C58                        429 00120$:
      003C58 7F 00            [12]  430 	mov	r7,#0x00
      003C5A                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C5A 8F 05            [24]  433 	mov	ar5,r7
      003C5C 7E 00            [12]  434 	mov	r6,#0x00
      003C5E 90 05 64         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003C61 12 38 52         [24]  436 	lcall	_ak820_outline_0112
      003C64 ED               [12]  437 	mov	a,r5
      003C65 2B               [12]  438 	add	a, r3
      003C66 FB               [12]  439 	mov	r3,a
      003C67 EE               [12]  440 	mov	a,r6
      003C68 3C               [12]  441 	addc	a, r4
      003C69 FC               [12]  442 	mov	r4,a
      003C6A 12 33 FC         [24]  443 	lcall	_ak820_outline_0113
      003C6D 12 38 AC         [24]  444 	lcall	_ak820_flash_read
      003C70 AE 82            [24]  445 	mov	r6, dpl
      003C72 12 43 0E         [24]  446 	lcall	_ak820_outline_0096
      003C75 FD               [12]  447 	mov	r5,a
      003C76 EE               [12]  448 	mov	a,r6
      003C77 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003C7A 80 04            [24]  450 	sjmp	00109$
      003C7C                        451 00149$:
      003C7C 75 82 00         [24]  452 	mov	dpl, #0x00
      003C7F 22               [24]  453 	ret
      003C80                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C80 0F               [12]  456 	inc	r7
      003C81 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003C84 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003C87 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003C88                        472 _journal_header_valid:
      003C88 12 38 3C         [24]  473 	lcall	_ak820_outline_0098
      003C8B 90 05 66         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003C8E 12 38 41         [24]  475 	lcall	_ak820_outline_0099
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003C91 90 05 66         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003C94 12 37 A2         [24]  478 	lcall	_ak820_outline_0004
      003C97 E0               [24]  479 	movx	a,@dptr
      003C98 FD               [12]  480 	mov	r5,a
      003C99 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003C9C 80 04            [24]  482 	sjmp	00116$
      003C9E                        483 00138$:
      003C9E 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CA1 22               [24]  486 	ret
      003CA2                        487 00116$:
      003CA2 7D 01            [12]  488 	mov	r5,#0x01
      003CA4                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CA4 ED               [12]  491 	mov	a,r5
      003CA5 12 37 E9         [24]  492 	lcall	_ak820_outline_0018
      003CA8 E0               [24]  493 	movx	a,@dptr
      003CA9 FC               [12]  494 	mov	r4,a
      003CAA 8D 02            [24]  495 	mov	ar2,r5
      003CAC 7B 00            [12]  496 	mov	r3,#0x00
      003CAE 74 04            [12]  497 	mov	a,#0x04
      003CB0 2A               [12]  498 	add	a, r2
      003CB1 FA               [12]  499 	mov	r2,a
      003CB2 E4               [12]  500 	clr	a
      003CB3 3B               [12]  501 	addc	a, r3
      003CB4 FB               [12]  502 	mov	r3,a
      003CB5 EA               [12]  503 	mov	a,r2
      003CB6 2E               [12]  504 	add	a, r6
      003CB7 F5 82            [12]  505 	mov	dpl,a
      003CB9 EB               [12]  506 	mov	a,r3
      003CBA 3F               [12]  507 	addc	a, r7
      003CBB F5 83            [12]  508 	mov	dph,a
      003CBD E0               [24]  509 	movx	a,@dptr
      003CBE 62 04            [12]  510 	xrl	ar4,a
      003CC0 BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      003CC3 80 04            [24]  512 	sjmp	00107$
      003CC5                        513 00139$:
      003CC5 75 82 00         [24]  514 	mov	dpl, #0x00
      003CC8 22               [24]  515 	ret
      003CC9                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CC9 0D               [12]  518 	inc	r5
      003CCA BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003CCD 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003CD0 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      003CD1                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003CD1 7F 00            [12]  538 	mov	r7,#0x00
      003CD3                        539 00115$:
      003CD3 EF               [12]  540 	mov	a,r7
      003CD4 24 68            [12]  541 	add	a, #_recover_journal_header_10000_46
      003CD6 FD               [12]  542 	mov	r5,a
      003CD7 E4               [12]  543 	clr	a
      003CD8 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003CDA FE               [12]  545 	mov	r6,a
      003CDB 8F 04            [24]  546 	mov	ar4,r7
      003CDD 7B 00            [12]  547 	mov	r3,#0x00
      003CDF 74 40            [12]  548 	mov	a,#0x40
      003CE1 2C               [12]  549 	add	a, r4
      003CE2 FC               [12]  550 	mov	r4,a
      003CE3 74 EF            [12]  551 	mov	a,#0xef
      003CE5 3B               [12]  552 	addc	a, r3
      003CE6 FB               [12]  553 	mov	r3,a
      003CE7 12 43 50         [24]  554 	lcall	_ak820_outline_0171
      003CEA 12 38 AC         [24]  555 	lcall	_ak820_flash_read
      003CED AC 82            [24]  556 	mov	r4, dpl
      003CEF 12 38 5D         [24]  557 	lcall	_ak820_outline_0122
      003CF2 EC               [12]  558 	mov	a,r4
      003CF3 F0               [24]  559 	movx	@dptr,a
      003CF4 0F               [12]  560 	inc	r7
      003CF5 BF 09 DB         [24]  561 	cjne	r7,#0x09,00115$
                                    562 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003CF8 90 05 68         [24]  563 	mov	dptr,#_recover_journal_header_10000_46
      003CFB 12 3C 88         [24]  564 	lcall	_journal_header_valid
      003CFE E5 82            [12]  565 	mov	a, dpl
      003D00 70 01            [24]  566 	jnz	00103$
      003D02 22               [24]  567 	ret
      003D03                        568 00103$:
                                    569 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D03 90 05 69         [24]  570 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D06 E0               [24]  571 	movx	a,@dptr
      003D07 FF               [12]  572 	mov	r7,a
      003D08 7E 00            [12]  573 	mov	r6,#0x00
      003D0A 90 05 6A         [24]  574 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D0D E0               [24]  575 	movx	a,@dptr
      003D0E FC               [12]  576 	mov	r4,a
      003D0F E4               [12]  577 	clr	a
      003D10 42 07            [12]  578 	orl	ar7,a
      003D12 EC               [12]  579 	mov	a,r4
      003D13 42 06            [12]  580 	orl	ar6,a
                                    581 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D15 90 05 6B         [24]  582 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D18 E0               [24]  583 	movx	a,@dptr
      003D19 FD               [12]  584 	mov	r5,a
      003D1A 7C 00            [12]  585 	mov	r4,#0x00
      003D1C 90 05 6C         [24]  586 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D1F E0               [24]  587 	movx	a,@dptr
      003D20 FA               [12]  588 	mov	r2,a
      003D21 E4               [12]  589 	clr	a
      003D22 12 43 2A         [24]  590 	lcall	_ak820_outline_0131
                                    591 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D25 C3               [12]  592 	clr	c
      003D26 EF               [12]  593 	mov	a,r7
      003D27 94 A0            [12]  594 	subb	a,#0xa0
      003D29 EE               [12]  595 	mov	a,r6
      003D2A 94 00            [12]  596 	subb	a,#0x00
      003D2C 40 06            [24]  597 	jc	00134$
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D2E 75 82 01         [24]  599 	mov	dpl, #0x01
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D31 02 3B 40         [24]  601 	ljmp	_nvm_fail
                                    602 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D34                        603 00134$:
      003D34 7B 00            [12]  604 	mov	r3,#0x00
      003D36                        605 00117$:
      003D36 C0 05            [24]  606 	push	ar5
      003D38 C0 04            [24]  607 	push	ar4
      003D3A EB               [12]  608 	mov	a,r3
      003D3B 24 19            [12]  609 	add	a, #_page_data
      003D3D F9               [12]  610 	mov	r1,a
      003D3E E4               [12]  611 	clr	a
      003D3F 34 05            [12]  612 	addc	a, #(_page_data >> 8)
      003D41 FA               [12]  613 	mov	r2,a
      003D42 8B 00            [24]  614 	mov	ar0,r3
      003D44 7D 00            [12]  615 	mov	r5,#0x00
      003D46 74 EF            [12]  616 	mov	a,#0xef
      003D48 2D               [12]  617 	add	a, r5
      003D49 FD               [12]  618 	mov	r5,a
      003D4A 88 82            [24]  619 	mov	dpl, r0
      003D4C 8D 83            [24]  620 	mov	dph, r5
      003D4E 12 38 AC         [24]  621 	lcall	_ak820_flash_read
      003D51 AD 82            [24]  622 	mov	r5, dpl
      003D53 12 43 4B         [24]  623 	lcall	_ak820_outline_0170
      003D56 ED               [12]  624 	mov	a,r5
      003D57 F0               [24]  625 	movx	@dptr,a
      003D58 0B               [12]  626 	inc	r3
      003D59 BB 40 02         [24]  627 	cjne	r3,#0x40,00190$
      003D5C 80 06            [24]  628 	sjmp	00191$
      003D5E                        629 00190$:
      003D5E D0 04            [24]  630 	pop	ar4
      003D60 D0 05            [24]  631 	pop	ar5
      003D62 80 D2            [24]  632 	sjmp	00117$
      003D64                        633 00191$:
      003D64 D0 04            [24]  634 	pop	ar4
      003D66 D0 05            [24]  635 	pop	ar5
                                    636 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003D68 C0 07            [24]  637 	push	ar7
      003D6A C0 06            [24]  638 	push	ar6
      003D6C C0 05            [24]  639 	push	ar5
      003D6E C0 04            [24]  640 	push	ar4
      003D70 12 3B EE         [24]  641 	lcall	_page_crc
      003D73 AA 82            [24]  642 	mov	r2, dpl
      003D75 AB 83            [24]  643 	mov	r3, dph
      003D77 D0 04            [24]  644 	pop	ar4
      003D79 D0 05            [24]  645 	pop	ar5
      003D7B D0 06            [24]  646 	pop	ar6
      003D7D D0 07            [24]  647 	pop	ar7
      003D7F EA               [12]  648 	mov	a,r2
      003D80 B5 05 06         [24]  649 	cjne	a,ar5,00192$
      003D83 EB               [12]  650 	mov	a,r3
      003D84 B5 04 02         [24]  651 	cjne	a,ar4,00192$
      003D87 80 06            [24]  652 	sjmp	00113$
      003D89                        653 00192$:
      003D89 75 82 02         [24]  654 	mov	dpl, #0x02
      003D8C 02 3B 40         [24]  655 	ljmp	_nvm_fail
      003D8F                        656 00113$:
                                    657 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003D8F EE               [12]  658 	mov	a,r6
      003D90 54 03            [12]  659 	anl	a,#0x03
      003D92 A2 E0            [12]  660 	mov	c,acc.0
      003D94 CF               [12]  661 	xch	a,r7
      003D95 13               [12]  662 	rrc	a
      003D96 CF               [12]  663 	xch	a,r7
      003D97 13               [12]  664 	rrc	a
      003D98 A2 E0            [12]  665 	mov	c,acc.0
      003D9A CF               [12]  666 	xch	a,r7
      003D9B 13               [12]  667 	rrc	a
      003D9C CF               [12]  668 	xch	a,r7
      003D9D 13               [12]  669 	rrc	a
      003D9E CF               [12]  670 	xch	a,r7
      003D9F 24 C7            [12]  671 	add	a,#0xc7
      003DA1 FE               [12]  672 	mov	r6,a
      003DA2 12 43 3A         [24]  673 	lcall	_ak820_outline_0145
      003DA5 12 3C 21         [24]  674 	lcall	_write_page
      003DA8 E5 82            [12]  675 	mov	a, dpl
      003DAA 70 06            [24]  676 	jnz	00110$
      003DAC 75 82 03         [24]  677 	mov	dpl, #0x03
      003DAF 02 3B 40         [24]  678 	ljmp	_nvm_fail
      003DB2                        679 00110$:
                                    680 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DB2 90 EF 40         [24]  681 	mov	dptr,#0xef40
      003DB5 12 39 B9         [24]  682 	lcall	_ak820_flash_erase
      003DB8 E5 82            [12]  683 	mov	a, dpl
      003DBA 70 06            [24]  684 	jnz	00119$
      003DBC 75 82 04         [24]  685 	mov	dpl, #0x04
                                    686 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003DBF 02 3B 40         [24]  687 	ljmp	_nvm_fail
      003DC2                        688 00119$:
      003DC2 22               [24]  689 	ret
                                    690 ;------------------------------------------------------------
                                    691 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    692 ;------------------------------------------------------------
                                    693 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    694 ;	-----------------------------------------
                                    695 ;	 function eeprom_driver_init
                                    696 ;	-----------------------------------------
      003DC3                        697 _eeprom_driver_init:
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    699 ;	assignBit
      003DC3 C2 09            [12]  700 	clr	_storage_failed
                                    701 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003DC5 90 05 5B         [24]  702 	mov	dptr,#_first_failure_stage
      003DC8 E4               [12]  703 	clr	a
      003DC9 F0               [24]  704 	movx	@dptr,a
                                    705 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    706 ;	assignBit
      003DCA C2 08            [12]  707 	clr	_page_dirty
                                    708 ;	assignBit
      003DCC C2 07            [12]  709 	clr	_page_valid
                                    710 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003DCE 90 05 5A         [24]  711 	mov	dptr,#_batch_depth
      003DD1 E4               [12]  712 	clr	a
      003DD2 F0               [24]  713 	movx	@dptr,a
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003DD3 12 3C D1         [24]  715 	lcall	_recover_journal
                                    716 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    717 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003DD6 02 2A B7         [24]  718 	ljmp	_ak820_macro_init
                                    719 ;------------------------------------------------------------
                                    720 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    721 ;------------------------------------------------------------
                                    722 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    723 ;	-----------------------------------------
                                    724 ;	 function ak820_nvm_ok
                                    725 ;	-----------------------------------------
      003DD9                        726 _ak820_nvm_ok:
      003DD9 A2 09            [12]  727 	mov	c,_storage_failed
      003DDB B3               [12]  728 	cpl	c
      003DDC 92 0A            [24]  729 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003DDE 12 38 79         [24]  730 	lcall	_ak820_outline_0158
      003DE1 22               [24]  731 	ret
                                    732 ;------------------------------------------------------------
                                    733 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    734 ;------------------------------------------------------------
                                    735 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    736 ;	-----------------------------------------
                                    737 ;	 function ak820_nvm_schema_fault
                                    738 ;	-----------------------------------------
      003DE2                        739 _ak820_nvm_schema_fault:
      003DE2 75 82 10         [24]  740 	mov	dpl, #0x10
      003DE5 02 3B 40         [24]  741 	ljmp	_nvm_fail
                                    742 ;------------------------------------------------------------
                                    743 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    744 ;------------------------------------------------------------
                                    745 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    746 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    747 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    748 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    749 ;------------------------------------------------------------
                                    750 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    751 ;	-----------------------------------------
                                    752 ;	 function ak820_nvm_flush
                                    753 ;	-----------------------------------------
      003DE8                        754 _ak820_nvm_flush:
                                    755 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003DE8 30 08 03         [24]  756 	jnb	_page_dirty,00101$
      003DEB 30 09 01         [24]  757 	jnb	_storage_failed,00102$
      003DEE                        758 00101$:
      003DEE 22               [24]  759 	ret
      003DEF                        760 00102$:
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003DEF 12 3B EE         [24]  762 	lcall	_page_crc
      003DF2 12 43 1F         [24]  763 	lcall	_ak820_outline_0123
                                    764 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003DF5 90 05 71         [24]  765 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003DF8 74 A5            [12]  766 	mov	a,#0xa5
      003DFA F0               [24]  767 	movx	@dptr,a
                                    768 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003DFB 90 05 59         [24]  769 	mov	dptr,#_cached_page
      003DFE E0               [24]  770 	movx	a,@dptr
      003DFF 90 05 72         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E02 F0               [24]  772 	movx	@dptr,a
                                    773 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E03 90 05 73         [24]  774 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E06 E4               [12]  775 	clr	a
      003E07 F0               [24]  776 	movx	@dptr,a
                                    777 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E08 8E 05            [24]  778 	mov	ar5,r6
      003E0A 90 05 74         [24]  779 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E0D ED               [12]  780 	mov	a,r5
      003E0E F0               [24]  781 	movx	@dptr,a
                                    782 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E0F 8F 06            [24]  783 	mov	ar6,r7
      003E11 90 05 75         [24]  784 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E14 EE               [12]  785 	mov	a,r6
      003E15 F0               [24]  786 	movx	@dptr,a
                                    787 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E16 7F 01            [12]  788 	mov	r7,#0x01
      003E18                        789 00128$:
      003E18 8F 06            [24]  790 	mov	ar6,r7
      003E1A EE               [12]  791 	mov	a,r6
      003E1B 24 04            [12]  792 	add	a,#0x04
      003E1D FE               [12]  793 	mov	r6,a
      003E1E 33               [12]  794 	rlc	a
      003E1F 95 E0            [12]  795 	subb	a,acc
      003E21 FD               [12]  796 	mov	r5,a
      003E22 EE               [12]  797 	mov	a,r6
      003E23 24 71            [12]  798 	add	a, #_ak820_nvm_flush_header_10000_62
      003E25 FE               [12]  799 	mov	r6,a
      003E26 ED               [12]  800 	mov	a,r5
      003E27 34 05            [12]  801 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E29 FD               [12]  802 	mov	r5,a
      003E2A 12 42 D9         [24]  803 	lcall	_ak820_outline_0037
      003E2D FC               [12]  804 	mov	r4,a
      003E2E 63 04 FF         [24]  805 	xrl	ar4,#0xff
      003E31 8E 82            [24]  806 	mov	dpl,r6
      003E33 8D 83            [24]  807 	mov	dph,r5
      003E35 EC               [12]  808 	mov	a,r4
      003E36 F0               [24]  809 	movx	@dptr,a
      003E37 0F               [12]  810 	inc	r7
      003E38 BF 05 DD         [24]  811 	cjne	r7,#0x05,00128$
                                    812 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E3B 90 05 7A         [24]  813 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E3E 74 05            [12]  814 	mov	a,#0x05
      003E40 F0               [24]  815 	movx	@dptr,a
                                    816 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E41 90 EF 40         [24]  817 	mov	dptr,#0xef40
      003E44 12 39 B9         [24]  818 	lcall	_ak820_flash_erase
      003E47 E5 82            [12]  819 	mov	a, dpl
      003E49 70 03            [24]  820 	jnz	00269$
      003E4B 02 3F 32         [24]  821 	ljmp	00127$
      003E4E                        822 00269$:
                                    823 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E4E 90 05 7A         [24]  824 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E51 74 06            [12]  825 	mov	a,#0x06
      003E53 F0               [24]  826 	movx	@dptr,a
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E54 7F 00            [12]  828 	mov	r7,#0x00
      003E56                        829 00130$:
                                    830 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E56 12 42 E5         [24]  831 	lcall	_ak820_outline_0048
      003E59 12 38 AC         [24]  832 	lcall	_ak820_flash_read
      003E5C E5 82            [12]  833 	mov	a, dpl
      003E5E 60 03            [24]  834 	jz	00270$
      003E60 02 3F 32         [24]  835 	ljmp	00127$
      003E63                        836 00270$:
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E63 0F               [12]  838 	inc	r7
      003E64 BF 40 EF         [24]  839 	cjne	r7,#0x40,00130$
                                    840 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003E67 90 05 7A         [24]  841 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E6A 74 07            [12]  842 	mov	a,#0x07
      003E6C F0               [24]  843 	movx	@dptr,a
                                    844 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003E6D 90 EF 00         [24]  845 	mov	dptr,#0xef00
      003E70 12 3C 21         [24]  846 	lcall	_write_page
      003E73 E5 82            [12]  847 	mov	a, dpl
      003E75 70 03            [24]  848 	jnz	00273$
      003E77 02 3F 32         [24]  849 	ljmp	00127$
      003E7A                        850 00273$:
                                    851 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003E7A 90 05 7A         [24]  852 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E7D 74 08            [12]  853 	mov	a,#0x08
      003E7F F0               [24]  854 	movx	@dptr,a
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003E80 7F 01            [12]  856 	mov	r7,#0x01
      003E82                        857 00132$:
                                    858 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003E82 12 42 D9         [24]  859 	lcall	_ak820_outline_0037
      003E85 FE               [12]  860 	mov	r6,a
      003E86 60 23            [24]  861 	jz	00133$
      003E88 8F 05            [24]  862 	mov	ar5,r7
      003E8A 7C 00            [12]  863 	mov	r4,#0x00
      003E8C 74 40            [12]  864 	mov	a,#0x40
      003E8E 2D               [12]  865 	add	a, r5
      003E8F FD               [12]  866 	mov	r5,a
      003E90 74 EF            [12]  867 	mov	a,#0xef
      003E92 3C               [12]  868 	addc	a, r4
      003E93 FC               [12]  869 	mov	r4,a
      003E94 90 04 F2         [24]  870 	mov	dptr,#_ak820_flash_program_PARM_2
      003E97 EE               [12]  871 	mov	a,r6
      003E98 F0               [24]  872 	movx	@dptr,a
      003E99 8D 82            [24]  873 	mov	dpl, r5
      003E9B 8C 83            [24]  874 	mov	dph, r4
      003E9D C0 07            [24]  875 	push	ar7
      003E9F 12 3A 19         [24]  876 	lcall	_ak820_flash_program
      003EA2 E5 82            [12]  877 	mov	a, dpl
      003EA4 D0 07            [24]  878 	pop	ar7
      003EA6 70 03            [24]  879 	jnz	00275$
      003EA8 02 3F 32         [24]  880 	ljmp	00127$
      003EAB                        881 00275$:
      003EAB                        882 00133$:
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EAB 0F               [12]  884 	inc	r7
      003EAC BF 09 D3         [24]  885 	cjne	r7,#0x09,00132$
                                    886 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EAF 90 05 7A         [24]  887 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EB2 74 09            [12]  888 	mov	a,#0x09
      003EB4 F0               [24]  889 	movx	@dptr,a
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EB5 7F 01            [12]  891 	mov	r7,#0x01
      003EB7                        892 00134$:
                                    893 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EB7 12 42 E5         [24]  894 	lcall	_ak820_outline_0048
      003EBA 12 38 AC         [24]  895 	lcall	_ak820_flash_read
      003EBD AE 82            [24]  896 	mov	r6, dpl
      003EBF 12 42 D9         [24]  897 	lcall	_ak820_outline_0037
      003EC2 FD               [12]  898 	mov	r5,a
      003EC3 EE               [12]  899 	mov	a,r6
      003EC4 B5 05 6B         [24]  900 	cjne	a,ar5,00127$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EC7 0F               [12]  902 	inc	r7
      003EC8 BF 09 EC         [24]  903 	cjne	r7,#0x09,00134$
                                    904 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003ECB 90 05 7A         [24]  905 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003ECE 74 0A            [12]  906 	mov	a,#0x0a
      003ED0 F0               [24]  907 	movx	@dptr,a
                                    908 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003ED1 90 05 71         [24]  909 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003ED4 E0               [24]  910 	movx	a,@dptr
      003ED5 90 04 F2         [24]  911 	mov	dptr,#_ak820_flash_program_PARM_2
      003ED8 F0               [24]  912 	movx	@dptr,a
      003ED9 90 EF 40         [24]  913 	mov	dptr,#0xef40
      003EDC 12 3A 19         [24]  914 	lcall	_ak820_flash_program
      003EDF E5 82            [12]  915 	mov	a, dpl
      003EE1 60 4F            [24]  916 	jz	00127$
                                    917 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003EE3 90 05 7A         [24]  918 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EE6 74 0B            [12]  919 	mov	a,#0x0b
      003EE8 F0               [24]  920 	movx	@dptr,a
                                    921 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003EE9 90 EF 40         [24]  922 	mov	dptr,#0xef40
      003EEC 12 38 AC         [24]  923 	lcall	_ak820_flash_read
      003EEF AF 82            [24]  924 	mov	r7, dpl
      003EF1 90 05 71         [24]  925 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EF4 E0               [24]  926 	movx	a,@dptr
      003EF5 FE               [12]  927 	mov	r6,a
      003EF6 EF               [12]  928 	mov	a,r7
      003EF7 B5 06 38         [24]  929 	cjne	a,ar6,00127$
                                    930 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003EFA 90 05 7A         [24]  931 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EFD 74 0C            [12]  932 	mov	a,#0x0c
      003EFF F0               [24]  933 	movx	@dptr,a
                                    934 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F00 90 05 59         [24]  935 	mov	dptr,#_cached_page
      003F03 E0               [24]  936 	movx	a,@dptr
      003F04 FE               [12]  937 	mov	r6,a
      003F05 E4               [12]  938 	clr	a
      003F06 C3               [12]  939 	clr	c
      003F07 CE               [12]  940 	xch	a,r6
      003F08 13               [12]  941 	rrc	a
      003F09 CE               [12]  942 	xch	a,r6
      003F0A 13               [12]  943 	rrc	a
      003F0B A2 E0            [12]  944 	mov	c,acc.0
      003F0D CE               [12]  945 	xch	a,r6
      003F0E 13               [12]  946 	rrc	a
      003F0F CE               [12]  947 	xch	a,r6
      003F10 13               [12]  948 	rrc	a
      003F11 CE               [12]  949 	xch	a,r6
      003F12 24 C7            [12]  950 	add	a,#0xc7
      003F14 FF               [12]  951 	mov	r7,a
      003F15 12 43 1A         [24]  952 	lcall	_ak820_outline_0109
      003F18 12 3C 21         [24]  953 	lcall	_write_page
      003F1B E5 82            [12]  954 	mov	a, dpl
      003F1D 60 13            [24]  955 	jz	00127$
                                    956 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F1F 90 05 7A         [24]  957 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F22 74 0D            [12]  958 	mov	a,#0x0d
      003F24 F0               [24]  959 	movx	@dptr,a
                                    960 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F25 90 EF 40         [24]  961 	mov	dptr,#0xef40
      003F28 12 39 B9         [24]  962 	lcall	_ak820_flash_erase
      003F2B E5 82            [12]  963 	mov	a, dpl
      003F2D 60 03            [24]  964 	jz	00127$
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    966 ;	assignBit
      003F2F C2 08            [12]  967 	clr	_page_dirty
                                    968 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F31 22               [24]  970 	ret
      003F32                        971 00127$:
                                    972 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F32 90 05 7A         [24]  973 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F35 E0               [24]  974 	movx	a,@dptr
      003F36 F5 82            [12]  975 	mov	dpl,a
                                    976 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F38 02 3B 40         [24]  977 	ljmp	_nvm_fail
                                    978 ;------------------------------------------------------------
                                    979 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    980 ;------------------------------------------------------------
                                    981 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function ak820_nvm_begin
                                    984 ;	-----------------------------------------
      003F3B                        985 _ak820_nvm_begin:
                                    986 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F3B 90 05 5A         [24]  987 	mov	dptr,#_batch_depth
      003F3E E0               [24]  988 	movx	a,@dptr
      003F3F FF               [12]  989 	mov	r7,a
      003F40 BF FF 06         [24]  990 	cjne	r7,#0xff,00102$
      003F43 75 82 0F         [24]  991 	mov	dpl, #0x0f
      003F46 02 3B 40         [24]  992 	ljmp	_nvm_fail
      003F49                        993 00102$:
                                    994 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F49 90 05 5A         [24]  995 	mov	dptr,#_batch_depth
      003F4C EF               [12]  996 	mov	a,r7
      003F4D 04               [12]  997 	inc	a
      003F4E F0               [24]  998 	movx	@dptr,a
                                    999 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F4F 22               [24] 1000 	ret
                                   1001 ;------------------------------------------------------------
                                   1002 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1003 ;------------------------------------------------------------
                                   1004 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1005 ;	-----------------------------------------
                                   1006 ;	 function ak820_nvm_end
                                   1007 ;	-----------------------------------------
      003F50                       1008 _ak820_nvm_end:
                                   1009 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F50 90 05 5A         [24] 1010 	mov	dptr,#_batch_depth
      003F53 E0               [24] 1011 	movx	a,@dptr
      003F54 FF               [12] 1012 	mov	r7,a
      003F55 E0               [24] 1013 	movx	a,@dptr
      003F56 60 06            [24] 1014 	jz	00102$
      003F58 EF               [12] 1015 	mov	a,r7
      003F59 14               [12] 1016 	dec	a
      003F5A 90 05 5A         [24] 1017 	mov	dptr,#_batch_depth
      003F5D F0               [24] 1018 	movx	@dptr,a
      003F5E                       1019 00102$:
                                   1020 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003F5E 90 05 5A         [24] 1021 	mov	dptr,#_batch_depth
      003F61 E0               [24] 1022 	movx	a,@dptr
      003F62 70 03            [24] 1023 	jnz	00105$
                                   1024 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003F64 02 3D E8         [24] 1025 	ljmp	_ak820_nvm_flush
      003F67                       1026 00105$:
      003F67 22               [24] 1027 	ret
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'load_page'
                                   1030 ;------------------------------------------------------------
                                   1031 ;page          Allocated with name '_load_page_page_10000_87'
                                   1032 ;i             Allocated with name '_load_page_i_10000_88'
                                   1033 ;------------------------------------------------------------
                                   1034 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1035 ;	-----------------------------------------
                                   1036 ;	 function load_page
                                   1037 ;	-----------------------------------------
      003F68                       1038 _load_page:
      003F68 E5 82            [12] 1039 	mov	a,dpl
      003F6A 90 05 7B         [24] 1040 	mov	dptr,#_load_page_page_10000_87
      003F6D F0               [24] 1041 	movx	@dptr,a
                                   1042 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003F6E 30 07 17         [24] 1043 	jnb	_page_valid,00102$
      003F71 90 05 59         [24] 1044 	mov	dptr,#_cached_page
      003F74 E0               [24] 1045 	movx	a,@dptr
      003F75 FF               [12] 1046 	mov	r7,a
      003F76 90 05 7B         [24] 1047 	mov	dptr,#_load_page_page_10000_87
      003F79 E0               [24] 1048 	movx	a,@dptr
      003F7A FE               [12] 1049 	mov	r6,a
      003F7B EF               [12] 1050 	mov	a,r7
      003F7C B5 06 09         [24] 1051 	cjne	a,ar6,00102$
      003F7F A2 09            [12] 1052 	mov	c,_storage_failed
      003F81 B3               [12] 1053 	cpl	c
      003F82 92 0B            [24] 1054 	mov  _load_page_sloc0_1_0,c
      003F84 12 38 79         [24] 1055 	lcall	_ak820_outline_0158
      003F87 22               [24] 1056 	ret
      003F88                       1057 00102$:
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003F88 12 3D E8         [24] 1059 	lcall	_ak820_nvm_flush
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003F8B 30 09 04         [24] 1061 	jnb	_storage_failed,00119$
      003F8E 75 82 00         [24] 1062 	mov	dpl, #0x00
                                   1063 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F91 22               [24] 1064 	ret
      003F92                       1065 00119$:
      003F92 7F 00            [12] 1066 	mov	r7,#0x00
      003F94                       1067 00107$:
                                   1068 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003F94 EF               [12] 1069 	mov	a,r7
      003F95 24 19            [12] 1070 	add	a, #_page_data
      003F97 FD               [12] 1071 	mov	r5,a
      003F98 E4               [12] 1072 	clr	a
      003F99 34 05            [12] 1073 	addc	a, #(_page_data >> 8)
      003F9B FE               [12] 1074 	mov	r6,a
      003F9C 90 05 7B         [24] 1075 	mov	dptr,#_load_page_page_10000_87
      003F9F E0               [24] 1076 	movx	a,@dptr
      003FA0 FC               [12] 1077 	mov	r4,a
      003FA1 FA               [12] 1078 	mov	r2,a
      003FA2 E4               [12] 1079 	clr	a
      003FA3 C3               [12] 1080 	clr	c
      003FA4 CA               [12] 1081 	xch	a,r2
      003FA5 13               [12] 1082 	rrc	a
      003FA6 CA               [12] 1083 	xch	a,r2
      003FA7 13               [12] 1084 	rrc	a
      003FA8 A2 E0            [12] 1085 	mov	c,acc.0
      003FAA CA               [12] 1086 	xch	a,r2
      003FAB 13               [12] 1087 	rrc	a
      003FAC CA               [12] 1088 	xch	a,r2
      003FAD 13               [12] 1089 	rrc	a
      003FAE CA               [12] 1090 	xch	a,r2
      003FAF 24 C7            [12] 1091 	add	a,#0xc7
      003FB1 FB               [12] 1092 	mov	r3,a
      003FB2 8F 01            [24] 1093 	mov	ar1,r7
      003FB4 89 00            [24] 1094 	mov	ar0,r1
      003FB6 79 00            [12] 1095 	mov	r1,#0x00
      003FB8 E8               [12] 1096 	mov	a,r0
      003FB9 2A               [12] 1097 	add	a, r2
      003FBA FA               [12] 1098 	mov	r2,a
      003FBB E9               [12] 1099 	mov	a,r1
      003FBC 3B               [12] 1100 	addc	a, r3
      003FBD FB               [12] 1101 	mov	r3,a
      003FBE 12 43 30         [24] 1102 	lcall	_ak820_outline_0132
      003FC1 12 38 AC         [24] 1103 	lcall	_ak820_flash_read
      003FC4 AB 82            [24] 1104 	mov	r3, dpl
      003FC6 12 38 5D         [24] 1105 	lcall	_ak820_outline_0122
      003FC9 EB               [12] 1106 	mov	a,r3
      003FCA F0               [24] 1107 	movx	@dptr,a
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FCB 0F               [12] 1109 	inc	r7
      003FCC BF 40 C5         [24] 1110 	cjne	r7,#0x40,00107$
                                   1111 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      003FCF 90 05 59         [24] 1112 	mov	dptr,#_cached_page
      003FD2 EC               [12] 1113 	mov	a,r4
      003FD3 F0               [24] 1114 	movx	@dptr,a
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1116 ;	assignBit
      003FD4 D2 07            [12] 1117 	setb	_page_valid
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      003FD6 75 82 01         [24] 1119 	mov	dpl, #0x01
                                   1120 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      003FD9 22               [24] 1121 	ret
                                   1122 ;------------------------------------------------------------
                                   1123 ;Allocation info for local variables in function 'read_offset'
                                   1124 ;------------------------------------------------------------
                                   1125 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1126 ;------------------------------------------------------------
                                   1127 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1128 ;	-----------------------------------------
                                   1129 ;	 function read_offset
                                   1130 ;	-----------------------------------------
      003FDA                       1131 _read_offset:
      003FDA 12 38 3C         [24] 1132 	lcall	_ak820_outline_0098
      003FDD 90 05 7C         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      003FE0 12 38 41         [24] 1134 	lcall	_ak820_outline_0099
                                   1135 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      003FE3 90 05 7C         [24] 1136 	mov	dptr,#_read_offset_offset_10000_93
      003FE6 12 37 F9         [24] 1137 	lcall	_ak820_outline_0047
      003FE9 C3               [12] 1138 	clr	c
      003FEA 94 28            [12] 1139 	subb	a,#0x28
      003FEC 40 04            [24] 1140 	jc	00102$
      003FEE 75 82 00         [24] 1141 	mov	dpl, #0x00
      003FF1 22               [24] 1142 	ret
      003FF2                       1143 00102$:
                                   1144 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      003FF2 30 07 34         [24] 1145 	jnb	_page_valid,00104$
      003FF5 8E 04            [24] 1146 	mov	ar4,r6
      003FF7 EF               [12] 1147 	mov	a,r7
      003FF8 A2 E7            [12] 1148 	mov	c,acc.7
      003FFA CC               [12] 1149 	xch	a,r4
      003FFB 33               [12] 1150 	rlc	a
      003FFC CC               [12] 1151 	xch	a,r4
      003FFD 33               [12] 1152 	rlc	a
      003FFE A2 E7            [12] 1153 	mov	c,acc.7
      004000 CC               [12] 1154 	xch	a,r4
      004001 33               [12] 1155 	rlc	a
      004002 CC               [12] 1156 	xch	a,r4
      004003 33               [12] 1157 	rlc	a
      004004 CC               [12] 1158 	xch	a,r4
      004005 54 03            [12] 1159 	anl	a,#0x03
      004007 FD               [12] 1160 	mov	r5,a
      004008 90 05 59         [24] 1161 	mov	dptr,#_cached_page
      00400B E0               [24] 1162 	movx	a,@dptr
      00400C FA               [12] 1163 	mov	r2,a
      00400D 7B 00            [12] 1164 	mov	r3,#0x00
      00400F EC               [12] 1165 	mov	a,r4
      004010 B5 02 16         [24] 1166 	cjne	a,ar2,00104$
      004013 ED               [12] 1167 	mov	a,r5
      004014 B5 03 12         [24] 1168 	cjne	a,ar3,00104$
                                   1169 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004017 74 3F            [12] 1170 	mov	a,#0x3f
      004019 5E               [12] 1171 	anl	a,r6
      00401A 7D 00            [12] 1172 	mov	r5,#0x00
      00401C 24 19            [12] 1173 	add	a, #_page_data
      00401E F5 82            [12] 1174 	mov	dpl,a
      004020 ED               [12] 1175 	mov	a,r5
      004021 34 05            [12] 1176 	addc	a, #(_page_data >> 8)
      004023 F5 83            [12] 1177 	mov	dph,a
      004025 E0               [24] 1178 	movx	a,@dptr
      004026 F5 82            [12] 1179 	mov	dpl,a
      004028 22               [24] 1180 	ret
      004029                       1181 00104$:
                                   1182 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004029 74 C7            [12] 1183 	mov	a,#0xc7
      00402B 2F               [12] 1184 	add	a, r7
      00402C FF               [12] 1185 	mov	r7,a
      00402D 12 43 1A         [24] 1186 	lcall	_ak820_outline_0109
                                   1187 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      004030 02 38 AC         [24] 1188 	ljmp	_ak820_flash_read
                                   1189 ;------------------------------------------------------------
                                   1190 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1191 ;------------------------------------------------------------
                                   1192 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1193 ;------------------------------------------------------------
                                   1194 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1195 ;	-----------------------------------------
                                   1196 ;	 function eeprom_read_byte
                                   1197 ;	-----------------------------------------
      004033                       1198 _eeprom_read_byte:
      004033 C0 07            [24] 1199 	push	ar7
      004035 C0 06            [24] 1200 	push	ar6
      004037 12 42 D2         [24] 1201 	lcall	_ak820_outline_0034
      00403A 90 05 7E         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00403D 12 37 E1         [24] 1203 	lcall	_ak820_outline_0015
                                   1204 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      004040 90 05 7E         [24] 1205 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004043 12 37 A2         [24] 1206 	lcall	_ak820_outline_0004
      004046 C0 06            [24] 1207 	push	ar6
      004048 C0 05            [24] 1208 	push	ar5
      00404A C0 04            [24] 1209 	push	ar4
      00404C C0 03            [24] 1210 	push	ar3
      00404E C0 02            [24] 1211 	push	ar2
      004050 C0 01            [24] 1212 	push	ar1
      004052 C0 00            [24] 1213 	push	ar0
      004054 12 3F DA         [24] 1214 	lcall	_read_offset
      004057 AF 82            [24] 1215 	mov	r7, dpl
      004059 D0 00            [24] 1216 	pop	ar0
      00405B D0 01            [24] 1217 	pop	ar1
      00405D D0 02            [24] 1218 	pop	ar2
      00405F D0 03            [24] 1219 	pop	ar3
      004061 D0 04            [24] 1220 	pop	ar4
      004063 D0 05            [24] 1221 	pop	ar5
      004065 D0 06            [24] 1222 	pop	ar6
      004067 8F 82            [24] 1223 	mov	dpl, r7
                                   1224 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004069 D0 06            [24] 1225 	pop	ar6
      00406B D0 07            [24] 1226 	pop	ar7
      00406D 22               [24] 1227 	ret
                                   1228 ;------------------------------------------------------------
                                   1229 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1230 ;------------------------------------------------------------
                                   1231 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1232 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1233 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1234 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1235 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1236 ;------------------------------------------------------------
                                   1237 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1238 ;	-----------------------------------------
                                   1239 ;	 function ak820_eeprom_read_block_xdata
                                   1240 ;	-----------------------------------------
      00406E                       1241 _ak820_eeprom_read_block_xdata:
      00406E 12 38 3C         [24] 1242 	lcall	_ak820_outline_0098
      004071 90 05 86         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004074 12 38 41         [24] 1244 	lcall	_ak820_outline_0099
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004077 90 05 81         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00407A 12 37 F9         [24] 1247 	lcall	_ak820_outline_0047
                                   1248 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      00407D 90 05 86         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004080 12 38 18         [24] 1250 	lcall	_ak820_outline_0056
      004083 90 05 88         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004086 12 38 24         [24] 1252 	lcall	_ak820_outline_0070
                                   1253 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004089 90 05 84         [24] 1254 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00408C 12 38 18         [24] 1255 	lcall	_ak820_outline_0056
      00408F                       1256 00103$:
      00408F 8C 02            [24] 1257 	mov	ar2,r4
      004091 8D 03            [24] 1258 	mov	ar3,r5
      004093 1C               [12] 1259 	dec	r4
      004094 BC FF 01         [24] 1260 	cjne	r4,#0xff,00130$
      004097 1D               [12] 1261 	dec	r5
      004098                       1262 00130$:
      004098 EA               [12] 1263 	mov	a,r2
      004099 4B               [12] 1264 	orl	a,r3
      00409A 60 5D            [24] 1265 	jz	00106$
                                   1266 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00409C 8E 02            [24] 1267 	mov	ar2,r6
      00409E 8F 03            [24] 1268 	mov	ar3,r7
      0040A0 74 D8            [12] 1269 	mov	a,#0x100 - 0x28
      0040A2 2B               [12] 1270 	add	a,r3
      0040A3 50 17            [24] 1271 	jnc	00102$
      0040A5 90 05 88         [24] 1272 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040A8 12 43 02         [24] 1273 	lcall	_ak820_outline_0093
      0040AB 12 43 30         [24] 1274 	lcall	_ak820_outline_0132
      0040AE E4               [12] 1275 	clr	a
      0040AF F0               [24] 1276 	movx	@dptr,a
      0040B0 90 05 88         [24] 1277 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040B3 04               [12] 1278 	inc	a
      0040B4 2A               [12] 1279 	add	a, r2
      0040B5 F0               [24] 1280 	movx	@dptr,a
      0040B6 E4               [12] 1281 	clr	a
      0040B7 3B               [12] 1282 	addc	a, r3
      0040B8 A3               [24] 1283 	inc	dptr
      0040B9 F0               [24] 1284 	movx	@dptr,a
      0040BA 80 D3            [24] 1285 	sjmp	00103$
      0040BC                       1286 00102$:
                                   1287 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040BC 90 05 88         [24] 1288 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040BF 12 43 02         [24] 1289 	lcall	_ak820_outline_0093
      0040C2 12 43 1A         [24] 1290 	lcall	_ak820_outline_0109
      0040C5 C0 07            [24] 1291 	push	ar7
      0040C7 C0 06            [24] 1292 	push	ar6
      0040C9 C0 05            [24] 1293 	push	ar5
      0040CB C0 04            [24] 1294 	push	ar4
      0040CD C0 03            [24] 1295 	push	ar3
      0040CF C0 02            [24] 1296 	push	ar2
      0040D1 12 3F DA         [24] 1297 	lcall	_read_offset
      0040D4 A9 82            [24] 1298 	mov	r1, dpl
      0040D6 D0 02            [24] 1299 	pop	ar2
      0040D8 D0 03            [24] 1300 	pop	ar3
      0040DA D0 04            [24] 1301 	pop	ar4
      0040DC D0 05            [24] 1302 	pop	ar5
      0040DE D0 06            [24] 1303 	pop	ar6
      0040E0 D0 07            [24] 1304 	pop	ar7
      0040E2 12 43 30         [24] 1305 	lcall	_ak820_outline_0132
      0040E5 E9               [12] 1306 	mov	a,r1
      0040E6 F0               [24] 1307 	movx	@dptr,a
      0040E7 90 05 88         [24] 1308 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040EA 74 01            [12] 1309 	mov	a,#0x01
      0040EC 2A               [12] 1310 	add	a, r2
      0040ED F0               [24] 1311 	movx	@dptr,a
      0040EE E4               [12] 1312 	clr	a
      0040EF 3B               [12] 1313 	addc	a, r3
      0040F0 A3               [24] 1314 	inc	dptr
      0040F1 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0040F2 0E               [12] 1317 	inc	r6
      0040F3 BE 00 99         [24] 1318 	cjne	r6,#0x00,00103$
      0040F6 0F               [12] 1319 	inc	r7
      0040F7 80 96            [24] 1320 	sjmp	00103$
      0040F9                       1321 00106$:
                                   1322 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0040F9 22               [24] 1323 	ret
                                   1324 ;------------------------------------------------------------
                                   1325 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1326 ;------------------------------------------------------------
                                   1327 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1328 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1329 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1330 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1331 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1332 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1333 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1334 ;------------------------------------------------------------
                                   1335 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1336 ;	-----------------------------------------
                                   1337 ;	 function ak820_eeprom_write_block_xdata
                                   1338 ;	-----------------------------------------
      0040FA                       1339 _ak820_eeprom_write_block_xdata:
      0040FA 12 38 3C         [24] 1340 	lcall	_ak820_outline_0098
      0040FD 90 05 8F         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004100 12 38 41         [24] 1342 	lcall	_ak820_outline_0099
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004103 90 05 8A         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004106 12 37 F9         [24] 1345 	lcall	_ak820_outline_0047
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004109 90 05 8F         [24] 1347 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00410C 12 38 18         [24] 1348 	lcall	_ak820_outline_0056
                                   1349 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00410F 8E 02            [24] 1350 	mov	ar2,r6
      004111 8F 03            [24] 1351 	mov	ar3,r7
      004113 C3               [12] 1352 	clr	c
      004114 E4               [12] 1353 	clr	a
      004115 9A               [12] 1354 	subb	a,r2
      004116 74 28            [12] 1355 	mov	a,#0x28
      004118 9B               [12] 1356 	subb	a,r3
      004119 40 15            [24] 1357 	jc	00101$
                                   1358 ;	free result
      00411B E4               [12] 1359 	clr	a
      00411C C3               [12] 1360 	clr	c
      00411D 9E               [12] 1361 	subb	a,r6
      00411E FA               [12] 1362 	mov	r2,a
      00411F 74 28            [12] 1363 	mov	a,#0x28
      004121 9F               [12] 1364 	subb	a,r7
      004122 FB               [12] 1365 	mov	r3,a
      004123 90 05 8D         [24] 1366 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004126 12 38 36         [24] 1367 	lcall	_ak820_outline_0092
      004129 C3               [12] 1368 	clr	c
      00412A EA               [12] 1369 	mov	a,r2
      00412B 98               [12] 1370 	subb	a,r0
      00412C EB               [12] 1371 	mov	a,r3
      00412D 99               [12] 1372 	subb	a,r1
      00412E 50 06            [24] 1373 	jnc	00125$
                                   1374 ;	free result
      004130                       1375 00101$:
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004130 75 82 0E         [24] 1377 	mov	dpl, #0x0e
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      004133 02 3B 40         [24] 1379 	ljmp	_nvm_fail
                                   1380 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004136                       1381 00125$:
      004136 90 05 8D         [24] 1382 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004139 12 43 02         [24] 1383 	lcall	_ak820_outline_0093
      00413C                       1384 00108$:
      00413C 8A 00            [24] 1385 	mov	ar0,r2
      00413E 8B 01            [24] 1386 	mov	ar1,r3
      004140 1A               [12] 1387 	dec	r2
      004141 BA FF 01         [24] 1388 	cjne	r2,#0xff,00159$
      004144 1B               [12] 1389 	dec	r3
      004145                       1390 00159$:
      004145 E8               [12] 1391 	mov	a,r0
      004146 49               [12] 1392 	orl	a,r1
      004147 70 03            [24] 1393 	jnz	00160$
      004149 02 41 D3         [24] 1394 	ljmp	00110$
      00414C                       1395 00160$:
                                   1396 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      00414C C0 02            [24] 1397 	push	ar2
      00414E C0 03            [24] 1398 	push	ar3
      004150 12 42 FC         [24] 1399 	lcall	_ak820_outline_0083
      004153 F9               [12] 1400 	mov	r1,a
      004154 A3               [24] 1401 	inc	dptr
      004155 12 43 35         [24] 1402 	lcall	_ak820_outline_0137
                                   1403 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004158 8E 0C            [24] 1404 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      00415A 8F 0D            [24] 1405 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00415C A8 0C            [24] 1406 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00415E E5 0D            [12] 1407 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004160 A2 E7            [12] 1408 	mov	c,acc.7
      004162 C8               [12] 1409 	xch	a,r0
      004163 33               [12] 1410 	rlc	a
      004164 C8               [12] 1411 	xch	a,r0
      004165 33               [12] 1412 	rlc	a
      004166 A2 E7            [12] 1413 	mov	c,acc.7
      004168 C8               [12] 1414 	xch	a,r0
      004169 33               [12] 1415 	rlc	a
      00416A C8               [12] 1416 	xch	a,r0
      00416B 33               [12] 1417 	rlc	a
      00416C C8               [12] 1418 	xch	a,r0
      00416D 54 03            [12] 1419 	anl	a,#0x03
      00416F FB               [12] 1420 	mov	r3,a
      004170 88 82            [24] 1421 	mov	dpl, r0
      004172 C0 07            [24] 1422 	push	ar7
      004174 C0 06            [24] 1423 	push	ar6
      004176 C0 05            [24] 1424 	push	ar5
      004178 C0 04            [24] 1425 	push	ar4
      00417A C0 03            [24] 1426 	push	ar3
      00417C C0 02            [24] 1427 	push	ar2
      00417E C0 01            [24] 1428 	push	ar1
      004180 12 3F 68         [24] 1429 	lcall	_load_page
      004183 E5 82            [12] 1430 	mov	a, dpl
      004185 D0 01            [24] 1431 	pop	ar1
      004187 D0 02            [24] 1432 	pop	ar2
      004189 D0 03            [24] 1433 	pop	ar3
      00418B D0 04            [24] 1434 	pop	ar4
      00418D D0 05            [24] 1435 	pop	ar5
      00418F D0 06            [24] 1436 	pop	ar6
      004191 D0 07            [24] 1437 	pop	ar7
      004193 D0 03            [24] 1438 	pop	ar3
      004195 D0 02            [24] 1439 	pop	ar2
      004197 70 01            [24] 1440 	jnz	00105$
      004199 22               [24] 1441 	ret
      00419A                       1442 00105$:
                                   1443 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      00419A C0 06            [24] 1444 	push	ar6
      00419C C0 07            [24] 1445 	push	ar7
      00419E 74 3F            [12] 1446 	mov	a,#0x3f
      0041A0 55 0C            [12] 1447 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041A2 7F 00            [12] 1448 	mov	r7,#0x00
      0041A4 24 19            [12] 1449 	add	a, #_page_data
      0041A6 F5 0C            [12] 1450 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041A8 EF               [12] 1451 	mov	a,r7
      0041A9 34 05            [12] 1452 	addc	a, #(_page_data >> 8)
      0041AB F5 0D            [12] 1453 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041AD 85 0C 82         [24] 1454 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041B0 85 0D 83         [24] 1455 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041B3 E0               [24] 1456 	movx	a,@dptr
      0041B4 B5 01 06         [24] 1457 	cjne	a,ar1,00162$
      0041B7 D0 07            [24] 1458 	pop	ar7
      0041B9 D0 06            [24] 1459 	pop	ar6
      0041BB 80 0E            [24] 1460 	sjmp	00107$
      0041BD                       1461 00162$:
      0041BD D0 07            [24] 1462 	pop	ar7
      0041BF D0 06            [24] 1463 	pop	ar6
                                   1464 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      0041C1 85 0C 82         [24] 1465 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041C4 85 0D 83         [24] 1466 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041C7 E9               [12] 1467 	mov	a,r1
      0041C8 F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1470 ;	assignBit
      0041C9 D2 08            [12] 1471 	setb	_page_dirty
      0041CB                       1472 00107$:
                                   1473 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      0041CB 0E               [12] 1474 	inc	r6
      0041CC BE 00 01         [24] 1475 	cjne	r6,#0x00,00163$
      0041CF 0F               [12] 1476 	inc	r7
      0041D0                       1477 00163$:
      0041D0 02 41 3C         [24] 1478 	ljmp	00108$
      0041D3                       1479 00110$:
                                   1480 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      0041D3 90 05 5A         [24] 1481 	mov	dptr,#_batch_depth
      0041D6 E0               [24] 1482 	movx	a,@dptr
      0041D7 70 03            [24] 1483 	jnz	00113$
                                   1484 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      0041D9 02 3D E8         [24] 1485 	ljmp	_ak820_nvm_flush
      0041DC                       1486 00113$:
      0041DC 22               [24] 1487 	ret
                                   1488 ;------------------------------------------------------------
                                   1489 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1490 ;------------------------------------------------------------
                                   1491 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1492 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1493 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1494 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1495 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1496 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1497 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1498 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1499 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1500 ;------------------------------------------------------------
                                   1501 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1502 ;	-----------------------------------------
                                   1503 ;	 function ak820_eeprom_update_block_xdata
                                   1504 ;	-----------------------------------------
      0041DD                       1505 _ak820_eeprom_update_block_xdata:
      0041DD 12 38 3C         [24] 1506 	lcall	_ak820_outline_0098
      0041E0 90 05 96         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041E3 12 38 41         [24] 1508 	lcall	_ak820_outline_0099
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0041E6 90 05 96         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041E9 12 37 F9         [24] 1511 	lcall	_ak820_outline_0047
                                   1512 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0041EC 90 05 91         [24] 1513 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0041EF E0               [24] 1514 	movx	a,@dptr
      0041F0 F5 12            [12] 1515 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0041F2 A3               [24] 1516 	inc	dptr
      0041F3 E0               [24] 1517 	movx	a,@dptr
      0041F4 F5 13            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0041F6 A3               [24] 1519 	inc	dptr
      0041F7 E0               [24] 1520 	movx	a,@dptr
      0041F8 F5 14            [12] 1521 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0041FA A9 12            [24] 1522 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0041FC AA 13            [24] 1523 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1524 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0041FE E4               [12] 1525 	clr	a
      0041FF F5 0E            [12] 1526 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004201 F5 0F            [12] 1527 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004203                       1528 00105$:
      004203 90 05 94         [24] 1529 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004206 E0               [24] 1530 	movx	a,@dptr
      004207 F5 10            [12] 1531 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004209 A3               [24] 1532 	inc	dptr
      00420A E0               [24] 1533 	movx	a,@dptr
      00420B F5 11            [12] 1534 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      00420D C3               [12] 1535 	clr	c
      00420E E5 0E            [12] 1536 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004210 95 10            [12] 1537 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004212 E5 0F            [12] 1538 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004214 95 11            [12] 1539 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004216 50 68            [24] 1540 	jnc	00107$
                                   1541 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004218 89 00            [24] 1542 	mov	ar0,r1
      00421A 8A 05            [24] 1543 	mov	ar5,r2
      00421C E5 0E            [12] 1544 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00421E 28               [12] 1545 	add	a, r0
      00421F F8               [12] 1546 	mov	r0,a
      004220 E5 0F            [12] 1547 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004222 3D               [12] 1548 	addc	a, r5
      004223 FD               [12] 1549 	mov	r5,a
      004224 88 82            [24] 1550 	mov	dpl, r0
      004226 8D 83            [24] 1551 	mov	dph, r5
      004228 C0 07            [24] 1552 	push	ar7
      00422A C0 06            [24] 1553 	push	ar6
      00422C C0 02            [24] 1554 	push	ar2
      00422E C0 01            [24] 1555 	push	ar1
      004230 12 3F DA         [24] 1556 	lcall	_read_offset
      004233 AD 82            [24] 1557 	mov	r5, dpl
      004235 D0 01            [24] 1558 	pop	ar1
      004237 D0 02            [24] 1559 	pop	ar2
      004239 D0 06            [24] 1560 	pop	ar6
      00423B D0 07            [24] 1561 	pop	ar7
      00423D E5 0E            [12] 1562 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00423F 2E               [12] 1563 	add	a, r6
      004240 F5 82            [12] 1564 	mov	dpl,a
      004242 E5 0F            [12] 1565 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004244 3F               [12] 1566 	addc	a, r7
      004245 F5 83            [12] 1567 	mov	dph,a
      004247 E0               [24] 1568 	movx	a,@dptr
      004248 FC               [12] 1569 	mov	r4,a
      004249 ED               [12] 1570 	mov	a,r5
      00424A B5 04 02         [24] 1571 	cjne	a,ar4,00131$
      00424D 80 27            [24] 1572 	sjmp	00106$
      00424F                       1573 00131$:
                                   1574 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00424F 90 05 96         [24] 1575 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004252 E0               [24] 1576 	movx	a,@dptr
      004253 F8               [12] 1577 	mov	r0,a
      004254 A3               [24] 1578 	inc	dptr
      004255 E0               [24] 1579 	movx	a,@dptr
      004256 FD               [12] 1580 	mov	r5,a
      004257 90 05 8A         [24] 1581 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00425A E5 12            [12] 1582 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00425C F0               [24] 1583 	movx	@dptr,a
      00425D E5 13            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00425F A3               [24] 1585 	inc	dptr
      004260 F0               [24] 1586 	movx	@dptr,a
      004261 E5 14            [12] 1587 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004263 A3               [24] 1588 	inc	dptr
      004264 F0               [24] 1589 	movx	@dptr,a
      004265 90 05 8D         [24] 1590 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004268 E5 10            [12] 1591 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00426A F0               [24] 1592 	movx	@dptr,a
      00426B E5 11            [12] 1593 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00426D A3               [24] 1594 	inc	dptr
      00426E F0               [24] 1595 	movx	@dptr,a
      00426F 88 82            [24] 1596 	mov	dpl, r0
      004271 8D 83            [24] 1597 	mov	dph, r5
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004273 02 40 FA         [24] 1599 	ljmp	_ak820_eeprom_write_block_xdata
      004276                       1600 00106$:
                                   1601 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004276 05 0E            [12] 1602 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004278 E4               [12] 1603 	clr	a
      004279 B5 0E 87         [24] 1604 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      00427C 05 0F            [12] 1605 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00427E 80 83            [24] 1606 	sjmp	00105$
      004280                       1607 00107$:
                                   1608 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      004280 22               [24] 1609 	ret
                                   1610 ;------------------------------------------------------------
                                   1611 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1612 ;------------------------------------------------------------
                                   1613 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1614 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1615 ;------------------------------------------------------------
                                   1616 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1617 ;	-----------------------------------------
                                   1618 ;	 function eeprom_driver_erase
                                   1619 ;	-----------------------------------------
      004281                       1620 _eeprom_driver_erase:
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      004281 12 3D E8         [24] 1622 	lcall	_ak820_nvm_flush
                                   1623 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004284 7F 00            [12] 1624 	mov	r7,#0x00
      004286                       1625 00111$:
      004286 BF A0 01         [24] 1626 	cjne	r7,#0xa0,00165$
      004289 22               [24] 1627 	ret
      00428A                       1628 00165$:
      00428A 20 09 32         [24] 1629 	jb	_storage_failed,00113$
                                   1630 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      00428D 8F 82            [24] 1631 	mov	dpl, r7
      00428F C0 07            [24] 1632 	push	ar7
      004291 12 3F 68         [24] 1633 	lcall	_load_page
      004294 E5 82            [12] 1634 	mov	a, dpl
      004296 D0 07            [24] 1635 	pop	ar7
      004298 70 01            [24] 1636 	jnz	00126$
                                   1637 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00429A 22               [24] 1638 	ret
      00429B                       1639 00126$:
      00429B 7E 00            [12] 1640 	mov	r6,#0x00
      00429D                       1641 00107$:
                                   1642 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      00429D EE               [12] 1643 	mov	a,r6
      00429E 24 19            [12] 1644 	add	a, #_page_data
      0042A0 FC               [12] 1645 	mov	r4,a
      0042A1 E4               [12] 1646 	clr	a
      0042A2 34 05            [12] 1647 	addc	a, #(_page_data >> 8)
      0042A4 FD               [12] 1648 	mov	r5,a
      0042A5 12 42 FC         [24] 1649 	lcall	_ak820_outline_0083
      0042A8 60 07            [24] 1650 	jz	00108$
      0042AA 12 38 4D         [24] 1651 	lcall	_ak820_outline_0110
      0042AD E4               [12] 1652 	clr	a
      0042AE F0               [24] 1653 	movx	@dptr,a
                                   1654 ;	assignBit
      0042AF D2 08            [12] 1655 	setb	_page_dirty
      0042B1                       1656 00108$:
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042B1 0E               [12] 1658 	inc	r6
      0042B2 BE 40 E8         [24] 1659 	cjne	r6,#0x40,00107$
                                   1660 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042B5 C0 07            [24] 1661 	push	ar7
      0042B7 12 3D E8         [24] 1662 	lcall	_ak820_nvm_flush
      0042BA D0 07            [24] 1663 	pop	ar7
                                   1664 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042BC 0F               [12] 1665 	inc	r7
      0042BD 80 C7            [24] 1666 	sjmp	00111$
      0042BF                       1667 00113$:
                                   1668 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0042BF 22               [24] 1669 	ret
                                   1670 	.area CSEG    (CODE)
                                   1671 	.area CONST   (CODE)
                                   1672 	.area XINIT   (CODE)
                                   1673 	.area CABS    (ABS,CODE)
                                   1674 
                                   1675 ; Experimental exact instruction outlining.
                                   1676 	.globl _ak820_outline_0004
                                   1677 	.globl _ak820_outline_0010
                                   1678 	.globl _ak820_outline_0015
                                   1679 	.globl _ak820_outline_0018
                                   1680 	.globl _ak820_outline_0028
                                   1681 	.globl _ak820_outline_0034
                                   1682 	.globl _ak820_outline_0037
                                   1683 	.globl _ak820_outline_0047
                                   1684 	.globl _ak820_outline_0048
                                   1685 	.globl _ak820_outline_0056
                                   1686 	.globl _ak820_outline_0057
                                   1687 	.globl _ak820_outline_0070
                                   1688 	.globl _ak820_outline_0071
                                   1689 	.globl _ak820_outline_0083
                                   1690 	.globl _ak820_outline_0092
                                   1691 	.globl _ak820_outline_0093
                                   1692 	.globl _ak820_outline_0094
                                   1693 	.globl _ak820_outline_0096
                                   1694 	.globl _ak820_outline_0098
                                   1695 	.globl _ak820_outline_0099
                                   1696 	.globl _ak820_outline_0109
                                   1697 	.globl _ak820_outline_0110
                                   1698 	.globl _ak820_outline_0112
                                   1699 	.globl _ak820_outline_0113
                                   1700 	.globl _ak820_outline_0122
                                   1701 	.globl _ak820_outline_0123
                                   1702 	.globl _ak820_outline_0125
                                   1703 	.globl _ak820_outline_0131
                                   1704 	.globl _ak820_outline_0132
                                   1705 	.globl _ak820_outline_0137
                                   1706 	.globl _ak820_outline_0145
                                   1707 	.globl _ak820_outline_0148
                                   1708 	.globl _ak820_outline_0149
                                   1709 	.globl _ak820_outline_0158
                                   1710 	.globl _ak820_outline_0170
                                   1711 	.globl _ak820_outline_0171
                                   1712 
                                   1713 	.area CSEG (CODE)
                                   1714 ; function ak820_outline_0010
      0042C0                       1715 _ak820_outline_0010:
      0042C0 8E 82            [24] 1716 	mov	dpl,r6
      0042C2 8F 83            [24] 1717 	mov	dph,r7
      0042C4 A3               [24] 1718 	inc	dptr
      0042C5 A3               [24] 1719 	inc	dptr
      0042C6 A3               [24] 1720 	inc	dptr
      0042C7 A3               [24] 1721 	inc	dptr
      0042C8 A3               [24] 1722 	inc	dptr
      0042C9 22               [24] 1723 	ret
                                   1724 
                                   1725 	.area CSEG (CODE)
                                   1726 ; function ak820_outline_0028
      0042CA                       1727 _ak820_outline_0028:
      0042CA F0               [24] 1728 	movx	@dptr,a
      0042CB 8E 82            [24] 1729 	mov	dpl,r6
      0042CD 8F 83            [24] 1730 	mov	dph,r7
      0042CF A3               [24] 1731 	inc	dptr
      0042D0 A3               [24] 1732 	inc	dptr
      0042D1 22               [24] 1733 	ret
                                   1734 
                                   1735 	.area CSEG (CODE)
                                   1736 ; function ak820_outline_0034
      0042D2                       1737 _ak820_outline_0034:
      0042D2 AF F0            [24] 1738 	mov	r7,b
      0042D4 AE 83            [24] 1739 	mov	r6,dph
      0042D6 E5 82            [12] 1740 	mov	a,dpl
      0042D8 22               [24] 1741 	ret
                                   1742 
                                   1743 	.area CSEG (CODE)
                                   1744 ; function ak820_outline_0037
      0042D9                       1745 _ak820_outline_0037:
      0042D9 EF               [12] 1746 	mov	a,r7
      0042DA 24 71            [12] 1747 	add	a,#_ak820_nvm_flush_header_10000_62
      0042DC F5 82            [12] 1748 	mov	dpl,a
      0042DE E4               [12] 1749 	clr	a
      0042DF 34 05            [12] 1750 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      0042E1 F5 83            [12] 1751 	mov	dph,a
      0042E3 E0               [24] 1752 	movx	a,@dptr
      0042E4 22               [24] 1753 	ret
                                   1754 
                                   1755 	.area CSEG (CODE)
                                   1756 ; function ak820_outline_0048
      0042E5                       1757 _ak820_outline_0048:
      0042E5 8F 06            [24] 1758 	mov	ar6,r7
      0042E7 7D 00            [12] 1759 	mov	r5,#0x00
      0042E9 74 40            [12] 1760 	mov	a,#0x40
      0042EB 2E               [12] 1761 	add	a,r6
      0042EC FE               [12] 1762 	mov	r6,a
      0042ED 74 EF            [12] 1763 	mov	a,#0xef
      0042EF 3D               [12] 1764 	addc	a,r5
      0042F0 FD               [12] 1765 	mov	r5,a
      0042F1 8E 82            [24] 1766 	mov	dpl,r6
      0042F3 8D 83            [24] 1767 	mov	dph,r5
      0042F5 22               [24] 1768 	ret
                                   1769 
                                   1770 	.area CSEG (CODE)
                                   1771 ; function ak820_outline_0057
      0042F6                       1772 _ak820_outline_0057:
      0042F6 F0               [24] 1773 	movx	@dptr,a
      0042F7 8E 82            [24] 1774 	mov	dpl,r6
      0042F9 8F 83            [24] 1775 	mov	dph,r7
      0042FB 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0083
      0042FC                       1780 _ak820_outline_0083:
      0042FC 8C 82            [24] 1781 	mov	dpl,r4
      0042FE 8D 83            [24] 1782 	mov	dph,r5
      004300 E0               [24] 1783 	movx	a,@dptr
      004301 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0093
      004302                       1788 _ak820_outline_0093:
      004302 E0               [24] 1789 	movx	a,@dptr
      004303 FA               [12] 1790 	mov	r2,a
      004304 A3               [24] 1791 	inc	dptr
      004305 E0               [24] 1792 	movx	a,@dptr
      004306 FB               [12] 1793 	mov	r3,a
      004307 22               [24] 1794 	ret
                                   1795 
                                   1796 	.area CSEG (CODE)
                                   1797 ; function ak820_outline_0094
      004308                       1798 _ak820_outline_0094:
      004308 E0               [24] 1799 	movx	a,@dptr
      004309 FD               [12] 1800 	mov	r5,a
      00430A A3               [24] 1801 	inc	dptr
      00430B E0               [24] 1802 	movx	a,@dptr
      00430C FE               [12] 1803 	mov	r6,a
      00430D 22               [24] 1804 	ret
                                   1805 
                                   1806 	.area CSEG (CODE)
                                   1807 ; function ak820_outline_0096
      00430E                       1808 _ak820_outline_0096:
      00430E EF               [12] 1809 	mov	a,r7
      00430F 24 19            [12] 1810 	add	a,#_page_data
      004311 F5 82            [12] 1811 	mov	dpl,a
      004313 E4               [12] 1812 	clr	a
      004314 34 05            [12] 1813 	addc	a,#(_page_data>>8)
      004316 F5 83            [12] 1814 	mov	dph,a
      004318 E0               [24] 1815 	movx	a,@dptr
      004319 22               [24] 1816 	ret
                                   1817 
                                   1818 	.area CSEG (CODE)
                                   1819 ; function ak820_outline_0109
      00431A                       1820 _ak820_outline_0109:
      00431A 8E 82            [24] 1821 	mov	dpl,r6
      00431C 8F 83            [24] 1822 	mov	dph,r7
      00431E 22               [24] 1823 	ret
                                   1824 
                                   1825 	.area CSEG (CODE)
                                   1826 ; function ak820_outline_0123
      00431F                       1827 _ak820_outline_0123:
      00431F AE 82            [24] 1828 	mov	r6,dpl
      004321 AF 83            [24] 1829 	mov	r7,dph
      004323 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0125
      004324                       1834 _ak820_outline_0125:
      004324 2E               [12] 1835 	add	a,r6
      004325 FE               [12] 1836 	mov	r6,a
      004326 E4               [12] 1837 	clr	a
      004327 3F               [12] 1838 	addc	a,r7
      004328 FF               [12] 1839 	mov	r7,a
      004329 22               [24] 1840 	ret
                                   1841 
                                   1842 	.area CSEG (CODE)
                                   1843 ; function ak820_outline_0131
      00432A                       1844 _ak820_outline_0131:
      00432A 42 05            [12] 1845 	orl	ar5,a
      00432C EA               [12] 1846 	mov	a,r2
      00432D 42 04            [12] 1847 	orl	ar4,a
      00432F 22               [24] 1848 	ret
                                   1849 
                                   1850 	.area CSEG (CODE)
                                   1851 ; function ak820_outline_0132
      004330                       1852 _ak820_outline_0132:
      004330 8A 82            [24] 1853 	mov	dpl,r2
      004332 8B 83            [24] 1854 	mov	dph,r3
      004334 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0137
      004335                       1859 _ak820_outline_0137:
      004335 AC 82            [24] 1860 	mov	r4,dpl
      004337 AD 83            [24] 1861 	mov	r5,dph
      004339 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0145
      00433A                       1866 _ak820_outline_0145:
      00433A 8F 82            [24] 1867 	mov	dpl,r7
      00433C 8E 83            [24] 1868 	mov	dph,r6
      00433E 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0148
      00433F                       1873 _ak820_outline_0148:
      00433F 2E               [12] 1874 	add	a,r6
      004340 FC               [12] 1875 	mov	r4,a
      004341 E4               [12] 1876 	clr	a
      004342 3F               [12] 1877 	addc	a,r7
      004343 FD               [12] 1878 	mov	r5,a
      004344 22               [24] 1879 	ret
                                   1880 
                                   1881 	.area CSEG (CODE)
                                   1882 ; function ak820_outline_0149
      004345                       1883 _ak820_outline_0149:
      004345 ED               [12] 1884 	mov	a,r5
      004346 F0               [24] 1885 	movx	@dptr,a
      004347 EE               [12] 1886 	mov	a,r6
      004348 A3               [24] 1887 	inc	dptr
      004349 F0               [24] 1888 	movx	@dptr,a
      00434A 22               [24] 1889 	ret
                                   1890 
                                   1891 	.area CSEG (CODE)
                                   1892 ; function ak820_outline_0170
      00434B                       1893 _ak820_outline_0170:
      00434B 89 82            [24] 1894 	mov	dpl,r1
      00434D 8A 83            [24] 1895 	mov	dph,r2
      00434F 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0171
      004350                       1900 _ak820_outline_0171:
      004350 8C 82            [24] 1901 	mov	dpl,r4
      004352 8B 83            [24] 1902 	mov	dph,r3
      004354 22               [24] 1903 	ret
