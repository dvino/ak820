                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module repeat_key
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_weak_mods
                                     12 	.globl _register_weak_mods
                                     13 	.globl _process_record
                                     14 	.globl _memset
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _get_alt_repeat_key_keycode_user_PARM_2
                                    259 	.globl _set_last_record_PARM_2
                                    260 	.globl _repeat_key_cancel
                                    261 	.globl _set_last_mods
                                    262 	.globl _set_last_record
                                    263 	.globl _get_repeat_key_count
                                    264 	.globl _repeat_key_invoke
                                    265 	.globl _get_alt_repeat_key_keycode
                                    266 	.globl _alt_repeat_key_invoke
                                    267 	.globl _get_alt_repeat_key_keycode_user
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 ;--------------------------------------------------------
                                    534 ; indirectly addressable internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area ISEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; absolute internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area IABS    (ABS,DATA)
                                    541 	.area IABS    (ABS,DATA)
                                    542 ;--------------------------------------------------------
                                    543 ; bit data
                                    544 ;--------------------------------------------------------
                                    545 	.area BSEG    (BIT)
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      000BDC                        554 _last_record:
      000BDC                        555 	.ds 9
      000BE5                        556 _ak820_repeat_invoking:
      000BE5                        557 	.ds 1
      000BE6                        558 _registered_record:
      000BE6                        559 	.ds 9
      000BEF                        560 _registered_repeat_count:
      000BEF                        561 	.ds 1
      000BF0                        562 _registered_mods:
      000BF0                        563 	.ds 1
      000BF1                        564 _set_last_mods_mods_10000_170:
      000BF1                        565 	.ds 1
      000BF2                        566 _set_last_record_PARM_2:
      000BF2                        567 	.ds 2
      000BF4                        568 _set_last_record_keycode_10000_172:
      000BF4                        569 	.ds 2
      000BF6                        570 _update_last_repeat_count_dir_10000_174:
      000BF6                        571 	.ds 1
      000BF7                        572 _repeat_invoke_PARM_2:
      000BF7                        573 	.ds 1
      000BF8                        574 _repeat_invoke_event_10000_182:
      000BF8                        575 	.ds 2
      000BFA                        576 _repeat_key_invoke_event_10000_197:
      000BFA                        577 	.ds 2
      000BFC                        578 _find_alt_keycode_PARM_2:
      000BFC                        579 	.ds 1
      000BFD                        580 _find_alt_keycode_PARM_3:
      000BFD                        581 	.ds 1
      000BFE                        582 _find_alt_keycode_table_10000_199:
      000BFE                        583 	.ds 3
      000C01                        584 _get_alt_repeat_key_keycode_keycode_10000_206:
      000C01                        585 	.ds 2
      000C03                        586 _get_alt_repeat_key_keycode_mods_10000_206:
      000C03                        587 	.ds 1
      000C04                        588 _get_alt_repeat_key_keycode_alt_keycode_10000_206:
      000C04                        589 	.ds 2
      000C06                        590 _alt_repeat_key_invoke_event_10000_220:
      000C06                        591 	.ds 2
      000C08                        592 _get_alt_repeat_key_keycode_user_PARM_2:
      000C08                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; absolute external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XABS    (ABS,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; initialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XISEG   (XDATA)
      000DDE                        602 _last_mods:
      000DDE                        603 	.ds 1
      000DDF                        604 _last_repeat_count:
      000DDF                        605 	.ds 1
      000DE0                        606 _processing_repeat_count:
      000DE0                        607 	.ds 1
                                    608 	.area HOME    (CODE)
                                    609 	.area GSINIT0 (CODE)
                                    610 	.area GSINIT1 (CODE)
                                    611 	.area GSINIT2 (CODE)
                                    612 	.area GSINIT3 (CODE)
                                    613 	.area GSINIT4 (CODE)
                                    614 	.area GSINIT5 (CODE)
                                    615 	.area GSINIT  (CODE)
                                    616 	.area GSFINAL (CODE)
                                    617 	.area CSEG    (CODE)
                                    618 ;--------------------------------------------------------
                                    619 ; global & static initialisations
                                    620 ;--------------------------------------------------------
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 	.area GSFINAL (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 ;--------------------------------------------------------
                                    626 ; Home
                                    627 ;--------------------------------------------------------
                                    628 	.area HOME    (CODE)
                                    629 	.area HOME    (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; code
                                    632 ;--------------------------------------------------------
                                    633 	.area CSEG    (CODE)
                                    634 ;------------------------------------------------------------
                                    635 ;Allocation info for local variables in function 'repeat_key_cancel'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/repeat_key.c:44: void repeat_key_cancel(void) {
                                    638 ;	-----------------------------------------
                                    639 ;	 function repeat_key_cancel
                                    640 ;	-----------------------------------------
      009D38                        641 _repeat_key_cancel:
                           000007   642 	ar7 = 0x07
                           000006   643 	ar6 = 0x06
                           000005   644 	ar5 = 0x05
                           000004   645 	ar4 = 0x04
                           000003   646 	ar3 = 0x03
                           000002   647 	ar2 = 0x02
                           000001   648 	ar1 = 0x01
                           000000   649 	ar0 = 0x00
                                    650 ;	quantum/repeat_key.c:45: registered_record.keycode = 0;
      009D38 90 0B ED         [24]  651 	mov	dptr,#(_registered_record + 0x0007)
      009D3B 12 4D 8A         [24]  652 	lcall	_ak820_outline_0157
                                    653 ;	quantum/repeat_key.c:46: }
      009D3E 22               [24]  654 	ret
                                    655 ;------------------------------------------------------------
                                    656 ;Allocation info for local variables in function 'get_last_keycode'
                                    657 ;------------------------------------------------------------
                                    658 ;	quantum/repeat_key.c:48: uint16_t get_last_keycode(void) {
                                    659 ;	-----------------------------------------
                                    660 ;	 function set_last_mods
                                    661 ;	-----------------------------------------
      009D3F                        662 _set_last_mods:
      009D3F E5 82            [12]  663 	mov	a,dpl
      009D41 90 0B F1         [24]  664 	mov	dptr,#_set_last_mods_mods_10000_170
      009D44 F0               [24]  665 	movx	@dptr,a
                                    666 ;	quantum/repeat_key.c:66: last_mods = mods;
      009D45 E0               [24]  667 	movx	a,@dptr
      009D46 90 0D DE         [24]  668 	mov	dptr,#_last_mods
      009D49 F0               [24]  669 	movx	@dptr,a
                                    670 ;	quantum/repeat_key.c:67: }
      009D4A 22               [24]  671 	ret
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'set_last_record'
                                    674 ;------------------------------------------------------------
                                    675 ;record        Allocated with name '_set_last_record_PARM_2'
                                    676 ;keycode       Allocated with name '_set_last_record_keycode_10000_172'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/repeat_key.c:69: void set_last_record(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record) {
                                    679 ;	-----------------------------------------
                                    680 ;	 function set_last_record
                                    681 ;	-----------------------------------------
      009D4B                        682 _set_last_record:
      009D4B 12 38 3C         [24]  683 	lcall	_ak820_outline_0098
      009D4E 90 0B F4         [24]  684 	mov	dptr,#_set_last_record_keycode_10000_172
      009D51 12 38 41         [24]  685 	lcall	_ak820_outline_0099
                                    686 ;	quantum/repeat_key.c:70: last_record         = *record;
      009D54 90 0B F2         [24]  687 	mov	dptr,#_set_last_record_PARM_2
      009D57 12 38 10         [24]  688 	lcall	_ak820_outline_0054
      009D5A 90 0D 67         [24]  689 	mov	dptr,#___memcpy_PARM_2
      009D5D ED               [12]  690 	mov	a,r5
      009D5E 12 37 E1         [24]  691 	lcall	_ak820_outline_0015
      009D61 90 0D 6A         [24]  692 	mov	dptr,#___memcpy_PARM_3
      009D64 74 09            [12]  693 	mov	a,#0x09
      009D66 12 38 58         [24]  694 	lcall	_ak820_outline_0114
      009D69 90 0B DC         [24]  695 	mov	dptr,#_last_record
      009D6C F5 F0            [12]  696 	mov	b,a
      009D6E 12 B3 DC         [24]  697 	lcall	___memcpy
                                    698 ;	quantum/repeat_key.c:71: last_record.keycode = keycode;
      009D71 90 0B F4         [24]  699 	mov	dptr,#_set_last_record_keycode_10000_172
      009D74 12 37 F9         [24]  700 	lcall	_ak820_outline_0047
      009D77 90 0B E3         [24]  701 	mov	dptr,#(_last_record + 0x0007)
      009D7A 12 47 03         [24]  702 	lcall	_ak820_outline_0055
                                    703 ;	quantum/repeat_key.c:72: last_repeat_count   = 0;
      009D7D 90 0D DF         [24]  704 	mov	dptr,#_last_repeat_count
      009D80 E4               [12]  705 	clr	a
      009D81 F0               [24]  706 	movx	@dptr,a
                                    707 ;	quantum/repeat_key.c:73: }
      009D82 22               [24]  708 	ret
                                    709 ;------------------------------------------------------------
                                    710 ;Allocation info for local variables in function 'update_last_repeat_count'
                                    711 ;------------------------------------------------------------
                                    712 ;dir           Allocated with name '_update_last_repeat_count_dir_10000_174'
                                    713 ;------------------------------------------------------------
                                    714 ;	quantum/repeat_key.c:76: static void update_last_repeat_count(int8_t dir) {
                                    715 ;	-----------------------------------------
                                    716 ;	 function update_last_repeat_count
                                    717 ;	-----------------------------------------
      009D83                        718 _update_last_repeat_count:
      009D83 E5 82            [12]  719 	mov	a,dpl
      009D85 90 0B F6         [24]  720 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      009D88 F0               [24]  721 	movx	@dptr,a
                                    722 ;	quantum/repeat_key.c:77: if ((dir < 0) != (last_repeat_count < 0)) {
      009D89 E0               [24]  723 	movx	a,@dptr
      009D8A FF               [12]  724 	mov	r7,a
      009D8B 33               [12]  725 	rlc	a
      009D8C E4               [12]  726 	clr	a
      009D8D 33               [12]  727 	rlc	a
      009D8E FE               [12]  728 	mov	r6,a
      009D8F 90 0D DF         [24]  729 	mov	dptr,#_last_repeat_count
      009D92 E0               [24]  730 	movx	a,@dptr
      009D93 FD               [12]  731 	mov	r5,a
      009D94 33               [12]  732 	rlc	a
      009D95 E4               [12]  733 	clr	a
      009D96 33               [12]  734 	rlc	a
      009D97 FC               [12]  735 	mov	r4,a
      009D98 EE               [12]  736 	mov	a,r6
      009D99 B5 04 02         [24]  737 	cjne	a,ar4,00131$
      009D9C 80 06            [24]  738 	sjmp	00104$
      009D9E                        739 00131$:
                                    740 ;	quantum/repeat_key.c:78: last_repeat_count = dir;
      009D9E 90 0D DF         [24]  741 	mov	dptr,#_last_repeat_count
      009DA1 EF               [12]  742 	mov	a,r7
      009DA2 F0               [24]  743 	movx	@dptr,a
      009DA3 22               [24]  744 	ret
      009DA4                        745 00104$:
                                    746 ;	quantum/repeat_key.c:79: } else if (dir < 0 ? last_repeat_count > -127 : last_repeat_count < 127) {
      009DA4 EE               [12]  747 	mov	a,r6
      009DA5 60 0F            [24]  748 	jz	00108$
      009DA7 C3               [12]  749 	clr	c
      009DA8 74 01            [12]  750 	mov	a,#(0x81 ^ 0x80)
      009DAA 8D F0            [24]  751 	mov	b,r5
      009DAC 63 F0 80         [24]  752 	xrl	b,#0x80
      009DAF 95 F0            [12]  753 	subb	a,b
      009DB1 E4               [12]  754 	clr	a
      009DB2 33               [12]  755 	rlc	a
      009DB3 FF               [12]  756 	mov	r7,a
                                    757 ;	free result
      009DB4 80 09            [24]  758 	sjmp	00109$
      009DB6                        759 00108$:
      009DB6 C3               [12]  760 	clr	c
      009DB7 ED               [12]  761 	mov	a,r5
      009DB8 64 80            [12]  762 	xrl	a,#0x80
      009DBA 94 FF            [12]  763 	subb	a,#0xff
      009DBC E4               [12]  764 	clr	a
      009DBD 33               [12]  765 	rlc	a
      009DBE FF               [12]  766 	mov	r7,a
      009DBF                        767 00109$:
      009DBF EF               [12]  768 	mov	a,r7
      009DC0 60 09            [24]  769 	jz	00106$
                                    770 ;	quantum/repeat_key.c:80: last_repeat_count += dir;
      009DC2 90 0B F6         [24]  771 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      009DC5 E0               [24]  772 	movx	a,@dptr
      009DC6 90 0D DF         [24]  773 	mov	dptr,#_last_repeat_count
      009DC9 2D               [12]  774 	add	a, r5
      009DCA F0               [24]  775 	movx	@dptr,a
      009DCB                        776 00106$:
                                    777 ;	quantum/repeat_key.c:82: }
      009DCB 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'get_repeat_key_count'
                                    781 ;------------------------------------------------------------
                                    782 ;	quantum/repeat_key.c:84: int8_t get_repeat_key_count(void) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function get_repeat_key_count
                                    785 ;	-----------------------------------------
      009DCC                        786 _get_repeat_key_count:
                                    787 ;	quantum/repeat_key.c:85: return processing_repeat_count;
      009DCC 90 0D E0         [24]  788 	mov	dptr,#_processing_repeat_count
      009DCF E0               [24]  789 	movx	a,@dptr
      009DD0 F5 82            [12]  790 	mov	dpl,a
                                    791 ;	quantum/repeat_key.c:86: }
      009DD2 22               [24]  792 	ret
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'repeat_invoke'
                                    795 ;------------------------------------------------------------
                                    796 ;alternate     Allocated with name '_repeat_invoke_PARM_2'
                                    797 ;event         Allocated with name '_repeat_invoke_event_10000_182'
                                    798 ;------------------------------------------------------------
                                    799 ;	quantum/repeat_key.c:88: static void repeat_invoke(const keyevent_t AK820_RECORD_MEM *event, bool alternate) {
                                    800 ;	-----------------------------------------
                                    801 ;	 function repeat_invoke
                                    802 ;	-----------------------------------------
      009DD3                        803 _repeat_invoke:
      009DD3 12 38 3C         [24]  804 	lcall	_ak820_outline_0098
      009DD6 90 0B F8         [24]  805 	mov	dptr,#_repeat_invoke_event_10000_182
      009DD9 12 38 41         [24]  806 	lcall	_ak820_outline_0099
                                    807 ;	quantum/repeat_key.c:97: if (ak820_repeat_invoking) return;
      009DDC 90 0B E5         [24]  808 	mov	dptr,#_ak820_repeat_invoking
      009DDF E0               [24]  809 	movx	a,@dptr
      009DE0 60 01            [24]  810 	jz	00102$
      009DE2 22               [24]  811 	ret
      009DE3                        812 00102$:
                                    813 ;	quantum/repeat_key.c:99: if (processing_repeat_count) {
      009DE3 90 0D E0         [24]  814 	mov	dptr,#_processing_repeat_count
      009DE6 E0               [24]  815 	movx	a,@dptr
      009DE7 60 01            [24]  816 	jz	00104$
                                    817 ;	quantum/repeat_key.c:100: return;
      009DE9 22               [24]  818 	ret
      009DEA                        819 00104$:
                                    820 ;	quantum/repeat_key.c:103: if (event->pressed) {
      009DEA 90 0B F8         [24]  821 	mov	dptr,#_repeat_invoke_event_10000_182
      009DED 12 37 F9         [24]  822 	lcall	_ak820_outline_0047
      009DF0 74 05            [12]  823 	mov	a,#0x05
      009DF2 12 46 B8         [24]  824 	lcall	_ak820_outline_0011
      009DF5 70 03            [24]  825 	jnz	00197$
      009DF7 02 9E 72         [24]  826 	ljmp	00117$
      009DFA                        827 00197$:
                                    828 ;	quantum/repeat_key.c:106: if (registered_record.keycode || !last_record.keycode) return;
      009DFA 90 0B ED         [24]  829 	mov	dptr,#(_registered_record + 0x0007)
      009DFD 12 38 68         [24]  830 	lcall	_ak820_outline_0129
      009E00 70 08            [24]  831 	jnz	00105$
      009E02 90 0B E3         [24]  832 	mov	dptr,#(_last_record + 0x0007)
      009E05 12 38 68         [24]  833 	lcall	_ak820_outline_0129
      009E08 70 01            [24]  834 	jnz	00106$
      009E0A                        835 00105$:
      009E0A 22               [24]  836 	ret
      009E0B                        837 00106$:
                                    838 ;	quantum/repeat_key.c:107: registered_record = last_record;
      009E0B 90 0D 67         [24]  839 	mov	dptr,#___memcpy_PARM_2
      009E0E 74 DC            [12]  840 	mov	a,#_last_record
      009E10 F0               [24]  841 	movx	@dptr,a
      009E11 74 0B            [12]  842 	mov	a,#(_last_record >> 8)
      009E13 12 38 1E         [24]  843 	lcall	_ak820_outline_0067
      009E16 90 0D 6A         [24]  844 	mov	dptr,#___memcpy_PARM_3
      009E19 74 09            [12]  845 	mov	a,#0x09
      009E1B 12 38 58         [24]  846 	lcall	_ak820_outline_0114
      009E1E 90 0B E6         [24]  847 	mov	dptr,#_registered_record
      009E21 F5 F0            [12]  848 	mov	b,a
      009E23 12 B3 DC         [24]  849 	lcall	___memcpy
                                    850 ;	quantum/repeat_key.c:108: registered_mods = last_mods;
      009E26 90 0D DE         [24]  851 	mov	dptr,#_last_mods
      009E29 E0               [24]  852 	movx	a,@dptr
      009E2A 90 0B F0         [24]  853 	mov	dptr,#_registered_mods
      009E2D F0               [24]  854 	movx	@dptr,a
                                    855 ;	quantum/repeat_key.c:110: if (alternate) {
      009E2E 90 0B F7         [24]  856 	mov	dptr,#_repeat_invoke_PARM_2
      009E31 E0               [24]  857 	movx	a,@dptr
      009E32 FD               [12]  858 	mov	r5,a
      009E33 E0               [24]  859 	movx	a,@dptr
      009E34 60 1B            [24]  860 	jz	00111$
                                    861 ;	quantum/repeat_key.c:111: registered_record.keycode = get_alt_repeat_key_keycode();
      009E36 C0 05            [24]  862 	push	ar5
      009E38 12 9F 3D         [24]  863 	lcall	_get_alt_repeat_key_keycode
      009E3B AB 82            [24]  864 	mov	r3, dpl
      009E3D AC 83            [24]  865 	mov	r4, dph
      009E3F D0 05            [24]  866 	pop	ar5
      009E41 90 0B ED         [24]  867 	mov	dptr,#(_registered_record + 0x0007)
      009E44 12 38 2A         [24]  868 	lcall	_ak820_outline_0071
                                    869 ;	quantum/repeat_key.c:112: if (!registered_record.keycode) return;
      009E47 EB               [12]  870 	mov	a,r3
      009E48 4C               [12]  871 	orl	a,r4
      009E49 70 01            [24]  872 	jnz	00109$
      009E4B 22               [24]  873 	ret
      009E4C                        874 00109$:
                                    875 ;	quantum/repeat_key.c:114: registered_mods = 0;
      009E4C 90 0B F0         [24]  876 	mov	dptr,#_registered_mods
      009E4F E4               [12]  877 	clr	a
      009E50 F0               [24]  878 	movx	@dptr,a
      009E51                        879 00111$:
                                    880 ;	quantum/repeat_key.c:117: update_last_repeat_count(alternate ? -1 : 1);
      009E51 ED               [12]  881 	mov	a,r5
      009E52 60 04            [24]  882 	jz	00123$
      009E54 7D FF            [12]  883 	mov	r5,#0xff
      009E56 80 02            [24]  884 	sjmp	00124$
      009E58                        885 00123$:
      009E58 7D 01            [12]  886 	mov	r5,#0x01
      009E5A                        887 00124$:
      009E5A 8D 82            [24]  888 	mov	dpl, r5
      009E5C 12 9D 83         [24]  889 	lcall	_update_last_repeat_count
                                    890 ;	quantum/repeat_key.c:118: register_weak_mods(registered_mods);
      009E5F 90 0B F0         [24]  891 	mov	dptr,#_registered_mods
      009E62 E0               [24]  892 	movx	a,@dptr
      009E63 F5 82            [12]  893 	mov	dpl,a
      009E65 12 73 88         [24]  894 	lcall	_register_weak_mods
                                    895 ;	quantum/repeat_key.c:119: registered_repeat_count = last_repeat_count;
      009E68 90 0D DF         [24]  896 	mov	dptr,#_last_repeat_count
      009E6B E0               [24]  897 	movx	a,@dptr
      009E6C 90 0B EF         [24]  898 	mov	dptr,#_registered_repeat_count
      009E6F F0               [24]  899 	movx	@dptr,a
      009E70 80 25            [24]  900 	sjmp	00118$
      009E72                        901 00117$:
                                    902 ;	quantum/repeat_key.c:122: if (!registered_record.keycode || event->key.row != registered_record.event.key.row ||
      009E72 90 0B ED         [24]  903 	mov	dptr,#(_registered_record + 0x0007)
      009E75 12 38 68         [24]  904 	lcall	_ak820_outline_0129
      009E78 60 1C            [24]  905 	jz	00112$
      009E7A 12 38 46         [24]  906 	lcall	_ak820_outline_0101
      009E7D FD               [12]  907 	mov	r5,a
      009E7E 90 0B E7         [24]  908 	mov	dptr,#(_registered_record + 0x0001)
      009E81 E0               [24]  909 	movx	a,@dptr
      009E82 FC               [12]  910 	mov	r4,a
      009E83 ED               [12]  911 	mov	a,r5
      009E84 B5 04 0F         [24]  912 	cjne	a,ar4,00112$
                                    913 ;	quantum/repeat_key.c:123: event->key.col != registered_record.event.key.col) return;
      009E87 12 38 30         [24]  914 	lcall	_ak820_outline_0090
      009E8A FF               [12]  915 	mov	r7,a
      009E8B 90 0B E6         [24]  916 	mov	dptr,#_registered_record
      009E8E E0               [24]  917 	movx	a,@dptr
      009E8F FE               [12]  918 	mov	r6,a
      009E90 EF               [12]  919 	mov	a,r7
      009E91 B5 06 02         [24]  920 	cjne	a,ar6,00206$
      009E94 80 01            [24]  921 	sjmp	00118$
      009E96                        922 00206$:
      009E96                        923 00112$:
      009E96 22               [24]  924 	ret
      009E97                        925 00118$:
                                    926 ;	quantum/repeat_key.c:127: registered_record.event = *event;
      009E97 90 0B F8         [24]  927 	mov	dptr,#_repeat_invoke_event_10000_182
      009E9A 12 38 10         [24]  928 	lcall	_ak820_outline_0054
      009E9D 90 0D 67         [24]  929 	mov	dptr,#___memcpy_PARM_2
      009EA0 ED               [12]  930 	mov	a,r5
      009EA1 12 37 E1         [24]  931 	lcall	_ak820_outline_0015
      009EA4 90 0D 6A         [24]  932 	mov	dptr,#___memcpy_PARM_3
      009EA7 74 06            [12]  933 	mov	a,#0x06
      009EA9 12 38 58         [24]  934 	lcall	_ak820_outline_0114
      009EAC 90 0B E6         [24]  935 	mov	dptr,#_registered_record
      009EAF F5 F0            [12]  936 	mov	b,a
      009EB1 12 B3 DC         [24]  937 	lcall	___memcpy
                                    938 ;	quantum/repeat_key.c:128: processing_repeat_count = registered_repeat_count;
      009EB4 90 0B EF         [24]  939 	mov	dptr,#_registered_repeat_count
      009EB7 E0               [24]  940 	movx	a,@dptr
      009EB8 90 0D E0         [24]  941 	mov	dptr,#_processing_repeat_count
      009EBB F0               [24]  942 	movx	@dptr,a
                                    943 ;	quantum/repeat_key.c:130: ak820_repeat_invoking = true;
      009EBC 90 0B E5         [24]  944 	mov	dptr,#_ak820_repeat_invoking
      009EBF 74 01            [12]  945 	mov	a,#0x01
      009EC1 F0               [24]  946 	movx	@dptr,a
                                    947 ;	quantum/repeat_key.c:132: process_record(&registered_record);
      009EC2 90 0B E6         [24]  948 	mov	dptr,#_registered_record
      009EC5 12 6E D6         [24]  949 	lcall	_process_record
                                    950 ;	quantum/repeat_key.c:134: ak820_repeat_invoking = false;
      009EC8 90 0B E5         [24]  951 	mov	dptr,#_ak820_repeat_invoking
      009ECB E4               [12]  952 	clr	a
      009ECC F0               [24]  953 	movx	@dptr,a
                                    954 ;	quantum/repeat_key.c:136: processing_repeat_count = 0;
      009ECD 90 0D E0         [24]  955 	mov	dptr,#_processing_repeat_count
      009ED0 F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/repeat_key.c:142: if (!registered_record.event.pressed) {
      009ED1 90 0B EB         [24]  958 	mov	dptr,#(_registered_record + 0x0005)
      009ED4 E0               [24]  959 	movx	a,@dptr
      009ED5 70 0F            [24]  960 	jnz	00121$
                                    961 ;	quantum/repeat_key.c:143: unregister_weak_mods(registered_mods);
      009ED7 90 0B F0         [24]  962 	mov	dptr,#_registered_mods
      009EDA E0               [24]  963 	movx	a,@dptr
      009EDB F5 82            [12]  964 	mov	dpl,a
      009EDD 12 73 9C         [24]  965 	lcall	_unregister_weak_mods
                                    966 ;	quantum/repeat_key.c:144: registered_record.keycode = 0;
      009EE0 90 0B ED         [24]  967 	mov	dptr,#(_registered_record + 0x0007)
      009EE3 12 4D 8A         [24]  968 	lcall	_ak820_outline_0157
      009EE6                        969 00121$:
                                    970 ;	quantum/repeat_key.c:146: }
      009EE6 22               [24]  971 	ret
                                    972 ;------------------------------------------------------------
                                    973 ;Allocation info for local variables in function 'repeat_key_invoke'
                                    974 ;------------------------------------------------------------
                                    975 ;event         Allocated with name '_repeat_key_invoke_event_10000_197'
                                    976 ;------------------------------------------------------------
                                    977 ;	quantum/repeat_key.c:148: void repeat_key_invoke(const keyevent_t AK820_RECORD_MEM *event) {
                                    978 ;	-----------------------------------------
                                    979 ;	 function repeat_key_invoke
                                    980 ;	-----------------------------------------
      009EE7                        981 _repeat_key_invoke:
      009EE7 12 38 3C         [24]  982 	lcall	_ak820_outline_0098
      009EEA 90 0B FA         [24]  983 	mov	dptr,#_repeat_key_invoke_event_10000_197
      009EED 12 38 41         [24]  984 	lcall	_ak820_outline_0099
                                    985 ;	quantum/repeat_key.c:149: repeat_invoke(event, false);
      009EF0 90 0B FA         [24]  986 	mov	dptr,#_repeat_key_invoke_event_10000_197
      009EF3 12 37 F9         [24]  987 	lcall	_ak820_outline_0047
      009EF6 90 0B F7         [24]  988 	mov	dptr,#_repeat_invoke_PARM_2
      009EF9 E4               [12]  989 	clr	a
      009EFA 12 42 F6         [24]  990 	lcall	_ak820_outline_0057
                                    991 ;	quantum/repeat_key.c:150: }
      009EFD 02 9D D3         [24]  992 	ljmp	_repeat_invoke
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'find_alt_keycode'
                                    995 ;------------------------------------------------------------
                                    996 ;table_size_bytes Allocated with name '_find_alt_keycode_PARM_2'
                                    997 ;target        Allocated with name '_find_alt_keycode_PARM_3'
                                    998 ;table         Allocated with name '_find_alt_keycode_table_10000_199'
                                    999 ;keycodes      Allocated with name '_find_alt_keycode_keycodes_10000_200'
                                   1000 ;i             Allocated with name '_find_alt_keycode_i_20000_201'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	quantum/repeat_key.c:166: static uint8_t find_alt_keycode(const uint8_t (*table)[2], uint8_t table_size_bytes, uint8_t target) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function find_alt_keycode
                                   1005 ;	-----------------------------------------
      009F00                       1006 _find_alt_keycode:
      009F00 12 42 D2         [24] 1007 	lcall	_ak820_outline_0034
      009F03 90 0B FE         [24] 1008 	mov	dptr,#_find_alt_keycode_table_10000_199
      009F06 12 37 E1         [24] 1009 	lcall	_ak820_outline_0015
                                   1010 ;	quantum/repeat_key.c:167: const uint8_t* keycodes = (const uint8_t*)table;
      009F09 90 0B FE         [24] 1011 	mov	dptr,#_find_alt_keycode_table_10000_199
      009F0C 12 4D 3F         [24] 1012 	lcall	_ak820_outline_0020
                                   1013 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      009F0F 7C 00            [12] 1014 	mov	r4,#0x00
      009F11                       1015 00105$:
      009F11 90 0B FC         [24] 1016 	mov	dptr,#_find_alt_keycode_PARM_2
      009F14 E0               [24] 1017 	movx	a,@dptr
      009F15 FB               [12] 1018 	mov	r3,a
      009F16 C3               [12] 1019 	clr	c
      009F17 EC               [12] 1020 	mov	a,r4
      009F18 9B               [12] 1021 	subb	a,r3
      009F19 50 1E            [24] 1022 	jnc	00103$
                                   1023 ;	quantum/repeat_key.c:169: if (target == pgm_read_byte(keycodes + i)) {
      009F1B EC               [12] 1024 	mov	a,r4
      009F1C 12 8B 09         [24] 1025 	lcall	_ak820_outline_0023
      009F1F 12 B4 B5         [24] 1026 	lcall	__gptrget
      009F22 F9               [12] 1027 	mov	r1,a
      009F23 90 0B FD         [24] 1028 	mov	dptr,#_find_alt_keycode_PARM_3
      009F26 E0               [24] 1029 	movx	a,@dptr
      009F27 B5 01 0C         [24] 1030 	cjne	a,ar1,00106$
                                   1031 ;	quantum/repeat_key.c:171: return pgm_read_byte(keycodes + (i ^ 1));
      009F2A 74 01            [12] 1032 	mov	a,#0x01
      009F2C 6C               [12] 1033 	xrl	a,r4
      009F2D 12 8B 09         [24] 1034 	lcall	_ak820_outline_0023
      009F30 12 B4 B5         [24] 1035 	lcall	__gptrget
      009F33 F5 82            [12] 1036 	mov	dpl,a
      009F35 22               [24] 1037 	ret
      009F36                       1038 00106$:
                                   1039 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      009F36 0C               [12] 1040 	inc	r4
      009F37 80 D8            [24] 1041 	sjmp	00105$
      009F39                       1042 00103$:
                                   1043 ;	quantum/repeat_key.c:174: return KC_NO;
      009F39 75 82 00         [24] 1044 	mov	dpl, #0x00
                                   1045 ;	quantum/repeat_key.c:175: }
      009F3C 22               [24] 1046 	ret
                                   1047 ;------------------------------------------------------------
                                   1048 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode'
                                   1049 ;------------------------------------------------------------
                                   1050 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_keycode_10000_206'
                                   1051 ;mods          Allocated with name '_get_alt_repeat_key_keycode_mods_10000_206'
                                   1052 ;alt_keycode   Allocated with name '_get_alt_repeat_key_keycode_alt_keycode_10000_206'
                                   1053 ;------------------------------------------------------------
                                   1054 ;	quantum/repeat_key.c:177: uint16_t get_alt_repeat_key_keycode(void) {
                                   1055 ;	-----------------------------------------
                                   1056 ;	 function get_alt_repeat_key_keycode
                                   1057 ;	-----------------------------------------
      009F3D                       1058 _get_alt_repeat_key_keycode:
                                   1059 ;	quantum/repeat_key.c:178: uint16_t keycode = last_record.keycode;
      009F3D 90 0B E3         [24] 1060 	mov	dptr,#(_last_record + 0x0007)
      009F40 12 37 F9         [24] 1061 	lcall	_ak820_outline_0047
      009F43 90 0C 01         [24] 1062 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      009F46 12 47 03         [24] 1063 	lcall	_ak820_outline_0055
                                   1064 ;	quantum/repeat_key.c:179: uint8_t  mods    = last_mods;
      009F49 90 0D DE         [24] 1065 	mov	dptr,#_last_mods
      009F4C E0               [24] 1066 	movx	a,@dptr
      009F4D FD               [12] 1067 	mov	r5,a
      009F4E 90 0C 03         [24] 1068 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      009F51 F0               [24] 1069 	movx	@dptr,a
                                   1070 ;	quantum/repeat_key.c:183: uint16_t alt_keycode = get_alt_repeat_key_keycode_user(keycode, mods);
      009F52 90 0C 08         [24] 1071 	mov	dptr,#_get_alt_repeat_key_keycode_user_PARM_2
      009F55 ED               [12] 1072 	mov	a,r5
      009F56 12 42 F6         [24] 1073 	lcall	_ak820_outline_0057
      009F59 C0 07            [24] 1074 	push	ar7
      009F5B C0 06            [24] 1075 	push	ar6
      009F5D 12 A0 70         [24] 1076 	lcall	_get_alt_repeat_key_keycode_user
      009F60 12 43 35         [24] 1077 	lcall	_ak820_outline_0137
      009F63 D0 06            [24] 1078 	pop	ar6
      009F65 D0 07            [24] 1079 	pop	ar7
                                   1080 ;	quantum/repeat_key.c:185: if (alt_keycode != KC_TRANSPARENT) {
      009F67 8C 02            [24] 1081 	mov	ar2,r4
      009F69 8D 03            [24] 1082 	mov	ar3,r5
      009F6B BA 01 05         [24] 1083 	cjne	r2,#0x01,00176$
      009F6E BB 00 02         [24] 1084 	cjne	r3,#0x00,00176$
      009F71 80 04            [24] 1085 	sjmp	00102$
      009F73                       1086 00176$:
                                   1087 ;	quantum/repeat_key.c:186: return alt_keycode;
      009F73 12 38 4D         [24] 1088 	lcall	_ak820_outline_0110
      009F76 22               [24] 1089 	ret
      009F77                       1090 00102$:
                                   1091 ;	quantum/repeat_key.c:191: mods = ((mods & 0xf0) ? /* set right hand bit */ 0x10 : 0)
      009F77 90 0C 03         [24] 1092 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      009F7A E0               [24] 1093 	movx	a,@dptr
      009F7B 54 F0            [12] 1094 	anl	a,#0xf0
      009F7D 60 02            [24] 1095 	jz	00118$
      009F7F 74 10            [12] 1096 	mov	a,#0x10
      009F81                       1097 00118$:
      009F81 FD               [12] 1098 	mov	r5,a
                                   1099 ;	quantum/repeat_key.c:193: | (((mods >> 4) | mods) & 0xf);
      009F82 90 0C 03         [24] 1100 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      009F85 E0               [24] 1101 	movx	a,@dptr
      009F86 FC               [12] 1102 	mov	r4,a
      009F87 C4               [12] 1103 	swap	a
      009F88 54 0F            [12] 1104 	anl	a,#0x0f
      009F8A 4C               [12] 1105 	orl	a,r4
      009F8B 54 0F            [12] 1106 	anl	a,#0x0f
      009F8D 4D               [12] 1107 	orl	a,r5
      009F8E F0               [24] 1108 	movx	@dptr,a
                                   1109 ;	quantum/repeat_key.c:196: if (keycode >= QK_MODS && keycode <= QK_MODS_MAX) {
      009F8F 8E 04            [24] 1110 	mov	ar4,r6
      009F91 8F 05            [24] 1111 	mov	ar5,r7
      009F93 74 FF            [12] 1112 	mov	a,#0x100 - 0x01
      009F95 2D               [12] 1113 	add	a,r5
      009F96 50 1C            [24] 1114 	jnc	00115$
      009F98 C3               [12] 1115 	clr	c
      009F99 74 FF            [12] 1116 	mov	a,#0xff
      009F9B 9C               [12] 1117 	subb	a,r4
      009F9C 74 1F            [12] 1118 	mov	a,#0x1f
      009F9E 9D               [12] 1119 	subb	a,r5
      009F9F 40 13            [24] 1120 	jc	00115$
                                   1121 ;	free result
                                   1122 ;	quantum/repeat_key.c:197: mods |= QK_MODS_GET_MODS(keycode);
      009FA1 8F 06            [24] 1123 	mov	ar6,r7
      009FA3 53 06 1F         [24] 1124 	anl	ar6,#0x1f
      009FA6 90 0C 03         [24] 1125 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      009FA9 E0               [24] 1126 	movx	a,@dptr
      009FAA 4E               [12] 1127 	orl	a,r6
      009FAB F0               [24] 1128 	movx	@dptr,a
                                   1129 ;	quantum/repeat_key.c:198: keycode = QK_MODS_GET_BASIC_KEYCODE(keycode);
      009FAC 7D 00            [12] 1130 	mov	r5,#0x00
      009FAE 90 0C 01         [24] 1131 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      009FB1 12 38 24         [24] 1132 	lcall	_ak820_outline_0070
                                   1133 ;	quantum/repeat_key.c:214: if (IS_QK_BASIC(keycode)) {
      009FB4                       1134 00115$:
      009FB4 90 0C 01         [24] 1135 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      009FB7 12 37 CD         [24] 1136 	lcall	_ak820_outline_0009
      009FBA C3               [12] 1137 	clr	c
      009FBB 74 FF            [12] 1138 	mov	a,#0xff
      009FBD 9C               [12] 1139 	subb	a,r4
      009FBE E4               [12] 1140 	clr	a
      009FBF 9D               [12] 1141 	subb	a,r5
      009FC0 50 03            [24] 1142 	jnc	00180$
      009FC2 02 A0 52         [24] 1143 	ljmp	00114$
      009FC5                       1144 00180$:
                                   1145 ;	free result
                                   1146 ;	quantum/repeat_key.c:215: if ((mods & (MOD_LCTL | MOD_LALT | MOD_LGUI))) {
      009FC5 90 0C 03         [24] 1147 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      009FC8 E0               [24] 1148 	movx	a,@dptr
      009FC9 54 0D            [12] 1149 	anl	a,#0x0d
      009FCB 60 21            [24] 1150 	jz	00107$
                                   1151 ;	quantum/repeat_key.c:230: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      009FCD 8E 05            [24] 1152 	mov	ar5,r6
      009FCF 90 0B FC         [24] 1153 	mov	dptr,#_find_alt_keycode_PARM_2
      009FD2 74 0A            [12] 1154 	mov	a,#0x0a
      009FD4 F0               [24] 1155 	movx	@dptr,a
      009FD5 90 0B FD         [24] 1156 	mov	dptr,#_find_alt_keycode_PARM_3
      009FD8 ED               [12] 1157 	mov	a,r5
      009FD9 F0               [24] 1158 	movx	@dptr,a
      009FDA 90 B8 7A         [24] 1159 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_214
      009FDD 75 F0 80         [24] 1160 	mov	b, #0x80
      009FE0 12 9F 00         [24] 1161 	lcall	_find_alt_keycode
      009FE3 AD 82            [24] 1162 	mov	r5, dpl
      009FE5 90 0C 04         [24] 1163 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      009FE8 ED               [12] 1164 	mov	a,r5
      009FE9 12 38 58         [24] 1165 	lcall	_ak820_outline_0114
      009FEC 80 1D            [24] 1166 	sjmp	00108$
      009FEE                       1167 00107$:
                                   1168 ;	quantum/repeat_key.c:243: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      009FEE 90 0B FC         [24] 1169 	mov	dptr,#_find_alt_keycode_PARM_2
      009FF1 74 08            [12] 1170 	mov	a,#0x08
      009FF3 F0               [24] 1171 	movx	@dptr,a
      009FF4 90 0B FD         [24] 1172 	mov	dptr,#_find_alt_keycode_PARM_3
      009FF7 EE               [12] 1173 	mov	a,r6
      009FF8 F0               [24] 1174 	movx	@dptr,a
      009FF9 90 B8 84         [24] 1175 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_215
      009FFC 75 F0 80         [24] 1176 	mov	b, #0x80
      009FFF 12 9F 00         [24] 1177 	lcall	_find_alt_keycode
      00A002 AF 82            [24] 1178 	mov	r7, dpl
      00A004 90 0C 04         [24] 1179 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A007 EF               [12] 1180 	mov	a,r7
      00A008 12 38 58         [24] 1181 	lcall	_ak820_outline_0114
      00A00B                       1182 00108$:
                                   1183 ;	quantum/repeat_key.c:246: if (!alt_keycode) {
      00A00B 90 0C 04         [24] 1184 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A00E 12 6B A1         [24] 1185 	lcall	_ak820_outline_0033
      00A011 70 22            [24] 1186 	jnz	00110$
                                   1187 ;	quantum/repeat_key.c:271: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A013 90 0C 01         [24] 1188 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A016 E0               [24] 1189 	movx	a,@dptr
      00A017 FF               [12] 1190 	mov	r7,a
      00A018 90 0B FC         [24] 1191 	mov	dptr,#_find_alt_keycode_PARM_2
      00A01B 74 16            [12] 1192 	mov	a,#0x16
      00A01D F0               [24] 1193 	movx	@dptr,a
      00A01E 90 0B FD         [24] 1194 	mov	dptr,#_find_alt_keycode_PARM_3
      00A021 EF               [12] 1195 	mov	a,r7
      00A022 F0               [24] 1196 	movx	@dptr,a
      00A023 90 B8 8C         [24] 1197 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_217
      00A026 75 F0 80         [24] 1198 	mov	b, #0x80
      00A029 12 9F 00         [24] 1199 	lcall	_find_alt_keycode
      00A02C AF 82            [24] 1200 	mov	r7, dpl
      00A02E 90 0C 04         [24] 1201 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A031 EF               [12] 1202 	mov	a,r7
      00A032 12 38 58         [24] 1203 	lcall	_ak820_outline_0114
      00A035                       1204 00110$:
                                   1205 ;	quantum/repeat_key.c:274: if (alt_keycode) {
      00A035 90 0C 04         [24] 1206 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A038 12 37 F9         [24] 1207 	lcall	_ak820_outline_0047
      00A03B 90 0C 04         [24] 1208 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A03E 12 6B A1         [24] 1209 	lcall	_ak820_outline_0033
      00A041 60 0F            [24] 1210 	jz	00114$
                                   1211 ;	quantum/repeat_key.c:276: return (mods << 8) | alt_keycode;
      00A043 90 0C 03         [24] 1212 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A046 E0               [24] 1213 	movx	a,@dptr
      00A047 FD               [12] 1214 	mov	r5,a
      00A048 E4               [12] 1215 	clr	a
      00A049 42 06            [12] 1216 	orl	ar6,a
      00A04B ED               [12] 1217 	mov	a,r5
      00A04C 42 07            [12] 1218 	orl	ar7,a
      00A04E 12 43 1A         [24] 1219 	lcall	_ak820_outline_0109
      00A051 22               [24] 1220 	ret
      00A052                       1221 00114$:
                                   1222 ;	quantum/repeat_key.c:280: return KC_NO; // No alternate key found.
      00A052 90 00 00         [24] 1223 	mov	dptr,#0x0000
                                   1224 ;	quantum/repeat_key.c:281: }
      00A055 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'alt_repeat_key_invoke'
                                   1228 ;------------------------------------------------------------
                                   1229 ;event         Allocated with name '_alt_repeat_key_invoke_event_10000_220'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/repeat_key.c:283: void alt_repeat_key_invoke(const keyevent_t AK820_RECORD_MEM *event) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function alt_repeat_key_invoke
                                   1234 ;	-----------------------------------------
      00A056                       1235 _alt_repeat_key_invoke:
      00A056 12 38 3C         [24] 1236 	lcall	_ak820_outline_0098
      00A059 90 0C 06         [24] 1237 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00A05C 12 38 41         [24] 1238 	lcall	_ak820_outline_0099
                                   1239 ;	quantum/repeat_key.c:285: repeat_invoke(event, true);
      00A05F 90 0C 06         [24] 1240 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00A062 12 37 F9         [24] 1241 	lcall	_ak820_outline_0047
      00A065 90 0B F7         [24] 1242 	mov	dptr,#_repeat_invoke_PARM_2
      00A068 74 01            [12] 1243 	mov	a,#0x01
      00A06A 12 42 F6         [24] 1244 	lcall	_ak820_outline_0057
                                   1245 ;	quantum/repeat_key.c:286: }
      00A06D 02 9D D3         [24] 1246 	ljmp	_repeat_invoke
                                   1247 ;------------------------------------------------------------
                                   1248 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode_user'
                                   1249 ;------------------------------------------------------------
                                   1250 ;mods          Allocated with name '_get_alt_repeat_key_keycode_user_PARM_2'
                                   1251 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_user_keycode_10000_222'
                                   1252 ;------------------------------------------------------------
                                   1253 ;	quantum/repeat_key.c:289: __attribute__((weak)) uint16_t get_alt_repeat_key_keycode_user(uint16_t keycode, uint8_t mods) {
                                   1254 ;	-----------------------------------------
                                   1255 ;	 function get_alt_repeat_key_keycode_user
                                   1256 ;	-----------------------------------------
      00A070                       1257 _get_alt_repeat_key_keycode_user:
                                   1258 ;	quantum/repeat_key.c:290: return KC_TRANSPARENT;
      00A070 90 00 01         [24] 1259 	mov	dptr,#0x0001
                                   1260 ;	quantum/repeat_key.c:291: }
      00A073 22               [24] 1261 	ret
                                   1262 	.area CSEG    (CODE)
                                   1263 	.area CONST   (CODE)
                                   1264 	.area CONST   (CODE)
      00B87A                       1265 _get_alt_repeat_key_keycode_pairs_50000_214:
      00B87A 09                    1266 	.db #0x09	; 9
      00B87B 05                    1267 	.db #0x05	; 5
      00B87C 07                    1268 	.db #0x07	; 7
      00B87D 18                    1269 	.db #0x18	; 24
      00B87E 11                    1270 	.db #0x11	; 17
      00B87F 13                    1271 	.db #0x13	; 19
      00B880 04                    1272 	.db #0x04	; 4
      00B881 08                    1273 	.db #0x08	; 8
      00B882 12                    1274 	.db #0x12	; 18
      00B883 0C                    1275 	.db #0x0c	; 12
                                   1276 	.area CSEG    (CODE)
                                   1277 	.area CONST   (CODE)
      00B884                       1278 _get_alt_repeat_key_keycode_pairs_50000_215:
      00B884 0D                    1279 	.db #0x0d	; 13
      00B885 0E                    1280 	.db #0x0e	; 14
      00B886 0B                    1281 	.db #0x0b	; 11
      00B887 0F                    1282 	.db #0x0f	; 15
      00B888 1A                    1283 	.db #0x1a	; 26
      00B889 05                    1284 	.db #0x05	; 5
      00B88A 08                    1285 	.db #0x08	; 8
      00B88B 05                    1286 	.db #0x05	; 5
                                   1287 	.area CSEG    (CODE)
                                   1288 	.area CONST   (CODE)
      00B88C                       1289 _get_alt_repeat_key_keycode_pairs_50000_217:
      00B88C 50                    1290 	.db #0x50	; 80	'P'
      00B88D 4F                    1291 	.db #0x4f	; 79	'O'
      00B88E 52                    1292 	.db #0x52	; 82	'R'
      00B88F 51                    1293 	.db #0x51	; 81	'Q'
      00B890 4A                    1294 	.db #0x4a	; 74	'J'
      00B891 4D                    1295 	.db #0x4d	; 77	'M'
      00B892 4B                    1296 	.db #0x4b	; 75	'K'
      00B893 4E                    1297 	.db #0x4e	; 78	'N'
      00B894 2A                    1298 	.db #0x2a	; 42
      00B895 4C                    1299 	.db #0x4c	; 76	'L'
      00B896 2F                    1300 	.db #0x2f	; 47
      00B897 30                    1301 	.db #0x30	; 48	'0'
      00B898 B6                    1302 	.db #0xb6	; 182
      00B899 B7                    1303 	.db #0xb7	; 183
      00B89A AB                    1304 	.db #0xab	; 171
      00B89B AC                    1305 	.db #0xac	; 172
      00B89C BB                    1306 	.db #0xbb	; 187
      00B89D BC                    1307 	.db #0xbc	; 188
      00B89E A9                    1308 	.db #0xa9	; 169
      00B89F AA                    1309 	.db #0xaa	; 170
      00B8A0 BD                    1310 	.db #0xbd	; 189
      00B8A1 BE                    1311 	.db #0xbe	; 190
                                   1312 	.area CSEG    (CODE)
                                   1313 	.area XINIT   (CODE)
      00BD03                       1314 __xinit__last_mods:
      00BD03 00                    1315 	.db #0x00	; 0
      00BD04                       1316 __xinit__last_repeat_count:
      00BD04 00                    1317 	.db #0x00	;  0
      00BD05                       1318 __xinit__processing_repeat_count:
      00BD05 00                    1319 	.db #0x00	;  0
                                   1320 	.area CABS    (ABS,CODE)
                                   1321 
                                   1322 ; Experimental exact instruction outlining.
                                   1323 	.globl _ak820_outline_0009
                                   1324 	.globl _ak820_outline_0011
                                   1325 	.globl _ak820_outline_0015
                                   1326 	.globl _ak820_outline_0020
                                   1327 	.globl _ak820_outline_0023
                                   1328 	.globl _ak820_outline_0033
                                   1329 	.globl _ak820_outline_0034
                                   1330 	.globl _ak820_outline_0047
                                   1331 	.globl _ak820_outline_0054
                                   1332 	.globl _ak820_outline_0055
                                   1333 	.globl _ak820_outline_0057
                                   1334 	.globl _ak820_outline_0067
                                   1335 	.globl _ak820_outline_0070
                                   1336 	.globl _ak820_outline_0071
                                   1337 	.globl _ak820_outline_0090
                                   1338 	.globl _ak820_outline_0098
                                   1339 	.globl _ak820_outline_0099
                                   1340 	.globl _ak820_outline_0101
                                   1341 	.globl _ak820_outline_0109
                                   1342 	.globl _ak820_outline_0110
                                   1343 	.globl _ak820_outline_0114
                                   1344 	.globl _ak820_outline_0129
                                   1345 	.globl _ak820_outline_0137
                                   1346 	.globl _ak820_outline_0157
