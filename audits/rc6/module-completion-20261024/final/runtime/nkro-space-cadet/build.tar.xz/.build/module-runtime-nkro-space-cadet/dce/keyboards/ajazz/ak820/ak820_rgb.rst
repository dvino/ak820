                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000015                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000015                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      00000F                        595 _suspended:
      00000F                        596 	.ds 1
      000010                        597 _dirty:
      000010                        598 	.ds 1
      000011                        599 _rendering:
      000011                        600 	.ds 1
      000012                        601 _rgb_matrix_task_sloc0_1_0:
      000012                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      00069E                        611 _rgb_matrix_config::
      00069E                        612 	.ds 8
      0006A6                        613 _changed_at:
      0006A6                        614 	.ds 2
      0006A8                        615 _frame_at:
      0006A8                        616 	.ds 2
      0006AA                        617 _phase:
      0006AA                        618 	.ds 2
      0006AC                        619 _led_index:
      0006AC                        620 	.ds 1
      0006AD                        621 _frame_mode:
      0006AD                        622 	.ds 1
      0006AE                        623 _frame_hue:
      0006AE                        624 	.ds 1
      0006AF                        625 _frame_sat:
      0006AF                        626 	.ds 1
      0006B0                        627 _frame_val:
      0006B0                        628 	.ds 1
      0006B1                        629 _frame_flags:
      0006B1                        630 	.ds 1
      0006B2                        631 _frame_phase:
      0006B2                        632 	.ds 1
      0006B3                        633 _reactive_age:
      0006B3                        634 	.ds 82
      000705                        635 _reactive_at:
      000705                        636 	.ds 2
      000707                        637 _add_sat_PARM_2:
      000707                        638 	.ds 1
      000708                        639 _add_sat_x_10000_266:
      000708                        640 	.ds 1
      000709                        641 _sub_sat_PARM_2:
      000709                        642 	.ds 1
      00070A                        643 _sub_sat_x_10000_268:
      00070A                        644 	.ds 1
      00070B                        645 _rgb_matrix_set_color_PARM_2:
      00070B                        646 	.ds 1
      00070C                        647 _rgb_matrix_set_color_PARM_3:
      00070C                        648 	.ds 1
      00070D                        649 _rgb_matrix_set_color_PARM_4:
      00070D                        650 	.ds 1
      00070E                        651 _rgb_matrix_set_color_index_10000_284:
      00070E                        652 	.ds 2
      000710                        653 _rgb_matrix_set_color_all_PARM_2:
      000710                        654 	.ds 1
      000711                        655 _rgb_matrix_set_color_all_PARM_3:
      000711                        656 	.ds 1
      000712                        657 _rgb_matrix_set_color_all_r_10000_287:
      000712                        658 	.ds 1
      000713                        659 _sine8_theta_10000_289:
      000713                        660 	.ds 1
      000714                        661 _sine8_offset_10000_290:
      000714                        662 	.ds 1
      000715                        663 _sine8_fraction_10000_290:
      000715                        664 	.ds 1
      000716                        665 _breathing_cie_value_10000_293:
      000716                        666 	.ds 1
      000717                        667 _rgb_matrix_task_end_10000_298:
      000717                        668 	.ds 1
      000718                        669 _rgb_matrix_task_hsv_10000_298:
      000718                        670 	.ds 3
      00071B                        671 _rgb_matrix_task_rgb_10000_298:
      00071B                        672 	.ds 3
      00071E                        673 _process_rgb_matrix_PARM_2:
      00071E                        674 	.ds 1
      00071F                        675 _process_rgb_matrix_PARM_3:
      00071F                        676 	.ds 1
      000720                        677 _process_rgb_matrix_row_10000_319:
      000720                        678 	.ds 1
      000721                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      000721                        680 	.ds 1
      000722                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      000722                        682 	.ds 1
      000723                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000723                        684 	.ds 1
      000724                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      000724                        686 	.ds 1
      000725                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      000725                        688 	.ds 2
      000727                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      000727                        690 	.ds 1
      000728                        691 _rgb_matrix_mode_mode_10000_411:
      000728                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      004D8F                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      004D8F 12 55 78         [24]  746 	lcall	_ak820_outline_0167
      004D92 74 52            [12]  747 	mov	a,#0x52
      004D94 12 38 58         [24]  748 	lcall	_ak820_outline_0114
      004D97 90 06 B3         [24]  749 	mov	dptr,#_reactive_age
      004D9A F5 F0            [12]  750 	mov	b,a
      004D9C 12 B4 52         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      004D9F 12 47 86         [24]  753 	lcall	_timer_read
      004DA2 12 38 62         [24]  754 	lcall	_ak820_outline_0126
      004DA5 90 07 05         [24]  755 	mov	dptr,#_reactive_at
      004DA8 12 55 64         [24]  756 	lcall	_ak820_outline_0156
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      004DAB 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      004DAC                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      004DAC 90 07 05         [24]  772 	mov	dptr,#_reactive_at
      004DAF 12 37 A2         [24]  773 	lcall	_ak820_outline_0004
      004DB2 12 47 89         [24]  774 	lcall	_timer_elapsed
      004DB5 AE 82            [24]  775 	mov	r6, dpl
      004DB7 E5 83            [12]  776 	mov	a,dph
      004DB9 C4               [12]  777 	swap	a
      004DBA CE               [12]  778 	xch	a,r6
      004DBB C4               [12]  779 	swap	a
      004DBC 54 0F            [12]  780 	anl	a,#0x0f
      004DBE 6E               [12]  781 	xrl	a,r6
      004DBF CE               [12]  782 	xch	a,r6
      004DC0 54 0F            [12]  783 	anl	a,#0x0f
      004DC2 CE               [12]  784 	xch	a,r6
      004DC3 6E               [12]  785 	xrl	a,r6
      004DC4 CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      004DC5 FF               [12]  788 	mov	r7,a
      004DC6 4E               [12]  789 	orl	a,r6
      004DC7 70 01            [24]  790 	jnz	00102$
      004DC9 22               [24]  791 	ret
      004DCA                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      004DCA 8E 04            [24]  794 	mov	ar4,r6
      004DCC EF               [12]  795 	mov	a,r7
      004DCD C4               [12]  796 	swap	a
      004DCE 54 F0            [12]  797 	anl	a,#0xf0
      004DD0 CC               [12]  798 	xch	a,r4
      004DD1 C4               [12]  799 	swap	a
      004DD2 CC               [12]  800 	xch	a,r4
      004DD3 6C               [12]  801 	xrl	a,r4
      004DD4 CC               [12]  802 	xch	a,r4
      004DD5 54 F0            [12]  803 	anl	a,#0xf0
      004DD7 CC               [12]  804 	xch	a,r4
      004DD8 6C               [12]  805 	xrl	a,r4
      004DD9 FD               [12]  806 	mov	r5,a
      004DDA 90 07 05         [24]  807 	mov	dptr,#_reactive_at
      004DDD 12 43 02         [24]  808 	lcall	_ak820_outline_0093
      004DE0 90 07 05         [24]  809 	mov	dptr,#_reactive_at
      004DE3 EC               [12]  810 	mov	a,r4
      004DE4 2A               [12]  811 	add	a, r2
      004DE5 F0               [24]  812 	movx	@dptr,a
      004DE6 ED               [12]  813 	mov	a,r5
      004DE7 3B               [12]  814 	addc	a, r3
      004DE8 A3               [24]  815 	inc	dptr
      004DE9 F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      004DEA 8E 04            [24]  818 	mov	ar4,r6
      004DEC 8F 05            [24]  819 	mov	ar5,r7
      004DEE C3               [12]  820 	clr	c
      004DEF 74 FF            [12]  821 	mov	a,#0xff
      004DF1 9C               [12]  822 	subb	a,r4
      004DF2 E4               [12]  823 	clr	a
      004DF3 9D               [12]  824 	subb	a,r5
      004DF4 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      004DF6 7D FF            [12]  827 	mov	r5,#0xff
      004DF8 80 02            [24]  828 	sjmp	00109$
      004DFA                        829 00108$:
      004DFA 8E 05            [24]  830 	mov	ar5,r6
      004DFC                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      004DFC 7F 00            [12]  833 	mov	r7,#0x00
      004DFE                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      004DFE EF               [12]  836 	mov	a,r7
      004DFF 24 B3            [12]  837 	add	a, #_reactive_age
      004E01 FC               [12]  838 	mov	r4,a
      004E02 E4               [12]  839 	clr	a
      004E03 34 06            [12]  840 	addc	a, #(_reactive_age >> 8)
      004E05 FE               [12]  841 	mov	r6,a
      004E06 8C 82            [24]  842 	mov	dpl,r4
      004E08 8E 83            [24]  843 	mov	dph,r6
      004E0A E0               [24]  844 	movx	a,@dptr
      004E0B FB               [12]  845 	mov	r3,a
      004E0C C3               [12]  846 	clr	c
      004E0D ED               [12]  847 	mov	a,r5
      004E0E 9B               [12]  848 	subb	a,r3
      004E0F 40 04            [24]  849 	jc	00110$
      004E11 7B 00            [12]  850 	mov	r3,#0x00
      004E13 80 08            [24]  851 	sjmp	00111$
      004E15                        852 00110$:
      004E15 8C 82            [24]  853 	mov	dpl,r4
      004E17 8E 83            [24]  854 	mov	dph,r6
      004E19 E0               [24]  855 	movx	a,@dptr
      004E1A C3               [12]  856 	clr	c
      004E1B 9D               [12]  857 	subb	a,r5
      004E1C FB               [12]  858 	mov	r3,a
      004E1D                        859 00111$:
      004E1D 8C 82            [24]  860 	mov	dpl,r4
      004E1F 8E 83            [24]  861 	mov	dph,r6
      004E21 EB               [12]  862 	mov	a,r3
      004E22 F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      004E23 0F               [12]  865 	inc	r7
      004E24 BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      004E27                        867 00144$:
      004E27 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      004E29 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      004E2A                        881 _add_sat:
      004E2A E5 82            [12]  882 	mov	a,dpl
      004E2C 90 07 08         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      004E2F F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      004E30 90 07 07         [24]  886 	mov	dptr,#_add_sat_PARM_2
      004E33 E0               [24]  887 	movx	a,@dptr
      004E34 FF               [12]  888 	mov	r7,a
      004E35 FE               [12]  889 	mov	r6,a
      004E36 74 FF            [12]  890 	mov	a,#0xff
      004E38 C3               [12]  891 	clr	c
      004E39 9E               [12]  892 	subb	a,r6
      004E3A FE               [12]  893 	mov	r6,a
      004E3B 90 07 08         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      004E3E E0               [24]  895 	movx	a,@dptr
      004E3F FD               [12]  896 	mov	r5,a
      004E40 C3               [12]  897 	clr	c
      004E41 EE               [12]  898 	mov	a,r6
      004E42 9D               [12]  899 	subb	a,r5
      004E43 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      004E45 7E FF            [12]  902 	mov	r6,#0xff
      004E47 80 03            [24]  903 	sjmp	00104$
      004E49                        904 00103$:
      004E49 EF               [12]  905 	mov	a,r7
      004E4A 2D               [12]  906 	add	a, r5
      004E4B FE               [12]  907 	mov	r6,a
      004E4C                        908 00104$:
      004E4C 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      004E4E 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      004E4F                        922 _sub_sat:
      004E4F E5 82            [12]  923 	mov	a,dpl
      004E51 90 07 0A         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      004E54 F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      004E55 E0               [24]  927 	movx	a,@dptr
      004E56 FF               [12]  928 	mov	r7,a
      004E57 90 07 09         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      004E5A E0               [24]  930 	movx	a,@dptr
      004E5B FE               [12]  931 	mov	r6,a
      004E5C C3               [12]  932 	clr	c
      004E5D EF               [12]  933 	mov	a,r7
      004E5E 9E               [12]  934 	subb	a,r6
      004E5F 50 04            [24]  935 	jnc	00103$
      004E61 7D 00            [12]  936 	mov	r5,#0x00
      004E63 80 04            [24]  937 	sjmp	00104$
      004E65                        938 00103$:
      004E65 EF               [12]  939 	mov	a,r7
      004E66 C3               [12]  940 	clr	c
      004E67 9E               [12]  941 	subb	a,r6
      004E68 FD               [12]  942 	mov	r5,a
      004E69                        943 00104$:
      004E69 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      004E6B 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      004E6C                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      004E6C D2 10            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      004E6E 12 47 86         [24]  959 	lcall	_timer_read
      004E71 12 38 62         [24]  960 	lcall	_ak820_outline_0126
      004E74 90 06 A6         [24]  961 	mov	dptr,#_changed_at
      004E77 12 55 64         [24]  962 	lcall	_ak820_outline_0156
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      004E7A 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      004E7B                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      004E7B 90 06 A5         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      004E7E E4               [12]  978 	clr	a
      004E7F F0               [24]  979 	movx	@dptr,a
      004E80 90 06 A4         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      004E83 F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      004E84 90 05 91         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004E87 12 55 47         [24]  984 	lcall	_ak820_outline_0076
      004E8A 90 05 94         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004E8D 12 55 3D         [24]  986 	lcall	_ak820_outline_0065
      004E90 12 41 DD         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      004E93 C2 10            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      004E95 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      004E96                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      004E96 12 55 78         [24] 1002 	lcall	_ak820_outline_0167
      004E99 12 55 3D         [24] 1003 	lcall	_ak820_outline_0065
      004E9C F5 F0            [12] 1004 	mov	b,a
      004E9E 12 B4 52         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      004EA1 12 55 57         [24] 1007 	lcall	_ak820_outline_0104
      004EA4 44 01            [12] 1008 	orl	a,#0x01
      004EA6 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      004EA7 12 55 36         [24] 1011 	lcall	_ak820_outline_0061
      004EAA 44 04            [12] 1012 	orl	a,#0x04
      004EAC F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      004EAD 90 06 9F         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      004EB0 E4               [12] 1016 	clr	a
      004EB1 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      004EB2 90 06 A0         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      004EB5 14               [12] 1020 	dec	a
      004EB6 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      004EB7 90 06 A1         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      004EBA 74 50            [12] 1024 	mov	a,#0x50
      004EBC F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      004EBD 90 06 A2         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      004EC0 74 60            [12] 1028 	mov	a,#0x60
      004EC2 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      004EC3 90 06 A3         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      004EC6 74 FF            [12] 1032 	mov	a,#0xff
      004EC8 F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      004EC9 02 4E 7B         [24] 1036 	ljmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      004ECC                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      004ECC 90 05 81         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004ECF 12 55 47         [24] 1047 	lcall	_ak820_outline_0076
      004ED2 90 05 84         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004ED5 12 55 3D         [24] 1049 	lcall	_ak820_outline_0065
      004ED8 12 40 6E         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      004EDB 12 55 57         [24] 1052 	lcall	_ak820_outline_0104
      004EDE 60 11            [24] 1053 	jz	00101$
      004EE0 12 55 17         [24] 1054 	lcall	_ak820_outline_0016
      004EE3 C3               [12] 1055 	clr	c
      004EE4 64 80            [12] 1056 	xrl	a,#0x80
      004EE6 94 87            [12] 1057 	subb	a,#0x87
      004EE8 50 07            [24] 1058 	jnc	00101$
      004EEA 12 55 36         [24] 1059 	lcall	_ak820_outline_0061
      004EED 24 FE            [12] 1060 	add	a,#0xff - 0x01
      004EEF 50 03            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      004EF1                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      004EF1 12 4E 96         [24] 1065 	lcall	_eeconfig_update_rgb_matrix_default
      004EF4                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      004EF4 90 06 A1         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      004EF7 E0               [24] 1069 	movx	a,@dptr
      004EF8 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      004EFA 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      004EFC 90 06 A1         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      004EFF 74 A0            [12] 1075 	mov	a,#0xa0
      004F01 F0               [24] 1076 	movx	@dptr,a
      004F02                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      004F02 C2 10            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      004F04 C2 11            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      004F06 02 4D 8F         [24] 1086 	ljmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      004F09                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      004F09 12 4E CC         [24] 1096 	lcall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      004F0C 12 47 86         [24] 1098 	lcall	_timer_read
      004F0F 12 43 1F         [24] 1099 	lcall	_ak820_outline_0123
      004F12 EE               [12] 1100 	mov	a,r6
      004F13 24 F0            [12] 1101 	add	a,#0xf0
      004F15 FE               [12] 1102 	mov	r6,a
      004F16 EF               [12] 1103 	mov	a,r7
      004F17 34 FF            [12] 1104 	addc	a,#0xff
      004F19 FF               [12] 1105 	mov	r7,a
      004F1A 90 06 A8         [24] 1106 	mov	dptr,#_frame_at
      004F1D 12 47 03         [24] 1107 	lcall	_ak820_outline_0055
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      004F20 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      004F21                       1122 _rgb_matrix_set_color:
      004F21 12 38 3C         [24] 1123 	lcall	_ak820_outline_0098
      004F24 90 07 0E         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      004F27 12 38 41         [24] 1125 	lcall	_ak820_outline_0099
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      004F2A 90 07 0E         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      004F2D 12 37 F9         [24] 1128 	lcall	_ak820_outline_0047
      004F30 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      004F33 C3               [12] 1130 	clr	c
      004F34 EE               [12] 1131 	mov	a,r6
      004F35 94 52            [12] 1132 	subb	a,#0x52
      004F37 EF               [12] 1133 	mov	a,r7
      004F38 64 80            [12] 1134 	xrl	a,#0x80
      004F3A 94 80            [12] 1135 	subb	a,#0x80
      004F3C 50 23            [24] 1136 	jnc	00104$
      004F3E 90 07 0B         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      004F41 E0               [24] 1138 	movx	a,@dptr
      004F42 FF               [12] 1139 	mov	r7,a
      004F43 90 07 0C         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      004F46 E0               [24] 1141 	movx	a,@dptr
      004F47 FD               [12] 1142 	mov	r5,a
      004F48 90 07 0D         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      004F4B E0               [24] 1144 	movx	a,@dptr
      004F4C FC               [12] 1145 	mov	r4,a
      004F4D 90 04 1A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      004F50 EF               [12] 1147 	mov	a,r7
      004F51 F0               [24] 1148 	movx	@dptr,a
      004F52 90 04 1B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      004F55 ED               [12] 1150 	mov	a,r5
      004F56 F0               [24] 1151 	movx	@dptr,a
      004F57 90 04 1C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      004F5A EC               [12] 1153 	mov	a,r4
      004F5B F0               [24] 1154 	movx	@dptr,a
      004F5C 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      004F5E 02 33 82         [24] 1157 	ljmp	_ak820_rgb_set_color
      004F61                       1158 00104$:
      004F61 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      004F62                       1171 _rgb_matrix_set_color_all:
      004F62 E5 82            [12] 1172 	mov	a,dpl
      004F64 90 07 12         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      004F67 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      004F68 E0               [24] 1176 	movx	a,@dptr
      004F69 FF               [12] 1177 	mov	r7,a
      004F6A 90 07 10         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      004F6D E0               [24] 1179 	movx	a,@dptr
      004F6E FE               [12] 1180 	mov	r6,a
      004F6F 90 07 11         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      004F72 E0               [24] 1182 	movx	a,@dptr
      004F73 FD               [12] 1183 	mov	r5,a
      004F74 90 04 1E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      004F77 EE               [12] 1185 	mov	a,r6
      004F78 F0               [24] 1186 	movx	@dptr,a
      004F79 90 04 1F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      004F7C ED               [12] 1188 	mov	a,r5
      004F7D F0               [24] 1189 	movx	@dptr,a
      004F7E 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      004F80 02 33 B9         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      004F83                       1206 _sine8:
      004F83 E5 82            [12] 1207 	mov	a,dpl
      004F85 90 07 13         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      004F88 F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      004F89 E0               [24] 1211 	movx	a,@dptr
      004F8A FF               [12] 1212 	mov	r7,a
      004F8B 90 07 14         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      004F8E F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      004F8F EF               [12] 1216 	mov	a,r7
      004F90 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      004F93 90 07 14         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      004F96 74 FF            [12] 1219 	mov	a,#0xff
      004F98 C3               [12] 1220 	clr	c
      004F99 9F               [12] 1221 	subb	a,r7
      004F9A F0               [24] 1222 	movx	@dptr,a
      004F9B                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      004F9B 90 07 14         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      004F9E E0               [24] 1226 	movx	a,@dptr
      004F9F 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      004FA2 F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      004FA3 90 07 14         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      004FA6 E0               [24] 1231 	movx	a,@dptr
      004FA7 54 0F            [12] 1232 	anl	a,#0x0f
      004FA9 FF               [12] 1233 	mov	r7,a
      004FAA 90 07 15         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      004FAD F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      004FAE 90 07 13         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      004FB1 E0               [24] 1238 	movx	a,@dptr
      004FB2 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      004FB5 90 07 15         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      004FB8 EF               [12] 1241 	mov	a,r7
      004FB9 04               [12] 1242 	inc	a
      004FBA F0               [24] 1243 	movx	@dptr,a
      004FBB                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      004FBB 90 07 14         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      004FBE E0               [24] 1247 	movx	a,@dptr
      004FBF C4               [12] 1248 	swap	a
      004FC0 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      004FC2 25 E0            [12] 1251 	add	a,acc
      004FC4 FF               [12] 1252 	mov	r7,a
      004FC5 90 B5 37         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      004FC8 93               [24] 1254 	movc	a,@a+dptr
      004FC9 FE               [12] 1255 	mov	r6,a
      004FCA 0F               [12] 1256 	inc	r7
      004FCB EF               [12] 1257 	mov	a,r7
      004FCC 90 B5 37         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      004FCF 93               [24] 1259 	movc	a,@a+dptr
      004FD0 FF               [12] 1260 	mov	r7,a
      004FD1 90 07 15         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      004FD4 E0               [24] 1262 	movx	a,@dptr
      004FD5 8F F0            [24] 1263 	mov	b,r7
      004FD7 A4               [48] 1264 	mul	ab
      004FD8 FF               [12] 1265 	mov	r7,a
      004FD9 E5 F0            [12] 1266 	mov	a,b
      004FDB C4               [12] 1267 	swap	a
      004FDC CF               [12] 1268 	xch	a,r7
      004FDD C4               [12] 1269 	swap	a
      004FDE 54 0F            [12] 1270 	anl	a,#0x0f
      004FE0 6F               [12] 1271 	xrl	a,r7
      004FE1 CF               [12] 1272 	xch	a,r7
      004FE2 54 0F            [12] 1273 	anl	a,#0x0f
      004FE4 CF               [12] 1274 	xch	a,r7
      004FE5 6F               [12] 1275 	xrl	a,r7
      004FE6 CF               [12] 1276 	xch	a,r7
      004FE7 EF               [12] 1277 	mov	a,r7
      004FE8 2E               [12] 1278 	add	a, r6
      004FE9 FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      004FEA 90 07 13         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      004FED E0               [24] 1282 	movx	a,@dptr
      004FEE 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      004FF1 8F 06            [24] 1284 	mov	ar6,r7
      004FF3 74 80            [12] 1285 	mov	a,#0x80
      004FF5 C3               [12] 1286 	clr	c
      004FF6 9E               [12] 1287 	subb	a,r6
      004FF7 FE               [12] 1288 	mov	r6,a
      004FF8 80 04            [24] 1289 	sjmp	00108$
      004FFA                       1290 00107$:
      004FFA 74 80            [12] 1291 	mov	a,#0x80
      004FFC 2F               [12] 1292 	add	a, r7
      004FFD FE               [12] 1293 	mov	r6,a
      004FFE                       1294 00108$:
      004FFE 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      005000 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      005001                       1312 _breathing_cie:
      005001 E5 82            [12] 1313 	mov	a,dpl
      005003 90 07 16         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      005006 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      005007 E0               [24] 1317 	movx	a,@dptr
      005008 FF               [12] 1318 	mov	r7,a
      005009 12 55 86         [24] 1319 	lcall	_ak820_outline_0174
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      00500C FE               [12] 1321 	mov	r6,a
      00500D 90 B8 43         [24] 1322 	mov	dptr,#_CIE1931_CURVE
      005010 93               [24] 1323 	movc	a,@a+dptr
      005011 FD               [12] 1324 	mov	r5,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      005012 BE 1F 03         [24] 1326 	cjne	r6,#0x1f,00102$
      005015 8D 82            [24] 1327 	mov	dpl, r5
      005017 22               [24] 1328 	ret
      005018                       1329 00102$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      005018 EE               [12] 1331 	mov	a,r6
      005019 04               [12] 1332 	inc	a
      00501A 90 B8 43         [24] 1333 	mov	dptr,#_CIE1931_CURVE
      00501D 93               [24] 1334 	movc	a,@a+dptr
      00501E C3               [12] 1335 	clr	c
      00501F 9D               [12] 1336 	subb	a,r5
      005020 FE               [12] 1337 	mov	r6,a
                                   1338 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      005021 74 07            [12] 1339 	mov	a,#0x07
      005023 5F               [12] 1340 	anl	a,r7
                                   1341 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      005024 F5 F0            [12] 1342 	mov	b,a
      005026 EE               [12] 1343 	mov	a,r6
      005027 A4               [48] 1344 	mul	ab
                                   1345 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      005028 12 55 86         [24] 1346 	lcall	_ak820_outline_0174
      00502B 2D               [12] 1347 	add	a, r5
                                   1348 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      00502C F5 82            [12] 1349 	mov	dpl,a
      00502E 22               [24] 1350 	ret
                                   1351 ;------------------------------------------------------------
                                   1352 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1353 ;------------------------------------------------------------
                                   1354 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1355 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1356 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1357 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1358 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1359 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1360 ;------------------------------------------------------------
                                   1361 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1362 ;	-----------------------------------------
                                   1363 ;	 function rgb_matrix_task
                                   1364 ;	-----------------------------------------
      00502F                       1365 _rgb_matrix_task:
                                   1366 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      00502F 12 4D AC         [24] 1367 	lcall	_age_reactive
                                   1368 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      005032 30 10 18         [24] 1369 	jnb	_dirty,00102$
      005035 90 06 A6         [24] 1370 	mov	dptr,#_changed_at
      005038 12 37 A2         [24] 1371 	lcall	_ak820_outline_0004
      00503B 12 47 89         [24] 1372 	lcall	_timer_elapsed
      00503E 12 43 1F         [24] 1373 	lcall	_ak820_outline_0123
      005041 C3               [12] 1374 	clr	c
      005042 EE               [12] 1375 	mov	a,r6
      005043 94 E8            [12] 1376 	subb	a,#0xe8
      005045 EF               [12] 1377 	mov	a,r7
      005046 94 03            [12] 1378 	subb	a,#0x03
      005048 40 03            [24] 1379 	jc	00102$
      00504A 12 4E 7B         [24] 1380 	lcall	_eeconfig_update_rgb_matrix
      00504D                       1381 00102$:
                                   1382 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      00504D 30 11 03         [24] 1383 	jnb	_rendering,00254$
      005050 02 51 08         [24] 1384 	ljmp	00109$
      005053                       1385 00254$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      005053 90 06 A8         [24] 1387 	mov	dptr,#_frame_at
      005056 12 37 A2         [24] 1388 	lcall	_ak820_outline_0004
      005059 12 47 89         [24] 1389 	lcall	_timer_elapsed
      00505C 12 43 1F         [24] 1390 	lcall	_ak820_outline_0123
      00505F C3               [12] 1391 	clr	c
      005060 EE               [12] 1392 	mov	a,r6
      005061 94 10            [12] 1393 	subb	a,#0x10
      005063 EF               [12] 1394 	mov	a,r7
      005064 94 00            [12] 1395 	subb	a,#0x00
      005066 50 01            [24] 1396 	jnc	00105$
      005068 22               [24] 1397 	ret
      005069                       1398 00105$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      005069 12 47 86         [24] 1400 	lcall	_timer_read
      00506C 12 38 62         [24] 1401 	lcall	_ak820_outline_0126
      00506F 90 06 A8         [24] 1402 	mov	dptr,#_frame_at
      005072 12 55 64         [24] 1403 	lcall	_ak820_outline_0156
                                   1404 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      005075 90 06 A2         [24] 1405 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005078 E0               [24] 1406 	movx	a,@dptr
      005079 FF               [12] 1407 	mov	r7,a
      00507A 7E 00            [12] 1408 	mov	r6,#0x00
      00507C 74 20            [12] 1409 	mov	a,#0x20
      00507E 2F               [12] 1410 	add	a, r7
      00507F FF               [12] 1411 	mov	r7,a
      005080 E4               [12] 1412 	clr	a
      005081 3E               [12] 1413 	addc	a, r6
      005082 FE               [12] 1414 	mov	r6,a
      005083 90 06 AA         [24] 1415 	mov	dptr,#_phase
      005086 12 38 18         [24] 1416 	lcall	_ak820_outline_0056
      005089 EF               [12] 1417 	mov	a,r7
      00508A 2C               [12] 1418 	add	a, r4
      00508B FF               [12] 1419 	mov	r7,a
      00508C EE               [12] 1420 	mov	a,r6
      00508D 3D               [12] 1421 	addc	a, r5
      00508E FE               [12] 1422 	mov	r6,a
      00508F 90 06 AA         [24] 1423 	mov	dptr,#_phase
      005092 EF               [12] 1424 	mov	a,r7
      005093 F0               [24] 1425 	movx	@dptr,a
      005094 EE               [12] 1426 	mov	a,r6
      005095 A3               [24] 1427 	inc	dptr
      005096 F0               [24] 1428 	movx	@dptr,a
                                   1429 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      005097 90 06 AA         [24] 1430 	mov	dptr,#_phase
      00509A E0               [24] 1431 	movx	a,@dptr
      00509B A3               [24] 1432 	inc	dptr
      00509C E0               [24] 1433 	movx	a,@dptr
      00509D FF               [12] 1434 	mov	r7,a
      00509E 90 06 B2         [24] 1435 	mov	dptr,#_frame_phase
      0050A1 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      0050A2 20 0F 05         [24] 1438 	jb	_suspended,00135$
      0050A5 12 55 36         [24] 1439 	lcall	_ak820_outline_0061
      0050A8 70 04            [24] 1440 	jnz	00132$
      0050AA                       1441 00135$:
      0050AA 7E 00            [12] 1442 	mov	r6,#0x00
      0050AC 80 04            [24] 1443 	sjmp	00133$
      0050AE                       1444 00132$:
      0050AE 12 55 17         [24] 1445 	lcall	_ak820_outline_0016
      0050B1 FE               [12] 1446 	mov	r6,a
      0050B2                       1447 00133$:
      0050B2 90 06 AD         [24] 1448 	mov	dptr,#_frame_mode
      0050B5 EE               [12] 1449 	mov	a,r6
      0050B6 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      0050B7 90 06 9F         [24] 1452 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0050BA E0               [24] 1453 	movx	a,@dptr
      0050BB 90 06 AE         [24] 1454 	mov	dptr,#_frame_hue
      0050BE F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      0050BF 90 06 A0         [24] 1457 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0050C2 E0               [24] 1458 	movx	a,@dptr
      0050C3 90 06 AF         [24] 1459 	mov	dptr,#_frame_sat
      0050C6 F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      0050C7 90 06 A1         [24] 1462 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0050CA E0               [24] 1463 	movx	a,@dptr
      0050CB FD               [12] 1464 	mov	r5,a
      0050CC 90 06 B0         [24] 1465 	mov	dptr,#_frame_val
      0050CF F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      0050D0 90 06 A3         [24] 1468 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      0050D3 E0               [24] 1469 	movx	a,@dptr
      0050D4 90 06 B1         [24] 1470 	mov	dptr,#_frame_flags
      0050D7 F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      0050D8 BE 02 26         [24] 1473 	cjne	r6,#0x02,00107$
                                   1474 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      0050DB EF               [12] 1475 	mov	a,r7
      0050DC 24 C0            [12] 1476 	add	a,#0xc0
      0050DE F5 82            [12] 1477 	mov	dpl,a
      0050E0 C0 05            [24] 1478 	push	ar5
      0050E2 12 4F 83         [24] 1479 	lcall	_sine8
      0050E5 AF 82            [24] 1480 	mov	r7, dpl
      0050E7 D0 05            [24] 1481 	pop	ar5
      0050E9 8D F0            [24] 1482 	mov	b,r5
      0050EB EF               [12] 1483 	mov	a,r7
      0050EC A4               [48] 1484 	mul	ab
      0050ED AE F0            [24] 1485 	mov	r6,b
      0050EF 8E 05            [24] 1486 	mov	ar5,r6
      0050F1 90 06 B0         [24] 1487 	mov	dptr,#_frame_val
      0050F4 ED               [12] 1488 	mov	a,r5
      0050F5 F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      0050F6 8D 82            [24] 1491 	mov	dpl, r5
      0050F8 12 50 01         [24] 1492 	lcall	_breathing_cie
      0050FB E5 82            [12] 1493 	mov	a, dpl
      0050FD 90 06 B0         [24] 1494 	mov	dptr,#_frame_val
      005100 F0               [24] 1495 	movx	@dptr,a
      005101                       1496 00107$:
                                   1497 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      005101 90 06 AC         [24] 1498 	mov	dptr,#_led_index
      005104 E4               [12] 1499 	clr	a
      005105 F0               [24] 1500 	movx	@dptr,a
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1502 ;	assignBit
      005106 D2 11            [12] 1503 	setb	_rendering
      005108                       1504 00109$:
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      005108 12 55 81         [24] 1506 	lcall	_ak820_outline_0173
      00510B 24 08            [12] 1507 	add	a,#0x08
      00510D FF               [12] 1508 	mov	r7,a
      00510E 90 07 17         [24] 1509 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005111 F0               [24] 1510 	movx	@dptr,a
                                   1511 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      005112 EF               [12] 1512 	mov	a,r7
      005113 24 AD            [12] 1513 	add	a,#0xff - 0x52
      005115 50 06            [24] 1514 	jnc	00125$
                                   1515 ;	free result
      005117 90 07 17         [24] 1516 	mov	dptr,#_rgb_matrix_task_end_10000_298
      00511A 74 52            [12] 1517 	mov	a,#0x52
      00511C F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      00511D                       1520 00125$:
      00511D 12 55 81         [24] 1521 	lcall	_ak820_outline_0173
      005120 FF               [12] 1522 	mov	r7,a
      005121 90 07 17         [24] 1523 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005124 E0               [24] 1524 	movx	a,@dptr
      005125 FE               [12] 1525 	mov	r6,a
      005126 C3               [12] 1526 	clr	c
      005127 EF               [12] 1527 	mov	a,r7
      005128 9E               [12] 1528 	subb	a,r6
      005129 40 03            [24] 1529 	jc	00261$
      00512B 02 52 9F         [24] 1530 	ljmp	00127$
      00512E                       1531 00261$:
                                   1532 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      00512E 12 55 5E         [24] 1533 	lcall	_ak820_outline_0128
      005131 E0               [24] 1534 	movx	a,@dptr
      005132 60 07            [24] 1535 	jz	00121$
      005134 90 06 B1         [24] 1536 	mov	dptr,#_frame_flags
      005137 E0               [24] 1537 	movx	a,@dptr
      005138 20 E2 1C         [24] 1538 	jb	acc.2,00122$
      00513B                       1539 00121$:
                                   1540 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      00513B 12 55 81         [24] 1541 	lcall	_ak820_outline_0173
      00513E FC               [12] 1542 	mov	r4,a
      00513F 7D 00            [12] 1543 	mov	r5,#0x00
      005141 90 07 0B         [24] 1544 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005144 E4               [12] 1545 	clr	a
      005145 F0               [24] 1546 	movx	@dptr,a
      005146 90 07 0C         [24] 1547 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      005149 F0               [24] 1548 	movx	@dptr,a
      00514A 90 07 0D         [24] 1549 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      00514D F0               [24] 1550 	movx	@dptr,a
      00514E 12 38 4D         [24] 1551 	lcall	_ak820_outline_0110
      005151 12 4F 21         [24] 1552 	lcall	_rgb_matrix_set_color
      005154 02 52 96         [24] 1553 	ljmp	00123$
      005157                       1554 00122$:
                                   1555 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      005157 BE 05 29         [24] 1556 	cjne	r6,#0x05,00119$
                                   1557 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      00515A EF               [12] 1558 	mov	a,r7
      00515B 75 F0 03         [24] 1559 	mov	b,#0x03
      00515E A4               [48] 1560 	mul	ab
      00515F 24 53            [12] 1561 	add	a, #_g_direct_mode_colors
      005161 FD               [12] 1562 	mov	r5,a
      005162 74 0C            [12] 1563 	mov	a,#(_g_direct_mode_colors >> 8)
      005164 35 F0            [12] 1564 	addc	a, b
      005166 FE               [12] 1565 	mov	r6,a
      005167 90 0D 67         [24] 1566 	mov	dptr,#___memcpy_PARM_2
      00516A ED               [12] 1567 	mov	a,r5
      00516B F0               [24] 1568 	movx	@dptr,a
      00516C EE               [12] 1569 	mov	a,r6
      00516D 12 38 1E         [24] 1570 	lcall	_ak820_outline_0067
      005170 90 0D 6A         [24] 1571 	mov	dptr,#___memcpy_PARM_3
      005173 74 03            [12] 1572 	mov	a,#0x03
      005175 12 38 58         [24] 1573 	lcall	_ak820_outline_0114
      005178 90 07 18         [24] 1574 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00517B F5 F0            [12] 1575 	mov	b,a
      00517D 12 B3 DC         [24] 1576 	lcall	___memcpy
      005180 02 52 32         [24] 1577 	ljmp	00120$
      005183                       1578 00119$:
                                   1579 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      005183 90 06 AE         [24] 1580 	mov	dptr,#_frame_hue
      005186 E0               [24] 1581 	movx	a,@dptr
      005187 90 07 18         [24] 1582 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00518A F0               [24] 1583 	movx	@dptr,a
                                   1584 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      00518B 90 06 AF         [24] 1585 	mov	dptr,#_frame_sat
      00518E E0               [24] 1586 	movx	a,@dptr
      00518F 90 07 19         [24] 1587 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      005192 F0               [24] 1588 	movx	@dptr,a
                                   1589 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      005193 90 06 B0         [24] 1590 	mov	dptr,#_frame_val
      005196 E0               [24] 1591 	movx	a,@dptr
      005197 90 07 1A         [24] 1592 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      00519A F0               [24] 1593 	movx	@dptr,a
                                   1594 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      00519B 12 55 5E         [24] 1595 	lcall	_ak820_outline_0128
      00519E BE 03 0E         [24] 1596 	cjne	r6,#0x03,00113$
      0051A1 90 07 18         [24] 1597 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0051A4 E0               [24] 1598 	movx	a,@dptr
      0051A5 FE               [12] 1599 	mov	r6,a
      0051A6 90 06 B2         [24] 1600 	mov	dptr,#_frame_phase
      0051A9 E0               [24] 1601 	movx	a,@dptr
      0051AA 2E               [12] 1602 	add	a, r6
      0051AB 90 07 18         [24] 1603 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0051AE F0               [24] 1604 	movx	@dptr,a
      0051AF                       1605 00113$:
                                   1606 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      0051AF 12 55 5E         [24] 1607 	lcall	_ak820_outline_0128
      0051B2 BE 04 23         [24] 1608 	cjne	r6,#0x04,00115$
      0051B5 90 07 18         [24] 1609 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0051B8 E0               [24] 1610 	movx	a,@dptr
      0051B9 FE               [12] 1611 	mov	r6,a
      0051BA 12 55 81         [24] 1612 	lcall	_ak820_outline_0173
      0051BD 75 F0 02         [24] 1613 	mov	b,#0x02
      0051C0 A4               [48] 1614 	mul	ab
      0051C1 24 9F            [12] 1615 	add	a, #_ak820_led_points
      0051C3 F5 82            [12] 1616 	mov	dpl,a
      0051C5 74 B7            [12] 1617 	mov	a,#(_ak820_led_points >> 8)
      0051C7 12 55 50         [24] 1618 	lcall	_ak820_outline_0100
      0051CA FD               [12] 1619 	mov	r5,a
      0051CB 90 06 B2         [24] 1620 	mov	dptr,#_frame_phase
      0051CE E0               [24] 1621 	movx	a,@dptr
      0051CF FC               [12] 1622 	mov	r4,a
      0051D0 ED               [12] 1623 	mov	a,r5
      0051D1 C3               [12] 1624 	clr	c
      0051D2 9C               [12] 1625 	subb	a,r4
      0051D3 2E               [12] 1626 	add	a, r6
      0051D4 90 07 18         [24] 1627 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0051D7 F0               [24] 1628 	movx	@dptr,a
      0051D8                       1629 00115$:
                                   1630 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      0051D8 12 55 5E         [24] 1631 	lcall	_ak820_outline_0128
      0051DB BE 06 54         [24] 1632 	cjne	r6,#0x06,00120$
                                   1633 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      0051DE 12 55 6F         [24] 1634 	lcall	_ak820_outline_0161
      0051E1 FE               [12] 1635 	mov	r6,a
      0051E2 74 07            [12] 1636 	mov	a,#0x07
      0051E4 C3               [12] 1637 	clr	c
      0051E5 9E               [12] 1638 	subb	a,r6
      0051E6 FE               [12] 1639 	mov	r6,a
                                   1640 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      0051E7 8E F0            [24] 1641 	mov	b,r6
      0051E9 05 F0            [12] 1642 	inc	b
      0051EB 74 01            [12] 1643 	mov	a,#0x01
      0051ED 80 02            [24] 1644 	sjmp	00273$
      0051EF                       1645 00272$:
      0051EF 25 E0            [12] 1646 	add	a,acc
      0051F1                       1647 00273$:
      0051F1 D5 F0 FB         [24] 1648 	djnz	b,00272$
      0051F4 FD               [12] 1649 	mov	r5,a
                                   1650 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      0051F5 12 55 81         [24] 1651 	lcall	_ak820_outline_0173
      0051F8 24 B3            [12] 1652 	add	a, #_reactive_age
      0051FA F5 82            [12] 1653 	mov	dpl,a
      0051FC E4               [12] 1654 	clr	a
      0051FD 34 06            [12] 1655 	addc	a, #(_reactive_age >> 8)
      0051FF F5 83            [12] 1656 	mov	dph,a
      005201 E0               [24] 1657 	movx	a,@dptr
                                   1658 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      005202 FC               [12] 1659 	mov	r4,a
      005203 C3               [12] 1660 	clr	c
      005204 9D               [12] 1661 	subb	a,r5
      005205 40 07            [24] 1662 	jc	00137$
      005207 90 06 B0         [24] 1663 	mov	dptr,#_frame_val
      00520A E0               [24] 1664 	movx	a,@dptr
      00520B FB               [12] 1665 	mov	r3,a
      00520C 80 1F            [24] 1666 	sjmp	00138$
      00520E                       1667 00137$:
      00520E 90 06 B0         [24] 1668 	mov	dptr,#_frame_val
      005211 E0               [24] 1669 	movx	a,@dptr
      005212 F5 F0            [12] 1670 	mov	b, a
      005214 EC               [12] 1671 	mov	a,r4
      005215 A4               [48] 1672 	mul	ab
      005216 FC               [12] 1673 	mov	r4,a
      005217 AA F0            [24] 1674 	mov	r2,b
      005219 8E F0            [24] 1675 	mov	b,r6
      00521B 05 F0            [12] 1676 	inc	b
      00521D AB 04            [24] 1677 	mov	r3,ar4
      00521F AD 02            [24] 1678 	mov	r5,ar2
      005221 80 07            [24] 1679 	sjmp	00276$
      005223                       1680 00275$:
      005223 C3               [12] 1681 	clr	c
      005224 ED               [12] 1682 	mov	a,r5
      005225 13               [12] 1683 	rrc	a
      005226 FD               [12] 1684 	mov	r5,a
      005227 EB               [12] 1685 	mov	a,r3
      005228 13               [12] 1686 	rrc	a
      005229 FB               [12] 1687 	mov	r3,a
      00522A                       1688 00276$:
      00522A D5 F0 F6         [24] 1689 	djnz	b,00275$
      00522D                       1690 00138$:
      00522D 90 07 1A         [24] 1691 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      005230 EB               [12] 1692 	mov	a,r3
      005231 F0               [24] 1693 	movx	@dptr,a
      005232                       1694 00120$:
                                   1695 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      005232 12 55 5E         [24] 1696 	lcall	_ak820_outline_0128
      005235 BE 02 03         [24] 1697 	cjne	r6,#0x02,00277$
      005238 D3               [12] 1698 	setb	c
      005239 80 01            [24] 1699 	sjmp	00278$
      00523B                       1700 00277$:
      00523B C3               [12] 1701 	clr	c
      00523C                       1702 00278$:
      00523C B3               [12] 1703 	cpl	c
      00523D 92 12            [24] 1704 	mov	_rgb_matrix_task_sloc0_1_0,c
      00523F 90 0D 67         [24] 1705 	mov	dptr,#___memcpy_PARM_2
      005242 74 18            [12] 1706 	mov	a,#_rgb_matrix_task_hsv_10000_298
      005244 F0               [24] 1707 	movx	@dptr,a
      005245 74 07            [12] 1708 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      005247 12 38 1E         [24] 1709 	lcall	_ak820_outline_0067
      00524A 90 0D 6A         [24] 1710 	mov	dptr,#___memcpy_PARM_3
      00524D 74 03            [12] 1711 	mov	a,#0x03
      00524F 12 38 58         [24] 1712 	lcall	_ak820_outline_0114
      005252 90 0A B0         [24] 1713 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      005255 F5 F0            [12] 1714 	mov	b,a
      005257 12 B3 DC         [24] 1715 	lcall	___memcpy
      00525A 90 0A B3         [24] 1716 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      00525D 74 1B            [12] 1717 	mov	a,#_rgb_matrix_task_rgb_10000_298
      00525F F0               [24] 1718 	movx	@dptr,a
      005260 74 07            [12] 1719 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      005262 A3               [24] 1720 	inc	dptr
      005263 F0               [24] 1721 	movx	@dptr,a
      005264 A2 12            [12] 1722 	mov	c,_rgb_matrix_task_sloc0_1_0
      005266 12 38 79         [24] 1723 	lcall	_ak820_outline_0158
      005269 12 7E 5A         [24] 1724 	lcall	_hsv_to_rgb_into
                                   1725 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      00526C 12 55 81         [24] 1726 	lcall	_ak820_outline_0173
      00526F FD               [12] 1727 	mov	r5,a
      005270 7E 00            [12] 1728 	mov	r6,#0x00
      005272 90 07 1C         [24] 1729 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      005275 E0               [24] 1730 	movx	a,@dptr
      005276 FC               [12] 1731 	mov	r4,a
      005277 90 07 1B         [24] 1732 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      00527A E0               [24] 1733 	movx	a,@dptr
      00527B FB               [12] 1734 	mov	r3,a
      00527C 90 07 1D         [24] 1735 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      00527F E0               [24] 1736 	movx	a,@dptr
      005280 FA               [12] 1737 	mov	r2,a
      005281 90 07 0B         [24] 1738 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005284 EC               [12] 1739 	mov	a,r4
      005285 F0               [24] 1740 	movx	@dptr,a
      005286 90 07 0C         [24] 1741 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      005289 EB               [12] 1742 	mov	a,r3
      00528A F0               [24] 1743 	movx	@dptr,a
      00528B 90 07 0D         [24] 1744 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      00528E EA               [12] 1745 	mov	a,r2
      00528F F0               [24] 1746 	movx	@dptr,a
      005290 12 38 5D         [24] 1747 	lcall	_ak820_outline_0122
      005293 12 4F 21         [24] 1748 	lcall	_rgb_matrix_set_color
      005296                       1749 00123$:
                                   1750 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      005296 12 55 81         [24] 1751 	lcall	_ak820_outline_0173
      005299 24 01            [12] 1752 	add	a, #0x01
      00529B F0               [24] 1753 	movx	@dptr,a
      00529C 02 51 1D         [24] 1754 	ljmp	00125$
      00529F                       1755 00127$:
                                   1756 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      00529F BF 52 02         [24] 1757 	cjne	r7,#0x52,00130$
                                   1758 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1759 ;	assignBit
      0052A2 C2 11            [12] 1760 	clr	_rendering
      0052A4                       1761 00130$:
                                   1762 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      0052A4 22               [24] 1763 	ret
                                   1764 ;------------------------------------------------------------
                                   1765 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1766 ;------------------------------------------------------------
                                   1767 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1768 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1769 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1770 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1771 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1772 ;------------------------------------------------------------
                                   1773 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1774 ;	-----------------------------------------
                                   1775 ;	 function process_rgb_matrix
                                   1776 ;	-----------------------------------------
      0052A5                       1777 _process_rgb_matrix:
      0052A5 E5 82            [12] 1778 	mov	a,dpl
      0052A7 90 07 20         [24] 1779 	mov	dptr,#_process_rgb_matrix_row_10000_319
      0052AA F0               [24] 1780 	movx	@dptr,a
                                   1781 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      0052AB 90 07 1F         [24] 1782 	mov	dptr,#_process_rgb_matrix_PARM_3
      0052AE E0               [24] 1783 	movx	a,@dptr
      0052AF 60 23            [24] 1784 	jz	00101$
      0052B1 20 0F 20         [24] 1785 	jb	_suspended,00101$
      0052B4 12 55 36         [24] 1786 	lcall	_ak820_outline_0061
      0052B7 60 1B            [24] 1787 	jz	00101$
                                   1788 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      0052B9 12 55 17         [24] 1789 	lcall	_ak820_outline_0016
      0052BC FF               [12] 1790 	mov	r7,a
      0052BD BF 06 14         [24] 1791 	cjne	r7,#0x06,00101$
      0052C0 90 07 20         [24] 1792 	mov	dptr,#_process_rgb_matrix_row_10000_319
      0052C3 E0               [24] 1793 	movx	a,@dptr
      0052C4 FF               [12] 1794 	mov	r7,a
      0052C5 BF 10 00         [24] 1795 	cjne	r7,#0x10,00169$
      0052C8                       1796 00169$:
      0052C8 50 0A            [24] 1797 	jnc	00101$
      0052CA 90 07 1E         [24] 1798 	mov	dptr,#_process_rgb_matrix_PARM_2
      0052CD E0               [24] 1799 	movx	a,@dptr
      0052CE FE               [12] 1800 	mov	r6,a
      0052CF BE 08 00         [24] 1801 	cjne	r6,#0x08,00171$
      0052D2                       1802 00171$:
      0052D2 40 01            [24] 1803 	jc	00102$
      0052D4                       1804 00101$:
      0052D4 22               [24] 1805 	ret
      0052D5                       1806 00102$:
                                   1807 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      0052D5 C0 07            [24] 1808 	push	ar7
      0052D7 C0 06            [24] 1809 	push	ar6
      0052D9 12 4D AC         [24] 1810 	lcall	_age_reactive
      0052DC D0 06            [24] 1811 	pop	ar6
      0052DE D0 07            [24] 1812 	pop	ar7
                                   1813 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      0052E0 EF               [12] 1814 	mov	a,r7
      0052E1 12 38 83         [24] 1815 	lcall	_ak820_outline_0176
      0052E4 2E               [12] 1816 	add	a,r6
      0052E5 FF               [12] 1817 	mov	r7,a
                                   1818 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0052E6 7E 00            [12] 1819 	mov	r6,#0x00
      0052E8                       1820 00111$:
                                   1821 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      0052E8 EE               [12] 1822 	mov	a,r6
      0052E9 90 B4 E5         [24] 1823 	mov	dptr,#_ak820_rgb_slots
      0052EC 93               [24] 1824 	movc	a,@a+dptr
      0052ED B5 07 29         [24] 1825 	cjne	a,ar7,00112$
                                   1826 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      0052F0 EE               [12] 1827 	mov	a,r6
      0052F1 24 B3            [12] 1828 	add	a, #_reactive_age
      0052F3 FC               [12] 1829 	mov	r4,a
      0052F4 E4               [12] 1830 	clr	a
      0052F5 34 06            [12] 1831 	addc	a, #(_reactive_age >> 8)
      0052F7 FD               [12] 1832 	mov	r5,a
      0052F8 12 55 6F         [24] 1833 	lcall	_ak820_outline_0161
      0052FB F5 F0            [12] 1834 	mov	b, a
      0052FD 05 F0            [12] 1835 	inc	b
      0052FF 7B 80            [12] 1836 	mov	r3,#0x80
      005301 E4               [12] 1837 	clr	a
      005302 FA               [12] 1838 	mov	r2,a
      005303 33               [12] 1839 	rlc	a
      005304 92 D2            [24] 1840 	mov	ov,c
      005306 80 08            [24] 1841 	sjmp	00176$
      005308                       1842 00175$:
      005308 A2 D2            [12] 1843 	mov	c,ov
      00530A EA               [12] 1844 	mov	a,r2
      00530B 13               [12] 1845 	rrc	a
      00530C FA               [12] 1846 	mov	r2,a
      00530D EB               [12] 1847 	mov	a,r3
      00530E 13               [12] 1848 	rrc	a
      00530F FB               [12] 1849 	mov	r3,a
      005310                       1850 00176$:
      005310 D5 F0 F5         [24] 1851 	djnz	b,00175$
      005313 12 38 4D         [24] 1852 	lcall	_ak820_outline_0110
      005316 EB               [12] 1853 	mov	a,r3
      005317 F0               [24] 1854 	movx	@dptr,a
                                   1855 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      005318 22               [24] 1856 	ret
      005319                       1857 00112$:
                                   1858 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005319 0E               [12] 1859 	inc	r6
      00531A BE 52 00         [24] 1860 	cjne	r6,#0x52,00177$
      00531D                       1861 00177$:
      00531D 40 C9            [24] 1862 	jc	00111$
                                   1863 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      00531F 22               [24] 1864 	ret
                                   1865 ;------------------------------------------------------------
                                   1866 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1867 ;------------------------------------------------------------
                                   1868 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1869 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1870 ;------------------------------------------------------------
                                   1871 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1872 ;	-----------------------------------------
                                   1873 ;	 function rgb_matrix_set_suspend_state
                                   1874 ;	-----------------------------------------
      005320                       1875 _rgb_matrix_set_suspend_state:
      005320 E5 82            [12] 1876 	mov	a,dpl
      005322 90 07 21         [24] 1877 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      005325 F0               [24] 1878 	movx	@dptr,a
                                   1879 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      005326 E0               [24] 1880 	movx	a,@dptr
                                   1881 ;	assignBit
      005327 F5 15            [12] 1882 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      005329 13               [12] 1883 	rrc	a
      00532A 92 0F            [24] 1884 	mov	_suspended,c
                                   1885 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1886 ;	assignBit
      00532C C2 11            [12] 1887 	clr	_rendering
                                   1888 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      00532E 12 4D 8F         [24] 1889 	lcall	_clear_reactive
                                   1890 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      005331 E5 15            [12] 1891 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      005333 60 0F            [24] 1892 	jz	00103$
                                   1893 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      005335 90 07 10         [24] 1894 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      005338 E4               [12] 1895 	clr	a
      005339 F0               [24] 1896 	movx	@dptr,a
      00533A 90 07 11         [24] 1897 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      00533D F0               [24] 1898 	movx	@dptr,a
      00533E 75 82 00         [24] 1899 	mov	dpl, #0x00
                                   1900 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      005341 02 4F 62         [24] 1901 	ljmp	_rgb_matrix_set_color_all
      005344                       1902 00103$:
      005344 22               [24] 1903 	ret
                                   1904 ;------------------------------------------------------------
                                   1905 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1906 ;------------------------------------------------------------
                                   1907 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1908 ;	-----------------------------------------
                                   1909 ;	 function rgb_matrix_is_enabled
                                   1910 ;	-----------------------------------------
      005345                       1911 _rgb_matrix_is_enabled:
      005345 12 55 36         [24] 1912 	lcall	_ak820_outline_0061
      005348 F5 82            [12] 1913 	mov	dpl,a
      00534A 22               [24] 1914 	ret
                                   1915 ;------------------------------------------------------------
                                   1916 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1917 ;------------------------------------------------------------
                                   1918 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1919 ;	-----------------------------------------
                                   1920 ;	 function rgb_matrix_get_mode
                                   1921 ;	-----------------------------------------
      00534B                       1922 _rgb_matrix_get_mode:
      00534B 12 55 17         [24] 1923 	lcall	_ak820_outline_0016
      00534E F5 82            [12] 1924 	mov	dpl,a
      005350 22               [24] 1925 	ret
                                   1926 ;------------------------------------------------------------
                                   1927 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1928 ;------------------------------------------------------------
                                   1929 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1930 ;	-----------------------------------------
                                   1931 ;	 function rgb_matrix_get_hue
                                   1932 ;	-----------------------------------------
      005351                       1933 _rgb_matrix_get_hue:
      005351 90 06 9F         [24] 1934 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005354 E0               [24] 1935 	movx	a,@dptr
      005355 F5 82            [12] 1936 	mov	dpl,a
      005357 22               [24] 1937 	ret
                                   1938 ;------------------------------------------------------------
                                   1939 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1940 ;------------------------------------------------------------
                                   1941 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1942 ;	-----------------------------------------
                                   1943 ;	 function rgb_matrix_get_sat
                                   1944 ;	-----------------------------------------
      005358                       1945 _rgb_matrix_get_sat:
      005358 90 06 A0         [24] 1946 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00535B E0               [24] 1947 	movx	a,@dptr
      00535C F5 82            [12] 1948 	mov	dpl,a
      00535E 22               [24] 1949 	ret
                                   1950 ;------------------------------------------------------------
                                   1951 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1952 ;------------------------------------------------------------
                                   1953 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1954 ;	-----------------------------------------
                                   1955 ;	 function rgb_matrix_get_val
                                   1956 ;	-----------------------------------------
      00535F                       1957 _rgb_matrix_get_val:
      00535F 90 06 A1         [24] 1958 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005362 E0               [24] 1959 	movx	a,@dptr
      005363 F5 82            [12] 1960 	mov	dpl,a
      005365 22               [24] 1961 	ret
                                   1962 ;------------------------------------------------------------
                                   1963 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1964 ;------------------------------------------------------------
                                   1965 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1966 ;	-----------------------------------------
                                   1967 ;	 function rgb_matrix_get_speed
                                   1968 ;	-----------------------------------------
      005366                       1969 _rgb_matrix_get_speed:
      005366 90 06 A2         [24] 1970 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005369 E0               [24] 1971 	movx	a,@dptr
      00536A F5 82            [12] 1972 	mov	dpl,a
      00536C 22               [24] 1973 	ret
                                   1974 ;------------------------------------------------------------
                                   1975 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1976 ;------------------------------------------------------------
                                   1977 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1978 ;	-----------------------------------------
                                   1979 ;	 function rgb_matrix_toggle_noeeprom
                                   1980 ;	-----------------------------------------
      00536D                       1981 _rgb_matrix_toggle_noeeprom:
      00536D 12 55 36         [24] 1982 	lcall	_ak820_outline_0061
      005370 FF               [12] 1983 	mov	r7,a
      005371 63 07 01         [24] 1984 	xrl	ar7,#0x01
      005374 90 06 9E         [24] 1985 	mov	dptr,#_rgb_matrix_config
      005377 EF               [12] 1986 	mov	a,r7
      005378 54 03            [12] 1987 	anl	a,#0x03
      00537A F5 F0            [12] 1988 	mov	b,a
      00537C E0               [24] 1989 	movx	a,@dptr
      00537D 54 FC            [12] 1990 	anl	a,#0xfc
      00537F 45 F0            [12] 1991 	orl	a,b
      005381 F0               [24] 1992 	movx	@dptr,a
                                   1993 ;	assignBit
      005382 C2 11            [12] 1994 	clr	_rendering
      005384 02 4D 8F         [24] 1995 	ljmp	_clear_reactive
                                   1996 ;------------------------------------------------------------
                                   1997 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   1998 ;------------------------------------------------------------
                                   1999 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   2000 ;	-----------------------------------------
                                   2001 ;	 function rgb_matrix_enable_noeeprom
                                   2002 ;	-----------------------------------------
      005387                       2003 _rgb_matrix_enable_noeeprom:
      005387 12 55 36         [24] 2004 	lcall	_ak820_outline_0061
      00538A 70 03            [24] 2005 	jnz	00102$
      00538C 12 4D 8F         [24] 2006 	lcall	_clear_reactive
      00538F                       2007 00102$:
      00538F 12 55 57         [24] 2008 	lcall	_ak820_outline_0104
      005392 44 01            [12] 2009 	orl	a,#0x01
      005394 F0               [24] 2010 	movx	@dptr,a
                                   2011 ;	assignBit
      005395 C2 11            [12] 2012 	clr	_rendering
      005397 22               [24] 2013 	ret
                                   2014 ;------------------------------------------------------------
                                   2015 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2016 ;------------------------------------------------------------
                                   2017 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2018 ;	-----------------------------------------
                                   2019 ;	 function rgb_matrix_disable_noeeprom
                                   2020 ;	-----------------------------------------
      005398                       2021 _rgb_matrix_disable_noeeprom:
      005398 12 55 57         [24] 2022 	lcall	_ak820_outline_0104
      00539B F0               [24] 2023 	movx	@dptr,a
                                   2024 ;	assignBit
      00539C C2 11            [12] 2025 	clr	_rendering
      00539E 02 4D 8F         [24] 2026 	ljmp	_clear_reactive
                                   2027 ;------------------------------------------------------------
                                   2028 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2029 ;------------------------------------------------------------
                                   2030 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2031 ;------------------------------------------------------------
                                   2032 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2033 ;	-----------------------------------------
                                   2034 ;	 function rgb_matrix_mode_noeeprom
                                   2035 ;	-----------------------------------------
      0053A1                       2036 _rgb_matrix_mode_noeeprom:
      0053A1 E5 82            [12] 2037 	mov	a,dpl
      0053A3 90 07 22         [24] 2038 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      0053A6 F0               [24] 2039 	movx	@dptr,a
                                   2040 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      0053A7 E0               [24] 2041 	movx	a,@dptr
      0053A8 FF               [12] 2042 	mov	r7,a
      0053A9 60 05            [24] 2043 	jz	00101$
      0053AB BF 07 00         [24] 2044 	cjne	r7,#0x07,00123$
      0053AE                       2045 00123$:
      0053AE 40 01            [24] 2046 	jc	00102$
      0053B0                       2047 00101$:
      0053B0 22               [24] 2048 	ret
      0053B1                       2049 00102$:
                                   2050 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      0053B1 12 55 17         [24] 2051 	lcall	_ak820_outline_0016
      0053B4 FE               [12] 2052 	mov	r6,a
      0053B5 EF               [12] 2053 	mov	a,r7
      0053B6 B5 06 02         [24] 2054 	cjne	a,ar6,00125$
      0053B9 80 03            [24] 2055 	sjmp	00105$
      0053BB                       2056 00125$:
      0053BB 12 4D 8F         [24] 2057 	lcall	_clear_reactive
      0053BE                       2058 00105$:
                                   2059 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      0053BE 90 07 22         [24] 2060 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      0053C1 E0               [24] 2061 	movx	a,@dptr
      0053C2 90 06 9E         [24] 2062 	mov	dptr,#_rgb_matrix_config
      0053C5 25 E0            [12] 2063 	add	a,acc
      0053C7 25 E0            [12] 2064 	add	a,acc
      0053C9 54 FC            [12] 2065 	anl	a,#0xfc
      0053CB F5 F0            [12] 2066 	mov	b,a
      0053CD E0               [24] 2067 	movx	a,@dptr
      0053CE 54 03            [12] 2068 	anl	a,#0x03
      0053D0 45 F0            [12] 2069 	orl	a,b
      0053D2 F0               [24] 2070 	movx	@dptr,a
                                   2071 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2072 ;	assignBit
      0053D3 C2 11            [12] 2073 	clr	_rendering
                                   2074 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      0053D5 22               [24] 2075 	ret
                                   2076 ;------------------------------------------------------------
                                   2077 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2078 ;------------------------------------------------------------
                                   2079 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2080 ;	-----------------------------------------
                                   2081 ;	 function rgb_matrix_step_noeeprom
                                   2082 ;	-----------------------------------------
      0053D6                       2083 _rgb_matrix_step_noeeprom:
                                   2084 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      0053D6 12 55 17         [24] 2085 	lcall	_ak820_outline_0016
      0053D9 FF               [12] 2086 	mov	r7,a
      0053DA 0F               [12] 2087 	inc	r7
      0053DB BF 07 00         [24] 2088 	cjne	r7,#0x07,00112$
      0053DE                       2089 00112$:
      0053DE 40 04            [24] 2090 	jc	00103$
      0053E0 7F 01            [12] 2091 	mov	r7,#0x01
      0053E2 80 07            [24] 2092 	sjmp	00104$
      0053E4                       2093 00103$:
      0053E4 12 55 17         [24] 2094 	lcall	_ak820_outline_0016
      0053E7 FE               [12] 2095 	mov	r6,a
      0053E8 0E               [12] 2096 	inc	r6
      0053E9 8E 07            [24] 2097 	mov	ar7,r6
      0053EB                       2098 00104$:
      0053EB 8F 82            [24] 2099 	mov	dpl, r7
                                   2100 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      0053ED 02 53 A1         [24] 2101 	ljmp	_rgb_matrix_mode_noeeprom
                                   2102 ;------------------------------------------------------------
                                   2103 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2104 ;------------------------------------------------------------
                                   2105 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2106 ;	-----------------------------------------
                                   2107 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2108 ;	-----------------------------------------
      0053F0                       2109 _rgb_matrix_step_reverse_noeeprom:
                                   2110 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      0053F0 12 55 17         [24] 2111 	lcall	_ak820_outline_0016
      0053F3 24 FE            [12] 2112 	add	a,#0xff - 0x01
      0053F5 40 04            [24] 2113 	jc	00103$
                                   2114 ;	free result
      0053F7 7F 06            [12] 2115 	mov	r7,#0x06
      0053F9 80 05            [24] 2116 	sjmp	00104$
      0053FB                       2117 00103$:
      0053FB 12 55 17         [24] 2118 	lcall	_ak820_outline_0016
      0053FE 14               [12] 2119 	dec	a
      0053FF FF               [12] 2120 	mov	r7,a
      005400                       2121 00104$:
      005400 8F 82            [24] 2122 	mov	dpl, r7
                                   2123 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      005402 02 53 A1         [24] 2124 	ljmp	_rgb_matrix_mode_noeeprom
                                   2125 ;------------------------------------------------------------
                                   2126 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2127 ;------------------------------------------------------------
                                   2128 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2129 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2130 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2131 ;------------------------------------------------------------
                                   2132 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2133 ;	-----------------------------------------
                                   2134 ;	 function rgb_matrix_sethsv_noeeprom
                                   2135 ;	-----------------------------------------
      005405                       2136 _rgb_matrix_sethsv_noeeprom:
      005405 12 38 3C         [24] 2137 	lcall	_ak820_outline_0098
      005408 90 07 25         [24] 2138 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      00540B 12 38 41         [24] 2139 	lcall	_ak820_outline_0099
                                   2140 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      00540E 90 07 25         [24] 2141 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005411 E0               [24] 2142 	movx	a,@dptr
      005412 90 06 9F         [24] 2143 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005415 F0               [24] 2144 	movx	@dptr,a
                                   2145 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      005416 90 07 23         [24] 2146 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      005419 E0               [24] 2147 	movx	a,@dptr
      00541A FF               [12] 2148 	mov	r7,a
      00541B 90 06 A0         [24] 2149 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00541E F0               [24] 2150 	movx	@dptr,a
                                   2151 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00541F 90 07 24         [24] 2152 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      005422 E0               [24] 2153 	movx	a,@dptr
      005423 FF               [12] 2154 	mov  r7,a
      005424 24 5F            [12] 2155 	add	a,#0xff - 0xa0
      005426 50 04            [24] 2156 	jnc	00103$
                                   2157 ;	free result
      005428 7E A0            [12] 2158 	mov	r6,#0xa0
      00542A 80 02            [24] 2159 	sjmp	00104$
      00542C                       2160 00103$:
      00542C 8F 06            [24] 2161 	mov	ar6,r7
      00542E                       2162 00104$:
      00542E 90 06 A1         [24] 2163 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005431 EE               [12] 2164 	mov	a,r6
      005432 F0               [24] 2165 	movx	@dptr,a
                                   2166 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      005433 22               [24] 2167 	ret
                                   2168 ;------------------------------------------------------------
                                   2169 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2170 ;------------------------------------------------------------
                                   2171 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2172 ;------------------------------------------------------------
                                   2173 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2174 ;	-----------------------------------------
                                   2175 ;	 function rgb_matrix_set_speed_noeeprom
                                   2176 ;	-----------------------------------------
      005434                       2177 _rgb_matrix_set_speed_noeeprom:
      005434 E5 82            [12] 2178 	mov	a,dpl
      005436 90 07 27         [24] 2179 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      005439 F0               [24] 2180 	movx	@dptr,a
      00543A E0               [24] 2181 	movx	a,@dptr
      00543B 90 06 A2         [24] 2182 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00543E F0               [24] 2183 	movx	@dptr,a
      00543F 22               [24] 2184 	ret
                                   2185 ;------------------------------------------------------------
                                   2186 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2187 ;------------------------------------------------------------
                                   2188 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2189 ;------------------------------------------------------------
                                   2190 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2191 ;	-----------------------------------------
                                   2192 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2193 ;	-----------------------------------------
      005440                       2194 _rgb_matrix_increase_hue_noeeprom:
      005440 90 06 9F         [24] 2195 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005443 E0               [24] 2196 	movx	a,@dptr
      005444 24 08            [12] 2197 	add	a,#0x08
      005446 90 06 9F         [24] 2198 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005449 F0               [24] 2199 	movx	@dptr,a
      00544A 22               [24] 2200 	ret
                                   2201 ;------------------------------------------------------------
                                   2202 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2203 ;------------------------------------------------------------
                                   2204 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2205 ;	-----------------------------------------
                                   2206 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2207 ;	-----------------------------------------
      00544B                       2208 _rgb_matrix_decrease_hue_noeeprom:
      00544B 90 06 9F         [24] 2209 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00544E E0               [24] 2210 	movx	a,@dptr
      00544F 24 F8            [12] 2211 	add	a,#0xf8
      005451 90 06 9F         [24] 2212 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005454 F0               [24] 2213 	movx	@dptr,a
      005455 22               [24] 2214 	ret
                                   2215 ;------------------------------------------------------------
                                   2216 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2217 ;------------------------------------------------------------
                                   2218 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2219 ;	-----------------------------------------
                                   2220 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2221 ;	-----------------------------------------
      005456                       2222 _rgb_matrix_increase_sat_noeeprom:
      005456 90 06 A0         [24] 2223 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005459 12 55 20         [24] 2224 	lcall	_ak820_outline_0044
      00545C 12 4E 2A         [24] 2225 	lcall	_add_sat
      00545F AF 82            [24] 2226 	mov	r7, dpl
      005461 90 06 A0         [24] 2227 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005464 EF               [12] 2228 	mov	a,r7
      005465 F0               [24] 2229 	movx	@dptr,a
      005466 22               [24] 2230 	ret
                                   2231 ;------------------------------------------------------------
                                   2232 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2233 ;------------------------------------------------------------
                                   2234 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2235 ;	-----------------------------------------
                                   2236 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2237 ;	-----------------------------------------
      005467                       2238 _rgb_matrix_decrease_sat_noeeprom:
      005467 90 06 A0         [24] 2239 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00546A 12 55 2B         [24] 2240 	lcall	_ak820_outline_0045
      00546D 12 4E 4F         [24] 2241 	lcall	_sub_sat
      005470 AF 82            [24] 2242 	mov	r7, dpl
      005472 90 06 A0         [24] 2243 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005475 EF               [12] 2244 	mov	a,r7
      005476 F0               [24] 2245 	movx	@dptr,a
      005477 22               [24] 2246 	ret
                                   2247 ;------------------------------------------------------------
                                   2248 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2249 ;------------------------------------------------------------
                                   2250 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2251 ;------------------------------------------------------------
                                   2252 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2253 ;	-----------------------------------------
                                   2254 ;	 function rgb_matrix_increase_val_noeeprom
                                   2255 ;	-----------------------------------------
      005478                       2256 _rgb_matrix_increase_val_noeeprom:
                                   2257 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      005478 90 06 A1         [24] 2258 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00547B 12 55 20         [24] 2259 	lcall	_ak820_outline_0044
      00547E 12 4E 2A         [24] 2260 	lcall	_add_sat
                                   2261 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005481 E5 82            [12] 2262 	mov	a,dpl
      005483 FF               [12] 2263 	mov	r7,a
      005484 24 5F            [12] 2264 	add	a,#0xff - 0xa0
      005486 50 04            [24] 2265 	jnc	00103$
                                   2266 ;	free result
      005488 7E A0            [12] 2267 	mov	r6,#0xa0
      00548A 80 02            [24] 2268 	sjmp	00104$
      00548C                       2269 00103$:
      00548C 8F 06            [24] 2270 	mov	ar6,r7
      00548E                       2271 00104$:
      00548E 90 06 A1         [24] 2272 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005491 EE               [12] 2273 	mov	a,r6
      005492 F0               [24] 2274 	movx	@dptr,a
                                   2275 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      005493 22               [24] 2276 	ret
                                   2277 ;------------------------------------------------------------
                                   2278 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2279 ;------------------------------------------------------------
                                   2280 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2281 ;	-----------------------------------------
                                   2282 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2283 ;	-----------------------------------------
      005494                       2284 _rgb_matrix_decrease_val_noeeprom:
      005494 90 06 A1         [24] 2285 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005497 12 55 2B         [24] 2286 	lcall	_ak820_outline_0045
      00549A 12 4E 4F         [24] 2287 	lcall	_sub_sat
      00549D AF 82            [24] 2288 	mov	r7, dpl
      00549F 90 06 A1         [24] 2289 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0054A2 EF               [12] 2290 	mov	a,r7
      0054A3 F0               [24] 2291 	movx	@dptr,a
      0054A4 22               [24] 2292 	ret
                                   2293 ;------------------------------------------------------------
                                   2294 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2295 ;------------------------------------------------------------
                                   2296 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2297 ;	-----------------------------------------
                                   2298 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2299 ;	-----------------------------------------
      0054A5                       2300 _rgb_matrix_increase_speed_noeeprom:
      0054A5 90 06 A2         [24] 2301 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0054A8 12 55 20         [24] 2302 	lcall	_ak820_outline_0044
      0054AB 12 4E 2A         [24] 2303 	lcall	_add_sat
      0054AE AF 82            [24] 2304 	mov	r7, dpl
      0054B0 90 06 A2         [24] 2305 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0054B3 EF               [12] 2306 	mov	a,r7
      0054B4 F0               [24] 2307 	movx	@dptr,a
      0054B5 22               [24] 2308 	ret
                                   2309 ;------------------------------------------------------------
                                   2310 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2311 ;------------------------------------------------------------
                                   2312 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2313 ;	-----------------------------------------
                                   2314 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2315 ;	-----------------------------------------
      0054B6                       2316 _rgb_matrix_decrease_speed_noeeprom:
      0054B6 90 06 A2         [24] 2317 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0054B9 12 55 2B         [24] 2318 	lcall	_ak820_outline_0045
      0054BC 12 4E 4F         [24] 2319 	lcall	_sub_sat
      0054BF AF 82            [24] 2320 	mov	r7, dpl
      0054C1 90 06 A2         [24] 2321 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0054C4 EF               [12] 2322 	mov	a,r7
      0054C5 F0               [24] 2323 	movx	@dptr,a
      0054C6 22               [24] 2324 	ret
                                   2325 ;------------------------------------------------------------
                                   2326 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2327 ;------------------------------------------------------------
                                   2328 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2329 ;	-----------------------------------------
                                   2330 ;	 function rgb_matrix_toggle
                                   2331 ;	-----------------------------------------
      0054C7                       2332 _rgb_matrix_toggle:
      0054C7 12 53 6D         [24] 2333 	lcall	_rgb_matrix_toggle_noeeprom
      0054CA 02 4E 6C         [24] 2334 	ljmp	_mark_dirty
                                   2335 ;------------------------------------------------------------
                                   2336 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2337 ;------------------------------------------------------------
                                   2338 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2339 ;	-----------------------------------------
                                   2340 ;	 function rgb_matrix_step
                                   2341 ;	-----------------------------------------
      0054CD                       2342 _rgb_matrix_step:
      0054CD 12 53 D6         [24] 2343 	lcall	_rgb_matrix_step_noeeprom
      0054D0 02 4E 6C         [24] 2344 	ljmp	_mark_dirty
                                   2345 ;------------------------------------------------------------
                                   2346 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2347 ;------------------------------------------------------------
                                   2348 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2349 ;	-----------------------------------------
                                   2350 ;	 function rgb_matrix_step_reverse
                                   2351 ;	-----------------------------------------
      0054D3                       2352 _rgb_matrix_step_reverse:
      0054D3 12 53 F0         [24] 2353 	lcall	_rgb_matrix_step_reverse_noeeprom
      0054D6 02 4E 6C         [24] 2354 	ljmp	_mark_dirty
                                   2355 ;------------------------------------------------------------
                                   2356 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2357 ;------------------------------------------------------------
                                   2358 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2359 ;	-----------------------------------------
                                   2360 ;	 function rgb_matrix_increase_hue
                                   2361 ;	-----------------------------------------
      0054D9                       2362 _rgb_matrix_increase_hue:
      0054D9 12 54 40         [24] 2363 	lcall	_rgb_matrix_increase_hue_noeeprom
      0054DC 02 4E 6C         [24] 2364 	ljmp	_mark_dirty
                                   2365 ;------------------------------------------------------------
                                   2366 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2367 ;------------------------------------------------------------
                                   2368 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2369 ;	-----------------------------------------
                                   2370 ;	 function rgb_matrix_decrease_hue
                                   2371 ;	-----------------------------------------
      0054DF                       2372 _rgb_matrix_decrease_hue:
      0054DF 12 54 4B         [24] 2373 	lcall	_rgb_matrix_decrease_hue_noeeprom
      0054E2 02 4E 6C         [24] 2374 	ljmp	_mark_dirty
                                   2375 ;------------------------------------------------------------
                                   2376 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2377 ;------------------------------------------------------------
                                   2378 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2379 ;	-----------------------------------------
                                   2380 ;	 function rgb_matrix_increase_sat
                                   2381 ;	-----------------------------------------
      0054E5                       2382 _rgb_matrix_increase_sat:
      0054E5 12 54 56         [24] 2383 	lcall	_rgb_matrix_increase_sat_noeeprom
      0054E8 02 4E 6C         [24] 2384 	ljmp	_mark_dirty
                                   2385 ;------------------------------------------------------------
                                   2386 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2387 ;------------------------------------------------------------
                                   2388 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2389 ;	-----------------------------------------
                                   2390 ;	 function rgb_matrix_decrease_sat
                                   2391 ;	-----------------------------------------
      0054EB                       2392 _rgb_matrix_decrease_sat:
      0054EB 12 54 67         [24] 2393 	lcall	_rgb_matrix_decrease_sat_noeeprom
      0054EE 02 4E 6C         [24] 2394 	ljmp	_mark_dirty
                                   2395 ;------------------------------------------------------------
                                   2396 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2397 ;------------------------------------------------------------
                                   2398 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2399 ;	-----------------------------------------
                                   2400 ;	 function rgb_matrix_increase_val
                                   2401 ;	-----------------------------------------
      0054F1                       2402 _rgb_matrix_increase_val:
      0054F1 12 54 78         [24] 2403 	lcall	_rgb_matrix_increase_val_noeeprom
      0054F4 02 4E 6C         [24] 2404 	ljmp	_mark_dirty
                                   2405 ;------------------------------------------------------------
                                   2406 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2407 ;------------------------------------------------------------
                                   2408 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2409 ;	-----------------------------------------
                                   2410 ;	 function rgb_matrix_decrease_val
                                   2411 ;	-----------------------------------------
      0054F7                       2412 _rgb_matrix_decrease_val:
      0054F7 12 54 94         [24] 2413 	lcall	_rgb_matrix_decrease_val_noeeprom
      0054FA 02 4E 6C         [24] 2414 	ljmp	_mark_dirty
                                   2415 ;------------------------------------------------------------
                                   2416 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2417 ;------------------------------------------------------------
                                   2418 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2419 ;	-----------------------------------------
                                   2420 ;	 function rgb_matrix_increase_speed
                                   2421 ;	-----------------------------------------
      0054FD                       2422 _rgb_matrix_increase_speed:
      0054FD 12 54 A5         [24] 2423 	lcall	_rgb_matrix_increase_speed_noeeprom
      005500 02 4E 6C         [24] 2424 	ljmp	_mark_dirty
                                   2425 ;------------------------------------------------------------
                                   2426 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2427 ;------------------------------------------------------------
                                   2428 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2429 ;	-----------------------------------------
                                   2430 ;	 function rgb_matrix_decrease_speed
                                   2431 ;	-----------------------------------------
      005503                       2432 _rgb_matrix_decrease_speed:
      005503 12 54 B6         [24] 2433 	lcall	_rgb_matrix_decrease_speed_noeeprom
      005506 02 4E 6C         [24] 2434 	ljmp	_mark_dirty
                                   2435 ;------------------------------------------------------------
                                   2436 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2437 ;------------------------------------------------------------
                                   2438 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2439 ;------------------------------------------------------------
                                   2440 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2441 ;	-----------------------------------------
                                   2442 ;	 function rgb_matrix_mode
                                   2443 ;	-----------------------------------------
      005509                       2444 _rgb_matrix_mode:
      005509 E5 82            [12] 2445 	mov	a,dpl
      00550B 90 07 28         [24] 2446 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      00550E 12 55 6A         [24] 2447 	lcall	_ak820_outline_0159
      005511 12 53 A1         [24] 2448 	lcall	_rgb_matrix_mode_noeeprom
      005514 02 4E 6C         [24] 2449 	ljmp	_mark_dirty
                                   2450 ;------------------------------------------------------------
                                   2451 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2452 ;------------------------------------------------------------
                                   2453 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2454 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2455 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2456 ;------------------------------------------------------------
                                   2457 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2458 ;	-----------------------------------------
                                   2459 	.area CSEG    (CODE)
                                   2460 	.area CONST   (CODE)
                                   2461 	.area CONST   (CODE)
      00B537                       2462 _sine8_coefficients_10000_290:
      00B537 00                    2463 	.db #0x00	; 0
      00B538 31                    2464 	.db #0x31	; 49	'1'
      00B539 31                    2465 	.db #0x31	; 49	'1'
      00B53A 29                    2466 	.db #0x29	; 41
      00B53B 5A                    2467 	.db #0x5a	; 90	'Z'
      00B53C 1B                    2468 	.db #0x1b	; 27
      00B53D 75                    2469 	.db #0x75	; 117	'u'
      00B53E 0A                    2470 	.db #0x0a	; 10
                                   2471 	.area CSEG    (CODE)
                                   2472 	.area XINIT   (CODE)
                                   2473 	.area CABS    (ABS,CODE)
                                   2474 
                                   2475 ; Experimental exact instruction outlining.
                                   2476 	.globl _ak820_outline_0004
                                   2477 	.globl _ak820_outline_0016
                                   2478 	.globl _ak820_outline_0044
                                   2479 	.globl _ak820_outline_0045
                                   2480 	.globl _ak820_outline_0047
                                   2481 	.globl _ak820_outline_0055
                                   2482 	.globl _ak820_outline_0056
                                   2483 	.globl _ak820_outline_0061
                                   2484 	.globl _ak820_outline_0065
                                   2485 	.globl _ak820_outline_0067
                                   2486 	.globl _ak820_outline_0076
                                   2487 	.globl _ak820_outline_0093
                                   2488 	.globl _ak820_outline_0098
                                   2489 	.globl _ak820_outline_0099
                                   2490 	.globl _ak820_outline_0100
                                   2491 	.globl _ak820_outline_0104
                                   2492 	.globl _ak820_outline_0110
                                   2493 	.globl _ak820_outline_0114
                                   2494 	.globl _ak820_outline_0122
                                   2495 	.globl _ak820_outline_0123
                                   2496 	.globl _ak820_outline_0126
                                   2497 	.globl _ak820_outline_0128
                                   2498 	.globl _ak820_outline_0156
                                   2499 	.globl _ak820_outline_0158
                                   2500 	.globl _ak820_outline_0159
                                   2501 	.globl _ak820_outline_0161
                                   2502 	.globl _ak820_outline_0167
                                   2503 	.globl _ak820_outline_0173
                                   2504 	.globl _ak820_outline_0174
                                   2505 	.globl _ak820_outline_0176
                                   2506 
                                   2507 	.area CSEG (CODE)
                                   2508 ; function ak820_outline_0016
      005517                       2509 _ak820_outline_0016:
      005517 90 06 9E         [24] 2510 	mov	dptr,#_rgb_matrix_config
      00551A E0               [24] 2511 	movx	a,@dptr
      00551B 03               [12] 2512 	rr	a
      00551C 03               [12] 2513 	rr	a
      00551D 54 3F            [12] 2514 	anl	a,#0x3f
      00551F 22               [24] 2515 	ret
                                   2516 
                                   2517 	.area CSEG (CODE)
                                   2518 ; function ak820_outline_0044
      005520                       2519 _ak820_outline_0044:
      005520 E0               [24] 2520 	movx	a,@dptr
      005521 FF               [12] 2521 	mov	r7,a
      005522 90 07 07         [24] 2522 	mov	dptr,#_add_sat_PARM_2
      005525 74 10            [12] 2523 	mov	a,#0x10
      005527 F0               [24] 2524 	movx	@dptr,a
      005528 8F 82            [24] 2525 	mov	dpl,r7
      00552A 22               [24] 2526 	ret
                                   2527 
                                   2528 	.area CSEG (CODE)
                                   2529 ; function ak820_outline_0045
      00552B                       2530 _ak820_outline_0045:
      00552B E0               [24] 2531 	movx	a,@dptr
      00552C FF               [12] 2532 	mov	r7,a
      00552D 90 07 09         [24] 2533 	mov	dptr,#_sub_sat_PARM_2
      005530 74 10            [12] 2534 	mov	a,#0x10
      005532 F0               [24] 2535 	movx	@dptr,a
      005533 8F 82            [24] 2536 	mov	dpl,r7
      005535 22               [24] 2537 	ret
                                   2538 
                                   2539 	.area CSEG (CODE)
                                   2540 ; function ak820_outline_0061
      005536                       2541 _ak820_outline_0061:
      005536 90 06 9E         [24] 2542 	mov	dptr,#_rgb_matrix_config
      005539 E0               [24] 2543 	movx	a,@dptr
      00553A 54 03            [12] 2544 	anl	a,#0x03
      00553C 22               [24] 2545 	ret
                                   2546 
                                   2547 	.area CSEG (CODE)
                                   2548 ; function ak820_outline_0065
      00553D                       2549 _ak820_outline_0065:
      00553D 74 08            [12] 2550 	mov	a,#0x08
      00553F F0               [24] 2551 	movx	@dptr,a
      005540 E4               [12] 2552 	clr	a
      005541 A3               [24] 2553 	inc	dptr
      005542 F0               [24] 2554 	movx	@dptr,a
      005543 90 06 9E         [24] 2555 	mov	dptr,#_rgb_matrix_config
      005546 22               [24] 2556 	ret
                                   2557 
                                   2558 	.area CSEG (CODE)
                                   2559 ; function ak820_outline_0076
      005547                       2560 _ak820_outline_0076:
      005547 74 18            [12] 2561 	mov	a,#0x18
      005549 F0               [24] 2562 	movx	@dptr,a
      00554A E4               [12] 2563 	clr	a
      00554B A3               [24] 2564 	inc	dptr
      00554C F0               [24] 2565 	movx	@dptr,a
      00554D A3               [24] 2566 	inc	dptr
      00554E F0               [24] 2567 	movx	@dptr,a
      00554F 22               [24] 2568 	ret
                                   2569 
                                   2570 	.area CSEG (CODE)
                                   2571 ; function ak820_outline_0100
      005550                       2572 _ak820_outline_0100:
      005550 35 F0            [12] 2573 	addc	a,b
      005552 F5 83            [12] 2574 	mov	dph,a
      005554 E4               [12] 2575 	clr	a
      005555 93               [24] 2576 	movc	a,@a+dptr
      005556 22               [24] 2577 	ret
                                   2578 
                                   2579 	.area CSEG (CODE)
                                   2580 ; function ak820_outline_0104
      005557                       2581 _ak820_outline_0104:
      005557 90 06 9E         [24] 2582 	mov	dptr,#_rgb_matrix_config
      00555A E0               [24] 2583 	movx	a,@dptr
      00555B 54 FC            [12] 2584 	anl	a,#0xfc
      00555D 22               [24] 2585 	ret
                                   2586 
                                   2587 	.area CSEG (CODE)
                                   2588 ; function ak820_outline_0128
      00555E                       2589 _ak820_outline_0128:
      00555E 90 06 AD         [24] 2590 	mov	dptr,#_frame_mode
      005561 E0               [24] 2591 	movx	a,@dptr
      005562 FE               [12] 2592 	mov	r6,a
      005563 22               [24] 2593 	ret
                                   2594 
                                   2595 	.area CSEG (CODE)
                                   2596 ; function ak820_outline_0156
      005564                       2597 _ak820_outline_0156:
      005564 F0               [24] 2598 	movx	@dptr,a
      005565 E5 F0            [12] 2599 	mov	a,b
      005567 A3               [24] 2600 	inc	dptr
      005568 F0               [24] 2601 	movx	@dptr,a
      005569 22               [24] 2602 	ret
                                   2603 
                                   2604 	.area CSEG (CODE)
                                   2605 ; function ak820_outline_0159
      00556A                       2606 _ak820_outline_0159:
      00556A F0               [24] 2607 	movx	@dptr,a
      00556B E0               [24] 2608 	movx	a,@dptr
      00556C F5 82            [12] 2609 	mov	dpl,a
      00556E 22               [24] 2610 	ret
                                   2611 
                                   2612 	.area CSEG (CODE)
                                   2613 ; function ak820_outline_0161
      00556F                       2614 _ak820_outline_0161:
      00556F 90 06 A2         [24] 2615 	mov	dptr,#(_rgb_matrix_config+0x0004)
      005572 E0               [24] 2616 	movx	a,@dptr
      005573 23               [12] 2617 	rl	a
      005574 23               [12] 2618 	rl	a
      005575 54 03            [12] 2619 	anl	a,#0x03
      005577 22               [24] 2620 	ret
                                   2621 
                                   2622 	.area CSEG (CODE)
                                   2623 ; function ak820_outline_0167
      005578                       2624 _ak820_outline_0167:
      005578 90 0D 6F         [24] 2625 	mov	dptr,#_memset_PARM_2
      00557B E4               [12] 2626 	clr	a
      00557C F0               [24] 2627 	movx	@dptr,a
      00557D 90 0D 70         [24] 2628 	mov	dptr,#_memset_PARM_3
      005580 22               [24] 2629 	ret
                                   2630 
                                   2631 	.area CSEG (CODE)
                                   2632 ; function ak820_outline_0173
      005581                       2633 _ak820_outline_0173:
      005581 90 06 AC         [24] 2634 	mov	dptr,#_led_index
      005584 E0               [24] 2635 	movx	a,@dptr
      005585 22               [24] 2636 	ret
                                   2637 
                                   2638 	.area CSEG (CODE)
                                   2639 ; function ak820_outline_0174
      005586                       2640 _ak820_outline_0174:
      005586 C4               [12] 2641 	swap	a
      005587 23               [12] 2642 	rl	a
      005588 54 1F            [12] 2643 	anl	a,#0x1f
      00558A 22               [24] 2644 	ret
