                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000028                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000028                        588 	.ds 2
      00002A                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002A                        590 	.ds 1
      00002B                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002B                        592 	.ds 1
      00002C                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002C                        594 	.ds 2
      00002E                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002E                        596 	.ds 2
      000030                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000030                        598 	.ds 1
      000031                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000031                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000022                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000022                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000AC5                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AC5                        628 	.ds 1
      000AC6                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AC6                        630 	.ds 1
      000AC7                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_364:
      000AC7                        632 	.ds 1
      000AC8                        633 _dynamic_keymap_get_keycode_PARM_2:
      000AC8                        634 	.ds 1
      000AC9                        635 _dynamic_keymap_get_keycode_PARM_3:
      000AC9                        636 	.ds 1
      000ACA                        637 _dynamic_keymap_get_keycode_layer_10000_366:
      000ACA                        638 	.ds 1
      000ACB                        639 _dynamic_keymap_set_keycode_PARM_2:
      000ACB                        640 	.ds 1
      000ACC                        641 _dynamic_keymap_set_keycode_PARM_3:
      000ACC                        642 	.ds 1
      000ACD                        643 _dynamic_keymap_set_keycode_PARM_4:
      000ACD                        644 	.ds 2
      000ACF                        645 _dynamic_keymap_set_keycode_layer_10000_370:
      000ACF                        646 	.ds 1
      000AD0                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000AD0                        648 	.ds 1
      000AD1                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_374:
      000AD1                        650 	.ds 1
      000AD2                        651 _dynamic_keymap_get_encoder_PARM_2:
      000AD2                        652 	.ds 1
      000AD3                        653 _dynamic_keymap_get_encoder_PARM_3:
      000AD3                        654 	.ds 1
      000AD4                        655 _dynamic_keymap_get_encoder_layer_10000_376:
      000AD4                        656 	.ds 1
      000AD5                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AD5                        658 	.ds 1
      000AD6                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AD6                        660 	.ds 1
      000AD7                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AD7                        662 	.ds 2
      000AD9                        663 _dynamic_keymap_set_encoder_layer_10000_380:
      000AD9                        664 	.ds 1
      000ADA                        665 _dynamic_keymap_get_combo_PARM_2:
      000ADA                        666 	.ds 3
      000ADD                        667 _dynamic_keymap_get_combo_index_10000_384:
      000ADD                        668 	.ds 1
      000ADE                        669 _dynamic_keymap_set_combo_PARM_2:
      000ADE                        670 	.ds 3
      000AE1                        671 _dynamic_keymap_set_combo_index_10000_390:
      000AE1                        672 	.ds 1
      000AE2                        673 _dynamic_keymap_set_combo_stored_10002_395:
      000AE2                        674 	.ds 10
      000AEC                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_398:
      000AEC                        676 	.ds 1
      000AED                        677 _dynamic_keymap_reset_combo_10001_407:
      000AED                        678 	.ds 10
      000AF7                        679 _ak820_dynamic_read_buffer_PARM_2:
      000AF7                        680 	.ds 2
      000AF9                        681 _ak820_dynamic_read_buffer_PARM_3:
      000AF9                        682 	.ds 2
      000AFB                        683 _ak820_dynamic_read_buffer_PARM_4:
      000AFB                        684 	.ds 2
      000AFD                        685 _ak820_dynamic_read_buffer_PARM_5:
      000AFD                        686 	.ds 3
      000B00                        687 _ak820_dynamic_read_buffer_base_10000_409:
      000B00                        688 	.ds 2
      000B02                        689 _ak820_dynamic_read_buffer_available_10000_410:
      000B02                        690 	.ds 1
      000B03                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B03                        692 	.ds 2
      000B05                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B05                        694 	.ds 3
      000B08                        695 _dynamic_keymap_get_buffer_offset_10000_416:
      000B08                        696 	.ds 2
      000B0A                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B0A                        698 	.ds 2
      000B0C                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B0C                        700 	.ds 3
      000B0F                        701 _dynamic_keymap_set_buffer_offset_10000_418:
      000B0F                        702 	.ds 2
      000B11                        703 _dynamic_keymap_set_buffer_chk_offset_30001_425:
      000B11                        704 	.ds 1
      000B12                        705 _dynamic_keymap_set_buffer_chk_sz_30001_425:
      000B12                        706 	.ds 1
      000B13                        707 _dynamic_keymap_set_buffer_i_40001_432:
      000B13                        708 	.ds 1
      000B14                        709 _keycode_at_keymap_location_PARM_2:
      000B14                        710 	.ds 1
      000B15                        711 _keycode_at_keymap_location_PARM_3:
      000B15                        712 	.ds 1
      000B16                        713 _keycode_at_keymap_location_layer_num_10000_436:
      000B16                        714 	.ds 1
      000B17                        715 _keycode_at_encodermap_location_PARM_2:
      000B17                        716 	.ds 1
      000B18                        717 _keycode_at_encodermap_location_PARM_3:
      000B18                        718 	.ds 1
      000B19                        719 _keycode_at_encodermap_location_layer_num_10000_440:
      000B19                        720 	.ds 1
      000B1A                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B1A                        722 	.ds 2
      000B1C                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B1C                        724 	.ds 3
      000B1F                        725 _dynamic_keymap_macro_get_buffer_offset_10000_448:
      000B1F                        726 	.ds 2
      000B21                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B21                        728 	.ds 2
      000B23                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B23                        730 	.ds 3
      000B26                        731 _dynamic_keymap_macro_set_buffer_offset_10000_450:
      000B26                        732 	.ds 2
      000B28                        733 _decode_keycode_kc_10000_454:
      000B28                        734 	.ds 2
      000B2A                        735 _dynamic_keymap_macro_send_id_10000_457:
      000B2A                        736 	.ds 1
      000B2B                        737 _dynamic_keymap_macro_send_sending_10000_458:
      000B2B                        738 	.ds 1
      000B2C                        739 _dynamic_keymap_macro_send_p_10001_463:
      000B2C                        740 	.ds 2
      000B2E                        741 _dynamic_keymap_macro_send_data_10003_470:
      000B2E                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008080                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008080 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      008083 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_364'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008084                        810 _dynamic_keymap_key_to_eeprom_address:
      008084 E5 82            [12]  811 	mov	a,dpl
      008086 90 0A C7         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_364
      008089 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      00808A E0               [24]  815 	movx	a,@dptr
      00808B FF               [12]  816 	mov	r7,a
      00808C 7E 00            [12]  817 	mov	r6,#0x00
      00808E 74 40            [12]  818 	mov	a,#0x40
      008090 12 43 24         [24]  819 	lcall	_ak820_outline_0125
      008093 7D 00            [12]  820 	mov	r5,#0x00
      008095 90 0A C5         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008098 E0               [24]  822 	movx	a,@dptr
      008099 75 F0 10         [24]  823 	mov	b,#0x10
      00809C A4               [48]  824 	mul	ab
      00809D 2E               [12]  825 	add	a, r6
      00809E FE               [12]  826 	mov	r6,a
      00809F EF               [12]  827 	mov	a,r7
      0080A0 35 F0            [12]  828 	addc	a, b
      0080A2 FF               [12]  829 	mov	r7,a
      0080A3 90 0A C6         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0080A6 E0               [24]  831 	movx	a,@dptr
      0080A7 7C 00            [12]  832 	mov	r4,#0x00
      0080A9 25 E0            [12]  833 	add	a,acc
      0080AB FB               [12]  834 	mov	r3,a
      0080AC EC               [12]  835 	mov	a,r4
      0080AD 33               [12]  836 	rlc	a
      0080AE FC               [12]  837 	mov	r4,a
      0080AF EB               [12]  838 	mov	a,r3
      0080B0 2E               [12]  839 	add	a, r6
      0080B1 FE               [12]  840 	mov	r6,a
      0080B2 EC               [12]  841 	mov	a,r4
      0080B3 3F               [12]  842 	addc	a, r7
      0080B4 FF               [12]  843 	mov	r7,a
      0080B5 12 43 1A         [24]  844 	lcall	_ak820_outline_0109
      0080B8 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      0080BA 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_366'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_369'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_369'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      0080BB                        861 _dynamic_keymap_get_keycode:
      0080BB E5 82            [12]  862 	mov	a,dpl
      0080BD 90 0A CA         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_366
      0080C0 F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0080C1 E0               [24]  866 	movx	a,@dptr
      0080C2 FF               [12]  867 	mov	r7,a
      0080C3 BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      0080C6                        869 00121$:
      0080C6 50 14            [24]  870 	jnc	00101$
      0080C8 90 0A C8         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0080CB E0               [24]  872 	movx	a,@dptr
      0080CC FE               [12]  873 	mov	r6,a
      0080CD BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      0080D0                        875 00123$:
      0080D0 50 0A            [24]  876 	jnc	00101$
      0080D2 90 0A C9         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0080D5 E0               [24]  878 	movx	a,@dptr
      0080D6 FD               [12]  879 	mov	r5,a
      0080D7 BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      0080DA                        881 00125$:
      0080DA 40 04            [24]  882 	jc	00102$
      0080DC                        883 00101$:
      0080DC 90 00 00         [24]  884 	mov	dptr,#0x0000
      0080DF 22               [24]  885 	ret
      0080E0                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0080E0 12 8B 32         [24]  888 	lcall	_ak820_outline_0089
      0080E3 12 80 84         [24]  889 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      0080E6 12 8B 3F         [24]  891 	lcall	_ak820_outline_0105
      0080E9 12 40 33         [24]  892 	lcall	_eeprom_read_byte
      0080EC AB 82            [24]  893 	mov	r3,dpl
      0080EE 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      0080F0 0D               [12]  896 	inc	r5
      0080F1 BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      0080F4 0E               [12]  898 	inc	r6
      0080F5                        899 00127$:
      0080F5 12 4D 48         [24]  900 	lcall	_ak820_outline_0041
      0080F8 12 40 33         [24]  901 	lcall	_eeprom_read_byte
      0080FB AF 82            [24]  902 	mov	r7, dpl
      0080FD 7E 00            [12]  903 	mov	r6,#0x00
      0080FF EF               [12]  904 	mov	a,r7
      008100 42 04            [12]  905 	orl	ar4,a
      008102 EE               [12]  906 	mov	a,r6
      008103 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      008105 12 43 50         [24]  909 	lcall	_ak820_outline_0171
                                    910 ;	quantum/dynamic_keymap.c:215: }
      008108 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_370'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_373'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      008109                        925 _dynamic_keymap_set_keycode:
      008109 E5 82            [12]  926 	mov	a,dpl
      00810B 90 0A CF         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_370
      00810E F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      00810F E0               [24]  930 	movx	a,@dptr
      008110 FF               [12]  931 	mov	r7,a
      008111 BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      008114                        933 00121$:
      008114 50 14            [24]  934 	jnc	00101$
      008116 90 0A CB         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008119 E0               [24]  936 	movx	a,@dptr
      00811A FE               [12]  937 	mov	r6,a
      00811B BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      00811E                        939 00123$:
      00811E 50 0A            [24]  940 	jnc	00101$
      008120 90 0A CC         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008123 E0               [24]  942 	movx	a,@dptr
      008124 FD               [12]  943 	mov	r5,a
      008125 BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      008128                        945 00125$:
      008128 40 01            [24]  946 	jc	00102$
      00812A                        947 00101$:
      00812A 22               [24]  948 	ret
      00812B                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00812B 12 8B 32         [24]  951 	lcall	_ak820_outline_0089
      00812E 12 80 84         [24]  952 	lcall	_dynamic_keymap_key_to_eeprom_address
      008131 12 8B 3F         [24]  953 	lcall	_ak820_outline_0105
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008134 90 0A CD         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008137 E0               [24]  956 	movx	a,@dptr
      008138 FB               [12]  957 	mov	r3,a
      008139 A3               [24]  958 	inc	dptr
      00813A E0               [24]  959 	movx	a,@dptr
      00813B 90 06 8E         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      00813E F0               [24]  961 	movx	@dptr,a
      00813F 12 4D 48         [24]  962 	lcall	_ak820_outline_0041
      008142 12 4C 31         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008145 0D               [12]  965 	inc	r5
      008146 BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      008149 0E               [12]  967 	inc	r6
      00814A                        968 00127$:
      00814A 90 06 8E         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      00814D EB               [12]  970 	mov	a,r3
      00814E F0               [24]  971 	movx	@dptr,a
      00814F 12 4D 48         [24]  972 	lcall	_ak820_outline_0041
                                    973 ;	quantum/dynamic_keymap.c:223: }
      008152 02 4C 31         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      008155                        985 _dynamic_keymap_encoder_to_eeprom_address:
      008155 E5 82            [12]  986 	mov	a,dpl
      008157 90 0A D1         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374
      00815A F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      00815B E0               [24]  990 	movx	a,@dptr
      00815C 75 F0 04         [24]  991 	mov	b,#0x04
      00815F A4               [48]  992 	mul	ab
      008160 24 40            [12]  993 	add	a, #0x40
      008162 FD               [12]  994 	mov	r5,a
      008163 74 06            [12]  995 	mov	a,#0x06
      008165 35 F0            [12]  996 	addc	a, b
      008167 FE               [12]  997 	mov	r6,a
      008168 7F 00            [12]  998 	mov	r7,#0x00
      00816A 90 0A D0         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00816D E0               [24] 1000 	movx	a,@dptr
      00816E 75 F0 04         [24] 1001 	mov	b,#0x04
      008171 A4               [48] 1002 	mul	ab
      008172 2D               [12] 1003 	add	a, r5
      008173 FD               [12] 1004 	mov	r5,a
      008174 EE               [12] 1005 	mov	a,r6
      008175 35 F0            [12] 1006 	addc	a, b
      008177 FE               [12] 1007 	mov	r6,a
      008178 12 4D 48         [24] 1008 	lcall	_ak820_outline_0041
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      00817B 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_376'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_379'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_379'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      00817C                       1024 _dynamic_keymap_get_encoder:
      00817C E5 82            [12] 1025 	mov	a,dpl
      00817E 90 0A D4         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_376
      008181 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008182 E0               [24] 1029 	movx	a,@dptr
      008183 FF               [12] 1030 	mov	r7,a
      008184 BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      008187                       1032 00131$:
      008187 50 0A            [24] 1033 	jnc	00101$
      008189 90 0A D2         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00818C E0               [24] 1035 	movx	a,@dptr
      00818D FE               [12] 1036 	mov	r6,a
      00818E BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      008191                       1038 00133$:
      008191 40 04            [24] 1039 	jc	00102$
      008193                       1040 00101$:
      008193 90 00 00         [24] 1041 	mov	dptr,#0x0000
      008196 22               [24] 1042 	ret
      008197                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008197 90 0A D0         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00819A E4               [12] 1046 	clr	a
      00819B F0               [24] 1047 	movx	@dptr,a
      00819C 8F 82            [24] 1048 	mov	dpl, r7
      00819E 12 81 55         [24] 1049 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0081A1 12 8B 3F         [24] 1050 	lcall	_ak820_outline_0105
                                   1051 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      0081A4 90 0A D3         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0081A7 E0               [24] 1053 	movx	a,@dptr
      0081A8 FC               [12] 1054 	mov	r4,a
      0081A9 E0               [24] 1055 	movx	a,@dptr
      0081AA 60 04            [24] 1056 	jz	00106$
      0081AC 7B 00            [12] 1057 	mov	r3,#0x00
      0081AE 80 02            [24] 1058 	sjmp	00107$
      0081B0                       1059 00106$:
      0081B0 7B 02            [12] 1060 	mov	r3,#0x02
      0081B2                       1061 00107$:
      0081B2 EB               [12] 1062 	mov	a,r3
      0081B3 12 8B 09         [24] 1063 	lcall	_ak820_outline_0023
      0081B6 12 40 33         [24] 1064 	lcall	_eeprom_read_byte
      0081B9 AA 82            [24] 1065 	mov	r2,dpl
      0081BB 7B 00            [12] 1066 	mov	r3,#0x00
                                   1067 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0081BD EC               [12] 1068 	mov	a,r4
      0081BE 60 04            [24] 1069 	jz	00108$
      0081C0 7C 00            [12] 1070 	mov	r4,#0x00
      0081C2 80 02            [24] 1071 	sjmp	00109$
      0081C4                       1072 00108$:
      0081C4 7C 02            [12] 1073 	mov	r4,#0x02
      0081C6                       1074 00109$:
      0081C6 EC               [12] 1075 	mov	a,r4
      0081C7 12 38 73         [24] 1076 	lcall	_ak820_outline_0147
      0081CA 0D               [12] 1077 	inc	r5
      0081CB BD 00 01         [24] 1078 	cjne	r5,#0x00,00137$
      0081CE 0E               [12] 1079 	inc	r6
      0081CF                       1080 00137$:
      0081CF 12 4D 48         [24] 1081 	lcall	_ak820_outline_0041
      0081D2 12 40 33         [24] 1082 	lcall	_eeprom_read_byte
      0081D5 AF 82            [24] 1083 	mov	r7, dpl
      0081D7 7E 00            [12] 1084 	mov	r6,#0x00
      0081D9 EF               [12] 1085 	mov	a,r7
      0081DA 42 03            [12] 1086 	orl	ar3,a
      0081DC EE               [12] 1087 	mov	a,r6
      0081DD 42 02            [12] 1088 	orl	ar2,a
                                   1089 ;	quantum/dynamic_keymap.c:236: return keycode;
      0081DF 8B 82            [24] 1090 	mov	dpl, r3
      0081E1 8A 83            [24] 1091 	mov	dph, r2
                                   1092 ;	quantum/dynamic_keymap.c:237: }
      0081E3 22               [24] 1093 	ret
                                   1094 ;------------------------------------------------------------
                                   1095 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1096 ;------------------------------------------------------------
                                   1097 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1098 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1099 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1100 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1101 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_380'
                                   1102 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_383'
                                   1103 ;------------------------------------------------------------
                                   1104 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1105 ;	-----------------------------------------
                                   1106 ;	 function dynamic_keymap_set_encoder
                                   1107 ;	-----------------------------------------
      0081E4                       1108 _dynamic_keymap_set_encoder:
      0081E4 E5 82            [12] 1109 	mov	a,dpl
      0081E6 90 0A D9         [24] 1110 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_380
      0081E9 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      0081EA E0               [24] 1113 	movx	a,@dptr
      0081EB FF               [12] 1114 	mov	r7,a
      0081EC BF 06 00         [24] 1115 	cjne	r7,#0x06,00131$
      0081EF                       1116 00131$:
      0081EF 50 0A            [24] 1117 	jnc	00101$
      0081F1 90 0A D5         [24] 1118 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0081F4 E0               [24] 1119 	movx	a,@dptr
      0081F5 FE               [12] 1120 	mov	r6,a
      0081F6 BE 01 00         [24] 1121 	cjne	r6,#0x01,00133$
      0081F9                       1122 00133$:
      0081F9 40 01            [24] 1123 	jc	00102$
      0081FB                       1124 00101$:
      0081FB 22               [24] 1125 	ret
      0081FC                       1126 00102$:
                                   1127 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0081FC 90 0A D0         [24] 1128 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0081FF E4               [12] 1129 	clr	a
      008200 F0               [24] 1130 	movx	@dptr,a
      008201 8F 82            [24] 1131 	mov	dpl, r7
      008203 12 81 55         [24] 1132 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008206 12 8B 3F         [24] 1133 	lcall	_ak820_outline_0105
                                   1134 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008209 90 0A D6         [24] 1135 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00820C E0               [24] 1136 	movx	a,@dptr
      00820D FC               [12] 1137 	mov	r4,a
      00820E E0               [24] 1138 	movx	a,@dptr
      00820F 60 04            [24] 1139 	jz	00106$
      008211 7B 00            [12] 1140 	mov	r3,#0x00
      008213 80 02            [24] 1141 	sjmp	00107$
      008215                       1142 00106$:
      008215 7B 02            [12] 1143 	mov	r3,#0x02
      008217                       1144 00107$:
      008217 EB               [12] 1145 	mov	a,r3
      008218 12 8B 51         [24] 1146 	lcall	_ak820_outline_0124
      00821B 8F 03            [24] 1147 	mov	ar3,r7
      00821D 90 0A D7         [24] 1148 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008220 E0               [24] 1149 	movx	a,@dptr
      008221 F5 28            [12] 1150 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008223 A3               [24] 1151 	inc	dptr
      008224 E0               [24] 1152 	movx	a,@dptr
      008225 F5 29            [12] 1153 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008227 90 06 8E         [24] 1154 	mov	dptr,#_eeprom_update_byte_PARM_2
      00822A F0               [24] 1155 	movx	@dptr,a
      00822B 12 43 4B         [24] 1156 	lcall	_ak820_outline_0170
      00822E 8B F0            [24] 1157 	mov	b, r3
      008230 12 4C 31         [24] 1158 	lcall	_eeprom_update_byte
                                   1159 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008233 EC               [12] 1160 	mov	a,r4
      008234 60 04            [24] 1161 	jz	00108$
      008236 7C 00            [12] 1162 	mov	r4,#0x00
      008238 80 02            [24] 1163 	sjmp	00109$
      00823A                       1164 00108$:
      00823A 7C 02            [12] 1165 	mov	r4,#0x02
      00823C                       1166 00109$:
      00823C EC               [12] 1167 	mov	a,r4
      00823D 12 38 73         [24] 1168 	lcall	_ak820_outline_0147
      008240 0D               [12] 1169 	inc	r5
      008241 BD 00 01         [24] 1170 	cjne	r5,#0x00,00137$
      008244 0E               [12] 1171 	inc	r6
      008245                       1172 00137$:
      008245 90 06 8E         [24] 1173 	mov	dptr,#_eeprom_update_byte_PARM_2
      008248 E5 28            [12] 1174 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      00824A F0               [24] 1175 	movx	@dptr,a
      00824B 12 4D 48         [24] 1176 	lcall	_ak820_outline_0041
                                   1177 ;	quantum/dynamic_keymap.c:245: }
      00824E 02 4C 31         [24] 1178 	ljmp	_eeprom_update_byte
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1183 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1184 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_384'
                                   1185 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_385'
                                   1186 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_387'
                                   1187 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_388'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function dynamic_keymap_get_combo
                                   1192 ;	-----------------------------------------
      008251                       1193 _dynamic_keymap_get_combo:
      008251 E5 82            [12] 1194 	mov	a,dpl
      008253 90 0A DD         [24] 1195 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      008256 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008257 90 0A DA         [24] 1198 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00825A 12 37 F9         [24] 1199 	lcall	_ak820_outline_0047
                                   1200 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      00825D 90 0A DD         [24] 1201 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      008260 E0               [24] 1202 	movx	a,@dptr
      008261 FD               [12] 1203 	mov	r5,a
      008262 BD 08 00         [24] 1204 	cjne	r5,#0x08,00132$
      008265                       1205 00132$:
      008265 40 04            [24] 1206 	jc	00102$
                                   1207 ;	quantum/dynamic_keymap.c:315: return -1;
      008267 90 FF FF         [24] 1208 	mov	dptr,#0xffff
      00826A 22               [24] 1209 	ret
      00826B                       1210 00102$:
                                   1211 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00826B 12 8B 17         [24] 1212 	lcall	_ak820_outline_0072
                                   1213 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      00826E 8E 02            [24] 1214 	mov	ar2,r6
      008270 8F 03            [24] 1215 	mov	ar3,r7
      008272 90 05 81         [24] 1216 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008275 EC               [12] 1217 	mov	a,r4
      008276 F0               [24] 1218 	movx	@dptr,a
      008277 ED               [12] 1219 	mov	a,r5
      008278 12 38 1E         [24] 1220 	lcall	_ak820_outline_0067
      00827B 90 05 84         [24] 1221 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00827E 12 8B 2B         [24] 1222 	lcall	_ak820_outline_0085
      008281 12 43 30         [24] 1223 	lcall	_ak820_outline_0132
      008284 C0 07            [24] 1224 	push	ar7
      008286 C0 06            [24] 1225 	push	ar6
      008288 12 40 6E         [24] 1226 	lcall	_ak820_eeprom_read_block_xdata
      00828B D0 06            [24] 1227 	pop	ar6
      00828D D0 07            [24] 1228 	pop	ar7
                                   1229 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      00828F 74 04            [12] 1230 	mov	a,#0x04
      008291 12 46 B8         [24] 1231 	lcall	_ak820_outline_0011
      008294 FA               [12] 1232 	mov	r2,a
      008295 A3               [24] 1233 	inc	dptr
      008296 E0               [24] 1234 	movx	a,@dptr
      008297 FB               [12] 1235 	mov	r3,a
      008298 BA 20 13         [24] 1236 	cjne	r2,#0x20,00108$
      00829B BB 08 10         [24] 1237 	cjne	r3,#0x08,00108$
      00829E 74 06            [12] 1238 	mov	a,#0x06
      0082A0 12 37 E9         [24] 1239 	lcall	_ak820_outline_0018
      0082A3 12 43 02         [24] 1240 	lcall	_ak820_outline_0093
      0082A6 BA 01 05         [24] 1241 	cjne	r2,#0x01,00136$
      0082A9 BB 00 02         [24] 1242 	cjne	r3,#0x00,00136$
      0082AC 80 05            [24] 1243 	sjmp	00109$
      0082AE                       1244 00136$:
      0082AE                       1245 00108$:
      0082AE 75 2A 00         [24] 1246 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      0082B1 80 03            [24] 1247 	sjmp	00110$
      0082B3                       1248 00109$:
      0082B3 75 2A 01         [24] 1249 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      0082B6                       1250 00110$:
                                   1251 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      0082B6 74 06            [12] 1252 	mov	a,#0x06
      0082B8 12 37 E9         [24] 1253 	lcall	_ak820_outline_0018
      0082BB 12 4D 8A         [24] 1254 	lcall	_ak820_outline_0157
      0082BE 12 38 4D         [24] 1255 	lcall	_ak820_outline_0110
      0082C1 F0               [24] 1256 	movx	@dptr,a
      0082C2 A3               [24] 1257 	inc	dptr
      0082C3 F0               [24] 1258 	movx	@dptr,a
                                   1259 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      0082C4 E5 2A            [12] 1260 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      0082C6 60 12            [24] 1261 	jz	00103$
      0082C8 12 43 1A         [24] 1262 	lcall	_ak820_outline_0109
      0082CB C0 07            [24] 1263 	push	ar7
      0082CD C0 06            [24] 1264 	push	ar6
      0082CF 12 34 68         [24] 1265 	lcall	_ak820_combo_valid
      0082D2 E5 82            [12] 1266 	mov	a, dpl
      0082D4 D0 06            [24] 1267 	pop	ar6
      0082D6 D0 07            [24] 1268 	pop	ar7
      0082D8 70 17            [24] 1269 	jnz	00104$
      0082DA                       1270 00103$:
      0082DA 7D 00            [12] 1271 	mov	r5,#0x00
      0082DC 90 0D 6F         [24] 1272 	mov	dptr,#_memset_PARM_2
      0082DF E4               [12] 1273 	clr	a
      0082E0 F0               [24] 1274 	movx	@dptr,a
      0082E1 90 0D 70         [24] 1275 	mov	dptr,#_memset_PARM_3
      0082E4 74 0A            [12] 1276 	mov	a,#0x0a
      0082E6 F0               [24] 1277 	movx	@dptr,a
      0082E7 E4               [12] 1278 	clr	a
      0082E8 A3               [24] 1279 	inc	dptr
      0082E9 12 42 F6         [24] 1280 	lcall	_ak820_outline_0057
      0082EC 8D F0            [24] 1281 	mov	b, r5
      0082EE 12 B4 52         [24] 1282 	lcall	_memset
      0082F1                       1283 00104$:
                                   1284 ;	quantum/dynamic_keymap.c:329: return 0;
      0082F1 90 00 00         [24] 1285 	mov	dptr,#0x0000
                                   1286 ;	quantum/dynamic_keymap.c:330: }
      0082F4 22               [24] 1287 	ret
                                   1288 ;------------------------------------------------------------
                                   1289 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1290 ;------------------------------------------------------------
                                   1291 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1292 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_390'
                                   1293 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_391'
                                   1294 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_394'
                                   1295 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_395'
                                   1296 ;------------------------------------------------------------
                                   1297 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1298 ;	-----------------------------------------
                                   1299 ;	 function dynamic_keymap_set_combo
                                   1300 ;	-----------------------------------------
      0082F5                       1301 _dynamic_keymap_set_combo:
      0082F5 E5 82            [12] 1302 	mov	a,dpl
      0082F7 90 0A E1         [24] 1303 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      0082FA F0               [24] 1304 	movx	@dptr,a
                                   1305 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0082FB 90 0A DE         [24] 1306 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0082FE 12 37 A2         [24] 1307 	lcall	_ak820_outline_0004
                                   1308 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008301 C0 07            [24] 1309 	push	ar7
      008303 C0 06            [24] 1310 	push	ar6
      008305 12 34 68         [24] 1311 	lcall	_ak820_combo_valid
      008308 E5 82            [12] 1312 	mov	a, dpl
      00830A D0 06            [24] 1313 	pop	ar6
      00830C D0 07            [24] 1314 	pop	ar7
      00830E 60 07            [24] 1315 	jz	00101$
      008310 12 3D D9         [24] 1316 	lcall	_ak820_nvm_ok
      008313 E5 82            [12] 1317 	mov	a, dpl
      008315 70 04            [24] 1318 	jnz	00102$
      008317                       1319 00101$:
      008317 90 FF FF         [24] 1320 	mov	dptr,#0xffff
      00831A 22               [24] 1321 	ret
      00831B                       1322 00102$:
                                   1323 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      00831B 90 0A E1         [24] 1324 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      00831E E0               [24] 1325 	movx	a,@dptr
      00831F FD               [12] 1326 	mov	r5,a
      008320 BD 08 00         [24] 1327 	cjne	r5,#0x08,00133$
      008323                       1328 00133$:
      008323 40 04            [24] 1329 	jc	00105$
                                   1330 ;	quantum/dynamic_keymap.c:342: return -1;
      008325 90 FF FF         [24] 1331 	mov	dptr,#0xffff
      008328 22               [24] 1332 	ret
      008329                       1333 00105$:
                                   1334 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008329 12 8B 17         [24] 1335 	lcall	_ak820_outline_0072
                                   1336 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      00832C C0 07            [24] 1337 	push	ar7
      00832E C0 06            [24] 1338 	push	ar6
      008330 C0 05            [24] 1339 	push	ar5
      008332 C0 04            [24] 1340 	push	ar4
      008334 12 73 B0         [24] 1341 	lcall	_clear_keyboard
      008337 D0 04            [24] 1342 	pop	ar4
      008339 D0 05            [24] 1343 	pop	ar5
      00833B D0 06            [24] 1344 	pop	ar6
      00833D D0 07            [24] 1345 	pop	ar7
                                   1346 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      00833F 90 0D 67         [24] 1347 	mov	dptr,#___memcpy_PARM_2
      008342 12 47 03         [24] 1348 	lcall	_ak820_outline_0055
      008345 E4               [12] 1349 	clr	a
      008346 A3               [24] 1350 	inc	dptr
      008347 F0               [24] 1351 	movx	@dptr,a
      008348 90 0D 6A         [24] 1352 	mov	dptr,#___memcpy_PARM_3
      00834B 12 8B 2B         [24] 1353 	lcall	_ak820_outline_0085
      00834E 90 0A E2         [24] 1354 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008351 F5 F0            [12] 1355 	mov	b,a
      008353 C0 05            [24] 1356 	push	ar5
      008355 C0 04            [24] 1357 	push	ar4
      008357 12 B3 DC         [24] 1358 	lcall	___memcpy
      00835A D0 04            [24] 1359 	pop	ar4
      00835C D0 05            [24] 1360 	pop	ar5
                                   1361 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      00835E 90 0A E6         [24] 1362 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0004)
      008361 74 20            [12] 1363 	mov	a,#0x20
      008363 F0               [24] 1364 	movx	@dptr,a
      008364 74 08            [12] 1365 	mov	a,#0x08
      008366 A3               [24] 1366 	inc	dptr
      008367 F0               [24] 1367 	movx	@dptr,a
                                   1368 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008368 90 0A E8         [24] 1369 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0006)
      00836B 74 01            [12] 1370 	mov	a,#0x01
      00836D 12 38 58         [24] 1371 	lcall	_ak820_outline_0114
                                   1372 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008370 90 05 8A         [24] 1373 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008373 EC               [12] 1374 	mov	a,r4
      008374 F0               [24] 1375 	movx	@dptr,a
      008375 ED               [12] 1376 	mov	a,r5
      008376 12 38 1E         [24] 1377 	lcall	_ak820_outline_0067
      008379 90 05 8D         [24] 1378 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00837C 12 8B 2B         [24] 1379 	lcall	_ak820_outline_0085
      00837F 90 0A E2         [24] 1380 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008382 12 40 FA         [24] 1381 	lcall	_ak820_eeprom_write_block_xdata
                                   1382 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008385 12 3D E8         [24] 1383 	lcall	_ak820_nvm_flush
                                   1384 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008388 12 3D D9         [24] 1385 	lcall	_ak820_nvm_ok
      00838B E5 82            [12] 1386 	mov	a, dpl
      00838D 70 04            [24] 1387 	jnz	00107$
      00838F 90 FF FF         [24] 1388 	mov	dptr,#0xffff
      008392 22               [24] 1389 	ret
      008393                       1390 00107$:
                                   1391 ;	quantum/dynamic_keymap.c:360: return 0;
      008393 90 00 00         [24] 1392 	mov	dptr,#0x0000
                                   1393 ;	quantum/dynamic_keymap.c:361: }
      008396 22               [24] 1394 	ret
                                   1395 ;------------------------------------------------------------
                                   1396 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1397 ;------------------------------------------------------------
                                   1398 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_398'
                                   1399 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_399'
                                   1400 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_401'
                                   1401 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_403'
                                   1402 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_405'
                                   1403 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_407'
                                   1404 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_408'
                                   1405 ;------------------------------------------------------------
                                   1406 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1407 ;	-----------------------------------------
                                   1408 ;	 function dynamic_keymap_reset
                                   1409 ;	-----------------------------------------
      008397                       1410 _dynamic_keymap_reset:
                                   1411 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008397 90 0D E6         [24] 1412 	mov	dptr,#_vial_unlocked
      00839A E0               [24] 1413 	movx	a,@dptr
      00839B 90 0A EC         [24] 1414 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      00839E F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      00839F 90 0D E6         [24] 1417 	mov	dptr,#_vial_unlocked
      0083A2 74 01            [12] 1418 	mov	a,#0x01
      0083A4 F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0083A5 7F 00            [12] 1421 	mov	r7,#0x00
      0083A7                       1422 00116$:
      0083A7 BF 06 00         [24] 1423 	cjne	r7,#0x06,00198$
      0083AA                       1424 00198$:
      0083AA 40 03            [24] 1425 	jc	00199$
      0083AC 02 84 5A         [24] 1426 	ljmp	00104$
      0083AF                       1427 00199$:
                                   1428 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0083AF 7E 00            [12] 1429 	mov	r6,#0x00
      0083B1                       1430 00110$:
      0083B1 BE 10 00         [24] 1431 	cjne	r6,#0x10,00200$
      0083B4                       1432 00200$:
      0083B4 50 4D            [24] 1433 	jnc	00102$
                                   1434 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0083B6 7D 00            [12] 1435 	mov	r5,#0x00
      0083B8                       1436 00107$:
      0083B8 BD 08 00         [24] 1437 	cjne	r5,#0x08,00202$
      0083BB                       1438 00202$:
      0083BB 50 43            [24] 1439 	jnc	00111$
                                   1440 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      0083BD 90 0B 88         [24] 1441 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      0083C0 EE               [12] 1442 	mov	a,r6
      0083C1 F0               [24] 1443 	movx	@dptr,a
      0083C2 90 0B 89         [24] 1444 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      0083C5 ED               [12] 1445 	mov	a,r5
      0083C6 F0               [24] 1446 	movx	@dptr,a
      0083C7 8F 82            [24] 1447 	mov	dpl, r7
      0083C9 C0 07            [24] 1448 	push	ar7
      0083CB C0 06            [24] 1449 	push	ar6
      0083CD C0 05            [24] 1450 	push	ar5
      0083CF 12 93 65         [24] 1451 	lcall	_keycode_at_keymap_location_raw
      0083D2 AB 82            [24] 1452 	mov	r3, dpl
      0083D4 AC 83            [24] 1453 	mov	r4, dph
      0083D6 D0 05            [24] 1454 	pop	ar5
      0083D8 D0 06            [24] 1455 	pop	ar6
      0083DA D0 07            [24] 1456 	pop	ar7
      0083DC 90 0A CB         [24] 1457 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0083DF EE               [12] 1458 	mov	a,r6
      0083E0 F0               [24] 1459 	movx	@dptr,a
      0083E1 90 0A CC         [24] 1460 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0083E4 ED               [12] 1461 	mov	a,r5
      0083E5 F0               [24] 1462 	movx	@dptr,a
      0083E6 90 0A CD         [24] 1463 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0083E9 12 38 2A         [24] 1464 	lcall	_ak820_outline_0071
      0083EC 8F 82            [24] 1465 	mov	dpl, r7
      0083EE C0 07            [24] 1466 	push	ar7
      0083F0 C0 06            [24] 1467 	push	ar6
      0083F2 C0 05            [24] 1468 	push	ar5
      0083F4 12 81 09         [24] 1469 	lcall	_dynamic_keymap_set_keycode
      0083F7 D0 05            [24] 1470 	pop	ar5
      0083F9 D0 06            [24] 1471 	pop	ar6
      0083FB D0 07            [24] 1472 	pop	ar7
                                   1473 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0083FD 0D               [12] 1474 	inc	r5
      0083FE 80 B8            [24] 1475 	sjmp	00107$
      008400                       1476 00111$:
                                   1477 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008400 0E               [12] 1478 	inc	r6
      008401 80 AE            [24] 1479 	sjmp	00110$
      008403                       1480 00102$:
                                   1481 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008403 7E 00            [12] 1482 	mov	r6,#0x00
      008405                       1483 00113$:
      008405 BE 01 00         [24] 1484 	cjne	r6,#0x01,00204$
      008408                       1485 00204$:
      008408 50 4C            [24] 1486 	jnc	00117$
                                   1487 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      00840A 12 8B 6D         [24] 1488 	lcall	_ak820_outline_0166
      00840D 04               [12] 1489 	inc	a
      00840E F0               [24] 1490 	movx	@dptr,a
      00840F 8F 82            [24] 1491 	mov	dpl, r7
      008411 C0 07            [24] 1492 	push	ar7
      008413 12 93 AA         [24] 1493 	lcall	_keycode_at_encodermap_location_raw
      008416 12 43 35         [24] 1494 	lcall	_ak820_outline_0137
      008419 D0 07            [24] 1495 	pop	ar7
      00841B 12 8B 64         [24] 1496 	lcall	_ak820_outline_0165
      00841E 04               [12] 1497 	inc	a
      00841F F0               [24] 1498 	movx	@dptr,a
      008420 90 0A D7         [24] 1499 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008423 12 38 24         [24] 1500 	lcall	_ak820_outline_0070
      008426 8F 82            [24] 1501 	mov	dpl, r7
      008428 C0 07            [24] 1502 	push	ar7
      00842A 12 81 E4         [24] 1503 	lcall	_dynamic_keymap_set_encoder
      00842D D0 07            [24] 1504 	pop	ar7
                                   1505 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      00842F 12 8B 6D         [24] 1506 	lcall	_ak820_outline_0166
      008432 F0               [24] 1507 	movx	@dptr,a
      008433 8F 82            [24] 1508 	mov	dpl, r7
      008435 C0 07            [24] 1509 	push	ar7
      008437 12 93 AA         [24] 1510 	lcall	_keycode_at_encodermap_location_raw
      00843A 12 43 35         [24] 1511 	lcall	_ak820_outline_0137
      00843D D0 07            [24] 1512 	pop	ar7
      00843F 12 8B 64         [24] 1513 	lcall	_ak820_outline_0165
      008442 F0               [24] 1514 	movx	@dptr,a
      008443 90 0A D7         [24] 1515 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008446 12 38 24         [24] 1516 	lcall	_ak820_outline_0070
      008449 8F 82            [24] 1517 	mov	dpl, r7
      00844B C0 07            [24] 1518 	push	ar7
      00844D 12 81 E4         [24] 1519 	lcall	_dynamic_keymap_set_encoder
      008450 D0 07            [24] 1520 	pop	ar7
                                   1521 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008452 7E 01            [12] 1522 	mov	r6,#0x01
      008454 80 AF            [24] 1523 	sjmp	00113$
      008456                       1524 00117$:
                                   1525 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008456 0F               [12] 1526 	inc	r7
      008457 02 83 A7         [24] 1527 	ljmp	00116$
      00845A                       1528 00104$:
                                   1529 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      00845A 90 0A ED         [24] 1530 	mov	dptr,#_dynamic_keymap_reset_combo_10001_407
      00845D 12 4D 8A         [24] 1531 	lcall	_ak820_outline_0157
      008460 90 0A EF         [24] 1532 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0002)
      008463 F0               [24] 1533 	movx	@dptr,a
      008464 A3               [24] 1534 	inc	dptr
      008465 F0               [24] 1535 	movx	@dptr,a
      008466 90 0A F1         [24] 1536 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0004)
      008469 F0               [24] 1537 	movx	@dptr,a
      00846A A3               [24] 1538 	inc	dptr
      00846B F0               [24] 1539 	movx	@dptr,a
      00846C 90 0A F3         [24] 1540 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0006)
      00846F F0               [24] 1541 	movx	@dptr,a
      008470 A3               [24] 1542 	inc	dptr
      008471 F0               [24] 1543 	movx	@dptr,a
      008472 90 0A F5         [24] 1544 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0008)
      008475 F0               [24] 1545 	movx	@dptr,a
      008476 A3               [24] 1546 	inc	dptr
      008477 F0               [24] 1547 	movx	@dptr,a
                                   1548 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008478 FF               [12] 1549 	mov	r7,a
      008479                       1550 00119$:
      008479 BF 08 00         [24] 1551 	cjne	r7,#0x08,00206$
      00847C                       1552 00206$:
      00847C 50 17            [24] 1553 	jnc	00105$
                                   1554 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      00847E 90 0A DE         [24] 1555 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008481 74 ED            [12] 1556 	mov	a,#_dynamic_keymap_reset_combo_10001_407
      008483 F0               [24] 1557 	movx	@dptr,a
      008484 74 0A            [12] 1558 	mov	a,#(_dynamic_keymap_reset_combo_10001_407 >> 8)
      008486 12 38 1E         [24] 1559 	lcall	_ak820_outline_0067
      008489 8F 82            [24] 1560 	mov	dpl, r7
      00848B C0 07            [24] 1561 	push	ar7
      00848D 12 82 F5         [24] 1562 	lcall	_dynamic_keymap_set_combo
      008490 D0 07            [24] 1563 	pop	ar7
                                   1564 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008492 0F               [12] 1565 	inc	r7
      008493 80 E4            [24] 1566 	sjmp	00119$
      008495                       1567 00105$:
                                   1568 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008495 90 0A EC         [24] 1569 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      008498 E0               [24] 1570 	movx	a,@dptr
      008499 90 0D E6         [24] 1571 	mov	dptr,#_vial_unlocked
      00849C F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/dynamic_keymap.c:468: }
      00849D 22               [24] 1574 	ret
                                   1575 ;------------------------------------------------------------
                                   1576 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1577 ;------------------------------------------------------------
                                   1578 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1579 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1580 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1581 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1582 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1583 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_409'
                                   1584 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_410'
                                   1585 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_410'
                                   1586 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_413'
                                   1587 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_415'
                                   1588 ;------------------------------------------------------------
                                   1589 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1590 ;	-----------------------------------------
                                   1591 ;	 function ak820_dynamic_read_buffer
                                   1592 ;	-----------------------------------------
      00849E                       1593 _ak820_dynamic_read_buffer:
      00849E 12 38 3C         [24] 1594 	lcall	_ak820_outline_0098
      0084A1 90 0B 00         [24] 1595 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      0084A4 12 38 41         [24] 1596 	lcall	_ak820_outline_0099
                                   1597 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0084A7 90 0A FD         [24] 1598 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0084AA 12 37 F9         [24] 1599 	lcall	_ak820_outline_0047
                                   1600 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      0084AD 90 0B 02         [24] 1601 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      0084B0 E4               [12] 1602 	clr	a
      0084B1 F0               [24] 1603 	movx	@dptr,a
                                   1604 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      0084B2 90 0A FB         [24] 1605 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0084B5 12 38 18         [24] 1606 	lcall	_ak820_outline_0056
      0084B8 8C 02            [24] 1607 	mov	ar2,r4
      0084BA 8D 03            [24] 1608 	mov	ar3,r5
      0084BC C3               [12] 1609 	clr	c
      0084BD 74 1C            [12] 1610 	mov	a,#0x1c
      0084BF 9A               [12] 1611 	subb	a,r2
      0084C0 E4               [12] 1612 	clr	a
      0084C1 9B               [12] 1613 	subb	a,r3
      0084C2 50 01            [24] 1614 	jnc	00102$
                                   1615 ;	free result
      0084C4 22               [24] 1616 	ret
      0084C5                       1617 00102$:
                                   1618 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      0084C5 90 0A F9         [24] 1619 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0084C8 12 43 02         [24] 1620 	lcall	_ak820_outline_0093
      0084CB 90 0A F7         [24] 1621 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0084CE 12 38 36         [24] 1622 	lcall	_ak820_outline_0092
      0084D1 C3               [12] 1623 	clr	c
      0084D2 EA               [12] 1624 	mov	a,r2
      0084D3 98               [12] 1625 	subb	a,r0
      0084D4 EB               [12] 1626 	mov	a,r3
      0084D5 99               [12] 1627 	subb	a,r1
      0084D6 50 17            [24] 1628 	jnc	00104$
                                   1629 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      0084D8 E8               [12] 1630 	mov	a,r0
      0084D9 C3               [12] 1631 	clr	c
      0084DA 9A               [12] 1632 	subb	a,r2
      0084DB F8               [12] 1633 	mov	r0,a
      0084DC E9               [12] 1634 	mov	a,r1
      0084DD 9B               [12] 1635 	subb	a,r3
      0084DE F9               [12] 1636 	mov	r1,a
                                   1637 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      0084DF C3               [12] 1638 	clr	c
      0084E0 E8               [12] 1639 	mov	a,r0
      0084E1 9C               [12] 1640 	subb	a,r4
      0084E2 E9               [12] 1641 	mov	a,r1
      0084E3 9D               [12] 1642 	subb	a,r5
      0084E4 40 04            [24] 1643 	jc	00114$
      0084E6 8C 00            [24] 1644 	mov	ar0,r4
      0084E8 8D 01            [24] 1645 	mov	ar1,r5
      0084EA                       1646 00114$:
      0084EA 90 0B 02         [24] 1647 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      0084ED E8               [12] 1648 	mov	a,r0
      0084EE F0               [24] 1649 	movx	@dptr,a
      0084EF                       1650 00104$:
                                   1651 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0084EF 90 0B 02         [24] 1652 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      0084F2 E0               [24] 1653 	movx	a,@dptr
      0084F3 F5 2B            [12] 1654 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      0084F5 E0               [24] 1655 	movx	a,@dptr
      0084F6 60 42            [24] 1656 	jz	00106$
      0084F8 C0 04            [24] 1657 	push	ar4
      0084FA C0 05            [24] 1658 	push	ar5
      0084FC 8E 00            [24] 1659 	mov	ar0,r6
      0084FE 8F 05            [24] 1660 	mov	ar5,r7
      008500 90 0B 00         [24] 1661 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      008503 E0               [24] 1662 	movx	a,@dptr
      008504 F9               [12] 1663 	mov	r1,a
      008505 A3               [24] 1664 	inc	dptr
      008506 E0               [24] 1665 	movx	a,@dptr
      008507 FC               [12] 1666 	mov	r4,a
      008508 EA               [12] 1667 	mov	a,r2
      008509 29               [12] 1668 	add	a, r1
      00850A FA               [12] 1669 	mov	r2,a
      00850B EB               [12] 1670 	mov	a,r3
      00850C 3C               [12] 1671 	addc	a, r4
      00850D FB               [12] 1672 	mov	r3,a
      00850E 90 05 81         [24] 1673 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008511 EA               [12] 1674 	mov	a,r2
      008512 F0               [24] 1675 	movx	@dptr,a
      008513 EB               [12] 1676 	mov	a,r3
      008514 12 38 1E         [24] 1677 	lcall	_ak820_outline_0067
      008517 90 05 84         [24] 1678 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00851A E5 2B            [12] 1679 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      00851C 12 38 58         [24] 1680 	lcall	_ak820_outline_0114
      00851F 88 82            [24] 1681 	mov	dpl, r0
      008521 8D 83            [24] 1682 	mov	dph, r5
      008523 C0 07            [24] 1683 	push	ar7
      008525 C0 06            [24] 1684 	push	ar6
      008527 C0 05            [24] 1685 	push	ar5
      008529 C0 04            [24] 1686 	push	ar4
      00852B 12 40 6E         [24] 1687 	lcall	_ak820_eeprom_read_block_xdata
      00852E D0 04            [24] 1688 	pop	ar4
      008530 D0 05            [24] 1689 	pop	ar5
      008532 D0 06            [24] 1690 	pop	ar6
      008534 D0 07            [24] 1691 	pop	ar7
                                   1692 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008536 D0 05            [24] 1693 	pop	ar5
      008538 D0 04            [24] 1694 	pop	ar4
                                   1695 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      00853A                       1696 00106$:
                                   1697 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      00853A 90 0B 02         [24] 1698 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      00853D E0               [24] 1699 	movx	a,@dptr
      00853E FB               [12] 1700 	mov	r3,a
      00853F                       1701 00109$:
      00853F 8B 01            [24] 1702 	mov	ar1,r3
      008541 7A 00            [12] 1703 	mov	r2,#0x00
      008543 C3               [12] 1704 	clr	c
      008544 E9               [12] 1705 	mov	a,r1
      008545 9C               [12] 1706 	subb	a,r4
      008546 EA               [12] 1707 	mov	a,r2
      008547 9D               [12] 1708 	subb	a,r5
      008548 50 09            [24] 1709 	jnc	00111$
      00854A EB               [12] 1710 	mov	a,r3
      00854B 12 37 E9         [24] 1711 	lcall	_ak820_outline_0018
      00854E E4               [12] 1712 	clr	a
      00854F F0               [24] 1713 	movx	@dptr,a
      008550 0B               [12] 1714 	inc	r3
      008551 80 EC            [24] 1715 	sjmp	00109$
      008553                       1716 00111$:
                                   1717 ;	quantum/dynamic_keymap.c:483: }
      008553 22               [24] 1718 	ret
                                   1719 ;------------------------------------------------------------
                                   1720 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1721 ;------------------------------------------------------------
                                   1722 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1723 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1724 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_416'
                                   1725 ;------------------------------------------------------------
                                   1726 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1727 ;	-----------------------------------------
                                   1728 ;	 function dynamic_keymap_get_buffer
                                   1729 ;	-----------------------------------------
      008554                       1730 _dynamic_keymap_get_buffer:
      008554 12 38 3C         [24] 1731 	lcall	_ak820_outline_0098
      008557 90 0B 08         [24] 1732 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      00855A 12 38 41         [24] 1733 	lcall	_ak820_outline_0099
                                   1734 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      00855D 90 0B 08         [24] 1735 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008560 12 37 F9         [24] 1736 	lcall	_ak820_outline_0047
      008563 90 0B 03         [24] 1737 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008566 12 38 18         [24] 1738 	lcall	_ak820_outline_0056
      008569 90 0B 05         [24] 1739 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00856C 12 4D 71         [24] 1740 	lcall	_ak820_outline_0081
      00856F 90 0A F7         [24] 1741 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008572 E4               [12] 1742 	clr	a
      008573 F0               [24] 1743 	movx	@dptr,a
      008574 74 06            [12] 1744 	mov	a,#0x06
      008576 A3               [24] 1745 	inc	dptr
      008577 F0               [24] 1746 	movx	@dptr,a
      008578 90 0A F9         [24] 1747 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      00857B 12 47 03         [24] 1748 	lcall	_ak820_outline_0055
      00857E 90 0A FB         [24] 1749 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008581 12 38 24         [24] 1750 	lcall	_ak820_outline_0070
      008584 90 0A FD         [24] 1751 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008587 E9               [12] 1752 	mov	a,r1
      008588 12 4D 83         [24] 1753 	lcall	_ak820_outline_0143
      00858B F0               [24] 1754 	movx	@dptr,a
      00858C 90 00 40         [24] 1755 	mov	dptr,#0x0040
                                   1756 ;	quantum/dynamic_keymap.c:511: }
      00858F 02 84 9E         [24] 1757 	ljmp	_ak820_dynamic_read_buffer
                                   1758 ;------------------------------------------------------------
                                   1759 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1760 ;------------------------------------------------------------
                                   1761 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1762 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1763 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1764 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1765 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1766 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_418'
                                   1767 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_419'
                                   1768 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_419'
                                   1769 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_419'
                                   1770 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_422'
                                   1771 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_425'
                                   1772 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_425'
                                   1773 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_427'
                                   1774 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_430'
                                   1775 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_432'
                                   1776 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_433'
                                   1777 ;------------------------------------------------------------
                                   1778 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1779 ;	-----------------------------------------
                                   1780 ;	 function dynamic_keymap_set_buffer
                                   1781 ;	-----------------------------------------
      008592                       1782 _dynamic_keymap_set_buffer:
      008592 12 38 3C         [24] 1783 	lcall	_ak820_outline_0098
      008595 90 0B 0F         [24] 1784 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008598 12 38 41         [24] 1785 	lcall	_ak820_outline_0099
                                   1786 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      00859B 90 0B 0F         [24] 1787 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      00859E 12 37 CD         [24] 1788 	lcall	_ak820_outline_0009
      0085A1 74 40            [12] 1789 	mov	a,#0x40
      0085A3 2C               [12] 1790 	add	a, r4
      0085A4 FA               [12] 1791 	mov	r2,a
      0085A5 E4               [12] 1792 	clr	a
      0085A6 3D               [12] 1793 	addc	a, r5
      0085A7 FB               [12] 1794 	mov	r3,a
                                   1795 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0085A8 90 0B 0C         [24] 1796 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      0085AB 12 38 36         [24] 1797 	lcall	_ak820_outline_0092
                                   1798 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      0085AE 90 0B 0A         [24] 1799 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      0085B1 E0               [24] 1800 	movx	a,@dptr
      0085B2 F5 2C            [12] 1801 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      0085B4 A3               [24] 1802 	inc	dptr
      0085B5 E0               [24] 1803 	movx	a,@dptr
      0085B6 F5 2D            [12] 1804 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      0085B8 E5 2C            [12] 1805 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0085BA 45 2D            [12] 1806 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0085BC 70 01            [24] 1807 	jnz	00102$
      0085BE 22               [24] 1808 	ret
      0085BF                       1809 00102$:
                                   1810 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      0085BF 85 2C 2E         [24] 1811 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      0085C2 85 2D 2F         [24] 1812 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0085C5 C3               [12] 1813 	clr	c
      0085C6 74 1C            [12] 1814 	mov	a,#0x1c
      0085C8 95 2E            [12] 1815 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      0085CA E4               [12] 1816 	clr	a
      0085CB 95 2F            [12] 1817 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      0085CD 50 01            [24] 1818 	jnc	00104$
                                   1819 ;	free result
      0085CF 22               [24] 1820 	ret
      0085D0                       1821 00104$:
                                   1822 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      0085D0 85 2C 30         [24] 1823 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1824 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      0085D3 74 FA            [12] 1825 	mov	a,#0x100 - 0x06
      0085D5 2F               [12] 1826 	add	a,r7
      0085D6 40 11            [24] 1827 	jc	00105$
      0085D8 E4               [12] 1828 	clr	a
      0085D9 C3               [12] 1829 	clr	c
      0085DA 9E               [12] 1830 	subb	a,r6
      0085DB FE               [12] 1831 	mov	r6,a
      0085DC 74 06            [12] 1832 	mov	a,#0x06
      0085DE 9F               [12] 1833 	subb	a,r7
      0085DF FF               [12] 1834 	mov	r7,a
      0085E0 C3               [12] 1835 	clr	c
      0085E1 EE               [12] 1836 	mov	a,r6
      0085E2 95 2C            [12] 1837 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0085E4 EF               [12] 1838 	mov	a,r7
      0085E5 95 2D            [12] 1839 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0085E7 50 01            [24] 1840 	jnc	00106$
      0085E9                       1841 00105$:
                                   1842 ;	quantum/dynamic_keymap.c:529: return;
      0085E9 22               [24] 1843 	ret
      0085EA                       1844 00106$:
                                   1845 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      0085EA 90 0D E6         [24] 1846 	mov	dptr,#_vial_unlocked
      0085ED E0               [24] 1847 	movx	a,@dptr
      0085EE 60 03            [24] 1848 	jz	00207$
      0085F0 02 86 FE         [24] 1849 	ljmp	00120$
      0085F3                       1850 00207$:
                                   1851 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      0085F3 90 0B 11         [24] 1852 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      0085F6 E4               [12] 1853 	clr	a
      0085F7 F0               [24] 1854 	movx	@dptr,a
                                   1855 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      0085F8 90 0B 12         [24] 1856 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      0085FB E5 30            [12] 1857 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0085FD F0               [24] 1858 	movx	@dptr,a
                                   1859 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      0085FE EC               [12] 1860 	mov	a,r4
      0085FF 30 E0 33         [24] 1861 	jnb	acc.0,00111$
                                   1862 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008602 EA               [12] 1863 	mov	a,r2
      008603 24 FF            [12] 1864 	add	a,#0xff
      008605 FE               [12] 1865 	mov	r6,a
      008606 EB               [12] 1866 	mov	a,r3
      008607 34 FF            [12] 1867 	addc	a,#0xff
      008609 FF               [12] 1868 	mov	r7,a
      00860A 7D 00            [12] 1869 	mov	r5,#0x00
      00860C 12 43 1A         [24] 1870 	lcall	_ak820_outline_0109
      00860F 8D F0            [24] 1871 	mov	b, r5
      008611 12 40 33         [24] 1872 	lcall	_eeprom_read_byte
      008614 AE 82            [24] 1873 	mov	r6,dpl
      008616 7F 00            [12] 1874 	mov	r7,#0x00
      008618 12 38 6E         [24] 1875 	lcall	_ak820_outline_0144
      00861B E0               [24] 1876 	movx	a,@dptr
      00861C 7C 00            [12] 1877 	mov	r4,#0x00
      00861E 42 07            [12] 1878 	orl	ar7,a
      008620 EC               [12] 1879 	mov	a,r4
      008621 42 06            [12] 1880 	orl	ar6,a
                                   1881 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008623 BF 00 09         [24] 1882 	cjne	r7,#0x00,00109$
      008626 BE 7C 06         [24] 1883 	cjne	r6,#0x7c,00109$
                                   1884 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008629 12 38 6E         [24] 1885 	lcall	_ak820_outline_0144
      00862C 74 FF            [12] 1886 	mov	a,#0xff
      00862E F0               [24] 1887 	movx	@dptr,a
      00862F                       1888 00109$:
                                   1889 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      00862F 90 0B 11         [24] 1890 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008632 74 01            [12] 1891 	mov	a,#0x01
      008634 F0               [24] 1892 	movx	@dptr,a
      008635                       1893 00111$:
                                   1894 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008635 90 0B 0F         [24] 1895 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008638 12 37 F9         [24] 1896 	lcall	_ak820_outline_0047
      00863B E5 2C            [12] 1897 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      00863D 2E               [12] 1898 	add	a, r6
      00863E FE               [12] 1899 	mov	r6,a
      00863F E5 2D            [12] 1900 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008641 3F               [12] 1901 	addc	a, r7
      008642 EE               [12] 1902 	mov	a,r6
      008643 30 E0 5A         [24] 1903 	jnb	acc.0,00115$
                                   1904 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008646 AE 30            [24] 1905 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008648 7F 00            [12] 1906 	mov	r7,#0x00
      00864A EE               [12] 1907 	mov	a,r6
      00864B 24 FF            [12] 1908 	add	a,#0xff
      00864D FC               [12] 1909 	mov	r4,a
      00864E EF               [12] 1910 	mov	a,r7
      00864F 34 FF            [12] 1911 	addc	a,#0xff
      008651 FD               [12] 1912 	mov	r5,a
      008652 EC               [12] 1913 	mov	a,r4
      008653 28               [12] 1914 	add	a, r0
      008654 F5 82            [12] 1915 	mov	dpl,a
      008656 ED               [12] 1916 	mov	a,r5
      008657 39               [12] 1917 	addc	a, r1
      008658 F5 83            [12] 1918 	mov	dph,a
      00865A E0               [24] 1919 	movx	a,@dptr
      00865B FC               [12] 1920 	mov	r4,a
      00865C 7D 00            [12] 1921 	mov	r5,#0x00
      00865E E5 30            [12] 1922 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008660 2A               [12] 1923 	add	a, r2
      008661 FA               [12] 1924 	mov	r2,a
      008662 E4               [12] 1925 	clr	a
      008663 3B               [12] 1926 	addc	a, r3
      008664 FB               [12] 1927 	mov	r3,a
      008665 C0 00            [24] 1928 	push	ar0
      008667 C0 01            [24] 1929 	push	ar1
      008669 8B 01            [24] 1930 	mov	ar1,r3
      00866B 7B 00            [12] 1931 	mov	r3,#0x00
      00866D 8A 82            [24] 1932 	mov	dpl, r2
      00866F 89 83            [24] 1933 	mov	dph, r1
      008671 8B F0            [24] 1934 	mov	b, r3
      008673 12 40 33         [24] 1935 	lcall	_eeprom_read_byte
      008676 AB 82            [24] 1936 	mov	r3, dpl
      008678 7A 00            [12] 1937 	mov	r2,#0x00
      00867A EB               [12] 1938 	mov	a,r3
      00867B 12 43 2A         [24] 1939 	lcall	_ak820_outline_0131
                                   1940 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      00867E BD 00 05         [24] 1941 	cjne	r5,#0x00,00212$
      008681 BC 7C 02         [24] 1942 	cjne	r4,#0x7c,00212$
      008684 80 06            [24] 1943 	sjmp	00213$
      008686                       1944 00212$:
      008686 D0 01            [24] 1945 	pop	ar1
      008688 D0 00            [24] 1946 	pop	ar0
      00868A 80 0D            [24] 1947 	sjmp	00113$
      00868C                       1948 00213$:
      00868C D0 01            [24] 1949 	pop	ar1
      00868E D0 00            [24] 1950 	pop	ar0
                                   1951 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008690 1E               [12] 1952 	dec	r6
      008691 BE FF 01         [24] 1953 	cjne	r6,#0xff,00214$
      008694 1F               [12] 1954 	dec	r7
      008695                       1955 00214$:
      008695 EE               [12] 1956 	mov	a,r6
      008696 12 8B 46         [24] 1957 	lcall	_ak820_outline_0118
      008699                       1958 00113$:
                                   1959 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008699 E5 30            [12] 1960 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      00869B 14               [12] 1961 	dec	a
      00869C 90 0B 12         [24] 1962 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      00869F F0               [24] 1963 	movx	@dptr,a
      0086A0                       1964 00115$:
                                   1965 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      0086A0 90 0B 11         [24] 1966 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      0086A3 E0               [24] 1967 	movx	a,@dptr
      0086A4 90 0B 13         [24] 1968 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      0086A7 F0               [24] 1969 	movx	@dptr,a
      0086A8                       1970 00122$:
      0086A8 90 0B 13         [24] 1971 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      0086AB E0               [24] 1972 	movx	a,@dptr
      0086AC FF               [12] 1973 	mov	r7,a
      0086AD 90 0B 12         [24] 1974 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      0086B0 E0               [24] 1975 	movx	a,@dptr
      0086B1 FE               [12] 1976 	mov	r6,a
      0086B2 C3               [12] 1977 	clr	c
      0086B3 EF               [12] 1978 	mov	a,r7
      0086B4 9E               [12] 1979 	subb	a,r6
      0086B5 50 47            [24] 1980 	jnc	00120$
                                   1981 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      0086B7 EF               [12] 1982 	mov	a,r7
      0086B8 28               [12] 1983 	add	a, r0
      0086B9 FD               [12] 1984 	mov	r5,a
      0086BA E4               [12] 1985 	clr	a
      0086BB 39               [12] 1986 	addc	a, r1
      0086BC 12 46 FB         [24] 1987 	lcall	_ak820_outline_0053
      0086BF 7B 00            [12] 1988 	mov	r3,#0x00
      0086C1 8C 2D            [24] 1989 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      0086C3 8B 2C            [24] 1990 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      0086C5 8F 02            [24] 1991 	mov	ar2,r7
      0086C7 7F 00            [12] 1992 	mov	r7,#0x00
      0086C9 74 01            [12] 1993 	mov	a,#0x01
      0086CB 2A               [12] 1994 	add	a, r2
      0086CC FB               [12] 1995 	mov	r3,a
      0086CD E4               [12] 1996 	clr	a
      0086CE 3F               [12] 1997 	addc	a, r7
      0086CF FC               [12] 1998 	mov	r4,a
      0086D0 EB               [12] 1999 	mov	a,r3
      0086D1 28               [12] 2000 	add	a, r0
      0086D2 F5 82            [12] 2001 	mov	dpl,a
      0086D4 EC               [12] 2002 	mov	a,r4
      0086D5 39               [12] 2003 	addc	a, r1
      0086D6 F5 83            [12] 2004 	mov	dph,a
      0086D8 E0               [24] 2005 	movx	a,@dptr
      0086D9 FC               [12] 2006 	mov	r4,a
      0086DA 7B 00            [12] 2007 	mov	r3,#0x00
      0086DC E5 2D            [12] 2008 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0086DE 42 03            [12] 2009 	orl	ar3,a
                                   2010 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      0086E0 BC 00 12         [24] 2011 	cjne	r4,#0x00,00123$
      0086E3 BB 7C 0F         [24] 2012 	cjne	r3,#0x7c,00123$
                                   2013 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      0086E6 12 38 5D         [24] 2014 	lcall	_ak820_outline_0122
      0086E9 74 FF            [12] 2015 	mov	a,#0xff
      0086EB F0               [24] 2016 	movx	@dptr,a
                                   2017 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      0086EC 0A               [12] 2018 	inc	r2
      0086ED BA 00 01         [24] 2019 	cjne	r2,#0x00,00218$
      0086F0 0F               [12] 2020 	inc	r7
      0086F1                       2021 00218$:
      0086F1 EA               [12] 2022 	mov	a,r2
      0086F2 12 8B 46         [24] 2023 	lcall	_ak820_outline_0118
      0086F5                       2024 00123$:
                                   2025 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      0086F5 90 0B 13         [24] 2026 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      0086F8 E0               [24] 2027 	movx	a,@dptr
      0086F9 24 02            [12] 2028 	add	a,#0x02
      0086FB F0               [24] 2029 	movx	@dptr,a
      0086FC 80 AA            [24] 2030 	sjmp	00122$
      0086FE                       2031 00120$:
                                   2032 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      0086FE 90 0B 0F         [24] 2033 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008701 12 37 F9         [24] 2034 	lcall	_ak820_outline_0047
      008704 74 40            [12] 2035 	mov	a,#0x40
      008706 12 43 24         [24] 2036 	lcall	_ak820_outline_0125
      008709 90 05 8A         [24] 2037 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00870C 12 47 03         [24] 2038 	lcall	_ak820_outline_0055
      00870F E4               [12] 2039 	clr	a
      008710 A3               [24] 2040 	inc	dptr
      008711 F0               [24] 2041 	movx	@dptr,a
      008712 90 05 8D         [24] 2042 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008715 E5 2E            [12] 2043 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008717 F0               [24] 2044 	movx	@dptr,a
      008718 E5 2F            [12] 2045 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      00871A A3               [24] 2046 	inc	dptr
      00871B F0               [24] 2047 	movx	@dptr,a
      00871C 12 38 6E         [24] 2048 	lcall	_ak820_outline_0144
                                   2049 ;	quantum/dynamic_keymap.c:584: }
      00871F 02 40 FA         [24] 2050 	ljmp	_ak820_eeprom_write_block_xdata
                                   2051 ;------------------------------------------------------------
                                   2052 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2053 ;------------------------------------------------------------
                                   2054 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2055 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2056 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_436'
                                   2057 ;------------------------------------------------------------
                                   2058 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2059 ;	-----------------------------------------
                                   2060 ;	 function keycode_at_keymap_location
                                   2061 ;	-----------------------------------------
      008722                       2062 _keycode_at_keymap_location:
      008722 E5 82            [12] 2063 	mov	a,dpl
      008724 90 0B 16         [24] 2064 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_436
      008727 F0               [24] 2065 	movx	@dptr,a
                                   2066 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008728 E0               [24] 2067 	movx	a,@dptr
      008729 FF               [12] 2068 	mov	r7,a
      00872A BF 06 00         [24] 2069 	cjne	r7,#0x06,00128$
      00872D                       2070 00128$:
      00872D 50 23            [24] 2071 	jnc	00102$
      00872F 90 0B 14         [24] 2072 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008732 E0               [24] 2073 	movx	a,@dptr
      008733 FE               [12] 2074 	mov	r6,a
      008734 BE 10 00         [24] 2075 	cjne	r6,#0x10,00130$
      008737                       2076 00130$:
      008737 50 19            [24] 2077 	jnc	00102$
      008739 90 0B 15         [24] 2078 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      00873C E0               [24] 2079 	movx	a,@dptr
      00873D FD               [12] 2080 	mov	r5,a
      00873E BD 08 00         [24] 2081 	cjne	r5,#0x08,00132$
      008741                       2082 00132$:
      008741 50 0F            [24] 2083 	jnc	00102$
                                   2084 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008743 90 0A C8         [24] 2085 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008746 EE               [12] 2086 	mov	a,r6
      008747 F0               [24] 2087 	movx	@dptr,a
      008748 90 0A C9         [24] 2088 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00874B ED               [12] 2089 	mov	a,r5
      00874C F0               [24] 2090 	movx	@dptr,a
      00874D 8F 82            [24] 2091 	mov	dpl, r7
      00874F 02 80 BB         [24] 2092 	ljmp	_dynamic_keymap_get_keycode
      008752                       2093 00102$:
                                   2094 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008752 90 00 00         [24] 2095 	mov	dptr,#0x0000
                                   2096 ;	quantum/dynamic_keymap.c:591: }
      008755 22               [24] 2097 	ret
                                   2098 ;------------------------------------------------------------
                                   2099 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2100 ;------------------------------------------------------------
                                   2101 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2102 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2103 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_440'
                                   2104 ;------------------------------------------------------------
                                   2105 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2106 ;	-----------------------------------------
                                   2107 ;	 function keycode_at_encodermap_location
                                   2108 ;	-----------------------------------------
      008756                       2109 _keycode_at_encodermap_location:
      008756 E5 82            [12] 2110 	mov	a,dpl
      008758 90 0B 19         [24] 2111 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_440
      00875B F0               [24] 2112 	movx	@dptr,a
                                   2113 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      00875C E0               [24] 2114 	movx	a,@dptr
      00875D FF               [12] 2115 	mov	r7,a
      00875E BF 06 00         [24] 2116 	cjne	r7,#0x06,00120$
      008761                       2117 00120$:
      008761 50 1E            [24] 2118 	jnc	00102$
      008763 90 0B 17         [24] 2119 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008766 E0               [24] 2120 	movx	a,@dptr
      008767 FE               [12] 2121 	mov	r6,a
      008768 BE 01 00         [24] 2122 	cjne	r6,#0x01,00122$
      00876B                       2123 00122$:
      00876B 50 14            [24] 2124 	jnc	00102$
                                   2125 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      00876D 90 0B 18         [24] 2126 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008770 E0               [24] 2127 	movx	a,@dptr
      008771 FE               [12] 2128 	mov	r6,a
      008772 90 0A D2         [24] 2129 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008775 E4               [12] 2130 	clr	a
      008776 F0               [24] 2131 	movx	@dptr,a
      008777 90 0A D3         [24] 2132 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00877A EE               [12] 2133 	mov	a,r6
      00877B F0               [24] 2134 	movx	@dptr,a
      00877C 8F 82            [24] 2135 	mov	dpl, r7
      00877E 02 81 7C         [24] 2136 	ljmp	_dynamic_keymap_get_encoder
      008781                       2137 00102$:
                                   2138 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008781 90 00 00         [24] 2139 	mov	dptr,#0x0000
                                   2140 ;	quantum/dynamic_keymap.c:599: }
      008784 22               [24] 2141 	ret
                                   2142 ;------------------------------------------------------------
                                   2143 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2144 ;------------------------------------------------------------
                                   2145 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2146 ;	-----------------------------------------
                                   2147 ;	 function dynamic_keymap_macro_get_count
                                   2148 ;	-----------------------------------------
      008785                       2149 _dynamic_keymap_macro_get_count:
                                   2150 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008785 75 82 10         [24] 2151 	mov	dpl, #0x10
                                   2152 ;	quantum/dynamic_keymap.c:604: }
      008788 22               [24] 2153 	ret
                                   2154 ;------------------------------------------------------------
                                   2155 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2156 ;------------------------------------------------------------
                                   2157 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2158 ;	-----------------------------------------
                                   2159 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2160 ;	-----------------------------------------
      008789                       2161 _dynamic_keymap_macro_get_buffer_size:
                                   2162 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008789 90 20 00         [24] 2163 	mov	dptr,#0x2000
                                   2164 ;	quantum/dynamic_keymap.c:608: }
      00878C 22               [24] 2165 	ret
                                   2166 ;------------------------------------------------------------
                                   2167 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2168 ;------------------------------------------------------------
                                   2169 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2170 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2171 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2172 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_448'
                                   2173 ;------------------------------------------------------------
                                   2174 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2175 ;	-----------------------------------------
                                   2176 ;	 function dynamic_keymap_macro_get_buffer
                                   2177 ;	-----------------------------------------
      00878D                       2178 _dynamic_keymap_macro_get_buffer:
      00878D 12 38 3C         [24] 2179 	lcall	_ak820_outline_0098
      008790 90 0B 1F         [24] 2180 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      008793 12 38 41         [24] 2181 	lcall	_ak820_outline_0099
                                   2182 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008796 12 2B 2B         [24] 2183 	lcall	_ak820_macro_length
      008799 12 43 1F         [24] 2184 	lcall	_ak820_outline_0123
      00879C 90 0B 1F         [24] 2185 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      00879F 12 38 18         [24] 2186 	lcall	_ak820_outline_0056
      0087A2 90 0B 1A         [24] 2187 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      0087A5 E0               [24] 2188 	movx	a,@dptr
      0087A6 F5 31            [12] 2189 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      0087A8 A3               [24] 2190 	inc	dptr
      0087A9 E0               [24] 2191 	movx	a,@dptr
      0087AA F5 32            [12] 2192 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      0087AC 90 0B 1C         [24] 2193 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      0087AF 12 38 36         [24] 2194 	lcall	_ak820_outline_0092
      0087B2 A3               [24] 2195 	inc	dptr
      0087B3 E0               [24] 2196 	movx	a,@dptr
      0087B4 FB               [12] 2197 	mov	r3,a
      0087B5 90 0A F7         [24] 2198 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0087B8 12 47 03         [24] 2199 	lcall	_ak820_outline_0055
      0087BB 90 0A F9         [24] 2200 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0087BE 12 38 24         [24] 2201 	lcall	_ak820_outline_0070
      0087C1 90 0A FB         [24] 2202 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0087C4 E5 31            [12] 2203 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      0087C6 F0               [24] 2204 	movx	@dptr,a
      0087C7 E5 32            [12] 2205 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      0087C9 A3               [24] 2206 	inc	dptr
      0087CA F0               [24] 2207 	movx	@dptr,a
      0087CB 90 0A FD         [24] 2208 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0087CE E8               [12] 2209 	mov	a,r0
      0087CF F0               [24] 2210 	movx	@dptr,a
      0087D0 E9               [12] 2211 	mov	a,r1
      0087D1 A3               [24] 2212 	inc	dptr
      0087D2 F0               [24] 2213 	movx	@dptr,a
      0087D3 EB               [12] 2214 	mov	a,r3
      0087D4 A3               [24] 2215 	inc	dptr
      0087D5 F0               [24] 2216 	movx	@dptr,a
      0087D6 90 08 00         [24] 2217 	mov	dptr,#0x0800
                                   2218 ;	quantum/dynamic_keymap.c:635: }
      0087D9 02 84 9E         [24] 2219 	ljmp	_ak820_dynamic_read_buffer
                                   2220 ;------------------------------------------------------------
                                   2221 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2222 ;------------------------------------------------------------
                                   2223 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2224 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2225 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_450'
                                   2226 ;------------------------------------------------------------
                                   2227 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2228 ;	-----------------------------------------
                                   2229 ;	 function dynamic_keymap_macro_set_buffer
                                   2230 ;	-----------------------------------------
      0087DC                       2231 _dynamic_keymap_macro_set_buffer:
      0087DC 12 38 3C         [24] 2232 	lcall	_ak820_outline_0098
      0087DF 90 0B 26         [24] 2233 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      0087E2 12 38 41         [24] 2234 	lcall	_ak820_outline_0099
                                   2235 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      0087E5 90 0B 26         [24] 2236 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      0087E8 12 37 F9         [24] 2237 	lcall	_ak820_outline_0047
      0087EB 90 0B 21         [24] 2238 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      0087EE 12 38 18         [24] 2239 	lcall	_ak820_outline_0056
      0087F1 90 0B 23         [24] 2240 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      0087F4 12 4D 71         [24] 2241 	lcall	_ak820_outline_0081
      0087F7 90 05 10         [24] 2242 	mov	dptr,#_ak820_macro_write_PARM_2
      0087FA 12 38 24         [24] 2243 	lcall	_ak820_outline_0070
      0087FD 90 05 12         [24] 2244 	mov	dptr,#_ak820_macro_write_PARM_3
      008800 E9               [12] 2245 	mov	a,r1
      008801 12 4D 83         [24] 2246 	lcall	_ak820_outline_0143
      008804 12 42 F6         [24] 2247 	lcall	_ak820_outline_0057
                                   2248 ;	quantum/dynamic_keymap.c:640: }
      008807 02 2B 45         [24] 2249 	ljmp	_ak820_macro_write
                                   2250 ;------------------------------------------------------------
                                   2251 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2252 ;------------------------------------------------------------
                                   2253 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2254 ;	-----------------------------------------
                                   2255 ;	 function dynamic_keymap_macro_reset
                                   2256 ;	-----------------------------------------
      00880A                       2257 _dynamic_keymap_macro_reset:
                                   2258 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2259 ;	quantum/dynamic_keymap.c:666: }
      00880A 02 2E 64         [24] 2260 	ljmp	_ak820_macro_reset
                                   2261 ;------------------------------------------------------------
                                   2262 ;Allocation info for local variables in function 'decode_keycode'
                                   2263 ;------------------------------------------------------------
                                   2264 ;kc            Allocated with name '_decode_keycode_kc_10000_454'
                                   2265 ;------------------------------------------------------------
                                   2266 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2267 ;	-----------------------------------------
                                   2268 ;	 function decode_keycode
                                   2269 ;	-----------------------------------------
      00880D                       2270 _decode_keycode:
      00880D 12 38 3C         [24] 2271 	lcall	_ak820_outline_0098
      008810 90 0B 28         [24] 2272 	mov	dptr,#_decode_keycode_kc_10000_454
      008813 12 38 41         [24] 2273 	lcall	_ak820_outline_0099
                                   2274 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      008816 90 0B 28         [24] 2275 	mov	dptr,#_decode_keycode_kc_10000_454
      008819 12 37 CD         [24] 2276 	lcall	_ak820_outline_0009
      00881C C3               [12] 2277 	clr	c
      00881D E4               [12] 2278 	clr	a
      00881E 9C               [12] 2279 	subb	a,r4
      00881F 74 FF            [12] 2280 	mov	a,#0xff
      008821 9D               [12] 2281 	subb	a,r5
      008822 50 08            [24] 2282 	jnc	00102$
                                   2283 ;	free result
                                   2284 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      008824 8C 05            [24] 2285 	mov	ar5,r4
      008826 7C 00            [12] 2286 	mov	r4,#0x00
      008828 12 38 4D         [24] 2287 	lcall	_ak820_outline_0110
      00882B 22               [24] 2288 	ret
      00882C                       2289 00102$:
                                   2290 ;	quantum/dynamic_keymap.c:672: return kc;
      00882C 12 43 1A         [24] 2291 	lcall	_ak820_outline_0109
                                   2292 ;	quantum/dynamic_keymap.c:673: }
      00882F 22               [24] 2293 	ret
                                   2294 ;------------------------------------------------------------
                                   2295 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2296 ;------------------------------------------------------------
                                   2297 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_457'
                                   2298 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_458'
                                   2299 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_463'
                                   2300 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_464'
                                   2301 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_470'
                                   2302 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_488'
                                   2303 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_492'
                                   2304 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_492'
                                   2305 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_494'
                                   2306 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_496'
                                   2307 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_500'
                                   2308 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_502'
                                   2309 ;------------------------------------------------------------
                                   2310 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2311 ;	-----------------------------------------
                                   2312 ;	 function dynamic_keymap_macro_send
                                   2313 ;	-----------------------------------------
      008830                       2314 _dynamic_keymap_macro_send:
      008830 E5 82            [12] 2315 	mov	a,dpl
      008832 90 0B 2A         [24] 2316 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008835 F0               [24] 2317 	movx	@dptr,a
                                   2318 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      008836 90 0B 2B         [24] 2319 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008839 E0               [24] 2320 	movx	a,@dptr
      00883A 60 01            [24] 2321 	jz	00102$
      00883C 22               [24] 2322 	ret
      00883D                       2323 00102$:
                                   2324 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      00883D 90 0B 2A         [24] 2325 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008840 E0               [24] 2326 	movx	a,@dptr
      008841 FF               [12] 2327 	mov	r7,a
      008842 BF 10 00         [24] 2328 	cjne	r7,#0x10,00422$
      008845                       2329 00422$:
      008845 40 01            [24] 2330 	jc	00104$
                                   2331 ;	quantum/dynamic_keymap.c:683: return;
      008847 22               [24] 2332 	ret
      008848                       2333 00104$:
                                   2334 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      008848 C0 07            [24] 2335 	push	ar7
      00884A 12 2A F2         [24] 2336 	lcall	_ak820_macro_ready
      00884D E5 82            [12] 2337 	mov	a, dpl
      00884F D0 07            [24] 2338 	pop	ar7
      008851 70 01            [24] 2339 	jnz	00106$
      008853 22               [24] 2340 	ret
      008854                       2341 00106$:
                                   2342 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008854 90 0B 2C         [24] 2343 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008857 E4               [12] 2344 	clr	a
      008858 F0               [24] 2345 	movx	@dptr,a
      008859 74 08            [12] 2346 	mov	a,#0x08
      00885B A3               [24] 2347 	inc	dptr
      00885C F0               [24] 2348 	movx	@dptr,a
                                   2349 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      00885D C0 07            [24] 2350 	push	ar7
      00885F 12 2B 2B         [24] 2351 	lcall	_ak820_macro_length
      008862 AD 82            [24] 2352 	mov	r5, dpl
      008864 AE 83            [24] 2353 	mov	r6, dph
      008866 D0 07            [24] 2354 	pop	ar7
      008868 74 08            [12] 2355 	mov	a,#0x08
      00886A 2E               [12] 2356 	add	a, r6
      00886B FE               [12] 2357 	mov	r6,a
                                   2358 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      00886C 7B 00            [12] 2359 	mov	r3,#0x00
      00886E 7C 08            [12] 2360 	mov	r4,#0x08
      008870                       2361 00111$:
      008870 EF               [12] 2362 	mov	a,r7
      008871 60 31            [24] 2363 	jz	00113$
                                   2364 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008873 EB               [12] 2365 	mov	a,r3
      008874 B5 05 05         [24] 2366 	cjne	a,ar5,00108$
      008877 EC               [12] 2367 	mov	a,r4
      008878 B5 06 01         [24] 2368 	cjne	a,ar6,00108$
                                   2369 ;	quantum/dynamic_keymap.c:717: return;
      00887B 22               [24] 2370 	ret
      00887C                       2371 00108$:
                                   2372 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      00887C 8B 01            [24] 2373 	mov	ar1,r3
      00887E 8C 02            [24] 2374 	mov	ar2,r4
      008880 8A 00            [24] 2375 	mov	ar0,r2
      008882 7A 00            [12] 2376 	mov	r2,#0x00
      008884 89 82            [24] 2377 	mov	dpl, r1
      008886 88 83            [24] 2378 	mov	dph, r0
      008888 8A F0            [24] 2379 	mov	b, r2
      00888A 12 40 33         [24] 2380 	lcall	_eeprom_read_byte
      00888D E5 82            [12] 2381 	mov	a, dpl
      00888F 70 06            [24] 2382 	jnz	00110$
                                   2383 ;	quantum/dynamic_keymap.c:720: --id;
      008891 1F               [12] 2384 	dec	r7
      008892 90 0B 2A         [24] 2385 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008895 EF               [12] 2386 	mov	a,r7
      008896 F0               [24] 2387 	movx	@dptr,a
      008897                       2388 00110$:
                                   2389 ;	quantum/dynamic_keymap.c:722: ++p;
      008897 0B               [12] 2390 	inc	r3
      008898 BB 00 01         [24] 2391 	cjne	r3,#0x00,00429$
      00889B 0C               [12] 2392 	inc	r4
      00889C                       2393 00429$:
      00889C 90 0B 2C         [24] 2394 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      00889F 12 38 2A         [24] 2395 	lcall	_ak820_outline_0071
      0088A2 80 CC            [24] 2396 	sjmp	00111$
      0088A4                       2397 00113$:
                                   2398 ;	quantum/dynamic_keymap.c:728: sending = true;
      0088A4 90 0B 2B         [24] 2399 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      0088A7 74 01            [12] 2400 	mov	a,#0x01
      0088A9 F0               [24] 2401 	movx	@dptr,a
                                   2402 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      0088AA 12 8B 5E         [24] 2403 	lcall	_ak820_outline_0152
      0088AD 90 09 74         [24] 2404 	mov	dptr,#_ak820_macro_cancelled
      0088B0 F0               [24] 2405 	movx	@dptr,a
                                   2406 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      0088B1 90 0B 2E         [24] 2407 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      0088B4 F0               [24] 2408 	movx	@dptr,a
      0088B5 90 0B 2F         [24] 2409 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      0088B8 F0               [24] 2410 	movx	@dptr,a
      0088B9 90 0B 30         [24] 2411 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      0088BC F0               [24] 2412 	movx	@dptr,a
      0088BD 90 0B 31         [24] 2413 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      0088C0 F0               [24] 2414 	movx	@dptr,a
                                   2415 ;	quantum/dynamic_keymap.c:738: while (p < end
      0088C1                       2416 00167$:
                                   2417 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      0088C1 90 0B 2C         [24] 2418 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      0088C4 E0               [24] 2419 	movx	a,@dptr
      0088C5 FC               [12] 2420 	mov	r4,a
      0088C6 A3               [24] 2421 	inc	dptr
      0088C7 E0               [24] 2422 	movx	a,@dptr
      0088C8 FF               [12] 2423 	mov	r7,a
      0088C9 C3               [12] 2424 	clr	c
      0088CA EC               [12] 2425 	mov	a,r4
      0088CB 9D               [12] 2426 	subb	a,r5
      0088CC EF               [12] 2427 	mov	a,r7
      0088CD 9E               [12] 2428 	subb	a,r6
      0088CE 40 03            [24] 2429 	jc	00430$
      0088D0 02 8A E5         [24] 2430 	ljmp	00169$
      0088D3                       2431 00430$:
      0088D3 90 09 74         [24] 2432 	mov	dptr,#_ak820_macro_cancelled
      0088D6 E0               [24] 2433 	movx	a,@dptr
      0088D7 60 03            [24] 2434 	jz	00431$
      0088D9 02 8A E5         [24] 2435 	ljmp	00169$
      0088DC                       2436 00431$:
                                   2437 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0088DC 8C 02            [24] 2438 	mov	ar2,r4
      0088DE 8F 03            [24] 2439 	mov	ar3,r7
      0088E0 90 0B 2C         [24] 2440 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      0088E3 74 01            [12] 2441 	mov	a,#0x01
      0088E5 2C               [12] 2442 	add	a, r4
      0088E6 F0               [24] 2443 	movx	@dptr,a
      0088E7 E4               [12] 2444 	clr	a
      0088E8 3F               [12] 2445 	addc	a, r7
      0088E9 A3               [24] 2446 	inc	dptr
      0088EA F0               [24] 2447 	movx	@dptr,a
      0088EB 7F 00            [12] 2448 	mov	r7,#0x00
      0088ED 12 43 30         [24] 2449 	lcall	_ak820_outline_0132
      0088F0 8F F0            [24] 2450 	mov	b, r7
      0088F2 12 40 33         [24] 2451 	lcall	_eeprom_read_byte
      0088F5 AF 82            [24] 2452 	mov	r7, dpl
      0088F7 90 0B 2E         [24] 2453 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      0088FA EF               [12] 2454 	mov	a,r7
      0088FB F0               [24] 2455 	movx	@dptr,a
                                   2456 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      0088FC 90 0B 2F         [24] 2457 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      0088FF E4               [12] 2458 	clr	a
      008900 F0               [24] 2459 	movx	@dptr,a
                                   2460 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      008901 90 0B 2E         [24] 2461 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008904 E0               [24] 2462 	movx	a,@dptr
      008905 70 03            [24] 2463 	jnz	00432$
      008907 02 8A E5         [24] 2464 	ljmp	00169$
      00890A                       2465 00432$:
                                   2466 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      00890A 90 0B 2E         [24] 2467 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      00890D E0               [24] 2468 	movx	a,@dptr
      00890E FF               [12] 2469 	mov	r7,a
      00890F BF 01 02         [24] 2470 	cjne	r7,#0x01,00433$
      008912 80 03            [24] 2471 	sjmp	00434$
      008914                       2472 00433$:
      008914 02 8A C7         [24] 2473 	ljmp	00164$
      008917                       2474 00434$:
                                   2475 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008917 12 8A ED         [24] 2476 	lcall	_ak820_outline_0000
      00891A 12 40 33         [24] 2477 	lcall	_eeprom_read_byte
      00891D AF 82            [24] 2478 	mov	r7, dpl
      00891F 90 0B 2F         [24] 2479 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008922 EF               [12] 2480 	mov	a,r7
      008923 F0               [24] 2481 	movx	@dptr,a
                                   2482 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      008924 EF               [12] 2483 	mov	a,r7
      008925 70 03            [24] 2484 	jnz	00435$
      008927 02 8A E5         [24] 2485 	ljmp	00169$
      00892A                       2486 00435$:
                                   2487 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      00892A 12 8B 25         [24] 2488 	lcall	_ak820_outline_0084
      00892D BF 01 02         [24] 2489 	cjne	r7,#0x01,00436$
      008930 80 13            [24] 2490 	sjmp	00151$
      008932                       2491 00436$:
      008932 12 8B 25         [24] 2492 	lcall	_ak820_outline_0084
      008935 BF 02 02         [24] 2493 	cjne	r7,#0x02,00437$
      008938 80 0B            [24] 2494 	sjmp	00151$
      00893A                       2495 00437$:
      00893A 12 8B 25         [24] 2496 	lcall	_ak820_outline_0084
      00893D BF 03 02         [24] 2497 	cjne	r7,#0x03,00438$
      008940 80 03            [24] 2498 	sjmp	00439$
      008942                       2499 00438$:
      008942 02 89 A6         [24] 2500 	ljmp	00152$
      008945                       2501 00439$:
      008945                       2502 00151$:
                                   2503 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008945 12 8A ED         [24] 2504 	lcall	_ak820_outline_0000
      008948 12 40 33         [24] 2505 	lcall	_eeprom_read_byte
      00894B 12 8B 76         [24] 2506 	lcall	_ak820_outline_0169
                                   2507 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      00894E 70 03            [24] 2508 	jnz	00440$
      008950 02 88 C1         [24] 2509 	ljmp	00167$
      008953                       2510 00440$:
                                   2511 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008953 12 8B 25         [24] 2512 	lcall	_ak820_outline_0084
      008956 BF 01 03         [24] 2513 	cjne	r7,#0x01,00441$
      008959 D3               [12] 2514 	setb	c
      00895A 80 01            [24] 2515 	sjmp	00442$
      00895C                       2516 00441$:
      00895C C3               [12] 2517 	clr	c
      00895D                       2518 00442$:
      00895D 92 22            [24] 2519 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      00895F 90 09 73         [24] 2520 	mov	dptr,#_ak820_macro_primitive
      008962 B3               [12] 2521 	cpl	c
      008963 E4               [12] 2522 	clr	a
      008964 33               [12] 2523 	rlc	a
      008965 F0               [24] 2524 	movx	@dptr,a
                                   2525 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008966 12 8B 25         [24] 2526 	lcall	_ak820_outline_0084
      008969 BF 01 10         [24] 2527 	cjne	r7,#0x01,00122$
      00896C 12 8B 57         [24] 2528 	lcall	_ak820_outline_0139
      00896F C0 06            [24] 2529 	push	ar6
      008971 C0 05            [24] 2530 	push	ar5
      008973 12 73 43         [24] 2531 	lcall	_tap_code
      008976 D0 05            [24] 2532 	pop	ar5
      008978 D0 06            [24] 2533 	pop	ar6
      00897A 80 24            [24] 2534 	sjmp	00123$
      00897C                       2535 00122$:
                                   2536 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      00897C 12 8B 25         [24] 2537 	lcall	_ak820_outline_0084
      00897F BF 02 10         [24] 2538 	cjne	r7,#0x02,00119$
      008982 12 8B 57         [24] 2539 	lcall	_ak820_outline_0139
      008985 C0 06            [24] 2540 	push	ar6
      008987 C0 05            [24] 2541 	push	ar5
      008989 12 72 3D         [24] 2542 	lcall	_register_code
      00898C D0 05            [24] 2543 	pop	ar5
      00898E D0 06            [24] 2544 	pop	ar6
      008990 80 0E            [24] 2545 	sjmp	00123$
      008992                       2546 00119$:
                                   2547 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      008992 12 8B 57         [24] 2548 	lcall	_ak820_outline_0139
      008995 C0 06            [24] 2549 	push	ar6
      008997 C0 05            [24] 2550 	push	ar5
      008999 12 72 AA         [24] 2551 	lcall	_unregister_code
      00899C D0 05            [24] 2552 	pop	ar5
      00899E D0 06            [24] 2553 	pop	ar6
      0089A0                       2554 00123$:
                                   2555 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      0089A0 12 8B 5E         [24] 2556 	lcall	_ak820_outline_0152
      0089A3 02 88 C1         [24] 2557 	ljmp	00167$
      0089A6                       2558 00152$:
                                   2559 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      0089A6 12 8B 25         [24] 2560 	lcall	_ak820_outline_0084
      0089A9 BF 05 02         [24] 2561 	cjne	r7,#0x05,00447$
      0089AC 80 13            [24] 2562 	sjmp	00146$
      0089AE                       2563 00447$:
      0089AE 12 8B 25         [24] 2564 	lcall	_ak820_outline_0084
      0089B1 BF 06 02         [24] 2565 	cjne	r7,#0x06,00448$
      0089B4 80 0B            [24] 2566 	sjmp	00146$
      0089B6                       2567 00448$:
      0089B6 12 8B 25         [24] 2568 	lcall	_ak820_outline_0084
      0089B9 BF 07 02         [24] 2569 	cjne	r7,#0x07,00449$
      0089BC 80 03            [24] 2570 	sjmp	00450$
      0089BE                       2571 00449$:
      0089BE 02 8A 67         [24] 2572 	ljmp	00147$
      0089C1                       2573 00450$:
      0089C1                       2574 00146$:
                                   2575 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0089C1 12 8A ED         [24] 2576 	lcall	_ak820_outline_0000
      0089C4 12 40 33         [24] 2577 	lcall	_eeprom_read_byte
      0089C7 12 8B 76         [24] 2578 	lcall	_ak820_outline_0169
                                   2579 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      0089CA 70 03            [24] 2580 	jnz	00451$
      0089CC 02 88 C1         [24] 2581 	ljmp	00167$
      0089CF                       2582 00451$:
                                   2583 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0089CF 12 8A ED         [24] 2584 	lcall	_ak820_outline_0000
      0089D2 12 40 33         [24] 2585 	lcall	_eeprom_read_byte
      0089D5 AF 82            [24] 2586 	mov	r7, dpl
      0089D7 90 0B 31         [24] 2587 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      0089DA EF               [12] 2588 	mov	a,r7
      0089DB F0               [24] 2589 	movx	@dptr,a
                                   2590 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      0089DC EF               [12] 2591 	mov	a,r7
      0089DD 70 03            [24] 2592 	jnz	00452$
      0089DF 02 88 C1         [24] 2593 	ljmp	00167$
      0089E2                       2594 00452$:
                                   2595 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      0089E2 90 0B 30         [24] 2596 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      0089E5 E0               [24] 2597 	movx	a,@dptr
      0089E6 FF               [12] 2598 	mov	r7,a
      0089E7 90 0B 31         [24] 2599 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      0089EA E0               [24] 2600 	movx	a,@dptr
      0089EB FB               [12] 2601 	mov	r3,a
      0089EC E4               [12] 2602 	clr	a
      0089ED FC               [12] 2603 	mov	r4,a
      0089EE FA               [12] 2604 	mov	r2,a
      0089EF EF               [12] 2605 	mov	a,r7
      0089F0 42 04            [12] 2606 	orl	ar4,a
      0089F2 EA               [12] 2607 	mov	a,r2
      0089F3 42 03            [12] 2608 	orl	ar3,a
                                   2609 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      0089F5 12 43 50         [24] 2610 	lcall	_ak820_outline_0171
      0089F8 C0 06            [24] 2611 	push	ar6
      0089FA C0 05            [24] 2612 	push	ar5
      0089FC 12 88 0D         [24] 2613 	lcall	_decode_keycode
      0089FF AC 82            [24] 2614 	mov	r4, dpl
      008A01 AF 83            [24] 2615 	mov	r7, dph
      008A03 D0 05            [24] 2616 	pop	ar5
      008A05 D0 06            [24] 2617 	pop	ar6
                                   2618 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008A07 90 0B 2F         [24] 2619 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008A0A E0               [24] 2620 	movx	a,@dptr
      008A0B FB               [12] 2621 	mov	r3,a
      008A0C BB 05 03         [24] 2622 	cjne	r3,#0x05,00453$
      008A0F D3               [12] 2623 	setb	c
      008A10 80 01            [24] 2624 	sjmp	00454$
      008A12                       2625 00453$:
      008A12 C3               [12] 2626 	clr	c
      008A13                       2627 00454$:
      008A13 92 22            [24] 2628 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008A15 90 09 73         [24] 2629 	mov	dptr,#_ak820_macro_primitive
      008A18 B3               [12] 2630 	cpl	c
      008A19 E4               [12] 2631 	clr	a
      008A1A 33               [12] 2632 	rlc	a
      008A1B F0               [24] 2633 	movx	@dptr,a
                                   2634 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      008A1C 90 0B 2F         [24] 2635 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008A1F E0               [24] 2636 	movx	a,@dptr
      008A20 FB               [12] 2637 	mov	r3,a
      008A21 BB 05 02         [24] 2638 	cjne	r3,#0x05,00455$
      008A24 80 0A            [24] 2639 	sjmp	00126$
      008A26                       2640 00455$:
      008A26 BB 06 02         [24] 2641 	cjne	r3,#0x06,00456$
      008A29 80 16            [24] 2642 	sjmp	00127$
      008A2B                       2643 00456$:
                                   2644 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      008A2B BB 07 33         [24] 2645 	cjne	r3,#0x07,00129$
      008A2E 80 22            [24] 2646 	sjmp	00128$
      008A30                       2647 00126$:
                                   2648 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      008A30 8C 82            [24] 2649 	mov	dpl, r4
      008A32 8F 83            [24] 2650 	mov	dph, r7
      008A34 C0 06            [24] 2651 	push	ar6
      008A36 C0 05            [24] 2652 	push	ar5
      008A38 12 AD E5         [24] 2653 	lcall	_vial_keycode_tap
      008A3B D0 05            [24] 2654 	pop	ar5
      008A3D D0 06            [24] 2655 	pop	ar6
                                   2656 ;	quantum/dynamic_keymap.c:795: break;
                                   2657 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      008A3F 80 20            [24] 2658 	sjmp	00129$
      008A41                       2659 00127$:
                                   2660 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      008A41 8C 82            [24] 2661 	mov	dpl, r4
      008A43 8F 83            [24] 2662 	mov	dph, r7
      008A45 C0 06            [24] 2663 	push	ar6
      008A47 C0 05            [24] 2664 	push	ar5
      008A49 12 AD 1A         [24] 2665 	lcall	_vial_keycode_down
      008A4C D0 05            [24] 2666 	pop	ar5
      008A4E D0 06            [24] 2667 	pop	ar6
                                   2668 ;	quantum/dynamic_keymap.c:798: break;
                                   2669 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      008A50 80 0F            [24] 2670 	sjmp	00129$
      008A52                       2671 00128$:
                                   2672 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      008A52 8C 82            [24] 2673 	mov	dpl, r4
      008A54 8F 83            [24] 2674 	mov	dph, r7
      008A56 C0 06            [24] 2675 	push	ar6
      008A58 C0 05            [24] 2676 	push	ar5
      008A5A 12 AD 80         [24] 2677 	lcall	_vial_keycode_up
      008A5D D0 05            [24] 2678 	pop	ar5
      008A5F D0 06            [24] 2679 	pop	ar6
                                   2680 ;	quantum/dynamic_keymap.c:802: }
      008A61                       2681 00129$:
                                   2682 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      008A61 12 8B 5E         [24] 2683 	lcall	_ak820_outline_0152
      008A64 02 88 C1         [24] 2684 	ljmp	00167$
      008A67                       2685 00147$:
                                   2686 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      008A67 12 8B 25         [24] 2687 	lcall	_ak820_outline_0084
      008A6A BF 04 02         [24] 2688 	cjne	r7,#0x04,00458$
      008A6D 80 03            [24] 2689 	sjmp	00459$
      008A6F                       2690 00458$:
      008A6F 02 88 C1         [24] 2691 	ljmp	00167$
      008A72                       2692 00459$:
                                   2693 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008A72 12 8A ED         [24] 2694 	lcall	_ak820_outline_0000
      008A75 12 40 33         [24] 2695 	lcall	_eeprom_read_byte
      008A78 AF 82            [24] 2696 	mov	r7, dpl
                                   2697 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008A7A 90 0B 2C         [24] 2698 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008A7D 12 38 52         [24] 2699 	lcall	_ak820_outline_0112
      008A80 90 0B 2C         [24] 2700 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008A83 74 01            [12] 2701 	mov	a,#0x01
      008A85 2B               [12] 2702 	add	a, r3
      008A86 F0               [24] 2703 	movx	@dptr,a
      008A87 E4               [12] 2704 	clr	a
      008A88 3C               [12] 2705 	addc	a, r4
      008A89 A3               [24] 2706 	inc	dptr
      008A8A F0               [24] 2707 	movx	@dptr,a
      008A8B 7A 00            [12] 2708 	mov	r2,#0x00
      008A8D 12 33 FC         [24] 2709 	lcall	_ak820_outline_0113
      008A90 8A F0            [24] 2710 	mov	b, r2
      008A92 12 40 33         [24] 2711 	lcall	_eeprom_read_byte
      008A95 AC 82            [24] 2712 	mov	r4, dpl
                                   2713 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      008A97 EF               [12] 2714 	mov	a,r7
      008A98 60 4B            [24] 2715 	jz	00169$
      008A9A EC               [12] 2716 	mov	a,r4
      008A9B 60 48            [24] 2717 	jz	00169$
                                   2718 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008A9D 1F               [12] 2719 	dec	r7
      008A9E 1C               [12] 2720 	dec	r4
      008A9F EC               [12] 2721 	mov	a,r4
      008AA0 75 F0 FF         [24] 2722 	mov	b,#0xff
      008AA3 A4               [48] 2723 	mul	ab
      008AA4 FC               [12] 2724 	mov	r4,a
      008AA5 AB F0            [24] 2725 	mov	r3,b
      008AA7 7A 00            [12] 2726 	mov	r2,#0x00
      008AA9 EC               [12] 2727 	mov	a,r4
      008AAA 2F               [12] 2728 	add	a, r7
      008AAB FC               [12] 2729 	mov	r4,a
      008AAC EB               [12] 2730 	mov	a,r3
      008AAD 3A               [12] 2731 	addc	a, r2
      008AAE FB               [12] 2732 	mov	r3,a
                                   2733 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      008AAF                       2734 00141$:
      008AAF 8C 02            [24] 2735 	mov	ar2,r4
      008AB1 8B 07            [24] 2736 	mov	ar7,r3
      008AB3 1C               [12] 2737 	dec	r4
      008AB4 BC FF 01         [24] 2738 	cjne	r4,#0xff,00462$
      008AB7 1B               [12] 2739 	dec	r3
      008AB8                       2740 00462$:
      008AB8 EA               [12] 2741 	mov	a,r2
      008AB9 4F               [12] 2742 	orl	a,r7
      008ABA 70 03            [24] 2743 	jnz	00463$
      008ABC 02 88 C1         [24] 2744 	ljmp	00167$
      008ABF                       2745 00463$:
      008ABF 90 00 01         [24] 2746 	mov	dptr,#0x0001
      008AC2 12 57 0D         [24] 2747 	lcall	_mDelaymS
      008AC5 80 E8            [24] 2748 	sjmp	00141$
      008AC7                       2749 00164$:
                                   2750 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      008AC7 90 0B 2E         [24] 2751 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008ACA E0               [24] 2752 	movx	a,@dptr
      008ACB FF               [12] 2753 	mov	r7,a
      008ACC BF 80 00         [24] 2754 	cjne	r7,#0x80,00464$
      008ACF                       2755 00464$:
      008ACF 50 14            [24] 2756 	jnc	00169$
                                   2757 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      008AD1 90 0B 2E         [24] 2758 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008AD4 E0               [24] 2759 	movx	a,@dptr
      008AD5 F5 82            [12] 2760 	mov	dpl,a
      008AD7 C0 06            [24] 2761 	push	ar6
      008AD9 C0 05            [24] 2762 	push	ar5
      008ADB 12 A0 74         [24] 2763 	lcall	_send_char
      008ADE D0 05            [24] 2764 	pop	ar5
      008AE0 D0 06            [24] 2765 	pop	ar6
                                   2766 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008AE2 02 88 C1         [24] 2767 	ljmp	00167$
      008AE5                       2768 00169$:
                                   2769 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      008AE5 12 8B 5E         [24] 2770 	lcall	_ak820_outline_0152
                                   2771 ;	quantum/dynamic_keymap.c:837: sending = false;
      008AE8 90 0B 2B         [24] 2772 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008AEB F0               [24] 2773 	movx	@dptr,a
                                   2774 ;	quantum/dynamic_keymap.c:839: }
      008AEC 22               [24] 2775 	ret
                                   2776 	.area CSEG    (CODE)
                                   2777 	.area CONST   (CODE)
                                   2778 	.area XINIT   (CODE)
                                   2779 	.area CABS    (ABS,CODE)
                                   2780 
                                   2781 ; Experimental exact instruction outlining.
                                   2782 	.globl _ak820_outline_0000
                                   2783 	.globl _ak820_outline_0004
                                   2784 	.globl _ak820_outline_0009
                                   2785 	.globl _ak820_outline_0011
                                   2786 	.globl _ak820_outline_0018
                                   2787 	.globl _ak820_outline_0023
                                   2788 	.globl _ak820_outline_0041
                                   2789 	.globl _ak820_outline_0047
                                   2790 	.globl _ak820_outline_0053
                                   2791 	.globl _ak820_outline_0055
                                   2792 	.globl _ak820_outline_0056
                                   2793 	.globl _ak820_outline_0057
                                   2794 	.globl _ak820_outline_0067
                                   2795 	.globl _ak820_outline_0070
                                   2796 	.globl _ak820_outline_0071
                                   2797 	.globl _ak820_outline_0072
                                   2798 	.globl _ak820_outline_0081
                                   2799 	.globl _ak820_outline_0084
                                   2800 	.globl _ak820_outline_0085
                                   2801 	.globl _ak820_outline_0089
                                   2802 	.globl _ak820_outline_0092
                                   2803 	.globl _ak820_outline_0093
                                   2804 	.globl _ak820_outline_0098
                                   2805 	.globl _ak820_outline_0099
                                   2806 	.globl _ak820_outline_0105
                                   2807 	.globl _ak820_outline_0109
                                   2808 	.globl _ak820_outline_0110
                                   2809 	.globl _ak820_outline_0112
                                   2810 	.globl _ak820_outline_0113
                                   2811 	.globl _ak820_outline_0114
                                   2812 	.globl _ak820_outline_0118
                                   2813 	.globl _ak820_outline_0122
                                   2814 	.globl _ak820_outline_0123
                                   2815 	.globl _ak820_outline_0124
                                   2816 	.globl _ak820_outline_0125
                                   2817 	.globl _ak820_outline_0131
                                   2818 	.globl _ak820_outline_0132
                                   2819 	.globl _ak820_outline_0137
                                   2820 	.globl _ak820_outline_0139
                                   2821 	.globl _ak820_outline_0143
                                   2822 	.globl _ak820_outline_0144
                                   2823 	.globl _ak820_outline_0147
                                   2824 	.globl _ak820_outline_0152
                                   2825 	.globl _ak820_outline_0157
                                   2826 	.globl _ak820_outline_0165
                                   2827 	.globl _ak820_outline_0166
                                   2828 	.globl _ak820_outline_0169
                                   2829 	.globl _ak820_outline_0170
                                   2830 	.globl _ak820_outline_0171
                                   2831 
                                   2832 	.area CSEG (CODE)
                                   2833 ; function ak820_outline_0000
      008AED                       2834 _ak820_outline_0000:
      008AED 90 0B 2C         [24] 2835 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008AF0 E0               [24] 2836 	movx	a,@dptr
      008AF1 FC               [12] 2837 	mov	r4,a
      008AF2 A3               [24] 2838 	inc	dptr
      008AF3 E0               [24] 2839 	movx	a,@dptr
      008AF4 FF               [12] 2840 	mov	r7,a
      008AF5 90 0B 2C         [24] 2841 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008AF8 74 01            [12] 2842 	mov	a,#0x01
      008AFA 2C               [12] 2843 	add	a,r4
      008AFB F0               [24] 2844 	movx	@dptr,a
      008AFC E4               [12] 2845 	clr	a
      008AFD 3F               [12] 2846 	addc	a,r7
      008AFE A3               [24] 2847 	inc	dptr
      008AFF F0               [24] 2848 	movx	@dptr,a
      008B00 7B 00            [12] 2849 	mov	r3,#0x00
      008B02 8C 82            [24] 2850 	mov	dpl,r4
      008B04 8F 83            [24] 2851 	mov	dph,r7
      008B06 8B F0            [24] 2852 	mov	b,r3
      008B08 22               [24] 2853 	ret
                                   2854 
                                   2855 	.area CSEG (CODE)
                                   2856 ; function ak820_outline_0023
      008B09                       2857 _ak820_outline_0023:
      008B09 2D               [12] 2858 	add	a,r5
      008B0A F9               [12] 2859 	mov	r1,a
      008B0B E4               [12] 2860 	clr	a
      008B0C 3E               [12] 2861 	addc	a,r6
      008B0D FA               [12] 2862 	mov	r2,a
      008B0E 8F 03            [24] 2863 	mov	ar3,r7
      008B10 89 82            [24] 2864 	mov	dpl,r1
      008B12 8A 83            [24] 2865 	mov	dph,r2
      008B14 8B F0            [24] 2866 	mov	b,r3
      008B16 22               [24] 2867 	ret
                                   2868 
                                   2869 	.area CSEG (CODE)
                                   2870 ; function ak820_outline_0072
      008B17                       2871 _ak820_outline_0072:
      008B17 ED               [12] 2872 	mov	a,r5
      008B18 75 F0 0A         [24] 2873 	mov	b,#0x0a
      008B1B A4               [48] 2874 	mul	ab
      008B1C 24 58            [12] 2875 	add	a,#0x58
      008B1E FC               [12] 2876 	mov	r4,a
      008B1F 74 06            [12] 2877 	mov	a,#0x06
      008B21 35 F0            [12] 2878 	addc	a,b
      008B23 FD               [12] 2879 	mov	r5,a
      008B24 22               [24] 2880 	ret
                                   2881 
                                   2882 	.area CSEG (CODE)
                                   2883 ; function ak820_outline_0084
      008B25                       2884 _ak820_outline_0084:
      008B25 90 0B 2F         [24] 2885 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0001)
      008B28 E0               [24] 2886 	movx	a,@dptr
      008B29 FF               [12] 2887 	mov	r7,a
      008B2A 22               [24] 2888 	ret
                                   2889 
                                   2890 	.area CSEG (CODE)
                                   2891 ; function ak820_outline_0085
      008B2B                       2892 _ak820_outline_0085:
      008B2B 74 0A            [12] 2893 	mov	a,#0x0a
      008B2D F0               [24] 2894 	movx	@dptr,a
      008B2E E4               [12] 2895 	clr	a
      008B2F A3               [24] 2896 	inc	dptr
      008B30 F0               [24] 2897 	movx	@dptr,a
      008B31 22               [24] 2898 	ret
                                   2899 
                                   2900 	.area CSEG (CODE)
                                   2901 ; function ak820_outline_0089
      008B32                       2902 _ak820_outline_0089:
      008B32 90 0A C5         [24] 2903 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008B35 EE               [12] 2904 	mov	a,r6
      008B36 F0               [24] 2905 	movx	@dptr,a
      008B37 90 0A C6         [24] 2906 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008B3A ED               [12] 2907 	mov	a,r5
      008B3B F0               [24] 2908 	movx	@dptr,a
      008B3C 8F 82            [24] 2909 	mov	dpl,r7
      008B3E 22               [24] 2910 	ret
                                   2911 
                                   2912 	.area CSEG (CODE)
                                   2913 ; function ak820_outline_0105
      008B3F                       2914 _ak820_outline_0105:
      008B3F AD 82            [24] 2915 	mov	r5,dpl
      008B41 AE 83            [24] 2916 	mov	r6,dph
      008B43 AF F0            [24] 2917 	mov	r7,b
      008B45 22               [24] 2918 	ret
                                   2919 
                                   2920 	.area CSEG (CODE)
                                   2921 ; function ak820_outline_0118
      008B46                       2922 _ak820_outline_0118:
      008B46 28               [12] 2923 	add	a,r0
      008B47 F5 82            [12] 2924 	mov	dpl,a
      008B49 EF               [12] 2925 	mov	a,r7
      008B4A 39               [12] 2926 	addc	a,r1
      008B4B F5 83            [12] 2927 	mov	dph,a
      008B4D 74 FF            [12] 2928 	mov	a,#0xff
      008B4F F0               [24] 2929 	movx	@dptr,a
      008B50 22               [24] 2930 	ret
                                   2931 
                                   2932 	.area CSEG (CODE)
                                   2933 ; function ak820_outline_0124
      008B51                       2934 _ak820_outline_0124:
      008B51 2D               [12] 2935 	add	a,r5
      008B52 F9               [12] 2936 	mov	r1,a
      008B53 E4               [12] 2937 	clr	a
      008B54 3E               [12] 2938 	addc	a,r6
      008B55 FA               [12] 2939 	mov	r2,a
      008B56 22               [24] 2940 	ret
                                   2941 
                                   2942 	.area CSEG (CODE)
                                   2943 ; function ak820_outline_0139
      008B57                       2944 _ak820_outline_0139:
      008B57 90 0B 30         [24] 2945 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008B5A E0               [24] 2946 	movx	a,@dptr
      008B5B F5 82            [12] 2947 	mov	dpl,a
      008B5D 22               [24] 2948 	ret
                                   2949 
                                   2950 	.area CSEG (CODE)
                                   2951 ; function ak820_outline_0152
      008B5E                       2952 _ak820_outline_0152:
      008B5E 90 09 73         [24] 2953 	mov	dptr,#_ak820_macro_primitive
      008B61 E4               [12] 2954 	clr	a
      008B62 F0               [24] 2955 	movx	@dptr,a
      008B63 22               [24] 2956 	ret
                                   2957 
                                   2958 	.area CSEG (CODE)
                                   2959 ; function ak820_outline_0165
      008B64                       2960 _ak820_outline_0165:
      008B64 90 0A D5         [24] 2961 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008B67 E4               [12] 2962 	clr	a
      008B68 F0               [24] 2963 	movx	@dptr,a
      008B69 90 0A D6         [24] 2964 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008B6C 22               [24] 2965 	ret
                                   2966 
                                   2967 	.area CSEG (CODE)
                                   2968 ; function ak820_outline_0166
      008B6D                       2969 _ak820_outline_0166:
      008B6D 90 0B 8B         [24] 2970 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      008B70 E4               [12] 2971 	clr	a
      008B71 F0               [24] 2972 	movx	@dptr,a
      008B72 90 0B 8C         [24] 2973 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      008B75 22               [24] 2974 	ret
                                   2975 
                                   2976 	.area CSEG (CODE)
                                   2977 ; function ak820_outline_0169
      008B76                       2978 _ak820_outline_0169:
      008B76 AF 82            [24] 2979 	mov	r7,dpl
      008B78 90 0B 30         [24] 2980 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008B7B EF               [12] 2981 	mov	a,r7
      008B7C F0               [24] 2982 	movx	@dptr,a
      008B7D EF               [12] 2983 	mov	a,r7
      008B7E 22               [24] 2984 	ret
