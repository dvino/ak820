                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000C                        552 _ak820_tapping_before_sloc0_1_0:
      00000C                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      00059A                        562 _source_state:
      00059A                        563 	.ds 130
      00061C                        564 _pending_time:
      00061C                        565 	.ds 2
      00061E                        566 _pending_code:
      00061E                        567 	.ds 2
      000620                        568 _ak820_tapping_source_PARM_1:
      000620                        569 	.ds 2
      000622                        570 _hold_PARM_2:
      000622                        571 	.ds 1
      000623                        572 _hold_code_10000_602:
      000623                        573 	.ds 2
      000625                        574 _hold_mods_30000_605:
      000625                        575 	.ds 1
      000626                        576 _commit_pending_id_10000_611:
      000626                        577 	.ds 1
      000627                        578 _ak820_tapping_before_event_10000_612:
      000627                        579 	.ds 2
      000629                        580 _ak820_tapping_process_record_10000_623:
      000629                        581 	.ds 2
      00062B                        582 _ak820_tapping_process_code_10000_624:
      00062B                        583 	.ds 2
      00062D                        584 _ak820_tapping_process_sc_mods_10000_624:
      00062D                        585 	.ds 1
      00062E                        586 _ak820_oneshot_mods::
      00062E                        587 	.ds 1
      00062F                        588 _ak820_oneshot_consumed::
      00062F                        589 	.ds 1
      000630                        590 _ak820_oneshot_process_PARM_2:
      000630                        591 	.ds 1
      000631                        592 _ak820_oneshot_process_PARM_3:
      000631                        593 	.ds 1
      000632                        594 _ak820_oneshot_process_code_10000_649:
      000632                        595 	.ds 2
      000634                        596 _ak820_oneshot_process_mods_10000_650:
      000634                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000D83                        606 _pending:
      000D83                        607 	.ds 1
      000D84                        608 _ak820_oneshot_target::
      000D84                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0043C5                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0043C5 90 06 21         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0043C8 E0               [24]  656 	movx	a,@dptr
      0043C9 FF               [12]  657 	mov	r7,a
      0043CA BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0043CD                        659 00147$:
      0043CD 50 14            [24]  660 	jnc	00102$
      0043CF 90 06 20         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0043D2 E0               [24]  662 	movx	a,@dptr
      0043D3 FE               [12]  663 	mov	r6,a
      0043D4 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0043D7                        665 00149$:
      0043D7 50 0A            [24]  666 	jnc	00102$
      0043D9 8F 05            [24]  667 	mov	ar5,r7
      0043DB ED               [12]  668 	mov	a,r5
      0043DC 12 38 90         [24]  669 	lcall	_ak820_outline_0185
      0043DF 2E               [12]  670 	add	a,r6
      0043E0 F5 82            [12]  671 	mov	dpl,a
      0043E2 22               [24]  672 	ret
      0043E3                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      0043E3 90 06 20         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0043E6 E0               [24]  676 	movx	a,@dptr
      0043E7 FE               [12]  677 	mov	r6,a
      0043E8 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0043EB                        679 00151$:
      0043EB 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0043ED BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0043F0 75 82 80         [24]  683 	mov	dpl, #0x80
      0043F3 22               [24]  684 	ret
      0043F4                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0043F4 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      0043F7 75 82 81         [24]  688 	mov	dpl, #0x81
      0043FA 22               [24]  689 	ret
      0043FB                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      0043FB 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      0043FE 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_602'
                                    700 ;mods          Allocated with name '_hold_mods_30000_605'
                                    701 ;layer         Allocated with name '_hold_layer_30000_608'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      0043FF                        707 _hold:
      0043FF 12 38 43         [24]  708 	lcall	_ak820_outline_0103
      004402 90 06 23         [24]  709 	mov	dptr,#_hold_code_10000_602
      004405 12 38 48         [24]  710 	lcall	_ak820_outline_0104
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004408 90 06 23         [24]  712 	mov	dptr,#_hold_code_10000_602
      00440B 12 37 CB         [24]  713 	lcall	_ak820_outline_0010
      00440E 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      004410 2D               [12]  715 	add	a,r5
      004411 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      004413 8F 05            [24]  718 	mov	ar5,r7
      004415 53 05 1F         [24]  719 	anl	ar5,#0x1f
      004418 90 06 25         [24]  720 	mov	dptr,#_hold_mods_30000_605
      00441B ED               [12]  721 	mov	a,r5
      00441C F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      00441D ED               [12]  724 	mov	a,r5
      00441E 30 E4 08         [24]  725 	jnb	acc.4,00102$
      004421 ED               [12]  726 	mov	a,r5
      004422 C4               [12]  727 	swap	a
      004423 54 F0            [12]  728 	anl	a,#0xf0
      004425 90 06 25         [24]  729 	mov	dptr,#_hold_mods_30000_605
      004428 F0               [24]  730 	movx	@dptr,a
      004429                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004429 90 06 22         [24]  733 	mov	dptr,#_hold_PARM_2
      00442C E0               [24]  734 	movx	a,@dptr
      00442D 60 09            [24]  735 	jz	00104$
      00442F 90 06 25         [24]  736 	mov	dptr,#_hold_mods_30000_605
      004432 E0               [24]  737 	movx	a,@dptr
      004433 F5 82            [12]  738 	mov	dpl,a
      004435 02 75 E2         [24]  739 	ljmp	_register_mods
      004438                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004438 90 06 25         [24]  742 	mov	dptr,#_hold_mods_30000_605
      00443B E0               [24]  743 	movx	a,@dptr
      00443C F5 82            [12]  744 	mov	dpl,a
      00443E 02 75 F6         [24]  745 	ljmp	_unregister_mods
      004441                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      004441 8F 06            [24]  748 	mov	ar6,r7
      004443 74 0F            [12]  749 	mov	a,#0x0f
      004445 5E               [12]  750 	anl	a,r6
      004446 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004447 90 06 22         [24]  753 	mov	dptr,#_hold_PARM_2
      00444A E0               [24]  754 	movx	a,@dptr
      00444B 60 05            [24]  755 	jz	00107$
      00444D 8F 82            [24]  756 	mov	dpl, r7
      00444F 02 77 A6         [24]  757 	ljmp	_layer_hold_on
      004452                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      004452 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004454 02 77 DE         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_611'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004457                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004457 90 0D 83         [24]  774 	mov	dptr,#_pending
      00445A E0               [24]  775 	movx	a,@dptr
      00445B 90 06 26         [24]  776 	mov	dptr,#_commit_pending_id_10000_611
      00445E F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      00445F 12 48 DE         [24]  779 	lcall	_ak820_outline_0150
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      004462 90 06 26         [24]  781 	mov	dptr,#_commit_pending_id_10000_611
      004465 E0               [24]  782 	movx	a,@dptr
      004466 24 9A            [12]  783 	add	a,#_source_state
      004468 FF               [12]  784 	mov	r7,a
      004469 E4               [12]  785 	clr	a
      00446A 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      00446C FE               [12]  787 	mov	r6,a
      00446D 12 43 AA         [24]  788 	lcall	_ak820_outline_0153
      004470 E0               [24]  789 	movx	a,@dptr
      004471 FD               [12]  790 	mov	r5,a
      004472 43 05 04         [24]  791 	orl	ar5,#0x04
      004475 12 43 AA         [24]  792 	lcall	_ak820_outline_0153
      004478 ED               [12]  793 	mov	a,r5
      004479 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      00447A 90 06 1E         [24]  796 	mov	dptr,#_pending_code
      00447D 12 38 00         [24]  797 	lcall	_ak820_outline_0050
      004480 90 06 22         [24]  798 	mov	dptr,#_hold_PARM_2
      004483 12 48 B3         [24]  799 	lcall	_ak820_outline_0054
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004486 02 43 FF         [24]  801 	ljmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_612'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_613'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      004489                        812 _ak820_tapping_before:
      004489 12 38 43         [24]  813 	lcall	_ak820_outline_0103
      00448C 90 06 27         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_612
      00448F 12 38 48         [24]  815 	lcall	_ak820_outline_0104
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004492 90 06 27         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_612
      004495 12 37 CB         [24]  818 	lcall	_ak820_outline_0010
      004498 12 48 8E         [24]  819 	lcall	_ak820_outline_0022
      00449B C0 07            [24]  820 	push	ar7
      00449D C0 06            [24]  821 	push	ar6
      00449F 12 B6 EB         [24]  822 	lcall	___memcpy
      0044A2 12 43 C5         [24]  823 	lcall	_ak820_tapping_source
      0044A5 AD 82            [24]  824 	mov	r5, dpl
      0044A7 D0 06            [24]  825 	pop	ar6
      0044A9 D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      0044AB 90 0D F4         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      0044AE E0               [24]  829 	movx	a,@dptr
      0044AF 60 29            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0044B1 74 04            [12]  832 	mov	a,#0x04
      0044B3 12 48 74         [24]  833 	lcall	_ak820_outline_0012
      0044B6 60 1E            [24]  834 	jz	00102$
      0044B8 BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      0044BB 80 19            [24]  836 	sjmp	00102$
      0044BD                        837 00218$:
      0044BD 74 05            [12]  838 	mov	a,#0x05
      0044BF 12 48 74         [24]  839 	lcall	_ak820_outline_0012
      0044C2 70 12            [24]  840 	jnz	00102$
      0044C4 ED               [12]  841 	mov	a,r5
      0044C5 24 9A            [12]  842 	add	a, #_source_state
      0044C7 FB               [12]  843 	mov	r3,a
      0044C8 E4               [12]  844 	clr	a
      0044C9 34 05            [12]  845 	addc	a, #(_source_state >> 8)
      0044CB 12 48 BB         [24]  846 	lcall	_ak820_outline_0055
      0044CE 53 02 FD         [24]  847 	anl	ar2,#0xfd
      0044D1 12 33 FC         [24]  848 	lcall	_ak820_outline_0122
      0044D4 EA               [12]  849 	mov	a,r2
      0044D5 F0               [24]  850 	movx	@dptr,a
      0044D6                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      0044D6 75 82 00         [24]  853 	mov	dpl, #0x00
      0044D9 22               [24]  854 	ret
      0044DA                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      0044DA 90 0D 83         [24]  857 	mov	dptr,#_pending
      0044DD E0               [24]  858 	movx	a,@dptr
      0044DE FC               [12]  859 	mov	r4,a
      0044DF BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      0044E2 80 3B            [24]  861 	sjmp	00108$
      0044E4                        862 00220$:
      0044E4 12 37 F8         [24]  863 	lcall	_ak820_outline_0033
      0044E7 FA               [12]  864 	mov	r2,a
      0044E8 A3               [24]  865 	inc	dptr
      0044E9 E0               [24]  866 	movx	a,@dptr
      0044EA FB               [12]  867 	mov	r3,a
      0044EB 90 06 1C         [24]  868 	mov	dptr,#_pending_time
      0044EE 12 38 3D         [24]  869 	lcall	_ak820_outline_0099
      0044F1 EA               [12]  870 	mov	a,r2
      0044F2 C3               [12]  871 	clr	c
      0044F3 98               [12]  872 	subb	a,r0
      0044F4 FA               [12]  873 	mov	r2,a
      0044F5 EB               [12]  874 	mov	a,r3
      0044F6 99               [12]  875 	subb	a,r1
      0044F7 FB               [12]  876 	mov	r3,a
      0044F8 C3               [12]  877 	clr	c
      0044F9 EA               [12]  878 	mov	a,r2
      0044FA 94 C8            [12]  879 	subb	a,#0xc8
      0044FC EB               [12]  880 	mov	a,r3
      0044FD 94 00            [12]  881 	subb	a,#0x00
      0044FF 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004501 74 04            [12]  884 	mov	a,#0x04
      004503 12 48 A8         [24]  885 	lcall	_ak820_outline_0045
      004506 60 17            [24]  886 	jz	00108$
      004508 12 37 AA         [24]  887 	lcall	_ak820_outline_0005
      00450B 60 12            [24]  888 	jz	00108$
      00450D BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      004510 80 06            [24]  890 	sjmp	00107$
      004512                        891 00224$:
      004512 ED               [12]  892 	mov	a,r5
      004513 B5 04 02         [24]  893 	cjne	a,ar4,00225$
      004516 80 07            [24]  894 	sjmp	00108$
      004518                        895 00225$:
      004518                        896 00107$:
      004518 C0 05            [24]  897 	push	ar5
      00451A 12 44 57         [24]  898 	lcall	_commit_pending
      00451D D0 05            [24]  899 	pop	ar5
      00451F                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      00451F 90 06 27         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_612
      004522 12 38 00         [24]  903 	lcall	_ak820_outline_0050
      004525 74 04            [12]  904 	mov	a,#0x04
      004527 12 48 74         [24]  905 	lcall	_ak820_outline_0012
      00452A 60 03            [24]  906 	jz	00114$
      00452C BD FF 04         [24]  907 	cjne	r5,#0xff,00115$
      00452F                        908 00114$:
      00452F 75 82 01         [24]  909 	mov	dpl, #0x01
      004532 22               [24]  910 	ret
      004533                        911 00115$:
                                    912 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004533 ED               [12]  913 	mov	a,r5
      004534 12 48 D0         [24]  914 	lcall	_ak820_outline_0077
      004537 30 E1 13         [24]  915 	jnb	acc.1,00120$
                                    916 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00453A 74 05            [12]  917 	mov	a,#0x05
      00453C 2E               [12]  918 	add	a, r6
      00453D 12 37 D5         [24]  919 	lcall	_ak820_outline_0013
      004540 70 07            [24]  920 	jnz	00118$
      004542 74 FD            [12]  921 	mov	a,#0xfd
      004544 5B               [12]  922 	anl	a,r3
      004545 12 38 60         [24]  923 	lcall	_ak820_outline_0121
      004548 F0               [24]  924 	movx	@dptr,a
      004549                        925 00118$:
                                    926 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004549 75 82 00         [24]  927 	mov	dpl, #0x00
      00454C 22               [24]  928 	ret
      00454D                        929 00120$:
                                    930 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      00454D 12 43 29         [24]  931 	lcall	_ak820_outline_0009
      004550 E0               [24]  932 	movx	a,@dptr
      004551 FF               [12]  933 	mov	r7,a
      004552 8B 06            [24]  934 	mov	ar6,r3
      004554 53 06 01         [24]  935 	anl	ar6,#0x01
      004557 EE               [12]  936 	mov	a,r6
      004558 B4 01 00         [24]  937 	cjne	a,#0x01,00231$
      00455B                        938 00231$:
      00455B B3               [12]  939 	cpl	c
      00455C 92 0C            [24]  940 	mov	_ak820_tapping_before_sloc0_1_0,c
      00455E 8F F0            [24]  941 	mov	b,r7
      004560 E4               [12]  942 	clr	a
      004561 33               [12]  943 	rlc	a
      004562 B5 F0 04         [24]  944 	cjne	a,b,00122$
      004565 75 82 00         [24]  945 	mov	dpl, #0x00
      004568 22               [24]  946 	ret
      004569                        947 00122$:
                                    948 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004569 63 03 01         [24]  949 	xrl	ar3,#0x01
      00456C 12 38 60         [24]  950 	lcall	_ak820_outline_0121
      00456F EB               [12]  951 	mov	a,r3
      004570 F0               [24]  952 	movx	@dptr,a
                                    953 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004571 75 82 01         [24]  954 	mov	dpl, #0x01
                                    955 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004574 22               [24]  956 	ret
                                    957 ;------------------------------------------------------------
                                    958 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    959 ;------------------------------------------------------------
                                    960 ;record        Allocated with name '_ak820_tapping_process_record_10000_623'
                                    961 ;id            Allocated with name '_ak820_tapping_process_id_10000_624'
                                    962 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_624'
                                    963 ;code          Allocated with name '_ak820_tapping_process_code_10000_624'
                                    964 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_624'
                                    965 ;------------------------------------------------------------
                                    966 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    967 ;	-----------------------------------------
                                    968 ;	 function ak820_tapping_process
                                    969 ;	-----------------------------------------
      004575                        970 _ak820_tapping_process:
      004575 12 38 43         [24]  971 	lcall	_ak820_outline_0103
      004578 90 06 29         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00457B 12 38 48         [24]  973 	lcall	_ak820_outline_0104
                                    974 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      00457E 90 06 2D         [24]  975 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004581 E4               [12]  976 	clr	a
      004582 F0               [24]  977 	movx	@dptr,a
                                    978 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004583 90 06 29         [24]  979 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004586 12 38 00         [24]  980 	lcall	_ak820_outline_0050
      004589 74 04            [12]  981 	mov	a,#0x04
      00458B 12 48 69         [24]  982 	lcall	_ak820_outline_0011
      00458E 70 04            [24]  983 	jnz	00102$
      004590 75 82 01         [24]  984 	mov	dpl, #0x01
      004593 22               [24]  985 	ret
      004594                        986 00102$:
                                    987 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004594 8E 04            [24]  988 	mov	ar4,r6
      004596 8F 05            [24]  989 	mov	ar5,r7
      004598 12 48 8E         [24]  990 	lcall	_ak820_outline_0022
      00459B C0 07            [24]  991 	push	ar7
      00459D C0 06            [24]  992 	push	ar6
      00459F 12 B6 EB         [24]  993 	lcall	___memcpy
      0045A2 12 43 C5         [24]  994 	lcall	_ak820_tapping_source
      0045A5 AD 82            [24]  995 	mov	r5, dpl
      0045A7 D0 06            [24]  996 	pop	ar6
      0045A9 D0 07            [24]  997 	pop	ar7
                                    998 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      0045AB BD FF 04         [24]  999 	cjne	r5,#0xff,00104$
      0045AE 75 82 01         [24] 1000 	mov	dpl, #0x01
      0045B1 22               [24] 1001 	ret
      0045B2                       1002 00104$:
                                   1003 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      0045B2 74 07            [12] 1004 	mov	a,#0x07
      0045B4 12 37 E7         [24] 1005 	lcall	_ak820_outline_0016
      0045B7 FE               [12] 1006 	mov	r6,a
      0045B8 A3               [24] 1007 	inc	dptr
      0045B9 E0               [24] 1008 	movx	a,@dptr
      0045BA FF               [12] 1009 	mov	r7,a
      0045BB 90 06 2B         [24] 1010 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0045BE 12 48 C3         [24] 1011 	lcall	_ak820_outline_0058
                                   1012 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      0045C1 BE 1A 15         [24] 1013 	cjne	r6,#0x1a,00111$
      0045C4 BF 7C 12         [24] 1014 	cjne	r7,#0x7c,00111$
      0045C7 90 06 2B         [24] 1015 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0045CA 74 26            [12] 1016 	mov	a,#0x26
      0045CC F0               [24] 1017 	movx	@dptr,a
      0045CD 74 22            [12] 1018 	mov	a,#0x22
      0045CF A3               [24] 1019 	inc	dptr
      0045D0 F0               [24] 1020 	movx	@dptr,a
      0045D1 90 06 2D         [24] 1021 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0045D4 74 02            [12] 1022 	mov	a,#0x02
      0045D6 F0               [24] 1023 	movx	@dptr,a
      0045D7 80 28            [24] 1024 	sjmp	00112$
      0045D9                       1025 00111$:
                                   1026 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0045D9 BE 1B 15         [24] 1027 	cjne	r6,#0x1b,00108$
      0045DC BF 7C 12         [24] 1028 	cjne	r7,#0x7c,00108$
      0045DF 90 06 2B         [24] 1029 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0045E2 74 27            [12] 1030 	mov	a,#0x27
      0045E4 F0               [24] 1031 	movx	@dptr,a
      0045E5 74 32            [12] 1032 	mov	a,#0x32
      0045E7 A3               [24] 1033 	inc	dptr
      0045E8 F0               [24] 1034 	movx	@dptr,a
      0045E9 90 06 2D         [24] 1035 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0045EC 74 20            [12] 1036 	mov	a,#0x20
      0045EE F0               [24] 1037 	movx	@dptr,a
      0045EF 80 10            [24] 1038 	sjmp	00112$
      0045F1                       1039 00108$:
                                   1040 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0045F1 BE 1E 0D         [24] 1041 	cjne	r6,#0x1e,00112$
      0045F4 BF 7C 0A         [24] 1042 	cjne	r7,#0x7c,00112$
      0045F7 90 06 2B         [24] 1043 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0045FA 74 28            [12] 1044 	mov	a,#0x28
      0045FC F0               [24] 1045 	movx	@dptr,a
      0045FD 74 32            [12] 1046 	mov	a,#0x32
      0045FF A3               [24] 1047 	inc	dptr
      004600 F0               [24] 1048 	movx	@dptr,a
      004601                       1049 00112$:
                                   1050 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004601 90 06 2B         [24] 1051 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004604 E0               [24] 1052 	movx	a,@dptr
      004605 A3               [24] 1053 	inc	dptr
      004606 E0               [24] 1054 	movx	a,@dptr
      004607 FF               [12] 1055 	mov	r7,a
                                   1056 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004608 BF 20 00         [24] 1057 	cjne	r7,#0x20,00242$
      00460B                       1058 00242$:
      00460B 40 05            [24] 1059 	jc	00113$
      00460D BF 50 00         [24] 1060 	cjne	r7,#0x50,00244$
      004610                       1061 00244$:
      004610 40 04            [24] 1062 	jc	00114$
      004612                       1063 00113$:
      004612 75 82 01         [24] 1064 	mov	dpl, #0x01
      004615 22               [24] 1065 	ret
      004616                       1066 00114$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004616 BF 40 00         [24] 1068 	cjne	r7,#0x40,00246$
      004619                       1069 00246$:
      004619 40 0C            [24] 1070 	jc	00117$
      00461B 53 07 0F         [24] 1071 	anl	ar7,#0x0f
      00461E BF 06 00         [24] 1072 	cjne	r7,#0x06,00248$
      004621                       1073 00248$:
      004621 40 04            [24] 1074 	jc	00117$
      004623 75 82 00         [24] 1075 	mov	dpl, #0x00
      004626 22               [24] 1076 	ret
      004627                       1077 00117$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004627 90 06 29         [24] 1079 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00462A 12 38 00         [24] 1080 	lcall	_ak820_outline_0050
      00462D 74 05            [12] 1081 	mov	a,#0x05
      00462F 12 48 74         [24] 1082 	lcall	_ak820_outline_0012
      004632 60 1F            [24] 1083 	jz	00131$
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004634 90 0D 83         [24] 1085 	mov	dptr,#_pending
      004637 ED               [12] 1086 	mov	a,r5
      004638 12 43 33         [24] 1087 	lcall	_ak820_outline_0029
                                   1088 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      00463B 12 38 00         [24] 1089 	lcall	_ak820_outline_0050
      00463E 90 06 1C         [24] 1090 	mov	dptr,#_pending_time
      004641 12 48 C3         [24] 1091 	lcall	_ak820_outline_0058
                                   1092 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004644 90 06 2B         [24] 1093 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004647 12 38 00         [24] 1094 	lcall	_ak820_outline_0050
      00464A 90 06 1E         [24] 1095 	mov	dptr,#_pending_code
      00464D 12 48 C3         [24] 1096 	lcall	_ak820_outline_0058
      004650 02 46 F0         [24] 1097 	ljmp	00132$
      004653                       1098 00131$:
                                   1099 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004653 90 0D 83         [24] 1100 	mov	dptr,#_pending
      004656 E0               [24] 1101 	movx	a,@dptr
      004657 FF               [12] 1102 	mov	r7,a
      004658 ED               [12] 1103 	mov	a,r5
      004659 B5 07 02         [24] 1104 	cjne	a,ar7,00251$
      00465C 80 03            [24] 1105 	sjmp	00252$
      00465E                       1106 00251$:
      00465E 02 46 C9         [24] 1107 	ljmp	00128$
      004661                       1108 00252$:
                                   1109 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004661 12 48 DE         [24] 1110 	lcall	_ak820_outline_0150
                                   1111 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004664 90 06 2D         [24] 1112 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004667 E0               [24] 1113 	movx	a,@dptr
      004668 FF               [12] 1114 	mov	r7,a
      004669 E0               [24] 1115 	movx	a,@dptr
      00466A 60 05            [24] 1116 	jz	00120$
      00466C 8F 82            [24] 1117 	mov	dpl, r7
      00466E 12 7C 7B         [24] 1118 	lcall	_add_owned_mods
      004671                       1119 00120$:
                                   1120 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004671 90 06 29         [24] 1121 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004674 12 38 00         [24] 1122 	lcall	_ak820_outline_0050
      004677 74 07            [12] 1123 	mov	a,#0x07
      004679 2E               [12] 1124 	add	a, r6
      00467A FB               [12] 1125 	mov	r3,a
      00467B E4               [12] 1126 	clr	a
      00467C 3F               [12] 1127 	addc	a, r7
      00467D FC               [12] 1128 	mov	r4,a
      00467E 90 06 2B         [24] 1129 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004681 E0               [24] 1130 	movx	a,@dptr
      004682 F9               [12] 1131 	mov	r1,a
      004683 7A 00            [12] 1132 	mov	r2,#0x00
      004685 12 33 FC         [24] 1133 	lcall	_ak820_outline_0122
      004688 E9               [12] 1134 	mov	a,r1
      004689 F0               [24] 1135 	movx	@dptr,a
      00468A EA               [12] 1136 	mov	a,r2
      00468B A3               [24] 1137 	inc	dptr
      00468C F0               [24] 1138 	movx	@dptr,a
                                   1139 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      00468D C3               [12] 1140 	clr	c
      00468E 04               [12] 1141 	inc	a
      00468F 99               [12] 1142 	subb	a,r1
      004690 50 25            [24] 1143 	jnc	00122$
                                   1144 ;	free result
                                   1145 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004692 74 06            [12] 1146 	mov	a,#0x06
      004694 12 37 E7         [24] 1147 	lcall	_ak820_outline_0016
      004697 54 0F            [12] 1148 	anl	a,#0x0f
      004699 44 10            [12] 1149 	orl	a,#0x10
      00469B F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      00469C 12 43 29         [24] 1152 	lcall	_ak820_outline_0009
      00469F 12 48 B3         [24] 1153 	lcall	_ak820_outline_0054
                                   1154 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      0046A2 12 70 AE         [24] 1155 	lcall	_process_record
                                   1156 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      0046A5 90 06 29         [24] 1157 	mov	dptr,#_ak820_tapping_process_record_10000_623
      0046A8 12 37 A0         [24] 1158 	lcall	_ak820_outline_0004
      0046AB A3               [24] 1159 	inc	dptr
      0046AC A3               [24] 1160 	inc	dptr
      0046AD A3               [24] 1161 	inc	dptr
      0046AE A3               [24] 1162 	inc	dptr
      0046AF A3               [24] 1163 	inc	dptr
      0046B0 E4               [12] 1164 	clr	a
      0046B1 12 43 5F         [24] 1165 	lcall	_ak820_outline_0060
                                   1166 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      0046B4 12 70 AE         [24] 1167 	lcall	_process_record
      0046B7                       1168 00122$:
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      0046B7 90 06 2D         [24] 1170 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0046BA E0               [24] 1171 	movx	a,@dptr
      0046BB FF               [12] 1172 	mov	r7,a
      0046BC E0               [24] 1173 	movx	a,@dptr
      0046BD 60 31            [24] 1174 	jz	00132$
                                   1175 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      0046BF 8F 82            [24] 1176 	mov	dpl, r7
      0046C1 12 7C 8B         [24] 1177 	lcall	_del_owned_mods
                                   1178 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      0046C4 12 7F B5         [24] 1179 	lcall	_send_keyboard_report
      0046C7 80 27            [24] 1180 	sjmp	00132$
      0046C9                       1181 00128$:
                                   1182 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      0046C9 ED               [12] 1183 	mov	a,r5
      0046CA 24 9A            [12] 1184 	add	a, #_source_state
      0046CC FE               [12] 1185 	mov	r6,a
      0046CD E4               [12] 1186 	clr	a
      0046CE 34 05            [12] 1187 	addc	a, #(_source_state >> 8)
      0046D0 FF               [12] 1188 	mov	r7,a
      0046D1 12 38 37         [24] 1189 	lcall	_ak820_outline_0097
      0046D4 FD               [12] 1190 	mov	r5,a
      0046D5 30 E2 18         [24] 1191 	jnb	acc.2,00132$
                                   1192 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      0046D8 53 05 FB         [24] 1193 	anl	ar5,#0xfb
      0046DB 12 43 84         [24] 1194 	lcall	_ak820_outline_0116
      0046DE ED               [12] 1195 	mov	a,r5
      0046DF F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      0046E0 90 06 2B         [24] 1198 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0046E3 12 38 00         [24] 1199 	lcall	_ak820_outline_0050
      0046E6 90 06 22         [24] 1200 	mov	dptr,#_hold_PARM_2
      0046E9 E4               [12] 1201 	clr	a
      0046EA 12 43 5F         [24] 1202 	lcall	_ak820_outline_0060
      0046ED 12 43 FF         [24] 1203 	lcall	_hold
      0046F0                       1204 00132$:
                                   1205 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      0046F0 75 82 00         [24] 1206 	mov	dpl, #0x00
                                   1207 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      0046F3 22               [24] 1208 	ret
                                   1209 ;------------------------------------------------------------
                                   1210 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1211 ;------------------------------------------------------------
                                   1212 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_647'
                                   1213 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_648'
                                   1214 ;------------------------------------------------------------
                                   1215 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1216 ;	-----------------------------------------
                                   1217 ;	 function ak820_tapping_cancel
                                   1218 ;	-----------------------------------------
      0046F4                       1219 _ak820_tapping_cancel:
                                   1220 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      0046F4 12 48 DE         [24] 1221 	lcall	_ak820_outline_0150
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0046F7 7F 00            [12] 1223 	mov	r7,#0x00
      0046F9                       1224 00103$:
      0046F9 BF 82 00         [24] 1225 	cjne	r7,#0x82,00122$
      0046FC                       1226 00122$:
      0046FC 50 16            [24] 1227 	jnc	00105$
                                   1228 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      0046FE 12 48 7F         [24] 1229 	lcall	_ak820_outline_0018
                                   1230 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004701 74 02            [12] 1231 	mov	a,#0x02
      004703 5C               [12] 1232 	anl	a,r4
      004704 FB               [12] 1233 	mov	r3,a
      004705 53 04 01         [24] 1234 	anl	ar4,#0x01
      004708 EC               [12] 1235 	mov	a,r4
      004709 2C               [12] 1236 	add	a,r4
      00470A 42 03            [12] 1237 	orl	ar3,a
      00470C 12 38 6A         [24] 1238 	lcall	_ak820_outline_0132
      00470F EB               [12] 1239 	mov	a,r3
      004710 F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004711 0F               [12] 1242 	inc	r7
      004712 80 E5            [24] 1243 	sjmp	00103$
      004714                       1244 00105$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004714 22               [24] 1246 	ret
                                   1247 ;------------------------------------------------------------
                                   1248 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1249 ;------------------------------------------------------------
                                   1250 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1251 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1252 ;code          Allocated with name '_ak820_oneshot_process_code_10000_649'
                                   1253 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_650'
                                   1254 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1255 ;------------------------------------------------------------
                                   1256 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1257 ;	-----------------------------------------
                                   1258 ;	 function ak820_oneshot_process
                                   1259 ;	-----------------------------------------
      004715                       1260 _ak820_oneshot_process:
      004715 12 38 43         [24] 1261 	lcall	_ak820_outline_0103
      004718 90 06 32         [24] 1262 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      00471B 12 38 48         [24] 1263 	lcall	_ak820_outline_0104
                                   1264 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      00471E 90 06 30         [24] 1265 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004721 E0               [24] 1266 	movx	a,@dptr
      004722 FF               [12] 1267 	mov	r7,a
      004723 BF FF 02         [24] 1268 	cjne	r7,#0xff,00266$
      004726 80 07            [24] 1269 	sjmp	00101$
      004728                       1270 00266$:
      004728 12 A0 DF         [24] 1271 	lcall	_get_repeat_key_count
      00472B E5 82            [12] 1272 	mov	a, dpl
      00472D 60 04            [24] 1273 	jz	00102$
      00472F                       1274 00101$:
      00472F 75 82 01         [24] 1275 	mov	dpl, #0x01
      004732 22               [24] 1276 	ret
      004733                       1277 00102$:
                                   1278 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: if (code == QK_MAGIC_SWAP_ALT_GUI || code == QK_MAGIC_UNSWAP_ALT_GUI || code == QK_MAGIC_TOGGLE_ALT_GUI) return true;
      004733 90 06 32         [24] 1279 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      004736 12 43 6C         [24] 1280 	lcall	_ak820_outline_0090
      004739 8D 03            [24] 1281 	mov	ar3,r5
      00473B 8E 04            [24] 1282 	mov	ar4,r6
      00473D BB 14 05         [24] 1283 	cjne	r3,#0x14,00268$
      004740 BC 70 02         [24] 1284 	cjne	r4,#0x70,00268$
      004743 80 0E            [24] 1285 	sjmp	00104$
      004745                       1286 00268$:
      004745 BB 15 05         [24] 1287 	cjne	r3,#0x15,00269$
      004748 BC 70 02         [24] 1288 	cjne	r4,#0x70,00269$
      00474B 80 06            [24] 1289 	sjmp	00104$
      00474D                       1290 00269$:
      00474D BB 16 07         [24] 1291 	cjne	r3,#0x16,00105$
      004750 BC 70 04         [24] 1292 	cjne	r4,#0x70,00105$
      004753                       1293 00104$:
      004753 75 82 01         [24] 1294 	mov	dpl, #0x01
      004756 22               [24] 1295 	ret
      004757                       1296 00105$:
                                   1297 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004757 8E 03            [24] 1298 	mov	ar3,r6
      004759 BB 52 02         [24] 1299 	cjne	r3,#0x52,00272$
      00475C 80 03            [24] 1300 	sjmp	00273$
      00475E                       1301 00272$:
      00475E 02 48 03         [24] 1302 	ljmp	00120$
      004761                       1303 00273$:
      004761 8D 04            [24] 1304 	mov	ar4,r5
      004763 53 04 E0         [24] 1305 	anl	ar4,#0xe0
      004766 BC A0 02         [24] 1306 	cjne	r4,#0xa0,00274$
      004769 80 03            [24] 1307 	sjmp	00275$
      00476B                       1308 00274$:
      00476B 02 48 03         [24] 1309 	ljmp	00120$
      00476E                       1310 00275$:
                                   1311 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      00476E 8D 04            [24] 1312 	mov	ar4,r5
      004770 53 04 0F         [24] 1313 	anl	ar4,#0x0f
      004773 90 06 34         [24] 1314 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004776 EC               [12] 1315 	mov	a,r4
      004777 F0               [24] 1316 	movx	@dptr,a
                                   1317 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004778 ED               [12] 1318 	mov	a,r5
      004779 30 E4 08         [24] 1319 	jnb	acc.4,00109$
      00477C EC               [12] 1320 	mov	a,r4
      00477D C4               [12] 1321 	swap	a
      00477E 54 F0            [12] 1322 	anl	a,#0xf0
      004780 90 06 34         [24] 1323 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004783 F0               [24] 1324 	movx	@dptr,a
      004784                       1325 00109$:
                                   1326 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004784 90 06 31         [24] 1327 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004787 E0               [24] 1328 	movx	a,@dptr
      004788 60 2D            [24] 1329 	jz	00117$
                                   1330 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      00478A 12 48 7F         [24] 1331 	lcall	_ak820_outline_0018
      00478D 43 04 08         [24] 1332 	orl	ar4,#0x08
      004790 12 43 65         [24] 1333 	lcall	_ak820_outline_0064
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004793 53 04 EF         [24] 1335 	anl	ar4,#0xef
      004796 12 43 65         [24] 1336 	lcall	_ak820_outline_0064
                                   1337 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004799 90 0D 84         [24] 1338 	mov	dptr,#_ak820_oneshot_target
      00479C E0               [24] 1339 	movx	a,@dptr
      00479D FC               [12] 1340 	mov	r4,a
      00479E BC FF 02         [24] 1341 	cjne	r4,#0xff,00278$
      0047A1 80 09            [24] 1342 	sjmp	00111$
      0047A3                       1343 00278$:
      0047A3 12 48 C9         [24] 1344 	lcall	_ak820_outline_0074
      0047A6 43 04 10         [24] 1345 	orl	ar4,#0x10
      0047A9 12 43 65         [24] 1346 	lcall	_ak820_outline_0064
      0047AC                       1347 00111$:
                                   1348 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      0047AC 90 06 34         [24] 1349 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0047AF E0               [24] 1350 	movx	a,@dptr
      0047B0 F5 82            [12] 1351 	mov	dpl,a
      0047B2 12 75 E2         [24] 1352 	lcall	_register_mods
      0047B5 80 48            [24] 1353 	sjmp	00118$
      0047B7                       1354 00117$:
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      0047B7 12 48 7F         [24] 1356 	lcall	_ak820_outline_0018
      0047BA 30 E3 42         [24] 1357 	jnb	acc.3,00118$
                                   1358 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      0047BD EC               [12] 1359 	mov	a,r4
      0047BE 20 E4 24         [24] 1360 	jb	acc.4,00113$
                                   1361 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      0047C1 90 06 2E         [24] 1362 	mov	dptr,#_ak820_oneshot_mods
      0047C4 E0               [24] 1363 	movx	a,@dptr
      0047C5 F4               [12] 1364 	cpl	a
      0047C6 FC               [12] 1365 	mov	r4,a
      0047C7 90 06 34         [24] 1366 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0047CA E0               [24] 1367 	movx	a,@dptr
      0047CB FB               [12] 1368 	mov	r3,a
      0047CC 52 04            [12] 1369 	anl	ar4,a
      0047CE 8C 82            [24] 1370 	mov	dpl, r4
      0047D0 C0 06            [24] 1371 	push	ar6
      0047D2 C0 05            [24] 1372 	push	ar5
      0047D4 C0 03            [24] 1373 	push	ar3
      0047D6 12 7C 7B         [24] 1374 	lcall	_add_owned_mods
      0047D9 D0 03            [24] 1375 	pop	ar3
      0047DB D0 05            [24] 1376 	pop	ar5
      0047DD D0 06            [24] 1377 	pop	ar6
                                   1378 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      0047DF 90 06 2E         [24] 1379 	mov	dptr,#_ak820_oneshot_mods
      0047E2 E0               [24] 1380 	movx	a,@dptr
      0047E3 4B               [12] 1381 	orl	a,r3
      0047E4 F0               [24] 1382 	movx	@dptr,a
      0047E5                       1383 00113$:
                                   1384 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      0047E5 90 06 34         [24] 1385 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0047E8 E0               [24] 1386 	movx	a,@dptr
      0047E9 F5 82            [12] 1387 	mov	dpl,a
      0047EB C0 06            [24] 1388 	push	ar6
      0047ED C0 05            [24] 1389 	push	ar5
      0047EF 12 75 F6         [24] 1390 	lcall	_unregister_mods
      0047F2 D0 05            [24] 1391 	pop	ar5
      0047F4 D0 06            [24] 1392 	pop	ar6
                                   1393 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      0047F6 12 48 C9         [24] 1394 	lcall	_ak820_outline_0074
      0047F9 53 04 E7         [24] 1395 	anl	ar4,#0xe7
      0047FC 12 43 65         [24] 1396 	lcall	_ak820_outline_0064
      0047FF                       1397 00118$:
                                   1398 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      0047FF 75 82 00         [24] 1399 	mov	dpl, #0x00
      004802 22               [24] 1400 	ret
      004803                       1401 00120$:
                                   1402 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004803 90 06 31         [24] 1403 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004806 E0               [24] 1404 	movx	a,@dptr
      004807 60 5C            [24] 1405 	jz	00128$
      004809 90 06 32         [24] 1406 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      00480C 12 43 6C         [24] 1407 	lcall	_ak820_outline_0090
      00480F C3               [12] 1408 	clr	c
      004810 74 01            [12] 1409 	mov	a,#0x01
      004812 9D               [12] 1410 	subb	a,r5
      004813 E4               [12] 1411 	clr	a
      004814 9E               [12] 1412 	subb	a,r6
      004815 50 4E            [24] 1413 	jnc	00128$
                                   1414 ;	free result
                                   1415 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004817 C3               [12] 1416 	clr	c
      004818 ED               [12] 1417 	mov	a,r5
      004819 94 E0            [12] 1418 	subb	a,#0xe0
      00481B EE               [12] 1419 	mov	a,r6
      00481C 94 00            [12] 1420 	subb	a,#0x00
      00481E 40 07            [24] 1421 	jc	00133$
      004820 74 E7            [12] 1422 	mov	a,#0xe7
      004822 9D               [12] 1423 	subb	a,r5
      004823 E4               [12] 1424 	clr	a
      004824 9E               [12] 1425 	subb	a,r6
      004825 50 3E            [24] 1426 	jnc	00128$
                                   1427 ;	free result
      004827                       1428 00133$:
                                   1429 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004827 74 AE            [12] 1430 	mov	a,#0x100 - 0x52
      004829 2E               [12] 1431 	add	a,r6
      00482A 50 09            [24] 1432 	jnc	00173$
      00482C C3               [12] 1433 	clr	c
      00482D 74 DF            [12] 1434 	mov	a,#0xdf
      00482F 9D               [12] 1435 	subb	a,r5
      004830 74 52            [12] 1436 	mov	a,#0x52
      004832 9E               [12] 1437 	subb	a,r6
      004833 50 30            [24] 1438 	jnc	00128$
                                   1439 ;	free result
                                   1440 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004835                       1441 00173$:
      004835 7E 00            [12] 1442 	mov	r6,#0x00
      004837                       1443 00135$:
      004837 BE 82 00         [24] 1444 	cjne	r6,#0x82,00287$
      00483A                       1445 00287$:
      00483A 50 12            [24] 1446 	jnc	00124$
                                   1447 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      00483C EE               [12] 1448 	mov	a,r6
      00483D 12 48 D0         [24] 1449 	lcall	_ak820_outline_0077
      004840 30 E3 08         [24] 1450 	jnb	acc.3,00136$
      004843 43 03 10         [24] 1451 	orl	ar3,#0x10
      004846 12 38 60         [24] 1452 	lcall	_ak820_outline_0121
      004849 EB               [12] 1453 	mov	a,r3
      00484A F0               [24] 1454 	movx	@dptr,a
      00484B                       1455 00136$:
                                   1456 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      00484B 0E               [12] 1457 	inc	r6
      00484C 80 E9            [24] 1458 	sjmp	00135$
      00484E                       1459 00124$:
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      00484E 90 06 2E         [24] 1461 	mov	dptr,#_ak820_oneshot_mods
      004851 E0               [24] 1462 	movx	a,@dptr
      004852 FE               [12] 1463 	mov	r6,a
      004853 E0               [24] 1464 	movx	a,@dptr
      004854 60 0F            [24] 1465 	jz	00128$
                                   1466 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004856 90 06 2F         [24] 1467 	mov	dptr,#_ak820_oneshot_consumed
      004859 EE               [12] 1468 	mov	a,r6
      00485A F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      00485B 90 0D 84         [24] 1471 	mov	dptr,#_ak820_oneshot_target
      00485E EF               [12] 1472 	mov	a,r7
      00485F F0               [24] 1473 	movx	@dptr,a
                                   1474 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004860 90 06 2E         [24] 1475 	mov	dptr,#_ak820_oneshot_mods
      004863 E4               [12] 1476 	clr	a
      004864 F0               [24] 1477 	movx	@dptr,a
      004865                       1478 00128$:
                                   1479 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004865 75 82 01         [24] 1480 	mov	dpl, #0x01
                                   1481 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004868 22               [24] 1482 	ret
                                   1483 	.area CSEG    (CODE)
                                   1484 	.area CONST   (CODE)
                                   1485 	.area XINIT   (CODE)
      00BFAB                       1486 __xinit__pending:
      00BFAB FF                    1487 	.db #0xff	; 255
      00BFAC                       1488 __xinit__ak820_oneshot_target:
      00BFAC FF                    1489 	.db #0xff	; 255
                                   1490 	.area CABS    (ABS,CODE)
                                   1491 
                                   1492 ; Experimental exact instruction outlining.
                                   1493 	.globl _ak820_outline_0004
                                   1494 	.globl _ak820_outline_0005
                                   1495 	.globl _ak820_outline_0009
                                   1496 	.globl _ak820_outline_0010
                                   1497 	.globl _ak820_outline_0011
                                   1498 	.globl _ak820_outline_0012
                                   1499 	.globl _ak820_outline_0013
                                   1500 	.globl _ak820_outline_0016
                                   1501 	.globl _ak820_outline_0018
                                   1502 	.globl _ak820_outline_0022
                                   1503 	.globl _ak820_outline_0029
                                   1504 	.globl _ak820_outline_0033
                                   1505 	.globl _ak820_outline_0045
                                   1506 	.globl _ak820_outline_0050
                                   1507 	.globl _ak820_outline_0054
                                   1508 	.globl _ak820_outline_0055
                                   1509 	.globl _ak820_outline_0058
                                   1510 	.globl _ak820_outline_0060
                                   1511 	.globl _ak820_outline_0064
                                   1512 	.globl _ak820_outline_0074
                                   1513 	.globl _ak820_outline_0077
                                   1514 	.globl _ak820_outline_0090
                                   1515 	.globl _ak820_outline_0097
                                   1516 	.globl _ak820_outline_0099
                                   1517 	.globl _ak820_outline_0103
                                   1518 	.globl _ak820_outline_0104
                                   1519 	.globl _ak820_outline_0116
                                   1520 	.globl _ak820_outline_0121
                                   1521 	.globl _ak820_outline_0122
                                   1522 	.globl _ak820_outline_0132
                                   1523 	.globl _ak820_outline_0150
                                   1524 	.globl _ak820_outline_0153
                                   1525 	.globl _ak820_outline_0185
                                   1526 
                                   1527 	.area CSEG (CODE)
                                   1528 ; function ak820_outline_0011
      004869                       1529 _ak820_outline_0011:
      004869 2E               [12] 1530 	add	a,r6
      00486A FC               [12] 1531 	mov	r4,a
      00486B E4               [12] 1532 	clr	a
      00486C 3F               [12] 1533 	addc	a,r7
      00486D FD               [12] 1534 	mov	r5,a
      00486E 8C 82            [24] 1535 	mov	dpl,r4
      004870 8D 83            [24] 1536 	mov	dph,r5
      004872 E0               [24] 1537 	movx	a,@dptr
      004873 22               [24] 1538 	ret
                                   1539 
                                   1540 	.area CSEG (CODE)
                                   1541 ; function ak820_outline_0012
      004874                       1542 _ak820_outline_0012:
      004874 2E               [12] 1543 	add	a,r6
      004875 FB               [12] 1544 	mov	r3,a
      004876 E4               [12] 1545 	clr	a
      004877 3F               [12] 1546 	addc	a,r7
      004878 FC               [12] 1547 	mov	r4,a
      004879 8B 82            [24] 1548 	mov	dpl,r3
      00487B 8C 83            [24] 1549 	mov	dph,r4
      00487D E0               [24] 1550 	movx	a,@dptr
      00487E 22               [24] 1551 	ret
                                   1552 
                                   1553 	.area CSEG (CODE)
                                   1554 ; function ak820_outline_0018
      00487F                       1555 _ak820_outline_0018:
      00487F EF               [12] 1556 	mov	a,r7
      004880 24 9A            [12] 1557 	add	a,#_source_state
      004882 FD               [12] 1558 	mov	r5,a
      004883 E4               [12] 1559 	clr	a
      004884 34 05            [12] 1560 	addc	a,#(_source_state>>8)
      004886 FE               [12] 1561 	mov	r6,a
      004887 8D 82            [24] 1562 	mov	dpl,r5
      004889 8E 83            [24] 1563 	mov	dph,r6
      00488B E0               [24] 1564 	movx	a,@dptr
      00488C FC               [12] 1565 	mov	r4,a
      00488D 22               [24] 1566 	ret
                                   1567 
                                   1568 	.area CSEG (CODE)
                                   1569 ; function ak820_outline_0022
      00488E                       1570 _ak820_outline_0022:
      00488E 90 0D 73         [24] 1571 	mov	dptr,#___memcpy_PARM_2
      004891 EC               [12] 1572 	mov	a,r4
      004892 F0               [24] 1573 	movx	@dptr,a
      004893 ED               [12] 1574 	mov	a,r5
      004894 A3               [24] 1575 	inc	dptr
      004895 F0               [24] 1576 	movx	@dptr,a
      004896 E4               [12] 1577 	clr	a
      004897 A3               [24] 1578 	inc	dptr
      004898 F0               [24] 1579 	movx	@dptr,a
      004899 90 0D 76         [24] 1580 	mov	dptr,#___memcpy_PARM_3
      00489C 74 02            [12] 1581 	mov	a,#0x02
      00489E F0               [24] 1582 	movx	@dptr,a
      00489F E4               [12] 1583 	clr	a
      0048A0 A3               [24] 1584 	inc	dptr
      0048A1 F0               [24] 1585 	movx	@dptr,a
      0048A2 90 06 20         [24] 1586 	mov	dptr,#_ak820_tapping_source_PARM_1
      0048A5 F5 F0            [12] 1587 	mov	b,a
      0048A7 22               [24] 1588 	ret
                                   1589 
                                   1590 	.area CSEG (CODE)
                                   1591 ; function ak820_outline_0045
      0048A8                       1592 _ak820_outline_0045:
      0048A8 2E               [12] 1593 	add	a,r6
      0048A9 FA               [12] 1594 	mov	r2,a
      0048AA E4               [12] 1595 	clr	a
      0048AB 3F               [12] 1596 	addc	a,r7
      0048AC FB               [12] 1597 	mov	r3,a
      0048AD 8A 82            [24] 1598 	mov	dpl,r2
      0048AF 8B 83            [24] 1599 	mov	dph,r3
      0048B1 E0               [24] 1600 	movx	a,@dptr
      0048B2 22               [24] 1601 	ret
                                   1602 
                                   1603 	.area CSEG (CODE)
                                   1604 ; function ak820_outline_0054
      0048B3                       1605 _ak820_outline_0054:
      0048B3 74 01            [12] 1606 	mov	a,#0x01
      0048B5 F0               [24] 1607 	movx	@dptr,a
      0048B6 8E 82            [24] 1608 	mov	dpl,r6
      0048B8 8F 83            [24] 1609 	mov	dph,r7
      0048BA 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0055
      0048BB                       1614 _ak820_outline_0055:
      0048BB FC               [12] 1615 	mov	r4,a
      0048BC 8B 82            [24] 1616 	mov	dpl,r3
      0048BE 8C 83            [24] 1617 	mov	dph,r4
      0048C0 E0               [24] 1618 	movx	a,@dptr
      0048C1 FA               [12] 1619 	mov	r2,a
      0048C2 22               [24] 1620 	ret
                                   1621 
                                   1622 	.area CSEG (CODE)
                                   1623 ; function ak820_outline_0058
      0048C3                       1624 _ak820_outline_0058:
      0048C3 EE               [12] 1625 	mov	a,r6
      0048C4 F0               [24] 1626 	movx	@dptr,a
      0048C5 EF               [12] 1627 	mov	a,r7
      0048C6 A3               [24] 1628 	inc	dptr
      0048C7 F0               [24] 1629 	movx	@dptr,a
      0048C8 22               [24] 1630 	ret
                                   1631 
                                   1632 	.area CSEG (CODE)
                                   1633 ; function ak820_outline_0074
      0048C9                       1634 _ak820_outline_0074:
      0048C9 8D 82            [24] 1635 	mov	dpl,r5
      0048CB 8E 83            [24] 1636 	mov	dph,r6
      0048CD E0               [24] 1637 	movx	a,@dptr
      0048CE FC               [12] 1638 	mov	r4,a
      0048CF 22               [24] 1639 	ret
                                   1640 
                                   1641 	.area CSEG (CODE)
                                   1642 ; function ak820_outline_0077
      0048D0                       1643 _ak820_outline_0077:
      0048D0 24 9A            [12] 1644 	add	a,#_source_state
      0048D2 FC               [12] 1645 	mov	r4,a
      0048D3 E4               [12] 1646 	clr	a
      0048D4 34 05            [12] 1647 	addc	a,#(_source_state>>8)
      0048D6 FD               [12] 1648 	mov	r5,a
      0048D7 8C 82            [24] 1649 	mov	dpl,r4
      0048D9 8D 83            [24] 1650 	mov	dph,r5
      0048DB E0               [24] 1651 	movx	a,@dptr
      0048DC FB               [12] 1652 	mov	r3,a
      0048DD 22               [24] 1653 	ret
                                   1654 
                                   1655 	.area CSEG (CODE)
                                   1656 ; function ak820_outline_0150
      0048DE                       1657 _ak820_outline_0150:
      0048DE 90 0D 83         [24] 1658 	mov	dptr,#_pending
      0048E1 74 FF            [12] 1659 	mov	a,#0xff
      0048E3 F0               [24] 1660 	movx	@dptr,a
      0048E4 22               [24] 1661 	ret
