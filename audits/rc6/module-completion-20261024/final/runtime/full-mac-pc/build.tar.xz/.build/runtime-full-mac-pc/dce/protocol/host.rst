                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module host
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_host_send_extra
                                     12 	.globl _ak820_host_send_keyboard
                                     13 	.globl _ak820_host_keyboard_leds
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _host_set_driver
                                    258 	.globl _host_keyboard_leds
                                    259 	.globl _host_keyboard_send
                                    260 	.globl _host_system_send
                                    261 	.globl _host_consumer_send
                                    262 	.globl _host_last_system_usage
                                    263 	.globl _host_last_consumer_usage
                                    264 ;--------------------------------------------------------
                                    265 ; special function registers
                                    266 ;--------------------------------------------------------
                                    267 	.area RSEG    (ABS,DATA)
      000000                        268 	.org 0x0000
                           0000D0   269 _PSW	=	0x00d0
                           0000E0   270 _ACC	=	0x00e0
                           0000F0   271 _B	=	0x00f0
                           0000FD   272 _A_INV	=	0x00fd
                           000081   273 _SP	=	0x0081
                           000082   274 _DPL	=	0x0082
                           000083   275 _DPH	=	0x0083
                           0000A1   276 _SAFE_MOD	=	0x00a1
                           0000B1   277 _GLOBAL_CFG	=	0x00b1
                           000087   278 _PCON	=	0x0087
                           0000BA   279 _POWER_CFG	=	0x00ba
                           0000B9   280 _CLOCK_CFG	=	0x00b9
                           0000A9   281 _WAKE_CTRL	=	0x00a9
                           0000FE   282 _RESET_KEEP	=	0x00fe
                           0000FF   283 _WDOG_COUNT	=	0x00ff
                           0000A8   284 _IE	=	0x00a8
                           0000B8   285 _IP	=	0x00b8
                           0000E8   286 _IE_EX	=	0x00e8
                           0000E9   287 _IP_EX	=	0x00e9
                           0000B2   288 _GPIO_IE	=	0x00b2
                           008584   289 _ROM_ADDR	=	0x8584
                           000084   290 _ROM_ADDR_L	=	0x0084
                           000085   291 _ROM_ADDR_H	=	0x0085
                           008F8E   292 _ROM_DATA_HI	=	0x8f8e
                           00008E   293 _ROM_DATA_HL	=	0x008e
                           00008F   294 _ROM_DATA_HH	=	0x008f
                           000086   295 _ROM_CTRL	=	0x0086
                           000080   296 _P0	=	0x0080
                           0000C4   297 _P0_MOD_OC	=	0x00c4
                           0000C5   298 _P0_DIR_PU	=	0x00c5
                           000090   299 _P1	=	0x0090
                           000092   300 _P1_MOD_OC	=	0x0092
                           000093   301 _P1_DIR_PU	=	0x0093
                           0000A0   302 _P2	=	0x00a0
                           000094   303 _P2_MOD_OC	=	0x0094
                           000095   304 _P2_DIR_PU	=	0x0095
                           0000B0   305 _P3	=	0x00b0
                           000096   306 _P3_MOD_OC	=	0x0096
                           000097   307 _P3_DIR_PU	=	0x0097
                           0000C0   308 _P4	=	0x00c0
                           0000C2   309 _P4_MOD_OC	=	0x00c2
                           0000C3   310 _P4_DIR_PU	=	0x00c3
                           0000C1   311 _P4_LED_KEY	=	0x00c1
                           0000AA   312 _P5_IN	=	0x00aa
                           0000AB   313 _P5_OUT_PU	=	0x00ab
                           0000AC   314 _P5_DIR	=	0x00ac
                           0000AD   315 _P6_IN	=	0x00ad
                           0000AE   316 _P6_OUT_PU	=	0x00ae
                           0000AF   317 _P6_DIR	=	0x00af
                           0000F1   318 _P7	=	0x00f1
                           0000A2   319 _XBUS_AUX	=	0x00a2
                           000088   320 _TCON	=	0x0088
                           000089   321 _TMOD	=	0x0089
                           00008A   322 _TL0	=	0x008a
                           00008B   323 _TL1	=	0x008b
                           00008C   324 _TH0	=	0x008c
                           00008D   325 _TH1	=	0x008d
                           000098   326 _SCON	=	0x0098
                           000099   327 _SBUF	=	0x0099
                           0000C8   328 _T2CON	=	0x00c8
                           0000C9   329 _T2MOD	=	0x00c9
                           00CBCA   330 _RCAP2	=	0xcbca
                           0000CA   331 _RCAP2L	=	0x00ca
                           0000CB   332 _RCAP2H	=	0x00cb
                           00CDCC   333 _T2COUNT	=	0xcdcc
                           0000CC   334 _TL2	=	0x00cc
                           0000CD   335 _TH2	=	0x00cd
                           00CFCE   336 _T2CAP1	=	0xcfce
                           0000CE   337 _T2CAP1L	=	0x00ce
                           0000CF   338 _T2CAP1H	=	0x00cf
                           0000F8   339 _SPI0_STAT	=	0x00f8
                           0000F9   340 _SPI0_DATA	=	0x00f9
                           0000FA   341 _SPI0_CTRL	=	0x00fa
                           0000FB   342 _SPI0_CK_SE	=	0x00fb
                           0000FC   343 _SPI0_SETUP	=	0x00fc
                           0000BC   344 _SCON1	=	0x00bc
                           0000BD   345 _SBUF1	=	0x00bd
                           0000BE   346 _SBAUD1	=	0x00be
                           0000BF   347 _SIF1	=	0x00bf
                           0000B4   348 _SPI1_STAT	=	0x00b4
                           0000B5   349 _SPI1_DATA	=	0x00b5
                           0000B6   350 _SPI1_CTRL	=	0x00b6
                           0000B7   351 _SPI1_CK_SE	=	0x00b7
                           0000F3   352 _ADC_CTRL	=	0x00f3
                           00F5F4   353 _ADC_DAT	=	0xf5f4
                           0000F4   354 _ADC_DAT_L	=	0x00f4
                           0000F5   355 _ADC_DAT_H	=	0x00f5
                           0000F6   356 _ADC_CHAN	=	0x00f6
                           0000A6   357 _LED_COMMON	=	0x00a6
                           0000A7   358 _LED_PWM_OE	=	0x00a7
                           00C7C6   359 _LED_DMA	=	0xc7c6
                           0000C6   360 _LED_DMA_L	=	0x00c6
                           0000C7   361 _LED_DMA_H	=	0x00c7
                           0000F7   362 _LED_STATUS	=	0x00f7
                           0000B3   363 _I2CX_INT	=	0x00b3
                           0000BB   364 _I2CS_INT_ST	=	0x00bb
                                    365 ;--------------------------------------------------------
                                    366 ; special function bits
                                    367 ;--------------------------------------------------------
                                    368 	.area RSEG    (ABS,DATA)
      000000                        369 	.org 0x0000
                           0000D7   370 _CY	=	0x00d7
                           0000D6   371 _AC	=	0x00d6
                           0000D5   372 _F0	=	0x00d5
                           0000D4   373 _RS1	=	0x00d4
                           0000D3   374 _RS0	=	0x00d3
                           0000D2   375 _OV	=	0x00d2
                           0000D1   376 _F1	=	0x00d1
                           0000D0   377 _P	=	0x00d0
                           0000AF   378 _EA	=	0x00af
                           0000AE   379 _E_DIS	=	0x00ae
                           0000AD   380 _ET2	=	0x00ad
                           0000AC   381 _ES	=	0x00ac
                           0000AB   382 _ET1	=	0x00ab
                           0000AA   383 _EX1	=	0x00aa
                           0000A9   384 _ET0	=	0x00a9
                           0000A8   385 _EX0	=	0x00a8
                           0000BF   386 _PH_FLAG	=	0x00bf
                           0000BE   387 _PL_FLAG	=	0x00be
                           0000BD   388 _PT2	=	0x00bd
                           0000BC   389 _PS	=	0x00bc
                           0000BB   390 _PT1	=	0x00bb
                           0000BA   391 _PX1	=	0x00ba
                           0000B9   392 _PT0	=	0x00b9
                           0000B8   393 _PX0	=	0x00b8
                           0000EF   394 _IE_WDOG	=	0x00ef
                           0000EE   395 _IE_GPIO	=	0x00ee
                           0000ED   396 _IE_PWM_I2C	=	0x00ed
                           0000EC   397 _IE_UART1	=	0x00ec
                           0000EB   398 _IE_ADC	=	0x00eb
                           0000E9   399 _IE_USB	=	0x00e9
                           0000E8   400 _IE_SPI0	=	0x00e8
                           000087   401 _P0_7	=	0x0087
                           000086   402 _P0_6	=	0x0086
                           000085   403 _P0_5	=	0x0085
                           000084   404 _P0_4	=	0x0084
                           000083   405 _P0_3	=	0x0083
                           000082   406 _P0_2	=	0x0082
                           000081   407 _P0_1	=	0x0081
                           000080   408 _P0_0	=	0x0080
                           000081   409 _SDA0	=	0x0081
                           000080   410 _SCL0	=	0x0080
                           000083   411 _TXD_	=	0x0083
                           000082   412 _RXD_	=	0x0082
                           000085   413 _AIN13	=	0x0085
                           000084   414 _AIN12	=	0x0084
                           000083   415 _AIN11	=	0x0083
                           000082   416 _AIN10	=	0x0082
                           000081   417 _AIN9	=	0x0081
                           000080   418 _AIN8	=	0x0080
                           000097   419 _P1_7	=	0x0097
                           000096   420 _P1_6	=	0x0096
                           000095   421 _P1_5	=	0x0095
                           000094   422 _P1_4	=	0x0094
                           000093   423 _P1_3	=	0x0093
                           000092   424 _P1_2	=	0x0092
                           000091   425 _P1_1	=	0x0091
                           000090   426 _P1_0	=	0x0090
                           000097   427 _TXD1_	=	0x0097
                           000096   428 _RXD1_	=	0x0096
                           000097   429 _SCK	=	0x0097
                           000096   430 _MISO	=	0x0096
                           000095   431 _MOSI	=	0x0095
                           000094   432 _SCS	=	0x0094
                           000092   433 _INT0_	=	0x0092
                           000091   434 _T2EX	=	0x0091
                           000091   435 _CAP2	=	0x0091
                           000090   436 _T2	=	0x0090
                           000090   437 _CAP1	=	0x0090
                           000097   438 _AIN7	=	0x0097
                           000096   439 _AIN6	=	0x0096
                           000095   440 _AIN5	=	0x0095
                           000094   441 _AIN4	=	0x0094
                           000093   442 _AIN3	=	0x0093
                           000092   443 _AIN2	=	0x0092
                           000091   444 _AIN1	=	0x0091
                           000090   445 _AIN0	=	0x0090
                           0000A7   446 _P2_7	=	0x00a7
                           0000A6   447 _P2_6	=	0x00a6
                           0000A5   448 _P2_5	=	0x00a5
                           0000A4   449 _P2_4	=	0x00a4
                           0000A3   450 _P2_3	=	0x00a3
                           0000A2   451 _P2_2	=	0x00a2
                           0000A1   452 _P2_1	=	0x00a1
                           0000A0   453 _P2_0	=	0x00a0
                           0000A7   454 _TXD1	=	0x00a7
                           0000A6   455 _RXD1	=	0x00a6
                           0000A5   456 _T2EX_	=	0x00a5
                           0000A5   457 _CAP2_	=	0x00a5
                           0000A4   458 _T2_	=	0x00a4
                           0000A4   459 _CAP1_	=	0x00a4
                           0000B7   460 _P3_7	=	0x00b7
                           0000B6   461 _P3_6	=	0x00b6
                           0000B5   462 _P3_5	=	0x00b5
                           0000B4   463 _P3_4	=	0x00b4
                           0000B3   464 _P3_3	=	0x00b3
                           0000B2   465 _P3_2	=	0x00b2
                           0000B1   466 _P3_1	=	0x00b1
                           0000B0   467 _P3_0	=	0x00b0
                           0000B7   468 _SCK1	=	0x00b7
                           0000B6   469 _MISO1	=	0x00b6
                           0000B5   470 _MOSI1	=	0x00b5
                           0000B5   471 _T1	=	0x00b5
                           0000B4   472 _T0	=	0x00b4
                           0000B3   473 _INT1	=	0x00b3
                           0000B2   474 _INT0	=	0x00b2
                           0000B1   475 _TXD	=	0x00b1
                           0000B0   476 _RXD	=	0x00b0
                           0000C6   477 _P4_6	=	0x00c6
                           0000C5   478 _P4_5	=	0x00c5
                           0000C4   479 _P4_4	=	0x00c4
                           0000C3   480 _P4_3	=	0x00c3
                           0000C2   481 _P4_2	=	0x00c2
                           0000C1   482 _P4_1	=	0x00c1
                           0000C0   483 _P4_0	=	0x00c0
                           00008F   484 _TF1	=	0x008f
                           00008E   485 _TR1	=	0x008e
                           00008D   486 _TF0	=	0x008d
                           00008C   487 _TR0	=	0x008c
                           00008B   488 _IE1	=	0x008b
                           00008A   489 _IT1	=	0x008a
                           000089   490 _IE0	=	0x0089
                           000088   491 _IT0	=	0x0088
                           00009F   492 _SM0	=	0x009f
                           00009E   493 _SM1	=	0x009e
                           00009D   494 _SM2	=	0x009d
                           00009C   495 _REN	=	0x009c
                           00009B   496 _TB8	=	0x009b
                           00009A   497 _RB8	=	0x009a
                           000099   498 _TI	=	0x0099
                           000098   499 _RI	=	0x0098
                           0000CF   500 _TF2	=	0x00cf
                           0000CF   501 _CAP1F	=	0x00cf
                           0000CE   502 _EXF2	=	0x00ce
                           0000CD   503 _RCLK	=	0x00cd
                           0000CC   504 _TCLK	=	0x00cc
                           0000CB   505 _EXEN2	=	0x00cb
                           0000CA   506 _TR2	=	0x00ca
                           0000C9   507 _C_T2	=	0x00c9
                           0000C8   508 _CP_RL2	=	0x00c8
                           0000FF   509 _S0_FST_ACT	=	0x00ff
                           0000FE   510 _S0_IF_OV	=	0x00fe
                           0000FD   511 _S0_IF_FIRST	=	0x00fd
                           0000FC   512 _S0_IF_BYTE	=	0x00fc
                           0000FB   513 _S0_FREE	=	0x00fb
                           0000FA   514 _S0_T_FIFO	=	0x00fa
                           0000F8   515 _S0_R_FIFO	=	0x00f8
                           0000F7   516 _ADC_START	=	0x00f7
                                    517 ;--------------------------------------------------------
                                    518 ; overlayable register banks
                                    519 ;--------------------------------------------------------
                                    520 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        521 	.ds 8
                                    522 ;--------------------------------------------------------
                                    523 ; internal ram data
                                    524 ;--------------------------------------------------------
                                    525 	.area DSEG    (DATA)
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable items in internal ram
                                    528 ;--------------------------------------------------------
                                    529 ;--------------------------------------------------------
                                    530 ; indirectly addressable internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area ISEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; absolute internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area IABS    (ABS,DATA)
                                    537 	.area IABS    (ABS,DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; bit data
                                    540 ;--------------------------------------------------------
                                    541 	.area BSEG    (BIT)
                                    542 ;--------------------------------------------------------
                                    543 ; paged external ram data
                                    544 ;--------------------------------------------------------
                                    545 	.area PSEG    (PAG,XDATA)
                                    546 ;--------------------------------------------------------
                                    547 ; uninitialized external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area XSEG    (XDATA)
      0007DB                        550 _driver:
      0007DB                        551 	.ds 2
      0007DD                        552 _host_set_driver_d_10000_179:
      0007DD                        553 	.ds 3
      0007E0                        554 _host_keyboard_send_report_10000_188:
      0007E0                        555 	.ds 3
      0007E3                        556 _host_extra_send_PARM_2:
      0007E3                        557 	.ds 2
      0007E5                        558 _host_extra_send_report_id_10000_201:
      0007E5                        559 	.ds 1
      0007E6                        560 _host_extra_send_report_10001_204:
      0007E6                        561 	.ds 3
      0007E9                        562 _host_system_send_usage_10000_205:
      0007E9                        563 	.ds 2
      0007EB                        564 _host_consumer_send_usage_10000_208:
      0007EB                        565 	.ds 2
                                    566 ;--------------------------------------------------------
                                    567 ; absolute external ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area XABS    (ABS,XDATA)
                                    570 ;--------------------------------------------------------
                                    571 ; initialized external ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area XISEG   (XDATA)
      000D8E                        574 _last_system_usage:
      000D8E                        575 	.ds 2
      000D90                        576 _last_consumer_usage:
      000D90                        577 	.ds 2
                                    578 	.area HOME    (CODE)
                                    579 	.area GSINIT0 (CODE)
                                    580 	.area GSINIT1 (CODE)
                                    581 	.area GSINIT2 (CODE)
                                    582 	.area GSINIT3 (CODE)
                                    583 	.area GSINIT4 (CODE)
                                    584 	.area GSINIT5 (CODE)
                                    585 	.area GSINIT  (CODE)
                                    586 	.area GSFINAL (CODE)
                                    587 	.area CSEG    (CODE)
                                    588 ;--------------------------------------------------------
                                    589 ; global & static initialisations
                                    590 ;--------------------------------------------------------
                                    591 	.area HOME    (CODE)
                                    592 	.area GSINIT  (CODE)
                                    593 	.area GSFINAL (CODE)
                                    594 	.area GSINIT  (CODE)
                                    595 ;--------------------------------------------------------
                                    596 ; Home
                                    597 ;--------------------------------------------------------
                                    598 	.area HOME    (CODE)
                                    599 	.area HOME    (CODE)
                                    600 ;--------------------------------------------------------
                                    601 ; code
                                    602 ;--------------------------------------------------------
                                    603 	.area CSEG    (CODE)
                                    604 ;------------------------------------------------------------
                                    605 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    606 ;------------------------------------------------------------
                                    607 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_98'
                                    608 ;------------------------------------------------------------
                                    609 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    610 ;	-----------------------------------------
                           000007   611 	ar7 = 0x07
                           000006   612 	ar6 = 0x06
                           000005   613 	ar5 = 0x05
                           000004   614 	ar4 = 0x04
                           000003   615 	ar3 = 0x03
                           000002   616 	ar2 = 0x02
                           000001   617 	ar1 = 0x01
                           000000   618 	ar0 = 0x00
                                    619 ;	 function host_set_driver
                                    620 ;	-----------------------------------------
      006C57                        621 _host_set_driver:
      006C57 12 43 3B         [24]  622 	lcall	_ak820_outline_0036
      006C5A 90 07 DD         [24]  623 	mov	dptr,#_host_set_driver_d_10000_179
      006C5D 12 37 DF         [24]  624 	lcall	_ak820_outline_0015
                                    625 ;	tmk_core/protocol/host.c:57: driver = (host_driver_t __xdata *)d;
      006C60 90 07 DD         [24]  626 	mov	dptr,#_host_set_driver_d_10000_179
      006C63 12 38 00         [24]  627 	lcall	_ak820_outline_0050
      006C66 90 07 DB         [24]  628 	mov	dptr,#_driver
      006C69 12 48 C3         [24]  629 	lcall	_ak820_outline_0058
                                    630 ;	tmk_core/protocol/host.c:61: }
      006C6C 22               [24]  631 	ret
                                    632 ;------------------------------------------------------------
                                    633 ;Allocation info for local variables in function 'host_get_driver'
                                    634 ;------------------------------------------------------------
                                    635 ;	tmk_core/protocol/host.c:63: host_driver_t *host_get_driver(void) {
                                    636 ;	-----------------------------------------
                                    637 ;	 function host_keyboard_leds
                                    638 ;	-----------------------------------------
      006C6D                        639 _host_keyboard_leds:
                                    640 ;	tmk_core/protocol/host.c:78: if (!driver) return 0;
      006C6D 90 07 DB         [24]  641 	mov	dptr,#_driver
      006C70 E0               [24]  642 	movx	a,@dptr
      006C71 FE               [12]  643 	mov	r6,a
      006C72 A3               [24]  644 	inc	dptr
      006C73 E0               [24]  645 	movx	a,@dptr
      006C74 4E               [12]  646 	orl	a,r6
      006C75 70 03            [24]  647 	jnz	00102$
      006C77 F5 82            [12]  648 	mov	dpl,a
      006C79 22               [24]  649 	ret
      006C7A                        650 00102$:
                                    651 ;	tmk_core/protocol/host.c:80: return ak820_host_keyboard_leds();
                                    652 ;	tmk_core/protocol/host.c:84: }
      006C7A 02 4A CB         [24]  653 	ljmp	_ak820_host_keyboard_leds
                                    654 ;------------------------------------------------------------
                                    655 ;Allocation info for local variables in function 'host_keyboard_led_state'
                                    656 ;------------------------------------------------------------
                                    657 ;usb_led       Allocated with name '_host_keyboard_led_state_usb_led_10000_187'
                                    658 ;usb_led_p2    Allocated with name '_host_keyboard_led_state_usb_led_p2_10000_187'
                                    659 ;usb_led_p     Allocated with name '_host_keyboard_led_state_usb_led_p_10000_187'
                                    660 ;------------------------------------------------------------
                                    661 ;	tmk_core/protocol/host.c:86: led_t host_keyboard_led_state(void) {
                                    662 ;	-----------------------------------------
                                    663 ;	 function host_keyboard_send
                                    664 ;	-----------------------------------------
      006C7D                        665 _host_keyboard_send:
      006C7D 12 43 3B         [24]  666 	lcall	_ak820_outline_0036
      006C80 90 07 E0         [24]  667 	mov	dptr,#_host_keyboard_send_report_10000_188
      006C83 12 37 DF         [24]  668 	lcall	_ak820_outline_0015
                                    669 ;	tmk_core/protocol/host.c:103: if (!driver) return;
      006C86 90 07 DB         [24]  670 	mov	dptr,#_driver
      006C89 12 6D 76         [24]  671 	lcall	_ak820_outline_0035
      006C8C 70 01            [24]  672 	jnz	00102$
      006C8E 22               [24]  673 	ret
      006C8F                        674 00102$:
                                    675 ;	tmk_core/protocol/host.c:105: if (keyboard_protocol && keymap_config.nkro) {
      006C8F 90 0D 85         [24]  676 	mov	dptr,#_keyboard_protocol
      006C92 E0               [24]  677 	movx	a,@dptr
      006C93 60 2C            [24]  678 	jz	00104$
      006C95 90 0A B7         [24]  679 	mov	dptr,#_keymap_config
      006C98 E0               [24]  680 	movx	a,@dptr
      006C99 30 E7 25         [24]  681 	jnb	acc.7,00104$
                                    682 ;	tmk_core/protocol/host.c:109: report->nkro.mods      = report->mods;
      006C9C 90 07 E0         [24]  683 	mov	dptr,#_host_keyboard_send_report_10000_188
      006C9F 12 4F 0F         [24]  684 	lcall	_ak820_outline_0021
      006CA2 74 01            [12]  685 	mov	a,#0x01
      006CA4 2D               [12]  686 	add	a, r5
      006CA5 FA               [12]  687 	mov	r2,a
      006CA6 E4               [12]  688 	clr	a
      006CA7 3E               [12]  689 	addc	a, r6
      006CA8 FB               [12]  690 	mov	r3,a
      006CA9 8F 04            [24]  691 	mov	ar4,r7
      006CAB 12 4F 18         [24]  692 	lcall	_ak820_outline_0043
      006CAE 12 B7 C4         [24]  693 	lcall	__gptrget
      006CB1 12 43 A0         [24]  694 	lcall	_ak820_outline_0140
      006CB4 8C F0            [24]  695 	mov	b,r4
      006CB6 12 B7 89         [24]  696 	lcall	__gptrput
                                    697 ;	tmk_core/protocol/host.c:110: report->nkro.report_id = REPORT_ID_NKRO;
      006CB9 12 4F 18         [24]  698 	lcall	_ak820_outline_0043
      006CBC 74 06            [12]  699 	mov	a,#0x06
      006CBE 12 B7 89         [24]  700 	lcall	__gptrput
      006CC1                        701 00104$:
                                    702 ;	tmk_core/protocol/host.c:119: ak820_host_send_keyboard(report);
      006CC1 90 07 E0         [24]  703 	mov	dptr,#_host_keyboard_send_report_10000_188
      006CC4 12 4F 00         [24]  704 	lcall	_ak820_outline_0003
      006CC7 12 4A CE         [24]  705 	lcall	_ak820_host_send_keyboard
                                    706 ;	tmk_core/protocol/host.c:124: if (debug_keyboard) {
      006CCA 90 0D E5         [24]  707 	mov	dptr,#_debug_config
      006CCD E0               [24]  708 	movx	a,@dptr
      006CCE 30 E2 0A         [24]  709 	jnb	acc.2,00112$
                                    710 ;	tmk_core/protocol/host.c:126: for (uint8_t i = 0; i < KEYBOARD_REPORT_SIZE; i++) {
      006CD1 7F 00            [12]  711 	mov	r7,#0x00
      006CD3                        712 00110$:
      006CD3 BF 08 00         [24]  713 	cjne	r7,#0x08,00161$
      006CD6                        714 00161$:
      006CD6 50 03            [24]  715 	jnc	00112$
      006CD8 0F               [12]  716 	inc	r7
      006CD9 80 F8            [24]  717 	sjmp	00110$
      006CDB                        718 00112$:
                                    719 ;	tmk_core/protocol/host.c:131: }
      006CDB 22               [24]  720 	ret
                                    721 ;------------------------------------------------------------
                                    722 ;Allocation info for local variables in function 'host_mouse_send'
                                    723 ;------------------------------------------------------------
                                    724 ;report        Allocated with name '_host_mouse_send_report_10000_198'
                                    725 ;------------------------------------------------------------
                                    726 ;	tmk_core/protocol/host.c:133: void host_mouse_send(report_mouse_t *report) {
                                    727 ;	-----------------------------------------
                                    728 ;	 function host_extra_send
                                    729 ;	-----------------------------------------
      006CDC                        730 _host_extra_send:
      006CDC E5 82            [12]  731 	mov	a,dpl
      006CDE 90 07 E5         [24]  732 	mov	dptr,#_host_extra_send_report_id_10000_201
      006CE1 F0               [24]  733 	movx	@dptr,a
                                    734 ;	tmk_core/protocol/host.c:158: if (!driver) return;
      006CE2 90 07 DB         [24]  735 	mov	dptr,#_driver
      006CE5 12 6D 76         [24]  736 	lcall	_ak820_outline_0035
      006CE8 70 01            [24]  737 	jnz	00102$
      006CEA 22               [24]  738 	ret
      006CEB                        739 00102$:
                                    740 ;	tmk_core/protocol/host.c:159: report_extra_t report = {
      006CEB 90 07 E5         [24]  741 	mov	dptr,#_host_extra_send_report_id_10000_201
      006CEE E0               [24]  742 	movx	a,@dptr
      006CEF 90 07 E6         [24]  743 	mov	dptr,#_host_extra_send_report_10001_204
      006CF2 F0               [24]  744 	movx	@dptr,a
      006CF3 90 07 E3         [24]  745 	mov	dptr,#_host_extra_send_PARM_2
      006CF6 12 38 00         [24]  746 	lcall	_ak820_outline_0050
      006CF9 90 07 E7         [24]  747 	mov	dptr,#(_host_extra_send_report_10001_204 + 0x0001)
      006CFC 12 48 C3         [24]  748 	lcall	_ak820_outline_0058
                                    749 ;	tmk_core/protocol/host.c:164: ak820_host_send_extra(&report);
      006CFF 90 07 E6         [24]  750 	mov	dptr,#_host_extra_send_report_10001_204
      006D02 75 F0 00         [24]  751 	mov	b, #0x00
                                    752 ;	tmk_core/protocol/host.c:168: }
      006D05 02 4A F2         [24]  753 	ljmp	_ak820_host_send_extra
                                    754 ;------------------------------------------------------------
                                    755 ;Allocation info for local variables in function 'host_system_send'
                                    756 ;------------------------------------------------------------
                                    757 ;usage         Allocated with name '_host_system_send_usage_10000_205'
                                    758 ;------------------------------------------------------------
                                    759 ;	tmk_core/protocol/host.c:170: void host_system_send(uint16_t usage) {
                                    760 ;	-----------------------------------------
                                    761 ;	 function host_system_send
                                    762 ;	-----------------------------------------
      006D08                        763 _host_system_send:
      006D08 12 38 43         [24]  764 	lcall	_ak820_outline_0103
      006D0B 90 07 E9         [24]  765 	mov	dptr,#_host_system_send_usage_10000_205
      006D0E 12 38 48         [24]  766 	lcall	_ak820_outline_0104
                                    767 ;	tmk_core/protocol/host.c:171: if (usage == last_system_usage) return;
      006D11 90 07 E9         [24]  768 	mov	dptr,#_host_system_send_usage_10000_205
      006D14 12 38 00         [24]  769 	lcall	_ak820_outline_0050
      006D17 90 0D 8E         [24]  770 	mov	dptr,#_last_system_usage
      006D1A 12 38 1F         [24]  771 	lcall	_ak820_outline_0059
      006D1D EE               [12]  772 	mov	a,r6
      006D1E B5 04 05         [24]  773 	cjne	a,ar4,00102$
      006D21 EF               [12]  774 	mov	a,r7
      006D22 B5 05 01         [24]  775 	cjne	a,ar5,00102$
      006D25 22               [24]  776 	ret
      006D26                        777 00102$:
                                    778 ;	tmk_core/protocol/host.c:172: last_system_usage = usage;
      006D26 90 0D 8E         [24]  779 	mov	dptr,#_last_system_usage
      006D29 12 48 C3         [24]  780 	lcall	_ak820_outline_0058
                                    781 ;	tmk_core/protocol/host.c:174: host_extra_send(REPORT_ID_SYSTEM, usage);
      006D2C 90 07 E3         [24]  782 	mov	dptr,#_host_extra_send_PARM_2
      006D2F 12 48 C3         [24]  783 	lcall	_ak820_outline_0058
      006D32 75 82 03         [24]  784 	mov	dpl, #0x03
                                    785 ;	tmk_core/protocol/host.c:175: }
      006D35 02 6C DC         [24]  786 	ljmp	_host_extra_send
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'host_consumer_send'
                                    789 ;------------------------------------------------------------
                                    790 ;usage         Allocated with name '_host_consumer_send_usage_10000_208'
                                    791 ;------------------------------------------------------------
                                    792 ;	tmk_core/protocol/host.c:177: void host_consumer_send(uint16_t usage) {
                                    793 ;	-----------------------------------------
                                    794 ;	 function host_consumer_send
                                    795 ;	-----------------------------------------
      006D38                        796 _host_consumer_send:
      006D38 12 38 43         [24]  797 	lcall	_ak820_outline_0103
      006D3B 90 07 EB         [24]  798 	mov	dptr,#_host_consumer_send_usage_10000_208
      006D3E 12 38 48         [24]  799 	lcall	_ak820_outline_0104
                                    800 ;	tmk_core/protocol/host.c:178: if (usage == last_consumer_usage) return;
      006D41 90 07 EB         [24]  801 	mov	dptr,#_host_consumer_send_usage_10000_208
      006D44 12 38 00         [24]  802 	lcall	_ak820_outline_0050
      006D47 90 0D 90         [24]  803 	mov	dptr,#_last_consumer_usage
      006D4A 12 38 1F         [24]  804 	lcall	_ak820_outline_0059
      006D4D EE               [12]  805 	mov	a,r6
      006D4E B5 04 05         [24]  806 	cjne	a,ar4,00102$
      006D51 EF               [12]  807 	mov	a,r7
      006D52 B5 05 01         [24]  808 	cjne	a,ar5,00102$
      006D55 22               [24]  809 	ret
      006D56                        810 00102$:
                                    811 ;	tmk_core/protocol/host.c:179: last_consumer_usage = usage;
      006D56 90 0D 90         [24]  812 	mov	dptr,#_last_consumer_usage
      006D59 12 48 C3         [24]  813 	lcall	_ak820_outline_0058
                                    814 ;	tmk_core/protocol/host.c:188: host_extra_send(REPORT_ID_CONSUMER, usage);
      006D5C 90 07 E3         [24]  815 	mov	dptr,#_host_extra_send_PARM_2
      006D5F 12 48 C3         [24]  816 	lcall	_ak820_outline_0058
      006D62 75 82 04         [24]  817 	mov	dpl, #0x04
                                    818 ;	tmk_core/protocol/host.c:189: }
      006D65 02 6C DC         [24]  819 	ljmp	_host_extra_send
                                    820 ;------------------------------------------------------------
                                    821 ;Allocation info for local variables in function 'host_last_system_usage'
                                    822 ;------------------------------------------------------------
                                    823 ;	tmk_core/protocol/host.c:284: uint16_t host_last_system_usage(void) {
                                    824 ;	-----------------------------------------
                                    825 ;	 function host_last_system_usage
                                    826 ;	-----------------------------------------
      006D68                        827 _host_last_system_usage:
                                    828 ;	tmk_core/protocol/host.c:285: return last_system_usage;
      006D68 90 0D 8E         [24]  829 	mov	dptr,#_last_system_usage
      006D6B 12 4F 4A         [24]  830 	lcall	_ak820_outline_0088
                                    831 ;	tmk_core/protocol/host.c:286: }
      006D6E 22               [24]  832 	ret
                                    833 ;------------------------------------------------------------
                                    834 ;Allocation info for local variables in function 'host_last_consumer_usage'
                                    835 ;------------------------------------------------------------
                                    836 ;	tmk_core/protocol/host.c:288: uint16_t host_last_consumer_usage(void) {
                                    837 ;	-----------------------------------------
                                    838 ;	 function host_last_consumer_usage
                                    839 ;	-----------------------------------------
      006D6F                        840 _host_last_consumer_usage:
                                    841 ;	tmk_core/protocol/host.c:289: return last_consumer_usage;
      006D6F 90 0D 90         [24]  842 	mov	dptr,#_last_consumer_usage
      006D72 12 4F 4A         [24]  843 	lcall	_ak820_outline_0088
                                    844 ;	tmk_core/protocol/host.c:290: }
      006D75 22               [24]  845 	ret
                                    846 	.area CSEG    (CODE)
                                    847 	.area CONST   (CODE)
                                    848 	.area XINIT   (CODE)
      00BFB6                        849 __xinit__last_system_usage:
      00BFB6 00 00                  850 	.byte #0x00, #0x00	; 0
      00BFB8                        851 __xinit__last_consumer_usage:
      00BFB8 00 00                  852 	.byte #0x00, #0x00	; 0
                                    853 	.area CABS    (ABS,CODE)
                                    854 
                                    855 ; Experimental exact instruction outlining.
                                    856 	.globl _ak820_outline_0003
                                    857 	.globl _ak820_outline_0015
                                    858 	.globl _ak820_outline_0021
                                    859 	.globl _ak820_outline_0035
                                    860 	.globl _ak820_outline_0036
                                    861 	.globl _ak820_outline_0043
                                    862 	.globl _ak820_outline_0050
                                    863 	.globl _ak820_outline_0058
                                    864 	.globl _ak820_outline_0059
                                    865 	.globl _ak820_outline_0088
                                    866 	.globl _ak820_outline_0103
                                    867 	.globl _ak820_outline_0104
                                    868 	.globl _ak820_outline_0140
                                    869 
                                    870 	.area CSEG (CODE)
                                    871 ; function ak820_outline_0035
      006D76                        872 _ak820_outline_0035:
      006D76 E0               [24]  873 	movx	a,@dptr
      006D77 F5 F0            [12]  874 	mov	b,a
      006D79 A3               [24]  875 	inc	dptr
      006D7A E0               [24]  876 	movx	a,@dptr
      006D7B 45 F0            [12]  877 	orl	a,b
      006D7D 22               [24]  878 	ret
