                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000519                        109 _page_data:
      000519                        110 	.ds 64
      000559                        111 _cached_page:
      000559                        112 	.ds 1
      00055A                        113 _batch_depth:
      00055A                        114 	.ds 1
      00055B                        115 _first_failure_stage:
      00055B                        116 	.ds 1
      00055C                        117 _nvm_fail_stage_10000_20:
      00055C                        118 	.ds 1
      00055D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055D                        120 	.ds 2
      00055F                        121 _crc_byte_PARM_2:
      00055F                        122 	.ds 1
      000560                        123 _crc_byte_crc_10000_25:
      000560                        124 	.ds 2
      000562                        125 _page_crc_crc_10000_30:
      000562                        126 	.ds 2
      000564                        127 _write_page_address_10000_32:
      000564                        128 	.ds 2
      000566                        129 _journal_header_valid_header_10000_39:
      000566                        130 	.ds 2
      000568                        131 _recover_journal_header_10000_46:
      000568                        132 	.ds 9
      000571                        133 _ak820_nvm_flush_header_10000_62:
      000571                        134 	.ds 9
      00057A                        135 _ak820_nvm_flush_stage_10000_62:
      00057A                        136 	.ds 1
      00057B                        137 _load_page_page_10000_87:
      00057B                        138 	.ds 1
      00057C                        139 _read_offset_offset_10000_93:
      00057C                        140 	.ds 2
      00057E                        141 _eeprom_read_byte_addr_10000_97:
      00057E                        142 	.ds 3
      000581                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000584                        146 	.ds 2
      000586                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000586                        148 	.ds 2
      000588                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000588                        150 	.ds 2
      00058A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058A                        152 	.ds 3
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058D                        154 	.ds 2
      00058F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058F                        156 	.ds 2
      000591                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000591                        158 	.ds 3
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000594                        160 	.ds 2
      000596                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000596                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003BAC                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003BAC E5 82            [12]  215 	mov	a,dpl
      003BAE 90 05 5C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003BB1 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003BB2 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003BB5 90 05 5C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003BB8 E0               [24]  221 	movx	a,@dptr
      003BB9 90 05 5B         [24]  222 	mov	dptr,#_first_failure_stage
      003BBC F0               [24]  223 	movx	@dptr,a
      003BBD                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003BBD D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003BBF 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003BC0                        239 _ak820_nvm_diagnostic:
      003BC0 12 38 43         [24]  240 	lcall	_ak820_outline_0103
      003BC3 90 05 5D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BC6 12 38 48         [24]  242 	lcall	_ak820_outline_0104
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003BC9 90 05 5D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BCC 12 38 00         [24]  245 	lcall	_ak820_outline_0050
      003BCF A2 09            [12]  246 	mov	c,_storage_failed
      003BD1 E4               [12]  247 	clr	a
      003BD2 33               [12]  248 	rlc	a
      003BD3 12 43 84         [24]  249 	lcall	_ak820_outline_0116
      003BD6 12 43 5F         [24]  250 	lcall	_ak820_outline_0060
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003BD9 A3               [24]  252 	inc	dptr
      003BDA A2 07            [12]  253 	mov	c,_page_valid
      003BDC E4               [12]  254 	clr	a
      003BDD 33               [12]  255 	rlc	a
      003BDE 12 43 33         [24]  256 	lcall	_ak820_outline_0029
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003BE1 A2 08            [12]  258 	mov	c,_page_dirty
      003BE3 E4               [12]  259 	clr	a
      003BE4 33               [12]  260 	rlc	a
      003BE5 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003BE6 74 03            [12]  263 	mov	a,#0x03
      003BE8 12 43 AF         [24]  264 	lcall	_ak820_outline_0156
      003BEB 90 05 5A         [24]  265 	mov	dptr,#_batch_depth
      003BEE E0               [24]  266 	movx	a,@dptr
      003BEF 12 38 60         [24]  267 	lcall	_ak820_outline_0121
      003BF2 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003BF3 74 04            [12]  270 	mov	a,#0x04
      003BF5 12 43 AF         [24]  271 	lcall	_ak820_outline_0156
      003BF8 90 05 59         [24]  272 	mov	dptr,#_cached_page
      003BFB E0               [24]  273 	movx	a,@dptr
      003BFC 12 38 60         [24]  274 	lcall	_ak820_outline_0121
      003BFF F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003C00 12 43 29         [24]  277 	lcall	_ak820_outline_0009
      003C03 E4               [12]  278 	clr	a
      003C04 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003C05 74 06            [12]  281 	mov	a,#0x06
      003C07 12 43 94         [24]  282 	lcall	_ak820_outline_0134
      003C0A 90 05 5B         [24]  283 	mov	dptr,#_first_failure_stage
      003C0D E0               [24]  284 	movx	a,@dptr
      003C0E 12 43 84         [24]  285 	lcall	_ak820_outline_0116
      003C11 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003C12 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003C13                        300 _crc_byte:
      003C13 12 38 43         [24]  301 	lcall	_ak820_outline_0103
      003C16 90 05 60         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003C19 12 38 48         [24]  303 	lcall	_ak820_outline_0104
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003C1C 90 05 5F         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003C1F E0               [24]  306 	movx	a,@dptr
      003C20 FF               [12]  307 	mov	r7,a
      003C21 7E 00            [12]  308 	mov	r6,#0x00
      003C23 90 05 60         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003C26 E0               [24]  310 	movx	a,@dptr
      003C27 6E               [12]  311 	xrl	a,r6
      003C28 F0               [24]  312 	movx	@dptr,a
      003C29 A3               [24]  313 	inc	dptr
      003C2A E0               [24]  314 	movx	a,@dptr
      003C2B 6F               [12]  315 	xrl	a,r7
      003C2C F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C2D 7F 00            [12]  318 	mov	r7,#0x00
      003C2F                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C2F 90 05 60         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003C32 12 43 6C         [24]  322 	lcall	_ak820_outline_0090
      003C35 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003C38 ED               [12]  324 	mov	a,r5
      003C39 2D               [12]  325 	add	a,r5
      003C3A FB               [12]  326 	mov	r3,a
      003C3B EE               [12]  327 	mov	a,r6
      003C3C 33               [12]  328 	rlc	a
      003C3D FC               [12]  329 	mov	r4,a
      003C3E 63 03 21         [24]  330 	xrl	ar3,#0x21
      003C41 63 04 10         [24]  331 	xrl	ar4,#0x10
      003C44 80 06            [24]  332 	sjmp	00107$
      003C46                        333 00106$:
      003C46 ED               [12]  334 	mov	a,r5
      003C47 2D               [12]  335 	add	a,r5
      003C48 FB               [12]  336 	mov	r3,a
      003C49 EE               [12]  337 	mov	a,r6
      003C4A 33               [12]  338 	rlc	a
      003C4B FC               [12]  339 	mov	r4,a
      003C4C                        340 00107$:
      003C4C 90 05 60         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003C4F 12 38 2B         [24]  342 	lcall	_ak820_outline_0076
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C52 0F               [12]  344 	inc	r7
      003C53 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C56 12 33 FC         [24]  347 	lcall	_ak820_outline_0122
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C59 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003C5A                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C5A 90 05 62         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003C5D 74 FF            [12]  363 	mov	a,#0xff
      003C5F F0               [24]  364 	movx	@dptr,a
      003C60 A3               [24]  365 	inc	dptr
      003C61 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C62 7F 00            [12]  368 	mov	r7,#0x00
      003C64                        369 00102$:
      003C64 90 05 62         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003C67 12 43 6C         [24]  371 	lcall	_ak820_outline_0090
      003C6A 12 43 78         [24]  372 	lcall	_ak820_outline_0101
      003C6D 90 05 5F         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003C70 F0               [24]  374 	movx	@dptr,a
      003C71 12 38 6A         [24]  375 	lcall	_ak820_outline_0132
      003C74 C0 07            [24]  376 	push	ar7
      003C76 12 3C 13         [24]  377 	lcall	_crc_byte
      003C79 AD 82            [24]  378 	mov	r5, dpl
      003C7B AE 83            [24]  379 	mov	r6, dph
      003C7D D0 07            [24]  380 	pop	ar7
      003C7F 90 05 62         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003C82 12 43 B5         [24]  382 	lcall	_ak820_outline_0157
      003C85 0F               [12]  383 	inc	r7
      003C86 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C89 12 38 6A         [24]  386 	lcall	_ak820_outline_0132
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C8C 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003C8D                        399 _write_page:
      003C8D 12 38 43         [24]  400 	lcall	_ak820_outline_0103
      003C90 90 05 64         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003C93 12 38 48         [24]  402 	lcall	_ak820_outline_0104
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C96 90 05 64         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003C99 12 37 A0         [24]  405 	lcall	_ak820_outline_0004
      003C9C C0 07            [24]  406 	push	ar7
      003C9E C0 06            [24]  407 	push	ar6
      003CA0 12 39 C6         [24]  408 	lcall	_ak820_flash_erase
      003CA3 E5 82            [12]  409 	mov	a, dpl
      003CA5 D0 06            [24]  410 	pop	ar6
      003CA7 D0 07            [24]  411 	pop	ar7
      003CA9 70 03            [24]  412 	jnz	00102$
      003CAB F5 82            [12]  413 	mov	dpl,a
      003CAD 22               [24]  414 	ret
      003CAE                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003CAE 90 04 F5         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003CB1 74 19            [12]  418 	mov	a,#_page_data
      003CB3 F0               [24]  419 	movx	@dptr,a
      003CB4 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003CB6 A3               [24]  421 	inc	dptr
      003CB7 12 43 5F         [24]  422 	lcall	_ak820_outline_0060
      003CBA 12 3A DA         [24]  423 	lcall	_ak820_flash_program_page
      003CBD E5 82            [12]  424 	mov	a, dpl
      003CBF 70 03            [24]  425 	jnz	00120$
      003CC1 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CC3 22               [24]  428 	ret
      003CC4                        429 00120$:
      003CC4 7F 00            [12]  430 	mov	r7,#0x00
      003CC6                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003CC6 8F 05            [24]  433 	mov	ar5,r7
      003CC8 7E 00            [12]  434 	mov	r6,#0x00
      003CCA 90 05 64         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003CCD 12 38 5A         [24]  436 	lcall	_ak820_outline_0120
      003CD0 ED               [12]  437 	mov	a,r5
      003CD1 2B               [12]  438 	add	a, r3
      003CD2 FB               [12]  439 	mov	r3,a
      003CD3 EE               [12]  440 	mov	a,r6
      003CD4 3C               [12]  441 	addc	a, r4
      003CD5 FC               [12]  442 	mov	r4,a
      003CD6 12 33 FC         [24]  443 	lcall	_ak820_outline_0122
      003CD9 12 38 B9         [24]  444 	lcall	_ak820_flash_read
      003CDC AE 82            [24]  445 	mov	r6, dpl
      003CDE 12 43 78         [24]  446 	lcall	_ak820_outline_0101
      003CE1 FD               [12]  447 	mov	r5,a
      003CE2 EE               [12]  448 	mov	a,r6
      003CE3 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003CE6 80 04            [24]  450 	sjmp	00109$
      003CE8                        451 00149$:
      003CE8 75 82 00         [24]  452 	mov	dpl, #0x00
      003CEB 22               [24]  453 	ret
      003CEC                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CEC 0F               [12]  456 	inc	r7
      003CED BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003CF0 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003CF3 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003CF4                        472 _journal_header_valid:
      003CF4 12 38 43         [24]  473 	lcall	_ak820_outline_0103
      003CF7 90 05 66         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003CFA 12 38 48         [24]  475 	lcall	_ak820_outline_0104
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003CFD 90 05 66         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003D00 12 37 A0         [24]  478 	lcall	_ak820_outline_0004
      003D03 E0               [24]  479 	movx	a,@dptr
      003D04 FD               [12]  480 	mov	r5,a
      003D05 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003D08 80 04            [24]  482 	sjmp	00116$
      003D0A                        483 00138$:
      003D0A 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D0D 22               [24]  486 	ret
      003D0E                        487 00116$:
      003D0E 7D 01            [12]  488 	mov	r5,#0x01
      003D10                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003D10 ED               [12]  491 	mov	a,r5
      003D11 12 37 E7         [24]  492 	lcall	_ak820_outline_0016
      003D14 FC               [12]  493 	mov	r4,a
      003D15 8D 02            [24]  494 	mov	ar2,r5
      003D17 7B 00            [12]  495 	mov	r3,#0x00
      003D19 74 04            [12]  496 	mov	a,#0x04
      003D1B 2A               [12]  497 	add	a, r2
      003D1C FA               [12]  498 	mov	r2,a
      003D1D E4               [12]  499 	clr	a
      003D1E 3B               [12]  500 	addc	a, r3
      003D1F FB               [12]  501 	mov	r3,a
      003D20 EA               [12]  502 	mov	a,r2
      003D21 2E               [12]  503 	add	a, r6
      003D22 F5 82            [12]  504 	mov	dpl,a
      003D24 EB               [12]  505 	mov	a,r3
      003D25 3F               [12]  506 	addc	a, r7
      003D26 F5 83            [12]  507 	mov	dph,a
      003D28 E0               [24]  508 	movx	a,@dptr
      003D29 62 04            [12]  509 	xrl	ar4,a
      003D2B BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      003D2E 80 04            [24]  511 	sjmp	00107$
      003D30                        512 00139$:
      003D30 75 82 00         [24]  513 	mov	dpl, #0x00
      003D33 22               [24]  514 	ret
      003D34                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D34 0D               [12]  517 	inc	r5
      003D35 BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D38 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D3B 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      003D3C                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D3C 7F 00            [12]  537 	mov	r7,#0x00
      003D3E                        538 00115$:
      003D3E EF               [12]  539 	mov	a,r7
      003D3F 24 68            [12]  540 	add	a, #_recover_journal_header_10000_46
      003D41 FD               [12]  541 	mov	r5,a
      003D42 E4               [12]  542 	clr	a
      003D43 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D45 FE               [12]  544 	mov	r6,a
      003D46 8F 04            [24]  545 	mov	ar4,r7
      003D48 7B 00            [12]  546 	mov	r3,#0x00
      003D4A 74 40            [12]  547 	mov	a,#0x40
      003D4C 2C               [12]  548 	add	a, r4
      003D4D FC               [12]  549 	mov	r4,a
      003D4E 74 EF            [12]  550 	mov	a,#0xef
      003D50 3B               [12]  551 	addc	a, r3
      003D51 FB               [12]  552 	mov	r3,a
      003D52 12 43 C0         [24]  553 	lcall	_ak820_outline_0180
      003D55 12 38 B9         [24]  554 	lcall	_ak820_flash_read
      003D58 AC 82            [24]  555 	mov	r4, dpl
      003D5A 12 43 65         [24]  556 	lcall	_ak820_outline_0064
      003D5D 0F               [12]  557 	inc	r7
      003D5E BF 09 DD         [24]  558 	cjne	r7,#0x09,00115$
                                    559 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D61 90 05 68         [24]  560 	mov	dptr,#_recover_journal_header_10000_46
      003D64 12 3C F4         [24]  561 	lcall	_journal_header_valid
      003D67 E5 82            [12]  562 	mov	a, dpl
      003D69 70 01            [24]  563 	jnz	00103$
      003D6B 22               [24]  564 	ret
      003D6C                        565 00103$:
                                    566 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D6C 90 05 69         [24]  567 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D6F E0               [24]  568 	movx	a,@dptr
      003D70 FF               [12]  569 	mov	r7,a
      003D71 7E 00            [12]  570 	mov	r6,#0x00
      003D73 90 05 6A         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D76 E0               [24]  572 	movx	a,@dptr
      003D77 FC               [12]  573 	mov	r4,a
      003D78 E4               [12]  574 	clr	a
      003D79 42 07            [12]  575 	orl	ar7,a
      003D7B EC               [12]  576 	mov	a,r4
      003D7C 42 06            [12]  577 	orl	ar6,a
                                    578 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D7E 90 05 6B         [24]  579 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D81 E0               [24]  580 	movx	a,@dptr
      003D82 FD               [12]  581 	mov	r5,a
      003D83 7C 00            [12]  582 	mov	r4,#0x00
      003D85 90 05 6C         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D88 E0               [24]  584 	movx	a,@dptr
      003D89 FA               [12]  585 	mov	r2,a
      003D8A E4               [12]  586 	clr	a
      003D8B 12 43 9A         [24]  587 	lcall	_ak820_outline_0139
                                    588 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D8E C3               [12]  589 	clr	c
      003D8F EF               [12]  590 	mov	a,r7
      003D90 94 A0            [12]  591 	subb	a,#0xa0
      003D92 EE               [12]  592 	mov	a,r6
      003D93 94 00            [12]  593 	subb	a,#0x00
      003D95 40 06            [24]  594 	jc	00134$
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D97 75 82 01         [24]  596 	mov	dpl, #0x01
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D9A 02 3B AC         [24]  598 	ljmp	_nvm_fail
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D9D                        600 00134$:
      003D9D 7B 00            [12]  601 	mov	r3,#0x00
      003D9F                        602 00117$:
      003D9F C0 05            [24]  603 	push	ar5
      003DA1 C0 04            [24]  604 	push	ar4
      003DA3 EB               [12]  605 	mov	a,r3
      003DA4 24 19            [12]  606 	add	a, #_page_data
      003DA6 F9               [12]  607 	mov	r1,a
      003DA7 E4               [12]  608 	clr	a
      003DA8 34 05            [12]  609 	addc	a, #(_page_data >> 8)
      003DAA FA               [12]  610 	mov	r2,a
      003DAB 8B 00            [24]  611 	mov	ar0,r3
      003DAD 7D 00            [12]  612 	mov	r5,#0x00
      003DAF 74 EF            [12]  613 	mov	a,#0xef
      003DB1 2D               [12]  614 	add	a, r5
      003DB2 FD               [12]  615 	mov	r5,a
      003DB3 88 82            [24]  616 	mov	dpl, r0
      003DB5 8D 83            [24]  617 	mov	dph, r5
      003DB7 12 38 B9         [24]  618 	lcall	_ak820_flash_read
      003DBA AD 82            [24]  619 	mov	r5, dpl
      003DBC 12 43 BB         [24]  620 	lcall	_ak820_outline_0179
      003DBF ED               [12]  621 	mov	a,r5
      003DC0 F0               [24]  622 	movx	@dptr,a
      003DC1 0B               [12]  623 	inc	r3
      003DC2 BB 40 02         [24]  624 	cjne	r3,#0x40,00190$
      003DC5 80 06            [24]  625 	sjmp	00191$
      003DC7                        626 00190$:
      003DC7 D0 04            [24]  627 	pop	ar4
      003DC9 D0 05            [24]  628 	pop	ar5
      003DCB 80 D2            [24]  629 	sjmp	00117$
      003DCD                        630 00191$:
      003DCD D0 04            [24]  631 	pop	ar4
      003DCF D0 05            [24]  632 	pop	ar5
                                    633 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003DD1 C0 07            [24]  634 	push	ar7
      003DD3 C0 06            [24]  635 	push	ar6
      003DD5 C0 05            [24]  636 	push	ar5
      003DD7 C0 04            [24]  637 	push	ar4
      003DD9 12 3C 5A         [24]  638 	lcall	_page_crc
      003DDC AA 82            [24]  639 	mov	r2, dpl
      003DDE AB 83            [24]  640 	mov	r3, dph
      003DE0 D0 04            [24]  641 	pop	ar4
      003DE2 D0 05            [24]  642 	pop	ar5
      003DE4 D0 06            [24]  643 	pop	ar6
      003DE6 D0 07            [24]  644 	pop	ar7
      003DE8 EA               [12]  645 	mov	a,r2
      003DE9 B5 05 06         [24]  646 	cjne	a,ar5,00192$
      003DEC EB               [12]  647 	mov	a,r3
      003DED B5 04 02         [24]  648 	cjne	a,ar4,00192$
      003DF0 80 06            [24]  649 	sjmp	00113$
      003DF2                        650 00192$:
      003DF2 75 82 02         [24]  651 	mov	dpl, #0x02
      003DF5 02 3B AC         [24]  652 	ljmp	_nvm_fail
      003DF8                        653 00113$:
                                    654 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003DF8 EE               [12]  655 	mov	a,r6
      003DF9 54 03            [12]  656 	anl	a,#0x03
      003DFB A2 E0            [12]  657 	mov	c,acc.0
      003DFD CF               [12]  658 	xch	a,r7
      003DFE 13               [12]  659 	rrc	a
      003DFF CF               [12]  660 	xch	a,r7
      003E00 13               [12]  661 	rrc	a
      003E01 A2 E0            [12]  662 	mov	c,acc.0
      003E03 CF               [12]  663 	xch	a,r7
      003E04 13               [12]  664 	rrc	a
      003E05 CF               [12]  665 	xch	a,r7
      003E06 13               [12]  666 	rrc	a
      003E07 CF               [12]  667 	xch	a,r7
      003E08 24 C7            [12]  668 	add	a,#0xc7
      003E0A FE               [12]  669 	mov	r6,a
      003E0B 12 43 AA         [24]  670 	lcall	_ak820_outline_0153
      003E0E 12 3C 8D         [24]  671 	lcall	_write_page
      003E11 E5 82            [12]  672 	mov	a, dpl
      003E13 70 06            [24]  673 	jnz	00110$
      003E15 75 82 03         [24]  674 	mov	dpl, #0x03
      003E18 02 3B AC         [24]  675 	ljmp	_nvm_fail
      003E1B                        676 00110$:
                                    677 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003E1B 90 EF 40         [24]  678 	mov	dptr,#0xef40
      003E1E 12 39 C6         [24]  679 	lcall	_ak820_flash_erase
      003E21 E5 82            [12]  680 	mov	a, dpl
      003E23 70 06            [24]  681 	jnz	00119$
      003E25 75 82 04         [24]  682 	mov	dpl, #0x04
                                    683 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003E28 02 3B AC         [24]  684 	ljmp	_nvm_fail
      003E2B                        685 00119$:
      003E2B 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    689 ;------------------------------------------------------------
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    691 ;	-----------------------------------------
                                    692 ;	 function eeprom_driver_init
                                    693 ;	-----------------------------------------
      003E2C                        694 _eeprom_driver_init:
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    696 ;	assignBit
      003E2C C2 09            [12]  697 	clr	_storage_failed
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E2E 90 05 5B         [24]  699 	mov	dptr,#_first_failure_stage
      003E31 E4               [12]  700 	clr	a
      003E32 F0               [24]  701 	movx	@dptr,a
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    703 ;	assignBit
      003E33 C2 08            [12]  704 	clr	_page_dirty
                                    705 ;	assignBit
      003E35 C2 07            [12]  706 	clr	_page_valid
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E37 90 05 5A         [24]  708 	mov	dptr,#_batch_depth
      003E3A E4               [12]  709 	clr	a
      003E3B F0               [24]  710 	movx	@dptr,a
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E3C 12 3D 3C         [24]  712 	lcall	_recover_journal
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E3F 02 2A 6B         [24]  715 	ljmp	_ak820_macro_init
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_nvm_ok
                                    722 ;	-----------------------------------------
      003E42                        723 _ak820_nvm_ok:
      003E42 A2 09            [12]  724 	mov	c,_storage_failed
      003E44 B3               [12]  725 	cpl	c
      003E45 92 0A            [24]  726 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E47 12 38 86         [24]  727 	lcall	_ak820_outline_0166
      003E4A 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    731 ;------------------------------------------------------------
                                    732 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    733 ;	-----------------------------------------
                                    734 ;	 function ak820_nvm_schema_fault
                                    735 ;	-----------------------------------------
      003E4B                        736 _ak820_nvm_schema_fault:
      003E4B 75 82 10         [24]  737 	mov	dpl, #0x10
      003E4E 02 3B AC         [24]  738 	ljmp	_nvm_fail
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    741 ;------------------------------------------------------------
                                    742 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    743 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    744 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    745 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_flush
                                    750 ;	-----------------------------------------
      003E51                        751 _ak820_nvm_flush:
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E51 30 08 03         [24]  753 	jnb	_page_dirty,00101$
      003E54 30 09 01         [24]  754 	jnb	_storage_failed,00102$
      003E57                        755 00101$:
      003E57 22               [24]  756 	ret
      003E58                        757 00102$:
                                    758 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E58 12 3C 5A         [24]  759 	lcall	_page_crc
      003E5B 12 43 8F         [24]  760 	lcall	_ak820_outline_0131
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E5E 90 05 71         [24]  762 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E61 74 A5            [12]  763 	mov	a,#0xa5
      003E63 F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E64 90 05 59         [24]  766 	mov	dptr,#_cached_page
      003E67 E0               [24]  767 	movx	a,@dptr
      003E68 90 05 72         [24]  768 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E6B F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E6C 90 05 73         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E6F E4               [12]  772 	clr	a
      003E70 F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E71 8E 05            [24]  775 	mov	ar5,r6
      003E73 90 05 74         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E76 ED               [12]  777 	mov	a,r5
      003E77 F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E78 8F 06            [24]  780 	mov	ar6,r7
      003E7A 90 05 75         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E7D EE               [12]  782 	mov	a,r6
      003E7E F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E7F 7F 01            [12]  785 	mov	r7,#0x01
      003E81                        786 00128$:
      003E81 8F 06            [24]  787 	mov	ar6,r7
      003E83 EE               [12]  788 	mov	a,r6
      003E84 24 04            [12]  789 	add	a,#0x04
      003E86 FE               [12]  790 	mov	r6,a
      003E87 33               [12]  791 	rlc	a
      003E88 95 E0            [12]  792 	subb	a,acc
      003E8A FD               [12]  793 	mov	r5,a
      003E8B EE               [12]  794 	mov	a,r6
      003E8C 24 71            [12]  795 	add	a, #_ak820_nvm_flush_header_10000_62
      003E8E FE               [12]  796 	mov	r6,a
      003E8F ED               [12]  797 	mov	a,r5
      003E90 34 05            [12]  798 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E92 FD               [12]  799 	mov	r5,a
      003E93 12 43 42         [24]  800 	lcall	_ak820_outline_0039
      003E96 FC               [12]  801 	mov	r4,a
      003E97 63 04 FF         [24]  802 	xrl	ar4,#0xff
      003E9A 8E 82            [24]  803 	mov	dpl,r6
      003E9C 8D 83            [24]  804 	mov	dph,r5
      003E9E EC               [12]  805 	mov	a,r4
      003E9F F0               [24]  806 	movx	@dptr,a
      003EA0 0F               [12]  807 	inc	r7
      003EA1 BF 05 DD         [24]  808 	cjne	r7,#0x05,00128$
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003EA4 90 05 7A         [24]  810 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EA7 74 05            [12]  811 	mov	a,#0x05
      003EA9 F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003EAA 90 EF 40         [24]  814 	mov	dptr,#0xef40
      003EAD 12 39 C6         [24]  815 	lcall	_ak820_flash_erase
      003EB0 E5 82            [12]  816 	mov	a, dpl
      003EB2 70 03            [24]  817 	jnz	00269$
      003EB4 02 3F 9B         [24]  818 	ljmp	00127$
      003EB7                        819 00269$:
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003EB7 90 05 7A         [24]  821 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EBA 74 06            [12]  822 	mov	a,#0x06
      003EBC F0               [24]  823 	movx	@dptr,a
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EBD 7F 00            [12]  825 	mov	r7,#0x00
      003EBF                        826 00130$:
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003EBF 12 43 4E         [24]  828 	lcall	_ak820_outline_0051
      003EC2 12 38 B9         [24]  829 	lcall	_ak820_flash_read
      003EC5 E5 82            [12]  830 	mov	a, dpl
      003EC7 60 03            [24]  831 	jz	00270$
      003EC9 02 3F 9B         [24]  832 	ljmp	00127$
      003ECC                        833 00270$:
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003ECC 0F               [12]  835 	inc	r7
      003ECD BF 40 EF         [24]  836 	cjne	r7,#0x40,00130$
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003ED0 90 05 7A         [24]  838 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003ED3 74 07            [12]  839 	mov	a,#0x07
      003ED5 F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003ED6 90 EF 00         [24]  842 	mov	dptr,#0xef00
      003ED9 12 3C 8D         [24]  843 	lcall	_write_page
      003EDC E5 82            [12]  844 	mov	a, dpl
      003EDE 70 03            [24]  845 	jnz	00273$
      003EE0 02 3F 9B         [24]  846 	ljmp	00127$
      003EE3                        847 00273$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003EE3 90 05 7A         [24]  849 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EE6 74 08            [12]  850 	mov	a,#0x08
      003EE8 F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EE9 7F 01            [12]  853 	mov	r7,#0x01
      003EEB                        854 00132$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003EEB 12 43 42         [24]  856 	lcall	_ak820_outline_0039
      003EEE FE               [12]  857 	mov	r6,a
      003EEF 60 23            [24]  858 	jz	00133$
      003EF1 8F 05            [24]  859 	mov	ar5,r7
      003EF3 7C 00            [12]  860 	mov	r4,#0x00
      003EF5 74 40            [12]  861 	mov	a,#0x40
      003EF7 2D               [12]  862 	add	a, r5
      003EF8 FD               [12]  863 	mov	r5,a
      003EF9 74 EF            [12]  864 	mov	a,#0xef
      003EFB 3C               [12]  865 	addc	a, r4
      003EFC FC               [12]  866 	mov	r4,a
      003EFD 90 04 F2         [24]  867 	mov	dptr,#_ak820_flash_program_PARM_2
      003F00 EE               [12]  868 	mov	a,r6
      003F01 F0               [24]  869 	movx	@dptr,a
      003F02 8D 82            [24]  870 	mov	dpl, r5
      003F04 8C 83            [24]  871 	mov	dph, r4
      003F06 C0 07            [24]  872 	push	ar7
      003F08 12 3A 26         [24]  873 	lcall	_ak820_flash_program
      003F0B E5 82            [12]  874 	mov	a, dpl
      003F0D D0 07            [24]  875 	pop	ar7
      003F0F 70 03            [24]  876 	jnz	00275$
      003F11 02 3F 9B         [24]  877 	ljmp	00127$
      003F14                        878 00275$:
      003F14                        879 00133$:
                                    880 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003F14 0F               [12]  881 	inc	r7
      003F15 BF 09 D3         [24]  882 	cjne	r7,#0x09,00132$
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003F18 90 05 7A         [24]  884 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F1B 74 09            [12]  885 	mov	a,#0x09
      003F1D F0               [24]  886 	movx	@dptr,a
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F1E 7F 01            [12]  888 	mov	r7,#0x01
      003F20                        889 00134$:
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003F20 12 43 4E         [24]  891 	lcall	_ak820_outline_0051
      003F23 12 38 B9         [24]  892 	lcall	_ak820_flash_read
      003F26 AE 82            [24]  893 	mov	r6, dpl
      003F28 12 43 42         [24]  894 	lcall	_ak820_outline_0039
      003F2B FD               [12]  895 	mov	r5,a
      003F2C EE               [12]  896 	mov	a,r6
      003F2D B5 05 6B         [24]  897 	cjne	a,ar5,00127$
                                    898 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F30 0F               [12]  899 	inc	r7
      003F31 BF 09 EC         [24]  900 	cjne	r7,#0x09,00134$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F34 90 05 7A         [24]  902 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F37 74 0A            [12]  903 	mov	a,#0x0a
      003F39 F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F3A 90 05 71         [24]  906 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F3D E0               [24]  907 	movx	a,@dptr
      003F3E 90 04 F2         [24]  908 	mov	dptr,#_ak820_flash_program_PARM_2
      003F41 F0               [24]  909 	movx	@dptr,a
      003F42 90 EF 40         [24]  910 	mov	dptr,#0xef40
      003F45 12 3A 26         [24]  911 	lcall	_ak820_flash_program
      003F48 E5 82            [12]  912 	mov	a, dpl
      003F4A 60 4F            [24]  913 	jz	00127$
                                    914 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F4C 90 05 7A         [24]  915 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F4F 74 0B            [12]  916 	mov	a,#0x0b
      003F51 F0               [24]  917 	movx	@dptr,a
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F52 90 EF 40         [24]  919 	mov	dptr,#0xef40
      003F55 12 38 B9         [24]  920 	lcall	_ak820_flash_read
      003F58 AF 82            [24]  921 	mov	r7, dpl
      003F5A 90 05 71         [24]  922 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F5D E0               [24]  923 	movx	a,@dptr
      003F5E FE               [12]  924 	mov	r6,a
      003F5F EF               [12]  925 	mov	a,r7
      003F60 B5 06 38         [24]  926 	cjne	a,ar6,00127$
                                    927 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F63 90 05 7A         [24]  928 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F66 74 0C            [12]  929 	mov	a,#0x0c
      003F68 F0               [24]  930 	movx	@dptr,a
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F69 90 05 59         [24]  932 	mov	dptr,#_cached_page
      003F6C E0               [24]  933 	movx	a,@dptr
      003F6D FE               [12]  934 	mov	r6,a
      003F6E E4               [12]  935 	clr	a
      003F6F C3               [12]  936 	clr	c
      003F70 CE               [12]  937 	xch	a,r6
      003F71 13               [12]  938 	rrc	a
      003F72 CE               [12]  939 	xch	a,r6
      003F73 13               [12]  940 	rrc	a
      003F74 A2 E0            [12]  941 	mov	c,acc.0
      003F76 CE               [12]  942 	xch	a,r6
      003F77 13               [12]  943 	rrc	a
      003F78 CE               [12]  944 	xch	a,r6
      003F79 13               [12]  945 	rrc	a
      003F7A CE               [12]  946 	xch	a,r6
      003F7B 24 C7            [12]  947 	add	a,#0xc7
      003F7D FF               [12]  948 	mov	r7,a
      003F7E 12 43 84         [24]  949 	lcall	_ak820_outline_0116
      003F81 12 3C 8D         [24]  950 	lcall	_write_page
      003F84 E5 82            [12]  951 	mov	a, dpl
      003F86 60 13            [24]  952 	jz	00127$
                                    953 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F88 90 05 7A         [24]  954 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F8B 74 0D            [12]  955 	mov	a,#0x0d
      003F8D F0               [24]  956 	movx	@dptr,a
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F8E 90 EF 40         [24]  958 	mov	dptr,#0xef40
      003F91 12 39 C6         [24]  959 	lcall	_ak820_flash_erase
      003F94 E5 82            [12]  960 	mov	a, dpl
      003F96 60 03            [24]  961 	jz	00127$
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    963 ;	assignBit
      003F98 C2 08            [12]  964 	clr	_page_dirty
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F9A 22               [24]  967 	ret
      003F9B                        968 00127$:
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F9B 90 05 7A         [24]  970 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F9E E0               [24]  971 	movx	a,@dptr
      003F9F F5 82            [12]  972 	mov	dpl,a
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003FA1 02 3B AC         [24]  974 	ljmp	_nvm_fail
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    977 ;------------------------------------------------------------
                                    978 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function ak820_nvm_begin
                                    981 ;	-----------------------------------------
      003FA4                        982 _ak820_nvm_begin:
                                    983 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003FA4 90 05 5A         [24]  984 	mov	dptr,#_batch_depth
      003FA7 E0               [24]  985 	movx	a,@dptr
      003FA8 FF               [12]  986 	mov	r7,a
      003FA9 BF FF 06         [24]  987 	cjne	r7,#0xff,00102$
      003FAC 75 82 0F         [24]  988 	mov	dpl, #0x0f
      003FAF 02 3B AC         [24]  989 	ljmp	_nvm_fail
      003FB2                        990 00102$:
                                    991 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003FB2 90 05 5A         [24]  992 	mov	dptr,#_batch_depth
      003FB5 EF               [12]  993 	mov	a,r7
      003FB6 04               [12]  994 	inc	a
      003FB7 F0               [24]  995 	movx	@dptr,a
                                    996 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003FB8 22               [24]  997 	ret
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function ak820_nvm_end
                                   1004 ;	-----------------------------------------
      003FB9                       1005 _ak820_nvm_end:
                                   1006 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003FB9 90 05 5A         [24] 1007 	mov	dptr,#_batch_depth
      003FBC E0               [24] 1008 	movx	a,@dptr
      003FBD FF               [12] 1009 	mov	r7,a
      003FBE E0               [24] 1010 	movx	a,@dptr
      003FBF 60 06            [24] 1011 	jz	00102$
      003FC1 EF               [12] 1012 	mov	a,r7
      003FC2 14               [12] 1013 	dec	a
      003FC3 90 05 5A         [24] 1014 	mov	dptr,#_batch_depth
      003FC6 F0               [24] 1015 	movx	@dptr,a
      003FC7                       1016 00102$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003FC7 90 05 5A         [24] 1018 	mov	dptr,#_batch_depth
      003FCA E0               [24] 1019 	movx	a,@dptr
      003FCB 70 03            [24] 1020 	jnz	00105$
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003FCD 02 3E 51         [24] 1022 	ljmp	_ak820_nvm_flush
      003FD0                       1023 00105$:
      003FD0 22               [24] 1024 	ret
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'load_page'
                                   1027 ;------------------------------------------------------------
                                   1028 ;page          Allocated with name '_load_page_page_10000_87'
                                   1029 ;i             Allocated with name '_load_page_i_10000_88'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function load_page
                                   1034 ;	-----------------------------------------
      003FD1                       1035 _load_page:
      003FD1 E5 82            [12] 1036 	mov	a,dpl
      003FD3 90 05 7B         [24] 1037 	mov	dptr,#_load_page_page_10000_87
      003FD6 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003FD7 30 07 17         [24] 1040 	jnb	_page_valid,00102$
      003FDA 90 05 59         [24] 1041 	mov	dptr,#_cached_page
      003FDD E0               [24] 1042 	movx	a,@dptr
      003FDE FF               [12] 1043 	mov	r7,a
      003FDF 90 05 7B         [24] 1044 	mov	dptr,#_load_page_page_10000_87
      003FE2 E0               [24] 1045 	movx	a,@dptr
      003FE3 FE               [12] 1046 	mov	r6,a
      003FE4 EF               [12] 1047 	mov	a,r7
      003FE5 B5 06 09         [24] 1048 	cjne	a,ar6,00102$
      003FE8 A2 09            [12] 1049 	mov	c,_storage_failed
      003FEA B3               [12] 1050 	cpl	c
      003FEB 92 0B            [24] 1051 	mov  _load_page_sloc0_1_0,c
      003FED 12 38 86         [24] 1052 	lcall	_ak820_outline_0166
      003FF0 22               [24] 1053 	ret
      003FF1                       1054 00102$:
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003FF1 12 3E 51         [24] 1056 	lcall	_ak820_nvm_flush
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003FF4 30 09 04         [24] 1058 	jnb	_storage_failed,00119$
      003FF7 75 82 00         [24] 1059 	mov	dpl, #0x00
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FFA 22               [24] 1061 	ret
      003FFB                       1062 00119$:
      003FFB 7F 00            [12] 1063 	mov	r7,#0x00
      003FFD                       1064 00107$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003FFD EF               [12] 1066 	mov	a,r7
      003FFE 24 19            [12] 1067 	add	a, #_page_data
      004000 FD               [12] 1068 	mov	r5,a
      004001 E4               [12] 1069 	clr	a
      004002 34 05            [12] 1070 	addc	a, #(_page_data >> 8)
      004004 FE               [12] 1071 	mov	r6,a
      004005 90 05 7B         [24] 1072 	mov	dptr,#_load_page_page_10000_87
      004008 E0               [24] 1073 	movx	a,@dptr
      004009 FC               [12] 1074 	mov	r4,a
      00400A FA               [12] 1075 	mov	r2,a
      00400B E4               [12] 1076 	clr	a
      00400C C3               [12] 1077 	clr	c
      00400D CA               [12] 1078 	xch	a,r2
      00400E 13               [12] 1079 	rrc	a
      00400F CA               [12] 1080 	xch	a,r2
      004010 13               [12] 1081 	rrc	a
      004011 A2 E0            [12] 1082 	mov	c,acc.0
      004013 CA               [12] 1083 	xch	a,r2
      004014 13               [12] 1084 	rrc	a
      004015 CA               [12] 1085 	xch	a,r2
      004016 13               [12] 1086 	rrc	a
      004017 CA               [12] 1087 	xch	a,r2
      004018 24 C7            [12] 1088 	add	a,#0xc7
      00401A FB               [12] 1089 	mov	r3,a
      00401B 8F 01            [24] 1090 	mov	ar1,r7
      00401D 89 00            [24] 1091 	mov	ar0,r1
      00401F 79 00            [12] 1092 	mov	r1,#0x00
      004021 E8               [12] 1093 	mov	a,r0
      004022 2A               [12] 1094 	add	a, r2
      004023 FA               [12] 1095 	mov	r2,a
      004024 E9               [12] 1096 	mov	a,r1
      004025 3B               [12] 1097 	addc	a, r3
      004026 FB               [12] 1098 	mov	r3,a
      004027 12 43 A0         [24] 1099 	lcall	_ak820_outline_0140
      00402A 12 38 B9         [24] 1100 	lcall	_ak820_flash_read
      00402D AB 82            [24] 1101 	mov	r3, dpl
      00402F 12 38 6A         [24] 1102 	lcall	_ak820_outline_0132
      004032 EB               [12] 1103 	mov	a,r3
      004033 F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004034 0F               [12] 1106 	inc	r7
      004035 BF 40 C5         [24] 1107 	cjne	r7,#0x40,00107$
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004038 90 05 59         [24] 1109 	mov	dptr,#_cached_page
      00403B EC               [12] 1110 	mov	a,r4
      00403C F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1113 ;	assignBit
      00403D D2 07            [12] 1114 	setb	_page_valid
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      00403F 75 82 01         [24] 1116 	mov	dpl, #0x01
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004042 22               [24] 1118 	ret
                                   1119 ;------------------------------------------------------------
                                   1120 ;Allocation info for local variables in function 'read_offset'
                                   1121 ;------------------------------------------------------------
                                   1122 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1123 ;------------------------------------------------------------
                                   1124 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1125 ;	-----------------------------------------
                                   1126 ;	 function read_offset
                                   1127 ;	-----------------------------------------
      004043                       1128 _read_offset:
      004043 12 38 43         [24] 1129 	lcall	_ak820_outline_0103
      004046 90 05 7C         [24] 1130 	mov	dptr,#_read_offset_offset_10000_93
      004049 12 38 48         [24] 1131 	lcall	_ak820_outline_0104
                                   1132 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      00404C 90 05 7C         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      00404F 12 38 00         [24] 1134 	lcall	_ak820_outline_0050
      004052 C3               [12] 1135 	clr	c
      004053 94 28            [12] 1136 	subb	a,#0x28
      004055 40 04            [24] 1137 	jc	00102$
      004057 75 82 00         [24] 1138 	mov	dpl, #0x00
      00405A 22               [24] 1139 	ret
      00405B                       1140 00102$:
                                   1141 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      00405B 30 07 34         [24] 1142 	jnb	_page_valid,00104$
      00405E 8E 04            [24] 1143 	mov	ar4,r6
      004060 EF               [12] 1144 	mov	a,r7
      004061 A2 E7            [12] 1145 	mov	c,acc.7
      004063 CC               [12] 1146 	xch	a,r4
      004064 33               [12] 1147 	rlc	a
      004065 CC               [12] 1148 	xch	a,r4
      004066 33               [12] 1149 	rlc	a
      004067 A2 E7            [12] 1150 	mov	c,acc.7
      004069 CC               [12] 1151 	xch	a,r4
      00406A 33               [12] 1152 	rlc	a
      00406B CC               [12] 1153 	xch	a,r4
      00406C 33               [12] 1154 	rlc	a
      00406D CC               [12] 1155 	xch	a,r4
      00406E 54 03            [12] 1156 	anl	a,#0x03
      004070 FD               [12] 1157 	mov	r5,a
      004071 90 05 59         [24] 1158 	mov	dptr,#_cached_page
      004074 E0               [24] 1159 	movx	a,@dptr
      004075 FA               [12] 1160 	mov	r2,a
      004076 7B 00            [12] 1161 	mov	r3,#0x00
      004078 EC               [12] 1162 	mov	a,r4
      004079 B5 02 16         [24] 1163 	cjne	a,ar2,00104$
      00407C ED               [12] 1164 	mov	a,r5
      00407D B5 03 12         [24] 1165 	cjne	a,ar3,00104$
                                   1166 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004080 74 3F            [12] 1167 	mov	a,#0x3f
      004082 5E               [12] 1168 	anl	a,r6
      004083 7D 00            [12] 1169 	mov	r5,#0x00
      004085 24 19            [12] 1170 	add	a, #_page_data
      004087 F5 82            [12] 1171 	mov	dpl,a
      004089 ED               [12] 1172 	mov	a,r5
      00408A 34 05            [12] 1173 	addc	a, #(_page_data >> 8)
      00408C F5 83            [12] 1174 	mov	dph,a
      00408E E0               [24] 1175 	movx	a,@dptr
      00408F F5 82            [12] 1176 	mov	dpl,a
      004091 22               [24] 1177 	ret
      004092                       1178 00104$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004092 74 C7            [12] 1180 	mov	a,#0xc7
      004094 2F               [12] 1181 	add	a, r7
      004095 FF               [12] 1182 	mov	r7,a
      004096 12 43 84         [24] 1183 	lcall	_ak820_outline_0116
                                   1184 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      004099 02 38 B9         [24] 1185 	ljmp	_ak820_flash_read
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1188 ;------------------------------------------------------------
                                   1189 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function eeprom_read_byte
                                   1194 ;	-----------------------------------------
      00409C                       1195 _eeprom_read_byte:
      00409C C0 07            [24] 1196 	push	ar7
      00409E C0 06            [24] 1197 	push	ar6
      0040A0 12 43 3B         [24] 1198 	lcall	_ak820_outline_0036
      0040A3 90 05 7E         [24] 1199 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040A6 12 37 DF         [24] 1200 	lcall	_ak820_outline_0015
                                   1201 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0040A9 90 05 7E         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040AC 12 37 A0         [24] 1203 	lcall	_ak820_outline_0004
      0040AF C0 06            [24] 1204 	push	ar6
      0040B1 C0 05            [24] 1205 	push	ar5
      0040B3 C0 04            [24] 1206 	push	ar4
      0040B5 C0 03            [24] 1207 	push	ar3
      0040B7 C0 02            [24] 1208 	push	ar2
      0040B9 C0 01            [24] 1209 	push	ar1
      0040BB C0 00            [24] 1210 	push	ar0
      0040BD 12 40 43         [24] 1211 	lcall	_read_offset
      0040C0 AF 82            [24] 1212 	mov	r7, dpl
      0040C2 D0 00            [24] 1213 	pop	ar0
      0040C4 D0 01            [24] 1214 	pop	ar1
      0040C6 D0 02            [24] 1215 	pop	ar2
      0040C8 D0 03            [24] 1216 	pop	ar3
      0040CA D0 04            [24] 1217 	pop	ar4
      0040CC D0 05            [24] 1218 	pop	ar5
      0040CE D0 06            [24] 1219 	pop	ar6
      0040D0 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0040D2 D0 06            [24] 1222 	pop	ar6
      0040D4 D0 07            [24] 1223 	pop	ar7
      0040D6 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1227 ;------------------------------------------------------------
                                   1228 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1229 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1230 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1231 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1232 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1233 ;------------------------------------------------------------
                                   1234 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1235 ;	-----------------------------------------
                                   1236 ;	 function ak820_eeprom_read_block_xdata
                                   1237 ;	-----------------------------------------
      0040D7                       1238 _ak820_eeprom_read_block_xdata:
      0040D7 12 38 43         [24] 1239 	lcall	_ak820_outline_0103
      0040DA 90 05 86         [24] 1240 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040DD 12 38 48         [24] 1241 	lcall	_ak820_outline_0104
                                   1242 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040E0 90 05 81         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0040E3 12 38 00         [24] 1244 	lcall	_ak820_outline_0050
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0040E6 90 05 86         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040E9 12 38 1F         [24] 1247 	lcall	_ak820_outline_0059
      0040EC 90 05 88         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040EF 12 38 25         [24] 1249 	lcall	_ak820_outline_0070
                                   1250 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0040F2 90 05 84         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0040F5 12 38 1F         [24] 1252 	lcall	_ak820_outline_0059
      0040F8                       1253 00103$:
      0040F8 8C 02            [24] 1254 	mov	ar2,r4
      0040FA 8D 03            [24] 1255 	mov	ar3,r5
      0040FC 1C               [12] 1256 	dec	r4
      0040FD BC FF 01         [24] 1257 	cjne	r4,#0xff,00130$
      004100 1D               [12] 1258 	dec	r5
      004101                       1259 00130$:
      004101 EA               [12] 1260 	mov	a,r2
      004102 4B               [12] 1261 	orl	a,r3
      004103 60 5D            [24] 1262 	jz	00106$
                                   1263 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      004105 8E 02            [24] 1264 	mov	ar2,r6
      004107 8F 03            [24] 1265 	mov	ar3,r7
      004109 74 D8            [12] 1266 	mov	a,#0x100 - 0x28
      00410B 2B               [12] 1267 	add	a,r3
      00410C 50 17            [24] 1268 	jnc	00102$
      00410E 90 05 88         [24] 1269 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004111 12 43 89         [24] 1270 	lcall	_ak820_outline_0119
      004114 12 43 A0         [24] 1271 	lcall	_ak820_outline_0140
      004117 E4               [12] 1272 	clr	a
      004118 F0               [24] 1273 	movx	@dptr,a
      004119 90 05 88         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00411C 04               [12] 1275 	inc	a
      00411D 2A               [12] 1276 	add	a, r2
      00411E F0               [24] 1277 	movx	@dptr,a
      00411F E4               [12] 1278 	clr	a
      004120 3B               [12] 1279 	addc	a, r3
      004121 A3               [24] 1280 	inc	dptr
      004122 F0               [24] 1281 	movx	@dptr,a
      004123 80 D3            [24] 1282 	sjmp	00103$
      004125                       1283 00102$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004125 90 05 88         [24] 1285 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004128 12 43 89         [24] 1286 	lcall	_ak820_outline_0119
      00412B 12 43 84         [24] 1287 	lcall	_ak820_outline_0116
      00412E C0 07            [24] 1288 	push	ar7
      004130 C0 06            [24] 1289 	push	ar6
      004132 C0 05            [24] 1290 	push	ar5
      004134 C0 04            [24] 1291 	push	ar4
      004136 C0 03            [24] 1292 	push	ar3
      004138 C0 02            [24] 1293 	push	ar2
      00413A 12 40 43         [24] 1294 	lcall	_read_offset
      00413D A9 82            [24] 1295 	mov	r1, dpl
      00413F D0 02            [24] 1296 	pop	ar2
      004141 D0 03            [24] 1297 	pop	ar3
      004143 D0 04            [24] 1298 	pop	ar4
      004145 D0 05            [24] 1299 	pop	ar5
      004147 D0 06            [24] 1300 	pop	ar6
      004149 D0 07            [24] 1301 	pop	ar7
      00414B 12 43 A0         [24] 1302 	lcall	_ak820_outline_0140
      00414E E9               [12] 1303 	mov	a,r1
      00414F F0               [24] 1304 	movx	@dptr,a
      004150 90 05 88         [24] 1305 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004153 74 01            [12] 1306 	mov	a,#0x01
      004155 2A               [12] 1307 	add	a, r2
      004156 F0               [24] 1308 	movx	@dptr,a
      004157 E4               [12] 1309 	clr	a
      004158 3B               [12] 1310 	addc	a, r3
      004159 A3               [24] 1311 	inc	dptr
      00415A F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      00415B 0E               [12] 1314 	inc	r6
      00415C BE 00 99         [24] 1315 	cjne	r6,#0x00,00103$
      00415F 0F               [12] 1316 	inc	r7
      004160 80 96            [24] 1317 	sjmp	00103$
      004162                       1318 00106$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004162 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1325 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1326 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1327 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1328 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1329 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1330 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function ak820_eeprom_write_block_xdata
                                   1335 ;	-----------------------------------------
      004163                       1336 _ak820_eeprom_write_block_xdata:
      004163 12 38 43         [24] 1337 	lcall	_ak820_outline_0103
      004166 90 05 8F         [24] 1338 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004169 12 38 48         [24] 1339 	lcall	_ak820_outline_0104
                                   1340 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00416C 90 05 8A         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00416F 12 38 00         [24] 1342 	lcall	_ak820_outline_0050
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004172 90 05 8F         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004175 12 38 1F         [24] 1345 	lcall	_ak820_outline_0059
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004178 8E 02            [24] 1347 	mov	ar2,r6
      00417A 8F 03            [24] 1348 	mov	ar3,r7
      00417C C3               [12] 1349 	clr	c
      00417D E4               [12] 1350 	clr	a
      00417E 9A               [12] 1351 	subb	a,r2
      00417F 74 28            [12] 1352 	mov	a,#0x28
      004181 9B               [12] 1353 	subb	a,r3
      004182 40 15            [24] 1354 	jc	00101$
                                   1355 ;	free result
      004184 E4               [12] 1356 	clr	a
      004185 C3               [12] 1357 	clr	c
      004186 9E               [12] 1358 	subb	a,r6
      004187 FA               [12] 1359 	mov	r2,a
      004188 74 28            [12] 1360 	mov	a,#0x28
      00418A 9F               [12] 1361 	subb	a,r7
      00418B FB               [12] 1362 	mov	r3,a
      00418C 90 05 8D         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00418F 12 38 3D         [24] 1364 	lcall	_ak820_outline_0099
      004192 C3               [12] 1365 	clr	c
      004193 EA               [12] 1366 	mov	a,r2
      004194 98               [12] 1367 	subb	a,r0
      004195 EB               [12] 1368 	mov	a,r3
      004196 99               [12] 1369 	subb	a,r1
      004197 50 06            [24] 1370 	jnc	00125$
                                   1371 ;	free result
      004199                       1372 00101$:
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004199 75 82 0E         [24] 1374 	mov	dpl, #0x0e
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      00419C 02 3B AC         [24] 1376 	ljmp	_nvm_fail
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      00419F                       1378 00125$:
      00419F 90 05 8D         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0041A2 12 43 89         [24] 1380 	lcall	_ak820_outline_0119
      0041A5                       1381 00108$:
      0041A5 8A 00            [24] 1382 	mov	ar0,r2
      0041A7 8B 01            [24] 1383 	mov	ar1,r3
      0041A9 1A               [12] 1384 	dec	r2
      0041AA BA FF 01         [24] 1385 	cjne	r2,#0xff,00159$
      0041AD 1B               [12] 1386 	dec	r3
      0041AE                       1387 00159$:
      0041AE E8               [12] 1388 	mov	a,r0
      0041AF 49               [12] 1389 	orl	a,r1
      0041B0 70 03            [24] 1390 	jnz	00160$
      0041B2 02 42 3C         [24] 1391 	ljmp	00110$
      0041B5                       1392 00160$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0041B5 C0 02            [24] 1394 	push	ar2
      0041B7 C0 03            [24] 1395 	push	ar3
      0041B9 12 43 72         [24] 1396 	lcall	_ak820_outline_0092
      0041BC F9               [12] 1397 	mov	r1,a
      0041BD A3               [24] 1398 	inc	dptr
      0041BE 12 43 A5         [24] 1399 	lcall	_ak820_outline_0145
                                   1400 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0041C1 8E 0C            [24] 1401 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0041C3 8F 0D            [24] 1402 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0041C5 A8 0C            [24] 1403 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041C7 E5 0D            [12] 1404 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041C9 A2 E7            [12] 1405 	mov	c,acc.7
      0041CB C8               [12] 1406 	xch	a,r0
      0041CC 33               [12] 1407 	rlc	a
      0041CD C8               [12] 1408 	xch	a,r0
      0041CE 33               [12] 1409 	rlc	a
      0041CF A2 E7            [12] 1410 	mov	c,acc.7
      0041D1 C8               [12] 1411 	xch	a,r0
      0041D2 33               [12] 1412 	rlc	a
      0041D3 C8               [12] 1413 	xch	a,r0
      0041D4 33               [12] 1414 	rlc	a
      0041D5 C8               [12] 1415 	xch	a,r0
      0041D6 54 03            [12] 1416 	anl	a,#0x03
      0041D8 FB               [12] 1417 	mov	r3,a
      0041D9 88 82            [24] 1418 	mov	dpl, r0
      0041DB C0 07            [24] 1419 	push	ar7
      0041DD C0 06            [24] 1420 	push	ar6
      0041DF C0 05            [24] 1421 	push	ar5
      0041E1 C0 04            [24] 1422 	push	ar4
      0041E3 C0 03            [24] 1423 	push	ar3
      0041E5 C0 02            [24] 1424 	push	ar2
      0041E7 C0 01            [24] 1425 	push	ar1
      0041E9 12 3F D1         [24] 1426 	lcall	_load_page
      0041EC E5 82            [12] 1427 	mov	a, dpl
      0041EE D0 01            [24] 1428 	pop	ar1
      0041F0 D0 02            [24] 1429 	pop	ar2
      0041F2 D0 03            [24] 1430 	pop	ar3
      0041F4 D0 04            [24] 1431 	pop	ar4
      0041F6 D0 05            [24] 1432 	pop	ar5
      0041F8 D0 06            [24] 1433 	pop	ar6
      0041FA D0 07            [24] 1434 	pop	ar7
      0041FC D0 03            [24] 1435 	pop	ar3
      0041FE D0 02            [24] 1436 	pop	ar2
      004200 70 01            [24] 1437 	jnz	00105$
      004202 22               [24] 1438 	ret
      004203                       1439 00105$:
                                   1440 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004203 C0 06            [24] 1441 	push	ar6
      004205 C0 07            [24] 1442 	push	ar7
      004207 74 3F            [12] 1443 	mov	a,#0x3f
      004209 55 0C            [12] 1444 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00420B 7F 00            [12] 1445 	mov	r7,#0x00
      00420D 24 19            [12] 1446 	add	a, #_page_data
      00420F F5 0C            [12] 1447 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004211 EF               [12] 1448 	mov	a,r7
      004212 34 05            [12] 1449 	addc	a, #(_page_data >> 8)
      004214 F5 0D            [12] 1450 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      004216 85 0C 82         [24] 1451 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004219 85 0D 83         [24] 1452 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00421C E0               [24] 1453 	movx	a,@dptr
      00421D B5 01 06         [24] 1454 	cjne	a,ar1,00162$
      004220 D0 07            [24] 1455 	pop	ar7
      004222 D0 06            [24] 1456 	pop	ar6
      004224 80 0E            [24] 1457 	sjmp	00107$
      004226                       1458 00162$:
      004226 D0 07            [24] 1459 	pop	ar7
      004228 D0 06            [24] 1460 	pop	ar6
                                   1461 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00422A 85 0C 82         [24] 1462 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00422D 85 0D 83         [24] 1463 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004230 E9               [12] 1464 	mov	a,r1
      004231 F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1467 ;	assignBit
      004232 D2 08            [12] 1468 	setb	_page_dirty
      004234                       1469 00107$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004234 0E               [12] 1471 	inc	r6
      004235 BE 00 01         [24] 1472 	cjne	r6,#0x00,00163$
      004238 0F               [12] 1473 	inc	r7
      004239                       1474 00163$:
      004239 02 41 A5         [24] 1475 	ljmp	00108$
      00423C                       1476 00110$:
                                   1477 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00423C 90 05 5A         [24] 1478 	mov	dptr,#_batch_depth
      00423F E0               [24] 1479 	movx	a,@dptr
      004240 70 03            [24] 1480 	jnz	00113$
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004242 02 3E 51         [24] 1482 	ljmp	_ak820_nvm_flush
      004245                       1483 00113$:
      004245 22               [24] 1484 	ret
                                   1485 ;------------------------------------------------------------
                                   1486 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1487 ;------------------------------------------------------------
                                   1488 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1489 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1490 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1491 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1492 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1493 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1494 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1495 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1496 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1497 ;------------------------------------------------------------
                                   1498 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1499 ;	-----------------------------------------
                                   1500 ;	 function ak820_eeprom_update_block_xdata
                                   1501 ;	-----------------------------------------
      004246                       1502 _ak820_eeprom_update_block_xdata:
      004246 12 38 43         [24] 1503 	lcall	_ak820_outline_0103
      004249 90 05 96         [24] 1504 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00424C 12 38 48         [24] 1505 	lcall	_ak820_outline_0104
                                   1506 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      00424F 90 05 96         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004252 12 38 00         [24] 1508 	lcall	_ak820_outline_0050
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004255 90 05 91         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004258 E0               [24] 1511 	movx	a,@dptr
      004259 F5 12            [12] 1512 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      00425B A3               [24] 1513 	inc	dptr
      00425C E0               [24] 1514 	movx	a,@dptr
      00425D F5 13            [12] 1515 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      00425F A3               [24] 1516 	inc	dptr
      004260 E0               [24] 1517 	movx	a,@dptr
      004261 F5 14            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004263 A9 12            [24] 1519 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004265 AA 13            [24] 1520 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1521 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004267 E4               [12] 1522 	clr	a
      004268 F5 0E            [12] 1523 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      00426A F5 0F            [12] 1524 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00426C                       1525 00105$:
      00426C 90 05 94         [24] 1526 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00426F E0               [24] 1527 	movx	a,@dptr
      004270 F5 10            [12] 1528 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004272 A3               [24] 1529 	inc	dptr
      004273 E0               [24] 1530 	movx	a,@dptr
      004274 F5 11            [12] 1531 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004276 C3               [12] 1532 	clr	c
      004277 E5 0E            [12] 1533 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004279 95 10            [12] 1534 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00427B E5 0F            [12] 1535 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00427D 95 11            [12] 1536 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00427F 50 68            [24] 1537 	jnc	00107$
                                   1538 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004281 89 00            [24] 1539 	mov	ar0,r1
      004283 8A 05            [24] 1540 	mov	ar5,r2
      004285 E5 0E            [12] 1541 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004287 28               [12] 1542 	add	a, r0
      004288 F8               [12] 1543 	mov	r0,a
      004289 E5 0F            [12] 1544 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00428B 3D               [12] 1545 	addc	a, r5
      00428C FD               [12] 1546 	mov	r5,a
      00428D 88 82            [24] 1547 	mov	dpl, r0
      00428F 8D 83            [24] 1548 	mov	dph, r5
      004291 C0 07            [24] 1549 	push	ar7
      004293 C0 06            [24] 1550 	push	ar6
      004295 C0 02            [24] 1551 	push	ar2
      004297 C0 01            [24] 1552 	push	ar1
      004299 12 40 43         [24] 1553 	lcall	_read_offset
      00429C AD 82            [24] 1554 	mov	r5, dpl
      00429E D0 01            [24] 1555 	pop	ar1
      0042A0 D0 02            [24] 1556 	pop	ar2
      0042A2 D0 06            [24] 1557 	pop	ar6
      0042A4 D0 07            [24] 1558 	pop	ar7
      0042A6 E5 0E            [12] 1559 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042A8 2E               [12] 1560 	add	a, r6
      0042A9 F5 82            [12] 1561 	mov	dpl,a
      0042AB E5 0F            [12] 1562 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042AD 3F               [12] 1563 	addc	a, r7
      0042AE F5 83            [12] 1564 	mov	dph,a
      0042B0 E0               [24] 1565 	movx	a,@dptr
      0042B1 FC               [12] 1566 	mov	r4,a
      0042B2 ED               [12] 1567 	mov	a,r5
      0042B3 B5 04 02         [24] 1568 	cjne	a,ar4,00131$
      0042B6 80 27            [24] 1569 	sjmp	00106$
      0042B8                       1570 00131$:
                                   1571 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      0042B8 90 05 96         [24] 1572 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0042BB E0               [24] 1573 	movx	a,@dptr
      0042BC F8               [12] 1574 	mov	r0,a
      0042BD A3               [24] 1575 	inc	dptr
      0042BE E0               [24] 1576 	movx	a,@dptr
      0042BF FD               [12] 1577 	mov	r5,a
      0042C0 90 05 8A         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0042C3 E5 12            [12] 1579 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0042C5 F0               [24] 1580 	movx	@dptr,a
      0042C6 E5 13            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0042C8 A3               [24] 1582 	inc	dptr
      0042C9 F0               [24] 1583 	movx	@dptr,a
      0042CA E5 14            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0042CC A3               [24] 1585 	inc	dptr
      0042CD F0               [24] 1586 	movx	@dptr,a
      0042CE 90 05 8D         [24] 1587 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0042D1 E5 10            [12] 1588 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042D3 F0               [24] 1589 	movx	@dptr,a
      0042D4 E5 11            [12] 1590 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042D6 A3               [24] 1591 	inc	dptr
      0042D7 F0               [24] 1592 	movx	@dptr,a
      0042D8 88 82            [24] 1593 	mov	dpl, r0
      0042DA 8D 83            [24] 1594 	mov	dph, r5
                                   1595 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0042DC 02 41 63         [24] 1596 	ljmp	_ak820_eeprom_write_block_xdata
      0042DF                       1597 00106$:
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042DF 05 0E            [12] 1599 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042E1 E4               [12] 1600 	clr	a
      0042E2 B5 0E 87         [24] 1601 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0042E5 05 0F            [12] 1602 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042E7 80 83            [24] 1603 	sjmp	00105$
      0042E9                       1604 00107$:
                                   1605 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0042E9 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1609 ;------------------------------------------------------------
                                   1610 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1611 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function eeprom_driver_erase
                                   1616 ;	-----------------------------------------
      0042EA                       1617 _eeprom_driver_erase:
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0042EA 12 3E 51         [24] 1619 	lcall	_ak820_nvm_flush
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042ED 7F 00            [12] 1621 	mov	r7,#0x00
      0042EF                       1622 00111$:
      0042EF BF A0 01         [24] 1623 	cjne	r7,#0xa0,00165$
      0042F2 22               [24] 1624 	ret
      0042F3                       1625 00165$:
      0042F3 20 09 32         [24] 1626 	jb	_storage_failed,00113$
                                   1627 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0042F6 8F 82            [24] 1628 	mov	dpl, r7
      0042F8 C0 07            [24] 1629 	push	ar7
      0042FA 12 3F D1         [24] 1630 	lcall	_load_page
      0042FD E5 82            [12] 1631 	mov	a, dpl
      0042FF D0 07            [24] 1632 	pop	ar7
      004301 70 01            [24] 1633 	jnz	00126$
                                   1634 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004303 22               [24] 1635 	ret
      004304                       1636 00126$:
      004304 7E 00            [12] 1637 	mov	r6,#0x00
      004306                       1638 00107$:
                                   1639 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      004306 EE               [12] 1640 	mov	a,r6
      004307 24 19            [12] 1641 	add	a, #_page_data
      004309 FC               [12] 1642 	mov	r4,a
      00430A E4               [12] 1643 	clr	a
      00430B 34 05            [12] 1644 	addc	a, #(_page_data >> 8)
      00430D FD               [12] 1645 	mov	r5,a
      00430E 12 43 72         [24] 1646 	lcall	_ak820_outline_0092
      004311 60 07            [24] 1647 	jz	00108$
      004313 12 38 60         [24] 1648 	lcall	_ak820_outline_0121
      004316 E4               [12] 1649 	clr	a
      004317 F0               [24] 1650 	movx	@dptr,a
                                   1651 ;	assignBit
      004318 D2 08            [12] 1652 	setb	_page_dirty
      00431A                       1653 00108$:
                                   1654 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00431A 0E               [12] 1655 	inc	r6
      00431B BE 40 E8         [24] 1656 	cjne	r6,#0x40,00107$
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      00431E C0 07            [24] 1658 	push	ar7
      004320 12 3E 51         [24] 1659 	lcall	_ak820_nvm_flush
      004323 D0 07            [24] 1660 	pop	ar7
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004325 0F               [12] 1662 	inc	r7
      004326 80 C7            [24] 1663 	sjmp	00111$
      004328                       1664 00113$:
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004328 22               [24] 1666 	ret
                                   1667 	.area CSEG    (CODE)
                                   1668 	.area CONST   (CODE)
                                   1669 	.area XINIT   (CODE)
                                   1670 	.area CABS    (ABS,CODE)
                                   1671 
                                   1672 ; Experimental exact instruction outlining.
                                   1673 	.globl _ak820_outline_0004
                                   1674 	.globl _ak820_outline_0009
                                   1675 	.globl _ak820_outline_0015
                                   1676 	.globl _ak820_outline_0016
                                   1677 	.globl _ak820_outline_0029
                                   1678 	.globl _ak820_outline_0036
                                   1679 	.globl _ak820_outline_0039
                                   1680 	.globl _ak820_outline_0050
                                   1681 	.globl _ak820_outline_0051
                                   1682 	.globl _ak820_outline_0059
                                   1683 	.globl _ak820_outline_0060
                                   1684 	.globl _ak820_outline_0064
                                   1685 	.globl _ak820_outline_0070
                                   1686 	.globl _ak820_outline_0076
                                   1687 	.globl _ak820_outline_0090
                                   1688 	.globl _ak820_outline_0092
                                   1689 	.globl _ak820_outline_0099
                                   1690 	.globl _ak820_outline_0101
                                   1691 	.globl _ak820_outline_0103
                                   1692 	.globl _ak820_outline_0104
                                   1693 	.globl _ak820_outline_0116
                                   1694 	.globl _ak820_outline_0119
                                   1695 	.globl _ak820_outline_0120
                                   1696 	.globl _ak820_outline_0121
                                   1697 	.globl _ak820_outline_0122
                                   1698 	.globl _ak820_outline_0131
                                   1699 	.globl _ak820_outline_0132
                                   1700 	.globl _ak820_outline_0134
                                   1701 	.globl _ak820_outline_0139
                                   1702 	.globl _ak820_outline_0140
                                   1703 	.globl _ak820_outline_0145
                                   1704 	.globl _ak820_outline_0153
                                   1705 	.globl _ak820_outline_0156
                                   1706 	.globl _ak820_outline_0157
                                   1707 	.globl _ak820_outline_0166
                                   1708 	.globl _ak820_outline_0179
                                   1709 	.globl _ak820_outline_0180
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0009
      004329                       1713 _ak820_outline_0009:
      004329 8E 82            [24] 1714 	mov	dpl,r6
      00432B 8F 83            [24] 1715 	mov	dph,r7
      00432D A3               [24] 1716 	inc	dptr
      00432E A3               [24] 1717 	inc	dptr
      00432F A3               [24] 1718 	inc	dptr
      004330 A3               [24] 1719 	inc	dptr
      004331 A3               [24] 1720 	inc	dptr
      004332 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0029
      004333                       1725 _ak820_outline_0029:
      004333 F0               [24] 1726 	movx	@dptr,a
      004334 8E 82            [24] 1727 	mov	dpl,r6
      004336 8F 83            [24] 1728 	mov	dph,r7
      004338 A3               [24] 1729 	inc	dptr
      004339 A3               [24] 1730 	inc	dptr
      00433A 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0036
      00433B                       1735 _ak820_outline_0036:
      00433B AF F0            [24] 1736 	mov	r7,b
      00433D AE 83            [24] 1737 	mov	r6,dph
      00433F E5 82            [12] 1738 	mov	a,dpl
      004341 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0039
      004342                       1743 _ak820_outline_0039:
      004342 EF               [12] 1744 	mov	a,r7
      004343 24 71            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      004345 F5 82            [12] 1746 	mov	dpl,a
      004347 E4               [12] 1747 	clr	a
      004348 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00434A F5 83            [12] 1749 	mov	dph,a
      00434C E0               [24] 1750 	movx	a,@dptr
      00434D 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0051
      00434E                       1755 _ak820_outline_0051:
      00434E 8F 06            [24] 1756 	mov	ar6,r7
      004350 7D 00            [12] 1757 	mov	r5,#0x00
      004352 74 40            [12] 1758 	mov	a,#0x40
      004354 2E               [12] 1759 	add	a,r6
      004355 FE               [12] 1760 	mov	r6,a
      004356 74 EF            [12] 1761 	mov	a,#0xef
      004358 3D               [12] 1762 	addc	a,r5
      004359 FD               [12] 1763 	mov	r5,a
      00435A 8E 82            [24] 1764 	mov	dpl,r6
      00435C 8D 83            [24] 1765 	mov	dph,r5
      00435E 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0060
      00435F                       1770 _ak820_outline_0060:
      00435F F0               [24] 1771 	movx	@dptr,a
      004360 8E 82            [24] 1772 	mov	dpl,r6
      004362 8F 83            [24] 1773 	mov	dph,r7
      004364 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0064
      004365                       1778 _ak820_outline_0064:
      004365 8D 82            [24] 1779 	mov	dpl,r5
      004367 8E 83            [24] 1780 	mov	dph,r6
      004369 EC               [12] 1781 	mov	a,r4
      00436A F0               [24] 1782 	movx	@dptr,a
      00436B 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0090
      00436C                       1787 _ak820_outline_0090:
      00436C E0               [24] 1788 	movx	a,@dptr
      00436D FD               [12] 1789 	mov	r5,a
      00436E A3               [24] 1790 	inc	dptr
      00436F E0               [24] 1791 	movx	a,@dptr
      004370 FE               [12] 1792 	mov	r6,a
      004371 22               [24] 1793 	ret
                                   1794 
                                   1795 	.area CSEG (CODE)
                                   1796 ; function ak820_outline_0092
      004372                       1797 _ak820_outline_0092:
      004372 8C 82            [24] 1798 	mov	dpl,r4
      004374 8D 83            [24] 1799 	mov	dph,r5
      004376 E0               [24] 1800 	movx	a,@dptr
      004377 22               [24] 1801 	ret
                                   1802 
                                   1803 	.area CSEG (CODE)
                                   1804 ; function ak820_outline_0101
      004378                       1805 _ak820_outline_0101:
      004378 EF               [12] 1806 	mov	a,r7
      004379 24 19            [12] 1807 	add	a,#_page_data
      00437B F5 82            [12] 1808 	mov	dpl,a
      00437D E4               [12] 1809 	clr	a
      00437E 34 05            [12] 1810 	addc	a,#(_page_data>>8)
      004380 F5 83            [12] 1811 	mov	dph,a
      004382 E0               [24] 1812 	movx	a,@dptr
      004383 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0116
      004384                       1817 _ak820_outline_0116:
      004384 8E 82            [24] 1818 	mov	dpl,r6
      004386 8F 83            [24] 1819 	mov	dph,r7
      004388 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0119
      004389                       1824 _ak820_outline_0119:
      004389 E0               [24] 1825 	movx	a,@dptr
      00438A FA               [12] 1826 	mov	r2,a
      00438B A3               [24] 1827 	inc	dptr
      00438C E0               [24] 1828 	movx	a,@dptr
      00438D FB               [12] 1829 	mov	r3,a
      00438E 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0131
      00438F                       1834 _ak820_outline_0131:
      00438F AE 82            [24] 1835 	mov	r6,dpl
      004391 AF 83            [24] 1836 	mov	r7,dph
      004393 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0134
      004394                       1841 _ak820_outline_0134:
      004394 2E               [12] 1842 	add	a,r6
      004395 FE               [12] 1843 	mov	r6,a
      004396 E4               [12] 1844 	clr	a
      004397 3F               [12] 1845 	addc	a,r7
      004398 FF               [12] 1846 	mov	r7,a
      004399 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0139
      00439A                       1851 _ak820_outline_0139:
      00439A 42 05            [12] 1852 	orl	ar5,a
      00439C EA               [12] 1853 	mov	a,r2
      00439D 42 04            [12] 1854 	orl	ar4,a
      00439F 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0140
      0043A0                       1859 _ak820_outline_0140:
      0043A0 8A 82            [24] 1860 	mov	dpl,r2
      0043A2 8B 83            [24] 1861 	mov	dph,r3
      0043A4 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0145
      0043A5                       1866 _ak820_outline_0145:
      0043A5 AC 82            [24] 1867 	mov	r4,dpl
      0043A7 AD 83            [24] 1868 	mov	r5,dph
      0043A9 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0153
      0043AA                       1873 _ak820_outline_0153:
      0043AA 8F 82            [24] 1874 	mov	dpl,r7
      0043AC 8E 83            [24] 1875 	mov	dph,r6
      0043AE 22               [24] 1876 	ret
                                   1877 
                                   1878 	.area CSEG (CODE)
                                   1879 ; function ak820_outline_0156
      0043AF                       1880 _ak820_outline_0156:
      0043AF 2E               [12] 1881 	add	a,r6
      0043B0 FC               [12] 1882 	mov	r4,a
      0043B1 E4               [12] 1883 	clr	a
      0043B2 3F               [12] 1884 	addc	a,r7
      0043B3 FD               [12] 1885 	mov	r5,a
      0043B4 22               [24] 1886 	ret
                                   1887 
                                   1888 	.area CSEG (CODE)
                                   1889 ; function ak820_outline_0157
      0043B5                       1890 _ak820_outline_0157:
      0043B5 ED               [12] 1891 	mov	a,r5
      0043B6 F0               [24] 1892 	movx	@dptr,a
      0043B7 EE               [12] 1893 	mov	a,r6
      0043B8 A3               [24] 1894 	inc	dptr
      0043B9 F0               [24] 1895 	movx	@dptr,a
      0043BA 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0179
      0043BB                       1900 _ak820_outline_0179:
      0043BB 89 82            [24] 1901 	mov	dpl,r1
      0043BD 8A 83            [24] 1902 	mov	dph,r2
      0043BF 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0180
      0043C0                       1907 _ak820_outline_0180:
      0043C0 8C 82            [24] 1908 	mov	dpl,r4
      0043C2 8B 83            [24] 1909 	mov	dph,r3
      0043C4 22               [24] 1910 	ret
