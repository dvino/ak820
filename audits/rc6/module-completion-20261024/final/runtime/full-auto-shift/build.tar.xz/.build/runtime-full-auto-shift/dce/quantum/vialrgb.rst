                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000C6C                        569 _g_direct_mode_colors::
      000C6C                        570 	.ds 246
      000D62                        571 _get_supported_PARM_2:
      000D62                        572 	.ds 1
      000D63                        573 _get_supported_args_10000_255:
      000D63                        574 	.ds 2
      000D65                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000D65                        576 	.ds 2
      000D67                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000D67                        578 	.ds 2
      000D69                        579 _set_mode_mode_10000_275:
      000D69                        580 	.ds 2
      000D6B                        581 _get_matrix_pos_for_led_PARM_2:
      000D6B                        582 	.ds 2
      000D6D                        583 _get_matrix_pos_for_led_led_10000_280:
      000D6D                        584 	.ds 2
      000D6F                        585 _fast_set_leds_PARM_2:
      000D6F                        586 	.ds 1
      000D70                        587 _fast_set_leds_args_10000_282:
      000D70                        588 	.ds 2
      000D72                        589 _fast_set_leds_first_index_10001_285:
      000D72                        590 	.ds 2
      000D74                        591 _fast_set_leds_num_leds_10001_285:
      000D74                        592 	.ds 1
      000D75                        593 _vialrgb_get_value_PARM_2:
      000D75                        594 	.ds 1
      000D76                        595 _vialrgb_get_value_data_10000_291:
      000D76                        596 	.ds 3
      000D79                        597 _vialrgb_set_value_PARM_2:
      000D79                        598 	.ds 1
      000D7A                        599 _vialrgb_set_value_data_10000_302:
      000D7A                        600 	.ds 3
      000D7D                        601 _vialrgb_save_PARM_2:
      000D7D                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B288                        654 _get_supported:
      00B288 12 3A 8A         [24]  655 	lcall	_ak820_outline_0103
      00B28B 90 0D 63         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B28E 12 3A 8F         [24]  657 	lcall	_ak820_outline_0104
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B291 90 0D 63         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B294 12 39 E7         [24]  660 	lcall	_ak820_outline_0004
      00B297 E0               [24]  661 	movx	a,@dptr
      00B298 FD               [12]  662 	mov	r5,a
      00B299 7C 00            [12]  663 	mov	r4,#0x00
      00B29B 12 3A 94         [24]  664 	lcall	_ak820_outline_0108
      00B29E FA               [12]  665 	mov	r2,a
      00B29F E4               [12]  666 	clr	a
      00B2A0 12 45 7C         [24]  667 	lcall	_ak820_outline_0138
                                    668 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B2A3 90 0D 62         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00B2A6 E0               [24]  670 	movx	a,@dptr
      00B2A7 FB               [12]  671 	mov	r3,a
      00B2A8 7A 00            [12]  672 	mov	r2,#0x00
      00B2AA                        673 00107$:
      00B2AA C3               [12]  674 	clr	c
      00B2AB EA               [12]  675 	mov	a,r2
      00B2AC 9B               [12]  676 	subb	a,r3
      00B2AD 50 0A            [24]  677 	jnc	00101$
      00B2AF EA               [12]  678 	mov	a,r2
      00B2B0 12 3A 37         [24]  679 	lcall	_ak820_outline_0030
      00B2B3 74 FF            [12]  680 	mov	a,#0xff
      00B2B5 F0               [24]  681 	movx	@dptr,a
      00B2B6 0A               [12]  682 	inc	r2
      00B2B7 80 F1            [24]  683 	sjmp	00107$
      00B2B9                        684 00101$:
                                    685 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B2B9 8D 06            [24]  686 	mov	ar6,r5
      00B2BB 8C 07            [24]  687 	mov	ar7,r4
      00B2BD 8B 05            [24]  688 	mov	ar5,r3
      00B2BF 90 0D 63         [24]  689 	mov	dptr,#_get_supported_args_10000_255
      00B2C2 12 3A A0         [24]  690 	lcall	_ak820_outline_0120
      00B2C5 7A 00            [12]  691 	mov	r2,#0x00
      00B2C7                        692 00110$:
      00B2C7 BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00B2CA                        694 00159$:
      00B2CA 50 46            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B2CC EA               [12]  697 	mov	a,r2
      00B2CD 75 F0 02         [24]  698 	mov	b,#0x02
      00B2D0 A4               [48]  699 	mul	ab
      00B2D1 24 31            [12]  700 	add	a, #_supported_modes
      00B2D3 F5 82            [12]  701 	mov	dpl,a
      00B2D5 74 BF            [12]  702 	mov	a,#(_supported_modes >> 8)
      00B2D7 12 58 EB         [24]  703 	lcall	_ak820_outline_0105
      00B2DA F8               [12]  704 	mov	r0,a
      00B2DB 79 00            [12]  705 	mov	r1,#0x00
                                    706 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B2DD C3               [12]  707 	clr	c
      00B2DE EE               [12]  708 	mov	a,r6
      00B2DF 98               [12]  709 	subb	a,r0
      00B2E0 EF               [12]  710 	mov	a,r7
      00B2E1 99               [12]  711 	subb	a,r1
      00B2E2 50 2B            [24]  712 	jnc	00111$
                                    713 ;	free result
      00B2E4 BD 02 00         [24]  714 	cjne	r5,#0x02,00162$
      00B2E7                        715 00162$:
      00B2E7 40 26            [24]  716 	jc	00111$
                                    717 ;	quantum/vialrgb.c:49: args[0] = id;
      00B2E9 C0 06            [24]  718 	push	ar6
      00B2EB C0 07            [24]  719 	push	ar7
      00B2ED 88 07            [24]  720 	mov	ar7,r0
      00B2EF 12 36 42         [24]  721 	lcall	_ak820_outline_0121
      00B2F2 EF               [12]  722 	mov	a,r7
      00B2F3 F0               [24]  723 	movx	@dptr,a
                                    724 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B2F4 12 36 42         [24]  725 	lcall	_ak820_outline_0121
      00B2F7 A3               [24]  726 	inc	dptr
      00B2F8 89 00            [24]  727 	mov	ar0,r1
      00B2FA E8               [12]  728 	mov	a,r0
      00B2FB F0               [24]  729 	movx	@dptr,a
                                    730 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B2FC 1D               [12]  731 	dec	r5
      00B2FD 1D               [12]  732 	dec	r5
                                    733 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B2FE 74 02            [12]  734 	mov	a,#0x02
      00B300 2B               [12]  735 	add	a, r3
      00B301 FB               [12]  736 	mov	r3,a
      00B302 E4               [12]  737 	clr	a
      00B303 3C               [12]  738 	addc	a, r4
      00B304 FC               [12]  739 	mov	r4,a
      00B305 90 0D 63         [24]  740 	mov	dptr,#_get_supported_args_10000_255
      00B308 12 3A 72         [24]  741 	lcall	_ak820_outline_0076
                                    742 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B30B D0 07            [24]  743 	pop	ar7
      00B30D D0 06            [24]  744 	pop	ar6
                                    745 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B30F                        746 00111$:
                                    747 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B30F 0A               [12]  748 	inc	r2
      00B310 80 B5            [24]  749 	sjmp	00110$
      00B312                        750 00127$:
      00B312 90 0D 63         [24]  751 	mov	dptr,#_get_supported_args_10000_255
      00B315 12 3A 72         [24]  752 	lcall	_ak820_outline_0076
                                    753 ;	quantum/vialrgb.c:55: }
      00B318 22               [24]  754 	ret
                                    755 ;------------------------------------------------------------
                                    756 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    757 ;------------------------------------------------------------
                                    758 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    759 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    760 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    761 ;------------------------------------------------------------
                                    762 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function qmk_id_to_vialrgb_id
                                    765 ;	-----------------------------------------
      00B319                        766 _qmk_id_to_vialrgb_id:
      00B319 12 3A 8A         [24]  767 	lcall	_ak820_outline_0103
      00B31C 90 0D 65         [24]  768 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B31F 12 3A 8F         [24]  769 	lcall	_ak820_outline_0104
                                    770 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B322 90 0D 65         [24]  771 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B325 12 3A 47         [24]  772 	lcall	_ak820_outline_0050
      00B328 7D 00            [12]  773 	mov	r5,#0x00
      00B32A                        774 00105$:
      00B32A BD 07 00         [24]  775 	cjne	r5,#0x07,00130$
      00B32D                        776 00130$:
      00B32D 50 19            [24]  777 	jnc	00103$
                                    778 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B32F 12 B7 50         [24]  779 	lcall	_ak820_outline_0044
      00B332 A3               [24]  780 	inc	dptr
      00B333 E4               [12]  781 	clr	a
      00B334 93               [24]  782 	movc	a,@a+dptr
                                    783 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B335 7A 00            [12]  784 	mov	r2,#0x00
      00B337 B5 06 0B         [24]  785 	cjne	a,ar6,00106$
      00B33A EA               [12]  786 	mov	a,r2
      00B33B B5 07 07         [24]  787 	cjne	a,ar7,00106$
                                    788 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B33E 12 36 42         [24]  789 	lcall	_ak820_outline_0121
      00B341 12 B7 7C         [24]  790 	lcall	_ak820_outline_0140
      00B344 22               [24]  791 	ret
      00B345                        792 00106$:
                                    793 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B345 0D               [12]  794 	inc	r5
      00B346 80 E2            [24]  795 	sjmp	00105$
      00B348                        796 00103$:
                                    797 ;	quantum/vialrgb.c:63: return 0;
      00B348 90 00 00         [24]  798 	mov	dptr,#0x0000
                                    799 ;	quantum/vialrgb.c:64: }
      00B34B 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    803 ;------------------------------------------------------------
                                    804 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    805 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    806 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function vialrgb_id_to_qmk_id
                                    811 ;	-----------------------------------------
      00B34C                        812 _vialrgb_id_to_qmk_id:
      00B34C 12 3A 8A         [24]  813 	lcall	_ak820_outline_0103
      00B34F 90 0D 67         [24]  814 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B352 12 3A 8F         [24]  815 	lcall	_ak820_outline_0104
                                    816 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B355 90 0D 67         [24]  817 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B358 12 3A 47         [24]  818 	lcall	_ak820_outline_0050
      00B35B 7D 00            [12]  819 	mov	r5,#0x00
      00B35D                        820 00105$:
      00B35D BD 07 00         [24]  821 	cjne	r5,#0x07,00130$
      00B360                        822 00130$:
      00B360 50 19            [24]  823 	jnc	00103$
                                    824 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B362 12 B7 50         [24]  825 	lcall	_ak820_outline_0044
      00B365 E4               [12]  826 	clr	a
      00B366 93               [24]  827 	movc	a,@a+dptr
                                    828 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B367 7A 00            [12]  829 	mov	r2,#0x00
      00B369 B5 06 0C         [24]  830 	cjne	a,ar6,00106$
      00B36C EA               [12]  831 	mov	a,r2
      00B36D B5 07 08         [24]  832 	cjne	a,ar7,00106$
                                    833 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B370 12 36 42         [24]  834 	lcall	_ak820_outline_0121
      00B373 A3               [24]  835 	inc	dptr
      00B374 12 B7 7C         [24]  836 	lcall	_ak820_outline_0140
      00B377 22               [24]  837 	ret
      00B378                        838 00106$:
                                    839 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B378 0D               [12]  840 	inc	r5
      00B379 80 E2            [24]  841 	sjmp	00105$
      00B37B                        842 00103$:
                                    843 ;	quantum/vialrgb.c:72: return 0;
      00B37B 90 00 00         [24]  844 	mov	dptr,#0x0000
                                    845 ;	quantum/vialrgb.c:73: }
      00B37E 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'get_mode'
                                    849 ;------------------------------------------------------------
                                    850 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    851 ;	-----------------------------------------
                                    852 ;	 function get_mode
                                    853 ;	-----------------------------------------
      00B37F                        854 _get_mode:
                                    855 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B37F 12 56 D1         [24]  856 	lcall	_rgb_matrix_is_enabled
      00B382 E5 82            [12]  857 	mov	a, dpl
      00B384 70 04            [24]  858 	jnz	00102$
                                    859 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B386 90 00 00         [24]  860 	mov	dptr,#0x0000
      00B389 22               [24]  861 	ret
      00B38A                        862 00102$:
                                    863 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B38A 12 56 D7         [24]  864 	lcall	_rgb_matrix_get_mode
      00B38D 7E 00            [12]  865 	mov	r6,#0x00
      00B38F 8E 83            [24]  866 	mov	dph, r6
                                    867 ;	quantum/vialrgb.c:80: }
      00B391 02 B3 19         [24]  868 	ljmp	_qmk_id_to_vialrgb_id
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'set_mode'
                                    871 ;------------------------------------------------------------
                                    872 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    873 ;------------------------------------------------------------
                                    874 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function set_mode
                                    877 ;	-----------------------------------------
      00B394                        878 _set_mode:
      00B394 12 3A 8A         [24]  879 	lcall	_ak820_outline_0103
      00B397 90 0D 69         [24]  880 	mov	dptr,#_set_mode_mode_10000_275
      00B39A 12 3A 8F         [24]  881 	lcall	_ak820_outline_0104
                                    882 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B39D 90 0D 69         [24]  883 	mov	dptr,#_set_mode_mode_10000_275
      00B3A0 12 3A 47         [24]  884 	lcall	_ak820_outline_0050
      00B3A3 90 0D 69         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00B3A6 12 6F 3C         [24]  886 	lcall	_ak820_outline_0035
      00B3A9 70 03            [24]  887 	jnz	00102$
                                    888 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B3AB 02 57 24         [24]  889 	ljmp	_rgb_matrix_disable_noeeprom
      00B3AE                        890 00102$:
                                    891 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B3AE C0 07            [24]  892 	push	ar7
      00B3B0 C0 06            [24]  893 	push	ar6
      00B3B2 12 57 13         [24]  894 	lcall	_rgb_matrix_enable_noeeprom
      00B3B5 D0 06            [24]  895 	pop	ar6
      00B3B7 D0 07            [24]  896 	pop	ar7
                                    897 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B3B9 12 45 66         [24]  898 	lcall	_ak820_outline_0116
      00B3BC 12 B3 4C         [24]  899 	lcall	_vialrgb_id_to_qmk_id
                                    900 ;	quantum/vialrgb.c:90: }
      00B3BF 02 57 2D         [24]  901 	ljmp	_rgb_matrix_mode_noeeprom
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    904 ;------------------------------------------------------------
                                    905 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    906 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    907 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    908 ;------------------------------------------------------------
                                    909 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    910 ;	-----------------------------------------
                                    911 ;	 function get_matrix_pos_for_led
                                    912 ;	-----------------------------------------
      00B3C2                        913 _get_matrix_pos_for_led:
      00B3C2 12 3A 8A         [24]  914 	lcall	_ak820_outline_0103
      00B3C5 90 0D 6D         [24]  915 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B3C8 12 3A 8F         [24]  916 	lcall	_ak820_outline_0104
                                    917 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B3CB 90 0D 6D         [24]  918 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B3CE 12 3A 47         [24]  919 	lcall	_ak820_outline_0050
      00B3D1 EE               [12]  920 	mov	a,r6
      00B3D2 24 38            [12]  921 	add	a, #_ak820_rgb_slots
      00B3D4 F5 82            [12]  922 	mov	dpl,a
      00B3D6 EF               [12]  923 	mov	a,r7
      00B3D7 34 B9            [12]  924 	addc	a, #(_ak820_rgb_slots >> 8)
      00B3D9 F5 83            [12]  925 	mov	dph,a
      00B3DB E4               [12]  926 	clr	a
      00B3DC 93               [24]  927 	movc	a,@a+dptr
      00B3DD FF               [12]  928 	mov	r7,a
                                    929 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B3DE 90 0D 6B         [24]  930 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B3E1 12 45 54         [24]  931 	lcall	_ak820_outline_0092
      00B3E4 EF               [12]  932 	mov	a,r7
      00B3E5 12 59 21         [24]  933 	lcall	_ak820_outline_0182
      00B3E8 12 82 2F         [24]  934 	lcall	_ak820_outline_0118
                                    935 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B3EB 12 3A AB         [24]  936 	lcall	_ak820_outline_0131
      00B3EE A3               [24]  937 	inc	dptr
      00B3EF 53 07 07         [24]  938 	anl	ar7,#0x07
      00B3F2 EF               [12]  939 	mov	a,r7
      00B3F3 F0               [24]  940 	movx	@dptr,a
                                    941 ;	quantum/vialrgb.c:110: }
      00B3F4 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'fast_set_leds'
                                    945 ;------------------------------------------------------------
                                    946 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    947 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    948 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    949 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    950 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    951 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    952 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    953 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    954 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function fast_set_leds
                                    959 ;	-----------------------------------------
      00B3F5                        960 _fast_set_leds:
      00B3F5 12 3A 8A         [24]  961 	lcall	_ak820_outline_0103
      00B3F8 90 0D 70         [24]  962 	mov	dptr,#_fast_set_leds_args_10000_282
      00B3FB 12 3A 8F         [24]  963 	lcall	_ak820_outline_0104
                                    964 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B3FE 90 0D 6F         [24]  965 	mov	dptr,#_fast_set_leds_PARM_2
      00B401 E0               [24]  966 	movx	a,@dptr
      00B402 FF               [12]  967 	mov	r7,a
      00B403 BF 03 00         [24]  968 	cjne	r7,#0x03,00159$
      00B406                        969 00159$:
      00B406 50 01            [24]  970 	jnc	00102$
      00B408 22               [24]  971 	ret
      00B409                        972 00102$:
                                    973 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B409 90 0D 70         [24]  974 	mov	dptr,#_fast_set_leds_args_10000_282
      00B40C 12 45 54         [24]  975 	lcall	_ak820_outline_0092
      00B40F 12 4A 8D         [24]  976 	lcall	_ak820_outline_0074
      00B412 7B 00            [12]  977 	mov	r3,#0x00
      00B414 12 3A AB         [24]  978 	lcall	_ak820_outline_0131
      00B417 A3               [24]  979 	inc	dptr
      00B418 E0               [24]  980 	movx	a,@dptr
      00B419 FA               [12]  981 	mov	r2,a
      00B41A 79 00            [12]  982 	mov	r1,#0x00
      00B41C 90 0D 72         [24]  983 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B41F E9               [12]  984 	mov	a,r1
      00B420 4C               [12]  985 	orl	a,r4
      00B421 F0               [24]  986 	movx	@dptr,a
      00B422 EA               [12]  987 	mov	a,r2
      00B423 4B               [12]  988 	orl	a,r3
      00B424 A3               [24]  989 	inc	dptr
      00B425 F0               [24]  990 	movx	@dptr,a
                                    991 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B426 12 3A AB         [24]  992 	lcall	_ak820_outline_0131
      00B429 A3               [24]  993 	inc	dptr
      00B42A A3               [24]  994 	inc	dptr
      00B42B E0               [24]  995 	movx	a,@dptr
      00B42C 90 0D 74         [24]  996 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B42F F0               [24]  997 	movx	@dptr,a
                                    998 ;	quantum/vialrgb.c:119: length -= 3;
      00B430 EF               [12]  999 	mov	a,r7
      00B431 24 FD            [12] 1000 	add	a,#0xfd
      00B433 90 0D 6F         [24] 1001 	mov	dptr,#_fast_set_leds_PARM_2
      00B436 F0               [24] 1002 	movx	@dptr,a
                                   1003 ;	quantum/vialrgb.c:120: args += 3;
      00B437 90 0D 70         [24] 1004 	mov	dptr,#_fast_set_leds_args_10000_282
      00B43A 74 03            [12] 1005 	mov	a,#0x03
      00B43C 2D               [12] 1006 	add	a, r5
      00B43D F0               [24] 1007 	movx	@dptr,a
      00B43E E4               [12] 1008 	clr	a
      00B43F 3E               [12] 1009 	addc	a, r6
      00B440 A3               [24] 1010 	inc	dptr
      00B441 F0               [24] 1011 	movx	@dptr,a
                                   1012 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B442 90 0D 74         [24] 1013 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B445 E0               [24] 1014 	movx	a,@dptr
      00B446 FF               [12] 1015 	mov	r7,a
      00B447 75 F0 03         [24] 1016 	mov	b,#0x03
      00B44A A4               [48] 1017 	mul	ab
      00B44B FE               [12] 1018 	mov	r6,a
      00B44C AD F0            [24] 1019 	mov	r5,b
      00B44E 90 0D 6F         [24] 1020 	mov	dptr,#_fast_set_leds_PARM_2
      00B451 E0               [24] 1021 	movx	a,@dptr
      00B452 FB               [12] 1022 	mov	r3,a
      00B453 7C 00            [12] 1023 	mov	r4,#0x00
      00B455 C3               [12] 1024 	clr	c
      00B456 EB               [12] 1025 	mov	a,r3
      00B457 9E               [12] 1026 	subb	a,r6
      00B458 EC               [12] 1027 	mov	a,r4
      00B459 9D               [12] 1028 	subb	a,r5
      00B45A 40 13            [24] 1029 	jc	00103$
                                   1030 ;	free result
      00B45C 90 0D 72         [24] 1031 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B45F 12 45 54         [24] 1032 	lcall	_ak820_outline_0092
      00B462 8D 03            [24] 1033 	mov	ar3,r5
      00B464 8E 04            [24] 1034 	mov	ar4,r6
      00B466 C3               [12] 1035 	clr	c
      00B467 EB               [12] 1036 	mov	a,r3
      00B468 94 52            [12] 1037 	subb	a,#0x52
      00B46A EC               [12] 1038 	mov	a,r4
      00B46B 94 00            [12] 1039 	subb	a,#0x00
      00B46D 40 01            [24] 1040 	jc	00104$
      00B46F                       1041 00103$:
      00B46F 22               [24] 1042 	ret
      00B470                       1043 00104$:
                                   1044 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B470 74 52            [12] 1045 	mov	a,#0x52
      00B472 C3               [12] 1046 	clr	c
      00B473 9D               [12] 1047 	subb	a,r5
      00B474 FB               [12] 1048 	mov	r3,a
      00B475 E4               [12] 1049 	clr	a
      00B476 9E               [12] 1050 	subb	a,r6
      00B477 FC               [12] 1051 	mov	r4,a
      00B478 7A 00            [12] 1052 	mov	r2,#0x00
      00B47A C3               [12] 1053 	clr	c
      00B47B EB               [12] 1054 	mov	a,r3
      00B47C 9F               [12] 1055 	subb	a,r7
      00B47D EC               [12] 1056 	mov	a,r4
      00B47E 9A               [12] 1057 	subb	a,r2
      00B47F 50 08            [24] 1058 	jnc	00127$
                                   1059 ;	free result
      00B481 90 0D 74         [24] 1060 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B484 74 52            [12] 1061 	mov	a,#0x52
      00B486 C3               [12] 1062 	clr	c
      00B487 9D               [12] 1063 	subb	a,r5
      00B488 F0               [24] 1064 	movx	@dptr,a
                                   1065 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B489                       1066 00127$:
      00B489 90 0D 74         [24] 1067 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B48C E0               [24] 1068 	movx	a,@dptr
      00B48D FF               [12] 1069 	mov	r7,a
      00B48E 90 0D 72         [24] 1070 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B491 12 45 54         [24] 1071 	lcall	_ak820_outline_0092
      00B494 7C 00            [12] 1072 	mov	r4,#0x00
      00B496                       1073 00110$:
      00B496 C3               [12] 1074 	clr	c
      00B497 EC               [12] 1075 	mov	a,r4
      00B498 9F               [12] 1076 	subb	a,r7
      00B499 40 01            [24] 1077 	jc	00164$
      00B49B 22               [24] 1078 	ret
      00B49C                       1079 00164$:
                                   1080 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B49C C0 07            [24] 1081 	push	ar7
      00B49E 90 0D 8C         [24] 1082 	mov	dptr,#__mulint_PARM_2
      00B4A1 12 45 97         [24] 1083 	lcall	_ak820_outline_0156
      00B4A4 90 00 03         [24] 1084 	mov	dptr,#0x0003
      00B4A7 C0 07            [24] 1085 	push	ar7
      00B4A9 C0 06            [24] 1086 	push	ar6
      00B4AB C0 05            [24] 1087 	push	ar5
      00B4AD C0 04            [24] 1088 	push	ar4
      00B4AF 12 B8 E8         [24] 1089 	lcall	__mulint
      00B4B2 AA 82            [24] 1090 	mov	r2, dpl
      00B4B4 AB 83            [24] 1091 	mov	r3, dph
      00B4B6 D0 04            [24] 1092 	pop	ar4
      00B4B8 D0 05            [24] 1093 	pop	ar5
      00B4BA D0 06            [24] 1094 	pop	ar6
      00B4BC D0 07            [24] 1095 	pop	ar7
      00B4BE 0D               [12] 1096 	inc	r5
      00B4BF BD 00 01         [24] 1097 	cjne	r5,#0x00,00165$
      00B4C2 0E               [12] 1098 	inc	r6
      00B4C3                       1099 00165$:
      00B4C3 EA               [12] 1100 	mov	a,r2
      00B4C4 24 6C            [12] 1101 	add	a, #_g_direct_mode_colors
      00B4C6 FA               [12] 1102 	mov	r2,a
      00B4C7 EB               [12] 1103 	mov	a,r3
      00B4C8 34 0C            [12] 1104 	addc	a, #(_g_direct_mode_colors >> 8)
      00B4CA FB               [12] 1105 	mov	r3,a
                                   1106 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B4CB 8A 4A            [24] 1107 	mov	_fast_set_leds_sloc0_1_0,r2
      00B4CD 8B 4B            [24] 1108 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B4CF 12 B7 62         [24] 1109 	lcall	_ak820_outline_0081
      00B4D2 F8               [12] 1110 	mov	r0,a
      00B4D3 12 B7 70         [24] 1111 	lcall	_ak820_outline_0102
      00B4D6 85 4A 82         [24] 1112 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B4D9 85 4B 83         [24] 1113 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B4DC E8               [12] 1114 	mov	a,r0
      00B4DD F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B4DE 74 01            [12] 1117 	mov	a,#0x01
      00B4E0 2A               [12] 1118 	add	a, r2
      00B4E1 F5 4A            [12] 1119 	mov	_fast_set_leds_sloc0_1_0,a
      00B4E3 E4               [12] 1120 	clr	a
      00B4E4 3B               [12] 1121 	addc	a, r3
      00B4E5 F5 4B            [12] 1122 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B4E7 90 0D 70         [24] 1123 	mov	dptr,#_fast_set_leds_args_10000_282
      00B4EA E0               [24] 1124 	movx	a,@dptr
      00B4EB F8               [12] 1125 	mov	r0,a
      00B4EC A3               [24] 1126 	inc	dptr
      00B4ED E0               [24] 1127 	movx	a,@dptr
      00B4EE FF               [12] 1128 	mov	r7,a
      00B4EF 88 82            [24] 1129 	mov	dpl,r0
      00B4F1 8F 83            [24] 1130 	mov	dph,r7
      00B4F3 E0               [24] 1131 	movx	a,@dptr
      00B4F4 F9               [12] 1132 	mov	r1,a
      00B4F5 90 0D 70         [24] 1133 	mov	dptr,#_fast_set_leds_args_10000_282
      00B4F8 74 01            [12] 1134 	mov	a,#0x01
      00B4FA 28               [12] 1135 	add	a, r0
      00B4FB F0               [24] 1136 	movx	@dptr,a
      00B4FC E4               [12] 1137 	clr	a
      00B4FD 3F               [12] 1138 	addc	a, r7
      00B4FE A3               [24] 1139 	inc	dptr
      00B4FF F0               [24] 1140 	movx	@dptr,a
      00B500 85 4A 82         [24] 1141 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B503 85 4B 83         [24] 1142 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B506 E9               [12] 1143 	mov	a,r1
      00B507 F0               [24] 1144 	movx	@dptr,a
                                   1145 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B508 12 B7 62         [24] 1146 	lcall	_ak820_outline_0081
      00B50B F5 4A            [12] 1147 	mov	_fast_set_leds_sloc0_1_0,a
      00B50D 12 B7 70         [24] 1148 	lcall	_ak820_outline_0102
                                   1149 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B510 74 02            [12] 1150 	mov	a,#0x02
      00B512 2A               [12] 1151 	add	a, r2
      00B513 F5 4C            [12] 1152 	mov	_fast_set_leds_sloc1_1_0,a
      00B515 E4               [12] 1153 	clr	a
      00B516 3B               [12] 1154 	addc	a, r3
      00B517 F5 4D            [12] 1155 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B519 C3               [12] 1156 	clr	c
      00B51A 74 A0            [12] 1157 	mov	a,#0xa0
      00B51C 95 4A            [12] 1158 	subb	a,_fast_set_leds_sloc0_1_0
      00B51E D0 07            [24] 1159 	pop	ar7
      00B520 50 04            [24] 1160 	jnc	00114$
                                   1161 ;	free result
      00B522 7B A0            [12] 1162 	mov	r3,#0xa0
      00B524 80 04            [24] 1163 	sjmp	00115$
      00B526                       1164 00114$:
      00B526 AA 4A            [24] 1165 	mov	r2,_fast_set_leds_sloc0_1_0
      00B528 8A 03            [24] 1166 	mov	ar3,r2
      00B52A                       1167 00115$:
      00B52A 85 4C 82         [24] 1168 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B52D 85 4D 83         [24] 1169 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B530 EB               [12] 1170 	mov	a,r3
      00B531 F0               [24] 1171 	movx	@dptr,a
                                   1172 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B532 0C               [12] 1173 	inc	r4
                                   1174 ;	quantum/vialrgb.c:133: }
      00B533 02 B4 96         [24] 1175 	ljmp	00110$
                                   1176 ;------------------------------------------------------------
                                   1177 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1178 ;------------------------------------------------------------
                                   1179 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1180 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1181 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1182 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1183 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1184 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1185 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1186 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1187 ;------------------------------------------------------------
                                   1188 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1189 ;	-----------------------------------------
                                   1190 ;	 function vialrgb_get_value
                                   1191 ;	-----------------------------------------
      00B536                       1192 _vialrgb_get_value:
      00B536 12 45 1D         [24] 1193 	lcall	_ak820_outline_0036
      00B539 90 0D 76         [24] 1194 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B53C 12 3A 26         [24] 1195 	lcall	_ak820_outline_0015
                                   1196 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B53F 90 0D 75         [24] 1197 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B542 E0               [24] 1198 	movx	a,@dptr
      00B543 FF               [12] 1199 	mov	r7,a
      00B544 BF 20 02         [24] 1200 	cjne	r7,#0x20,00162$
      00B547 80 01            [24] 1201 	sjmp	00102$
      00B549                       1202 00162$:
      00B549 22               [24] 1203 	ret
      00B54A                       1204 00102$:
                                   1205 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B54A 90 0D 76         [24] 1206 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B54D 12 B7 3C         [24] 1207 	lcall	_ak820_outline_0042
                                   1208 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1209 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B550 BA 40 02         [24] 1210 	cjne	r2,#0x40,00163$
      00B553 80 18            [24] 1211 	sjmp	00103$
      00B555                       1212 00163$:
      00B555 BA 41 02         [24] 1213 	cjne	r2,#0x41,00164$
      00B558 80 26            [24] 1214 	sjmp	00104$
      00B55A                       1215 00164$:
      00B55A BA 42 03         [24] 1216 	cjne	r2,#0x42,00165$
      00B55D 02 B6 12         [24] 1217 	ljmp	00105$
      00B560                       1218 00165$:
      00B560 BA 43 03         [24] 1219 	cjne	r2,#0x43,00166$
      00B563 02 B6 1F         [24] 1220 	ljmp	00106$
      00B566                       1221 00166$:
      00B566 BA 44 03         [24] 1222 	cjne	r2,#0x44,00167$
      00B569 02 B6 2B         [24] 1223 	ljmp	00107$
      00B56C                       1224 00167$:
      00B56C 22               [24] 1225 	ret
                                   1226 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B56D                       1227 00103$:
                                   1228 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B56D 12 36 42         [24] 1229 	lcall	_ak820_outline_0121
      00B570 74 01            [12] 1230 	mov	a,#0x01
      00B572 F0               [24] 1231 	movx	@dptr,a
                                   1232 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B573 12 B7 34         [24] 1233 	lcall	_ak820_outline_0034
      00B576 E4               [12] 1234 	clr	a
      00B577 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B578 12 B7 34         [24] 1237 	lcall	_ak820_outline_0034
      00B57B A3               [24] 1238 	inc	dptr
      00B57C 74 A0            [12] 1239 	mov	a,#0xa0
      00B57E F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	quantum/vialrgb.c:147: break;
      00B57F 22               [24] 1242 	ret
                                   1243 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B580                       1244 00104$:
                                   1245 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B580 C0 06            [24] 1246 	push	ar6
      00B582 C0 05            [24] 1247 	push	ar5
      00B584 C0 04            [24] 1248 	push	ar4
      00B586 C0 03            [24] 1249 	push	ar3
      00B588 12 B3 7F         [24] 1250 	lcall	_get_mode
      00B58B A9 82            [24] 1251 	mov	r1, dpl
      00B58D AA 83            [24] 1252 	mov	r2, dph
      00B58F D0 03            [24] 1253 	pop	ar3
      00B591 D0 04            [24] 1254 	pop	ar4
      00B593 D0 05            [24] 1255 	pop	ar5
      00B595 D0 06            [24] 1256 	pop	ar6
                                   1257 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B597 89 00            [24] 1258 	mov	ar0,r1
      00B599 12 36 42         [24] 1259 	lcall	_ak820_outline_0121
      00B59C E8               [12] 1260 	mov	a,r0
      00B59D F0               [24] 1261 	movx	@dptr,a
                                   1262 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B59E 12 B7 34         [24] 1263 	lcall	_ak820_outline_0034
      00B5A1 8A 01            [24] 1264 	mov	ar1,r2
      00B5A3 E9               [12] 1265 	mov	a,r1
      00B5A4 F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B5A5 74 04            [12] 1268 	mov	a,#0x04
      00B5A7 12 8F BB         [24] 1269 	lcall	_ak820_outline_0132
      00B5AA C0 06            [24] 1270 	push	ar6
      00B5AC C0 05            [24] 1271 	push	ar5
      00B5AE C0 02            [24] 1272 	push	ar2
      00B5B0 C0 01            [24] 1273 	push	ar1
      00B5B2 12 56 F2         [24] 1274 	lcall	_rgb_matrix_get_speed
      00B5B5 A8 82            [24] 1275 	mov	r0, dpl
      00B5B7 D0 01            [24] 1276 	pop	ar1
      00B5B9 D0 02            [24] 1277 	pop	ar2
      00B5BB D0 05            [24] 1278 	pop	ar5
      00B5BD D0 06            [24] 1279 	pop	ar6
      00B5BF 12 82 08         [24] 1280 	lcall	_ak820_outline_0063
                                   1281 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B5C2 74 05            [12] 1282 	mov	a,#0x05
      00B5C4 12 8F BB         [24] 1283 	lcall	_ak820_outline_0132
      00B5C7 C0 06            [24] 1284 	push	ar6
      00B5C9 C0 05            [24] 1285 	push	ar5
      00B5CB C0 02            [24] 1286 	push	ar2
      00B5CD C0 01            [24] 1287 	push	ar1
      00B5CF 12 56 DD         [24] 1288 	lcall	_rgb_matrix_get_hue
      00B5D2 A8 82            [24] 1289 	mov	r0, dpl
      00B5D4 D0 01            [24] 1290 	pop	ar1
      00B5D6 D0 02            [24] 1291 	pop	ar2
      00B5D8 D0 05            [24] 1292 	pop	ar5
      00B5DA D0 06            [24] 1293 	pop	ar6
      00B5DC 12 82 08         [24] 1294 	lcall	_ak820_outline_0063
                                   1295 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B5DF 74 06            [12] 1296 	mov	a,#0x06
      00B5E1 12 8F BB         [24] 1297 	lcall	_ak820_outline_0132
      00B5E4 C0 06            [24] 1298 	push	ar6
      00B5E6 C0 05            [24] 1299 	push	ar5
      00B5E8 C0 02            [24] 1300 	push	ar2
      00B5EA C0 01            [24] 1301 	push	ar1
      00B5EC 12 56 E4         [24] 1302 	lcall	_rgb_matrix_get_sat
      00B5EF A8 82            [24] 1303 	mov	r0, dpl
      00B5F1 D0 01            [24] 1304 	pop	ar1
      00B5F3 D0 02            [24] 1305 	pop	ar2
      00B5F5 D0 05            [24] 1306 	pop	ar5
      00B5F7 D0 06            [24] 1307 	pop	ar6
      00B5F9 12 82 08         [24] 1308 	lcall	_ak820_outline_0063
                                   1309 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B5FC 74 07            [12] 1310 	mov	a,#0x07
      00B5FE 12 8F BB         [24] 1311 	lcall	_ak820_outline_0132
      00B601 C0 02            [24] 1312 	push	ar2
      00B603 C0 01            [24] 1313 	push	ar1
      00B605 12 56 EB         [24] 1314 	lcall	_rgb_matrix_get_val
      00B608 A8 82            [24] 1315 	mov	r0, dpl
      00B60A D0 01            [24] 1316 	pop	ar1
      00B60C D0 02            [24] 1317 	pop	ar2
      00B60E 12 82 08         [24] 1318 	lcall	_ak820_outline_0063
                                   1319 ;	quantum/vialrgb.c:156: break;
      00B611 22               [24] 1320 	ret
                                   1321 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B612                       1322 00105$:
                                   1323 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B612 EF               [12] 1324 	mov	a,r7
      00B613 24 FE            [12] 1325 	add	a,#0xfe
      00B615 90 0D 62         [24] 1326 	mov	dptr,#_get_supported_PARM_2
      00B618 F0               [24] 1327 	movx	@dptr,a
      00B619 12 36 42         [24] 1328 	lcall	_ak820_outline_0121
                                   1329 ;	quantum/vialrgb.c:160: break;
      00B61C 02 B2 88         [24] 1330 	ljmp	_get_supported
                                   1331 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B61F                       1332 00106$:
                                   1333 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B61F 12 36 42         [24] 1334 	lcall	_ak820_outline_0121
      00B622 74 52            [12] 1335 	mov	a,#0x52
      00B624 F0               [24] 1336 	movx	@dptr,a
                                   1337 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B625 12 B7 34         [24] 1338 	lcall	_ak820_outline_0034
      00B628 E4               [12] 1339 	clr	a
      00B629 F0               [24] 1340 	movx	@dptr,a
                                   1341 ;	quantum/vialrgb.c:166: break;
      00B62A 22               [24] 1342 	ret
                                   1343 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00B62B                       1344 00107$:
                                   1345 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B62B 12 36 42         [24] 1346 	lcall	_ak820_outline_0121
      00B62E E0               [24] 1347 	movx	a,@dptr
      00B62F FF               [12] 1348 	mov	r7,a
      00B630 7A 00            [12] 1349 	mov	r2,#0x00
      00B632 74 03            [12] 1350 	mov	a,#0x03
      00B634 2D               [12] 1351 	add	a, r5
      00B635 F8               [12] 1352 	mov	r0,a
      00B636 E4               [12] 1353 	clr	a
      00B637 3E               [12] 1354 	addc	a, r6
      00B638 F9               [12] 1355 	mov	r1,a
      00B639 C0 03            [24] 1356 	push	ar3
      00B63B C0 04            [24] 1357 	push	ar4
      00B63D 12 3A B6         [24] 1358 	lcall	_ak820_outline_0151
      00B640 E0               [24] 1359 	movx	a,@dptr
      00B641 FB               [12] 1360 	mov	r3,a
      00B642 E4               [12] 1361 	clr	a
      00B643 4F               [12] 1362 	orl	a,r7
      00B644 F5 4E            [12] 1363 	mov	_vialrgb_get_value_sloc0_1_0,a
      00B646 EB               [12] 1364 	mov	a,r3
      00B647 4A               [12] 1365 	orl	a,r2
      00B648 F5 4F            [12] 1366 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1367 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00B64A AC 4E            [24] 1368 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00B64C AF 4F            [24] 1369 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B64E C3               [12] 1370 	clr	c
      00B64F EC               [12] 1371 	mov	a,r4
      00B650 94 52            [12] 1372 	subb	a,#0x52
      00B652 EF               [12] 1373 	mov	a,r7
      00B653 94 00            [12] 1374 	subb	a,#0x00
      00B655 D0 04            [24] 1375 	pop	ar4
      00B657 D0 03            [24] 1376 	pop	ar3
      00B659 40 01            [24] 1377 	jc	00109$
      00B65B 22               [24] 1378 	ret
      00B65C                       1379 00109$:
                                   1380 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00B65C E5 4E            [12] 1381 	mov	a,_vialrgb_get_value_sloc0_1_0
      00B65E 25 4E            [12] 1382 	add	a,_vialrgb_get_value_sloc0_1_0
      00B660 FA               [12] 1383 	mov	r2,a
      00B661 E5 4F            [12] 1384 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B663 33               [12] 1385 	rlc	a
      00B664 FF               [12] 1386 	mov	r7,a
      00B665 EA               [12] 1387 	mov	a,r2
      00B666 24 F2            [12] 1388 	add	a, #_ak820_led_points
      00B668 F5 50            [12] 1389 	mov	_vialrgb_get_value_sloc1_1_0,a
      00B66A EF               [12] 1390 	mov	a,r7
      00B66B 34 BB            [12] 1391 	addc	a, #(_ak820_led_points >> 8)
      00B66D F5 51            [12] 1392 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00B66F 85 50 82         [24] 1393 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B672 85 51 83         [24] 1394 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B675 E4               [12] 1395 	clr	a
      00B676 93               [24] 1396 	movc	a,@a+dptr
      00B677 12 36 42         [24] 1397 	lcall	_ak820_outline_0121
      00B67A F0               [24] 1398 	movx	@dptr,a
                                   1399 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00B67B 85 50 82         [24] 1400 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B67E 85 51 83         [24] 1401 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B681 A3               [24] 1402 	inc	dptr
      00B682 E4               [12] 1403 	clr	a
      00B683 93               [24] 1404 	movc	a,@a+dptr
      00B684 12 3A B6         [24] 1405 	lcall	_ak820_outline_0151
      00B687 F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00B688 12 B7 34         [24] 1408 	lcall	_ak820_outline_0034
      00B68B A3               [24] 1409 	inc	dptr
      00B68C 74 04            [12] 1410 	mov	a,#0x04
      00B68E F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00B68F 90 0D 6B         [24] 1413 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B692 04               [12] 1414 	inc	a
      00B693 2D               [12] 1415 	add	a, r5
      00B694 F0               [24] 1416 	movx	@dptr,a
      00B695 E4               [12] 1417 	clr	a
      00B696 3E               [12] 1418 	addc	a, r6
      00B697 A3               [24] 1419 	inc	dptr
      00B698 F0               [24] 1420 	movx	@dptr,a
      00B699 85 4E 82         [24] 1421 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00B69C 85 4F 83         [24] 1422 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1423 ;	quantum/vialrgb.c:187: }
                                   1424 ;	quantum/vialrgb.c:188: }
      00B69F 02 B3 C2         [24] 1425 	ljmp	_get_matrix_pos_for_led
                                   1426 ;------------------------------------------------------------
                                   1427 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1428 ;------------------------------------------------------------
                                   1429 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1430 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1431 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1432 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1433 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1434 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1435 ;------------------------------------------------------------
                                   1436 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1437 ;	-----------------------------------------
                                   1438 ;	 function vialrgb_set_value
                                   1439 ;	-----------------------------------------
      00B6A2                       1440 _vialrgb_set_value:
      00B6A2 12 45 1D         [24] 1441 	lcall	_ak820_outline_0036
      00B6A5 90 0D 7A         [24] 1442 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B6A8 12 3A 26         [24] 1443 	lcall	_ak820_outline_0015
                                   1444 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00B6AB 90 0D 79         [24] 1445 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B6AE E0               [24] 1446 	movx	a,@dptr
      00B6AF FF               [12] 1447 	mov	r7,a
      00B6B0 BF 20 02         [24] 1448 	cjne	r7,#0x20,00129$
      00B6B3 80 01            [24] 1449 	sjmp	00102$
      00B6B5                       1450 00129$:
      00B6B5 22               [24] 1451 	ret
      00B6B6                       1452 00102$:
                                   1453 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B6B6 90 0D 7A         [24] 1454 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B6B9 12 B7 3C         [24] 1455 	lcall	_ak820_outline_0042
                                   1456 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1457 ;	quantum/vialrgb.c:196: switch (cmd) {
      00B6BC BA 41 02         [24] 1458 	cjne	r2,#0x41,00130$
      00B6BF 80 06            [24] 1459 	sjmp	00103$
      00B6C1                       1460 00130$:
      00B6C1 BA 42 02         [24] 1461 	cjne	r2,#0x42,00131$
      00B6C4 80 5E            [24] 1462 	sjmp	00104$
      00B6C6                       1463 00131$:
      00B6C6 22               [24] 1464 	ret
                                   1465 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00B6C7                       1466 00103$:
                                   1467 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00B6C7 12 36 42         [24] 1468 	lcall	_ak820_outline_0121
      00B6CA E0               [24] 1469 	movx	a,@dptr
      00B6CB FA               [12] 1470 	mov	r2,a
      00B6CC 12 B7 34         [24] 1471 	lcall	_ak820_outline_0034
      00B6CF E0               [24] 1472 	movx	a,@dptr
      00B6D0 F8               [12] 1473 	mov	r0,a
      00B6D1 79 00            [12] 1474 	mov	r1,#0x00
      00B6D3 88 53            [24] 1475 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00B6D5 89 52            [24] 1476 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00B6D7 8A 01            [24] 1477 	mov	ar1,r2
      00B6D9 7A 00            [12] 1478 	mov	r2,#0x00
      00B6DB E5 53            [12] 1479 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00B6DD 42 02            [12] 1480 	orl	ar2,a
                                   1481 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00B6DF 12 45 9D         [24] 1482 	lcall	_ak820_outline_0178
      00B6E2 C0 06            [24] 1483 	push	ar6
      00B6E4 C0 05            [24] 1484 	push	ar5
      00B6E6 12 B3 94         [24] 1485 	lcall	_set_mode
      00B6E9 D0 05            [24] 1486 	pop	ar5
      00B6EB D0 06            [24] 1487 	pop	ar6
                                   1488 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00B6ED 12 B7 34         [24] 1489 	lcall	_ak820_outline_0034
      00B6F0 A3               [24] 1490 	inc	dptr
      00B6F1 E0               [24] 1491 	movx	a,@dptr
      00B6F2 F5 82            [12] 1492 	mov	dpl,a
      00B6F4 C0 06            [24] 1493 	push	ar6
      00B6F6 C0 05            [24] 1494 	push	ar5
      00B6F8 12 57 C0         [24] 1495 	lcall	_rgb_matrix_set_speed_noeeprom
      00B6FB D0 05            [24] 1496 	pop	ar5
      00B6FD D0 06            [24] 1497 	pop	ar6
                                   1498 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00B6FF 12 B7 34         [24] 1499 	lcall	_ak820_outline_0034
      00B702 A3               [24] 1500 	inc	dptr
      00B703 A3               [24] 1501 	inc	dptr
      00B704 E0               [24] 1502 	movx	a,@dptr
      00B705 F9               [12] 1503 	mov	r1,a
      00B706 7A 00            [12] 1504 	mov	r2,#0x00
      00B708 74 06            [12] 1505 	mov	a,#0x06
      00B70A 12 B7 86         [24] 1506 	lcall	_ak820_outline_0168
      00B70D F8               [12] 1507 	mov	r0,a
      00B70E 74 07            [12] 1508 	mov	a,#0x07
      00B710 12 B7 86         [24] 1509 	lcall	_ak820_outline_0168
      00B713 FE               [12] 1510 	mov	r6,a
      00B714 90 07 3C         [24] 1511 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00B717 E8               [12] 1512 	mov	a,r0
      00B718 F0               [24] 1513 	movx	@dptr,a
      00B719 90 07 3D         [24] 1514 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00B71C EE               [12] 1515 	mov	a,r6
      00B71D F0               [24] 1516 	movx	@dptr,a
      00B71E 12 45 9D         [24] 1517 	lcall	_ak820_outline_0178
                                   1518 ;	quantum/vialrgb.c:202: break;
                                   1519 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00B721 02 57 91         [24] 1520 	ljmp	_rgb_matrix_sethsv_noeeprom
      00B724                       1521 00104$:
                                   1522 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00B724 EF               [12] 1523 	mov	a,r7
      00B725 24 FE            [12] 1524 	add	a,#0xfe
      00B727 90 0D 6F         [24] 1525 	mov	dptr,#_fast_set_leds_PARM_2
      00B72A F0               [24] 1526 	movx	@dptr,a
      00B72B 12 36 42         [24] 1527 	lcall	_ak820_outline_0121
                                   1528 ;	quantum/vialrgb.c:210: }
                                   1529 ;	quantum/vialrgb.c:211: }
      00B72E 02 B3 F5         [24] 1530 	ljmp	_fast_set_leds
                                   1531 ;------------------------------------------------------------
                                   1532 ;Allocation info for local variables in function 'vialrgb_save'
                                   1533 ;------------------------------------------------------------
                                   1534 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1535 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1536 ;------------------------------------------------------------
                                   1537 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1538 ;	-----------------------------------------
                                   1539 ;	 function vialrgb_save
                                   1540 ;	-----------------------------------------
      00B731                       1541 _vialrgb_save:
                                   1542 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1543 ;	quantum/vialrgb.c:218: }
      00B731 02 52 17         [24] 1544 	ljmp	_eeconfig_update_rgb_matrix
                                   1545 	.area CSEG    (CODE)
                                   1546 	.area CONST   (CODE)
                                   1547 	.area CONST   (CODE)
      00BF31                       1548 _supported_modes:
      00BF31 00                    1549 	.db #0x00	; 0
      00BF32 00                    1550 	.db #0x00	; 0
      00BF33 01                    1551 	.db #0x01	; 1
      00BF34 05                    1552 	.db #0x05	; 5
      00BF35 02                    1553 	.db #0x02	; 2
      00BF36 01                    1554 	.db #0x01	; 1
      00BF37 06                    1555 	.db #0x06	; 6
      00BF38 02                    1556 	.db #0x02	; 2
      00BF39 0D                    1557 	.db #0x0d	; 13
      00BF3A 03                    1558 	.db #0x03	; 3
      00BF3B 0E                    1559 	.db #0x0e	; 14
      00BF3C 04                    1560 	.db #0x04	; 4
      00BF3D 1F                    1561 	.db #0x1f	; 31
      00BF3E 06                    1562 	.db #0x06	; 6
                                   1563 	.area CSEG    (CODE)
                                   1564 	.area XINIT   (CODE)
                                   1565 	.area CABS    (ABS,CODE)
                                   1566 
                                   1567 ; Experimental exact instruction outlining.
                                   1568 	.globl _ak820_outline_0004
                                   1569 	.globl _ak820_outline_0015
                                   1570 	.globl _ak820_outline_0030
                                   1571 	.globl _ak820_outline_0034
                                   1572 	.globl _ak820_outline_0035
                                   1573 	.globl _ak820_outline_0036
                                   1574 	.globl _ak820_outline_0042
                                   1575 	.globl _ak820_outline_0044
                                   1576 	.globl _ak820_outline_0050
                                   1577 	.globl _ak820_outline_0063
                                   1578 	.globl _ak820_outline_0074
                                   1579 	.globl _ak820_outline_0076
                                   1580 	.globl _ak820_outline_0081
                                   1581 	.globl _ak820_outline_0092
                                   1582 	.globl _ak820_outline_0102
                                   1583 	.globl _ak820_outline_0103
                                   1584 	.globl _ak820_outline_0104
                                   1585 	.globl _ak820_outline_0105
                                   1586 	.globl _ak820_outline_0108
                                   1587 	.globl _ak820_outline_0116
                                   1588 	.globl _ak820_outline_0118
                                   1589 	.globl _ak820_outline_0120
                                   1590 	.globl _ak820_outline_0121
                                   1591 	.globl _ak820_outline_0131
                                   1592 	.globl _ak820_outline_0132
                                   1593 	.globl _ak820_outline_0138
                                   1594 	.globl _ak820_outline_0140
                                   1595 	.globl _ak820_outline_0151
                                   1596 	.globl _ak820_outline_0156
                                   1597 	.globl _ak820_outline_0168
                                   1598 	.globl _ak820_outline_0178
                                   1599 	.globl _ak820_outline_0182
                                   1600 
                                   1601 	.area CSEG (CODE)
                                   1602 ; function ak820_outline_0034
      00B734                       1603 _ak820_outline_0034:
      00B734 8D 82            [24] 1604 	mov	dpl,r5
      00B736 8E 83            [24] 1605 	mov	dph,r6
      00B738 A3               [24] 1606 	inc	dptr
      00B739 A3               [24] 1607 	inc	dptr
      00B73A A3               [24] 1608 	inc	dptr
      00B73B 22               [24] 1609 	ret
                                   1610 
                                   1611 	.area CSEG (CODE)
                                   1612 ; function ak820_outline_0042
      00B73C                       1613 _ak820_outline_0042:
      00B73C E0               [24] 1614 	movx	a,@dptr
      00B73D FD               [12] 1615 	mov	r5,a
      00B73E A3               [24] 1616 	inc	dptr
      00B73F E0               [24] 1617 	movx	a,@dptr
      00B740 FE               [12] 1618 	mov	r6,a
      00B741 74 02            [12] 1619 	mov	a,#0x02
      00B743 2D               [12] 1620 	add	a,r5
      00B744 FB               [12] 1621 	mov	r3,a
      00B745 E4               [12] 1622 	clr	a
      00B746 3E               [12] 1623 	addc	a,r6
      00B747 FC               [12] 1624 	mov	r4,a
      00B748 8D 82            [24] 1625 	mov	dpl,r5
      00B74A 8E 83            [24] 1626 	mov	dph,r6
      00B74C A3               [24] 1627 	inc	dptr
      00B74D E0               [24] 1628 	movx	a,@dptr
      00B74E FA               [12] 1629 	mov	r2,a
      00B74F 22               [24] 1630 	ret
                                   1631 
                                   1632 	.area CSEG (CODE)
                                   1633 ; function ak820_outline_0044
      00B750                       1634 _ak820_outline_0044:
      00B750 ED               [12] 1635 	mov	a,r5
      00B751 75 F0 02         [24] 1636 	mov	b,#0x02
      00B754 A4               [48] 1637 	mul	ab
      00B755 24 31            [12] 1638 	add	a,#_supported_modes
      00B757 FB               [12] 1639 	mov	r3,a
      00B758 74 BF            [12] 1640 	mov	a,#(_supported_modes>>8)
      00B75A 35 F0            [12] 1641 	addc	a,b
      00B75C FC               [12] 1642 	mov	r4,a
      00B75D 8B 82            [24] 1643 	mov	dpl,r3
      00B75F 8C 83            [24] 1644 	mov	dph,r4
      00B761 22               [24] 1645 	ret
                                   1646 
                                   1647 	.area CSEG (CODE)
                                   1648 ; function ak820_outline_0081
      00B762                       1649 _ak820_outline_0081:
      00B762 90 0D 70         [24] 1650 	mov	dptr,#_fast_set_leds_args_10000_282
      00B765 E0               [24] 1651 	movx	a,@dptr
      00B766 F9               [12] 1652 	mov	r1,a
      00B767 A3               [24] 1653 	inc	dptr
      00B768 E0               [24] 1654 	movx	a,@dptr
      00B769 FF               [12] 1655 	mov	r7,a
      00B76A 89 82            [24] 1656 	mov	dpl,r1
      00B76C 8F 83            [24] 1657 	mov	dph,r7
      00B76E E0               [24] 1658 	movx	a,@dptr
      00B76F 22               [24] 1659 	ret
                                   1660 
                                   1661 	.area CSEG (CODE)
                                   1662 ; function ak820_outline_0102
      00B770                       1663 _ak820_outline_0102:
      00B770 90 0D 70         [24] 1664 	mov	dptr,#_fast_set_leds_args_10000_282
      00B773 74 01            [12] 1665 	mov	a,#0x01
      00B775 29               [12] 1666 	add	a,r1
      00B776 F0               [24] 1667 	movx	@dptr,a
      00B777 E4               [12] 1668 	clr	a
      00B778 3F               [12] 1669 	addc	a,r7
      00B779 A3               [24] 1670 	inc	dptr
      00B77A F0               [24] 1671 	movx	@dptr,a
      00B77B 22               [24] 1672 	ret
                                   1673 
                                   1674 	.area CSEG (CODE)
                                   1675 ; function ak820_outline_0140
      00B77C                       1676 _ak820_outline_0140:
      00B77C E4               [12] 1677 	clr	a
      00B77D 93               [24] 1678 	movc	a,@a+dptr
      00B77E FC               [12] 1679 	mov	r4,a
      00B77F 7B 00            [12] 1680 	mov	r3,#0x00
      00B781 8C 82            [24] 1681 	mov	dpl,r4
      00B783 8B 83            [24] 1682 	mov	dph,r3
      00B785 22               [24] 1683 	ret
                                   1684 
                                   1685 	.area CSEG (CODE)
                                   1686 ; function ak820_outline_0168
      00B786                       1687 _ak820_outline_0168:
      00B786 2D               [12] 1688 	add	a,r5
      00B787 F5 82            [12] 1689 	mov	dpl,a
      00B789 E4               [12] 1690 	clr	a
      00B78A 3E               [12] 1691 	addc	a,r6
      00B78B F5 83            [12] 1692 	mov	dph,a
      00B78D E0               [24] 1693 	movx	a,@dptr
      00B78E 22               [24] 1694 	ret
