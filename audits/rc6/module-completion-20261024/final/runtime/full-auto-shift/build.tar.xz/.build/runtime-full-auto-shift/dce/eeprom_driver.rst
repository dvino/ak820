                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00068B                         85 _eeprom_read_word_addr_10000_91:
      00068B                         86 	.ds 3
      00068E                         87 _eeprom_read_word_ret_10000_92:
      00068E                         88 	.ds 2
      000690                         89 _eeprom_read_dword_addr_10000_93:
      000690                         90 	.ds 3
      000693                         91 _eeprom_read_dword_ret_10000_94:
      000693                         92 	.ds 4
      000697                         93 _eeprom_write_byte_PARM_2:
      000697                         94 	.ds 1
      000698                         95 _eeprom_write_byte_addr_10000_95:
      000698                         96 	.ds 3
      00069B                         97 _eeprom_write_word_PARM_2:
      00069B                         98 	.ds 2
      00069D                         99 _eeprom_write_word_addr_10000_97:
      00069D                        100 	.ds 3
      0006A0                        101 _eeprom_write_dword_PARM_2:
      0006A0                        102 	.ds 4
      0006A4                        103 _eeprom_write_dword_addr_10000_99:
      0006A4                        104 	.ds 3
      0006A7                        105 _eeprom_update_byte_PARM_2:
      0006A7                        106 	.ds 1
      0006A8                        107 _eeprom_update_byte_addr_10000_107:
      0006A8                        108 	.ds 3
      0006AB                        109 _eeprom_update_word_PARM_2:
      0006AB                        110 	.ds 2
      0006AD                        111 _eeprom_update_word_addr_10000_111:
      0006AD                        112 	.ds 3
      0006B0                        113 _eeprom_update_dword_PARM_2:
      0006B0                        114 	.ds 4
      0006B4                        115 _eeprom_update_dword_addr_10000_115:
      0006B4                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004F1A                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004F1A 12 45 1D         [24]  170 	lcall	_ak820_outline_0036
      004F1D 90 06 8B         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004F20 12 3A 26         [24]  172 	lcall	_ak820_outline_0015
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004F23 90 06 8E         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004F26 12 51 26         [24]  175 	lcall	_ak820_outline_0165
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004F29 90 06 8B         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004F2C 12 50 D4         [24]  178 	lcall	_ak820_outline_0021
      004F2F 90 05 91         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004F32 ED               [12]  180 	mov	a,r5
      004F33 12 3A 26         [24]  181 	lcall	_ak820_outline_0015
      004F36 90 05 94         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004F39 12 51 18         [24]  183 	lcall	_ak820_outline_0106
      004F3C 90 06 8E         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004F3F 12 42 B9         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004F42 90 06 8E         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004F45 12 51 0F         [24]  188 	lcall	_ak820_outline_0088
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004F48 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004F49                        201 _eeprom_read_dword:
      004F49 12 45 1D         [24]  202 	lcall	_ak820_outline_0036
      004F4C 90 06 90         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004F4F 12 3A 26         [24]  204 	lcall	_ak820_outline_0015
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004F52 90 06 93         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004F55 12 50 E4         [24]  207 	lcall	_ak820_outline_0048
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004F58 90 06 90         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004F5B 12 50 D4         [24]  210 	lcall	_ak820_outline_0021
      004F5E 90 05 91         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004F61 ED               [12]  212 	mov	a,r5
      004F62 12 3A 26         [24]  213 	lcall	_ak820_outline_0015
      004F65 90 05 94         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004F68 74 04            [12]  215 	mov	a,#0x04
      004F6A 12 3A A6         [24]  216 	lcall	_ak820_outline_0122
      004F6D 90 06 93         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004F70 12 42 B9         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004F73 90 06 93         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004F76 12 50 ED         [24]  221 	lcall	_ak820_outline_0053
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004F79 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004F7A                        234 _eeprom_write_byte:
      004F7A 12 45 1D         [24]  235 	lcall	_ak820_outline_0036
      004F7D 90 06 98         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004F80 12 3A 26         [24]  237 	lcall	_ak820_outline_0015
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004F83 90 06 98         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004F86 12 50 AE         [24]  240 	lcall	_ak820_outline_0002
      004F89 74 01            [12]  241 	mov	a,#0x01
      004F8B 12 3A A6         [24]  242 	lcall	_ak820_outline_0122
      004F8E 90 06 97         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004F91 02 43 45         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004F94                        256 _eeprom_write_word:
      004F94 12 45 1D         [24]  257 	lcall	_ak820_outline_0036
      004F97 90 06 9D         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004F9A 12 3A 26         [24]  259 	lcall	_ak820_outline_0015
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004F9D 90 06 9D         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004FA0 12 50 AE         [24]  262 	lcall	_ak820_outline_0002
      004FA3 12 51 18         [24]  263 	lcall	_ak820_outline_0106
      004FA6 90 06 9B         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004FA9 02 43 45         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004FAC                        277 _eeprom_write_dword:
      004FAC 12 45 1D         [24]  278 	lcall	_ak820_outline_0036
      004FAF 90 06 A4         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004FB2 12 3A 26         [24]  280 	lcall	_ak820_outline_0015
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004FB5 90 06 A4         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004FB8 12 50 AE         [24]  283 	lcall	_ak820_outline_0002
      004FBB 74 04            [12]  284 	mov	a,#0x04
      004FBD 12 3A A6         [24]  285 	lcall	_ak820_outline_0122
      004FC0 90 06 A0         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004FC3 02 43 45         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004FC6                        307 _eeprom_update_byte:
      004FC6 C0 07            [24]  308 	push	ar7
      004FC8 C0 06            [24]  309 	push	ar6
      004FCA C0 05            [24]  310 	push	ar5
      004FCC C0 04            [24]  311 	push	ar4
      004FCE 12 45 1D         [24]  312 	lcall	_ak820_outline_0036
      004FD1 90 06 A8         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004FD4 12 3A 26         [24]  314 	lcall	_ak820_outline_0015
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004FD7 90 06 A8         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004FDA 12 50 C5         [24]  317 	lcall	_ak820_outline_0003
      004FDD 12 42 7E         [24]  318 	lcall	_eeprom_read_byte
      004FE0 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004FE2 90 06 A7         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004FE5 E0               [24]  322 	movx	a,@dptr
      004FE6 FE               [12]  323 	mov	r6,a
      004FE7 EF               [12]  324 	mov	a,r7
      004FE8 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004FEB 80 36            [24]  326 	sjmp	00103$
      004FED                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004FED 90 06 A8         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004FF0 12 3A 66         [24]  330 	lcall	_ak820_outline_0059
      004FF3 A3               [24]  331 	inc	dptr
      004FF4 E0               [24]  332 	movx	a,@dptr
      004FF5 FF               [12]  333 	mov	r7,a
      004FF6 90 06 97         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004FF9 EE               [12]  335 	mov	a,r6
      004FFA F0               [24]  336 	movx	@dptr,a
      004FFB 12 3A 9B         [24]  337 	lcall	_ak820_outline_0117
      004FFE 8F F0            [24]  338 	mov	b, r7
      005000 C0 07            [24]  339 	push	ar7
      005002 C0 06            [24]  340 	push	ar6
      005004 C0 05            [24]  341 	push	ar5
      005006 C0 04            [24]  342 	push	ar4
      005008 C0 03            [24]  343 	push	ar3
      00500A C0 02            [24]  344 	push	ar2
      00500C C0 01            [24]  345 	push	ar1
      00500E C0 00            [24]  346 	push	ar0
      005010 12 4F 7A         [24]  347 	lcall	_eeprom_write_byte
      005013 D0 00            [24]  348 	pop	ar0
      005015 D0 01            [24]  349 	pop	ar1
      005017 D0 02            [24]  350 	pop	ar2
      005019 D0 03            [24]  351 	pop	ar3
      00501B D0 04            [24]  352 	pop	ar4
      00501D D0 05            [24]  353 	pop	ar5
      00501F D0 06            [24]  354 	pop	ar6
      005021 D0 07            [24]  355 	pop	ar7
      005023                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      005023 D0 04            [24]  358 	pop	ar4
      005025 D0 05            [24]  359 	pop	ar5
      005027 D0 06            [24]  360 	pop	ar6
      005029 D0 07            [24]  361 	pop	ar7
      00502B 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      00502C                        374 _eeprom_update_word:
      00502C 12 45 1D         [24]  375 	lcall	_ak820_outline_0036
      00502F 90 06 AD         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005032 12 3A 26         [24]  377 	lcall	_ak820_outline_0015
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      005035 90 06 AD         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005038 12 50 C5         [24]  380 	lcall	_ak820_outline_0003
      00503B 12 4F 1A         [24]  381 	lcall	_eeprom_read_word
      00503E 12 45 71         [24]  382 	lcall	_ak820_outline_0130
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      005041 90 06 AB         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      005044 12 3A 66         [24]  385 	lcall	_ak820_outline_0059
      005047 EE               [12]  386 	mov	a,r6
      005048 B5 04 05         [24]  387 	cjne	a,ar4,00112$
      00504B EF               [12]  388 	mov	a,r7
      00504C B5 05 01         [24]  389 	cjne	a,ar5,00112$
      00504F 22               [24]  390 	ret
      005050                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      005050 90 06 AD         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005053 E0               [24]  394 	movx	a,@dptr
      005054 FB               [12]  395 	mov	r3,a
      005055 A3               [24]  396 	inc	dptr
      005056 12 3A 47         [24]  397 	lcall	_ak820_outline_0050
      005059 90 06 9B         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      00505C 12 3A 6C         [24]  399 	lcall	_ak820_outline_0070
      00505F 8B 82            [24]  400 	mov	dpl, r3
      005061 8E 83            [24]  401 	mov	dph, r6
      005063 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      005065 02 4F 94         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      005068                        416 _eeprom_update_dword:
      005068 12 45 1D         [24]  417 	lcall	_ak820_outline_0036
      00506B 90 06 B4         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00506E 12 3A 26         [24]  419 	lcall	_ak820_outline_0015
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      005071 90 06 B4         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005074 12 50 C5         [24]  422 	lcall	_ak820_outline_0003
      005077 12 4F 49         [24]  423 	lcall	_eeprom_read_dword
      00507A 12 50 FE         [24]  424 	lcall	_ak820_outline_0056
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      00507D 90 06 B0         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      005080 E0               [24]  427 	movx	a,@dptr
      005081 F8               [12]  428 	mov	r0,a
      005082 A3               [24]  429 	inc	dptr
      005083 12 51 06         [24]  430 	lcall	_ak820_outline_0087
      005086 EC               [12]  431 	mov	a,r4
      005087 B5 00 0D         [24]  432 	cjne	a,ar0,00112$
      00508A ED               [12]  433 	mov	a,r5
      00508B B5 01 09         [24]  434 	cjne	a,ar1,00112$
      00508E EE               [12]  435 	mov	a,r6
      00508F B5 02 05         [24]  436 	cjne	a,ar2,00112$
      005092 EF               [12]  437 	mov	a,r7
      005093 B5 03 01         [24]  438 	cjne	a,ar3,00112$
      005096 22               [24]  439 	ret
      005097                        440 00112$:
                                    441 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      005097 90 06 B4         [24]  442 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00509A 12 50 D4         [24]  443 	lcall	_ak820_outline_0021
      00509D 90 06 A0         [24]  444 	mov	dptr,#_eeprom_write_dword_PARM_2
      0050A0 E8               [12]  445 	mov	a,r0
      0050A1 F0               [24]  446 	movx	@dptr,a
      0050A2 E9               [12]  447 	mov	a,r1
      0050A3 A3               [24]  448 	inc	dptr
      0050A4 12 51 1F         [24]  449 	lcall	_ak820_outline_0150
      0050A7 F0               [24]  450 	movx	@dptr,a
      0050A8 12 50 DD         [24]  451 	lcall	_ak820_outline_0043
                                    452 ;	drivers/eeprom/eeprom_driver.c:101: }
      0050AB 02 4F AC         [24]  453 	ljmp	_eeprom_write_dword
                                    454 	.area CSEG    (CODE)
                                    455 	.area CONST   (CODE)
                                    456 	.area XINIT   (CODE)
                                    457 	.area CABS    (ABS,CODE)
                                    458 
                                    459 ; Experimental exact instruction outlining.
                                    460 	.globl _ak820_outline_0002
                                    461 	.globl _ak820_outline_0003
                                    462 	.globl _ak820_outline_0015
                                    463 	.globl _ak820_outline_0021
                                    464 	.globl _ak820_outline_0036
                                    465 	.globl _ak820_outline_0043
                                    466 	.globl _ak820_outline_0048
                                    467 	.globl _ak820_outline_0050
                                    468 	.globl _ak820_outline_0053
                                    469 	.globl _ak820_outline_0056
                                    470 	.globl _ak820_outline_0059
                                    471 	.globl _ak820_outline_0070
                                    472 	.globl _ak820_outline_0087
                                    473 	.globl _ak820_outline_0088
                                    474 	.globl _ak820_outline_0106
                                    475 	.globl _ak820_outline_0117
                                    476 	.globl _ak820_outline_0122
                                    477 	.globl _ak820_outline_0130
                                    478 	.globl _ak820_outline_0150
                                    479 	.globl _ak820_outline_0165
                                    480 
                                    481 	.area CSEG (CODE)
                                    482 ; function ak820_outline_0002
      0050AE                        483 _ak820_outline_0002:
      0050AE E0               [24]  484 	movx	a,@dptr
      0050AF FD               [12]  485 	mov	r5,a
      0050B0 A3               [24]  486 	inc	dptr
      0050B1 E0               [24]  487 	movx	a,@dptr
      0050B2 FE               [12]  488 	mov	r6,a
      0050B3 A3               [24]  489 	inc	dptr
      0050B4 E0               [24]  490 	movx	a,@dptr
      0050B5 FF               [12]  491 	mov	r7,a
      0050B6 90 05 9A         [24]  492 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0050B9 ED               [12]  493 	mov	a,r5
      0050BA F0               [24]  494 	movx	@dptr,a
      0050BB EE               [12]  495 	mov	a,r6
      0050BC A3               [24]  496 	inc	dptr
      0050BD F0               [24]  497 	movx	@dptr,a
      0050BE EF               [12]  498 	mov	a,r7
      0050BF A3               [24]  499 	inc	dptr
      0050C0 F0               [24]  500 	movx	@dptr,a
      0050C1 90 05 9D         [24]  501 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0050C4 22               [24]  502 	ret
                                    503 
                                    504 	.area CSEG (CODE)
                                    505 ; function ak820_outline_0003
      0050C5                        506 _ak820_outline_0003:
      0050C5 E0               [24]  507 	movx	a,@dptr
      0050C6 FD               [12]  508 	mov	r5,a
      0050C7 A3               [24]  509 	inc	dptr
      0050C8 E0               [24]  510 	movx	a,@dptr
      0050C9 FE               [12]  511 	mov	r6,a
      0050CA A3               [24]  512 	inc	dptr
      0050CB E0               [24]  513 	movx	a,@dptr
      0050CC FF               [12]  514 	mov	r7,a
      0050CD 8D 82            [24]  515 	mov	dpl,r5
      0050CF 8E 83            [24]  516 	mov	dph,r6
      0050D1 8F F0            [24]  517 	mov	b,r7
      0050D3 22               [24]  518 	ret
                                    519 
                                    520 	.area CSEG (CODE)
                                    521 ; function ak820_outline_0021
      0050D4                        522 _ak820_outline_0021:
      0050D4 E0               [24]  523 	movx	a,@dptr
      0050D5 FD               [12]  524 	mov	r5,a
      0050D6 A3               [24]  525 	inc	dptr
      0050D7 E0               [24]  526 	movx	a,@dptr
      0050D8 FE               [12]  527 	mov	r6,a
      0050D9 A3               [24]  528 	inc	dptr
      0050DA E0               [24]  529 	movx	a,@dptr
      0050DB FF               [12]  530 	mov	r7,a
      0050DC 22               [24]  531 	ret
                                    532 
                                    533 	.area CSEG (CODE)
                                    534 ; function ak820_outline_0043
      0050DD                        535 _ak820_outline_0043:
      0050DD 8D 82            [24]  536 	mov	dpl,r5
      0050DF 8E 83            [24]  537 	mov	dph,r6
      0050E1 8F F0            [24]  538 	mov	b,r7
      0050E3 22               [24]  539 	ret
                                    540 
                                    541 	.area CSEG (CODE)
                                    542 ; function ak820_outline_0048
      0050E4                        543 _ak820_outline_0048:
      0050E4 E4               [12]  544 	clr	a
      0050E5 F0               [24]  545 	movx	@dptr,a
      0050E6 A3               [24]  546 	inc	dptr
      0050E7 F0               [24]  547 	movx	@dptr,a
      0050E8 A3               [24]  548 	inc	dptr
      0050E9 F0               [24]  549 	movx	@dptr,a
      0050EA A3               [24]  550 	inc	dptr
      0050EB F0               [24]  551 	movx	@dptr,a
      0050EC 22               [24]  552 	ret
                                    553 
                                    554 	.area CSEG (CODE)
                                    555 ; function ak820_outline_0053
      0050ED                        556 _ak820_outline_0053:
      0050ED E0               [24]  557 	movx	a,@dptr
      0050EE FC               [12]  558 	mov	r4,a
      0050EF A3               [24]  559 	inc	dptr
      0050F0 E0               [24]  560 	movx	a,@dptr
      0050F1 FD               [12]  561 	mov	r5,a
      0050F2 A3               [24]  562 	inc	dptr
      0050F3 E0               [24]  563 	movx	a,@dptr
      0050F4 FE               [12]  564 	mov	r6,a
      0050F5 A3               [24]  565 	inc	dptr
      0050F6 E0               [24]  566 	movx	a,@dptr
      0050F7 8C 82            [24]  567 	mov	dpl,r4
      0050F9 8D 83            [24]  568 	mov	dph,r5
      0050FB 8E F0            [24]  569 	mov	b,r6
      0050FD 22               [24]  570 	ret
                                    571 
                                    572 	.area CSEG (CODE)
                                    573 ; function ak820_outline_0056
      0050FE                        574 _ak820_outline_0056:
      0050FE AC 82            [24]  575 	mov	r4,dpl
      005100 AD 83            [24]  576 	mov	r5,dph
      005102 AE F0            [24]  577 	mov	r6,b
      005104 FF               [12]  578 	mov	r7,a
      005105 22               [24]  579 	ret
                                    580 
                                    581 	.area CSEG (CODE)
                                    582 ; function ak820_outline_0087
      005106                        583 _ak820_outline_0087:
      005106 E0               [24]  584 	movx	a,@dptr
      005107 F9               [12]  585 	mov	r1,a
      005108 A3               [24]  586 	inc	dptr
      005109 E0               [24]  587 	movx	a,@dptr
      00510A FA               [12]  588 	mov	r2,a
      00510B A3               [24]  589 	inc	dptr
      00510C E0               [24]  590 	movx	a,@dptr
      00510D FB               [12]  591 	mov	r3,a
      00510E 22               [24]  592 	ret
                                    593 
                                    594 	.area CSEG (CODE)
                                    595 ; function ak820_outline_0088
      00510F                        596 _ak820_outline_0088:
      00510F E0               [24]  597 	movx	a,@dptr
      005110 FE               [12]  598 	mov	r6,a
      005111 A3               [24]  599 	inc	dptr
      005112 E0               [24]  600 	movx	a,@dptr
      005113 8E 82            [24]  601 	mov	dpl,r6
      005115 F5 83            [12]  602 	mov	dph,a
      005117 22               [24]  603 	ret
                                    604 
                                    605 	.area CSEG (CODE)
                                    606 ; function ak820_outline_0106
      005118                        607 _ak820_outline_0106:
      005118 74 02            [12]  608 	mov	a,#0x02
      00511A F0               [24]  609 	movx	@dptr,a
      00511B E4               [12]  610 	clr	a
      00511C A3               [24]  611 	inc	dptr
      00511D F0               [24]  612 	movx	@dptr,a
      00511E 22               [24]  613 	ret
                                    614 
                                    615 	.area CSEG (CODE)
                                    616 ; function ak820_outline_0150
      00511F                        617 _ak820_outline_0150:
      00511F F0               [24]  618 	movx	@dptr,a
      005120 EA               [12]  619 	mov	a,r2
      005121 A3               [24]  620 	inc	dptr
      005122 F0               [24]  621 	movx	@dptr,a
      005123 EB               [12]  622 	mov	a,r3
      005124 A3               [24]  623 	inc	dptr
      005125 22               [24]  624 	ret
                                    625 
                                    626 	.area CSEG (CODE)
                                    627 ; function ak820_outline_0165
      005126                        628 _ak820_outline_0165:
      005126 E4               [12]  629 	clr	a
      005127 F0               [24]  630 	movx	@dptr,a
      005128 A3               [24]  631 	inc	dptr
      005129 F0               [24]  632 	movx	@dptr,a
      00512A 22               [24]  633 	ret
