                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module repeat_key
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_weak_mods
                                     12 	.globl _register_weak_mods
                                     13 	.globl _process_record
                                     14 	.globl _memset
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _get_alt_repeat_key_keycode_user_PARM_2
                                    259 	.globl _set_last_record_PARM_2
                                    260 	.globl _repeat_key_cancel
                                    261 	.globl _set_last_mods
                                    262 	.globl _set_last_record
                                    263 	.globl _get_repeat_key_count
                                    264 	.globl _repeat_key_invoke
                                    265 	.globl _get_alt_repeat_key_keycode
                                    266 	.globl _alt_repeat_key_invoke
                                    267 	.globl _get_alt_repeat_key_keycode_user
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 ;--------------------------------------------------------
                                    534 ; indirectly addressable internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area ISEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; absolute internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area IABS    (ABS,DATA)
                                    541 	.area IABS    (ABS,DATA)
                                    542 ;--------------------------------------------------------
                                    543 ; bit data
                                    544 ;--------------------------------------------------------
                                    545 	.area BSEG    (BIT)
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      000BF5                        554 _last_record:
      000BF5                        555 	.ds 9
      000BFE                        556 _ak820_repeat_invoking:
      000BFE                        557 	.ds 1
      000BFF                        558 _registered_record:
      000BFF                        559 	.ds 9
      000C08                        560 _registered_repeat_count:
      000C08                        561 	.ds 1
      000C09                        562 _registered_mods:
      000C09                        563 	.ds 1
      000C0A                        564 _set_last_mods_mods_10000_170:
      000C0A                        565 	.ds 1
      000C0B                        566 _set_last_record_PARM_2:
      000C0B                        567 	.ds 2
      000C0D                        568 _set_last_record_keycode_10000_172:
      000C0D                        569 	.ds 2
      000C0F                        570 _update_last_repeat_count_dir_10000_174:
      000C0F                        571 	.ds 1
      000C10                        572 _repeat_invoke_PARM_2:
      000C10                        573 	.ds 1
      000C11                        574 _repeat_invoke_event_10000_182:
      000C11                        575 	.ds 2
      000C13                        576 _repeat_key_invoke_event_10000_197:
      000C13                        577 	.ds 2
      000C15                        578 _find_alt_keycode_PARM_2:
      000C15                        579 	.ds 1
      000C16                        580 _find_alt_keycode_PARM_3:
      000C16                        581 	.ds 1
      000C17                        582 _find_alt_keycode_table_10000_199:
      000C17                        583 	.ds 3
      000C1A                        584 _get_alt_repeat_key_keycode_keycode_10000_206:
      000C1A                        585 	.ds 2
      000C1C                        586 _get_alt_repeat_key_keycode_mods_10000_206:
      000C1C                        587 	.ds 1
      000C1D                        588 _get_alt_repeat_key_keycode_alt_keycode_10000_206:
      000C1D                        589 	.ds 2
      000C1F                        590 _alt_repeat_key_invoke_event_10000_220:
      000C1F                        591 	.ds 2
      000C21                        592 _get_alt_repeat_key_keycode_user_PARM_2:
      000C21                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; absolute external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XABS    (ABS,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; initialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XISEG   (XDATA)
      000DF9                        602 _last_mods:
      000DF9                        603 	.ds 1
      000DFA                        604 _last_repeat_count:
      000DFA                        605 	.ds 1
      000DFB                        606 _processing_repeat_count:
      000DFB                        607 	.ds 1
                                    608 	.area HOME    (CODE)
                                    609 	.area GSINIT0 (CODE)
                                    610 	.area GSINIT1 (CODE)
                                    611 	.area GSINIT2 (CODE)
                                    612 	.area GSINIT3 (CODE)
                                    613 	.area GSINIT4 (CODE)
                                    614 	.area GSINIT5 (CODE)
                                    615 	.area GSINIT  (CODE)
                                    616 	.area GSFINAL (CODE)
                                    617 	.area CSEG    (CODE)
                                    618 ;--------------------------------------------------------
                                    619 ; global & static initialisations
                                    620 ;--------------------------------------------------------
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 	.area GSFINAL (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 ;--------------------------------------------------------
                                    626 ; Home
                                    627 ;--------------------------------------------------------
                                    628 	.area HOME    (CODE)
                                    629 	.area HOME    (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; code
                                    632 ;--------------------------------------------------------
                                    633 	.area CSEG    (CODE)
                                    634 ;------------------------------------------------------------
                                    635 ;Allocation info for local variables in function 'repeat_key_cancel'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/repeat_key.c:44: void repeat_key_cancel(void) {
                                    638 ;	-----------------------------------------
                                    639 ;	 function repeat_key_cancel
                                    640 ;	-----------------------------------------
      00A18E                        641 _repeat_key_cancel:
                           000007   642 	ar7 = 0x07
                           000006   643 	ar6 = 0x06
                           000005   644 	ar5 = 0x05
                           000004   645 	ar4 = 0x04
                           000003   646 	ar3 = 0x03
                           000002   647 	ar2 = 0x02
                           000001   648 	ar1 = 0x01
                           000000   649 	ar0 = 0x00
                                    650 ;	quantum/repeat_key.c:45: registered_record.keycode = 0;
      00A18E 90 0C 06         [24]  651 	mov	dptr,#(_registered_record + 0x0007)
      00A191 12 51 26         [24]  652 	lcall	_ak820_outline_0165
                                    653 ;	quantum/repeat_key.c:46: }
      00A194 22               [24]  654 	ret
                                    655 ;------------------------------------------------------------
                                    656 ;Allocation info for local variables in function 'get_last_keycode'
                                    657 ;------------------------------------------------------------
                                    658 ;	quantum/repeat_key.c:48: uint16_t get_last_keycode(void) {
                                    659 ;	-----------------------------------------
                                    660 ;	 function set_last_mods
                                    661 ;	-----------------------------------------
      00A195                        662 _set_last_mods:
      00A195 E5 82            [12]  663 	mov	a,dpl
      00A197 90 0C 0A         [24]  664 	mov	dptr,#_set_last_mods_mods_10000_170
      00A19A F0               [24]  665 	movx	@dptr,a
                                    666 ;	quantum/repeat_key.c:66: last_mods = mods;
      00A19B E0               [24]  667 	movx	a,@dptr
      00A19C 90 0D F9         [24]  668 	mov	dptr,#_last_mods
      00A19F F0               [24]  669 	movx	@dptr,a
                                    670 ;	quantum/repeat_key.c:67: }
      00A1A0 22               [24]  671 	ret
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'set_last_record'
                                    674 ;------------------------------------------------------------
                                    675 ;record        Allocated with name '_set_last_record_PARM_2'
                                    676 ;keycode       Allocated with name '_set_last_record_keycode_10000_172'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/repeat_key.c:69: void set_last_record(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record) {
                                    679 ;	-----------------------------------------
                                    680 ;	 function set_last_record
                                    681 ;	-----------------------------------------
      00A1A1                        682 _set_last_record:
      00A1A1 12 3A 8A         [24]  683 	lcall	_ak820_outline_0103
      00A1A4 90 0C 0D         [24]  684 	mov	dptr,#_set_last_record_keycode_10000_172
      00A1A7 12 3A 8F         [24]  685 	lcall	_ak820_outline_0104
                                    686 ;	quantum/repeat_key.c:70: last_record         = *record;
      00A1AA 90 0C 0B         [24]  687 	mov	dptr,#_set_last_record_PARM_2
      00A1AD 12 3A 5E         [24]  688 	lcall	_ak820_outline_0057
      00A1B0 90 0D 80         [24]  689 	mov	dptr,#___memcpy_PARM_2
      00A1B3 ED               [12]  690 	mov	a,r5
      00A1B4 12 3A 26         [24]  691 	lcall	_ak820_outline_0015
      00A1B7 90 0D 83         [24]  692 	mov	dptr,#___memcpy_PARM_3
      00A1BA 74 09            [12]  693 	mov	a,#0x09
      00A1BC 12 3A A6         [24]  694 	lcall	_ak820_outline_0122
      00A1BF 90 0B F5         [24]  695 	mov	dptr,#_last_record
      00A1C2 F5 F0            [12]  696 	mov	b,a
      00A1C4 12 B8 2F         [24]  697 	lcall	___memcpy
                                    698 ;	quantum/repeat_key.c:71: last_record.keycode = keycode;
      00A1C7 90 0C 0D         [24]  699 	mov	dptr,#_set_last_record_keycode_10000_172
      00A1CA 12 3A 47         [24]  700 	lcall	_ak820_outline_0050
      00A1CD 90 0B FC         [24]  701 	mov	dptr,#(_last_record + 0x0007)
      00A1D0 12 4A 87         [24]  702 	lcall	_ak820_outline_0058
                                    703 ;	quantum/repeat_key.c:72: last_repeat_count   = 0;
      00A1D3 90 0D FA         [24]  704 	mov	dptr,#_last_repeat_count
      00A1D6 E4               [12]  705 	clr	a
      00A1D7 F0               [24]  706 	movx	@dptr,a
                                    707 ;	quantum/repeat_key.c:73: }
      00A1D8 22               [24]  708 	ret
                                    709 ;------------------------------------------------------------
                                    710 ;Allocation info for local variables in function 'update_last_repeat_count'
                                    711 ;------------------------------------------------------------
                                    712 ;dir           Allocated with name '_update_last_repeat_count_dir_10000_174'
                                    713 ;------------------------------------------------------------
                                    714 ;	quantum/repeat_key.c:76: static void update_last_repeat_count(int8_t dir) {
                                    715 ;	-----------------------------------------
                                    716 ;	 function update_last_repeat_count
                                    717 ;	-----------------------------------------
      00A1D9                        718 _update_last_repeat_count:
      00A1D9 E5 82            [12]  719 	mov	a,dpl
      00A1DB 90 0C 0F         [24]  720 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      00A1DE F0               [24]  721 	movx	@dptr,a
                                    722 ;	quantum/repeat_key.c:77: if ((dir < 0) != (last_repeat_count < 0)) {
      00A1DF E0               [24]  723 	movx	a,@dptr
      00A1E0 FF               [12]  724 	mov	r7,a
      00A1E1 33               [12]  725 	rlc	a
      00A1E2 E4               [12]  726 	clr	a
      00A1E3 33               [12]  727 	rlc	a
      00A1E4 FE               [12]  728 	mov	r6,a
      00A1E5 90 0D FA         [24]  729 	mov	dptr,#_last_repeat_count
      00A1E8 E0               [24]  730 	movx	a,@dptr
      00A1E9 FD               [12]  731 	mov	r5,a
      00A1EA 33               [12]  732 	rlc	a
      00A1EB E4               [12]  733 	clr	a
      00A1EC 33               [12]  734 	rlc	a
      00A1ED FC               [12]  735 	mov	r4,a
      00A1EE EE               [12]  736 	mov	a,r6
      00A1EF B5 04 02         [24]  737 	cjne	a,ar4,00131$
      00A1F2 80 06            [24]  738 	sjmp	00104$
      00A1F4                        739 00131$:
                                    740 ;	quantum/repeat_key.c:78: last_repeat_count = dir;
      00A1F4 90 0D FA         [24]  741 	mov	dptr,#_last_repeat_count
      00A1F7 EF               [12]  742 	mov	a,r7
      00A1F8 F0               [24]  743 	movx	@dptr,a
      00A1F9 22               [24]  744 	ret
      00A1FA                        745 00104$:
                                    746 ;	quantum/repeat_key.c:79: } else if (dir < 0 ? last_repeat_count > -127 : last_repeat_count < 127) {
      00A1FA EE               [12]  747 	mov	a,r6
      00A1FB 60 0F            [24]  748 	jz	00108$
      00A1FD C3               [12]  749 	clr	c
      00A1FE 74 01            [12]  750 	mov	a,#(0x81 ^ 0x80)
      00A200 8D F0            [24]  751 	mov	b,r5
      00A202 63 F0 80         [24]  752 	xrl	b,#0x80
      00A205 95 F0            [12]  753 	subb	a,b
      00A207 E4               [12]  754 	clr	a
      00A208 33               [12]  755 	rlc	a
      00A209 FF               [12]  756 	mov	r7,a
                                    757 ;	free result
      00A20A 80 09            [24]  758 	sjmp	00109$
      00A20C                        759 00108$:
      00A20C C3               [12]  760 	clr	c
      00A20D ED               [12]  761 	mov	a,r5
      00A20E 64 80            [12]  762 	xrl	a,#0x80
      00A210 94 FF            [12]  763 	subb	a,#0xff
      00A212 E4               [12]  764 	clr	a
      00A213 33               [12]  765 	rlc	a
      00A214 FF               [12]  766 	mov	r7,a
      00A215                        767 00109$:
      00A215 EF               [12]  768 	mov	a,r7
      00A216 60 09            [24]  769 	jz	00106$
                                    770 ;	quantum/repeat_key.c:80: last_repeat_count += dir;
      00A218 90 0C 0F         [24]  771 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      00A21B E0               [24]  772 	movx	a,@dptr
      00A21C 90 0D FA         [24]  773 	mov	dptr,#_last_repeat_count
      00A21F 2D               [12]  774 	add	a, r5
      00A220 F0               [24]  775 	movx	@dptr,a
      00A221                        776 00106$:
                                    777 ;	quantum/repeat_key.c:82: }
      00A221 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'get_repeat_key_count'
                                    781 ;------------------------------------------------------------
                                    782 ;	quantum/repeat_key.c:84: int8_t get_repeat_key_count(void) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function get_repeat_key_count
                                    785 ;	-----------------------------------------
      00A222                        786 _get_repeat_key_count:
                                    787 ;	quantum/repeat_key.c:85: return processing_repeat_count;
      00A222 90 0D FB         [24]  788 	mov	dptr,#_processing_repeat_count
      00A225 E0               [24]  789 	movx	a,@dptr
      00A226 F5 82            [12]  790 	mov	dpl,a
                                    791 ;	quantum/repeat_key.c:86: }
      00A228 22               [24]  792 	ret
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'repeat_invoke'
                                    795 ;------------------------------------------------------------
                                    796 ;alternate     Allocated with name '_repeat_invoke_PARM_2'
                                    797 ;event         Allocated with name '_repeat_invoke_event_10000_182'
                                    798 ;------------------------------------------------------------
                                    799 ;	quantum/repeat_key.c:88: static void repeat_invoke(const keyevent_t AK820_RECORD_MEM *event, bool alternate) {
                                    800 ;	-----------------------------------------
                                    801 ;	 function repeat_invoke
                                    802 ;	-----------------------------------------
      00A229                        803 _repeat_invoke:
      00A229 12 3A 8A         [24]  804 	lcall	_ak820_outline_0103
      00A22C 90 0C 11         [24]  805 	mov	dptr,#_repeat_invoke_event_10000_182
      00A22F 12 3A 8F         [24]  806 	lcall	_ak820_outline_0104
                                    807 ;	quantum/repeat_key.c:97: if (ak820_repeat_invoking) return;
      00A232 90 0B FE         [24]  808 	mov	dptr,#_ak820_repeat_invoking
      00A235 E0               [24]  809 	movx	a,@dptr
      00A236 60 01            [24]  810 	jz	00102$
      00A238 22               [24]  811 	ret
      00A239                        812 00102$:
                                    813 ;	quantum/repeat_key.c:99: if (processing_repeat_count) {
      00A239 90 0D FB         [24]  814 	mov	dptr,#_processing_repeat_count
      00A23C E0               [24]  815 	movx	a,@dptr
      00A23D 60 01            [24]  816 	jz	00104$
                                    817 ;	quantum/repeat_key.c:100: return;
      00A23F 22               [24]  818 	ret
      00A240                        819 00104$:
                                    820 ;	quantum/repeat_key.c:103: if (event->pressed) {
      00A240 90 0C 11         [24]  821 	mov	dptr,#_repeat_invoke_event_10000_182
      00A243 12 3A 47         [24]  822 	lcall	_ak820_outline_0050
      00A246 74 05            [12]  823 	mov	a,#0x05
      00A248 12 4A 2D         [24]  824 	lcall	_ak820_outline_0011
      00A24B 70 03            [24]  825 	jnz	00197$
      00A24D 02 A2 C8         [24]  826 	ljmp	00117$
      00A250                        827 00197$:
                                    828 ;	quantum/repeat_key.c:106: if (registered_record.keycode || !last_record.keycode) return;
      00A250 90 0C 06         [24]  829 	mov	dptr,#(_registered_record + 0x0007)
      00A253 12 3A C1         [24]  830 	lcall	_ak820_outline_0164
      00A256 70 08            [24]  831 	jnz	00105$
      00A258 90 0B FC         [24]  832 	mov	dptr,#(_last_record + 0x0007)
      00A25B 12 3A C1         [24]  833 	lcall	_ak820_outline_0164
      00A25E 70 01            [24]  834 	jnz	00106$
      00A260                        835 00105$:
      00A260 22               [24]  836 	ret
      00A261                        837 00106$:
                                    838 ;	quantum/repeat_key.c:107: registered_record = last_record;
      00A261 90 0D 80         [24]  839 	mov	dptr,#___memcpy_PARM_2
      00A264 74 F5            [12]  840 	mov	a,#_last_record
      00A266 F0               [24]  841 	movx	@dptr,a
      00A267 74 0B            [12]  842 	mov	a,#(_last_record >> 8)
      00A269 12 3A 78         [24]  843 	lcall	_ak820_outline_0096
      00A26C 90 0D 83         [24]  844 	mov	dptr,#___memcpy_PARM_3
      00A26F 74 09            [12]  845 	mov	a,#0x09
      00A271 12 3A A6         [24]  846 	lcall	_ak820_outline_0122
      00A274 90 0B FF         [24]  847 	mov	dptr,#_registered_record
      00A277 F5 F0            [12]  848 	mov	b,a
      00A279 12 B8 2F         [24]  849 	lcall	___memcpy
                                    850 ;	quantum/repeat_key.c:108: registered_mods = last_mods;
      00A27C 90 0D F9         [24]  851 	mov	dptr,#_last_mods
      00A27F E0               [24]  852 	movx	a,@dptr
      00A280 90 0C 09         [24]  853 	mov	dptr,#_registered_mods
      00A283 F0               [24]  854 	movx	@dptr,a
                                    855 ;	quantum/repeat_key.c:110: if (alternate) {
      00A284 90 0C 10         [24]  856 	mov	dptr,#_repeat_invoke_PARM_2
      00A287 E0               [24]  857 	movx	a,@dptr
      00A288 FD               [12]  858 	mov	r5,a
      00A289 E0               [24]  859 	movx	a,@dptr
      00A28A 60 1B            [24]  860 	jz	00111$
                                    861 ;	quantum/repeat_key.c:111: registered_record.keycode = get_alt_repeat_key_keycode();
      00A28C C0 05            [24]  862 	push	ar5
      00A28E 12 A3 91         [24]  863 	lcall	_get_alt_repeat_key_keycode
      00A291 AB 82            [24]  864 	mov	r3, dpl
      00A293 AC 83            [24]  865 	mov	r4, dph
      00A295 D0 05            [24]  866 	pop	ar5
      00A297 90 0C 06         [24]  867 	mov	dptr,#(_registered_record + 0x0007)
      00A29A 12 3A 72         [24]  868 	lcall	_ak820_outline_0076
                                    869 ;	quantum/repeat_key.c:112: if (!registered_record.keycode) return;
      00A29D EB               [12]  870 	mov	a,r3
      00A29E 4C               [12]  871 	orl	a,r4
      00A29F 70 01            [24]  872 	jnz	00109$
      00A2A1 22               [24]  873 	ret
      00A2A2                        874 00109$:
                                    875 ;	quantum/repeat_key.c:114: registered_mods = 0;
      00A2A2 90 0C 09         [24]  876 	mov	dptr,#_registered_mods
      00A2A5 E4               [12]  877 	clr	a
      00A2A6 F0               [24]  878 	movx	@dptr,a
      00A2A7                        879 00111$:
                                    880 ;	quantum/repeat_key.c:117: update_last_repeat_count(alternate ? -1 : 1);
      00A2A7 ED               [12]  881 	mov	a,r5
      00A2A8 60 04            [24]  882 	jz	00123$
      00A2AA 7D FF            [12]  883 	mov	r5,#0xff
      00A2AC 80 02            [24]  884 	sjmp	00124$
      00A2AE                        885 00123$:
      00A2AE 7D 01            [12]  886 	mov	r5,#0x01
      00A2B0                        887 00124$:
      00A2B0 8D 82            [24]  888 	mov	dpl, r5
      00A2B2 12 A1 D9         [24]  889 	lcall	_update_last_repeat_count
                                    890 ;	quantum/repeat_key.c:118: register_weak_mods(registered_mods);
      00A2B5 90 0C 09         [24]  891 	mov	dptr,#_registered_mods
      00A2B8 E0               [24]  892 	movx	a,@dptr
      00A2B9 F5 82            [12]  893 	mov	dpl,a
      00A2BB 12 77 E6         [24]  894 	lcall	_register_weak_mods
                                    895 ;	quantum/repeat_key.c:119: registered_repeat_count = last_repeat_count;
      00A2BE 90 0D FA         [24]  896 	mov	dptr,#_last_repeat_count
      00A2C1 E0               [24]  897 	movx	a,@dptr
      00A2C2 90 0C 08         [24]  898 	mov	dptr,#_registered_repeat_count
      00A2C5 F0               [24]  899 	movx	@dptr,a
      00A2C6 80 25            [24]  900 	sjmp	00118$
      00A2C8                        901 00117$:
                                    902 ;	quantum/repeat_key.c:122: if (!registered_record.keycode || event->key.row != registered_record.event.key.row ||
      00A2C8 90 0C 06         [24]  903 	mov	dptr,#(_registered_record + 0x0007)
      00A2CB 12 3A C1         [24]  904 	lcall	_ak820_outline_0164
      00A2CE 60 1C            [24]  905 	jz	00112$
      00A2D0 12 3A 94         [24]  906 	lcall	_ak820_outline_0108
      00A2D3 FD               [12]  907 	mov	r5,a
      00A2D4 90 0C 00         [24]  908 	mov	dptr,#(_registered_record + 0x0001)
      00A2D7 E0               [24]  909 	movx	a,@dptr
      00A2D8 FC               [12]  910 	mov	r4,a
      00A2D9 ED               [12]  911 	mov	a,r5
      00A2DA B5 04 0F         [24]  912 	cjne	a,ar4,00112$
                                    913 ;	quantum/repeat_key.c:123: event->key.col != registered_record.event.key.col) return;
      00A2DD 12 3A 7E         [24]  914 	lcall	_ak820_outline_0097
      00A2E0 FF               [12]  915 	mov	r7,a
      00A2E1 90 0B FF         [24]  916 	mov	dptr,#_registered_record
      00A2E4 E0               [24]  917 	movx	a,@dptr
      00A2E5 FE               [12]  918 	mov	r6,a
      00A2E6 EF               [12]  919 	mov	a,r7
      00A2E7 B5 06 02         [24]  920 	cjne	a,ar6,00206$
      00A2EA 80 01            [24]  921 	sjmp	00118$
      00A2EC                        922 00206$:
      00A2EC                        923 00112$:
      00A2EC 22               [24]  924 	ret
      00A2ED                        925 00118$:
                                    926 ;	quantum/repeat_key.c:127: registered_record.event = *event;
      00A2ED 90 0C 11         [24]  927 	mov	dptr,#_repeat_invoke_event_10000_182
      00A2F0 12 3A 5E         [24]  928 	lcall	_ak820_outline_0057
      00A2F3 90 0D 80         [24]  929 	mov	dptr,#___memcpy_PARM_2
      00A2F6 ED               [12]  930 	mov	a,r5
      00A2F7 12 3A 26         [24]  931 	lcall	_ak820_outline_0015
      00A2FA 90 0D 83         [24]  932 	mov	dptr,#___memcpy_PARM_3
      00A2FD 12 78 8B         [24]  933 	lcall	_ak820_outline_0107
      00A300 90 0B FF         [24]  934 	mov	dptr,#_registered_record
      00A303 F5 F0            [12]  935 	mov	b,a
      00A305 12 B8 2F         [24]  936 	lcall	___memcpy
                                    937 ;	quantum/repeat_key.c:128: processing_repeat_count = registered_repeat_count;
      00A308 90 0C 08         [24]  938 	mov	dptr,#_registered_repeat_count
      00A30B E0               [24]  939 	movx	a,@dptr
      00A30C 90 0D FB         [24]  940 	mov	dptr,#_processing_repeat_count
      00A30F F0               [24]  941 	movx	@dptr,a
                                    942 ;	quantum/repeat_key.c:130: ak820_repeat_invoking = true;
      00A310 90 0B FE         [24]  943 	mov	dptr,#_ak820_repeat_invoking
      00A313 74 01            [12]  944 	mov	a,#0x01
      00A315 F0               [24]  945 	movx	@dptr,a
                                    946 ;	quantum/repeat_key.c:132: process_record(&registered_record);
      00A316 90 0B FF         [24]  947 	mov	dptr,#_registered_record
      00A319 12 72 8A         [24]  948 	lcall	_process_record
                                    949 ;	quantum/repeat_key.c:134: ak820_repeat_invoking = false;
      00A31C 90 0B FE         [24]  950 	mov	dptr,#_ak820_repeat_invoking
      00A31F E4               [12]  951 	clr	a
      00A320 F0               [24]  952 	movx	@dptr,a
                                    953 ;	quantum/repeat_key.c:136: processing_repeat_count = 0;
      00A321 90 0D FB         [24]  954 	mov	dptr,#_processing_repeat_count
      00A324 F0               [24]  955 	movx	@dptr,a
                                    956 ;	quantum/repeat_key.c:142: if (!registered_record.event.pressed) {
      00A325 90 0C 04         [24]  957 	mov	dptr,#(_registered_record + 0x0005)
      00A328 E0               [24]  958 	movx	a,@dptr
      00A329 70 0F            [24]  959 	jnz	00121$
                                    960 ;	quantum/repeat_key.c:143: unregister_weak_mods(registered_mods);
      00A32B 90 0C 09         [24]  961 	mov	dptr,#_registered_mods
      00A32E E0               [24]  962 	movx	a,@dptr
      00A32F F5 82            [12]  963 	mov	dpl,a
      00A331 12 77 FA         [24]  964 	lcall	_unregister_weak_mods
                                    965 ;	quantum/repeat_key.c:144: registered_record.keycode = 0;
      00A334 90 0C 06         [24]  966 	mov	dptr,#(_registered_record + 0x0007)
      00A337 12 51 26         [24]  967 	lcall	_ak820_outline_0165
      00A33A                        968 00121$:
                                    969 ;	quantum/repeat_key.c:146: }
      00A33A 22               [24]  970 	ret
                                    971 ;------------------------------------------------------------
                                    972 ;Allocation info for local variables in function 'repeat_key_invoke'
                                    973 ;------------------------------------------------------------
                                    974 ;event         Allocated with name '_repeat_key_invoke_event_10000_197'
                                    975 ;------------------------------------------------------------
                                    976 ;	quantum/repeat_key.c:148: void repeat_key_invoke(const keyevent_t AK820_RECORD_MEM *event) {
                                    977 ;	-----------------------------------------
                                    978 ;	 function repeat_key_invoke
                                    979 ;	-----------------------------------------
      00A33B                        980 _repeat_key_invoke:
      00A33B 12 3A 8A         [24]  981 	lcall	_ak820_outline_0103
      00A33E 90 0C 13         [24]  982 	mov	dptr,#_repeat_key_invoke_event_10000_197
      00A341 12 3A 8F         [24]  983 	lcall	_ak820_outline_0104
                                    984 ;	quantum/repeat_key.c:149: repeat_invoke(event, false);
      00A344 90 0C 13         [24]  985 	mov	dptr,#_repeat_key_invoke_event_10000_197
      00A347 12 3A 47         [24]  986 	lcall	_ak820_outline_0050
      00A34A 90 0C 10         [24]  987 	mov	dptr,#_repeat_invoke_PARM_2
      00A34D E4               [12]  988 	clr	a
      00A34E 12 45 41         [24]  989 	lcall	_ak820_outline_0060
                                    990 ;	quantum/repeat_key.c:150: }
      00A351 02 A2 29         [24]  991 	ljmp	_repeat_invoke
                                    992 ;------------------------------------------------------------
                                    993 ;Allocation info for local variables in function 'find_alt_keycode'
                                    994 ;------------------------------------------------------------
                                    995 ;table_size_bytes Allocated with name '_find_alt_keycode_PARM_2'
                                    996 ;target        Allocated with name '_find_alt_keycode_PARM_3'
                                    997 ;table         Allocated with name '_find_alt_keycode_table_10000_199'
                                    998 ;keycodes      Allocated with name '_find_alt_keycode_keycodes_10000_200'
                                    999 ;i             Allocated with name '_find_alt_keycode_i_20000_201'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	quantum/repeat_key.c:166: static uint8_t find_alt_keycode(const uint8_t (*table)[2], uint8_t table_size_bytes, uint8_t target) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function find_alt_keycode
                                   1004 ;	-----------------------------------------
      00A354                       1005 _find_alt_keycode:
      00A354 12 45 1D         [24] 1006 	lcall	_ak820_outline_0036
      00A357 90 0C 17         [24] 1007 	mov	dptr,#_find_alt_keycode_table_10000_199
      00A35A 12 3A 26         [24] 1008 	lcall	_ak820_outline_0015
                                   1009 ;	quantum/repeat_key.c:167: const uint8_t* keycodes = (const uint8_t*)table;
      00A35D 90 0C 17         [24] 1010 	mov	dptr,#_find_alt_keycode_table_10000_199
      00A360 12 50 D4         [24] 1011 	lcall	_ak820_outline_0021
                                   1012 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00A363 7C 00            [12] 1013 	mov	r4,#0x00
      00A365                       1014 00105$:
      00A365 90 0C 15         [24] 1015 	mov	dptr,#_find_alt_keycode_PARM_2
      00A368 E0               [24] 1016 	movx	a,@dptr
      00A369 FB               [12] 1017 	mov	r3,a
      00A36A C3               [12] 1018 	clr	c
      00A36B EC               [12] 1019 	mov	a,r4
      00A36C 9B               [12] 1020 	subb	a,r3
      00A36D 50 1E            [24] 1021 	jnc	00103$
                                   1022 ;	quantum/repeat_key.c:169: if (target == pgm_read_byte(keycodes + i)) {
      00A36F EC               [12] 1023 	mov	a,r4
      00A370 12 8F 7A         [24] 1024 	lcall	_ak820_outline_0024
      00A373 12 B9 08         [24] 1025 	lcall	__gptrget
      00A376 F9               [12] 1026 	mov	r1,a
      00A377 90 0C 16         [24] 1027 	mov	dptr,#_find_alt_keycode_PARM_3
      00A37A E0               [24] 1028 	movx	a,@dptr
      00A37B B5 01 0C         [24] 1029 	cjne	a,ar1,00106$
                                   1030 ;	quantum/repeat_key.c:171: return pgm_read_byte(keycodes + (i ^ 1));
      00A37E 74 01            [12] 1031 	mov	a,#0x01
      00A380 6C               [12] 1032 	xrl	a,r4
      00A381 12 8F 7A         [24] 1033 	lcall	_ak820_outline_0024
      00A384 12 B9 08         [24] 1034 	lcall	__gptrget
      00A387 F5 82            [12] 1035 	mov	dpl,a
      00A389 22               [24] 1036 	ret
      00A38A                       1037 00106$:
                                   1038 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00A38A 0C               [12] 1039 	inc	r4
      00A38B 80 D8            [24] 1040 	sjmp	00105$
      00A38D                       1041 00103$:
                                   1042 ;	quantum/repeat_key.c:174: return KC_NO;
      00A38D 75 82 00         [24] 1043 	mov	dpl, #0x00
                                   1044 ;	quantum/repeat_key.c:175: }
      00A390 22               [24] 1045 	ret
                                   1046 ;------------------------------------------------------------
                                   1047 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode'
                                   1048 ;------------------------------------------------------------
                                   1049 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_keycode_10000_206'
                                   1050 ;mods          Allocated with name '_get_alt_repeat_key_keycode_mods_10000_206'
                                   1051 ;alt_keycode   Allocated with name '_get_alt_repeat_key_keycode_alt_keycode_10000_206'
                                   1052 ;------------------------------------------------------------
                                   1053 ;	quantum/repeat_key.c:177: uint16_t get_alt_repeat_key_keycode(void) {
                                   1054 ;	-----------------------------------------
                                   1055 ;	 function get_alt_repeat_key_keycode
                                   1056 ;	-----------------------------------------
      00A391                       1057 _get_alt_repeat_key_keycode:
                                   1058 ;	quantum/repeat_key.c:178: uint16_t keycode = last_record.keycode;
      00A391 90 0B FC         [24] 1059 	mov	dptr,#(_last_record + 0x0007)
      00A394 12 3A 47         [24] 1060 	lcall	_ak820_outline_0050
      00A397 90 0C 1A         [24] 1061 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A39A 12 4A 87         [24] 1062 	lcall	_ak820_outline_0058
                                   1063 ;	quantum/repeat_key.c:179: uint8_t  mods    = last_mods;
      00A39D 90 0D F9         [24] 1064 	mov	dptr,#_last_mods
      00A3A0 E0               [24] 1065 	movx	a,@dptr
      00A3A1 FD               [12] 1066 	mov	r5,a
      00A3A2 90 0C 1C         [24] 1067 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A3A5 F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	quantum/repeat_key.c:183: uint16_t alt_keycode = get_alt_repeat_key_keycode_user(keycode, mods);
      00A3A6 90 0C 21         [24] 1070 	mov	dptr,#_get_alt_repeat_key_keycode_user_PARM_2
      00A3A9 ED               [12] 1071 	mov	a,r5
      00A3AA 12 45 41         [24] 1072 	lcall	_ak820_outline_0060
      00A3AD C0 07            [24] 1073 	push	ar7
      00A3AF C0 06            [24] 1074 	push	ar6
      00A3B1 12 A4 C2         [24] 1075 	lcall	_get_alt_repeat_key_keycode_user
      00A3B4 12 45 87         [24] 1076 	lcall	_ak820_outline_0144
      00A3B7 D0 06            [24] 1077 	pop	ar6
      00A3B9 D0 07            [24] 1078 	pop	ar7
                                   1079 ;	quantum/repeat_key.c:185: if (alt_keycode != KC_TRANSPARENT) {
      00A3BB 8C 02            [24] 1080 	mov	ar2,r4
      00A3BD 8D 03            [24] 1081 	mov	ar3,r5
      00A3BF BA 01 05         [24] 1082 	cjne	r2,#0x01,00176$
      00A3C2 BB 00 02         [24] 1083 	cjne	r3,#0x00,00176$
      00A3C5 80 04            [24] 1084 	sjmp	00102$
      00A3C7                       1085 00176$:
                                   1086 ;	quantum/repeat_key.c:186: return alt_keycode;
      00A3C7 12 3A 9B         [24] 1087 	lcall	_ak820_outline_0117
      00A3CA 22               [24] 1088 	ret
      00A3CB                       1089 00102$:
                                   1090 ;	quantum/repeat_key.c:191: mods = ((mods & 0xf0) ? /* set right hand bit */ 0x10 : 0)
      00A3CB 90 0C 1C         [24] 1091 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A3CE E0               [24] 1092 	movx	a,@dptr
      00A3CF 54 F0            [12] 1093 	anl	a,#0xf0
      00A3D1 60 02            [24] 1094 	jz	00118$
      00A3D3 74 10            [12] 1095 	mov	a,#0x10
      00A3D5                       1096 00118$:
      00A3D5 FD               [12] 1097 	mov	r5,a
                                   1098 ;	quantum/repeat_key.c:193: | (((mods >> 4) | mods) & 0xf);
      00A3D6 90 0C 1C         [24] 1099 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A3D9 E0               [24] 1100 	movx	a,@dptr
      00A3DA FC               [12] 1101 	mov	r4,a
      00A3DB C4               [12] 1102 	swap	a
      00A3DC 54 0F            [12] 1103 	anl	a,#0x0f
      00A3DE 4C               [12] 1104 	orl	a,r4
      00A3DF 54 0F            [12] 1105 	anl	a,#0x0f
      00A3E1 4D               [12] 1106 	orl	a,r5
      00A3E2 F0               [24] 1107 	movx	@dptr,a
                                   1108 ;	quantum/repeat_key.c:196: if (keycode >= QK_MODS && keycode <= QK_MODS_MAX) {
      00A3E3 8E 04            [24] 1109 	mov	ar4,r6
      00A3E5 8F 05            [24] 1110 	mov	ar5,r7
      00A3E7 74 FF            [12] 1111 	mov	a,#0x100 - 0x01
      00A3E9 2D               [12] 1112 	add	a,r5
      00A3EA 50 1C            [24] 1113 	jnc	00115$
      00A3EC C3               [12] 1114 	clr	c
      00A3ED 74 FF            [12] 1115 	mov	a,#0xff
      00A3EF 9C               [12] 1116 	subb	a,r4
      00A3F0 74 1F            [12] 1117 	mov	a,#0x1f
      00A3F2 9D               [12] 1118 	subb	a,r5
      00A3F3 40 13            [24] 1119 	jc	00115$
                                   1120 ;	free result
                                   1121 ;	quantum/repeat_key.c:197: mods |= QK_MODS_GET_MODS(keycode);
      00A3F5 8F 06            [24] 1122 	mov	ar6,r7
      00A3F7 53 06 1F         [24] 1123 	anl	ar6,#0x1f
      00A3FA 90 0C 1C         [24] 1124 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A3FD E0               [24] 1125 	movx	a,@dptr
      00A3FE 4E               [12] 1126 	orl	a,r6
      00A3FF F0               [24] 1127 	movx	@dptr,a
                                   1128 ;	quantum/repeat_key.c:198: keycode = QK_MODS_GET_BASIC_KEYCODE(keycode);
      00A400 7D 00            [12] 1129 	mov	r5,#0x00
      00A402 90 0C 1A         [24] 1130 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A405 12 3A 6C         [24] 1131 	lcall	_ak820_outline_0070
                                   1132 ;	quantum/repeat_key.c:214: if (IS_QK_BASIC(keycode)) {
      00A408                       1133 00115$:
      00A408 90 0C 1A         [24] 1134 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A40B 12 3A 12         [24] 1135 	lcall	_ak820_outline_0009
      00A40E C3               [12] 1136 	clr	c
      00A40F 74 FF            [12] 1137 	mov	a,#0xff
      00A411 9C               [12] 1138 	subb	a,r4
      00A412 E4               [12] 1139 	clr	a
      00A413 9D               [12] 1140 	subb	a,r5
      00A414 50 03            [24] 1141 	jnc	00180$
      00A416 02 A4 A6         [24] 1142 	ljmp	00114$
      00A419                       1143 00180$:
                                   1144 ;	free result
                                   1145 ;	quantum/repeat_key.c:215: if ((mods & (MOD_LCTL | MOD_LALT | MOD_LGUI))) {
      00A419 90 0C 1C         [24] 1146 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A41C E0               [24] 1147 	movx	a,@dptr
      00A41D 54 0D            [12] 1148 	anl	a,#0x0d
      00A41F 60 21            [24] 1149 	jz	00107$
                                   1150 ;	quantum/repeat_key.c:230: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A421 8E 05            [24] 1151 	mov	ar5,r6
      00A423 90 0C 15         [24] 1152 	mov	dptr,#_find_alt_keycode_PARM_2
      00A426 74 0A            [12] 1153 	mov	a,#0x0a
      00A428 F0               [24] 1154 	movx	@dptr,a
      00A429 90 0C 16         [24] 1155 	mov	dptr,#_find_alt_keycode_PARM_3
      00A42C ED               [12] 1156 	mov	a,r5
      00A42D F0               [24] 1157 	movx	@dptr,a
      00A42E 90 BC CD         [24] 1158 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_214
      00A431 75 F0 80         [24] 1159 	mov	b, #0x80
      00A434 12 A3 54         [24] 1160 	lcall	_find_alt_keycode
      00A437 AD 82            [24] 1161 	mov	r5, dpl
      00A439 90 0C 1D         [24] 1162 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A43C ED               [12] 1163 	mov	a,r5
      00A43D 12 3A A6         [24] 1164 	lcall	_ak820_outline_0122
      00A440 80 1D            [24] 1165 	sjmp	00108$
      00A442                       1166 00107$:
                                   1167 ;	quantum/repeat_key.c:243: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A442 90 0C 15         [24] 1168 	mov	dptr,#_find_alt_keycode_PARM_2
      00A445 74 08            [12] 1169 	mov	a,#0x08
      00A447 F0               [24] 1170 	movx	@dptr,a
      00A448 90 0C 16         [24] 1171 	mov	dptr,#_find_alt_keycode_PARM_3
      00A44B EE               [12] 1172 	mov	a,r6
      00A44C F0               [24] 1173 	movx	@dptr,a
      00A44D 90 BC D7         [24] 1174 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_215
      00A450 75 F0 80         [24] 1175 	mov	b, #0x80
      00A453 12 A3 54         [24] 1176 	lcall	_find_alt_keycode
      00A456 AF 82            [24] 1177 	mov	r7, dpl
      00A458 90 0C 1D         [24] 1178 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A45B EF               [12] 1179 	mov	a,r7
      00A45C 12 3A A6         [24] 1180 	lcall	_ak820_outline_0122
      00A45F                       1181 00108$:
                                   1182 ;	quantum/repeat_key.c:246: if (!alt_keycode) {
      00A45F 90 0C 1D         [24] 1183 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A462 12 6F 3C         [24] 1184 	lcall	_ak820_outline_0035
      00A465 70 22            [24] 1185 	jnz	00110$
                                   1186 ;	quantum/repeat_key.c:271: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A467 90 0C 1A         [24] 1187 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A46A E0               [24] 1188 	movx	a,@dptr
      00A46B FF               [12] 1189 	mov	r7,a
      00A46C 90 0C 15         [24] 1190 	mov	dptr,#_find_alt_keycode_PARM_2
      00A46F 74 16            [12] 1191 	mov	a,#0x16
      00A471 F0               [24] 1192 	movx	@dptr,a
      00A472 90 0C 16         [24] 1193 	mov	dptr,#_find_alt_keycode_PARM_3
      00A475 EF               [12] 1194 	mov	a,r7
      00A476 F0               [24] 1195 	movx	@dptr,a
      00A477 90 BC DF         [24] 1196 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_217
      00A47A 75 F0 80         [24] 1197 	mov	b, #0x80
      00A47D 12 A3 54         [24] 1198 	lcall	_find_alt_keycode
      00A480 AF 82            [24] 1199 	mov	r7, dpl
      00A482 90 0C 1D         [24] 1200 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A485 EF               [12] 1201 	mov	a,r7
      00A486 12 3A A6         [24] 1202 	lcall	_ak820_outline_0122
      00A489                       1203 00110$:
                                   1204 ;	quantum/repeat_key.c:274: if (alt_keycode) {
      00A489 90 0C 1D         [24] 1205 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A48C 12 3A 47         [24] 1206 	lcall	_ak820_outline_0050
      00A48F 90 0C 1D         [24] 1207 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A492 12 6F 3C         [24] 1208 	lcall	_ak820_outline_0035
      00A495 60 0F            [24] 1209 	jz	00114$
                                   1210 ;	quantum/repeat_key.c:276: return (mods << 8) | alt_keycode;
      00A497 90 0C 1C         [24] 1211 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A49A E0               [24] 1212 	movx	a,@dptr
      00A49B FD               [12] 1213 	mov	r5,a
      00A49C E4               [12] 1214 	clr	a
      00A49D 42 06            [12] 1215 	orl	ar6,a
      00A49F ED               [12] 1216 	mov	a,r5
      00A4A0 42 07            [12] 1217 	orl	ar7,a
      00A4A2 12 45 66         [24] 1218 	lcall	_ak820_outline_0116
      00A4A5 22               [24] 1219 	ret
      00A4A6                       1220 00114$:
                                   1221 ;	quantum/repeat_key.c:280: return KC_NO; // No alternate key found.
      00A4A6 90 00 00         [24] 1222 	mov	dptr,#0x0000
                                   1223 ;	quantum/repeat_key.c:281: }
      00A4A9 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'alt_repeat_key_invoke'
                                   1227 ;------------------------------------------------------------
                                   1228 ;event         Allocated with name '_alt_repeat_key_invoke_event_10000_220'
                                   1229 ;------------------------------------------------------------
                                   1230 ;	quantum/repeat_key.c:283: void alt_repeat_key_invoke(const keyevent_t AK820_RECORD_MEM *event) {
                                   1231 ;	-----------------------------------------
                                   1232 ;	 function alt_repeat_key_invoke
                                   1233 ;	-----------------------------------------
      00A4AA                       1234 _alt_repeat_key_invoke:
      00A4AA 12 3A 8A         [24] 1235 	lcall	_ak820_outline_0103
      00A4AD 90 0C 1F         [24] 1236 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00A4B0 12 3A 8F         [24] 1237 	lcall	_ak820_outline_0104
                                   1238 ;	quantum/repeat_key.c:285: repeat_invoke(event, true);
      00A4B3 90 0C 1F         [24] 1239 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00A4B6 12 3A 47         [24] 1240 	lcall	_ak820_outline_0050
      00A4B9 90 0C 10         [24] 1241 	mov	dptr,#_repeat_invoke_PARM_2
      00A4BC 12 4A 77         [24] 1242 	lcall	_ak820_outline_0054
                                   1243 ;	quantum/repeat_key.c:286: }
      00A4BF 02 A2 29         [24] 1244 	ljmp	_repeat_invoke
                                   1245 ;------------------------------------------------------------
                                   1246 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode_user'
                                   1247 ;------------------------------------------------------------
                                   1248 ;mods          Allocated with name '_get_alt_repeat_key_keycode_user_PARM_2'
                                   1249 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_user_keycode_10000_222'
                                   1250 ;------------------------------------------------------------
                                   1251 ;	quantum/repeat_key.c:289: __attribute__((weak)) uint16_t get_alt_repeat_key_keycode_user(uint16_t keycode, uint8_t mods) {
                                   1252 ;	-----------------------------------------
                                   1253 ;	 function get_alt_repeat_key_keycode_user
                                   1254 ;	-----------------------------------------
      00A4C2                       1255 _get_alt_repeat_key_keycode_user:
                                   1256 ;	quantum/repeat_key.c:290: return KC_TRANSPARENT;
      00A4C2 90 00 01         [24] 1257 	mov	dptr,#0x0001
                                   1258 ;	quantum/repeat_key.c:291: }
      00A4C5 22               [24] 1259 	ret
                                   1260 	.area CSEG    (CODE)
                                   1261 	.area CONST   (CODE)
                                   1262 	.area CONST   (CODE)
      00BCCD                       1263 _get_alt_repeat_key_keycode_pairs_50000_214:
      00BCCD 09                    1264 	.db #0x09	; 9
      00BCCE 05                    1265 	.db #0x05	; 5
      00BCCF 07                    1266 	.db #0x07	; 7
      00BCD0 18                    1267 	.db #0x18	; 24
      00BCD1 11                    1268 	.db #0x11	; 17
      00BCD2 13                    1269 	.db #0x13	; 19
      00BCD3 04                    1270 	.db #0x04	; 4
      00BCD4 08                    1271 	.db #0x08	; 8
      00BCD5 12                    1272 	.db #0x12	; 18
      00BCD6 0C                    1273 	.db #0x0c	; 12
                                   1274 	.area CSEG    (CODE)
                                   1275 	.area CONST   (CODE)
      00BCD7                       1276 _get_alt_repeat_key_keycode_pairs_50000_215:
      00BCD7 0D                    1277 	.db #0x0d	; 13
      00BCD8 0E                    1278 	.db #0x0e	; 14
      00BCD9 0B                    1279 	.db #0x0b	; 11
      00BCDA 0F                    1280 	.db #0x0f	; 15
      00BCDB 1A                    1281 	.db #0x1a	; 26
      00BCDC 05                    1282 	.db #0x05	; 5
      00BCDD 08                    1283 	.db #0x08	; 8
      00BCDE 05                    1284 	.db #0x05	; 5
                                   1285 	.area CSEG    (CODE)
                                   1286 	.area CONST   (CODE)
      00BCDF                       1287 _get_alt_repeat_key_keycode_pairs_50000_217:
      00BCDF 50                    1288 	.db #0x50	; 80	'P'
      00BCE0 4F                    1289 	.db #0x4f	; 79	'O'
      00BCE1 52                    1290 	.db #0x52	; 82	'R'
      00BCE2 51                    1291 	.db #0x51	; 81	'Q'
      00BCE3 4A                    1292 	.db #0x4a	; 74	'J'
      00BCE4 4D                    1293 	.db #0x4d	; 77	'M'
      00BCE5 4B                    1294 	.db #0x4b	; 75	'K'
      00BCE6 4E                    1295 	.db #0x4e	; 78	'N'
      00BCE7 2A                    1296 	.db #0x2a	; 42
      00BCE8 4C                    1297 	.db #0x4c	; 76	'L'
      00BCE9 2F                    1298 	.db #0x2f	; 47
      00BCEA 30                    1299 	.db #0x30	; 48	'0'
      00BCEB B6                    1300 	.db #0xb6	; 182
      00BCEC B7                    1301 	.db #0xb7	; 183
      00BCED AB                    1302 	.db #0xab	; 171
      00BCEE AC                    1303 	.db #0xac	; 172
      00BCEF BB                    1304 	.db #0xbb	; 187
      00BCF0 BC                    1305 	.db #0xbc	; 188
      00BCF1 A9                    1306 	.db #0xa9	; 169
      00BCF2 AA                    1307 	.db #0xaa	; 170
      00BCF3 BD                    1308 	.db #0xbd	; 189
      00BCF4 BE                    1309 	.db #0xbe	; 190
                                   1310 	.area CSEG    (CODE)
                                   1311 	.area XINIT   (CODE)
      00C158                       1312 __xinit__last_mods:
      00C158 00                    1313 	.db #0x00	; 0
      00C159                       1314 __xinit__last_repeat_count:
      00C159 00                    1315 	.db #0x00	;  0
      00C15A                       1316 __xinit__processing_repeat_count:
      00C15A 00                    1317 	.db #0x00	;  0
                                   1318 	.area CABS    (ABS,CODE)
                                   1319 
                                   1320 ; Experimental exact instruction outlining.
                                   1321 	.globl _ak820_outline_0009
                                   1322 	.globl _ak820_outline_0011
                                   1323 	.globl _ak820_outline_0015
                                   1324 	.globl _ak820_outline_0021
                                   1325 	.globl _ak820_outline_0024
                                   1326 	.globl _ak820_outline_0035
                                   1327 	.globl _ak820_outline_0036
                                   1328 	.globl _ak820_outline_0050
                                   1329 	.globl _ak820_outline_0054
                                   1330 	.globl _ak820_outline_0057
                                   1331 	.globl _ak820_outline_0058
                                   1332 	.globl _ak820_outline_0060
                                   1333 	.globl _ak820_outline_0070
                                   1334 	.globl _ak820_outline_0076
                                   1335 	.globl _ak820_outline_0096
                                   1336 	.globl _ak820_outline_0097
                                   1337 	.globl _ak820_outline_0103
                                   1338 	.globl _ak820_outline_0104
                                   1339 	.globl _ak820_outline_0107
                                   1340 	.globl _ak820_outline_0108
                                   1341 	.globl _ak820_outline_0116
                                   1342 	.globl _ak820_outline_0117
                                   1343 	.globl _ak820_outline_0122
                                   1344 	.globl _ak820_outline_0144
                                   1345 	.globl _ak820_outline_0164
                                   1346 	.globl _ak820_outline_0165
