                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000D                        552 _ak820_tapping_before_sloc0_1_0:
      00000D                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005AA                        562 _source_state:
      0005AA                        563 	.ds 130
      00062C                        564 _pending_time:
      00062C                        565 	.ds 2
      00062E                        566 _pending_code:
      00062E                        567 	.ds 2
      000630                        568 _ak820_tapping_source_PARM_1:
      000630                        569 	.ds 2
      000632                        570 _hold_PARM_2:
      000632                        571 	.ds 1
      000633                        572 _hold_code_10000_601:
      000633                        573 	.ds 2
      000635                        574 _hold_mods_30000_604:
      000635                        575 	.ds 1
      000636                        576 _commit_pending_id_10000_610:
      000636                        577 	.ds 1
      000637                        578 _ak820_tapping_before_event_10000_611:
      000637                        579 	.ds 2
      000639                        580 _ak820_tapping_process_record_10000_622:
      000639                        581 	.ds 2
      00063B                        582 _ak820_tapping_process_code_10000_623:
      00063B                        583 	.ds 2
      00063D                        584 _ak820_tapping_process_sc_mods_10000_623:
      00063D                        585 	.ds 1
      00063E                        586 _ak820_oneshot_mods::
      00063E                        587 	.ds 1
      00063F                        588 _ak820_oneshot_consumed::
      00063F                        589 	.ds 1
      000640                        590 _ak820_oneshot_process_PARM_2:
      000640                        591 	.ds 1
      000641                        592 _ak820_oneshot_process_PARM_3:
      000641                        593 	.ds 1
      000642                        594 _ak820_oneshot_process_code_10000_648:
      000642                        595 	.ds 2
      000644                        596 _ak820_oneshot_process_mods_10000_649:
      000644                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000D91                        606 _pending:
      000D91                        607 	.ds 1
      000D92                        608 _ak820_oneshot_target::
      000D92                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0045A7                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0045A7 90 06 31         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0045AA E0               [24]  656 	movx	a,@dptr
      0045AB FF               [12]  657 	mov	r7,a
      0045AC BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0045AF                        659 00147$:
      0045AF 50 14            [24]  660 	jnc	00102$
      0045B1 90 06 30         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0045B4 E0               [24]  662 	movx	a,@dptr
      0045B5 FE               [12]  663 	mov	r6,a
      0045B6 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0045B9                        665 00149$:
      0045B9 50 0A            [24]  666 	jnc	00102$
      0045BB 8F 05            [24]  667 	mov	ar5,r7
      0045BD ED               [12]  668 	mov	a,r5
      0045BE 12 3A D1         [24]  669 	lcall	_ak820_outline_0184
      0045C1 2E               [12]  670 	add	a,r6
      0045C2 F5 82            [12]  671 	mov	dpl,a
      0045C4 22               [24]  672 	ret
      0045C5                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      0045C5 90 06 30         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0045C8 E0               [24]  676 	movx	a,@dptr
      0045C9 FE               [12]  677 	mov	r6,a
      0045CA BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0045CD                        679 00151$:
      0045CD 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0045CF BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0045D2 75 82 80         [24]  683 	mov	dpl, #0x80
      0045D5 22               [24]  684 	ret
      0045D6                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0045D6 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      0045D9 75 82 81         [24]  688 	mov	dpl, #0x81
      0045DC 22               [24]  689 	ret
      0045DD                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      0045DD 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      0045E0 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_601'
                                    700 ;mods          Allocated with name '_hold_mods_30000_604'
                                    701 ;layer         Allocated with name '_hold_layer_30000_607'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      0045E1                        707 _hold:
      0045E1 12 3A 8A         [24]  708 	lcall	_ak820_outline_0103
      0045E4 90 06 33         [24]  709 	mov	dptr,#_hold_code_10000_601
      0045E7 12 3A 8F         [24]  710 	lcall	_ak820_outline_0104
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      0045EA 90 06 33         [24]  712 	mov	dptr,#_hold_code_10000_601
      0045ED 12 3A 12         [24]  713 	lcall	_ak820_outline_0009
      0045F0 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      0045F2 2D               [12]  715 	add	a,r5
      0045F3 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      0045F5 8F 05            [24]  718 	mov	ar5,r7
      0045F7 53 05 1F         [24]  719 	anl	ar5,#0x1f
      0045FA 90 06 35         [24]  720 	mov	dptr,#_hold_mods_30000_604
      0045FD ED               [12]  721 	mov	a,r5
      0045FE F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      0045FF ED               [12]  724 	mov	a,r5
      004600 30 E4 08         [24]  725 	jnb	acc.4,00102$
      004603 ED               [12]  726 	mov	a,r5
      004604 C4               [12]  727 	swap	a
      004605 54 F0            [12]  728 	anl	a,#0xf0
      004607 90 06 35         [24]  729 	mov	dptr,#_hold_mods_30000_604
      00460A F0               [24]  730 	movx	@dptr,a
      00460B                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      00460B 90 06 32         [24]  733 	mov	dptr,#_hold_PARM_2
      00460E E0               [24]  734 	movx	a,@dptr
      00460F 60 09            [24]  735 	jz	00104$
      004611 90 06 35         [24]  736 	mov	dptr,#_hold_mods_30000_604
      004614 E0               [24]  737 	movx	a,@dptr
      004615 F5 82            [12]  738 	mov	dpl,a
      004617 02 77 BE         [24]  739 	ljmp	_register_mods
      00461A                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      00461A 90 06 35         [24]  742 	mov	dptr,#_hold_mods_30000_604
      00461D E0               [24]  743 	movx	a,@dptr
      00461E F5 82            [12]  744 	mov	dpl,a
      004620 02 77 D2         [24]  745 	ljmp	_unregister_mods
      004623                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      004623 8F 06            [24]  748 	mov	ar6,r7
      004625 74 0F            [12]  749 	mov	a,#0x0f
      004627 5E               [12]  750 	anl	a,r6
      004628 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004629 90 06 32         [24]  753 	mov	dptr,#_hold_PARM_2
      00462C E0               [24]  754 	movx	a,@dptr
      00462D 60 05            [24]  755 	jz	00107$
      00462F 8F 82            [24]  756 	mov	dpl, r7
      004631 02 79 85         [24]  757 	ljmp	_layer_hold_on
      004634                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      004634 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004636 02 79 BD         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_610'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004639                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004639 90 0D 91         [24]  774 	mov	dptr,#_pending
      00463C E0               [24]  775 	movx	a,@dptr
      00463D 90 06 36         [24]  776 	mov	dptr,#_commit_pending_id_10000_610
      004640 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004641 12 4A A2         [24]  779 	lcall	_ak820_outline_0149
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      004644 90 06 36         [24]  781 	mov	dptr,#_commit_pending_id_10000_610
      004647 E0               [24]  782 	movx	a,@dptr
      004648 24 AA            [12]  783 	add	a,#_source_state
      00464A FF               [12]  784 	mov	r7,a
      00464B E4               [12]  785 	clr	a
      00464C 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      00464E FE               [12]  787 	mov	r6,a
      00464F 12 45 8C         [24]  788 	lcall	_ak820_outline_0152
      004652 E0               [24]  789 	movx	a,@dptr
      004653 FD               [12]  790 	mov	r5,a
      004654 43 05 04         [24]  791 	orl	ar5,#0x04
      004657 12 45 8C         [24]  792 	lcall	_ak820_outline_0152
      00465A ED               [12]  793 	mov	a,r5
      00465B F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      00465C 90 06 2E         [24]  796 	mov	dptr,#_pending_code
      00465F 12 3A 47         [24]  797 	lcall	_ak820_outline_0050
      004662 90 06 32         [24]  798 	mov	dptr,#_hold_PARM_2
      004665 12 4A 77         [24]  799 	lcall	_ak820_outline_0054
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004668 02 45 E1         [24]  801 	ljmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_611'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_612'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      00466B                        812 _ak820_tapping_before:
      00466B 12 3A 8A         [24]  813 	lcall	_ak820_outline_0103
      00466E 90 06 37         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004671 12 3A 8F         [24]  815 	lcall	_ak820_outline_0104
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004674 90 06 37         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004677 12 3A 12         [24]  818 	lcall	_ak820_outline_0009
      00467A 12 4A 52         [24]  819 	lcall	_ak820_outline_0022
      00467D C0 07            [24]  820 	push	ar7
      00467F C0 06            [24]  821 	push	ar6
      004681 12 B8 2F         [24]  822 	lcall	___memcpy
      004684 12 45 A7         [24]  823 	lcall	_ak820_tapping_source
      004687 AD 82            [24]  824 	mov	r5, dpl
      004689 D0 06            [24]  825 	pop	ar6
      00468B D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      00468D 90 0E 02         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      004690 E0               [24]  829 	movx	a,@dptr
      004691 60 29            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004693 74 04            [12]  832 	mov	a,#0x04
      004695 12 4A 38         [24]  833 	lcall	_ak820_outline_0012
      004698 60 1E            [24]  834 	jz	00102$
      00469A BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      00469D 80 19            [24]  836 	sjmp	00102$
      00469F                        837 00218$:
      00469F 74 05            [12]  838 	mov	a,#0x05
      0046A1 12 4A 38         [24]  839 	lcall	_ak820_outline_0012
      0046A4 70 12            [24]  840 	jnz	00102$
      0046A6 ED               [12]  841 	mov	a,r5
      0046A7 24 AA            [12]  842 	add	a, #_source_state
      0046A9 FB               [12]  843 	mov	r3,a
      0046AA E4               [12]  844 	clr	a
      0046AB 34 05            [12]  845 	addc	a, #(_source_state >> 8)
      0046AD 12 4A 7F         [24]  846 	lcall	_ak820_outline_0055
      0046B0 53 02 FD         [24]  847 	anl	ar2,#0xfd
      0046B3 12 36 42         [24]  848 	lcall	_ak820_outline_0121
      0046B6 EA               [12]  849 	mov	a,r2
      0046B7 F0               [24]  850 	movx	@dptr,a
      0046B8                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      0046B8 75 82 00         [24]  853 	mov	dpl, #0x00
      0046BB 22               [24]  854 	ret
      0046BC                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      0046BC 90 0D 91         [24]  857 	mov	dptr,#_pending
      0046BF E0               [24]  858 	movx	a,@dptr
      0046C0 FC               [12]  859 	mov	r4,a
      0046C1 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      0046C4 80 3B            [24]  861 	sjmp	00108$
      0046C6                        862 00220$:
      0046C6 12 3A 3F         [24]  863 	lcall	_ak820_outline_0033
      0046C9 FA               [12]  864 	mov	r2,a
      0046CA A3               [24]  865 	inc	dptr
      0046CB E0               [24]  866 	movx	a,@dptr
      0046CC FB               [12]  867 	mov	r3,a
      0046CD 90 06 2C         [24]  868 	mov	dptr,#_pending_time
      0046D0 12 3A 84         [24]  869 	lcall	_ak820_outline_0099
      0046D3 EA               [12]  870 	mov	a,r2
      0046D4 C3               [12]  871 	clr	c
      0046D5 98               [12]  872 	subb	a,r0
      0046D6 FA               [12]  873 	mov	r2,a
      0046D7 EB               [12]  874 	mov	a,r3
      0046D8 99               [12]  875 	subb	a,r1
      0046D9 FB               [12]  876 	mov	r3,a
      0046DA C3               [12]  877 	clr	c
      0046DB EA               [12]  878 	mov	a,r2
      0046DC 94 C8            [12]  879 	subb	a,#0xc8
      0046DE EB               [12]  880 	mov	a,r3
      0046DF 94 00            [12]  881 	subb	a,#0x00
      0046E1 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0046E3 74 04            [12]  884 	mov	a,#0x04
      0046E5 12 4A 6C         [24]  885 	lcall	_ak820_outline_0045
      0046E8 60 17            [24]  886 	jz	00108$
      0046EA 12 39 F1         [24]  887 	lcall	_ak820_outline_0005
      0046ED 60 12            [24]  888 	jz	00108$
      0046EF BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      0046F2 80 06            [24]  890 	sjmp	00107$
      0046F4                        891 00224$:
      0046F4 ED               [12]  892 	mov	a,r5
      0046F5 B5 04 02         [24]  893 	cjne	a,ar4,00225$
      0046F8 80 07            [24]  894 	sjmp	00108$
      0046FA                        895 00225$:
      0046FA                        896 00107$:
      0046FA C0 05            [24]  897 	push	ar5
      0046FC 12 46 39         [24]  898 	lcall	_commit_pending
      0046FF D0 05            [24]  899 	pop	ar5
      004701                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004701 90 06 37         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004704 12 3A 47         [24]  903 	lcall	_ak820_outline_0050
      004707 74 04            [12]  904 	mov	a,#0x04
      004709 12 4A 38         [24]  905 	lcall	_ak820_outline_0012
      00470C 60 03            [24]  906 	jz	00114$
      00470E BD FF 04         [24]  907 	cjne	r5,#0xff,00115$
      004711                        908 00114$:
      004711 75 82 01         [24]  909 	mov	dpl, #0x01
      004714 22               [24]  910 	ret
      004715                        911 00115$:
                                    912 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004715 ED               [12]  913 	mov	a,r5
      004716 12 4A 94         [24]  914 	lcall	_ak820_outline_0077
      004719 30 E1 13         [24]  915 	jnb	acc.1,00120$
                                    916 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00471C 74 05            [12]  917 	mov	a,#0x05
      00471E 2E               [12]  918 	add	a, r6
      00471F 12 3A 1C         [24]  919 	lcall	_ak820_outline_0013
      004722 70 07            [24]  920 	jnz	00118$
      004724 74 FD            [12]  921 	mov	a,#0xfd
      004726 5B               [12]  922 	anl	a,r3
      004727 12 3A 9B         [24]  923 	lcall	_ak820_outline_0117
      00472A F0               [24]  924 	movx	@dptr,a
      00472B                        925 00118$:
                                    926 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      00472B 75 82 00         [24]  927 	mov	dpl, #0x00
      00472E 22               [24]  928 	ret
      00472F                        929 00120$:
                                    930 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      00472F 12 45 0B         [24]  931 	lcall	_ak820_outline_0010
      004732 E0               [24]  932 	movx	a,@dptr
      004733 FF               [12]  933 	mov	r7,a
      004734 8B 06            [24]  934 	mov	ar6,r3
      004736 53 06 01         [24]  935 	anl	ar6,#0x01
      004739 EE               [12]  936 	mov	a,r6
      00473A B4 01 00         [24]  937 	cjne	a,#0x01,00231$
      00473D                        938 00231$:
      00473D B3               [12]  939 	cpl	c
      00473E 92 0D            [24]  940 	mov	_ak820_tapping_before_sloc0_1_0,c
      004740 8F F0            [24]  941 	mov	b,r7
      004742 E4               [12]  942 	clr	a
      004743 33               [12]  943 	rlc	a
      004744 B5 F0 04         [24]  944 	cjne	a,b,00122$
      004747 75 82 00         [24]  945 	mov	dpl, #0x00
      00474A 22               [24]  946 	ret
      00474B                        947 00122$:
                                    948 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      00474B 63 03 01         [24]  949 	xrl	ar3,#0x01
      00474E 12 3A 9B         [24]  950 	lcall	_ak820_outline_0117
      004751 EB               [12]  951 	mov	a,r3
      004752 F0               [24]  952 	movx	@dptr,a
                                    953 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004753 75 82 01         [24]  954 	mov	dpl, #0x01
                                    955 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004756 22               [24]  956 	ret
                                    957 ;------------------------------------------------------------
                                    958 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    959 ;------------------------------------------------------------
                                    960 ;record        Allocated with name '_ak820_tapping_process_record_10000_622'
                                    961 ;id            Allocated with name '_ak820_tapping_process_id_10000_623'
                                    962 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_623'
                                    963 ;code          Allocated with name '_ak820_tapping_process_code_10000_623'
                                    964 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_623'
                                    965 ;------------------------------------------------------------
                                    966 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    967 ;	-----------------------------------------
                                    968 ;	 function ak820_tapping_process
                                    969 ;	-----------------------------------------
      004757                        970 _ak820_tapping_process:
      004757 12 3A 8A         [24]  971 	lcall	_ak820_outline_0103
      00475A 90 06 39         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00475D 12 3A 8F         [24]  973 	lcall	_ak820_outline_0104
                                    974 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004760 90 06 3D         [24]  975 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004763 E4               [12]  976 	clr	a
      004764 F0               [24]  977 	movx	@dptr,a
                                    978 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004765 90 06 39         [24]  979 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004768 12 3A 47         [24]  980 	lcall	_ak820_outline_0050
      00476B 74 04            [12]  981 	mov	a,#0x04
      00476D 12 4A 2D         [24]  982 	lcall	_ak820_outline_0011
      004770 70 04            [24]  983 	jnz	00102$
      004772 75 82 01         [24]  984 	mov	dpl, #0x01
      004775 22               [24]  985 	ret
      004776                        986 00102$:
                                    987 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004776 8E 04            [24]  988 	mov	ar4,r6
      004778 8F 05            [24]  989 	mov	ar5,r7
      00477A 12 4A 52         [24]  990 	lcall	_ak820_outline_0022
      00477D C0 07            [24]  991 	push	ar7
      00477F C0 06            [24]  992 	push	ar6
      004781 12 B8 2F         [24]  993 	lcall	___memcpy
      004784 12 45 A7         [24]  994 	lcall	_ak820_tapping_source
      004787 AD 82            [24]  995 	mov	r5, dpl
      004789 D0 06            [24]  996 	pop	ar6
      00478B D0 07            [24]  997 	pop	ar7
                                    998 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      00478D BD FF 04         [24]  999 	cjne	r5,#0xff,00104$
      004790 75 82 01         [24] 1000 	mov	dpl, #0x01
      004793 22               [24] 1001 	ret
      004794                       1002 00104$:
                                   1003 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004794 74 07            [12] 1004 	mov	a,#0x07
      004796 12 3A 2E         [24] 1005 	lcall	_ak820_outline_0016
      004799 FE               [12] 1006 	mov	r6,a
      00479A A3               [24] 1007 	inc	dptr
      00479B E0               [24] 1008 	movx	a,@dptr
      00479C FF               [12] 1009 	mov	r7,a
      00479D 90 06 3B         [24] 1010 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0047A0 12 4A 87         [24] 1011 	lcall	_ak820_outline_0058
                                   1012 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      0047A3 BE 1A 15         [24] 1013 	cjne	r6,#0x1a,00111$
      0047A6 BF 7C 12         [24] 1014 	cjne	r7,#0x7c,00111$
      0047A9 90 06 3B         [24] 1015 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0047AC 74 26            [12] 1016 	mov	a,#0x26
      0047AE F0               [24] 1017 	movx	@dptr,a
      0047AF 74 22            [12] 1018 	mov	a,#0x22
      0047B1 A3               [24] 1019 	inc	dptr
      0047B2 F0               [24] 1020 	movx	@dptr,a
      0047B3 90 06 3D         [24] 1021 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0047B6 74 02            [12] 1022 	mov	a,#0x02
      0047B8 F0               [24] 1023 	movx	@dptr,a
      0047B9 80 28            [24] 1024 	sjmp	00112$
      0047BB                       1025 00111$:
                                   1026 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0047BB BE 1B 15         [24] 1027 	cjne	r6,#0x1b,00108$
      0047BE BF 7C 12         [24] 1028 	cjne	r7,#0x7c,00108$
      0047C1 90 06 3B         [24] 1029 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0047C4 74 27            [12] 1030 	mov	a,#0x27
      0047C6 F0               [24] 1031 	movx	@dptr,a
      0047C7 74 32            [12] 1032 	mov	a,#0x32
      0047C9 A3               [24] 1033 	inc	dptr
      0047CA F0               [24] 1034 	movx	@dptr,a
      0047CB 90 06 3D         [24] 1035 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0047CE 74 20            [12] 1036 	mov	a,#0x20
      0047D0 F0               [24] 1037 	movx	@dptr,a
      0047D1 80 10            [24] 1038 	sjmp	00112$
      0047D3                       1039 00108$:
                                   1040 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0047D3 BE 1E 0D         [24] 1041 	cjne	r6,#0x1e,00112$
      0047D6 BF 7C 0A         [24] 1042 	cjne	r7,#0x7c,00112$
      0047D9 90 06 3B         [24] 1043 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0047DC 74 28            [12] 1044 	mov	a,#0x28
      0047DE F0               [24] 1045 	movx	@dptr,a
      0047DF 74 32            [12] 1046 	mov	a,#0x32
      0047E1 A3               [24] 1047 	inc	dptr
      0047E2 F0               [24] 1048 	movx	@dptr,a
      0047E3                       1049 00112$:
                                   1050 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      0047E3 90 06 3B         [24] 1051 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0047E6 E0               [24] 1052 	movx	a,@dptr
      0047E7 A3               [24] 1053 	inc	dptr
      0047E8 E0               [24] 1054 	movx	a,@dptr
      0047E9 FF               [12] 1055 	mov	r7,a
                                   1056 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      0047EA BF 20 00         [24] 1057 	cjne	r7,#0x20,00242$
      0047ED                       1058 00242$:
      0047ED 40 05            [24] 1059 	jc	00113$
      0047EF BF 50 00         [24] 1060 	cjne	r7,#0x50,00244$
      0047F2                       1061 00244$:
      0047F2 40 04            [24] 1062 	jc	00114$
      0047F4                       1063 00113$:
      0047F4 75 82 01         [24] 1064 	mov	dpl, #0x01
      0047F7 22               [24] 1065 	ret
      0047F8                       1066 00114$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      0047F8 BF 40 00         [24] 1068 	cjne	r7,#0x40,00246$
      0047FB                       1069 00246$:
      0047FB 40 0C            [24] 1070 	jc	00117$
      0047FD 53 07 0F         [24] 1071 	anl	ar7,#0x0f
      004800 BF 06 00         [24] 1072 	cjne	r7,#0x06,00248$
      004803                       1073 00248$:
      004803 40 04            [24] 1074 	jc	00117$
      004805 75 82 00         [24] 1075 	mov	dpl, #0x00
      004808 22               [24] 1076 	ret
      004809                       1077 00117$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004809 90 06 39         [24] 1079 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00480C 12 3A 47         [24] 1080 	lcall	_ak820_outline_0050
      00480F 74 05            [12] 1081 	mov	a,#0x05
      004811 12 4A 38         [24] 1082 	lcall	_ak820_outline_0012
      004814 60 1F            [24] 1083 	jz	00131$
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004816 90 0D 91         [24] 1085 	mov	dptr,#_pending
      004819 ED               [12] 1086 	mov	a,r5
      00481A 12 45 15         [24] 1087 	lcall	_ak820_outline_0029
                                   1088 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      00481D 12 3A 47         [24] 1089 	lcall	_ak820_outline_0050
      004820 90 06 2C         [24] 1090 	mov	dptr,#_pending_time
      004823 12 4A 87         [24] 1091 	lcall	_ak820_outline_0058
                                   1092 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004826 90 06 3B         [24] 1093 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004829 12 3A 47         [24] 1094 	lcall	_ak820_outline_0050
      00482C 90 06 2E         [24] 1095 	mov	dptr,#_pending_code
      00482F 12 4A 87         [24] 1096 	lcall	_ak820_outline_0058
      004832 02 48 D2         [24] 1097 	ljmp	00132$
      004835                       1098 00131$:
                                   1099 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004835 90 0D 91         [24] 1100 	mov	dptr,#_pending
      004838 E0               [24] 1101 	movx	a,@dptr
      004839 FF               [12] 1102 	mov	r7,a
      00483A ED               [12] 1103 	mov	a,r5
      00483B B5 07 02         [24] 1104 	cjne	a,ar7,00251$
      00483E 80 03            [24] 1105 	sjmp	00252$
      004840                       1106 00251$:
      004840 02 48 AB         [24] 1107 	ljmp	00128$
      004843                       1108 00252$:
                                   1109 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004843 12 4A A2         [24] 1110 	lcall	_ak820_outline_0149
                                   1111 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004846 90 06 3D         [24] 1112 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004849 E0               [24] 1113 	movx	a,@dptr
      00484A FF               [12] 1114 	mov	r7,a
      00484B E0               [24] 1115 	movx	a,@dptr
      00484C 60 05            [24] 1116 	jz	00120$
      00484E 8F 82            [24] 1117 	mov	dpl, r7
      004850 12 7E 0A         [24] 1118 	lcall	_add_owned_mods
      004853                       1119 00120$:
                                   1120 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004853 90 06 39         [24] 1121 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004856 12 3A 47         [24] 1122 	lcall	_ak820_outline_0050
      004859 74 07            [12] 1123 	mov	a,#0x07
      00485B 2E               [12] 1124 	add	a, r6
      00485C FB               [12] 1125 	mov	r3,a
      00485D E4               [12] 1126 	clr	a
      00485E 3F               [12] 1127 	addc	a, r7
      00485F FC               [12] 1128 	mov	r4,a
      004860 90 06 3B         [24] 1129 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004863 E0               [24] 1130 	movx	a,@dptr
      004864 F9               [12] 1131 	mov	r1,a
      004865 7A 00            [12] 1132 	mov	r2,#0x00
      004867 12 36 42         [24] 1133 	lcall	_ak820_outline_0121
      00486A E9               [12] 1134 	mov	a,r1
      00486B F0               [24] 1135 	movx	@dptr,a
      00486C EA               [12] 1136 	mov	a,r2
      00486D A3               [24] 1137 	inc	dptr
      00486E F0               [24] 1138 	movx	@dptr,a
                                   1139 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      00486F C3               [12] 1140 	clr	c
      004870 04               [12] 1141 	inc	a
      004871 99               [12] 1142 	subb	a,r1
      004872 50 25            [24] 1143 	jnc	00122$
                                   1144 ;	free result
                                   1145 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004874 74 06            [12] 1146 	mov	a,#0x06
      004876 12 3A 2E         [24] 1147 	lcall	_ak820_outline_0016
      004879 54 0F            [12] 1148 	anl	a,#0x0f
      00487B 44 10            [12] 1149 	orl	a,#0x10
      00487D F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      00487E 12 45 0B         [24] 1152 	lcall	_ak820_outline_0010
      004881 12 4A 77         [24] 1153 	lcall	_ak820_outline_0054
                                   1154 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004884 12 72 8A         [24] 1155 	lcall	_process_record
                                   1156 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004887 90 06 39         [24] 1157 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00488A 12 39 E7         [24] 1158 	lcall	_ak820_outline_0004
      00488D A3               [24] 1159 	inc	dptr
      00488E A3               [24] 1160 	inc	dptr
      00488F A3               [24] 1161 	inc	dptr
      004890 A3               [24] 1162 	inc	dptr
      004891 A3               [24] 1163 	inc	dptr
      004892 E4               [12] 1164 	clr	a
      004893 12 45 41         [24] 1165 	lcall	_ak820_outline_0060
                                   1166 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004896 12 72 8A         [24] 1167 	lcall	_process_record
      004899                       1168 00122$:
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004899 90 06 3D         [24] 1170 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      00489C E0               [24] 1171 	movx	a,@dptr
      00489D FF               [12] 1172 	mov	r7,a
      00489E E0               [24] 1173 	movx	a,@dptr
      00489F 60 31            [24] 1174 	jz	00132$
                                   1175 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      0048A1 8F 82            [24] 1176 	mov	dpl, r7
      0048A3 12 7E 1A         [24] 1177 	lcall	_del_owned_mods
                                   1178 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      0048A6 12 81 44         [24] 1179 	lcall	_send_keyboard_report
      0048A9 80 27            [24] 1180 	sjmp	00132$
      0048AB                       1181 00128$:
                                   1182 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      0048AB ED               [12] 1183 	mov	a,r5
      0048AC 24 AA            [12] 1184 	add	a, #_source_state
      0048AE FE               [12] 1185 	mov	r6,a
      0048AF E4               [12] 1186 	clr	a
      0048B0 34 05            [12] 1187 	addc	a, #(_source_state >> 8)
      0048B2 FF               [12] 1188 	mov	r7,a
      0048B3 12 3A 7E         [24] 1189 	lcall	_ak820_outline_0097
      0048B6 FD               [12] 1190 	mov	r5,a
      0048B7 30 E2 18         [24] 1191 	jnb	acc.2,00132$
                                   1192 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      0048BA 53 05 FB         [24] 1193 	anl	ar5,#0xfb
      0048BD 12 45 66         [24] 1194 	lcall	_ak820_outline_0116
      0048C0 ED               [12] 1195 	mov	a,r5
      0048C1 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      0048C2 90 06 3B         [24] 1198 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0048C5 12 3A 47         [24] 1199 	lcall	_ak820_outline_0050
      0048C8 90 06 32         [24] 1200 	mov	dptr,#_hold_PARM_2
      0048CB E4               [12] 1201 	clr	a
      0048CC 12 45 41         [24] 1202 	lcall	_ak820_outline_0060
      0048CF 12 45 E1         [24] 1203 	lcall	_hold
      0048D2                       1204 00132$:
                                   1205 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      0048D2 75 82 00         [24] 1206 	mov	dpl, #0x00
                                   1207 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      0048D5 22               [24] 1208 	ret
                                   1209 ;------------------------------------------------------------
                                   1210 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1211 ;------------------------------------------------------------
                                   1212 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_646'
                                   1213 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_647'
                                   1214 ;------------------------------------------------------------
                                   1215 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1216 ;	-----------------------------------------
                                   1217 ;	 function ak820_tapping_cancel
                                   1218 ;	-----------------------------------------
      0048D6                       1219 _ak820_tapping_cancel:
                                   1220 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      0048D6 12 4A A2         [24] 1221 	lcall	_ak820_outline_0149
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0048D9 7F 00            [12] 1223 	mov	r7,#0x00
      0048DB                       1224 00103$:
      0048DB BF 82 00         [24] 1225 	cjne	r7,#0x82,00122$
      0048DE                       1226 00122$:
      0048DE 50 16            [24] 1227 	jnc	00105$
                                   1228 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      0048E0 12 4A 43         [24] 1229 	lcall	_ak820_outline_0018
                                   1230 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      0048E3 74 02            [12] 1231 	mov	a,#0x02
      0048E5 5C               [12] 1232 	anl	a,r4
      0048E6 FB               [12] 1233 	mov	r3,a
      0048E7 53 04 01         [24] 1234 	anl	ar4,#0x01
      0048EA EC               [12] 1235 	mov	a,r4
      0048EB 2C               [12] 1236 	add	a,r4
      0048EC 42 03            [12] 1237 	orl	ar3,a
      0048EE 12 3A AB         [24] 1238 	lcall	_ak820_outline_0131
      0048F1 EB               [12] 1239 	mov	a,r3
      0048F2 F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0048F3 0F               [12] 1242 	inc	r7
      0048F4 80 E5            [24] 1243 	sjmp	00103$
      0048F6                       1244 00105$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      0048F6 22               [24] 1246 	ret
                                   1247 ;------------------------------------------------------------
                                   1248 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1249 ;------------------------------------------------------------
                                   1250 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1251 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1252 ;code          Allocated with name '_ak820_oneshot_process_code_10000_648'
                                   1253 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_649'
                                   1254 ;i             Allocated with name '_ak820_oneshot_process_i_40000_663'
                                   1255 ;------------------------------------------------------------
                                   1256 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1257 ;	-----------------------------------------
                                   1258 ;	 function ak820_oneshot_process
                                   1259 ;	-----------------------------------------
      0048F7                       1260 _ak820_oneshot_process:
      0048F7 12 3A 8A         [24] 1261 	lcall	_ak820_outline_0103
      0048FA 90 06 42         [24] 1262 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      0048FD 12 3A 8F         [24] 1263 	lcall	_ak820_outline_0104
                                   1264 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004900 90 06 40         [24] 1265 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004903 E0               [24] 1266 	movx	a,@dptr
      004904 FF               [12] 1267 	mov	r7,a
      004905 BF FF 02         [24] 1268 	cjne	r7,#0xff,00248$
      004908 80 07            [24] 1269 	sjmp	00101$
      00490A                       1270 00248$:
      00490A 12 A2 22         [24] 1271 	lcall	_get_repeat_key_count
      00490D E5 82            [12] 1272 	mov	a, dpl
      00490F 60 04            [24] 1273 	jz	00102$
      004911                       1274 00101$:
      004911 75 82 01         [24] 1275 	mov	dpl, #0x01
      004914 22               [24] 1276 	ret
      004915                       1277 00102$:
                                   1278 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004915 90 06 42         [24] 1279 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      004918 E0               [24] 1280 	movx	a,@dptr
      004919 FD               [12] 1281 	mov	r5,a
      00491A A3               [24] 1282 	inc	dptr
      00491B E0               [24] 1283 	movx	a,@dptr
      00491C FB               [12] 1284 	mov	r3,a
      00491D BB 52 02         [24] 1285 	cjne	r3,#0x52,00250$
      004920 80 03            [24] 1286 	sjmp	00251$
      004922                       1287 00250$:
      004922 02 49 C7         [24] 1288 	ljmp	00116$
      004925                       1289 00251$:
      004925 8D 04            [24] 1290 	mov	ar4,r5
      004927 53 04 E0         [24] 1291 	anl	ar4,#0xe0
      00492A BC A0 02         [24] 1292 	cjne	r4,#0xa0,00252$
      00492D 80 03            [24] 1293 	sjmp	00253$
      00492F                       1294 00252$:
      00492F 02 49 C7         [24] 1295 	ljmp	00116$
      004932                       1296 00253$:
                                   1297 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004932 8D 04            [24] 1298 	mov	ar4,r5
      004934 53 04 0F         [24] 1299 	anl	ar4,#0x0f
      004937 90 06 44         [24] 1300 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      00493A EC               [12] 1301 	mov	a,r4
      00493B F0               [24] 1302 	movx	@dptr,a
                                   1303 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      00493C ED               [12] 1304 	mov	a,r5
      00493D 30 E4 08         [24] 1305 	jnb	acc.4,00105$
      004940 EC               [12] 1306 	mov	a,r4
      004941 C4               [12] 1307 	swap	a
      004942 54 F0            [12] 1308 	anl	a,#0xf0
      004944 90 06 44         [24] 1309 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004947 F0               [24] 1310 	movx	@dptr,a
      004948                       1311 00105$:
                                   1312 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004948 90 06 41         [24] 1313 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00494B E0               [24] 1314 	movx	a,@dptr
      00494C 60 2D            [24] 1315 	jz	00113$
                                   1316 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      00494E 12 4A 43         [24] 1317 	lcall	_ak820_outline_0018
      004951 43 04 08         [24] 1318 	orl	ar4,#0x08
      004954 12 45 47         [24] 1319 	lcall	_ak820_outline_0064
                                   1320 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004957 53 04 EF         [24] 1321 	anl	ar4,#0xef
      00495A 12 45 47         [24] 1322 	lcall	_ak820_outline_0064
                                   1323 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      00495D 90 0D 92         [24] 1324 	mov	dptr,#_ak820_oneshot_target
      004960 E0               [24] 1325 	movx	a,@dptr
      004961 FC               [12] 1326 	mov	r4,a
      004962 BC FF 02         [24] 1327 	cjne	r4,#0xff,00256$
      004965 80 09            [24] 1328 	sjmp	00107$
      004967                       1329 00256$:
      004967 12 4A 8D         [24] 1330 	lcall	_ak820_outline_0074
      00496A 43 04 10         [24] 1331 	orl	ar4,#0x10
      00496D 12 45 47         [24] 1332 	lcall	_ak820_outline_0064
      004970                       1333 00107$:
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004970 90 06 44         [24] 1335 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004973 E0               [24] 1336 	movx	a,@dptr
      004974 F5 82            [12] 1337 	mov	dpl,a
      004976 12 77 BE         [24] 1338 	lcall	_register_mods
      004979 80 48            [24] 1339 	sjmp	00114$
      00497B                       1340 00113$:
                                   1341 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      00497B 12 4A 43         [24] 1342 	lcall	_ak820_outline_0018
      00497E 30 E3 42         [24] 1343 	jnb	acc.3,00114$
                                   1344 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004981 EC               [12] 1345 	mov	a,r4
      004982 20 E4 24         [24] 1346 	jb	acc.4,00109$
                                   1347 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004985 90 06 3E         [24] 1348 	mov	dptr,#_ak820_oneshot_mods
      004988 E0               [24] 1349 	movx	a,@dptr
      004989 F4               [12] 1350 	cpl	a
      00498A FC               [12] 1351 	mov	r4,a
      00498B 90 06 44         [24] 1352 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      00498E E0               [24] 1353 	movx	a,@dptr
      00498F FB               [12] 1354 	mov	r3,a
      004990 52 04            [12] 1355 	anl	ar4,a
      004992 8C 82            [24] 1356 	mov	dpl, r4
      004994 C0 06            [24] 1357 	push	ar6
      004996 C0 05            [24] 1358 	push	ar5
      004998 C0 03            [24] 1359 	push	ar3
      00499A 12 7E 0A         [24] 1360 	lcall	_add_owned_mods
      00499D D0 03            [24] 1361 	pop	ar3
      00499F D0 05            [24] 1362 	pop	ar5
      0049A1 D0 06            [24] 1363 	pop	ar6
                                   1364 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      0049A3 90 06 3E         [24] 1365 	mov	dptr,#_ak820_oneshot_mods
      0049A6 E0               [24] 1366 	movx	a,@dptr
      0049A7 4B               [12] 1367 	orl	a,r3
      0049A8 F0               [24] 1368 	movx	@dptr,a
      0049A9                       1369 00109$:
                                   1370 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      0049A9 90 06 44         [24] 1371 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      0049AC E0               [24] 1372 	movx	a,@dptr
      0049AD F5 82            [12] 1373 	mov	dpl,a
      0049AF C0 06            [24] 1374 	push	ar6
      0049B1 C0 05            [24] 1375 	push	ar5
      0049B3 12 77 D2         [24] 1376 	lcall	_unregister_mods
      0049B6 D0 05            [24] 1377 	pop	ar5
      0049B8 D0 06            [24] 1378 	pop	ar6
                                   1379 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      0049BA 12 4A 8D         [24] 1380 	lcall	_ak820_outline_0074
      0049BD 53 04 E7         [24] 1381 	anl	ar4,#0xe7
      0049C0 12 45 47         [24] 1382 	lcall	_ak820_outline_0064
      0049C3                       1383 00114$:
                                   1384 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      0049C3 75 82 00         [24] 1385 	mov	dpl, #0x00
      0049C6 22               [24] 1386 	ret
      0049C7                       1387 00116$:
                                   1388 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      0049C7 90 06 41         [24] 1389 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0049CA E0               [24] 1390 	movx	a,@dptr
      0049CB 60 5C            [24] 1391 	jz	00124$
      0049CD 90 06 42         [24] 1392 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      0049D0 12 45 54         [24] 1393 	lcall	_ak820_outline_0092
      0049D3 C3               [12] 1394 	clr	c
      0049D4 74 01            [12] 1395 	mov	a,#0x01
      0049D6 9D               [12] 1396 	subb	a,r5
      0049D7 E4               [12] 1397 	clr	a
      0049D8 9E               [12] 1398 	subb	a,r6
      0049D9 50 4E            [24] 1399 	jnc	00124$
                                   1400 ;	free result
                                   1401 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      0049DB C3               [12] 1402 	clr	c
      0049DC ED               [12] 1403 	mov	a,r5
      0049DD 94 E0            [12] 1404 	subb	a,#0xe0
      0049DF EE               [12] 1405 	mov	a,r6
      0049E0 94 00            [12] 1406 	subb	a,#0x00
      0049E2 40 07            [24] 1407 	jc	00129$
      0049E4 74 E7            [12] 1408 	mov	a,#0xe7
      0049E6 9D               [12] 1409 	subb	a,r5
      0049E7 E4               [12] 1410 	clr	a
      0049E8 9E               [12] 1411 	subb	a,r6
      0049E9 50 3E            [24] 1412 	jnc	00124$
                                   1413 ;	free result
      0049EB                       1414 00129$:
                                   1415 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      0049EB 74 AE            [12] 1416 	mov	a,#0x100 - 0x52
      0049ED 2E               [12] 1417 	add	a,r6
      0049EE 50 09            [24] 1418 	jnc	00165$
      0049F0 C3               [12] 1419 	clr	c
      0049F1 74 DF            [12] 1420 	mov	a,#0xdf
      0049F3 9D               [12] 1421 	subb	a,r5
      0049F4 74 52            [12] 1422 	mov	a,#0x52
      0049F6 9E               [12] 1423 	subb	a,r6
      0049F7 50 30            [24] 1424 	jnc	00124$
                                   1425 ;	free result
                                   1426 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      0049F9                       1427 00165$:
      0049F9 7E 00            [12] 1428 	mov	r6,#0x00
      0049FB                       1429 00131$:
      0049FB BE 82 00         [24] 1430 	cjne	r6,#0x82,00265$
      0049FE                       1431 00265$:
      0049FE 50 12            [24] 1432 	jnc	00120$
                                   1433 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004A00 EE               [12] 1434 	mov	a,r6
      004A01 12 4A 94         [24] 1435 	lcall	_ak820_outline_0077
      004A04 30 E3 08         [24] 1436 	jnb	acc.3,00132$
      004A07 43 03 10         [24] 1437 	orl	ar3,#0x10
      004A0A 12 3A 9B         [24] 1438 	lcall	_ak820_outline_0117
      004A0D EB               [12] 1439 	mov	a,r3
      004A0E F0               [24] 1440 	movx	@dptr,a
      004A0F                       1441 00132$:
                                   1442 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004A0F 0E               [12] 1443 	inc	r6
      004A10 80 E9            [24] 1444 	sjmp	00131$
      004A12                       1445 00120$:
                                   1446 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004A12 90 06 3E         [24] 1447 	mov	dptr,#_ak820_oneshot_mods
      004A15 E0               [24] 1448 	movx	a,@dptr
      004A16 FE               [12] 1449 	mov	r6,a
      004A17 E0               [24] 1450 	movx	a,@dptr
      004A18 60 0F            [24] 1451 	jz	00124$
                                   1452 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004A1A 90 06 3F         [24] 1453 	mov	dptr,#_ak820_oneshot_consumed
      004A1D EE               [12] 1454 	mov	a,r6
      004A1E F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004A1F 90 0D 92         [24] 1457 	mov	dptr,#_ak820_oneshot_target
      004A22 EF               [12] 1458 	mov	a,r7
      004A23 F0               [24] 1459 	movx	@dptr,a
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004A24 90 06 3E         [24] 1461 	mov	dptr,#_ak820_oneshot_mods
      004A27 E4               [12] 1462 	clr	a
      004A28 F0               [24] 1463 	movx	@dptr,a
      004A29                       1464 00124$:
                                   1465 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004A29 75 82 01         [24] 1466 	mov	dpl, #0x01
                                   1467 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004A2C 22               [24] 1468 	ret
                                   1469 	.area CSEG    (CODE)
                                   1470 	.area CONST   (CODE)
                                   1471 	.area XINIT   (CODE)
      00C0F0                       1472 __xinit__pending:
      00C0F0 FF                    1473 	.db #0xff	; 255
      00C0F1                       1474 __xinit__ak820_oneshot_target:
      00C0F1 FF                    1475 	.db #0xff	; 255
                                   1476 	.area CABS    (ABS,CODE)
                                   1477 
                                   1478 ; Experimental exact instruction outlining.
                                   1479 	.globl _ak820_outline_0004
                                   1480 	.globl _ak820_outline_0005
                                   1481 	.globl _ak820_outline_0009
                                   1482 	.globl _ak820_outline_0010
                                   1483 	.globl _ak820_outline_0011
                                   1484 	.globl _ak820_outline_0012
                                   1485 	.globl _ak820_outline_0013
                                   1486 	.globl _ak820_outline_0016
                                   1487 	.globl _ak820_outline_0018
                                   1488 	.globl _ak820_outline_0022
                                   1489 	.globl _ak820_outline_0029
                                   1490 	.globl _ak820_outline_0033
                                   1491 	.globl _ak820_outline_0045
                                   1492 	.globl _ak820_outline_0050
                                   1493 	.globl _ak820_outline_0054
                                   1494 	.globl _ak820_outline_0055
                                   1495 	.globl _ak820_outline_0058
                                   1496 	.globl _ak820_outline_0060
                                   1497 	.globl _ak820_outline_0064
                                   1498 	.globl _ak820_outline_0074
                                   1499 	.globl _ak820_outline_0077
                                   1500 	.globl _ak820_outline_0092
                                   1501 	.globl _ak820_outline_0097
                                   1502 	.globl _ak820_outline_0099
                                   1503 	.globl _ak820_outline_0103
                                   1504 	.globl _ak820_outline_0104
                                   1505 	.globl _ak820_outline_0116
                                   1506 	.globl _ak820_outline_0117
                                   1507 	.globl _ak820_outline_0121
                                   1508 	.globl _ak820_outline_0131
                                   1509 	.globl _ak820_outline_0149
                                   1510 	.globl _ak820_outline_0152
                                   1511 	.globl _ak820_outline_0184
                                   1512 
                                   1513 	.area CSEG (CODE)
                                   1514 ; function ak820_outline_0011
      004A2D                       1515 _ak820_outline_0011:
      004A2D 2E               [12] 1516 	add	a,r6
      004A2E FC               [12] 1517 	mov	r4,a
      004A2F E4               [12] 1518 	clr	a
      004A30 3F               [12] 1519 	addc	a,r7
      004A31 FD               [12] 1520 	mov	r5,a
      004A32 8C 82            [24] 1521 	mov	dpl,r4
      004A34 8D 83            [24] 1522 	mov	dph,r5
      004A36 E0               [24] 1523 	movx	a,@dptr
      004A37 22               [24] 1524 	ret
                                   1525 
                                   1526 	.area CSEG (CODE)
                                   1527 ; function ak820_outline_0012
      004A38                       1528 _ak820_outline_0012:
      004A38 2E               [12] 1529 	add	a,r6
      004A39 FB               [12] 1530 	mov	r3,a
      004A3A E4               [12] 1531 	clr	a
      004A3B 3F               [12] 1532 	addc	a,r7
      004A3C FC               [12] 1533 	mov	r4,a
      004A3D 8B 82            [24] 1534 	mov	dpl,r3
      004A3F 8C 83            [24] 1535 	mov	dph,r4
      004A41 E0               [24] 1536 	movx	a,@dptr
      004A42 22               [24] 1537 	ret
                                   1538 
                                   1539 	.area CSEG (CODE)
                                   1540 ; function ak820_outline_0018
      004A43                       1541 _ak820_outline_0018:
      004A43 EF               [12] 1542 	mov	a,r7
      004A44 24 AA            [12] 1543 	add	a,#_source_state
      004A46 FD               [12] 1544 	mov	r5,a
      004A47 E4               [12] 1545 	clr	a
      004A48 34 05            [12] 1546 	addc	a,#(_source_state>>8)
      004A4A FE               [12] 1547 	mov	r6,a
      004A4B 8D 82            [24] 1548 	mov	dpl,r5
      004A4D 8E 83            [24] 1549 	mov	dph,r6
      004A4F E0               [24] 1550 	movx	a,@dptr
      004A50 FC               [12] 1551 	mov	r4,a
      004A51 22               [24] 1552 	ret
                                   1553 
                                   1554 	.area CSEG (CODE)
                                   1555 ; function ak820_outline_0022
      004A52                       1556 _ak820_outline_0022:
      004A52 90 0D 80         [24] 1557 	mov	dptr,#___memcpy_PARM_2
      004A55 EC               [12] 1558 	mov	a,r4
      004A56 F0               [24] 1559 	movx	@dptr,a
      004A57 ED               [12] 1560 	mov	a,r5
      004A58 A3               [24] 1561 	inc	dptr
      004A59 F0               [24] 1562 	movx	@dptr,a
      004A5A E4               [12] 1563 	clr	a
      004A5B A3               [24] 1564 	inc	dptr
      004A5C F0               [24] 1565 	movx	@dptr,a
      004A5D 90 0D 83         [24] 1566 	mov	dptr,#___memcpy_PARM_3
      004A60 74 02            [12] 1567 	mov	a,#0x02
      004A62 F0               [24] 1568 	movx	@dptr,a
      004A63 E4               [12] 1569 	clr	a
      004A64 A3               [24] 1570 	inc	dptr
      004A65 F0               [24] 1571 	movx	@dptr,a
      004A66 90 06 30         [24] 1572 	mov	dptr,#_ak820_tapping_source_PARM_1
      004A69 F5 F0            [12] 1573 	mov	b,a
      004A6B 22               [24] 1574 	ret
                                   1575 
                                   1576 	.area CSEG (CODE)
                                   1577 ; function ak820_outline_0045
      004A6C                       1578 _ak820_outline_0045:
      004A6C 2E               [12] 1579 	add	a,r6
      004A6D FA               [12] 1580 	mov	r2,a
      004A6E E4               [12] 1581 	clr	a
      004A6F 3F               [12] 1582 	addc	a,r7
      004A70 FB               [12] 1583 	mov	r3,a
      004A71 8A 82            [24] 1584 	mov	dpl,r2
      004A73 8B 83            [24] 1585 	mov	dph,r3
      004A75 E0               [24] 1586 	movx	a,@dptr
      004A76 22               [24] 1587 	ret
                                   1588 
                                   1589 	.area CSEG (CODE)
                                   1590 ; function ak820_outline_0054
      004A77                       1591 _ak820_outline_0054:
      004A77 74 01            [12] 1592 	mov	a,#0x01
      004A79 F0               [24] 1593 	movx	@dptr,a
      004A7A 8E 82            [24] 1594 	mov	dpl,r6
      004A7C 8F 83            [24] 1595 	mov	dph,r7
      004A7E 22               [24] 1596 	ret
                                   1597 
                                   1598 	.area CSEG (CODE)
                                   1599 ; function ak820_outline_0055
      004A7F                       1600 _ak820_outline_0055:
      004A7F FC               [12] 1601 	mov	r4,a
      004A80 8B 82            [24] 1602 	mov	dpl,r3
      004A82 8C 83            [24] 1603 	mov	dph,r4
      004A84 E0               [24] 1604 	movx	a,@dptr
      004A85 FA               [12] 1605 	mov	r2,a
      004A86 22               [24] 1606 	ret
                                   1607 
                                   1608 	.area CSEG (CODE)
                                   1609 ; function ak820_outline_0058
      004A87                       1610 _ak820_outline_0058:
      004A87 EE               [12] 1611 	mov	a,r6
      004A88 F0               [24] 1612 	movx	@dptr,a
      004A89 EF               [12] 1613 	mov	a,r7
      004A8A A3               [24] 1614 	inc	dptr
      004A8B F0               [24] 1615 	movx	@dptr,a
      004A8C 22               [24] 1616 	ret
                                   1617 
                                   1618 	.area CSEG (CODE)
                                   1619 ; function ak820_outline_0074
      004A8D                       1620 _ak820_outline_0074:
      004A8D 8D 82            [24] 1621 	mov	dpl,r5
      004A8F 8E 83            [24] 1622 	mov	dph,r6
      004A91 E0               [24] 1623 	movx	a,@dptr
      004A92 FC               [12] 1624 	mov	r4,a
      004A93 22               [24] 1625 	ret
                                   1626 
                                   1627 	.area CSEG (CODE)
                                   1628 ; function ak820_outline_0077
      004A94                       1629 _ak820_outline_0077:
      004A94 24 AA            [12] 1630 	add	a,#_source_state
      004A96 FC               [12] 1631 	mov	r4,a
      004A97 E4               [12] 1632 	clr	a
      004A98 34 05            [12] 1633 	addc	a,#(_source_state>>8)
      004A9A FD               [12] 1634 	mov	r5,a
      004A9B 8C 82            [24] 1635 	mov	dpl,r4
      004A9D 8D 83            [24] 1636 	mov	dph,r5
      004A9F E0               [24] 1637 	movx	a,@dptr
      004AA0 FB               [12] 1638 	mov	r3,a
      004AA1 22               [24] 1639 	ret
                                   1640 
                                   1641 	.area CSEG (CODE)
                                   1642 ; function ak820_outline_0149
      004AA2                       1643 _ak820_outline_0149:
      004AA2 90 0D 91         [24] 1644 	mov	dptr,#_pending
      004AA5 74 FF            [12] 1645 	mov	a,#0xff
      004AA7 F0               [24] 1646 	movx	@dptr,a
      004AA8 22               [24] 1647 	ret
