                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module process_tri_layer
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _layer_hold_off
                                     13 	.globl _layer_hold_on
                                     14 	.globl _ak820_cache_keycode
                                     15 	.globl _get_tri_layer_upper_layer
                                     16 	.globl _get_tri_layer_lower_layer
                                     17 	.globl _ADC_START
                                     18 	.globl _S0_R_FIFO
                                     19 	.globl _S0_T_FIFO
                                     20 	.globl _S0_FREE
                                     21 	.globl _S0_IF_BYTE
                                     22 	.globl _S0_IF_FIRST
                                     23 	.globl _S0_IF_OV
                                     24 	.globl _S0_FST_ACT
                                     25 	.globl _CP_RL2
                                     26 	.globl _C_T2
                                     27 	.globl _TR2
                                     28 	.globl _EXEN2
                                     29 	.globl _TCLK
                                     30 	.globl _RCLK
                                     31 	.globl _EXF2
                                     32 	.globl _CAP1F
                                     33 	.globl _TF2
                                     34 	.globl _RI
                                     35 	.globl _TI
                                     36 	.globl _RB8
                                     37 	.globl _TB8
                                     38 	.globl _REN
                                     39 	.globl _SM2
                                     40 	.globl _SM1
                                     41 	.globl _SM0
                                     42 	.globl _IT0
                                     43 	.globl _IE0
                                     44 	.globl _IT1
                                     45 	.globl _IE1
                                     46 	.globl _TR0
                                     47 	.globl _TF0
                                     48 	.globl _TR1
                                     49 	.globl _TF1
                                     50 	.globl _P4_0
                                     51 	.globl _P4_1
                                     52 	.globl _P4_2
                                     53 	.globl _P4_3
                                     54 	.globl _P4_4
                                     55 	.globl _P4_5
                                     56 	.globl _P4_6
                                     57 	.globl _RXD
                                     58 	.globl _TXD
                                     59 	.globl _INT0
                                     60 	.globl _INT1
                                     61 	.globl _T0
                                     62 	.globl _T1
                                     63 	.globl _MOSI1
                                     64 	.globl _MISO1
                                     65 	.globl _SCK1
                                     66 	.globl _P3_0
                                     67 	.globl _P3_1
                                     68 	.globl _P3_2
                                     69 	.globl _P3_3
                                     70 	.globl _P3_4
                                     71 	.globl _P3_5
                                     72 	.globl _P3_6
                                     73 	.globl _P3_7
                                     74 	.globl _CAP1_
                                     75 	.globl _T2_
                                     76 	.globl _CAP2_
                                     77 	.globl _T2EX_
                                     78 	.globl _RXD1
                                     79 	.globl _TXD1
                                     80 	.globl _P2_0
                                     81 	.globl _P2_1
                                     82 	.globl _P2_2
                                     83 	.globl _P2_3
                                     84 	.globl _P2_4
                                     85 	.globl _P2_5
                                     86 	.globl _P2_6
                                     87 	.globl _P2_7
                                     88 	.globl _AIN0
                                     89 	.globl _AIN1
                                     90 	.globl _AIN2
                                     91 	.globl _AIN3
                                     92 	.globl _AIN4
                                     93 	.globl _AIN5
                                     94 	.globl _AIN6
                                     95 	.globl _AIN7
                                     96 	.globl _CAP1
                                     97 	.globl _T2
                                     98 	.globl _CAP2
                                     99 	.globl _T2EX
                                    100 	.globl _INT0_
                                    101 	.globl _SCS
                                    102 	.globl _MOSI
                                    103 	.globl _MISO
                                    104 	.globl _SCK
                                    105 	.globl _RXD1_
                                    106 	.globl _TXD1_
                                    107 	.globl _P1_0
                                    108 	.globl _P1_1
                                    109 	.globl _P1_2
                                    110 	.globl _P1_3
                                    111 	.globl _P1_4
                                    112 	.globl _P1_5
                                    113 	.globl _P1_6
                                    114 	.globl _P1_7
                                    115 	.globl _AIN8
                                    116 	.globl _AIN9
                                    117 	.globl _AIN10
                                    118 	.globl _AIN11
                                    119 	.globl _AIN12
                                    120 	.globl _AIN13
                                    121 	.globl _RXD_
                                    122 	.globl _TXD_
                                    123 	.globl _SCL0
                                    124 	.globl _SDA0
                                    125 	.globl _P0_0
                                    126 	.globl _P0_1
                                    127 	.globl _P0_2
                                    128 	.globl _P0_3
                                    129 	.globl _P0_4
                                    130 	.globl _P0_5
                                    131 	.globl _P0_6
                                    132 	.globl _P0_7
                                    133 	.globl _IE_SPI0
                                    134 	.globl _IE_USB
                                    135 	.globl _IE_ADC
                                    136 	.globl _IE_UART1
                                    137 	.globl _IE_PWM_I2C
                                    138 	.globl _IE_GPIO
                                    139 	.globl _IE_WDOG
                                    140 	.globl _PX0
                                    141 	.globl _PT0
                                    142 	.globl _PX1
                                    143 	.globl _PT1
                                    144 	.globl _PS
                                    145 	.globl _PT2
                                    146 	.globl _PL_FLAG
                                    147 	.globl _PH_FLAG
                                    148 	.globl _EX0
                                    149 	.globl _ET0
                                    150 	.globl _EX1
                                    151 	.globl _ET1
                                    152 	.globl _ES
                                    153 	.globl _ET2
                                    154 	.globl _E_DIS
                                    155 	.globl _EA
                                    156 	.globl _P
                                    157 	.globl _F1
                                    158 	.globl _OV
                                    159 	.globl _RS0
                                    160 	.globl _RS1
                                    161 	.globl _F0
                                    162 	.globl _AC
                                    163 	.globl _CY
                                    164 	.globl _I2CS_INT_ST
                                    165 	.globl _I2CX_INT
                                    166 	.globl _LED_STATUS
                                    167 	.globl _LED_DMA_H
                                    168 	.globl _LED_DMA_L
                                    169 	.globl _LED_DMA
                                    170 	.globl _LED_PWM_OE
                                    171 	.globl _LED_COMMON
                                    172 	.globl _ADC_CHAN
                                    173 	.globl _ADC_DAT_H
                                    174 	.globl _ADC_DAT_L
                                    175 	.globl _ADC_DAT
                                    176 	.globl _ADC_CTRL
                                    177 	.globl _SPI1_CK_SE
                                    178 	.globl _SPI1_CTRL
                                    179 	.globl _SPI1_DATA
                                    180 	.globl _SPI1_STAT
                                    181 	.globl _SIF1
                                    182 	.globl _SBAUD1
                                    183 	.globl _SBUF1
                                    184 	.globl _SCON1
                                    185 	.globl _SPI0_SETUP
                                    186 	.globl _SPI0_CK_SE
                                    187 	.globl _SPI0_CTRL
                                    188 	.globl _SPI0_DATA
                                    189 	.globl _SPI0_STAT
                                    190 	.globl _T2CAP1H
                                    191 	.globl _T2CAP1L
                                    192 	.globl _T2CAP1
                                    193 	.globl _TH2
                                    194 	.globl _TL2
                                    195 	.globl _T2COUNT
                                    196 	.globl _RCAP2H
                                    197 	.globl _RCAP2L
                                    198 	.globl _RCAP2
                                    199 	.globl _T2MOD
                                    200 	.globl _T2CON
                                    201 	.globl _SBUF
                                    202 	.globl _SCON
                                    203 	.globl _TH1
                                    204 	.globl _TH0
                                    205 	.globl _TL1
                                    206 	.globl _TL0
                                    207 	.globl _TMOD
                                    208 	.globl _TCON
                                    209 	.globl _XBUS_AUX
                                    210 	.globl _P7
                                    211 	.globl _P6_DIR
                                    212 	.globl _P6_OUT_PU
                                    213 	.globl _P6_IN
                                    214 	.globl _P5_DIR
                                    215 	.globl _P5_OUT_PU
                                    216 	.globl _P5_IN
                                    217 	.globl _P4_LED_KEY
                                    218 	.globl _P4_DIR_PU
                                    219 	.globl _P4_MOD_OC
                                    220 	.globl _P4
                                    221 	.globl _P3_DIR_PU
                                    222 	.globl _P3_MOD_OC
                                    223 	.globl _P3
                                    224 	.globl _P2_DIR_PU
                                    225 	.globl _P2_MOD_OC
                                    226 	.globl _P2
                                    227 	.globl _P1_DIR_PU
                                    228 	.globl _P1_MOD_OC
                                    229 	.globl _P1
                                    230 	.globl _P0_DIR_PU
                                    231 	.globl _P0_MOD_OC
                                    232 	.globl _P0
                                    233 	.globl _ROM_CTRL
                                    234 	.globl _ROM_DATA_HH
                                    235 	.globl _ROM_DATA_HL
                                    236 	.globl _ROM_DATA_HI
                                    237 	.globl _ROM_ADDR_H
                                    238 	.globl _ROM_ADDR_L
                                    239 	.globl _ROM_ADDR
                                    240 	.globl _GPIO_IE
                                    241 	.globl _IP_EX
                                    242 	.globl _IE_EX
                                    243 	.globl _IP
                                    244 	.globl _IE
                                    245 	.globl _WDOG_COUNT
                                    246 	.globl _RESET_KEEP
                                    247 	.globl _WAKE_CTRL
                                    248 	.globl _CLOCK_CFG
                                    249 	.globl _POWER_CFG
                                    250 	.globl _PCON
                                    251 	.globl _GLOBAL_CFG
                                    252 	.globl _SAFE_MOD
                                    253 	.globl _DPH
                                    254 	.globl _DPL
                                    255 	.globl _SP
                                    256 	.globl _A_INV
                                    257 	.globl _B
                                    258 	.globl _ACC
                                    259 	.globl _PSW
                                    260 	.globl _process_tri_layer_PARM_2
                                    261 	.globl _clear_macro_tri_layer
                                    262 	.globl _process_tri_layer
                                    263 ;--------------------------------------------------------
                                    264 ; special function registers
                                    265 ;--------------------------------------------------------
                                    266 	.area RSEG    (ABS,DATA)
      000000                        267 	.org 0x0000
                           0000D0   268 _PSW	=	0x00d0
                           0000E0   269 _ACC	=	0x00e0
                           0000F0   270 _B	=	0x00f0
                           0000FD   271 _A_INV	=	0x00fd
                           000081   272 _SP	=	0x0081
                           000082   273 _DPL	=	0x0082
                           000083   274 _DPH	=	0x0083
                           0000A1   275 _SAFE_MOD	=	0x00a1
                           0000B1   276 _GLOBAL_CFG	=	0x00b1
                           000087   277 _PCON	=	0x0087
                           0000BA   278 _POWER_CFG	=	0x00ba
                           0000B9   279 _CLOCK_CFG	=	0x00b9
                           0000A9   280 _WAKE_CTRL	=	0x00a9
                           0000FE   281 _RESET_KEEP	=	0x00fe
                           0000FF   282 _WDOG_COUNT	=	0x00ff
                           0000A8   283 _IE	=	0x00a8
                           0000B8   284 _IP	=	0x00b8
                           0000E8   285 _IE_EX	=	0x00e8
                           0000E9   286 _IP_EX	=	0x00e9
                           0000B2   287 _GPIO_IE	=	0x00b2
                           008584   288 _ROM_ADDR	=	0x8584
                           000084   289 _ROM_ADDR_L	=	0x0084
                           000085   290 _ROM_ADDR_H	=	0x0085
                           008F8E   291 _ROM_DATA_HI	=	0x8f8e
                           00008E   292 _ROM_DATA_HL	=	0x008e
                           00008F   293 _ROM_DATA_HH	=	0x008f
                           000086   294 _ROM_CTRL	=	0x0086
                           000080   295 _P0	=	0x0080
                           0000C4   296 _P0_MOD_OC	=	0x00c4
                           0000C5   297 _P0_DIR_PU	=	0x00c5
                           000090   298 _P1	=	0x0090
                           000092   299 _P1_MOD_OC	=	0x0092
                           000093   300 _P1_DIR_PU	=	0x0093
                           0000A0   301 _P2	=	0x00a0
                           000094   302 _P2_MOD_OC	=	0x0094
                           000095   303 _P2_DIR_PU	=	0x0095
                           0000B0   304 _P3	=	0x00b0
                           000096   305 _P3_MOD_OC	=	0x0096
                           000097   306 _P3_DIR_PU	=	0x0097
                           0000C0   307 _P4	=	0x00c0
                           0000C2   308 _P4_MOD_OC	=	0x00c2
                           0000C3   309 _P4_DIR_PU	=	0x00c3
                           0000C1   310 _P4_LED_KEY	=	0x00c1
                           0000AA   311 _P5_IN	=	0x00aa
                           0000AB   312 _P5_OUT_PU	=	0x00ab
                           0000AC   313 _P5_DIR	=	0x00ac
                           0000AD   314 _P6_IN	=	0x00ad
                           0000AE   315 _P6_OUT_PU	=	0x00ae
                           0000AF   316 _P6_DIR	=	0x00af
                           0000F1   317 _P7	=	0x00f1
                           0000A2   318 _XBUS_AUX	=	0x00a2
                           000088   319 _TCON	=	0x0088
                           000089   320 _TMOD	=	0x0089
                           00008A   321 _TL0	=	0x008a
                           00008B   322 _TL1	=	0x008b
                           00008C   323 _TH0	=	0x008c
                           00008D   324 _TH1	=	0x008d
                           000098   325 _SCON	=	0x0098
                           000099   326 _SBUF	=	0x0099
                           0000C8   327 _T2CON	=	0x00c8
                           0000C9   328 _T2MOD	=	0x00c9
                           00CBCA   329 _RCAP2	=	0xcbca
                           0000CA   330 _RCAP2L	=	0x00ca
                           0000CB   331 _RCAP2H	=	0x00cb
                           00CDCC   332 _T2COUNT	=	0xcdcc
                           0000CC   333 _TL2	=	0x00cc
                           0000CD   334 _TH2	=	0x00cd
                           00CFCE   335 _T2CAP1	=	0xcfce
                           0000CE   336 _T2CAP1L	=	0x00ce
                           0000CF   337 _T2CAP1H	=	0x00cf
                           0000F8   338 _SPI0_STAT	=	0x00f8
                           0000F9   339 _SPI0_DATA	=	0x00f9
                           0000FA   340 _SPI0_CTRL	=	0x00fa
                           0000FB   341 _SPI0_CK_SE	=	0x00fb
                           0000FC   342 _SPI0_SETUP	=	0x00fc
                           0000BC   343 _SCON1	=	0x00bc
                           0000BD   344 _SBUF1	=	0x00bd
                           0000BE   345 _SBAUD1	=	0x00be
                           0000BF   346 _SIF1	=	0x00bf
                           0000B4   347 _SPI1_STAT	=	0x00b4
                           0000B5   348 _SPI1_DATA	=	0x00b5
                           0000B6   349 _SPI1_CTRL	=	0x00b6
                           0000B7   350 _SPI1_CK_SE	=	0x00b7
                           0000F3   351 _ADC_CTRL	=	0x00f3
                           00F5F4   352 _ADC_DAT	=	0xf5f4
                           0000F4   353 _ADC_DAT_L	=	0x00f4
                           0000F5   354 _ADC_DAT_H	=	0x00f5
                           0000F6   355 _ADC_CHAN	=	0x00f6
                           0000A6   356 _LED_COMMON	=	0x00a6
                           0000A7   357 _LED_PWM_OE	=	0x00a7
                           00C7C6   358 _LED_DMA	=	0xc7c6
                           0000C6   359 _LED_DMA_L	=	0x00c6
                           0000C7   360 _LED_DMA_H	=	0x00c7
                           0000F7   361 _LED_STATUS	=	0x00f7
                           0000B3   362 _I2CX_INT	=	0x00b3
                           0000BB   363 _I2CS_INT_ST	=	0x00bb
                                    364 ;--------------------------------------------------------
                                    365 ; special function bits
                                    366 ;--------------------------------------------------------
                                    367 	.area RSEG    (ABS,DATA)
      000000                        368 	.org 0x0000
                           0000D7   369 _CY	=	0x00d7
                           0000D6   370 _AC	=	0x00d6
                           0000D5   371 _F0	=	0x00d5
                           0000D4   372 _RS1	=	0x00d4
                           0000D3   373 _RS0	=	0x00d3
                           0000D2   374 _OV	=	0x00d2
                           0000D1   375 _F1	=	0x00d1
                           0000D0   376 _P	=	0x00d0
                           0000AF   377 _EA	=	0x00af
                           0000AE   378 _E_DIS	=	0x00ae
                           0000AD   379 _ET2	=	0x00ad
                           0000AC   380 _ES	=	0x00ac
                           0000AB   381 _ET1	=	0x00ab
                           0000AA   382 _EX1	=	0x00aa
                           0000A9   383 _ET0	=	0x00a9
                           0000A8   384 _EX0	=	0x00a8
                           0000BF   385 _PH_FLAG	=	0x00bf
                           0000BE   386 _PL_FLAG	=	0x00be
                           0000BD   387 _PT2	=	0x00bd
                           0000BC   388 _PS	=	0x00bc
                           0000BB   389 _PT1	=	0x00bb
                           0000BA   390 _PX1	=	0x00ba
                           0000B9   391 _PT0	=	0x00b9
                           0000B8   392 _PX0	=	0x00b8
                           0000EF   393 _IE_WDOG	=	0x00ef
                           0000EE   394 _IE_GPIO	=	0x00ee
                           0000ED   395 _IE_PWM_I2C	=	0x00ed
                           0000EC   396 _IE_UART1	=	0x00ec
                           0000EB   397 _IE_ADC	=	0x00eb
                           0000E9   398 _IE_USB	=	0x00e9
                           0000E8   399 _IE_SPI0	=	0x00e8
                           000087   400 _P0_7	=	0x0087
                           000086   401 _P0_6	=	0x0086
                           000085   402 _P0_5	=	0x0085
                           000084   403 _P0_4	=	0x0084
                           000083   404 _P0_3	=	0x0083
                           000082   405 _P0_2	=	0x0082
                           000081   406 _P0_1	=	0x0081
                           000080   407 _P0_0	=	0x0080
                           000081   408 _SDA0	=	0x0081
                           000080   409 _SCL0	=	0x0080
                           000083   410 _TXD_	=	0x0083
                           000082   411 _RXD_	=	0x0082
                           000085   412 _AIN13	=	0x0085
                           000084   413 _AIN12	=	0x0084
                           000083   414 _AIN11	=	0x0083
                           000082   415 _AIN10	=	0x0082
                           000081   416 _AIN9	=	0x0081
                           000080   417 _AIN8	=	0x0080
                           000097   418 _P1_7	=	0x0097
                           000096   419 _P1_6	=	0x0096
                           000095   420 _P1_5	=	0x0095
                           000094   421 _P1_4	=	0x0094
                           000093   422 _P1_3	=	0x0093
                           000092   423 _P1_2	=	0x0092
                           000091   424 _P1_1	=	0x0091
                           000090   425 _P1_0	=	0x0090
                           000097   426 _TXD1_	=	0x0097
                           000096   427 _RXD1_	=	0x0096
                           000097   428 _SCK	=	0x0097
                           000096   429 _MISO	=	0x0096
                           000095   430 _MOSI	=	0x0095
                           000094   431 _SCS	=	0x0094
                           000092   432 _INT0_	=	0x0092
                           000091   433 _T2EX	=	0x0091
                           000091   434 _CAP2	=	0x0091
                           000090   435 _T2	=	0x0090
                           000090   436 _CAP1	=	0x0090
                           000097   437 _AIN7	=	0x0097
                           000096   438 _AIN6	=	0x0096
                           000095   439 _AIN5	=	0x0095
                           000094   440 _AIN4	=	0x0094
                           000093   441 _AIN3	=	0x0093
                           000092   442 _AIN2	=	0x0092
                           000091   443 _AIN1	=	0x0091
                           000090   444 _AIN0	=	0x0090
                           0000A7   445 _P2_7	=	0x00a7
                           0000A6   446 _P2_6	=	0x00a6
                           0000A5   447 _P2_5	=	0x00a5
                           0000A4   448 _P2_4	=	0x00a4
                           0000A3   449 _P2_3	=	0x00a3
                           0000A2   450 _P2_2	=	0x00a2
                           0000A1   451 _P2_1	=	0x00a1
                           0000A0   452 _P2_0	=	0x00a0
                           0000A7   453 _TXD1	=	0x00a7
                           0000A6   454 _RXD1	=	0x00a6
                           0000A5   455 _T2EX_	=	0x00a5
                           0000A5   456 _CAP2_	=	0x00a5
                           0000A4   457 _T2_	=	0x00a4
                           0000A4   458 _CAP1_	=	0x00a4
                           0000B7   459 _P3_7	=	0x00b7
                           0000B6   460 _P3_6	=	0x00b6
                           0000B5   461 _P3_5	=	0x00b5
                           0000B4   462 _P3_4	=	0x00b4
                           0000B3   463 _P3_3	=	0x00b3
                           0000B2   464 _P3_2	=	0x00b2
                           0000B1   465 _P3_1	=	0x00b1
                           0000B0   466 _P3_0	=	0x00b0
                           0000B7   467 _SCK1	=	0x00b7
                           0000B6   468 _MISO1	=	0x00b6
                           0000B5   469 _MOSI1	=	0x00b5
                           0000B5   470 _T1	=	0x00b5
                           0000B4   471 _T0	=	0x00b4
                           0000B3   472 _INT1	=	0x00b3
                           0000B2   473 _INT0	=	0x00b2
                           0000B1   474 _TXD	=	0x00b1
                           0000B0   475 _RXD	=	0x00b0
                           0000C6   476 _P4_6	=	0x00c6
                           0000C5   477 _P4_5	=	0x00c5
                           0000C4   478 _P4_4	=	0x00c4
                           0000C3   479 _P4_3	=	0x00c3
                           0000C2   480 _P4_2	=	0x00c2
                           0000C1   481 _P4_1	=	0x00c1
                           0000C0   482 _P4_0	=	0x00c0
                           00008F   483 _TF1	=	0x008f
                           00008E   484 _TR1	=	0x008e
                           00008D   485 _TF0	=	0x008d
                           00008C   486 _TR0	=	0x008c
                           00008B   487 _IE1	=	0x008b
                           00008A   488 _IT1	=	0x008a
                           000089   489 _IE0	=	0x0089
                           000088   490 _IT0	=	0x0088
                           00009F   491 _SM0	=	0x009f
                           00009E   492 _SM1	=	0x009e
                           00009D   493 _SM2	=	0x009d
                           00009C   494 _REN	=	0x009c
                           00009B   495 _TB8	=	0x009b
                           00009A   496 _RB8	=	0x009a
                           000099   497 _TI	=	0x0099
                           000098   498 _RI	=	0x0098
                           0000CF   499 _TF2	=	0x00cf
                           0000CF   500 _CAP1F	=	0x00cf
                           0000CE   501 _EXF2	=	0x00ce
                           0000CD   502 _RCLK	=	0x00cd
                           0000CC   503 _TCLK	=	0x00cc
                           0000CB   504 _EXEN2	=	0x00cb
                           0000CA   505 _TR2	=	0x00ca
                           0000C9   506 _C_T2	=	0x00c9
                           0000C8   507 _CP_RL2	=	0x00c8
                           0000FF   508 _S0_FST_ACT	=	0x00ff
                           0000FE   509 _S0_IF_OV	=	0x00fe
                           0000FD   510 _S0_IF_FIRST	=	0x00fd
                           0000FC   511 _S0_IF_BYTE	=	0x00fc
                           0000FB   512 _S0_FREE	=	0x00fb
                           0000FA   513 _S0_T_FIFO	=	0x00fa
                           0000F8   514 _S0_R_FIFO	=	0x00f8
                           0000F7   515 _ADC_START	=	0x00f7
                                    516 ;--------------------------------------------------------
                                    517 ; overlayable register banks
                                    518 ;--------------------------------------------------------
                                    519 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        520 	.ds 8
                                    521 ;--------------------------------------------------------
                                    522 ; internal ram data
                                    523 ;--------------------------------------------------------
                                    524 	.area DSEG    (DATA)
                                    525 ;--------------------------------------------------------
                                    526 ; overlayable items in internal ram
                                    527 ;--------------------------------------------------------
                                    528 ;--------------------------------------------------------
                                    529 ; indirectly addressable internal ram data
                                    530 ;--------------------------------------------------------
                                    531 	.area ISEG    (DATA)
                                    532 ;--------------------------------------------------------
                                    533 ; absolute internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area IABS    (ABS,DATA)
                                    536 	.area IABS    (ABS,DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; bit data
                                    539 ;--------------------------------------------------------
                                    540 	.area BSEG    (BIT)
                                    541 ;--------------------------------------------------------
                                    542 ; paged external ram data
                                    543 ;--------------------------------------------------------
                                    544 	.area PSEG    (PAG,XDATA)
                                    545 ;--------------------------------------------------------
                                    546 ; uninitialized external ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area XSEG    (XDATA)
      000BD6                        549 _process_tri_layer_PARM_2:
      000BD6                        550 	.ds 3
      000BD9                        551 _process_tri_layer_keycode_10000_265:
      000BD9                        552 	.ds 2
      000BDB                        553 _process_tri_layer_layer_10000_266:
      000BDB                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; absolute external ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area XABS    (ABS,XDATA)
                                    559 ;--------------------------------------------------------
                                    560 ; initialized external ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area XISEG   (XDATA)
      000DF7                        563 _macro_targets:
      000DF7                        564 	.ds 2
                                    565 	.area HOME    (CODE)
                                    566 	.area GSINIT0 (CODE)
                                    567 	.area GSINIT1 (CODE)
                                    568 	.area GSINIT2 (CODE)
                                    569 	.area GSINIT3 (CODE)
                                    570 	.area GSINIT4 (CODE)
                                    571 	.area GSINIT5 (CODE)
                                    572 	.area GSINIT  (CODE)
                                    573 	.area GSFINAL (CODE)
                                    574 	.area CSEG    (CODE)
                                    575 ;--------------------------------------------------------
                                    576 ; global & static initialisations
                                    577 ;--------------------------------------------------------
                                    578 	.area HOME    (CODE)
                                    579 	.area GSINIT  (CODE)
                                    580 	.area GSFINAL (CODE)
                                    581 	.area GSINIT  (CODE)
                                    582 ;--------------------------------------------------------
                                    583 ; Home
                                    584 ;--------------------------------------------------------
                                    585 	.area HOME    (CODE)
                                    586 	.area HOME    (CODE)
                                    587 ;--------------------------------------------------------
                                    588 ; code
                                    589 ;--------------------------------------------------------
                                    590 	.area CSEG    (CODE)
                                    591 ;------------------------------------------------------------
                                    592 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    593 ;------------------------------------------------------------
                                    594 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_179'
                                    595 ;------------------------------------------------------------
                                    596 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    597 ;	-----------------------------------------
                           000007   598 	ar7 = 0x07
                           000006   599 	ar6 = 0x06
                           000005   600 	ar5 = 0x05
                           000004   601 	ar4 = 0x04
                           000003   602 	ar3 = 0x03
                           000002   603 	ar2 = 0x02
                           000001   604 	ar1 = 0x01
                           000000   605 	ar0 = 0x00
                                    606 ;	 function clear_macro_tri_layer
                                    607 ;	-----------------------------------------
      009D2E                        608 _clear_macro_tri_layer:
      009D2E 90 0D F8         [24]  609 	mov	dptr,#(_macro_targets + 0x0001)
      009D31 74 FF            [12]  610 	mov	a,#0xff
      009D33 F0               [24]  611 	movx	@dptr,a
      009D34 90 0D F7         [24]  612 	mov	dptr,#_macro_targets
      009D37 F0               [24]  613 	movx	@dptr,a
      009D38 22               [24]  614 	ret
                                    615 ;------------------------------------------------------------
                                    616 ;Allocation info for local variables in function 'process_tri_layer'
                                    617 ;------------------------------------------------------------
                                    618 ;record_argument Allocated with name '_process_tri_layer_PARM_2'
                                    619 ;keycode       Allocated with name '_process_tri_layer_keycode_10000_265'
                                    620 ;record        Allocated with name '_process_tri_layer_record_10000_266'
                                    621 ;layer         Allocated with name '_process_tri_layer_layer_10000_266'
                                    622 ;role          Allocated with name '_process_tri_layer_role_30000_273'
                                    623 ;------------------------------------------------------------
                                    624 ;	quantum/process_keycode/process_tri_layer.c:17: bool process_tri_layer(uint16_t keycode, keyrecord_t *record_argument) {
                                    625 ;	-----------------------------------------
                                    626 ;	 function process_tri_layer
                                    627 ;	-----------------------------------------
      009D39                        628 _process_tri_layer:
      009D39 12 3A 8A         [24]  629 	lcall	_ak820_outline_0103
      009D3C 90 0B D9         [24]  630 	mov	dptr,#_process_tri_layer_keycode_10000_265
      009D3F 12 3A 8F         [24]  631 	lcall	_ak820_outline_0104
                                    632 ;	quantum/process_keycode/process_tri_layer.c:19: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009D42 90 0B D6         [24]  633 	mov	dptr,#_process_tri_layer_PARM_2
      009D45 12 3A 47         [24]  634 	lcall	_ak820_outline_0050
                                    635 ;	quantum/process_keycode/process_tri_layer.c:24: if (keycode == QK_TRI_LAYER_LOWER) {
      009D48 90 0B D9         [24]  636 	mov	dptr,#_process_tri_layer_keycode_10000_265
      009D4B 12 3A 66         [24]  637 	lcall	_ak820_outline_0059
      009D4E BC 77 1E         [24]  638 	cjne	r4,#0x77,00105$
      009D51 BD 7C 1B         [24]  639 	cjne	r5,#0x7c,00105$
                                    640 ;	quantum/process_keycode/process_tri_layer.c:25: layer = get_tri_layer_lower_layer();
      009D54 C0 07            [24]  641 	push	ar7
      009D56 C0 06            [24]  642 	push	ar6
      009D58 C0 05            [24]  643 	push	ar5
      009D5A C0 04            [24]  644 	push	ar4
      009D5C 12 A5 7B         [24]  645 	lcall	_get_tri_layer_lower_layer
      009D5F E5 82            [12]  646 	mov	a, dpl
      009D61 D0 04            [24]  647 	pop	ar4
      009D63 D0 05            [24]  648 	pop	ar5
      009D65 D0 06            [24]  649 	pop	ar6
      009D67 D0 07            [24]  650 	pop	ar7
      009D69 90 0B DB         [24]  651 	mov	dptr,#_process_tri_layer_layer_10000_266
      009D6C F0               [24]  652 	movx	@dptr,a
      009D6D 80 25            [24]  653 	sjmp	00106$
      009D6F                        654 00105$:
                                    655 ;	quantum/process_keycode/process_tri_layer.c:26: } else if (keycode == QK_TRI_LAYER_UPPER) {
      009D6F BC 78 1E         [24]  656 	cjne	r4,#0x78,00102$
      009D72 BD 7C 1B         [24]  657 	cjne	r5,#0x7c,00102$
                                    658 ;	quantum/process_keycode/process_tri_layer.c:27: layer = get_tri_layer_upper_layer();
      009D75 C0 07            [24]  659 	push	ar7
      009D77 C0 06            [24]  660 	push	ar6
      009D79 C0 05            [24]  661 	push	ar5
      009D7B C0 04            [24]  662 	push	ar4
      009D7D 12 A5 82         [24]  663 	lcall	_get_tri_layer_upper_layer
      009D80 E5 82            [12]  664 	mov	a, dpl
      009D82 D0 04            [24]  665 	pop	ar4
      009D84 D0 05            [24]  666 	pop	ar5
      009D86 D0 06            [24]  667 	pop	ar6
      009D88 D0 07            [24]  668 	pop	ar7
      009D8A 90 0B DB         [24]  669 	mov	dptr,#_process_tri_layer_layer_10000_266
      009D8D F0               [24]  670 	movx	@dptr,a
      009D8E 80 04            [24]  671 	sjmp	00106$
      009D90                        672 00102$:
                                    673 ;	quantum/process_keycode/process_tri_layer.c:29: return true;
      009D90 75 82 01         [24]  674 	mov	dpl, #0x01
      009D93 22               [24]  675 	ret
      009D94                        676 00106$:
                                    677 ;	quantum/process_keycode/process_tri_layer.c:32: if (ak820_macro_primitive) {
      009D94 90 09 8C         [24]  678 	mov	dptr,#_ak820_macro_primitive
      009D97 E0               [24]  679 	movx	a,@dptr
      009D98 60 5A            [24]  680 	jz	00117$
                                    681 ;	quantum/process_keycode/process_tri_layer.c:33: uint8_t role = keycode == QK_TRI_LAYER_UPPER;
      009D9A E4               [12]  682 	clr	a
      009D9B BC 78 04         [24]  683 	cjne	r4,#0x78,00193$
      009D9E BD 7C 01         [24]  684 	cjne	r5,#0x7c,00193$
      009DA1 04               [12]  685 	inc	a
      009DA2                        686 00193$:
      009DA2 FD               [12]  687 	mov	r5,a
                                    688 ;	quantum/process_keycode/process_tri_layer.c:34: if (record->event.pressed) {
      009DA3 74 05            [12]  689 	mov	a,#0x05
      009DA5 12 4A 38         [24]  690 	lcall	_ak820_outline_0012
      009DA8 60 19            [24]  691 	jz	00112$
                                    692 ;	quantum/process_keycode/process_tri_layer.c:35: if (macro_targets[role] == 255) macro_targets[role] = layer;
      009DAA ED               [12]  693 	mov	a,r5
      009DAB 24 F7            [12]  694 	add	a, #_macro_targets
      009DAD F9               [12]  695 	mov	r1,a
      009DAE E4               [12]  696 	clr	a
      009DAF 34 0D            [12]  697 	addc	a, #(_macro_targets >> 8)
      009DB1 FA               [12]  698 	mov	r2,a
      009DB2 12 45 9D         [24]  699 	lcall	_ak820_outline_0178
      009DB5 E0               [24]  700 	movx	a,@dptr
      009DB6 F8               [12]  701 	mov	r0,a
      009DB7 B8 FF 1C         [24]  702 	cjne	r0,#0xff,00113$
      009DBA 90 0B DB         [24]  703 	mov	dptr,#_process_tri_layer_layer_10000_266
      009DBD E0               [24]  704 	movx	a,@dptr
      009DBE 12 6E 0B         [24]  705 	lcall	_ak820_outline_0135
      009DC1 80 13            [24]  706 	sjmp	00113$
      009DC3                        707 00112$:
                                    708 ;	quantum/process_keycode/process_tri_layer.c:36: } else if (macro_targets[role] == 255) return false;
      009DC3 ED               [12]  709 	mov	a,r5
      009DC4 24 F7            [12]  710 	add	a, #_macro_targets
      009DC6 F5 82            [12]  711 	mov	dpl,a
      009DC8 E4               [12]  712 	clr	a
      009DC9 34 0D            [12]  713 	addc	a, #(_macro_targets >> 8)
      009DCB F5 83            [12]  714 	mov	dph,a
      009DCD E0               [24]  715 	movx	a,@dptr
      009DCE FA               [12]  716 	mov	r2,a
      009DCF BA FF 04         [24]  717 	cjne	r2,#0xff,00113$
      009DD2 75 82 00         [24]  718 	mov	dpl, #0x00
      009DD5 22               [24]  719 	ret
      009DD6                        720 00113$:
                                    721 ;	quantum/process_keycode/process_tri_layer.c:37: layer = macro_targets[role];
      009DD6 ED               [12]  722 	mov	a,r5
      009DD7 24 F7            [12]  723 	add	a, #_macro_targets
      009DD9 FA               [12]  724 	mov	r2,a
      009DDA E4               [12]  725 	clr	a
      009DDB 34 0D            [12]  726 	addc	a, #(_macro_targets >> 8)
      009DDD FD               [12]  727 	mov	r5,a
      009DDE 8A 82            [24]  728 	mov	dpl,r2
      009DE0 8D 83            [24]  729 	mov	dph,r5
      009DE2 E0               [24]  730 	movx	a,@dptr
      009DE3 90 0B DB         [24]  731 	mov	dptr,#_process_tri_layer_layer_10000_266
      009DE6 F0               [24]  732 	movx	@dptr,a
                                    733 ;	quantum/process_keycode/process_tri_layer.c:38: if (!record->event.pressed) macro_targets[role] = 255;
      009DE7 12 36 42         [24]  734 	lcall	_ak820_outline_0121
      009DEA E0               [24]  735 	movx	a,@dptr
      009DEB 70 07            [24]  736 	jnz	00117$
      009DED 8A 82            [24]  737 	mov	dpl,r2
      009DEF 8D 83            [24]  738 	mov	dph,r5
      009DF1 74 FF            [12]  739 	mov	a,#0xff
      009DF3 F0               [24]  740 	movx	@dptr,a
      009DF4                        741 00117$:
                                    742 ;	quantum/process_keycode/process_tri_layer.c:41: if (record->event.pressed) {
      009DF4 74 05            [12]  743 	mov	a,#0x05
      009DF6 12 4A 2D         [24]  744 	lcall	_ak820_outline_0011
      009DF9 60 38            [24]  745 	jz	00121$
                                    746 ;	quantum/process_keycode/process_tri_layer.c:47: if (!get_repeat_key_count())
      009DFB 12 A2 22         [24]  747 	lcall	_get_repeat_key_count
      009DFE E5 82            [12]  748 	mov	a, dpl
      009E00 70 26            [24]  749 	jnz	00119$
                                    750 ;	quantum/process_keycode/process_tri_layer.c:49: ak820_cache_keycode(AK820_KEYPOS_VALUE(record->event.key), QK_MOMENTARY + layer);
      009E02 12 78 53         [24]  751 	lcall	_ak820_outline_0019
      009E05 7E 00            [12]  752 	mov	r6,#0x00
      009E07 42 05            [12]  753 	orl	ar5,a
      009E09 EE               [12]  754 	mov	a,r6
      009E0A 42 04            [12]  755 	orl	ar4,a
      009E0C 90 0B DB         [24]  756 	mov	dptr,#_process_tri_layer_layer_10000_266
      009E0F E0               [24]  757 	movx	a,@dptr
      009E10 FE               [12]  758 	mov	r6,a
      009E11 7F 00            [12]  759 	mov	r7,#0x00
      009E13 74 20            [12]  760 	mov	a,#0x20
      009E15 2E               [12]  761 	add	a, r6
      009E16 FE               [12]  762 	mov	r6,a
      009E17 74 52            [12]  763 	mov	a,#0x52
      009E19 3F               [12]  764 	addc	a, r7
      009E1A FF               [12]  765 	mov	r7,a
      009E1B 90 09 69         [24]  766 	mov	dptr,#_ak820_cache_keycode_PARM_2
      009E1E 12 4A 87         [24]  767 	lcall	_ak820_outline_0058
      009E21 8D 82            [24]  768 	mov	dpl, r5
      009E23 8C 83            [24]  769 	mov	dph, r4
      009E25 12 7B 32         [24]  770 	lcall	_ak820_cache_keycode
      009E28                        771 00119$:
                                    772 ;	quantum/process_keycode/process_tri_layer.c:51: layer_hold_on(layer);
      009E28 90 0B DB         [24]  773 	mov	dptr,#_process_tri_layer_layer_10000_266
      009E2B E0               [24]  774 	movx	a,@dptr
      009E2C F5 82            [12]  775 	mov	dpl,a
      009E2E 12 79 85         [24]  776 	lcall	_layer_hold_on
      009E31 80 09            [24]  777 	sjmp	00122$
      009E33                        778 00121$:
                                    779 ;	quantum/process_keycode/process_tri_layer.c:53: layer_hold_off(layer);
      009E33 90 0B DB         [24]  780 	mov	dptr,#_process_tri_layer_layer_10000_266
      009E36 E0               [24]  781 	movx	a,@dptr
      009E37 F5 82            [12]  782 	mov	dpl,a
      009E39 12 79 BD         [24]  783 	lcall	_layer_hold_off
      009E3C                        784 00122$:
                                    785 ;	quantum/process_keycode/process_tri_layer.c:58: return false;
      009E3C 75 82 00         [24]  786 	mov	dpl, #0x00
                                    787 ;	quantum/process_keycode/process_tri_layer.c:59: }
      009E3F 22               [24]  788 	ret
                                    789 	.area CSEG    (CODE)
                                    790 	.area CONST   (CODE)
                                    791 	.area XINIT   (CODE)
      00C156                        792 __xinit__macro_targets:
      00C156 FF                     793 	.db #0xff	; 255
      00C157 FF                     794 	.db #0xff	; 255
                                    795 	.area CABS    (ABS,CODE)
                                    796 
                                    797 ; Experimental exact instruction outlining.
                                    798 	.globl _ak820_outline_0011
                                    799 	.globl _ak820_outline_0012
                                    800 	.globl _ak820_outline_0019
                                    801 	.globl _ak820_outline_0050
                                    802 	.globl _ak820_outline_0058
                                    803 	.globl _ak820_outline_0059
                                    804 	.globl _ak820_outline_0103
                                    805 	.globl _ak820_outline_0104
                                    806 	.globl _ak820_outline_0121
                                    807 	.globl _ak820_outline_0135
                                    808 	.globl _ak820_outline_0178
