                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_autoshift_cancel
                                     14 	.globl _ak820_autoshift_process
                                     15 	.globl _ak820_autoshift_before
                                     16 	.globl _ak820_oneshot_cancel
                                     17 	.globl _ak820_oneshot_post
                                     18 	.globl _ak820_oneshot_process
                                     19 	.globl _ak820_tapping_source
                                     20 	.globl _ak820_tapping_cancel
                                     21 	.globl _ak820_tapping_process
                                     22 	.globl _ak820_tapping_before
                                     23 	.globl _pre_process_record_quantum
                                     24 	.globl _get_record_keycode
                                     25 	.globl _repeat_key_cancel
                                     26 	.globl _clear_owned_usages
                                     27 	.globl _owned_usage_key
                                     28 	.globl _clear_owned_keys
                                     29 	.globl _del_owned_key
                                     30 	.globl _add_owned_key
                                     31 	.globl _clear_owned_mods
                                     32 	.globl _del_owned_weak_mods
                                     33 	.globl _add_owned_weak_mods
                                     34 	.globl _del_owned_mods
                                     35 	.globl _add_owned_mods
                                     36 	.globl _clear_weak_mods
                                     37 	.globl _clear_mods
                                     38 	.globl _send_keyboard_report
                                     39 	.globl _layer_hold_clear
                                     40 	.globl _layer_hold_off
                                     41 	.globl _layer_hold_on
                                     42 	.globl _ak820_resolve_key
                                     43 	.globl _layer_xor
                                     44 	.globl _layer_and
                                     45 	.globl _layer_or
                                     46 	.globl _layer_off
                                     47 	.globl _layer_on
                                     48 	.globl _layer_move
                                     49 	.globl _layer_clear
                                     50 	.globl _layer_state_set
                                     51 	.globl _default_layer_xor
                                     52 	.globl _default_layer_and
                                     53 	.globl _default_layer_or
                                     54 	.globl _default_layer_set
                                     55 	.globl _process_record_quantum
                                     56 	.globl _action_for_keycode
                                     57 	.globl _mDelaymS
                                     58 	.globl _host_consumer_send
                                     59 	.globl _host_system_send
                                     60 	.globl _host_keyboard_leds
                                     61 	.globl _led_set
                                     62 	.globl _clear_keys_from_report
                                     63 	.globl ___memcpy
                                     64 	.globl _ADC_START
                                     65 	.globl _S0_R_FIFO
                                     66 	.globl _S0_T_FIFO
                                     67 	.globl _S0_FREE
                                     68 	.globl _S0_IF_BYTE
                                     69 	.globl _S0_IF_FIRST
                                     70 	.globl _S0_IF_OV
                                     71 	.globl _S0_FST_ACT
                                     72 	.globl _CP_RL2
                                     73 	.globl _C_T2
                                     74 	.globl _TR2
                                     75 	.globl _EXEN2
                                     76 	.globl _TCLK
                                     77 	.globl _RCLK
                                     78 	.globl _EXF2
                                     79 	.globl _CAP1F
                                     80 	.globl _TF2
                                     81 	.globl _RI
                                     82 	.globl _TI
                                     83 	.globl _RB8
                                     84 	.globl _TB8
                                     85 	.globl _REN
                                     86 	.globl _SM2
                                     87 	.globl _SM1
                                     88 	.globl _SM0
                                     89 	.globl _IT0
                                     90 	.globl _IE0
                                     91 	.globl _IT1
                                     92 	.globl _IE1
                                     93 	.globl _TR0
                                     94 	.globl _TF0
                                     95 	.globl _TR1
                                     96 	.globl _TF1
                                     97 	.globl _P4_0
                                     98 	.globl _P4_1
                                     99 	.globl _P4_2
                                    100 	.globl _P4_3
                                    101 	.globl _P4_4
                                    102 	.globl _P4_5
                                    103 	.globl _P4_6
                                    104 	.globl _RXD
                                    105 	.globl _TXD
                                    106 	.globl _INT0
                                    107 	.globl _INT1
                                    108 	.globl _T0
                                    109 	.globl _T1
                                    110 	.globl _MOSI1
                                    111 	.globl _MISO1
                                    112 	.globl _SCK1
                                    113 	.globl _P3_0
                                    114 	.globl _P3_1
                                    115 	.globl _P3_2
                                    116 	.globl _P3_3
                                    117 	.globl _P3_4
                                    118 	.globl _P3_5
                                    119 	.globl _P3_6
                                    120 	.globl _P3_7
                                    121 	.globl _CAP1_
                                    122 	.globl _T2_
                                    123 	.globl _CAP2_
                                    124 	.globl _T2EX_
                                    125 	.globl _RXD1
                                    126 	.globl _TXD1
                                    127 	.globl _P2_0
                                    128 	.globl _P2_1
                                    129 	.globl _P2_2
                                    130 	.globl _P2_3
                                    131 	.globl _P2_4
                                    132 	.globl _P2_5
                                    133 	.globl _P2_6
                                    134 	.globl _P2_7
                                    135 	.globl _AIN0
                                    136 	.globl _AIN1
                                    137 	.globl _AIN2
                                    138 	.globl _AIN3
                                    139 	.globl _AIN4
                                    140 	.globl _AIN5
                                    141 	.globl _AIN6
                                    142 	.globl _AIN7
                                    143 	.globl _CAP1
                                    144 	.globl _T2
                                    145 	.globl _CAP2
                                    146 	.globl _T2EX
                                    147 	.globl _INT0_
                                    148 	.globl _SCS
                                    149 	.globl _MOSI
                                    150 	.globl _MISO
                                    151 	.globl _SCK
                                    152 	.globl _RXD1_
                                    153 	.globl _TXD1_
                                    154 	.globl _P1_0
                                    155 	.globl _P1_1
                                    156 	.globl _P1_2
                                    157 	.globl _P1_3
                                    158 	.globl _P1_4
                                    159 	.globl _P1_5
                                    160 	.globl _P1_6
                                    161 	.globl _P1_7
                                    162 	.globl _AIN8
                                    163 	.globl _AIN9
                                    164 	.globl _AIN10
                                    165 	.globl _AIN11
                                    166 	.globl _AIN12
                                    167 	.globl _AIN13
                                    168 	.globl _RXD_
                                    169 	.globl _TXD_
                                    170 	.globl _SCL0
                                    171 	.globl _SDA0
                                    172 	.globl _P0_0
                                    173 	.globl _P0_1
                                    174 	.globl _P0_2
                                    175 	.globl _P0_3
                                    176 	.globl _P0_4
                                    177 	.globl _P0_5
                                    178 	.globl _P0_6
                                    179 	.globl _P0_7
                                    180 	.globl _IE_SPI0
                                    181 	.globl _IE_USB
                                    182 	.globl _IE_ADC
                                    183 	.globl _IE_UART1
                                    184 	.globl _IE_PWM_I2C
                                    185 	.globl _IE_GPIO
                                    186 	.globl _IE_WDOG
                                    187 	.globl _PX0
                                    188 	.globl _PT0
                                    189 	.globl _PX1
                                    190 	.globl _PT1
                                    191 	.globl _PS
                                    192 	.globl _PT2
                                    193 	.globl _PL_FLAG
                                    194 	.globl _PH_FLAG
                                    195 	.globl _EX0
                                    196 	.globl _ET0
                                    197 	.globl _EX1
                                    198 	.globl _ET1
                                    199 	.globl _ES
                                    200 	.globl _ET2
                                    201 	.globl _E_DIS
                                    202 	.globl _EA
                                    203 	.globl _P
                                    204 	.globl _F1
                                    205 	.globl _OV
                                    206 	.globl _RS0
                                    207 	.globl _RS1
                                    208 	.globl _F0
                                    209 	.globl _AC
                                    210 	.globl _CY
                                    211 	.globl _I2CS_INT_ST
                                    212 	.globl _I2CX_INT
                                    213 	.globl _LED_STATUS
                                    214 	.globl _LED_DMA_H
                                    215 	.globl _LED_DMA_L
                                    216 	.globl _LED_DMA
                                    217 	.globl _LED_PWM_OE
                                    218 	.globl _LED_COMMON
                                    219 	.globl _ADC_CHAN
                                    220 	.globl _ADC_DAT_H
                                    221 	.globl _ADC_DAT_L
                                    222 	.globl _ADC_DAT
                                    223 	.globl _ADC_CTRL
                                    224 	.globl _SPI1_CK_SE
                                    225 	.globl _SPI1_CTRL
                                    226 	.globl _SPI1_DATA
                                    227 	.globl _SPI1_STAT
                                    228 	.globl _SIF1
                                    229 	.globl _SBAUD1
                                    230 	.globl _SBUF1
                                    231 	.globl _SCON1
                                    232 	.globl _SPI0_SETUP
                                    233 	.globl _SPI0_CK_SE
                                    234 	.globl _SPI0_CTRL
                                    235 	.globl _SPI0_DATA
                                    236 	.globl _SPI0_STAT
                                    237 	.globl _T2CAP1H
                                    238 	.globl _T2CAP1L
                                    239 	.globl _T2CAP1
                                    240 	.globl _TH2
                                    241 	.globl _TL2
                                    242 	.globl _T2COUNT
                                    243 	.globl _RCAP2H
                                    244 	.globl _RCAP2L
                                    245 	.globl _RCAP2
                                    246 	.globl _T2MOD
                                    247 	.globl _T2CON
                                    248 	.globl _SBUF
                                    249 	.globl _SCON
                                    250 	.globl _TH1
                                    251 	.globl _TH0
                                    252 	.globl _TL1
                                    253 	.globl _TL0
                                    254 	.globl _TMOD
                                    255 	.globl _TCON
                                    256 	.globl _XBUS_AUX
                                    257 	.globl _P7
                                    258 	.globl _P6_DIR
                                    259 	.globl _P6_OUT_PU
                                    260 	.globl _P6_IN
                                    261 	.globl _P5_DIR
                                    262 	.globl _P5_OUT_PU
                                    263 	.globl _P5_IN
                                    264 	.globl _P4_LED_KEY
                                    265 	.globl _P4_DIR_PU
                                    266 	.globl _P4_MOD_OC
                                    267 	.globl _P4
                                    268 	.globl _P3_DIR_PU
                                    269 	.globl _P3_MOD_OC
                                    270 	.globl _P3
                                    271 	.globl _P2_DIR_PU
                                    272 	.globl _P2_MOD_OC
                                    273 	.globl _P2
                                    274 	.globl _P1_DIR_PU
                                    275 	.globl _P1_MOD_OC
                                    276 	.globl _P1
                                    277 	.globl _P0_DIR_PU
                                    278 	.globl _P0_MOD_OC
                                    279 	.globl _P0
                                    280 	.globl _ROM_CTRL
                                    281 	.globl _ROM_DATA_HH
                                    282 	.globl _ROM_DATA_HL
                                    283 	.globl _ROM_DATA_HI
                                    284 	.globl _ROM_ADDR_H
                                    285 	.globl _ROM_ADDR_L
                                    286 	.globl _ROM_ADDR
                                    287 	.globl _GPIO_IE
                                    288 	.globl _IP_EX
                                    289 	.globl _IE_EX
                                    290 	.globl _IP
                                    291 	.globl _IE
                                    292 	.globl _WDOG_COUNT
                                    293 	.globl _RESET_KEEP
                                    294 	.globl _WAKE_CTRL
                                    295 	.globl _CLOCK_CFG
                                    296 	.globl _POWER_CFG
                                    297 	.globl _PCON
                                    298 	.globl _GLOBAL_CFG
                                    299 	.globl _SAFE_MOD
                                    300 	.globl _DPH
                                    301 	.globl _DPL
                                    302 	.globl _SP
                                    303 	.globl _A_INV
                                    304 	.globl _B
                                    305 	.globl _ACC
                                    306 	.globl _PSW
                                    307 	.globl _disable_action_cache
                                    308 	.globl _tap_code_delay_PARM_2
                                    309 	.globl _process_action_PARM_2
                                    310 	.globl _action_exec_PARM_1
                                    311 	.globl _tp_buttons
                                    312 	.globl _action_exec
                                    313 	.globl _ak820_action_exec
                                    314 	.globl _process_record
                                    315 	.globl _process_record_handler
                                    316 	.globl _process_action
                                    317 	.globl _register_code
                                    318 	.globl _unregister_code
                                    319 	.globl _tap_code_delay
                                    320 	.globl _tap_code
                                    321 	.globl _register_mods
                                    322 	.globl _unregister_mods
                                    323 	.globl _register_weak_mods
                                    324 	.globl _unregister_weak_mods
                                    325 	.globl _clear_keyboard
                                    326 	.globl _clear_keyboard_but_mods
                                    327 	.globl _clear_keyboard_but_mods_and_keys
                                    328 ;--------------------------------------------------------
                                    329 ; special function registers
                                    330 ;--------------------------------------------------------
                                    331 	.area RSEG    (ABS,DATA)
      000000                        332 	.org 0x0000
                           0000D0   333 _PSW	=	0x00d0
                           0000E0   334 _ACC	=	0x00e0
                           0000F0   335 _B	=	0x00f0
                           0000FD   336 _A_INV	=	0x00fd
                           000081   337 _SP	=	0x0081
                           000082   338 _DPL	=	0x0082
                           000083   339 _DPH	=	0x0083
                           0000A1   340 _SAFE_MOD	=	0x00a1
                           0000B1   341 _GLOBAL_CFG	=	0x00b1
                           000087   342 _PCON	=	0x0087
                           0000BA   343 _POWER_CFG	=	0x00ba
                           0000B9   344 _CLOCK_CFG	=	0x00b9
                           0000A9   345 _WAKE_CTRL	=	0x00a9
                           0000FE   346 _RESET_KEEP	=	0x00fe
                           0000FF   347 _WDOG_COUNT	=	0x00ff
                           0000A8   348 _IE	=	0x00a8
                           0000B8   349 _IP	=	0x00b8
                           0000E8   350 _IE_EX	=	0x00e8
                           0000E9   351 _IP_EX	=	0x00e9
                           0000B2   352 _GPIO_IE	=	0x00b2
                           008584   353 _ROM_ADDR	=	0x8584
                           000084   354 _ROM_ADDR_L	=	0x0084
                           000085   355 _ROM_ADDR_H	=	0x0085
                           008F8E   356 _ROM_DATA_HI	=	0x8f8e
                           00008E   357 _ROM_DATA_HL	=	0x008e
                           00008F   358 _ROM_DATA_HH	=	0x008f
                           000086   359 _ROM_CTRL	=	0x0086
                           000080   360 _P0	=	0x0080
                           0000C4   361 _P0_MOD_OC	=	0x00c4
                           0000C5   362 _P0_DIR_PU	=	0x00c5
                           000090   363 _P1	=	0x0090
                           000092   364 _P1_MOD_OC	=	0x0092
                           000093   365 _P1_DIR_PU	=	0x0093
                           0000A0   366 _P2	=	0x00a0
                           000094   367 _P2_MOD_OC	=	0x0094
                           000095   368 _P2_DIR_PU	=	0x0095
                           0000B0   369 _P3	=	0x00b0
                           000096   370 _P3_MOD_OC	=	0x0096
                           000097   371 _P3_DIR_PU	=	0x0097
                           0000C0   372 _P4	=	0x00c0
                           0000C2   373 _P4_MOD_OC	=	0x00c2
                           0000C3   374 _P4_DIR_PU	=	0x00c3
                           0000C1   375 _P4_LED_KEY	=	0x00c1
                           0000AA   376 _P5_IN	=	0x00aa
                           0000AB   377 _P5_OUT_PU	=	0x00ab
                           0000AC   378 _P5_DIR	=	0x00ac
                           0000AD   379 _P6_IN	=	0x00ad
                           0000AE   380 _P6_OUT_PU	=	0x00ae
                           0000AF   381 _P6_DIR	=	0x00af
                           0000F1   382 _P7	=	0x00f1
                           0000A2   383 _XBUS_AUX	=	0x00a2
                           000088   384 _TCON	=	0x0088
                           000089   385 _TMOD	=	0x0089
                           00008A   386 _TL0	=	0x008a
                           00008B   387 _TL1	=	0x008b
                           00008C   388 _TH0	=	0x008c
                           00008D   389 _TH1	=	0x008d
                           000098   390 _SCON	=	0x0098
                           000099   391 _SBUF	=	0x0099
                           0000C8   392 _T2CON	=	0x00c8
                           0000C9   393 _T2MOD	=	0x00c9
                           00CBCA   394 _RCAP2	=	0xcbca
                           0000CA   395 _RCAP2L	=	0x00ca
                           0000CB   396 _RCAP2H	=	0x00cb
                           00CDCC   397 _T2COUNT	=	0xcdcc
                           0000CC   398 _TL2	=	0x00cc
                           0000CD   399 _TH2	=	0x00cd
                           00CFCE   400 _T2CAP1	=	0xcfce
                           0000CE   401 _T2CAP1L	=	0x00ce
                           0000CF   402 _T2CAP1H	=	0x00cf
                           0000F8   403 _SPI0_STAT	=	0x00f8
                           0000F9   404 _SPI0_DATA	=	0x00f9
                           0000FA   405 _SPI0_CTRL	=	0x00fa
                           0000FB   406 _SPI0_CK_SE	=	0x00fb
                           0000FC   407 _SPI0_SETUP	=	0x00fc
                           0000BC   408 _SCON1	=	0x00bc
                           0000BD   409 _SBUF1	=	0x00bd
                           0000BE   410 _SBAUD1	=	0x00be
                           0000BF   411 _SIF1	=	0x00bf
                           0000B4   412 _SPI1_STAT	=	0x00b4
                           0000B5   413 _SPI1_DATA	=	0x00b5
                           0000B6   414 _SPI1_CTRL	=	0x00b6
                           0000B7   415 _SPI1_CK_SE	=	0x00b7
                           0000F3   416 _ADC_CTRL	=	0x00f3
                           00F5F4   417 _ADC_DAT	=	0xf5f4
                           0000F4   418 _ADC_DAT_L	=	0x00f4
                           0000F5   419 _ADC_DAT_H	=	0x00f5
                           0000F6   420 _ADC_CHAN	=	0x00f6
                           0000A6   421 _LED_COMMON	=	0x00a6
                           0000A7   422 _LED_PWM_OE	=	0x00a7
                           00C7C6   423 _LED_DMA	=	0xc7c6
                           0000C6   424 _LED_DMA_L	=	0x00c6
                           0000C7   425 _LED_DMA_H	=	0x00c7
                           0000F7   426 _LED_STATUS	=	0x00f7
                           0000B3   427 _I2CX_INT	=	0x00b3
                           0000BB   428 _I2CS_INT_ST	=	0x00bb
                                    429 ;--------------------------------------------------------
                                    430 ; special function bits
                                    431 ;--------------------------------------------------------
                                    432 	.area RSEG    (ABS,DATA)
      000000                        433 	.org 0x0000
                           0000D7   434 _CY	=	0x00d7
                           0000D6   435 _AC	=	0x00d6
                           0000D5   436 _F0	=	0x00d5
                           0000D4   437 _RS1	=	0x00d4
                           0000D3   438 _RS0	=	0x00d3
                           0000D2   439 _OV	=	0x00d2
                           0000D1   440 _F1	=	0x00d1
                           0000D0   441 _P	=	0x00d0
                           0000AF   442 _EA	=	0x00af
                           0000AE   443 _E_DIS	=	0x00ae
                           0000AD   444 _ET2	=	0x00ad
                           0000AC   445 _ES	=	0x00ac
                           0000AB   446 _ET1	=	0x00ab
                           0000AA   447 _EX1	=	0x00aa
                           0000A9   448 _ET0	=	0x00a9
                           0000A8   449 _EX0	=	0x00a8
                           0000BF   450 _PH_FLAG	=	0x00bf
                           0000BE   451 _PL_FLAG	=	0x00be
                           0000BD   452 _PT2	=	0x00bd
                           0000BC   453 _PS	=	0x00bc
                           0000BB   454 _PT1	=	0x00bb
                           0000BA   455 _PX1	=	0x00ba
                           0000B9   456 _PT0	=	0x00b9
                           0000B8   457 _PX0	=	0x00b8
                           0000EF   458 _IE_WDOG	=	0x00ef
                           0000EE   459 _IE_GPIO	=	0x00ee
                           0000ED   460 _IE_PWM_I2C	=	0x00ed
                           0000EC   461 _IE_UART1	=	0x00ec
                           0000EB   462 _IE_ADC	=	0x00eb
                           0000E9   463 _IE_USB	=	0x00e9
                           0000E8   464 _IE_SPI0	=	0x00e8
                           000087   465 _P0_7	=	0x0087
                           000086   466 _P0_6	=	0x0086
                           000085   467 _P0_5	=	0x0085
                           000084   468 _P0_4	=	0x0084
                           000083   469 _P0_3	=	0x0083
                           000082   470 _P0_2	=	0x0082
                           000081   471 _P0_1	=	0x0081
                           000080   472 _P0_0	=	0x0080
                           000081   473 _SDA0	=	0x0081
                           000080   474 _SCL0	=	0x0080
                           000083   475 _TXD_	=	0x0083
                           000082   476 _RXD_	=	0x0082
                           000085   477 _AIN13	=	0x0085
                           000084   478 _AIN12	=	0x0084
                           000083   479 _AIN11	=	0x0083
                           000082   480 _AIN10	=	0x0082
                           000081   481 _AIN9	=	0x0081
                           000080   482 _AIN8	=	0x0080
                           000097   483 _P1_7	=	0x0097
                           000096   484 _P1_6	=	0x0096
                           000095   485 _P1_5	=	0x0095
                           000094   486 _P1_4	=	0x0094
                           000093   487 _P1_3	=	0x0093
                           000092   488 _P1_2	=	0x0092
                           000091   489 _P1_1	=	0x0091
                           000090   490 _P1_0	=	0x0090
                           000097   491 _TXD1_	=	0x0097
                           000096   492 _RXD1_	=	0x0096
                           000097   493 _SCK	=	0x0097
                           000096   494 _MISO	=	0x0096
                           000095   495 _MOSI	=	0x0095
                           000094   496 _SCS	=	0x0094
                           000092   497 _INT0_	=	0x0092
                           000091   498 _T2EX	=	0x0091
                           000091   499 _CAP2	=	0x0091
                           000090   500 _T2	=	0x0090
                           000090   501 _CAP1	=	0x0090
                           000097   502 _AIN7	=	0x0097
                           000096   503 _AIN6	=	0x0096
                           000095   504 _AIN5	=	0x0095
                           000094   505 _AIN4	=	0x0094
                           000093   506 _AIN3	=	0x0093
                           000092   507 _AIN2	=	0x0092
                           000091   508 _AIN1	=	0x0091
                           000090   509 _AIN0	=	0x0090
                           0000A7   510 _P2_7	=	0x00a7
                           0000A6   511 _P2_6	=	0x00a6
                           0000A5   512 _P2_5	=	0x00a5
                           0000A4   513 _P2_4	=	0x00a4
                           0000A3   514 _P2_3	=	0x00a3
                           0000A2   515 _P2_2	=	0x00a2
                           0000A1   516 _P2_1	=	0x00a1
                           0000A0   517 _P2_0	=	0x00a0
                           0000A7   518 _TXD1	=	0x00a7
                           0000A6   519 _RXD1	=	0x00a6
                           0000A5   520 _T2EX_	=	0x00a5
                           0000A5   521 _CAP2_	=	0x00a5
                           0000A4   522 _T2_	=	0x00a4
                           0000A4   523 _CAP1_	=	0x00a4
                           0000B7   524 _P3_7	=	0x00b7
                           0000B6   525 _P3_6	=	0x00b6
                           0000B5   526 _P3_5	=	0x00b5
                           0000B4   527 _P3_4	=	0x00b4
                           0000B3   528 _P3_3	=	0x00b3
                           0000B2   529 _P3_2	=	0x00b2
                           0000B1   530 _P3_1	=	0x00b1
                           0000B0   531 _P3_0	=	0x00b0
                           0000B7   532 _SCK1	=	0x00b7
                           0000B6   533 _MISO1	=	0x00b6
                           0000B5   534 _MOSI1	=	0x00b5
                           0000B5   535 _T1	=	0x00b5
                           0000B4   536 _T0	=	0x00b4
                           0000B3   537 _INT1	=	0x00b3
                           0000B2   538 _INT0	=	0x00b2
                           0000B1   539 _TXD	=	0x00b1
                           0000B0   540 _RXD	=	0x00b0
                           0000C6   541 _P4_6	=	0x00c6
                           0000C5   542 _P4_5	=	0x00c5
                           0000C4   543 _P4_4	=	0x00c4
                           0000C3   544 _P4_3	=	0x00c3
                           0000C2   545 _P4_2	=	0x00c2
                           0000C1   546 _P4_1	=	0x00c1
                           0000C0   547 _P4_0	=	0x00c0
                           00008F   548 _TF1	=	0x008f
                           00008E   549 _TR1	=	0x008e
                           00008D   550 _TF0	=	0x008d
                           00008C   551 _TR0	=	0x008c
                           00008B   552 _IE1	=	0x008b
                           00008A   553 _IT1	=	0x008a
                           000089   554 _IE0	=	0x0089
                           000088   555 _IT0	=	0x0088
                           00009F   556 _SM0	=	0x009f
                           00009E   557 _SM1	=	0x009e
                           00009D   558 _SM2	=	0x009d
                           00009C   559 _REN	=	0x009c
                           00009B   560 _TB8	=	0x009b
                           00009A   561 _RB8	=	0x009a
                           000099   562 _TI	=	0x0099
                           000098   563 _RI	=	0x0098
                           0000CF   564 _TF2	=	0x00cf
                           0000CF   565 _CAP1F	=	0x00cf
                           0000CE   566 _EXF2	=	0x00ce
                           0000CD   567 _RCLK	=	0x00cd
                           0000CC   568 _TCLK	=	0x00cc
                           0000CB   569 _EXEN2	=	0x00cb
                           0000CA   570 _TR2	=	0x00ca
                           0000C9   571 _C_T2	=	0x00c9
                           0000C8   572 _CP_RL2	=	0x00c8
                           0000FF   573 _S0_FST_ACT	=	0x00ff
                           0000FE   574 _S0_IF_OV	=	0x00fe
                           0000FD   575 _S0_IF_FIRST	=	0x00fd
                           0000FC   576 _S0_IF_BYTE	=	0x00fc
                           0000FB   577 _S0_FREE	=	0x00fb
                           0000FA   578 _S0_T_FIFO	=	0x00fa
                           0000F8   579 _S0_R_FIFO	=	0x00f8
                           0000F7   580 _ADC_START	=	0x00f7
                                    581 ;--------------------------------------------------------
                                    582 ; overlayable register banks
                                    583 ;--------------------------------------------------------
                                    584 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        585 	.ds 8
                                    586 ;--------------------------------------------------------
                                    587 ; internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area DSEG    (DATA)
      000027                        590 _process_action_sloc0_1_0:
      000027                        591 	.ds 1
                                    592 ;--------------------------------------------------------
                                    593 ; overlayable items in internal ram
                                    594 ;--------------------------------------------------------
                                    595 ;--------------------------------------------------------
                                    596 ; indirectly addressable internal ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area ISEG    (DATA)
                                    599 ;--------------------------------------------------------
                                    600 ; absolute internal ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area IABS    (ABS,DATA)
                                    603 	.area IABS    (ABS,DATA)
                                    604 ;--------------------------------------------------------
                                    605 ; bit data
                                    606 ;--------------------------------------------------------
                                    607 	.area BSEG    (BIT)
      00001E                        608 _process_action_sloc1_1_0:
      00001E                        609 	.ds 1
                                    610 ;--------------------------------------------------------
                                    611 ; paged external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area PSEG    (PAG,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; uninitialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XSEG    (XDATA)
      00081A                        618 _tp_buttons::
      00081A                        619 	.ds 2
      00081C                        620 _action_exec_PARM_1:
      00081C                        621 	.ds 6
      000822                        622 _action_exec_record_10001_628:
      000822                        623 	.ds 9
      00082B                        624 _ak820_action_exec_event_10000_633:
      00082B                        625 	.ds 2
      00082D                        626 _ak820_action_exec_snapshot_10000_634:
      00082D                        627 	.ds 6
      000833                        628 _process_record_record_argument_10000_637:
      000833                        629 	.ds 2
      000835                        630 _process_record_handler_record_argument_10000_645:
      000835                        631 	.ds 2
      000837                        632 _process_record_handler_action_10000_646:
      000837                        633 	.ds 2
      000839                        634 _process_action_PARM_2:
      000839                        635 	.ds 2
      00083B                        636 _process_action_record_argument_10000_657:
      00083B                        637 	.ds 2
      00083D                        638 _process_action_on_40000_680:
      00083D                        639 	.ds 1
      00083E                        640 _register_code_code_10000_714:
      00083E                        641 	.ds 1
      00083F                        642 _unregister_code_code_10000_728:
      00083F                        643 	.ds 1
      000840                        644 _tap_code_delay_PARM_2:
      000840                        645 	.ds 2
      000842                        646 _tap_code_delay_code_10000_741:
      000842                        647 	.ds 1
      000843                        648 _tap_code_code_10000_748:
      000843                        649 	.ds 1
      000844                        650 _register_mods_mods_10000_750:
      000844                        651 	.ds 1
      000845                        652 _unregister_mods_mods_10000_754:
      000845                        653 	.ds 1
      000846                        654 _register_weak_mods_mods_10000_758:
      000846                        655 	.ds 1
      000847                        656 _unregister_weak_mods_mods_10000_762:
      000847                        657 	.ds 1
                                    658 ;--------------------------------------------------------
                                    659 ; absolute external ram data
                                    660 ;--------------------------------------------------------
                                    661 	.area XABS    (ABS,XDATA)
                                    662 ;--------------------------------------------------------
                                    663 ; initialized external ram data
                                    664 ;--------------------------------------------------------
                                    665 	.area XISEG   (XDATA)
      000DA1                        666 _disable_action_cache::
      000DA1                        667 	.ds 1
                                    668 	.area HOME    (CODE)
                                    669 	.area GSINIT0 (CODE)
                                    670 	.area GSINIT1 (CODE)
                                    671 	.area GSINIT2 (CODE)
                                    672 	.area GSINIT3 (CODE)
                                    673 	.area GSINIT4 (CODE)
                                    674 	.area GSINIT5 (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area CSEG    (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; global & static initialisations
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 	.area GSFINAL (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; Home
                                    687 ;--------------------------------------------------------
                                    688 	.area HOME    (CODE)
                                    689 	.area HOME    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; code
                                    692 ;--------------------------------------------------------
                                    693 	.area CSEG    (CODE)
                                    694 ;------------------------------------------------------------
                                    695 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    696 ;------------------------------------------------------------
                                    697 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    698 ;------------------------------------------------------------
                                    699 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    700 ;	-----------------------------------------
                           000007   701 	ar7 = 0x07
                           000006   702 	ar6 = 0x06
                           000005   703 	ar5 = 0x05
                           000004   704 	ar4 = 0x04
                           000003   705 	ar3 = 0x03
                           000002   706 	ar2 = 0x02
                           000001   707 	ar1 = 0x01
                           000000   708 	ar0 = 0x00
                                    709 ;	 function action_exec
                                    710 ;	-----------------------------------------
      0071D5                        711 _action_exec:
                                    712 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      0071D5 90 08 1E         [24]  713 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0071D8 12 39 E7         [24]  714 	lcall	_ak820_outline_0004
      0071DB 12 37 FE         [24]  715 	lcall	_ak820_combo_tick
                                    716 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      0071DE 90 08 1C         [24]  717 	mov	dptr,#_action_exec_PARM_1
      0071E1 12 46 6B         [24]  718 	lcall	_ak820_tapping_before
      0071E4 E5 82            [12]  719 	mov	a, dpl
      0071E6 70 01            [24]  720 	jnz	00102$
      0071E8 22               [24]  721 	ret
      0071E9                        722 00102$:
                                    723 ;	quantum/action.c:110: if (!ak820_autoshift_before(&event)) return;
      0071E9 90 08 1C         [24]  724 	mov	dptr,#_action_exec_PARM_1
      0071EC 12 31 2A         [24]  725 	lcall	_ak820_autoshift_before
      0071EF E5 82            [12]  726 	mov	a, dpl
      0071F1 70 01            [24]  727 	jnz	00104$
      0071F3 22               [24]  728 	ret
      0071F4                        729 00104$:
                                    730 ;	quantum/action.c:126: if (event.pressed) {
      0071F4 90 08 21         [24]  731 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0071F7 E0               [24]  732 	movx	a,@dptr
      0071F8 60 03            [24]  733 	jz	00106$
                                    734 ;	quantum/action.c:128: clear_weak_mods();
      0071FA 12 81 F4         [24]  735 	lcall	_clear_weak_mods
      0071FD                        736 00106$:
                                    737 ;	quantum/action.c:140: record.event = event;
      0071FD 90 0D 80         [24]  738 	mov	dptr,#___memcpy_PARM_2
      007200 74 1C            [12]  739 	mov	a,#_action_exec_PARM_1
      007202 F0               [24]  740 	movx	@dptr,a
      007203 74 08            [12]  741 	mov	a,#(_action_exec_PARM_1 >> 8)
      007205 12 78 6B         [24]  742 	lcall	_ak820_outline_0049
      007208 12 78 8B         [24]  743 	lcall	_ak820_outline_0107
      00720B 90 08 22         [24]  744 	mov	dptr,#_action_exec_record_10001_628
      00720E F5 F0            [12]  745 	mov	b,a
      007210 12 B8 2F         [24]  746 	lcall	___memcpy
                                    747 ;	quantum/action.c:142: record.tap.count = 0;
      007213 90 08 28         [24]  748 	mov	dptr,#(_action_exec_record_10001_628 + 0x0006)
      007216 E0               [24]  749 	movx	a,@dptr
      007217 54 0F            [12]  750 	anl	a,#0x0f
      007219 F0               [24]  751 	movx	@dptr,a
                                    752 ;	quantum/action.c:147: record.keycode = 0;
      00721A 90 08 29         [24]  753 	mov	dptr,#(_action_exec_record_10001_628 + 0x0007)
      00721D 12 51 26         [24]  754 	lcall	_ak820_outline_0165
                                    755 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007220 90 08 26         [24]  756 	mov	dptr,#(_action_exec_record_10001_628 + 0x0004)
      007223 E0               [24]  757 	movx	a,@dptr
      007224 60 0A            [24]  758 	jz	00111$
      007226 90 08 22         [24]  759 	mov	dptr,#_action_exec_record_10001_628
      007229 12 9F 58         [24]  760 	lcall	_pre_process_record_quantum
      00722C E5 82            [12]  761 	mov	a, dpl
      00722E 60 1C            [24]  762 	jz	00114$
      007230                        763 00111$:
                                    764 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      007230 90 08 22         [24]  765 	mov	dptr,#_action_exec_record_10001_628
      007233 12 47 57         [24]  766 	lcall	_ak820_tapping_process
      007236 E5 82            [12]  767 	mov	a, dpl
      007238 70 01            [24]  768 	jnz	00108$
      00723A 22               [24]  769 	ret
      00723B                        770 00108$:
                                    771 ;	quantum/action.c:182: if (!ak820_autoshift_process(&record)) return;
      00723B 90 08 22         [24]  772 	mov	dptr,#_action_exec_record_10001_628
      00723E 12 32 30         [24]  773 	lcall	_ak820_autoshift_process
      007241 E5 82            [12]  774 	mov	a, dpl
      007243 70 01            [24]  775 	jnz	00110$
      007245 22               [24]  776 	ret
      007246                        777 00110$:
                                    778 ;	quantum/action.c:185: process_record(&record);
      007246 90 08 22         [24]  779 	mov	dptr,#_action_exec_record_10001_628
                                    780 ;	quantum/action.c:200: }
      007249 02 72 8A         [24]  781 	ljmp	_process_record
      00724C                        782 00114$:
      00724C 22               [24]  783 	ret
                                    784 ;------------------------------------------------------------
                                    785 ;Allocation info for local variables in function 'ak820_action_exec'
                                    786 ;------------------------------------------------------------
                                    787 ;event         Allocated with name '_ak820_action_exec_event_10000_633'
                                    788 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_634'
                                    789 ;------------------------------------------------------------
                                    790 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    791 ;	-----------------------------------------
                                    792 ;	 function ak820_action_exec
                                    793 ;	-----------------------------------------
      00724D                        794 _ak820_action_exec:
      00724D 12 3A 8A         [24]  795 	lcall	_ak820_outline_0103
      007250 90 08 2B         [24]  796 	mov	dptr,#_ak820_action_exec_event_10000_633
      007253 12 3A 8F         [24]  797 	lcall	_ak820_outline_0104
                                    798 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007256 90 08 2B         [24]  799 	mov	dptr,#_ak820_action_exec_event_10000_633
      007259 12 3A 5E         [24]  800 	lcall	_ak820_outline_0057
      00725C 90 0D 80         [24]  801 	mov	dptr,#___memcpy_PARM_2
      00725F ED               [12]  802 	mov	a,r5
      007260 12 3A 26         [24]  803 	lcall	_ak820_outline_0015
      007263 90 0D 83         [24]  804 	mov	dptr,#___memcpy_PARM_3
      007266 12 78 8B         [24]  805 	lcall	_ak820_outline_0107
      007269 90 08 2D         [24]  806 	mov	dptr,#_ak820_action_exec_snapshot_10000_634
      00726C F5 F0            [12]  807 	mov	b,a
      00726E 12 B8 2F         [24]  808 	lcall	___memcpy
                                    809 ;	quantum/action.c:207: action_exec(snapshot);
      007271 90 0D 80         [24]  810 	mov	dptr,#___memcpy_PARM_2
      007274 74 2D            [12]  811 	mov	a,#_ak820_action_exec_snapshot_10000_634
      007276 F0               [24]  812 	movx	@dptr,a
      007277 74 08            [12]  813 	mov	a,#(_ak820_action_exec_snapshot_10000_634 >> 8)
      007279 12 78 6B         [24]  814 	lcall	_ak820_outline_0049
      00727C 12 78 8B         [24]  815 	lcall	_ak820_outline_0107
      00727F 90 08 1C         [24]  816 	mov	dptr,#_action_exec_PARM_1
      007282 F5 F0            [12]  817 	mov	b,a
      007284 12 B8 2F         [24]  818 	lcall	___memcpy
                                    819 ;	quantum/action.c:208: }
      007287 02 71 D5         [24]  820 	ljmp	_action_exec
                                    821 ;------------------------------------------------------------
                                    822 ;Allocation info for local variables in function 'process_record_nocache'
                                    823 ;------------------------------------------------------------
                                    824 ;record        Allocated with name '_process_record_nocache_record_10000_635'
                                    825 ;------------------------------------------------------------
                                    826 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    827 ;	-----------------------------------------
                                    828 ;	 function process_record
                                    829 ;	-----------------------------------------
      00728A                        830 _process_record:
      00728A 12 3A 8A         [24]  831 	lcall	_ak820_outline_0103
      00728D 90 08 33         [24]  832 	mov	dptr,#_process_record_record_argument_10000_637
      007290 12 3A 8F         [24]  833 	lcall	_ak820_outline_0104
                                    834 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007293 90 08 33         [24]  835 	mov	dptr,#_process_record_record_argument_10000_637
      007296 12 3A 47         [24]  836 	lcall	_ak820_outline_0050
                                    837 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      007299 74 04            [12]  838 	mov	a,#0x04
      00729B 12 4A 2D         [24]  839 	lcall	_ak820_outline_0011
      00729E 70 01            [24]  840 	jnz	00102$
                                    841 ;	quantum/action.c:354: return;
      0072A0 22               [24]  842 	ret
      0072A1                        843 00102$:
                                    844 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0072A1 8E 04            [24]  845 	mov	ar4,r6
      0072A3 8F 05            [24]  846 	mov	ar5,r7
      0072A5 90 0D 80         [24]  847 	mov	dptr,#___memcpy_PARM_2
      0072A8 EC               [12]  848 	mov	a,r4
      0072A9 F0               [24]  849 	movx	@dptr,a
      0072AA ED               [12]  850 	mov	a,r5
      0072AB 12 78 6B         [24]  851 	lcall	_ak820_outline_0049
      0072AE 12 51 18         [24]  852 	lcall	_ak820_outline_0106
      0072B1 90 06 30         [24]  853 	mov	dptr,#_ak820_tapping_source_PARM_1
      0072B4 F5 F0            [12]  854 	mov	b,a
      0072B6 C0 07            [24]  855 	push	ar7
      0072B8 C0 06            [24]  856 	push	ar6
      0072BA 12 B8 2F         [24]  857 	lcall	___memcpy
      0072BD 12 45 A7         [24]  858 	lcall	_ak820_tapping_source
      0072C0 AD 82            [24]  859 	mov	r5, dpl
      0072C2 D0 06            [24]  860 	pop	ar6
      0072C4 D0 07            [24]  861 	pop	ar7
                                    862 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      0072C6 12 45 0B         [24]  863 	lcall	_ak820_outline_0010
      0072C9 E0               [24]  864 	movx	a,@dptr
      0072CA FC               [12]  865 	mov	r4,a
                                    866 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      0072CB 74 07            [12]  867 	mov	a,#0x07
      0072CD 2E               [12]  868 	add	a, r6
      0072CE FA               [12]  869 	mov	r2,a
      0072CF E4               [12]  870 	clr	a
      0072D0 3F               [12]  871 	addc	a, r7
      0072D1 FB               [12]  872 	mov	r3,a
      0072D2 90 0B E2         [24]  873 	mov	dptr,#_get_record_keycode_PARM_2
      0072D5 12 4A 77         [24]  874 	lcall	_ak820_outline_0054
      0072D8 C0 07            [24]  875 	push	ar7
      0072DA C0 06            [24]  876 	push	ar6
      0072DC C0 05            [24]  877 	push	ar5
      0072DE C0 04            [24]  878 	push	ar4
      0072E0 C0 03            [24]  879 	push	ar3
      0072E2 C0 02            [24]  880 	push	ar2
      0072E4 12 9F 1A         [24]  881 	lcall	_get_record_keycode
      0072E7 A8 82            [24]  882 	mov	r0, dpl
      0072E9 A9 83            [24]  883 	mov	r1, dph
      0072EB D0 02            [24]  884 	pop	ar2
      0072ED D0 03            [24]  885 	pop	ar3
      0072EF D0 04            [24]  886 	pop	ar4
      0072F1 D0 05            [24]  887 	pop	ar5
      0072F3 D0 06            [24]  888 	pop	ar6
      0072F5 D0 07            [24]  889 	pop	ar7
      0072F7 12 45 82         [24]  890 	lcall	_ak820_outline_0139
      0072FA E8               [12]  891 	mov	a,r0
      0072FB F0               [24]  892 	movx	@dptr,a
      0072FC E9               [12]  893 	mov	a,r1
      0072FD A3               [24]  894 	inc	dptr
      0072FE F0               [24]  895 	movx	@dptr,a
                                    896 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0072FF 74 07            [12]  897 	mov	a,#0x07
      007301 12 3A 2E         [24]  898 	lcall	_ak820_outline_0016
      007304 FA               [12]  899 	mov	r2,a
      007305 A3               [24]  900 	inc	dptr
      007306 E0               [24]  901 	movx	a,@dptr
      007307 FB               [12]  902 	mov	r3,a
      007308 90 06 40         [24]  903 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00730B ED               [12]  904 	mov	a,r5
      00730C F0               [24]  905 	movx	@dptr,a
      00730D 90 06 41         [24]  906 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007310 EC               [12]  907 	mov	a,r4
      007311 F0               [24]  908 	movx	@dptr,a
      007312 12 45 82         [24]  909 	lcall	_ak820_outline_0139
      007315 C0 07            [24]  910 	push	ar7
      007317 C0 06            [24]  911 	push	ar6
      007319 C0 05            [24]  912 	push	ar5
      00731B C0 04            [24]  913 	push	ar4
      00731D 12 48 F7         [24]  914 	lcall	_ak820_oneshot_process
      007320 E5 82            [12]  915 	mov	a, dpl
      007322 D0 04            [24]  916 	pop	ar4
      007324 D0 05            [24]  917 	pop	ar5
      007326 D0 06            [24]  918 	pop	ar6
      007328 D0 07            [24]  919 	pop	ar7
      00732A 70 01            [24]  920 	jnz	00104$
      00732C 22               [24]  921 	ret
      00732D                        922 00104$:
                                    923 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      00732D 12 45 66         [24]  924 	lcall	_ak820_outline_0116
      007330 C0 07            [24]  925 	push	ar7
      007332 C0 06            [24]  926 	push	ar6
      007334 C0 05            [24]  927 	push	ar5
      007336 C0 04            [24]  928 	push	ar4
      007338 12 9F 9A         [24]  929 	lcall	_process_record_quantum
      00733B E5 82            [12]  930 	mov	a, dpl
      00733D D0 04            [24]  931 	pop	ar4
      00733F D0 05            [24]  932 	pop	ar5
      007341 D0 06            [24]  933 	pop	ar6
      007343 D0 07            [24]  934 	pop	ar7
      007345 70 0A            [24]  935 	jnz	00106$
                                    936 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007347 90 05 A8         [24]  937 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00734A EC               [12]  938 	mov	a,r4
      00734B F0               [24]  939 	movx	@dptr,a
      00734C 8D 82            [24]  940 	mov	dpl, r5
                                    941 ;	quantum/action.c:376: return;
      00734E 02 2E BB         [24]  942 	ljmp	_ak820_oneshot_post
      007351                        943 00106$:
                                    944 ;	quantum/action.c:382: process_record_handler(record);
      007351 12 45 66         [24]  945 	lcall	_ak820_outline_0116
      007354 C0 05            [24]  946 	push	ar5
      007356 C0 04            [24]  947 	push	ar4
      007358 12 73 69         [24]  948 	lcall	_process_record_handler
      00735B D0 04            [24]  949 	pop	ar4
      00735D D0 05            [24]  950 	pop	ar5
                                    951 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00735F 90 05 A8         [24]  952 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007362 EC               [12]  953 	mov	a,r4
      007363 F0               [24]  954 	movx	@dptr,a
      007364 8D 82            [24]  955 	mov	dpl, r5
                                    956 ;	quantum/action.c:392: }
      007366 02 2E BB         [24]  957 	ljmp	_ak820_oneshot_post
                                    958 ;------------------------------------------------------------
                                    959 ;Allocation info for local variables in function 'process_record_handler'
                                    960 ;------------------------------------------------------------
                                    961 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_645'
                                    962 ;record        Allocated with name '_process_record_handler_record_10000_646'
                                    963 ;action        Allocated with name '_process_record_handler_action_10000_646'
                                    964 ;------------------------------------------------------------
                                    965 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    966 ;	-----------------------------------------
                                    967 ;	 function process_record_handler
                                    968 ;	-----------------------------------------
      007369                        969 _process_record_handler:
      007369 12 3A 8A         [24]  970 	lcall	_ak820_outline_0103
      00736C 90 08 35         [24]  971 	mov	dptr,#_process_record_handler_record_argument_10000_645
      00736F 12 3A 8F         [24]  972 	lcall	_ak820_outline_0104
                                    973 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007372 90 08 35         [24]  974 	mov	dptr,#_process_record_handler_record_argument_10000_645
      007375 12 39 FE         [24]  975 	lcall	_ak820_outline_0008
                                    976 ;	quantum/action.c:405: if (record->keycode) {
      007378 4C               [12]  977 	orl	a,r4
      007379 60 19            [24]  978 	jz	00102$
                                    979 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      00737B 12 3A 9B         [24]  980 	lcall	_ak820_outline_0117
      00737E C0 07            [24]  981 	push	ar7
      007380 C0 06            [24]  982 	push	ar6
      007382 12 95 EB         [24]  983 	lcall	_action_for_keycode
      007385 12 45 87         [24]  984 	lcall	_ak820_outline_0144
      007388 D0 06            [24]  985 	pop	ar6
      00738A D0 07            [24]  986 	pop	ar7
      00738C 90 08 37         [24]  987 	mov	dptr,#_process_record_handler_action_10000_646
      00738F 12 3A 6C         [24]  988 	lcall	_ak820_outline_0070
      007392 80 2B            [24]  989 	sjmp	00104$
      007394                        990 00102$:
                                    991 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007394 12 78 53         [24]  992 	lcall	_ak820_outline_0019
      007397 7A 00            [12]  993 	mov	r2,#0x00
      007399 12 45 7C         [24]  994 	lcall	_ak820_outline_0138
      00739C 12 45 0B         [24]  995 	lcall	_ak820_outline_0010
      00739F E0               [24]  996 	movx	a,@dptr
      0073A0 90 09 72         [24]  997 	mov	dptr,#_ak820_resolve_key_PARM_2
      0073A3 F0               [24]  998 	movx	@dptr,a
      0073A4 8D 82            [24]  999 	mov	dpl, r5
      0073A6 8C 83            [24] 1000 	mov	dph, r4
      0073A8 C0 07            [24] 1001 	push	ar7
      0073AA C0 06            [24] 1002 	push	ar6
      0073AC 12 7B F0         [24] 1003 	lcall	_ak820_resolve_key
      0073AF 12 95 EB         [24] 1004 	lcall	_action_for_keycode
      0073B2 12 45 87         [24] 1005 	lcall	_ak820_outline_0144
      0073B5 D0 06            [24] 1006 	pop	ar6
      0073B7 D0 07            [24] 1007 	pop	ar7
      0073B9 90 08 37         [24] 1008 	mov	dptr,#_process_record_handler_action_10000_646
      0073BC 12 3A 6C         [24] 1009 	lcall	_ak820_outline_0070
                                   1010 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      0073BF                       1011 00104$:
                                   1012 ;	quantum/action.c:429: process_action(record, action);
      0073BF 90 0D 80         [24] 1013 	mov	dptr,#___memcpy_PARM_2
      0073C2 74 37            [12] 1014 	mov	a,#_process_record_handler_action_10000_646
      0073C4 F0               [24] 1015 	movx	@dptr,a
      0073C5 74 08            [12] 1016 	mov	a,#(_process_record_handler_action_10000_646 >> 8)
      0073C7 12 78 6B         [24] 1017 	lcall	_ak820_outline_0049
      0073CA 12 51 18         [24] 1018 	lcall	_ak820_outline_0106
      0073CD 90 08 39         [24] 1019 	mov	dptr,#_process_action_PARM_2
      0073D0 F5 F0            [12] 1020 	mov	b,a
      0073D2 C0 07            [24] 1021 	push	ar7
      0073D4 C0 06            [24] 1022 	push	ar6
      0073D6 12 B8 2F         [24] 1023 	lcall	___memcpy
      0073D9 D0 06            [24] 1024 	pop	ar6
      0073DB D0 07            [24] 1025 	pop	ar7
      0073DD 12 45 66         [24] 1026 	lcall	_ak820_outline_0116
                                   1027 ;	quantum/action.c:430: }
      0073E0 02 73 E3         [24] 1028 	ljmp	_process_action
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'register_mouse'
                                   1031 ;------------------------------------------------------------
                                   1032 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1033 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_654'
                                   1034 ;------------------------------------------------------------
                                   1035 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1036 ;	-----------------------------------------
                                   1037 ;	 function process_action
                                   1038 ;	-----------------------------------------
      0073E3                       1039 _process_action:
      0073E3 12 3A 8A         [24] 1040 	lcall	_ak820_outline_0103
      0073E6 90 08 3B         [24] 1041 	mov	dptr,#_process_action_record_argument_10000_657
      0073E9 12 3A 8F         [24] 1042 	lcall	_ak820_outline_0104
                                   1043 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0073EC 90 08 3B         [24] 1044 	mov	dptr,#_process_action_record_argument_10000_657
      0073EF 12 39 E7         [24] 1045 	lcall	_ak820_outline_0004
                                   1046 ;	quantum/action.c:501: pressed = record->event.pressed;
      0073F2 A3               [24] 1047 	inc	dptr
      0073F3 A3               [24] 1048 	inc	dptr
      0073F4 A3               [24] 1049 	inc	dptr
      0073F5 A3               [24] 1050 	inc	dptr
      0073F6 A3               [24] 1051 	inc	dptr
      0073F7 E0               [24] 1052 	movx	a,@dptr
      0073F8 F5 27            [12] 1053 	mov	_process_action_sloc0_1_0,a
                                   1054 ;	quantum/action.c:525: switch (action.kind.id) {
      0073FA 90 08 3A         [24] 1055 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0073FD E0               [24] 1056 	movx	a,@dptr
      0073FE C4               [12] 1057 	swap	a
      0073FF 54 0F            [12] 1058 	anl	a,#0x0f
      007401 FD               [12] 1059 	mov  r5,a
      007402 24 F4            [12] 1060 	add	a,#0xff - 0x0b
      007404 50 03            [24] 1061 	jnc	00434$
      007406 02 76 84         [24] 1062 	ljmp	00181$
      007409                       1063 00434$:
                                   1064 ;	free result
      007409 ED               [12] 1065 	mov	a,r5
      00740A 24 0A            [12] 1066 	add	a,#(00435$-3-.)
      00740C 83               [24] 1067 	movc	a,@a+pc
      00740D F5 82            [12] 1068 	mov	dpl,a
      00740F ED               [12] 1069 	mov	a,r5
      007410 24 10            [12] 1070 	add	a,#(00436$-3-.)
      007412 83               [24] 1071 	movc	a,@a+pc
      007413 F5 83            [12] 1072 	mov	dph,a
      007415 E4               [12] 1073 	clr	a
      007416 73               [24] 1074 	jmp	@a+dptr
      007417                       1075 00435$:
      007417 2F                    1076 	.db	00102$
      007418 2F                    1077 	.db	00102$
      007419 84                    1078 	.db	00181$
      00741A 84                    1079 	.db	00181$
      00741B B9                    1080 	.db	00123$
      00741C 84                    1081 	.db	00181$
      00741D 84                    1082 	.db	00181$
      00741E 84                    1083 	.db	00181$
      00741F 19                    1084 	.db	00131$
      007420 EB                    1085 	.db	00147$
      007421 11                    1086 	.db	00152$
      007422 11                    1087 	.db	00152$
      007423                       1088 00436$:
      007423 74                    1089 	.db	00102$>>8
      007424 74                    1090 	.db	00102$>>8
      007425 76                    1091 	.db	00181$>>8
      007426 76                    1092 	.db	00181$>>8
      007427 74                    1093 	.db	00123$>>8
      007428 76                    1094 	.db	00181$>>8
      007429 76                    1095 	.db	00181$>>8
      00742A 76                    1096 	.db	00181$>>8
      00742B 75                    1097 	.db	00131$>>8
      00742C 75                    1098 	.db	00147$>>8
      00742D 76                    1099 	.db	00152$>>8
      00742E 76                    1100 	.db	00152$>>8
                                   1101 ;	quantum/action.c:528: case ACT_RMODS: {
      00742F                       1102 00102$:
                                   1103 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00742F 90 08 3A         [24] 1104 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007432 E0               [24] 1105 	movx	a,@dptr
      007433 54 F0            [12] 1106 	anl	a,#0xf0
      007435 70 06            [24] 1107 	jnz	00194$
      007437 12 78 92         [24] 1108 	lcall	_ak820_outline_0109
      00743A FD               [12] 1109 	mov	r5,a
      00743B 80 07            [24] 1110 	sjmp	00195$
      00743D                       1111 00194$:
      00743D 12 78 92         [24] 1112 	lcall	_ak820_outline_0109
      007440 C4               [12] 1113 	swap	a
      007441 54 F0            [12] 1114 	anl	a,#0xf0
      007443 FD               [12] 1115 	mov	r5,a
      007444                       1116 00195$:
                                   1117 ;	quantum/action.c:531: if (pressed) {
      007444 E5 27            [12] 1118 	mov	a,_process_action_sloc0_1_0
      007446 60 35            [24] 1119 	jz	00119$
                                   1120 ;	quantum/action.c:532: if (mods) {
      007448 ED               [12] 1121 	mov	a,r5
      007449 60 29            [24] 1122 	jz	00110$
                                   1123 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00744B 12 78 A4         [24] 1124 	lcall	_ak820_outline_0153
      00744E FC               [12] 1125 	mov	r4,a
      00744F BC E0 00         [24] 1126 	cjne	r4,#0xe0,00440$
      007452                       1127 00440$:
      007452 40 07            [24] 1128 	jc	00108$
      007454 12 78 A4         [24] 1129 	lcall	_ak820_outline_0153
      007457 24 18            [12] 1130 	add	a,#0xff - 0xe7
      007459 50 0A            [24] 1131 	jnc	00104$
                                   1132 ;	free result
      00745B                       1133 00108$:
      00745B 7B 39            [12] 1134 	mov	r3,#_process_action_PARM_2
      00745D 7C 08            [12] 1135 	mov	r4,#(_process_action_PARM_2 >> 8)
      00745F 12 36 42         [24] 1136 	lcall	_ak820_outline_0121
      007462 E0               [24] 1137 	movx	a,@dptr
      007463 70 07            [24] 1138 	jnz	00105$
      007465                       1139 00104$:
                                   1140 ;	quantum/action.c:537: add_owned_mods(mods);
      007465 8D 82            [24] 1141 	mov	dpl, r5
      007467 12 7E 0A         [24] 1142 	lcall	_add_owned_mods
      00746A 80 05            [24] 1143 	sjmp	00106$
      00746C                       1144 00105$:
                                   1145 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      00746C 8D 82            [24] 1146 	mov	dpl, r5
      00746E 12 7E 29         [24] 1147 	lcall	_add_owned_weak_mods
      007471                       1148 00106$:
                                   1149 ;	quantum/action.c:541: send_keyboard_report();
      007471 12 81 44         [24] 1150 	lcall	_send_keyboard_report
      007474                       1151 00110$:
                                   1152 ;	quantum/action.c:543: register_code(action.key.code);
      007474 12 78 7B         [24] 1153 	lcall	_ak820_outline_0075
      007477 12 76 9B         [24] 1154 	lcall	_register_code
      00747A 02 76 84         [24] 1155 	ljmp	00181$
      00747D                       1156 00119$:
                                   1157 ;	quantum/action.c:545: unregister_code(action.key.code);
      00747D 12 78 7B         [24] 1158 	lcall	_ak820_outline_0075
      007480 C0 05            [24] 1159 	push	ar5
      007482 12 77 08         [24] 1160 	lcall	_unregister_code
      007485 D0 05            [24] 1161 	pop	ar5
                                   1162 ;	quantum/action.c:546: if (mods) {
      007487 ED               [12] 1163 	mov	a,r5
      007488 70 03            [24] 1164 	jnz	00444$
      00748A 02 76 84         [24] 1165 	ljmp	00181$
      00748D                       1166 00444$:
                                   1167 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00748D 12 78 A4         [24] 1168 	lcall	_ak820_outline_0153
      007490 FC               [12] 1169 	mov	r4,a
      007491 BC E0 00         [24] 1170 	cjne	r4,#0xe0,00445$
      007494                       1171 00445$:
      007494 40 07            [24] 1172 	jc	00115$
      007496 12 78 A4         [24] 1173 	lcall	_ak820_outline_0153
      007499 24 18            [12] 1174 	add	a,#0xff - 0xe7
      00749B 50 0A            [24] 1175 	jnc	00111$
                                   1176 ;	free result
      00749D                       1177 00115$:
      00749D 7B 39            [12] 1178 	mov	r3,#_process_action_PARM_2
      00749F 7C 08            [12] 1179 	mov	r4,#(_process_action_PARM_2 >> 8)
      0074A1 12 36 42         [24] 1180 	lcall	_ak820_outline_0121
      0074A4 E0               [24] 1181 	movx	a,@dptr
      0074A5 70 07            [24] 1182 	jnz	00112$
      0074A7                       1183 00111$:
                                   1184 ;	quantum/action.c:548: del_owned_mods(mods);
      0074A7 8D 82            [24] 1185 	mov	dpl, r5
      0074A9 12 7E 1A         [24] 1186 	lcall	_del_owned_mods
      0074AC 80 05            [24] 1187 	sjmp	00113$
      0074AE                       1188 00112$:
                                   1189 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      0074AE 8D 82            [24] 1190 	mov	dpl, r5
      0074B0 12 7E 39         [24] 1191 	lcall	_del_owned_weak_mods
      0074B3                       1192 00113$:
                                   1193 ;	quantum/action.c:552: send_keyboard_report();
      0074B3 12 81 44         [24] 1194 	lcall	_send_keyboard_report
                                   1195 ;	quantum/action.c:555: } break;
      0074B6 02 76 84         [24] 1196 	ljmp	00181$
                                   1197 ;	quantum/action.c:632: case ACT_USAGE:
      0074B9                       1198 00123$:
                                   1199 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0074B9 74 07            [12] 1200 	mov	a,#0x07
      0074BB 12 3A 37         [24] 1201 	lcall	_ak820_outline_0030
      0074BE 12 3A 12         [24] 1202 	lcall	_ak820_outline_0009
      0074C1 C3               [12] 1203 	clr	c
      0074C2 EC               [12] 1204 	mov	a,r4
      0074C3 94 A5            [12] 1205 	subb	a,#0xa5
      0074C5 ED               [12] 1206 	mov	a,r5
      0074C6 94 00            [12] 1207 	subb	a,#0x00
      0074C8 40 15            [24] 1208 	jc	00125$
      0074CA 74 C2            [12] 1209 	mov	a,#0xc2
      0074CC 9C               [12] 1210 	subb	a,r4
      0074CD E4               [12] 1211 	clr	a
      0074CE 9D               [12] 1212 	subb	a,r5
      0074CF 40 0E            [24] 1213 	jc	00125$
                                   1214 ;	free result
                                   1215 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      0074D1 90 0A 99         [24] 1216 	mov	dptr,#_owned_usage_key_PARM_2
      0074D4 E5 27            [12] 1217 	mov	a,_process_action_sloc0_1_0
      0074D6 F0               [24] 1218 	movx	@dptr,a
      0074D7 8E 82            [24] 1219 	mov	dpl, r6
      0074D9 12 7F EF         [24] 1220 	lcall	_owned_usage_key
                                   1221 ;	quantum/action.c:640: break;
      0074DC 02 76 84         [24] 1222 	ljmp	00181$
      0074DF                       1223 00125$:
                                   1224 ;	quantum/action.c:643: switch (action.usage.page) {
      0074DF 12 78 82         [24] 1225 	lcall	_ak820_outline_0085
      0074E2 FF               [12] 1226 	mov	r7,a
      0074E3 60 08            [24] 1227 	jz	00127$
      0074E5 BF 01 02         [24] 1228 	cjne	r7,#0x01,00452$
      0074E8 80 19            [24] 1229 	sjmp	00128$
      0074EA                       1230 00452$:
      0074EA 02 76 84         [24] 1231 	ljmp	00181$
                                   1232 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0074ED                       1233 00127$:
                                   1234 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0074ED E5 27            [12] 1235 	mov	a,_process_action_sloc0_1_0
      0074EF 60 05            [24] 1236 	jz	00196$
      0074F1 12 78 99         [24] 1237 	lcall	_ak820_outline_0128
      0074F4 80 04            [24] 1238 	sjmp	00197$
      0074F6                       1239 00196$:
      0074F6 7E 00            [12] 1240 	mov	r6,#0x00
      0074F8 7F 00            [12] 1241 	mov	r7,#0x00
      0074FA                       1242 00197$:
      0074FA 12 45 66         [24] 1243 	lcall	_ak820_outline_0116
      0074FD 12 6E CE         [24] 1244 	lcall	_host_system_send
                                   1245 ;	quantum/action.c:646: break;
      007500 02 76 84         [24] 1246 	ljmp	00181$
                                   1247 ;	quantum/action.c:647: case PAGE_CONSUMER:
      007503                       1248 00128$:
                                   1249 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      007503 E5 27            [12] 1250 	mov	a,_process_action_sloc0_1_0
      007505 60 05            [24] 1251 	jz	00198$
      007507 12 78 99         [24] 1252 	lcall	_ak820_outline_0128
      00750A 80 04            [24] 1253 	sjmp	00199$
      00750C                       1254 00198$:
      00750C 7E 00            [12] 1255 	mov	r6,#0x00
      00750E 7F 00            [12] 1256 	mov	r7,#0x00
      007510                       1257 00199$:
      007510 12 45 66         [24] 1258 	lcall	_ak820_outline_0116
      007513 12 6E FE         [24] 1259 	lcall	_host_consumer_send
                                   1260 ;	quantum/action.c:651: break;
      007516 02 76 84         [24] 1261 	ljmp	00181$
                                   1262 ;	quantum/action.c:658: case ACT_LAYER: {
      007519                       1263 00131$:
                                   1264 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      007519 90 08 3A         [24] 1265 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00751C E0               [24] 1266 	movx	a,@dptr
      00751D 54 03            [12] 1267 	anl	a,#0x03
      00751F 90 08 3D         [24] 1268 	mov	dptr,#_process_action_on_40000_680
      007522 F0               [24] 1269 	movx	@dptr,a
                                   1270 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007523 E0               [24] 1271 	movx	a,@dptr
      007524 FF               [12] 1272 	mov	r7,a
      007525 60 11            [24] 1273 	jz	00200$
      007527 E5 27            [12] 1274 	mov	a,_process_action_sloc0_1_0
      007529 60 07            [24] 1275 	jz	00202$
      00752B 8F 06            [24] 1276 	mov	ar6,r7
      00752D 53 06 01         [24] 1277 	anl	ar6,#0x01
      007530 80 10            [24] 1278 	sjmp	00201$
      007532                       1279 00202$:
      007532 74 02            [12] 1280 	mov	a,#0x02
      007534 5F               [12] 1281 	anl	a,r7
      007535 FE               [12] 1282 	mov	r6,a
      007536 80 0A            [24] 1283 	sjmp	00201$
      007538                       1284 00200$:
      007538 E5 27            [12] 1285 	mov	a,_process_action_sloc0_1_0
      00753A B4 01 00         [24] 1286 	cjne	a,#0x01,00457$
      00753D                       1287 00457$:
      00753D 92 1E            [24] 1288 	mov  _process_action_sloc1_1_0,c
      00753F E4               [12] 1289 	clr	a
      007540 33               [12] 1290 	rlc	a
      007541 FE               [12] 1291 	mov	r6,a
      007542                       1292 00201$:
      007542 EE               [12] 1293 	mov	a,r6
      007543 70 03            [24] 1294 	jnz	00458$
      007545 02 76 84         [24] 1295 	ljmp	00181$
      007548                       1296 00458$:
                                   1297 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007548 12 78 A4         [24] 1298 	lcall	_ak820_outline_0153
      00754B C4               [12] 1299 	swap	a
      00754C 03               [12] 1300 	rr	a
      00754D 54 07            [12] 1301 	anl	a,#0x07
      00754F 25 E0            [12] 1302 	add	a,acc
      007551 25 E0            [12] 1303 	add	a,acc
      007553 FF               [12] 1304 	mov	r7,a
                                   1305 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007554 12 78 A4         [24] 1306 	lcall	_ak820_outline_0153
      007557 54 0F            [12] 1307 	anl	a,#0x0f
      007559 FE               [12] 1308 	mov	r6,a
      00755A 8F F0            [24] 1309 	mov	b,r7
      00755C 05 F0            [12] 1310 	inc	b
      00755E EE               [12] 1311 	mov	a,r6
      00755F 80 02            [24] 1312 	sjmp	00460$
      007561                       1313 00459$:
      007561 25 E0            [12] 1314 	add	a,acc
      007563                       1315 00460$:
      007563 D5 F0 FB         [24] 1316 	djnz	b,00459$
      007566 FE               [12] 1317 	mov	r6,a
                                   1318 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007567 12 78 A4         [24] 1319 	lcall	_ak820_outline_0153
      00756A 30 E4 11         [24] 1320 	jnb	acc.4,00204$
      00756D 8F F0            [24] 1321 	mov	b,r7
      00756F 05 F0            [12] 1322 	inc	b
      007571 74 0F            [12] 1323 	mov	a,#0x0f
      007573 80 02            [24] 1324 	sjmp	00463$
      007575                       1325 00462$:
      007575 25 E0            [12] 1326 	add	a,acc
      007577                       1327 00463$:
      007577 D5 F0 FB         [24] 1328 	djnz	b,00462$
      00757A F4               [12] 1329 	cpl	a
      00757B FF               [12] 1330 	mov	r7,a
      00757C 80 02            [24] 1331 	sjmp	00205$
      00757E                       1332 00204$:
      00757E 7F 00            [12] 1333 	mov	r7,#0x00
      007580                       1334 00205$:
                                   1335 ;	quantum/action.c:666: bits |= mask;
      007580 EE               [12] 1336 	mov	a,r6
      007581 42 07            [12] 1337 	orl	ar7,a
                                   1338 ;	quantum/action.c:667: if (!on) {
      007583 90 08 3D         [24] 1339 	mov	dptr,#_process_action_on_40000_680
      007586 E0               [24] 1340 	movx	a,@dptr
      007587 70 31            [24] 1341 	jnz	00143$
                                   1342 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      007589 12 78 82         [24] 1343 	lcall	_ak820_outline_0085
      00758C FE               [12] 1344 	mov	r6,a
      00758D 2E               [12] 1345 	add	a,r6
                                   1346 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      00758E 90 75 92         [24] 1347 	mov	dptr,#00465$
      007591 73               [24] 1348 	jmp	@a+dptr
      007592                       1349 00465$:
      007592 80 06            [24] 1350 	sjmp	00132$
      007594 80 0C            [24] 1351 	sjmp	00133$
      007596 80 12            [24] 1352 	sjmp	00134$
      007598 80 18            [24] 1353 	sjmp	00135$
      00759A                       1354 00132$:
      00759A 8F 82            [24] 1355 	mov	dpl, r7
      00759C 12 78 FF         [24] 1356 	lcall	_default_layer_and
      00759F 02 76 84         [24] 1357 	ljmp	00181$
                                   1358 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      0075A2                       1359 00133$:
      0075A2 8F 82            [24] 1360 	mov	dpl, r7
      0075A4 12 78 EE         [24] 1361 	lcall	_default_layer_or
      0075A7 02 76 84         [24] 1362 	ljmp	00181$
                                   1363 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      0075AA                       1364 00134$:
      0075AA 8F 82            [24] 1365 	mov	dpl, r7
      0075AC 12 79 15         [24] 1366 	lcall	_default_layer_xor
      0075AF 02 76 84         [24] 1367 	ljmp	00181$
                                   1368 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      0075B2                       1369 00135$:
      0075B2 8F 82            [24] 1370 	mov	dpl, r7
      0075B4 12 78 E3         [24] 1371 	lcall	_default_layer_set
                                   1372 ;	quantum/action.c:673: }
      0075B7 02 76 84         [24] 1373 	ljmp	00181$
      0075BA                       1374 00143$:
                                   1375 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      0075BA 12 78 82         [24] 1376 	lcall	_ak820_outline_0085
      0075BD FE               [12] 1377 	mov	r6,a
      0075BE 2E               [12] 1378 	add	a,r6
                                   1379 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      0075BF 90 75 C3         [24] 1380 	mov	dptr,#00466$
      0075C2 73               [24] 1381 	jmp	@a+dptr
      0075C3                       1382 00466$:
      0075C3 80 06            [24] 1383 	sjmp	00137$
      0075C5 80 0C            [24] 1384 	sjmp	00138$
      0075C7 80 12            [24] 1385 	sjmp	00139$
      0075C9 80 18            [24] 1386 	sjmp	00140$
      0075CB                       1387 00137$:
      0075CB 8F 82            [24] 1388 	mov	dpl, r7
      0075CD 12 7A 98         [24] 1389 	lcall	_layer_and
      0075D0 02 76 84         [24] 1390 	ljmp	00181$
                                   1391 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      0075D3                       1392 00138$:
      0075D3 8F 82            [24] 1393 	mov	dpl, r7
      0075D5 12 7A 87         [24] 1394 	lcall	_layer_or
      0075D8 02 76 84         [24] 1395 	ljmp	00181$
                                   1396 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      0075DB                       1397 00139$:
      0075DB 8F 82            [24] 1398 	mov	dpl, r7
      0075DD 12 7A AE         [24] 1399 	lcall	_layer_xor
      0075E0 02 76 84         [24] 1400 	ljmp	00181$
                                   1401 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      0075E3                       1402 00140$:
      0075E3 8F 82            [24] 1403 	mov	dpl, r7
      0075E5 12 7A 24         [24] 1404 	lcall	_layer_state_set
                                   1405 ;	quantum/action.c:683: break;
      0075E8 02 76 84         [24] 1406 	ljmp	00181$
                                   1407 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      0075EB                       1408 00147$:
                                   1409 ;	quantum/action.c:686: if (pressed) {
      0075EB E5 27            [12] 1410 	mov	a,_process_action_sloc0_1_0
      0075ED 60 11            [24] 1411 	jz	00149$
                                   1412 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      0075EF 12 78 92         [24] 1413 	lcall	_ak820_outline_0109
      0075F2 F5 82            [12] 1414 	mov	dpl,a
      0075F4 12 79 85         [24] 1415 	lcall	_layer_hold_on
                                   1416 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      0075F7 12 78 7B         [24] 1417 	lcall	_ak820_outline_0075
      0075FA 12 77 BE         [24] 1418 	lcall	_register_mods
      0075FD 02 76 84         [24] 1419 	ljmp	00181$
      007600                       1420 00149$:
                                   1421 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      007600 12 78 7B         [24] 1422 	lcall	_ak820_outline_0075
      007603 12 77 D2         [24] 1423 	lcall	_unregister_mods
                                   1424 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      007606 12 78 92         [24] 1425 	lcall	_ak820_outline_0109
      007609 F5 82            [12] 1426 	mov	dpl,a
      00760B 12 79 BD         [24] 1427 	lcall	_layer_hold_off
                                   1428 ;	quantum/action.c:693: break;
      00760E 02 76 84         [24] 1429 	ljmp	00181$
                                   1430 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      007611                       1431 00152$:
                                   1432 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      007611 12 78 A4         [24] 1433 	lcall	_ak820_outline_0153
      007614 FF               [12] 1434 	mov	r7,a
      007615 BF F1 02         [24] 1435 	cjne	r7,#0xf1,00468$
      007618 80 0A            [24] 1436 	sjmp	00154$
      00761A                       1437 00468$:
      00761A BF F2 02         [24] 1438 	cjne	r7,#0xf2,00469$
      00761D 80 19            [24] 1439 	sjmp	00155$
      00761F                       1440 00469$:
                                   1441 ;	quantum/action.c:712: momentary_layer_action:
      00761F BF F3 3B         [24] 1442 	cjne	r7,#0xf3,00160$
      007622 80 28            [24] 1443 	sjmp	00156$
      007624                       1444 00154$:
                                   1445 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007624 E5 27            [12] 1446 	mov	a,_process_action_sloc0_1_0
      007626 60 08            [24] 1447 	jz	00206$
      007628 12 78 62         [24] 1448 	lcall	_ak820_outline_0038
      00762B 12 79 85         [24] 1449 	lcall	_layer_hold_on
      00762E 80 54            [24] 1450 	sjmp	00181$
      007630                       1451 00206$:
      007630 12 78 62         [24] 1452 	lcall	_ak820_outline_0038
      007633 12 79 BD         [24] 1453 	lcall	_layer_hold_off
                                   1454 ;	quantum/action.c:714: break;
                                   1455 ;	quantum/action.c:715: case OP_OFF_ON:
      007636 80 4C            [24] 1456 	sjmp	00181$
      007638                       1457 00155$:
                                   1458 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007638 E5 27            [12] 1459 	mov	a,_process_action_sloc0_1_0
      00763A 60 08            [24] 1460 	jz	00208$
      00763C 12 78 62         [24] 1461 	lcall	_ak820_outline_0038
      00763F 12 7A 69         [24] 1462 	lcall	_layer_off
      007642 80 40            [24] 1463 	sjmp	00181$
      007644                       1464 00208$:
      007644 12 78 62         [24] 1465 	lcall	_ak820_outline_0038
      007647 12 7A 4E         [24] 1466 	lcall	_layer_on
                                   1467 ;	quantum/action.c:717: break;
                                   1468 ;	quantum/action.c:718: case OP_SET_CLEAR:
      00764A 80 38            [24] 1469 	sjmp	00181$
      00764C                       1470 00156$:
                                   1471 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00764C E5 27            [12] 1472 	mov	a,_process_action_sloc0_1_0
      00764E 60 08            [24] 1473 	jz	00210$
      007650 12 78 62         [24] 1474 	lcall	_ak820_outline_0038
      007653 12 7A 38         [24] 1475 	lcall	_layer_move
      007656 80 2C            [24] 1476 	sjmp	00181$
      007658                       1477 00210$:
      007658 12 7A 32         [24] 1478 	lcall	_layer_clear
                                   1479 ;	quantum/action.c:720: break;
                                   1480 ;	quantum/action.c:766: default:
      00765B 80 27            [24] 1481 	sjmp	00181$
      00765D                       1482 00160$:
                                   1483 ;	quantum/action.c:773: if (pressed) {
      00765D E5 27            [12] 1484 	mov	a,_process_action_sloc0_1_0
      00765F 60 08            [24] 1485 	jz	00163$
                                   1486 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007661 12 78 7B         [24] 1487 	lcall	_ak820_outline_0075
      007664 12 76 9B         [24] 1488 	lcall	_register_code
                                   1489 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007667 80 1B            [24] 1490 	sjmp	00181$
      007669                       1491 00163$:
                                   1492 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007669 12 78 A4         [24] 1493 	lcall	_ak820_outline_0153
      00766C FF               [12] 1494 	mov	r7,a
      00766D BF 39 0E         [24] 1495 	cjne	r7,#0x39,00175$
                                   1496 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      007670 7F 50            [12] 1497 	mov	r7,#0x50
      007672                       1498 00187$:
      007672 EF               [12] 1499 	mov	a,r7
      007673 60 09            [24] 1500 	jz	00175$
      007675 90 00 01         [24] 1501 	mov	dptr,#0x0001
      007678 12 5A A8         [24] 1502 	lcall	_mDelaymS
      00767B 1F               [12] 1503 	dec	r7
                                   1504 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      00767C 80 F4            [24] 1505 	sjmp	00187$
      00767E                       1506 00175$:
                                   1507 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      00767E 12 78 7B         [24] 1508 	lcall	_ak820_outline_0075
      007681 12 77 08         [24] 1509 	lcall	_unregister_code
                                   1510 ;	quantum/action.c:866: }
      007684                       1511 00181$:
                                   1512 ;	quantum/action.c:887: switch (action.kind.id) {
      007684 90 08 3A         [24] 1513 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007687 E0               [24] 1514 	movx	a,@dptr
      007688 C4               [12] 1515 	swap	a
      007689 54 0F            [12] 1516 	anl	a,#0x0f
      00768B FF               [12] 1517 	mov	r7,a
      00768C BF 08 02         [24] 1518 	cjne	r7,#0x08,00478$
      00768F 80 03            [24] 1519 	sjmp	00183$
      007691                       1520 00478$:
      007691 BF 09 06         [24] 1521 	cjne	r7,#0x09,00192$
                                   1522 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007694                       1523 00183$:
                                   1524 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007694 12 6E 33         [24] 1525 	lcall	_host_keyboard_leds
                                   1526 ;	quantum/action.c:898: }
                                   1527 ;	quantum/action.c:951: }
      007697 02 98 A0         [24] 1528 	ljmp	_led_set
      00769A                       1529 00192$:
      00769A 22               [24] 1530 	ret
                                   1531 ;------------------------------------------------------------
                                   1532 ;Allocation info for local variables in function 'register_code'
                                   1533 ;------------------------------------------------------------
                                   1534 ;code          Allocated with name '_register_code_code_10000_714'
                                   1535 ;------------------------------------------------------------
                                   1536 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1537 ;	-----------------------------------------
                                   1538 ;	 function register_code
                                   1539 ;	-----------------------------------------
      00769B                       1540 _register_code:
      00769B E5 82            [12] 1541 	mov	a,dpl
      00769D 90 08 3E         [24] 1542 	mov	dptr,#_register_code_code_10000_714
      0076A0 F0               [24] 1543 	movx	@dptr,a
                                   1544 ;	quantum/action.c:958: if (code == KC_NO) {
      0076A1 E0               [24] 1545 	movx	a,@dptr
      0076A2 FF               [12] 1546 	mov	r7,a
      0076A3 70 01            [24] 1547 	jnz	00123$
                                   1548 ;	quantum/action.c:959: return;
      0076A5 22               [24] 1549 	ret
      0076A6                       1550 00123$:
                                   1551 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      0076A6 BF 04 00         [24] 1552 	cjne	r7,#0x04,00186$
      0076A9                       1553 00186$:
      0076A9 40 12            [24] 1554 	jc	00119$
      0076AB EF               [12] 1555 	mov	a,r7
      0076AC 24 5B            [12] 1556 	add	a,#0xff - 0xa4
      0076AE 40 0D            [24] 1557 	jc	00119$
                                   1558 ;	free result
                                   1559 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      0076B0 8F 82            [24] 1560 	mov	dpl, r7
      0076B2 12 7E AE         [24] 1561 	lcall	_add_owned_key
      0076B5 E5 82            [12] 1562 	mov	a, dpl
      0076B7 70 01            [24] 1563 	jnz	00104$
      0076B9 22               [24] 1564 	ret
      0076BA                       1565 00104$:
                                   1566 ;	quantum/action.c:1013: send_keyboard_report();
      0076BA 02 81 44         [24] 1567 	ljmp	_send_keyboard_report
      0076BD                       1568 00119$:
                                   1569 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      0076BD 12 78 A9         [24] 1570 	lcall	_ak820_outline_0161
      0076C0 BF E0 00         [24] 1571 	cjne	r7,#0xe0,00190$
      0076C3                       1572 00190$:
      0076C3 40 1A            [24] 1573 	jc	00115$
      0076C5 EF               [12] 1574 	mov	a,r7
      0076C6 24 18            [12] 1575 	add	a,#0xff - 0xe7
      0076C8 40 15            [24] 1576 	jc	00115$
                                   1577 ;	free result
                                   1578 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      0076CA 74 07            [12] 1579 	mov	a,#0x07
      0076CC 5F               [12] 1580 	anl	a,r7
      0076CD 12 78 74         [24] 1581 	lcall	_ak820_outline_0062
      0076D0 80 02            [24] 1582 	sjmp	00194$
      0076D2                       1583 00193$:
      0076D2 25 E0            [12] 1584 	add	a,acc
      0076D4                       1585 00194$:
      0076D4 D5 F0 FB         [24] 1586 	djnz	b,00193$
      0076D7 F5 82            [12] 1587 	mov	dpl,a
      0076D9 12 7E 0A         [24] 1588 	lcall	_add_owned_mods
                                   1589 ;	quantum/action.c:1016: send_keyboard_report();
      0076DC 02 81 44         [24] 1590 	ljmp	_send_keyboard_report
      0076DF                       1591 00115$:
                                   1592 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0076DF 12 78 A9         [24] 1593 	lcall	_ak820_outline_0161
      0076E2 BF A5 00         [24] 1594 	cjne	r7,#0xa5,00195$
      0076E5                       1595 00195$:
      0076E5 40 05            [24] 1596 	jc	00113$
      0076E7 EF               [12] 1597 	mov	a,r7
      0076E8 24 58            [12] 1598 	add	a,#0xff - 0xa7
      0076EA 50 0D            [24] 1599 	jnc	00108$
                                   1600 ;	free result
      0076EC                       1601 00113$:
      0076EC 12 78 A9         [24] 1602 	lcall	_ak820_outline_0161
      0076EF BF A8 00         [24] 1603 	cjne	r7,#0xa8,00198$
      0076F2                       1604 00198$:
      0076F2 40 13            [24] 1605 	jc	00125$
      0076F4 EF               [12] 1606 	mov	a,r7
      0076F5 24 3D            [12] 1607 	add	a,#0xff - 0xc2
      0076F7 40 0E            [24] 1608 	jc	00125$
                                   1609 ;	free result
      0076F9                       1610 00108$:
                                   1611 ;	quantum/action.c:1021: owned_usage_key(code, true);
      0076F9 12 78 A9         [24] 1612 	lcall	_ak820_outline_0161
      0076FC 90 0A 99         [24] 1613 	mov	dptr,#_owned_usage_key_PARM_2
      0076FF 74 01            [12] 1614 	mov	a,#0x01
      007701 F0               [24] 1615 	movx	@dptr,a
      007702 8F 82            [24] 1616 	mov	dpl, r7
                                   1617 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1618 ;	quantum/action.c:1031: }
      007704 02 7F EF         [24] 1619 	ljmp	_owned_usage_key
      007707                       1620 00125$:
      007707 22               [24] 1621 	ret
                                   1622 ;------------------------------------------------------------
                                   1623 ;Allocation info for local variables in function 'unregister_code'
                                   1624 ;------------------------------------------------------------
                                   1625 ;code          Allocated with name '_unregister_code_code_10000_728'
                                   1626 ;------------------------------------------------------------
                                   1627 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1628 ;	-----------------------------------------
                                   1629 ;	 function unregister_code
                                   1630 ;	-----------------------------------------
      007708                       1631 _unregister_code:
      007708 E5 82            [12] 1632 	mov	a,dpl
      00770A 90 08 3F         [24] 1633 	mov	dptr,#_unregister_code_code_10000_728
      00770D F0               [24] 1634 	movx	@dptr,a
                                   1635 ;	quantum/action.c:1038: if (code == KC_NO) {
      00770E E0               [24] 1636 	movx	a,@dptr
      00770F FF               [12] 1637 	mov	r7,a
      007710 70 01            [24] 1638 	jnz	00121$
                                   1639 ;	quantum/action.c:1039: return;
      007712 22               [24] 1640 	ret
      007713                       1641 00121$:
                                   1642 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      007713 BF 04 00         [24] 1643 	cjne	r7,#0x04,00184$
      007716                       1644 00184$:
      007716 40 12            [24] 1645 	jc	00117$
      007718 EF               [12] 1646 	mov	a,r7
      007719 24 5B            [12] 1647 	add	a,#0xff - 0xa4
      00771B 40 0D            [24] 1648 	jc	00117$
                                   1649 ;	free result
                                   1650 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      00771D 8F 82            [24] 1651 	mov	dpl, r7
      00771F 12 7F 28         [24] 1652 	lcall	_del_owned_key
      007722 E5 82            [12] 1653 	mov	a, dpl
      007724 70 01            [24] 1654 	jnz	00102$
      007726 22               [24] 1655 	ret
      007727                       1656 00102$:
                                   1657 ;	quantum/action.c:1080: send_keyboard_report();
      007727 02 81 44         [24] 1658 	ljmp	_send_keyboard_report
      00772A                       1659 00117$:
                                   1660 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      00772A 12 78 AF         [24] 1661 	lcall	_ak820_outline_0162
      00772D BF E0 00         [24] 1662 	cjne	r7,#0xe0,00188$
      007730                       1663 00188$:
      007730 40 1A            [24] 1664 	jc	00113$
      007732 EF               [12] 1665 	mov	a,r7
      007733 24 18            [12] 1666 	add	a,#0xff - 0xe7
      007735 40 15            [24] 1667 	jc	00113$
                                   1668 ;	free result
                                   1669 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007737 74 07            [12] 1670 	mov	a,#0x07
      007739 5F               [12] 1671 	anl	a,r7
      00773A 12 78 74         [24] 1672 	lcall	_ak820_outline_0062
      00773D 80 02            [24] 1673 	sjmp	00192$
      00773F                       1674 00191$:
      00773F 25 E0            [12] 1675 	add	a,acc
      007741                       1676 00192$:
      007741 D5 F0 FB         [24] 1677 	djnz	b,00191$
      007744 F5 82            [12] 1678 	mov	dpl,a
      007746 12 7E 1A         [24] 1679 	lcall	_del_owned_mods
                                   1680 ;	quantum/action.c:1083: send_keyboard_report();
      007749 02 81 44         [24] 1681 	ljmp	_send_keyboard_report
      00774C                       1682 00113$:
                                   1683 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00774C 12 78 AF         [24] 1684 	lcall	_ak820_outline_0162
      00774F BF A5 00         [24] 1685 	cjne	r7,#0xa5,00193$
      007752                       1686 00193$:
      007752 40 05            [24] 1687 	jc	00111$
      007754 EF               [12] 1688 	mov	a,r7
      007755 24 58            [12] 1689 	add	a,#0xff - 0xa7
      007757 50 0D            [24] 1690 	jnc	00106$
                                   1691 ;	free result
      007759                       1692 00111$:
      007759 12 78 AF         [24] 1693 	lcall	_ak820_outline_0162
      00775C BF A8 00         [24] 1694 	cjne	r7,#0xa8,00196$
      00775F                       1695 00196$:
      00775F 40 12            [24] 1696 	jc	00123$
      007761 EF               [12] 1697 	mov	a,r7
      007762 24 3D            [12] 1698 	add	a,#0xff - 0xc2
      007764 40 0D            [24] 1699 	jc	00123$
                                   1700 ;	free result
      007766                       1701 00106$:
                                   1702 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007766 12 78 AF         [24] 1703 	lcall	_ak820_outline_0162
      007769 90 0A 99         [24] 1704 	mov	dptr,#_owned_usage_key_PARM_2
      00776C E4               [12] 1705 	clr	a
      00776D F0               [24] 1706 	movx	@dptr,a
      00776E 8F 82            [24] 1707 	mov	dpl, r7
                                   1708 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1709 ;	quantum/action.c:1098: }
      007770 02 7F EF         [24] 1710 	ljmp	_owned_usage_key
      007773                       1711 00123$:
      007773 22               [24] 1712 	ret
                                   1713 ;------------------------------------------------------------
                                   1714 ;Allocation info for local variables in function 'tap_code_delay'
                                   1715 ;------------------------------------------------------------
                                   1716 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1717 ;code          Allocated with name '_tap_code_delay_code_10000_741'
                                   1718 ;i             Allocated with name '_tap_code_delay_i_20000_743'
                                   1719 ;i             Allocated with name '_tap_code_delay_i_50000_746'
                                   1720 ;------------------------------------------------------------
                                   1721 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1722 ;	-----------------------------------------
                                   1723 ;	 function tap_code_delay
                                   1724 ;	-----------------------------------------
      007774                       1725 _tap_code_delay:
      007774 E5 82            [12] 1726 	mov	a,dpl
      007776 90 08 42         [24] 1727 	mov	dptr,#_tap_code_delay_code_10000_741
      007779 F0               [24] 1728 	movx	@dptr,a
                                   1729 ;	quantum/action.c:1106: register_code(code);
      00777A E0               [24] 1730 	movx	a,@dptr
      00777B FF               [12] 1731 	mov	r7,a
      00777C F5 82            [12] 1732 	mov	dpl,a
      00777E C0 07            [24] 1733 	push	ar7
      007780 12 76 9B         [24] 1734 	lcall	_register_code
      007783 D0 07            [24] 1735 	pop	ar7
                                   1736 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007785 90 08 40         [24] 1737 	mov	dptr,#_tap_code_delay_PARM_2
      007788 12 45 54         [24] 1738 	lcall	_ak820_outline_0092
      00778B                       1739 00110$:
      00778B ED               [12] 1740 	mov	a,r5
      00778C 4E               [12] 1741 	orl	a,r6
      00778D 60 0D            [24] 1742 	jz	00105$
                                   1743 ;	quantum/action.c:1108: wait_ms(1);
      00778F 90 00 01         [24] 1744 	mov	dptr,#0x0001
      007792 12 5A A8         [24] 1745 	lcall	_mDelaymS
                                   1746 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007795 1D               [12] 1747 	dec	r5
      007796 BD FF 01         [24] 1748 	cjne	r5,#0xff,00141$
      007799 1E               [12] 1749 	dec	r6
      00779A                       1750 00141$:
      00779A 80 EF            [24] 1751 	sjmp	00110$
      00779C                       1752 00105$:
                                   1753 ;	quantum/action.c:1110: unregister_code(code);
      00779C 8F 82            [24] 1754 	mov	dpl, r7
                                   1755 ;	quantum/action.c:1111: }
      00779E 02 77 08         [24] 1756 	ljmp	_unregister_code
                                   1757 ;------------------------------------------------------------
                                   1758 ;Allocation info for local variables in function 'tap_code'
                                   1759 ;------------------------------------------------------------
                                   1760 ;code          Allocated with name '_tap_code_code_10000_748'
                                   1761 ;------------------------------------------------------------
                                   1762 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1763 ;	-----------------------------------------
                                   1764 ;	 function tap_code
                                   1765 ;	-----------------------------------------
      0077A1                       1766 _tap_code:
      0077A1 E5 82            [12] 1767 	mov	a,dpl
      0077A3 90 08 43         [24] 1768 	mov	dptr,#_tap_code_code_10000_748
      0077A6 F0               [24] 1769 	movx	@dptr,a
                                   1770 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0077A7 E0               [24] 1771 	movx	a,@dptr
      0077A8 FF               [12] 1772 	mov	r7,a
      0077A9 BF 39 04         [24] 1773 	cjne	r7,#0x39,00103$
      0077AC 7E 50            [12] 1774 	mov	r6,#0x50
      0077AE 80 02            [24] 1775 	sjmp	00104$
      0077B0                       1776 00103$:
      0077B0 7E 00            [12] 1777 	mov	r6,#0x00
      0077B2                       1778 00104$:
      0077B2 90 08 40         [24] 1779 	mov	dptr,#_tap_code_delay_PARM_2
      0077B5 EE               [12] 1780 	mov	a,r6
      0077B6 12 3A A6         [24] 1781 	lcall	_ak820_outline_0122
      0077B9 8F 82            [24] 1782 	mov	dpl, r7
                                   1783 ;	quantum/action.c:1119: }
      0077BB 02 77 74         [24] 1784 	ljmp	_tap_code_delay
                                   1785 ;------------------------------------------------------------
                                   1786 ;Allocation info for local variables in function 'register_mods'
                                   1787 ;------------------------------------------------------------
                                   1788 ;mods          Allocated with name '_register_mods_mods_10000_750'
                                   1789 ;------------------------------------------------------------
                                   1790 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1791 ;	-----------------------------------------
                                   1792 ;	 function register_mods
                                   1793 ;	-----------------------------------------
      0077BE                       1794 _register_mods:
      0077BE E5 82            [12] 1795 	mov	a,dpl
      0077C0 90 08 44         [24] 1796 	mov	dptr,#_register_mods_mods_10000_750
      0077C3 F0               [24] 1797 	movx	@dptr,a
                                   1798 ;	quantum/action.c:1126: if (mods) {
      0077C4 E0               [24] 1799 	movx	a,@dptr
      0077C5 FF               [12] 1800 	mov	r7,a
      0077C6 E0               [24] 1801 	movx	a,@dptr
      0077C7 60 08            [24] 1802 	jz	00103$
                                   1803 ;	quantum/action.c:1127: add_owned_mods(mods);
      0077C9 8F 82            [24] 1804 	mov	dpl, r7
      0077CB 12 7E 0A         [24] 1805 	lcall	_add_owned_mods
                                   1806 ;	quantum/action.c:1128: send_keyboard_report();
                                   1807 ;	quantum/action.c:1130: }
      0077CE 02 81 44         [24] 1808 	ljmp	_send_keyboard_report
      0077D1                       1809 00103$:
      0077D1 22               [24] 1810 	ret
                                   1811 ;------------------------------------------------------------
                                   1812 ;Allocation info for local variables in function 'unregister_mods'
                                   1813 ;------------------------------------------------------------
                                   1814 ;mods          Allocated with name '_unregister_mods_mods_10000_754'
                                   1815 ;------------------------------------------------------------
                                   1816 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1817 ;	-----------------------------------------
                                   1818 ;	 function unregister_mods
                                   1819 ;	-----------------------------------------
      0077D2                       1820 _unregister_mods:
      0077D2 E5 82            [12] 1821 	mov	a,dpl
      0077D4 90 08 45         [24] 1822 	mov	dptr,#_unregister_mods_mods_10000_754
      0077D7 F0               [24] 1823 	movx	@dptr,a
                                   1824 ;	quantum/action.c:1137: if (mods) {
      0077D8 E0               [24] 1825 	movx	a,@dptr
      0077D9 FF               [12] 1826 	mov	r7,a
      0077DA E0               [24] 1827 	movx	a,@dptr
      0077DB 60 08            [24] 1828 	jz	00103$
                                   1829 ;	quantum/action.c:1138: del_owned_mods(mods);
      0077DD 8F 82            [24] 1830 	mov	dpl, r7
      0077DF 12 7E 1A         [24] 1831 	lcall	_del_owned_mods
                                   1832 ;	quantum/action.c:1139: send_keyboard_report();
                                   1833 ;	quantum/action.c:1141: }
      0077E2 02 81 44         [24] 1834 	ljmp	_send_keyboard_report
      0077E5                       1835 00103$:
      0077E5 22               [24] 1836 	ret
                                   1837 ;------------------------------------------------------------
                                   1838 ;Allocation info for local variables in function 'register_weak_mods'
                                   1839 ;------------------------------------------------------------
                                   1840 ;mods          Allocated with name '_register_weak_mods_mods_10000_758'
                                   1841 ;------------------------------------------------------------
                                   1842 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1843 ;	-----------------------------------------
                                   1844 ;	 function register_weak_mods
                                   1845 ;	-----------------------------------------
      0077E6                       1846 _register_weak_mods:
      0077E6 E5 82            [12] 1847 	mov	a,dpl
      0077E8 90 08 46         [24] 1848 	mov	dptr,#_register_weak_mods_mods_10000_758
      0077EB F0               [24] 1849 	movx	@dptr,a
                                   1850 ;	quantum/action.c:1148: if (mods) {
      0077EC E0               [24] 1851 	movx	a,@dptr
      0077ED FF               [12] 1852 	mov	r7,a
      0077EE E0               [24] 1853 	movx	a,@dptr
      0077EF 60 08            [24] 1854 	jz	00103$
                                   1855 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      0077F1 8F 82            [24] 1856 	mov	dpl, r7
      0077F3 12 7E 29         [24] 1857 	lcall	_add_owned_weak_mods
                                   1858 ;	quantum/action.c:1150: send_keyboard_report();
                                   1859 ;	quantum/action.c:1152: }
      0077F6 02 81 44         [24] 1860 	ljmp	_send_keyboard_report
      0077F9                       1861 00103$:
      0077F9 22               [24] 1862 	ret
                                   1863 ;------------------------------------------------------------
                                   1864 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1865 ;------------------------------------------------------------
                                   1866 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_762'
                                   1867 ;------------------------------------------------------------
                                   1868 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1869 ;	-----------------------------------------
                                   1870 ;	 function unregister_weak_mods
                                   1871 ;	-----------------------------------------
      0077FA                       1872 _unregister_weak_mods:
      0077FA E5 82            [12] 1873 	mov	a,dpl
      0077FC 90 08 47         [24] 1874 	mov	dptr,#_unregister_weak_mods_mods_10000_762
      0077FF F0               [24] 1875 	movx	@dptr,a
                                   1876 ;	quantum/action.c:1159: if (mods) {
      007800 E0               [24] 1877 	movx	a,@dptr
      007801 FF               [12] 1878 	mov	r7,a
      007802 E0               [24] 1879 	movx	a,@dptr
      007803 60 08            [24] 1880 	jz	00103$
                                   1881 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      007805 8F 82            [24] 1882 	mov	dpl, r7
      007807 12 7E 39         [24] 1883 	lcall	_del_owned_weak_mods
                                   1884 ;	quantum/action.c:1161: send_keyboard_report();
                                   1885 ;	quantum/action.c:1163: }
      00780A 02 81 44         [24] 1886 	ljmp	_send_keyboard_report
      00780D                       1887 00103$:
      00780D 22               [24] 1888 	ret
                                   1889 ;------------------------------------------------------------
                                   1890 ;Allocation info for local variables in function 'clear_keyboard'
                                   1891 ;------------------------------------------------------------
                                   1892 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1893 ;	-----------------------------------------
                                   1894 ;	 function clear_keyboard
                                   1895 ;	-----------------------------------------
      00780E                       1896 _clear_keyboard:
                                   1897 ;	quantum/action.c:1170: clear_mods();
      00780E 12 81 BF         [24] 1898 	lcall	_clear_mods
                                   1899 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1900 ;	quantum/action.c:1172: }
      007811 02 78 14         [24] 1901 	ljmp	_clear_keyboard_but_mods
                                   1902 ;------------------------------------------------------------
                                   1903 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1904 ;------------------------------------------------------------
                                   1905 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1906 ;	-----------------------------------------
                                   1907 ;	 function clear_keyboard_but_mods
                                   1908 ;	-----------------------------------------
      007814                       1909 _clear_keyboard_but_mods:
                                   1910 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007814 90 0D A6         [24] 1911 	mov	dptr,#_actual_keyboard_report
      007817 12 70 F3         [24] 1912 	lcall	_clear_keys_from_report
                                   1913 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1914 ;	quantum/action.c:1181: }
      00781A 02 78 1D         [24] 1915 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1916 ;------------------------------------------------------------
                                   1917 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1918 ;------------------------------------------------------------
                                   1919 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1920 ;	-----------------------------------------
                                   1921 ;	 function clear_keyboard_but_mods_and_keys
                                   1922 ;	-----------------------------------------
      00781D                       1923 _clear_keyboard_but_mods_and_keys:
                                   1924 ;	quantum/action.c:1189: ak820_tapping_cancel();
      00781D 12 48 D6         [24] 1925 	lcall	_ak820_tapping_cancel
                                   1926 ;	quantum/action.c:1203: ak820_autoshift_cancel();
      007820 12 33 45         [24] 1927 	lcall	_ak820_autoshift_cancel
                                   1928 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007823 12 2E F0         [24] 1929 	lcall	_ak820_oneshot_cancel
                                   1930 ;	quantum/action.c:1209: ak820_combo_cancel();
      007826 12 37 6D         [24] 1931 	lcall	_ak820_combo_cancel
                                   1932 ;	quantum/action.c:1212: repeat_key_cancel();
      007829 12 A1 8E         [24] 1933 	lcall	_repeat_key_cancel
                                   1934 ;	quantum/action.c:1214: clear_owned_mods();
      00782C 12 7E 49         [24] 1935 	lcall	_clear_owned_mods
                                   1936 ;	quantum/action.c:1215: clear_owned_keys();
      00782F 12 7E 81         [24] 1937 	lcall	_clear_owned_keys
                                   1938 ;	quantum/action.c:1216: clear_owned_usages();
      007832 12 7F B7         [24] 1939 	lcall	_clear_owned_usages
                                   1940 ;	quantum/action.c:1217: layer_hold_clear();
      007835 12 79 F5         [24] 1941 	lcall	_layer_hold_clear
                                   1942 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007838 12 9D 2E         [24] 1943 	lcall	_clear_macro_tri_layer
                                   1944 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00783B 90 0D A6         [24] 1945 	mov	dptr,#_actual_keyboard_report
      00783E 12 70 F3         [24] 1946 	lcall	_clear_keys_from_report
                                   1947 ;	quantum/action.c:1224: host_system_send(0);
      007841 90 00 00         [24] 1948 	mov	dptr,#0x0000
      007844 12 6E CE         [24] 1949 	lcall	_host_system_send
                                   1950 ;	quantum/action.c:1225: host_consumer_send(0);
      007847 90 00 00         [24] 1951 	mov	dptr,#0x0000
      00784A 12 6E FE         [24] 1952 	lcall	_host_consumer_send
                                   1953 ;	quantum/action.c:1227: clear_weak_mods();
      00784D 12 81 F4         [24] 1954 	lcall	_clear_weak_mods
                                   1955 ;	quantum/action.c:1228: send_keyboard_report();
                                   1956 ;	quantum/action.c:1236: }
      007850 02 81 44         [24] 1957 	ljmp	_send_keyboard_report
                                   1958 ;------------------------------------------------------------
                                   1959 ;Allocation info for local variables in function 'is_tap_record'
                                   1960 ;------------------------------------------------------------
                                   1961 ;record        Allocated with name '_is_tap_record_record_10000_778'
                                   1962 ;action        Allocated with name '_is_tap_record_action_10001_782'
                                   1963 ;------------------------------------------------------------
                                   1964 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1965 ;	-----------------------------------------
                                   1966 	.area CSEG    (CODE)
                                   1967 	.area CONST   (CODE)
                                   1968 	.area XINIT   (CODE)
      00C100                       1969 __xinit__disable_action_cache:
      00C100 00                    1970 	.db #0x00	;  0
                                   1971 	.area CABS    (ABS,CODE)
                                   1972 
                                   1973 ; Experimental exact instruction outlining.
                                   1974 	.globl _ak820_outline_0004
                                   1975 	.globl _ak820_outline_0008
                                   1976 	.globl _ak820_outline_0009
                                   1977 	.globl _ak820_outline_0010
                                   1978 	.globl _ak820_outline_0011
                                   1979 	.globl _ak820_outline_0015
                                   1980 	.globl _ak820_outline_0016
                                   1981 	.globl _ak820_outline_0019
                                   1982 	.globl _ak820_outline_0030
                                   1983 	.globl _ak820_outline_0038
                                   1984 	.globl _ak820_outline_0049
                                   1985 	.globl _ak820_outline_0050
                                   1986 	.globl _ak820_outline_0054
                                   1987 	.globl _ak820_outline_0057
                                   1988 	.globl _ak820_outline_0062
                                   1989 	.globl _ak820_outline_0070
                                   1990 	.globl _ak820_outline_0075
                                   1991 	.globl _ak820_outline_0085
                                   1992 	.globl _ak820_outline_0092
                                   1993 	.globl _ak820_outline_0103
                                   1994 	.globl _ak820_outline_0104
                                   1995 	.globl _ak820_outline_0106
                                   1996 	.globl _ak820_outline_0107
                                   1997 	.globl _ak820_outline_0109
                                   1998 	.globl _ak820_outline_0116
                                   1999 	.globl _ak820_outline_0117
                                   2000 	.globl _ak820_outline_0121
                                   2001 	.globl _ak820_outline_0122
                                   2002 	.globl _ak820_outline_0128
                                   2003 	.globl _ak820_outline_0138
                                   2004 	.globl _ak820_outline_0139
                                   2005 	.globl _ak820_outline_0144
                                   2006 	.globl _ak820_outline_0153
                                   2007 	.globl _ak820_outline_0161
                                   2008 	.globl _ak820_outline_0162
                                   2009 	.globl _ak820_outline_0165
                                   2010 
                                   2011 	.area CSEG (CODE)
                                   2012 ; function ak820_outline_0019
      007853                       2013 _ak820_outline_0019:
      007853 8E 82            [24] 2014 	mov	dpl,r6
      007855 8F 83            [24] 2015 	mov	dph,r7
      007857 A3               [24] 2016 	inc	dptr
      007858 E0               [24] 2017 	movx	a,@dptr
      007859 FC               [12] 2018 	mov	r4,a
      00785A 7D 00            [12] 2019 	mov	r5,#0x00
      00785C 8E 82            [24] 2020 	mov	dpl,r6
      00785E 8F 83            [24] 2021 	mov	dph,r7
      007860 E0               [24] 2022 	movx	a,@dptr
      007861 22               [24] 2023 	ret
                                   2024 
                                   2025 	.area CSEG (CODE)
                                   2026 ; function ak820_outline_0038
      007862                       2027 _ak820_outline_0038:
      007862 90 08 3A         [24] 2028 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007865 E0               [24] 2029 	movx	a,@dptr
      007866 54 1F            [12] 2030 	anl	a,#0x1f
      007868 F5 82            [12] 2031 	mov	dpl,a
      00786A 22               [24] 2032 	ret
                                   2033 
                                   2034 	.area CSEG (CODE)
                                   2035 ; function ak820_outline_0049
      00786B                       2036 _ak820_outline_0049:
      00786B A3               [24] 2037 	inc	dptr
      00786C F0               [24] 2038 	movx	@dptr,a
      00786D E4               [12] 2039 	clr	a
      00786E A3               [24] 2040 	inc	dptr
      00786F F0               [24] 2041 	movx	@dptr,a
      007870 90 0D 83         [24] 2042 	mov	dptr,#___memcpy_PARM_3
      007873 22               [24] 2043 	ret
                                   2044 
                                   2045 	.area CSEG (CODE)
                                   2046 ; function ak820_outline_0062
      007874                       2047 _ak820_outline_0062:
      007874 F5 F0            [12] 2048 	mov	b,a
      007876 05 F0            [12] 2049 	inc	b
      007878 74 01            [12] 2050 	mov	a,#0x01
      00787A 22               [24] 2051 	ret
                                   2052 
                                   2053 	.area CSEG (CODE)
                                   2054 ; function ak820_outline_0075
      00787B                       2055 _ak820_outline_0075:
      00787B 90 08 39         [24] 2056 	mov	dptr,#_process_action_PARM_2
      00787E E0               [24] 2057 	movx	a,@dptr
      00787F F5 82            [12] 2058 	mov	dpl,a
      007881 22               [24] 2059 	ret
                                   2060 
                                   2061 	.area CSEG (CODE)
                                   2062 ; function ak820_outline_0085
      007882                       2063 _ak820_outline_0085:
      007882 90 08 3A         [24] 2064 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007885 E0               [24] 2065 	movx	a,@dptr
      007886 03               [12] 2066 	rr	a
      007887 03               [12] 2067 	rr	a
      007888 54 03            [12] 2068 	anl	a,#0x03
      00788A 22               [24] 2069 	ret
                                   2070 
                                   2071 	.area CSEG (CODE)
                                   2072 ; function ak820_outline_0107
      00788B                       2073 _ak820_outline_0107:
      00788B 74 06            [12] 2074 	mov	a,#0x06
      00788D F0               [24] 2075 	movx	@dptr,a
      00788E E4               [12] 2076 	clr	a
      00788F A3               [24] 2077 	inc	dptr
      007890 F0               [24] 2078 	movx	@dptr,a
      007891 22               [24] 2079 	ret
                                   2080 
                                   2081 	.area CSEG (CODE)
                                   2082 ; function ak820_outline_0109
      007892                       2083 _ak820_outline_0109:
      007892 90 08 3A         [24] 2084 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007895 E0               [24] 2085 	movx	a,@dptr
      007896 54 0F            [12] 2086 	anl	a,#0x0f
      007898 22               [24] 2087 	ret
                                   2088 
                                   2089 	.area CSEG (CODE)
                                   2090 ; function ak820_outline_0128
      007899                       2091 _ak820_outline_0128:
      007899 90 08 39         [24] 2092 	mov	dptr,#_process_action_PARM_2
      00789C E0               [24] 2093 	movx	a,@dptr
      00789D FE               [12] 2094 	mov	r6,a
      00789E A3               [24] 2095 	inc	dptr
      00789F E0               [24] 2096 	movx	a,@dptr
      0078A0 54 03            [12] 2097 	anl	a,#0x03
      0078A2 FF               [12] 2098 	mov	r7,a
      0078A3 22               [24] 2099 	ret
                                   2100 
                                   2101 	.area CSEG (CODE)
                                   2102 ; function ak820_outline_0153
      0078A4                       2103 _ak820_outline_0153:
      0078A4 90 08 39         [24] 2104 	mov	dptr,#_process_action_PARM_2
      0078A7 E0               [24] 2105 	movx	a,@dptr
      0078A8 22               [24] 2106 	ret
                                   2107 
                                   2108 	.area CSEG (CODE)
                                   2109 ; function ak820_outline_0161
      0078A9                       2110 _ak820_outline_0161:
      0078A9 90 08 3E         [24] 2111 	mov	dptr,#_register_code_code_10000_714
      0078AC E0               [24] 2112 	movx	a,@dptr
      0078AD FF               [12] 2113 	mov	r7,a
      0078AE 22               [24] 2114 	ret
                                   2115 
                                   2116 	.area CSEG (CODE)
                                   2117 ; function ak820_outline_0162
      0078AF                       2118 _ak820_outline_0162:
      0078AF 90 08 3F         [24] 2119 	mov	dptr,#_unregister_code_code_10000_728
      0078B2 E0               [24] 2120 	movx	a,@dptr
      0078B3 FF               [12] 2121 	mov	r7,a
      0078B4 22               [24] 2122 	ret
