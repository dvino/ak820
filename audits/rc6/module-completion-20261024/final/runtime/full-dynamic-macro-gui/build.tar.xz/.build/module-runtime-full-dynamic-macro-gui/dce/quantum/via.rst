                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      000039                        553 _raw_hid_receive_sloc0_1_0:
      000039                        554 	.ds 4
      00003D                        555 _raw_hid_receive_sloc1_1_0:
      00003D                        556 	.ds 1
      00003E                        557 _raw_hid_receive_sloc2_1_0:
      00003E                        558 	.ds 1
      00003F                        559 _raw_hid_receive_sloc3_1_0:
      00003F                        560 	.ds 2
      000041                        561 _raw_hid_receive_sloc4_1_0:
      000041                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      00002B                        579 _via_eeprom_is_valid_sloc0_1_0:
      00002B                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000C6D                        589 _via_eeprom_set_valid_valid_10000_610:
      000C6D                        590 	.ds 1
      000C6E                        591 _via_set_layout_options_value_10000_626:
      000C6E                        592 	.ds 4
      000C72                        593 _process_record_via_PARM_2:
      000C72                        594 	.ds 3
      000C75                        595 _process_record_via_keycode_10000_628:
      000C75                        596 	.ds 2
      000C77                        597 _raw_hid_receive_kb_PARM_2:
      000C77                        598 	.ds 1
      000C78                        599 _raw_hid_receive_kb_data_10000_634:
      000C78                        600 	.ds 3
      000C7B                        601 _raw_hid_receive_PARM_2:
      000C7B                        602 	.ds 1
      000C7C                        603 _raw_hid_receive_packet_10000_636:
      000C7C                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00A7E8                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00A7E8 90 00 25         [24]  658 	mov	dptr,#0x0025
      00A7EB 75 F0 00         [24]  659 	mov	b, #0x00
      00A7EE 12 43 7D         [24]  660 	lcall	_eeprom_read_byte
      00A7F1 AF 82            [24]  661 	mov	r7, dpl
      00A7F3 BF 02 1E         [24]  662 	cjne	r7,#0x02,00103$
      00A7F6 90 00 26         [24]  663 	mov	dptr,#0x0026
      00A7F9 75 F0 00         [24]  664 	mov	b, #0x00
      00A7FC 12 43 7D         [24]  665 	lcall	_eeprom_read_byte
      00A7FF AF 82            [24]  666 	mov	r7, dpl
      00A801 BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00A804 90 00 27         [24]  668 	mov	dptr,#0x0027
      00A807 75 F0 00         [24]  669 	mov	b, #0x00
      00A80A 12 43 7D         [24]  670 	lcall	_eeprom_read_byte
      00A80D AF 82            [24]  671 	mov	r7, dpl
      00A80F BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00A812 80 04            [24]  673 	sjmp	00104$
      00A814                        674 00126$:
      00A814                        675 00103$:
                                    676 ;	assignBit
      00A814 C2 2B            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00A816 80 02            [24]  678 	sjmp	00105$
      00A818                        679 00104$:
                                    680 ;	assignBit
      00A818 D2 2B            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00A81A                        682 00105$:
      00A81A A2 2B            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00A81C 12 38 86         [24]  684 	lcall	_ak820_outline_0166
                                    685 ;	quantum/via.c:104: }
      00A81F 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_610'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_611'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_611'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_611'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00A820                        699 _via_eeprom_set_valid:
      00A820 E5 82            [12]  700 	mov	a,dpl
      00A822 90 0C 6D         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_610
      00A825 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00A826 E0               [24]  704 	movx	a,@dptr
      00A827 60 04            [24]  705 	jz	00103$
      00A829 7F 02            [12]  706 	mov	r7,#0x02
      00A82B 80 02            [24]  707 	sjmp	00104$
      00A82D                        708 00103$:
      00A82D 7F FF            [12]  709 	mov	r7,#0xff
      00A82F                        710 00104$:
      00A82F 90 06 ED         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A832 EF               [12]  712 	mov	a,r7
      00A833 F0               [24]  713 	movx	@dptr,a
      00A834 90 00 25         [24]  714 	mov	dptr,#0x0025
      00A837 75 F0 00         [24]  715 	mov	b, #0x00
      00A83A 12 51 00         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00A83D 90 0C 6D         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_610
      00A840 E0               [24]  719 	movx	a,@dptr
      00A841 60 04            [24]  720 	jz	00105$
      00A843 7F 20            [12]  721 	mov	r7,#0x20
      00A845 80 02            [24]  722 	sjmp	00106$
      00A847                        723 00105$:
      00A847 7F FF            [12]  724 	mov	r7,#0xff
      00A849                        725 00106$:
      00A849 90 06 ED         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A84C EF               [12]  727 	mov	a,r7
      00A84D F0               [24]  728 	movx	@dptr,a
      00A84E 90 00 26         [24]  729 	mov	dptr,#0x0026
      00A851 75 F0 00         [24]  730 	mov	b, #0x00
      00A854 12 51 00         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00A857 90 0C 6D         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_610
      00A85A E0               [24]  734 	movx	a,@dptr
      00A85B 60 04            [24]  735 	jz	00107$
      00A85D 7F 08            [12]  736 	mov	r7,#0x08
      00A85F 80 02            [24]  737 	sjmp	00108$
      00A861                        738 00107$:
      00A861 7F FF            [12]  739 	mov	r7,#0xff
      00A863                        740 00108$:
      00A863 90 06 ED         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A866 EF               [12]  742 	mov	a,r7
      00A867 F0               [24]  743 	movx	@dptr,a
      00A868 90 00 27         [24]  744 	mov	dptr,#0x0027
      00A86B 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00A86E 02 51 00         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00A871                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00A871 12 A8 9A         [24]  757 	lcall	_via_get_layout_options
      00A874 12 A8 B2         [24]  758 	lcall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00A877 12 A7 E8         [24]  760 	lcall	_via_eeprom_is_valid
      00A87A E5 82            [12]  761 	mov	a, dpl
      00A87C 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00A87E 02 41 2C         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00A881                        766 00103$:
      00A881 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00A882                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00A882 75 82 00         [24]  777 	mov	dpl, #0x00
      00A885 12 A8 20         [24]  778 	lcall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00A888 12 93 C2         [24]  780 	lcall	_ak820_outline_0148
      00A88B 12 A8 B3         [24]  781 	lcall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00A88E 12 8A 41         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00A891 12 8E B4         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00A894 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00A897 02 A8 20         [24]  789 	ljmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00A89A                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00A89A 90 00 28         [24]  799 	mov	dptr,#0x0028
      00A89D 75 F0 00         [24]  800 	mov	b, #0x00
      00A8A0 12 43 7D         [24]  801 	lcall	_eeprom_read_byte
      00A8A3 AF 82            [24]  802 	mov	r7, dpl
      00A8A5 7E 00            [12]  803 	mov	r6,#0x00
      00A8A7 7D 00            [12]  804 	mov	r5,#0x00
      00A8A9 7C 00            [12]  805 	mov	r4,#0x00
      00A8AB 12 46 83         [24]  806 	lcall	_ak820_outline_0153
      00A8AE 8D F0            [24]  807 	mov	b, r5
      00A8B0 EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00A8B1 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_623'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00A8B2                        820 _via_set_layout_options_kb:
      00A8B2 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_626'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00A8B3                        831 _via_set_layout_options:
      00A8B3 12 93 BA         [24]  832 	lcall	_ak820_outline_0115
      00A8B6 90 0C 6E         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_626
      00A8B9 12 93 A8         [24]  834 	lcall	_ak820_outline_0040
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00A8BC 90 0C 6E         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_626
      00A8BF E0               [24]  837 	movx	a,@dptr
      00A8C0 90 06 ED         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A8C3 F0               [24]  839 	movx	@dptr,a
      00A8C4 90 00 28         [24]  840 	mov	dptr,#0x0028
      00A8C7 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00A8CA 02 51 00         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_628'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_633'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00A8CD                        855 _process_record_via:
      00A8CD 12 38 4A         [24]  856 	lcall	_ak820_outline_0104
      00A8D0 90 0C 75         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_628
      00A8D3 12 38 4F         [24]  858 	lcall	_ak820_outline_0105
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00A8D6 90 0C 72         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00A8D9 12 52 0D         [24]  861 	lcall	_ak820_outline_0020
      00A8DC 74 05            [12]  862 	mov	a,#0x05
      00A8DE 12 38 7A         [24]  863 	lcall	_ak820_outline_0155
      00A8E1 12 52 16         [24]  864 	lcall	_ak820_outline_0044
      00A8E4 12 BB 5B         [24]  865 	lcall	__gptrget
      00A8E7 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00A8E9 90 0C 75         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_628
      00A8EC 12 37 CB         [24]  869 	lcall	_ak820_outline_0010
      00A8EF 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00A8F1 2D               [12]  871 	add	a,r5
      00A8F2 50 12            [24]  872 	jnc	00105$
      00A8F4 C3               [12]  873 	clr	c
      00A8F5 74 7F            [12]  874 	mov	a,#0x7f
      00A8F7 9C               [12]  875 	subb	a,r4
      00A8F8 74 77            [12]  876 	mov	a,#0x77
      00A8FA 9D               [12]  877 	subb	a,r5
      00A8FB 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00A8FD 8E 82            [24]  882 	mov	dpl, r6
      00A8FF 12 8E DA         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00A902 75 82 00         [24]  885 	mov	dpl, #0x00
      00A905 22               [24]  886 	ret
      00A906                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00A906 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00A909 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_634'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_635'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00A90A                        903 _raw_hid_receive_kb:
      00A90A 12 46 1B         [24]  904 	lcall	_ak820_outline_0036
      00A90D 90 0C 78         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_634
      00A910 12 37 DF         [24]  906 	lcall	_ak820_outline_0016
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00A913 90 0C 78         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_634
      00A916 12 51 FE         [24]  909 	lcall	_ak820_outline_0003
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00A919 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00A91B 02 BB 20         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_636'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_637'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_637'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_637'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_643'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_651'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_652'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_655'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_656'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_657'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_662'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_664'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_673'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_674'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_674'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_679'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_679'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_684'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_684'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_686'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_686'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_691'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00A91E                        950 _raw_hid_receive:
      00A91E 12 46 1B         [24]  951 	lcall	_ak820_outline_0036
      00A921 90 0C 7C         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_636
      00A924 12 37 DF         [24]  953 	lcall	_ak820_outline_0016
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00A927 90 0C 7C         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_636
      00A92A 12 38 00         [24]  956 	lcall	_ak820_outline_0051
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00A92D 74 01            [12]  958 	mov	a,#0x01
      00A92F 12 46 88         [24]  959 	lcall	_ak820_outline_0156
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00A932 90 0C 7B         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00A935 E0               [24]  962 	movx	a,@dptr
      00A936 FB               [12]  963 	mov	r3,a
      00A937 BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00A93A 80 01            [24]  965 	sjmp	00102$
      00A93C                        966 00520$:
      00A93C 22               [24]  967 	ret
      00A93D                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00A93D 90 0E 4A         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00A940 E0               [24]  971 	movx	a,@dptr
      00A941 60 31            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00A943 12 38 38         [24]  974 	lcall	_ak820_outline_0093
      00A946 FA               [12]  975 	mov	r2,a
      00A947 BA FE 02         [24]  976 	cjne	r2,#0xfe,00522$
      00A94A 80 01            [24]  977 	sjmp	00104$
      00A94C                        978 00522$:
                                    979 ;	quantum/via.c:252: return;
      00A94C 22               [24]  980 	ret
      00A94D                        981 00104$:
                                    982 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00A94D 12 46 45         [24]  983 	lcall	_ak820_outline_0092
                                    984 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00A950 FA               [12]  985 	mov	r2,a
      00A951 60 21            [24]  986 	jz	00114$
      00A953 BA 01 02         [24]  987 	cjne	r2,#0x01,00524$
      00A956 80 1C            [24]  988 	sjmp	00114$
      00A958                        989 00524$:
      00A958 BA 02 02         [24]  990 	cjne	r2,#0x02,00525$
      00A95B 80 17            [24]  991 	sjmp	00114$
      00A95D                        992 00525$:
      00A95D BA 05 02         [24]  993 	cjne	r2,#0x05,00526$
      00A960 80 12            [24]  994 	sjmp	00114$
      00A962                        995 00526$:
      00A962 BA 06 02         [24]  996 	cjne	r2,#0x06,00527$
      00A965 80 0D            [24]  997 	sjmp	00114$
      00A967                        998 00527$:
      00A967 BA 07 02         [24]  999 	cjne	r2,#0x07,00528$
      00A96A 80 08            [24] 1000 	sjmp	00114$
      00A96C                       1001 00528$:
      00A96C BA 08 02         [24] 1002 	cjne	r2,#0x08,00529$
      00A96F 80 03            [24] 1003 	sjmp	00530$
      00A971                       1004 00529$:
      00A971 02 AE AD         [24] 1005 	ljmp	00171$
      00A974                       1006 00530$:
                                   1007 ;	quantum/via.c:259: goto skip;
      00A974                       1008 00114$:
                                   1009 ;	quantum/via.c:263: switch (*command_id) {
      00A974 12 38 38         [24] 1010 	lcall	_ak820_outline_0093
      00A977 FA               [12] 1011 	mov	r2,a
      00A978 BA 01 02         [24] 1012 	cjne	r2,#0x01,00531$
      00A97B 80 6E            [24] 1013 	sjmp	00115$
      00A97D                       1014 00531$:
      00A97D BA 02 02         [24] 1015 	cjne	r2,#0x02,00532$
      00A980 80 76            [24] 1016 	sjmp	00116$
      00A982                       1017 00532$:
      00A982 BA 03 03         [24] 1018 	cjne	r2,#0x03,00533$
      00A985 02 AA BC         [24] 1019 	ljmp	00125$
      00A988                       1020 00533$:
      00A988 BA 04 03         [24] 1021 	cjne	r2,#0x04,00534$
      00A98B 02 AB 52         [24] 1022 	ljmp	00129$
      00A98E                       1023 00534$:
      00A98E BA 05 03         [24] 1024 	cjne	r2,#0x05,00535$
      00A991 02 AB 8D         [24] 1025 	ljmp	00130$
      00A994                       1026 00535$:
      00A994 BA 06 03         [24] 1027 	cjne	r2,#0x06,00536$
      00A997 02 AB F9         [24] 1028 	ljmp	00135$
      00A99A                       1029 00536$:
      00A99A BA 07 03         [24] 1030 	cjne	r2,#0x07,00537$
      00A99D 02 AC 0B         [24] 1031 	ljmp	00136$
      00A9A0                       1032 00537$:
      00A9A0 BA 08 03         [24] 1033 	cjne	r2,#0x08,00538$
      00A9A3 02 AC 26         [24] 1034 	ljmp	00137$
      00A9A6                       1035 00538$:
      00A9A6 BA 09 03         [24] 1036 	cjne	r2,#0x09,00539$
      00A9A9 02 AC 41         [24] 1037 	ljmp	00138$
      00A9AC                       1038 00539$:
      00A9AC BA 0B 03         [24] 1039 	cjne	r2,#0x0b,00540$
      00A9AF 02 AE 3B         [24] 1040 	ljmp	00161$
      00A9B2                       1041 00540$:
      00A9B2 BA 0C 03         [24] 1042 	cjne	r2,#0x0c,00541$
      00A9B5 02 AC 5C         [24] 1043 	ljmp	00139$
      00A9B8                       1044 00541$:
      00A9B8 BA 0D 03         [24] 1045 	cjne	r2,#0x0d,00542$
      00A9BB 02 AC 7D         [24] 1046 	ljmp	00140$
      00A9BE                       1047 00542$:
      00A9BE BA 0E 03         [24] 1048 	cjne	r2,#0x0e,00543$
      00A9C1 02 AC A6         [24] 1049 	ljmp	00141$
      00A9C4                       1050 00543$:
      00A9C4 BA 0F 03         [24] 1051 	cjne	r2,#0x0f,00544$
      00A9C7 02 AC EE         [24] 1052 	ljmp	00144$
      00A9CA                       1053 00544$:
      00A9CA BA 10 03         [24] 1054 	cjne	r2,#0x10,00545$
      00A9CD 02 AD 5D         [24] 1055 	ljmp	00151$
      00A9D0                       1056 00545$:
      00A9D0 BA 11 03         [24] 1057 	cjne	r2,#0x11,00546$
      00A9D3 02 AD 76         [24] 1058 	ljmp	00154$
      00A9D6                       1059 00546$:
      00A9D6 BA 12 03         [24] 1060 	cjne	r2,#0x12,00547$
      00A9D9 02 AD 97         [24] 1061 	ljmp	00155$
      00A9DC                       1062 00547$:
      00A9DC BA 13 03         [24] 1063 	cjne	r2,#0x13,00548$
      00A9DF 02 AD DF         [24] 1064 	ljmp	00158$
      00A9E2                       1065 00548$:
      00A9E2 BA FE 03         [24] 1066 	cjne	r2,#0xfe,00549$
      00A9E5 02 AE 7B         [24] 1067 	ljmp	00168$
      00A9E8                       1068 00549$:
      00A9E8 02 AE 95         [24] 1069 	ljmp	00169$
                                   1070 ;	quantum/via.c:264: case id_get_protocol_version: {
      00A9EB                       1071 00115$:
                                   1072 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00A9EB 12 38 60         [24] 1073 	lcall	_ak820_outline_0121
      00A9EE E4               [12] 1074 	clr	a
      00A9EF 12 46 13         [24] 1075 	lcall	_ak820_outline_0029
                                   1076 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00A9F2 74 09            [12] 1077 	mov	a,#0x09
      00A9F4 F0               [24] 1078 	movx	@dptr,a
                                   1079 ;	quantum/via.c:267: break;
      00A9F5 02 AE AD         [24] 1080 	ljmp	00171$
                                   1081 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00A9F8                       1082 00116$:
                                   1083 ;	quantum/via.c:270: switch (command_data[0]) {
      00A9F8 12 46 45         [24] 1084 	lcall	_ak820_outline_0092
      00A9FB FA               [12] 1085 	mov	r2,a
      00A9FC BA 01 02         [24] 1086 	cjne	r2,#0x01,00550$
      00A9FF 80 0E            [24] 1087 	sjmp	00117$
      00AA01                       1088 00550$:
      00AA01 BA 02 02         [24] 1089 	cjne	r2,#0x02,00551$
      00AA04 80 35            [24] 1090 	sjmp	00118$
      00AA06                       1091 00551$:
      00AA06 BA 03 03         [24] 1092 	cjne	r2,#0x03,00552$
      00AA09 02 AA 77         [24] 1093 	ljmp	00119$
      00AA0C                       1094 00552$:
      00AA0C 02 AA A1         [24] 1095 	ljmp	00123$
                                   1096 ;	quantum/via.c:271: case id_uptime: {
      00AA0F                       1097 00117$:
                                   1098 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00AA0F 12 4C 0C         [24] 1099 	lcall	_timer_read32
      00AA12 85 82 39         [24] 1100 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AA15 85 83 3A         [24] 1101 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AA18 85 F0 3B         [24] 1102 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AA1B F5 3C            [12] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1104 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00AA1D 12 46 5D         [24] 1105 	lcall	_ak820_outline_0116
      00AA20 A3               [24] 1106 	inc	dptr
      00AA21 A3               [24] 1107 	inc	dptr
      00AA22 E5 3C            [12] 1108 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AA24 12 46 13         [24] 1109 	lcall	_ak820_outline_0029
                                   1110 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00AA27 A3               [24] 1111 	inc	dptr
      00AA28 E5 3B            [12] 1112 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AA2A F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00AA2B 12 46 0A         [24] 1115 	lcall	_ak820_outline_0013
      00AA2E E5 3A            [12] 1116 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AA30 F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00AA31 12 46 0A         [24] 1119 	lcall	_ak820_outline_0013
      00AA34 A3               [24] 1120 	inc	dptr
      00AA35 E5 39            [12] 1121 	mov	a,_raw_hid_receive_sloc0_1_0
      00AA37 F0               [24] 1122 	movx	@dptr,a
                                   1123 ;	quantum/via.c:277: break;
      00AA38 02 AE AD         [24] 1124 	ljmp	00171$
                                   1125 ;	quantum/via.c:279: case id_layout_options: {
      00AA3B                       1126 00118$:
                                   1127 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00AA3B C0 03            [24] 1128 	push	ar3
      00AA3D C0 07            [24] 1129 	push	ar7
      00AA3F C0 06            [24] 1130 	push	ar6
      00AA41 C0 03            [24] 1131 	push	ar3
      00AA43 12 A8 9A         [24] 1132 	lcall	_via_get_layout_options
      00AA46 85 82 39         [24] 1133 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AA49 85 83 3A         [24] 1134 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AA4C 85 F0 3B         [24] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AA4F F5 3C            [12] 1136 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AA51 D0 03            [24] 1137 	pop	ar3
      00AA53 D0 06            [24] 1138 	pop	ar6
      00AA55 D0 07            [24] 1139 	pop	ar7
                                   1140 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00AA57 12 46 5D         [24] 1141 	lcall	_ak820_outline_0116
      00AA5A A3               [24] 1142 	inc	dptr
      00AA5B A3               [24] 1143 	inc	dptr
      00AA5C E5 3C            [12] 1144 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AA5E 12 46 13         [24] 1145 	lcall	_ak820_outline_0029
                                   1146 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00AA61 A3               [24] 1147 	inc	dptr
      00AA62 E5 3B            [12] 1148 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AA64 F0               [24] 1149 	movx	@dptr,a
                                   1150 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00AA65 12 46 0A         [24] 1151 	lcall	_ak820_outline_0013
      00AA68 E5 3A            [12] 1152 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AA6A F0               [24] 1153 	movx	@dptr,a
                                   1154 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00AA6B 12 46 0A         [24] 1155 	lcall	_ak820_outline_0013
      00AA6E A3               [24] 1156 	inc	dptr
      00AA6F E5 39            [12] 1157 	mov	a,_raw_hid_receive_sloc0_1_0
      00AA71 F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	quantum/via.c:285: break;
      00AA72 D0 03            [24] 1160 	pop	ar3
      00AA74 02 AE AD         [24] 1161 	ljmp	00171$
                                   1162 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00AA77                       1163 00119$:
                                   1164 ;	quantum/via.c:290: if (!vial_unlocked)
      00AA77 90 0E 49         [24] 1165 	mov	dptr,#_vial_unlocked
      00AA7A E0               [24] 1166 	movx	a,@dptr
      00AA7B 70 03            [24] 1167 	jnz	00553$
      00AA7D 02 AE AD         [24] 1168 	ljmp	00171$
      00AA80                       1169 00553$:
                                   1170 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AA80 7A 01            [12] 1171 	mov	r2,#0x01
      00AA82 79 00            [12] 1172 	mov	r1,#0x00
      00AA84                       1173 00173$:
      00AA84 B9 10 00         [24] 1174 	cjne	r1,#0x10,00554$
      00AA87                       1175 00554$:
      00AA87 40 03            [24] 1176 	jc	00555$
      00AA89 02 AE AD         [24] 1177 	ljmp	00171$
      00AA8C                       1178 00555$:
                                   1179 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00AA8C 89 82            [24] 1180 	mov	dpl, r1
      00AA8E 12 5C A1         [24] 1181 	lcall	_matrix_get_row
      00AA91 A8 82            [24] 1182 	mov	r0, dpl
                                   1183 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00AA93 EA               [12] 1184 	mov	a,r2
      00AA94 2C               [12] 1185 	add	a, r4
      00AA95 F5 82            [12] 1186 	mov	dpl,a
      00AA97 E4               [12] 1187 	clr	a
      00AA98 3D               [12] 1188 	addc	a, r5
      00AA99 F5 83            [12] 1189 	mov	dph,a
      00AA9B 0A               [12] 1190 	inc	r2
      00AA9C E8               [12] 1191 	mov	a,r0
      00AA9D F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AA9E 09               [12] 1194 	inc	r1
                                   1195 ;	quantum/via.c:312: default: {
      00AA9F 80 E3            [24] 1196 	sjmp	00173$
      00AAA1                       1197 00123$:
                                   1198 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00AAA1 12 AF 00         [24] 1199 	lcall	_ak820_outline_0090
      00AAA4 90 0C 77         [24] 1200 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AAA7 12 AE DB         [24] 1201 	lcall	_ak820_outline_0037
      00AAAA C0 07            [24] 1202 	push	ar7
      00AAAC C0 06            [24] 1203 	push	ar6
      00AAAE C0 03            [24] 1204 	push	ar3
      00AAB0 12 A9 0A         [24] 1205 	lcall	_raw_hid_receive_kb
      00AAB3 D0 03            [24] 1206 	pop	ar3
      00AAB5 D0 06            [24] 1207 	pop	ar6
      00AAB7 D0 07            [24] 1208 	pop	ar7
                                   1209 ;	quantum/via.c:317: break;
      00AAB9 02 AE AD         [24] 1210 	ljmp	00171$
                                   1211 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00AABC                       1212 00125$:
                                   1213 ;	quantum/via.c:320: switch (command_data[0]) {
      00AABC 12 46 45         [24] 1214 	lcall	_ak820_outline_0092
      00AABF FA               [12] 1215 	mov	r2,a
      00AAC0 BA 02 02         [24] 1216 	cjne	r2,#0x02,00556$
      00AAC3 80 03            [24] 1217 	sjmp	00557$
      00AAC5                       1218 00556$:
      00AAC5 02 AB 37         [24] 1219 	ljmp	00127$
      00AAC8                       1220 00557$:
                                   1221 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00AAC8 C0 03            [24] 1222 	push	ar3
      00AACA 12 37 F8         [24] 1223 	lcall	_ak820_outline_0033
      00AACD F8               [12] 1224 	mov	r0,a
      00AACE 79 00            [12] 1225 	mov	r1,#0x00
      00AAD0 7B 00            [12] 1226 	mov	r3,#0x00
      00AAD2 88 3C            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00AAD4 8B 39            [24] 1228 	mov	_raw_hid_receive_sloc0_1_0,r3
      00AAD6 8B 3A            [24] 1229 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00AAD8 8B 3B            [24] 1230 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00AADA 12 AE D2         [24] 1231 	lcall	_ak820_outline_0015
      00AADD F8               [12] 1232 	mov	r0,a
      00AADE 89 03            [24] 1233 	mov	ar3,r1
      00AAE0 88 02            [24] 1234 	mov	ar2,r0
      00AAE2 E4               [12] 1235 	clr	a
      00AAE3 42 39            [12] 1236 	orl	_raw_hid_receive_sloc0_1_0,a
      00AAE5 E9               [12] 1237 	mov	a,r1
      00AAE6 42 3A            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AAE8 EA               [12] 1239 	mov	a,r2
      00AAE9 42 3B            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AAEB EB               [12] 1241 	mov	a,r3
      00AAEC 42 3C            [12] 1242 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AAEE 12 46 0A         [24] 1243 	lcall	_ak820_outline_0013
      00AAF1 E0               [24] 1244 	movx	a,@dptr
      00AAF2 F8               [12] 1245 	mov	r0,a
      00AAF3 79 00            [12] 1246 	mov	r1,#0x00
      00AAF5 7A 00            [12] 1247 	mov	r2,#0x00
      00AAF7 8A 03            [24] 1248 	mov	ar3,r2
      00AAF9 89 02            [24] 1249 	mov	ar2,r1
      00AAFB 88 01            [24] 1250 	mov	ar1,r0
      00AAFD E4               [12] 1251 	clr	a
      00AAFE 42 39            [12] 1252 	orl	_raw_hid_receive_sloc0_1_0,a
      00AB00 E9               [12] 1253 	mov	a,r1
      00AB01 42 3A            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AB03 EA               [12] 1255 	mov	a,r2
      00AB04 42 3B            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AB06 EB               [12] 1257 	mov	a,r3
      00AB07 42 3C            [12] 1258 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AB09 12 4B 3A         [24] 1259 	lcall	_ak820_outline_0008
      00AB0C F8               [12] 1260 	mov	r0,a
      00AB0D E4               [12] 1261 	clr	a
      00AB0E F9               [12] 1262 	mov	r1,a
      00AB0F FA               [12] 1263 	mov	r2,a
      00AB10 FB               [12] 1264 	mov	r3,a
      00AB11 E5 3A            [12] 1265 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AB13 42 01            [12] 1266 	orl	ar1,a
      00AB15 E5 3B            [12] 1267 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AB17 42 02            [12] 1268 	orl	ar2,a
      00AB19 E5 3C            [12] 1269 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AB1B 42 03            [12] 1270 	orl	ar3,a
                                   1271 ;	quantum/via.c:323: via_set_layout_options(value);
      00AB1D 12 38 75         [24] 1272 	lcall	_ak820_outline_0152
      00AB20 8A F0            [24] 1273 	mov	b, r2
      00AB22 EB               [12] 1274 	mov	a, r3
      00AB23 C0 07            [24] 1275 	push	ar7
      00AB25 C0 06            [24] 1276 	push	ar6
      00AB27 C0 03            [24] 1277 	push	ar3
      00AB29 12 A8 B3         [24] 1278 	lcall	_via_set_layout_options
      00AB2C D0 03            [24] 1279 	pop	ar3
      00AB2E D0 06            [24] 1280 	pop	ar6
      00AB30 D0 07            [24] 1281 	pop	ar7
                                   1282 ;	quantum/via.c:324: break;
      00AB32 D0 03            [24] 1283 	pop	ar3
      00AB34 02 AE AD         [24] 1284 	ljmp	00171$
                                   1285 ;	quantum/via.c:326: default: {
      00AB37                       1286 00127$:
                                   1287 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00AB37 12 AF 00         [24] 1288 	lcall	_ak820_outline_0090
      00AB3A 90 0C 77         [24] 1289 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AB3D 12 AE DB         [24] 1290 	lcall	_ak820_outline_0037
      00AB40 C0 07            [24] 1291 	push	ar7
      00AB42 C0 06            [24] 1292 	push	ar6
      00AB44 C0 03            [24] 1293 	push	ar3
      00AB46 12 A9 0A         [24] 1294 	lcall	_raw_hid_receive_kb
      00AB49 D0 03            [24] 1295 	pop	ar3
      00AB4B D0 06            [24] 1296 	pop	ar6
      00AB4D D0 07            [24] 1297 	pop	ar7
                                   1298 ;	quantum/via.c:331: break;
      00AB4F 02 AE AD         [24] 1299 	ljmp	00171$
                                   1300 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00AB52                       1301 00129$:
                                   1302 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00AB52 12 46 45         [24] 1303 	lcall	_ak820_outline_0092
      00AB55 FA               [12] 1304 	mov	r2,a
      00AB56 12 37 F8         [24] 1305 	lcall	_ak820_outline_0033
      00AB59 F9               [12] 1306 	mov	r1,a
      00AB5A 12 AE D2         [24] 1307 	lcall	_ak820_outline_0015
      00AB5D F8               [12] 1308 	mov	r0,a
      00AB5E 90 0B 2A         [24] 1309 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00AB61 E9               [12] 1310 	mov	a,r1
      00AB62 F0               [24] 1311 	movx	@dptr,a
      00AB63 90 0B 2B         [24] 1312 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00AB66 E8               [12] 1313 	mov	a,r0
      00AB67 F0               [24] 1314 	movx	@dptr,a
      00AB68 8A 82            [24] 1315 	mov	dpl, r2
      00AB6A C0 07            [24] 1316 	push	ar7
      00AB6C C0 06            [24] 1317 	push	ar6
      00AB6E C0 03            [24] 1318 	push	ar3
      00AB70 12 87 60         [24] 1319 	lcall	_dynamic_keymap_get_keycode
      00AB73 A9 82            [24] 1320 	mov	r1, dpl
      00AB75 AA 83            [24] 1321 	mov	r2, dph
      00AB77 D0 03            [24] 1322 	pop	ar3
      00AB79 D0 06            [24] 1323 	pop	ar6
      00AB7B D0 07            [24] 1324 	pop	ar7
                                   1325 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00AB7D 12 46 0A         [24] 1326 	lcall	_ak820_outline_0013
      00AB80 8A 00            [24] 1327 	mov	ar0,r2
      00AB82 E8               [12] 1328 	mov	a,r0
      00AB83 F0               [24] 1329 	movx	@dptr,a
                                   1330 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00AB84 12 46 0A         [24] 1331 	lcall	_ak820_outline_0013
      00AB87 A3               [24] 1332 	inc	dptr
      00AB88 E9               [12] 1333 	mov	a,r1
      00AB89 F0               [24] 1334 	movx	@dptr,a
                                   1335 ;	quantum/via.c:337: break;
      00AB8A 02 AE AD         [24] 1336 	ljmp	00171$
                                   1337 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00AB8D                       1338 00130$:
                                   1339 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00AB8D 90 0E 49         [24] 1340 	mov	dptr,#_vial_unlocked
      00AB90 E0               [24] 1341 	movx	a,@dptr
      00AB91 70 19            [24] 1342 	jnz	00132$
      00AB93 12 46 0A         [24] 1343 	lcall	_ak820_outline_0013
      00AB96 E0               [24] 1344 	movx	a,@dptr
      00AB97 FA               [12] 1345 	mov	r2,a
      00AB98 BA 7C 11         [24] 1346 	cjne	r2,#0x7c,00132$
      00AB9B 74 05            [12] 1347 	mov	a,#0x05
      00AB9D 2E               [12] 1348 	add	a, r6
      00AB9E 12 37 D5         [24] 1349 	lcall	_ak820_outline_0014
      00ABA1 70 09            [24] 1350 	jnz	00132$
                                   1351 ;	quantum/via.c:344: *command_id = id_unhandled;
      00ABA3 12 46 5D         [24] 1352 	lcall	_ak820_outline_0116
      00ABA6 74 FF            [12] 1353 	mov	a,#0xff
      00ABA8 F0               [24] 1354 	movx	@dptr,a
                                   1355 ;	quantum/via.c:345: break;
      00ABA9 02 AE AD         [24] 1356 	ljmp	00171$
      00ABAC                       1357 00132$:
                                   1358 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00ABAC C0 03            [24] 1359 	push	ar3
      00ABAE 12 46 45         [24] 1360 	lcall	_ak820_outline_0092
      00ABB1 F5 3E            [12] 1361 	mov	_raw_hid_receive_sloc2_1_0,a
      00ABB3 12 37 F8         [24] 1362 	lcall	_ak820_outline_0033
      00ABB6 F5 3D            [12] 1363 	mov	_raw_hid_receive_sloc1_1_0,a
      00ABB8 12 AE D2         [24] 1364 	lcall	_ak820_outline_0015
      00ABBB F5 39            [12] 1365 	mov	_raw_hid_receive_sloc0_1_0,a
      00ABBD 12 46 0A         [24] 1366 	lcall	_ak820_outline_0013
      00ABC0 E0               [24] 1367 	movx	a,@dptr
      00ABC1 FB               [12] 1368 	mov	r3,a
      00ABC2 78 00            [12] 1369 	mov	r0,#0x00
      00ABC4 12 4B 3A         [24] 1370 	lcall	_ak820_outline_0008
      00ABC7 7A 00            [12] 1371 	mov	r2,#0x00
      00ABC9 42 00            [12] 1372 	orl	ar0,a
      00ABCB EA               [12] 1373 	mov	a,r2
      00ABCC 42 03            [12] 1374 	orl	ar3,a
      00ABCE 90 0B 2D         [24] 1375 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00ABD1 E5 3D            [12] 1376 	mov	a,_raw_hid_receive_sloc1_1_0
      00ABD3 F0               [24] 1377 	movx	@dptr,a
      00ABD4 90 0B 2E         [24] 1378 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00ABD7 E5 39            [12] 1379 	mov	a,_raw_hid_receive_sloc0_1_0
      00ABD9 F0               [24] 1380 	movx	@dptr,a
      00ABDA 90 0B 2F         [24] 1381 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00ABDD E8               [12] 1382 	mov	a,r0
      00ABDE F0               [24] 1383 	movx	@dptr,a
      00ABDF EB               [12] 1384 	mov	a,r3
      00ABE0 A3               [24] 1385 	inc	dptr
      00ABE1 F0               [24] 1386 	movx	@dptr,a
      00ABE2 85 3E 82         [24] 1387 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00ABE5 C0 07            [24] 1388 	push	ar7
      00ABE7 C0 06            [24] 1389 	push	ar6
      00ABE9 C0 03            [24] 1390 	push	ar3
      00ABEB 12 87 AE         [24] 1391 	lcall	_dynamic_keymap_set_keycode
      00ABEE D0 03            [24] 1392 	pop	ar3
      00ABF0 D0 06            [24] 1393 	pop	ar6
      00ABF2 D0 07            [24] 1394 	pop	ar7
                                   1395 ;	quantum/via.c:349: break;
      00ABF4 D0 03            [24] 1396 	pop	ar3
      00ABF6 02 AE AD         [24] 1397 	ljmp	00171$
                                   1398 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00ABF9                       1399 00135$:
                                   1400 ;	quantum/via.c:352: dynamic_keymap_reset();
      00ABF9 C0 07            [24] 1401 	push	ar7
      00ABFB C0 06            [24] 1402 	push	ar6
      00ABFD C0 03            [24] 1403 	push	ar3
      00ABFF 12 8A 41         [24] 1404 	lcall	_dynamic_keymap_reset
      00AC02 D0 03            [24] 1405 	pop	ar3
      00AC04 D0 06            [24] 1406 	pop	ar6
      00AC06 D0 07            [24] 1407 	pop	ar7
                                   1408 ;	quantum/via.c:353: break;
      00AC08 02 AE AD         [24] 1409 	ljmp	00171$
                                   1410 ;	quantum/via.c:355: case id_lighting_set_value: {
      00AC0B                       1411 00136$:
                                   1412 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00AC0B 12 AF 00         [24] 1413 	lcall	_ak820_outline_0090
      00AC0E 90 0D C2         [24] 1414 	mov	dptr,#_vialrgb_set_value_PARM_2
      00AC11 12 AE DB         [24] 1415 	lcall	_ak820_outline_0037
      00AC14 C0 07            [24] 1416 	push	ar7
      00AC16 C0 06            [24] 1417 	push	ar6
      00AC18 C0 03            [24] 1418 	push	ar3
      00AC1A 12 B8 F7         [24] 1419 	lcall	_vialrgb_set_value
      00AC1D D0 03            [24] 1420 	pop	ar3
      00AC1F D0 06            [24] 1421 	pop	ar6
      00AC21 D0 07            [24] 1422 	pop	ar7
                                   1423 ;	quantum/via.c:375: break;
      00AC23 02 AE AD         [24] 1424 	ljmp	00171$
                                   1425 ;	quantum/via.c:377: case id_lighting_get_value: {
      00AC26                       1426 00137$:
                                   1427 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00AC26 12 AF 00         [24] 1428 	lcall	_ak820_outline_0090
      00AC29 90 0D BE         [24] 1429 	mov	dptr,#_vialrgb_get_value_PARM_2
      00AC2C 12 AE DB         [24] 1430 	lcall	_ak820_outline_0037
      00AC2F C0 07            [24] 1431 	push	ar7
      00AC31 C0 06            [24] 1432 	push	ar6
      00AC33 C0 03            [24] 1433 	push	ar3
      00AC35 12 B7 8B         [24] 1434 	lcall	_vialrgb_get_value
      00AC38 D0 03            [24] 1435 	pop	ar3
      00AC3A D0 06            [24] 1436 	pop	ar6
      00AC3C D0 07            [24] 1437 	pop	ar7
                                   1438 ;	quantum/via.c:397: break;
      00AC3E 02 AE AD         [24] 1439 	ljmp	00171$
                                   1440 ;	quantum/via.c:399: case id_lighting_save: {
      00AC41                       1441 00138$:
                                   1442 ;	quantum/via.c:407: vialrgb_save(data, length);
      00AC41 12 AF 00         [24] 1443 	lcall	_ak820_outline_0090
      00AC44 90 0D C6         [24] 1444 	mov	dptr,#_vialrgb_save_PARM_2
      00AC47 12 AE DB         [24] 1445 	lcall	_ak820_outline_0037
      00AC4A C0 07            [24] 1446 	push	ar7
      00AC4C C0 06            [24] 1447 	push	ar6
      00AC4E C0 03            [24] 1448 	push	ar3
      00AC50 12 B9 84         [24] 1449 	lcall	_vialrgb_save
      00AC53 D0 03            [24] 1450 	pop	ar3
      00AC55 D0 06            [24] 1451 	pop	ar6
      00AC57 D0 07            [24] 1452 	pop	ar7
                                   1453 ;	quantum/via.c:419: break;
      00AC59 02 AE AD         [24] 1454 	ljmp	00171$
                                   1455 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00AC5C                       1456 00139$:
                                   1457 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00AC5C C0 07            [24] 1458 	push	ar7
      00AC5E C0 06            [24] 1459 	push	ar6
      00AC60 C0 05            [24] 1460 	push	ar5
      00AC62 C0 04            [24] 1461 	push	ar4
      00AC64 C0 03            [24] 1462 	push	ar3
      00AC66 12 8E 2F         [24] 1463 	lcall	_dynamic_keymap_macro_get_count
      00AC69 AA 82            [24] 1464 	mov	r2, dpl
      00AC6B D0 03            [24] 1465 	pop	ar3
      00AC6D D0 04            [24] 1466 	pop	ar4
      00AC6F D0 05            [24] 1467 	pop	ar5
      00AC71 D0 06            [24] 1468 	pop	ar6
      00AC73 D0 07            [24] 1469 	pop	ar7
      00AC75 12 38 60         [24] 1470 	lcall	_ak820_outline_0121
      00AC78 EA               [12] 1471 	mov	a,r2
      00AC79 F0               [24] 1472 	movx	@dptr,a
                                   1473 ;	quantum/via.c:430: break;
      00AC7A 02 AE AD         [24] 1474 	ljmp	00171$
                                   1475 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00AC7D                       1476 00140$:
                                   1477 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00AC7D C0 07            [24] 1478 	push	ar7
      00AC7F C0 06            [24] 1479 	push	ar6
      00AC81 C0 05            [24] 1480 	push	ar5
      00AC83 C0 04            [24] 1481 	push	ar4
      00AC85 C0 03            [24] 1482 	push	ar3
      00AC87 12 8E 33         [24] 1483 	lcall	_dynamic_keymap_macro_get_buffer_size
      00AC8A A9 82            [24] 1484 	mov	r1, dpl
      00AC8C AA 83            [24] 1485 	mov	r2, dph
      00AC8E D0 03            [24] 1486 	pop	ar3
      00AC90 D0 04            [24] 1487 	pop	ar4
      00AC92 D0 05            [24] 1488 	pop	ar5
      00AC94 D0 06            [24] 1489 	pop	ar6
      00AC96 D0 07            [24] 1490 	pop	ar7
                                   1491 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00AC98 8A 00            [24] 1492 	mov	ar0,r2
      00AC9A 12 38 60         [24] 1493 	lcall	_ak820_outline_0121
      00AC9D E8               [12] 1494 	mov	a,r0
      00AC9E 12 46 13         [24] 1495 	lcall	_ak820_outline_0029
                                   1496 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00ACA1 E9               [12] 1497 	mov	a,r1
      00ACA2 F0               [24] 1498 	movx	@dptr,a
                                   1499 ;	quantum/via.c:436: break;
      00ACA3 02 AE AD         [24] 1500 	ljmp	00171$
                                   1501 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00ACA6                       1502 00141$:
                                   1503 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00ACA6 C0 03            [24] 1504 	push	ar3
      00ACA8 12 AE BB         [24] 1505 	lcall	_ak820_outline_0001
      00ACAB 89 39            [24] 1506 	mov	_raw_hid_receive_sloc0_1_0,r1
      00ACAD 8A 3A            [24] 1507 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1508 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00ACAF 12 AE D2         [24] 1509 	lcall	_ak820_outline_0015
      00ACB2 FB               [12] 1510 	mov	r3,a
                                   1511 ;	quantum/via.c:441: if (size <= 28)
      00ACB3 8B 3F            [24] 1512 	mov	_raw_hid_receive_sloc3_1_0,r3
      00ACB5 75 40 00         [24] 1513 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00ACB8 C3               [12] 1514 	clr	c
      00ACB9 74 1C            [12] 1515 	mov	a,#0x1c
      00ACBB 9B               [12] 1516 	subb	a,r3
      00ACBC D0 03            [24] 1517 	pop	ar3
      00ACBE 50 03            [24] 1518 	jnc	00562$
      00ACC0 02 AE AD         [24] 1519 	ljmp	00171$
      00ACC3                       1520 00562$:
                                   1521 ;	free result
                                   1522 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00ACC3 12 AE E4         [24] 1523 	lcall	_ak820_outline_0068
      00ACC6 90 0B 7C         [24] 1524 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00ACC9 E5 3F            [12] 1525 	mov	a,_raw_hid_receive_sloc3_1_0
      00ACCB F0               [24] 1526 	movx	@dptr,a
      00ACCC E5 40            [12] 1527 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00ACCE A3               [24] 1528 	inc	dptr
      00ACCF F0               [24] 1529 	movx	@dptr,a
      00ACD0 90 0B 7E         [24] 1530 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00ACD3 12 AE EE         [24] 1531 	lcall	_ak820_outline_0083
      00ACD6 85 39 82         [24] 1532 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00ACD9 85 3A 83         [24] 1533 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00ACDC C0 07            [24] 1534 	push	ar7
      00ACDE C0 06            [24] 1535 	push	ar6
      00ACE0 C0 03            [24] 1536 	push	ar3
      00ACE2 12 8E 37         [24] 1537 	lcall	_dynamic_keymap_macro_get_buffer
      00ACE5 D0 03            [24] 1538 	pop	ar3
      00ACE7 D0 06            [24] 1539 	pop	ar6
      00ACE9 D0 07            [24] 1540 	pop	ar7
                                   1541 ;	quantum/via.c:443: break;
      00ACEB 02 AE AD         [24] 1542 	ljmp	00171$
                                   1543 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00ACEE                       1544 00144$:
                                   1545 ;	quantum/via.c:448: if (!vial_unlocked) {
      00ACEE 90 0E 49         [24] 1546 	mov	dptr,#_vial_unlocked
      00ACF1 E0               [24] 1547 	movx	a,@dptr
      00ACF2 70 01            [24] 1548 	jnz	00146$
                                   1549 ;	quantum/via.c:450: return;
      00ACF4 22               [24] 1550 	ret
      00ACF5                       1551 00146$:
                                   1552 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00ACF5 C0 03            [24] 1553 	push	ar3
      00ACF7 12 AE BB         [24] 1554 	lcall	_ak820_outline_0001
      00ACFA 89 3F            [24] 1555 	mov	_raw_hid_receive_sloc3_1_0,r1
      00ACFC 8A 40            [24] 1556 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1557 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00ACFE 12 AE D2         [24] 1558 	lcall	_ak820_outline_0015
      00AD01 F5 39            [12] 1559 	mov	_raw_hid_receive_sloc0_1_0, a
      00AD03 75 3A 00         [24] 1560 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1561 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00AD06 85 39 41         [24] 1562 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00AD09 85 3A 42         [24] 1563 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00AD0C C3               [12] 1564 	clr	c
      00AD0D 74 1C            [12] 1565 	mov	a,#0x1c
      00AD0F 95 41            [12] 1566 	subb	a,_raw_hid_receive_sloc4_1_0
      00AD11 E4               [12] 1567 	clr	a
      00AD12 95 42            [12] 1568 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AD14 D0 03            [24] 1569 	pop	ar3
      00AD16 40 44            [24] 1570 	jc	00147$
                                   1571 ;	free result
      00AD18 8B 01            [24] 1572 	mov	ar1,r3
      00AD1A 7A 00            [12] 1573 	mov	r2,#0x00
      00AD1C E9               [12] 1574 	mov	a,r1
      00AD1D 24 FC            [12] 1575 	add	a,#0xfc
      00AD1F F9               [12] 1576 	mov	r1,a
      00AD20 EA               [12] 1577 	mov	a,r2
      00AD21 34 FF            [12] 1578 	addc	a,#0xff
      00AD23 FA               [12] 1579 	mov	r2,a
      00AD24 C3               [12] 1580 	clr	c
      00AD25 E9               [12] 1581 	mov	a,r1
      00AD26 95 41            [12] 1582 	subb	a,_raw_hid_receive_sloc4_1_0
      00AD28 EA               [12] 1583 	mov	a,r2
      00AD29 95 42            [12] 1584 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AD2B 40 2F            [24] 1585 	jc	00147$
                                   1586 ;	free result
      00AD2D 12 AE E4         [24] 1587 	lcall	_ak820_outline_0068
      00AD30 90 0B 83         [24] 1588 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00AD33 E5 39            [12] 1589 	mov	a,_raw_hid_receive_sloc0_1_0
      00AD35 F0               [24] 1590 	movx	@dptr,a
      00AD36 E5 3A            [12] 1591 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AD38 A3               [24] 1592 	inc	dptr
      00AD39 F0               [24] 1593 	movx	@dptr,a
      00AD3A 90 0B 85         [24] 1594 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00AD3D 12 AE EE         [24] 1595 	lcall	_ak820_outline_0083
      00AD40 85 3F 82         [24] 1596 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00AD43 85 40 83         [24] 1597 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00AD46 C0 07            [24] 1598 	push	ar7
      00AD48 C0 06            [24] 1599 	push	ar6
      00AD4A C0 03            [24] 1600 	push	ar3
      00AD4C 12 8E 86         [24] 1601 	lcall	_dynamic_keymap_macro_set_buffer
      00AD4F E5 82            [12] 1602 	mov	a, dpl
      00AD51 D0 03            [24] 1603 	pop	ar3
      00AD53 D0 06            [24] 1604 	pop	ar6
      00AD55 D0 07            [24] 1605 	pop	ar7
      00AD57 60 03            [24] 1606 	jz	00566$
      00AD59 02 AE AD         [24] 1607 	ljmp	00171$
      00AD5C                       1608 00566$:
      00AD5C                       1609 00147$:
      00AD5C 22               [24] 1610 	ret
                                   1611 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00AD5D                       1612 00151$:
                                   1613 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00AD5D 90 0E 49         [24] 1614 	mov	dptr,#_vial_unlocked
      00AD60 E0               [24] 1615 	movx	a,@dptr
      00AD61 70 01            [24] 1616 	jnz	00153$
      00AD63 22               [24] 1617 	ret
      00AD64                       1618 00153$:
                                   1619 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00AD64 C0 07            [24] 1620 	push	ar7
      00AD66 C0 06            [24] 1621 	push	ar6
      00AD68 C0 03            [24] 1622 	push	ar3
      00AD6A 12 8E B4         [24] 1623 	lcall	_dynamic_keymap_macro_reset
      00AD6D D0 03            [24] 1624 	pop	ar3
      00AD6F D0 06            [24] 1625 	pop	ar6
      00AD71 D0 07            [24] 1626 	pop	ar7
                                   1627 ;	quantum/via.c:473: break;
      00AD73 02 AE AD         [24] 1628 	ljmp	00171$
                                   1629 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00AD76                       1630 00154$:
                                   1631 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00AD76 C0 07            [24] 1632 	push	ar7
      00AD78 C0 06            [24] 1633 	push	ar6
      00AD7A C0 05            [24] 1634 	push	ar5
      00AD7C C0 04            [24] 1635 	push	ar4
      00AD7E C0 03            [24] 1636 	push	ar3
      00AD80 12 87 25         [24] 1637 	lcall	_dynamic_keymap_get_layer_count
      00AD83 AA 82            [24] 1638 	mov	r2, dpl
      00AD85 D0 03            [24] 1639 	pop	ar3
      00AD87 D0 04            [24] 1640 	pop	ar4
      00AD89 D0 05            [24] 1641 	pop	ar5
      00AD8B D0 06            [24] 1642 	pop	ar6
      00AD8D D0 07            [24] 1643 	pop	ar7
      00AD8F 12 38 60         [24] 1644 	lcall	_ak820_outline_0121
      00AD92 EA               [12] 1645 	mov	a,r2
      00AD93 F0               [24] 1646 	movx	@dptr,a
                                   1647 ;	quantum/via.c:477: break;
      00AD94 02 AE AD         [24] 1648 	ljmp	00171$
                                   1649 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00AD97                       1650 00155$:
                                   1651 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AD97 C0 03            [24] 1652 	push	ar3
      00AD99 12 AE BB         [24] 1653 	lcall	_ak820_outline_0001
      00AD9C 89 41            [24] 1654 	mov	_raw_hid_receive_sloc4_1_0,r1
      00AD9E 8A 42            [24] 1655 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1656 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00ADA0 12 AE D2         [24] 1657 	lcall	_ak820_outline_0015
      00ADA3 FB               [12] 1658 	mov	r3,a
                                   1659 ;	quantum/via.c:482: if (size <= 28)
      00ADA4 8B 3F            [24] 1660 	mov	_raw_hid_receive_sloc3_1_0,r3
      00ADA6 75 40 00         [24] 1661 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00ADA9 C3               [12] 1662 	clr	c
      00ADAA 74 1C            [12] 1663 	mov	a,#0x1c
      00ADAC 9B               [12] 1664 	subb	a,r3
      00ADAD D0 03            [24] 1665 	pop	ar3
      00ADAF 50 03            [24] 1666 	jnc	00568$
      00ADB1 02 AE AD         [24] 1667 	ljmp	00171$
      00ADB4                       1668 00568$:
                                   1669 ;	free result
                                   1670 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00ADB4 12 AE E4         [24] 1671 	lcall	_ak820_outline_0068
      00ADB7 90 0B 65         [24] 1672 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00ADBA E5 3F            [12] 1673 	mov	a,_raw_hid_receive_sloc3_1_0
      00ADBC F0               [24] 1674 	movx	@dptr,a
      00ADBD E5 40            [12] 1675 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00ADBF A3               [24] 1676 	inc	dptr
      00ADC0 F0               [24] 1677 	movx	@dptr,a
      00ADC1 90 0B 67         [24] 1678 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00ADC4 12 AE EE         [24] 1679 	lcall	_ak820_outline_0083
      00ADC7 85 41 82         [24] 1680 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00ADCA 85 42 83         [24] 1681 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00ADCD C0 07            [24] 1682 	push	ar7
      00ADCF C0 06            [24] 1683 	push	ar6
      00ADD1 C0 03            [24] 1684 	push	ar3
      00ADD3 12 8B FE         [24] 1685 	lcall	_dynamic_keymap_get_buffer
      00ADD6 D0 03            [24] 1686 	pop	ar3
      00ADD8 D0 06            [24] 1687 	pop	ar6
      00ADDA D0 07            [24] 1688 	pop	ar7
                                   1689 ;	quantum/via.c:484: break;
      00ADDC 02 AE AD         [24] 1690 	ljmp	00171$
                                   1691 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00ADDF                       1692 00158$:
                                   1693 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00ADDF 12 46 45         [24] 1694 	lcall	_ak820_outline_0092
      00ADE2 FD               [12] 1695 	mov	r5,a
      00ADE3 7C 00            [12] 1696 	mov	r4,#0x00
      00ADE5 12 37 F8         [24] 1697 	lcall	_ak820_outline_0033
      00ADE8 7A 00            [12] 1698 	mov	r2,#0x00
      00ADEA 42 04            [12] 1699 	orl	ar4,a
      00ADEC EA               [12] 1700 	mov	a,r2
      00ADED 42 05            [12] 1701 	orl	ar5,a
      00ADEF 8C 41            [24] 1702 	mov	_raw_hid_receive_sloc4_1_0,r4
      00ADF1 8D 42            [24] 1703 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1704 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00ADF3 12 AE D2         [24] 1705 	lcall	_ak820_outline_0015
      00ADF6 F9               [12] 1706 	mov	r1,a
      00ADF7 7A 00            [12] 1707 	mov	r2,#0x00
                                   1708 ;	quantum/via.c:489: if (size <= 28)
      00ADF9 89 00            [24] 1709 	mov	ar0,r1
      00ADFB E8               [12] 1710 	mov	a,r0
      00ADFC 24 E3            [12] 1711 	add	a,#0xff - 0x1c
      00ADFE 50 03            [24] 1712 	jnc	00569$
      00AE00 02 AE AD         [24] 1713 	ljmp	00171$
      00AE03                       1714 00569$:
                                   1715 ;	free result
                                   1716 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00AE03 C0 03            [24] 1717 	push	ar3
      00AE05 74 04            [12] 1718 	mov	a,#0x04
      00AE07 2E               [12] 1719 	add	a, r6
      00AE08 F8               [12] 1720 	mov	r0,a
      00AE09 E4               [12] 1721 	clr	a
      00AE0A 3F               [12] 1722 	addc	a, r7
      00AE0B FB               [12] 1723 	mov	r3,a
      00AE0C 7D 00            [12] 1724 	mov	r5,#0x00
      00AE0E 90 0B 6C         [24] 1725 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00AE11 E9               [12] 1726 	mov	a,r1
      00AE12 F0               [24] 1727 	movx	@dptr,a
      00AE13 EA               [12] 1728 	mov	a,r2
      00AE14 A3               [24] 1729 	inc	dptr
      00AE15 F0               [24] 1730 	movx	@dptr,a
      00AE16 90 0B 6E         [24] 1731 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00AE19 E8               [12] 1732 	mov	a,r0
      00AE1A F0               [24] 1733 	movx	@dptr,a
      00AE1B EB               [12] 1734 	mov	a,r3
      00AE1C A3               [24] 1735 	inc	dptr
      00AE1D F0               [24] 1736 	movx	@dptr,a
      00AE1E ED               [12] 1737 	mov	a,r5
      00AE1F A3               [24] 1738 	inc	dptr
      00AE20 F0               [24] 1739 	movx	@dptr,a
      00AE21 85 41 82         [24] 1740 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AE24 85 42 83         [24] 1741 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AE27 C0 07            [24] 1742 	push	ar7
      00AE29 C0 06            [24] 1743 	push	ar6
      00AE2B C0 03            [24] 1744 	push	ar3
      00AE2D 12 8C 3C         [24] 1745 	lcall	_dynamic_keymap_set_buffer
      00AE30 D0 03            [24] 1746 	pop	ar3
      00AE32 D0 06            [24] 1747 	pop	ar6
      00AE34 D0 07            [24] 1748 	pop	ar7
                                   1749 ;	quantum/via.c:491: break;
      00AE36 D0 03            [24] 1750 	pop	ar3
      00AE38 02 AE AD         [24] 1751 	ljmp	00171$
                                   1752 ;	quantum/via.c:495: case id_bootloader_jump: {
      00AE3B                       1753 00161$:
                                   1754 ;	quantum/via.c:497: if (!vial_unlocked)
      00AE3B 90 0E 49         [24] 1755 	mov	dptr,#_vial_unlocked
      00AE3E E0               [24] 1756 	movx	a,@dptr
      00AE3F 70 03            [24] 1757 	jnz	00570$
      00AE41 02 AE AD         [24] 1758 	ljmp	00171$
      00AE44                       1759 00570$:
                                   1760 ;	quantum/via.c:501: raw_hid_send(data, length);
      00AE44 12 AF 07         [24] 1761 	lcall	_ak820_outline_0146
      00AE47 90 06 C7         [24] 1762 	mov	dptr,#_raw_hid_send_PARM_2
      00AE4A 12 AE F7         [24] 1763 	lcall	_ak820_outline_0084
      00AE4D C0 07            [24] 1764 	push	ar7
      00AE4F C0 06            [24] 1765 	push	ar6
      00AE51 C0 03            [24] 1766 	push	ar3
      00AE53 12 4E 14         [24] 1767 	lcall	_raw_hid_send
      00AE56 D0 03            [24] 1768 	pop	ar3
      00AE58 D0 06            [24] 1769 	pop	ar6
      00AE5A D0 07            [24] 1770 	pop	ar7
                                   1771 ;	quantum/via.c:503: wait_ms(100);
      00AE5C 7D 64            [12] 1772 	mov	r5,#0x64
      00AE5E                       1773 00176$:
      00AE5E ED               [12] 1774 	mov	a,r5
      00AE5F 60 09            [24] 1775 	jz	00166$
      00AE61 90 00 01         [24] 1776 	mov	dptr,#0x0001
      00AE64 12 5B E0         [24] 1777 	lcall	_mDelaymS
      00AE67 1D               [12] 1778 	dec	r5
      00AE68 80 F4            [24] 1779 	sjmp	00176$
      00AE6A                       1780 00166$:
                                   1781 ;	quantum/via.c:504: bootloader_jump();
      00AE6A C0 07            [24] 1782 	push	ar7
      00AE6C C0 06            [24] 1783 	push	ar6
      00AE6E C0 03            [24] 1784 	push	ar3
      00AE70 12 34 0E         [24] 1785 	lcall	_bootloader_jump
      00AE73 D0 03            [24] 1786 	pop	ar3
      00AE75 D0 06            [24] 1787 	pop	ar6
      00AE77 D0 07            [24] 1788 	pop	ar7
                                   1789 ;	quantum/via.c:505: break;
                                   1790 ;	quantum/via.c:509: case id_vial_prefix: {
      00AE79 80 32            [24] 1791 	sjmp	00171$
      00AE7B                       1792 00168$:
                                   1793 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00AE7B 12 AF 07         [24] 1794 	lcall	_ak820_outline_0146
      00AE7E 90 0C 89         [24] 1795 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AE81 12 AE F7         [24] 1796 	lcall	_ak820_outline_0084
      00AE84 C0 07            [24] 1797 	push	ar7
      00AE86 C0 06            [24] 1798 	push	ar6
      00AE88 C0 03            [24] 1799 	push	ar3
      00AE8A 12 AF F4         [24] 1800 	lcall	_vial_handle_cmd
      00AE8D D0 03            [24] 1801 	pop	ar3
      00AE8F D0 06            [24] 1802 	pop	ar6
      00AE91 D0 07            [24] 1803 	pop	ar7
                                   1804 ;	quantum/via.c:511: break;
                                   1805 ;	quantum/via.c:514: default: {
      00AE93 80 18            [24] 1806 	sjmp	00171$
      00AE95                       1807 00169$:
                                   1808 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00AE95 12 AF 07         [24] 1809 	lcall	_ak820_outline_0146
      00AE98 90 0C 77         [24] 1810 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AE9B 12 AE F7         [24] 1811 	lcall	_ak820_outline_0084
      00AE9E C0 07            [24] 1812 	push	ar7
      00AEA0 C0 06            [24] 1813 	push	ar6
      00AEA2 C0 03            [24] 1814 	push	ar3
      00AEA4 12 A9 0A         [24] 1815 	lcall	_raw_hid_receive_kb
      00AEA7 D0 03            [24] 1816 	pop	ar3
      00AEA9 D0 06            [24] 1817 	pop	ar6
      00AEAB D0 07            [24] 1818 	pop	ar7
                                   1819 ;	quantum/via.c:521: skip:
      00AEAD                       1820 00171$:
                                   1821 ;	quantum/via.c:525: raw_hid_send(data, length);
      00AEAD 7D 00            [12] 1822 	mov	r5,#0x00
      00AEAF 90 06 C7         [24] 1823 	mov	dptr,#_raw_hid_send_PARM_2
      00AEB2 EB               [12] 1824 	mov	a,r3
      00AEB3 12 46 3F         [24] 1825 	lcall	_ak820_outline_0060
      00AEB6 8D F0            [24] 1826 	mov	b, r5
                                   1827 ;	quantum/via.c:526: }
      00AEB8 02 4E 14         [24] 1828 	ljmp	_raw_hid_send
                                   1829 	.area CSEG    (CODE)
                                   1830 	.area CONST   (CODE)
                                   1831 	.area XINIT   (CODE)
                                   1832 	.area CABS    (ABS,CODE)
                                   1833 
                                   1834 ; Experimental exact instruction outlining.
                                   1835 	.globl _ak820_outline_0001
                                   1836 	.globl _ak820_outline_0003
                                   1837 	.globl _ak820_outline_0008
                                   1838 	.globl _ak820_outline_0010
                                   1839 	.globl _ak820_outline_0013
                                   1840 	.globl _ak820_outline_0014
                                   1841 	.globl _ak820_outline_0015
                                   1842 	.globl _ak820_outline_0016
                                   1843 	.globl _ak820_outline_0020
                                   1844 	.globl _ak820_outline_0029
                                   1845 	.globl _ak820_outline_0033
                                   1846 	.globl _ak820_outline_0036
                                   1847 	.globl _ak820_outline_0037
                                   1848 	.globl _ak820_outline_0040
                                   1849 	.globl _ak820_outline_0044
                                   1850 	.globl _ak820_outline_0051
                                   1851 	.globl _ak820_outline_0060
                                   1852 	.globl _ak820_outline_0068
                                   1853 	.globl _ak820_outline_0083
                                   1854 	.globl _ak820_outline_0084
                                   1855 	.globl _ak820_outline_0090
                                   1856 	.globl _ak820_outline_0092
                                   1857 	.globl _ak820_outline_0093
                                   1858 	.globl _ak820_outline_0104
                                   1859 	.globl _ak820_outline_0105
                                   1860 	.globl _ak820_outline_0115
                                   1861 	.globl _ak820_outline_0116
                                   1862 	.globl _ak820_outline_0121
                                   1863 	.globl _ak820_outline_0146
                                   1864 	.globl _ak820_outline_0148
                                   1865 	.globl _ak820_outline_0152
                                   1866 	.globl _ak820_outline_0153
                                   1867 	.globl _ak820_outline_0155
                                   1868 	.globl _ak820_outline_0156
                                   1869 	.globl _ak820_outline_0166
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0001
      00AEBB                       1873 _ak820_outline_0001:
      00AEBB 8C 82            [24] 1874 	mov	dpl,r4
      00AEBD 8D 83            [24] 1875 	mov	dph,r5
      00AEBF E0               [24] 1876 	movx	a,@dptr
      00AEC0 FA               [12] 1877 	mov	r2,a
      00AEC1 79 00            [12] 1878 	mov	r1,#0x00
      00AEC3 8E 82            [24] 1879 	mov	dpl,r6
      00AEC5 8F 83            [24] 1880 	mov	dph,r7
      00AEC7 A3               [24] 1881 	inc	dptr
      00AEC8 A3               [24] 1882 	inc	dptr
      00AEC9 E0               [24] 1883 	movx	a,@dptr
      00AECA 7B 00            [12] 1884 	mov	r3,#0x00
      00AECC 42 01            [12] 1885 	orl	ar1,a
      00AECE EB               [12] 1886 	mov	a,r3
      00AECF 42 02            [12] 1887 	orl	ar2,a
      00AED1 22               [24] 1888 	ret
                                   1889 
                                   1890 	.area CSEG (CODE)
                                   1891 ; function ak820_outline_0015
      00AED2                       1892 _ak820_outline_0015:
      00AED2 8E 82            [24] 1893 	mov	dpl,r6
      00AED4 8F 83            [24] 1894 	mov	dph,r7
      00AED6 A3               [24] 1895 	inc	dptr
      00AED7 A3               [24] 1896 	inc	dptr
      00AED8 A3               [24] 1897 	inc	dptr
      00AED9 E0               [24] 1898 	movx	a,@dptr
      00AEDA 22               [24] 1899 	ret
                                   1900 
                                   1901 	.area CSEG (CODE)
                                   1902 ; function ak820_outline_0037
      00AEDB                       1903 _ak820_outline_0037:
      00AEDB EB               [12] 1904 	mov	a,r3
      00AEDC F0               [24] 1905 	movx	@dptr,a
      00AEDD 88 82            [24] 1906 	mov	dpl,r0
      00AEDF 89 83            [24] 1907 	mov	dph,r1
      00AEE1 8A F0            [24] 1908 	mov	b,r2
      00AEE3 22               [24] 1909 	ret
                                   1910 
                                   1911 	.area CSEG (CODE)
                                   1912 ; function ak820_outline_0068
      00AEE4                       1913 _ak820_outline_0068:
      00AEE4 74 04            [12] 1914 	mov	a,#0x04
      00AEE6 2E               [12] 1915 	add	a,r6
      00AEE7 F9               [12] 1916 	mov	r1,a
      00AEE8 E4               [12] 1917 	clr	a
      00AEE9 3F               [12] 1918 	addc	a,r7
      00AEEA F8               [12] 1919 	mov	r0,a
      00AEEB 7A 00            [12] 1920 	mov	r2,#0x00
      00AEED 22               [24] 1921 	ret
                                   1922 
                                   1923 	.area CSEG (CODE)
                                   1924 ; function ak820_outline_0083
      00AEEE                       1925 _ak820_outline_0083:
      00AEEE E9               [12] 1926 	mov	a,r1
      00AEEF F0               [24] 1927 	movx	@dptr,a
      00AEF0 E8               [12] 1928 	mov	a,r0
      00AEF1 A3               [24] 1929 	inc	dptr
      00AEF2 F0               [24] 1930 	movx	@dptr,a
      00AEF3 EA               [12] 1931 	mov	a,r2
      00AEF4 A3               [24] 1932 	inc	dptr
      00AEF5 F0               [24] 1933 	movx	@dptr,a
      00AEF6 22               [24] 1934 	ret
                                   1935 
                                   1936 	.area CSEG (CODE)
                                   1937 ; function ak820_outline_0084
      00AEF7                       1938 _ak820_outline_0084:
      00AEF7 EB               [12] 1939 	mov	a,r3
      00AEF8 F0               [24] 1940 	movx	@dptr,a
      00AEF9 8A 82            [24] 1941 	mov	dpl,r2
      00AEFB 8C 83            [24] 1942 	mov	dph,r4
      00AEFD 8D F0            [24] 1943 	mov	b,r5
      00AEFF 22               [24] 1944 	ret
                                   1945 
                                   1946 	.area CSEG (CODE)
                                   1947 ; function ak820_outline_0090
      00AF00                       1948 _ak820_outline_0090:
      00AF00 8E 00            [24] 1949 	mov	ar0,r6
      00AF02 8F 01            [24] 1950 	mov	ar1,r7
      00AF04 7A 00            [12] 1951 	mov	r2,#0x00
      00AF06 22               [24] 1952 	ret
                                   1953 
                                   1954 	.area CSEG (CODE)
                                   1955 ; function ak820_outline_0146
      00AF07                       1956 _ak820_outline_0146:
      00AF07 8E 02            [24] 1957 	mov	ar2,r6
      00AF09 8F 04            [24] 1958 	mov	ar4,r7
      00AF0B 7D 00            [12] 1959 	mov	r5,#0x00
      00AF0D 22               [24] 1960 	ret
