                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_dynamic_macro_cancel
                                     21 	.globl _ak820_dynamic_macro_task
                                     22 	.globl _ak820_dynamic_macro_observe
                                     23 	.globl _ak820_dynamic_macro_process
                                     24 	.globl _pre_process_record_quantum
                                     25 	.globl _get_record_keycode
                                     26 	.globl _get_repeat_key_count
                                     27 	.globl _repeat_key_cancel
                                     28 	.globl _clear_owned_usages
                                     29 	.globl _owned_usage_key
                                     30 	.globl _clear_owned_keys
                                     31 	.globl _del_owned_key
                                     32 	.globl _add_owned_key
                                     33 	.globl _clear_owned_mods
                                     34 	.globl _del_owned_weak_mods
                                     35 	.globl _add_owned_weak_mods
                                     36 	.globl _del_owned_mods
                                     37 	.globl _add_owned_mods
                                     38 	.globl _clear_weak_mods
                                     39 	.globl _clear_mods
                                     40 	.globl _send_keyboard_report
                                     41 	.globl _layer_hold_clear
                                     42 	.globl _layer_hold_off
                                     43 	.globl _layer_hold_on
                                     44 	.globl _ak820_resolve_key
                                     45 	.globl _layer_xor
                                     46 	.globl _layer_and
                                     47 	.globl _layer_or
                                     48 	.globl _layer_off
                                     49 	.globl _layer_on
                                     50 	.globl _layer_move
                                     51 	.globl _layer_clear
                                     52 	.globl _layer_state_set
                                     53 	.globl _default_layer_xor
                                     54 	.globl _default_layer_and
                                     55 	.globl _default_layer_or
                                     56 	.globl _default_layer_set
                                     57 	.globl _process_record_quantum
                                     58 	.globl _action_for_keycode
                                     59 	.globl _mDelaymS
                                     60 	.globl _host_consumer_send
                                     61 	.globl _host_system_send
                                     62 	.globl _host_keyboard_leds
                                     63 	.globl _led_set
                                     64 	.globl _clear_keys_from_report
                                     65 	.globl ___memcpy
                                     66 	.globl _ADC_START
                                     67 	.globl _S0_R_FIFO
                                     68 	.globl _S0_T_FIFO
                                     69 	.globl _S0_FREE
                                     70 	.globl _S0_IF_BYTE
                                     71 	.globl _S0_IF_FIRST
                                     72 	.globl _S0_IF_OV
                                     73 	.globl _S0_FST_ACT
                                     74 	.globl _CP_RL2
                                     75 	.globl _C_T2
                                     76 	.globl _TR2
                                     77 	.globl _EXEN2
                                     78 	.globl _TCLK
                                     79 	.globl _RCLK
                                     80 	.globl _EXF2
                                     81 	.globl _CAP1F
                                     82 	.globl _TF2
                                     83 	.globl _RI
                                     84 	.globl _TI
                                     85 	.globl _RB8
                                     86 	.globl _TB8
                                     87 	.globl _REN
                                     88 	.globl _SM2
                                     89 	.globl _SM1
                                     90 	.globl _SM0
                                     91 	.globl _IT0
                                     92 	.globl _IE0
                                     93 	.globl _IT1
                                     94 	.globl _IE1
                                     95 	.globl _TR0
                                     96 	.globl _TF0
                                     97 	.globl _TR1
                                     98 	.globl _TF1
                                     99 	.globl _P4_0
                                    100 	.globl _P4_1
                                    101 	.globl _P4_2
                                    102 	.globl _P4_3
                                    103 	.globl _P4_4
                                    104 	.globl _P4_5
                                    105 	.globl _P4_6
                                    106 	.globl _RXD
                                    107 	.globl _TXD
                                    108 	.globl _INT0
                                    109 	.globl _INT1
                                    110 	.globl _T0
                                    111 	.globl _T1
                                    112 	.globl _MOSI1
                                    113 	.globl _MISO1
                                    114 	.globl _SCK1
                                    115 	.globl _P3_0
                                    116 	.globl _P3_1
                                    117 	.globl _P3_2
                                    118 	.globl _P3_3
                                    119 	.globl _P3_4
                                    120 	.globl _P3_5
                                    121 	.globl _P3_6
                                    122 	.globl _P3_7
                                    123 	.globl _CAP1_
                                    124 	.globl _T2_
                                    125 	.globl _CAP2_
                                    126 	.globl _T2EX_
                                    127 	.globl _RXD1
                                    128 	.globl _TXD1
                                    129 	.globl _P2_0
                                    130 	.globl _P2_1
                                    131 	.globl _P2_2
                                    132 	.globl _P2_3
                                    133 	.globl _P2_4
                                    134 	.globl _P2_5
                                    135 	.globl _P2_6
                                    136 	.globl _P2_7
                                    137 	.globl _AIN0
                                    138 	.globl _AIN1
                                    139 	.globl _AIN2
                                    140 	.globl _AIN3
                                    141 	.globl _AIN4
                                    142 	.globl _AIN5
                                    143 	.globl _AIN6
                                    144 	.globl _AIN7
                                    145 	.globl _CAP1
                                    146 	.globl _T2
                                    147 	.globl _CAP2
                                    148 	.globl _T2EX
                                    149 	.globl _INT0_
                                    150 	.globl _SCS
                                    151 	.globl _MOSI
                                    152 	.globl _MISO
                                    153 	.globl _SCK
                                    154 	.globl _RXD1_
                                    155 	.globl _TXD1_
                                    156 	.globl _P1_0
                                    157 	.globl _P1_1
                                    158 	.globl _P1_2
                                    159 	.globl _P1_3
                                    160 	.globl _P1_4
                                    161 	.globl _P1_5
                                    162 	.globl _P1_6
                                    163 	.globl _P1_7
                                    164 	.globl _AIN8
                                    165 	.globl _AIN9
                                    166 	.globl _AIN10
                                    167 	.globl _AIN11
                                    168 	.globl _AIN12
                                    169 	.globl _AIN13
                                    170 	.globl _RXD_
                                    171 	.globl _TXD_
                                    172 	.globl _SCL0
                                    173 	.globl _SDA0
                                    174 	.globl _P0_0
                                    175 	.globl _P0_1
                                    176 	.globl _P0_2
                                    177 	.globl _P0_3
                                    178 	.globl _P0_4
                                    179 	.globl _P0_5
                                    180 	.globl _P0_6
                                    181 	.globl _P0_7
                                    182 	.globl _IE_SPI0
                                    183 	.globl _IE_USB
                                    184 	.globl _IE_ADC
                                    185 	.globl _IE_UART1
                                    186 	.globl _IE_PWM_I2C
                                    187 	.globl _IE_GPIO
                                    188 	.globl _IE_WDOG
                                    189 	.globl _PX0
                                    190 	.globl _PT0
                                    191 	.globl _PX1
                                    192 	.globl _PT1
                                    193 	.globl _PS
                                    194 	.globl _PT2
                                    195 	.globl _PL_FLAG
                                    196 	.globl _PH_FLAG
                                    197 	.globl _EX0
                                    198 	.globl _ET0
                                    199 	.globl _EX1
                                    200 	.globl _ET1
                                    201 	.globl _ES
                                    202 	.globl _ET2
                                    203 	.globl _E_DIS
                                    204 	.globl _EA
                                    205 	.globl _P
                                    206 	.globl _F1
                                    207 	.globl _OV
                                    208 	.globl _RS0
                                    209 	.globl _RS1
                                    210 	.globl _F0
                                    211 	.globl _AC
                                    212 	.globl _CY
                                    213 	.globl _I2CS_INT_ST
                                    214 	.globl _I2CX_INT
                                    215 	.globl _LED_STATUS
                                    216 	.globl _LED_DMA_H
                                    217 	.globl _LED_DMA_L
                                    218 	.globl _LED_DMA
                                    219 	.globl _LED_PWM_OE
                                    220 	.globl _LED_COMMON
                                    221 	.globl _ADC_CHAN
                                    222 	.globl _ADC_DAT_H
                                    223 	.globl _ADC_DAT_L
                                    224 	.globl _ADC_DAT
                                    225 	.globl _ADC_CTRL
                                    226 	.globl _SPI1_CK_SE
                                    227 	.globl _SPI1_CTRL
                                    228 	.globl _SPI1_DATA
                                    229 	.globl _SPI1_STAT
                                    230 	.globl _SIF1
                                    231 	.globl _SBAUD1
                                    232 	.globl _SBUF1
                                    233 	.globl _SCON1
                                    234 	.globl _SPI0_SETUP
                                    235 	.globl _SPI0_CK_SE
                                    236 	.globl _SPI0_CTRL
                                    237 	.globl _SPI0_DATA
                                    238 	.globl _SPI0_STAT
                                    239 	.globl _T2CAP1H
                                    240 	.globl _T2CAP1L
                                    241 	.globl _T2CAP1
                                    242 	.globl _TH2
                                    243 	.globl _TL2
                                    244 	.globl _T2COUNT
                                    245 	.globl _RCAP2H
                                    246 	.globl _RCAP2L
                                    247 	.globl _RCAP2
                                    248 	.globl _T2MOD
                                    249 	.globl _T2CON
                                    250 	.globl _SBUF
                                    251 	.globl _SCON
                                    252 	.globl _TH1
                                    253 	.globl _TH0
                                    254 	.globl _TL1
                                    255 	.globl _TL0
                                    256 	.globl _TMOD
                                    257 	.globl _TCON
                                    258 	.globl _XBUS_AUX
                                    259 	.globl _P7
                                    260 	.globl _P6_DIR
                                    261 	.globl _P6_OUT_PU
                                    262 	.globl _P6_IN
                                    263 	.globl _P5_DIR
                                    264 	.globl _P5_OUT_PU
                                    265 	.globl _P5_IN
                                    266 	.globl _P4_LED_KEY
                                    267 	.globl _P4_DIR_PU
                                    268 	.globl _P4_MOD_OC
                                    269 	.globl _P4
                                    270 	.globl _P3_DIR_PU
                                    271 	.globl _P3_MOD_OC
                                    272 	.globl _P3
                                    273 	.globl _P2_DIR_PU
                                    274 	.globl _P2_MOD_OC
                                    275 	.globl _P2
                                    276 	.globl _P1_DIR_PU
                                    277 	.globl _P1_MOD_OC
                                    278 	.globl _P1
                                    279 	.globl _P0_DIR_PU
                                    280 	.globl _P0_MOD_OC
                                    281 	.globl _P0
                                    282 	.globl _ROM_CTRL
                                    283 	.globl _ROM_DATA_HH
                                    284 	.globl _ROM_DATA_HL
                                    285 	.globl _ROM_DATA_HI
                                    286 	.globl _ROM_ADDR_H
                                    287 	.globl _ROM_ADDR_L
                                    288 	.globl _ROM_ADDR
                                    289 	.globl _GPIO_IE
                                    290 	.globl _IP_EX
                                    291 	.globl _IE_EX
                                    292 	.globl _IP
                                    293 	.globl _IE
                                    294 	.globl _WDOG_COUNT
                                    295 	.globl _RESET_KEEP
                                    296 	.globl _WAKE_CTRL
                                    297 	.globl _CLOCK_CFG
                                    298 	.globl _POWER_CFG
                                    299 	.globl _PCON
                                    300 	.globl _GLOBAL_CFG
                                    301 	.globl _SAFE_MOD
                                    302 	.globl _DPH
                                    303 	.globl _DPL
                                    304 	.globl _SP
                                    305 	.globl _A_INV
                                    306 	.globl _B
                                    307 	.globl _ACC
                                    308 	.globl _PSW
                                    309 	.globl _disable_action_cache
                                    310 	.globl _tap_code_delay_PARM_2
                                    311 	.globl _process_action_PARM_2
                                    312 	.globl _action_exec_PARM_1
                                    313 	.globl _tp_buttons
                                    314 	.globl _action_exec
                                    315 	.globl _ak820_action_exec
                                    316 	.globl _process_record
                                    317 	.globl _process_record_handler
                                    318 	.globl _process_action
                                    319 	.globl _register_code
                                    320 	.globl _unregister_code
                                    321 	.globl _tap_code_delay
                                    322 	.globl _tap_code
                                    323 	.globl _register_mods
                                    324 	.globl _unregister_mods
                                    325 	.globl _register_weak_mods
                                    326 	.globl _unregister_weak_mods
                                    327 	.globl _clear_keyboard
                                    328 	.globl _clear_keyboard_but_mods
                                    329 	.globl _clear_keyboard_but_mods_and_keys
                                    330 ;--------------------------------------------------------
                                    331 ; special function registers
                                    332 ;--------------------------------------------------------
                                    333 	.area RSEG    (ABS,DATA)
      000000                        334 	.org 0x0000
                           0000D0   335 _PSW	=	0x00d0
                           0000E0   336 _ACC	=	0x00e0
                           0000F0   337 _B	=	0x00f0
                           0000FD   338 _A_INV	=	0x00fd
                           000081   339 _SP	=	0x0081
                           000082   340 _DPL	=	0x0082
                           000083   341 _DPH	=	0x0083
                           0000A1   342 _SAFE_MOD	=	0x00a1
                           0000B1   343 _GLOBAL_CFG	=	0x00b1
                           000087   344 _PCON	=	0x0087
                           0000BA   345 _POWER_CFG	=	0x00ba
                           0000B9   346 _CLOCK_CFG	=	0x00b9
                           0000A9   347 _WAKE_CTRL	=	0x00a9
                           0000FE   348 _RESET_KEEP	=	0x00fe
                           0000FF   349 _WDOG_COUNT	=	0x00ff
                           0000A8   350 _IE	=	0x00a8
                           0000B8   351 _IP	=	0x00b8
                           0000E8   352 _IE_EX	=	0x00e8
                           0000E9   353 _IP_EX	=	0x00e9
                           0000B2   354 _GPIO_IE	=	0x00b2
                           008584   355 _ROM_ADDR	=	0x8584
                           000084   356 _ROM_ADDR_L	=	0x0084
                           000085   357 _ROM_ADDR_H	=	0x0085
                           008F8E   358 _ROM_DATA_HI	=	0x8f8e
                           00008E   359 _ROM_DATA_HL	=	0x008e
                           00008F   360 _ROM_DATA_HH	=	0x008f
                           000086   361 _ROM_CTRL	=	0x0086
                           000080   362 _P0	=	0x0080
                           0000C4   363 _P0_MOD_OC	=	0x00c4
                           0000C5   364 _P0_DIR_PU	=	0x00c5
                           000090   365 _P1	=	0x0090
                           000092   366 _P1_MOD_OC	=	0x0092
                           000093   367 _P1_DIR_PU	=	0x0093
                           0000A0   368 _P2	=	0x00a0
                           000094   369 _P2_MOD_OC	=	0x0094
                           000095   370 _P2_DIR_PU	=	0x0095
                           0000B0   371 _P3	=	0x00b0
                           000096   372 _P3_MOD_OC	=	0x0096
                           000097   373 _P3_DIR_PU	=	0x0097
                           0000C0   374 _P4	=	0x00c0
                           0000C2   375 _P4_MOD_OC	=	0x00c2
                           0000C3   376 _P4_DIR_PU	=	0x00c3
                           0000C1   377 _P4_LED_KEY	=	0x00c1
                           0000AA   378 _P5_IN	=	0x00aa
                           0000AB   379 _P5_OUT_PU	=	0x00ab
                           0000AC   380 _P5_DIR	=	0x00ac
                           0000AD   381 _P6_IN	=	0x00ad
                           0000AE   382 _P6_OUT_PU	=	0x00ae
                           0000AF   383 _P6_DIR	=	0x00af
                           0000F1   384 _P7	=	0x00f1
                           0000A2   385 _XBUS_AUX	=	0x00a2
                           000088   386 _TCON	=	0x0088
                           000089   387 _TMOD	=	0x0089
                           00008A   388 _TL0	=	0x008a
                           00008B   389 _TL1	=	0x008b
                           00008C   390 _TH0	=	0x008c
                           00008D   391 _TH1	=	0x008d
                           000098   392 _SCON	=	0x0098
                           000099   393 _SBUF	=	0x0099
                           0000C8   394 _T2CON	=	0x00c8
                           0000C9   395 _T2MOD	=	0x00c9
                           00CBCA   396 _RCAP2	=	0xcbca
                           0000CA   397 _RCAP2L	=	0x00ca
                           0000CB   398 _RCAP2H	=	0x00cb
                           00CDCC   399 _T2COUNT	=	0xcdcc
                           0000CC   400 _TL2	=	0x00cc
                           0000CD   401 _TH2	=	0x00cd
                           00CFCE   402 _T2CAP1	=	0xcfce
                           0000CE   403 _T2CAP1L	=	0x00ce
                           0000CF   404 _T2CAP1H	=	0x00cf
                           0000F8   405 _SPI0_STAT	=	0x00f8
                           0000F9   406 _SPI0_DATA	=	0x00f9
                           0000FA   407 _SPI0_CTRL	=	0x00fa
                           0000FB   408 _SPI0_CK_SE	=	0x00fb
                           0000FC   409 _SPI0_SETUP	=	0x00fc
                           0000BC   410 _SCON1	=	0x00bc
                           0000BD   411 _SBUF1	=	0x00bd
                           0000BE   412 _SBAUD1	=	0x00be
                           0000BF   413 _SIF1	=	0x00bf
                           0000B4   414 _SPI1_STAT	=	0x00b4
                           0000B5   415 _SPI1_DATA	=	0x00b5
                           0000B6   416 _SPI1_CTRL	=	0x00b6
                           0000B7   417 _SPI1_CK_SE	=	0x00b7
                           0000F3   418 _ADC_CTRL	=	0x00f3
                           00F5F4   419 _ADC_DAT	=	0xf5f4
                           0000F4   420 _ADC_DAT_L	=	0x00f4
                           0000F5   421 _ADC_DAT_H	=	0x00f5
                           0000F6   422 _ADC_CHAN	=	0x00f6
                           0000A6   423 _LED_COMMON	=	0x00a6
                           0000A7   424 _LED_PWM_OE	=	0x00a7
                           00C7C6   425 _LED_DMA	=	0xc7c6
                           0000C6   426 _LED_DMA_L	=	0x00c6
                           0000C7   427 _LED_DMA_H	=	0x00c7
                           0000F7   428 _LED_STATUS	=	0x00f7
                           0000B3   429 _I2CX_INT	=	0x00b3
                           0000BB   430 _I2CS_INT_ST	=	0x00bb
                                    431 ;--------------------------------------------------------
                                    432 ; special function bits
                                    433 ;--------------------------------------------------------
                                    434 	.area RSEG    (ABS,DATA)
      000000                        435 	.org 0x0000
                           0000D7   436 _CY	=	0x00d7
                           0000D6   437 _AC	=	0x00d6
                           0000D5   438 _F0	=	0x00d5
                           0000D4   439 _RS1	=	0x00d4
                           0000D3   440 _RS0	=	0x00d3
                           0000D2   441 _OV	=	0x00d2
                           0000D1   442 _F1	=	0x00d1
                           0000D0   443 _P	=	0x00d0
                           0000AF   444 _EA	=	0x00af
                           0000AE   445 _E_DIS	=	0x00ae
                           0000AD   446 _ET2	=	0x00ad
                           0000AC   447 _ES	=	0x00ac
                           0000AB   448 _ET1	=	0x00ab
                           0000AA   449 _EX1	=	0x00aa
                           0000A9   450 _ET0	=	0x00a9
                           0000A8   451 _EX0	=	0x00a8
                           0000BF   452 _PH_FLAG	=	0x00bf
                           0000BE   453 _PL_FLAG	=	0x00be
                           0000BD   454 _PT2	=	0x00bd
                           0000BC   455 _PS	=	0x00bc
                           0000BB   456 _PT1	=	0x00bb
                           0000BA   457 _PX1	=	0x00ba
                           0000B9   458 _PT0	=	0x00b9
                           0000B8   459 _PX0	=	0x00b8
                           0000EF   460 _IE_WDOG	=	0x00ef
                           0000EE   461 _IE_GPIO	=	0x00ee
                           0000ED   462 _IE_PWM_I2C	=	0x00ed
                           0000EC   463 _IE_UART1	=	0x00ec
                           0000EB   464 _IE_ADC	=	0x00eb
                           0000E9   465 _IE_USB	=	0x00e9
                           0000E8   466 _IE_SPI0	=	0x00e8
                           000087   467 _P0_7	=	0x0087
                           000086   468 _P0_6	=	0x0086
                           000085   469 _P0_5	=	0x0085
                           000084   470 _P0_4	=	0x0084
                           000083   471 _P0_3	=	0x0083
                           000082   472 _P0_2	=	0x0082
                           000081   473 _P0_1	=	0x0081
                           000080   474 _P0_0	=	0x0080
                           000081   475 _SDA0	=	0x0081
                           000080   476 _SCL0	=	0x0080
                           000083   477 _TXD_	=	0x0083
                           000082   478 _RXD_	=	0x0082
                           000085   479 _AIN13	=	0x0085
                           000084   480 _AIN12	=	0x0084
                           000083   481 _AIN11	=	0x0083
                           000082   482 _AIN10	=	0x0082
                           000081   483 _AIN9	=	0x0081
                           000080   484 _AIN8	=	0x0080
                           000097   485 _P1_7	=	0x0097
                           000096   486 _P1_6	=	0x0096
                           000095   487 _P1_5	=	0x0095
                           000094   488 _P1_4	=	0x0094
                           000093   489 _P1_3	=	0x0093
                           000092   490 _P1_2	=	0x0092
                           000091   491 _P1_1	=	0x0091
                           000090   492 _P1_0	=	0x0090
                           000097   493 _TXD1_	=	0x0097
                           000096   494 _RXD1_	=	0x0096
                           000097   495 _SCK	=	0x0097
                           000096   496 _MISO	=	0x0096
                           000095   497 _MOSI	=	0x0095
                           000094   498 _SCS	=	0x0094
                           000092   499 _INT0_	=	0x0092
                           000091   500 _T2EX	=	0x0091
                           000091   501 _CAP2	=	0x0091
                           000090   502 _T2	=	0x0090
                           000090   503 _CAP1	=	0x0090
                           000097   504 _AIN7	=	0x0097
                           000096   505 _AIN6	=	0x0096
                           000095   506 _AIN5	=	0x0095
                           000094   507 _AIN4	=	0x0094
                           000093   508 _AIN3	=	0x0093
                           000092   509 _AIN2	=	0x0092
                           000091   510 _AIN1	=	0x0091
                           000090   511 _AIN0	=	0x0090
                           0000A7   512 _P2_7	=	0x00a7
                           0000A6   513 _P2_6	=	0x00a6
                           0000A5   514 _P2_5	=	0x00a5
                           0000A4   515 _P2_4	=	0x00a4
                           0000A3   516 _P2_3	=	0x00a3
                           0000A2   517 _P2_2	=	0x00a2
                           0000A1   518 _P2_1	=	0x00a1
                           0000A0   519 _P2_0	=	0x00a0
                           0000A7   520 _TXD1	=	0x00a7
                           0000A6   521 _RXD1	=	0x00a6
                           0000A5   522 _T2EX_	=	0x00a5
                           0000A5   523 _CAP2_	=	0x00a5
                           0000A4   524 _T2_	=	0x00a4
                           0000A4   525 _CAP1_	=	0x00a4
                           0000B7   526 _P3_7	=	0x00b7
                           0000B6   527 _P3_6	=	0x00b6
                           0000B5   528 _P3_5	=	0x00b5
                           0000B4   529 _P3_4	=	0x00b4
                           0000B3   530 _P3_3	=	0x00b3
                           0000B2   531 _P3_2	=	0x00b2
                           0000B1   532 _P3_1	=	0x00b1
                           0000B0   533 _P3_0	=	0x00b0
                           0000B7   534 _SCK1	=	0x00b7
                           0000B6   535 _MISO1	=	0x00b6
                           0000B5   536 _MOSI1	=	0x00b5
                           0000B5   537 _T1	=	0x00b5
                           0000B4   538 _T0	=	0x00b4
                           0000B3   539 _INT1	=	0x00b3
                           0000B2   540 _INT0	=	0x00b2
                           0000B1   541 _TXD	=	0x00b1
                           0000B0   542 _RXD	=	0x00b0
                           0000C6   543 _P4_6	=	0x00c6
                           0000C5   544 _P4_5	=	0x00c5
                           0000C4   545 _P4_4	=	0x00c4
                           0000C3   546 _P4_3	=	0x00c3
                           0000C2   547 _P4_2	=	0x00c2
                           0000C1   548 _P4_1	=	0x00c1
                           0000C0   549 _P4_0	=	0x00c0
                           00008F   550 _TF1	=	0x008f
                           00008E   551 _TR1	=	0x008e
                           00008D   552 _TF0	=	0x008d
                           00008C   553 _TR0	=	0x008c
                           00008B   554 _IE1	=	0x008b
                           00008A   555 _IT1	=	0x008a
                           000089   556 _IE0	=	0x0089
                           000088   557 _IT0	=	0x0088
                           00009F   558 _SM0	=	0x009f
                           00009E   559 _SM1	=	0x009e
                           00009D   560 _SM2	=	0x009d
                           00009C   561 _REN	=	0x009c
                           00009B   562 _TB8	=	0x009b
                           00009A   563 _RB8	=	0x009a
                           000099   564 _TI	=	0x0099
                           000098   565 _RI	=	0x0098
                           0000CF   566 _TF2	=	0x00cf
                           0000CF   567 _CAP1F	=	0x00cf
                           0000CE   568 _EXF2	=	0x00ce
                           0000CD   569 _RCLK	=	0x00cd
                           0000CC   570 _TCLK	=	0x00cc
                           0000CB   571 _EXEN2	=	0x00cb
                           0000CA   572 _TR2	=	0x00ca
                           0000C9   573 _C_T2	=	0x00c9
                           0000C8   574 _CP_RL2	=	0x00c8
                           0000FF   575 _S0_FST_ACT	=	0x00ff
                           0000FE   576 _S0_IF_OV	=	0x00fe
                           0000FD   577 _S0_IF_FIRST	=	0x00fd
                           0000FC   578 _S0_IF_BYTE	=	0x00fc
                           0000FB   579 _S0_FREE	=	0x00fb
                           0000FA   580 _S0_T_FIFO	=	0x00fa
                           0000F8   581 _S0_R_FIFO	=	0x00f8
                           0000F7   582 _ADC_START	=	0x00f7
                                    583 ;--------------------------------------------------------
                                    584 ; overlayable register banks
                                    585 ;--------------------------------------------------------
                                    586 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        587 	.ds 8
                                    588 ;--------------------------------------------------------
                                    589 ; internal ram data
                                    590 ;--------------------------------------------------------
                                    591 	.area DSEG    (DATA)
      000027                        592 _process_record_sloc0_1_0:
      000027                        593 	.ds 1
      000028                        594 _process_action_sloc0_1_0:
      000028                        595 	.ds 1
                                    596 ;--------------------------------------------------------
                                    597 ; overlayable items in internal ram
                                    598 ;--------------------------------------------------------
                                    599 ;--------------------------------------------------------
                                    600 ; indirectly addressable internal ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area ISEG    (DATA)
                                    603 ;--------------------------------------------------------
                                    604 ; absolute internal ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area IABS    (ABS,DATA)
                                    607 	.area IABS    (ABS,DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; bit data
                                    610 ;--------------------------------------------------------
                                    611 	.area BSEG    (BIT)
      00001F                        612 _process_action_sloc1_1_0:
      00001F                        613 	.ds 1
                                    614 ;--------------------------------------------------------
                                    615 ; paged external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area PSEG    (PAG,XDATA)
                                    618 ;--------------------------------------------------------
                                    619 ; uninitialized external ram data
                                    620 ;--------------------------------------------------------
                                    621 	.area XSEG    (XDATA)
      000860                        622 _tp_buttons::
      000860                        623 	.ds 2
      000862                        624 _action_exec_PARM_1:
      000862                        625 	.ds 6
      000868                        626 _action_exec_record_10001_630:
      000868                        627 	.ds 9
      000871                        628 _ak820_action_exec_event_10000_634:
      000871                        629 	.ds 2
      000873                        630 _ak820_action_exec_snapshot_10000_635:
      000873                        631 	.ds 6
      000879                        632 _process_record_record_argument_10000_638:
      000879                        633 	.ds 2
      00087B                        634 _process_record_handler_record_argument_10000_647:
      00087B                        635 	.ds 2
      00087D                        636 _process_record_handler_action_10000_648:
      00087D                        637 	.ds 2
      00087F                        638 _process_action_PARM_2:
      00087F                        639 	.ds 2
      000881                        640 _process_action_record_argument_10000_659:
      000881                        641 	.ds 2
      000883                        642 _process_action_on_40000_682:
      000883                        643 	.ds 1
      000884                        644 _register_code_code_10000_716:
      000884                        645 	.ds 1
      000885                        646 _unregister_code_code_10000_730:
      000885                        647 	.ds 1
      000886                        648 _tap_code_delay_PARM_2:
      000886                        649 	.ds 2
      000888                        650 _tap_code_delay_code_10000_743:
      000888                        651 	.ds 1
      000889                        652 _tap_code_code_10000_750:
      000889                        653 	.ds 1
      00088A                        654 _register_mods_mods_10000_752:
      00088A                        655 	.ds 1
      00088B                        656 _unregister_mods_mods_10000_756:
      00088B                        657 	.ds 1
      00088C                        658 _register_weak_mods_mods_10000_760:
      00088C                        659 	.ds 1
      00088D                        660 _unregister_weak_mods_mods_10000_764:
      00088D                        661 	.ds 1
                                    662 ;--------------------------------------------------------
                                    663 ; absolute external ram data
                                    664 ;--------------------------------------------------------
                                    665 	.area XABS    (ABS,XDATA)
                                    666 ;--------------------------------------------------------
                                    667 ; initialized external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XISEG   (XDATA)
      000DE9                        670 _disable_action_cache::
      000DE9                        671 	.ds 1
                                    672 	.area HOME    (CODE)
                                    673 	.area GSINIT0 (CODE)
                                    674 	.area GSINIT1 (CODE)
                                    675 	.area GSINIT2 (CODE)
                                    676 	.area GSINIT3 (CODE)
                                    677 	.area GSINIT4 (CODE)
                                    678 	.area GSINIT5 (CODE)
                                    679 	.area GSINIT  (CODE)
                                    680 	.area GSFINAL (CODE)
                                    681 	.area CSEG    (CODE)
                                    682 ;--------------------------------------------------------
                                    683 ; global & static initialisations
                                    684 ;--------------------------------------------------------
                                    685 	.area HOME    (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 	.area GSFINAL (CODE)
                                    688 	.area GSINIT  (CODE)
                                    689 ;--------------------------------------------------------
                                    690 ; Home
                                    691 ;--------------------------------------------------------
                                    692 	.area HOME    (CODE)
                                    693 	.area HOME    (CODE)
                                    694 ;--------------------------------------------------------
                                    695 ; code
                                    696 ;--------------------------------------------------------
                                    697 	.area CSEG    (CODE)
                                    698 ;------------------------------------------------------------
                                    699 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    700 ;------------------------------------------------------------
                                    701 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    702 ;------------------------------------------------------------
                                    703 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    704 ;	-----------------------------------------
                           000007   705 	ar7 = 0x07
                           000006   706 	ar6 = 0x06
                           000005   707 	ar5 = 0x05
                           000004   708 	ar4 = 0x04
                           000003   709 	ar3 = 0x03
                           000002   710 	ar2 = 0x02
                           000001   711 	ar1 = 0x01
                           000000   712 	ar0 = 0x00
                                    713 ;	 function action_exec
                                    714 ;	-----------------------------------------
      007330                        715 _action_exec:
                                    716 ;	quantum/action.c:98: ak820_dynamic_macro_task(event.time);
      007330 90 08 64         [24]  717 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007333 12 37 A0         [24]  718 	lcall	_ak820_outline_0004
      007336 12 3A E0         [24]  719 	lcall	_ak820_dynamic_macro_task
                                    720 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      007339 90 08 64         [24]  721 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00733C 12 37 A0         [24]  722 	lcall	_ak820_outline_0004
      00733F 12 35 B8         [24]  723 	lcall	_ak820_combo_tick
                                    724 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      007342 90 08 62         [24]  725 	mov	dptr,#_action_exec_PARM_1
      007345 12 47 62         [24]  726 	lcall	_ak820_tapping_before
      007348 E5 82            [12]  727 	mov	a, dpl
      00734A 70 01            [24]  728 	jnz	00102$
      00734C 22               [24]  729 	ret
      00734D                        730 00102$:
                                    731 ;	quantum/action.c:126: if (event.pressed) {
      00734D 90 08 67         [24]  732 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007350 E0               [24]  733 	movx	a,@dptr
      007351 60 03            [24]  734 	jz	00104$
                                    735 ;	quantum/action.c:128: clear_weak_mods();
      007353 12 84 30         [24]  736 	lcall	_clear_weak_mods
      007356                        737 00104$:
                                    738 ;	quantum/action.c:140: record.event = event;
      007356 90 0D C9         [24]  739 	mov	dptr,#___memcpy_PARM_2
      007359 74 62            [12]  740 	mov	a,#_action_exec_PARM_1
      00735B F0               [24]  741 	movx	@dptr,a
      00735C 74 08            [12]  742 	mov	a,#(_action_exec_PARM_1 >> 8)
      00735E 12 7A 48         [24]  743 	lcall	_ak820_outline_0050
      007361 12 7A 68         [24]  744 	lcall	_ak820_outline_0108
      007364 90 08 68         [24]  745 	mov	dptr,#_action_exec_record_10001_630
      007367 F5 F0            [12]  746 	mov	b,a
      007369 12 BA 82         [24]  747 	lcall	___memcpy
                                    748 ;	quantum/action.c:142: record.tap.count = 0;
      00736C 90 08 6E         [24]  749 	mov	dptr,#(_action_exec_record_10001_630 + 0x0006)
      00736F E0               [24]  750 	movx	a,@dptr
      007370 54 0F            [12]  751 	anl	a,#0x0f
      007372 F0               [24]  752 	movx	@dptr,a
                                    753 ;	quantum/action.c:147: record.keycode = 0;
      007373 90 08 6F         [24]  754 	mov	dptr,#(_action_exec_record_10001_630 + 0x0007)
      007376 12 52 5F         [24]  755 	lcall	_ak820_outline_0178
                                    756 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007379 90 08 6C         [24]  757 	mov	dptr,#(_action_exec_record_10001_630 + 0x0004)
      00737C E0               [24]  758 	movx	a,@dptr
      00737D 60 0A            [24]  759 	jz	00107$
      00737F 90 08 68         [24]  760 	mov	dptr,#_action_exec_record_10001_630
      007382 12 A1 94         [24]  761 	lcall	_pre_process_record_quantum
      007385 E5 82            [12]  762 	mov	a, dpl
      007387 60 11            [24]  763 	jz	00110$
      007389                        764 00107$:
                                    765 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      007389 90 08 68         [24]  766 	mov	dptr,#_action_exec_record_10001_630
      00738C 12 48 45         [24]  767 	lcall	_ak820_tapping_process
      00738F E5 82            [12]  768 	mov	a, dpl
      007391 70 01            [24]  769 	jnz	00106$
      007393 22               [24]  770 	ret
      007394                        771 00106$:
                                    772 ;	quantum/action.c:185: process_record(&record);
      007394 90 08 68         [24]  773 	mov	dptr,#_action_exec_record_10001_630
                                    774 ;	quantum/action.c:200: }
      007397 02 73 D8         [24]  775 	ljmp	_process_record
      00739A                        776 00110$:
      00739A 22               [24]  777 	ret
                                    778 ;------------------------------------------------------------
                                    779 ;Allocation info for local variables in function 'ak820_action_exec'
                                    780 ;------------------------------------------------------------
                                    781 ;event         Allocated with name '_ak820_action_exec_event_10000_634'
                                    782 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_635'
                                    783 ;------------------------------------------------------------
                                    784 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    785 ;	-----------------------------------------
                                    786 ;	 function ak820_action_exec
                                    787 ;	-----------------------------------------
      00739B                        788 _ak820_action_exec:
      00739B 12 38 4A         [24]  789 	lcall	_ak820_outline_0104
      00739E 90 08 71         [24]  790 	mov	dptr,#_ak820_action_exec_event_10000_634
      0073A1 12 38 4F         [24]  791 	lcall	_ak820_outline_0105
                                    792 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      0073A4 90 08 71         [24]  793 	mov	dptr,#_ak820_action_exec_event_10000_634
      0073A7 12 38 17         [24]  794 	lcall	_ak820_outline_0057
      0073AA 90 0D C9         [24]  795 	mov	dptr,#___memcpy_PARM_2
      0073AD ED               [12]  796 	mov	a,r5
      0073AE 12 37 DF         [24]  797 	lcall	_ak820_outline_0016
      0073B1 90 0D CC         [24]  798 	mov	dptr,#___memcpy_PARM_3
      0073B4 12 7A 68         [24]  799 	lcall	_ak820_outline_0108
      0073B7 90 08 73         [24]  800 	mov	dptr,#_ak820_action_exec_snapshot_10000_635
      0073BA F5 F0            [12]  801 	mov	b,a
      0073BC 12 BA 82         [24]  802 	lcall	___memcpy
                                    803 ;	quantum/action.c:207: action_exec(snapshot);
      0073BF 90 0D C9         [24]  804 	mov	dptr,#___memcpy_PARM_2
      0073C2 74 73            [12]  805 	mov	a,#_ak820_action_exec_snapshot_10000_635
      0073C4 F0               [24]  806 	movx	@dptr,a
      0073C5 74 08            [12]  807 	mov	a,#(_ak820_action_exec_snapshot_10000_635 >> 8)
      0073C7 12 7A 48         [24]  808 	lcall	_ak820_outline_0050
      0073CA 12 7A 68         [24]  809 	lcall	_ak820_outline_0108
      0073CD 90 08 62         [24]  810 	mov	dptr,#_action_exec_PARM_1
      0073D0 F5 F0            [12]  811 	mov	b,a
      0073D2 12 BA 82         [24]  812 	lcall	___memcpy
                                    813 ;	quantum/action.c:208: }
      0073D5 02 73 30         [24]  814 	ljmp	_action_exec
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'process_record_nocache'
                                    817 ;------------------------------------------------------------
                                    818 ;record        Allocated with name '_process_record_nocache_record_10000_636'
                                    819 ;------------------------------------------------------------
                                    820 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    821 ;	-----------------------------------------
                                    822 ;	 function process_record
                                    823 ;	-----------------------------------------
      0073D8                        824 _process_record:
      0073D8 12 38 4A         [24]  825 	lcall	_ak820_outline_0104
      0073DB 90 08 79         [24]  826 	mov	dptr,#_process_record_record_argument_10000_638
      0073DE 12 38 4F         [24]  827 	lcall	_ak820_outline_0105
                                    828 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0073E1 90 08 79         [24]  829 	mov	dptr,#_process_record_record_argument_10000_638
      0073E4 12 38 00         [24]  830 	lcall	_ak820_outline_0051
                                    831 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      0073E7 74 04            [12]  832 	mov	a,#0x04
      0073E9 12 4B 45         [24]  833 	lcall	_ak820_outline_0011
      0073EC 70 01            [24]  834 	jnz	00102$
                                    835 ;	quantum/action.c:354: return;
      0073EE 22               [24]  836 	ret
      0073EF                        837 00102$:
                                    838 ;	quantum/action.c:358: if (record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !ak820_macro_primitive &&
      0073EF 12 38 2B         [24]  839 	lcall	_ak820_outline_0074
      0073F2 FD               [12]  840 	mov	r5,a
      0073F3 BD 10 00         [24]  841 	cjne	r5,#0x10,00192$
      0073F6                        842 00192$:
      0073F6 50 3C            [24]  843 	jnc	00104$
      0073F8 12 38 38         [24]  844 	lcall	_ak820_outline_0093
      0073FB FD               [12]  845 	mov	r5,a
      0073FC BD 08 00         [24]  846 	cjne	r5,#0x08,00194$
      0073FF                        847 00194$:
      0073FF 50 33            [24]  848 	jnc	00104$
      007401 90 09 D5         [24]  849 	mov	dptr,#_ak820_macro_primitive
      007404 E0               [24]  850 	movx	a,@dptr
      007405 70 2D            [24]  851 	jnz	00104$
                                    852 ;	quantum/action.c:359: !ak820_dynamic_macro_process(get_record_keycode(record, true), record->event.pressed)) return;
      007407 90 0C 2B         [24]  853 	mov	dptr,#_get_record_keycode_PARM_2
      00740A 12 4B 83         [24]  854 	lcall	_ak820_outline_0043
      00740D C0 07            [24]  855 	push	ar7
      00740F C0 06            [24]  856 	push	ar6
      007411 12 A1 56         [24]  857 	lcall	_get_record_keycode
      007414 12 46 7E         [24]  858 	lcall	_ak820_outline_0141
      007417 D0 06            [24]  859 	pop	ar6
      007419 D0 07            [24]  860 	pop	ar7
      00741B 12 4B 3A         [24]  861 	lcall	_ak820_outline_0008
      00741E 90 04 AA         [24]  862 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      007421 12 38 3E         [24]  863 	lcall	_ak820_outline_0094
      007424 C0 07            [24]  864 	push	ar7
      007426 C0 06            [24]  865 	push	ar6
      007428 12 39 47         [24]  866 	lcall	_ak820_dynamic_macro_process
      00742B E5 82            [12]  867 	mov	a, dpl
      00742D D0 06            [24]  868 	pop	ar6
      00742F D0 07            [24]  869 	pop	ar7
      007431 70 01            [24]  870 	jnz	00104$
      007433 22               [24]  871 	ret
      007434                        872 00104$:
                                    873 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007434 8E 04            [24]  874 	mov	ar4,r6
      007436 8F 05            [24]  875 	mov	ar5,r7
      007438 90 0D C9         [24]  876 	mov	dptr,#___memcpy_PARM_2
      00743B EC               [12]  877 	mov	a,r4
      00743C F0               [24]  878 	movx	@dptr,a
      00743D ED               [12]  879 	mov	a,r5
      00743E 12 7A 48         [24]  880 	lcall	_ak820_outline_0050
      007441 12 52 51         [24]  881 	lcall	_ak820_outline_0107
      007444 90 06 76         [24]  882 	mov	dptr,#_ak820_tapping_source_PARM_1
      007447 F5 F0            [12]  883 	mov	b,a
      007449 C0 07            [24]  884 	push	ar7
      00744B C0 06            [24]  885 	push	ar6
      00744D 12 BA 82         [24]  886 	lcall	___memcpy
      007450 12 46 9E         [24]  887 	lcall	_ak820_tapping_source
      007453 AD 82            [24]  888 	mov	r5, dpl
      007455 D0 06            [24]  889 	pop	ar6
      007457 D0 07            [24]  890 	pop	ar7
                                    891 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      007459 12 4B 3A         [24]  892 	lcall	_ak820_outline_0008
      00745C FC               [12]  893 	mov	r4,a
                                    894 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      00745D 74 07            [12]  895 	mov	a,#0x07
      00745F 2E               [12]  896 	add	a, r6
      007460 FA               [12]  897 	mov	r2,a
      007461 E4               [12]  898 	clr	a
      007462 3F               [12]  899 	addc	a, r7
      007463 FB               [12]  900 	mov	r3,a
      007464 90 0C 2B         [24]  901 	mov	dptr,#_get_record_keycode_PARM_2
      007467 12 4B 83         [24]  902 	lcall	_ak820_outline_0043
      00746A C0 07            [24]  903 	push	ar7
      00746C C0 06            [24]  904 	push	ar6
      00746E C0 05            [24]  905 	push	ar5
      007470 C0 04            [24]  906 	push	ar4
      007472 C0 03            [24]  907 	push	ar3
      007474 C0 02            [24]  908 	push	ar2
      007476 12 A1 56         [24]  909 	lcall	_get_record_keycode
      007479 A8 82            [24]  910 	mov	r0, dpl
      00747B A9 83            [24]  911 	mov	r1, dph
      00747D D0 02            [24]  912 	pop	ar2
      00747F D0 03            [24]  913 	pop	ar3
      007481 D0 04            [24]  914 	pop	ar4
      007483 D0 05            [24]  915 	pop	ar5
      007485 D0 06            [24]  916 	pop	ar6
      007487 D0 07            [24]  917 	pop	ar7
      007489 12 46 79         [24]  918 	lcall	_ak820_outline_0140
      00748C E8               [12]  919 	mov	a,r0
      00748D F0               [24]  920 	movx	@dptr,a
      00748E E9               [12]  921 	mov	a,r1
      00748F A3               [24]  922 	inc	dptr
      007490 F0               [24]  923 	movx	@dptr,a
                                    924 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007491 74 07            [12]  925 	mov	a,#0x07
      007493 12 37 E7         [24]  926 	lcall	_ak820_outline_0017
      007496 FA               [12]  927 	mov	r2,a
      007497 A3               [24]  928 	inc	dptr
      007498 E0               [24]  929 	movx	a,@dptr
      007499 FB               [12]  930 	mov	r3,a
      00749A 90 06 86         [24]  931 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00749D ED               [12]  932 	mov	a,r5
      00749E F0               [24]  933 	movx	@dptr,a
      00749F 90 06 87         [24]  934 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0074A2 EC               [12]  935 	mov	a,r4
      0074A3 F0               [24]  936 	movx	@dptr,a
      0074A4 12 46 79         [24]  937 	lcall	_ak820_outline_0140
      0074A7 C0 07            [24]  938 	push	ar7
      0074A9 C0 06            [24]  939 	push	ar6
      0074AB C0 05            [24]  940 	push	ar5
      0074AD C0 04            [24]  941 	push	ar4
      0074AF 12 49 ED         [24]  942 	lcall	_ak820_oneshot_process
      0074B2 E5 82            [12]  943 	mov	a, dpl
      0074B4 D0 04            [24]  944 	pop	ar4
      0074B6 D0 05            [24]  945 	pop	ar5
      0074B8 D0 06            [24]  946 	pop	ar6
      0074BA D0 07            [24]  947 	pop	ar7
      0074BC 70 01            [24]  948 	jnz	00109$
      0074BE 22               [24]  949 	ret
      0074BF                        950 00109$:
                                    951 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      0074BF 12 46 5D         [24]  952 	lcall	_ak820_outline_0116
      0074C2 C0 07            [24]  953 	push	ar7
      0074C4 C0 06            [24]  954 	push	ar6
      0074C6 C0 05            [24]  955 	push	ar5
      0074C8 C0 04            [24]  956 	push	ar4
      0074CA 12 A1 D6         [24]  957 	lcall	_process_record_quantum
      0074CD E5 82            [12]  958 	mov	a, dpl
      0074CF D0 04            [24]  959 	pop	ar4
      0074D1 D0 05            [24]  960 	pop	ar5
      0074D3 D0 06            [24]  961 	pop	ar6
      0074D5 D0 07            [24]  962 	pop	ar7
      0074D7 70 0A            [24]  963 	jnz	00111$
                                    964 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0074D9 90 05 EE         [24]  965 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0074DC EC               [12]  966 	mov	a,r4
      0074DD F0               [24]  967 	movx	@dptr,a
      0074DE 8D 82            [24]  968 	mov	dpl, r5
                                    969 ;	quantum/action.c:376: return;
      0074E0 02 2E BB         [24]  970 	ljmp	_ak820_oneshot_post
      0074E3                        971 00111$:
                                    972 ;	quantum/action.c:380: ak820_dynamic_macro_source = record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !get_repeat_key_count() && !ak820_macro_primitive;
      0074E3 12 38 2B         [24]  973 	lcall	_ak820_outline_0074
      0074E6 FB               [12]  974 	mov	r3,a
      0074E7 BB 10 00         [24]  975 	cjne	r3,#0x10,00200$
      0074EA                        976 00200$:
      0074EA 50 16            [24]  977 	jnc	00114$
      0074EC 12 38 38         [24]  978 	lcall	_ak820_outline_0093
      0074EF FB               [12]  979 	mov	r3,a
      0074F0 BB 08 00         [24]  980 	cjne	r3,#0x08,00202$
      0074F3                        981 00202$:
      0074F3 50 0D            [24]  982 	jnc	00114$
      0074F5 12 A4 81         [24]  983 	lcall	_get_repeat_key_count
      0074F8 E5 82            [12]  984 	mov	a, dpl
      0074FA 70 06            [24]  985 	jnz	00114$
      0074FC 90 09 D5         [24]  986 	mov	dptr,#_ak820_macro_primitive
      0074FF E0               [24]  987 	movx	a,@dptr
      007500 60 05            [24]  988 	jz	00115$
      007502                        989 00114$:
      007502 75 27 00         [24]  990 	mov	_process_record_sloc0_1_0,#0x00
      007505 80 03            [24]  991 	sjmp	00116$
      007507                        992 00115$:
      007507 75 27 01         [24]  993 	mov	_process_record_sloc0_1_0,#0x01
      00750A                        994 00116$:
      00750A 90 04 A9         [24]  995 	mov	dptr,#_ak820_dynamic_macro_source
      00750D E5 27            [12]  996 	mov	a,_process_record_sloc0_1_0
      00750F 12 46 3F         [24]  997 	lcall	_ak820_outline_0060
                                    998 ;	quantum/action.c:382: process_record_handler(record);
      007512 C0 05            [24]  999 	push	ar5
      007514 C0 04            [24] 1000 	push	ar4
      007516 12 75 2C         [24] 1001 	lcall	_process_record_handler
      007519 D0 04            [24] 1002 	pop	ar4
      00751B D0 05            [24] 1003 	pop	ar5
                                   1004 ;	quantum/action.c:384: ak820_dynamic_macro_source = false;
      00751D 90 04 A9         [24] 1005 	mov	dptr,#_ak820_dynamic_macro_source
      007520 E4               [12] 1006 	clr	a
      007521 F0               [24] 1007 	movx	@dptr,a
                                   1008 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007522 90 05 EE         [24] 1009 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007525 EC               [12] 1010 	mov	a,r4
      007526 F0               [24] 1011 	movx	@dptr,a
      007527 8D 82            [24] 1012 	mov	dpl, r5
                                   1013 ;	quantum/action.c:392: }
      007529 02 2E BB         [24] 1014 	ljmp	_ak820_oneshot_post
                                   1015 ;------------------------------------------------------------
                                   1016 ;Allocation info for local variables in function 'process_record_handler'
                                   1017 ;------------------------------------------------------------
                                   1018 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_647'
                                   1019 ;record        Allocated with name '_process_record_handler_record_10000_648'
                                   1020 ;action        Allocated with name '_process_record_handler_action_10000_648'
                                   1021 ;------------------------------------------------------------
                                   1022 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1023 ;	-----------------------------------------
                                   1024 ;	 function process_record_handler
                                   1025 ;	-----------------------------------------
      00752C                       1026 _process_record_handler:
      00752C 12 38 4A         [24] 1027 	lcall	_ak820_outline_0104
      00752F 90 08 7B         [24] 1028 	mov	dptr,#_process_record_handler_record_argument_10000_647
      007532 12 38 4F         [24] 1029 	lcall	_ak820_outline_0105
                                   1030 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007535 90 08 7B         [24] 1031 	mov	dptr,#_process_record_handler_record_argument_10000_647
      007538 12 37 B7         [24] 1032 	lcall	_ak820_outline_0009
                                   1033 ;	quantum/action.c:405: if (record->keycode) {
      00753B 4C               [12] 1034 	orl	a,r4
      00753C 60 19            [24] 1035 	jz	00102$
                                   1036 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      00753E 12 38 60         [24] 1037 	lcall	_ak820_outline_0121
      007541 C0 07            [24] 1038 	push	ar7
      007543 C0 06            [24] 1039 	push	ar6
      007545 12 98 26         [24] 1040 	lcall	_action_for_keycode
      007548 12 46 7E         [24] 1041 	lcall	_ak820_outline_0141
      00754B D0 06            [24] 1042 	pop	ar6
      00754D D0 07            [24] 1043 	pop	ar7
      00754F 90 08 7D         [24] 1044 	mov	dptr,#_process_record_handler_action_10000_648
      007552 12 38 25         [24] 1045 	lcall	_ak820_outline_0070
      007555 80 2A            [24] 1046 	sjmp	00104$
      007557                       1047 00102$:
                                   1048 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007557 12 7A 30         [24] 1049 	lcall	_ak820_outline_0019
      00755A 7A 00            [12] 1050 	mov	r2,#0x00
      00755C 12 46 73         [24] 1051 	lcall	_ak820_outline_0139
      00755F 12 4B 3A         [24] 1052 	lcall	_ak820_outline_0008
      007562 90 09 B8         [24] 1053 	mov	dptr,#_ak820_resolve_key_PARM_2
      007565 F0               [24] 1054 	movx	@dptr,a
      007566 8D 82            [24] 1055 	mov	dpl, r5
      007568 8C 83            [24] 1056 	mov	dph, r4
      00756A C0 07            [24] 1057 	push	ar7
      00756C C0 06            [24] 1058 	push	ar6
      00756E 12 7D D2         [24] 1059 	lcall	_ak820_resolve_key
      007571 12 98 26         [24] 1060 	lcall	_action_for_keycode
      007574 12 46 7E         [24] 1061 	lcall	_ak820_outline_0141
      007577 D0 06            [24] 1062 	pop	ar6
      007579 D0 07            [24] 1063 	pop	ar7
      00757B 90 08 7D         [24] 1064 	mov	dptr,#_process_record_handler_action_10000_648
      00757E 12 38 25         [24] 1065 	lcall	_ak820_outline_0070
                                   1066 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      007581                       1067 00104$:
                                   1068 ;	quantum/action.c:429: process_action(record, action);
      007581 90 0D C9         [24] 1069 	mov	dptr,#___memcpy_PARM_2
      007584 74 7D            [12] 1070 	mov	a,#_process_record_handler_action_10000_648
      007586 F0               [24] 1071 	movx	@dptr,a
      007587 74 08            [12] 1072 	mov	a,#(_process_record_handler_action_10000_648 >> 8)
      007589 12 7A 48         [24] 1073 	lcall	_ak820_outline_0050
      00758C 12 52 51         [24] 1074 	lcall	_ak820_outline_0107
      00758F 90 08 7F         [24] 1075 	mov	dptr,#_process_action_PARM_2
      007592 F5 F0            [12] 1076 	mov	b,a
      007594 C0 07            [24] 1077 	push	ar7
      007596 C0 06            [24] 1078 	push	ar6
      007598 12 BA 82         [24] 1079 	lcall	___memcpy
      00759B D0 06            [24] 1080 	pop	ar6
      00759D D0 07            [24] 1081 	pop	ar7
      00759F 12 46 5D         [24] 1082 	lcall	_ak820_outline_0116
                                   1083 ;	quantum/action.c:430: }
      0075A2 02 75 A5         [24] 1084 	ljmp	_process_action
                                   1085 ;------------------------------------------------------------
                                   1086 ;Allocation info for local variables in function 'register_mouse'
                                   1087 ;------------------------------------------------------------
                                   1088 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1089 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_656'
                                   1090 ;------------------------------------------------------------
                                   1091 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1092 ;	-----------------------------------------
                                   1093 ;	 function process_action
                                   1094 ;	-----------------------------------------
      0075A5                       1095 _process_action:
      0075A5 12 38 4A         [24] 1096 	lcall	_ak820_outline_0104
      0075A8 90 08 81         [24] 1097 	mov	dptr,#_process_action_record_argument_10000_659
      0075AB 12 38 4F         [24] 1098 	lcall	_ak820_outline_0105
                                   1099 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0075AE 90 08 81         [24] 1100 	mov	dptr,#_process_action_record_argument_10000_659
      0075B1 12 37 A0         [24] 1101 	lcall	_ak820_outline_0004
                                   1102 ;	quantum/action.c:501: pressed = record->event.pressed;
      0075B4 A3               [24] 1103 	inc	dptr
      0075B5 A3               [24] 1104 	inc	dptr
      0075B6 A3               [24] 1105 	inc	dptr
      0075B7 A3               [24] 1106 	inc	dptr
      0075B8 A3               [24] 1107 	inc	dptr
      0075B9 E0               [24] 1108 	movx	a,@dptr
      0075BA F5 28            [12] 1109 	mov	_process_action_sloc0_1_0,a
                                   1110 ;	quantum/action.c:525: switch (action.kind.id) {
      0075BC 90 08 80         [24] 1111 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0075BF E0               [24] 1112 	movx	a,@dptr
      0075C0 C4               [12] 1113 	swap	a
      0075C1 54 0F            [12] 1114 	anl	a,#0x0f
      0075C3 FD               [12] 1115 	mov  r5,a
      0075C4 24 F4            [12] 1116 	add	a,#0xff - 0x0b
      0075C6 50 03            [24] 1117 	jnc	00434$
      0075C8 02 78 46         [24] 1118 	ljmp	00181$
      0075CB                       1119 00434$:
                                   1120 ;	free result
      0075CB ED               [12] 1121 	mov	a,r5
      0075CC 24 0A            [12] 1122 	add	a,#(00435$-3-.)
      0075CE 83               [24] 1123 	movc	a,@a+pc
      0075CF F5 82            [12] 1124 	mov	dpl,a
      0075D1 ED               [12] 1125 	mov	a,r5
      0075D2 24 10            [12] 1126 	add	a,#(00436$-3-.)
      0075D4 83               [24] 1127 	movc	a,@a+pc
      0075D5 F5 83            [12] 1128 	mov	dph,a
      0075D7 E4               [12] 1129 	clr	a
      0075D8 73               [24] 1130 	jmp	@a+dptr
      0075D9                       1131 00435$:
      0075D9 F1                    1132 	.db	00102$
      0075DA F1                    1133 	.db	00102$
      0075DB 46                    1134 	.db	00181$
      0075DC 46                    1135 	.db	00181$
      0075DD 7B                    1136 	.db	00123$
      0075DE 46                    1137 	.db	00181$
      0075DF 46                    1138 	.db	00181$
      0075E0 46                    1139 	.db	00181$
      0075E1 DB                    1140 	.db	00131$
      0075E2 AD                    1141 	.db	00147$
      0075E3 D3                    1142 	.db	00152$
      0075E4 D3                    1143 	.db	00152$
      0075E5                       1144 00436$:
      0075E5 75                    1145 	.db	00102$>>8
      0075E6 75                    1146 	.db	00102$>>8
      0075E7 78                    1147 	.db	00181$>>8
      0075E8 78                    1148 	.db	00181$>>8
      0075E9 76                    1149 	.db	00123$>>8
      0075EA 78                    1150 	.db	00181$>>8
      0075EB 78                    1151 	.db	00181$>>8
      0075EC 78                    1152 	.db	00181$>>8
      0075ED 76                    1153 	.db	00131$>>8
      0075EE 77                    1154 	.db	00147$>>8
      0075EF 77                    1155 	.db	00152$>>8
      0075F0 77                    1156 	.db	00152$>>8
                                   1157 ;	quantum/action.c:528: case ACT_RMODS: {
      0075F1                       1158 00102$:
                                   1159 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0075F1 90 08 80         [24] 1160 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0075F4 E0               [24] 1161 	movx	a,@dptr
      0075F5 54 F0            [12] 1162 	anl	a,#0xf0
      0075F7 70 06            [24] 1163 	jnz	00194$
      0075F9 12 7A 6F         [24] 1164 	lcall	_ak820_outline_0109
      0075FC FD               [12] 1165 	mov	r5,a
      0075FD 80 07            [24] 1166 	sjmp	00195$
      0075FF                       1167 00194$:
      0075FF 12 7A 6F         [24] 1168 	lcall	_ak820_outline_0109
      007602 C4               [12] 1169 	swap	a
      007603 54 F0            [12] 1170 	anl	a,#0xf0
      007605 FD               [12] 1171 	mov	r5,a
      007606                       1172 00195$:
                                   1173 ;	quantum/action.c:531: if (pressed) {
      007606 E5 28            [12] 1174 	mov	a,_process_action_sloc0_1_0
      007608 60 35            [24] 1175 	jz	00119$
                                   1176 ;	quantum/action.c:532: if (mods) {
      00760A ED               [12] 1177 	mov	a,r5
      00760B 60 29            [24] 1178 	jz	00110$
                                   1179 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00760D 12 7A 81         [24] 1180 	lcall	_ak820_outline_0154
      007610 FC               [12] 1181 	mov	r4,a
      007611 BC E0 00         [24] 1182 	cjne	r4,#0xe0,00440$
      007614                       1183 00440$:
      007614 40 07            [24] 1184 	jc	00108$
      007616 12 7A 81         [24] 1185 	lcall	_ak820_outline_0154
      007619 24 18            [12] 1186 	add	a,#0xff - 0xe7
      00761B 50 0A            [24] 1187 	jnc	00104$
                                   1188 ;	free result
      00761D                       1189 00108$:
      00761D 7B 7F            [12] 1190 	mov	r3,#_process_action_PARM_2
      00761F 7C 08            [12] 1191 	mov	r4,#(_process_action_PARM_2 >> 8)
      007621 12 33 FC         [24] 1192 	lcall	_ak820_outline_0122
      007624 E0               [24] 1193 	movx	a,@dptr
      007625 70 07            [24] 1194 	jnz	00105$
      007627                       1195 00104$:
                                   1196 ;	quantum/action.c:537: add_owned_mods(mods);
      007627 8D 82            [24] 1197 	mov	dpl, r5
      007629 12 80 3C         [24] 1198 	lcall	_add_owned_mods
      00762C 80 05            [24] 1199 	sjmp	00106$
      00762E                       1200 00105$:
                                   1201 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      00762E 8D 82            [24] 1202 	mov	dpl, r5
      007630 12 80 5A         [24] 1203 	lcall	_add_owned_weak_mods
      007633                       1204 00106$:
                                   1205 ;	quantum/action.c:541: send_keyboard_report();
      007633 12 83 77         [24] 1206 	lcall	_send_keyboard_report
      007636                       1207 00110$:
                                   1208 ;	quantum/action.c:543: register_code(action.key.code);
      007636 12 7A 58         [24] 1209 	lcall	_ak820_outline_0075
      007639 12 78 5D         [24] 1210 	lcall	_register_code
      00763C 02 78 46         [24] 1211 	ljmp	00181$
      00763F                       1212 00119$:
                                   1213 ;	quantum/action.c:545: unregister_code(action.key.code);
      00763F 12 7A 58         [24] 1214 	lcall	_ak820_outline_0075
      007642 C0 05            [24] 1215 	push	ar5
      007644 12 78 D9         [24] 1216 	lcall	_unregister_code
      007647 D0 05            [24] 1217 	pop	ar5
                                   1218 ;	quantum/action.c:546: if (mods) {
      007649 ED               [12] 1219 	mov	a,r5
      00764A 70 03            [24] 1220 	jnz	00444$
      00764C 02 78 46         [24] 1221 	ljmp	00181$
      00764F                       1222 00444$:
                                   1223 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00764F 12 7A 81         [24] 1224 	lcall	_ak820_outline_0154
      007652 FC               [12] 1225 	mov	r4,a
      007653 BC E0 00         [24] 1226 	cjne	r4,#0xe0,00445$
      007656                       1227 00445$:
      007656 40 07            [24] 1228 	jc	00115$
      007658 12 7A 81         [24] 1229 	lcall	_ak820_outline_0154
      00765B 24 18            [12] 1230 	add	a,#0xff - 0xe7
      00765D 50 0A            [24] 1231 	jnc	00111$
                                   1232 ;	free result
      00765F                       1233 00115$:
      00765F 7B 7F            [12] 1234 	mov	r3,#_process_action_PARM_2
      007661 7C 08            [12] 1235 	mov	r4,#(_process_action_PARM_2 >> 8)
      007663 12 33 FC         [24] 1236 	lcall	_ak820_outline_0122
      007666 E0               [24] 1237 	movx	a,@dptr
      007667 70 07            [24] 1238 	jnz	00112$
      007669                       1239 00111$:
                                   1240 ;	quantum/action.c:548: del_owned_mods(mods);
      007669 8D 82            [24] 1241 	mov	dpl, r5
      00766B 12 80 4C         [24] 1242 	lcall	_del_owned_mods
      00766E 80 05            [24] 1243 	sjmp	00113$
      007670                       1244 00112$:
                                   1245 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      007670 8D 82            [24] 1246 	mov	dpl, r5
      007672 12 80 6A         [24] 1247 	lcall	_del_owned_weak_mods
      007675                       1248 00113$:
                                   1249 ;	quantum/action.c:552: send_keyboard_report();
      007675 12 83 77         [24] 1250 	lcall	_send_keyboard_report
                                   1251 ;	quantum/action.c:555: } break;
      007678 02 78 46         [24] 1252 	ljmp	00181$
                                   1253 ;	quantum/action.c:632: case ACT_USAGE:
      00767B                       1254 00123$:
                                   1255 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      00767B 74 07            [12] 1256 	mov	a,#0x07
      00767D 12 37 F0         [24] 1257 	lcall	_ak820_outline_0030
      007680 12 37 CB         [24] 1258 	lcall	_ak820_outline_0010
      007683 C3               [12] 1259 	clr	c
      007684 EC               [12] 1260 	mov	a,r4
      007685 94 A5            [12] 1261 	subb	a,#0xa5
      007687 ED               [12] 1262 	mov	a,r5
      007688 94 00            [12] 1263 	subb	a,#0x00
      00768A 40 15            [24] 1264 	jc	00125$
      00768C 74 C2            [12] 1265 	mov	a,#0xc2
      00768E 9C               [12] 1266 	subb	a,r4
      00768F E4               [12] 1267 	clr	a
      007690 9D               [12] 1268 	subb	a,r5
      007691 40 0E            [24] 1269 	jc	00125$
                                   1270 ;	free result
                                   1271 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      007693 90 0A E2         [24] 1272 	mov	dptr,#_owned_usage_key_PARM_2
      007696 E5 28            [12] 1273 	mov	a,_process_action_sloc0_1_0
      007698 F0               [24] 1274 	movx	@dptr,a
      007699 8E 82            [24] 1275 	mov	dpl, r6
      00769B 12 82 22         [24] 1276 	lcall	_owned_usage_key
                                   1277 ;	quantum/action.c:640: break;
      00769E 02 78 46         [24] 1278 	ljmp	00181$
      0076A1                       1279 00125$:
                                   1280 ;	quantum/action.c:643: switch (action.usage.page) {
      0076A1 12 7A 5F         [24] 1281 	lcall	_ak820_outline_0085
      0076A4 FF               [12] 1282 	mov	r7,a
      0076A5 60 08            [24] 1283 	jz	00127$
      0076A7 BF 01 02         [24] 1284 	cjne	r7,#0x01,00452$
      0076AA 80 19            [24] 1285 	sjmp	00128$
      0076AC                       1286 00452$:
      0076AC 02 78 46         [24] 1287 	ljmp	00181$
                                   1288 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0076AF                       1289 00127$:
                                   1290 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0076AF E5 28            [12] 1291 	mov	a,_process_action_sloc0_1_0
      0076B1 60 05            [24] 1292 	jz	00196$
      0076B3 12 7A 76         [24] 1293 	lcall	_ak820_outline_0129
      0076B6 80 04            [24] 1294 	sjmp	00197$
      0076B8                       1295 00196$:
      0076B8 7E 00            [12] 1296 	mov	r6,#0x00
      0076BA 7F 00            [12] 1297 	mov	r7,#0x00
      0076BC                       1298 00197$:
      0076BC 12 46 5D         [24] 1299 	lcall	_ak820_outline_0116
      0076BF 12 70 28         [24] 1300 	lcall	_host_system_send
                                   1301 ;	quantum/action.c:646: break;
      0076C2 02 78 46         [24] 1302 	ljmp	00181$
                                   1303 ;	quantum/action.c:647: case PAGE_CONSUMER:
      0076C5                       1304 00128$:
                                   1305 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      0076C5 E5 28            [12] 1306 	mov	a,_process_action_sloc0_1_0
      0076C7 60 05            [24] 1307 	jz	00198$
      0076C9 12 7A 76         [24] 1308 	lcall	_ak820_outline_0129
      0076CC 80 04            [24] 1309 	sjmp	00199$
      0076CE                       1310 00198$:
      0076CE 7E 00            [12] 1311 	mov	r6,#0x00
      0076D0 7F 00            [12] 1312 	mov	r7,#0x00
      0076D2                       1313 00199$:
      0076D2 12 46 5D         [24] 1314 	lcall	_ak820_outline_0116
      0076D5 12 70 58         [24] 1315 	lcall	_host_consumer_send
                                   1316 ;	quantum/action.c:651: break;
      0076D8 02 78 46         [24] 1317 	ljmp	00181$
                                   1318 ;	quantum/action.c:658: case ACT_LAYER: {
      0076DB                       1319 00131$:
                                   1320 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      0076DB 90 08 80         [24] 1321 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076DE E0               [24] 1322 	movx	a,@dptr
      0076DF 54 03            [12] 1323 	anl	a,#0x03
      0076E1 90 08 83         [24] 1324 	mov	dptr,#_process_action_on_40000_682
      0076E4 F0               [24] 1325 	movx	@dptr,a
                                   1326 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0076E5 E0               [24] 1327 	movx	a,@dptr
      0076E6 FF               [12] 1328 	mov	r7,a
      0076E7 60 11            [24] 1329 	jz	00200$
      0076E9 E5 28            [12] 1330 	mov	a,_process_action_sloc0_1_0
      0076EB 60 07            [24] 1331 	jz	00202$
      0076ED 8F 06            [24] 1332 	mov	ar6,r7
      0076EF 53 06 01         [24] 1333 	anl	ar6,#0x01
      0076F2 80 10            [24] 1334 	sjmp	00201$
      0076F4                       1335 00202$:
      0076F4 74 02            [12] 1336 	mov	a,#0x02
      0076F6 5F               [12] 1337 	anl	a,r7
      0076F7 FE               [12] 1338 	mov	r6,a
      0076F8 80 0A            [24] 1339 	sjmp	00201$
      0076FA                       1340 00200$:
      0076FA E5 28            [12] 1341 	mov	a,_process_action_sloc0_1_0
      0076FC B4 01 00         [24] 1342 	cjne	a,#0x01,00457$
      0076FF                       1343 00457$:
      0076FF 92 1F            [24] 1344 	mov  _process_action_sloc1_1_0,c
      007701 E4               [12] 1345 	clr	a
      007702 33               [12] 1346 	rlc	a
      007703 FE               [12] 1347 	mov	r6,a
      007704                       1348 00201$:
      007704 EE               [12] 1349 	mov	a,r6
      007705 70 03            [24] 1350 	jnz	00458$
      007707 02 78 46         [24] 1351 	ljmp	00181$
      00770A                       1352 00458$:
                                   1353 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      00770A 12 7A 81         [24] 1354 	lcall	_ak820_outline_0154
      00770D C4               [12] 1355 	swap	a
      00770E 03               [12] 1356 	rr	a
      00770F 54 07            [12] 1357 	anl	a,#0x07
      007711 25 E0            [12] 1358 	add	a,acc
      007713 25 E0            [12] 1359 	add	a,acc
      007715 FF               [12] 1360 	mov	r7,a
                                   1361 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007716 12 7A 81         [24] 1362 	lcall	_ak820_outline_0154
      007719 54 0F            [12] 1363 	anl	a,#0x0f
      00771B FE               [12] 1364 	mov	r6,a
      00771C 8F F0            [24] 1365 	mov	b,r7
      00771E 05 F0            [12] 1366 	inc	b
      007720 EE               [12] 1367 	mov	a,r6
      007721 80 02            [24] 1368 	sjmp	00460$
      007723                       1369 00459$:
      007723 25 E0            [12] 1370 	add	a,acc
      007725                       1371 00460$:
      007725 D5 F0 FB         [24] 1372 	djnz	b,00459$
      007728 FE               [12] 1373 	mov	r6,a
                                   1374 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007729 12 7A 81         [24] 1375 	lcall	_ak820_outline_0154
      00772C 30 E4 11         [24] 1376 	jnb	acc.4,00204$
      00772F 8F F0            [24] 1377 	mov	b,r7
      007731 05 F0            [12] 1378 	inc	b
      007733 74 0F            [12] 1379 	mov	a,#0x0f
      007735 80 02            [24] 1380 	sjmp	00463$
      007737                       1381 00462$:
      007737 25 E0            [12] 1382 	add	a,acc
      007739                       1383 00463$:
      007739 D5 F0 FB         [24] 1384 	djnz	b,00462$
      00773C F4               [12] 1385 	cpl	a
      00773D FF               [12] 1386 	mov	r7,a
      00773E 80 02            [24] 1387 	sjmp	00205$
      007740                       1388 00204$:
      007740 7F 00            [12] 1389 	mov	r7,#0x00
      007742                       1390 00205$:
                                   1391 ;	quantum/action.c:666: bits |= mask;
      007742 EE               [12] 1392 	mov	a,r6
      007743 42 07            [12] 1393 	orl	ar7,a
                                   1394 ;	quantum/action.c:667: if (!on) {
      007745 90 08 83         [24] 1395 	mov	dptr,#_process_action_on_40000_682
      007748 E0               [24] 1396 	movx	a,@dptr
      007749 70 31            [24] 1397 	jnz	00143$
                                   1398 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      00774B 12 7A 5F         [24] 1399 	lcall	_ak820_outline_0085
      00774E FE               [12] 1400 	mov	r6,a
      00774F 2E               [12] 1401 	add	a,r6
                                   1402 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      007750 90 77 54         [24] 1403 	mov	dptr,#00465$
      007753 73               [24] 1404 	jmp	@a+dptr
      007754                       1405 00465$:
      007754 80 06            [24] 1406 	sjmp	00132$
      007756 80 0C            [24] 1407 	sjmp	00133$
      007758 80 12            [24] 1408 	sjmp	00134$
      00775A 80 18            [24] 1409 	sjmp	00135$
      00775C                       1410 00132$:
      00775C 8F 82            [24] 1411 	mov	dpl, r7
      00775E 12 7A E1         [24] 1412 	lcall	_default_layer_and
      007761 02 78 46         [24] 1413 	ljmp	00181$
                                   1414 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      007764                       1415 00133$:
      007764 8F 82            [24] 1416 	mov	dpl, r7
      007766 12 7A D0         [24] 1417 	lcall	_default_layer_or
      007769 02 78 46         [24] 1418 	ljmp	00181$
                                   1419 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      00776C                       1420 00134$:
      00776C 8F 82            [24] 1421 	mov	dpl, r7
      00776E 12 7A F7         [24] 1422 	lcall	_default_layer_xor
      007771 02 78 46         [24] 1423 	ljmp	00181$
                                   1424 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      007774                       1425 00135$:
      007774 8F 82            [24] 1426 	mov	dpl, r7
      007776 12 7A C5         [24] 1427 	lcall	_default_layer_set
                                   1428 ;	quantum/action.c:673: }
      007779 02 78 46         [24] 1429 	ljmp	00181$
      00777C                       1430 00143$:
                                   1431 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      00777C 12 7A 5F         [24] 1432 	lcall	_ak820_outline_0085
      00777F FE               [12] 1433 	mov	r6,a
      007780 2E               [12] 1434 	add	a,r6
                                   1435 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      007781 90 77 85         [24] 1436 	mov	dptr,#00466$
      007784 73               [24] 1437 	jmp	@a+dptr
      007785                       1438 00466$:
      007785 80 06            [24] 1439 	sjmp	00137$
      007787 80 0C            [24] 1440 	sjmp	00138$
      007789 80 12            [24] 1441 	sjmp	00139$
      00778B 80 18            [24] 1442 	sjmp	00140$
      00778D                       1443 00137$:
      00778D 8F 82            [24] 1444 	mov	dpl, r7
      00778F 12 7C 7A         [24] 1445 	lcall	_layer_and
      007792 02 78 46         [24] 1446 	ljmp	00181$
                                   1447 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      007795                       1448 00138$:
      007795 8F 82            [24] 1449 	mov	dpl, r7
      007797 12 7C 69         [24] 1450 	lcall	_layer_or
      00779A 02 78 46         [24] 1451 	ljmp	00181$
                                   1452 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      00779D                       1453 00139$:
      00779D 8F 82            [24] 1454 	mov	dpl, r7
      00779F 12 7C 90         [24] 1455 	lcall	_layer_xor
      0077A2 02 78 46         [24] 1456 	ljmp	00181$
                                   1457 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      0077A5                       1458 00140$:
      0077A5 8F 82            [24] 1459 	mov	dpl, r7
      0077A7 12 7C 06         [24] 1460 	lcall	_layer_state_set
                                   1461 ;	quantum/action.c:683: break;
      0077AA 02 78 46         [24] 1462 	ljmp	00181$
                                   1463 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      0077AD                       1464 00147$:
                                   1465 ;	quantum/action.c:686: if (pressed) {
      0077AD E5 28            [12] 1466 	mov	a,_process_action_sloc0_1_0
      0077AF 60 11            [24] 1467 	jz	00149$
                                   1468 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      0077B1 12 7A 6F         [24] 1469 	lcall	_ak820_outline_0109
      0077B4 F5 82            [12] 1470 	mov	dpl,a
      0077B6 12 7B 67         [24] 1471 	lcall	_layer_hold_on
                                   1472 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      0077B9 12 7A 58         [24] 1473 	lcall	_ak820_outline_0075
      0077BC 12 79 9B         [24] 1474 	lcall	_register_mods
      0077BF 02 78 46         [24] 1475 	ljmp	00181$
      0077C2                       1476 00149$:
                                   1477 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      0077C2 12 7A 58         [24] 1478 	lcall	_ak820_outline_0075
      0077C5 12 79 AF         [24] 1479 	lcall	_unregister_mods
                                   1480 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      0077C8 12 7A 6F         [24] 1481 	lcall	_ak820_outline_0109
      0077CB F5 82            [12] 1482 	mov	dpl,a
      0077CD 12 7B 9F         [24] 1483 	lcall	_layer_hold_off
                                   1484 ;	quantum/action.c:693: break;
      0077D0 02 78 46         [24] 1485 	ljmp	00181$
                                   1486 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      0077D3                       1487 00152$:
                                   1488 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      0077D3 12 7A 81         [24] 1489 	lcall	_ak820_outline_0154
      0077D6 FF               [12] 1490 	mov	r7,a
      0077D7 BF F1 02         [24] 1491 	cjne	r7,#0xf1,00468$
      0077DA 80 0A            [24] 1492 	sjmp	00154$
      0077DC                       1493 00468$:
      0077DC BF F2 02         [24] 1494 	cjne	r7,#0xf2,00469$
      0077DF 80 19            [24] 1495 	sjmp	00155$
      0077E1                       1496 00469$:
                                   1497 ;	quantum/action.c:712: momentary_layer_action:
      0077E1 BF F3 3B         [24] 1498 	cjne	r7,#0xf3,00160$
      0077E4 80 28            [24] 1499 	sjmp	00156$
      0077E6                       1500 00154$:
                                   1501 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0077E6 E5 28            [12] 1502 	mov	a,_process_action_sloc0_1_0
      0077E8 60 08            [24] 1503 	jz	00206$
      0077EA 12 7A 3F         [24] 1504 	lcall	_ak820_outline_0038
      0077ED 12 7B 67         [24] 1505 	lcall	_layer_hold_on
      0077F0 80 54            [24] 1506 	sjmp	00181$
      0077F2                       1507 00206$:
      0077F2 12 7A 3F         [24] 1508 	lcall	_ak820_outline_0038
      0077F5 12 7B 9F         [24] 1509 	lcall	_layer_hold_off
                                   1510 ;	quantum/action.c:714: break;
                                   1511 ;	quantum/action.c:715: case OP_OFF_ON:
      0077F8 80 4C            [24] 1512 	sjmp	00181$
      0077FA                       1513 00155$:
                                   1514 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0077FA E5 28            [12] 1515 	mov	a,_process_action_sloc0_1_0
      0077FC 60 08            [24] 1516 	jz	00208$
      0077FE 12 7A 3F         [24] 1517 	lcall	_ak820_outline_0038
      007801 12 7C 4B         [24] 1518 	lcall	_layer_off
      007804 80 40            [24] 1519 	sjmp	00181$
      007806                       1520 00208$:
      007806 12 7A 3F         [24] 1521 	lcall	_ak820_outline_0038
      007809 12 7C 30         [24] 1522 	lcall	_layer_on
                                   1523 ;	quantum/action.c:717: break;
                                   1524 ;	quantum/action.c:718: case OP_SET_CLEAR:
      00780C 80 38            [24] 1525 	sjmp	00181$
      00780E                       1526 00156$:
                                   1527 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00780E E5 28            [12] 1528 	mov	a,_process_action_sloc0_1_0
      007810 60 08            [24] 1529 	jz	00210$
      007812 12 7A 3F         [24] 1530 	lcall	_ak820_outline_0038
      007815 12 7C 1A         [24] 1531 	lcall	_layer_move
      007818 80 2C            [24] 1532 	sjmp	00181$
      00781A                       1533 00210$:
      00781A 12 7C 14         [24] 1534 	lcall	_layer_clear
                                   1535 ;	quantum/action.c:720: break;
                                   1536 ;	quantum/action.c:766: default:
      00781D 80 27            [24] 1537 	sjmp	00181$
      00781F                       1538 00160$:
                                   1539 ;	quantum/action.c:773: if (pressed) {
      00781F E5 28            [12] 1540 	mov	a,_process_action_sloc0_1_0
      007821 60 08            [24] 1541 	jz	00163$
                                   1542 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007823 12 7A 58         [24] 1543 	lcall	_ak820_outline_0075
      007826 12 78 5D         [24] 1544 	lcall	_register_code
                                   1545 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007829 80 1B            [24] 1546 	sjmp	00181$
      00782B                       1547 00163$:
                                   1548 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      00782B 12 7A 81         [24] 1549 	lcall	_ak820_outline_0154
      00782E FF               [12] 1550 	mov	r7,a
      00782F BF 39 0E         [24] 1551 	cjne	r7,#0x39,00175$
                                   1552 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      007832 7F 50            [12] 1553 	mov	r7,#0x50
      007834                       1554 00187$:
      007834 EF               [12] 1555 	mov	a,r7
      007835 60 09            [24] 1556 	jz	00175$
      007837 90 00 01         [24] 1557 	mov	dptr,#0x0001
      00783A 12 5B E0         [24] 1558 	lcall	_mDelaymS
      00783D 1F               [12] 1559 	dec	r7
                                   1560 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      00783E 80 F4            [24] 1561 	sjmp	00187$
      007840                       1562 00175$:
                                   1563 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      007840 12 7A 58         [24] 1564 	lcall	_ak820_outline_0075
      007843 12 78 D9         [24] 1565 	lcall	_unregister_code
                                   1566 ;	quantum/action.c:866: }
      007846                       1567 00181$:
                                   1568 ;	quantum/action.c:887: switch (action.kind.id) {
      007846 90 08 80         [24] 1569 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007849 E0               [24] 1570 	movx	a,@dptr
      00784A C4               [12] 1571 	swap	a
      00784B 54 0F            [12] 1572 	anl	a,#0x0f
      00784D FF               [12] 1573 	mov	r7,a
      00784E BF 08 02         [24] 1574 	cjne	r7,#0x08,00478$
      007851 80 03            [24] 1575 	sjmp	00183$
      007853                       1576 00478$:
      007853 BF 09 06         [24] 1577 	cjne	r7,#0x09,00192$
                                   1578 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007856                       1579 00183$:
                                   1580 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007856 12 6F 8D         [24] 1581 	lcall	_host_keyboard_leds
                                   1582 ;	quantum/action.c:898: }
                                   1583 ;	quantum/action.c:951: }
      007859 02 9A DB         [24] 1584 	ljmp	_led_set
      00785C                       1585 00192$:
      00785C 22               [24] 1586 	ret
                                   1587 ;------------------------------------------------------------
                                   1588 ;Allocation info for local variables in function 'register_code'
                                   1589 ;------------------------------------------------------------
                                   1590 ;code          Allocated with name '_register_code_code_10000_716'
                                   1591 ;------------------------------------------------------------
                                   1592 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1593 ;	-----------------------------------------
                                   1594 ;	 function register_code
                                   1595 ;	-----------------------------------------
      00785D                       1596 _register_code:
      00785D E5 82            [12] 1597 	mov	a,dpl
      00785F 90 08 84         [24] 1598 	mov	dptr,#_register_code_code_10000_716
      007862 F0               [24] 1599 	movx	@dptr,a
                                   1600 ;	quantum/action.c:958: if (code == KC_NO) {
      007863 E0               [24] 1601 	movx	a,@dptr
      007864 FF               [12] 1602 	mov	r7,a
      007865 70 01            [24] 1603 	jnz	00123$
                                   1604 ;	quantum/action.c:959: return;
      007867 22               [24] 1605 	ret
      007868                       1606 00123$:
                                   1607 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007868 BF 04 00         [24] 1608 	cjne	r7,#0x04,00186$
      00786B                       1609 00186$:
      00786B 40 21            [24] 1610 	jc	00119$
      00786D EF               [12] 1611 	mov	a,r7
      00786E 24 5B            [12] 1612 	add	a,#0xff - 0xa4
      007870 40 1C            [24] 1613 	jc	00119$
                                   1614 ;	free result
                                   1615 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      007872 8F 82            [24] 1616 	mov	dpl, r7
      007874 C0 07            [24] 1617 	push	ar7
      007876 12 80 DF         [24] 1618 	lcall	_add_owned_key
      007879 E5 82            [12] 1619 	mov	a, dpl
      00787B D0 07            [24] 1620 	pop	ar7
      00787D 70 01            [24] 1621 	jnz	00104$
      00787F 22               [24] 1622 	ret
      007880                       1623 00104$:
                                   1624 ;	quantum/action.c:1001: ak820_dynamic_macro_observe(code, true);
      007880 90 04 AD         [24] 1625 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007883 74 01            [12] 1626 	mov	a,#0x01
      007885 F0               [24] 1627 	movx	@dptr,a
      007886 8F 82            [24] 1628 	mov	dpl, r7
      007888 12 39 F5         [24] 1629 	lcall	_ak820_dynamic_macro_observe
                                   1630 ;	quantum/action.c:1013: send_keyboard_report();
      00788B 02 83 77         [24] 1631 	ljmp	_send_keyboard_report
      00788E                       1632 00119$:
                                   1633 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      00788E 12 7A 86         [24] 1634 	lcall	_ak820_outline_0162
      007891 BF E0 00         [24] 1635 	cjne	r7,#0xe0,00190$
      007894                       1636 00190$:
      007894 40 1A            [24] 1637 	jc	00115$
      007896 EF               [12] 1638 	mov	a,r7
      007897 24 18            [12] 1639 	add	a,#0xff - 0xe7
      007899 40 15            [24] 1640 	jc	00115$
                                   1641 ;	free result
                                   1642 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      00789B 74 07            [12] 1643 	mov	a,#0x07
      00789D 5F               [12] 1644 	anl	a,r7
      00789E 12 7A 51         [24] 1645 	lcall	_ak820_outline_0062
      0078A1 80 02            [24] 1646 	sjmp	00194$
      0078A3                       1647 00193$:
      0078A3 25 E0            [12] 1648 	add	a,acc
      0078A5                       1649 00194$:
      0078A5 D5 F0 FB         [24] 1650 	djnz	b,00193$
      0078A8 F5 82            [12] 1651 	mov	dpl,a
      0078AA 12 80 3C         [24] 1652 	lcall	_add_owned_mods
                                   1653 ;	quantum/action.c:1016: send_keyboard_report();
      0078AD 02 83 77         [24] 1654 	ljmp	_send_keyboard_report
      0078B0                       1655 00115$:
                                   1656 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0078B0 12 7A 86         [24] 1657 	lcall	_ak820_outline_0162
      0078B3 BF A5 00         [24] 1658 	cjne	r7,#0xa5,00195$
      0078B6                       1659 00195$:
      0078B6 40 05            [24] 1660 	jc	00113$
      0078B8 EF               [12] 1661 	mov	a,r7
      0078B9 24 58            [12] 1662 	add	a,#0xff - 0xa7
      0078BB 50 0D            [24] 1663 	jnc	00108$
                                   1664 ;	free result
      0078BD                       1665 00113$:
      0078BD 12 7A 86         [24] 1666 	lcall	_ak820_outline_0162
      0078C0 BF A8 00         [24] 1667 	cjne	r7,#0xa8,00198$
      0078C3                       1668 00198$:
      0078C3 40 13            [24] 1669 	jc	00125$
      0078C5 EF               [12] 1670 	mov	a,r7
      0078C6 24 3D            [12] 1671 	add	a,#0xff - 0xc2
      0078C8 40 0E            [24] 1672 	jc	00125$
                                   1673 ;	free result
      0078CA                       1674 00108$:
                                   1675 ;	quantum/action.c:1021: owned_usage_key(code, true);
      0078CA 12 7A 86         [24] 1676 	lcall	_ak820_outline_0162
      0078CD 90 0A E2         [24] 1677 	mov	dptr,#_owned_usage_key_PARM_2
      0078D0 74 01            [12] 1678 	mov	a,#0x01
      0078D2 F0               [24] 1679 	movx	@dptr,a
      0078D3 8F 82            [24] 1680 	mov	dpl, r7
                                   1681 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1682 ;	quantum/action.c:1031: }
      0078D5 02 82 22         [24] 1683 	ljmp	_owned_usage_key
      0078D8                       1684 00125$:
      0078D8 22               [24] 1685 	ret
                                   1686 ;------------------------------------------------------------
                                   1687 ;Allocation info for local variables in function 'unregister_code'
                                   1688 ;------------------------------------------------------------
                                   1689 ;code          Allocated with name '_unregister_code_code_10000_730'
                                   1690 ;------------------------------------------------------------
                                   1691 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1692 ;	-----------------------------------------
                                   1693 ;	 function unregister_code
                                   1694 ;	-----------------------------------------
      0078D9                       1695 _unregister_code:
      0078D9 E5 82            [12] 1696 	mov	a,dpl
      0078DB 90 08 85         [24] 1697 	mov	dptr,#_unregister_code_code_10000_730
      0078DE F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	quantum/action.c:1038: if (code == KC_NO) {
      0078DF E0               [24] 1700 	movx	a,@dptr
      0078E0 FF               [12] 1701 	mov	r7,a
      0078E1 70 01            [24] 1702 	jnz	00121$
                                   1703 ;	quantum/action.c:1039: return;
      0078E3 22               [24] 1704 	ret
      0078E4                       1705 00121$:
                                   1706 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      0078E4 BF 04 00         [24] 1707 	cjne	r7,#0x04,00184$
      0078E7                       1708 00184$:
      0078E7 40 1F            [24] 1709 	jc	00117$
      0078E9 EF               [12] 1710 	mov	a,r7
      0078EA 24 5B            [12] 1711 	add	a,#0xff - 0xa4
      0078EC 40 1A            [24] 1712 	jc	00117$
                                   1713 ;	free result
                                   1714 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      0078EE 8F 82            [24] 1715 	mov	dpl, r7
      0078F0 C0 07            [24] 1716 	push	ar7
      0078F2 12 81 59         [24] 1717 	lcall	_del_owned_key
      0078F5 E5 82            [12] 1718 	mov	a, dpl
      0078F7 D0 07            [24] 1719 	pop	ar7
      0078F9 70 01            [24] 1720 	jnz	00102$
      0078FB 22               [24] 1721 	ret
      0078FC                       1722 00102$:
                                   1723 ;	quantum/action.c:1075: ak820_dynamic_macro_observe(code, false);
      0078FC 90 04 AD         [24] 1724 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      0078FF 12 7A 92         [24] 1725 	lcall	_ak820_outline_0184
      007902 12 39 F5         [24] 1726 	lcall	_ak820_dynamic_macro_observe
                                   1727 ;	quantum/action.c:1080: send_keyboard_report();
      007905 02 83 77         [24] 1728 	ljmp	_send_keyboard_report
      007908                       1729 00117$:
                                   1730 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007908 12 7A 8C         [24] 1731 	lcall	_ak820_outline_0163
      00790B BF E0 00         [24] 1732 	cjne	r7,#0xe0,00188$
      00790E                       1733 00188$:
      00790E 40 1A            [24] 1734 	jc	00113$
      007910 EF               [12] 1735 	mov	a,r7
      007911 24 18            [12] 1736 	add	a,#0xff - 0xe7
      007913 40 15            [24] 1737 	jc	00113$
                                   1738 ;	free result
                                   1739 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007915 74 07            [12] 1740 	mov	a,#0x07
      007917 5F               [12] 1741 	anl	a,r7
      007918 12 7A 51         [24] 1742 	lcall	_ak820_outline_0062
      00791B 80 02            [24] 1743 	sjmp	00192$
      00791D                       1744 00191$:
      00791D 25 E0            [12] 1745 	add	a,acc
      00791F                       1746 00192$:
      00791F D5 F0 FB         [24] 1747 	djnz	b,00191$
      007922 F5 82            [12] 1748 	mov	dpl,a
      007924 12 80 4C         [24] 1749 	lcall	_del_owned_mods
                                   1750 ;	quantum/action.c:1083: send_keyboard_report();
      007927 02 83 77         [24] 1751 	ljmp	_send_keyboard_report
      00792A                       1752 00113$:
                                   1753 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00792A 12 7A 8C         [24] 1754 	lcall	_ak820_outline_0163
      00792D BF A5 00         [24] 1755 	cjne	r7,#0xa5,00193$
      007930                       1756 00193$:
      007930 40 05            [24] 1757 	jc	00111$
      007932 EF               [12] 1758 	mov	a,r7
      007933 24 58            [12] 1759 	add	a,#0xff - 0xa7
      007935 50 0D            [24] 1760 	jnc	00106$
                                   1761 ;	free result
      007937                       1762 00111$:
      007937 12 7A 8C         [24] 1763 	lcall	_ak820_outline_0163
      00793A BF A8 00         [24] 1764 	cjne	r7,#0xa8,00196$
      00793D                       1765 00196$:
      00793D 40 11            [24] 1766 	jc	00123$
      00793F EF               [12] 1767 	mov	a,r7
      007940 24 3D            [12] 1768 	add	a,#0xff - 0xc2
      007942 40 0C            [24] 1769 	jc	00123$
                                   1770 ;	free result
      007944                       1771 00106$:
                                   1772 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007944 12 7A 8C         [24] 1773 	lcall	_ak820_outline_0163
      007947 90 0A E2         [24] 1774 	mov	dptr,#_owned_usage_key_PARM_2
      00794A 12 7A 92         [24] 1775 	lcall	_ak820_outline_0184
                                   1776 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1777 ;	quantum/action.c:1098: }
      00794D 02 82 22         [24] 1778 	ljmp	_owned_usage_key
      007950                       1779 00123$:
      007950 22               [24] 1780 	ret
                                   1781 ;------------------------------------------------------------
                                   1782 ;Allocation info for local variables in function 'tap_code_delay'
                                   1783 ;------------------------------------------------------------
                                   1784 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1785 ;code          Allocated with name '_tap_code_delay_code_10000_743'
                                   1786 ;i             Allocated with name '_tap_code_delay_i_20000_745'
                                   1787 ;i             Allocated with name '_tap_code_delay_i_50000_748'
                                   1788 ;------------------------------------------------------------
                                   1789 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1790 ;	-----------------------------------------
                                   1791 ;	 function tap_code_delay
                                   1792 ;	-----------------------------------------
      007951                       1793 _tap_code_delay:
      007951 E5 82            [12] 1794 	mov	a,dpl
      007953 90 08 88         [24] 1795 	mov	dptr,#_tap_code_delay_code_10000_743
      007956 F0               [24] 1796 	movx	@dptr,a
                                   1797 ;	quantum/action.c:1106: register_code(code);
      007957 E0               [24] 1798 	movx	a,@dptr
      007958 FF               [12] 1799 	mov	r7,a
      007959 F5 82            [12] 1800 	mov	dpl,a
      00795B C0 07            [24] 1801 	push	ar7
      00795D 12 78 5D         [24] 1802 	lcall	_register_code
      007960 D0 07            [24] 1803 	pop	ar7
                                   1804 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007962 90 08 86         [24] 1805 	mov	dptr,#_tap_code_delay_PARM_2
      007965 12 46 4B         [24] 1806 	lcall	_ak820_outline_0098
      007968                       1807 00110$:
      007968 ED               [12] 1808 	mov	a,r5
      007969 4E               [12] 1809 	orl	a,r6
      00796A 60 0D            [24] 1810 	jz	00105$
                                   1811 ;	quantum/action.c:1108: wait_ms(1);
      00796C 90 00 01         [24] 1812 	mov	dptr,#0x0001
      00796F 12 5B E0         [24] 1813 	lcall	_mDelaymS
                                   1814 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007972 1D               [12] 1815 	dec	r5
      007973 BD FF 01         [24] 1816 	cjne	r5,#0xff,00141$
      007976 1E               [12] 1817 	dec	r6
      007977                       1818 00141$:
      007977 80 EF            [24] 1819 	sjmp	00110$
      007979                       1820 00105$:
                                   1821 ;	quantum/action.c:1110: unregister_code(code);
      007979 8F 82            [24] 1822 	mov	dpl, r7
                                   1823 ;	quantum/action.c:1111: }
      00797B 02 78 D9         [24] 1824 	ljmp	_unregister_code
                                   1825 ;------------------------------------------------------------
                                   1826 ;Allocation info for local variables in function 'tap_code'
                                   1827 ;------------------------------------------------------------
                                   1828 ;code          Allocated with name '_tap_code_code_10000_750'
                                   1829 ;------------------------------------------------------------
                                   1830 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1831 ;	-----------------------------------------
                                   1832 ;	 function tap_code
                                   1833 ;	-----------------------------------------
      00797E                       1834 _tap_code:
      00797E E5 82            [12] 1835 	mov	a,dpl
      007980 90 08 89         [24] 1836 	mov	dptr,#_tap_code_code_10000_750
      007983 F0               [24] 1837 	movx	@dptr,a
                                   1838 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007984 E0               [24] 1839 	movx	a,@dptr
      007985 FF               [12] 1840 	mov	r7,a
      007986 BF 39 04         [24] 1841 	cjne	r7,#0x39,00103$
      007989 7E 50            [12] 1842 	mov	r6,#0x50
      00798B 80 02            [24] 1843 	sjmp	00104$
      00798D                       1844 00103$:
      00798D 7E 00            [12] 1845 	mov	r6,#0x00
      00798F                       1846 00104$:
      00798F 90 08 86         [24] 1847 	mov	dptr,#_tap_code_delay_PARM_2
      007992 EE               [12] 1848 	mov	a,r6
      007993 12 38 65         [24] 1849 	lcall	_ak820_outline_0123
      007996 8F 82            [24] 1850 	mov	dpl, r7
                                   1851 ;	quantum/action.c:1119: }
      007998 02 79 51         [24] 1852 	ljmp	_tap_code_delay
                                   1853 ;------------------------------------------------------------
                                   1854 ;Allocation info for local variables in function 'register_mods'
                                   1855 ;------------------------------------------------------------
                                   1856 ;mods          Allocated with name '_register_mods_mods_10000_752'
                                   1857 ;------------------------------------------------------------
                                   1858 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1859 ;	-----------------------------------------
                                   1860 ;	 function register_mods
                                   1861 ;	-----------------------------------------
      00799B                       1862 _register_mods:
      00799B E5 82            [12] 1863 	mov	a,dpl
      00799D 90 08 8A         [24] 1864 	mov	dptr,#_register_mods_mods_10000_752
      0079A0 F0               [24] 1865 	movx	@dptr,a
                                   1866 ;	quantum/action.c:1126: if (mods) {
      0079A1 E0               [24] 1867 	movx	a,@dptr
      0079A2 FF               [12] 1868 	mov	r7,a
      0079A3 E0               [24] 1869 	movx	a,@dptr
      0079A4 60 08            [24] 1870 	jz	00103$
                                   1871 ;	quantum/action.c:1127: add_owned_mods(mods);
      0079A6 8F 82            [24] 1872 	mov	dpl, r7
      0079A8 12 80 3C         [24] 1873 	lcall	_add_owned_mods
                                   1874 ;	quantum/action.c:1128: send_keyboard_report();
                                   1875 ;	quantum/action.c:1130: }
      0079AB 02 83 77         [24] 1876 	ljmp	_send_keyboard_report
      0079AE                       1877 00103$:
      0079AE 22               [24] 1878 	ret
                                   1879 ;------------------------------------------------------------
                                   1880 ;Allocation info for local variables in function 'unregister_mods'
                                   1881 ;------------------------------------------------------------
                                   1882 ;mods          Allocated with name '_unregister_mods_mods_10000_756'
                                   1883 ;------------------------------------------------------------
                                   1884 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1885 ;	-----------------------------------------
                                   1886 ;	 function unregister_mods
                                   1887 ;	-----------------------------------------
      0079AF                       1888 _unregister_mods:
      0079AF E5 82            [12] 1889 	mov	a,dpl
      0079B1 90 08 8B         [24] 1890 	mov	dptr,#_unregister_mods_mods_10000_756
      0079B4 F0               [24] 1891 	movx	@dptr,a
                                   1892 ;	quantum/action.c:1137: if (mods) {
      0079B5 E0               [24] 1893 	movx	a,@dptr
      0079B6 FF               [12] 1894 	mov	r7,a
      0079B7 E0               [24] 1895 	movx	a,@dptr
      0079B8 60 08            [24] 1896 	jz	00103$
                                   1897 ;	quantum/action.c:1138: del_owned_mods(mods);
      0079BA 8F 82            [24] 1898 	mov	dpl, r7
      0079BC 12 80 4C         [24] 1899 	lcall	_del_owned_mods
                                   1900 ;	quantum/action.c:1139: send_keyboard_report();
                                   1901 ;	quantum/action.c:1141: }
      0079BF 02 83 77         [24] 1902 	ljmp	_send_keyboard_report
      0079C2                       1903 00103$:
      0079C2 22               [24] 1904 	ret
                                   1905 ;------------------------------------------------------------
                                   1906 ;Allocation info for local variables in function 'register_weak_mods'
                                   1907 ;------------------------------------------------------------
                                   1908 ;mods          Allocated with name '_register_weak_mods_mods_10000_760'
                                   1909 ;------------------------------------------------------------
                                   1910 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1911 ;	-----------------------------------------
                                   1912 ;	 function register_weak_mods
                                   1913 ;	-----------------------------------------
      0079C3                       1914 _register_weak_mods:
      0079C3 E5 82            [12] 1915 	mov	a,dpl
      0079C5 90 08 8C         [24] 1916 	mov	dptr,#_register_weak_mods_mods_10000_760
      0079C8 F0               [24] 1917 	movx	@dptr,a
                                   1918 ;	quantum/action.c:1148: if (mods) {
      0079C9 E0               [24] 1919 	movx	a,@dptr
      0079CA FF               [12] 1920 	mov	r7,a
      0079CB E0               [24] 1921 	movx	a,@dptr
      0079CC 60 08            [24] 1922 	jz	00103$
                                   1923 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      0079CE 8F 82            [24] 1924 	mov	dpl, r7
      0079D0 12 80 5A         [24] 1925 	lcall	_add_owned_weak_mods
                                   1926 ;	quantum/action.c:1150: send_keyboard_report();
                                   1927 ;	quantum/action.c:1152: }
      0079D3 02 83 77         [24] 1928 	ljmp	_send_keyboard_report
      0079D6                       1929 00103$:
      0079D6 22               [24] 1930 	ret
                                   1931 ;------------------------------------------------------------
                                   1932 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1933 ;------------------------------------------------------------
                                   1934 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_764'
                                   1935 ;------------------------------------------------------------
                                   1936 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1937 ;	-----------------------------------------
                                   1938 ;	 function unregister_weak_mods
                                   1939 ;	-----------------------------------------
      0079D7                       1940 _unregister_weak_mods:
      0079D7 E5 82            [12] 1941 	mov	a,dpl
      0079D9 90 08 8D         [24] 1942 	mov	dptr,#_unregister_weak_mods_mods_10000_764
      0079DC F0               [24] 1943 	movx	@dptr,a
                                   1944 ;	quantum/action.c:1159: if (mods) {
      0079DD E0               [24] 1945 	movx	a,@dptr
      0079DE FF               [12] 1946 	mov	r7,a
      0079DF E0               [24] 1947 	movx	a,@dptr
      0079E0 60 08            [24] 1948 	jz	00103$
                                   1949 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      0079E2 8F 82            [24] 1950 	mov	dpl, r7
      0079E4 12 80 6A         [24] 1951 	lcall	_del_owned_weak_mods
                                   1952 ;	quantum/action.c:1161: send_keyboard_report();
                                   1953 ;	quantum/action.c:1163: }
      0079E7 02 83 77         [24] 1954 	ljmp	_send_keyboard_report
      0079EA                       1955 00103$:
      0079EA 22               [24] 1956 	ret
                                   1957 ;------------------------------------------------------------
                                   1958 ;Allocation info for local variables in function 'clear_keyboard'
                                   1959 ;------------------------------------------------------------
                                   1960 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1961 ;	-----------------------------------------
                                   1962 ;	 function clear_keyboard
                                   1963 ;	-----------------------------------------
      0079EB                       1964 _clear_keyboard:
                                   1965 ;	quantum/action.c:1170: clear_mods();
      0079EB 12 83 FB         [24] 1966 	lcall	_clear_mods
                                   1967 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1968 ;	quantum/action.c:1172: }
      0079EE 02 79 F1         [24] 1969 	ljmp	_clear_keyboard_but_mods
                                   1970 ;------------------------------------------------------------
                                   1971 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1972 ;------------------------------------------------------------
                                   1973 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1974 ;	-----------------------------------------
                                   1975 ;	 function clear_keyboard_but_mods
                                   1976 ;	-----------------------------------------
      0079F1                       1977 _clear_keyboard_but_mods:
                                   1978 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0079F1 90 0D EE         [24] 1979 	mov	dptr,#_actual_keyboard_report
      0079F4 12 72 4E         [24] 1980 	lcall	_clear_keys_from_report
                                   1981 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1982 ;	quantum/action.c:1181: }
      0079F7 02 79 FA         [24] 1983 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1984 ;------------------------------------------------------------
                                   1985 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1986 ;------------------------------------------------------------
                                   1987 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1988 ;	-----------------------------------------
                                   1989 ;	 function clear_keyboard_but_mods_and_keys
                                   1990 ;	-----------------------------------------
      0079FA                       1991 _clear_keyboard_but_mods_and_keys:
                                   1992 ;	quantum/action.c:1189: ak820_tapping_cancel();
      0079FA 12 49 C5         [24] 1993 	lcall	_ak820_tapping_cancel
                                   1994 ;	quantum/action.c:1200: ak820_dynamic_macro_cancel();
      0079FD 12 39 36         [24] 1995 	lcall	_ak820_dynamic_macro_cancel
                                   1996 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007A00 12 2E F0         [24] 1997 	lcall	_ak820_oneshot_cancel
                                   1998 ;	quantum/action.c:1209: ak820_combo_cancel();
      007A03 12 35 27         [24] 1999 	lcall	_ak820_combo_cancel
                                   2000 ;	quantum/action.c:1212: repeat_key_cancel();
      007A06 12 A3 ED         [24] 2001 	lcall	_repeat_key_cancel
                                   2002 ;	quantum/action.c:1214: clear_owned_mods();
      007A09 12 80 7A         [24] 2003 	lcall	_clear_owned_mods
                                   2004 ;	quantum/action.c:1215: clear_owned_keys();
      007A0C 12 80 B2         [24] 2005 	lcall	_clear_owned_keys
                                   2006 ;	quantum/action.c:1216: clear_owned_usages();
      007A0F 12 81 EA         [24] 2007 	lcall	_clear_owned_usages
                                   2008 ;	quantum/action.c:1217: layer_hold_clear();
      007A12 12 7B D7         [24] 2009 	lcall	_layer_hold_clear
                                   2010 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007A15 12 9F 6A         [24] 2011 	lcall	_clear_macro_tri_layer
                                   2012 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007A18 90 0D EE         [24] 2013 	mov	dptr,#_actual_keyboard_report
      007A1B 12 72 4E         [24] 2014 	lcall	_clear_keys_from_report
                                   2015 ;	quantum/action.c:1224: host_system_send(0);
      007A1E 90 00 00         [24] 2016 	mov	dptr,#0x0000
      007A21 12 70 28         [24] 2017 	lcall	_host_system_send
                                   2018 ;	quantum/action.c:1225: host_consumer_send(0);
      007A24 90 00 00         [24] 2019 	mov	dptr,#0x0000
      007A27 12 70 58         [24] 2020 	lcall	_host_consumer_send
                                   2021 ;	quantum/action.c:1227: clear_weak_mods();
      007A2A 12 84 30         [24] 2022 	lcall	_clear_weak_mods
                                   2023 ;	quantum/action.c:1228: send_keyboard_report();
                                   2024 ;	quantum/action.c:1236: }
      007A2D 02 83 77         [24] 2025 	ljmp	_send_keyboard_report
                                   2026 ;------------------------------------------------------------
                                   2027 ;Allocation info for local variables in function 'is_tap_record'
                                   2028 ;------------------------------------------------------------
                                   2029 ;record        Allocated with name '_is_tap_record_record_10000_780'
                                   2030 ;action        Allocated with name '_is_tap_record_action_10001_784'
                                   2031 ;------------------------------------------------------------
                                   2032 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   2033 ;	-----------------------------------------
                                   2034 	.area CSEG    (CODE)
                                   2035 	.area CONST   (CODE)
                                   2036 	.area XINIT   (CODE)
      00C352                       2037 __xinit__disable_action_cache:
      00C352 00                    2038 	.db #0x00	;  0
                                   2039 	.area CABS    (ABS,CODE)
                                   2040 
                                   2041 ; Experimental exact instruction outlining.
                                   2042 	.globl _ak820_outline_0004
                                   2043 	.globl _ak820_outline_0008
                                   2044 	.globl _ak820_outline_0009
                                   2045 	.globl _ak820_outline_0010
                                   2046 	.globl _ak820_outline_0011
                                   2047 	.globl _ak820_outline_0016
                                   2048 	.globl _ak820_outline_0017
                                   2049 	.globl _ak820_outline_0019
                                   2050 	.globl _ak820_outline_0030
                                   2051 	.globl _ak820_outline_0038
                                   2052 	.globl _ak820_outline_0043
                                   2053 	.globl _ak820_outline_0050
                                   2054 	.globl _ak820_outline_0051
                                   2055 	.globl _ak820_outline_0057
                                   2056 	.globl _ak820_outline_0060
                                   2057 	.globl _ak820_outline_0062
                                   2058 	.globl _ak820_outline_0070
                                   2059 	.globl _ak820_outline_0074
                                   2060 	.globl _ak820_outline_0075
                                   2061 	.globl _ak820_outline_0085
                                   2062 	.globl _ak820_outline_0093
                                   2063 	.globl _ak820_outline_0094
                                   2064 	.globl _ak820_outline_0098
                                   2065 	.globl _ak820_outline_0104
                                   2066 	.globl _ak820_outline_0105
                                   2067 	.globl _ak820_outline_0107
                                   2068 	.globl _ak820_outline_0108
                                   2069 	.globl _ak820_outline_0109
                                   2070 	.globl _ak820_outline_0116
                                   2071 	.globl _ak820_outline_0121
                                   2072 	.globl _ak820_outline_0122
                                   2073 	.globl _ak820_outline_0123
                                   2074 	.globl _ak820_outline_0129
                                   2075 	.globl _ak820_outline_0139
                                   2076 	.globl _ak820_outline_0140
                                   2077 	.globl _ak820_outline_0141
                                   2078 	.globl _ak820_outline_0154
                                   2079 	.globl _ak820_outline_0162
                                   2080 	.globl _ak820_outline_0163
                                   2081 	.globl _ak820_outline_0178
                                   2082 	.globl _ak820_outline_0184
                                   2083 
                                   2084 	.area CSEG (CODE)
                                   2085 ; function ak820_outline_0019
      007A30                       2086 _ak820_outline_0019:
      007A30 8E 82            [24] 2087 	mov	dpl,r6
      007A32 8F 83            [24] 2088 	mov	dph,r7
      007A34 A3               [24] 2089 	inc	dptr
      007A35 E0               [24] 2090 	movx	a,@dptr
      007A36 FC               [12] 2091 	mov	r4,a
      007A37 7D 00            [12] 2092 	mov	r5,#0x00
      007A39 8E 82            [24] 2093 	mov	dpl,r6
      007A3B 8F 83            [24] 2094 	mov	dph,r7
      007A3D E0               [24] 2095 	movx	a,@dptr
      007A3E 22               [24] 2096 	ret
                                   2097 
                                   2098 	.area CSEG (CODE)
                                   2099 ; function ak820_outline_0038
      007A3F                       2100 _ak820_outline_0038:
      007A3F 90 08 80         [24] 2101 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007A42 E0               [24] 2102 	movx	a,@dptr
      007A43 54 1F            [12] 2103 	anl	a,#0x1f
      007A45 F5 82            [12] 2104 	mov	dpl,a
      007A47 22               [24] 2105 	ret
                                   2106 
                                   2107 	.area CSEG (CODE)
                                   2108 ; function ak820_outline_0050
      007A48                       2109 _ak820_outline_0050:
      007A48 A3               [24] 2110 	inc	dptr
      007A49 F0               [24] 2111 	movx	@dptr,a
      007A4A E4               [12] 2112 	clr	a
      007A4B A3               [24] 2113 	inc	dptr
      007A4C F0               [24] 2114 	movx	@dptr,a
      007A4D 90 0D CC         [24] 2115 	mov	dptr,#___memcpy_PARM_3
      007A50 22               [24] 2116 	ret
                                   2117 
                                   2118 	.area CSEG (CODE)
                                   2119 ; function ak820_outline_0062
      007A51                       2120 _ak820_outline_0062:
      007A51 F5 F0            [12] 2121 	mov	b,a
      007A53 05 F0            [12] 2122 	inc	b
      007A55 74 01            [12] 2123 	mov	a,#0x01
      007A57 22               [24] 2124 	ret
                                   2125 
                                   2126 	.area CSEG (CODE)
                                   2127 ; function ak820_outline_0075
      007A58                       2128 _ak820_outline_0075:
      007A58 90 08 7F         [24] 2129 	mov	dptr,#_process_action_PARM_2
      007A5B E0               [24] 2130 	movx	a,@dptr
      007A5C F5 82            [12] 2131 	mov	dpl,a
      007A5E 22               [24] 2132 	ret
                                   2133 
                                   2134 	.area CSEG (CODE)
                                   2135 ; function ak820_outline_0085
      007A5F                       2136 _ak820_outline_0085:
      007A5F 90 08 80         [24] 2137 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007A62 E0               [24] 2138 	movx	a,@dptr
      007A63 03               [12] 2139 	rr	a
      007A64 03               [12] 2140 	rr	a
      007A65 54 03            [12] 2141 	anl	a,#0x03
      007A67 22               [24] 2142 	ret
                                   2143 
                                   2144 	.area CSEG (CODE)
                                   2145 ; function ak820_outline_0108
      007A68                       2146 _ak820_outline_0108:
      007A68 74 06            [12] 2147 	mov	a,#0x06
      007A6A F0               [24] 2148 	movx	@dptr,a
      007A6B E4               [12] 2149 	clr	a
      007A6C A3               [24] 2150 	inc	dptr
      007A6D F0               [24] 2151 	movx	@dptr,a
      007A6E 22               [24] 2152 	ret
                                   2153 
                                   2154 	.area CSEG (CODE)
                                   2155 ; function ak820_outline_0109
      007A6F                       2156 _ak820_outline_0109:
      007A6F 90 08 80         [24] 2157 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007A72 E0               [24] 2158 	movx	a,@dptr
      007A73 54 0F            [12] 2159 	anl	a,#0x0f
      007A75 22               [24] 2160 	ret
                                   2161 
                                   2162 	.area CSEG (CODE)
                                   2163 ; function ak820_outline_0129
      007A76                       2164 _ak820_outline_0129:
      007A76 90 08 7F         [24] 2165 	mov	dptr,#_process_action_PARM_2
      007A79 E0               [24] 2166 	movx	a,@dptr
      007A7A FE               [12] 2167 	mov	r6,a
      007A7B A3               [24] 2168 	inc	dptr
      007A7C E0               [24] 2169 	movx	a,@dptr
      007A7D 54 03            [12] 2170 	anl	a,#0x03
      007A7F FF               [12] 2171 	mov	r7,a
      007A80 22               [24] 2172 	ret
                                   2173 
                                   2174 	.area CSEG (CODE)
                                   2175 ; function ak820_outline_0154
      007A81                       2176 _ak820_outline_0154:
      007A81 90 08 7F         [24] 2177 	mov	dptr,#_process_action_PARM_2
      007A84 E0               [24] 2178 	movx	a,@dptr
      007A85 22               [24] 2179 	ret
                                   2180 
                                   2181 	.area CSEG (CODE)
                                   2182 ; function ak820_outline_0162
      007A86                       2183 _ak820_outline_0162:
      007A86 90 08 84         [24] 2184 	mov	dptr,#_register_code_code_10000_716
      007A89 E0               [24] 2185 	movx	a,@dptr
      007A8A FF               [12] 2186 	mov	r7,a
      007A8B 22               [24] 2187 	ret
                                   2188 
                                   2189 	.area CSEG (CODE)
                                   2190 ; function ak820_outline_0163
      007A8C                       2191 _ak820_outline_0163:
      007A8C 90 08 85         [24] 2192 	mov	dptr,#_unregister_code_code_10000_730
      007A8F E0               [24] 2193 	movx	a,@dptr
      007A90 FF               [12] 2194 	mov	r7,a
      007A91 22               [24] 2195 	ret
                                   2196 
                                   2197 	.area CSEG (CODE)
                                   2198 ; function ak820_outline_0184
      007A92                       2199 _ak820_outline_0184:
      007A92 E4               [12] 2200 	clr	a
      007A93 F0               [24] 2201 	movx	@dptr,a
      007A94 8F 82            [24] 2202 	mov	dpl,r7
      007A96 22               [24] 2203 	ret
