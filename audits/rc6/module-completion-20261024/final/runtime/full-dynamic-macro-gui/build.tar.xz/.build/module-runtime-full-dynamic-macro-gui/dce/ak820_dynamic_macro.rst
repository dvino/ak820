                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_dynamic_macro
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_keyboard_report_pending
                                     12 	.globl _get_repeat_key_count
                                     13 	.globl _del_owned_key
                                     14 	.globl _add_owned_key
                                     15 	.globl _del_owned_mods
                                     16 	.globl _add_owned_mods
                                     17 	.globl _get_weak_mods
                                     18 	.globl _get_mods
                                     19 	.globl _send_keyboard_report
                                     20 	.globl _timer_read
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_dynamic_macro_observe_PARM_2
                                    265 	.globl _ak820_dynamic_macro_process_PARM_2
                                    266 	.globl _ak820_dynamic_macro_source
                                    267 	.globl _ak820_dynamic_macro_cancel
                                    268 	.globl _ak820_dynamic_macro_process
                                    269 	.globl _ak820_dynamic_macro_observe
                                    270 	.globl _ak820_dynamic_macro_task
                                    271 ;--------------------------------------------------------
                                    272 ; special function registers
                                    273 ;--------------------------------------------------------
                                    274 	.area RSEG    (ABS,DATA)
      000000                        275 	.org 0x0000
                           0000D0   276 _PSW	=	0x00d0
                           0000E0   277 _ACC	=	0x00e0
                           0000F0   278 _B	=	0x00f0
                           0000FD   279 _A_INV	=	0x00fd
                           000081   280 _SP	=	0x0081
                           000082   281 _DPL	=	0x0082
                           000083   282 _DPH	=	0x0083
                           0000A1   283 _SAFE_MOD	=	0x00a1
                           0000B1   284 _GLOBAL_CFG	=	0x00b1
                           000087   285 _PCON	=	0x0087
                           0000BA   286 _POWER_CFG	=	0x00ba
                           0000B9   287 _CLOCK_CFG	=	0x00b9
                           0000A9   288 _WAKE_CTRL	=	0x00a9
                           0000FE   289 _RESET_KEEP	=	0x00fe
                           0000FF   290 _WDOG_COUNT	=	0x00ff
                           0000A8   291 _IE	=	0x00a8
                           0000B8   292 _IP	=	0x00b8
                           0000E8   293 _IE_EX	=	0x00e8
                           0000E9   294 _IP_EX	=	0x00e9
                           0000B2   295 _GPIO_IE	=	0x00b2
                           008584   296 _ROM_ADDR	=	0x8584
                           000084   297 _ROM_ADDR_L	=	0x0084
                           000085   298 _ROM_ADDR_H	=	0x0085
                           008F8E   299 _ROM_DATA_HI	=	0x8f8e
                           00008E   300 _ROM_DATA_HL	=	0x008e
                           00008F   301 _ROM_DATA_HH	=	0x008f
                           000086   302 _ROM_CTRL	=	0x0086
                           000080   303 _P0	=	0x0080
                           0000C4   304 _P0_MOD_OC	=	0x00c4
                           0000C5   305 _P0_DIR_PU	=	0x00c5
                           000090   306 _P1	=	0x0090
                           000092   307 _P1_MOD_OC	=	0x0092
                           000093   308 _P1_DIR_PU	=	0x0093
                           0000A0   309 _P2	=	0x00a0
                           000094   310 _P2_MOD_OC	=	0x0094
                           000095   311 _P2_DIR_PU	=	0x0095
                           0000B0   312 _P3	=	0x00b0
                           000096   313 _P3_MOD_OC	=	0x0096
                           000097   314 _P3_DIR_PU	=	0x0097
                           0000C0   315 _P4	=	0x00c0
                           0000C2   316 _P4_MOD_OC	=	0x00c2
                           0000C3   317 _P4_DIR_PU	=	0x00c3
                           0000C1   318 _P4_LED_KEY	=	0x00c1
                           0000AA   319 _P5_IN	=	0x00aa
                           0000AB   320 _P5_OUT_PU	=	0x00ab
                           0000AC   321 _P5_DIR	=	0x00ac
                           0000AD   322 _P6_IN	=	0x00ad
                           0000AE   323 _P6_OUT_PU	=	0x00ae
                           0000AF   324 _P6_DIR	=	0x00af
                           0000F1   325 _P7	=	0x00f1
                           0000A2   326 _XBUS_AUX	=	0x00a2
                           000088   327 _TCON	=	0x0088
                           000089   328 _TMOD	=	0x0089
                           00008A   329 _TL0	=	0x008a
                           00008B   330 _TL1	=	0x008b
                           00008C   331 _TH0	=	0x008c
                           00008D   332 _TH1	=	0x008d
                           000098   333 _SCON	=	0x0098
                           000099   334 _SBUF	=	0x0099
                           0000C8   335 _T2CON	=	0x00c8
                           0000C9   336 _T2MOD	=	0x00c9
                           00CBCA   337 _RCAP2	=	0xcbca
                           0000CA   338 _RCAP2L	=	0x00ca
                           0000CB   339 _RCAP2H	=	0x00cb
                           00CDCC   340 _T2COUNT	=	0xcdcc
                           0000CC   341 _TL2	=	0x00cc
                           0000CD   342 _TH2	=	0x00cd
                           00CFCE   343 _T2CAP1	=	0xcfce
                           0000CE   344 _T2CAP1L	=	0x00ce
                           0000CF   345 _T2CAP1H	=	0x00cf
                           0000F8   346 _SPI0_STAT	=	0x00f8
                           0000F9   347 _SPI0_DATA	=	0x00f9
                           0000FA   348 _SPI0_CTRL	=	0x00fa
                           0000FB   349 _SPI0_CK_SE	=	0x00fb
                           0000FC   350 _SPI0_SETUP	=	0x00fc
                           0000BC   351 _SCON1	=	0x00bc
                           0000BD   352 _SBUF1	=	0x00bd
                           0000BE   353 _SBAUD1	=	0x00be
                           0000BF   354 _SIF1	=	0x00bf
                           0000B4   355 _SPI1_STAT	=	0x00b4
                           0000B5   356 _SPI1_DATA	=	0x00b5
                           0000B6   357 _SPI1_CTRL	=	0x00b6
                           0000B7   358 _SPI1_CK_SE	=	0x00b7
                           0000F3   359 _ADC_CTRL	=	0x00f3
                           00F5F4   360 _ADC_DAT	=	0xf5f4
                           0000F4   361 _ADC_DAT_L	=	0x00f4
                           0000F5   362 _ADC_DAT_H	=	0x00f5
                           0000F6   363 _ADC_CHAN	=	0x00f6
                           0000A6   364 _LED_COMMON	=	0x00a6
                           0000A7   365 _LED_PWM_OE	=	0x00a7
                           00C7C6   366 _LED_DMA	=	0xc7c6
                           0000C6   367 _LED_DMA_L	=	0x00c6
                           0000C7   368 _LED_DMA_H	=	0x00c7
                           0000F7   369 _LED_STATUS	=	0x00f7
                           0000B3   370 _I2CX_INT	=	0x00b3
                           0000BB   371 _I2CS_INT_ST	=	0x00bb
                                    372 ;--------------------------------------------------------
                                    373 ; special function bits
                                    374 ;--------------------------------------------------------
                                    375 	.area RSEG    (ABS,DATA)
      000000                        376 	.org 0x0000
                           0000D7   377 _CY	=	0x00d7
                           0000D6   378 _AC	=	0x00d6
                           0000D5   379 _F0	=	0x00d5
                           0000D4   380 _RS1	=	0x00d4
                           0000D3   381 _RS0	=	0x00d3
                           0000D2   382 _OV	=	0x00d2
                           0000D1   383 _F1	=	0x00d1
                           0000D0   384 _P	=	0x00d0
                           0000AF   385 _EA	=	0x00af
                           0000AE   386 _E_DIS	=	0x00ae
                           0000AD   387 _ET2	=	0x00ad
                           0000AC   388 _ES	=	0x00ac
                           0000AB   389 _ET1	=	0x00ab
                           0000AA   390 _EX1	=	0x00aa
                           0000A9   391 _ET0	=	0x00a9
                           0000A8   392 _EX0	=	0x00a8
                           0000BF   393 _PH_FLAG	=	0x00bf
                           0000BE   394 _PL_FLAG	=	0x00be
                           0000BD   395 _PT2	=	0x00bd
                           0000BC   396 _PS	=	0x00bc
                           0000BB   397 _PT1	=	0x00bb
                           0000BA   398 _PX1	=	0x00ba
                           0000B9   399 _PT0	=	0x00b9
                           0000B8   400 _PX0	=	0x00b8
                           0000EF   401 _IE_WDOG	=	0x00ef
                           0000EE   402 _IE_GPIO	=	0x00ee
                           0000ED   403 _IE_PWM_I2C	=	0x00ed
                           0000EC   404 _IE_UART1	=	0x00ec
                           0000EB   405 _IE_ADC	=	0x00eb
                           0000E9   406 _IE_USB	=	0x00e9
                           0000E8   407 _IE_SPI0	=	0x00e8
                           000087   408 _P0_7	=	0x0087
                           000086   409 _P0_6	=	0x0086
                           000085   410 _P0_5	=	0x0085
                           000084   411 _P0_4	=	0x0084
                           000083   412 _P0_3	=	0x0083
                           000082   413 _P0_2	=	0x0082
                           000081   414 _P0_1	=	0x0081
                           000080   415 _P0_0	=	0x0080
                           000081   416 _SDA0	=	0x0081
                           000080   417 _SCL0	=	0x0080
                           000083   418 _TXD_	=	0x0083
                           000082   419 _RXD_	=	0x0082
                           000085   420 _AIN13	=	0x0085
                           000084   421 _AIN12	=	0x0084
                           000083   422 _AIN11	=	0x0083
                           000082   423 _AIN10	=	0x0082
                           000081   424 _AIN9	=	0x0081
                           000080   425 _AIN8	=	0x0080
                           000097   426 _P1_7	=	0x0097
                           000096   427 _P1_6	=	0x0096
                           000095   428 _P1_5	=	0x0095
                           000094   429 _P1_4	=	0x0094
                           000093   430 _P1_3	=	0x0093
                           000092   431 _P1_2	=	0x0092
                           000091   432 _P1_1	=	0x0091
                           000090   433 _P1_0	=	0x0090
                           000097   434 _TXD1_	=	0x0097
                           000096   435 _RXD1_	=	0x0096
                           000097   436 _SCK	=	0x0097
                           000096   437 _MISO	=	0x0096
                           000095   438 _MOSI	=	0x0095
                           000094   439 _SCS	=	0x0094
                           000092   440 _INT0_	=	0x0092
                           000091   441 _T2EX	=	0x0091
                           000091   442 _CAP2	=	0x0091
                           000090   443 _T2	=	0x0090
                           000090   444 _CAP1	=	0x0090
                           000097   445 _AIN7	=	0x0097
                           000096   446 _AIN6	=	0x0096
                           000095   447 _AIN5	=	0x0095
                           000094   448 _AIN4	=	0x0094
                           000093   449 _AIN3	=	0x0093
                           000092   450 _AIN2	=	0x0092
                           000091   451 _AIN1	=	0x0091
                           000090   452 _AIN0	=	0x0090
                           0000A7   453 _P2_7	=	0x00a7
                           0000A6   454 _P2_6	=	0x00a6
                           0000A5   455 _P2_5	=	0x00a5
                           0000A4   456 _P2_4	=	0x00a4
                           0000A3   457 _P2_3	=	0x00a3
                           0000A2   458 _P2_2	=	0x00a2
                           0000A1   459 _P2_1	=	0x00a1
                           0000A0   460 _P2_0	=	0x00a0
                           0000A7   461 _TXD1	=	0x00a7
                           0000A6   462 _RXD1	=	0x00a6
                           0000A5   463 _T2EX_	=	0x00a5
                           0000A5   464 _CAP2_	=	0x00a5
                           0000A4   465 _T2_	=	0x00a4
                           0000A4   466 _CAP1_	=	0x00a4
                           0000B7   467 _P3_7	=	0x00b7
                           0000B6   468 _P3_6	=	0x00b6
                           0000B5   469 _P3_5	=	0x00b5
                           0000B4   470 _P3_4	=	0x00b4
                           0000B3   471 _P3_3	=	0x00b3
                           0000B2   472 _P3_2	=	0x00b2
                           0000B1   473 _P3_1	=	0x00b1
                           0000B0   474 _P3_0	=	0x00b0
                           0000B7   475 _SCK1	=	0x00b7
                           0000B6   476 _MISO1	=	0x00b6
                           0000B5   477 _MOSI1	=	0x00b5
                           0000B5   478 _T1	=	0x00b5
                           0000B4   479 _T0	=	0x00b4
                           0000B3   480 _INT1	=	0x00b3
                           0000B2   481 _INT0	=	0x00b2
                           0000B1   482 _TXD	=	0x00b1
                           0000B0   483 _RXD	=	0x00b0
                           0000C6   484 _P4_6	=	0x00c6
                           0000C5   485 _P4_5	=	0x00c5
                           0000C4   486 _P4_4	=	0x00c4
                           0000C3   487 _P4_3	=	0x00c3
                           0000C2   488 _P4_2	=	0x00c2
                           0000C1   489 _P4_1	=	0x00c1
                           0000C0   490 _P4_0	=	0x00c0
                           00008F   491 _TF1	=	0x008f
                           00008E   492 _TR1	=	0x008e
                           00008D   493 _TF0	=	0x008d
                           00008C   494 _TR0	=	0x008c
                           00008B   495 _IE1	=	0x008b
                           00008A   496 _IT1	=	0x008a
                           000089   497 _IE0	=	0x0089
                           000088   498 _IT0	=	0x0088
                           00009F   499 _SM0	=	0x009f
                           00009E   500 _SM1	=	0x009e
                           00009D   501 _SM2	=	0x009d
                           00009C   502 _REN	=	0x009c
                           00009B   503 _TB8	=	0x009b
                           00009A   504 _RB8	=	0x009a
                           000099   505 _TI	=	0x0099
                           000098   506 _RI	=	0x0098
                           0000CF   507 _TF2	=	0x00cf
                           0000CF   508 _CAP1F	=	0x00cf
                           0000CE   509 _EXF2	=	0x00ce
                           0000CD   510 _RCLK	=	0x00cd
                           0000CC   511 _TCLK	=	0x00cc
                           0000CB   512 _EXEN2	=	0x00cb
                           0000CA   513 _TR2	=	0x00ca
                           0000C9   514 _C_T2	=	0x00c9
                           0000C8   515 _CP_RL2	=	0x00c8
                           0000FF   516 _S0_FST_ACT	=	0x00ff
                           0000FE   517 _S0_IF_OV	=	0x00fe
                           0000FD   518 _S0_IF_FIRST	=	0x00fd
                           0000FC   519 _S0_IF_BYTE	=	0x00fc
                           0000FB   520 _S0_FREE	=	0x00fb
                           0000FA   521 _S0_T_FIFO	=	0x00fa
                           0000F8   522 _S0_R_FIFO	=	0x00f8
                           0000F7   523 _ADC_START	=	0x00f7
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable register banks
                                    526 ;--------------------------------------------------------
                                    527 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        528 	.ds 8
                                    529 ;--------------------------------------------------------
                                    530 ; internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area DSEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; overlayable items in internal ram
                                    535 ;--------------------------------------------------------
                                    536 ;--------------------------------------------------------
                                    537 ; indirectly addressable internal ram data
                                    538 ;--------------------------------------------------------
                                    539 	.area ISEG    (DATA)
                                    540 ;--------------------------------------------------------
                                    541 ; absolute internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area IABS    (ABS,DATA)
                                    544 	.area IABS    (ABS,DATA)
                                    545 ;--------------------------------------------------------
                                    546 ; bit data
                                    547 ;--------------------------------------------------------
                                    548 	.area BSEG    (BIT)
                                    549 ;--------------------------------------------------------
                                    550 ; paged external ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area PSEG    (PAG,XDATA)
                                    553 ;--------------------------------------------------------
                                    554 ; uninitialized external ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area XSEG    (XDATA)
      000460                        557 _dm_taps:
      000460                        558 	.ds 64
      0004A0                        559 _dm_lengths:
      0004A0                        560 	.ds 2
      0004A2                        561 _dm_record:
      0004A2                        562 	.ds 1
      0004A3                        563 _dm_play:
      0004A3                        564 	.ds 1
      0004A4                        565 _dm_index:
      0004A4                        566 	.ds 1
      0004A5                        567 _dm_down:
      0004A5                        568 	.ds 1
      0004A6                        569 _dm_mods:
      0004A6                        570 	.ds 1
      0004A7                        571 _dm_time:
      0004A7                        572 	.ds 2
      0004A9                        573 _ak820_dynamic_macro_source::
      0004A9                        574 	.ds 1
      0004AA                        575 _ak820_dynamic_macro_process_PARM_2:
      0004AA                        576 	.ds 1
      0004AB                        577 _ak820_dynamic_macro_process_code_10000_603:
      0004AB                        578 	.ds 2
      0004AD                        579 _ak820_dynamic_macro_observe_PARM_2:
      0004AD                        580 	.ds 1
      0004AE                        581 _ak820_dynamic_macro_observe_code_10000_612:
      0004AE                        582 	.ds 1
      0004AF                        583 _ak820_dynamic_macro_observe_slot_10001_615:
      0004AF                        584 	.ds 1
      0004B0                        585 _ak820_dynamic_macro_observe_base_10001_615:
      0004B0                        586 	.ds 1
      0004B1                        587 _ak820_dynamic_macro_observe_i_30001_617:
      0004B1                        588 	.ds 1
      0004B2                        589 _ak820_dynamic_macro_task_now_10000_624:
      0004B2                        590 	.ds 2
      0004B4                        591 _ak820_dynamic_macro_task_i_40000_631:
      0004B4                        592 	.ds 1
      0004B5                        593 _ak820_dynamic_macro_task_code_40000_631:
      0004B5                        594 	.ds 1
                                    595 ;--------------------------------------------------------
                                    596 ; absolute external ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area XABS    (ABS,XDATA)
                                    599 ;--------------------------------------------------------
                                    600 ; initialized external ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area XISEG   (XDATA)
                                    603 	.area HOME    (CODE)
                                    604 	.area GSINIT0 (CODE)
                                    605 	.area GSINIT1 (CODE)
                                    606 	.area GSINIT2 (CODE)
                                    607 	.area GSINIT3 (CODE)
                                    608 	.area GSINIT4 (CODE)
                                    609 	.area GSINIT5 (CODE)
                                    610 	.area GSINIT  (CODE)
                                    611 	.area GSFINAL (CODE)
                                    612 	.area CSEG    (CODE)
                                    613 ;--------------------------------------------------------
                                    614 ; global & static initialisations
                                    615 ;--------------------------------------------------------
                                    616 	.area HOME    (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area GSINIT  (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; Home
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area HOME    (CODE)
                                    625 ;--------------------------------------------------------
                                    626 ; code
                                    627 ;--------------------------------------------------------
                                    628 	.area CSEG    (CODE)
                                    629 ;------------------------------------------------------------
                                    630 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    631 ;------------------------------------------------------------
                                    632 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    633 ;------------------------------------------------------------
                                    634 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    635 ;	-----------------------------------------
                           000007   636 	ar7 = 0x07
                           000006   637 	ar6 = 0x06
                           000005   638 	ar5 = 0x05
                           000004   639 	ar4 = 0x04
                           000003   640 	ar3 = 0x03
                           000002   641 	ar2 = 0x02
                           000001   642 	ar1 = 0x01
                           000000   643 	ar0 = 0x00
                                    644 ;	 function dm_finish
                                    645 ;	-----------------------------------------
      003895                        646 _dm_finish:
                                    647 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:17: if (dm_record) {
      003895 90 04 A2         [24]  648 	mov	dptr,#_dm_record
      003898 E0               [24]  649 	movx	a,@dptr
      003899 FF               [12]  650 	mov	r7,a
      00389A E0               [24]  651 	movx	a,@dptr
      00389B 70 01            [24]  652 	jnz	00140$
      00389D 22               [24]  653 	ret
      00389E                        654 00140$:
                                    655 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:18: uint8_t slot = dm_record - 1, base = slot * 16, out = 0;
      00389E 1F               [12]  656 	dec	r7
      00389F EF               [12]  657 	mov	a,r7
      0038A0 C4               [12]  658 	swap	a
      0038A1 54 F0            [12]  659 	anl	a,#0xf0
      0038A3 FE               [12]  660 	mov	r6,a
                                    661 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:19: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      0038A4 EF               [12]  662 	mov	a,r7
      0038A5 24 A0            [12]  663 	add	a, #_dm_lengths
      0038A7 FD               [12]  664 	mov	r5,a
      0038A8 E4               [12]  665 	clr	a
      0038A9 34 04            [12]  666 	addc	a, #(_dm_lengths >> 8)
      0038AB FF               [12]  667 	mov	r7,a
      0038AC 7C 00            [12]  668 	mov	r4,#0x00
      0038AE 7B 00            [12]  669 	mov	r3,#0x00
      0038B0                        670 00107$:
      0038B0 8D 82            [24]  671 	mov	dpl,r5
      0038B2 8F 83            [24]  672 	mov	dph,r7
      0038B4 E0               [24]  673 	movx	a,@dptr
      0038B5 FA               [12]  674 	mov	r2,a
      0038B6 C3               [12]  675 	clr	c
      0038B7 EB               [12]  676 	mov	a,r3
      0038B8 9A               [12]  677 	subb	a,r2
      0038B9 50 6F            [24]  678 	jnc	00103$
                                    679 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:20: if (!(dm_taps[base + i].code & 0x80)) {
      0038BB EB               [12]  680 	mov	a,r3
      0038BC 2E               [12]  681 	add	a, r6
      0038BD 75 F0 02         [24]  682 	mov	b,#0x02
      0038C0 A4               [48]  683 	mul	ab
      0038C1 24 60            [12]  684 	add	a, #_dm_taps
      0038C3 F5 82            [12]  685 	mov	dpl,a
      0038C5 74 04            [12]  686 	mov	a,#(_dm_taps >> 8)
      0038C7 35 F0            [12]  687 	addc	a, b
      0038C9 F5 83            [12]  688 	mov	dph,a
      0038CB E0               [24]  689 	movx	a,@dptr
      0038CC 20 E7 58         [24]  690 	jb	acc.7,00108$
                                    691 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:21: dm_taps[base + out] = dm_taps[base + i];
      0038CF C0 05            [24]  692 	push	ar5
      0038D1 C0 07            [24]  693 	push	ar7
      0038D3 EC               [12]  694 	mov	a,r4
      0038D4 2E               [12]  695 	add	a, r6
      0038D5 75 F0 02         [24]  696 	mov	b,#0x02
      0038D8 A4               [48]  697 	mul	ab
      0038D9 24 60            [12]  698 	add	a, #_dm_taps
      0038DB F9               [12]  699 	mov	r1,a
      0038DC 74 04            [12]  700 	mov	a,#(_dm_taps >> 8)
      0038DE 35 F0            [12]  701 	addc	a, b
      0038E0 F8               [12]  702 	mov	r0,a
      0038E1 7A 00            [12]  703 	mov	r2,#0x00
      0038E3 EB               [12]  704 	mov	a,r3
      0038E4 2E               [12]  705 	add	a, r6
      0038E5 75 F0 02         [24]  706 	mov	b,#0x02
      0038E8 A4               [48]  707 	mul	ab
      0038E9 24 60            [12]  708 	add	a, #_dm_taps
      0038EB FD               [12]  709 	mov	r5,a
      0038EC 74 04            [12]  710 	mov	a,#(_dm_taps >> 8)
      0038EE 35 F0            [12]  711 	addc	a, b
      0038F0 FF               [12]  712 	mov	r7,a
      0038F1 90 0D C9         [24]  713 	mov	dptr,#___memcpy_PARM_2
      0038F4 ED               [12]  714 	mov	a,r5
      0038F5 F0               [24]  715 	movx	@dptr,a
      0038F6 EF               [12]  716 	mov	a,r7
      0038F7 A3               [24]  717 	inc	dptr
      0038F8 F0               [24]  718 	movx	@dptr,a
      0038F9 E4               [12]  719 	clr	a
      0038FA A3               [24]  720 	inc	dptr
      0038FB F0               [24]  721 	movx	@dptr,a
      0038FC 90 0D CC         [24]  722 	mov	dptr,#___memcpy_PARM_3
      0038FF 74 02            [12]  723 	mov	a,#0x02
      003901 F0               [24]  724 	movx	@dptr,a
      003902 E4               [12]  725 	clr	a
      003903 A3               [24]  726 	inc	dptr
      003904 F0               [24]  727 	movx	@dptr,a
      003905 89 82            [24]  728 	mov	dpl, r1
      003907 88 83            [24]  729 	mov	dph, r0
      003909 8A F0            [24]  730 	mov	b, r2
      00390B C0 07            [24]  731 	push	ar7
      00390D C0 06            [24]  732 	push	ar6
      00390F C0 05            [24]  733 	push	ar5
      003911 C0 04            [24]  734 	push	ar4
      003913 C0 03            [24]  735 	push	ar3
      003915 12 BA 82         [24]  736 	lcall	___memcpy
      003918 D0 03            [24]  737 	pop	ar3
      00391A D0 04            [24]  738 	pop	ar4
      00391C D0 05            [24]  739 	pop	ar5
      00391E D0 06            [24]  740 	pop	ar6
      003920 D0 07            [24]  741 	pop	ar7
                                    742 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:22: ++out;
      003922 0C               [12]  743 	inc	r4
                                    744 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:26: dm_record = 0;
      003923 D0 07            [24]  745 	pop	ar7
      003925 D0 05            [24]  746 	pop	ar5
                                    747 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:22: ++out;
      003927                        748 00108$:
                                    749 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:19: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003927 0B               [12]  750 	inc	r3
      003928 80 86            [24]  751 	sjmp	00107$
      00392A                        752 00103$:
                                    753 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:25: dm_lengths[slot] = out;
      00392A 8D 82            [24]  754 	mov	dpl,r5
      00392C 8F 83            [24]  755 	mov	dph,r7
      00392E EC               [12]  756 	mov	a,r4
      00392F F0               [24]  757 	movx	@dptr,a
                                    758 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:26: dm_record = 0;
      003930 90 04 A2         [24]  759 	mov	dptr,#_dm_record
      003933 E4               [12]  760 	clr	a
      003934 F0               [24]  761 	movx	@dptr,a
                                    762 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:28: }
      003935 22               [24]  763 	ret
                                    764 ;------------------------------------------------------------
                                    765 ;Allocation info for local variables in function 'ak820_dynamic_macro_cancel'
                                    766 ;------------------------------------------------------------
                                    767 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:29: void ak820_dynamic_macro_cancel(void) {
                                    768 ;	-----------------------------------------
                                    769 ;	 function ak820_dynamic_macro_cancel
                                    770 ;	-----------------------------------------
      003936                        771 _ak820_dynamic_macro_cancel:
                                    772 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:30: dm_finish();
      003936 12 38 95         [24]  773 	lcall	_dm_finish
                                    774 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:33: dm_play = dm_down = 0;
      003939 90 04 A5         [24]  775 	mov	dptr,#_dm_down
      00393C E4               [12]  776 	clr	a
      00393D F0               [24]  777 	movx	@dptr,a
      00393E 90 04 A3         [24]  778 	mov	dptr,#_dm_play
      003941 F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:34: ak820_dynamic_macro_source = false;
      003942 90 04 A9         [24]  781 	mov	dptr,#_ak820_dynamic_macro_source
      003945 F0               [24]  782 	movx	@dptr,a
                                    783 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:35: }
      003946 22               [24]  784 	ret
                                    785 ;------------------------------------------------------------
                                    786 ;Allocation info for local variables in function 'ak820_dynamic_macro_process'
                                    787 ;------------------------------------------------------------
                                    788 ;pressed       Allocated with name '_ak820_dynamic_macro_process_PARM_2'
                                    789 ;code          Allocated with name '_ak820_dynamic_macro_process_code_10000_603'
                                    790 ;------------------------------------------------------------
                                    791 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:36: bool ak820_dynamic_macro_process(uint16_t code, bool pressed) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function ak820_dynamic_macro_process
                                    794 ;	-----------------------------------------
      003947                        795 _ak820_dynamic_macro_process:
      003947 AF 83            [24]  796 	mov	r7,dph
      003949 E5 82            [12]  797 	mov	a,dpl
      00394B 90 04 AB         [24]  798 	mov	dptr,#_ak820_dynamic_macro_process_code_10000_603
      00394E F0               [24]  799 	movx	@dptr,a
      00394F EF               [12]  800 	mov	a,r7
      003950 A3               [24]  801 	inc	dptr
      003951 F0               [24]  802 	movx	@dptr,a
                                    803 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:37: if (code < QK_DYNAMIC_MACRO_RECORD_START_1 || code > QK_DYNAMIC_MACRO_PLAY_2) return true;
      003952 90 04 AB         [24]  804 	mov	dptr,#_ak820_dynamic_macro_process_code_10000_603
      003955 E0               [24]  805 	movx	a,@dptr
      003956 FE               [12]  806 	mov	r6,a
      003957 A3               [24]  807 	inc	dptr
      003958 E0               [24]  808 	movx	a,@dptr
      003959 FF               [12]  809 	mov	r7,a
      00395A 8E 04            [24]  810 	mov	ar4,r6
      00395C 8F 05            [24]  811 	mov	ar5,r7
      00395E C3               [12]  812 	clr	c
      00395F EC               [12]  813 	mov	a,r4
      003960 94 53            [12]  814 	subb	a,#0x53
      003962 ED               [12]  815 	mov	a,r5
      003963 94 7C            [12]  816 	subb	a,#0x7c
      003965 40 08            [24]  817 	jc	00101$
      003967 74 57            [12]  818 	mov	a,#0x57
      003969 9C               [12]  819 	subb	a,r4
      00396A 74 7C            [12]  820 	mov	a,#0x7c
      00396C 9D               [12]  821 	subb	a,r5
      00396D 50 04            [24]  822 	jnc	00102$
                                    823 ;	free result
      00396F                        824 00101$:
      00396F 75 82 01         [24]  825 	mov	dpl, #0x01
      003972 22               [24]  826 	ret
      003973                        827 00102$:
                                    828 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:38: if (!pressed || get_repeat_key_count()) return false;
      003973 90 04 AA         [24]  829 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      003976 E0               [24]  830 	movx	a,@dptr
      003977 60 07            [24]  831 	jz	00104$
      003979 12 A4 81         [24]  832 	lcall	_get_repeat_key_count
      00397C E5 82            [12]  833 	mov	a, dpl
      00397E 60 04            [24]  834 	jz	00105$
      003980                        835 00104$:
      003980 75 82 00         [24]  836 	mov	dpl, #0x00
      003983 22               [24]  837 	ret
      003984                        838 00105$:
                                    839 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:41: if (dm_play) return false;
      003984 90 04 A3         [24]  840 	mov	dptr,#_dm_play
      003987 E0               [24]  841 	movx	a,@dptr
      003988 60 04            [24]  842 	jz	00108$
      00398A 75 82 00         [24]  843 	mov	dpl, #0x00
      00398D 22               [24]  844 	ret
      00398E                        845 00108$:
                                    846 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:42: dm_finish();
      00398E C0 07            [24]  847 	push	ar7
      003990 C0 06            [24]  848 	push	ar6
      003992 C0 05            [24]  849 	push	ar5
      003994 C0 04            [24]  850 	push	ar4
      003996 12 38 95         [24]  851 	lcall	_dm_finish
      003999 D0 04            [24]  852 	pop	ar4
      00399B D0 05            [24]  853 	pop	ar5
      00399D D0 06            [24]  854 	pop	ar6
      00399F D0 07            [24]  855 	pop	ar7
                                    856 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:43: if (code <= QK_DYNAMIC_MACRO_RECORD_START_2) {
      0039A1 C3               [12]  857 	clr	c
      0039A2 74 54            [12]  858 	mov	a,#0x54
      0039A4 9C               [12]  859 	subb	a,r4
      0039A5 74 7C            [12]  860 	mov	a,#0x7c
      0039A7 9D               [12]  861 	subb	a,r5
      0039A8 40 1E            [24]  862 	jc	00112$
                                    863 ;	free result
                                    864 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:44: dm_record = code - QK_DYNAMIC_MACRO_RECORD_START_1 + 1;
      0039AA 8E 03            [24]  865 	mov	ar3,r6
      0039AC 74 AE            [12]  866 	mov	a,#0xae
      0039AE 2B               [12]  867 	add	a, r3
      0039AF FB               [12]  868 	mov	r3,a
      0039B0 90 04 A2         [24]  869 	mov	dptr,#_dm_record
      0039B3 F0               [24]  870 	movx	@dptr,a
                                    871 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:45: dm_lengths[dm_record - 1] = 0;
      0039B4 1B               [12]  872 	dec	r3
      0039B5 EB               [12]  873 	mov	a,r3
      0039B6 33               [12]  874 	rlc	a
      0039B7 95 E0            [12]  875 	subb	a,acc
      0039B9 FA               [12]  876 	mov	r2,a
      0039BA EB               [12]  877 	mov	a,r3
      0039BB 24 A0            [12]  878 	add	a, #_dm_lengths
      0039BD F5 82            [12]  879 	mov	dpl,a
      0039BF EA               [12]  880 	mov	a,r2
      0039C0 34 04            [12]  881 	addc	a, #(_dm_lengths >> 8)
      0039C2 F5 83            [12]  882 	mov	dph,a
      0039C4 E4               [12]  883 	clr	a
      0039C5 F0               [24]  884 	movx	@dptr,a
      0039C6 80 29            [24]  885 	sjmp	00113$
      0039C8                        886 00112$:
                                    887 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:46: } else if (code >= QK_DYNAMIC_MACRO_PLAY_1) {
      0039C8 C3               [12]  888 	clr	c
      0039C9 EC               [12]  889 	mov	a,r4
      0039CA 94 56            [12]  890 	subb	a,#0x56
      0039CC ED               [12]  891 	mov	a,r5
      0039CD 94 7C            [12]  892 	subb	a,#0x7c
      0039CF 40 20            [24]  893 	jc	00113$
                                    894 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:47: dm_play = code - QK_DYNAMIC_MACRO_PLAY_1 + 1;
      0039D1 90 04 A3         [24]  895 	mov	dptr,#_dm_play
      0039D4 74 AB            [12]  896 	mov	a,#0xab
      0039D6 2E               [12]  897 	add	a, r6
      0039D7 F0               [24]  898 	movx	@dptr,a
                                    899 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:48: dm_index = dm_down = 0;
      0039D8 90 04 A5         [24]  900 	mov	dptr,#_dm_down
      0039DB E4               [12]  901 	clr	a
      0039DC F0               [24]  902 	movx	@dptr,a
      0039DD 90 04 A4         [24]  903 	mov	dptr,#_dm_index
      0039E0 F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:49: dm_time = timer_read();
      0039E1 12 4C 3D         [24]  906 	lcall	_timer_read
      0039E4 E5 82            [12]  907 	mov	a, dpl
      0039E6 85 83 F0         [24]  908 	mov	b, dph
      0039E9 90 04 A7         [24]  909 	mov	dptr,#_dm_time
      0039EC F0               [24]  910 	movx	@dptr,a
      0039ED E5 F0            [12]  911 	mov	a,b
      0039EF A3               [24]  912 	inc	dptr
      0039F0 F0               [24]  913 	movx	@dptr,a
      0039F1                        914 00113$:
                                    915 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:51: return false;
      0039F1 75 82 00         [24]  916 	mov	dpl, #0x00
                                    917 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:52: }
      0039F4 22               [24]  918 	ret
                                    919 ;------------------------------------------------------------
                                    920 ;Allocation info for local variables in function 'ak820_dynamic_macro_observe'
                                    921 ;------------------------------------------------------------
                                    922 ;pressed       Allocated with name '_ak820_dynamic_macro_observe_PARM_2'
                                    923 ;code          Allocated with name '_ak820_dynamic_macro_observe_code_10000_612'
                                    924 ;slot          Allocated with name '_ak820_dynamic_macro_observe_slot_10001_615'
                                    925 ;base          Allocated with name '_ak820_dynamic_macro_observe_base_10001_615'
                                    926 ;i             Allocated with name '_ak820_dynamic_macro_observe_i_30001_617'
                                    927 ;i             Allocated with name '_ak820_dynamic_macro_observe_i_40001_620'
                                    928 ;------------------------------------------------------------
                                    929 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:53: void ak820_dynamic_macro_observe(uint8_t code, bool pressed) {
                                    930 ;	-----------------------------------------
                                    931 ;	 function ak820_dynamic_macro_observe
                                    932 ;	-----------------------------------------
      0039F5                        933 _ak820_dynamic_macro_observe:
      0039F5 E5 82            [12]  934 	mov	a,dpl
      0039F7 90 04 AE         [24]  935 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_612
      0039FA F0               [24]  936 	movx	@dptr,a
                                    937 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:54: if (!dm_record || !ak820_dynamic_macro_source || code < KC_A || code >= 0x80) return;
      0039FB 90 04 A2         [24]  938 	mov	dptr,#_dm_record
      0039FE E0               [24]  939 	movx	a,@dptr
      0039FF FF               [12]  940 	mov	r7,a
      003A00 E0               [24]  941 	movx	a,@dptr
      003A01 60 15            [24]  942 	jz	00101$
      003A03 90 04 A9         [24]  943 	mov	dptr,#_ak820_dynamic_macro_source
      003A06 E0               [24]  944 	movx	a,@dptr
      003A07 60 0F            [24]  945 	jz	00101$
      003A09 90 04 AE         [24]  946 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_612
      003A0C E0               [24]  947 	movx	a,@dptr
      003A0D FE               [12]  948 	mov	r6,a
      003A0E BE 04 00         [24]  949 	cjne	r6,#0x04,00177$
      003A11                        950 00177$:
      003A11 40 05            [24]  951 	jc	00101$
      003A13 BE 80 00         [24]  952 	cjne	r6,#0x80,00179$
      003A16                        953 00179$:
      003A16 40 01            [24]  954 	jc	00102$
      003A18                        955 00101$:
      003A18 22               [24]  956 	ret
      003A19                        957 00102$:
                                    958 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:55: uint8_t slot = dm_record - 1, base = slot * 16;
      003A19 1F               [12]  959 	dec	r7
      003A1A 90 04 AF         [24]  960 	mov	dptr,#_ak820_dynamic_macro_observe_slot_10001_615
      003A1D EF               [12]  961 	mov	a,r7
      003A1E F0               [24]  962 	movx	@dptr,a
      003A1F EF               [12]  963 	mov	a,r7
      003A20 C4               [12]  964 	swap	a
      003A21 54 F0            [12]  965 	anl	a,#0xf0
      003A23 FD               [12]  966 	mov	r5,a
      003A24 90 04 B0         [24]  967 	mov	dptr,#_ak820_dynamic_macro_observe_base_10001_615
      003A27 F0               [24]  968 	movx	@dptr,a
                                    969 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:56: if (pressed) {
      003A28 90 04 AD         [24]  970 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      003A2B E0               [24]  971 	movx	a,@dptr
      003A2C 60 67            [24]  972 	jz	00134$
                                    973 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:57: uint8_t i = dm_lengths[slot];
      003A2E EF               [12]  974 	mov	a,r7
      003A2F 24 A0            [12]  975 	add	a, #_dm_lengths
      003A31 F5 82            [12]  976 	mov	dpl,a
      003A33 E4               [12]  977 	clr	a
      003A34 34 04            [12]  978 	addc	a, #(_dm_lengths >> 8)
      003A36 F5 83            [12]  979 	mov	dph,a
      003A38 E0               [24]  980 	movx	a,@dptr
      003A39 FC               [12]  981 	mov	r4,a
      003A3A 90 04 B1         [24]  982 	mov	dptr,#_ak820_dynamic_macro_observe_i_30001_617
      003A3D F0               [24]  983 	movx	@dptr,a
                                    984 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:58: if (i == 16) return; /* Full: retain first 16; still accept releases. */
      003A3E BC 10 01         [24]  985 	cjne	r4,#0x10,00107$
      003A41 22               [24]  986 	ret
      003A42                        987 00107$:
                                    988 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:59: dm_taps[base + i].code = code | 0x80;
      003A42 EC               [12]  989 	mov	a,r4
      003A43 2D               [12]  990 	add	a, r5
      003A44 75 F0 02         [24]  991 	mov	b,#0x02
      003A47 A4               [48]  992 	mul	ab
      003A48 24 60            [12]  993 	add	a, #_dm_taps
      003A4A F5 82            [12]  994 	mov	dpl,a
      003A4C 74 04            [12]  995 	mov	a,#(_dm_taps >> 8)
      003A4E 35 F0            [12]  996 	addc	a, b
      003A50 F5 83            [12]  997 	mov	dph,a
      003A52 43 06 80         [24]  998 	orl	ar6,#0x80
      003A55 EE               [12]  999 	mov	a,r6
      003A56 F0               [24] 1000 	movx	@dptr,a
                                   1001 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:60: dm_taps[base + i].mods = get_mods() | get_weak_mods();
      003A57 90 04 B1         [24] 1002 	mov	dptr,#_ak820_dynamic_macro_observe_i_30001_617
      003A5A E0               [24] 1003 	movx	a,@dptr
      003A5B FE               [12] 1004 	mov	r6,a
      003A5C 90 04 B0         [24] 1005 	mov	dptr,#_ak820_dynamic_macro_observe_base_10001_615
      003A5F E0               [24] 1006 	movx	a,@dptr
      003A60 2E               [12] 1007 	add	a, r6
      003A61 75 F0 02         [24] 1008 	mov	b,#0x02
      003A64 A4               [48] 1009 	mul	ab
      003A65 24 60            [12] 1010 	add	a, #_dm_taps
      003A67 FB               [12] 1011 	mov	r3,a
      003A68 74 04            [12] 1012 	mov	a,#(_dm_taps >> 8)
      003A6A 35 F0            [12] 1013 	addc	a, b
      003A6C FC               [12] 1014 	mov	r4,a
      003A6D 0B               [12] 1015 	inc	r3
      003A6E BB 00 01         [24] 1016 	cjne	r3,#0x00,00184$
      003A71 0C               [12] 1017 	inc	r4
      003A72                       1018 00184$:
      003A72 12 83 EB         [24] 1019 	lcall	_get_mods
      003A75 AA 82            [24] 1020 	mov	r2, dpl
      003A77 12 84 01         [24] 1021 	lcall	_get_weak_mods
      003A7A E5 82            [12] 1022 	mov	a,dpl
      003A7C 42 02            [12] 1023 	orl	ar2,a
      003A7E 8B 82            [24] 1024 	mov	dpl,r3
      003A80 8C 83            [24] 1025 	mov	dph,r4
      003A82 EA               [12] 1026 	mov	a,r2
      003A83 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:61: dm_lengths[slot] = i + 1;
      003A84 90 04 AF         [24] 1029 	mov	dptr,#_ak820_dynamic_macro_observe_slot_10001_615
      003A87 E0               [24] 1030 	movx	a,@dptr
      003A88 24 A0            [12] 1031 	add	a, #_dm_lengths
      003A8A F5 82            [12] 1032 	mov	dpl,a
      003A8C E4               [12] 1033 	clr	a
      003A8D 34 04            [12] 1034 	addc	a, #(_dm_lengths >> 8)
      003A8F F5 83            [12] 1035 	mov	dph,a
      003A91 0E               [12] 1036 	inc	r6
      003A92 EE               [12] 1037 	mov	a,r6
      003A93 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:63: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003A94 22               [24] 1040 	ret
      003A95                       1041 00134$:
      003A95 EF               [12] 1042 	mov	a,r7
      003A96 24 A0            [12] 1043 	add	a, #_dm_lengths
      003A98 FE               [12] 1044 	mov	r6,a
      003A99 E4               [12] 1045 	clr	a
      003A9A 34 04            [12] 1046 	addc	a, #(_dm_lengths >> 8)
      003A9C FF               [12] 1047 	mov	r7,a
      003A9D 7C 00            [12] 1048 	mov	r4,#0x00
      003A9F                       1049 00115$:
      003A9F 8E 82            [24] 1050 	mov	dpl,r6
      003AA1 8F 83            [24] 1051 	mov	dph,r7
      003AA3 E0               [24] 1052 	movx	a,@dptr
      003AA4 FB               [12] 1053 	mov	r3,a
      003AA5 C3               [12] 1054 	clr	c
      003AA6 EC               [12] 1055 	mov	a,r4
      003AA7 9B               [12] 1056 	subb	a,r3
      003AA8 50 35            [24] 1057 	jnc	00117$
                                   1058 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:64: if (dm_taps[base + i].code == (uint8_t)(code | 0x80)) {
      003AAA EC               [12] 1059 	mov	a,r4
      003AAB 2D               [12] 1060 	add	a, r5
      003AAC 75 F0 02         [24] 1061 	mov	b,#0x02
      003AAF A4               [48] 1062 	mul	ab
      003AB0 24 60            [12] 1063 	add	a, #_dm_taps
      003AB2 F5 82            [12] 1064 	mov	dpl,a
      003AB4 74 04            [12] 1065 	mov	a,#(_dm_taps >> 8)
      003AB6 35 F0            [12] 1066 	addc	a, b
      003AB8 F5 83            [12] 1067 	mov	dph,a
      003ABA E0               [24] 1068 	movx	a,@dptr
      003ABB FB               [12] 1069 	mov	r3,a
      003ABC 90 04 AE         [24] 1070 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_612
      003ABF E0               [24] 1071 	movx	a,@dptr
      003AC0 FA               [12] 1072 	mov	r2,a
      003AC1 74 80            [12] 1073 	mov	a,#0x80
      003AC3 4A               [12] 1074 	orl	a,r2
      003AC4 F9               [12] 1075 	mov	r1,a
      003AC5 EB               [12] 1076 	mov	a,r3
      003AC6 B5 01 13         [24] 1077 	cjne	a,ar1,00116$
                                   1078 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:65: dm_taps[base + i].code = code;
      003AC9 EC               [12] 1079 	mov	a,r4
      003ACA 2D               [12] 1080 	add	a, r5
      003ACB 75 F0 02         [24] 1081 	mov	b,#0x02
      003ACE A4               [48] 1082 	mul	ab
      003ACF 24 60            [12] 1083 	add	a, #_dm_taps
      003AD1 F5 82            [12] 1084 	mov	dpl,a
      003AD3 74 04            [12] 1085 	mov	a,#(_dm_taps >> 8)
      003AD5 35 F0            [12] 1086 	addc	a, b
      003AD7 F5 83            [12] 1087 	mov	dph,a
      003AD9 EA               [12] 1088 	mov	a,r2
      003ADA F0               [24] 1089 	movx	@dptr,a
                                   1090 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:66: break;
      003ADB 22               [24] 1091 	ret
      003ADC                       1092 00116$:
                                   1093 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:63: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003ADC 0C               [12] 1094 	inc	r4
      003ADD 80 C0            [24] 1095 	sjmp	00115$
      003ADF                       1096 00117$:
                                   1097 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:70: }
      003ADF 22               [24] 1098 	ret
                                   1099 ;------------------------------------------------------------
                                   1100 ;Allocation info for local variables in function 'ak820_dynamic_macro_task'
                                   1101 ;------------------------------------------------------------
                                   1102 ;now           Allocated with name '_ak820_dynamic_macro_task_now_10000_624'
                                   1103 ;i             Allocated with name '_ak820_dynamic_macro_task_i_40000_631'
                                   1104 ;code          Allocated with name '_ak820_dynamic_macro_task_code_40000_631'
                                   1105 ;------------------------------------------------------------
                                   1106 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:71: void ak820_dynamic_macro_task(uint16_t now) {
                                   1107 ;	-----------------------------------------
                                   1108 ;	 function ak820_dynamic_macro_task
                                   1109 ;	-----------------------------------------
      003AE0                       1110 _ak820_dynamic_macro_task:
      003AE0 AF 83            [24] 1111 	mov	r7,dph
      003AE2 E5 82            [12] 1112 	mov	a,dpl
      003AE4 90 04 B2         [24] 1113 	mov	dptr,#_ak820_dynamic_macro_task_now_10000_624
      003AE7 F0               [24] 1114 	movx	@dptr,a
      003AE8 EF               [12] 1115 	mov	a,r7
      003AE9 A3               [24] 1116 	inc	dptr
      003AEA F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:72: if (!dm_play || ak820_macro_primitive || ak820_keyboard_report_pending() || (uint16_t)(now - dm_time) < 10) return;
      003AEB 90 04 A3         [24] 1119 	mov	dptr,#_dm_play
      003AEE E0               [24] 1120 	movx	a,@dptr
      003AEF 60 2D            [24] 1121 	jz	00101$
      003AF1 90 09 D5         [24] 1122 	mov	dptr,#_ak820_macro_primitive
      003AF4 E0               [24] 1123 	movx	a,@dptr
      003AF5 70 27            [24] 1124 	jnz	00101$
      003AF7 12 4C A5         [24] 1125 	lcall	_ak820_keyboard_report_pending
      003AFA E5 82            [12] 1126 	mov	a, dpl
      003AFC 70 20            [24] 1127 	jnz	00101$
      003AFE 90 04 A7         [24] 1128 	mov	dptr,#_dm_time
      003B01 E0               [24] 1129 	movx	a,@dptr
      003B02 FE               [12] 1130 	mov	r6,a
      003B03 A3               [24] 1131 	inc	dptr
      003B04 E0               [24] 1132 	movx	a,@dptr
      003B05 FF               [12] 1133 	mov	r7,a
      003B06 90 04 B2         [24] 1134 	mov	dptr,#_ak820_dynamic_macro_task_now_10000_624
      003B09 E0               [24] 1135 	movx	a,@dptr
      003B0A FC               [12] 1136 	mov	r4,a
      003B0B A3               [24] 1137 	inc	dptr
      003B0C E0               [24] 1138 	movx	a,@dptr
      003B0D FD               [12] 1139 	mov	r5,a
      003B0E EC               [12] 1140 	mov	a,r4
      003B0F C3               [12] 1141 	clr	c
      003B10 9E               [12] 1142 	subb	a,r6
      003B11 FE               [12] 1143 	mov	r6,a
      003B12 ED               [12] 1144 	mov	a,r5
      003B13 9F               [12] 1145 	subb	a,r7
      003B14 FF               [12] 1146 	mov	r7,a
      003B15 C3               [12] 1147 	clr	c
      003B16 EE               [12] 1148 	mov	a,r6
      003B17 94 0A            [12] 1149 	subb	a,#0x0a
      003B19 EF               [12] 1150 	mov	a,r7
      003B1A 94 00            [12] 1151 	subb	a,#0x00
      003B1C 50 01            [24] 1152 	jnc	00102$
      003B1E                       1153 00101$:
      003B1E 22               [24] 1154 	ret
      003B1F                       1155 00102$:
                                   1156 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:73: dm_time = now;
      003B1F 90 04 A7         [24] 1157 	mov	dptr,#_dm_time
      003B22 EC               [12] 1158 	mov	a,r4
      003B23 F0               [24] 1159 	movx	@dptr,a
      003B24 ED               [12] 1160 	mov	a,r5
      003B25 A3               [24] 1161 	inc	dptr
      003B26 F0               [24] 1162 	movx	@dptr,a
                                   1163 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:74: if (dm_down) {
      003B27 90 04 A5         [24] 1164 	mov	dptr,#_dm_down
      003B2A E0               [24] 1165 	movx	a,@dptr
      003B2B FF               [12] 1166 	mov	r7,a
      003B2C E0               [24] 1167 	movx	a,@dptr
      003B2D 60 16            [24] 1168 	jz	00112$
                                   1169 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:75: del_owned_key(dm_down);
      003B2F 8F 82            [24] 1170 	mov	dpl, r7
      003B31 12 81 59         [24] 1171 	lcall	_del_owned_key
                                   1172 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:76: del_owned_mods(dm_mods);
      003B34 90 04 A6         [24] 1173 	mov	dptr,#_dm_mods
      003B37 E0               [24] 1174 	movx	a,@dptr
      003B38 F5 82            [12] 1175 	mov	dpl,a
      003B3A 12 80 4C         [24] 1176 	lcall	_del_owned_mods
                                   1177 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:77: dm_down = 0;
      003B3D 90 04 A5         [24] 1178 	mov	dptr,#_dm_down
      003B40 E4               [12] 1179 	clr	a
      003B41 F0               [24] 1180 	movx	@dptr,a
                                   1181 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:78: send_keyboard_report();
      003B42 02 83 77         [24] 1182 	ljmp	_send_keyboard_report
      003B45                       1183 00112$:
                                   1184 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:79: } else if (dm_index == dm_lengths[dm_play - 1]) {
      003B45 90 04 A3         [24] 1185 	mov	dptr,#_dm_play
      003B48 E0               [24] 1186 	movx	a,@dptr
      003B49 FF               [12] 1187 	mov	r7,a
      003B4A 14               [12] 1188 	dec	a
      003B4B FE               [12] 1189 	mov	r6,a
      003B4C 33               [12] 1190 	rlc	a
      003B4D 95 E0            [12] 1191 	subb	a,acc
      003B4F FD               [12] 1192 	mov	r5,a
      003B50 EE               [12] 1193 	mov	a,r6
      003B51 24 A0            [12] 1194 	add	a, #_dm_lengths
      003B53 F5 82            [12] 1195 	mov	dpl,a
      003B55 ED               [12] 1196 	mov	a,r5
      003B56 34 04            [12] 1197 	addc	a, #(_dm_lengths >> 8)
      003B58 F5 83            [12] 1198 	mov	dph,a
      003B5A E0               [24] 1199 	movx	a,@dptr
      003B5B FE               [12] 1200 	mov	r6,a
      003B5C 90 04 A4         [24] 1201 	mov	dptr,#_dm_index
      003B5F E0               [24] 1202 	movx	a,@dptr
      003B60 FD               [12] 1203 	mov	r5,a
      003B61 B5 06 06         [24] 1204 	cjne	a,ar6,00109$
                                   1205 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:80: dm_play = 0;
      003B64 90 04 A3         [24] 1206 	mov	dptr,#_dm_play
      003B67 E4               [12] 1207 	clr	a
      003B68 F0               [24] 1208 	movx	@dptr,a
      003B69 22               [24] 1209 	ret
      003B6A                       1210 00109$:
                                   1211 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:82: uint8_t i = (dm_play - 1) * 16 + dm_index++;
      003B6A 1F               [12] 1212 	dec	r7
      003B6B EF               [12] 1213 	mov	a,r7
      003B6C C4               [12] 1214 	swap	a
      003B6D 54 F0            [12] 1215 	anl	a,#0xf0
      003B6F FF               [12] 1216 	mov	r7,a
      003B70 8D 06            [24] 1217 	mov	ar6,r5
      003B72 90 04 A4         [24] 1218 	mov	dptr,#_dm_index
      003B75 ED               [12] 1219 	mov	a,r5
      003B76 04               [12] 1220 	inc	a
      003B77 F0               [24] 1221 	movx	@dptr,a
      003B78 EE               [12] 1222 	mov	a,r6
      003B79 2F               [12] 1223 	add	a, r7
      003B7A FF               [12] 1224 	mov	r7,a
      003B7B 90 04 B4         [24] 1225 	mov	dptr,#_ak820_dynamic_macro_task_i_40000_631
      003B7E F0               [24] 1226 	movx	@dptr,a
                                   1227 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:83: uint8_t code = dm_taps[i].code;
      003B7F 8F E0            [24] 1228 	mov	acc,r7
      003B81 75 F0 02         [24] 1229 	mov	b,#0x02
      003B84 A4               [48] 1230 	mul	ab
      003B85 24 60            [12] 1231 	add	a, #_dm_taps
      003B87 F5 82            [12] 1232 	mov	dpl,a
      003B89 74 04            [12] 1233 	mov	a,#(_dm_taps >> 8)
      003B8B 35 F0            [12] 1234 	addc	a, b
      003B8D F5 83            [12] 1235 	mov	dph,a
      003B8F E0               [24] 1236 	movx	a,@dptr
      003B90 FF               [12] 1237 	mov	r7,a
      003B91 90 04 B5         [24] 1238 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_631
      003B94 F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:86: if (!add_owned_key(code)) {
      003B95 8F 82            [24] 1241 	mov	dpl, r7
      003B97 12 80 DF         [24] 1242 	lcall	_add_owned_key
      003B9A E5 82            [12] 1243 	mov	a, dpl
      003B9C 70 09            [24] 1244 	jnz	00107$
                                   1245 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:87: del_owned_key(code);
      003B9E 90 04 B5         [24] 1246 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_631
      003BA1 E0               [24] 1247 	movx	a,@dptr
      003BA2 F5 82            [12] 1248 	mov	dpl,a
                                   1249 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:88: return;
      003BA4 02 81 59         [24] 1250 	ljmp	_del_owned_key
      003BA7                       1251 00107$:
                                   1252 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:90: dm_down = code;
      003BA7 90 04 B5         [24] 1253 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_631
      003BAA E0               [24] 1254 	movx	a,@dptr
      003BAB 90 04 A5         [24] 1255 	mov	dptr,#_dm_down
      003BAE F0               [24] 1256 	movx	@dptr,a
                                   1257 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:91: dm_mods = dm_taps[i].mods;
      003BAF 90 04 B4         [24] 1258 	mov	dptr,#_ak820_dynamic_macro_task_i_40000_631
      003BB2 E0               [24] 1259 	movx	a,@dptr
      003BB3 75 F0 02         [24] 1260 	mov	b,#0x02
      003BB6 A4               [48] 1261 	mul	ab
      003BB7 24 60            [12] 1262 	add	a, #_dm_taps
      003BB9 FE               [12] 1263 	mov	r6,a
      003BBA 74 04            [12] 1264 	mov	a,#(_dm_taps >> 8)
      003BBC 35 F0            [12] 1265 	addc	a, b
      003BBE FF               [12] 1266 	mov	r7,a
      003BBF 8E 82            [24] 1267 	mov	dpl,r6
      003BC1 8F 83            [24] 1268 	mov	dph,r7
      003BC3 A3               [24] 1269 	inc	dptr
      003BC4 E0               [24] 1270 	movx	a,@dptr
      003BC5 FF               [12] 1271 	mov	r7,a
      003BC6 90 04 A6         [24] 1272 	mov	dptr,#_dm_mods
      003BC9 F0               [24] 1273 	movx	@dptr,a
                                   1274 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:92: add_owned_mods(dm_mods);
      003BCA 8F 82            [24] 1275 	mov	dpl, r7
      003BCC 12 80 3C         [24] 1276 	lcall	_add_owned_mods
                                   1277 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:93: send_keyboard_report();
                                   1278 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:95: }
      003BCF 02 83 77         [24] 1279 	ljmp	_send_keyboard_report
                                   1280 	.area CSEG    (CODE)
                                   1281 	.area CONST   (CODE)
                                   1282 	.area XINIT   (CODE)
                                   1283 	.area CABS    (ABS,CODE)
