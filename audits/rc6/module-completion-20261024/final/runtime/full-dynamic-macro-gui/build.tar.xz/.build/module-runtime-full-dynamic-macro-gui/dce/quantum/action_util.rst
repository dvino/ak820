                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_gui_process
                                    269 	.globl _ak820_macro_change
                                    270 	.globl _add_owned_mods
                                    271 	.globl _del_owned_mods
                                    272 	.globl _add_owned_weak_mods
                                    273 	.globl _del_owned_weak_mods
                                    274 	.globl _clear_owned_mods
                                    275 	.globl _clear_owned_keys
                                    276 	.globl _add_owned_key
                                    277 	.globl _del_owned_key
                                    278 	.globl _clear_owned_usages
                                    279 	.globl _owned_usage_key
                                    280 	.globl _send_keyboard_report
                                    281 	.globl _get_mods
                                    282 	.globl _clear_mods
                                    283 	.globl _get_weak_mods
                                    284 	.globl _add_weak_mods
                                    285 	.globl _del_weak_mods
                                    286 	.globl _clear_weak_mods
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 	.area	OSEG    (OVR,DATA)
      000055                        553 _change_owned_sloc1_1_0:
      000055                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      000020                        568 _gui_disabled:
      000020                        569 	.ds 1
      000021                        570 _ak820_gui_process_sloc0_1_0:
      000021                        571 	.ds 1
      000022                        572 _ak820_macro_change_sloc0_1_0:
      000022                        573 	.ds 1
      000023                        574 _change_owned_sloc0_1_0:
      000023                        575 	.ds 1
      000024                        576 _owned_usage_key_sloc0_1_0:
      000024                        577 	.ds 1
                                    578 ;--------------------------------------------------------
                                    579 ; paged external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area PSEG    (PAG,XDATA)
                                    582 ;--------------------------------------------------------
                                    583 ; uninitialized external ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area XSEG    (XDATA)
      0009BE                        586 _ak820_gui_process_PARM_2:
      0009BE                        587 	.ds 1
      0009BF                        588 _ak820_gui_process_code_10000_294:
      0009BF                        589 	.ds 2
      0009C1                        590 _owned_mod_refs:
      0009C1                        591 	.ds 8
      0009C9                        592 _owned_weak_refs:
      0009C9                        593 	.ds 8
      0009D1                        594 _owned_mods:
      0009D1                        595 	.ds 1
      0009D2                        596 _owned_weak_mods:
      0009D2                        597 	.ds 1
      0009D3                        598 _macro_mods:
      0009D3                        599 	.ds 2
      0009D5                        600 _ak820_macro_primitive::
      0009D5                        601 	.ds 1
      0009D6                        602 _ak820_macro_cancelled::
      0009D6                        603 	.ds 1
      0009D7                        604 _ak820_macro_change_PARM_2:
      0009D7                        605 	.ds 1
      0009D8                        606 _ak820_macro_change_PARM_3:
      0009D8                        607 	.ds 1
      0009D9                        608 _ak820_macro_change_bits_10000_299:
      0009D9                        609 	.ds 2
      0009DB                        610 _change_owned_PARM_2:
      0009DB                        611 	.ds 1
      0009DC                        612 _change_owned_mods_10000_304:
      0009DC                        613 	.ds 1
      0009DD                        614 _change_owned_result_10001_308:
      0009DD                        615 	.ds 1
      0009DE                        616 _change_owned_bit_20001_309:
      0009DE                        617 	.ds 1
      0009DF                        618 _add_owned_mods_mods_10000_317:
      0009DF                        619 	.ds 1
      0009E0                        620 _del_owned_mods_mods_10000_319:
      0009E0                        621 	.ds 1
      0009E1                        622 _add_owned_weak_mods_mods_10000_321:
      0009E1                        623 	.ds 1
      0009E2                        624 _del_owned_weak_mods_mods_10000_323:
      0009E2                        625 	.ds 1
      0009E3                        626 _key_refs:
      0009E3                        627 	.ds 165
      000A88                        628 _distinct_keys:
      000A88                        629 	.ds 1
      000A89                        630 _macro_keys:
      000A89                        631 	.ds 21
      000A9E                        632 _add_owned_key_code_10000_332:
      000A9E                        633 	.ds 1
      000A9F                        634 _del_owned_key_code_10000_347:
      000A9F                        635 	.ds 1
      000AA0                        636 _usage_refs:
      000AA0                        637 	.ds 30
      000ABE                        638 _usage_order:
      000ABE                        639 	.ds 30
      000ADC                        640 _usage_lengths:
      000ADC                        641 	.ds 2
      000ADE                        642 _macro_usages:
      000ADE                        643 	.ds 4
      000AE2                        644 _owned_usage_key_PARM_2:
      000AE2                        645 	.ds 1
      000AE3                        646 _owned_usage_key_code_10000_374:
      000AE3                        647 	.ds 1
      000AE4                        648 _owned_usage_key___200000085_20000_375:
      000AE4                        649 	.ds 2
      000AE6                        650 _owned_usage_key_which_10000_375:
      000AE6                        651 	.ds 1
      000AE7                        652 _owned_usage_key_count_10000_375:
      000AE7                        653 	.ds 1
      000AE8                        654 _owned_usage_key_pos_30001_382:
      000AE8                        655 	.ds 1
      000AE9                        656 _owned_usage_key_key_40000_387:
      000AE9                        657 	.ds 1
      000AEA                        658 _send_keyboard_report_last_report_10001_395:
      000AEA                        659 	.ds 32
      000B0A                        660 _send_keyboard_report_changed_10001_395:
      000B0A                        661 	.ds 1
      000B0B                        662 _add_weak_mods_mods_10000_413:
      000B0B                        663 	.ds 1
      000B0C                        664 _del_weak_mods_mods_10000_415:
      000B0C                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000DEC                        674 _real_mods:
      000DEC                        675 	.ds 1
      000DED                        676 _weak_mods:
      000DED                        677 	.ds 1
      000DEE                        678 _actual_keyboard_report::
      000DEE                        679 	.ds 32
                                    680 	.area HOME    (CODE)
                                    681 	.area GSINIT0 (CODE)
                                    682 	.area GSINIT1 (CODE)
                                    683 	.area GSINIT2 (CODE)
                                    684 	.area GSINIT3 (CODE)
                                    685 	.area GSINIT4 (CODE)
                                    686 	.area GSINIT5 (CODE)
                                    687 	.area GSINIT  (CODE)
                                    688 	.area GSFINAL (CODE)
                                    689 	.area CSEG    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; global & static initialisations
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area GSINIT  (CODE)
                                    695 	.area GSFINAL (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    708 ;------------------------------------------------------------
                                    709 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    710 ;------------------------------------------------------------
                                    711 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function ak820_gui_process
                                    722 ;	-----------------------------------------
      007EB1                        723 _ak820_gui_process:
      007EB1 12 38 4A         [24]  724 	lcall	_ak820_outline_0104
      007EB4 90 09 BF         [24]  725 	mov	dptr,#_ak820_gui_process_code_10000_294
      007EB7 12 38 4F         [24]  726 	lcall	_ak820_outline_0105
                                    727 ;	quantum/action_util.c:80: if (code < QK_MAGIC_GUI_ON || code > QK_MAGIC_TOGGLE_GUI) return true;
      007EBA 90 09 BF         [24]  728 	mov	dptr,#_ak820_gui_process_code_10000_294
      007EBD 12 38 00         [24]  729 	lcall	_ak820_outline_0051
      007EC0 C3               [12]  730 	clr	c
      007EC1 EE               [12]  731 	mov	a,r6
      007EC2 94 09            [12]  732 	subb	a,#0x09
      007EC4 EF               [12]  733 	mov	a,r7
      007EC5 94 70            [12]  734 	subb	a,#0x70
      007EC7 40 08            [24]  735 	jc	00101$
      007EC9 74 0B            [12]  736 	mov	a,#0x0b
      007ECB 9E               [12]  737 	subb	a,r6
      007ECC 74 70            [12]  738 	mov	a,#0x70
      007ECE 9F               [12]  739 	subb	a,r7
      007ECF 50 04            [24]  740 	jnc	00102$
                                    741 ;	free result
      007ED1                        742 00101$:
      007ED1 75 82 01         [24]  743 	mov	dpl, #0x01
      007ED4 22               [24]  744 	ret
      007ED5                        745 00102$:
                                    746 ;	quantum/action_util.c:81: if (pressed) {
      007ED5 90 09 BE         [24]  747 	mov	dptr,#_ak820_gui_process_PARM_2
      007ED8 E0               [24]  748 	movx	a,@dptr
      007ED9 60 21            [24]  749 	jz	00105$
                                    750 ;	quantum/action_util.c:82: gui_disabled = code == QK_MAGIC_TOGGLE_GUI ? !gui_disabled : code == QK_MAGIC_GUI_OFF;
      007EDB BE 0B 0D         [24]  751 	cjne	r6,#0x0b,00108$
      007EDE BF 70 0A         [24]  752 	cjne	r7,#0x70,00108$
      007EE1 A2 20            [12]  753 	mov	c,_gui_disabled
      007EE3 B3               [12]  754 	cpl	c
      007EE4 92 21            [24]  755 	mov  _ak820_gui_process_sloc0_1_0,c
      007EE6 E4               [12]  756 	clr	a
      007EE7 33               [12]  757 	rlc	a
      007EE8 FD               [12]  758 	mov	r5,a
      007EE9 80 09            [24]  759 	sjmp	00109$
      007EEB                        760 00108$:
      007EEB E4               [12]  761 	clr	a
      007EEC BE 0A 04         [24]  762 	cjne	r6,#0x0a,00136$
      007EEF BF 70 01         [24]  763 	cjne	r7,#0x70,00136$
      007EF2 04               [12]  764 	inc	a
      007EF3                        765 00136$:
      007EF3 FD               [12]  766 	mov	r5,a
      007EF4                        767 00109$:
                                    768 ;	assignBit
      007EF4 ED               [12]  769 	mov	a,r5
      007EF5 24 FF            [12]  770 	add	a,#0xff
      007EF7 92 20            [24]  771 	mov	_gui_disabled,c
                                    772 ;	quantum/action_util.c:83: send_keyboard_report();
      007EF9 12 83 77         [24]  773 	lcall	_send_keyboard_report
      007EFC                        774 00105$:
                                    775 ;	quantum/action_util.c:85: return false;
      007EFC 75 82 00         [24]  776 	mov	dpl, #0x00
                                    777 ;	quantum/action_util.c:89: }
      007EFF 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'ak820_macro_change'
                                    781 ;------------------------------------------------------------
                                    782 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    783 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    784 ;bits          Allocated with name '_ak820_macro_change_bits_10000_299'
                                    785 ;mask          Allocated with name '_ak820_macro_change_mask_10001_302'
                                    786 ;------------------------------------------------------------
                                    787 ;	quantum/action_util.c:98: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    788 ;	-----------------------------------------
                                    789 ;	 function ak820_macro_change
                                    790 ;	-----------------------------------------
      007F00                        791 _ak820_macro_change:
      007F00 12 38 4A         [24]  792 	lcall	_ak820_outline_0104
      007F03 90 09 D9         [24]  793 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007F06 12 38 4F         [24]  794 	lcall	_ak820_outline_0105
                                    795 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      007F09 90 09 D5         [24]  796 	mov	dptr,#_ak820_macro_primitive
      007F0C E0               [24]  797 	movx	a,@dptr
      007F0D 70 04            [24]  798 	jnz	00102$
      007F0F 75 82 01         [24]  799 	mov	dpl, #0x01
      007F12 22               [24]  800 	ret
      007F13                        801 00102$:
                                    802 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      007F13 90 09 D7         [24]  803 	mov	dptr,#_ak820_macro_change_PARM_2
      007F16 E0               [24]  804 	movx	a,@dptr
      007F17 FF               [12]  805 	mov	r7,a
      007F18 74 07            [12]  806 	mov	a,#0x07
      007F1A 5F               [12]  807 	anl	a,r7
      007F1B 12 7A 51         [24]  808 	lcall	_ak820_outline_0062
      007F1E 80 02            [24]  809 	sjmp	00123$
      007F20                        810 00122$:
      007F20 25 E0            [12]  811 	add	a,acc
      007F22                        812 00123$:
      007F22 D5 F0 FB         [24]  813 	djnz	b,00122$
      007F25 FE               [12]  814 	mov	r6,a
                                    815 ;	quantum/action_util.c:101: bits += index >> 3;
      007F26 EF               [12]  816 	mov	a,r7
      007F27 12 5A 59         [24]  817 	lcall	_ak820_outline_0183
      007F2A FF               [12]  818 	mov	r7,a
      007F2B 90 09 D9         [24]  819 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007F2E 12 38 1F         [24]  820 	lcall	_ak820_outline_0059
      007F31 90 09 D9         [24]  821 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007F34 EF               [12]  822 	mov	a,r7
      007F35 2C               [12]  823 	add	a, r4
      007F36 F0               [24]  824 	movx	@dptr,a
      007F37 E4               [12]  825 	clr	a
      007F38 3D               [12]  826 	addc	a, r5
      007F39 A3               [24]  827 	inc	dptr
      007F3A F0               [24]  828 	movx	@dptr,a
                                    829 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      007F3B 90 09 D9         [24]  830 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007F3E E0               [24]  831 	movx	a,@dptr
      007F3F FD               [12]  832 	mov	r5,a
      007F40 A3               [24]  833 	inc	dptr
      007F41 E0               [24]  834 	movx	a,@dptr
      007F42 FF               [12]  835 	mov	r7,a
      007F43 12 84 90         [24]  836 	lcall	_ak820_outline_0185
      007F46 E0               [24]  837 	movx	a,@dptr
      007F47 FC               [12]  838 	mov	r4,a
      007F48 EE               [12]  839 	mov	a,r6
      007F49 5C               [12]  840 	anl	a,r4
      007F4A B4 01 00         [24]  841 	cjne	a,#0x01,00124$
      007F4D                        842 00124$:
      007F4D B3               [12]  843 	cpl	c
      007F4E 92 22            [24]  844 	mov	_ak820_macro_change_sloc0_1_0,c
      007F50 90 09 D8         [24]  845 	mov	dptr,#_ak820_macro_change_PARM_3
      007F53 E0               [24]  846 	movx	a,@dptr
      007F54 FB               [12]  847 	mov	r3,a
      007F55 A2 22            [12]  848 	mov	c,_ak820_macro_change_sloc0_1_0
      007F57 E4               [12]  849 	clr	a
      007F58 33               [12]  850 	rlc	a
      007F59 B5 03 04         [24]  851 	cjne	a,ar3,00104$
      007F5C 75 82 00         [24]  852 	mov	dpl, #0x00
      007F5F 22               [24]  853 	ret
      007F60                        854 00104$:
                                    855 ;	quantum/action_util.c:103: *bits ^= mask;
      007F60 EC               [12]  856 	mov	a,r4
      007F61 62 06            [12]  857 	xrl	ar6,a
      007F63 12 84 90         [24]  858 	lcall	_ak820_outline_0185
      007F66 EE               [12]  859 	mov	a,r6
      007F67 F0               [24]  860 	movx	@dptr,a
                                    861 ;	quantum/action_util.c:104: return true;
      007F68 75 82 01         [24]  862 	mov	dpl, #0x01
                                    863 ;	quantum/action_util.c:105: }
      007F6B 22               [24]  864 	ret
                                    865 ;------------------------------------------------------------
                                    866 ;Allocation info for local variables in function 'change_owned'
                                    867 ;------------------------------------------------------------
                                    868 ;mode          Allocated with name '_change_owned_PARM_2'
                                    869 ;mods          Allocated with name '_change_owned_mods_10000_304'
                                    870 ;kind          Allocated with name '_change_owned_kind_10000_305'
                                    871 ;pressed       Allocated with name '_change_owned_pressed_10000_305'
                                    872 ;refs          Allocated with name '_change_owned_refs_10000_305'
                                    873 ;old           Allocated with name '_change_owned_old_30000_307'
                                    874 ;result        Allocated with name '_change_owned_result_10001_308'
                                    875 ;i             Allocated with name '_change_owned_i_20001_309'
                                    876 ;bit           Allocated with name '_change_owned_bit_20001_309'
                                    877 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    878 ;------------------------------------------------------------
                                    879 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    880 ;	-----------------------------------------
                                    881 ;	 function change_owned
                                    882 ;	-----------------------------------------
      007F6C                        883 _change_owned:
      007F6C E5 82            [12]  884 	mov	a,dpl
      007F6E 90 09 DC         [24]  885 	mov	dptr,#_change_owned_mods_10000_304
      007F71 F0               [24]  886 	movx	@dptr,a
                                    887 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      007F72 90 09 DB         [24]  888 	mov	dptr,#_change_owned_PARM_2
      007F75 E0               [24]  889 	movx	a,@dptr
      007F76 FF               [12]  890 	mov	r7,a
      007F77 C3               [12]  891 	clr	c
      007F78 13               [12]  892 	rrc	a
      007F79 FE               [12]  893 	mov	r6,a
                                    894 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      007F7A 53 07 01         [24]  895 	anl	ar7,#0x01
      007F7D EF               [12]  896 	mov	a,r7
      007F7E B4 01 00         [24]  897 	cjne	a,#0x01,00205$
      007F81                        898 00205$:
      007F81 92 23            [24]  899 	mov  _change_owned_sloc0_1_0,c
      007F83 B3               [12]  900 	cpl	c
      007F84 E4               [12]  901 	clr	a
      007F85 33               [12]  902 	rlc	a
      007F86 F5 55            [12]  903 	mov	_change_owned_sloc1_1_0,a
                                    904 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007F88 EE               [12]  905 	mov	a,r6
      007F89 60 06            [24]  906 	jz	00121$
      007F8B 7D C9            [12]  907 	mov	r5,#_owned_weak_refs
      007F8D 7F 09            [12]  908 	mov	r7,#(_owned_weak_refs >> 8)
      007F8F 80 04            [24]  909 	sjmp	00122$
      007F91                        910 00121$:
      007F91 7D C1            [12]  911 	mov	r5,#_owned_mod_refs
      007F93 7F 09            [12]  912 	mov	r7,#(_owned_mod_refs >> 8)
      007F95                        913 00122$:
                                    914 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      007F95 90 09 D5         [24]  915 	mov	dptr,#_ak820_macro_primitive
      007F98 E0               [24]  916 	movx	a,@dptr
      007F99 60 37            [24]  917 	jz	00102$
                                    918 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      007F9B EE               [12]  919 	mov	a,r6
      007F9C 24 D3            [12]  920 	add	a, #_macro_mods
      007F9E FB               [12]  921 	mov	r3,a
      007F9F E4               [12]  922 	clr	a
      007FA0 34 09            [12]  923 	addc	a, #(_macro_mods >> 8)
      007FA2 FC               [12]  924 	mov	r4,a
      007FA3 12 4B A4         [24]  925 	lcall	_ak820_outline_0064
                                    926 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007FA6 E5 55            [12]  927 	mov	a,_change_owned_sloc1_1_0
      007FA8 60 0A            [24]  928 	jz	00123$
      007FAA 90 09 DC         [24]  929 	mov	dptr,#_change_owned_mods_10000_304
      007FAD E0               [24]  930 	movx	a,@dptr
      007FAE F9               [12]  931 	mov	r1,a
      007FAF EA               [12]  932 	mov	a,r2
      007FB0 42 01            [12]  933 	orl	ar1,a
      007FB2 80 07            [24]  934 	sjmp	00124$
      007FB4                        935 00123$:
      007FB4 90 09 DC         [24]  936 	mov	dptr,#_change_owned_mods_10000_304
      007FB7 E0               [24]  937 	movx	a,@dptr
      007FB8 F4               [12]  938 	cpl	a
      007FB9 5A               [12]  939 	anl	a,r2
      007FBA F9               [12]  940 	mov	r1,a
      007FBB                        941 00124$:
      007FBB 12 33 FC         [24]  942 	lcall	_ak820_outline_0122
      007FBE E9               [12]  943 	mov	a,r1
      007FBF F0               [24]  944 	movx	@dptr,a
                                    945 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      007FC0 E5 55            [12]  946 	mov	a,_change_owned_sloc1_1_0
      007FC2 60 06            [24]  947 	jz	00125$
      007FC4 74 FF            [12]  948 	mov	a,#0xff
      007FC6 6A               [12]  949 	xrl	a,r2
      007FC7 FC               [12]  950 	mov	r4,a
      007FC8 80 02            [24]  951 	sjmp	00126$
      007FCA                        952 00125$:
      007FCA 8A 04            [24]  953 	mov	ar4,r2
      007FCC                        954 00126$:
      007FCC 90 09 DC         [24]  955 	mov	dptr,#_change_owned_mods_10000_304
      007FCF E0               [24]  956 	movx	a,@dptr
      007FD0 5C               [12]  957 	anl	a,r4
      007FD1 F0               [24]  958 	movx	@dptr,a
      007FD2                        959 00102$:
                                    960 ;	quantum/action_util.c:115: uint8_t result = 0;
      007FD2 90 09 DD         [24]  961 	mov	dptr,#_change_owned_result_10001_308
      007FD5 E4               [12]  962 	clr	a
      007FD6 F0               [24]  963 	movx	@dptr,a
                                    964 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007FD7 90 09 DE         [24]  965 	mov	dptr,#_change_owned_bit_20001_309
      007FDA 04               [12]  966 	inc	a
      007FDB F0               [24]  967 	movx	@dptr,a
      007FDC 90 09 DC         [24]  968 	mov	dptr,#_change_owned_mods_10000_304
      007FDF E0               [24]  969 	movx	a,@dptr
      007FE0 FC               [12]  970 	mov	r4,a
      007FE1 7B 00            [12]  971 	mov	r3,#0x00
      007FE3                        972 00117$:
      007FE3 BB 08 00         [24]  973 	cjne	r3,#0x08,00210$
      007FE6                        974 00210$:
      007FE6 50 3F            [24]  975 	jnc	00112$
                                    976 ;	quantum/action_util.c:117: if (mods & bit) {
      007FE8 90 09 DE         [24]  977 	mov	dptr,#_change_owned_bit_20001_309
      007FEB E0               [24]  978 	movx	a,@dptr
      007FEC 5C               [12]  979 	anl	a,r4
      007FED 60 1C            [24]  980 	jz	00109$
                                    981 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      007FEF E5 55            [12]  982 	mov	a,_change_owned_sloc1_1_0
      007FF1 60 0C            [24]  983 	jz	00106$
      007FF3 EB               [12]  984 	mov	a,r3
      007FF4 2D               [12]  985 	add	a, r5
      007FF5 12 37 D5         [24]  986 	lcall	_ak820_outline_0014
      007FF8 F8               [12]  987 	mov	r0,a
      007FF9 08               [12]  988 	inc	r0
      007FFA 12 84 44         [24]  989 	lcall	_ak820_outline_0063
      007FFD 80 0C            [24]  990 	sjmp	00109$
      007FFF                        991 00106$:
                                    992 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      007FFF EB               [12]  993 	mov	a,r3
      008000 2D               [12]  994 	add	a, r5
      008001 12 37 D5         [24]  995 	lcall	_ak820_outline_0014
      008004 F8               [12]  996 	mov	r0,a
      008005 60 04            [24]  997 	jz	00109$
      008007 18               [12]  998 	dec	r0
      008008 12 84 44         [24]  999 	lcall	_ak820_outline_0063
      00800B                       1000 00109$:
                                   1001 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      00800B EB               [12] 1002 	mov	a,r3
      00800C 2D               [12] 1003 	add	a, r5
      00800D 12 37 D5         [24] 1004 	lcall	_ak820_outline_0014
      008010 60 0B            [24] 1005 	jz	00118$
      008012 90 09 DE         [24] 1006 	mov	dptr,#_change_owned_bit_20001_309
      008015 E0               [24] 1007 	movx	a,@dptr
      008016 FA               [12] 1008 	mov	r2,a
      008017 90 09 DD         [24] 1009 	mov	dptr,#_change_owned_result_10001_308
      00801A E0               [24] 1010 	movx	a,@dptr
      00801B 4A               [12] 1011 	orl	a,r2
      00801C F0               [24] 1012 	movx	@dptr,a
      00801D                       1013 00118$:
                                   1014 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      00801D 0B               [12] 1015 	inc	r3
      00801E 90 09 DE         [24] 1016 	mov	dptr,#_change_owned_bit_20001_309
      008021 E0               [24] 1017 	movx	a,@dptr
      008022 25 E0            [12] 1018 	add	a,acc
      008024 F0               [24] 1019 	movx	@dptr,a
      008025 80 BC            [24] 1020 	sjmp	00117$
      008027                       1021 00112$:
                                   1022 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      008027 EE               [12] 1023 	mov	a,r6
      008028 60 09            [24] 1024 	jz	00114$
      00802A 90 09 DD         [24] 1025 	mov	dptr,#_change_owned_result_10001_308
      00802D E0               [24] 1026 	movx	a,@dptr
      00802E 90 09 D2         [24] 1027 	mov	dptr,#_owned_weak_mods
      008031 F0               [24] 1028 	movx	@dptr,a
      008032 22               [24] 1029 	ret
      008033                       1030 00114$:
                                   1031 ;	quantum/action_util.c:124: else owned_mods = result;
      008033 90 09 DD         [24] 1032 	mov	dptr,#_change_owned_result_10001_308
      008036 E0               [24] 1033 	movx	a,@dptr
      008037 90 09 D1         [24] 1034 	mov	dptr,#_owned_mods
      00803A F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	quantum/action_util.c:125: }
      00803B 22               [24] 1037 	ret
                                   1038 ;------------------------------------------------------------
                                   1039 ;Allocation info for local variables in function 'add_owned_mods'
                                   1040 ;------------------------------------------------------------
                                   1041 ;mods          Allocated with name '_add_owned_mods_mods_10000_317'
                                   1042 ;------------------------------------------------------------
                                   1043 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1044 ;	-----------------------------------------
                                   1045 ;	 function add_owned_mods
                                   1046 ;	-----------------------------------------
      00803C                       1047 _add_owned_mods:
      00803C E5 82            [12] 1048 	mov	a,dpl
      00803E 90 09 DF         [24] 1049 	mov	dptr,#_add_owned_mods_mods_10000_317
      008041 12 84 64         [24] 1050 	lcall	_ak820_outline_0113
      008044 74 01            [12] 1051 	mov	a,#0x01
      008046 F0               [24] 1052 	movx	@dptr,a
      008047 8F 82            [24] 1053 	mov	dpl, r7
      008049 02 7F 6C         [24] 1054 	ljmp	_change_owned
                                   1055 ;------------------------------------------------------------
                                   1056 ;Allocation info for local variables in function 'del_owned_mods'
                                   1057 ;------------------------------------------------------------
                                   1058 ;mods          Allocated with name '_del_owned_mods_mods_10000_319'
                                   1059 ;------------------------------------------------------------
                                   1060 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1061 ;	-----------------------------------------
                                   1062 ;	 function del_owned_mods
                                   1063 ;	-----------------------------------------
      00804C                       1064 _del_owned_mods:
      00804C E5 82            [12] 1065 	mov	a,dpl
      00804E 90 09 E0         [24] 1066 	mov	dptr,#_del_owned_mods_mods_10000_319
      008051 12 84 64         [24] 1067 	lcall	_ak820_outline_0113
      008054 12 7A 92         [24] 1068 	lcall	_ak820_outline_0184
      008057 02 7F 6C         [24] 1069 	ljmp	_change_owned
                                   1070 ;------------------------------------------------------------
                                   1071 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1072 ;------------------------------------------------------------
                                   1073 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_321'
                                   1074 ;------------------------------------------------------------
                                   1075 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1076 ;	-----------------------------------------
                                   1077 ;	 function add_owned_weak_mods
                                   1078 ;	-----------------------------------------
      00805A                       1079 _add_owned_weak_mods:
      00805A E5 82            [12] 1080 	mov	a,dpl
      00805C 90 09 E1         [24] 1081 	mov	dptr,#_add_owned_weak_mods_mods_10000_321
      00805F 12 84 64         [24] 1082 	lcall	_ak820_outline_0113
      008062 74 03            [12] 1083 	mov	a,#0x03
      008064 F0               [24] 1084 	movx	@dptr,a
      008065 8F 82            [24] 1085 	mov	dpl, r7
      008067 02 7F 6C         [24] 1086 	ljmp	_change_owned
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1089 ;------------------------------------------------------------
                                   1090 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_323'
                                   1091 ;------------------------------------------------------------
                                   1092 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1093 ;	-----------------------------------------
                                   1094 ;	 function del_owned_weak_mods
                                   1095 ;	-----------------------------------------
      00806A                       1096 _del_owned_weak_mods:
      00806A E5 82            [12] 1097 	mov	a,dpl
      00806C 90 09 E2         [24] 1098 	mov	dptr,#_del_owned_weak_mods_mods_10000_323
      00806F 12 84 64         [24] 1099 	lcall	_ak820_outline_0113
      008072 74 02            [12] 1100 	mov	a,#0x02
      008074 F0               [24] 1101 	movx	@dptr,a
      008075 8F 82            [24] 1102 	mov	dpl, r7
      008077 02 7F 6C         [24] 1103 	ljmp	_change_owned
                                   1104 ;------------------------------------------------------------
                                   1105 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1106 ;------------------------------------------------------------
                                   1107 ;i             Allocated with name '_clear_owned_mods_i_20000_327'
                                   1108 ;------------------------------------------------------------
                                   1109 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1110 ;	-----------------------------------------
                                   1111 ;	 function clear_owned_mods
                                   1112 ;	-----------------------------------------
      00807A                       1113 _clear_owned_mods:
                                   1114 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      00807A 7F 00            [12] 1115 	mov	r7,#0x00
      00807C                       1116 00103$:
      00807C BF 08 00         [24] 1117 	cjne	r7,#0x08,00122$
      00807F                       1118 00122$:
      00807F 50 1A            [24] 1119 	jnc	00101$
      008081 EF               [12] 1120 	mov	a,r7
      008082 24 C1            [12] 1121 	add	a, #_owned_mod_refs
      008084 FD               [12] 1122 	mov	r5,a
      008085 E4               [12] 1123 	clr	a
      008086 34 09            [12] 1124 	addc	a, #(_owned_mod_refs >> 8)
      008088 FE               [12] 1125 	mov	r6,a
      008089 EF               [12] 1126 	mov	a,r7
      00808A 24 C9            [12] 1127 	add	a, #_owned_weak_refs
      00808C F5 82            [12] 1128 	mov	dpl,a
      00808E E4               [12] 1129 	clr	a
      00808F 34 09            [12] 1130 	addc	a, #(_owned_weak_refs >> 8)
      008091 F5 83            [12] 1131 	mov	dph,a
      008093 E4               [12] 1132 	clr	a
      008094 F0               [24] 1133 	movx	@dptr,a
      008095 12 84 6B         [24] 1134 	lcall	_ak820_outline_0118
      008098 0F               [12] 1135 	inc	r7
      008099 80 E1            [24] 1136 	sjmp	00103$
      00809B                       1137 00101$:
                                   1138 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      00809B 90 09 D4         [24] 1139 	mov	dptr,#(_macro_mods + 0x0001)
      00809E E4               [12] 1140 	clr	a
      00809F F0               [24] 1141 	movx	@dptr,a
      0080A0 90 09 D3         [24] 1142 	mov	dptr,#_macro_mods
      0080A3 F0               [24] 1143 	movx	@dptr,a
      0080A4 90 09 D2         [24] 1144 	mov	dptr,#_owned_weak_mods
      0080A7 F0               [24] 1145 	movx	@dptr,a
      0080A8 90 09 D1         [24] 1146 	mov	dptr,#_owned_mods
      0080AB F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      0080AC 90 09 D6         [24] 1149 	mov	dptr,#_ak820_macro_cancelled
      0080AF 04               [12] 1150 	inc	a
      0080B0 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	quantum/action_util.c:134: }
      0080B1 22               [24] 1153 	ret
                                   1154 ;------------------------------------------------------------
                                   1155 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1156 ;------------------------------------------------------------
                                   1157 ;i             Allocated with name '_clear_owned_keys_i_20000_330'
                                   1158 ;i             Allocated with name '_clear_owned_keys_i_20000_331'
                                   1159 ;------------------------------------------------------------
                                   1160 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1161 ;	-----------------------------------------
                                   1162 ;	 function clear_owned_keys
                                   1163 ;	-----------------------------------------
      0080B2                       1164 _clear_owned_keys:
                                   1165 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      0080B2 7F 00            [12] 1166 	mov	r7,#0x00
      0080B4                       1167 00104$:
      0080B4 EF               [12] 1168 	mov	a,r7
      0080B5 24 5B            [12] 1169 	add	a,#0xff - 0xa4
      0080B7 40 0D            [24] 1170 	jc	00101$
                                   1171 ;	free result
      0080B9 EF               [12] 1172 	mov	a,r7
      0080BA 24 E3            [12] 1173 	add	a, #_key_refs
      0080BC F5 82            [12] 1174 	mov	dpl,a
      0080BE E4               [12] 1175 	clr	a
      0080BF 34 09            [12] 1176 	addc	a, #(_key_refs >> 8)
      0080C1 12 7E A2         [24] 1177 	lcall	_ak820_outline_0158
      0080C4 80 EE            [24] 1178 	sjmp	00104$
      0080C6                       1179 00101$:
                                   1180 ;	quantum/action_util.c:142: distinct_keys = 0;
      0080C6 90 0A 88         [24] 1181 	mov	dptr,#_distinct_keys
      0080C9 E4               [12] 1182 	clr	a
      0080CA F0               [24] 1183 	movx	@dptr,a
                                   1184 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      0080CB FF               [12] 1185 	mov	r7,a
      0080CC                       1186 00107$:
      0080CC BF 15 00         [24] 1187 	cjne	r7,#0x15,00142$
      0080CF                       1188 00142$:
      0080CF 50 0D            [24] 1189 	jnc	00109$
      0080D1 EF               [12] 1190 	mov	a,r7
      0080D2 24 89            [12] 1191 	add	a, #_macro_keys
      0080D4 F5 82            [12] 1192 	mov	dpl,a
      0080D6 E4               [12] 1193 	clr	a
      0080D7 34 0A            [12] 1194 	addc	a, #(_macro_keys >> 8)
      0080D9 12 7E A2         [24] 1195 	lcall	_ak820_outline_0158
      0080DC 80 EE            [24] 1196 	sjmp	00107$
      0080DE                       1197 00109$:
                                   1198 ;	quantum/action_util.c:144: }
      0080DE 22               [24] 1199 	ret
                                   1200 ;------------------------------------------------------------
                                   1201 ;Allocation info for local variables in function 'add_owned_key'
                                   1202 ;------------------------------------------------------------
                                   1203 ;code          Allocated with name '_add_owned_key_code_10000_332'
                                   1204 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_341'
                                   1205 ;key           Allocated with name '_add_owned_key_key_50000_342'
                                   1206 ;i             Allocated with name '_add_owned_key_i_40000_340'
                                   1207 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_344'
                                   1208 ;key           Allocated with name '_add_owned_key_key_40000_345'
                                   1209 ;------------------------------------------------------------
                                   1210 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1211 ;	-----------------------------------------
                                   1212 ;	 function add_owned_key
                                   1213 ;	-----------------------------------------
      0080DF                       1214 _add_owned_key:
      0080DF E5 82            [12] 1215 	mov	a,dpl
      0080E1 90 0A 9E         [24] 1216 	mov	dptr,#_add_owned_key_code_10000_332
      0080E4 12 84 7C         [24] 1217 	lcall	_ak820_outline_0130
                                   1218 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      0080E7 74 01            [12] 1219 	mov	a,#0x01
      0080E9 F0               [24] 1220 	movx	@dptr,a
      0080EA 90 0A 89         [24] 1221 	mov	dptr,#_macro_keys
      0080ED C0 07            [24] 1222 	push	ar7
      0080EF 12 7F 00         [24] 1223 	lcall	_ak820_macro_change
      0080F2 E5 82            [12] 1224 	mov	a, dpl
      0080F4 D0 07            [24] 1225 	pop	ar7
      0080F6 70 03            [24] 1226 	jnz	00102$
      0080F8 F5 82            [12] 1227 	mov	dpl,a
      0080FA 22               [24] 1228 	ret
      0080FB                       1229 00102$:
                                   1230 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      0080FB 12 84 36         [24] 1231 	lcall	_ak820_outline_0028
      0080FE FC               [12] 1232 	mov	r4,a
      0080FF 04               [12] 1233 	inc	a
      008100 12 84 6B         [24] 1234 	lcall	_ak820_outline_0118
      008103 EC               [12] 1235 	mov	a,r4
      008104 60 04            [24] 1236 	jz	00104$
      008106 75 82 00         [24] 1237 	mov	dpl, #0x00
      008109 22               [24] 1238 	ret
      00810A                       1239 00104$:
                                   1240 ;	quantum/action_util.c:148: ++distinct_keys;
      00810A 90 0A 88         [24] 1241 	mov	dptr,#_distinct_keys
      00810D E0               [24] 1242 	movx	a,@dptr
      00810E 24 01            [12] 1243 	add	a, #0x01
      008110 F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      008111 90 0D DB         [24] 1246 	mov	dptr,#_keyboard_protocol
      008114 E0               [24] 1247 	movx	a,@dptr
      008115 60 11            [24] 1248 	jz	00106$
      008117 90 0B 0D         [24] 1249 	mov	dptr,#_keymap_config
      00811A E0               [24] 1250 	movx	a,@dptr
      00811B 30 E7 0A         [24] 1251 	jnb	acc.7,00106$
                                   1252 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00811E 12 84 87         [24] 1253 	lcall	_ak820_outline_0171
      008121 12 71 E2         [24] 1254 	lcall	_add_key_to_report
                                   1255 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      008124 75 82 01         [24] 1256 	mov	dpl, #0x01
      008127 22               [24] 1257 	ret
      008128                       1258 00106$:
                                   1259 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      008128 90 0A 88         [24] 1260 	mov	dptr,#_distinct_keys
      00812B E0               [24] 1261 	movx	a,@dptr
      00812C 24 F9            [12] 1262 	add	a,#0xff - 0x06
      00812E 50 17            [24] 1263 	jnc	00110$
                                   1264 ;	free result
                                   1265 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      008130 7F 00            [12] 1266 	mov	r7,#0x00
      008132                       1267 00115$:
      008132 BF 06 00         [24] 1268 	cjne	r7,#0x06,00174$
      008135                       1269 00174$:
      008135 50 1E            [24] 1270 	jnc	00111$
      008137 EF               [12] 1271 	mov	a,r7
      008138 24 F0            [12] 1272 	add	a, #(_actual_keyboard_report + 0x0002)
      00813A F5 82            [12] 1273 	mov	dpl,a
      00813C E4               [12] 1274 	clr	a
      00813D 34 0D            [12] 1275 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      00813F F5 83            [12] 1276 	mov	dph,a
      008141 74 01            [12] 1277 	mov	a,#0x01
      008143 F0               [24] 1278 	movx	@dptr,a
      008144 0F               [12] 1279 	inc	r7
      008145 80 EB            [24] 1280 	sjmp	00115$
      008147                       1281 00110$:
                                   1282 ;	quantum/action_util.c:154: } else add_key(code);
      008147 90 0A 9E         [24] 1283 	mov	dptr,#_add_owned_key_code_10000_332
      00814A E0               [24] 1284 	movx	a,@dptr
                                   1285 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00814B 90 08 51         [24] 1286 	mov	dptr,#_add_key_to_report_PARM_2
      00814E F0               [24] 1287 	movx	@dptr,a
      00814F 90 0D EE         [24] 1288 	mov	dptr,#_actual_keyboard_report
      008152 12 71 E2         [24] 1289 	lcall	_add_key_to_report
                                   1290 ;	quantum/action_util.c:154: } else add_key(code);
      008155                       1291 00111$:
                                   1292 ;	quantum/action_util.c:155: return true;
      008155 75 82 01         [24] 1293 	mov	dpl, #0x01
                                   1294 ;	quantum/action_util.c:156: }
      008158 22               [24] 1295 	ret
                                   1296 ;------------------------------------------------------------
                                   1297 ;Allocation info for local variables in function 'del_owned_key'
                                   1298 ;------------------------------------------------------------
                                   1299 ;code          Allocated with name '_del_owned_key_code_10000_347'
                                   1300 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_358'
                                   1301 ;key           Allocated with name '_del_owned_key_key_50000_359'
                                   1302 ;key           Allocated with name '_del_owned_key_key_40000_356'
                                   1303 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_364'
                                   1304 ;key           Allocated with name '_del_owned_key_key_70000_365'
                                   1305 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_367'
                                   1306 ;key           Allocated with name '_del_owned_key_key_40000_368'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function del_owned_key
                                   1311 ;	-----------------------------------------
      008159                       1312 _del_owned_key:
      008159 E5 82            [12] 1313 	mov	a,dpl
      00815B 90 0A 9F         [24] 1314 	mov	dptr,#_del_owned_key_code_10000_347
      00815E 12 84 7C         [24] 1315 	lcall	_ak820_outline_0130
                                   1316 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      008161 E4               [12] 1317 	clr	a
      008162 F0               [24] 1318 	movx	@dptr,a
      008163 90 0A 89         [24] 1319 	mov	dptr,#_macro_keys
      008166 C0 07            [24] 1320 	push	ar7
      008168 12 7F 00         [24] 1321 	lcall	_ak820_macro_change
      00816B E5 82            [12] 1322 	mov	a, dpl
      00816D D0 07            [24] 1323 	pop	ar7
      00816F 70 03            [24] 1324 	jnz	00102$
      008171 F5 82            [12] 1325 	mov	dpl,a
      008173 22               [24] 1326 	ret
      008174                       1327 00102$:
                                   1328 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      008174 12 84 36         [24] 1329 	lcall	_ak820_outline_0028
      008177 FC               [12] 1330 	mov	r4,a
      008178 60 09            [24] 1331 	jz	00103$
      00817A 1C               [12] 1332 	dec	r4
      00817B 12 38 6A         [24] 1333 	lcall	_ak820_outline_0131
      00817E EC               [12] 1334 	mov	a,r4
      00817F F0               [24] 1335 	movx	@dptr,a
      008180 EC               [12] 1336 	mov	a,r4
      008181 60 04            [24] 1337 	jz	00104$
      008183                       1338 00103$:
      008183 75 82 00         [24] 1339 	mov	dpl, #0x00
      008186 22               [24] 1340 	ret
      008187                       1341 00104$:
                                   1342 ;	quantum/action_util.c:160: --distinct_keys;
      008187 90 0A 88         [24] 1343 	mov	dptr,#_distinct_keys
      00818A E0               [24] 1344 	movx	a,@dptr
      00818B 14               [12] 1345 	dec	a
      00818C F0               [24] 1346 	movx	@dptr,a
                                   1347 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      00818D 90 0D DB         [24] 1348 	mov	dptr,#_keyboard_protocol
      008190 E0               [24] 1349 	movx	a,@dptr
      008191 60 16            [24] 1350 	jz	00107$
      008193 90 0B 0D         [24] 1351 	mov	dptr,#_keymap_config
      008196 E0               [24] 1352 	movx	a,@dptr
      008197 30 E7 0F         [24] 1353 	jnb	acc.7,00107$
                                   1354 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      00819A 90 08 54         [24] 1355 	mov	dptr,#_del_key_from_report_PARM_2
      00819D EF               [12] 1356 	mov	a,r7
      00819E F0               [24] 1357 	movx	@dptr,a
      00819F 90 0D EE         [24] 1358 	mov	dptr,#_actual_keyboard_report
      0081A2 12 72 18         [24] 1359 	lcall	_del_key_from_report
                                   1360 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      0081A5 75 82 01         [24] 1361 	mov	dpl, #0x01
      0081A8 22               [24] 1362 	ret
      0081A9                       1363 00107$:
                                   1364 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      0081A9 90 0A 88         [24] 1365 	mov	dptr,#_distinct_keys
      0081AC E0               [24] 1366 	movx	a,@dptr
      0081AD FF               [12] 1367 	mov  r7,a
      0081AE 24 F9            [12] 1368 	add	a,#0xff - 0x06
      0081B0 50 04            [24] 1369 	jnc	00110$
                                   1370 ;	free result
      0081B2 75 82 01         [24] 1371 	mov	dpl, #0x01
      0081B5 22               [24] 1372 	ret
      0081B6                       1373 00110$:
                                   1374 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      0081B6 BF 06 1F         [24] 1375 	cjne	r7,#0x06,00115$
                                   1376 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0081B9 90 0D EE         [24] 1377 	mov	dptr,#_actual_keyboard_report
      0081BC 12 72 4E         [24] 1378 	lcall	_clear_keys_from_report
                                   1379 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      0081BF 7F 04            [12] 1380 	mov	r7,#0x04
      0081C1                       1381 00122$:
      0081C1 EF               [12] 1382 	mov	a,r7
      0081C2 24 5B            [12] 1383 	add	a,#0xff - 0xa4
      0081C4 40 20            [24] 1384 	jc	00116$
                                   1385 ;	free result
      0081C6 12 84 36         [24] 1386 	lcall	_ak820_outline_0028
      0081C9 60 0A            [24] 1387 	jz	00123$
                                   1388 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0081CB 12 84 87         [24] 1389 	lcall	_ak820_outline_0171
      0081CE C0 07            [24] 1390 	push	ar7
      0081D0 12 71 E2         [24] 1391 	lcall	_add_key_to_report
      0081D3 D0 07            [24] 1392 	pop	ar7
                                   1393 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      0081D5                       1394 00123$:
      0081D5 0F               [12] 1395 	inc	r7
      0081D6 80 E9            [24] 1396 	sjmp	00122$
      0081D8                       1397 00115$:
                                   1398 ;	quantum/action_util.c:169: } else del_key(code);
      0081D8 90 0A 9F         [24] 1399 	mov	dptr,#_del_owned_key_code_10000_347
      0081DB E0               [24] 1400 	movx	a,@dptr
                                   1401 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      0081DC 90 08 54         [24] 1402 	mov	dptr,#_del_key_from_report_PARM_2
      0081DF F0               [24] 1403 	movx	@dptr,a
      0081E0 90 0D EE         [24] 1404 	mov	dptr,#_actual_keyboard_report
      0081E3 12 72 18         [24] 1405 	lcall	_del_key_from_report
                                   1406 ;	quantum/action_util.c:169: } else del_key(code);
      0081E6                       1407 00116$:
                                   1408 ;	quantum/action_util.c:170: return true;
      0081E6 75 82 01         [24] 1409 	mov	dpl, #0x01
                                   1410 ;	quantum/action_util.c:171: }
      0081E9 22               [24] 1411 	ret
                                   1412 ;------------------------------------------------------------
                                   1413 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1414 ;------------------------------------------------------------
                                   1415 ;i             Allocated with name '_clear_owned_usages_i_20000_372'
                                   1416 ;i             Allocated with name '_clear_owned_usages_i_20000_373'
                                   1417 ;------------------------------------------------------------
                                   1418 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1419 ;	-----------------------------------------
                                   1420 ;	 function clear_owned_usages
                                   1421 ;	-----------------------------------------
      0081EA                       1422 _clear_owned_usages:
                                   1423 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      0081EA 7F 00            [12] 1424 	mov	r7,#0x00
      0081EC                       1425 00104$:
      0081EC BF 1E 00         [24] 1426 	cjne	r7,#0x1e,00141$
      0081EF                       1427 00141$:
      0081EF 50 14            [24] 1428 	jnc	00101$
      0081F1 EF               [12] 1429 	mov	a,r7
      0081F2 24 A0            [12] 1430 	add	a, #_usage_refs
      0081F4 FD               [12] 1431 	mov	r5,a
      0081F5 E4               [12] 1432 	clr	a
      0081F6 34 0A            [12] 1433 	addc	a, #(_usage_refs >> 8)
      0081F8 FE               [12] 1434 	mov	r6,a
      0081F9 EF               [12] 1435 	mov	a,r7
      0081FA 12 84 4B         [24] 1436 	lcall	_ak820_outline_0067
      0081FD E4               [12] 1437 	clr	a
      0081FE F0               [24] 1438 	movx	@dptr,a
      0081FF 12 84 6B         [24] 1439 	lcall	_ak820_outline_0118
      008202 0F               [12] 1440 	inc	r7
      008203 80 E7            [24] 1441 	sjmp	00104$
      008205                       1442 00101$:
                                   1443 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      008205 90 0A DD         [24] 1444 	mov	dptr,#(_usage_lengths + 0x0001)
      008208 E4               [12] 1445 	clr	a
      008209 F0               [24] 1446 	movx	@dptr,a
      00820A 90 0A DC         [24] 1447 	mov	dptr,#_usage_lengths
      00820D F0               [24] 1448 	movx	@dptr,a
                                   1449 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      00820E FF               [12] 1450 	mov	r7,a
      00820F                       1451 00107$:
      00820F BF 04 00         [24] 1452 	cjne	r7,#0x04,00143$
      008212                       1453 00143$:
      008212 50 0D            [24] 1454 	jnc	00109$
      008214 EF               [12] 1455 	mov	a,r7
      008215 24 DE            [12] 1456 	add	a, #_macro_usages
      008217 F5 82            [12] 1457 	mov	dpl,a
      008219 E4               [12] 1458 	clr	a
      00821A 34 0A            [12] 1459 	addc	a, #(_macro_usages >> 8)
      00821C 12 7E A2         [24] 1460 	lcall	_ak820_outline_0158
      00821F 80 EE            [24] 1461 	sjmp	00107$
      008221                       1462 00109$:
                                   1463 ;	quantum/action_util.c:185: }
      008221 22               [24] 1464 	ret
                                   1465 ;------------------------------------------------------------
                                   1466 ;Allocation info for local variables in function 'owned_usage_key'
                                   1467 ;------------------------------------------------------------
                                   1468 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1469 ;code          Allocated with name '_owned_usage_key_code_10000_374'
                                   1470 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_375'
                                   1471 ;which         Allocated with name '_owned_usage_key_which_10000_375'
                                   1472 ;base          Allocated with name '_owned_usage_key_base_10000_375'
                                   1473 ;count         Allocated with name '_owned_usage_key_count_10000_375'
                                   1474 ;index         Allocated with name '_owned_usage_key_index_10000_375'
                                   1475 ;pos           Allocated with name '_owned_usage_key_pos_30001_382'
                                   1476 ;i             Allocated with name '_owned_usage_key_i_40001_383'
                                   1477 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_386'
                                   1478 ;key           Allocated with name '_owned_usage_key_key_40000_387'
                                   1479 ;------------------------------------------------------------
                                   1480 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1481 ;	-----------------------------------------
                                   1482 ;	 function owned_usage_key
                                   1483 ;	-----------------------------------------
      008222                       1484 _owned_usage_key:
      008222 E5 82            [12] 1485 	mov	a,dpl
      008224 90 0A E3         [24] 1486 	mov	dptr,#_owned_usage_key_code_10000_374
      008227 F0               [24] 1487 	movx	@dptr,a
                                   1488 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      008228 E0               [24] 1489 	movx	a,@dptr
      008229 FF               [12] 1490 	mov	r7,a
      00822A BF A8 00         [24] 1491 	cjne	r7,#0xa8,00244$
      00822D                       1492 00244$:
      00822D B3               [12] 1493 	cpl	c
      00822E 92 24            [24] 1494 	mov	_owned_usage_key_sloc0_1_0,c
      008230 E4               [12] 1495 	clr	a
      008231 33               [12] 1496 	rlc	a
      008232 FF               [12] 1497 	mov	r7,a
      008233 90 0A E6         [24] 1498 	mov	dptr,#_owned_usage_key_which_10000_375
      008236 F0               [24] 1499 	movx	@dptr,a
                                   1500 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      008237 EF               [12] 1501 	mov	a,r7
      008238 60 02            [24] 1502 	jz	00129$
      00823A 74 03            [12] 1503 	mov	a,#0x03
      00823C                       1504 00129$:
      00823C FE               [12] 1505 	mov	r6,a
                                   1506 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      00823D EF               [12] 1507 	mov	a,r7
      00823E 24 DC            [12] 1508 	add	a, #_usage_lengths
      008240 FD               [12] 1509 	mov	r5,a
      008241 E4               [12] 1510 	clr	a
      008242 34 0A            [12] 1511 	addc	a, #(_usage_lengths >> 8)
      008244 FF               [12] 1512 	mov	r7,a
      008245 12 84 90         [24] 1513 	lcall	_ak820_outline_0185
      008248 E0               [24] 1514 	movx	a,@dptr
      008249 FC               [12] 1515 	mov	r4,a
                                   1516 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      00824A 90 0A E3         [24] 1517 	mov	dptr,#_owned_usage_key_code_10000_374
      00824D E0               [24] 1518 	movx	a,@dptr
      00824E 24 5B            [12] 1519 	add	a,#0x5b
      008250 FB               [12] 1520 	mov	r3,a
                                   1521 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      008251 90 0A E2         [24] 1522 	mov	dptr,#_owned_usage_key_PARM_2
      008254 E0               [24] 1523 	movx	a,@dptr
      008255 FA               [12] 1524 	mov	r2,a
      008256 90 09 D7         [24] 1525 	mov	dptr,#_ak820_macro_change_PARM_2
      008259 EB               [12] 1526 	mov	a,r3
      00825A F0               [24] 1527 	movx	@dptr,a
      00825B 90 09 D8         [24] 1528 	mov	dptr,#_ak820_macro_change_PARM_3
      00825E EA               [12] 1529 	mov	a,r2
      00825F F0               [24] 1530 	movx	@dptr,a
      008260 90 0A DE         [24] 1531 	mov	dptr,#_macro_usages
      008263 C0 07            [24] 1532 	push	ar7
      008265 C0 06            [24] 1533 	push	ar6
      008267 C0 05            [24] 1534 	push	ar5
      008269 C0 04            [24] 1535 	push	ar4
      00826B C0 03            [24] 1536 	push	ar3
      00826D C0 02            [24] 1537 	push	ar2
      00826F 12 7F 00         [24] 1538 	lcall	_ak820_macro_change
      008272 E5 82            [12] 1539 	mov	a, dpl
      008274 D0 02            [24] 1540 	pop	ar2
      008276 D0 03            [24] 1541 	pop	ar3
      008278 D0 04            [24] 1542 	pop	ar4
      00827A D0 05            [24] 1543 	pop	ar5
      00827C D0 06            [24] 1544 	pop	ar6
      00827E D0 07            [24] 1545 	pop	ar7
      008280 70 01            [24] 1546 	jnz	00102$
      008282 22               [24] 1547 	ret
      008283                       1548 00102$:
                                   1549 ;	quantum/action_util.c:192: if (pressed) {
      008283 EA               [12] 1550 	mov	a,r2
      008284 60 1B            [24] 1551 	jz	00115$
                                   1552 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      008286 12 84 55         [24] 1553 	lcall	_ak820_outline_0073
      008289 04               [12] 1554 	inc	a
      00828A 12 6F 65         [24] 1555 	lcall	_ak820_outline_0136
      00828D E8               [12] 1556 	mov	a,r0
      00828E 60 01            [24] 1557 	jz	00104$
      008290 22               [24] 1558 	ret
      008291                       1559 00104$:
                                   1560 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      008291 90 0A E7         [24] 1561 	mov	dptr,#_owned_usage_key_count_10000_375
      008294 EC               [12] 1562 	mov	a,r4
      008295 04               [12] 1563 	inc	a
      008296 F0               [24] 1564 	movx	@dptr,a
      008297 EC               [12] 1565 	mov	a,r4
      008298 2E               [12] 1566 	add	a, r6
      008299 12 84 4B         [24] 1567 	lcall	_ak820_outline_0067
      00829C EB               [12] 1568 	mov	a,r3
      00829D F0               [24] 1569 	movx	@dptr,a
      00829E 02 83 02         [24] 1570 	ljmp	00116$
      0082A1                       1571 00115$:
                                   1572 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      0082A1 12 84 55         [24] 1573 	lcall	_ak820_outline_0073
      0082A4 60 07            [24] 1574 	jz	00105$
      0082A6 18               [12] 1575 	dec	r0
      0082A7 12 84 44         [24] 1576 	lcall	_ak820_outline_0063
      0082AA E8               [12] 1577 	mov	a,r0
      0082AB 60 01            [24] 1578 	jz	00106$
      0082AD                       1579 00105$:
      0082AD 22               [24] 1580 	ret
      0082AE                       1581 00106$:
                                   1582 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      0082AE 7A 00            [12] 1583 	mov	r2,#0x00
      0082B0                       1584 00108$:
      0082B0 EA               [12] 1585 	mov	a,r2
      0082B1 2E               [12] 1586 	add	a, r6
      0082B2 12 84 4B         [24] 1587 	lcall	_ak820_outline_0067
      0082B5 E0               [24] 1588 	movx	a,@dptr
      0082B6 B5 03 02         [24] 1589 	cjne	a,ar3,00251$
      0082B9 80 03            [24] 1590 	sjmp	00167$
      0082BB                       1591 00251$:
      0082BB 0A               [12] 1592 	inc	r2
      0082BC 80 F2            [24] 1593 	sjmp	00108$
      0082BE                       1594 00167$:
      0082BE 90 0A E8         [24] 1595 	mov	dptr,#_owned_usage_key_pos_30001_382
      0082C1 EA               [12] 1596 	mov	a,r2
      0082C2 F0               [24] 1597 	movx	@dptr,a
                                   1598 ;	quantum/action_util.c:199: --count;
      0082C3 1C               [12] 1599 	dec	r4
      0082C4 90 0A E7         [24] 1600 	mov	dptr,#_owned_usage_key_count_10000_375
      0082C7 EC               [12] 1601 	mov	a,r4
      0082C8 F0               [24] 1602 	movx	@dptr,a
                                   1603 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      0082C9 8A 03            [24] 1604 	mov	ar3,r2
      0082CB                       1605 00125$:
      0082CB C3               [12] 1606 	clr	c
      0082CC EB               [12] 1607 	mov	a,r3
      0082CD 9C               [12] 1608 	subb	a,r4
      0082CE 50 23            [24] 1609 	jnc	00111$
      0082D0 C0 05            [24] 1610 	push	ar5
      0082D2 C0 07            [24] 1611 	push	ar7
      0082D4 EB               [12] 1612 	mov	a,r3
      0082D5 2E               [12] 1613 	add	a, r6
      0082D6 FA               [12] 1614 	mov	r2,a
      0082D7 24 BE            [12] 1615 	add	a, #_usage_order
      0082D9 F8               [12] 1616 	mov	r0,a
      0082DA E4               [12] 1617 	clr	a
      0082DB 34 0A            [12] 1618 	addc	a, #(_usage_order >> 8)
      0082DD F9               [12] 1619 	mov	r1,a
      0082DE 0A               [12] 1620 	inc	r2
      0082DF EA               [12] 1621 	mov	a,r2
      0082E0 33               [12] 1622 	rlc	a
      0082E1 95 E0            [12] 1623 	subb	a,acc
      0082E3 FF               [12] 1624 	mov	r7,a
      0082E4 EA               [12] 1625 	mov	a,r2
      0082E5 12 84 71         [24] 1626 	lcall	_ak820_outline_0124
      0082E8 12 38 75         [24] 1627 	lcall	_ak820_outline_0152
      0082EB F0               [24] 1628 	movx	@dptr,a
      0082EC 0B               [12] 1629 	inc	r3
      0082ED D0 07            [24] 1630 	pop	ar7
      0082EF D0 05            [24] 1631 	pop	ar5
      0082F1 80 D8            [24] 1632 	sjmp	00125$
      0082F3                       1633 00111$:
                                   1634 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      0082F3 12 84 90         [24] 1635 	lcall	_ak820_outline_0185
      0082F6 EC               [12] 1636 	mov	a,r4
      0082F7 F0               [24] 1637 	movx	@dptr,a
                                   1638 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      0082F8 90 0A E8         [24] 1639 	mov	dptr,#_owned_usage_key_pos_30001_382
      0082FB E0               [24] 1640 	movx	a,@dptr
      0082FC B5 04 02         [24] 1641 	cjne	a,ar4,00253$
      0082FF 80 01            [24] 1642 	sjmp	00116$
      008301                       1643 00253$:
      008301 22               [24] 1644 	ret
      008302                       1645 00116$:
                                   1646 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      008302 90 0A E7         [24] 1647 	mov	dptr,#_owned_usage_key_count_10000_375
      008305 E0               [24] 1648 	movx	a,@dptr
      008306 FC               [12] 1649 	mov	r4,a
      008307 12 84 90         [24] 1650 	lcall	_ak820_outline_0185
      00830A F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      00830B EC               [12] 1653 	mov	a,r4
      00830C 60 15            [24] 1654 	jz	00131$
      00830E EC               [12] 1655 	mov	a,r4
      00830F 2E               [12] 1656 	add	a, r6
      008310 FE               [12] 1657 	mov	r6,a
      008311 1E               [12] 1658 	dec	r6
      008312 EE               [12] 1659 	mov	a,r6
      008313 33               [12] 1660 	rlc	a
      008314 95 E0            [12] 1661 	subb	a,acc
      008316 FF               [12] 1662 	mov	r7,a
      008317 EE               [12] 1663 	mov	a,r6
      008318 12 84 71         [24] 1664 	lcall	_ak820_outline_0124
      00831B 24 A5            [12] 1665 	add	a,#0xa5
      00831D FE               [12] 1666 	mov	r6,a
      00831E 33               [12] 1667 	rlc	a
      00831F 95 E0            [12] 1668 	subb	a,acc
      008321 80 02            [24] 1669 	sjmp	00132$
      008323                       1670 00131$:
      008323 7E 00            [12] 1671 	mov	r6,#0x00
      008325                       1672 00132$:
      008325 90 0A E3         [24] 1673 	mov	dptr,#_owned_usage_key_code_10000_374
      008328 EE               [12] 1674 	mov	a,r6
      008329 F0               [24] 1675 	movx	@dptr,a
                                   1676 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      00832A 90 0A E6         [24] 1677 	mov	dptr,#_owned_usage_key_which_10000_375
      00832D E0               [24] 1678 	movx	a,@dptr
      00832E 60 18            [24] 1679 	jz	00118$
      008330 EE               [12] 1680 	mov	a,r6
      008331 60 0B            [24] 1681 	jz	00133$
      008333 8E 82            [24] 1682 	mov	dpl, r6
      008335 12 70 9E         [24] 1683 	lcall	_KEYCODE2CONSUMER
      008338 AD 82            [24] 1684 	mov	r5, dpl
      00833A AF 83            [24] 1685 	mov	r7, dph
      00833C 80 04            [24] 1686 	sjmp	00134$
      00833E                       1687 00133$:
      00833E 7D 00            [12] 1688 	mov	r5,#0x00
      008340 7F 00            [12] 1689 	mov	r7,#0x00
      008342                       1690 00134$:
      008342 12 84 90         [24] 1691 	lcall	_ak820_outline_0185
      008345 02 70 58         [24] 1692 	ljmp	_host_consumer_send
      008348                       1693 00118$:
                                   1694 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008348 EE               [12] 1695 	mov	a,r6
      008349 60 22            [24] 1696 	jz	00135$
                                   1697 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      00834B BE A5 00         [24] 1698 	cjne	r6,#0xa5,00258$
      00834E                       1699 00258$:
      00834E 40 05            [24] 1700 	jc	00121$
      008350 EE               [12] 1701 	mov	a,r6
      008351 24 58            [12] 1702 	add	a,#0xff - 0xa7
      008353 50 08            [24] 1703 	jnc	00122$
                                   1704 ;	free result
      008355                       1705 00121$:
      008355 90 0A E4         [24] 1706 	mov	dptr,#_owned_usage_key___200000085_20000_375
      008358 12 52 5F         [24] 1707 	lcall	_ak820_outline_0178
      00835B 80 09            [24] 1708 	sjmp	00123$
      00835D                       1709 00122$:
                                   1710 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      00835D 74 DC            [12] 1711 	mov	a,#0xdc
      00835F 2E               [12] 1712 	add	a, r6
      008360 90 0A E4         [24] 1713 	mov	dptr,#_owned_usage_key___200000085_20000_375
      008363 12 38 65         [24] 1714 	lcall	_ak820_outline_0123
                                   1715 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008366                       1716 00123$:
      008366 90 0A E4         [24] 1717 	mov	dptr,#_owned_usage_key___200000085_20000_375
      008369 E0               [24] 1718 	movx	a,@dptr
      00836A FF               [12] 1719 	mov	r7,a
      00836B 80 02            [24] 1720 	sjmp	00136$
      00836D                       1721 00135$:
      00836D 7F 00            [12] 1722 	mov	r7,#0x00
      00836F                       1723 00136$:
      00836F 7E 00            [12] 1724 	mov	r6,#0x00
      008371 12 46 83         [24] 1725 	lcall	_ak820_outline_0153
                                   1726 ;	quantum/action_util.c:208: }
      008374 02 70 28         [24] 1727 	ljmp	_host_system_send
                                   1728 ;------------------------------------------------------------
                                   1729 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1730 ;------------------------------------------------------------
                                   1731 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_395'
                                   1732 ;changed       Allocated with name '_send_keyboard_report_changed_10001_395'
                                   1733 ;dest          Allocated with name '_send_keyboard_report_dest_10001_395'
                                   1734 ;src           Allocated with name '_send_keyboard_report_src_10001_395'
                                   1735 ;i             Allocated with name '_send_keyboard_report_i_20001_396'
                                   1736 ;------------------------------------------------------------
                                   1737 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1738 ;	-----------------------------------------
                                   1739 ;	 function send_keyboard_report
                                   1740 ;	-----------------------------------------
      008377                       1741 _send_keyboard_report:
                                   1742 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      008377 90 0D EC         [24] 1743 	mov	dptr,#_real_mods
      00837A E0               [24] 1744 	movx	a,@dptr
      00837B FF               [12] 1745 	mov	r7,a
      00837C 90 0D EE         [24] 1746 	mov	dptr,#_actual_keyboard_report
      00837F F0               [24] 1747 	movx	@dptr,a
                                   1748 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      008380 90 0D ED         [24] 1749 	mov	dptr,#_weak_mods
      008383 E0               [24] 1750 	movx	a,@dptr
      008384 42 07            [12] 1751 	orl	ar7,a
      008386 90 0D EE         [24] 1752 	mov	dptr,#_actual_keyboard_report
      008389 EF               [12] 1753 	mov	a,r7
      00838A F0               [24] 1754 	movx	@dptr,a
                                   1755 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      00838B 90 09 D2         [24] 1756 	mov	dptr,#_owned_weak_mods
      00838E E0               [24] 1757 	movx	a,@dptr
      00838F FE               [12] 1758 	mov	r6,a
      008390 90 09 D1         [24] 1759 	mov	dptr,#_owned_mods
      008393 E0               [24] 1760 	movx	a,@dptr
      008394 4E               [12] 1761 	orl	a,r6
      008395 42 07            [12] 1762 	orl	ar7,a
      008397 90 0D EE         [24] 1763 	mov	dptr,#_actual_keyboard_report
      00839A EF               [12] 1764 	mov	a,r7
      00839B F0               [24] 1765 	movx	@dptr,a
                                   1766 ;	quantum/action_util.c:475: if (gui_disabled) keyboard_report->mods &= ~(MOD_BIT(KC_LGUI) | MOD_BIT(KC_RGUI));
      00839C 30 20 07         [24] 1767 	jnb	_gui_disabled,00102$
      00839F 90 0D EE         [24] 1768 	mov	dptr,#_actual_keyboard_report
      0083A2 E0               [24] 1769 	movx	a,@dptr
      0083A3 54 77            [12] 1770 	anl	a,#0x77
      0083A5 F0               [24] 1771 	movx	@dptr,a
      0083A6                       1772 00102$:
                                   1773 ;	quantum/action_util.c:515: bool changed = false;
      0083A6 90 0B 0A         [24] 1774 	mov	dptr,#_send_keyboard_report_changed_10001_395
      0083A9 E4               [12] 1775 	clr	a
      0083AA F0               [24] 1776 	movx	@dptr,a
                                   1777 ;	quantum/action_util.c:517: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1778 ;	quantum/action_util.c:518: const uint8_t __xdata *src = (const uint8_t __xdata *)AK820_REPORT_OUT;
                                   1779 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0083AB FF               [12] 1780 	mov	r7,a
      0083AC                       1781 00109$:
      0083AC BF 20 00         [24] 1782 	cjne	r7,#0x20,00150$
      0083AF                       1783 00150$:
      0083AF 50 2A            [24] 1784 	jnc	00105$
                                   1785 ;	quantum/action_util.c:524: if (dest[i] != src[i]) {
      0083B1 EF               [12] 1786 	mov	a,r7
      0083B2 24 EA            [12] 1787 	add	a, #_send_keyboard_report_last_report_10001_395
      0083B4 FD               [12] 1788 	mov	r5,a
      0083B5 E4               [12] 1789 	clr	a
      0083B6 34 0A            [12] 1790 	addc	a, #(_send_keyboard_report_last_report_10001_395 >> 8)
      0083B8 12 4B 96         [24] 1791 	lcall	_ak820_outline_0056
      0083BB EF               [12] 1792 	mov	a,r7
      0083BC 24 EE            [12] 1793 	add	a, #_actual_keyboard_report
      0083BE F5 82            [12] 1794 	mov	dpl,a
      0083C0 E4               [12] 1795 	clr	a
      0083C1 34 0D            [12] 1796 	addc	a, #(_actual_keyboard_report >> 8)
      0083C3 F5 83            [12] 1797 	mov	dph,a
      0083C5 E0               [24] 1798 	movx	a,@dptr
      0083C6 FB               [12] 1799 	mov	r3,a
      0083C7 EC               [12] 1800 	mov	a,r4
      0083C8 B5 03 02         [24] 1801 	cjne	a,ar3,00152$
      0083CB 80 0B            [24] 1802 	sjmp	00110$
      0083CD                       1803 00152$:
                                   1804 ;	quantum/action_util.c:525: dest[i] = src[i];
      0083CD 12 38 6A         [24] 1805 	lcall	_ak820_outline_0131
      0083D0 EB               [12] 1806 	mov	a,r3
      0083D1 F0               [24] 1807 	movx	@dptr,a
                                   1808 ;	quantum/action_util.c:526: changed = true;
      0083D2 90 0B 0A         [24] 1809 	mov	dptr,#_send_keyboard_report_changed_10001_395
      0083D5 74 01            [12] 1810 	mov	a,#0x01
      0083D7 F0               [24] 1811 	movx	@dptr,a
      0083D8                       1812 00110$:
                                   1813 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0083D8 0F               [12] 1814 	inc	r7
      0083D9 80 D1            [24] 1815 	sjmp	00109$
      0083DB                       1816 00105$:
                                   1817 ;	quantum/action_util.c:529: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      0083DB 90 0B 0A         [24] 1818 	mov	dptr,#_send_keyboard_report_changed_10001_395
      0083DE E0               [24] 1819 	movx	a,@dptr
      0083DF 60 09            [24] 1820 	jz	00111$
      0083E1 90 0D EE         [24] 1821 	mov	dptr,#_actual_keyboard_report
      0083E4 75 F0 00         [24] 1822 	mov	b, #0x00
                                   1823 ;	quantum/action_util.c:538: }
      0083E7 02 6F 9D         [24] 1824 	ljmp	_host_keyboard_send
      0083EA                       1825 00111$:
      0083EA 22               [24] 1826 	ret
                                   1827 ;------------------------------------------------------------
                                   1828 ;Allocation info for local variables in function 'get_mods'
                                   1829 ;------------------------------------------------------------
                                   1830 ;	quantum/action_util.c:544: uint8_t get_mods(void) {
                                   1831 ;	-----------------------------------------
                                   1832 ;	 function get_mods
                                   1833 ;	-----------------------------------------
      0083EB                       1834 _get_mods:
      0083EB C0 07            [24] 1835 	push	ar7
                                   1836 ;	quantum/action_util.c:549: ;
      0083ED 90 09 D1         [24] 1837 	mov	dptr,#_owned_mods
      0083F0 E0               [24] 1838 	movx	a,@dptr
      0083F1 FF               [12] 1839 	mov	r7,a
      0083F2 90 0D EC         [24] 1840 	mov	dptr,#_real_mods
      0083F5 12 7E 9C         [24] 1841 	lcall	_ak820_outline_0138
                                   1842 ;	quantum/action_util.c:550: }
      0083F8 D0 07            [24] 1843 	pop	ar7
      0083FA 22               [24] 1844 	ret
                                   1845 ;------------------------------------------------------------
                                   1846 ;Allocation info for local variables in function 'add_mods'
                                   1847 ;------------------------------------------------------------
                                   1848 ;mods          Allocated with name '_add_mods_mods_10000_403'
                                   1849 ;------------------------------------------------------------
                                   1850 ;	quantum/action_util.c:555: void add_mods(uint8_t mods) {
                                   1851 ;	-----------------------------------------
                                   1852 ;	 function clear_mods
                                   1853 ;	-----------------------------------------
      0083FB                       1854 _clear_mods:
                                   1855 ;	quantum/action_util.c:577: real_mods = 0;
      0083FB 90 0D EC         [24] 1856 	mov	dptr,#_real_mods
      0083FE E4               [12] 1857 	clr	a
      0083FF F0               [24] 1858 	movx	@dptr,a
                                   1859 ;	quantum/action_util.c:578: }
      008400 22               [24] 1860 	ret
                                   1861 ;------------------------------------------------------------
                                   1862 ;Allocation info for local variables in function 'get_weak_mods'
                                   1863 ;------------------------------------------------------------
                                   1864 ;	quantum/action_util.c:584: uint8_t get_weak_mods(void) {
                                   1865 ;	-----------------------------------------
                                   1866 ;	 function get_weak_mods
                                   1867 ;	-----------------------------------------
      008401                       1868 _get_weak_mods:
      008401 C0 07            [24] 1869 	push	ar7
                                   1870 ;	quantum/action_util.c:589: ;
      008403 90 09 D2         [24] 1871 	mov	dptr,#_owned_weak_mods
      008406 E0               [24] 1872 	movx	a,@dptr
      008407 FF               [12] 1873 	mov	r7,a
      008408 90 0D ED         [24] 1874 	mov	dptr,#_weak_mods
      00840B 12 7E 9C         [24] 1875 	lcall	_ak820_outline_0138
                                   1876 ;	quantum/action_util.c:590: }
      00840E D0 07            [24] 1877 	pop	ar7
      008410 22               [24] 1878 	ret
                                   1879 ;------------------------------------------------------------
                                   1880 ;Allocation info for local variables in function 'add_weak_mods'
                                   1881 ;------------------------------------------------------------
                                   1882 ;mods          Allocated with name '_add_weak_mods_mods_10000_413'
                                   1883 ;------------------------------------------------------------
                                   1884 ;	quantum/action_util.c:595: void add_weak_mods(uint8_t mods) {
                                   1885 ;	-----------------------------------------
                                   1886 ;	 function add_weak_mods
                                   1887 ;	-----------------------------------------
      008411                       1888 _add_weak_mods:
      008411 E5 82            [12] 1889 	mov	a,dpl
      008413 90 0B 0B         [24] 1890 	mov	dptr,#_add_weak_mods_mods_10000_413
      008416 F0               [24] 1891 	movx	@dptr,a
                                   1892 ;	quantum/action_util.c:596: weak_mods |= mods;
      008417 E0               [24] 1893 	movx	a,@dptr
      008418 FF               [12] 1894 	mov	r7,a
      008419 90 0D ED         [24] 1895 	mov	dptr,#_weak_mods
      00841C E0               [24] 1896 	movx	a,@dptr
      00841D 4F               [12] 1897 	orl	a,r7
      00841E F0               [24] 1898 	movx	@dptr,a
                                   1899 ;	quantum/action_util.c:597: }
      00841F 22               [24] 1900 	ret
                                   1901 ;------------------------------------------------------------
                                   1902 ;Allocation info for local variables in function 'del_weak_mods'
                                   1903 ;------------------------------------------------------------
                                   1904 ;mods          Allocated with name '_del_weak_mods_mods_10000_415'
                                   1905 ;------------------------------------------------------------
                                   1906 ;	quantum/action_util.c:602: void del_weak_mods(uint8_t mods) {
                                   1907 ;	-----------------------------------------
                                   1908 ;	 function del_weak_mods
                                   1909 ;	-----------------------------------------
      008420                       1910 _del_weak_mods:
      008420 E5 82            [12] 1911 	mov	a,dpl
      008422 90 0B 0C         [24] 1912 	mov	dptr,#_del_weak_mods_mods_10000_415
      008425 F0               [24] 1913 	movx	@dptr,a
                                   1914 ;	quantum/action_util.c:603: weak_mods &= ~mods;
      008426 E0               [24] 1915 	movx	a,@dptr
      008427 F4               [12] 1916 	cpl	a
      008428 FF               [12] 1917 	mov	r7,a
      008429 90 0D ED         [24] 1918 	mov	dptr,#_weak_mods
      00842C E0               [24] 1919 	movx	a,@dptr
      00842D 5F               [12] 1920 	anl	a,r7
      00842E F0               [24] 1921 	movx	@dptr,a
                                   1922 ;	quantum/action_util.c:604: }
      00842F 22               [24] 1923 	ret
                                   1924 ;------------------------------------------------------------
                                   1925 ;Allocation info for local variables in function 'set_weak_mods'
                                   1926 ;------------------------------------------------------------
                                   1927 ;mods          Allocated with name '_set_weak_mods_mods_10000_417'
                                   1928 ;------------------------------------------------------------
                                   1929 ;	quantum/action_util.c:609: void set_weak_mods(uint8_t mods) {
                                   1930 ;	-----------------------------------------
                                   1931 ;	 function clear_weak_mods
                                   1932 ;	-----------------------------------------
      008430                       1933 _clear_weak_mods:
                                   1934 ;	quantum/action_util.c:617: weak_mods = 0;
      008430 90 0D ED         [24] 1935 	mov	dptr,#_weak_mods
      008433 E4               [12] 1936 	clr	a
      008434 F0               [24] 1937 	movx	@dptr,a
                                   1938 ;	quantum/action_util.c:618: }
      008435 22               [24] 1939 	ret
                                   1940 ;------------------------------------------------------------
                                   1941 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1942 ;------------------------------------------------------------
                                   1943 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_421'
                                   1944 ;------------------------------------------------------------
                                   1945 ;	quantum/action_util.c:700: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1946 ;	-----------------------------------------
                                   1947 	.area CSEG    (CODE)
                                   1948 	.area CONST   (CODE)
                                   1949 	.area XINIT   (CODE)
      00C355                       1950 __xinit__real_mods:
      00C355 00                    1951 	.db #0x00	; 0
      00C356                       1952 __xinit__weak_mods:
      00C356 00                    1953 	.db #0x00	; 0
      00C357                       1954 __xinit__actual_keyboard_report:
      00C357 00                    1955 	.db #0x00	; 0
      00C358 00                    1956 	.db #0x00	; 0
      00C359 00                    1957 	.db #0x00	; 0
      00C35A 00                    1958 	.db #0x00	; 0
      00C35B 00                    1959 	.db #0x00	; 0
      00C35C 00                    1960 	.db #0x00	; 0
      00C35D 00                    1961 	.db #0x00	; 0
      00C35E 00                    1962 	.db #0x00	; 0
      00C35F 00                    1963 	.db 0x00
      00C360 00                    1964 	.db 0x00
      00C361 00                    1965 	.db 0x00
      00C362 00                    1966 	.db 0x00
      00C363 00                    1967 	.db 0x00
      00C364 00                    1968 	.db 0x00
      00C365 00                    1969 	.db 0x00
      00C366 00                    1970 	.db 0x00
      00C367 00                    1971 	.db 0x00
      00C368 00                    1972 	.db 0x00
      00C369 00                    1973 	.db 0x00
      00C36A 00                    1974 	.db 0x00
      00C36B 00                    1975 	.db 0x00
      00C36C 00                    1976 	.db 0x00
      00C36D 00                    1977 	.db 0x00
      00C36E 00                    1978 	.db 0x00
      00C36F 00                    1979 	.db 0x00
      00C370 00                    1980 	.db 0x00
      00C371 00                    1981 	.db 0x00
      00C372 00                    1982 	.db 0x00
      00C373 00                    1983 	.db 0x00
      00C374 00                    1984 	.db 0x00
      00C375 00                    1985 	.db 0x00
      00C376 00                    1986 	.db 0x00
                                   1987 	.area CABS    (ABS,CODE)
                                   1988 
                                   1989 ; Experimental exact instruction outlining.
                                   1990 	.globl _ak820_outline_0014
                                   1991 	.globl _ak820_outline_0028
                                   1992 	.globl _ak820_outline_0051
                                   1993 	.globl _ak820_outline_0056
                                   1994 	.globl _ak820_outline_0059
                                   1995 	.globl _ak820_outline_0062
                                   1996 	.globl _ak820_outline_0063
                                   1997 	.globl _ak820_outline_0064
                                   1998 	.globl _ak820_outline_0067
                                   1999 	.globl _ak820_outline_0073
                                   2000 	.globl _ak820_outline_0104
                                   2001 	.globl _ak820_outline_0105
                                   2002 	.globl _ak820_outline_0113
                                   2003 	.globl _ak820_outline_0118
                                   2004 	.globl _ak820_outline_0122
                                   2005 	.globl _ak820_outline_0123
                                   2006 	.globl _ak820_outline_0124
                                   2007 	.globl _ak820_outline_0130
                                   2008 	.globl _ak820_outline_0131
                                   2009 	.globl _ak820_outline_0136
                                   2010 	.globl _ak820_outline_0138
                                   2011 	.globl _ak820_outline_0152
                                   2012 	.globl _ak820_outline_0153
                                   2013 	.globl _ak820_outline_0158
                                   2014 	.globl _ak820_outline_0171
                                   2015 	.globl _ak820_outline_0178
                                   2016 	.globl _ak820_outline_0183
                                   2017 	.globl _ak820_outline_0184
                                   2018 	.globl _ak820_outline_0185
                                   2019 
                                   2020 	.area CSEG (CODE)
                                   2021 ; function ak820_outline_0028
      008436                       2022 _ak820_outline_0028:
      008436 EF               [12] 2023 	mov	a,r7
      008437 24 E3            [12] 2024 	add	a,#_key_refs
      008439 FD               [12] 2025 	mov	r5,a
      00843A E4               [12] 2026 	clr	a
      00843B 34 09            [12] 2027 	addc	a,#(_key_refs>>8)
      00843D FE               [12] 2028 	mov	r6,a
      00843E 8D 82            [24] 2029 	mov	dpl,r5
      008440 8E 83            [24] 2030 	mov	dph,r6
      008442 E0               [24] 2031 	movx	a,@dptr
      008443 22               [24] 2032 	ret
                                   2033 
                                   2034 	.area CSEG (CODE)
                                   2035 ; function ak820_outline_0063
      008444                       2036 _ak820_outline_0063:
      008444 89 82            [24] 2037 	mov	dpl,r1
      008446 8A 83            [24] 2038 	mov	dph,r2
      008448 E8               [12] 2039 	mov	a,r0
      008449 F0               [24] 2040 	movx	@dptr,a
      00844A 22               [24] 2041 	ret
                                   2042 
                                   2043 	.area CSEG (CODE)
                                   2044 ; function ak820_outline_0067
      00844B                       2045 _ak820_outline_0067:
      00844B 24 BE            [12] 2046 	add	a,#_usage_order
      00844D F5 82            [12] 2047 	mov	dpl,a
      00844F E4               [12] 2048 	clr	a
      008450 34 0A            [12] 2049 	addc	a,#(_usage_order>>8)
      008452 F5 83            [12] 2050 	mov	dph,a
      008454 22               [24] 2051 	ret
                                   2052 
                                   2053 	.area CSEG (CODE)
                                   2054 ; function ak820_outline_0073
      008455                       2055 _ak820_outline_0073:
      008455 EB               [12] 2056 	mov	a,r3
      008456 24 A0            [12] 2057 	add	a,#_usage_refs
      008458 F9               [12] 2058 	mov	r1,a
      008459 E4               [12] 2059 	clr	a
      00845A 34 0A            [12] 2060 	addc	a,#(_usage_refs>>8)
      00845C FA               [12] 2061 	mov	r2,a
      00845D 89 82            [24] 2062 	mov	dpl,r1
      00845F 8A 83            [24] 2063 	mov	dph,r2
      008461 E0               [24] 2064 	movx	a,@dptr
      008462 F8               [12] 2065 	mov	r0,a
      008463 22               [24] 2066 	ret
                                   2067 
                                   2068 	.area CSEG (CODE)
                                   2069 ; function ak820_outline_0113
      008464                       2070 _ak820_outline_0113:
      008464 F0               [24] 2071 	movx	@dptr,a
      008465 E0               [24] 2072 	movx	a,@dptr
      008466 FF               [12] 2073 	mov	r7,a
      008467 90 09 DB         [24] 2074 	mov	dptr,#_change_owned_PARM_2
      00846A 22               [24] 2075 	ret
                                   2076 
                                   2077 	.area CSEG (CODE)
                                   2078 ; function ak820_outline_0118
      00846B                       2079 _ak820_outline_0118:
      00846B 8D 82            [24] 2080 	mov	dpl,r5
      00846D 8E 83            [24] 2081 	mov	dph,r6
      00846F F0               [24] 2082 	movx	@dptr,a
      008470 22               [24] 2083 	ret
                                   2084 
                                   2085 	.area CSEG (CODE)
                                   2086 ; function ak820_outline_0124
      008471                       2087 _ak820_outline_0124:
      008471 24 BE            [12] 2088 	add	a,#_usage_order
      008473 F5 82            [12] 2089 	mov	dpl,a
      008475 EF               [12] 2090 	mov	a,r7
      008476 34 0A            [12] 2091 	addc	a,#(_usage_order>>8)
      008478 F5 83            [12] 2092 	mov	dph,a
      00847A E0               [24] 2093 	movx	a,@dptr
      00847B 22               [24] 2094 	ret
                                   2095 
                                   2096 	.area CSEG (CODE)
                                   2097 ; function ak820_outline_0130
      00847C                       2098 _ak820_outline_0130:
      00847C F0               [24] 2099 	movx	@dptr,a
      00847D E0               [24] 2100 	movx	a,@dptr
      00847E FF               [12] 2101 	mov	r7,a
      00847F 90 09 D7         [24] 2102 	mov	dptr,#_ak820_macro_change_PARM_2
      008482 F0               [24] 2103 	movx	@dptr,a
      008483 90 09 D8         [24] 2104 	mov	dptr,#_ak820_macro_change_PARM_3
      008486 22               [24] 2105 	ret
                                   2106 
                                   2107 	.area CSEG (CODE)
                                   2108 ; function ak820_outline_0171
      008487                       2109 _ak820_outline_0171:
      008487 90 08 51         [24] 2110 	mov	dptr,#_add_key_to_report_PARM_2
      00848A EF               [12] 2111 	mov	a,r7
      00848B F0               [24] 2112 	movx	@dptr,a
      00848C 90 0D EE         [24] 2113 	mov	dptr,#_actual_keyboard_report
      00848F 22               [24] 2114 	ret
                                   2115 
                                   2116 	.area CSEG (CODE)
                                   2117 ; function ak820_outline_0185
      008490                       2118 _ak820_outline_0185:
      008490 8D 82            [24] 2119 	mov	dpl,r5
      008492 8F 83            [24] 2120 	mov	dph,r7
      008494 22               [24] 2121 	ret
