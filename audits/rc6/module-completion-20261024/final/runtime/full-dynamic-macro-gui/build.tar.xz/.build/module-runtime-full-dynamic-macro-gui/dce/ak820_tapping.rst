                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000C                        552 _ak820_tapping_before_sloc0_1_0:
      00000C                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005F0                        562 _source_state:
      0005F0                        563 	.ds 130
      000672                        564 _pending_time:
      000672                        565 	.ds 2
      000674                        566 _pending_code:
      000674                        567 	.ds 2
      000676                        568 _ak820_tapping_source_PARM_1:
      000676                        569 	.ds 2
      000678                        570 _hold_PARM_2:
      000678                        571 	.ds 1
      000679                        572 _hold_code_10000_602:
      000679                        573 	.ds 2
      00067B                        574 _hold_mods_30000_605:
      00067B                        575 	.ds 1
      00067C                        576 _commit_pending_id_10000_611:
      00067C                        577 	.ds 1
      00067D                        578 _ak820_tapping_before_event_10000_612:
      00067D                        579 	.ds 2
      00067F                        580 _ak820_tapping_process_record_10000_623:
      00067F                        581 	.ds 2
      000681                        582 _ak820_tapping_process_code_10000_624:
      000681                        583 	.ds 2
      000683                        584 _ak820_tapping_process_sc_mods_10000_624:
      000683                        585 	.ds 1
      000684                        586 _ak820_oneshot_mods::
      000684                        587 	.ds 1
      000685                        588 _ak820_oneshot_consumed::
      000685                        589 	.ds 1
      000686                        590 _ak820_oneshot_process_PARM_2:
      000686                        591 	.ds 1
      000687                        592 _ak820_oneshot_process_PARM_3:
      000687                        593 	.ds 1
      000688                        594 _ak820_oneshot_process_code_10000_649:
      000688                        595 	.ds 2
      00068A                        596 _ak820_oneshot_process_mods_10000_650:
      00068A                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000DD9                        606 _pending:
      000DD9                        607 	.ds 1
      000DDA                        608 _ak820_oneshot_target::
      000DDA                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      00469E                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      00469E 90 06 77         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0046A1 E0               [24]  656 	movx	a,@dptr
      0046A2 FF               [12]  657 	mov	r7,a
      0046A3 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0046A6                        659 00147$:
      0046A6 50 14            [24]  660 	jnc	00102$
      0046A8 90 06 76         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0046AB E0               [24]  662 	movx	a,@dptr
      0046AC FE               [12]  663 	mov	r6,a
      0046AD BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0046B0                        665 00149$:
      0046B0 50 0A            [24]  666 	jnc	00102$
      0046B2 8F 05            [24]  667 	mov	ar5,r7
      0046B4 ED               [12]  668 	mov	a,r5
      0046B5 12 38 90         [24]  669 	lcall	_ak820_outline_0186
      0046B8 2E               [12]  670 	add	a,r6
      0046B9 F5 82            [12]  671 	mov	dpl,a
      0046BB 22               [24]  672 	ret
      0046BC                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      0046BC 90 06 76         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0046BF E0               [24]  676 	movx	a,@dptr
      0046C0 FE               [12]  677 	mov	r6,a
      0046C1 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0046C4                        679 00151$:
      0046C4 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0046C6 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0046C9 75 82 80         [24]  683 	mov	dpl, #0x80
      0046CC 22               [24]  684 	ret
      0046CD                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0046CD BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      0046D0 75 82 81         [24]  688 	mov	dpl, #0x81
      0046D3 22               [24]  689 	ret
      0046D4                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      0046D4 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      0046D7 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_602'
                                    700 ;mods          Allocated with name '_hold_mods_30000_605'
                                    701 ;layer         Allocated with name '_hold_layer_30000_608'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      0046D8                        707 _hold:
      0046D8 12 38 4A         [24]  708 	lcall	_ak820_outline_0104
      0046DB 90 06 79         [24]  709 	mov	dptr,#_hold_code_10000_602
      0046DE 12 38 4F         [24]  710 	lcall	_ak820_outline_0105
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      0046E1 90 06 79         [24]  712 	mov	dptr,#_hold_code_10000_602
      0046E4 12 37 CB         [24]  713 	lcall	_ak820_outline_0010
      0046E7 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      0046E9 2D               [12]  715 	add	a,r5
      0046EA 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      0046EC 8F 05            [24]  718 	mov	ar5,r7
      0046EE 53 05 1F         [24]  719 	anl	ar5,#0x1f
      0046F1 90 06 7B         [24]  720 	mov	dptr,#_hold_mods_30000_605
      0046F4 ED               [12]  721 	mov	a,r5
      0046F5 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      0046F6 ED               [12]  724 	mov	a,r5
      0046F7 30 E4 08         [24]  725 	jnb	acc.4,00102$
      0046FA ED               [12]  726 	mov	a,r5
      0046FB C4               [12]  727 	swap	a
      0046FC 54 F0            [12]  728 	anl	a,#0xf0
      0046FE 90 06 7B         [24]  729 	mov	dptr,#_hold_mods_30000_605
      004701 F0               [24]  730 	movx	@dptr,a
      004702                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004702 90 06 78         [24]  733 	mov	dptr,#_hold_PARM_2
      004705 E0               [24]  734 	movx	a,@dptr
      004706 60 09            [24]  735 	jz	00104$
      004708 90 06 7B         [24]  736 	mov	dptr,#_hold_mods_30000_605
      00470B E0               [24]  737 	movx	a,@dptr
      00470C F5 82            [12]  738 	mov	dpl,a
      00470E 02 79 9B         [24]  739 	ljmp	_register_mods
      004711                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004711 90 06 7B         [24]  742 	mov	dptr,#_hold_mods_30000_605
      004714 E0               [24]  743 	movx	a,@dptr
      004715 F5 82            [12]  744 	mov	dpl,a
      004717 02 79 AF         [24]  745 	ljmp	_unregister_mods
      00471A                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      00471A 8F 06            [24]  748 	mov	ar6,r7
      00471C 74 0F            [12]  749 	mov	a,#0x0f
      00471E 5E               [12]  750 	anl	a,r6
      00471F FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004720 90 06 78         [24]  753 	mov	dptr,#_hold_PARM_2
      004723 E0               [24]  754 	movx	a,@dptr
      004724 60 05            [24]  755 	jz	00107$
      004726 8F 82            [24]  756 	mov	dpl, r7
      004728 02 7B 67         [24]  757 	ljmp	_layer_hold_on
      00472B                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      00472B 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      00472D 02 7B 9F         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_611'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004730                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004730 90 0D D9         [24]  774 	mov	dptr,#_pending
      004733 E0               [24]  775 	movx	a,@dptr
      004734 90 06 7C         [24]  776 	mov	dptr,#_commit_pending_id_10000_611
      004737 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004738 12 4B C0         [24]  779 	lcall	_ak820_outline_0150
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      00473B 90 06 7C         [24]  781 	mov	dptr,#_commit_pending_id_10000_611
      00473E E0               [24]  782 	movx	a,@dptr
      00473F 24 F0            [12]  783 	add	a,#_source_state
      004741 FF               [12]  784 	mov	r7,a
      004742 E4               [12]  785 	clr	a
      004743 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      004745 FE               [12]  787 	mov	r6,a
      004746 12 46 83         [24]  788 	lcall	_ak820_outline_0153
      004749 E0               [24]  789 	movx	a,@dptr
      00474A FD               [12]  790 	mov	r5,a
      00474B 43 05 04         [24]  791 	orl	ar5,#0x04
      00474E 12 46 83         [24]  792 	lcall	_ak820_outline_0153
      004751 ED               [12]  793 	mov	a,r5
      004752 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      004753 90 06 74         [24]  796 	mov	dptr,#_pending_code
      004756 12 38 00         [24]  797 	lcall	_ak820_outline_0051
      004759 90 06 78         [24]  798 	mov	dptr,#_hold_PARM_2
      00475C 12 4B 83         [24]  799 	lcall	_ak820_outline_0043
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      00475F 02 46 D8         [24]  801 	ljmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_612'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_613'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      004762                        812 _ak820_tapping_before:
      004762 12 38 4A         [24]  813 	lcall	_ak820_outline_0104
      004765 90 06 7D         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_612
      004768 12 38 4F         [24]  815 	lcall	_ak820_outline_0105
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      00476B 90 06 7D         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_612
      00476E 12 37 CB         [24]  818 	lcall	_ak820_outline_0010
      004771 12 4B 5B         [24]  819 	lcall	_ak820_outline_0021
      004774 C0 07            [24]  820 	push	ar7
      004776 C0 06            [24]  821 	push	ar6
      004778 12 BA 82         [24]  822 	lcall	___memcpy
      00477B 12 46 9E         [24]  823 	lcall	_ak820_tapping_source
      00477E AD 82            [24]  824 	mov	r5, dpl
      004780 D0 06            [24]  825 	pop	ar6
      004782 D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004784 90 0E 4A         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      004787 E0               [24]  829 	movx	a,@dptr
      004788 60 21            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00478A 74 04            [12]  832 	mov	a,#0x04
      00478C 12 4B 50         [24]  833 	lcall	_ak820_outline_0012
      00478F 60 16            [24]  834 	jz	00102$
      004791 BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      004794 80 11            [24]  836 	sjmp	00102$
      004796                        837 00218$:
      004796 74 05            [12]  838 	mov	a,#0x05
      004798 12 4B 50         [24]  839 	lcall	_ak820_outline_0012
      00479B 70 0A            [24]  840 	jnz	00102$
      00479D ED               [12]  841 	mov	a,r5
      00479E 12 4B 75         [24]  842 	lcall	_ak820_outline_0023
      0047A1 53 02 FD         [24]  843 	anl	ar2,#0xfd
      0047A4 12 4B B9         [24]  844 	lcall	_ak820_outline_0091
      0047A7                        845 00102$:
                                    846 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      0047A7 75 82 00         [24]  847 	mov	dpl, #0x00
      0047AA 22               [24]  848 	ret
      0047AB                        849 00106$:
                                    850 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      0047AB 90 0D D9         [24]  851 	mov	dptr,#_pending
      0047AE E0               [24]  852 	movx	a,@dptr
      0047AF FC               [12]  853 	mov	r4,a
      0047B0 BC FF 02         [24]  854 	cjne	r4,#0xff,00220$
      0047B3 80 3B            [24]  855 	sjmp	00108$
      0047B5                        856 00220$:
      0047B5 12 37 F8         [24]  857 	lcall	_ak820_outline_0033
      0047B8 FA               [12]  858 	mov	r2,a
      0047B9 A3               [24]  859 	inc	dptr
      0047BA E0               [24]  860 	movx	a,@dptr
      0047BB FB               [12]  861 	mov	r3,a
      0047BC 90 06 72         [24]  862 	mov	dptr,#_pending_time
      0047BF 12 38 44         [24]  863 	lcall	_ak820_outline_0100
      0047C2 EA               [12]  864 	mov	a,r2
      0047C3 C3               [12]  865 	clr	c
      0047C4 98               [12]  866 	subb	a,r0
      0047C5 FA               [12]  867 	mov	r2,a
      0047C6 EB               [12]  868 	mov	a,r3
      0047C7 99               [12]  869 	subb	a,r1
      0047C8 FB               [12]  870 	mov	r3,a
      0047C9 C3               [12]  871 	clr	c
      0047CA EA               [12]  872 	mov	a,r2
      0047CB 94 C8            [12]  873 	subb	a,#0xc8
      0047CD EB               [12]  874 	mov	a,r3
      0047CE 94 00            [12]  875 	subb	a,#0x00
      0047D0 50 17            [24]  876 	jnc	00107$
                                    877 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0047D2 74 04            [12]  878 	mov	a,#0x04
      0047D4 12 4B 8B         [24]  879 	lcall	_ak820_outline_0046
      0047D7 60 17            [24]  880 	jz	00108$
      0047D9 12 37 AA         [24]  881 	lcall	_ak820_outline_0005
      0047DC 60 12            [24]  882 	jz	00108$
      0047DE BD FF 02         [24]  883 	cjne	r5,#0xff,00224$
      0047E1 80 06            [24]  884 	sjmp	00107$
      0047E3                        885 00224$:
      0047E3 ED               [12]  886 	mov	a,r5
      0047E4 B5 04 02         [24]  887 	cjne	a,ar4,00225$
      0047E7 80 07            [24]  888 	sjmp	00108$
      0047E9                        889 00225$:
      0047E9                        890 00107$:
      0047E9 C0 05            [24]  891 	push	ar5
      0047EB 12 47 30         [24]  892 	lcall	_commit_pending
      0047EE D0 05            [24]  893 	pop	ar5
      0047F0                        894 00108$:
                                    895 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      0047F0 90 06 7D         [24]  896 	mov	dptr,#_ak820_tapping_before_event_10000_612
      0047F3 12 38 00         [24]  897 	lcall	_ak820_outline_0051
      0047F6 74 04            [12]  898 	mov	a,#0x04
      0047F8 12 4B 50         [24]  899 	lcall	_ak820_outline_0012
      0047FB 60 03            [24]  900 	jz	00114$
      0047FD BD FF 04         [24]  901 	cjne	r5,#0xff,00115$
      004800                        902 00114$:
      004800 75 82 01         [24]  903 	mov	dpl, #0x01
      004803 22               [24]  904 	ret
      004804                        905 00115$:
                                    906 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004804 ED               [12]  907 	mov	a,r5
      004805 12 4B AB         [24]  908 	lcall	_ak820_outline_0077
      004808 30 E1 13         [24]  909 	jnb	acc.1,00120$
                                    910 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00480B 74 05            [12]  911 	mov	a,#0x05
      00480D 2E               [12]  912 	add	a, r6
      00480E 12 37 D5         [24]  913 	lcall	_ak820_outline_0014
      004811 70 07            [24]  914 	jnz	00118$
      004813 74 FD            [12]  915 	mov	a,#0xfd
      004815 5B               [12]  916 	anl	a,r3
      004816 12 38 60         [24]  917 	lcall	_ak820_outline_0121
      004819 F0               [24]  918 	movx	@dptr,a
      00481A                        919 00118$:
                                    920 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      00481A 75 82 00         [24]  921 	mov	dpl, #0x00
      00481D 22               [24]  922 	ret
      00481E                        923 00120$:
                                    924 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      00481E 12 4B 3A         [24]  925 	lcall	_ak820_outline_0008
      004821 FF               [12]  926 	mov	r7,a
      004822 8B 06            [24]  927 	mov	ar6,r3
      004824 53 06 01         [24]  928 	anl	ar6,#0x01
      004827 EE               [12]  929 	mov	a,r6
      004828 B4 01 00         [24]  930 	cjne	a,#0x01,00231$
      00482B                        931 00231$:
      00482B B3               [12]  932 	cpl	c
      00482C 92 0C            [24]  933 	mov	_ak820_tapping_before_sloc0_1_0,c
      00482E 8F F0            [24]  934 	mov	b,r7
      004830 E4               [12]  935 	clr	a
      004831 33               [12]  936 	rlc	a
      004832 B5 F0 04         [24]  937 	cjne	a,b,00122$
      004835 75 82 00         [24]  938 	mov	dpl, #0x00
      004838 22               [24]  939 	ret
      004839                        940 00122$:
                                    941 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004839 63 03 01         [24]  942 	xrl	ar3,#0x01
      00483C 12 38 60         [24]  943 	lcall	_ak820_outline_0121
      00483F EB               [12]  944 	mov	a,r3
      004840 F0               [24]  945 	movx	@dptr,a
                                    946 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004841 75 82 01         [24]  947 	mov	dpl, #0x01
                                    948 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004844 22               [24]  949 	ret
                                    950 ;------------------------------------------------------------
                                    951 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    952 ;------------------------------------------------------------
                                    953 ;record        Allocated with name '_ak820_tapping_process_record_10000_623'
                                    954 ;id            Allocated with name '_ak820_tapping_process_id_10000_624'
                                    955 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_624'
                                    956 ;code          Allocated with name '_ak820_tapping_process_code_10000_624'
                                    957 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_624'
                                    958 ;------------------------------------------------------------
                                    959 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    960 ;	-----------------------------------------
                                    961 ;	 function ak820_tapping_process
                                    962 ;	-----------------------------------------
      004845                        963 _ak820_tapping_process:
      004845 12 38 4A         [24]  964 	lcall	_ak820_outline_0104
      004848 90 06 7F         [24]  965 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00484B 12 38 4F         [24]  966 	lcall	_ak820_outline_0105
                                    967 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      00484E 90 06 83         [24]  968 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004851 E4               [12]  969 	clr	a
      004852 F0               [24]  970 	movx	@dptr,a
                                    971 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004853 90 06 7F         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004856 12 38 00         [24]  973 	lcall	_ak820_outline_0051
      004859 74 04            [12]  974 	mov	a,#0x04
      00485B 12 4B 45         [24]  975 	lcall	_ak820_outline_0011
      00485E 70 04            [24]  976 	jnz	00102$
      004860 75 82 01         [24]  977 	mov	dpl, #0x01
      004863 22               [24]  978 	ret
      004864                        979 00102$:
                                    980 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004864 8E 04            [24]  981 	mov	ar4,r6
      004866 8F 05            [24]  982 	mov	ar5,r7
      004868 12 4B 5B         [24]  983 	lcall	_ak820_outline_0021
      00486B C0 07            [24]  984 	push	ar7
      00486D C0 06            [24]  985 	push	ar6
      00486F 12 BA 82         [24]  986 	lcall	___memcpy
      004872 12 46 9E         [24]  987 	lcall	_ak820_tapping_source
      004875 AD 82            [24]  988 	mov	r5, dpl
      004877 D0 06            [24]  989 	pop	ar6
      004879 D0 07            [24]  990 	pop	ar7
                                    991 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      00487B BD FF 04         [24]  992 	cjne	r5,#0xff,00104$
      00487E 75 82 01         [24]  993 	mov	dpl, #0x01
      004881 22               [24]  994 	ret
      004882                        995 00104$:
                                    996 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004882 74 07            [12]  997 	mov	a,#0x07
      004884 12 37 E7         [24]  998 	lcall	_ak820_outline_0017
      004887 FE               [12]  999 	mov	r6,a
      004888 A3               [24] 1000 	inc	dptr
      004889 E0               [24] 1001 	movx	a,@dptr
      00488A FF               [12] 1002 	mov	r7,a
      00488B 90 06 81         [24] 1003 	mov	dptr,#_ak820_tapping_process_code_10000_624
      00488E 12 4B 9E         [24] 1004 	lcall	_ak820_outline_0058
                                   1005 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004891 BE 1A 15         [24] 1006 	cjne	r6,#0x1a,00111$
      004894 BF 7C 12         [24] 1007 	cjne	r7,#0x7c,00111$
      004897 90 06 81         [24] 1008 	mov	dptr,#_ak820_tapping_process_code_10000_624
      00489A 74 26            [12] 1009 	mov	a,#0x26
      00489C F0               [24] 1010 	movx	@dptr,a
      00489D 74 22            [12] 1011 	mov	a,#0x22
      00489F A3               [24] 1012 	inc	dptr
      0048A0 F0               [24] 1013 	movx	@dptr,a
      0048A1 90 06 83         [24] 1014 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0048A4 74 02            [12] 1015 	mov	a,#0x02
      0048A6 F0               [24] 1016 	movx	@dptr,a
      0048A7 80 28            [24] 1017 	sjmp	00112$
      0048A9                       1018 00111$:
                                   1019 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0048A9 BE 1B 15         [24] 1020 	cjne	r6,#0x1b,00108$
      0048AC BF 7C 12         [24] 1021 	cjne	r7,#0x7c,00108$
      0048AF 90 06 81         [24] 1022 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0048B2 74 27            [12] 1023 	mov	a,#0x27
      0048B4 F0               [24] 1024 	movx	@dptr,a
      0048B5 74 32            [12] 1025 	mov	a,#0x32
      0048B7 A3               [24] 1026 	inc	dptr
      0048B8 F0               [24] 1027 	movx	@dptr,a
      0048B9 90 06 83         [24] 1028 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0048BC 74 20            [12] 1029 	mov	a,#0x20
      0048BE F0               [24] 1030 	movx	@dptr,a
      0048BF 80 10            [24] 1031 	sjmp	00112$
      0048C1                       1032 00108$:
                                   1033 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0048C1 BE 1E 0D         [24] 1034 	cjne	r6,#0x1e,00112$
      0048C4 BF 7C 0A         [24] 1035 	cjne	r7,#0x7c,00112$
      0048C7 90 06 81         [24] 1036 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0048CA 74 28            [12] 1037 	mov	a,#0x28
      0048CC F0               [24] 1038 	movx	@dptr,a
      0048CD 74 32            [12] 1039 	mov	a,#0x32
      0048CF A3               [24] 1040 	inc	dptr
      0048D0 F0               [24] 1041 	movx	@dptr,a
      0048D1                       1042 00112$:
                                   1043 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      0048D1 90 06 81         [24] 1044 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0048D4 E0               [24] 1045 	movx	a,@dptr
      0048D5 A3               [24] 1046 	inc	dptr
      0048D6 E0               [24] 1047 	movx	a,@dptr
      0048D7 FF               [12] 1048 	mov	r7,a
                                   1049 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      0048D8 BF 20 00         [24] 1050 	cjne	r7,#0x20,00242$
      0048DB                       1051 00242$:
      0048DB 40 05            [24] 1052 	jc	00113$
      0048DD BF 50 00         [24] 1053 	cjne	r7,#0x50,00244$
      0048E0                       1054 00244$:
      0048E0 40 04            [24] 1055 	jc	00114$
      0048E2                       1056 00113$:
      0048E2 75 82 01         [24] 1057 	mov	dpl, #0x01
      0048E5 22               [24] 1058 	ret
      0048E6                       1059 00114$:
                                   1060 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      0048E6 BF 40 00         [24] 1061 	cjne	r7,#0x40,00246$
      0048E9                       1062 00246$:
      0048E9 40 0C            [24] 1063 	jc	00117$
      0048EB 53 07 0F         [24] 1064 	anl	ar7,#0x0f
      0048EE BF 06 00         [24] 1065 	cjne	r7,#0x06,00248$
      0048F1                       1066 00248$:
      0048F1 40 04            [24] 1067 	jc	00117$
      0048F3 75 82 00         [24] 1068 	mov	dpl, #0x00
      0048F6 22               [24] 1069 	ret
      0048F7                       1070 00117$:
                                   1071 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      0048F7 90 06 7F         [24] 1072 	mov	dptr,#_ak820_tapping_process_record_10000_623
      0048FA 12 38 00         [24] 1073 	lcall	_ak820_outline_0051
      0048FD 74 05            [12] 1074 	mov	a,#0x05
      0048FF 12 4B 50         [24] 1075 	lcall	_ak820_outline_0012
      004902 60 1F            [24] 1076 	jz	00131$
                                   1077 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004904 90 0D D9         [24] 1078 	mov	dptr,#_pending
      004907 ED               [12] 1079 	mov	a,r5
      004908 12 46 13         [24] 1080 	lcall	_ak820_outline_0029
                                   1081 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      00490B 12 38 00         [24] 1082 	lcall	_ak820_outline_0051
      00490E 90 06 72         [24] 1083 	mov	dptr,#_pending_time
      004911 12 4B 9E         [24] 1084 	lcall	_ak820_outline_0058
                                   1085 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004914 90 06 81         [24] 1086 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004917 12 38 00         [24] 1087 	lcall	_ak820_outline_0051
      00491A 90 06 74         [24] 1088 	mov	dptr,#_pending_code
      00491D 12 4B 9E         [24] 1089 	lcall	_ak820_outline_0058
      004920 02 49 C1         [24] 1090 	ljmp	00132$
      004923                       1091 00131$:
                                   1092 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004923 90 0D D9         [24] 1093 	mov	dptr,#_pending
      004926 E0               [24] 1094 	movx	a,@dptr
      004927 FF               [12] 1095 	mov	r7,a
      004928 ED               [12] 1096 	mov	a,r5
      004929 B5 07 02         [24] 1097 	cjne	a,ar7,00251$
      00492C 80 03            [24] 1098 	sjmp	00252$
      00492E                       1099 00251$:
      00492E 02 49 9A         [24] 1100 	ljmp	00128$
      004931                       1101 00252$:
                                   1102 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004931 12 4B C0         [24] 1103 	lcall	_ak820_outline_0150
                                   1104 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004934 90 06 83         [24] 1105 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004937 E0               [24] 1106 	movx	a,@dptr
      004938 FF               [12] 1107 	mov	r7,a
      004939 E0               [24] 1108 	movx	a,@dptr
      00493A 60 05            [24] 1109 	jz	00120$
      00493C 8F 82            [24] 1110 	mov	dpl, r7
      00493E 12 80 3C         [24] 1111 	lcall	_add_owned_mods
      004941                       1112 00120$:
                                   1113 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004941 90 06 7F         [24] 1114 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004944 12 38 00         [24] 1115 	lcall	_ak820_outline_0051
      004947 74 07            [12] 1116 	mov	a,#0x07
      004949 2E               [12] 1117 	add	a, r6
      00494A FB               [12] 1118 	mov	r3,a
      00494B E4               [12] 1119 	clr	a
      00494C 3F               [12] 1120 	addc	a, r7
      00494D FC               [12] 1121 	mov	r4,a
      00494E 90 06 81         [24] 1122 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004951 E0               [24] 1123 	movx	a,@dptr
      004952 F9               [12] 1124 	mov	r1,a
      004953 7A 00            [12] 1125 	mov	r2,#0x00
      004955 12 33 FC         [24] 1126 	lcall	_ak820_outline_0122
      004958 E9               [12] 1127 	mov	a,r1
      004959 F0               [24] 1128 	movx	@dptr,a
      00495A EA               [12] 1129 	mov	a,r2
      00495B A3               [24] 1130 	inc	dptr
      00495C F0               [24] 1131 	movx	@dptr,a
                                   1132 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      00495D C3               [12] 1133 	clr	c
      00495E 04               [12] 1134 	inc	a
      00495F 99               [12] 1135 	subb	a,r1
      004960 50 26            [24] 1136 	jnc	00122$
                                   1137 ;	free result
                                   1138 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004962 74 06            [12] 1139 	mov	a,#0x06
      004964 12 37 E7         [24] 1140 	lcall	_ak820_outline_0017
      004967 54 0F            [12] 1141 	anl	a,#0x0f
      004969 44 10            [12] 1142 	orl	a,#0x10
      00496B F0               [24] 1143 	movx	@dptr,a
                                   1144 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      00496C 12 46 0A         [24] 1145 	lcall	_ak820_outline_0013
      00496F A3               [24] 1146 	inc	dptr
      004970 12 4B 83         [24] 1147 	lcall	_ak820_outline_0043
                                   1148 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004973 12 73 D8         [24] 1149 	lcall	_process_record
                                   1150 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004976 90 06 7F         [24] 1151 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004979 12 37 A0         [24] 1152 	lcall	_ak820_outline_0004
      00497C A3               [24] 1153 	inc	dptr
      00497D A3               [24] 1154 	inc	dptr
      00497E A3               [24] 1155 	inc	dptr
      00497F A3               [24] 1156 	inc	dptr
      004980 A3               [24] 1157 	inc	dptr
      004981 E4               [12] 1158 	clr	a
      004982 12 46 3F         [24] 1159 	lcall	_ak820_outline_0060
                                   1160 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004985 12 73 D8         [24] 1161 	lcall	_process_record
      004988                       1162 00122$:
                                   1163 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004988 90 06 83         [24] 1164 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00498B E0               [24] 1165 	movx	a,@dptr
      00498C FF               [12] 1166 	mov	r7,a
      00498D E0               [24] 1167 	movx	a,@dptr
      00498E 60 31            [24] 1168 	jz	00132$
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004990 8F 82            [24] 1170 	mov	dpl, r7
      004992 12 80 4C         [24] 1171 	lcall	_del_owned_mods
                                   1172 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004995 12 83 77         [24] 1173 	lcall	_send_keyboard_report
      004998 80 27            [24] 1174 	sjmp	00132$
      00499A                       1175 00128$:
                                   1176 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      00499A ED               [12] 1177 	mov	a,r5
      00499B 24 F0            [12] 1178 	add	a, #_source_state
      00499D FE               [12] 1179 	mov	r6,a
      00499E E4               [12] 1180 	clr	a
      00499F 34 05            [12] 1181 	addc	a, #(_source_state >> 8)
      0049A1 FF               [12] 1182 	mov	r7,a
      0049A2 12 38 38         [24] 1183 	lcall	_ak820_outline_0093
      0049A5 FD               [12] 1184 	mov	r5,a
      0049A6 30 E2 18         [24] 1185 	jnb	acc.2,00132$
                                   1186 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      0049A9 53 05 FB         [24] 1187 	anl	ar5,#0xfb
      0049AC 12 46 5D         [24] 1188 	lcall	_ak820_outline_0116
      0049AF ED               [12] 1189 	mov	a,r5
      0049B0 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      0049B1 90 06 81         [24] 1192 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0049B4 12 38 00         [24] 1193 	lcall	_ak820_outline_0051
      0049B7 90 06 78         [24] 1194 	mov	dptr,#_hold_PARM_2
      0049BA E4               [12] 1195 	clr	a
      0049BB 12 46 3F         [24] 1196 	lcall	_ak820_outline_0060
      0049BE 12 46 D8         [24] 1197 	lcall	_hold
      0049C1                       1198 00132$:
                                   1199 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      0049C1 75 82 00         [24] 1200 	mov	dpl, #0x00
                                   1201 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      0049C4 22               [24] 1202 	ret
                                   1203 ;------------------------------------------------------------
                                   1204 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1205 ;------------------------------------------------------------
                                   1206 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_647'
                                   1207 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_648'
                                   1208 ;------------------------------------------------------------
                                   1209 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1210 ;	-----------------------------------------
                                   1211 ;	 function ak820_tapping_cancel
                                   1212 ;	-----------------------------------------
      0049C5                       1213 _ak820_tapping_cancel:
                                   1214 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      0049C5 12 4B C0         [24] 1215 	lcall	_ak820_outline_0150
                                   1216 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0049C8 7F 00            [12] 1217 	mov	r7,#0x00
      0049CA                       1218 00103$:
      0049CA BF 82 00         [24] 1219 	cjne	r7,#0x82,00122$
      0049CD                       1220 00122$:
      0049CD 50 1D            [24] 1221 	jnc	00105$
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      0049CF EF               [12] 1223 	mov	a,r7
      0049D0 24 F0            [12] 1224 	add	a, #_source_state
      0049D2 FD               [12] 1225 	mov	r5,a
      0049D3 E4               [12] 1226 	clr	a
      0049D4 34 05            [12] 1227 	addc	a, #(_source_state >> 8)
      0049D6 12 4B 96         [24] 1228 	lcall	_ak820_outline_0056
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      0049D9 74 02            [12] 1230 	mov	a,#0x02
      0049DB 5C               [12] 1231 	anl	a,r4
      0049DC FB               [12] 1232 	mov	r3,a
      0049DD 53 04 01         [24] 1233 	anl	ar4,#0x01
      0049E0 EC               [12] 1234 	mov	a,r4
      0049E1 2C               [12] 1235 	add	a,r4
      0049E2 42 03            [12] 1236 	orl	ar3,a
      0049E4 12 38 6A         [24] 1237 	lcall	_ak820_outline_0131
      0049E7 EB               [12] 1238 	mov	a,r3
      0049E8 F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0049E9 0F               [12] 1241 	inc	r7
      0049EA 80 DE            [24] 1242 	sjmp	00103$
      0049EC                       1243 00105$:
                                   1244 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      0049EC 22               [24] 1245 	ret
                                   1246 ;------------------------------------------------------------
                                   1247 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1248 ;------------------------------------------------------------
                                   1249 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1250 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1251 ;code          Allocated with name '_ak820_oneshot_process_code_10000_649'
                                   1252 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_650'
                                   1253 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1254 ;------------------------------------------------------------
                                   1255 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1256 ;	-----------------------------------------
                                   1257 ;	 function ak820_oneshot_process
                                   1258 ;	-----------------------------------------
      0049ED                       1259 _ak820_oneshot_process:
      0049ED 12 38 4A         [24] 1260 	lcall	_ak820_outline_0104
      0049F0 90 06 88         [24] 1261 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      0049F3 12 38 4F         [24] 1262 	lcall	_ak820_outline_0105
                                   1263 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      0049F6 90 06 86         [24] 1264 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0049F9 E0               [24] 1265 	movx	a,@dptr
      0049FA FF               [12] 1266 	mov	r7,a
      0049FB BF FF 02         [24] 1267 	cjne	r7,#0xff,00265$
      0049FE 80 07            [24] 1268 	sjmp	00101$
      004A00                       1269 00265$:
      004A00 12 A4 81         [24] 1270 	lcall	_get_repeat_key_count
      004A03 E5 82            [12] 1271 	mov	a, dpl
      004A05 60 04            [24] 1272 	jz	00102$
      004A07                       1273 00101$:
      004A07 75 82 01         [24] 1274 	mov	dpl, #0x01
      004A0A 22               [24] 1275 	ret
      004A0B                       1276 00102$:
                                   1277 ;	keyboards/ajazz/ak820/ak820_tapping.c:154: if (code >= QK_MAGIC_GUI_ON && code <= QK_MAGIC_TOGGLE_GUI) return true;
      004A0B 90 06 88         [24] 1278 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      004A0E 12 46 4B         [24] 1279 	lcall	_ak820_outline_0098
      004A11 C3               [12] 1280 	clr	c
      004A12 ED               [12] 1281 	mov	a,r5
      004A13 94 09            [12] 1282 	subb	a,#0x09
      004A15 EE               [12] 1283 	mov	a,r6
      004A16 94 70            [12] 1284 	subb	a,#0x70
      004A18 40 0C            [24] 1285 	jc	00105$
      004A1A 74 0B            [12] 1286 	mov	a,#0x0b
      004A1C 9D               [12] 1287 	subb	a,r5
      004A1D 74 70            [12] 1288 	mov	a,#0x70
      004A1F 9E               [12] 1289 	subb	a,r6
      004A20 40 04            [24] 1290 	jc	00105$
                                   1291 ;	free result
      004A22 75 82 01         [24] 1292 	mov	dpl, #0x01
      004A25 22               [24] 1293 	ret
      004A26                       1294 00105$:
                                   1295 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004A26 90 06 88         [24] 1296 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      004A29 E0               [24] 1297 	movx	a,@dptr
      004A2A FB               [12] 1298 	mov	r3,a
      004A2B A3               [24] 1299 	inc	dptr
      004A2C E0               [24] 1300 	movx	a,@dptr
      004A2D F9               [12] 1301 	mov	r1,a
      004A2E B9 52 02         [24] 1302 	cjne	r1,#0x52,00269$
      004A31 80 03            [24] 1303 	sjmp	00270$
      004A33                       1304 00269$:
      004A33 02 4A DA         [24] 1305 	ljmp	00119$
      004A36                       1306 00270$:
      004A36 8B 02            [24] 1307 	mov	ar2,r3
      004A38 53 02 E0         [24] 1308 	anl	ar2,#0xe0
      004A3B BA A0 02         [24] 1309 	cjne	r2,#0xa0,00271$
      004A3E 80 03            [24] 1310 	sjmp	00272$
      004A40                       1311 00271$:
      004A40 02 4A DA         [24] 1312 	ljmp	00119$
      004A43                       1313 00272$:
                                   1314 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004A43 8B 02            [24] 1315 	mov	ar2,r3
      004A45 53 02 0F         [24] 1316 	anl	ar2,#0x0f
      004A48 90 06 8A         [24] 1317 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004A4B EA               [12] 1318 	mov	a,r2
      004A4C F0               [24] 1319 	movx	@dptr,a
                                   1320 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004A4D EB               [12] 1321 	mov	a,r3
      004A4E 30 E4 08         [24] 1322 	jnb	acc.4,00108$
      004A51 EA               [12] 1323 	mov	a,r2
      004A52 C4               [12] 1324 	swap	a
      004A53 54 F0            [12] 1325 	anl	a,#0xf0
      004A55 90 06 8A         [24] 1326 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004A58 F0               [24] 1327 	movx	@dptr,a
      004A59                       1328 00108$:
                                   1329 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004A59 90 06 87         [24] 1330 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004A5C E0               [24] 1331 	movx	a,@dptr
      004A5D 60 2E            [24] 1332 	jz	00116$
                                   1333 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004A5F EF               [12] 1334 	mov	a,r7
      004A60 12 4B 75         [24] 1335 	lcall	_ak820_outline_0023
      004A63 43 02 08         [24] 1336 	orl	ar2,#0x08
      004A66 12 4B B9         [24] 1337 	lcall	_ak820_outline_0091
                                   1338 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004A69 53 02 EF         [24] 1339 	anl	ar2,#0xef
      004A6C 12 4B B9         [24] 1340 	lcall	_ak820_outline_0091
                                   1341 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004A6F 90 0D DA         [24] 1342 	mov	dptr,#_ak820_oneshot_target
      004A72 E0               [24] 1343 	movx	a,@dptr
      004A73 FA               [12] 1344 	mov	r2,a
      004A74 BA FF 02         [24] 1345 	cjne	r2,#0xff,00275$
      004A77 80 09            [24] 1346 	sjmp	00110$
      004A79                       1347 00275$:
      004A79 12 4B A4         [24] 1348 	lcall	_ak820_outline_0064
      004A7C 43 02 10         [24] 1349 	orl	ar2,#0x10
      004A7F 12 4B B9         [24] 1350 	lcall	_ak820_outline_0091
      004A82                       1351 00110$:
                                   1352 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004A82 90 06 8A         [24] 1353 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004A85 E0               [24] 1354 	movx	a,@dptr
      004A86 F5 82            [12] 1355 	mov	dpl,a
      004A88 12 79 9B         [24] 1356 	lcall	_register_mods
      004A8B 80 49            [24] 1357 	sjmp	00117$
      004A8D                       1358 00116$:
                                   1359 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004A8D EF               [12] 1360 	mov	a,r7
      004A8E 12 4B 75         [24] 1361 	lcall	_ak820_outline_0023
      004A91 30 E3 42         [24] 1362 	jnb	acc.3,00117$
                                   1363 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004A94 EA               [12] 1364 	mov	a,r2
      004A95 20 E4 24         [24] 1365 	jb	acc.4,00112$
                                   1366 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004A98 90 06 84         [24] 1367 	mov	dptr,#_ak820_oneshot_mods
      004A9B E0               [24] 1368 	movx	a,@dptr
      004A9C F4               [12] 1369 	cpl	a
      004A9D FA               [12] 1370 	mov	r2,a
      004A9E 90 06 8A         [24] 1371 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004AA1 E0               [24] 1372 	movx	a,@dptr
      004AA2 F9               [12] 1373 	mov	r1,a
      004AA3 52 02            [12] 1374 	anl	ar2,a
      004AA5 8A 82            [24] 1375 	mov	dpl, r2
      004AA7 C0 04            [24] 1376 	push	ar4
      004AA9 C0 03            [24] 1377 	push	ar3
      004AAB C0 01            [24] 1378 	push	ar1
      004AAD 12 80 3C         [24] 1379 	lcall	_add_owned_mods
      004AB0 D0 01            [24] 1380 	pop	ar1
      004AB2 D0 03            [24] 1381 	pop	ar3
      004AB4 D0 04            [24] 1382 	pop	ar4
                                   1383 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004AB6 90 06 84         [24] 1384 	mov	dptr,#_ak820_oneshot_mods
      004AB9 E0               [24] 1385 	movx	a,@dptr
      004ABA 49               [12] 1386 	orl	a,r1
      004ABB F0               [24] 1387 	movx	@dptr,a
      004ABC                       1388 00112$:
                                   1389 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004ABC 90 06 8A         [24] 1390 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004ABF E0               [24] 1391 	movx	a,@dptr
      004AC0 F5 82            [12] 1392 	mov	dpl,a
      004AC2 C0 04            [24] 1393 	push	ar4
      004AC4 C0 03            [24] 1394 	push	ar3
      004AC6 12 79 AF         [24] 1395 	lcall	_unregister_mods
      004AC9 D0 03            [24] 1396 	pop	ar3
      004ACB D0 04            [24] 1397 	pop	ar4
                                   1398 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004ACD 12 4B A4         [24] 1399 	lcall	_ak820_outline_0064
      004AD0 53 02 E7         [24] 1400 	anl	ar2,#0xe7
      004AD3 12 4B B9         [24] 1401 	lcall	_ak820_outline_0091
      004AD6                       1402 00117$:
                                   1403 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004AD6 75 82 00         [24] 1404 	mov	dpl, #0x00
      004AD9 22               [24] 1405 	ret
      004ADA                       1406 00119$:
                                   1407 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004ADA 90 06 87         [24] 1408 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004ADD E0               [24] 1409 	movx	a,@dptr
      004ADE 60 56            [24] 1410 	jz	00127$
      004AE0 C3               [12] 1411 	clr	c
      004AE1 74 01            [12] 1412 	mov	a,#0x01
      004AE3 9D               [12] 1413 	subb	a,r5
      004AE4 E4               [12] 1414 	clr	a
      004AE5 9E               [12] 1415 	subb	a,r6
      004AE6 50 4E            [24] 1416 	jnc	00127$
                                   1417 ;	free result
                                   1418 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004AE8 C3               [12] 1419 	clr	c
      004AE9 ED               [12] 1420 	mov	a,r5
      004AEA 94 E0            [12] 1421 	subb	a,#0xe0
      004AEC EE               [12] 1422 	mov	a,r6
      004AED 94 00            [12] 1423 	subb	a,#0x00
      004AEF 40 07            [24] 1424 	jc	00132$
      004AF1 74 E7            [12] 1425 	mov	a,#0xe7
      004AF3 9D               [12] 1426 	subb	a,r5
      004AF4 E4               [12] 1427 	clr	a
      004AF5 9E               [12] 1428 	subb	a,r6
      004AF6 50 3E            [24] 1429 	jnc	00127$
                                   1430 ;	free result
      004AF8                       1431 00132$:
                                   1432 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004AF8 74 AE            [12] 1433 	mov	a,#0x100 - 0x52
      004AFA 2E               [12] 1434 	add	a,r6
      004AFB 50 09            [24] 1435 	jnc	00172$
      004AFD C3               [12] 1436 	clr	c
      004AFE 74 DF            [12] 1437 	mov	a,#0xdf
      004B00 9D               [12] 1438 	subb	a,r5
      004B01 74 52            [12] 1439 	mov	a,#0x52
      004B03 9E               [12] 1440 	subb	a,r6
      004B04 50 30            [24] 1441 	jnc	00127$
                                   1442 ;	free result
                                   1443 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004B06                       1444 00172$:
      004B06 7E 00            [12] 1445 	mov	r6,#0x00
      004B08                       1446 00134$:
      004B08 BE 82 00         [24] 1447 	cjne	r6,#0x82,00284$
      004B0B                       1448 00284$:
      004B0B 50 12            [24] 1449 	jnc	00123$
                                   1450 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004B0D EE               [12] 1451 	mov	a,r6
      004B0E 12 4B AB         [24] 1452 	lcall	_ak820_outline_0077
      004B11 30 E3 08         [24] 1453 	jnb	acc.3,00135$
      004B14 43 03 10         [24] 1454 	orl	ar3,#0x10
      004B17 12 38 60         [24] 1455 	lcall	_ak820_outline_0121
      004B1A EB               [12] 1456 	mov	a,r3
      004B1B F0               [24] 1457 	movx	@dptr,a
      004B1C                       1458 00135$:
                                   1459 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004B1C 0E               [12] 1460 	inc	r6
      004B1D 80 E9            [24] 1461 	sjmp	00134$
      004B1F                       1462 00123$:
                                   1463 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004B1F 90 06 84         [24] 1464 	mov	dptr,#_ak820_oneshot_mods
      004B22 E0               [24] 1465 	movx	a,@dptr
      004B23 FE               [12] 1466 	mov	r6,a
      004B24 E0               [24] 1467 	movx	a,@dptr
      004B25 60 0F            [24] 1468 	jz	00127$
                                   1469 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004B27 90 06 85         [24] 1470 	mov	dptr,#_ak820_oneshot_consumed
      004B2A EE               [12] 1471 	mov	a,r6
      004B2B F0               [24] 1472 	movx	@dptr,a
                                   1473 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004B2C 90 0D DA         [24] 1474 	mov	dptr,#_ak820_oneshot_target
      004B2F EF               [12] 1475 	mov	a,r7
      004B30 F0               [24] 1476 	movx	@dptr,a
                                   1477 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004B31 90 06 84         [24] 1478 	mov	dptr,#_ak820_oneshot_mods
      004B34 E4               [12] 1479 	clr	a
      004B35 F0               [24] 1480 	movx	@dptr,a
      004B36                       1481 00127$:
                                   1482 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004B36 75 82 01         [24] 1483 	mov	dpl, #0x01
                                   1484 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004B39 22               [24] 1485 	ret
                                   1486 	.area CSEG    (CODE)
                                   1487 	.area CONST   (CODE)
                                   1488 	.area XINIT   (CODE)
      00C342                       1489 __xinit__pending:
      00C342 FF                    1490 	.db #0xff	; 255
      00C343                       1491 __xinit__ak820_oneshot_target:
      00C343 FF                    1492 	.db #0xff	; 255
                                   1493 	.area CABS    (ABS,CODE)
                                   1494 
                                   1495 ; Experimental exact instruction outlining.
                                   1496 	.globl _ak820_outline_0004
                                   1497 	.globl _ak820_outline_0005
                                   1498 	.globl _ak820_outline_0008
                                   1499 	.globl _ak820_outline_0010
                                   1500 	.globl _ak820_outline_0011
                                   1501 	.globl _ak820_outline_0012
                                   1502 	.globl _ak820_outline_0013
                                   1503 	.globl _ak820_outline_0014
                                   1504 	.globl _ak820_outline_0017
                                   1505 	.globl _ak820_outline_0021
                                   1506 	.globl _ak820_outline_0023
                                   1507 	.globl _ak820_outline_0029
                                   1508 	.globl _ak820_outline_0033
                                   1509 	.globl _ak820_outline_0043
                                   1510 	.globl _ak820_outline_0046
                                   1511 	.globl _ak820_outline_0051
                                   1512 	.globl _ak820_outline_0056
                                   1513 	.globl _ak820_outline_0058
                                   1514 	.globl _ak820_outline_0060
                                   1515 	.globl _ak820_outline_0064
                                   1516 	.globl _ak820_outline_0077
                                   1517 	.globl _ak820_outline_0091
                                   1518 	.globl _ak820_outline_0093
                                   1519 	.globl _ak820_outline_0098
                                   1520 	.globl _ak820_outline_0100
                                   1521 	.globl _ak820_outline_0104
                                   1522 	.globl _ak820_outline_0105
                                   1523 	.globl _ak820_outline_0116
                                   1524 	.globl _ak820_outline_0121
                                   1525 	.globl _ak820_outline_0122
                                   1526 	.globl _ak820_outline_0131
                                   1527 	.globl _ak820_outline_0150
                                   1528 	.globl _ak820_outline_0153
                                   1529 	.globl _ak820_outline_0186
                                   1530 
                                   1531 	.area CSEG (CODE)
                                   1532 ; function ak820_outline_0008
      004B3A                       1533 _ak820_outline_0008:
      004B3A 8E 82            [24] 1534 	mov	dpl,r6
      004B3C 8F 83            [24] 1535 	mov	dph,r7
      004B3E A3               [24] 1536 	inc	dptr
      004B3F A3               [24] 1537 	inc	dptr
      004B40 A3               [24] 1538 	inc	dptr
      004B41 A3               [24] 1539 	inc	dptr
      004B42 A3               [24] 1540 	inc	dptr
      004B43 E0               [24] 1541 	movx	a,@dptr
      004B44 22               [24] 1542 	ret
                                   1543 
                                   1544 	.area CSEG (CODE)
                                   1545 ; function ak820_outline_0011
      004B45                       1546 _ak820_outline_0011:
      004B45 2E               [12] 1547 	add	a,r6
      004B46 FC               [12] 1548 	mov	r4,a
      004B47 E4               [12] 1549 	clr	a
      004B48 3F               [12] 1550 	addc	a,r7
      004B49 FD               [12] 1551 	mov	r5,a
      004B4A 8C 82            [24] 1552 	mov	dpl,r4
      004B4C 8D 83            [24] 1553 	mov	dph,r5
      004B4E E0               [24] 1554 	movx	a,@dptr
      004B4F 22               [24] 1555 	ret
                                   1556 
                                   1557 	.area CSEG (CODE)
                                   1558 ; function ak820_outline_0012
      004B50                       1559 _ak820_outline_0012:
      004B50 2E               [12] 1560 	add	a,r6
      004B51 FB               [12] 1561 	mov	r3,a
      004B52 E4               [12] 1562 	clr	a
      004B53 3F               [12] 1563 	addc	a,r7
      004B54 FC               [12] 1564 	mov	r4,a
      004B55 8B 82            [24] 1565 	mov	dpl,r3
      004B57 8C 83            [24] 1566 	mov	dph,r4
      004B59 E0               [24] 1567 	movx	a,@dptr
      004B5A 22               [24] 1568 	ret
                                   1569 
                                   1570 	.area CSEG (CODE)
                                   1571 ; function ak820_outline_0021
      004B5B                       1572 _ak820_outline_0021:
      004B5B 90 0D C9         [24] 1573 	mov	dptr,#___memcpy_PARM_2
      004B5E EC               [12] 1574 	mov	a,r4
      004B5F F0               [24] 1575 	movx	@dptr,a
      004B60 ED               [12] 1576 	mov	a,r5
      004B61 A3               [24] 1577 	inc	dptr
      004B62 F0               [24] 1578 	movx	@dptr,a
      004B63 E4               [12] 1579 	clr	a
      004B64 A3               [24] 1580 	inc	dptr
      004B65 F0               [24] 1581 	movx	@dptr,a
      004B66 90 0D CC         [24] 1582 	mov	dptr,#___memcpy_PARM_3
      004B69 74 02            [12] 1583 	mov	a,#0x02
      004B6B F0               [24] 1584 	movx	@dptr,a
      004B6C E4               [12] 1585 	clr	a
      004B6D A3               [24] 1586 	inc	dptr
      004B6E F0               [24] 1587 	movx	@dptr,a
      004B6F 90 06 76         [24] 1588 	mov	dptr,#_ak820_tapping_source_PARM_1
      004B72 F5 F0            [12] 1589 	mov	b,a
      004B74 22               [24] 1590 	ret
                                   1591 
                                   1592 	.area CSEG (CODE)
                                   1593 ; function ak820_outline_0023
      004B75                       1594 _ak820_outline_0023:
      004B75 24 F0            [12] 1595 	add	a,#_source_state
      004B77 FB               [12] 1596 	mov	r3,a
      004B78 E4               [12] 1597 	clr	a
      004B79 34 05            [12] 1598 	addc	a,#(_source_state>>8)
      004B7B FC               [12] 1599 	mov	r4,a
      004B7C 8B 82            [24] 1600 	mov	dpl,r3
      004B7E 8C 83            [24] 1601 	mov	dph,r4
      004B80 E0               [24] 1602 	movx	a,@dptr
      004B81 FA               [12] 1603 	mov	r2,a
      004B82 22               [24] 1604 	ret
                                   1605 
                                   1606 	.area CSEG (CODE)
                                   1607 ; function ak820_outline_0043
      004B83                       1608 _ak820_outline_0043:
      004B83 74 01            [12] 1609 	mov	a,#0x01
      004B85 F0               [24] 1610 	movx	@dptr,a
      004B86 8E 82            [24] 1611 	mov	dpl,r6
      004B88 8F 83            [24] 1612 	mov	dph,r7
      004B8A 22               [24] 1613 	ret
                                   1614 
                                   1615 	.area CSEG (CODE)
                                   1616 ; function ak820_outline_0046
      004B8B                       1617 _ak820_outline_0046:
      004B8B 2E               [12] 1618 	add	a,r6
      004B8C FA               [12] 1619 	mov	r2,a
      004B8D E4               [12] 1620 	clr	a
      004B8E 3F               [12] 1621 	addc	a,r7
      004B8F FB               [12] 1622 	mov	r3,a
      004B90 8A 82            [24] 1623 	mov	dpl,r2
      004B92 8B 83            [24] 1624 	mov	dph,r3
      004B94 E0               [24] 1625 	movx	a,@dptr
      004B95 22               [24] 1626 	ret
                                   1627 
                                   1628 	.area CSEG (CODE)
                                   1629 ; function ak820_outline_0056
      004B96                       1630 _ak820_outline_0056:
      004B96 FE               [12] 1631 	mov	r6,a
      004B97 8D 82            [24] 1632 	mov	dpl,r5
      004B99 8E 83            [24] 1633 	mov	dph,r6
      004B9B E0               [24] 1634 	movx	a,@dptr
      004B9C FC               [12] 1635 	mov	r4,a
      004B9D 22               [24] 1636 	ret
                                   1637 
                                   1638 	.area CSEG (CODE)
                                   1639 ; function ak820_outline_0058
      004B9E                       1640 _ak820_outline_0058:
      004B9E EE               [12] 1641 	mov	a,r6
      004B9F F0               [24] 1642 	movx	@dptr,a
      004BA0 EF               [12] 1643 	mov	a,r7
      004BA1 A3               [24] 1644 	inc	dptr
      004BA2 F0               [24] 1645 	movx	@dptr,a
      004BA3 22               [24] 1646 	ret
                                   1647 
                                   1648 	.area CSEG (CODE)
                                   1649 ; function ak820_outline_0064
      004BA4                       1650 _ak820_outline_0064:
      004BA4 8B 82            [24] 1651 	mov	dpl,r3
      004BA6 8C 83            [24] 1652 	mov	dph,r4
      004BA8 E0               [24] 1653 	movx	a,@dptr
      004BA9 FA               [12] 1654 	mov	r2,a
      004BAA 22               [24] 1655 	ret
                                   1656 
                                   1657 	.area CSEG (CODE)
                                   1658 ; function ak820_outline_0077
      004BAB                       1659 _ak820_outline_0077:
      004BAB 24 F0            [12] 1660 	add	a,#_source_state
      004BAD FC               [12] 1661 	mov	r4,a
      004BAE E4               [12] 1662 	clr	a
      004BAF 34 05            [12] 1663 	addc	a,#(_source_state>>8)
      004BB1 FD               [12] 1664 	mov	r5,a
      004BB2 8C 82            [24] 1665 	mov	dpl,r4
      004BB4 8D 83            [24] 1666 	mov	dph,r5
      004BB6 E0               [24] 1667 	movx	a,@dptr
      004BB7 FB               [12] 1668 	mov	r3,a
      004BB8 22               [24] 1669 	ret
                                   1670 
                                   1671 	.area CSEG (CODE)
                                   1672 ; function ak820_outline_0091
      004BB9                       1673 _ak820_outline_0091:
      004BB9 8B 82            [24] 1674 	mov	dpl,r3
      004BBB 8C 83            [24] 1675 	mov	dph,r4
      004BBD EA               [12] 1676 	mov	a,r2
      004BBE F0               [24] 1677 	movx	@dptr,a
      004BBF 22               [24] 1678 	ret
                                   1679 
                                   1680 	.area CSEG (CODE)
                                   1681 ; function ak820_outline_0150
      004BC0                       1682 _ak820_outline_0150:
      004BC0 90 0D D9         [24] 1683 	mov	dptr,#_pending
      004BC3 74 FF            [12] 1684 	mov	a,#0xff
      004BC5 F0               [24] 1685 	movx	@dptr,a
      004BC6 22               [24] 1686 	ret
