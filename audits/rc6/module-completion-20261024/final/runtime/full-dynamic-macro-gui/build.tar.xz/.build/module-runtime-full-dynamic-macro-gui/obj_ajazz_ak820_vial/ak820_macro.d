ak820_macro.o: keyboards/ajazz/ak820/ak820_macro.c \
 keyboards/ajazz/ak820/config.h \
 .build/module-runtime-full-dynamic-macro-gui/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h keyboards/ajazz/ak820/ak820_macro.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdbool.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdint.h \
 keyboards/ajazz/ak820/ak820_nvm.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stddef.h \
 platforms/eeprom.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdlib.h
