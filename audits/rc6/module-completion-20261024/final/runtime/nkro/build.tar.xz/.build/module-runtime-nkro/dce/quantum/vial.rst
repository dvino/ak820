                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000045                        541 _vial_handle_cmd_sloc0_1_0:
      000045                        542 	.ds 2
      000047                        543 _vial_handle_cmd_sloc1_1_0:
      000047                        544 	.ds 2
      000049                        545 _vial_handle_cmd_sloc2_1_0:
      000049                        546 	.ds 2
      00004B                        547 _vial_handle_cmd_sloc3_1_0:
      00004B                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C1A                        573 _vial_unlock_timer:
      000C1A                        574 	.ds 4
      000C1E                        575 _vial_unlock_holding:
      000C1E                        576 	.ds 1
      000C1F                        577 _vial_keycode_firewall_in_10000_609:
      000C1F                        578 	.ds 2
      000C21                        579 _vial_fill_packet_PARM_2:
      000C21                        580 	.ds 1
      000C22                        581 _vial_fill_packet_msg_10000_612:
      000C22                        582 	.ds 2
      000C24                        583 _vial_handle_cmd_PARM_2:
      000C24                        584 	.ds 1
      000C25                        585 _vial_handle_cmd_data_10000_617:
      000C25                        586 	.ds 3
      000C28                        587 _vial_handle_cmd_entry_70000_645:
      000C28                        588 	.ds 10
      000C32                        589 _vial_handle_cmd_entry_70000_646:
      000C32                        590 	.ds 10
      000C3C                        591 _g_vial_magic_keycode_override::
      000C3C                        592 	.ds 2
      000C3E                        593 _vial_keycode_down_keycode_10000_648:
      000C3E                        594 	.ds 2
      000C40                        595 _vial_keycode_down_dummy_event_30000_655:
      000C40                        596 	.ds 6
      000C46                        597 _vial_keycode_up_keycode_10000_656:
      000C46                        598 	.ds 2
      000C48                        599 _vial_keycode_up_dummy_event_30000_663:
      000C48                        600 	.ds 6
      000C4E                        601 _vial_keycode_tap_keycode_10000_664:
      000C4E                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000DE3                        611 _vial_unlocked::
      000DE3                        612 	.ds 1
      000DE4                        613 _vial_unlock_in_progress::
      000DE4                        614 	.ds 1
      000DE5                        615 _vial_unlock_counter:
      000DE5                        616 	.ds 1
      000DE6                        617 _vial_unlock_combo_rows:
      000DE6                        618 	.ds 2
      000DE8                        619 _vial_unlock_combo_cols:
      000DE8                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00A7F8                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00A7F8 90 0D E4         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00A7FB E0               [24]  667 	movx	a,@dptr
      00A7FC 70 01            [24]  668 	jnz	00131$
      00A7FE 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00A7FF                        671 00131$:
      00A7FF 7F 00            [12]  672 	mov	r7,#0x00
      00A801                        673 00115$:
      00A801 BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00A804                        675 00184$:
      00A804 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00A806 EF               [12]  678 	mov	a,r7
      00A807 12 AD BC         [24]  679 	lcall	_ak820_outline_0119
      00A80A FE               [12]  680 	mov	r6,a
      00A80B EF               [12]  681 	mov	a,r7
      00A80C 12 AD B1         [24]  682 	lcall	_ak820_outline_0118
      00A80F 90 07 4F         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00A812 F0               [24]  684 	movx	@dptr,a
      00A813 8E 82            [24]  685 	mov	dpl, r6
      00A815 C0 07            [24]  686 	push	ar7
      00A817 12 57 16         [24]  687 	lcall	_matrix_is_on
      00A81A E5 82            [12]  688 	mov	a, dpl
      00A81C D0 07            [24]  689 	pop	ar7
      00A81E 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00A820 90 0C 1E         [24]  692 	mov	dptr,#_vial_unlock_holding
      00A823 E4               [12]  693 	clr	a
      00A824 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00A825 90 0D E5         [24]  696 	mov	dptr,#_vial_unlock_counter
      00A828 74 1E            [12]  697 	mov	a,#0x1e
      00A82A F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00A82B 22               [24]  700 	ret
      00A82C                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00A82C 0F               [12]  703 	inc	r7
      00A82D 80 D2            [24]  704 	sjmp	00115$
      00A82F                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00A82F 90 0C 1E         [24]  707 	mov	dptr,#_vial_unlock_holding
      00A832 E0               [24]  708 	movx	a,@dptr
      00A833 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00A835 90 0C 1E         [24]  711 	mov	dptr,#_vial_unlock_holding
      00A838 74 01            [12]  712 	mov	a,#0x01
      00A83A F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00A83B 12 46 EC         [24]  715 	lcall	_timer_read32
      00A83E 12 4D 00         [24]  716 	lcall	_ak820_outline_0052
      00A841 90 0C 1A         [24]  717 	mov	dptr,#_vial_unlock_timer
      00A844 12 8C 8D         [24]  718 	lcall	_ak820_outline_0007
      00A847                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00A847 90 0C 1A         [24]  721 	mov	dptr,#_vial_unlock_timer
      00A84A 12 4C EF         [24]  722 	lcall	_ak820_outline_0050
      00A84D 12 47 45         [24]  723 	lcall	_timer_elapsed32
      00A850 12 4D 00         [24]  724 	lcall	_ak820_outline_0052
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00A853 7B 1E            [12]  726 	mov	r3,#0x1e
      00A855                        727 00109$:
      00A855 EB               [12]  728 	mov	a,r3
      00A856 60 22            [24]  729 	jz	00111$
      00A858 C3               [12]  730 	clr	c
      00A859 EC               [12]  731 	mov	a,r4
      00A85A 94 64            [12]  732 	subb	a,#0x64
      00A85C ED               [12]  733 	mov	a,r5
      00A85D 94 00            [12]  734 	subb	a,#0x00
      00A85F EE               [12]  735 	mov	a,r6
      00A860 94 00            [12]  736 	subb	a,#0x00
      00A862 EF               [12]  737 	mov	a,r7
      00A863 94 00            [12]  738 	subb	a,#0x00
      00A865 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00A867 EC               [12]  741 	mov	a,r4
      00A868 24 9C            [12]  742 	add	a,#0x9c
      00A86A FC               [12]  743 	mov	r4,a
      00A86B ED               [12]  744 	mov	a,r5
      00A86C 34 FF            [12]  745 	addc	a,#0xff
      00A86E FD               [12]  746 	mov	r5,a
      00A86F EE               [12]  747 	mov	a,r6
      00A870 34 FF            [12]  748 	addc	a,#0xff
      00A872 FE               [12]  749 	mov	r6,a
      00A873 EF               [12]  750 	mov	a,r7
      00A874 34 FF            [12]  751 	addc	a,#0xff
      00A876 FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00A877 1B               [12]  754 	dec	r3
      00A878 80 DB            [24]  755 	sjmp	00109$
      00A87A                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00A87A 90 0D E5         [24]  758 	mov	dptr,#_vial_unlock_counter
      00A87D EB               [12]  759 	mov	a,r3
      00A87E F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00A87F EB               [12]  762 	mov	a,r3
      00A880 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00A882 90 0D E4         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00A885 E4               [12]  766 	clr	a
      00A886 F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00A887 90 0D E3         [24]  769 	mov	dptr,#_vial_unlocked
      00A88A 04               [12]  770 	inc	a
      00A88B F0               [24]  771 	movx	@dptr,a
      00A88C                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00A88C 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:117: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00A88D                        782 _vial_init:
                                    783 ;	quantum/vial.c:125: reload_combo();
                                    784 ;	quantum/vial.c:130: }
      00A88D 02 35 38         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_609'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00A890                        795 _vial_keycode_firewall:
      00A890 12 38 47         [24]  796 	lcall	_ak820_outline_0100
      00A893 90 0C 1F         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_609
      00A896 12 38 42         [24]  798 	lcall	_ak820_outline_0099
                                    799 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00A899 90 0C 1F         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_609
      00A89C 12 37 CD         [24]  801 	lcall	_ak820_outline_0009
      00A89F BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00A8A2 BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00A8A5 90 0D E3         [24]  804 	mov	dptr,#_vial_unlocked
      00A8A8 E0               [24]  805 	movx	a,@dptr
      00A8A9 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:134: return 0;
      00A8AB 90 00 00         [24]  808 	mov	dptr,#0x0000
      00A8AE 22               [24]  809 	ret
      00A8AF                        810 00102$:
                                    811 ;	quantum/vial.c:135: return in;
      00A8AF 12 43 1A         [24]  812 	lcall	_ak820_outline_0111
                                    813 ;	quantum/vial.c:136: }
      00A8B2 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_612'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_614'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00A8B3                        826 _vial_fill_packet:
      00A8B3 12 38 47         [24]  827 	lcall	_ak820_outline_0100
      00A8B6 90 0C 22         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_612
      00A8B9 12 38 42         [24]  829 	lcall	_ak820_outline_0099
                                    830 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00A8BC 90 0C 22         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_612
      00A8BF 12 37 F9         [24]  832 	lcall	_ak820_outline_0047
      00A8C2 90 0C 21         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00A8C5 E0               [24]  834 	movx	a,@dptr
      00A8C6 FD               [12]  835 	mov	r5,a
      00A8C7 7C 00            [12]  836 	mov	r4,#0x00
      00A8C9                        837 00103$:
      00A8C9 BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00A8CC                        839 00122$:
      00A8CC 50 09            [24]  840 	jnc	00105$
      00A8CE EC               [12]  841 	mov	a,r4
      00A8CF 12 37 E9         [24]  842 	lcall	_ak820_outline_0018
      00A8D2 ED               [12]  843 	mov	a,r5
      00A8D3 F0               [24]  844 	movx	@dptr,a
      00A8D4 0C               [12]  845 	inc	r4
      00A8D5 80 F2            [24]  846 	sjmp	00103$
      00A8D7                        847 00105$:
                                    848 ;	quantum/vial.c:141: }
      00A8D7 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00A8D8                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:174: repeat_key_cancel();
      00A8D8 12 9C CB         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:176: clear_keyboard();
                                    861 ;	quantum/vial.c:177: }
      00A8DB 02 73 44         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_617'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_618'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_623'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_624'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_627'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_629'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_629'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_629'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_630'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_631'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_631'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_631'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_634'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_645'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_645'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00A8DE                        893 _vial_handle_cmd:
      00A8DE 12 42 D2         [24]  894 	lcall	_ak820_outline_0034
      00A8E1 90 0C 25         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_617
      00A8E4 12 37 E1         [24]  896 	lcall	_ak820_outline_0014
                                    897 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00A8E7 90 0C 25         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_617
      00A8EA 12 37 F9         [24]  899 	lcall	_ak820_outline_0047
                                    900 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00A8ED 90 0C 24         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00A8F0 E0               [24]  902 	movx	a,@dptr
      00A8F1 FD               [12]  903 	mov	r5,a
      00A8F2 BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00A8F5 80 01            [24]  905 	sjmp	00102$
      00A8F7                        906 00258$:
                                    907 ;	quantum/vial.c:190: return;
      00A8F7 22               [24]  908 	ret
      00A8F8                        909 00102$:
                                    910 ;	quantum/vial.c:193: switch (msg[1]) {
      00A8F8 74 01            [12]  911 	mov	a,#0x01
      00A8FA 12 46 41         [24]  912 	lcall	_ak820_outline_0010
      00A8FD FB               [12]  913 	mov  r3,a
      00A8FE 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00A900 50 01            [24]  915 	jnc	00259$
      00A902 22               [24]  916 	ret
      00A903                        917 00259$:
                                    918 ;	free result
      00A903 EB               [12]  919 	mov	a,r3
      00A904 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00A906 83               [24]  921 	movc	a,@a+pc
      00A907 F5 82            [12]  922 	mov	dpl,a
      00A909 EB               [12]  923 	mov	a,r3
      00A90A 24 12            [12]  924 	add	a,#(00261$-3-.)
      00A90C 83               [24]  925 	movc	a,@a+pc
      00A90D F5 83            [12]  926 	mov	dph,a
      00A90F E4               [12]  927 	clr	a
      00A910 73               [24]  928 	jmp	@a+dptr
      00A911                        929 00260$:
      00A911 2D                     930 	.db	00103$
      00A912 75                     931 	.db	00105$
      00A913 8A                     932 	.db	00106$
      00A914 16                     933 	.db	00112$
      00A915 9C                     934 	.db	00113$
      00A916 E8                     935 	.db	00114$
      00A917 57                     936 	.db	00116$
      00A918 72                     937 	.db	00119$
      00A919 92                     938 	.db	00120$
      00A91A A0                     939 	.db	00121$
      00A91B AC                     940 	.db	00139$
      00A91C AC                     941 	.db	00139$
      00A91D AC                     942 	.db	00139$
      00A91E AB                     943 	.db	00122$
      00A91F                        944 00261$:
      00A91F A9                     945 	.db	00103$>>8
      00A920 A9                     946 	.db	00105$>>8
      00A921 A9                     947 	.db	00106$>>8
      00A922 AA                     948 	.db	00112$>>8
      00A923 AA                     949 	.db	00113$>>8
      00A924 AA                     950 	.db	00114$>>8
      00A925 AB                     951 	.db	00116$>>8
      00A926 AB                     952 	.db	00119$>>8
      00A927 AB                     953 	.db	00120$>>8
      00A928 AB                     954 	.db	00121$>>8
      00A929 AC                     955 	.db	00139$>>8
      00A92A AC                     956 	.db	00139$>>8
      00A92B AC                     957 	.db	00139$>>8
      00A92C AB                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00A92D                        960 00103$:
                                    961 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00A92D 90 0C 21         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00A930 E4               [12]  963 	clr	a
      00A931 12 42 F6         [24]  964 	lcall	_ak820_outline_0057
      00A934 C0 07            [24]  965 	push	ar7
      00A936 C0 06            [24]  966 	push	ar6
      00A938 12 A8 B3         [24]  967 	lcall	_vial_fill_packet
      00A93B D0 06            [24]  968 	pop	ar6
      00A93D D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00A93F 12 43 1A         [24]  971 	lcall	_ak820_outline_0111
      00A942 74 06            [12]  972 	mov	a,#0x06
      00A944 12 42 F6         [24]  973 	lcall	_ak820_outline_0057
                                    974 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00A947 A3               [24]  975 	inc	dptr
      00A948 E4               [12]  976 	clr	a
      00A949 12 42 CA         [24]  977 	lcall	_ak820_outline_0028
                                    978 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00A94C 12 42 CA         [24]  979 	lcall	_ak820_outline_0028
                                    980 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00A94F A3               [24]  981 	inc	dptr
      00A950 F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00A951 FB               [12]  984 	mov	r3,a
      00A952                        985 00131$:
      00A952 BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00A955                        987 00262$:
      00A955 50 15            [24]  988 	jnc	00104$
      00A957 8B 02            [24]  989 	mov	ar2,r3
      00A959 74 04            [12]  990 	mov	a,#0x04
      00A95B 2A               [12]  991 	add	a, r2
      00A95C 2E               [12]  992 	add	a, r6
      00A95D F9               [12]  993 	mov	r1,a
      00A95E E4               [12]  994 	clr	a
      00A95F 3F               [12]  995 	addc	a,r7
      00A960 FA               [12]  996 	mov	r2,a
      00A961 EB               [12]  997 	mov	a,r3
      00A962 90 BA 66         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_622
      00A965 93               [24]  999 	movc	a,@a+dptr
      00A966 12 6A 07         [24] 1000 	lcall	_ak820_outline_0129
      00A969 0B               [12] 1001 	inc	r3
      00A96A 80 E6            [24] 1002 	sjmp	00131$
      00A96C                       1003 00104$:
                                   1004 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00A96C 74 0C            [12] 1005 	mov	a,#0x0c
      00A96E 12 37 E9         [24] 1006 	lcall	_ak820_outline_0018
      00A971 74 01            [12] 1007 	mov	a,#0x01
      00A973 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:207: break;
      00A974 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:210: case vial_get_size: {
      00A975                       1012 00105$:
                                   1013 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00A975 12 43 1A         [24] 1014 	lcall	_ak820_outline_0111
      00A978 74 7C            [12] 1015 	mov	a,#0x7c
      00A97A F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00A97B 12 38 53         [24] 1018 	lcall	_ak820_outline_0112
      00A97E 74 01            [12] 1019 	mov	a,#0x01
      00A980 12 42 CA         [24] 1020 	lcall	_ak820_outline_0028
                                   1021 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00A983 E4               [12] 1022 	clr	a
      00A984 12 42 CA         [24] 1023 	lcall	_ak820_outline_0028
                                   1024 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00A987 A3               [24] 1025 	inc	dptr
      00A988 F0               [24] 1026 	movx	@dptr,a
                                   1027 ;	quantum/vial.c:216: break;
      00A989 22               [24] 1028 	ret
                                   1029 ;	quantum/vial.c:219: case vial_get_def: {
      00A98A                       1030 00106$:
                                   1031 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00A98A 12 A7 BC         [24] 1032 	lcall	_ak820_outline_0019
      00A98D E0               [24] 1033 	movx	a,@dptr
      00A98E FB               [12] 1034 	mov	r3,a
      00A98F 12 42 C0         [24] 1035 	lcall	_ak820_outline_0011
      00A992 E0               [24] 1036 	movx	a,@dptr
      00A993 4B               [12] 1037 	orl	a,r3
      00A994 60 01            [24] 1038 	jz	00108$
      00A996 22               [24] 1039 	ret
      00A997                       1040 00108$:
                                   1041 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00A997 12 37 F1         [24] 1042 	lcall	_ak820_outline_0031
      00A99A FB               [12] 1043 	mov	r3,a
      00A99B 7A 00            [12] 1044 	mov	r2,#0x00
      00A99D 12 A7 B3         [24] 1045 	lcall	_ak820_outline_0013
      00A9A0 F9               [12] 1046 	mov	r1,a
      00A9A1 E4               [12] 1047 	clr	a
      00A9A2 42 03            [12] 1048 	orl	ar3,a
      00A9A4 E9               [12] 1049 	mov	a,r1
      00A9A5 42 02            [12] 1050 	orl	ar2,a
                                   1051 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00A9A7 C3               [12] 1052 	clr	c
      00A9A8 EB               [12] 1053 	mov	a,r3
      00A9A9 94 0C            [12] 1054 	subb	a,#0x0c
      00A9AB EA               [12] 1055 	mov	a,r2
      00A9AC 94 00            [12] 1056 	subb	a,#0x00
      00A9AE 40 01            [24] 1057 	jc	00110$
      00A9B0 22               [24] 1058 	ret
      00A9B1                       1059 00110$:
                                   1060 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00A9B1 EA               [12] 1061 	mov	a,r2
      00A9B2 C4               [12] 1062 	swap	a
      00A9B3 23               [12] 1063 	rl	a
      00A9B4 54 E0            [12] 1064 	anl	a,#0xe0
      00A9B6 CB               [12] 1065 	xch	a,r3
      00A9B7 C4               [12] 1066 	swap	a
      00A9B8 23               [12] 1067 	rl	a
      00A9B9 CB               [12] 1068 	xch	a,r3
      00A9BA 6B               [12] 1069 	xrl	a,r3
      00A9BB CB               [12] 1070 	xch	a,r3
      00A9BC 54 E0            [12] 1071 	anl	a,#0xe0
      00A9BE CB               [12] 1072 	xch	a,r3
      00A9BF 6B               [12] 1073 	xrl	a,r3
      00A9C0 FA               [12] 1074 	mov	r2,a
      00A9C1 8B 45            [24] 1075 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00A9C3 8A 46            [24] 1076 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1077 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00A9C5 74 7C            [12] 1078 	mov	a,#0x7c
      00A9C7 C3               [12] 1079 	clr	c
      00A9C8 95 45            [12] 1080 	subb	a,_vial_handle_cmd_sloc0_1_0
      00A9CA F8               [12] 1081 	mov	r0,a
      00A9CB 74 01            [12] 1082 	mov	a,#0x01
      00A9CD 95 46            [12] 1083 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00A9CF F9               [12] 1084 	mov	r1,a
                                   1085 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00A9D0 C3               [12] 1086 	clr	c
      00A9D1 E8               [12] 1087 	mov	a,r0
      00A9D2 94 20            [12] 1088 	subb	a,#0x20
      00A9D4 E9               [12] 1089 	mov	a,r1
      00A9D5 94 00            [12] 1090 	subb	a,#0x00
      00A9D7 40 02            [24] 1091 	jc	00142$
      00A9D9 78 20            [12] 1092 	mov	r0,#0x20
      00A9DB                       1093 00142$:
                                   1094 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00A9DB 79 00            [12] 1095 	mov	r1,#0x00
      00A9DD                       1096 00134$:
      00A9DD C3               [12] 1097 	clr	c
      00A9DE E9               [12] 1098 	mov	a,r1
      00A9DF 98               [12] 1099 	subb	a,r0
      00A9E0 40 01            [24] 1100 	jc	00267$
      00A9E2 22               [24] 1101 	ret
      00A9E3                       1102 00267$:
      00A9E3 C0 00            [24] 1103 	push	ar0
      00A9E5 E9               [12] 1104 	mov	a,r1
      00A9E6 2E               [12] 1105 	add	a, r6
      00A9E7 F5 47            [12] 1106 	mov	_vial_handle_cmd_sloc1_1_0,a
      00A9E9 E4               [12] 1107 	clr	a
      00A9EA 3F               [12] 1108 	addc	a, r7
      00A9EB F5 48            [12] 1109 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00A9ED 89 49            [24] 1110 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00A9EF 75 4A 00         [24] 1111 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00A9F2 A8 45            [24] 1112 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00A9F4 AB 46            [24] 1113 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00A9F6 E5 49            [12] 1114 	mov	a,_vial_handle_cmd_sloc2_1_0
      00A9F8 28               [12] 1115 	add	a, r0
      00A9F9 F8               [12] 1116 	mov	r0,a
      00A9FA E5 4A            [12] 1117 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00A9FC 3B               [12] 1118 	addc	a, r3
      00A9FD FB               [12] 1119 	mov	r3,a
      00A9FE E8               [12] 1120 	mov	a,r0
      00A9FF 24 EA            [12] 1121 	add	a, #_keyboard_definition
      00AA01 F5 82            [12] 1122 	mov	dpl,a
      00AA03 EB               [12] 1123 	mov	a,r3
      00AA04 34 B8            [12] 1124 	addc	a, #(_keyboard_definition >> 8)
      00AA06 F5 83            [12] 1125 	mov	dph,a
      00AA08 E4               [12] 1126 	clr	a
      00AA09 93               [24] 1127 	movc	a,@a+dptr
      00AA0A 85 47 82         [24] 1128 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AA0D 85 48 83         [24] 1129 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AA10 F0               [24] 1130 	movx	@dptr,a
      00AA11 09               [12] 1131 	inc	r1
      00AA12 D0 00            [24] 1132 	pop	ar0
                                   1133 ;	quantum/vial.c:246: case vial_get_encoder: {
      00AA14 80 C7            [24] 1134 	sjmp	00134$
      00AA16                       1135 00112$:
                                   1136 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00AA16 74 02            [12] 1137 	mov	a,#0x02
      00AA18 12 46 71         [24] 1138 	lcall	_ak820_outline_0043
      00AA1B F5 49            [12] 1139 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1140 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00AA1D 74 03            [12] 1141 	mov	a,#0x03
      00AA1F 2E               [12] 1142 	add	a, r6
      00AA20 F5 47            [12] 1143 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AA22 E4               [12] 1144 	clr	a
      00AA23 3F               [12] 1145 	addc	a, r7
      00AA24 F5 48            [12] 1146 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00AA26 85 47 82         [24] 1147 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AA29 85 48 83         [24] 1148 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AA2C E0               [24] 1149 	movx	a,@dptr
                                   1150 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00AA2D F5 45            [12] 1151 	mov	_vial_handle_cmd_sloc0_1_0,a
      00AA2F 90 0A CF         [24] 1152 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00AA32 F0               [24] 1153 	movx	@dptr,a
      00AA33 90 0A D0         [24] 1154 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AA36 E4               [12] 1155 	clr	a
      00AA37 F0               [24] 1156 	movx	@dptr,a
      00AA38 85 49 82         [24] 1157 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AA3B C0 07            [24] 1158 	push	ar7
      00AA3D C0 06            [24] 1159 	push	ar6
      00AA3F C0 05            [24] 1160 	push	ar5
      00AA41 C0 04            [24] 1161 	push	ar4
      00AA43 C0 03            [24] 1162 	push	ar3
      00AA45 C0 02            [24] 1163 	push	ar2
      00AA47 12 81 10         [24] 1164 	lcall	_dynamic_keymap_get_encoder
      00AA4A 85 82 4B         [24] 1165 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AA4D 85 83 4C         [24] 1166 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AA50 D0 02            [24] 1167 	pop	ar2
      00AA52 D0 03            [24] 1168 	pop	ar3
      00AA54 D0 04            [24] 1169 	pop	ar4
      00AA56 D0 05            [24] 1170 	pop	ar5
      00AA58 D0 06            [24] 1171 	pop	ar6
      00AA5A D0 07            [24] 1172 	pop	ar7
                                   1173 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00AA5C A9 4C            [24] 1174 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AA5E 12 43 1A         [24] 1175 	lcall	_ak820_outline_0111
      00AA61 E9               [12] 1176 	mov	a,r1
      00AA62 F0               [24] 1177 	movx	@dptr,a
                                   1178 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00AA63 A8 4B            [24] 1179 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AA65 12 38 53         [24] 1180 	lcall	_ak820_outline_0112
      00AA68 E8               [12] 1181 	mov	a,r0
      00AA69 F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00AA6A 90 0A CF         [24] 1184 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00AA6D E5 45            [12] 1185 	mov	a,_vial_handle_cmd_sloc0_1_0
      00AA6F F0               [24] 1186 	movx	@dptr,a
      00AA70 90 0A D0         [24] 1187 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AA73 74 01            [12] 1188 	mov	a,#0x01
      00AA75 F0               [24] 1189 	movx	@dptr,a
      00AA76 85 49 82         [24] 1190 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AA79 C0 03            [24] 1191 	push	ar3
      00AA7B C0 02            [24] 1192 	push	ar2
      00AA7D 12 81 10         [24] 1193 	lcall	_dynamic_keymap_get_encoder
      00AA80 85 82 4B         [24] 1194 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AA83 85 83 4C         [24] 1195 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AA86 D0 02            [24] 1196 	pop	ar2
      00AA88 D0 03            [24] 1197 	pop	ar3
                                   1198 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00AA8A A9 4C            [24] 1199 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AA8C 12 43 30         [24] 1200 	lcall	_ak820_outline_0134
      00AA8F E9               [12] 1201 	mov	a,r1
      00AA90 F0               [24] 1202 	movx	@dptr,a
                                   1203 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00AA91 A8 4B            [24] 1204 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AA93 85 47 82         [24] 1205 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AA96 85 48 83         [24] 1206 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AA99 E8               [12] 1207 	mov	a,r0
      00AA9A F0               [24] 1208 	movx	@dptr,a
                                   1209 ;	quantum/vial.c:255: break;
      00AA9B 22               [24] 1210 	ret
                                   1211 ;	quantum/vial.c:257: case vial_set_encoder: {
      00AA9C                       1212 00113$:
                                   1213 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00AA9C 12 37 F1         [24] 1214 	lcall	_ak820_outline_0031
      00AA9F F5 47            [12] 1215 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AAA1 12 A7 B3         [24] 1216 	lcall	_ak820_outline_0013
      00AAA4 F5 49            [12] 1217 	mov	_vial_handle_cmd_sloc2_1_0,a
      00AAA6 12 A7 BC         [24] 1218 	lcall	_ak820_outline_0019
      00AAA9 E0               [24] 1219 	movx	a,@dptr
                                   1220 ;	assignBit
      00AAAA 24 FF            [12] 1221 	add	a,#0xff
      00AAAC E4               [12] 1222 	clr	a
      00AAAD 33               [12] 1223 	rlc	a
      00AAAE F5 4B            [12] 1224 	mov	_vial_handle_cmd_sloc3_1_0,a
      00AAB0 12 42 C0         [24] 1225 	lcall	_ak820_outline_0011
      00AAB3 E0               [24] 1226 	movx	a,@dptr
      00AAB4 F9               [12] 1227 	mov	r1,a
      00AAB5 78 00            [12] 1228 	mov	r0,#0x00
      00AAB7 74 06            [12] 1229 	mov	a,#0x06
      00AAB9 12 37 E9         [24] 1230 	lcall	_ak820_outline_0018
      00AABC E0               [24] 1231 	movx	a,@dptr
      00AABD 7B 00            [12] 1232 	mov	r3,#0x00
      00AABF 42 00            [12] 1233 	orl	ar0,a
      00AAC1 EB               [12] 1234 	mov	a,r3
      00AAC2 42 01            [12] 1235 	orl	ar1,a
      00AAC4 12 38 6E         [24] 1236 	lcall	_ak820_outline_0145
      00AAC7 12 A8 90         [24] 1237 	lcall	_vial_keycode_firewall
      00AACA AA 82            [24] 1238 	mov	r2, dpl
      00AACC AB 83            [24] 1239 	mov	r3, dph
      00AACE 90 0A D2         [24] 1240 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00AAD1 E5 49            [12] 1241 	mov	a,_vial_handle_cmd_sloc2_1_0
      00AAD3 F0               [24] 1242 	movx	@dptr,a
      00AAD4 90 0A D3         [24] 1243 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00AAD7 E5 4B            [12] 1244 	mov	a,_vial_handle_cmd_sloc3_1_0
      00AAD9 F0               [24] 1245 	movx	@dptr,a
      00AADA 90 0A D4         [24] 1246 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00AADD EA               [12] 1247 	mov	a,r2
      00AADE F0               [24] 1248 	movx	@dptr,a
      00AADF EB               [12] 1249 	mov	a,r3
      00AAE0 A3               [24] 1250 	inc	dptr
      00AAE1 F0               [24] 1251 	movx	@dptr,a
      00AAE2 85 47 82         [24] 1252 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1253 ;	quantum/vial.c:259: break;
      00AAE5 02 81 78         [24] 1254 	ljmp	_dynamic_keymap_set_encoder
                                   1255 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00AAE8                       1256 00114$:
                                   1257 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00AAE8 90 0C 21         [24] 1258 	mov	dptr,#_vial_fill_packet_PARM_2
      00AAEB 74 FF            [12] 1259 	mov	a,#0xff
      00AAED 12 42 F6         [24] 1260 	lcall	_ak820_outline_0057
      00AAF0 C0 07            [24] 1261 	push	ar7
      00AAF2 C0 06            [24] 1262 	push	ar6
      00AAF4 12 A8 B3         [24] 1263 	lcall	_vial_fill_packet
      00AAF7 D0 06            [24] 1264 	pop	ar6
      00AAF9 D0 07            [24] 1265 	pop	ar7
                                   1266 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00AAFB 90 0D E3         [24] 1267 	mov	dptr,#_vial_unlocked
      00AAFE E0               [24] 1268 	movx	a,@dptr
      00AAFF 12 43 1A         [24] 1269 	lcall	_ak820_outline_0111
      00AB02 F0               [24] 1270 	movx	@dptr,a
                                   1271 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00AB03 74 01            [12] 1272 	mov	a,#0x01
      00AB05 2E               [12] 1273 	add	a, r6
      00AB06 FA               [12] 1274 	mov	r2,a
      00AB07 E4               [12] 1275 	clr	a
      00AB08 3F               [12] 1276 	addc	a, r7
      00AB09 FB               [12] 1277 	mov	r3,a
      00AB0A 90 0D E4         [24] 1278 	mov	dptr,#_vial_unlock_in_progress
      00AB0D E0               [24] 1279 	movx	a,@dptr
      00AB0E 12 43 30         [24] 1280 	lcall	_ak820_outline_0134
      00AB11 F0               [24] 1281 	movx	@dptr,a
                                   1282 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AB12 7B 00            [12] 1283 	mov	r3,#0x00
      00AB14                       1284 00137$:
      00AB14 BB 02 00         [24] 1285 	cjne	r3,#0x02,00268$
      00AB17                       1286 00268$:
      00AB17 40 01            [24] 1287 	jc	00269$
      00AB19 22               [24] 1288 	ret
      00AB1A                       1289 00269$:
                                   1290 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00AB1A 8B 01            [24] 1291 	mov	ar1,r3
      00AB1C 7A 00            [12] 1292 	mov	r2,#0x00
      00AB1E E9               [12] 1293 	mov	a,r1
      00AB1F 29               [12] 1294 	add	a,r1
      00AB20 F5 4B            [12] 1295 	mov	_vial_handle_cmd_sloc3_1_0,a
      00AB22 EA               [12] 1296 	mov	a,r2
      00AB23 33               [12] 1297 	rlc	a
      00AB24 F5 4C            [12] 1298 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00AB26 74 02            [12] 1299 	mov	a,#0x02
      00AB28 25 4B            [12] 1300 	add	a, _vial_handle_cmd_sloc3_1_0
      00AB2A F8               [12] 1301 	mov	r0,a
      00AB2B E4               [12] 1302 	clr	a
      00AB2C 35 4C            [12] 1303 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00AB2E FA               [12] 1304 	mov	r2,a
      00AB2F E8               [12] 1305 	mov	a,r0
      00AB30 2E               [12] 1306 	add	a, r6
      00AB31 F8               [12] 1307 	mov	r0,a
      00AB32 EA               [12] 1308 	mov	a,r2
      00AB33 3F               [12] 1309 	addc	a, r7
      00AB34 FA               [12] 1310 	mov	r2,a
      00AB35 EB               [12] 1311 	mov	a,r3
      00AB36 12 AD BC         [24] 1312 	lcall	_ak820_outline_0119
      00AB39 88 82            [24] 1313 	mov	dpl,r0
      00AB3B 8A 83            [24] 1314 	mov	dph,r2
      00AB3D F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00AB3E 74 03            [12] 1317 	mov	a,#0x03
      00AB40 25 4B            [12] 1318 	add	a, _vial_handle_cmd_sloc3_1_0
      00AB42 F9               [12] 1319 	mov	r1,a
      00AB43 E4               [12] 1320 	clr	a
      00AB44 35 4C            [12] 1321 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00AB46 FA               [12] 1322 	mov	r2,a
      00AB47 E9               [12] 1323 	mov	a,r1
      00AB48 2E               [12] 1324 	add	a, r6
      00AB49 F9               [12] 1325 	mov	r1,a
      00AB4A EA               [12] 1326 	mov	a,r2
      00AB4B 3F               [12] 1327 	addc	a, r7
      00AB4C FA               [12] 1328 	mov	r2,a
      00AB4D EB               [12] 1329 	mov	a,r3
      00AB4E 12 AD B1         [24] 1330 	lcall	_ak820_outline_0118
      00AB51 12 6A 07         [24] 1331 	lcall	_ak820_outline_0129
                                   1332 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AB54 0B               [12] 1333 	inc	r3
                                   1334 ;	quantum/vial.c:278: case vial_unlock_start: {
      00AB55 80 BD            [24] 1335 	sjmp	00137$
      00AB57                       1336 00116$:
                                   1337 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00AB57 90 0D E4         [24] 1338 	mov	dptr,#_vial_unlock_in_progress
      00AB5A E0               [24] 1339 	movx	a,@dptr
      00AB5B 70 03            [24] 1340 	jnz	00118$
      00AB5D 12 A8 D8         [24] 1341 	lcall	_vial_release_held_state
      00AB60                       1342 00118$:
                                   1343 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00AB60 90 0D E4         [24] 1344 	mov	dptr,#_vial_unlock_in_progress
      00AB63 74 01            [12] 1345 	mov	a,#0x01
      00AB65 F0               [24] 1346 	movx	@dptr,a
                                   1347 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AB66 90 0D E5         [24] 1348 	mov	dptr,#_vial_unlock_counter
      00AB69 74 1E            [12] 1349 	mov	a,#0x1e
      00AB6B F0               [24] 1350 	movx	@dptr,a
                                   1351 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00AB6C 90 0C 1E         [24] 1352 	mov	dptr,#_vial_unlock_holding
      00AB6F E4               [12] 1353 	clr	a
      00AB70 F0               [24] 1354 	movx	@dptr,a
                                   1355 ;	quantum/vial.c:287: break;
      00AB71 22               [24] 1356 	ret
                                   1357 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00AB72                       1358 00119$:
                                   1359 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00AB72 90 0D E3         [24] 1360 	mov	dptr,#_vial_unlocked
      00AB75 E0               [24] 1361 	movx	a,@dptr
      00AB76 12 43 1A         [24] 1362 	lcall	_ak820_outline_0111
      00AB79 F0               [24] 1363 	movx	@dptr,a
                                   1364 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00AB7A 90 0D E4         [24] 1365 	mov	dptr,#_vial_unlock_in_progress
      00AB7D E0               [24] 1366 	movx	a,@dptr
      00AB7E 12 38 53         [24] 1367 	lcall	_ak820_outline_0112
      00AB81 F0               [24] 1368 	movx	@dptr,a
                                   1369 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00AB82 74 02            [12] 1370 	mov	a,#0x02
      00AB84 2E               [12] 1371 	add	a, r6
      00AB85 FA               [12] 1372 	mov	r2,a
      00AB86 E4               [12] 1373 	clr	a
      00AB87 3F               [12] 1374 	addc	a, r7
      00AB88 FB               [12] 1375 	mov	r3,a
      00AB89 90 0D E5         [24] 1376 	mov	dptr,#_vial_unlock_counter
      00AB8C E0               [24] 1377 	movx	a,@dptr
      00AB8D 12 43 30         [24] 1378 	lcall	_ak820_outline_0134
      00AB90 F0               [24] 1379 	movx	@dptr,a
                                   1380 ;	quantum/vial.c:293: break;
      00AB91 22               [24] 1381 	ret
                                   1382 ;	quantum/vial.c:295: case vial_lock: {
      00AB92                       1383 00120$:
                                   1384 ;	quantum/vial.c:297: vial_unlocked = 0;
      00AB92 90 0D E3         [24] 1385 	mov	dptr,#_vial_unlocked
      00AB95 E4               [12] 1386 	clr	a
      00AB96 F0               [24] 1387 	movx	@dptr,a
                                   1388 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00AB97 90 0D E4         [24] 1389 	mov	dptr,#_vial_unlock_in_progress
      00AB9A F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00AB9B 90 0C 1E         [24] 1392 	mov	dptr,#_vial_unlock_holding
      00AB9E F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	quantum/vial.c:301: break;
      00AB9F 22               [24] 1395 	ret
                                   1396 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00ABA0                       1397 00121$:
                                   1398 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00ABA0 90 0C 21         [24] 1399 	mov	dptr,#_vial_fill_packet_PARM_2
      00ABA3 74 FF            [12] 1400 	mov	a,#0xff
      00ABA5 12 42 F6         [24] 1401 	lcall	_ak820_outline_0057
                                   1402 ;	quantum/vial.c:314: break;
      00ABA8 02 A8 B3         [24] 1403 	ljmp	_vial_fill_packet
                                   1404 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00ABAB                       1405 00122$:
                                   1406 ;	quantum/vial.c:347: switch (msg[2]) {
      00ABAB 12 37 F1         [24] 1407 	lcall	_ak820_outline_0031
      00ABAE FB               [12] 1408 	mov	r3,a
      00ABAF 60 0C            [24] 1409 	jz	00123$
      00ABB1 BB 03 02         [24] 1410 	cjne	r3,#0x03,00272$
      00ABB4 80 31            [24] 1411 	sjmp	00124$
      00ABB6                       1412 00272$:
      00ABB6 BB 04 03         [24] 1413 	cjne	r3,#0x04,00273$
      00ABB9 02 AC 4B         [24] 1414 	ljmp	00125$
      00ABBC                       1415 00273$:
      00ABBC 22               [24] 1416 	ret
                                   1417 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00ABBD                       1418 00123$:
                                   1419 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00ABBD 90 0C 21         [24] 1420 	mov	dptr,#_vial_fill_packet_PARM_2
      00ABC0 E4               [12] 1421 	clr	a
      00ABC1 12 42 F6         [24] 1422 	lcall	_ak820_outline_0057
      00ABC4 C0 07            [24] 1423 	push	ar7
      00ABC6 C0 06            [24] 1424 	push	ar6
      00ABC8 12 A8 B3         [24] 1425 	lcall	_vial_fill_packet
      00ABCB D0 06            [24] 1426 	pop	ar6
      00ABCD D0 07            [24] 1427 	pop	ar7
                                   1428 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00ABCF 12 43 1A         [24] 1429 	lcall	_ak820_outline_0111
      00ABD2 E4               [12] 1430 	clr	a
      00ABD3 12 42 F6         [24] 1431 	lcall	_ak820_outline_0057
                                   1432 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00ABD6 A3               [24] 1433 	inc	dptr
      00ABD7 74 08            [12] 1434 	mov	a,#0x08
      00ABD9 12 42 CA         [24] 1435 	lcall	_ak820_outline_0028
                                   1436 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00ABDC E4               [12] 1437 	clr	a
      00ABDD F0               [24] 1438 	movx	@dptr,a
                                   1439 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00ABDE 74 1F            [12] 1440 	mov	a,#0x1f
      00ABE0 12 37 E9         [24] 1441 	lcall	_ak820_outline_0018
      00ABE3 74 01            [12] 1442 	mov	a,#0x01
      00ABE5 F0               [24] 1443 	movx	@dptr,a
                                   1444 ;	quantum/vial.c:356: break;
      00ABE6 22               [24] 1445 	ret
                                   1446 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00ABE7                       1447 00124$:
                                   1448 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00ABE7 12 A7 B3         [24] 1449 	lcall	_ak820_outline_0013
      00ABEA FB               [12] 1450 	mov	r3,a
                                   1451 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00ABEB 90 0C 28         [24] 1452 	mov	dptr,#_vial_handle_cmd_entry_70000_645
      00ABEE 12 4D 21         [24] 1453 	lcall	_ak820_outline_0159
      00ABF1 90 0C 2A         [24] 1454 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0002)
      00ABF4 F0               [24] 1455 	movx	@dptr,a
      00ABF5 A3               [24] 1456 	inc	dptr
      00ABF6 F0               [24] 1457 	movx	@dptr,a
      00ABF7 90 0C 2C         [24] 1458 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0004)
      00ABFA F0               [24] 1459 	movx	@dptr,a
      00ABFB A3               [24] 1460 	inc	dptr
      00ABFC F0               [24] 1461 	movx	@dptr,a
      00ABFD 90 0C 2E         [24] 1462 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0006)
      00AC00 F0               [24] 1463 	movx	@dptr,a
      00AC01 A3               [24] 1464 	inc	dptr
      00AC02 F0               [24] 1465 	movx	@dptr,a
      00AC03 90 0C 30         [24] 1466 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0008)
      00AC06 F0               [24] 1467 	movx	@dptr,a
      00AC07 A3               [24] 1468 	inc	dptr
      00AC08 F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00AC09 90 0A D7         [24] 1471 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00AC0C 74 28            [12] 1472 	mov	a,#_vial_handle_cmd_entry_70000_645
      00AC0E F0               [24] 1473 	movx	@dptr,a
      00AC0F 74 0C            [12] 1474 	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
      00AC11 12 38 1E         [24] 1475 	lcall	_ak820_outline_0067
      00AC14 8B 82            [24] 1476 	mov	dpl, r3
      00AC16 C0 07            [24] 1477 	push	ar7
      00AC18 C0 06            [24] 1478 	push	ar6
      00AC1A C0 05            [24] 1479 	push	ar5
      00AC1C C0 04            [24] 1480 	push	ar4
      00AC1E 12 81 E5         [24] 1481 	lcall	_dynamic_keymap_get_combo
      00AC21 AA 82            [24] 1482 	mov	r2, dpl
      00AC23 D0 04            [24] 1483 	pop	ar4
      00AC25 D0 05            [24] 1484 	pop	ar5
      00AC27 D0 06            [24] 1485 	pop	ar6
      00AC29 D0 07            [24] 1486 	pop	ar7
      00AC2B 12 43 1A         [24] 1487 	lcall	_ak820_outline_0111
      00AC2E EA               [12] 1488 	mov	a,r2
      00AC2F F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00AC30 7B 00            [12] 1491 	mov	r3,#0x00
      00AC32 90 0D 64         [24] 1492 	mov	dptr,#___memcpy_PARM_2
      00AC35 74 28            [12] 1493 	mov	a,#_vial_handle_cmd_entry_70000_645
      00AC37 F0               [24] 1494 	movx	@dptr,a
      00AC38 74 0C            [12] 1495 	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
      00AC3A 12 38 1E         [24] 1496 	lcall	_ak820_outline_0067
      00AC3D 90 0D 67         [24] 1497 	mov	dptr,#___memcpy_PARM_3
      00AC40 12 8A BF         [24] 1498 	lcall	_ak820_outline_0085
      00AC43 12 38 53         [24] 1499 	lcall	_ak820_outline_0112
      00AC46 8B F0            [24] 1500 	mov	b, r3
                                   1501 ;	quantum/vial.c:387: break;
      00AC48 02 B3 6C         [24] 1502 	ljmp	___memcpy
                                   1503 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00AC4B                       1504 00125$:
                                   1505 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00AC4B 12 A7 B3         [24] 1506 	lcall	_ak820_outline_0013
      00AC4E FD               [12] 1507 	mov	r5,a
                                   1508 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00AC4F 74 04            [12] 1509 	mov	a,#0x04
      00AC51 2E               [12] 1510 	add	a, r6
      00AC52 FB               [12] 1511 	mov	r3,a
      00AC53 E4               [12] 1512 	clr	a
      00AC54 3F               [12] 1513 	addc	a, r7
      00AC55 FC               [12] 1514 	mov	r4,a
      00AC56 90 0D 64         [24] 1515 	mov	dptr,#___memcpy_PARM_2
      00AC59 EB               [12] 1516 	mov	a,r3
      00AC5A F0               [24] 1517 	movx	@dptr,a
      00AC5B EC               [12] 1518 	mov	a,r4
      00AC5C 12 38 1E         [24] 1519 	lcall	_ak820_outline_0067
      00AC5F 90 0D 67         [24] 1520 	mov	dptr,#___memcpy_PARM_3
      00AC62 12 8A BF         [24] 1521 	lcall	_ak820_outline_0085
      00AC65 90 0C 32         [24] 1522 	mov	dptr,#_vial_handle_cmd_entry_70000_646
      00AC68 F5 F0            [12] 1523 	mov	b,a
      00AC6A C0 07            [24] 1524 	push	ar7
      00AC6C C0 06            [24] 1525 	push	ar6
      00AC6E C0 05            [24] 1526 	push	ar5
      00AC70 12 B3 6C         [24] 1527 	lcall	___memcpy
                                   1528 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00AC73 90 0C 3A         [24] 1529 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00AC76 12 38 3C         [24] 1530 	lcall	_ak820_outline_0094
      00AC79 12 33 FC         [24] 1531 	lcall	_ak820_outline_0116
      00AC7C 12 A8 90         [24] 1532 	lcall	_vial_keycode_firewall
      00AC7F AB 82            [24] 1533 	mov	r3, dpl
      00AC81 AC 83            [24] 1534 	mov	r4, dph
      00AC83 D0 05            [24] 1535 	pop	ar5
      00AC85 90 0C 3A         [24] 1536 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00AC88 12 38 2A         [24] 1537 	lcall	_ak820_outline_0071
                                   1538 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00AC8B 90 0A DB         [24] 1539 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00AC8E 74 32            [12] 1540 	mov	a,#_vial_handle_cmd_entry_70000_646
      00AC90 F0               [24] 1541 	movx	@dptr,a
      00AC91 74 0C            [12] 1542 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00AC93 12 38 1E         [24] 1543 	lcall	_ak820_outline_0067
      00AC96 8D 82            [24] 1544 	mov	dpl, r5
      00AC98 12 82 89         [24] 1545 	lcall	_dynamic_keymap_set_combo
      00AC9B AC 82            [24] 1546 	mov	r4, dpl
      00AC9D D0 06            [24] 1547 	pop	ar6
      00AC9F D0 07            [24] 1548 	pop	ar7
      00ACA1 12 43 1A         [24] 1549 	lcall	_ak820_outline_0111
      00ACA4 EC               [12] 1550 	mov	a,r4
      00ACA5 F0               [24] 1551 	movx	@dptr,a
                                   1552 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00ACA6 EC               [12] 1553 	mov	a,r4
      00ACA7 70 03            [24] 1554 	jnz	00139$
                                   1555 ;	quantum/vial.c:423: }
                                   1556 ;	quantum/vial.c:424: }
      00ACA9 02 35 38         [24] 1557 	ljmp	_ak820_combo_reload
      00ACAC                       1558 00139$:
      00ACAC 22               [24] 1559 	ret
                                   1560 ;------------------------------------------------------------
                                   1561 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1562 ;------------------------------------------------------------
                                   1563 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_648'
                                   1564 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_655'
                                   1565 ;------------------------------------------------------------
                                   1566 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1567 ;	-----------------------------------------
                                   1568 ;	 function vial_keycode_down
                                   1569 ;	-----------------------------------------
      00ACAD                       1570 _vial_keycode_down:
      00ACAD 12 38 47         [24] 1571 	lcall	_ak820_outline_0100
      00ACB0 90 0C 3E         [24] 1572 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00ACB3 12 38 42         [24] 1573 	lcall	_ak820_outline_0099
                                   1574 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00ACB6 90 0C 3E         [24] 1575 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00ACB9 12 37 CD         [24] 1576 	lcall	_ak820_outline_0009
      00ACBC 74 E0            [12] 1577 	mov	a,#0x100 - 0x20
      00ACBE 2D               [12] 1578 	add	a,r5
      00ACBF 50 19            [24] 1579 	jnc	00104$
      00ACC1 C3               [12] 1580 	clr	c
      00ACC2 74 FF            [12] 1581 	mov	a,#0xff
      00ACC4 9C               [12] 1582 	subb	a,r4
      00ACC5 74 4F            [12] 1583 	mov	a,#0x4f
      00ACC7 9D               [12] 1584 	subb	a,r5
      00ACC8 40 10            [24] 1585 	jc	00104$
                                   1586 ;	free result
                                   1587 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00ACCA 90 0C 3E         [24] 1588 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00ACCD EE               [12] 1589 	mov	a,r6
      00ACCE 12 38 58         [24] 1590 	lcall	_ak820_outline_0115
                                   1591 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00ACD1 90 0C 3E         [24] 1592 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00ACD4 E0               [24] 1593 	movx	a,@dptr
      00ACD5 24 FE            [12] 1594 	add	a,#0xff - 0x01
      00ACD7 40 01            [24] 1595 	jc	00104$
                                   1596 ;	free result
      00ACD9 22               [24] 1597 	ret
      00ACDA                       1598 00104$:
                                   1599 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00ACDA 90 0C 3E         [24] 1600 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00ACDD 12 AD 98         [24] 1601 	lcall	_ak820_outline_0022
                                   1602 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00ACE0 40 06            [24] 1603 	jc	00107$
                                   1604 ;	free result
                                   1605 ;	quantum/vial.c:440: register_code16(keycode);
      00ACE2 12 43 1A         [24] 1606 	lcall	_ak820_outline_0111
      00ACE5 02 99 A6         [24] 1607 	ljmp	_register_code16
      00ACE8                       1608 00107$:
                                   1609 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00ACE8 90 0C 44         [24] 1610 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0004)
      00ACEB 74 01            [12] 1611 	mov	a,#0x01
      00ACED F0               [24] 1612 	movx	@dptr,a
      00ACEE 90 0C 41         [24] 1613 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0001)
      00ACF1 74 F0            [12] 1614 	mov	a,#0xf0
      00ACF3 F0               [24] 1615 	movx	@dptr,a
      00ACF4 90 0C 40         [24] 1616 	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
      00ACF7 F0               [24] 1617 	movx	@dptr,a
      00ACF8 90 0C 45         [24] 1618 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0005)
      00ACFB 74 01            [12] 1619 	mov	a,#0x01
      00ACFD F0               [24] 1620 	movx	@dptr,a
      00ACFE 12 47 1D         [24] 1621 	lcall	_timer_read
      00AD01 12 43 1F         [24] 1622 	lcall	_ak820_outline_0125
      00AD04 43 06 01         [24] 1623 	orl	ar6,#0x01
      00AD07 90 0C 42         [24] 1624 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0002)
      00AD0A 12 46 8C         [24] 1625 	lcall	_ak820_outline_0055
                                   1626 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00AD0D 90 0C 40         [24] 1627 	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
                                   1628 ;	quantum/vial.c:448: }
      00AD10 02 6E 30         [24] 1629 	ljmp	_ak820_action_exec
                                   1630 ;------------------------------------------------------------
                                   1631 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1632 ;------------------------------------------------------------
                                   1633 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_656'
                                   1634 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_663'
                                   1635 ;------------------------------------------------------------
                                   1636 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1637 ;	-----------------------------------------
                                   1638 ;	 function vial_keycode_up
                                   1639 ;	-----------------------------------------
      00AD13                       1640 _vial_keycode_up:
      00AD13 12 38 47         [24] 1641 	lcall	_ak820_outline_0100
      00AD16 90 0C 46         [24] 1642 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AD19 12 38 42         [24] 1643 	lcall	_ak820_outline_0099
                                   1644 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00AD1C 90 0C 46         [24] 1645 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AD1F 12 37 CD         [24] 1646 	lcall	_ak820_outline_0009
      00AD22 74 E0            [12] 1647 	mov	a,#0x100 - 0x20
      00AD24 2D               [12] 1648 	add	a,r5
      00AD25 50 19            [24] 1649 	jnc	00104$
      00AD27 C3               [12] 1650 	clr	c
      00AD28 74 FF            [12] 1651 	mov	a,#0xff
      00AD2A 9C               [12] 1652 	subb	a,r4
      00AD2B 74 4F            [12] 1653 	mov	a,#0x4f
      00AD2D 9D               [12] 1654 	subb	a,r5
      00AD2E 40 10            [24] 1655 	jc	00104$
                                   1656 ;	free result
                                   1657 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00AD30 90 0C 46         [24] 1658 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AD33 EE               [12] 1659 	mov	a,r6
      00AD34 12 38 58         [24] 1660 	lcall	_ak820_outline_0115
                                   1661 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00AD37 90 0C 46         [24] 1662 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AD3A E0               [24] 1663 	movx	a,@dptr
      00AD3B 24 FE            [12] 1664 	add	a,#0xff - 0x01
      00AD3D 40 01            [24] 1665 	jc	00104$
                                   1666 ;	free result
      00AD3F 22               [24] 1667 	ret
      00AD40                       1668 00104$:
                                   1669 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00AD40 90 0C 46         [24] 1670 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AD43 12 AD 98         [24] 1671 	lcall	_ak820_outline_0022
                                   1672 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00AD46 40 06            [24] 1673 	jc	00107$
                                   1674 ;	free result
                                   1675 ;	quantum/vial.c:462: unregister_code16(keycode);
      00AD48 12 43 1A         [24] 1676 	lcall	_ak820_outline_0111
      00AD4B 02 99 EB         [24] 1677 	ljmp	_unregister_code16
      00AD4E                       1678 00107$:
                                   1679 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00AD4E 90 0C 4C         [24] 1680 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0004)
      00AD51 74 01            [12] 1681 	mov	a,#0x01
      00AD53 F0               [24] 1682 	movx	@dptr,a
      00AD54 90 0C 49         [24] 1683 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0001)
      00AD57 74 F0            [12] 1684 	mov	a,#0xf0
      00AD59 F0               [24] 1685 	movx	@dptr,a
      00AD5A 90 0C 48         [24] 1686 	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
      00AD5D F0               [24] 1687 	movx	@dptr,a
      00AD5E 90 0C 4D         [24] 1688 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0005)
      00AD61 E4               [12] 1689 	clr	a
      00AD62 F0               [24] 1690 	movx	@dptr,a
      00AD63 12 47 1D         [24] 1691 	lcall	_timer_read
      00AD66 12 43 1F         [24] 1692 	lcall	_ak820_outline_0125
      00AD69 43 06 01         [24] 1693 	orl	ar6,#0x01
      00AD6C 90 0C 4A         [24] 1694 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0002)
      00AD6F 12 46 8C         [24] 1695 	lcall	_ak820_outline_0055
                                   1696 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00AD72 90 0C 48         [24] 1697 	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
                                   1698 ;	quantum/vial.c:470: }
      00AD75 02 6E 30         [24] 1699 	ljmp	_ak820_action_exec
                                   1700 ;------------------------------------------------------------
                                   1701 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1702 ;------------------------------------------------------------
                                   1703 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_664'
                                   1704 ;i             Allocated with name '_vial_keycode_tap_i_30000_667'
                                   1705 ;------------------------------------------------------------
                                   1706 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1707 ;	-----------------------------------------
                                   1708 ;	 function vial_keycode_tap
                                   1709 ;	-----------------------------------------
      00AD78                       1710 _vial_keycode_tap:
      00AD78 12 38 47         [24] 1711 	lcall	_ak820_outline_0100
      00AD7B 90 0C 4E         [24] 1712 	mov	dptr,#_vial_keycode_tap_keycode_10000_664
      00AD7E 12 38 42         [24] 1713 	lcall	_ak820_outline_0099
                                   1714 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00AD81 90 0C 4E         [24] 1715 	mov	dptr,#_vial_keycode_tap_keycode_10000_664
      00AD84 12 37 A2         [24] 1716 	lcall	_ak820_outline_0004
      00AD87 C0 07            [24] 1717 	push	ar7
      00AD89 C0 06            [24] 1718 	push	ar6
      00AD8B 12 AC AD         [24] 1719 	lcall	_vial_keycode_down
      00AD8E D0 06            [24] 1720 	pop	ar6
      00AD90 D0 07            [24] 1721 	pop	ar7
                                   1722 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00AD92 12 43 1A         [24] 1723 	lcall	_ak820_outline_0111
                                   1724 ;	quantum/vial.c:476: }
      00AD95 02 AD 13         [24] 1725 	ljmp	_vial_keycode_up
                                   1726 ;------------------------------------------------------------
                                   1727 ;Allocation info for local variables in function 'process_record_vial'
                                   1728 ;------------------------------------------------------------
                                   1729 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1730 ;keycode       Allocated with name '_process_record_vial_keycode_10000_669'
                                   1731 ;------------------------------------------------------------
                                   1732 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1733 ;	-----------------------------------------
                                   1734 	.area CSEG    (CODE)
                                   1735 	.area CONST   (CODE)
                                   1736 	.area CONST   (CODE)
      00B8EA                       1737 _keyboard_definition:
      00B8EA FD                    1738 	.db #0xfd	; 253
      00B8EB 37                    1739 	.db #0x37	; 55	'7'
      00B8EC 7A                    1740 	.db #0x7a	; 122	'z'
      00B8ED 58                    1741 	.db #0x58	; 88	'X'
      00B8EE 5A                    1742 	.db #0x5a	; 90	'Z'
      00B8EF 00                    1743 	.db #0x00	; 0
      00B8F0 00                    1744 	.db #0x00	; 0
      00B8F1 04                    1745 	.db #0x04	; 4
      00B8F2 E6                    1746 	.db #0xe6	; 230
      00B8F3 D6                    1747 	.db #0xd6	; 214
      00B8F4 B4                    1748 	.db #0xb4	; 180
      00B8F5 46                    1749 	.db #0x46	; 70	'F'
      00B8F6 02                    1750 	.db #0x02	; 2
      00B8F7 00                    1751 	.db #0x00	; 0
      00B8F8 21                    1752 	.db #0x21	; 33
      00B8F9 01                    1753 	.db #0x01	; 1
      00B8FA 00                    1754 	.db #0x00	; 0
      00B8FB 00                    1755 	.db #0x00	; 0
      00B8FC 00                    1756 	.db #0x00	; 0
      00B8FD 00                    1757 	.db #0x00	; 0
      00B8FE 37                    1758 	.db #0x37	; 55	'7'
      00B8FF 27                    1759 	.db #0x27	; 39
      00B900 97                    1760 	.db #0x97	; 151
      00B901 D6                    1761 	.db #0xd6	; 214
      00B902 E0                    1762 	.db #0xe0	; 224
      00B903 03                    1763 	.db #0x03	; 3
      00B904 CB                    1764 	.db #0xcb	; 203
      00B905 01                    1765 	.db #0x01	; 1
      00B906 3C                    1766 	.db #0x3c	; 60
      00B907 00                    1767 	.db #0x00	; 0
      00B908 00                    1768 	.db #0x00	; 0
      00B909 3D                    1769 	.db #0x3d	; 61
      00B90A 88                    1770 	.db #0x88	; 136
      00B90B CD                    1771 	.db #0xcd	; 205
      00B90C A5                    1772 	.db #0xa5	; 165
      00B90D AA                    1773 	.db #0xaa	; 170
      00B90E E5                    1774 	.db #0xe5	; 229
      00B90F A8                    1775 	.db #0xa8	; 168
      00B910 76                    1776 	.db #0x76	; 118	'v'
      00B911 F6                    1777 	.db #0xf6	; 246
      00B912 43                    1778 	.db #0x43	; 67	'C'
      00B913 0E                    1779 	.db #0x0e	; 14
      00B914 D2                    1780 	.db #0xd2	; 210
      00B915 90                    1781 	.db #0x90	; 144
      00B916 7D                    1782 	.db #0x7d	; 125
      00B917 94                    1783 	.db #0x94	; 148
      00B918 79                    1784 	.db #0x79	; 121	'y'
      00B919 78                    1785 	.db #0x78	; 120	'x'
      00B91A EF                    1786 	.db #0xef	; 239
      00B91B 49                    1787 	.db #0x49	; 73	'I'
      00B91C 3E                    1788 	.db #0x3e	; 62
      00B91D EF                    1789 	.db #0xef	; 239
      00B91E FD                    1790 	.db #0xfd	; 253
      00B91F 8F                    1791 	.db #0x8f	; 143
      00B920 EF                    1792 	.db #0xef	; 239
      00B921 00                    1793 	.db #0x00	; 0
      00B922 C6                    1794 	.db #0xc6	; 198
      00B923 D1                    1795 	.db #0xd1	; 209
      00B924 DB                    1796 	.db #0xdb	; 219
      00B925 FB                    1797 	.db #0xfb	; 251
      00B926 EB                    1798 	.db #0xeb	; 235
      00B927 DE                    1799 	.db #0xde	; 222
      00B928 66                    1800 	.db #0x66	; 102	'f'
      00B929 63                    1801 	.db #0x63	; 99	'c'
      00B92A 0C                    1802 	.db #0x0c	; 12
      00B92B 92                    1803 	.db #0x92	; 146
      00B92C 7B                    1804 	.db #0x7b	; 123
      00B92D F9                    1805 	.db #0xf9	; 249
      00B92E D4                    1806 	.db #0xd4	; 212
      00B92F 7A                    1807 	.db #0x7a	; 122	'z'
      00B930 4F                    1808 	.db #0x4f	; 79	'O'
      00B931 83                    1809 	.db #0x83	; 131
      00B932 4B                    1810 	.db #0x4b	; 75	'K'
      00B933 86                    1811 	.db #0x86	; 134
      00B934 0E                    1812 	.db #0x0e	; 14
      00B935 6A                    1813 	.db #0x6a	; 106	'j'
      00B936 F2                    1814 	.db #0xf2	; 242
      00B937 22                    1815 	.db #0x22	; 34
      00B938 22                    1816 	.db #0x22	; 34
      00B939 0B                    1817 	.db #0x0b	; 11
      00B93A 03                    1818 	.db #0x03	; 3
      00B93B BA                    1819 	.db #0xba	; 186
      00B93C 67                    1820 	.db #0x67	; 103	'g'
      00B93D 9B                    1821 	.db #0x9b	; 155
      00B93E 7A                    1822 	.db #0x7a	; 122	'z'
      00B93F E1                    1823 	.db #0xe1	; 225
      00B940 BC                    1824 	.db #0xbc	; 188
      00B941 37                    1825 	.db #0x37	; 55	'7'
      00B942 26                    1826 	.db #0x26	; 38
      00B943 46                    1827 	.db #0x46	; 70	'F'
      00B944 78                    1828 	.db #0x78	; 120	'x'
      00B945 05                    1829 	.db #0x05	; 5
      00B946 0D                    1830 	.db #0x0d	; 13
      00B947 95                    1831 	.db #0x95	; 149
      00B948 02                    1832 	.db #0x02	; 2
      00B949 E4                    1833 	.db #0xe4	; 228
      00B94A 18                    1834 	.db #0x18	; 24
      00B94B CA                    1835 	.db #0xca	; 202
      00B94C 33                    1836 	.db #0x33	; 51	'3'
      00B94D EA                    1837 	.db #0xea	; 234
      00B94E 24                    1838 	.db #0x24	; 36
      00B94F C8                    1839 	.db #0xc8	; 200
      00B950 81                    1840 	.db #0x81	; 129
      00B951 4E                    1841 	.db #0x4e	; 78	'N'
      00B952 47                    1842 	.db #0x47	; 71	'G'
      00B953 A8                    1843 	.db #0xa8	; 168
      00B954 44                    1844 	.db #0x44	; 68	'D'
      00B955 DD                    1845 	.db #0xdd	; 221
      00B956 91                    1846 	.db #0x91	; 145
      00B957 6D                    1847 	.db #0x6d	; 109	'm'
      00B958 69                    1848 	.db #0x69	; 105	'i'
      00B959 DB                    1849 	.db #0xdb	; 219
      00B95A 4F                    1850 	.db #0x4f	; 79	'O'
      00B95B 3A                    1851 	.db #0x3a	; 58
      00B95C 43                    1852 	.db #0x43	; 67	'C'
      00B95D 9D                    1853 	.db #0x9d	; 157
      00B95E 26                    1854 	.db #0x26	; 38
      00B95F 49                    1855 	.db #0x49	; 73	'I'
      00B960 4C                    1856 	.db #0x4c	; 76	'L'
      00B961 EF                    1857 	.db #0xef	; 239
      00B962 2B                    1858 	.db #0x2b	; 43
      00B963 D8                    1859 	.db #0xd8	; 216
      00B964 55                    1860 	.db #0x55	; 85	'U'
      00B965 95                    1861 	.db #0x95	; 149
      00B966 70                    1862 	.db #0x70	; 112	'p'
      00B967 B1                    1863 	.db #0xb1	; 177
      00B968 CC                    1864 	.db #0xcc	; 204
      00B969 CF                    1865 	.db #0xcf	; 207
      00B96A 13                    1866 	.db #0x13	; 19
      00B96B 32                    1867 	.db #0x32	; 50	'2'
      00B96C 6A                    1868 	.db #0x6a	; 106	'j'
      00B96D A1                    1869 	.db #0xa1	; 161
      00B96E FF                    1870 	.db #0xff	; 255
      00B96F 99                    1871 	.db #0x99	; 153
      00B970 61                    1872 	.db #0x61	; 97	'a'
      00B971 95                    1873 	.db #0x95	; 149
      00B972 B1                    1874 	.db #0xb1	; 177
      00B973 89                    1875 	.db #0x89	; 137
      00B974 9B                    1876 	.db #0x9b	; 155
      00B975 11                    1877 	.db #0x11	; 17
      00B976 D9                    1878 	.db #0xd9	; 217
      00B977 35                    1879 	.db #0x35	; 53	'5'
      00B978 78                    1880 	.db #0x78	; 120	'x'
      00B979 ED                    1881 	.db #0xed	; 237
      00B97A CD                    1882 	.db #0xcd	; 205
      00B97B 94                    1883 	.db #0x94	; 148
      00B97C 6E                    1884 	.db #0x6e	; 110	'n'
      00B97D 60                    1885 	.db #0x60	; 96
      00B97E 8E                    1886 	.db #0x8e	; 142
      00B97F 63                    1887 	.db #0x63	; 99	'c'
      00B980 8B                    1888 	.db #0x8b	; 139
      00B981 FF                    1889 	.db #0xff	; 255
      00B982 4E                    1890 	.db #0x4e	; 78	'N'
      00B983 20                    1891 	.db #0x20	; 32
      00B984 7A                    1892 	.db #0x7a	; 122	'z'
      00B985 B5                    1893 	.db #0xb5	; 181
      00B986 87                    1894 	.db #0x87	; 135
      00B987 C2                    1895 	.db #0xc2	; 194
      00B988 35                    1896 	.db #0x35	; 53	'5'
      00B989 A4                    1897 	.db #0xa4	; 164
      00B98A 6D                    1898 	.db #0x6d	; 109	'm'
      00B98B 18                    1899 	.db #0x18	; 24
      00B98C C1                    1900 	.db #0xc1	; 193
      00B98D A3                    1901 	.db #0xa3	; 163
      00B98E DB                    1902 	.db #0xdb	; 219
      00B98F 53                    1903 	.db #0x53	; 83	'S'
      00B990 1D                    1904 	.db #0x1d	; 29
      00B991 EC                    1905 	.db #0xec	; 236
      00B992 F0                    1906 	.db #0xf0	; 240
      00B993 BF                    1907 	.db #0xbf	; 191
      00B994 4A                    1908 	.db #0x4a	; 74	'J'
      00B995 4C                    1909 	.db #0x4c	; 76	'L'
      00B996 4A                    1910 	.db #0x4a	; 74	'J'
      00B997 C4                    1911 	.db #0xc4	; 196
      00B998 AA                    1912 	.db #0xaa	; 170
      00B999 37                    1913 	.db #0x37	; 55	'7'
      00B99A 19                    1914 	.db #0x19	; 25
      00B99B 34                    1915 	.db #0x34	; 52	'4'
      00B99C 3F                    1916 	.db #0x3f	; 63
      00B99D A1                    1917 	.db #0xa1	; 161
      00B99E D3                    1918 	.db #0xd3	; 211
      00B99F 1A                    1919 	.db #0x1a	; 26
      00B9A0 5C                    1920 	.db #0x5c	; 92
      00B9A1 03                    1921 	.db #0x03	; 3
      00B9A2 4D                    1922 	.db #0x4d	; 77	'M'
      00B9A3 BC                    1923 	.db #0xbc	; 188
      00B9A4 10                    1924 	.db #0x10	; 16
      00B9A5 2E                    1925 	.db #0x2e	; 46
      00B9A6 80                    1926 	.db #0x80	; 128
      00B9A7 F7                    1927 	.db #0xf7	; 247
      00B9A8 D6                    1928 	.db #0xd6	; 214
      00B9A9 82                    1929 	.db #0x82	; 130
      00B9AA 24                    1930 	.db #0x24	; 36
      00B9AB 4C                    1931 	.db #0x4c	; 76	'L'
      00B9AC 87                    1932 	.db #0x87	; 135
      00B9AD B9                    1933 	.db #0xb9	; 185
      00B9AE F8                    1934 	.db #0xf8	; 248
      00B9AF BE                    1935 	.db #0xbe	; 190
      00B9B0 67                    1936 	.db #0x67	; 103	'g'
      00B9B1 96                    1937 	.db #0x96	; 150
      00B9B2 89                    1938 	.db #0x89	; 137
      00B9B3 30                    1939 	.db #0x30	; 48	'0'
      00B9B4 C8                    1940 	.db #0xc8	; 200
      00B9B5 8D                    1941 	.db #0x8d	; 141
      00B9B6 2C                    1942 	.db #0x2c	; 44
      00B9B7 F5                    1943 	.db #0xf5	; 245
      00B9B8 06                    1944 	.db #0x06	; 6
      00B9B9 05                    1945 	.db #0x05	; 5
      00B9BA 7C                    1946 	.db #0x7c	; 124
      00B9BB 48                    1947 	.db #0x48	; 72	'H'
      00B9BC 1B                    1948 	.db #0x1b	; 27
      00B9BD 76                    1949 	.db #0x76	; 118	'v'
      00B9BE AA                    1950 	.db #0xaa	; 170
      00B9BF 3D                    1951 	.db #0x3d	; 61
      00B9C0 28                    1952 	.db #0x28	; 40
      00B9C1 FC                    1953 	.db #0xfc	; 252
      00B9C2 80                    1954 	.db #0x80	; 128
      00B9C3 75                    1955 	.db #0x75	; 117	'u'
      00B9C4 EB                    1956 	.db #0xeb	; 235
      00B9C5 78                    1957 	.db #0x78	; 120	'x'
      00B9C6 D0                    1958 	.db #0xd0	; 208
      00B9C7 8A                    1959 	.db #0x8a	; 138
      00B9C8 8F                    1960 	.db #0x8f	; 143
      00B9C9 27                    1961 	.db #0x27	; 39
      00B9CA F7                    1962 	.db #0xf7	; 247
      00B9CB F2                    1963 	.db #0xf2	; 242
      00B9CC EB                    1964 	.db #0xeb	; 235
      00B9CD 58                    1965 	.db #0x58	; 88	'X'
      00B9CE 37                    1966 	.db #0x37	; 55	'7'
      00B9CF 3C                    1967 	.db #0x3c	; 60
      00B9D0 2B                    1968 	.db #0x2b	; 43
      00B9D1 6F                    1969 	.db #0x6f	; 111	'o'
      00B9D2 0E                    1970 	.db #0x0e	; 14
      00B9D3 C7                    1971 	.db #0xc7	; 199
      00B9D4 E2                    1972 	.db #0xe2	; 226
      00B9D5 A0                    1973 	.db #0xa0	; 160
      00B9D6 97                    1974 	.db #0x97	; 151
      00B9D7 EE                    1975 	.db #0xee	; 238
      00B9D8 FD                    1976 	.db #0xfd	; 253
      00B9D9 9F                    1977 	.db #0x9f	; 159
      00B9DA 45                    1978 	.db #0x45	; 69	'E'
      00B9DB 17                    1979 	.db #0x17	; 23
      00B9DC 94                    1980 	.db #0x94	; 148
      00B9DD E6                    1981 	.db #0xe6	; 230
      00B9DE E7                    1982 	.db #0xe7	; 231
      00B9DF FA                    1983 	.db #0xfa	; 250
      00B9E0 4C                    1984 	.db #0x4c	; 76	'L'
      00B9E1 7A                    1985 	.db #0x7a	; 122	'z'
      00B9E2 D6                    1986 	.db #0xd6	; 214
      00B9E3 7A                    1987 	.db #0x7a	; 122	'z'
      00B9E4 7B                    1988 	.db #0x7b	; 123
      00B9E5 ED                    1989 	.db #0xed	; 237
      00B9E6 10                    1990 	.db #0x10	; 16
      00B9E7 C5                    1991 	.db #0xc5	; 197
      00B9E8 BC                    1992 	.db #0xbc	; 188
      00B9E9 E3                    1993 	.db #0xe3	; 227
      00B9EA A9                    1994 	.db #0xa9	; 169
      00B9EB 1F                    1995 	.db #0x1f	; 31
      00B9EC CF                    1996 	.db #0xcf	; 207
      00B9ED C4                    1997 	.db #0xc4	; 196
      00B9EE 9D                    1998 	.db #0x9d	; 157
      00B9EF DC                    1999 	.db #0xdc	; 220
      00B9F0 45                    2000 	.db #0x45	; 69	'E'
      00B9F1 2A                    2001 	.db #0x2a	; 42
      00B9F2 69                    2002 	.db #0x69	; 105	'i'
      00B9F3 57                    2003 	.db #0x57	; 87	'W'
      00B9F4 8F                    2004 	.db #0x8f	; 143
      00B9F5 EC                    2005 	.db #0xec	; 236
      00B9F6 85                    2006 	.db #0x85	; 133
      00B9F7 6C                    2007 	.db #0x6c	; 108	'l'
      00B9F8 43                    2008 	.db #0x43	; 67	'C'
      00B9F9 1C                    2009 	.db #0x1c	; 28
      00B9FA BA                    2010 	.db #0xba	; 186
      00B9FB 89                    2011 	.db #0x89	; 137
      00B9FC 68                    2012 	.db #0x68	; 104	'h'
      00B9FD 4A                    2013 	.db #0x4a	; 74	'J'
      00B9FE 1C                    2014 	.db #0x1c	; 28
      00B9FF 91                    2015 	.db #0x91	; 145
      00BA00 3F                    2016 	.db #0x3f	; 63
      00BA01 D1                    2017 	.db #0xd1	; 209
      00BA02 B3                    2018 	.db #0xb3	; 179
      00BA03 96                    2019 	.db #0x96	; 150
      00BA04 1D                    2020 	.db #0x1d	; 29
      00BA05 7C                    2021 	.db #0x7c	; 124
      00BA06 14                    2022 	.db #0x14	; 20
      00BA07 77                    2023 	.db #0x77	; 119	'w'
      00BA08 9C                    2024 	.db #0x9c	; 156
      00BA09 74                    2025 	.db #0x74	; 116	't'
      00BA0A 36                    2026 	.db #0x36	; 54	'6'
      00BA0B FF                    2027 	.db #0xff	; 255
      00BA0C 2C                    2028 	.db #0x2c	; 44
      00BA0D 66                    2029 	.db #0x66	; 102	'f'
      00BA0E AF                    2030 	.db #0xaf	; 175
      00BA0F 0F                    2031 	.db #0x0f	; 15
      00BA10 3C                    2032 	.db #0x3c	; 60
      00BA11 A2                    2033 	.db #0xa2	; 162
      00BA12 23                    2034 	.db #0x23	; 35
      00BA13 85                    2035 	.db #0x85	; 133
      00BA14 05                    2036 	.db #0x05	; 5
      00BA15 87                    2037 	.db #0x87	; 135
      00BA16 DA                    2038 	.db #0xda	; 218
      00BA17 61                    2039 	.db #0x61	; 97	'a'
      00BA18 5E                    2040 	.db #0x5e	; 94
      00BA19 42                    2041 	.db #0x42	; 66	'B'
      00BA1A 54                    2042 	.db #0x54	; 84	'T'
      00BA1B 60                    2043 	.db #0x60	; 96
      00BA1C 23                    2044 	.db #0x23	; 35
      00BA1D CA                    2045 	.db #0xca	; 202
      00BA1E BC                    2046 	.db #0xbc	; 188
      00BA1F B3                    2047 	.db #0xb3	; 179
      00BA20 18                    2048 	.db #0x18	; 24
      00BA21 1D                    2049 	.db #0x1d	; 29
      00BA22 F8                    2050 	.db #0xf8	; 248
      00BA23 0A                    2051 	.db #0x0a	; 10
      00BA24 55                    2052 	.db #0x55	; 85	'U'
      00BA25 CD                    2053 	.db #0xcd	; 205
      00BA26 A3                    2054 	.db #0xa3	; 163
      00BA27 DE                    2055 	.db #0xde	; 222
      00BA28 FF                    2056 	.db #0xff	; 255
      00BA29 B2                    2057 	.db #0xb2	; 178
      00BA2A 2A                    2058 	.db #0x2a	; 42
      00BA2B 35                    2059 	.db #0x35	; 53	'5'
      00BA2C 00                    2060 	.db #0x00	; 0
      00BA2D D6                    2061 	.db #0xd6	; 214
      00BA2E 7B                    2062 	.db #0x7b	; 123
      00BA2F E8                    2063 	.db #0xe8	; 232
      00BA30 F2                    2064 	.db #0xf2	; 242
      00BA31 1A                    2065 	.db #0x1a	; 26
      00BA32 BC                    2066 	.db #0xbc	; 188
      00BA33 F5                    2067 	.db #0xf5	; 245
      00BA34 7E                    2068 	.db #0x7e	; 126
      00BA35 48                    2069 	.db #0x48	; 72	'H'
      00BA36 72                    2070 	.db #0x72	; 114	'r'
      00BA37 E0                    2071 	.db #0xe0	; 224
      00BA38 E4                    2072 	.db #0xe4	; 228
      00BA39 E0                    2073 	.db #0xe0	; 224
      00BA3A 27                    2074 	.db #0x27	; 39
      00BA3B 87                    2075 	.db #0x87	; 135
      00BA3C 9A                    2076 	.db #0x9a	; 154
      00BA3D 51                    2077 	.db #0x51	; 81	'Q'
      00BA3E D4                    2078 	.db #0xd4	; 212
      00BA3F DD                    2079 	.db #0xdd	; 221
      00BA40 C3                    2080 	.db #0xc3	; 195
      00BA41 AA                    2081 	.db #0xaa	; 170
      00BA42 49                    2082 	.db #0x49	; 73	'I'
      00BA43 5A                    2083 	.db #0x5a	; 90	'Z'
      00BA44 2A                    2084 	.db #0x2a	; 42
      00BA45 00                    2085 	.db #0x00	; 0
      00BA46 A0                    2086 	.db #0xa0	; 160
      00BA47 8C                    2087 	.db #0x8c	; 140
      00BA48 FF                    2088 	.db #0xff	; 255
      00BA49 74                    2089 	.db #0x74	; 116	't'
      00BA4A BF                    2090 	.db #0xbf	; 191
      00BA4B EC                    2091 	.db #0xec	; 236
      00BA4C 1D                    2092 	.db #0x1d	; 29
      00BA4D F1                    2093 	.db #0xf1	; 241
      00BA4E 00                    2094 	.db #0x00	; 0
      00BA4F 01                    2095 	.db #0x01	; 1
      00BA50 D8                    2096 	.db #0xd8	; 216
      00BA51 02                    2097 	.db #0x02	; 2
      00BA52 CC                    2098 	.db #0xcc	; 204
      00BA53 07                    2099 	.db #0x07	; 7
      00BA54 00                    2100 	.db #0x00	; 0
      00BA55 00                    2101 	.db #0x00	; 0
      00BA56 C4                    2102 	.db #0xc4	; 196
      00BA57 5E                    2103 	.db #0x5e	; 94
      00BA58 2C                    2104 	.db #0x2c	; 44
      00BA59 7E                    2105 	.db #0x7e	; 126
      00BA5A B1                    2106 	.db #0xb1	; 177
      00BA5B C4                    2107 	.db #0xc4	; 196
      00BA5C 67                    2108 	.db #0x67	; 103	'g'
      00BA5D FB                    2109 	.db #0xfb	; 251
      00BA5E 02                    2110 	.db #0x02	; 2
      00BA5F 00                    2111 	.db #0x00	; 0
      00BA60 00                    2112 	.db #0x00	; 0
      00BA61 00                    2113 	.db #0x00	; 0
      00BA62 00                    2114 	.db #0x00	; 0
      00BA63 04                    2115 	.db #0x04	; 4
      00BA64 59                    2116 	.db #0x59	; 89	'Y'
      00BA65 5A                    2117 	.db #0x5a	; 90	'Z'
                                   2118 	.area CSEG    (CODE)
                                   2119 	.area CONST   (CODE)
      00BA66                       2120 _vial_handle_cmd_keyboard_uid_40000_622:
      00BA66 04                    2121 	.db #0x04	; 4
      00BA67 70                    2122 	.db #0x70	; 112	'p'
      00BA68 FF                    2123 	.db #0xff	; 255
      00BA69 90                    2124 	.db #0x90	; 144
      00BA6A 01                    2125 	.db #0x01	; 1
      00BA6B B9                    2126 	.db #0xb9	; 185
      00BA6C 15                    2127 	.db #0x15	; 21
      00BA6D D3                    2128 	.db #0xd3	; 211
                                   2129 	.area CSEG    (CODE)
                                   2130 	.area XINIT   (CODE)
      00BC9B                       2131 __xinit__vial_unlocked:
      00BC9B 00                    2132 	.db #0x00	;  0
      00BC9C                       2133 __xinit__vial_unlock_in_progress:
      00BC9C 00                    2134 	.db #0x00	;  0
      00BC9D                       2135 __xinit__vial_unlock_counter:
      00BC9D 00                    2136 	.db #0x00	; 0
      00BC9E                       2137 __xinit__vial_unlock_combo_rows:
      00BC9E 00                    2138 	.db #0x00	; 0
      00BC9F 00                    2139 	.db #0x00	; 0
      00BCA0                       2140 __xinit__vial_unlock_combo_cols:
      00BCA0 00                    2141 	.db #0x00	; 0
      00BCA1 05                    2142 	.db #0x05	; 5
                                   2143 	.area CABS    (ABS,CODE)
                                   2144 
                                   2145 ; Experimental exact instruction outlining.
                                   2146 	.globl _ak820_outline_0004
                                   2147 	.globl _ak820_outline_0007
                                   2148 	.globl _ak820_outline_0009
                                   2149 	.globl _ak820_outline_0010
                                   2150 	.globl _ak820_outline_0011
                                   2151 	.globl _ak820_outline_0013
                                   2152 	.globl _ak820_outline_0014
                                   2153 	.globl _ak820_outline_0018
                                   2154 	.globl _ak820_outline_0019
                                   2155 	.globl _ak820_outline_0022
                                   2156 	.globl _ak820_outline_0028
                                   2157 	.globl _ak820_outline_0031
                                   2158 	.globl _ak820_outline_0034
                                   2159 	.globl _ak820_outline_0043
                                   2160 	.globl _ak820_outline_0047
                                   2161 	.globl _ak820_outline_0050
                                   2162 	.globl _ak820_outline_0052
                                   2163 	.globl _ak820_outline_0055
                                   2164 	.globl _ak820_outline_0057
                                   2165 	.globl _ak820_outline_0067
                                   2166 	.globl _ak820_outline_0071
                                   2167 	.globl _ak820_outline_0085
                                   2168 	.globl _ak820_outline_0094
                                   2169 	.globl _ak820_outline_0099
                                   2170 	.globl _ak820_outline_0100
                                   2171 	.globl _ak820_outline_0111
                                   2172 	.globl _ak820_outline_0112
                                   2173 	.globl _ak820_outline_0115
                                   2174 	.globl _ak820_outline_0116
                                   2175 	.globl _ak820_outline_0118
                                   2176 	.globl _ak820_outline_0119
                                   2177 	.globl _ak820_outline_0125
                                   2178 	.globl _ak820_outline_0129
                                   2179 	.globl _ak820_outline_0134
                                   2180 	.globl _ak820_outline_0145
                                   2181 	.globl _ak820_outline_0159
                                   2182 
                                   2183 	.area CSEG (CODE)
                                   2184 ; function ak820_outline_0022
      00AD98                       2185 _ak820_outline_0022:
      00AD98 E0               [24] 2186 	movx	a,@dptr
      00AD99 FE               [12] 2187 	mov	r6,a
      00AD9A A3               [24] 2188 	inc	dptr
      00AD9B E0               [24] 2189 	movx	a,@dptr
      00AD9C FF               [12] 2190 	mov	r7,a
      00AD9D 90 0C 3C         [24] 2191 	mov	dptr,#_g_vial_magic_keycode_override
      00ADA0 EE               [12] 2192 	mov	a,r6
      00ADA1 F0               [24] 2193 	movx	@dptr,a
      00ADA2 EF               [12] 2194 	mov	a,r7
      00ADA3 A3               [24] 2195 	inc	dptr
      00ADA4 F0               [24] 2196 	movx	@dptr,a
      00ADA5 8E 04            [24] 2197 	mov	ar4,r6
      00ADA7 8F 05            [24] 2198 	mov	ar5,r7
      00ADA9 C3               [12] 2199 	clr	c
      00ADAA 74 FF            [12] 2200 	mov	a,#0xff
      00ADAC 9C               [12] 2201 	subb	a,r4
      00ADAD 74 1F            [12] 2202 	mov	a,#0x1f
      00ADAF 9D               [12] 2203 	subb	a,r5
      00ADB0 22               [24] 2204 	ret
                                   2205 
                                   2206 	.area CSEG (CODE)
                                   2207 ; function ak820_outline_0118
      00ADB1                       2208 _ak820_outline_0118:
      00ADB1 24 E8            [12] 2209 	add	a,#_vial_unlock_combo_cols
      00ADB3 F5 82            [12] 2210 	mov	dpl,a
      00ADB5 E4               [12] 2211 	clr	a
      00ADB6 34 0D            [12] 2212 	addc	a,#(_vial_unlock_combo_cols>>8)
      00ADB8 F5 83            [12] 2213 	mov	dph,a
      00ADBA E0               [24] 2214 	movx	a,@dptr
      00ADBB 22               [24] 2215 	ret
                                   2216 
                                   2217 	.area CSEG (CODE)
                                   2218 ; function ak820_outline_0119
      00ADBC                       2219 _ak820_outline_0119:
      00ADBC 24 E6            [12] 2220 	add	a,#_vial_unlock_combo_rows
      00ADBE F5 82            [12] 2221 	mov	dpl,a
      00ADC0 E4               [12] 2222 	clr	a
      00ADC1 34 0D            [12] 2223 	addc	a,#(_vial_unlock_combo_rows>>8)
      00ADC3 F5 83            [12] 2224 	mov	dph,a
      00ADC5 E0               [24] 2225 	movx	a,@dptr
      00ADC6 22               [24] 2226 	ret
