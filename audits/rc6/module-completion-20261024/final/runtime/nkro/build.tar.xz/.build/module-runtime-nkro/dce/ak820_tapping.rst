                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _layer_hold_off
                                     12 	.globl _layer_hold_on
                                     13 	.globl _unregister_mods
                                     14 	.globl _register_mods
                                     15 	.globl _process_record
                                     16 	.globl _ADC_START
                                     17 	.globl _S0_R_FIFO
                                     18 	.globl _S0_T_FIFO
                                     19 	.globl _S0_FREE
                                     20 	.globl _S0_IF_BYTE
                                     21 	.globl _S0_IF_FIRST
                                     22 	.globl _S0_IF_OV
                                     23 	.globl _S0_FST_ACT
                                     24 	.globl _CP_RL2
                                     25 	.globl _C_T2
                                     26 	.globl _TR2
                                     27 	.globl _EXEN2
                                     28 	.globl _TCLK
                                     29 	.globl _RCLK
                                     30 	.globl _EXF2
                                     31 	.globl _CAP1F
                                     32 	.globl _TF2
                                     33 	.globl _RI
                                     34 	.globl _TI
                                     35 	.globl _RB8
                                     36 	.globl _TB8
                                     37 	.globl _REN
                                     38 	.globl _SM2
                                     39 	.globl _SM1
                                     40 	.globl _SM0
                                     41 	.globl _IT0
                                     42 	.globl _IE0
                                     43 	.globl _IT1
                                     44 	.globl _IE1
                                     45 	.globl _TR0
                                     46 	.globl _TF0
                                     47 	.globl _TR1
                                     48 	.globl _TF1
                                     49 	.globl _P4_0
                                     50 	.globl _P4_1
                                     51 	.globl _P4_2
                                     52 	.globl _P4_3
                                     53 	.globl _P4_4
                                     54 	.globl _P4_5
                                     55 	.globl _P4_6
                                     56 	.globl _RXD
                                     57 	.globl _TXD
                                     58 	.globl _INT0
                                     59 	.globl _INT1
                                     60 	.globl _T0
                                     61 	.globl _T1
                                     62 	.globl _MOSI1
                                     63 	.globl _MISO1
                                     64 	.globl _SCK1
                                     65 	.globl _P3_0
                                     66 	.globl _P3_1
                                     67 	.globl _P3_2
                                     68 	.globl _P3_3
                                     69 	.globl _P3_4
                                     70 	.globl _P3_5
                                     71 	.globl _P3_6
                                     72 	.globl _P3_7
                                     73 	.globl _CAP1_
                                     74 	.globl _T2_
                                     75 	.globl _CAP2_
                                     76 	.globl _T2EX_
                                     77 	.globl _RXD1
                                     78 	.globl _TXD1
                                     79 	.globl _P2_0
                                     80 	.globl _P2_1
                                     81 	.globl _P2_2
                                     82 	.globl _P2_3
                                     83 	.globl _P2_4
                                     84 	.globl _P2_5
                                     85 	.globl _P2_6
                                     86 	.globl _P2_7
                                     87 	.globl _AIN0
                                     88 	.globl _AIN1
                                     89 	.globl _AIN2
                                     90 	.globl _AIN3
                                     91 	.globl _AIN4
                                     92 	.globl _AIN5
                                     93 	.globl _AIN6
                                     94 	.globl _AIN7
                                     95 	.globl _CAP1
                                     96 	.globl _T2
                                     97 	.globl _CAP2
                                     98 	.globl _T2EX
                                     99 	.globl _INT0_
                                    100 	.globl _SCS
                                    101 	.globl _MOSI
                                    102 	.globl _MISO
                                    103 	.globl _SCK
                                    104 	.globl _RXD1_
                                    105 	.globl _TXD1_
                                    106 	.globl _P1_0
                                    107 	.globl _P1_1
                                    108 	.globl _P1_2
                                    109 	.globl _P1_3
                                    110 	.globl _P1_4
                                    111 	.globl _P1_5
                                    112 	.globl _P1_6
                                    113 	.globl _P1_7
                                    114 	.globl _AIN8
                                    115 	.globl _AIN9
                                    116 	.globl _AIN10
                                    117 	.globl _AIN11
                                    118 	.globl _AIN12
                                    119 	.globl _AIN13
                                    120 	.globl _RXD_
                                    121 	.globl _TXD_
                                    122 	.globl _SCL0
                                    123 	.globl _SDA0
                                    124 	.globl _P0_0
                                    125 	.globl _P0_1
                                    126 	.globl _P0_2
                                    127 	.globl _P0_3
                                    128 	.globl _P0_4
                                    129 	.globl _P0_5
                                    130 	.globl _P0_6
                                    131 	.globl _P0_7
                                    132 	.globl _IE_SPI0
                                    133 	.globl _IE_USB
                                    134 	.globl _IE_ADC
                                    135 	.globl _IE_UART1
                                    136 	.globl _IE_PWM_I2C
                                    137 	.globl _IE_GPIO
                                    138 	.globl _IE_WDOG
                                    139 	.globl _PX0
                                    140 	.globl _PT0
                                    141 	.globl _PX1
                                    142 	.globl _PT1
                                    143 	.globl _PS
                                    144 	.globl _PT2
                                    145 	.globl _PL_FLAG
                                    146 	.globl _PH_FLAG
                                    147 	.globl _EX0
                                    148 	.globl _ET0
                                    149 	.globl _EX1
                                    150 	.globl _ET1
                                    151 	.globl _ES
                                    152 	.globl _ET2
                                    153 	.globl _E_DIS
                                    154 	.globl _EA
                                    155 	.globl _P
                                    156 	.globl _F1
                                    157 	.globl _OV
                                    158 	.globl _RS0
                                    159 	.globl _RS1
                                    160 	.globl _F0
                                    161 	.globl _AC
                                    162 	.globl _CY
                                    163 	.globl _I2CS_INT_ST
                                    164 	.globl _I2CX_INT
                                    165 	.globl _LED_STATUS
                                    166 	.globl _LED_DMA_H
                                    167 	.globl _LED_DMA_L
                                    168 	.globl _LED_DMA
                                    169 	.globl _LED_PWM_OE
                                    170 	.globl _LED_COMMON
                                    171 	.globl _ADC_CHAN
                                    172 	.globl _ADC_DAT_H
                                    173 	.globl _ADC_DAT_L
                                    174 	.globl _ADC_DAT
                                    175 	.globl _ADC_CTRL
                                    176 	.globl _SPI1_CK_SE
                                    177 	.globl _SPI1_CTRL
                                    178 	.globl _SPI1_DATA
                                    179 	.globl _SPI1_STAT
                                    180 	.globl _SIF1
                                    181 	.globl _SBAUD1
                                    182 	.globl _SBUF1
                                    183 	.globl _SCON1
                                    184 	.globl _SPI0_SETUP
                                    185 	.globl _SPI0_CK_SE
                                    186 	.globl _SPI0_CTRL
                                    187 	.globl _SPI0_DATA
                                    188 	.globl _SPI0_STAT
                                    189 	.globl _T2CAP1H
                                    190 	.globl _T2CAP1L
                                    191 	.globl _T2CAP1
                                    192 	.globl _TH2
                                    193 	.globl _TL2
                                    194 	.globl _T2COUNT
                                    195 	.globl _RCAP2H
                                    196 	.globl _RCAP2L
                                    197 	.globl _RCAP2
                                    198 	.globl _T2MOD
                                    199 	.globl _T2CON
                                    200 	.globl _SBUF
                                    201 	.globl _SCON
                                    202 	.globl _TH1
                                    203 	.globl _TH0
                                    204 	.globl _TL1
                                    205 	.globl _TL0
                                    206 	.globl _TMOD
                                    207 	.globl _TCON
                                    208 	.globl _XBUS_AUX
                                    209 	.globl _P7
                                    210 	.globl _P6_DIR
                                    211 	.globl _P6_OUT_PU
                                    212 	.globl _P6_IN
                                    213 	.globl _P5_DIR
                                    214 	.globl _P5_OUT_PU
                                    215 	.globl _P5_IN
                                    216 	.globl _P4_LED_KEY
                                    217 	.globl _P4_DIR_PU
                                    218 	.globl _P4_MOD_OC
                                    219 	.globl _P4
                                    220 	.globl _P3_DIR_PU
                                    221 	.globl _P3_MOD_OC
                                    222 	.globl _P3
                                    223 	.globl _P2_DIR_PU
                                    224 	.globl _P2_MOD_OC
                                    225 	.globl _P2
                                    226 	.globl _P1_DIR_PU
                                    227 	.globl _P1_MOD_OC
                                    228 	.globl _P1
                                    229 	.globl _P0_DIR_PU
                                    230 	.globl _P0_MOD_OC
                                    231 	.globl _P0
                                    232 	.globl _ROM_CTRL
                                    233 	.globl _ROM_DATA_HH
                                    234 	.globl _ROM_DATA_HL
                                    235 	.globl _ROM_DATA_HI
                                    236 	.globl _ROM_ADDR_H
                                    237 	.globl _ROM_ADDR_L
                                    238 	.globl _ROM_ADDR
                                    239 	.globl _GPIO_IE
                                    240 	.globl _IP_EX
                                    241 	.globl _IE_EX
                                    242 	.globl _IP
                                    243 	.globl _IE
                                    244 	.globl _WDOG_COUNT
                                    245 	.globl _RESET_KEEP
                                    246 	.globl _WAKE_CTRL
                                    247 	.globl _CLOCK_CFG
                                    248 	.globl _POWER_CFG
                                    249 	.globl _PCON
                                    250 	.globl _GLOBAL_CFG
                                    251 	.globl _SAFE_MOD
                                    252 	.globl _DPH
                                    253 	.globl _DPL
                                    254 	.globl _SP
                                    255 	.globl _A_INV
                                    256 	.globl _B
                                    257 	.globl _ACC
                                    258 	.globl _PSW
                                    259 	.globl _ak820_tapping_before
                                    260 	.globl _ak820_tapping_process
                                    261 	.globl _ak820_tapping_cancel
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
      000015                        524 _ak820_tapping_process_sloc0_1_0:
      000015                        525 	.ds 2
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable items in internal ram
                                    528 ;--------------------------------------------------------
                                    529 ;--------------------------------------------------------
                                    530 ; indirectly addressable internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area ISEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; absolute internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area IABS    (ABS,DATA)
                                    537 	.area IABS    (ABS,DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; bit data
                                    540 ;--------------------------------------------------------
                                    541 	.area BSEG    (BIT)
      00000C                        542 _ak820_tapping_before_sloc0_1_0:
      00000C                        543 	.ds 1
                                    544 ;--------------------------------------------------------
                                    545 ; paged external ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area PSEG    (PAG,XDATA)
                                    548 ;--------------------------------------------------------
                                    549 ; uninitialized external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area XSEG    (XDATA)
      000598                        552 _source_state:
      000598                        553 	.ds 130
      00061A                        554 _pending_time:
      00061A                        555 	.ds 2
      00061C                        556 _pending_code:
      00061C                        557 	.ds 2
      00061E                        558 _source_PARM_1:
      00061E                        559 	.ds 2
      000620                        560 _hold_PARM_2:
      000620                        561 	.ds 1
      000621                        562 _hold_code_10000_597:
      000621                        563 	.ds 2
      000623                        564 _hold_mods_30000_600:
      000623                        565 	.ds 1
      000624                        566 _commit_pending_id_10000_606:
      000624                        567 	.ds 1
      000625                        568 _ak820_tapping_before_event_10000_607:
      000625                        569 	.ds 2
      000627                        570 _ak820_tapping_process_record_10000_618:
      000627                        571 	.ds 2
                                    572 ;--------------------------------------------------------
                                    573 ; absolute external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area XABS    (ABS,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; initialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XISEG   (XDATA)
      000D74                        580 _pending:
      000D74                        581 	.ds 1
                                    582 	.area HOME    (CODE)
                                    583 	.area GSINIT0 (CODE)
                                    584 	.area GSINIT1 (CODE)
                                    585 	.area GSINIT2 (CODE)
                                    586 	.area GSINIT3 (CODE)
                                    587 	.area GSINIT4 (CODE)
                                    588 	.area GSINIT5 (CODE)
                                    589 	.area GSINIT  (CODE)
                                    590 	.area GSFINAL (CODE)
                                    591 	.area CSEG    (CODE)
                                    592 ;--------------------------------------------------------
                                    593 ; global & static initialisations
                                    594 ;--------------------------------------------------------
                                    595 	.area HOME    (CODE)
                                    596 	.area GSINIT  (CODE)
                                    597 	.area GSFINAL (CODE)
                                    598 	.area GSINIT  (CODE)
                                    599 ;--------------------------------------------------------
                                    600 ; Home
                                    601 ;--------------------------------------------------------
                                    602 	.area HOME    (CODE)
                                    603 	.area HOME    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; code
                                    606 ;--------------------------------------------------------
                                    607 	.area CSEG    (CODE)
                                    608 ;------------------------------------------------------------
                                    609 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    610 ;------------------------------------------------------------
                                    611 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    612 ;------------------------------------------------------------
                                    613 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    614 ;	-----------------------------------------
                           000007   615 	ar7 = 0x07
                           000006   616 	ar6 = 0x06
                           000005   617 	ar5 = 0x05
                           000004   618 	ar4 = 0x04
                           000003   619 	ar3 = 0x03
                           000002   620 	ar2 = 0x02
                           000001   621 	ar1 = 0x01
                           000000   622 	ar0 = 0x00
                                    623 ;	 function source
                                    624 ;	-----------------------------------------
      004355                        625 _source:
                                    626 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004355 90 06 1F         [24]  627 	mov	dptr,#(_source_PARM_1 + 0x0001)
      004358 E0               [24]  628 	movx	a,@dptr
      004359 FF               [12]  629 	mov	r7,a
      00435A BF 10 00         [24]  630 	cjne	r7,#0x10,00147$
      00435D                        631 00147$:
      00435D 50 14            [24]  632 	jnc	00102$
      00435F 90 06 1E         [24]  633 	mov	dptr,#_source_PARM_1
      004362 E0               [24]  634 	movx	a,@dptr
      004363 FE               [12]  635 	mov	r6,a
      004364 BE 08 00         [24]  636 	cjne	r6,#0x08,00149$
      004367                        637 00149$:
      004367 50 0A            [24]  638 	jnc	00102$
      004369 8F 05            [24]  639 	mov	ar5,r7
      00436B ED               [12]  640 	mov	a,r5
      00436C 12 38 83         [24]  641 	lcall	_ak820_outline_0178
      00436F 2E               [12]  642 	add	a,r6
      004370 F5 82            [12]  643 	mov	dpl,a
      004372 22               [24]  644 	ret
      004373                        645 00102$:
                                    646 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      004373 90 06 1E         [24]  647 	mov	dptr,#_source_PARM_1
      004376 E0               [24]  648 	movx	a,@dptr
      004377 FE               [12]  649 	mov	r6,a
      004378 BE 01 00         [24]  650 	cjne	r6,#0x01,00151$
      00437B                        651 00151$:
      00437B 50 0E            [24]  652 	jnc	00109$
                                    653 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      00437D BF FD 04         [24]  654 	cjne	r7,#0xfd,00105$
      004380 75 82 80         [24]  655 	mov	dpl, #0x80
      004383 22               [24]  656 	ret
      004384                        657 00105$:
                                    658 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004384 BF FC 04         [24]  659 	cjne	r7,#0xfc,00109$
      004387 75 82 81         [24]  660 	mov	dpl, #0x81
      00438A 22               [24]  661 	ret
      00438B                        662 00109$:
                                    663 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      00438B 75 82 FF         [24]  664 	mov	dpl, #0xff
                                    665 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      00438E 22               [24]  666 	ret
                                    667 ;------------------------------------------------------------
                                    668 ;Allocation info for local variables in function 'hold'
                                    669 ;------------------------------------------------------------
                                    670 ;pressed       Allocated with name '_hold_PARM_2'
                                    671 ;code          Allocated with name '_hold_code_10000_597'
                                    672 ;mods          Allocated with name '_hold_mods_30000_600'
                                    673 ;layer         Allocated with name '_hold_layer_30000_603'
                                    674 ;------------------------------------------------------------
                                    675 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    676 ;	-----------------------------------------
                                    677 ;	 function hold
                                    678 ;	-----------------------------------------
      00438F                        679 _hold:
      00438F 12 38 47         [24]  680 	lcall	_ak820_outline_0100
      004392 90 06 21         [24]  681 	mov	dptr,#_hold_code_10000_597
      004395 12 38 42         [24]  682 	lcall	_ak820_outline_0099
                                    683 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004398 90 06 21         [24]  684 	mov	dptr,#_hold_code_10000_597
      00439B 12 37 CD         [24]  685 	lcall	_ak820_outline_0009
      00439E 74 C0            [12]  686 	mov	a,#0x100 - 0x40
      0043A0 2D               [12]  687 	add	a,r5
      0043A1 40 2E            [24]  688 	jc	00110$
                                    689 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      0043A3 8F 05            [24]  690 	mov	ar5,r7
      0043A5 53 05 1F         [24]  691 	anl	ar5,#0x1f
      0043A8 90 06 23         [24]  692 	mov	dptr,#_hold_mods_30000_600
      0043AB ED               [12]  693 	mov	a,r5
      0043AC F0               [24]  694 	movx	@dptr,a
                                    695 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      0043AD ED               [12]  696 	mov	a,r5
      0043AE 30 E4 08         [24]  697 	jnb	acc.4,00102$
      0043B1 ED               [12]  698 	mov	a,r5
      0043B2 C4               [12]  699 	swap	a
      0043B3 54 F0            [12]  700 	anl	a,#0xf0
      0043B5 90 06 23         [24]  701 	mov	dptr,#_hold_mods_30000_600
      0043B8 F0               [24]  702 	movx	@dptr,a
      0043B9                        703 00102$:
                                    704 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      0043B9 90 06 20         [24]  705 	mov	dptr,#_hold_PARM_2
      0043BC E0               [24]  706 	movx	a,@dptr
      0043BD 60 09            [24]  707 	jz	00104$
      0043BF 90 06 23         [24]  708 	mov	dptr,#_hold_mods_30000_600
      0043C2 E0               [24]  709 	movx	a,@dptr
      0043C3 F5 82            [12]  710 	mov	dpl,a
      0043C5 02 72 F4         [24]  711 	ljmp	_register_mods
      0043C8                        712 00104$:
                                    713 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      0043C8 90 06 23         [24]  714 	mov	dptr,#_hold_mods_30000_600
      0043CB E0               [24]  715 	movx	a,@dptr
      0043CC F5 82            [12]  716 	mov	dpl,a
      0043CE 02 73 08         [24]  717 	ljmp	_unregister_mods
      0043D1                        718 00110$:
                                    719 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      0043D1 8F 06            [24]  720 	mov	ar6,r7
      0043D3 74 0F            [12]  721 	mov	a,#0x0f
      0043D5 5E               [12]  722 	anl	a,r6
      0043D6 FF               [12]  723 	mov	r7,a
                                    724 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      0043D7 90 06 20         [24]  725 	mov	dptr,#_hold_PARM_2
      0043DA E0               [24]  726 	movx	a,@dptr
      0043DB 60 05            [24]  727 	jz	00107$
      0043DD 8F 82            [24]  728 	mov	dpl, r7
      0043DF 02 74 AF         [24]  729 	ljmp	_layer_hold_on
      0043E2                        730 00107$:
                                    731 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      0043E2 8F 82            [24]  732 	mov	dpl, r7
                                    733 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0043E4 02 74 E7         [24]  734 	ljmp	_layer_hold_off
                                    735 ;------------------------------------------------------------
                                    736 ;Allocation info for local variables in function 'commit_pending'
                                    737 ;------------------------------------------------------------
                                    738 ;id            Allocated with name '_commit_pending_id_10000_606'
                                    739 ;------------------------------------------------------------
                                    740 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    741 ;	-----------------------------------------
                                    742 ;	 function commit_pending
                                    743 ;	-----------------------------------------
      0043E7                        744 _commit_pending:
                                    745 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      0043E7 90 0D 74         [24]  746 	mov	dptr,#_pending
      0043EA E0               [24]  747 	movx	a,@dptr
      0043EB 90 06 24         [24]  748 	mov	dptr,#_commit_pending_id_10000_606
      0043EE F0               [24]  749 	movx	@dptr,a
                                    750 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      0043EF 12 46 A0         [24]  751 	lcall	_ak820_outline_0143
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      0043F2 90 06 24         [24]  753 	mov	dptr,#_commit_pending_id_10000_606
      0043F5 E0               [24]  754 	movx	a,@dptr
      0043F6 24 98            [12]  755 	add	a,#_source_state
      0043F8 FF               [12]  756 	mov	r7,a
      0043F9 E4               [12]  757 	clr	a
      0043FA 34 05            [12]  758 	addc	a, #(_source_state >> 8)
      0043FC FE               [12]  759 	mov	r6,a
      0043FD 12 43 3F         [24]  760 	lcall	_ak820_outline_0147
      004400 E0               [24]  761 	movx	a,@dptr
      004401 FD               [12]  762 	mov	r5,a
      004402 43 05 04         [24]  763 	orl	ar5,#0x04
      004405 12 43 3F         [24]  764 	lcall	_ak820_outline_0147
      004408 ED               [12]  765 	mov	a,r5
      004409 F0               [24]  766 	movx	@dptr,a
                                    767 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      00440A 90 06 1C         [24]  768 	mov	dptr,#_pending_code
      00440D 12 37 F9         [24]  769 	lcall	_ak820_outline_0047
      004410 90 06 20         [24]  770 	mov	dptr,#_hold_PARM_2
      004413 74 01            [12]  771 	mov	a,#0x01
      004415 12 42 F6         [24]  772 	lcall	_ak820_outline_0057
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004418 02 43 8F         [24]  774 	ljmp	_hold
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    777 ;------------------------------------------------------------
                                    778 ;event         Allocated with name '_ak820_tapping_before_event_10000_607'
                                    779 ;id            Allocated with name '_ak820_tapping_before_id_10000_608'
                                    780 ;------------------------------------------------------------
                                    781 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    782 ;	-----------------------------------------
                                    783 ;	 function ak820_tapping_before
                                    784 ;	-----------------------------------------
      00441B                        785 _ak820_tapping_before:
      00441B 12 38 47         [24]  786 	lcall	_ak820_outline_0100
      00441E 90 06 25         [24]  787 	mov	dptr,#_ak820_tapping_before_event_10000_607
      004421 12 38 42         [24]  788 	lcall	_ak820_outline_0099
                                    789 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004424 90 06 25         [24]  790 	mov	dptr,#_ak820_tapping_before_event_10000_607
      004427 12 37 CD         [24]  791 	lcall	_ak820_outline_0009
      00442A 12 46 57         [24]  792 	lcall	_ak820_outline_0021
      00442D C0 07            [24]  793 	push	ar7
      00442F C0 06            [24]  794 	push	ar6
      004431 12 B3 6C         [24]  795 	lcall	___memcpy
      004434 12 43 55         [24]  796 	lcall	_source
      004437 AD 82            [24]  797 	mov	r5, dpl
      004439 D0 06            [24]  798 	pop	ar6
      00443B D0 07            [24]  799 	pop	ar7
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      00443D 90 0D E4         [24]  801 	mov	dptr,#_vial_unlock_in_progress
      004440 E0               [24]  802 	movx	a,@dptr
      004441 60 29            [24]  803 	jz	00106$
                                    804 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004443 74 04            [12]  805 	mov	a,#0x04
      004445 12 46 4C         [24]  806 	lcall	_ak820_outline_0015
      004448 60 1E            [24]  807 	jz	00102$
      00444A BD FF 02         [24]  808 	cjne	r5,#0xff,00218$
      00444D 80 19            [24]  809 	sjmp	00102$
      00444F                        810 00218$:
      00444F 74 05            [12]  811 	mov	a,#0x05
      004451 12 46 4C         [24]  812 	lcall	_ak820_outline_0015
      004454 70 12            [24]  813 	jnz	00102$
      004456 ED               [12]  814 	mov	a,r5
      004457 24 98            [12]  815 	add	a, #_source_state
      004459 FB               [12]  816 	mov	r3,a
      00445A E4               [12]  817 	clr	a
      00445B 34 05            [12]  818 	addc	a, #(_source_state >> 8)
      00445D 12 46 7C         [24]  819 	lcall	_ak820_outline_0051
      004460 53 02 FD         [24]  820 	anl	ar2,#0xfd
      004463 12 33 FC         [24]  821 	lcall	_ak820_outline_0116
      004466 EA               [12]  822 	mov	a,r2
      004467 F0               [24]  823 	movx	@dptr,a
      004468                        824 00102$:
                                    825 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004468 75 82 00         [24]  826 	mov	dpl, #0x00
      00446B 22               [24]  827 	ret
      00446C                        828 00106$:
                                    829 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      00446C 90 0D 74         [24]  830 	mov	dptr,#_pending
      00446F E0               [24]  831 	movx	a,@dptr
      004470 FC               [12]  832 	mov	r4,a
      004471 BC FF 02         [24]  833 	cjne	r4,#0xff,00220$
      004474 80 3B            [24]  834 	sjmp	00108$
      004476                        835 00220$:
      004476 12 37 F1         [24]  836 	lcall	_ak820_outline_0031
      004479 FA               [12]  837 	mov	r2,a
      00447A A3               [24]  838 	inc	dptr
      00447B E0               [24]  839 	movx	a,@dptr
      00447C FB               [12]  840 	mov	r3,a
      00447D 90 06 1A         [24]  841 	mov	dptr,#_pending_time
      004480 12 38 36         [24]  842 	lcall	_ak820_outline_0092
      004483 EA               [12]  843 	mov	a,r2
      004484 C3               [12]  844 	clr	c
      004485 98               [12]  845 	subb	a,r0
      004486 FA               [12]  846 	mov	r2,a
      004487 EB               [12]  847 	mov	a,r3
      004488 99               [12]  848 	subb	a,r1
      004489 FB               [12]  849 	mov	r3,a
      00448A C3               [12]  850 	clr	c
      00448B EA               [12]  851 	mov	a,r2
      00448C 94 C8            [12]  852 	subb	a,#0xc8
      00448E EB               [12]  853 	mov	a,r3
      00448F 94 00            [12]  854 	subb	a,#0x00
      004491 50 17            [24]  855 	jnc	00107$
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004493 74 04            [12]  857 	mov	a,#0x04
      004495 12 46 71         [24]  858 	lcall	_ak820_outline_0043
      004498 60 17            [24]  859 	jz	00108$
      00449A 12 37 AC         [24]  860 	lcall	_ak820_outline_0005
      00449D 60 12            [24]  861 	jz	00108$
      00449F BD FF 02         [24]  862 	cjne	r5,#0xff,00224$
      0044A2 80 06            [24]  863 	sjmp	00107$
      0044A4                        864 00224$:
      0044A4 ED               [12]  865 	mov	a,r5
      0044A5 B5 04 02         [24]  866 	cjne	a,ar4,00225$
      0044A8 80 07            [24]  867 	sjmp	00108$
      0044AA                        868 00225$:
      0044AA                        869 00107$:
      0044AA C0 05            [24]  870 	push	ar5
      0044AC 12 43 E7         [24]  871 	lcall	_commit_pending
      0044AF D0 05            [24]  872 	pop	ar5
      0044B1                        873 00108$:
                                    874 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      0044B1 90 06 25         [24]  875 	mov	dptr,#_ak820_tapping_before_event_10000_607
      0044B4 12 37 F9         [24]  876 	lcall	_ak820_outline_0047
      0044B7 74 04            [12]  877 	mov	a,#0x04
      0044B9 12 46 4C         [24]  878 	lcall	_ak820_outline_0015
      0044BC 60 03            [24]  879 	jz	00114$
      0044BE BD FF 04         [24]  880 	cjne	r5,#0xff,00115$
      0044C1                        881 00114$:
      0044C1 75 82 01         [24]  882 	mov	dpl, #0x01
      0044C4 22               [24]  883 	ret
      0044C5                        884 00115$:
                                    885 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      0044C5 ED               [12]  886 	mov	a,r5
      0044C6 24 98            [12]  887 	add	a, #_source_state
      0044C8 FC               [12]  888 	mov	r4,a
      0044C9 E4               [12]  889 	clr	a
      0044CA 34 05            [12]  890 	addc	a, #(_source_state >> 8)
      0044CC FD               [12]  891 	mov	r5,a
      0044CD 12 42 FC         [24]  892 	lcall	_ak820_outline_0083
      0044D0 FB               [12]  893 	mov	r3,a
      0044D1 30 E1 13         [24]  894 	jnb	acc.1,00120$
                                    895 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0044D4 74 05            [12]  896 	mov	a,#0x05
      0044D6 2E               [12]  897 	add	a, r6
      0044D7 12 37 D7         [24]  898 	lcall	_ak820_outline_0012
      0044DA 70 07            [24]  899 	jnz	00118$
      0044DC 74 FD            [12]  900 	mov	a,#0xfd
      0044DE 5B               [12]  901 	anl	a,r3
      0044DF 12 38 53         [24]  902 	lcall	_ak820_outline_0112
      0044E2 F0               [24]  903 	movx	@dptr,a
      0044E3                        904 00118$:
                                    905 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      0044E3 75 82 00         [24]  906 	mov	dpl, #0x00
      0044E6 22               [24]  907 	ret
      0044E7                        908 00120$:
                                    909 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      0044E7 12 42 C0         [24]  910 	lcall	_ak820_outline_0011
      0044EA E0               [24]  911 	movx	a,@dptr
      0044EB FF               [12]  912 	mov	r7,a
      0044EC 8B 06            [24]  913 	mov	ar6,r3
      0044EE 53 06 01         [24]  914 	anl	ar6,#0x01
      0044F1 EE               [12]  915 	mov	a,r6
      0044F2 B4 01 00         [24]  916 	cjne	a,#0x01,00231$
      0044F5                        917 00231$:
      0044F5 B3               [12]  918 	cpl	c
      0044F6 92 0C            [24]  919 	mov	_ak820_tapping_before_sloc0_1_0,c
      0044F8 8F F0            [24]  920 	mov	b,r7
      0044FA E4               [12]  921 	clr	a
      0044FB 33               [12]  922 	rlc	a
      0044FC B5 F0 04         [24]  923 	cjne	a,b,00122$
      0044FF 75 82 00         [24]  924 	mov	dpl, #0x00
      004502 22               [24]  925 	ret
      004503                        926 00122$:
                                    927 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004503 63 03 01         [24]  928 	xrl	ar3,#0x01
      004506 12 38 53         [24]  929 	lcall	_ak820_outline_0112
      004509 EB               [12]  930 	mov	a,r3
      00450A F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      00450B 75 82 01         [24]  933 	mov	dpl, #0x01
                                    934 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      00450E 22               [24]  935 	ret
                                    936 ;------------------------------------------------------------
                                    937 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    938 ;------------------------------------------------------------
                                    939 ;sloc0         Allocated with name '_ak820_tapping_process_sloc0_1_0'
                                    940 ;record        Allocated with name '_ak820_tapping_process_record_10000_618'
                                    941 ;id            Allocated with name '_ak820_tapping_process_id_10000_619'
                                    942 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_619'
                                    943 ;code          Allocated with name '_ak820_tapping_process_code_10000_619'
                                    944 ;------------------------------------------------------------
                                    945 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function ak820_tapping_process
                                    948 ;	-----------------------------------------
      00450F                        949 _ak820_tapping_process:
      00450F 12 38 47         [24]  950 	lcall	_ak820_outline_0100
      004512 90 06 27         [24]  951 	mov	dptr,#_ak820_tapping_process_record_10000_618
      004515 12 38 42         [24]  952 	lcall	_ak820_outline_0099
                                    953 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004518 90 06 27         [24]  954 	mov	dptr,#_ak820_tapping_process_record_10000_618
      00451B 12 37 F9         [24]  955 	lcall	_ak820_outline_0047
      00451E 74 04            [12]  956 	mov	a,#0x04
      004520 12 46 41         [24]  957 	lcall	_ak820_outline_0010
      004523 70 04            [24]  958 	jnz	00102$
      004525 75 82 01         [24]  959 	mov	dpl, #0x01
      004528 22               [24]  960 	ret
      004529                        961 00102$:
                                    962 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004529 8E 04            [24]  963 	mov	ar4,r6
      00452B 8F 05            [24]  964 	mov	ar5,r7
      00452D 12 46 57         [24]  965 	lcall	_ak820_outline_0021
      004530 C0 07            [24]  966 	push	ar7
      004532 C0 06            [24]  967 	push	ar6
      004534 12 B3 6C         [24]  968 	lcall	___memcpy
      004537 12 43 55         [24]  969 	lcall	_source
      00453A AD 82            [24]  970 	mov	r5, dpl
      00453C D0 06            [24]  971 	pop	ar6
      00453E D0 07            [24]  972 	pop	ar7
                                    973 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004540 BD FF 04         [24]  974 	cjne	r5,#0xff,00104$
      004543 75 82 01         [24]  975 	mov	dpl, #0x01
      004546 22               [24]  976 	ret
      004547                        977 00104$:
                                    978 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004547 74 07            [12]  979 	mov	a,#0x07
      004549 12 37 E9         [24]  980 	lcall	_ak820_outline_0018
      00454C E0               [24]  981 	movx	a,@dptr
      00454D F5 15            [12]  982 	mov	_ak820_tapping_process_sloc0_1_0,a
      00454F A3               [24]  983 	inc	dptr
      004550 E0               [24]  984 	movx	a,@dptr
      004551 F5 16            [12]  985 	mov	(_ak820_tapping_process_sloc0_1_0 + 1),a
                                    986 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004553 AC 16            [24]  987 	mov	r4,(_ak820_tapping_process_sloc0_1_0 + 1)
                                    988 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004555 BC 20 00         [24]  989 	cjne	r4,#0x20,00189$
      004558                        990 00189$:
      004558 40 05            [24]  991 	jc	00105$
      00455A BC 50 00         [24]  992 	cjne	r4,#0x50,00191$
      00455D                        993 00191$:
      00455D 40 04            [24]  994 	jc	00106$
      00455F                        995 00105$:
      00455F 75 82 01         [24]  996 	mov	dpl, #0x01
      004562 22               [24]  997 	ret
      004563                        998 00106$:
                                    999 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004563 BC 40 00         [24] 1000 	cjne	r4,#0x40,00193$
      004566                       1001 00193$:
      004566 40 0C            [24] 1002 	jc	00109$
      004568 53 04 0F         [24] 1003 	anl	ar4,#0x0f
      00456B BC 06 00         [24] 1004 	cjne	r4,#0x06,00195$
      00456E                       1005 00195$:
      00456E 40 04            [24] 1006 	jc	00109$
      004570 75 82 00         [24] 1007 	mov	dpl, #0x00
      004573 22               [24] 1008 	ret
      004574                       1009 00109$:
                                   1010 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004574 90 06 27         [24] 1011 	mov	dptr,#_ak820_tapping_process_record_10000_618
      004577 12 38 3C         [24] 1012 	lcall	_ak820_outline_0094
      00457A 74 05            [12] 1013 	mov	a,#0x05
      00457C 2B               [12] 1014 	add	a, r3
      00457D F9               [12] 1015 	mov	r1,a
      00457E E4               [12] 1016 	clr	a
      00457F 3C               [12] 1017 	addc	a, r4
      004580 FA               [12] 1018 	mov	r2,a
      004581 12 43 3A         [24] 1019 	lcall	_ak820_outline_0146
      004584 E0               [24] 1020 	movx	a,@dptr
      004585 60 22            [24] 1021 	jz	00119$
                                   1022 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004587 90 0D 74         [24] 1023 	mov	dptr,#_pending
      00458A ED               [12] 1024 	mov	a,r5
      00458B 12 46 9A         [24] 1025 	lcall	_ak820_outline_0114
                                   1026 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      00458E A3               [24] 1027 	inc	dptr
      00458F A3               [24] 1028 	inc	dptr
      004590 E0               [24] 1029 	movx	a,@dptr
      004591 F8               [12] 1030 	mov	r0,a
      004592 A3               [24] 1031 	inc	dptr
      004593 E0               [24] 1032 	movx	a,@dptr
      004594 FF               [12] 1033 	mov	r7,a
      004595 90 06 1A         [24] 1034 	mov	dptr,#_pending_time
      004598 E8               [12] 1035 	mov	a,r0
      004599 12 38 42         [24] 1036 	lcall	_ak820_outline_0099
                                   1037 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      00459C 90 06 1C         [24] 1038 	mov	dptr,#_pending_code
      00459F E5 15            [12] 1039 	mov	a,_ak820_tapping_process_sloc0_1_0
      0045A1 F0               [24] 1040 	movx	@dptr,a
      0045A2 E5 16            [12] 1041 	mov	a,(_ak820_tapping_process_sloc0_1_0 + 1)
      0045A4 A3               [24] 1042 	inc	dptr
      0045A5 F0               [24] 1043 	movx	@dptr,a
      0045A6 02 46 15         [24] 1044 	ljmp	00120$
      0045A9                       1045 00119$:
                                   1046 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      0045A9 90 0D 74         [24] 1047 	mov	dptr,#_pending
      0045AC E0               [24] 1048 	movx	a,@dptr
      0045AD FF               [12] 1049 	mov	r7,a
      0045AE ED               [12] 1050 	mov	a,r5
      0045AF B5 07 3E         [24] 1051 	cjne	a,ar7,00116$
                                   1052 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      0045B2 12 46 A0         [24] 1053 	lcall	_ak820_outline_0143
                                   1054 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      0045B5 74 07            [12] 1055 	mov	a,#0x07
      0045B7 12 46 92         [24] 1056 	lcall	_ak820_outline_0108
      0045BA AE 15            [24] 1057 	mov	r6,_ak820_tapping_process_sloc0_1_0
      0045BC 7F 00            [12] 1058 	mov	r7,#0x00
      0045BE 12 46 8C         [24] 1059 	lcall	_ak820_outline_0055
                                   1060 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      0045C1 C3               [12] 1061 	clr	c
      0045C2 04               [12] 1062 	inc	a
      0045C3 9E               [12] 1063 	subb	a,r6
      0045C4 50 4F            [24] 1064 	jnc	00120$
                                   1065 ;	free result
                                   1066 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      0045C6 74 06            [12] 1067 	mov	a,#0x06
      0045C8 12 46 92         [24] 1068 	lcall	_ak820_outline_0108
      0045CB E0               [24] 1069 	movx	a,@dptr
      0045CC 54 0F            [12] 1070 	anl	a,#0x0f
      0045CE 44 10            [12] 1071 	orl	a,#0x10
      0045D0 F0               [24] 1072 	movx	@dptr,a
                                   1073 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      0045D1 12 43 3A         [24] 1074 	lcall	_ak820_outline_0146
      0045D4 74 01            [12] 1075 	mov	a,#0x01
      0045D6 12 46 9A         [24] 1076 	lcall	_ak820_outline_0114
                                   1077 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      0045D9 12 6E 6A         [24] 1078 	lcall	_process_record
                                   1079 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      0045DC 90 06 27         [24] 1080 	mov	dptr,#_ak820_tapping_process_record_10000_618
      0045DF 12 37 A2         [24] 1081 	lcall	_ak820_outline_0004
      0045E2 A3               [24] 1082 	inc	dptr
      0045E3 A3               [24] 1083 	inc	dptr
      0045E4 A3               [24] 1084 	inc	dptr
      0045E5 A3               [24] 1085 	inc	dptr
      0045E6 A3               [24] 1086 	inc	dptr
      0045E7 E4               [12] 1087 	clr	a
      0045E8 12 42 F6         [24] 1088 	lcall	_ak820_outline_0057
                                   1089 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      0045EB 12 6E 6A         [24] 1090 	lcall	_process_record
      0045EE 80 25            [24] 1091 	sjmp	00120$
      0045F0                       1092 00116$:
                                   1093 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      0045F0 ED               [12] 1094 	mov	a,r5
      0045F1 24 98            [12] 1095 	add	a, #_source_state
      0045F3 FE               [12] 1096 	mov	r6,a
      0045F4 E4               [12] 1097 	clr	a
      0045F5 34 05            [12] 1098 	addc	a, #(_source_state >> 8)
      0045F7 FF               [12] 1099 	mov	r7,a
      0045F8 12 38 30         [24] 1100 	lcall	_ak820_outline_0090
      0045FB FD               [12] 1101 	mov	r5,a
      0045FC 30 E2 16         [24] 1102 	jnb	acc.2,00120$
                                   1103 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      0045FF 53 05 FB         [24] 1104 	anl	ar5,#0xfb
      004602 12 43 1A         [24] 1105 	lcall	_ak820_outline_0111
      004605 ED               [12] 1106 	mov	a,r5
      004606 F0               [24] 1107 	movx	@dptr,a
                                   1108 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004607 90 06 20         [24] 1109 	mov	dptr,#_hold_PARM_2
      00460A E4               [12] 1110 	clr	a
      00460B F0               [24] 1111 	movx	@dptr,a
      00460C 85 15 82         [24] 1112 	mov	dpl, _ak820_tapping_process_sloc0_1_0
      00460F 85 16 83         [24] 1113 	mov	dph, (_ak820_tapping_process_sloc0_1_0 + 1)
      004612 12 43 8F         [24] 1114 	lcall	_hold
      004615                       1115 00120$:
                                   1116 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004615 75 82 00         [24] 1117 	mov	dpl, #0x00
                                   1118 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004618 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1122 ;------------------------------------------------------------
                                   1123 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_634'
                                   1124 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_635'
                                   1125 ;------------------------------------------------------------
                                   1126 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1127 ;	-----------------------------------------
                                   1128 ;	 function ak820_tapping_cancel
                                   1129 ;	-----------------------------------------
      004619                       1130 _ak820_tapping_cancel:
                                   1131 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004619 12 46 A0         [24] 1132 	lcall	_ak820_outline_0143
                                   1133 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      00461C 7F 00            [12] 1134 	mov	r7,#0x00
      00461E                       1135 00103$:
      00461E BF 82 00         [24] 1136 	cjne	r7,#0x82,00122$
      004621                       1137 00122$:
      004621 50 1D            [24] 1138 	jnc	00105$
                                   1139 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004623 EF               [12] 1140 	mov	a,r7
      004624 24 98            [12] 1141 	add	a, #_source_state
      004626 FD               [12] 1142 	mov	r5,a
      004627 E4               [12] 1143 	clr	a
      004628 34 05            [12] 1144 	addc	a, #(_source_state >> 8)
      00462A 12 46 84         [24] 1145 	lcall	_ak820_outline_0053
                                   1146 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      00462D 74 02            [12] 1147 	mov	a,#0x02
      00462F 5C               [12] 1148 	anl	a,r4
      004630 FB               [12] 1149 	mov	r3,a
      004631 53 04 01         [24] 1150 	anl	ar4,#0x01
      004634 EC               [12] 1151 	mov	a,r4
      004635 2C               [12] 1152 	add	a,r4
      004636 42 03            [12] 1153 	orl	ar3,a
      004638 12 38 5D         [24] 1154 	lcall	_ak820_outline_0124
      00463B EB               [12] 1155 	mov	a,r3
      00463C F0               [24] 1156 	movx	@dptr,a
                                   1157 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      00463D 0F               [12] 1158 	inc	r7
      00463E 80 DE            [24] 1159 	sjmp	00103$
      004640                       1160 00105$:
                                   1161 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004640 22               [24] 1162 	ret
                                   1163 	.area CSEG    (CODE)
                                   1164 	.area CONST   (CODE)
                                   1165 	.area XINIT   (CODE)
      00BC2C                       1166 __xinit__pending:
      00BC2C FF                    1167 	.db #0xff	; 255
                                   1168 	.area CABS    (ABS,CODE)
                                   1169 
                                   1170 ; Experimental exact instruction outlining.
                                   1171 	.globl _ak820_outline_0004
                                   1172 	.globl _ak820_outline_0005
                                   1173 	.globl _ak820_outline_0009
                                   1174 	.globl _ak820_outline_0010
                                   1175 	.globl _ak820_outline_0011
                                   1176 	.globl _ak820_outline_0012
                                   1177 	.globl _ak820_outline_0015
                                   1178 	.globl _ak820_outline_0018
                                   1179 	.globl _ak820_outline_0021
                                   1180 	.globl _ak820_outline_0031
                                   1181 	.globl _ak820_outline_0043
                                   1182 	.globl _ak820_outline_0047
                                   1183 	.globl _ak820_outline_0051
                                   1184 	.globl _ak820_outline_0053
                                   1185 	.globl _ak820_outline_0055
                                   1186 	.globl _ak820_outline_0057
                                   1187 	.globl _ak820_outline_0083
                                   1188 	.globl _ak820_outline_0090
                                   1189 	.globl _ak820_outline_0092
                                   1190 	.globl _ak820_outline_0094
                                   1191 	.globl _ak820_outline_0099
                                   1192 	.globl _ak820_outline_0100
                                   1193 	.globl _ak820_outline_0108
                                   1194 	.globl _ak820_outline_0111
                                   1195 	.globl _ak820_outline_0112
                                   1196 	.globl _ak820_outline_0114
                                   1197 	.globl _ak820_outline_0116
                                   1198 	.globl _ak820_outline_0124
                                   1199 	.globl _ak820_outline_0143
                                   1200 	.globl _ak820_outline_0146
                                   1201 	.globl _ak820_outline_0147
                                   1202 	.globl _ak820_outline_0178
                                   1203 
                                   1204 	.area CSEG (CODE)
                                   1205 ; function ak820_outline_0010
      004641                       1206 _ak820_outline_0010:
      004641 2E               [12] 1207 	add	a,r6
      004642 FC               [12] 1208 	mov	r4,a
      004643 E4               [12] 1209 	clr	a
      004644 3F               [12] 1210 	addc	a,r7
      004645 FD               [12] 1211 	mov	r5,a
      004646 8C 82            [24] 1212 	mov	dpl,r4
      004648 8D 83            [24] 1213 	mov	dph,r5
      00464A E0               [24] 1214 	movx	a,@dptr
      00464B 22               [24] 1215 	ret
                                   1216 
                                   1217 	.area CSEG (CODE)
                                   1218 ; function ak820_outline_0015
      00464C                       1219 _ak820_outline_0015:
      00464C 2E               [12] 1220 	add	a,r6
      00464D FB               [12] 1221 	mov	r3,a
      00464E E4               [12] 1222 	clr	a
      00464F 3F               [12] 1223 	addc	a,r7
      004650 FC               [12] 1224 	mov	r4,a
      004651 8B 82            [24] 1225 	mov	dpl,r3
      004653 8C 83            [24] 1226 	mov	dph,r4
      004655 E0               [24] 1227 	movx	a,@dptr
      004656 22               [24] 1228 	ret
                                   1229 
                                   1230 	.area CSEG (CODE)
                                   1231 ; function ak820_outline_0021
      004657                       1232 _ak820_outline_0021:
      004657 90 0D 64         [24] 1233 	mov	dptr,#___memcpy_PARM_2
      00465A EC               [12] 1234 	mov	a,r4
      00465B F0               [24] 1235 	movx	@dptr,a
      00465C ED               [12] 1236 	mov	a,r5
      00465D A3               [24] 1237 	inc	dptr
      00465E F0               [24] 1238 	movx	@dptr,a
      00465F E4               [12] 1239 	clr	a
      004660 A3               [24] 1240 	inc	dptr
      004661 F0               [24] 1241 	movx	@dptr,a
      004662 90 0D 67         [24] 1242 	mov	dptr,#___memcpy_PARM_3
      004665 74 02            [12] 1243 	mov	a,#0x02
      004667 F0               [24] 1244 	movx	@dptr,a
      004668 E4               [12] 1245 	clr	a
      004669 A3               [24] 1246 	inc	dptr
      00466A F0               [24] 1247 	movx	@dptr,a
      00466B 90 06 1E         [24] 1248 	mov	dptr,#_source_PARM_1
      00466E F5 F0            [12] 1249 	mov	b,a
      004670 22               [24] 1250 	ret
                                   1251 
                                   1252 	.area CSEG (CODE)
                                   1253 ; function ak820_outline_0043
      004671                       1254 _ak820_outline_0043:
      004671 2E               [12] 1255 	add	a,r6
      004672 FA               [12] 1256 	mov	r2,a
      004673 E4               [12] 1257 	clr	a
      004674 3F               [12] 1258 	addc	a,r7
      004675 FB               [12] 1259 	mov	r3,a
      004676 8A 82            [24] 1260 	mov	dpl,r2
      004678 8B 83            [24] 1261 	mov	dph,r3
      00467A E0               [24] 1262 	movx	a,@dptr
      00467B 22               [24] 1263 	ret
                                   1264 
                                   1265 	.area CSEG (CODE)
                                   1266 ; function ak820_outline_0051
      00467C                       1267 _ak820_outline_0051:
      00467C FC               [12] 1268 	mov	r4,a
      00467D 8B 82            [24] 1269 	mov	dpl,r3
      00467F 8C 83            [24] 1270 	mov	dph,r4
      004681 E0               [24] 1271 	movx	a,@dptr
      004682 FA               [12] 1272 	mov	r2,a
      004683 22               [24] 1273 	ret
                                   1274 
                                   1275 	.area CSEG (CODE)
                                   1276 ; function ak820_outline_0053
      004684                       1277 _ak820_outline_0053:
      004684 FE               [12] 1278 	mov	r6,a
      004685 8D 82            [24] 1279 	mov	dpl,r5
      004687 8E 83            [24] 1280 	mov	dph,r6
      004689 E0               [24] 1281 	movx	a,@dptr
      00468A FC               [12] 1282 	mov	r4,a
      00468B 22               [24] 1283 	ret
                                   1284 
                                   1285 	.area CSEG (CODE)
                                   1286 ; function ak820_outline_0055
      00468C                       1287 _ak820_outline_0055:
      00468C EE               [12] 1288 	mov	a,r6
      00468D F0               [24] 1289 	movx	@dptr,a
      00468E EF               [12] 1290 	mov	a,r7
      00468F A3               [24] 1291 	inc	dptr
      004690 F0               [24] 1292 	movx	@dptr,a
      004691 22               [24] 1293 	ret
                                   1294 
                                   1295 	.area CSEG (CODE)
                                   1296 ; function ak820_outline_0108
      004692                       1297 _ak820_outline_0108:
      004692 2B               [12] 1298 	add	a,r3
      004693 F5 82            [12] 1299 	mov	dpl,a
      004695 E4               [12] 1300 	clr	a
      004696 3C               [12] 1301 	addc	a,r4
      004697 F5 83            [12] 1302 	mov	dph,a
      004699 22               [24] 1303 	ret
                                   1304 
                                   1305 	.area CSEG (CODE)
                                   1306 ; function ak820_outline_0114
      00469A                       1307 _ak820_outline_0114:
      00469A F0               [24] 1308 	movx	@dptr,a
      00469B 8B 82            [24] 1309 	mov	dpl,r3
      00469D 8C 83            [24] 1310 	mov	dph,r4
      00469F 22               [24] 1311 	ret
                                   1312 
                                   1313 	.area CSEG (CODE)
                                   1314 ; function ak820_outline_0143
      0046A0                       1315 _ak820_outline_0143:
      0046A0 90 0D 74         [24] 1316 	mov	dptr,#_pending
      0046A3 74 FF            [12] 1317 	mov	a,#0xff
      0046A5 F0               [24] 1318 	movx	@dptr,a
      0046A6 22               [24] 1319 	ret
