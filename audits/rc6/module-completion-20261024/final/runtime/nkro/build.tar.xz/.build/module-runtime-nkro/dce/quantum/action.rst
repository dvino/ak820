                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_tapping_cancel
                                     14 	.globl _ak820_tapping_process
                                     15 	.globl _ak820_tapping_before
                                     16 	.globl _pre_process_record_quantum
                                     17 	.globl _repeat_key_cancel
                                     18 	.globl _clear_owned_usages
                                     19 	.globl _owned_usage_key
                                     20 	.globl _clear_owned_keys
                                     21 	.globl _del_owned_key
                                     22 	.globl _add_owned_key
                                     23 	.globl _clear_owned_mods
                                     24 	.globl _del_owned_weak_mods
                                     25 	.globl _add_owned_weak_mods
                                     26 	.globl _del_owned_mods
                                     27 	.globl _add_owned_mods
                                     28 	.globl _clear_weak_mods
                                     29 	.globl _clear_mods
                                     30 	.globl _send_keyboard_report
                                     31 	.globl _layer_hold_clear
                                     32 	.globl _layer_hold_off
                                     33 	.globl _layer_hold_on
                                     34 	.globl _ak820_resolve_key
                                     35 	.globl _layer_xor
                                     36 	.globl _layer_and
                                     37 	.globl _layer_or
                                     38 	.globl _layer_off
                                     39 	.globl _layer_on
                                     40 	.globl _layer_move
                                     41 	.globl _layer_clear
                                     42 	.globl _layer_state_set
                                     43 	.globl _default_layer_xor
                                     44 	.globl _default_layer_and
                                     45 	.globl _default_layer_or
                                     46 	.globl _default_layer_set
                                     47 	.globl _process_record_quantum
                                     48 	.globl _action_for_keycode
                                     49 	.globl _mDelaymS
                                     50 	.globl _host_consumer_send
                                     51 	.globl _host_system_send
                                     52 	.globl _host_keyboard_leds
                                     53 	.globl _led_set
                                     54 	.globl _clear_keys_from_report
                                     55 	.globl ___memcpy
                                     56 	.globl _ADC_START
                                     57 	.globl _S0_R_FIFO
                                     58 	.globl _S0_T_FIFO
                                     59 	.globl _S0_FREE
                                     60 	.globl _S0_IF_BYTE
                                     61 	.globl _S0_IF_FIRST
                                     62 	.globl _S0_IF_OV
                                     63 	.globl _S0_FST_ACT
                                     64 	.globl _CP_RL2
                                     65 	.globl _C_T2
                                     66 	.globl _TR2
                                     67 	.globl _EXEN2
                                     68 	.globl _TCLK
                                     69 	.globl _RCLK
                                     70 	.globl _EXF2
                                     71 	.globl _CAP1F
                                     72 	.globl _TF2
                                     73 	.globl _RI
                                     74 	.globl _TI
                                     75 	.globl _RB8
                                     76 	.globl _TB8
                                     77 	.globl _REN
                                     78 	.globl _SM2
                                     79 	.globl _SM1
                                     80 	.globl _SM0
                                     81 	.globl _IT0
                                     82 	.globl _IE0
                                     83 	.globl _IT1
                                     84 	.globl _IE1
                                     85 	.globl _TR0
                                     86 	.globl _TF0
                                     87 	.globl _TR1
                                     88 	.globl _TF1
                                     89 	.globl _P4_0
                                     90 	.globl _P4_1
                                     91 	.globl _P4_2
                                     92 	.globl _P4_3
                                     93 	.globl _P4_4
                                     94 	.globl _P4_5
                                     95 	.globl _P4_6
                                     96 	.globl _RXD
                                     97 	.globl _TXD
                                     98 	.globl _INT0
                                     99 	.globl _INT1
                                    100 	.globl _T0
                                    101 	.globl _T1
                                    102 	.globl _MOSI1
                                    103 	.globl _MISO1
                                    104 	.globl _SCK1
                                    105 	.globl _P3_0
                                    106 	.globl _P3_1
                                    107 	.globl _P3_2
                                    108 	.globl _P3_3
                                    109 	.globl _P3_4
                                    110 	.globl _P3_5
                                    111 	.globl _P3_6
                                    112 	.globl _P3_7
                                    113 	.globl _CAP1_
                                    114 	.globl _T2_
                                    115 	.globl _CAP2_
                                    116 	.globl _T2EX_
                                    117 	.globl _RXD1
                                    118 	.globl _TXD1
                                    119 	.globl _P2_0
                                    120 	.globl _P2_1
                                    121 	.globl _P2_2
                                    122 	.globl _P2_3
                                    123 	.globl _P2_4
                                    124 	.globl _P2_5
                                    125 	.globl _P2_6
                                    126 	.globl _P2_7
                                    127 	.globl _AIN0
                                    128 	.globl _AIN1
                                    129 	.globl _AIN2
                                    130 	.globl _AIN3
                                    131 	.globl _AIN4
                                    132 	.globl _AIN5
                                    133 	.globl _AIN6
                                    134 	.globl _AIN7
                                    135 	.globl _CAP1
                                    136 	.globl _T2
                                    137 	.globl _CAP2
                                    138 	.globl _T2EX
                                    139 	.globl _INT0_
                                    140 	.globl _SCS
                                    141 	.globl _MOSI
                                    142 	.globl _MISO
                                    143 	.globl _SCK
                                    144 	.globl _RXD1_
                                    145 	.globl _TXD1_
                                    146 	.globl _P1_0
                                    147 	.globl _P1_1
                                    148 	.globl _P1_2
                                    149 	.globl _P1_3
                                    150 	.globl _P1_4
                                    151 	.globl _P1_5
                                    152 	.globl _P1_6
                                    153 	.globl _P1_7
                                    154 	.globl _AIN8
                                    155 	.globl _AIN9
                                    156 	.globl _AIN10
                                    157 	.globl _AIN11
                                    158 	.globl _AIN12
                                    159 	.globl _AIN13
                                    160 	.globl _RXD_
                                    161 	.globl _TXD_
                                    162 	.globl _SCL0
                                    163 	.globl _SDA0
                                    164 	.globl _P0_0
                                    165 	.globl _P0_1
                                    166 	.globl _P0_2
                                    167 	.globl _P0_3
                                    168 	.globl _P0_4
                                    169 	.globl _P0_5
                                    170 	.globl _P0_6
                                    171 	.globl _P0_7
                                    172 	.globl _IE_SPI0
                                    173 	.globl _IE_USB
                                    174 	.globl _IE_ADC
                                    175 	.globl _IE_UART1
                                    176 	.globl _IE_PWM_I2C
                                    177 	.globl _IE_GPIO
                                    178 	.globl _IE_WDOG
                                    179 	.globl _PX0
                                    180 	.globl _PT0
                                    181 	.globl _PX1
                                    182 	.globl _PT1
                                    183 	.globl _PS
                                    184 	.globl _PT2
                                    185 	.globl _PL_FLAG
                                    186 	.globl _PH_FLAG
                                    187 	.globl _EX0
                                    188 	.globl _ET0
                                    189 	.globl _EX1
                                    190 	.globl _ET1
                                    191 	.globl _ES
                                    192 	.globl _ET2
                                    193 	.globl _E_DIS
                                    194 	.globl _EA
                                    195 	.globl _P
                                    196 	.globl _F1
                                    197 	.globl _OV
                                    198 	.globl _RS0
                                    199 	.globl _RS1
                                    200 	.globl _F0
                                    201 	.globl _AC
                                    202 	.globl _CY
                                    203 	.globl _I2CS_INT_ST
                                    204 	.globl _I2CX_INT
                                    205 	.globl _LED_STATUS
                                    206 	.globl _LED_DMA_H
                                    207 	.globl _LED_DMA_L
                                    208 	.globl _LED_DMA
                                    209 	.globl _LED_PWM_OE
                                    210 	.globl _LED_COMMON
                                    211 	.globl _ADC_CHAN
                                    212 	.globl _ADC_DAT_H
                                    213 	.globl _ADC_DAT_L
                                    214 	.globl _ADC_DAT
                                    215 	.globl _ADC_CTRL
                                    216 	.globl _SPI1_CK_SE
                                    217 	.globl _SPI1_CTRL
                                    218 	.globl _SPI1_DATA
                                    219 	.globl _SPI1_STAT
                                    220 	.globl _SIF1
                                    221 	.globl _SBAUD1
                                    222 	.globl _SBUF1
                                    223 	.globl _SCON1
                                    224 	.globl _SPI0_SETUP
                                    225 	.globl _SPI0_CK_SE
                                    226 	.globl _SPI0_CTRL
                                    227 	.globl _SPI0_DATA
                                    228 	.globl _SPI0_STAT
                                    229 	.globl _T2CAP1H
                                    230 	.globl _T2CAP1L
                                    231 	.globl _T2CAP1
                                    232 	.globl _TH2
                                    233 	.globl _TL2
                                    234 	.globl _T2COUNT
                                    235 	.globl _RCAP2H
                                    236 	.globl _RCAP2L
                                    237 	.globl _RCAP2
                                    238 	.globl _T2MOD
                                    239 	.globl _T2CON
                                    240 	.globl _SBUF
                                    241 	.globl _SCON
                                    242 	.globl _TH1
                                    243 	.globl _TH0
                                    244 	.globl _TL1
                                    245 	.globl _TL0
                                    246 	.globl _TMOD
                                    247 	.globl _TCON
                                    248 	.globl _XBUS_AUX
                                    249 	.globl _P7
                                    250 	.globl _P6_DIR
                                    251 	.globl _P6_OUT_PU
                                    252 	.globl _P6_IN
                                    253 	.globl _P5_DIR
                                    254 	.globl _P5_OUT_PU
                                    255 	.globl _P5_IN
                                    256 	.globl _P4_LED_KEY
                                    257 	.globl _P4_DIR_PU
                                    258 	.globl _P4_MOD_OC
                                    259 	.globl _P4
                                    260 	.globl _P3_DIR_PU
                                    261 	.globl _P3_MOD_OC
                                    262 	.globl _P3
                                    263 	.globl _P2_DIR_PU
                                    264 	.globl _P2_MOD_OC
                                    265 	.globl _P2
                                    266 	.globl _P1_DIR_PU
                                    267 	.globl _P1_MOD_OC
                                    268 	.globl _P1
                                    269 	.globl _P0_DIR_PU
                                    270 	.globl _P0_MOD_OC
                                    271 	.globl _P0
                                    272 	.globl _ROM_CTRL
                                    273 	.globl _ROM_DATA_HH
                                    274 	.globl _ROM_DATA_HL
                                    275 	.globl _ROM_DATA_HI
                                    276 	.globl _ROM_ADDR_H
                                    277 	.globl _ROM_ADDR_L
                                    278 	.globl _ROM_ADDR
                                    279 	.globl _GPIO_IE
                                    280 	.globl _IP_EX
                                    281 	.globl _IE_EX
                                    282 	.globl _IP
                                    283 	.globl _IE
                                    284 	.globl _WDOG_COUNT
                                    285 	.globl _RESET_KEEP
                                    286 	.globl _WAKE_CTRL
                                    287 	.globl _CLOCK_CFG
                                    288 	.globl _POWER_CFG
                                    289 	.globl _PCON
                                    290 	.globl _GLOBAL_CFG
                                    291 	.globl _SAFE_MOD
                                    292 	.globl _DPH
                                    293 	.globl _DPL
                                    294 	.globl _SP
                                    295 	.globl _A_INV
                                    296 	.globl _B
                                    297 	.globl _ACC
                                    298 	.globl _PSW
                                    299 	.globl _disable_action_cache
                                    300 	.globl _tap_code_delay_PARM_2
                                    301 	.globl _process_action_PARM_2
                                    302 	.globl _action_exec_PARM_1
                                    303 	.globl _tp_buttons
                                    304 	.globl _action_exec
                                    305 	.globl _ak820_action_exec
                                    306 	.globl _process_record
                                    307 	.globl _process_record_handler
                                    308 	.globl _process_action
                                    309 	.globl _register_code
                                    310 	.globl _unregister_code
                                    311 	.globl _tap_code_delay
                                    312 	.globl _tap_code
                                    313 	.globl _register_mods
                                    314 	.globl _unregister_mods
                                    315 	.globl _register_weak_mods
                                    316 	.globl _unregister_weak_mods
                                    317 	.globl _clear_keyboard
                                    318 	.globl _clear_keyboard_but_mods
                                    319 	.globl _clear_keyboard_but_mods_and_keys
                                    320 ;--------------------------------------------------------
                                    321 ; special function registers
                                    322 ;--------------------------------------------------------
                                    323 	.area RSEG    (ABS,DATA)
      000000                        324 	.org 0x0000
                           0000D0   325 _PSW	=	0x00d0
                           0000E0   326 _ACC	=	0x00e0
                           0000F0   327 _B	=	0x00f0
                           0000FD   328 _A_INV	=	0x00fd
                           000081   329 _SP	=	0x0081
                           000082   330 _DPL	=	0x0082
                           000083   331 _DPH	=	0x0083
                           0000A1   332 _SAFE_MOD	=	0x00a1
                           0000B1   333 _GLOBAL_CFG	=	0x00b1
                           000087   334 _PCON	=	0x0087
                           0000BA   335 _POWER_CFG	=	0x00ba
                           0000B9   336 _CLOCK_CFG	=	0x00b9
                           0000A9   337 _WAKE_CTRL	=	0x00a9
                           0000FE   338 _RESET_KEEP	=	0x00fe
                           0000FF   339 _WDOG_COUNT	=	0x00ff
                           0000A8   340 _IE	=	0x00a8
                           0000B8   341 _IP	=	0x00b8
                           0000E8   342 _IE_EX	=	0x00e8
                           0000E9   343 _IP_EX	=	0x00e9
                           0000B2   344 _GPIO_IE	=	0x00b2
                           008584   345 _ROM_ADDR	=	0x8584
                           000084   346 _ROM_ADDR_L	=	0x0084
                           000085   347 _ROM_ADDR_H	=	0x0085
                           008F8E   348 _ROM_DATA_HI	=	0x8f8e
                           00008E   349 _ROM_DATA_HL	=	0x008e
                           00008F   350 _ROM_DATA_HH	=	0x008f
                           000086   351 _ROM_CTRL	=	0x0086
                           000080   352 _P0	=	0x0080
                           0000C4   353 _P0_MOD_OC	=	0x00c4
                           0000C5   354 _P0_DIR_PU	=	0x00c5
                           000090   355 _P1	=	0x0090
                           000092   356 _P1_MOD_OC	=	0x0092
                           000093   357 _P1_DIR_PU	=	0x0093
                           0000A0   358 _P2	=	0x00a0
                           000094   359 _P2_MOD_OC	=	0x0094
                           000095   360 _P2_DIR_PU	=	0x0095
                           0000B0   361 _P3	=	0x00b0
                           000096   362 _P3_MOD_OC	=	0x0096
                           000097   363 _P3_DIR_PU	=	0x0097
                           0000C0   364 _P4	=	0x00c0
                           0000C2   365 _P4_MOD_OC	=	0x00c2
                           0000C3   366 _P4_DIR_PU	=	0x00c3
                           0000C1   367 _P4_LED_KEY	=	0x00c1
                           0000AA   368 _P5_IN	=	0x00aa
                           0000AB   369 _P5_OUT_PU	=	0x00ab
                           0000AC   370 _P5_DIR	=	0x00ac
                           0000AD   371 _P6_IN	=	0x00ad
                           0000AE   372 _P6_OUT_PU	=	0x00ae
                           0000AF   373 _P6_DIR	=	0x00af
                           0000F1   374 _P7	=	0x00f1
                           0000A2   375 _XBUS_AUX	=	0x00a2
                           000088   376 _TCON	=	0x0088
                           000089   377 _TMOD	=	0x0089
                           00008A   378 _TL0	=	0x008a
                           00008B   379 _TL1	=	0x008b
                           00008C   380 _TH0	=	0x008c
                           00008D   381 _TH1	=	0x008d
                           000098   382 _SCON	=	0x0098
                           000099   383 _SBUF	=	0x0099
                           0000C8   384 _T2CON	=	0x00c8
                           0000C9   385 _T2MOD	=	0x00c9
                           00CBCA   386 _RCAP2	=	0xcbca
                           0000CA   387 _RCAP2L	=	0x00ca
                           0000CB   388 _RCAP2H	=	0x00cb
                           00CDCC   389 _T2COUNT	=	0xcdcc
                           0000CC   390 _TL2	=	0x00cc
                           0000CD   391 _TH2	=	0x00cd
                           00CFCE   392 _T2CAP1	=	0xcfce
                           0000CE   393 _T2CAP1L	=	0x00ce
                           0000CF   394 _T2CAP1H	=	0x00cf
                           0000F8   395 _SPI0_STAT	=	0x00f8
                           0000F9   396 _SPI0_DATA	=	0x00f9
                           0000FA   397 _SPI0_CTRL	=	0x00fa
                           0000FB   398 _SPI0_CK_SE	=	0x00fb
                           0000FC   399 _SPI0_SETUP	=	0x00fc
                           0000BC   400 _SCON1	=	0x00bc
                           0000BD   401 _SBUF1	=	0x00bd
                           0000BE   402 _SBAUD1	=	0x00be
                           0000BF   403 _SIF1	=	0x00bf
                           0000B4   404 _SPI1_STAT	=	0x00b4
                           0000B5   405 _SPI1_DATA	=	0x00b5
                           0000B6   406 _SPI1_CTRL	=	0x00b6
                           0000B7   407 _SPI1_CK_SE	=	0x00b7
                           0000F3   408 _ADC_CTRL	=	0x00f3
                           00F5F4   409 _ADC_DAT	=	0xf5f4
                           0000F4   410 _ADC_DAT_L	=	0x00f4
                           0000F5   411 _ADC_DAT_H	=	0x00f5
                           0000F6   412 _ADC_CHAN	=	0x00f6
                           0000A6   413 _LED_COMMON	=	0x00a6
                           0000A7   414 _LED_PWM_OE	=	0x00a7
                           00C7C6   415 _LED_DMA	=	0xc7c6
                           0000C6   416 _LED_DMA_L	=	0x00c6
                           0000C7   417 _LED_DMA_H	=	0x00c7
                           0000F7   418 _LED_STATUS	=	0x00f7
                           0000B3   419 _I2CX_INT	=	0x00b3
                           0000BB   420 _I2CS_INT_ST	=	0x00bb
                                    421 ;--------------------------------------------------------
                                    422 ; special function bits
                                    423 ;--------------------------------------------------------
                                    424 	.area RSEG    (ABS,DATA)
      000000                        425 	.org 0x0000
                           0000D7   426 _CY	=	0x00d7
                           0000D6   427 _AC	=	0x00d6
                           0000D5   428 _F0	=	0x00d5
                           0000D4   429 _RS1	=	0x00d4
                           0000D3   430 _RS0	=	0x00d3
                           0000D2   431 _OV	=	0x00d2
                           0000D1   432 _F1	=	0x00d1
                           0000D0   433 _P	=	0x00d0
                           0000AF   434 _EA	=	0x00af
                           0000AE   435 _E_DIS	=	0x00ae
                           0000AD   436 _ET2	=	0x00ad
                           0000AC   437 _ES	=	0x00ac
                           0000AB   438 _ET1	=	0x00ab
                           0000AA   439 _EX1	=	0x00aa
                           0000A9   440 _ET0	=	0x00a9
                           0000A8   441 _EX0	=	0x00a8
                           0000BF   442 _PH_FLAG	=	0x00bf
                           0000BE   443 _PL_FLAG	=	0x00be
                           0000BD   444 _PT2	=	0x00bd
                           0000BC   445 _PS	=	0x00bc
                           0000BB   446 _PT1	=	0x00bb
                           0000BA   447 _PX1	=	0x00ba
                           0000B9   448 _PT0	=	0x00b9
                           0000B8   449 _PX0	=	0x00b8
                           0000EF   450 _IE_WDOG	=	0x00ef
                           0000EE   451 _IE_GPIO	=	0x00ee
                           0000ED   452 _IE_PWM_I2C	=	0x00ed
                           0000EC   453 _IE_UART1	=	0x00ec
                           0000EB   454 _IE_ADC	=	0x00eb
                           0000E9   455 _IE_USB	=	0x00e9
                           0000E8   456 _IE_SPI0	=	0x00e8
                           000087   457 _P0_7	=	0x0087
                           000086   458 _P0_6	=	0x0086
                           000085   459 _P0_5	=	0x0085
                           000084   460 _P0_4	=	0x0084
                           000083   461 _P0_3	=	0x0083
                           000082   462 _P0_2	=	0x0082
                           000081   463 _P0_1	=	0x0081
                           000080   464 _P0_0	=	0x0080
                           000081   465 _SDA0	=	0x0081
                           000080   466 _SCL0	=	0x0080
                           000083   467 _TXD_	=	0x0083
                           000082   468 _RXD_	=	0x0082
                           000085   469 _AIN13	=	0x0085
                           000084   470 _AIN12	=	0x0084
                           000083   471 _AIN11	=	0x0083
                           000082   472 _AIN10	=	0x0082
                           000081   473 _AIN9	=	0x0081
                           000080   474 _AIN8	=	0x0080
                           000097   475 _P1_7	=	0x0097
                           000096   476 _P1_6	=	0x0096
                           000095   477 _P1_5	=	0x0095
                           000094   478 _P1_4	=	0x0094
                           000093   479 _P1_3	=	0x0093
                           000092   480 _P1_2	=	0x0092
                           000091   481 _P1_1	=	0x0091
                           000090   482 _P1_0	=	0x0090
                           000097   483 _TXD1_	=	0x0097
                           000096   484 _RXD1_	=	0x0096
                           000097   485 _SCK	=	0x0097
                           000096   486 _MISO	=	0x0096
                           000095   487 _MOSI	=	0x0095
                           000094   488 _SCS	=	0x0094
                           000092   489 _INT0_	=	0x0092
                           000091   490 _T2EX	=	0x0091
                           000091   491 _CAP2	=	0x0091
                           000090   492 _T2	=	0x0090
                           000090   493 _CAP1	=	0x0090
                           000097   494 _AIN7	=	0x0097
                           000096   495 _AIN6	=	0x0096
                           000095   496 _AIN5	=	0x0095
                           000094   497 _AIN4	=	0x0094
                           000093   498 _AIN3	=	0x0093
                           000092   499 _AIN2	=	0x0092
                           000091   500 _AIN1	=	0x0091
                           000090   501 _AIN0	=	0x0090
                           0000A7   502 _P2_7	=	0x00a7
                           0000A6   503 _P2_6	=	0x00a6
                           0000A5   504 _P2_5	=	0x00a5
                           0000A4   505 _P2_4	=	0x00a4
                           0000A3   506 _P2_3	=	0x00a3
                           0000A2   507 _P2_2	=	0x00a2
                           0000A1   508 _P2_1	=	0x00a1
                           0000A0   509 _P2_0	=	0x00a0
                           0000A7   510 _TXD1	=	0x00a7
                           0000A6   511 _RXD1	=	0x00a6
                           0000A5   512 _T2EX_	=	0x00a5
                           0000A5   513 _CAP2_	=	0x00a5
                           0000A4   514 _T2_	=	0x00a4
                           0000A4   515 _CAP1_	=	0x00a4
                           0000B7   516 _P3_7	=	0x00b7
                           0000B6   517 _P3_6	=	0x00b6
                           0000B5   518 _P3_5	=	0x00b5
                           0000B4   519 _P3_4	=	0x00b4
                           0000B3   520 _P3_3	=	0x00b3
                           0000B2   521 _P3_2	=	0x00b2
                           0000B1   522 _P3_1	=	0x00b1
                           0000B0   523 _P3_0	=	0x00b0
                           0000B7   524 _SCK1	=	0x00b7
                           0000B6   525 _MISO1	=	0x00b6
                           0000B5   526 _MOSI1	=	0x00b5
                           0000B5   527 _T1	=	0x00b5
                           0000B4   528 _T0	=	0x00b4
                           0000B3   529 _INT1	=	0x00b3
                           0000B2   530 _INT0	=	0x00b2
                           0000B1   531 _TXD	=	0x00b1
                           0000B0   532 _RXD	=	0x00b0
                           0000C6   533 _P4_6	=	0x00c6
                           0000C5   534 _P4_5	=	0x00c5
                           0000C4   535 _P4_4	=	0x00c4
                           0000C3   536 _P4_3	=	0x00c3
                           0000C2   537 _P4_2	=	0x00c2
                           0000C1   538 _P4_1	=	0x00c1
                           0000C0   539 _P4_0	=	0x00c0
                           00008F   540 _TF1	=	0x008f
                           00008E   541 _TR1	=	0x008e
                           00008D   542 _TF0	=	0x008d
                           00008C   543 _TR0	=	0x008c
                           00008B   544 _IE1	=	0x008b
                           00008A   545 _IT1	=	0x008a
                           000089   546 _IE0	=	0x0089
                           000088   547 _IT0	=	0x0088
                           00009F   548 _SM0	=	0x009f
                           00009E   549 _SM1	=	0x009e
                           00009D   550 _SM2	=	0x009d
                           00009C   551 _REN	=	0x009c
                           00009B   552 _TB8	=	0x009b
                           00009A   553 _RB8	=	0x009a
                           000099   554 _TI	=	0x0099
                           000098   555 _RI	=	0x0098
                           0000CF   556 _TF2	=	0x00cf
                           0000CF   557 _CAP1F	=	0x00cf
                           0000CE   558 _EXF2	=	0x00ce
                           0000CD   559 _RCLK	=	0x00cd
                           0000CC   560 _TCLK	=	0x00cc
                           0000CB   561 _EXEN2	=	0x00cb
                           0000CA   562 _TR2	=	0x00ca
                           0000C9   563 _C_T2	=	0x00c9
                           0000C8   564 _CP_RL2	=	0x00c8
                           0000FF   565 _S0_FST_ACT	=	0x00ff
                           0000FE   566 _S0_IF_OV	=	0x00fe
                           0000FD   567 _S0_IF_FIRST	=	0x00fd
                           0000FC   568 _S0_IF_BYTE	=	0x00fc
                           0000FB   569 _S0_FREE	=	0x00fb
                           0000FA   570 _S0_T_FIFO	=	0x00fa
                           0000F8   571 _S0_R_FIFO	=	0x00f8
                           0000F7   572 _ADC_START	=	0x00f7
                                    573 ;--------------------------------------------------------
                                    574 ; overlayable register banks
                                    575 ;--------------------------------------------------------
                                    576 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        577 	.ds 8
                                    578 ;--------------------------------------------------------
                                    579 ; internal ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area DSEG    (DATA)
      000018                        582 _process_action_sloc0_1_0:
      000018                        583 	.ds 1
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable items in internal ram
                                    586 ;--------------------------------------------------------
                                    587 ;--------------------------------------------------------
                                    588 ; indirectly addressable internal ram data
                                    589 ;--------------------------------------------------------
                                    590 	.area ISEG    (DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; absolute internal ram data
                                    593 ;--------------------------------------------------------
                                    594 	.area IABS    (ABS,DATA)
                                    595 	.area IABS    (ABS,DATA)
                                    596 ;--------------------------------------------------------
                                    597 ; bit data
                                    598 ;--------------------------------------------------------
                                    599 	.area BSEG    (BIT)
      00001D                        600 _process_action_sloc1_1_0:
      00001D                        601 	.ds 1
                                    602 ;--------------------------------------------------------
                                    603 ; paged external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area PSEG    (PAG,XDATA)
                                    606 ;--------------------------------------------------------
                                    607 ; uninitialized external ram data
                                    608 ;--------------------------------------------------------
                                    609 	.area XSEG    (XDATA)
      0007FE                        610 _tp_buttons::
      0007FE                        611 	.ds 2
      000800                        612 _action_exec_PARM_1:
      000800                        613 	.ds 6
      000806                        614 _action_exec_record_10001_620:
      000806                        615 	.ds 9
      00080F                        616 _ak820_action_exec_event_10000_624:
      00080F                        617 	.ds 2
      000811                        618 _ak820_action_exec_snapshot_10000_625:
      000811                        619 	.ds 6
      000817                        620 _process_record_record_argument_10000_628:
      000817                        621 	.ds 2
      000819                        622 _process_record_handler_record_argument_10000_634:
      000819                        623 	.ds 2
      00081B                        624 _process_record_handler_action_10000_635:
      00081B                        625 	.ds 2
      00081D                        626 _process_action_PARM_2:
      00081D                        627 	.ds 2
      00081F                        628 _process_action_record_argument_10000_646:
      00081F                        629 	.ds 2
      000821                        630 _process_action_on_40000_669:
      000821                        631 	.ds 1
      000822                        632 _register_code_code_10000_703:
      000822                        633 	.ds 1
      000823                        634 _unregister_code_code_10000_717:
      000823                        635 	.ds 1
      000824                        636 _tap_code_delay_PARM_2:
      000824                        637 	.ds 2
      000826                        638 _tap_code_delay_code_10000_730:
      000826                        639 	.ds 1
      000827                        640 _tap_code_code_10000_737:
      000827                        641 	.ds 1
      000828                        642 _register_mods_mods_10000_739:
      000828                        643 	.ds 1
      000829                        644 _unregister_mods_mods_10000_743:
      000829                        645 	.ds 1
      00082A                        646 _register_weak_mods_mods_10000_747:
      00082A                        647 	.ds 1
      00082B                        648 _unregister_weak_mods_mods_10000_751:
      00082B                        649 	.ds 1
                                    650 ;--------------------------------------------------------
                                    651 ; absolute external ram data
                                    652 ;--------------------------------------------------------
                                    653 	.area XABS    (ABS,XDATA)
                                    654 ;--------------------------------------------------------
                                    655 ; initialized external ram data
                                    656 ;--------------------------------------------------------
                                    657 	.area XISEG   (XDATA)
      000D83                        658 _disable_action_cache::
      000D83                        659 	.ds 1
                                    660 	.area HOME    (CODE)
                                    661 	.area GSINIT0 (CODE)
                                    662 	.area GSINIT1 (CODE)
                                    663 	.area GSINIT2 (CODE)
                                    664 	.area GSINIT3 (CODE)
                                    665 	.area GSINIT4 (CODE)
                                    666 	.area GSINIT5 (CODE)
                                    667 	.area GSINIT  (CODE)
                                    668 	.area GSFINAL (CODE)
                                    669 	.area CSEG    (CODE)
                                    670 ;--------------------------------------------------------
                                    671 ; global & static initialisations
                                    672 ;--------------------------------------------------------
                                    673 	.area HOME    (CODE)
                                    674 	.area GSINIT  (CODE)
                                    675 	.area GSFINAL (CODE)
                                    676 	.area GSINIT  (CODE)
                                    677 ;--------------------------------------------------------
                                    678 ; Home
                                    679 ;--------------------------------------------------------
                                    680 	.area HOME    (CODE)
                                    681 	.area HOME    (CODE)
                                    682 ;--------------------------------------------------------
                                    683 ; code
                                    684 ;--------------------------------------------------------
                                    685 	.area CSEG    (CODE)
                                    686 ;------------------------------------------------------------
                                    687 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    688 ;------------------------------------------------------------
                                    689 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    690 ;------------------------------------------------------------
                                    691 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    692 ;	-----------------------------------------
                           000007   693 	ar7 = 0x07
                           000006   694 	ar6 = 0x06
                           000005   695 	ar5 = 0x05
                           000004   696 	ar4 = 0x04
                           000003   697 	ar3 = 0x03
                           000002   698 	ar2 = 0x02
                           000001   699 	ar1 = 0x01
                           000000   700 	ar0 = 0x00
                                    701 ;	 function action_exec
                                    702 ;	-----------------------------------------
      006DCE                        703 _action_exec:
                                    704 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      006DCE 90 08 02         [24]  705 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      006DD1 12 37 A2         [24]  706 	lcall	_ak820_outline_0004
      006DD4 12 35 B9         [24]  707 	lcall	_ak820_combo_tick
                                    708 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      006DD7 90 08 00         [24]  709 	mov	dptr,#_action_exec_PARM_1
      006DDA 12 44 1B         [24]  710 	lcall	_ak820_tapping_before
      006DDD E5 82            [12]  711 	mov	a, dpl
      006DDF 70 01            [24]  712 	jnz	00102$
      006DE1 22               [24]  713 	ret
      006DE2                        714 00102$:
                                    715 ;	quantum/action.c:126: if (event.pressed) {
      006DE2 90 08 05         [24]  716 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      006DE5 E0               [24]  717 	movx	a,@dptr
      006DE6 60 03            [24]  718 	jz	00104$
                                    719 ;	quantum/action.c:128: clear_weak_mods();
      006DE8 12 7D 1F         [24]  720 	lcall	_clear_weak_mods
      006DEB                        721 00104$:
                                    722 ;	quantum/action.c:140: record.event = event;
      006DEB 90 0D 64         [24]  723 	mov	dptr,#___memcpy_PARM_2
      006DEE 74 00            [12]  724 	mov	a,#_action_exec_PARM_1
      006DF0 F0               [24]  725 	movx	@dptr,a
      006DF1 74 08            [12]  726 	mov	a,#(_action_exec_PARM_1 >> 8)
      006DF3 12 38 1E         [24]  727 	lcall	_ak820_outline_0067
      006DF6 12 73 A2         [24]  728 	lcall	_ak820_outline_0066
      006DF9 90 08 06         [24]  729 	mov	dptr,#_action_exec_record_10001_620
      006DFC F5 F0            [12]  730 	mov	b,a
      006DFE 12 B3 6C         [24]  731 	lcall	___memcpy
                                    732 ;	quantum/action.c:142: record.tap.count = 0;
      006E01 90 08 0C         [24]  733 	mov	dptr,#(_action_exec_record_10001_620 + 0x0006)
      006E04 E0               [24]  734 	movx	a,@dptr
      006E05 54 0F            [12]  735 	anl	a,#0x0f
      006E07 F0               [24]  736 	movx	@dptr,a
                                    737 ;	quantum/action.c:147: record.keycode = 0;
      006E08 90 08 0D         [24]  738 	mov	dptr,#(_action_exec_record_10001_620 + 0x0007)
      006E0B 12 4D 21         [24]  739 	lcall	_ak820_outline_0159
                                    740 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      006E0E 90 08 0A         [24]  741 	mov	dptr,#(_action_exec_record_10001_620 + 0x0004)
      006E11 E0               [24]  742 	movx	a,@dptr
      006E12 60 0A            [24]  743 	jz	00107$
      006E14 90 08 06         [24]  744 	mov	dptr,#_action_exec_record_10001_620
      006E17 12 9A 93         [24]  745 	lcall	_pre_process_record_quantum
      006E1A E5 82            [12]  746 	mov	a, dpl
      006E1C 60 11            [24]  747 	jz	00110$
      006E1E                        748 00107$:
                                    749 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      006E1E 90 08 06         [24]  750 	mov	dptr,#_action_exec_record_10001_620
      006E21 12 45 0F         [24]  751 	lcall	_ak820_tapping_process
      006E24 E5 82            [12]  752 	mov	a, dpl
      006E26 70 01            [24]  753 	jnz	00106$
      006E28 22               [24]  754 	ret
      006E29                        755 00106$:
                                    756 ;	quantum/action.c:185: process_record(&record);
      006E29 90 08 06         [24]  757 	mov	dptr,#_action_exec_record_10001_620
                                    758 ;	quantum/action.c:200: }
      006E2C 02 6E 6A         [24]  759 	ljmp	_process_record
      006E2F                        760 00110$:
      006E2F 22               [24]  761 	ret
                                    762 ;------------------------------------------------------------
                                    763 ;Allocation info for local variables in function 'ak820_action_exec'
                                    764 ;------------------------------------------------------------
                                    765 ;event         Allocated with name '_ak820_action_exec_event_10000_624'
                                    766 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_625'
                                    767 ;------------------------------------------------------------
                                    768 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function ak820_action_exec
                                    771 ;	-----------------------------------------
      006E30                        772 _ak820_action_exec:
      006E30 12 38 47         [24]  773 	lcall	_ak820_outline_0100
      006E33 90 08 0F         [24]  774 	mov	dptr,#_ak820_action_exec_event_10000_624
      006E36 12 38 42         [24]  775 	lcall	_ak820_outline_0099
                                    776 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      006E39 90 08 0F         [24]  777 	mov	dptr,#_ak820_action_exec_event_10000_624
      006E3C 12 38 10         [24]  778 	lcall	_ak820_outline_0054
      006E3F 90 0D 64         [24]  779 	mov	dptr,#___memcpy_PARM_2
      006E42 ED               [12]  780 	mov	a,r5
      006E43 12 37 E1         [24]  781 	lcall	_ak820_outline_0014
      006E46 12 73 A2         [24]  782 	lcall	_ak820_outline_0066
      006E49 90 08 11         [24]  783 	mov	dptr,#_ak820_action_exec_snapshot_10000_625
      006E4C F5 F0            [12]  784 	mov	b,a
      006E4E 12 B3 6C         [24]  785 	lcall	___memcpy
                                    786 ;	quantum/action.c:207: action_exec(snapshot);
      006E51 90 0D 64         [24]  787 	mov	dptr,#___memcpy_PARM_2
      006E54 74 11            [12]  788 	mov	a,#_ak820_action_exec_snapshot_10000_625
      006E56 F0               [24]  789 	movx	@dptr,a
      006E57 74 08            [12]  790 	mov	a,#(_ak820_action_exec_snapshot_10000_625 >> 8)
      006E59 12 38 1E         [24]  791 	lcall	_ak820_outline_0067
      006E5C 12 73 A2         [24]  792 	lcall	_ak820_outline_0066
      006E5F 90 08 00         [24]  793 	mov	dptr,#_action_exec_PARM_1
      006E62 F5 F0            [12]  794 	mov	b,a
      006E64 12 B3 6C         [24]  795 	lcall	___memcpy
                                    796 ;	quantum/action.c:208: }
      006E67 02 6D CE         [24]  797 	ljmp	_action_exec
                                    798 ;------------------------------------------------------------
                                    799 ;Allocation info for local variables in function 'process_record_nocache'
                                    800 ;------------------------------------------------------------
                                    801 ;record        Allocated with name '_process_record_nocache_record_10000_626'
                                    802 ;------------------------------------------------------------
                                    803 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    804 ;	-----------------------------------------
                                    805 ;	 function process_record
                                    806 ;	-----------------------------------------
      006E6A                        807 _process_record:
      006E6A 12 38 47         [24]  808 	lcall	_ak820_outline_0100
      006E6D 90 08 17         [24]  809 	mov	dptr,#_process_record_record_argument_10000_628
      006E70 12 38 42         [24]  810 	lcall	_ak820_outline_0099
                                    811 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      006E73 90 08 17         [24]  812 	mov	dptr,#_process_record_record_argument_10000_628
      006E76 12 37 F9         [24]  813 	lcall	_ak820_outline_0047
                                    814 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      006E79 74 04            [12]  815 	mov	a,#0x04
      006E7B 12 46 41         [24]  816 	lcall	_ak820_outline_0010
      006E7E 70 01            [24]  817 	jnz	00102$
                                    818 ;	quantum/action.c:354: return;
      006E80 22               [24]  819 	ret
      006E81                        820 00102$:
                                    821 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      006E81 12 43 1A         [24]  822 	lcall	_ak820_outline_0111
      006E84 C0 07            [24]  823 	push	ar7
      006E86 C0 06            [24]  824 	push	ar6
      006E88 12 9A D7         [24]  825 	lcall	_process_record_quantum
      006E8B E5 82            [12]  826 	mov	a, dpl
      006E8D D0 06            [24]  827 	pop	ar6
      006E8F D0 07            [24]  828 	pop	ar7
      006E91 70 01            [24]  829 	jnz	00104$
                                    830 ;	quantum/action.c:376: return;
      006E93 22               [24]  831 	ret
      006E94                        832 00104$:
                                    833 ;	quantum/action.c:382: process_record_handler(record);
      006E94 12 43 1A         [24]  834 	lcall	_ak820_outline_0111
                                    835 ;	quantum/action.c:392: }
      006E97 02 6E 9A         [24]  836 	ljmp	_process_record_handler
                                    837 ;------------------------------------------------------------
                                    838 ;Allocation info for local variables in function 'process_record_handler'
                                    839 ;------------------------------------------------------------
                                    840 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_634'
                                    841 ;record        Allocated with name '_process_record_handler_record_10000_635'
                                    842 ;action        Allocated with name '_process_record_handler_action_10000_635'
                                    843 ;------------------------------------------------------------
                                    844 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    845 ;	-----------------------------------------
                                    846 ;	 function process_record_handler
                                    847 ;	-----------------------------------------
      006E9A                        848 _process_record_handler:
      006E9A 12 38 47         [24]  849 	lcall	_ak820_outline_0100
      006E9D 90 08 19         [24]  850 	mov	dptr,#_process_record_handler_record_argument_10000_634
      006EA0 12 38 42         [24]  851 	lcall	_ak820_outline_0099
                                    852 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      006EA3 90 08 19         [24]  853 	mov	dptr,#_process_record_handler_record_argument_10000_634
      006EA6 12 37 B9         [24]  854 	lcall	_ak820_outline_0008
                                    855 ;	quantum/action.c:405: if (record->keycode) {
      006EA9 4C               [12]  856 	orl	a,r4
      006EAA 60 19            [24]  857 	jz	00102$
                                    858 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      006EAC 12 38 53         [24]  859 	lcall	_ak820_outline_0112
      006EAF C0 07            [24]  860 	push	ar7
      006EB1 C0 06            [24]  861 	push	ar6
      006EB3 12 91 16         [24]  862 	lcall	_action_for_keycode
      006EB6 12 43 35         [24]  863 	lcall	_ak820_outline_0138
      006EB9 D0 06            [24]  864 	pop	ar6
      006EBB D0 07            [24]  865 	pop	ar7
      006EBD 90 08 1B         [24]  866 	mov	dptr,#_process_record_handler_action_10000_635
      006EC0 12 38 24         [24]  867 	lcall	_ak820_outline_0070
      006EC3 80 2B            [24]  868 	sjmp	00104$
      006EC5                        869 00102$:
                                    870 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      006EC5 12 73 83         [24]  871 	lcall	_ak820_outline_0017
      006EC8 7A 00            [12]  872 	mov	r2,#0x00
      006ECA 12 43 2A         [24]  873 	lcall	_ak820_outline_0133
      006ECD 12 42 C0         [24]  874 	lcall	_ak820_outline_0011
      006ED0 E0               [24]  875 	movx	a,@dptr
      006ED1 90 09 56         [24]  876 	mov	dptr,#_ak820_resolve_key_PARM_2
      006ED4 F0               [24]  877 	movx	@dptr,a
      006ED5 8D 82            [24]  878 	mov	dpl, r5
      006ED7 8C 83            [24]  879 	mov	dph, r4
      006ED9 C0 07            [24]  880 	push	ar7
      006EDB C0 06            [24]  881 	push	ar6
      006EDD 12 77 1A         [24]  882 	lcall	_ak820_resolve_key
      006EE0 12 91 16         [24]  883 	lcall	_action_for_keycode
      006EE3 12 43 35         [24]  884 	lcall	_ak820_outline_0138
      006EE6 D0 06            [24]  885 	pop	ar6
      006EE8 D0 07            [24]  886 	pop	ar7
      006EEA 90 08 1B         [24]  887 	mov	dptr,#_process_record_handler_action_10000_635
      006EED 12 38 24         [24]  888 	lcall	_ak820_outline_0070
                                    889 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      006EF0                        890 00104$:
                                    891 ;	quantum/action.c:429: process_action(record, action);
      006EF0 90 0D 64         [24]  892 	mov	dptr,#___memcpy_PARM_2
      006EF3 74 1B            [12]  893 	mov	a,#_process_record_handler_action_10000_635
      006EF5 F0               [24]  894 	movx	@dptr,a
      006EF6 74 08            [12]  895 	mov	a,#(_process_record_handler_action_10000_635 >> 8)
      006EF8 12 38 1E         [24]  896 	lcall	_ak820_outline_0067
      006EFB 90 0D 67         [24]  897 	mov	dptr,#___memcpy_PARM_3
      006EFE 74 02            [12]  898 	mov	a,#0x02
      006F00 12 38 58         [24]  899 	lcall	_ak820_outline_0115
      006F03 90 08 1D         [24]  900 	mov	dptr,#_process_action_PARM_2
      006F06 F5 F0            [12]  901 	mov	b,a
      006F08 C0 07            [24]  902 	push	ar7
      006F0A C0 06            [24]  903 	push	ar6
      006F0C 12 B3 6C         [24]  904 	lcall	___memcpy
      006F0F D0 06            [24]  905 	pop	ar6
      006F11 D0 07            [24]  906 	pop	ar7
      006F13 12 43 1A         [24]  907 	lcall	_ak820_outline_0111
                                    908 ;	quantum/action.c:430: }
      006F16 02 6F 19         [24]  909 	ljmp	_process_action
                                    910 ;------------------------------------------------------------
                                    911 ;Allocation info for local variables in function 'register_mouse'
                                    912 ;------------------------------------------------------------
                                    913 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                    914 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_643'
                                    915 ;------------------------------------------------------------
                                    916 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                    917 ;	-----------------------------------------
                                    918 ;	 function process_action
                                    919 ;	-----------------------------------------
      006F19                        920 _process_action:
      006F19 12 38 47         [24]  921 	lcall	_ak820_outline_0100
      006F1C 90 08 1F         [24]  922 	mov	dptr,#_process_action_record_argument_10000_646
      006F1F 12 38 42         [24]  923 	lcall	_ak820_outline_0099
                                    924 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      006F22 90 08 1F         [24]  925 	mov	dptr,#_process_action_record_argument_10000_646
      006F25 12 37 A2         [24]  926 	lcall	_ak820_outline_0004
                                    927 ;	quantum/action.c:501: pressed = record->event.pressed;
      006F28 A3               [24]  928 	inc	dptr
      006F29 A3               [24]  929 	inc	dptr
      006F2A A3               [24]  930 	inc	dptr
      006F2B A3               [24]  931 	inc	dptr
      006F2C A3               [24]  932 	inc	dptr
      006F2D E0               [24]  933 	movx	a,@dptr
      006F2E F5 18            [12]  934 	mov	_process_action_sloc0_1_0,a
                                    935 ;	quantum/action.c:525: switch (action.kind.id) {
      006F30 90 08 1E         [24]  936 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      006F33 E0               [24]  937 	movx	a,@dptr
      006F34 C4               [12]  938 	swap	a
      006F35 54 0F            [12]  939 	anl	a,#0x0f
      006F37 FD               [12]  940 	mov  r5,a
      006F38 24 F4            [12]  941 	add	a,#0xff - 0x0b
      006F3A 50 03            [24]  942 	jnc	00434$
      006F3C 02 71 BA         [24]  943 	ljmp	00181$
      006F3F                        944 00434$:
                                    945 ;	free result
      006F3F ED               [12]  946 	mov	a,r5
      006F40 24 0A            [12]  947 	add	a,#(00435$-3-.)
      006F42 83               [24]  948 	movc	a,@a+pc
      006F43 F5 82            [12]  949 	mov	dpl,a
      006F45 ED               [12]  950 	mov	a,r5
      006F46 24 10            [12]  951 	add	a,#(00436$-3-.)
      006F48 83               [24]  952 	movc	a,@a+pc
      006F49 F5 83            [12]  953 	mov	dph,a
      006F4B E4               [12]  954 	clr	a
      006F4C 73               [24]  955 	jmp	@a+dptr
      006F4D                        956 00435$:
      006F4D 65                     957 	.db	00102$
      006F4E 65                     958 	.db	00102$
      006F4F BA                     959 	.db	00181$
      006F50 BA                     960 	.db	00181$
      006F51 EF                     961 	.db	00123$
      006F52 BA                     962 	.db	00181$
      006F53 BA                     963 	.db	00181$
      006F54 BA                     964 	.db	00181$
      006F55 4F                     965 	.db	00131$
      006F56 21                     966 	.db	00147$
      006F57 47                     967 	.db	00152$
      006F58 47                     968 	.db	00152$
      006F59                        969 00436$:
      006F59 6F                     970 	.db	00102$>>8
      006F5A 6F                     971 	.db	00102$>>8
      006F5B 71                     972 	.db	00181$>>8
      006F5C 71                     973 	.db	00181$>>8
      006F5D 6F                     974 	.db	00123$>>8
      006F5E 71                     975 	.db	00181$>>8
      006F5F 71                     976 	.db	00181$>>8
      006F60 71                     977 	.db	00181$>>8
      006F61 70                     978 	.db	00131$>>8
      006F62 71                     979 	.db	00147$>>8
      006F63 71                     980 	.db	00152$>>8
      006F64 71                     981 	.db	00152$>>8
                                    982 ;	quantum/action.c:528: case ACT_RMODS: {
      006F65                        983 00102$:
                                    984 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      006F65 90 08 1E         [24]  985 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      006F68 E0               [24]  986 	movx	a,@dptr
      006F69 54 F0            [12]  987 	anl	a,#0xf0
      006F6B 70 06            [24]  988 	jnz	00194$
      006F6D 12 73 BC         [24]  989 	lcall	_ak820_outline_0103
      006F70 FD               [12]  990 	mov	r5,a
      006F71 80 07            [24]  991 	sjmp	00195$
      006F73                        992 00194$:
      006F73 12 73 BC         [24]  993 	lcall	_ak820_outline_0103
      006F76 C4               [12]  994 	swap	a
      006F77 54 F0            [12]  995 	anl	a,#0xf0
      006F79 FD               [12]  996 	mov	r5,a
      006F7A                        997 00195$:
                                    998 ;	quantum/action.c:531: if (pressed) {
      006F7A E5 18            [12]  999 	mov	a,_process_action_sloc0_1_0
      006F7C 60 35            [24] 1000 	jz	00119$
                                   1001 ;	quantum/action.c:532: if (mods) {
      006F7E ED               [12] 1002 	mov	a,r5
      006F7F 60 29            [24] 1003 	jz	00110$
                                   1004 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      006F81 12 73 CE         [24] 1005 	lcall	_ak820_outline_0148
      006F84 FC               [12] 1006 	mov	r4,a
      006F85 BC E0 00         [24] 1007 	cjne	r4,#0xe0,00440$
      006F88                       1008 00440$:
      006F88 40 07            [24] 1009 	jc	00108$
      006F8A 12 73 CE         [24] 1010 	lcall	_ak820_outline_0148
      006F8D 24 18            [12] 1011 	add	a,#0xff - 0xe7
      006F8F 50 0A            [24] 1012 	jnc	00104$
                                   1013 ;	free result
      006F91                       1014 00108$:
      006F91 7B 1D            [12] 1015 	mov	r3,#_process_action_PARM_2
      006F93 7C 08            [12] 1016 	mov	r4,#(_process_action_PARM_2 >> 8)
      006F95 12 33 FC         [24] 1017 	lcall	_ak820_outline_0116
      006F98 E0               [24] 1018 	movx	a,@dptr
      006F99 70 07            [24] 1019 	jnz	00105$
      006F9B                       1020 00104$:
                                   1021 ;	quantum/action.c:537: add_owned_mods(mods);
      006F9B 8D 82            [24] 1022 	mov	dpl, r5
      006F9D 12 79 34         [24] 1023 	lcall	_add_owned_mods
      006FA0 80 05            [24] 1024 	sjmp	00106$
      006FA2                       1025 00105$:
                                   1026 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      006FA2 8D 82            [24] 1027 	mov	dpl, r5
      006FA4 12 79 53         [24] 1028 	lcall	_add_owned_weak_mods
      006FA7                       1029 00106$:
                                   1030 ;	quantum/action.c:541: send_keyboard_report();
      006FA7 12 7C 70         [24] 1031 	lcall	_send_keyboard_report
      006FAA                       1032 00110$:
                                   1033 ;	quantum/action.c:543: register_code(action.key.code);
      006FAA 12 73 AC         [24] 1034 	lcall	_ak820_outline_0069
      006FAD 12 71 D1         [24] 1035 	lcall	_register_code
      006FB0 02 71 BA         [24] 1036 	ljmp	00181$
      006FB3                       1037 00119$:
                                   1038 ;	quantum/action.c:545: unregister_code(action.key.code);
      006FB3 12 73 AC         [24] 1039 	lcall	_ak820_outline_0069
      006FB6 C0 05            [24] 1040 	push	ar5
      006FB8 12 72 3E         [24] 1041 	lcall	_unregister_code
      006FBB D0 05            [24] 1042 	pop	ar5
                                   1043 ;	quantum/action.c:546: if (mods) {
      006FBD ED               [12] 1044 	mov	a,r5
      006FBE 70 03            [24] 1045 	jnz	00444$
      006FC0 02 71 BA         [24] 1046 	ljmp	00181$
      006FC3                       1047 00444$:
                                   1048 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      006FC3 12 73 CE         [24] 1049 	lcall	_ak820_outline_0148
      006FC6 FC               [12] 1050 	mov	r4,a
      006FC7 BC E0 00         [24] 1051 	cjne	r4,#0xe0,00445$
      006FCA                       1052 00445$:
      006FCA 40 07            [24] 1053 	jc	00115$
      006FCC 12 73 CE         [24] 1054 	lcall	_ak820_outline_0148
      006FCF 24 18            [12] 1055 	add	a,#0xff - 0xe7
      006FD1 50 0A            [24] 1056 	jnc	00111$
                                   1057 ;	free result
      006FD3                       1058 00115$:
      006FD3 7B 1D            [12] 1059 	mov	r3,#_process_action_PARM_2
      006FD5 7C 08            [12] 1060 	mov	r4,#(_process_action_PARM_2 >> 8)
      006FD7 12 33 FC         [24] 1061 	lcall	_ak820_outline_0116
      006FDA E0               [24] 1062 	movx	a,@dptr
      006FDB 70 07            [24] 1063 	jnz	00112$
      006FDD                       1064 00111$:
                                   1065 ;	quantum/action.c:548: del_owned_mods(mods);
      006FDD 8D 82            [24] 1066 	mov	dpl, r5
      006FDF 12 79 44         [24] 1067 	lcall	_del_owned_mods
      006FE2 80 05            [24] 1068 	sjmp	00113$
      006FE4                       1069 00112$:
                                   1070 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      006FE4 8D 82            [24] 1071 	mov	dpl, r5
      006FE6 12 79 63         [24] 1072 	lcall	_del_owned_weak_mods
      006FE9                       1073 00113$:
                                   1074 ;	quantum/action.c:552: send_keyboard_report();
      006FE9 12 7C 70         [24] 1075 	lcall	_send_keyboard_report
                                   1076 ;	quantum/action.c:555: } break;
      006FEC 02 71 BA         [24] 1077 	ljmp	00181$
                                   1078 ;	quantum/action.c:632: case ACT_USAGE:
      006FEF                       1079 00123$:
                                   1080 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      006FEF 74 07            [12] 1081 	mov	a,#0x07
      006FF1 12 37 E9         [24] 1082 	lcall	_ak820_outline_0018
      006FF4 12 37 CD         [24] 1083 	lcall	_ak820_outline_0009
      006FF7 C3               [12] 1084 	clr	c
      006FF8 EC               [12] 1085 	mov	a,r4
      006FF9 94 A5            [12] 1086 	subb	a,#0xa5
      006FFB ED               [12] 1087 	mov	a,r5
      006FFC 94 00            [12] 1088 	subb	a,#0x00
      006FFE 40 15            [24] 1089 	jc	00125$
      007000 74 C2            [12] 1090 	mov	a,#0xc2
      007002 9C               [12] 1091 	subb	a,r4
      007003 E4               [12] 1092 	clr	a
      007004 9D               [12] 1093 	subb	a,r5
      007005 40 0E            [24] 1094 	jc	00125$
                                   1095 ;	free result
                                   1096 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      007007 90 0A 7D         [24] 1097 	mov	dptr,#_owned_usage_key_PARM_2
      00700A E5 18            [12] 1098 	mov	a,_process_action_sloc0_1_0
      00700C F0               [24] 1099 	movx	@dptr,a
      00700D 8E 82            [24] 1100 	mov	dpl, r6
      00700F 12 7B 1B         [24] 1101 	lcall	_owned_usage_key
                                   1102 ;	quantum/action.c:640: break;
      007012 02 71 BA         [24] 1103 	ljmp	00181$
      007015                       1104 00125$:
                                   1105 ;	quantum/action.c:643: switch (action.usage.page) {
      007015 12 73 B3         [24] 1106 	lcall	_ak820_outline_0079
      007018 FF               [12] 1107 	mov	r7,a
      007019 60 08            [24] 1108 	jz	00127$
      00701B BF 01 02         [24] 1109 	cjne	r7,#0x01,00452$
      00701E 80 19            [24] 1110 	sjmp	00128$
      007020                       1111 00452$:
      007020 02 71 BA         [24] 1112 	ljmp	00181$
                                   1113 ;	quantum/action.c:644: case PAGE_SYSTEM:
      007023                       1114 00127$:
                                   1115 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      007023 E5 18            [12] 1116 	mov	a,_process_action_sloc0_1_0
      007025 60 05            [24] 1117 	jz	00196$
      007027 12 73 C3         [24] 1118 	lcall	_ak820_outline_0122
      00702A 80 04            [24] 1119 	sjmp	00197$
      00702C                       1120 00196$:
      00702C 7E 00            [12] 1121 	mov	r6,#0x00
      00702E 7F 00            [12] 1122 	mov	r7,#0x00
      007030                       1123 00197$:
      007030 12 43 1A         [24] 1124 	lcall	_ak820_outline_0111
      007033 12 6A CA         [24] 1125 	lcall	_host_system_send
                                   1126 ;	quantum/action.c:646: break;
      007036 02 71 BA         [24] 1127 	ljmp	00181$
                                   1128 ;	quantum/action.c:647: case PAGE_CONSUMER:
      007039                       1129 00128$:
                                   1130 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      007039 E5 18            [12] 1131 	mov	a,_process_action_sloc0_1_0
      00703B 60 05            [24] 1132 	jz	00198$
      00703D 12 73 C3         [24] 1133 	lcall	_ak820_outline_0122
      007040 80 04            [24] 1134 	sjmp	00199$
      007042                       1135 00198$:
      007042 7E 00            [12] 1136 	mov	r6,#0x00
      007044 7F 00            [12] 1137 	mov	r7,#0x00
      007046                       1138 00199$:
      007046 12 43 1A         [24] 1139 	lcall	_ak820_outline_0111
      007049 12 6A FA         [24] 1140 	lcall	_host_consumer_send
                                   1141 ;	quantum/action.c:651: break;
      00704C 02 71 BA         [24] 1142 	ljmp	00181$
                                   1143 ;	quantum/action.c:658: case ACT_LAYER: {
      00704F                       1144 00131$:
                                   1145 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      00704F 90 08 1E         [24] 1146 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007052 E0               [24] 1147 	movx	a,@dptr
      007053 54 03            [12] 1148 	anl	a,#0x03
      007055 90 08 21         [24] 1149 	mov	dptr,#_process_action_on_40000_669
      007058 F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007059 E0               [24] 1152 	movx	a,@dptr
      00705A FF               [12] 1153 	mov	r7,a
      00705B 60 11            [24] 1154 	jz	00200$
      00705D E5 18            [12] 1155 	mov	a,_process_action_sloc0_1_0
      00705F 60 07            [24] 1156 	jz	00202$
      007061 8F 06            [24] 1157 	mov	ar6,r7
      007063 53 06 01         [24] 1158 	anl	ar6,#0x01
      007066 80 10            [24] 1159 	sjmp	00201$
      007068                       1160 00202$:
      007068 74 02            [12] 1161 	mov	a,#0x02
      00706A 5F               [12] 1162 	anl	a,r7
      00706B FE               [12] 1163 	mov	r6,a
      00706C 80 0A            [24] 1164 	sjmp	00201$
      00706E                       1165 00200$:
      00706E E5 18            [12] 1166 	mov	a,_process_action_sloc0_1_0
      007070 B4 01 00         [24] 1167 	cjne	a,#0x01,00457$
      007073                       1168 00457$:
      007073 92 1D            [24] 1169 	mov  _process_action_sloc1_1_0,c
      007075 E4               [12] 1170 	clr	a
      007076 33               [12] 1171 	rlc	a
      007077 FE               [12] 1172 	mov	r6,a
      007078                       1173 00201$:
      007078 EE               [12] 1174 	mov	a,r6
      007079 70 03            [24] 1175 	jnz	00458$
      00707B 02 71 BA         [24] 1176 	ljmp	00181$
      00707E                       1177 00458$:
                                   1178 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      00707E 12 73 CE         [24] 1179 	lcall	_ak820_outline_0148
      007081 C4               [12] 1180 	swap	a
      007082 03               [12] 1181 	rr	a
      007083 54 07            [12] 1182 	anl	a,#0x07
      007085 25 E0            [12] 1183 	add	a,acc
      007087 25 E0            [12] 1184 	add	a,acc
      007089 FF               [12] 1185 	mov	r7,a
                                   1186 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00708A 12 73 CE         [24] 1187 	lcall	_ak820_outline_0148
      00708D 54 0F            [12] 1188 	anl	a,#0x0f
      00708F FE               [12] 1189 	mov	r6,a
      007090 8F F0            [24] 1190 	mov	b,r7
      007092 05 F0            [12] 1191 	inc	b
      007094 EE               [12] 1192 	mov	a,r6
      007095 80 02            [24] 1193 	sjmp	00460$
      007097                       1194 00459$:
      007097 25 E0            [12] 1195 	add	a,acc
      007099                       1196 00460$:
      007099 D5 F0 FB         [24] 1197 	djnz	b,00459$
      00709C FE               [12] 1198 	mov	r6,a
                                   1199 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      00709D 12 73 CE         [24] 1200 	lcall	_ak820_outline_0148
      0070A0 30 E4 11         [24] 1201 	jnb	acc.4,00204$
      0070A3 8F F0            [24] 1202 	mov	b,r7
      0070A5 05 F0            [12] 1203 	inc	b
      0070A7 74 0F            [12] 1204 	mov	a,#0x0f
      0070A9 80 02            [24] 1205 	sjmp	00463$
      0070AB                       1206 00462$:
      0070AB 25 E0            [12] 1207 	add	a,acc
      0070AD                       1208 00463$:
      0070AD D5 F0 FB         [24] 1209 	djnz	b,00462$
      0070B0 F4               [12] 1210 	cpl	a
      0070B1 FF               [12] 1211 	mov	r7,a
      0070B2 80 02            [24] 1212 	sjmp	00205$
      0070B4                       1213 00204$:
      0070B4 7F 00            [12] 1214 	mov	r7,#0x00
      0070B6                       1215 00205$:
                                   1216 ;	quantum/action.c:666: bits |= mask;
      0070B6 EE               [12] 1217 	mov	a,r6
      0070B7 42 07            [12] 1218 	orl	ar7,a
                                   1219 ;	quantum/action.c:667: if (!on) {
      0070B9 90 08 21         [24] 1220 	mov	dptr,#_process_action_on_40000_669
      0070BC E0               [24] 1221 	movx	a,@dptr
      0070BD 70 31            [24] 1222 	jnz	00143$
                                   1223 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      0070BF 12 73 B3         [24] 1224 	lcall	_ak820_outline_0079
      0070C2 FE               [12] 1225 	mov	r6,a
      0070C3 2E               [12] 1226 	add	a,r6
                                   1227 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      0070C4 90 70 C8         [24] 1228 	mov	dptr,#00465$
      0070C7 73               [24] 1229 	jmp	@a+dptr
      0070C8                       1230 00465$:
      0070C8 80 06            [24] 1231 	sjmp	00132$
      0070CA 80 0C            [24] 1232 	sjmp	00133$
      0070CC 80 12            [24] 1233 	sjmp	00134$
      0070CE 80 18            [24] 1234 	sjmp	00135$
      0070D0                       1235 00132$:
      0070D0 8F 82            [24] 1236 	mov	dpl, r7
      0070D2 12 74 29         [24] 1237 	lcall	_default_layer_and
      0070D5 02 71 BA         [24] 1238 	ljmp	00181$
                                   1239 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      0070D8                       1240 00133$:
      0070D8 8F 82            [24] 1241 	mov	dpl, r7
      0070DA 12 74 18         [24] 1242 	lcall	_default_layer_or
      0070DD 02 71 BA         [24] 1243 	ljmp	00181$
                                   1244 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      0070E0                       1245 00134$:
      0070E0 8F 82            [24] 1246 	mov	dpl, r7
      0070E2 12 74 3F         [24] 1247 	lcall	_default_layer_xor
      0070E5 02 71 BA         [24] 1248 	ljmp	00181$
                                   1249 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      0070E8                       1250 00135$:
      0070E8 8F 82            [24] 1251 	mov	dpl, r7
      0070EA 12 74 0D         [24] 1252 	lcall	_default_layer_set
                                   1253 ;	quantum/action.c:673: }
      0070ED 02 71 BA         [24] 1254 	ljmp	00181$
      0070F0                       1255 00143$:
                                   1256 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      0070F0 12 73 B3         [24] 1257 	lcall	_ak820_outline_0079
      0070F3 FE               [12] 1258 	mov	r6,a
      0070F4 2E               [12] 1259 	add	a,r6
                                   1260 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      0070F5 90 70 F9         [24] 1261 	mov	dptr,#00466$
      0070F8 73               [24] 1262 	jmp	@a+dptr
      0070F9                       1263 00466$:
      0070F9 80 06            [24] 1264 	sjmp	00137$
      0070FB 80 0C            [24] 1265 	sjmp	00138$
      0070FD 80 12            [24] 1266 	sjmp	00139$
      0070FF 80 18            [24] 1267 	sjmp	00140$
      007101                       1268 00137$:
      007101 8F 82            [24] 1269 	mov	dpl, r7
      007103 12 75 C2         [24] 1270 	lcall	_layer_and
      007106 02 71 BA         [24] 1271 	ljmp	00181$
                                   1272 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      007109                       1273 00138$:
      007109 8F 82            [24] 1274 	mov	dpl, r7
      00710B 12 75 B1         [24] 1275 	lcall	_layer_or
      00710E 02 71 BA         [24] 1276 	ljmp	00181$
                                   1277 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      007111                       1278 00139$:
      007111 8F 82            [24] 1279 	mov	dpl, r7
      007113 12 75 D8         [24] 1280 	lcall	_layer_xor
      007116 02 71 BA         [24] 1281 	ljmp	00181$
                                   1282 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      007119                       1283 00140$:
      007119 8F 82            [24] 1284 	mov	dpl, r7
      00711B 12 75 4E         [24] 1285 	lcall	_layer_state_set
                                   1286 ;	quantum/action.c:683: break;
      00711E 02 71 BA         [24] 1287 	ljmp	00181$
                                   1288 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      007121                       1289 00147$:
                                   1290 ;	quantum/action.c:686: if (pressed) {
      007121 E5 18            [12] 1291 	mov	a,_process_action_sloc0_1_0
      007123 60 11            [24] 1292 	jz	00149$
                                   1293 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      007125 12 73 BC         [24] 1294 	lcall	_ak820_outline_0103
      007128 F5 82            [12] 1295 	mov	dpl,a
      00712A 12 74 AF         [24] 1296 	lcall	_layer_hold_on
                                   1297 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      00712D 12 73 AC         [24] 1298 	lcall	_ak820_outline_0069
      007130 12 72 F4         [24] 1299 	lcall	_register_mods
      007133 02 71 BA         [24] 1300 	ljmp	00181$
      007136                       1301 00149$:
                                   1302 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      007136 12 73 AC         [24] 1303 	lcall	_ak820_outline_0069
      007139 12 73 08         [24] 1304 	lcall	_unregister_mods
                                   1305 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      00713C 12 73 BC         [24] 1306 	lcall	_ak820_outline_0103
      00713F F5 82            [12] 1307 	mov	dpl,a
      007141 12 74 E7         [24] 1308 	lcall	_layer_hold_off
                                   1309 ;	quantum/action.c:693: break;
      007144 02 71 BA         [24] 1310 	ljmp	00181$
                                   1311 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      007147                       1312 00152$:
                                   1313 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      007147 12 73 CE         [24] 1314 	lcall	_ak820_outline_0148
      00714A FF               [12] 1315 	mov	r7,a
      00714B BF F1 02         [24] 1316 	cjne	r7,#0xf1,00468$
      00714E 80 0A            [24] 1317 	sjmp	00154$
      007150                       1318 00468$:
      007150 BF F2 02         [24] 1319 	cjne	r7,#0xf2,00469$
      007153 80 19            [24] 1320 	sjmp	00155$
      007155                       1321 00469$:
                                   1322 ;	quantum/action.c:712: momentary_layer_action:
      007155 BF F3 3B         [24] 1323 	cjne	r7,#0xf3,00160$
      007158 80 28            [24] 1324 	sjmp	00156$
      00715A                       1325 00154$:
                                   1326 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      00715A E5 18            [12] 1327 	mov	a,_process_action_sloc0_1_0
      00715C 60 08            [24] 1328 	jz	00206$
      00715E 12 73 92         [24] 1329 	lcall	_ak820_outline_0036
      007161 12 74 AF         [24] 1330 	lcall	_layer_hold_on
      007164 80 54            [24] 1331 	sjmp	00181$
      007166                       1332 00206$:
      007166 12 73 92         [24] 1333 	lcall	_ak820_outline_0036
      007169 12 74 E7         [24] 1334 	lcall	_layer_hold_off
                                   1335 ;	quantum/action.c:714: break;
                                   1336 ;	quantum/action.c:715: case OP_OFF_ON:
      00716C 80 4C            [24] 1337 	sjmp	00181$
      00716E                       1338 00155$:
                                   1339 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      00716E E5 18            [12] 1340 	mov	a,_process_action_sloc0_1_0
      007170 60 08            [24] 1341 	jz	00208$
      007172 12 73 92         [24] 1342 	lcall	_ak820_outline_0036
      007175 12 75 93         [24] 1343 	lcall	_layer_off
      007178 80 40            [24] 1344 	sjmp	00181$
      00717A                       1345 00208$:
      00717A 12 73 92         [24] 1346 	lcall	_ak820_outline_0036
      00717D 12 75 78         [24] 1347 	lcall	_layer_on
                                   1348 ;	quantum/action.c:717: break;
                                   1349 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007180 80 38            [24] 1350 	sjmp	00181$
      007182                       1351 00156$:
                                   1352 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007182 E5 18            [12] 1353 	mov	a,_process_action_sloc0_1_0
      007184 60 08            [24] 1354 	jz	00210$
      007186 12 73 92         [24] 1355 	lcall	_ak820_outline_0036
      007189 12 75 62         [24] 1356 	lcall	_layer_move
      00718C 80 2C            [24] 1357 	sjmp	00181$
      00718E                       1358 00210$:
      00718E 12 75 5C         [24] 1359 	lcall	_layer_clear
                                   1360 ;	quantum/action.c:720: break;
                                   1361 ;	quantum/action.c:766: default:
      007191 80 27            [24] 1362 	sjmp	00181$
      007193                       1363 00160$:
                                   1364 ;	quantum/action.c:773: if (pressed) {
      007193 E5 18            [12] 1365 	mov	a,_process_action_sloc0_1_0
      007195 60 08            [24] 1366 	jz	00163$
                                   1367 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007197 12 73 AC         [24] 1368 	lcall	_ak820_outline_0069
      00719A 12 71 D1         [24] 1369 	lcall	_register_code
                                   1370 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      00719D 80 1B            [24] 1371 	sjmp	00181$
      00719F                       1372 00163$:
                                   1373 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      00719F 12 73 CE         [24] 1374 	lcall	_ak820_outline_0148
      0071A2 FF               [12] 1375 	mov	r7,a
      0071A3 BF 39 0E         [24] 1376 	cjne	r7,#0x39,00175$
                                   1377 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      0071A6 7F 50            [12] 1378 	mov	r7,#0x50
      0071A8                       1379 00187$:
      0071A8 EF               [12] 1380 	mov	a,r7
      0071A9 60 09            [24] 1381 	jz	00175$
      0071AB 90 00 01         [24] 1382 	mov	dptr,#0x0001
      0071AE 12 56 A4         [24] 1383 	lcall	_mDelaymS
      0071B1 1F               [12] 1384 	dec	r7
                                   1385 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      0071B2 80 F4            [24] 1386 	sjmp	00187$
      0071B4                       1387 00175$:
                                   1388 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      0071B4 12 73 AC         [24] 1389 	lcall	_ak820_outline_0069
      0071B7 12 72 3E         [24] 1390 	lcall	_unregister_code
                                   1391 ;	quantum/action.c:866: }
      0071BA                       1392 00181$:
                                   1393 ;	quantum/action.c:887: switch (action.kind.id) {
      0071BA 90 08 1E         [24] 1394 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0071BD E0               [24] 1395 	movx	a,@dptr
      0071BE C4               [12] 1396 	swap	a
      0071BF 54 0F            [12] 1397 	anl	a,#0x0f
      0071C1 FF               [12] 1398 	mov	r7,a
      0071C2 BF 08 02         [24] 1399 	cjne	r7,#0x08,00478$
      0071C5 80 03            [24] 1400 	sjmp	00183$
      0071C7                       1401 00478$:
      0071C7 BF 09 06         [24] 1402 	cjne	r7,#0x09,00192$
                                   1403 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      0071CA                       1404 00183$:
                                   1405 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      0071CA 12 6A 2F         [24] 1406 	lcall	_host_keyboard_leds
                                   1407 ;	quantum/action.c:898: }
                                   1408 ;	quantum/action.c:951: }
      0071CD 02 93 CB         [24] 1409 	ljmp	_led_set
      0071D0                       1410 00192$:
      0071D0 22               [24] 1411 	ret
                                   1412 ;------------------------------------------------------------
                                   1413 ;Allocation info for local variables in function 'register_code'
                                   1414 ;------------------------------------------------------------
                                   1415 ;code          Allocated with name '_register_code_code_10000_703'
                                   1416 ;------------------------------------------------------------
                                   1417 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1418 ;	-----------------------------------------
                                   1419 ;	 function register_code
                                   1420 ;	-----------------------------------------
      0071D1                       1421 _register_code:
      0071D1 E5 82            [12] 1422 	mov	a,dpl
      0071D3 90 08 22         [24] 1423 	mov	dptr,#_register_code_code_10000_703
      0071D6 F0               [24] 1424 	movx	@dptr,a
                                   1425 ;	quantum/action.c:958: if (code == KC_NO) {
      0071D7 E0               [24] 1426 	movx	a,@dptr
      0071D8 FF               [12] 1427 	mov	r7,a
      0071D9 70 01            [24] 1428 	jnz	00123$
                                   1429 ;	quantum/action.c:959: return;
      0071DB 22               [24] 1430 	ret
      0071DC                       1431 00123$:
                                   1432 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      0071DC BF 04 00         [24] 1433 	cjne	r7,#0x04,00186$
      0071DF                       1434 00186$:
      0071DF 40 12            [24] 1435 	jc	00119$
      0071E1 EF               [12] 1436 	mov	a,r7
      0071E2 24 5B            [12] 1437 	add	a,#0xff - 0xa4
      0071E4 40 0D            [24] 1438 	jc	00119$
                                   1439 ;	free result
                                   1440 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      0071E6 8F 82            [24] 1441 	mov	dpl, r7
      0071E8 12 79 D8         [24] 1442 	lcall	_add_owned_key
      0071EB E5 82            [12] 1443 	mov	a, dpl
      0071ED 70 01            [24] 1444 	jnz	00104$
      0071EF 22               [24] 1445 	ret
      0071F0                       1446 00104$:
                                   1447 ;	quantum/action.c:1013: send_keyboard_report();
      0071F0 02 7C 70         [24] 1448 	ljmp	_send_keyboard_report
      0071F3                       1449 00119$:
                                   1450 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      0071F3 12 73 D3         [24] 1451 	lcall	_ak820_outline_0156
      0071F6 BF E0 00         [24] 1452 	cjne	r7,#0xe0,00190$
      0071F9                       1453 00190$:
      0071F9 40 1A            [24] 1454 	jc	00115$
      0071FB EF               [12] 1455 	mov	a,r7
      0071FC 24 18            [12] 1456 	add	a,#0xff - 0xe7
      0071FE 40 15            [24] 1457 	jc	00115$
                                   1458 ;	free result
                                   1459 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      007200 74 07            [12] 1460 	mov	a,#0x07
      007202 5F               [12] 1461 	anl	a,r7
      007203 12 73 9B         [24] 1462 	lcall	_ak820_outline_0059
      007206 80 02            [24] 1463 	sjmp	00194$
      007208                       1464 00193$:
      007208 25 E0            [12] 1465 	add	a,acc
      00720A                       1466 00194$:
      00720A D5 F0 FB         [24] 1467 	djnz	b,00193$
      00720D F5 82            [12] 1468 	mov	dpl,a
      00720F 12 79 34         [24] 1469 	lcall	_add_owned_mods
                                   1470 ;	quantum/action.c:1016: send_keyboard_report();
      007212 02 7C 70         [24] 1471 	ljmp	_send_keyboard_report
      007215                       1472 00115$:
                                   1473 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007215 12 73 D3         [24] 1474 	lcall	_ak820_outline_0156
      007218 BF A5 00         [24] 1475 	cjne	r7,#0xa5,00195$
      00721B                       1476 00195$:
      00721B 40 05            [24] 1477 	jc	00113$
      00721D EF               [12] 1478 	mov	a,r7
      00721E 24 58            [12] 1479 	add	a,#0xff - 0xa7
      007220 50 0D            [24] 1480 	jnc	00108$
                                   1481 ;	free result
      007222                       1482 00113$:
      007222 12 73 D3         [24] 1483 	lcall	_ak820_outline_0156
      007225 BF A8 00         [24] 1484 	cjne	r7,#0xa8,00198$
      007228                       1485 00198$:
      007228 40 13            [24] 1486 	jc	00125$
      00722A EF               [12] 1487 	mov	a,r7
      00722B 24 3D            [12] 1488 	add	a,#0xff - 0xc2
      00722D 40 0E            [24] 1489 	jc	00125$
                                   1490 ;	free result
      00722F                       1491 00108$:
                                   1492 ;	quantum/action.c:1021: owned_usage_key(code, true);
      00722F 12 73 D3         [24] 1493 	lcall	_ak820_outline_0156
      007232 90 0A 7D         [24] 1494 	mov	dptr,#_owned_usage_key_PARM_2
      007235 74 01            [12] 1495 	mov	a,#0x01
      007237 F0               [24] 1496 	movx	@dptr,a
      007238 8F 82            [24] 1497 	mov	dpl, r7
                                   1498 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1499 ;	quantum/action.c:1031: }
      00723A 02 7B 1B         [24] 1500 	ljmp	_owned_usage_key
      00723D                       1501 00125$:
      00723D 22               [24] 1502 	ret
                                   1503 ;------------------------------------------------------------
                                   1504 ;Allocation info for local variables in function 'unregister_code'
                                   1505 ;------------------------------------------------------------
                                   1506 ;code          Allocated with name '_unregister_code_code_10000_717'
                                   1507 ;------------------------------------------------------------
                                   1508 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1509 ;	-----------------------------------------
                                   1510 ;	 function unregister_code
                                   1511 ;	-----------------------------------------
      00723E                       1512 _unregister_code:
      00723E E5 82            [12] 1513 	mov	a,dpl
      007240 90 08 23         [24] 1514 	mov	dptr,#_unregister_code_code_10000_717
      007243 F0               [24] 1515 	movx	@dptr,a
                                   1516 ;	quantum/action.c:1038: if (code == KC_NO) {
      007244 E0               [24] 1517 	movx	a,@dptr
      007245 FF               [12] 1518 	mov	r7,a
      007246 70 01            [24] 1519 	jnz	00121$
                                   1520 ;	quantum/action.c:1039: return;
      007248 22               [24] 1521 	ret
      007249                       1522 00121$:
                                   1523 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      007249 BF 04 00         [24] 1524 	cjne	r7,#0x04,00184$
      00724C                       1525 00184$:
      00724C 40 12            [24] 1526 	jc	00117$
      00724E EF               [12] 1527 	mov	a,r7
      00724F 24 5B            [12] 1528 	add	a,#0xff - 0xa4
      007251 40 0D            [24] 1529 	jc	00117$
                                   1530 ;	free result
                                   1531 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      007253 8F 82            [24] 1532 	mov	dpl, r7
      007255 12 7A 52         [24] 1533 	lcall	_del_owned_key
      007258 E5 82            [12] 1534 	mov	a, dpl
      00725A 70 01            [24] 1535 	jnz	00102$
      00725C 22               [24] 1536 	ret
      00725D                       1537 00102$:
                                   1538 ;	quantum/action.c:1080: send_keyboard_report();
      00725D 02 7C 70         [24] 1539 	ljmp	_send_keyboard_report
      007260                       1540 00117$:
                                   1541 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007260 12 73 D9         [24] 1542 	lcall	_ak820_outline_0157
      007263 BF E0 00         [24] 1543 	cjne	r7,#0xe0,00188$
      007266                       1544 00188$:
      007266 40 1A            [24] 1545 	jc	00113$
      007268 EF               [12] 1546 	mov	a,r7
      007269 24 18            [12] 1547 	add	a,#0xff - 0xe7
      00726B 40 15            [24] 1548 	jc	00113$
                                   1549 ;	free result
                                   1550 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      00726D 74 07            [12] 1551 	mov	a,#0x07
      00726F 5F               [12] 1552 	anl	a,r7
      007270 12 73 9B         [24] 1553 	lcall	_ak820_outline_0059
      007273 80 02            [24] 1554 	sjmp	00192$
      007275                       1555 00191$:
      007275 25 E0            [12] 1556 	add	a,acc
      007277                       1557 00192$:
      007277 D5 F0 FB         [24] 1558 	djnz	b,00191$
      00727A F5 82            [12] 1559 	mov	dpl,a
      00727C 12 79 44         [24] 1560 	lcall	_del_owned_mods
                                   1561 ;	quantum/action.c:1083: send_keyboard_report();
      00727F 02 7C 70         [24] 1562 	ljmp	_send_keyboard_report
      007282                       1563 00113$:
                                   1564 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007282 12 73 D9         [24] 1565 	lcall	_ak820_outline_0157
      007285 BF A5 00         [24] 1566 	cjne	r7,#0xa5,00193$
      007288                       1567 00193$:
      007288 40 05            [24] 1568 	jc	00111$
      00728A EF               [12] 1569 	mov	a,r7
      00728B 24 58            [12] 1570 	add	a,#0xff - 0xa7
      00728D 50 0D            [24] 1571 	jnc	00106$
                                   1572 ;	free result
      00728F                       1573 00111$:
      00728F 12 73 D9         [24] 1574 	lcall	_ak820_outline_0157
      007292 BF A8 00         [24] 1575 	cjne	r7,#0xa8,00196$
      007295                       1576 00196$:
      007295 40 12            [24] 1577 	jc	00123$
      007297 EF               [12] 1578 	mov	a,r7
      007298 24 3D            [12] 1579 	add	a,#0xff - 0xc2
      00729A 40 0D            [24] 1580 	jc	00123$
                                   1581 ;	free result
      00729C                       1582 00106$:
                                   1583 ;	quantum/action.c:1088: owned_usage_key(code, false);
      00729C 12 73 D9         [24] 1584 	lcall	_ak820_outline_0157
      00729F 90 0A 7D         [24] 1585 	mov	dptr,#_owned_usage_key_PARM_2
      0072A2 E4               [12] 1586 	clr	a
      0072A3 F0               [24] 1587 	movx	@dptr,a
      0072A4 8F 82            [24] 1588 	mov	dpl, r7
                                   1589 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1590 ;	quantum/action.c:1098: }
      0072A6 02 7B 1B         [24] 1591 	ljmp	_owned_usage_key
      0072A9                       1592 00123$:
      0072A9 22               [24] 1593 	ret
                                   1594 ;------------------------------------------------------------
                                   1595 ;Allocation info for local variables in function 'tap_code_delay'
                                   1596 ;------------------------------------------------------------
                                   1597 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1598 ;code          Allocated with name '_tap_code_delay_code_10000_730'
                                   1599 ;i             Allocated with name '_tap_code_delay_i_20000_732'
                                   1600 ;i             Allocated with name '_tap_code_delay_i_50000_735'
                                   1601 ;------------------------------------------------------------
                                   1602 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1603 ;	-----------------------------------------
                                   1604 ;	 function tap_code_delay
                                   1605 ;	-----------------------------------------
      0072AA                       1606 _tap_code_delay:
      0072AA E5 82            [12] 1607 	mov	a,dpl
      0072AC 90 08 26         [24] 1608 	mov	dptr,#_tap_code_delay_code_10000_730
      0072AF F0               [24] 1609 	movx	@dptr,a
                                   1610 ;	quantum/action.c:1106: register_code(code);
      0072B0 E0               [24] 1611 	movx	a,@dptr
      0072B1 FF               [12] 1612 	mov	r7,a
      0072B2 F5 82            [12] 1613 	mov	dpl,a
      0072B4 C0 07            [24] 1614 	push	ar7
      0072B6 12 71 D1         [24] 1615 	lcall	_register_code
      0072B9 D0 07            [24] 1616 	pop	ar7
                                   1617 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      0072BB 90 08 24         [24] 1618 	mov	dptr,#_tap_code_delay_PARM_2
      0072BE 12 43 08         [24] 1619 	lcall	_ak820_outline_0095
      0072C1                       1620 00110$:
      0072C1 ED               [12] 1621 	mov	a,r5
      0072C2 4E               [12] 1622 	orl	a,r6
      0072C3 60 0D            [24] 1623 	jz	00105$
                                   1624 ;	quantum/action.c:1108: wait_ms(1);
      0072C5 90 00 01         [24] 1625 	mov	dptr,#0x0001
      0072C8 12 56 A4         [24] 1626 	lcall	_mDelaymS
                                   1627 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      0072CB 1D               [12] 1628 	dec	r5
      0072CC BD FF 01         [24] 1629 	cjne	r5,#0xff,00141$
      0072CF 1E               [12] 1630 	dec	r6
      0072D0                       1631 00141$:
      0072D0 80 EF            [24] 1632 	sjmp	00110$
      0072D2                       1633 00105$:
                                   1634 ;	quantum/action.c:1110: unregister_code(code);
      0072D2 8F 82            [24] 1635 	mov	dpl, r7
                                   1636 ;	quantum/action.c:1111: }
      0072D4 02 72 3E         [24] 1637 	ljmp	_unregister_code
                                   1638 ;------------------------------------------------------------
                                   1639 ;Allocation info for local variables in function 'tap_code'
                                   1640 ;------------------------------------------------------------
                                   1641 ;code          Allocated with name '_tap_code_code_10000_737'
                                   1642 ;------------------------------------------------------------
                                   1643 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1644 ;	-----------------------------------------
                                   1645 ;	 function tap_code
                                   1646 ;	-----------------------------------------
      0072D7                       1647 _tap_code:
      0072D7 E5 82            [12] 1648 	mov	a,dpl
      0072D9 90 08 27         [24] 1649 	mov	dptr,#_tap_code_code_10000_737
      0072DC F0               [24] 1650 	movx	@dptr,a
                                   1651 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0072DD E0               [24] 1652 	movx	a,@dptr
      0072DE FF               [12] 1653 	mov	r7,a
      0072DF BF 39 04         [24] 1654 	cjne	r7,#0x39,00103$
      0072E2 7E 50            [12] 1655 	mov	r6,#0x50
      0072E4 80 02            [24] 1656 	sjmp	00104$
      0072E6                       1657 00103$:
      0072E6 7E 00            [12] 1658 	mov	r6,#0x00
      0072E8                       1659 00104$:
      0072E8 90 08 24         [24] 1660 	mov	dptr,#_tap_code_delay_PARM_2
      0072EB EE               [12] 1661 	mov	a,r6
      0072EC 12 38 58         [24] 1662 	lcall	_ak820_outline_0115
      0072EF 8F 82            [24] 1663 	mov	dpl, r7
                                   1664 ;	quantum/action.c:1119: }
      0072F1 02 72 AA         [24] 1665 	ljmp	_tap_code_delay
                                   1666 ;------------------------------------------------------------
                                   1667 ;Allocation info for local variables in function 'register_mods'
                                   1668 ;------------------------------------------------------------
                                   1669 ;mods          Allocated with name '_register_mods_mods_10000_739'
                                   1670 ;------------------------------------------------------------
                                   1671 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1672 ;	-----------------------------------------
                                   1673 ;	 function register_mods
                                   1674 ;	-----------------------------------------
      0072F4                       1675 _register_mods:
      0072F4 E5 82            [12] 1676 	mov	a,dpl
      0072F6 90 08 28         [24] 1677 	mov	dptr,#_register_mods_mods_10000_739
      0072F9 F0               [24] 1678 	movx	@dptr,a
                                   1679 ;	quantum/action.c:1126: if (mods) {
      0072FA E0               [24] 1680 	movx	a,@dptr
      0072FB FF               [12] 1681 	mov	r7,a
      0072FC E0               [24] 1682 	movx	a,@dptr
      0072FD 60 08            [24] 1683 	jz	00103$
                                   1684 ;	quantum/action.c:1127: add_owned_mods(mods);
      0072FF 8F 82            [24] 1685 	mov	dpl, r7
      007301 12 79 34         [24] 1686 	lcall	_add_owned_mods
                                   1687 ;	quantum/action.c:1128: send_keyboard_report();
                                   1688 ;	quantum/action.c:1130: }
      007304 02 7C 70         [24] 1689 	ljmp	_send_keyboard_report
      007307                       1690 00103$:
      007307 22               [24] 1691 	ret
                                   1692 ;------------------------------------------------------------
                                   1693 ;Allocation info for local variables in function 'unregister_mods'
                                   1694 ;------------------------------------------------------------
                                   1695 ;mods          Allocated with name '_unregister_mods_mods_10000_743'
                                   1696 ;------------------------------------------------------------
                                   1697 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1698 ;	-----------------------------------------
                                   1699 ;	 function unregister_mods
                                   1700 ;	-----------------------------------------
      007308                       1701 _unregister_mods:
      007308 E5 82            [12] 1702 	mov	a,dpl
      00730A 90 08 29         [24] 1703 	mov	dptr,#_unregister_mods_mods_10000_743
      00730D F0               [24] 1704 	movx	@dptr,a
                                   1705 ;	quantum/action.c:1137: if (mods) {
      00730E E0               [24] 1706 	movx	a,@dptr
      00730F FF               [12] 1707 	mov	r7,a
      007310 E0               [24] 1708 	movx	a,@dptr
      007311 60 08            [24] 1709 	jz	00103$
                                   1710 ;	quantum/action.c:1138: del_owned_mods(mods);
      007313 8F 82            [24] 1711 	mov	dpl, r7
      007315 12 79 44         [24] 1712 	lcall	_del_owned_mods
                                   1713 ;	quantum/action.c:1139: send_keyboard_report();
                                   1714 ;	quantum/action.c:1141: }
      007318 02 7C 70         [24] 1715 	ljmp	_send_keyboard_report
      00731B                       1716 00103$:
      00731B 22               [24] 1717 	ret
                                   1718 ;------------------------------------------------------------
                                   1719 ;Allocation info for local variables in function 'register_weak_mods'
                                   1720 ;------------------------------------------------------------
                                   1721 ;mods          Allocated with name '_register_weak_mods_mods_10000_747'
                                   1722 ;------------------------------------------------------------
                                   1723 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1724 ;	-----------------------------------------
                                   1725 ;	 function register_weak_mods
                                   1726 ;	-----------------------------------------
      00731C                       1727 _register_weak_mods:
      00731C E5 82            [12] 1728 	mov	a,dpl
      00731E 90 08 2A         [24] 1729 	mov	dptr,#_register_weak_mods_mods_10000_747
      007321 F0               [24] 1730 	movx	@dptr,a
                                   1731 ;	quantum/action.c:1148: if (mods) {
      007322 E0               [24] 1732 	movx	a,@dptr
      007323 FF               [12] 1733 	mov	r7,a
      007324 E0               [24] 1734 	movx	a,@dptr
      007325 60 08            [24] 1735 	jz	00103$
                                   1736 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      007327 8F 82            [24] 1737 	mov	dpl, r7
      007329 12 79 53         [24] 1738 	lcall	_add_owned_weak_mods
                                   1739 ;	quantum/action.c:1150: send_keyboard_report();
                                   1740 ;	quantum/action.c:1152: }
      00732C 02 7C 70         [24] 1741 	ljmp	_send_keyboard_report
      00732F                       1742 00103$:
      00732F 22               [24] 1743 	ret
                                   1744 ;------------------------------------------------------------
                                   1745 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1746 ;------------------------------------------------------------
                                   1747 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_751'
                                   1748 ;------------------------------------------------------------
                                   1749 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1750 ;	-----------------------------------------
                                   1751 ;	 function unregister_weak_mods
                                   1752 ;	-----------------------------------------
      007330                       1753 _unregister_weak_mods:
      007330 E5 82            [12] 1754 	mov	a,dpl
      007332 90 08 2B         [24] 1755 	mov	dptr,#_unregister_weak_mods_mods_10000_751
      007335 F0               [24] 1756 	movx	@dptr,a
                                   1757 ;	quantum/action.c:1159: if (mods) {
      007336 E0               [24] 1758 	movx	a,@dptr
      007337 FF               [12] 1759 	mov	r7,a
      007338 E0               [24] 1760 	movx	a,@dptr
      007339 60 08            [24] 1761 	jz	00103$
                                   1762 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      00733B 8F 82            [24] 1763 	mov	dpl, r7
      00733D 12 79 63         [24] 1764 	lcall	_del_owned_weak_mods
                                   1765 ;	quantum/action.c:1161: send_keyboard_report();
                                   1766 ;	quantum/action.c:1163: }
      007340 02 7C 70         [24] 1767 	ljmp	_send_keyboard_report
      007343                       1768 00103$:
      007343 22               [24] 1769 	ret
                                   1770 ;------------------------------------------------------------
                                   1771 ;Allocation info for local variables in function 'clear_keyboard'
                                   1772 ;------------------------------------------------------------
                                   1773 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1774 ;	-----------------------------------------
                                   1775 ;	 function clear_keyboard
                                   1776 ;	-----------------------------------------
      007344                       1777 _clear_keyboard:
                                   1778 ;	quantum/action.c:1170: clear_mods();
      007344 12 7C EA         [24] 1779 	lcall	_clear_mods
                                   1780 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1781 ;	quantum/action.c:1172: }
      007347 02 73 4A         [24] 1782 	ljmp	_clear_keyboard_but_mods
                                   1783 ;------------------------------------------------------------
                                   1784 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1785 ;------------------------------------------------------------
                                   1786 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1787 ;	-----------------------------------------
                                   1788 ;	 function clear_keyboard_but_mods
                                   1789 ;	-----------------------------------------
      00734A                       1790 _clear_keyboard_but_mods:
                                   1791 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00734A 90 0D 88         [24] 1792 	mov	dptr,#_actual_keyboard_report
      00734D 12 6C ED         [24] 1793 	lcall	_clear_keys_from_report
                                   1794 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1795 ;	quantum/action.c:1181: }
      007350 02 73 53         [24] 1796 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1797 ;------------------------------------------------------------
                                   1798 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1799 ;------------------------------------------------------------
                                   1800 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1801 ;	-----------------------------------------
                                   1802 ;	 function clear_keyboard_but_mods_and_keys
                                   1803 ;	-----------------------------------------
      007353                       1804 _clear_keyboard_but_mods_and_keys:
                                   1805 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007353 12 46 19         [24] 1806 	lcall	_ak820_tapping_cancel
                                   1807 ;	quantum/action.c:1209: ak820_combo_cancel();
      007356 12 35 28         [24] 1808 	lcall	_ak820_combo_cancel
                                   1809 ;	quantum/action.c:1212: repeat_key_cancel();
      007359 12 9C CB         [24] 1810 	lcall	_repeat_key_cancel
                                   1811 ;	quantum/action.c:1214: clear_owned_mods();
      00735C 12 79 73         [24] 1812 	lcall	_clear_owned_mods
                                   1813 ;	quantum/action.c:1215: clear_owned_keys();
      00735F 12 79 AB         [24] 1814 	lcall	_clear_owned_keys
                                   1815 ;	quantum/action.c:1216: clear_owned_usages();
      007362 12 7A E3         [24] 1816 	lcall	_clear_owned_usages
                                   1817 ;	quantum/action.c:1217: layer_hold_clear();
      007365 12 75 1F         [24] 1818 	lcall	_layer_hold_clear
                                   1819 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007368 12 98 6A         [24] 1820 	lcall	_clear_macro_tri_layer
                                   1821 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00736B 90 0D 88         [24] 1822 	mov	dptr,#_actual_keyboard_report
      00736E 12 6C ED         [24] 1823 	lcall	_clear_keys_from_report
                                   1824 ;	quantum/action.c:1224: host_system_send(0);
      007371 90 00 00         [24] 1825 	mov	dptr,#0x0000
      007374 12 6A CA         [24] 1826 	lcall	_host_system_send
                                   1827 ;	quantum/action.c:1225: host_consumer_send(0);
      007377 90 00 00         [24] 1828 	mov	dptr,#0x0000
      00737A 12 6A FA         [24] 1829 	lcall	_host_consumer_send
                                   1830 ;	quantum/action.c:1227: clear_weak_mods();
      00737D 12 7D 1F         [24] 1831 	lcall	_clear_weak_mods
                                   1832 ;	quantum/action.c:1228: send_keyboard_report();
                                   1833 ;	quantum/action.c:1236: }
      007380 02 7C 70         [24] 1834 	ljmp	_send_keyboard_report
                                   1835 ;------------------------------------------------------------
                                   1836 ;Allocation info for local variables in function 'is_tap_record'
                                   1837 ;------------------------------------------------------------
                                   1838 ;record        Allocated with name '_is_tap_record_record_10000_767'
                                   1839 ;action        Allocated with name '_is_tap_record_action_10001_771'
                                   1840 ;------------------------------------------------------------
                                   1841 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1842 ;	-----------------------------------------
                                   1843 	.area CSEG    (CODE)
                                   1844 	.area CONST   (CODE)
                                   1845 	.area XINIT   (CODE)
      00BC3B                       1846 __xinit__disable_action_cache:
      00BC3B 00                    1847 	.db #0x00	;  0
                                   1848 	.area CABS    (ABS,CODE)
                                   1849 
                                   1850 ; Experimental exact instruction outlining.
                                   1851 	.globl _ak820_outline_0004
                                   1852 	.globl _ak820_outline_0008
                                   1853 	.globl _ak820_outline_0009
                                   1854 	.globl _ak820_outline_0010
                                   1855 	.globl _ak820_outline_0011
                                   1856 	.globl _ak820_outline_0014
                                   1857 	.globl _ak820_outline_0017
                                   1858 	.globl _ak820_outline_0018
                                   1859 	.globl _ak820_outline_0036
                                   1860 	.globl _ak820_outline_0047
                                   1861 	.globl _ak820_outline_0054
                                   1862 	.globl _ak820_outline_0059
                                   1863 	.globl _ak820_outline_0066
                                   1864 	.globl _ak820_outline_0067
                                   1865 	.globl _ak820_outline_0069
                                   1866 	.globl _ak820_outline_0070
                                   1867 	.globl _ak820_outline_0079
                                   1868 	.globl _ak820_outline_0095
                                   1869 	.globl _ak820_outline_0099
                                   1870 	.globl _ak820_outline_0100
                                   1871 	.globl _ak820_outline_0103
                                   1872 	.globl _ak820_outline_0111
                                   1873 	.globl _ak820_outline_0112
                                   1874 	.globl _ak820_outline_0115
                                   1875 	.globl _ak820_outline_0116
                                   1876 	.globl _ak820_outline_0122
                                   1877 	.globl _ak820_outline_0133
                                   1878 	.globl _ak820_outline_0138
                                   1879 	.globl _ak820_outline_0148
                                   1880 	.globl _ak820_outline_0156
                                   1881 	.globl _ak820_outline_0157
                                   1882 	.globl _ak820_outline_0159
                                   1883 
                                   1884 	.area CSEG (CODE)
                                   1885 ; function ak820_outline_0017
      007383                       1886 _ak820_outline_0017:
      007383 8E 82            [24] 1887 	mov	dpl,r6
      007385 8F 83            [24] 1888 	mov	dph,r7
      007387 A3               [24] 1889 	inc	dptr
      007388 E0               [24] 1890 	movx	a,@dptr
      007389 FC               [12] 1891 	mov	r4,a
      00738A 7D 00            [12] 1892 	mov	r5,#0x00
      00738C 8E 82            [24] 1893 	mov	dpl,r6
      00738E 8F 83            [24] 1894 	mov	dph,r7
      007390 E0               [24] 1895 	movx	a,@dptr
      007391 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0036
      007392                       1900 _ak820_outline_0036:
      007392 90 08 1E         [24] 1901 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007395 E0               [24] 1902 	movx	a,@dptr
      007396 54 1F            [12] 1903 	anl	a,#0x1f
      007398 F5 82            [12] 1904 	mov	dpl,a
      00739A 22               [24] 1905 	ret
                                   1906 
                                   1907 	.area CSEG (CODE)
                                   1908 ; function ak820_outline_0059
      00739B                       1909 _ak820_outline_0059:
      00739B F5 F0            [12] 1910 	mov	b,a
      00739D 05 F0            [12] 1911 	inc	b
      00739F 74 01            [12] 1912 	mov	a,#0x01
      0073A1 22               [24] 1913 	ret
                                   1914 
                                   1915 	.area CSEG (CODE)
                                   1916 ; function ak820_outline_0066
      0073A2                       1917 _ak820_outline_0066:
      0073A2 90 0D 67         [24] 1918 	mov	dptr,#___memcpy_PARM_3
      0073A5 74 06            [12] 1919 	mov	a,#0x06
      0073A7 F0               [24] 1920 	movx	@dptr,a
      0073A8 E4               [12] 1921 	clr	a
      0073A9 A3               [24] 1922 	inc	dptr
      0073AA F0               [24] 1923 	movx	@dptr,a
      0073AB 22               [24] 1924 	ret
                                   1925 
                                   1926 	.area CSEG (CODE)
                                   1927 ; function ak820_outline_0069
      0073AC                       1928 _ak820_outline_0069:
      0073AC 90 08 1D         [24] 1929 	mov	dptr,#_process_action_PARM_2
      0073AF E0               [24] 1930 	movx	a,@dptr
      0073B0 F5 82            [12] 1931 	mov	dpl,a
      0073B2 22               [24] 1932 	ret
                                   1933 
                                   1934 	.area CSEG (CODE)
                                   1935 ; function ak820_outline_0079
      0073B3                       1936 _ak820_outline_0079:
      0073B3 90 08 1E         [24] 1937 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0073B6 E0               [24] 1938 	movx	a,@dptr
      0073B7 03               [12] 1939 	rr	a
      0073B8 03               [12] 1940 	rr	a
      0073B9 54 03            [12] 1941 	anl	a,#0x03
      0073BB 22               [24] 1942 	ret
                                   1943 
                                   1944 	.area CSEG (CODE)
                                   1945 ; function ak820_outline_0103
      0073BC                       1946 _ak820_outline_0103:
      0073BC 90 08 1E         [24] 1947 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0073BF E0               [24] 1948 	movx	a,@dptr
      0073C0 54 0F            [12] 1949 	anl	a,#0x0f
      0073C2 22               [24] 1950 	ret
                                   1951 
                                   1952 	.area CSEG (CODE)
                                   1953 ; function ak820_outline_0122
      0073C3                       1954 _ak820_outline_0122:
      0073C3 90 08 1D         [24] 1955 	mov	dptr,#_process_action_PARM_2
      0073C6 E0               [24] 1956 	movx	a,@dptr
      0073C7 FE               [12] 1957 	mov	r6,a
      0073C8 A3               [24] 1958 	inc	dptr
      0073C9 E0               [24] 1959 	movx	a,@dptr
      0073CA 54 03            [12] 1960 	anl	a,#0x03
      0073CC FF               [12] 1961 	mov	r7,a
      0073CD 22               [24] 1962 	ret
                                   1963 
                                   1964 	.area CSEG (CODE)
                                   1965 ; function ak820_outline_0148
      0073CE                       1966 _ak820_outline_0148:
      0073CE 90 08 1D         [24] 1967 	mov	dptr,#_process_action_PARM_2
      0073D1 E0               [24] 1968 	movx	a,@dptr
      0073D2 22               [24] 1969 	ret
                                   1970 
                                   1971 	.area CSEG (CODE)
                                   1972 ; function ak820_outline_0156
      0073D3                       1973 _ak820_outline_0156:
      0073D3 90 08 22         [24] 1974 	mov	dptr,#_register_code_code_10000_703
      0073D6 E0               [24] 1975 	movx	a,@dptr
      0073D7 FF               [12] 1976 	mov	r7,a
      0073D8 22               [24] 1977 	ret
                                   1978 
                                   1979 	.area CSEG (CODE)
                                   1980 ; function ak820_outline_0157
      0073D9                       1981 _ak820_outline_0157:
      0073D9 90 08 23         [24] 1982 	mov	dptr,#_unregister_code_code_10000_717
      0073DC E0               [24] 1983 	movx	a,@dptr
      0073DD FF               [12] 1984 	mov	r7,a
      0073DE 22               [24] 1985 	ret
