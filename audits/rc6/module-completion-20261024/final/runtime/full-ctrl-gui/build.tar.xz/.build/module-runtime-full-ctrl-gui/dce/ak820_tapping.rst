                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000C                        552 _ak820_tapping_before_sloc0_1_0:
      00000C                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      00059A                        562 _source_state:
      00059A                        563 	.ds 130
      00061C                        564 _pending_time:
      00061C                        565 	.ds 2
      00061E                        566 _pending_code:
      00061E                        567 	.ds 2
      000620                        568 _ak820_tapping_source_PARM_1:
      000620                        569 	.ds 2
      000622                        570 _hold_PARM_2:
      000622                        571 	.ds 1
      000623                        572 _hold_code_10000_602:
      000623                        573 	.ds 2
      000625                        574 _hold_mods_30000_605:
      000625                        575 	.ds 1
      000626                        576 _commit_pending_id_10000_611:
      000626                        577 	.ds 1
      000627                        578 _ak820_tapping_before_event_10000_612:
      000627                        579 	.ds 2
      000629                        580 _ak820_tapping_process_record_10000_623:
      000629                        581 	.ds 2
      00062B                        582 _ak820_tapping_process_code_10000_624:
      00062B                        583 	.ds 2
      00062D                        584 _ak820_tapping_process_sc_mods_10000_624:
      00062D                        585 	.ds 1
      00062E                        586 _ak820_oneshot_mods::
      00062E                        587 	.ds 1
      00062F                        588 _ak820_oneshot_consumed::
      00062F                        589 	.ds 1
      000630                        590 _ak820_oneshot_process_PARM_2:
      000630                        591 	.ds 1
      000631                        592 _ak820_oneshot_process_PARM_3:
      000631                        593 	.ds 1
      000632                        594 _ak820_oneshot_process_code_10000_649:
      000632                        595 	.ds 2
      000634                        596 _ak820_oneshot_process_mods_10000_650:
      000634                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000D83                        606 _pending:
      000D83                        607 	.ds 1
      000D84                        608 _ak820_oneshot_target::
      000D84                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      004361                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004361 90 06 21         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      004364 E0               [24]  656 	movx	a,@dptr
      004365 FF               [12]  657 	mov	r7,a
      004366 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      004369                        659 00147$:
      004369 50 14            [24]  660 	jnc	00102$
      00436B 90 06 20         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      00436E E0               [24]  662 	movx	a,@dptr
      00436F FE               [12]  663 	mov	r6,a
      004370 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      004373                        665 00149$:
      004373 50 0A            [24]  666 	jnc	00102$
      004375 8F 05            [24]  667 	mov	ar5,r7
      004377 ED               [12]  668 	mov	a,r5
      004378 12 38 90         [24]  669 	lcall	_ak820_outline_0184
      00437B 2E               [12]  670 	add	a,r6
      00437C F5 82            [12]  671 	mov	dpl,a
      00437E 22               [24]  672 	ret
      00437F                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      00437F 90 06 20         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      004382 E0               [24]  676 	movx	a,@dptr
      004383 FE               [12]  677 	mov	r6,a
      004384 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      004387                        679 00151$:
      004387 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004389 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      00438C 75 82 80         [24]  683 	mov	dpl, #0x80
      00438F 22               [24]  684 	ret
      004390                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004390 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      004393 75 82 81         [24]  688 	mov	dpl, #0x81
      004396 22               [24]  689 	ret
      004397                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004397 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      00439A 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_602'
                                    700 ;mods          Allocated with name '_hold_mods_30000_605'
                                    701 ;layer         Allocated with name '_hold_layer_30000_608'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      00439B                        707 _hold:
      00439B 12 38 49         [24]  708 	lcall	_ak820_outline_0104
      00439E 90 06 23         [24]  709 	mov	dptr,#_hold_code_10000_602
      0043A1 12 38 4E         [24]  710 	lcall	_ak820_outline_0105
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      0043A4 90 06 23         [24]  712 	mov	dptr,#_hold_code_10000_602
      0043A7 12 37 CB         [24]  713 	lcall	_ak820_outline_0010
      0043AA 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      0043AC 2D               [12]  715 	add	a,r5
      0043AD 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      0043AF 8F 05            [24]  718 	mov	ar5,r7
      0043B1 53 05 1F         [24]  719 	anl	ar5,#0x1f
      0043B4 90 06 25         [24]  720 	mov	dptr,#_hold_mods_30000_605
      0043B7 ED               [12]  721 	mov	a,r5
      0043B8 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      0043B9 ED               [12]  724 	mov	a,r5
      0043BA 30 E4 08         [24]  725 	jnb	acc.4,00102$
      0043BD ED               [12]  726 	mov	a,r5
      0043BE C4               [12]  727 	swap	a
      0043BF 54 F0            [12]  728 	anl	a,#0xf0
      0043C1 90 06 25         [24]  729 	mov	dptr,#_hold_mods_30000_605
      0043C4 F0               [24]  730 	movx	@dptr,a
      0043C5                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      0043C5 90 06 22         [24]  733 	mov	dptr,#_hold_PARM_2
      0043C8 E0               [24]  734 	movx	a,@dptr
      0043C9 60 09            [24]  735 	jz	00104$
      0043CB 90 06 25         [24]  736 	mov	dptr,#_hold_mods_30000_605
      0043CE E0               [24]  737 	movx	a,@dptr
      0043CF F5 82            [12]  738 	mov	dpl,a
      0043D1 02 75 9B         [24]  739 	ljmp	_register_mods
      0043D4                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      0043D4 90 06 25         [24]  742 	mov	dptr,#_hold_mods_30000_605
      0043D7 E0               [24]  743 	movx	a,@dptr
      0043D8 F5 82            [12]  744 	mov	dpl,a
      0043DA 02 75 AF         [24]  745 	ljmp	_unregister_mods
      0043DD                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      0043DD 8F 06            [24]  748 	mov	ar6,r7
      0043DF 74 0F            [12]  749 	mov	a,#0x0f
      0043E1 5E               [12]  750 	anl	a,r6
      0043E2 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      0043E3 90 06 22         [24]  753 	mov	dptr,#_hold_PARM_2
      0043E6 E0               [24]  754 	movx	a,@dptr
      0043E7 60 05            [24]  755 	jz	00107$
      0043E9 8F 82            [24]  756 	mov	dpl, r7
      0043EB 02 77 5F         [24]  757 	ljmp	_layer_hold_on
      0043EE                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      0043EE 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0043F0 02 77 97         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_611'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      0043F3                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      0043F3 90 0D 83         [24]  774 	mov	dptr,#_pending
      0043F6 E0               [24]  775 	movx	a,@dptr
      0043F7 90 06 26         [24]  776 	mov	dptr,#_commit_pending_id_10000_611
      0043FA F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      0043FB 12 48 96         [24]  779 	lcall	_ak820_outline_0150
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      0043FE 90 06 26         [24]  781 	mov	dptr,#_commit_pending_id_10000_611
      004401 E0               [24]  782 	movx	a,@dptr
      004402 24 9A            [12]  783 	add	a,#_source_state
      004404 FF               [12]  784 	mov	r7,a
      004405 E4               [12]  785 	clr	a
      004406 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      004408 FE               [12]  787 	mov	r6,a
      004409 12 43 46         [24]  788 	lcall	_ak820_outline_0153
      00440C E0               [24]  789 	movx	a,@dptr
      00440D FD               [12]  790 	mov	r5,a
      00440E 43 05 04         [24]  791 	orl	ar5,#0x04
      004411 12 43 46         [24]  792 	lcall	_ak820_outline_0153
      004414 ED               [12]  793 	mov	a,r5
      004415 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      004416 90 06 1E         [24]  796 	mov	dptr,#_pending_code
      004419 12 38 00         [24]  797 	lcall	_ak820_outline_0050
      00441C 90 06 22         [24]  798 	mov	dptr,#_hold_PARM_2
      00441F 12 48 64         [24]  799 	lcall	_ak820_outline_0054
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004422 02 43 9B         [24]  801 	ljmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_612'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_613'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      004425                        812 _ak820_tapping_before:
      004425 12 38 49         [24]  813 	lcall	_ak820_outline_0104
      004428 90 06 27         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_612
      00442B 12 38 4E         [24]  815 	lcall	_ak820_outline_0105
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      00442E 90 06 27         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_612
      004431 12 37 CB         [24]  818 	lcall	_ak820_outline_0010
      004434 12 48 31         [24]  819 	lcall	_ak820_outline_0021
      004437 C0 07            [24]  820 	push	ar7
      004439 C0 06            [24]  821 	push	ar6
      00443B 12 B6 FA         [24]  822 	lcall	___memcpy
      00443E 12 43 61         [24]  823 	lcall	_ak820_tapping_source
      004441 AD 82            [24]  824 	mov	r5, dpl
      004443 D0 06            [24]  825 	pop	ar6
      004445 D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004447 90 0D F4         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      00444A E0               [24]  829 	movx	a,@dptr
      00444B 60 21            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00444D 74 04            [12]  832 	mov	a,#0x04
      00444F 12 48 26         [24]  833 	lcall	_ak820_outline_0012
      004452 60 16            [24]  834 	jz	00102$
      004454 BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      004457 80 11            [24]  836 	sjmp	00102$
      004459                        837 00218$:
      004459 74 05            [12]  838 	mov	a,#0x05
      00445B 12 48 26         [24]  839 	lcall	_ak820_outline_0012
      00445E 70 0A            [24]  840 	jnz	00102$
      004460 ED               [12]  841 	mov	a,r5
      004461 12 48 4B         [24]  842 	lcall	_ak820_outline_0023
      004464 53 02 FD         [24]  843 	anl	ar2,#0xfd
      004467 12 48 8F         [24]  844 	lcall	_ak820_outline_0090
      00446A                        845 00102$:
                                    846 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      00446A 75 82 00         [24]  847 	mov	dpl, #0x00
      00446D 22               [24]  848 	ret
      00446E                        849 00106$:
                                    850 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      00446E 90 0D 83         [24]  851 	mov	dptr,#_pending
      004471 E0               [24]  852 	movx	a,@dptr
      004472 FC               [12]  853 	mov	r4,a
      004473 BC FF 02         [24]  854 	cjne	r4,#0xff,00220$
      004476 80 3B            [24]  855 	sjmp	00108$
      004478                        856 00220$:
      004478 12 37 F8         [24]  857 	lcall	_ak820_outline_0033
      00447B FA               [12]  858 	mov	r2,a
      00447C A3               [24]  859 	inc	dptr
      00447D E0               [24]  860 	movx	a,@dptr
      00447E FB               [12]  861 	mov	r3,a
      00447F 90 06 1C         [24]  862 	mov	dptr,#_pending_time
      004482 12 38 3D         [24]  863 	lcall	_ak820_outline_0099
      004485 EA               [12]  864 	mov	a,r2
      004486 C3               [12]  865 	clr	c
      004487 98               [12]  866 	subb	a,r0
      004488 FA               [12]  867 	mov	r2,a
      004489 EB               [12]  868 	mov	a,r3
      00448A 99               [12]  869 	subb	a,r1
      00448B FB               [12]  870 	mov	r3,a
      00448C C3               [12]  871 	clr	c
      00448D EA               [12]  872 	mov	a,r2
      00448E 94 C8            [12]  873 	subb	a,#0xc8
      004490 EB               [12]  874 	mov	a,r3
      004491 94 00            [12]  875 	subb	a,#0x00
      004493 50 17            [24]  876 	jnc	00107$
                                    877 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004495 74 04            [12]  878 	mov	a,#0x04
      004497 12 48 59         [24]  879 	lcall	_ak820_outline_0045
      00449A 60 17            [24]  880 	jz	00108$
      00449C 12 37 AA         [24]  881 	lcall	_ak820_outline_0005
      00449F 60 12            [24]  882 	jz	00108$
      0044A1 BD FF 02         [24]  883 	cjne	r5,#0xff,00224$
      0044A4 80 06            [24]  884 	sjmp	00107$
      0044A6                        885 00224$:
      0044A6 ED               [12]  886 	mov	a,r5
      0044A7 B5 04 02         [24]  887 	cjne	a,ar4,00225$
      0044AA 80 07            [24]  888 	sjmp	00108$
      0044AC                        889 00225$:
      0044AC                        890 00107$:
      0044AC C0 05            [24]  891 	push	ar5
      0044AE 12 43 F3         [24]  892 	lcall	_commit_pending
      0044B1 D0 05            [24]  893 	pop	ar5
      0044B3                        894 00108$:
                                    895 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      0044B3 90 06 27         [24]  896 	mov	dptr,#_ak820_tapping_before_event_10000_612
      0044B6 12 38 00         [24]  897 	lcall	_ak820_outline_0050
      0044B9 74 04            [12]  898 	mov	a,#0x04
      0044BB 12 48 26         [24]  899 	lcall	_ak820_outline_0012
      0044BE 60 03            [24]  900 	jz	00114$
      0044C0 BD FF 04         [24]  901 	cjne	r5,#0xff,00115$
      0044C3                        902 00114$:
      0044C3 75 82 01         [24]  903 	mov	dpl, #0x01
      0044C6 22               [24]  904 	ret
      0044C7                        905 00115$:
                                    906 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      0044C7 ED               [12]  907 	mov	a,r5
      0044C8 12 48 81         [24]  908 	lcall	_ak820_outline_0076
      0044CB 30 E1 13         [24]  909 	jnb	acc.1,00120$
                                    910 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0044CE 74 05            [12]  911 	mov	a,#0x05
      0044D0 2E               [12]  912 	add	a, r6
      0044D1 12 37 D5         [24]  913 	lcall	_ak820_outline_0013
      0044D4 70 07            [24]  914 	jnz	00118$
      0044D6 74 FD            [12]  915 	mov	a,#0xfd
      0044D8 5B               [12]  916 	anl	a,r3
      0044D9 12 38 60         [24]  917 	lcall	_ak820_outline_0121
      0044DC F0               [24]  918 	movx	@dptr,a
      0044DD                        919 00118$:
                                    920 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      0044DD 75 82 00         [24]  921 	mov	dpl, #0x00
      0044E0 22               [24]  922 	ret
      0044E1                        923 00120$:
                                    924 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      0044E1 12 42 CC         [24]  925 	lcall	_ak820_outline_0009
      0044E4 E0               [24]  926 	movx	a,@dptr
      0044E5 FF               [12]  927 	mov	r7,a
      0044E6 8B 06            [24]  928 	mov	ar6,r3
      0044E8 53 06 01         [24]  929 	anl	ar6,#0x01
      0044EB EE               [12]  930 	mov	a,r6
      0044EC B4 01 00         [24]  931 	cjne	a,#0x01,00231$
      0044EF                        932 00231$:
      0044EF B3               [12]  933 	cpl	c
      0044F0 92 0C            [24]  934 	mov	_ak820_tapping_before_sloc0_1_0,c
      0044F2 8F F0            [24]  935 	mov	b,r7
      0044F4 E4               [12]  936 	clr	a
      0044F5 33               [12]  937 	rlc	a
      0044F6 B5 F0 04         [24]  938 	cjne	a,b,00122$
      0044F9 75 82 00         [24]  939 	mov	dpl, #0x00
      0044FC 22               [24]  940 	ret
      0044FD                        941 00122$:
                                    942 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      0044FD 63 03 01         [24]  943 	xrl	ar3,#0x01
      004500 12 38 60         [24]  944 	lcall	_ak820_outline_0121
      004503 EB               [12]  945 	mov	a,r3
      004504 F0               [24]  946 	movx	@dptr,a
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004505 75 82 01         [24]  948 	mov	dpl, #0x01
                                    949 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004508 22               [24]  950 	ret
                                    951 ;------------------------------------------------------------
                                    952 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    953 ;------------------------------------------------------------
                                    954 ;record        Allocated with name '_ak820_tapping_process_record_10000_623'
                                    955 ;id            Allocated with name '_ak820_tapping_process_id_10000_624'
                                    956 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_624'
                                    957 ;code          Allocated with name '_ak820_tapping_process_code_10000_624'
                                    958 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_624'
                                    959 ;------------------------------------------------------------
                                    960 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function ak820_tapping_process
                                    963 ;	-----------------------------------------
      004509                        964 _ak820_tapping_process:
      004509 12 38 49         [24]  965 	lcall	_ak820_outline_0104
      00450C 90 06 29         [24]  966 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00450F 12 38 4E         [24]  967 	lcall	_ak820_outline_0105
                                    968 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004512 90 06 2D         [24]  969 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004515 E4               [12]  970 	clr	a
      004516 F0               [24]  971 	movx	@dptr,a
                                    972 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004517 90 06 29         [24]  973 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00451A 12 38 00         [24]  974 	lcall	_ak820_outline_0050
      00451D 74 04            [12]  975 	mov	a,#0x04
      00451F 12 48 1B         [24]  976 	lcall	_ak820_outline_0011
      004522 70 04            [24]  977 	jnz	00102$
      004524 75 82 01         [24]  978 	mov	dpl, #0x01
      004527 22               [24]  979 	ret
      004528                        980 00102$:
                                    981 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004528 8E 04            [24]  982 	mov	ar4,r6
      00452A 8F 05            [24]  983 	mov	ar5,r7
      00452C 12 48 31         [24]  984 	lcall	_ak820_outline_0021
      00452F C0 07            [24]  985 	push	ar7
      004531 C0 06            [24]  986 	push	ar6
      004533 12 B6 FA         [24]  987 	lcall	___memcpy
      004536 12 43 61         [24]  988 	lcall	_ak820_tapping_source
      004539 AD 82            [24]  989 	mov	r5, dpl
      00453B D0 06            [24]  990 	pop	ar6
      00453D D0 07            [24]  991 	pop	ar7
                                    992 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      00453F BD FF 04         [24]  993 	cjne	r5,#0xff,00104$
      004542 75 82 01         [24]  994 	mov	dpl, #0x01
      004545 22               [24]  995 	ret
      004546                        996 00104$:
                                    997 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004546 74 07            [12]  998 	mov	a,#0x07
      004548 12 37 E7         [24]  999 	lcall	_ak820_outline_0016
      00454B FE               [12] 1000 	mov	r6,a
      00454C A3               [24] 1001 	inc	dptr
      00454D E0               [24] 1002 	movx	a,@dptr
      00454E FF               [12] 1003 	mov	r7,a
      00454F 90 06 2B         [24] 1004 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004552 12 48 74         [24] 1005 	lcall	_ak820_outline_0058
                                   1006 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004555 BE 1A 15         [24] 1007 	cjne	r6,#0x1a,00111$
      004558 BF 7C 12         [24] 1008 	cjne	r7,#0x7c,00111$
      00455B 90 06 2B         [24] 1009 	mov	dptr,#_ak820_tapping_process_code_10000_624
      00455E 74 26            [12] 1010 	mov	a,#0x26
      004560 F0               [24] 1011 	movx	@dptr,a
      004561 74 22            [12] 1012 	mov	a,#0x22
      004563 A3               [24] 1013 	inc	dptr
      004564 F0               [24] 1014 	movx	@dptr,a
      004565 90 06 2D         [24] 1015 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004568 74 02            [12] 1016 	mov	a,#0x02
      00456A F0               [24] 1017 	movx	@dptr,a
      00456B 80 28            [24] 1018 	sjmp	00112$
      00456D                       1019 00111$:
                                   1020 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      00456D BE 1B 15         [24] 1021 	cjne	r6,#0x1b,00108$
      004570 BF 7C 12         [24] 1022 	cjne	r7,#0x7c,00108$
      004573 90 06 2B         [24] 1023 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004576 74 27            [12] 1024 	mov	a,#0x27
      004578 F0               [24] 1025 	movx	@dptr,a
      004579 74 32            [12] 1026 	mov	a,#0x32
      00457B A3               [24] 1027 	inc	dptr
      00457C F0               [24] 1028 	movx	@dptr,a
      00457D 90 06 2D         [24] 1029 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004580 74 20            [12] 1030 	mov	a,#0x20
      004582 F0               [24] 1031 	movx	@dptr,a
      004583 80 10            [24] 1032 	sjmp	00112$
      004585                       1033 00108$:
                                   1034 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004585 BE 1E 0D         [24] 1035 	cjne	r6,#0x1e,00112$
      004588 BF 7C 0A         [24] 1036 	cjne	r7,#0x7c,00112$
      00458B 90 06 2B         [24] 1037 	mov	dptr,#_ak820_tapping_process_code_10000_624
      00458E 74 28            [12] 1038 	mov	a,#0x28
      004590 F0               [24] 1039 	movx	@dptr,a
      004591 74 32            [12] 1040 	mov	a,#0x32
      004593 A3               [24] 1041 	inc	dptr
      004594 F0               [24] 1042 	movx	@dptr,a
      004595                       1043 00112$:
                                   1044 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004595 90 06 2B         [24] 1045 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004598 E0               [24] 1046 	movx	a,@dptr
      004599 A3               [24] 1047 	inc	dptr
      00459A E0               [24] 1048 	movx	a,@dptr
      00459B FF               [12] 1049 	mov	r7,a
                                   1050 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      00459C BF 20 00         [24] 1051 	cjne	r7,#0x20,00242$
      00459F                       1052 00242$:
      00459F 40 05            [24] 1053 	jc	00113$
      0045A1 BF 50 00         [24] 1054 	cjne	r7,#0x50,00244$
      0045A4                       1055 00244$:
      0045A4 40 04            [24] 1056 	jc	00114$
      0045A6                       1057 00113$:
      0045A6 75 82 01         [24] 1058 	mov	dpl, #0x01
      0045A9 22               [24] 1059 	ret
      0045AA                       1060 00114$:
                                   1061 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      0045AA BF 40 00         [24] 1062 	cjne	r7,#0x40,00246$
      0045AD                       1063 00246$:
      0045AD 40 0C            [24] 1064 	jc	00117$
      0045AF 53 07 0F         [24] 1065 	anl	ar7,#0x0f
      0045B2 BF 06 00         [24] 1066 	cjne	r7,#0x06,00248$
      0045B5                       1067 00248$:
      0045B5 40 04            [24] 1068 	jc	00117$
      0045B7 75 82 00         [24] 1069 	mov	dpl, #0x00
      0045BA 22               [24] 1070 	ret
      0045BB                       1071 00117$:
                                   1072 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      0045BB 90 06 29         [24] 1073 	mov	dptr,#_ak820_tapping_process_record_10000_623
      0045BE 12 38 00         [24] 1074 	lcall	_ak820_outline_0050
      0045C1 74 05            [12] 1075 	mov	a,#0x05
      0045C3 12 48 26         [24] 1076 	lcall	_ak820_outline_0012
      0045C6 60 1F            [24] 1077 	jz	00131$
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      0045C8 90 0D 83         [24] 1079 	mov	dptr,#_pending
      0045CB ED               [12] 1080 	mov	a,r5
      0045CC 12 42 D6         [24] 1081 	lcall	_ak820_outline_0029
                                   1082 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      0045CF 12 38 00         [24] 1083 	lcall	_ak820_outline_0050
      0045D2 90 06 1C         [24] 1084 	mov	dptr,#_pending_time
      0045D5 12 48 74         [24] 1085 	lcall	_ak820_outline_0058
                                   1086 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      0045D8 90 06 2B         [24] 1087 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0045DB 12 38 00         [24] 1088 	lcall	_ak820_outline_0050
      0045DE 90 06 1E         [24] 1089 	mov	dptr,#_pending_code
      0045E1 12 48 74         [24] 1090 	lcall	_ak820_outline_0058
      0045E4 02 46 84         [24] 1091 	ljmp	00132$
      0045E7                       1092 00131$:
                                   1093 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      0045E7 90 0D 83         [24] 1094 	mov	dptr,#_pending
      0045EA E0               [24] 1095 	movx	a,@dptr
      0045EB FF               [12] 1096 	mov	r7,a
      0045EC ED               [12] 1097 	mov	a,r5
      0045ED B5 07 02         [24] 1098 	cjne	a,ar7,00251$
      0045F0 80 03            [24] 1099 	sjmp	00252$
      0045F2                       1100 00251$:
      0045F2 02 46 5D         [24] 1101 	ljmp	00128$
      0045F5                       1102 00252$:
                                   1103 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      0045F5 12 48 96         [24] 1104 	lcall	_ak820_outline_0150
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      0045F8 90 06 2D         [24] 1106 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0045FB E0               [24] 1107 	movx	a,@dptr
      0045FC FF               [12] 1108 	mov	r7,a
      0045FD E0               [24] 1109 	movx	a,@dptr
      0045FE 60 05            [24] 1110 	jz	00120$
      004600 8F 82            [24] 1111 	mov	dpl, r7
      004602 12 7C 71         [24] 1112 	lcall	_add_owned_mods
      004605                       1113 00120$:
                                   1114 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004605 90 06 29         [24] 1115 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004608 12 38 00         [24] 1116 	lcall	_ak820_outline_0050
      00460B 74 07            [12] 1117 	mov	a,#0x07
      00460D 2E               [12] 1118 	add	a, r6
      00460E FB               [12] 1119 	mov	r3,a
      00460F E4               [12] 1120 	clr	a
      004610 3F               [12] 1121 	addc	a, r7
      004611 FC               [12] 1122 	mov	r4,a
      004612 90 06 2B         [24] 1123 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004615 E0               [24] 1124 	movx	a,@dptr
      004616 F9               [12] 1125 	mov	r1,a
      004617 7A 00            [12] 1126 	mov	r2,#0x00
      004619 12 33 FC         [24] 1127 	lcall	_ak820_outline_0122
      00461C E9               [12] 1128 	mov	a,r1
      00461D F0               [24] 1129 	movx	@dptr,a
      00461E EA               [12] 1130 	mov	a,r2
      00461F A3               [24] 1131 	inc	dptr
      004620 F0               [24] 1132 	movx	@dptr,a
                                   1133 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004621 C3               [12] 1134 	clr	c
      004622 04               [12] 1135 	inc	a
      004623 99               [12] 1136 	subb	a,r1
      004624 50 25            [24] 1137 	jnc	00122$
                                   1138 ;	free result
                                   1139 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004626 74 06            [12] 1140 	mov	a,#0x06
      004628 12 37 E7         [24] 1141 	lcall	_ak820_outline_0016
      00462B 54 0F            [12] 1142 	anl	a,#0x0f
      00462D 44 10            [12] 1143 	orl	a,#0x10
      00462F F0               [24] 1144 	movx	@dptr,a
                                   1145 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004630 12 42 CC         [24] 1146 	lcall	_ak820_outline_0009
      004633 12 48 64         [24] 1147 	lcall	_ak820_outline_0054
                                   1148 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004636 12 70 67         [24] 1149 	lcall	_process_record
                                   1150 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004639 90 06 29         [24] 1151 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00463C 12 37 A0         [24] 1152 	lcall	_ak820_outline_0004
      00463F A3               [24] 1153 	inc	dptr
      004640 A3               [24] 1154 	inc	dptr
      004641 A3               [24] 1155 	inc	dptr
      004642 A3               [24] 1156 	inc	dptr
      004643 A3               [24] 1157 	inc	dptr
      004644 E4               [12] 1158 	clr	a
      004645 12 43 02         [24] 1159 	lcall	_ak820_outline_0060
                                   1160 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004648 12 70 67         [24] 1161 	lcall	_process_record
      00464B                       1162 00122$:
                                   1163 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      00464B 90 06 2D         [24] 1164 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00464E E0               [24] 1165 	movx	a,@dptr
      00464F FF               [12] 1166 	mov	r7,a
      004650 E0               [24] 1167 	movx	a,@dptr
      004651 60 31            [24] 1168 	jz	00132$
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004653 8F 82            [24] 1170 	mov	dpl, r7
      004655 12 7C 81         [24] 1171 	lcall	_del_owned_mods
                                   1172 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004658 12 7F AD         [24] 1173 	lcall	_send_keyboard_report
      00465B 80 27            [24] 1174 	sjmp	00132$
      00465D                       1175 00128$:
                                   1176 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      00465D ED               [12] 1177 	mov	a,r5
      00465E 24 9A            [12] 1178 	add	a, #_source_state
      004660 FE               [12] 1179 	mov	r6,a
      004661 E4               [12] 1180 	clr	a
      004662 34 05            [12] 1181 	addc	a, #(_source_state >> 8)
      004664 FF               [12] 1182 	mov	r7,a
      004665 12 38 37         [24] 1183 	lcall	_ak820_outline_0097
      004668 FD               [12] 1184 	mov	r5,a
      004669 30 E2 18         [24] 1185 	jnb	acc.2,00132$
                                   1186 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      00466C 53 05 FB         [24] 1187 	anl	ar5,#0xfb
      00466F 12 43 20         [24] 1188 	lcall	_ak820_outline_0117
      004672 ED               [12] 1189 	mov	a,r5
      004673 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004674 90 06 2B         [24] 1192 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004677 12 38 00         [24] 1193 	lcall	_ak820_outline_0050
      00467A 90 06 22         [24] 1194 	mov	dptr,#_hold_PARM_2
      00467D E4               [12] 1195 	clr	a
      00467E 12 43 02         [24] 1196 	lcall	_ak820_outline_0060
      004681 12 43 9B         [24] 1197 	lcall	_hold
      004684                       1198 00132$:
                                   1199 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004684 75 82 00         [24] 1200 	mov	dpl, #0x00
                                   1201 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004687 22               [24] 1202 	ret
                                   1203 ;------------------------------------------------------------
                                   1204 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1205 ;------------------------------------------------------------
                                   1206 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_647'
                                   1207 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_648'
                                   1208 ;------------------------------------------------------------
                                   1209 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1210 ;	-----------------------------------------
                                   1211 ;	 function ak820_tapping_cancel
                                   1212 ;	-----------------------------------------
      004688                       1213 _ak820_tapping_cancel:
                                   1214 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004688 12 48 96         [24] 1215 	lcall	_ak820_outline_0150
                                   1216 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      00468B 7F 00            [12] 1217 	mov	r7,#0x00
      00468D                       1218 00103$:
      00468D BF 82 00         [24] 1219 	cjne	r7,#0x82,00122$
      004690                       1220 00122$:
      004690 50 1D            [24] 1221 	jnc	00105$
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004692 EF               [12] 1223 	mov	a,r7
      004693 24 9A            [12] 1224 	add	a, #_source_state
      004695 FD               [12] 1225 	mov	r5,a
      004696 E4               [12] 1226 	clr	a
      004697 34 05            [12] 1227 	addc	a, #(_source_state >> 8)
      004699 12 48 6C         [24] 1228 	lcall	_ak820_outline_0056
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      00469C 74 02            [12] 1230 	mov	a,#0x02
      00469E 5C               [12] 1231 	anl	a,r4
      00469F FB               [12] 1232 	mov	r3,a
      0046A0 53 04 01         [24] 1233 	anl	ar4,#0x01
      0046A3 EC               [12] 1234 	mov	a,r4
      0046A4 2C               [12] 1235 	add	a,r4
      0046A5 42 03            [12] 1236 	orl	ar3,a
      0046A7 12 38 6A         [24] 1237 	lcall	_ak820_outline_0131
      0046AA EB               [12] 1238 	mov	a,r3
      0046AB F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0046AC 0F               [12] 1241 	inc	r7
      0046AD 80 DE            [24] 1242 	sjmp	00103$
      0046AF                       1243 00105$:
                                   1244 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      0046AF 22               [24] 1245 	ret
                                   1246 ;------------------------------------------------------------
                                   1247 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1248 ;------------------------------------------------------------
                                   1249 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1250 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1251 ;code          Allocated with name '_ak820_oneshot_process_code_10000_649'
                                   1252 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_650'
                                   1253 ;i             Allocated with name '_ak820_oneshot_process_i_40000_666'
                                   1254 ;------------------------------------------------------------
                                   1255 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1256 ;	-----------------------------------------
                                   1257 ;	 function ak820_oneshot_process
                                   1258 ;	-----------------------------------------
      0046B0                       1259 _ak820_oneshot_process:
      0046B0 12 38 49         [24] 1260 	lcall	_ak820_outline_0104
      0046B3 90 06 32         [24] 1261 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      0046B6 12 38 4E         [24] 1262 	lcall	_ak820_outline_0105
                                   1263 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      0046B9 90 06 30         [24] 1264 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0046BC E0               [24] 1265 	movx	a,@dptr
      0046BD FF               [12] 1266 	mov	r7,a
      0046BE BF FF 02         [24] 1267 	cjne	r7,#0xff,00283$
      0046C1 80 07            [24] 1268 	sjmp	00101$
      0046C3                       1269 00283$:
      0046C3 12 A0 EF         [24] 1270 	lcall	_get_repeat_key_count
      0046C6 E5 82            [12] 1271 	mov	a, dpl
      0046C8 60 04            [24] 1272 	jz	00102$
      0046CA                       1273 00101$:
      0046CA 75 82 01         [24] 1274 	mov	dpl, #0x01
      0046CD 22               [24] 1275 	ret
      0046CE                       1276 00102$:
                                   1277 ;	keyboards/ajazz/ak820/ak820_tapping.c:154: if (code >= QK_MAGIC_GUI_ON && code <= QK_MAGIC_TOGGLE_GUI) return true;
      0046CE 90 06 32         [24] 1278 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      0046D1 12 43 0E         [24] 1279 	lcall	_ak820_outline_0096
      0046D4 C3               [12] 1280 	clr	c
      0046D5 ED               [12] 1281 	mov	a,r5
      0046D6 94 09            [12] 1282 	subb	a,#0x09
      0046D8 EE               [12] 1283 	mov	a,r6
      0046D9 94 70            [12] 1284 	subb	a,#0x70
      0046DB 40 0C            [24] 1285 	jc	00105$
      0046DD 74 0B            [12] 1286 	mov	a,#0x0b
      0046DF 9D               [12] 1287 	subb	a,r5
      0046E0 74 70            [12] 1288 	mov	a,#0x70
      0046E2 9E               [12] 1289 	subb	a,r6
      0046E3 40 04            [24] 1290 	jc	00105$
                                   1291 ;	free result
      0046E5 75 82 01         [24] 1292 	mov	dpl, #0x01
      0046E8 22               [24] 1293 	ret
      0046E9                       1294 00105$:
                                   1295 ;	keyboards/ajazz/ak820/ak820_tapping.c:158: if (code == QK_MAGIC_SWAP_CTL_GUI || code == QK_MAGIC_UNSWAP_CTL_GUI || code == QK_MAGIC_TOGGLE_CTL_GUI) return true;
      0046E9 90 06 32         [24] 1296 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      0046EC 12 38 43         [24] 1297 	lcall	_ak820_outline_0100
      0046EF 8B 01            [24] 1298 	mov	ar1,r3
      0046F1 8C 02            [24] 1299 	mov	ar2,r4
      0046F3 B9 1B 05         [24] 1300 	cjne	r1,#0x1b,00287$
      0046F6 BA 70 02         [24] 1301 	cjne	r2,#0x70,00287$
      0046F9 80 0E            [24] 1302 	sjmp	00107$
      0046FB                       1303 00287$:
      0046FB B9 1C 05         [24] 1304 	cjne	r1,#0x1c,00288$
      0046FE BA 70 02         [24] 1305 	cjne	r2,#0x70,00288$
      004701 80 06            [24] 1306 	sjmp	00107$
      004703                       1307 00288$:
      004703 B9 1D 07         [24] 1308 	cjne	r1,#0x1d,00108$
      004706 BA 70 04         [24] 1309 	cjne	r2,#0x70,00108$
      004709                       1310 00107$:
      004709 75 82 01         [24] 1311 	mov	dpl, #0x01
      00470C 22               [24] 1312 	ret
      00470D                       1313 00108$:
                                   1314 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      00470D 8C 01            [24] 1315 	mov	ar1,r4
      00470F B9 52 02         [24] 1316 	cjne	r1,#0x52,00291$
      004712 80 03            [24] 1317 	sjmp	00292$
      004714                       1318 00291$:
      004714 02 47 BB         [24] 1319 	ljmp	00123$
      004717                       1320 00292$:
      004717 8B 02            [24] 1321 	mov	ar2,r3
      004719 53 02 E0         [24] 1322 	anl	ar2,#0xe0
      00471C BA A0 02         [24] 1323 	cjne	r2,#0xa0,00293$
      00471F 80 03            [24] 1324 	sjmp	00294$
      004721                       1325 00293$:
      004721 02 47 BB         [24] 1326 	ljmp	00123$
      004724                       1327 00294$:
                                   1328 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004724 8B 02            [24] 1329 	mov	ar2,r3
      004726 53 02 0F         [24] 1330 	anl	ar2,#0x0f
      004729 90 06 34         [24] 1331 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      00472C EA               [12] 1332 	mov	a,r2
      00472D F0               [24] 1333 	movx	@dptr,a
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      00472E EB               [12] 1335 	mov	a,r3
      00472F 30 E4 08         [24] 1336 	jnb	acc.4,00112$
      004732 EA               [12] 1337 	mov	a,r2
      004733 C4               [12] 1338 	swap	a
      004734 54 F0            [12] 1339 	anl	a,#0xf0
      004736 90 06 34         [24] 1340 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004739 F0               [24] 1341 	movx	@dptr,a
      00473A                       1342 00112$:
                                   1343 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      00473A 90 06 31         [24] 1344 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00473D E0               [24] 1345 	movx	a,@dptr
      00473E 60 2E            [24] 1346 	jz	00120$
                                   1347 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004740 EF               [12] 1348 	mov	a,r7
      004741 12 48 4B         [24] 1349 	lcall	_ak820_outline_0023
      004744 43 02 08         [24] 1350 	orl	ar2,#0x08
      004747 12 48 8F         [24] 1351 	lcall	_ak820_outline_0090
                                   1352 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      00474A 53 02 EF         [24] 1353 	anl	ar2,#0xef
      00474D 12 48 8F         [24] 1354 	lcall	_ak820_outline_0090
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004750 90 0D 84         [24] 1356 	mov	dptr,#_ak820_oneshot_target
      004753 E0               [24] 1357 	movx	a,@dptr
      004754 FA               [12] 1358 	mov	r2,a
      004755 BA FF 02         [24] 1359 	cjne	r2,#0xff,00297$
      004758 80 09            [24] 1360 	sjmp	00114$
      00475A                       1361 00297$:
      00475A 12 48 7A         [24] 1362 	lcall	_ak820_outline_0064
      00475D 43 02 10         [24] 1363 	orl	ar2,#0x10
      004760 12 48 8F         [24] 1364 	lcall	_ak820_outline_0090
      004763                       1365 00114$:
                                   1366 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004763 90 06 34         [24] 1367 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004766 E0               [24] 1368 	movx	a,@dptr
      004767 F5 82            [12] 1369 	mov	dpl,a
      004769 12 75 9B         [24] 1370 	lcall	_register_mods
      00476C 80 49            [24] 1371 	sjmp	00121$
      00476E                       1372 00120$:
                                   1373 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      00476E EF               [12] 1374 	mov	a,r7
      00476F 12 48 4B         [24] 1375 	lcall	_ak820_outline_0023
      004772 30 E3 42         [24] 1376 	jnb	acc.3,00121$
                                   1377 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004775 EA               [12] 1378 	mov	a,r2
      004776 20 E4 24         [24] 1379 	jb	acc.4,00116$
                                   1380 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004779 90 06 2E         [24] 1381 	mov	dptr,#_ak820_oneshot_mods
      00477C E0               [24] 1382 	movx	a,@dptr
      00477D F4               [12] 1383 	cpl	a
      00477E FA               [12] 1384 	mov	r2,a
      00477F 90 06 34         [24] 1385 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004782 E0               [24] 1386 	movx	a,@dptr
      004783 F9               [12] 1387 	mov	r1,a
      004784 52 02            [12] 1388 	anl	ar2,a
      004786 8A 82            [24] 1389 	mov	dpl, r2
      004788 C0 04            [24] 1390 	push	ar4
      00478A C0 03            [24] 1391 	push	ar3
      00478C C0 01            [24] 1392 	push	ar1
      00478E 12 7C 71         [24] 1393 	lcall	_add_owned_mods
      004791 D0 01            [24] 1394 	pop	ar1
      004793 D0 03            [24] 1395 	pop	ar3
      004795 D0 04            [24] 1396 	pop	ar4
                                   1397 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004797 90 06 2E         [24] 1398 	mov	dptr,#_ak820_oneshot_mods
      00479A E0               [24] 1399 	movx	a,@dptr
      00479B 49               [12] 1400 	orl	a,r1
      00479C F0               [24] 1401 	movx	@dptr,a
      00479D                       1402 00116$:
                                   1403 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      00479D 90 06 34         [24] 1404 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0047A0 E0               [24] 1405 	movx	a,@dptr
      0047A1 F5 82            [12] 1406 	mov	dpl,a
      0047A3 C0 04            [24] 1407 	push	ar4
      0047A5 C0 03            [24] 1408 	push	ar3
      0047A7 12 75 AF         [24] 1409 	lcall	_unregister_mods
      0047AA D0 03            [24] 1410 	pop	ar3
      0047AC D0 04            [24] 1411 	pop	ar4
                                   1412 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      0047AE 12 48 7A         [24] 1413 	lcall	_ak820_outline_0064
      0047B1 53 02 E7         [24] 1414 	anl	ar2,#0xe7
      0047B4 12 48 8F         [24] 1415 	lcall	_ak820_outline_0090
      0047B7                       1416 00121$:
                                   1417 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      0047B7 75 82 00         [24] 1418 	mov	dpl, #0x00
      0047BA 22               [24] 1419 	ret
      0047BB                       1420 00123$:
                                   1421 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      0047BB 90 06 31         [24] 1422 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0047BE E0               [24] 1423 	movx	a,@dptr
      0047BF 60 56            [24] 1424 	jz	00131$
      0047C1 C3               [12] 1425 	clr	c
      0047C2 74 01            [12] 1426 	mov	a,#0x01
      0047C4 9D               [12] 1427 	subb	a,r5
      0047C5 E4               [12] 1428 	clr	a
      0047C6 9E               [12] 1429 	subb	a,r6
      0047C7 50 4E            [24] 1430 	jnc	00131$
                                   1431 ;	free result
                                   1432 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      0047C9 C3               [12] 1433 	clr	c
      0047CA ED               [12] 1434 	mov	a,r5
      0047CB 94 E0            [12] 1435 	subb	a,#0xe0
      0047CD EE               [12] 1436 	mov	a,r6
      0047CE 94 00            [12] 1437 	subb	a,#0x00
      0047D0 40 07            [24] 1438 	jc	00136$
      0047D2 74 E7            [12] 1439 	mov	a,#0xe7
      0047D4 9D               [12] 1440 	subb	a,r5
      0047D5 E4               [12] 1441 	clr	a
      0047D6 9E               [12] 1442 	subb	a,r6
      0047D7 50 3E            [24] 1443 	jnc	00131$
                                   1444 ;	free result
      0047D9                       1445 00136$:
                                   1446 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      0047D9 74 AE            [12] 1447 	mov	a,#0x100 - 0x52
      0047DB 2E               [12] 1448 	add	a,r6
      0047DC 50 09            [24] 1449 	jnc	00180$
      0047DE C3               [12] 1450 	clr	c
      0047DF 74 DF            [12] 1451 	mov	a,#0xdf
      0047E1 9D               [12] 1452 	subb	a,r5
      0047E2 74 52            [12] 1453 	mov	a,#0x52
      0047E4 9E               [12] 1454 	subb	a,r6
      0047E5 50 30            [24] 1455 	jnc	00131$
                                   1456 ;	free result
                                   1457 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      0047E7                       1458 00180$:
      0047E7 7E 00            [12] 1459 	mov	r6,#0x00
      0047E9                       1460 00138$:
      0047E9 BE 82 00         [24] 1461 	cjne	r6,#0x82,00306$
      0047EC                       1462 00306$:
      0047EC 50 12            [24] 1463 	jnc	00127$
                                   1464 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      0047EE EE               [12] 1465 	mov	a,r6
      0047EF 12 48 81         [24] 1466 	lcall	_ak820_outline_0076
      0047F2 30 E3 08         [24] 1467 	jnb	acc.3,00139$
      0047F5 43 03 10         [24] 1468 	orl	ar3,#0x10
      0047F8 12 38 60         [24] 1469 	lcall	_ak820_outline_0121
      0047FB EB               [12] 1470 	mov	a,r3
      0047FC F0               [24] 1471 	movx	@dptr,a
      0047FD                       1472 00139$:
                                   1473 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      0047FD 0E               [12] 1474 	inc	r6
      0047FE 80 E9            [24] 1475 	sjmp	00138$
      004800                       1476 00127$:
                                   1477 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004800 90 06 2E         [24] 1478 	mov	dptr,#_ak820_oneshot_mods
      004803 E0               [24] 1479 	movx	a,@dptr
      004804 FE               [12] 1480 	mov	r6,a
      004805 E0               [24] 1481 	movx	a,@dptr
      004806 60 0F            [24] 1482 	jz	00131$
                                   1483 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004808 90 06 2F         [24] 1484 	mov	dptr,#_ak820_oneshot_consumed
      00480B EE               [12] 1485 	mov	a,r6
      00480C F0               [24] 1486 	movx	@dptr,a
                                   1487 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      00480D 90 0D 84         [24] 1488 	mov	dptr,#_ak820_oneshot_target
      004810 EF               [12] 1489 	mov	a,r7
      004811 F0               [24] 1490 	movx	@dptr,a
                                   1491 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004812 90 06 2E         [24] 1492 	mov	dptr,#_ak820_oneshot_mods
      004815 E4               [12] 1493 	clr	a
      004816 F0               [24] 1494 	movx	@dptr,a
      004817                       1495 00131$:
                                   1496 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004817 75 82 01         [24] 1497 	mov	dpl, #0x01
                                   1498 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      00481A 22               [24] 1499 	ret
                                   1500 	.area CSEG    (CODE)
                                   1501 	.area CONST   (CODE)
                                   1502 	.area XINIT   (CODE)
      00BFBA                       1503 __xinit__pending:
      00BFBA FF                    1504 	.db #0xff	; 255
      00BFBB                       1505 __xinit__ak820_oneshot_target:
      00BFBB FF                    1506 	.db #0xff	; 255
                                   1507 	.area CABS    (ABS,CODE)
                                   1508 
                                   1509 ; Experimental exact instruction outlining.
                                   1510 	.globl _ak820_outline_0004
                                   1511 	.globl _ak820_outline_0005
                                   1512 	.globl _ak820_outline_0009
                                   1513 	.globl _ak820_outline_0010
                                   1514 	.globl _ak820_outline_0011
                                   1515 	.globl _ak820_outline_0012
                                   1516 	.globl _ak820_outline_0013
                                   1517 	.globl _ak820_outline_0016
                                   1518 	.globl _ak820_outline_0021
                                   1519 	.globl _ak820_outline_0023
                                   1520 	.globl _ak820_outline_0029
                                   1521 	.globl _ak820_outline_0033
                                   1522 	.globl _ak820_outline_0045
                                   1523 	.globl _ak820_outline_0050
                                   1524 	.globl _ak820_outline_0054
                                   1525 	.globl _ak820_outline_0056
                                   1526 	.globl _ak820_outline_0058
                                   1527 	.globl _ak820_outline_0060
                                   1528 	.globl _ak820_outline_0064
                                   1529 	.globl _ak820_outline_0076
                                   1530 	.globl _ak820_outline_0090
                                   1531 	.globl _ak820_outline_0096
                                   1532 	.globl _ak820_outline_0097
                                   1533 	.globl _ak820_outline_0099
                                   1534 	.globl _ak820_outline_0100
                                   1535 	.globl _ak820_outline_0104
                                   1536 	.globl _ak820_outline_0105
                                   1537 	.globl _ak820_outline_0117
                                   1538 	.globl _ak820_outline_0121
                                   1539 	.globl _ak820_outline_0122
                                   1540 	.globl _ak820_outline_0131
                                   1541 	.globl _ak820_outline_0150
                                   1542 	.globl _ak820_outline_0153
                                   1543 	.globl _ak820_outline_0184
                                   1544 
                                   1545 	.area CSEG (CODE)
                                   1546 ; function ak820_outline_0011
      00481B                       1547 _ak820_outline_0011:
      00481B 2E               [12] 1548 	add	a,r6
      00481C FC               [12] 1549 	mov	r4,a
      00481D E4               [12] 1550 	clr	a
      00481E 3F               [12] 1551 	addc	a,r7
      00481F FD               [12] 1552 	mov	r5,a
      004820 8C 82            [24] 1553 	mov	dpl,r4
      004822 8D 83            [24] 1554 	mov	dph,r5
      004824 E0               [24] 1555 	movx	a,@dptr
      004825 22               [24] 1556 	ret
                                   1557 
                                   1558 	.area CSEG (CODE)
                                   1559 ; function ak820_outline_0012
      004826                       1560 _ak820_outline_0012:
      004826 2E               [12] 1561 	add	a,r6
      004827 FB               [12] 1562 	mov	r3,a
      004828 E4               [12] 1563 	clr	a
      004829 3F               [12] 1564 	addc	a,r7
      00482A FC               [12] 1565 	mov	r4,a
      00482B 8B 82            [24] 1566 	mov	dpl,r3
      00482D 8C 83            [24] 1567 	mov	dph,r4
      00482F E0               [24] 1568 	movx	a,@dptr
      004830 22               [24] 1569 	ret
                                   1570 
                                   1571 	.area CSEG (CODE)
                                   1572 ; function ak820_outline_0021
      004831                       1573 _ak820_outline_0021:
      004831 90 0D 73         [24] 1574 	mov	dptr,#___memcpy_PARM_2
      004834 EC               [12] 1575 	mov	a,r4
      004835 F0               [24] 1576 	movx	@dptr,a
      004836 ED               [12] 1577 	mov	a,r5
      004837 A3               [24] 1578 	inc	dptr
      004838 F0               [24] 1579 	movx	@dptr,a
      004839 E4               [12] 1580 	clr	a
      00483A A3               [24] 1581 	inc	dptr
      00483B F0               [24] 1582 	movx	@dptr,a
      00483C 90 0D 76         [24] 1583 	mov	dptr,#___memcpy_PARM_3
      00483F 74 02            [12] 1584 	mov	a,#0x02
      004841 F0               [24] 1585 	movx	@dptr,a
      004842 E4               [12] 1586 	clr	a
      004843 A3               [24] 1587 	inc	dptr
      004844 F0               [24] 1588 	movx	@dptr,a
      004845 90 06 20         [24] 1589 	mov	dptr,#_ak820_tapping_source_PARM_1
      004848 F5 F0            [12] 1590 	mov	b,a
      00484A 22               [24] 1591 	ret
                                   1592 
                                   1593 	.area CSEG (CODE)
                                   1594 ; function ak820_outline_0023
      00484B                       1595 _ak820_outline_0023:
      00484B 24 9A            [12] 1596 	add	a,#_source_state
      00484D FB               [12] 1597 	mov	r3,a
      00484E E4               [12] 1598 	clr	a
      00484F 34 05            [12] 1599 	addc	a,#(_source_state>>8)
      004851 FC               [12] 1600 	mov	r4,a
      004852 8B 82            [24] 1601 	mov	dpl,r3
      004854 8C 83            [24] 1602 	mov	dph,r4
      004856 E0               [24] 1603 	movx	a,@dptr
      004857 FA               [12] 1604 	mov	r2,a
      004858 22               [24] 1605 	ret
                                   1606 
                                   1607 	.area CSEG (CODE)
                                   1608 ; function ak820_outline_0045
      004859                       1609 _ak820_outline_0045:
      004859 2E               [12] 1610 	add	a,r6
      00485A FA               [12] 1611 	mov	r2,a
      00485B E4               [12] 1612 	clr	a
      00485C 3F               [12] 1613 	addc	a,r7
      00485D FB               [12] 1614 	mov	r3,a
      00485E 8A 82            [24] 1615 	mov	dpl,r2
      004860 8B 83            [24] 1616 	mov	dph,r3
      004862 E0               [24] 1617 	movx	a,@dptr
      004863 22               [24] 1618 	ret
                                   1619 
                                   1620 	.area CSEG (CODE)
                                   1621 ; function ak820_outline_0054
      004864                       1622 _ak820_outline_0054:
      004864 74 01            [12] 1623 	mov	a,#0x01
      004866 F0               [24] 1624 	movx	@dptr,a
      004867 8E 82            [24] 1625 	mov	dpl,r6
      004869 8F 83            [24] 1626 	mov	dph,r7
      00486B 22               [24] 1627 	ret
                                   1628 
                                   1629 	.area CSEG (CODE)
                                   1630 ; function ak820_outline_0056
      00486C                       1631 _ak820_outline_0056:
      00486C FE               [12] 1632 	mov	r6,a
      00486D 8D 82            [24] 1633 	mov	dpl,r5
      00486F 8E 83            [24] 1634 	mov	dph,r6
      004871 E0               [24] 1635 	movx	a,@dptr
      004872 FC               [12] 1636 	mov	r4,a
      004873 22               [24] 1637 	ret
                                   1638 
                                   1639 	.area CSEG (CODE)
                                   1640 ; function ak820_outline_0058
      004874                       1641 _ak820_outline_0058:
      004874 EE               [12] 1642 	mov	a,r6
      004875 F0               [24] 1643 	movx	@dptr,a
      004876 EF               [12] 1644 	mov	a,r7
      004877 A3               [24] 1645 	inc	dptr
      004878 F0               [24] 1646 	movx	@dptr,a
      004879 22               [24] 1647 	ret
                                   1648 
                                   1649 	.area CSEG (CODE)
                                   1650 ; function ak820_outline_0064
      00487A                       1651 _ak820_outline_0064:
      00487A 8B 82            [24] 1652 	mov	dpl,r3
      00487C 8C 83            [24] 1653 	mov	dph,r4
      00487E E0               [24] 1654 	movx	a,@dptr
      00487F FA               [12] 1655 	mov	r2,a
      004880 22               [24] 1656 	ret
                                   1657 
                                   1658 	.area CSEG (CODE)
                                   1659 ; function ak820_outline_0076
      004881                       1660 _ak820_outline_0076:
      004881 24 9A            [12] 1661 	add	a,#_source_state
      004883 FC               [12] 1662 	mov	r4,a
      004884 E4               [12] 1663 	clr	a
      004885 34 05            [12] 1664 	addc	a,#(_source_state>>8)
      004887 FD               [12] 1665 	mov	r5,a
      004888 8C 82            [24] 1666 	mov	dpl,r4
      00488A 8D 83            [24] 1667 	mov	dph,r5
      00488C E0               [24] 1668 	movx	a,@dptr
      00488D FB               [12] 1669 	mov	r3,a
      00488E 22               [24] 1670 	ret
                                   1671 
                                   1672 	.area CSEG (CODE)
                                   1673 ; function ak820_outline_0090
      00488F                       1674 _ak820_outline_0090:
      00488F 8B 82            [24] 1675 	mov	dpl,r3
      004891 8C 83            [24] 1676 	mov	dph,r4
      004893 EA               [12] 1677 	mov	a,r2
      004894 F0               [24] 1678 	movx	@dptr,a
      004895 22               [24] 1679 	ret
                                   1680 
                                   1681 	.area CSEG (CODE)
                                   1682 ; function ak820_outline_0150
      004896                       1683 _ak820_outline_0150:
      004896 90 0D 83         [24] 1684 	mov	dptr,#_pending
      004899 74 FF            [12] 1685 	mov	a,#0xff
      00489B F0               [24] 1686 	movx	@dptr,a
      00489C 22               [24] 1687 	ret
