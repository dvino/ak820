                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000519                        109 _page_data:
      000519                        110 	.ds 64
      000559                        111 _cached_page:
      000559                        112 	.ds 1
      00055A                        113 _batch_depth:
      00055A                        114 	.ds 1
      00055B                        115 _first_failure_stage:
      00055B                        116 	.ds 1
      00055C                        117 _nvm_fail_stage_10000_20:
      00055C                        118 	.ds 1
      00055D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055D                        120 	.ds 2
      00055F                        121 _crc_byte_PARM_2:
      00055F                        122 	.ds 1
      000560                        123 _crc_byte_crc_10000_25:
      000560                        124 	.ds 2
      000562                        125 _page_crc_crc_10000_30:
      000562                        126 	.ds 2
      000564                        127 _write_page_address_10000_32:
      000564                        128 	.ds 2
      000566                        129 _journal_header_valid_header_10000_39:
      000566                        130 	.ds 2
      000568                        131 _recover_journal_header_10000_46:
      000568                        132 	.ds 9
      000571                        133 _ak820_nvm_flush_header_10000_62:
      000571                        134 	.ds 9
      00057A                        135 _ak820_nvm_flush_stage_10000_62:
      00057A                        136 	.ds 1
      00057B                        137 _load_page_page_10000_87:
      00057B                        138 	.ds 1
      00057C                        139 _read_offset_offset_10000_93:
      00057C                        140 	.ds 2
      00057E                        141 _eeprom_read_byte_addr_10000_97:
      00057E                        142 	.ds 3
      000581                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000584                        146 	.ds 2
      000586                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000586                        148 	.ds 2
      000588                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000588                        150 	.ds 2
      00058A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058A                        152 	.ds 3
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058D                        154 	.ds 2
      00058F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058F                        156 	.ds 2
      000591                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000591                        158 	.ds 3
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000594                        160 	.ds 2
      000596                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000596                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B4D                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B4D E5 82            [12]  215 	mov	a,dpl
      003B4F 90 05 5C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B52 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B53 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003B56 90 05 5C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B59 E0               [24]  221 	movx	a,@dptr
      003B5A 90 05 5B         [24]  222 	mov	dptr,#_first_failure_stage
      003B5D F0               [24]  223 	movx	@dptr,a
      003B5E                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B5E D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B60 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B61                        239 _ak820_nvm_diagnostic:
      003B61 12 38 49         [24]  240 	lcall	_ak820_outline_0104
      003B64 90 05 5D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B67 12 38 4E         [24]  242 	lcall	_ak820_outline_0105
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003B6A 90 05 5D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B6D 12 38 00         [24]  245 	lcall	_ak820_outline_0050
      003B70 A2 09            [12]  246 	mov	c,_storage_failed
      003B72 E4               [12]  247 	clr	a
      003B73 33               [12]  248 	rlc	a
      003B74 12 43 20         [24]  249 	lcall	_ak820_outline_0117
      003B77 12 43 02         [24]  250 	lcall	_ak820_outline_0060
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003B7A A3               [24]  252 	inc	dptr
      003B7B A2 07            [12]  253 	mov	c,_page_valid
      003B7D E4               [12]  254 	clr	a
      003B7E 33               [12]  255 	rlc	a
      003B7F 12 42 D6         [24]  256 	lcall	_ak820_outline_0029
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003B82 A2 08            [12]  258 	mov	c,_page_dirty
      003B84 E4               [12]  259 	clr	a
      003B85 33               [12]  260 	rlc	a
      003B86 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003B87 74 03            [12]  263 	mov	a,#0x03
      003B89 12 43 4B         [24]  264 	lcall	_ak820_outline_0156
      003B8C 90 05 5A         [24]  265 	mov	dptr,#_batch_depth
      003B8F E0               [24]  266 	movx	a,@dptr
      003B90 12 38 60         [24]  267 	lcall	_ak820_outline_0121
      003B93 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003B94 74 04            [12]  270 	mov	a,#0x04
      003B96 12 43 4B         [24]  271 	lcall	_ak820_outline_0156
      003B99 90 05 59         [24]  272 	mov	dptr,#_cached_page
      003B9C E0               [24]  273 	movx	a,@dptr
      003B9D 12 38 60         [24]  274 	lcall	_ak820_outline_0121
      003BA0 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003BA1 12 42 CC         [24]  277 	lcall	_ak820_outline_0009
      003BA4 E4               [12]  278 	clr	a
      003BA5 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003BA6 74 06            [12]  281 	mov	a,#0x06
      003BA8 12 43 30         [24]  282 	lcall	_ak820_outline_0134
      003BAB 90 05 5B         [24]  283 	mov	dptr,#_first_failure_stage
      003BAE E0               [24]  284 	movx	a,@dptr
      003BAF 12 43 20         [24]  285 	lcall	_ak820_outline_0117
      003BB2 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BB3 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003BB4                        300 _crc_byte:
      003BB4 12 38 49         [24]  301 	lcall	_ak820_outline_0104
      003BB7 90 05 60         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003BBA 12 38 4E         [24]  303 	lcall	_ak820_outline_0105
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BBD 90 05 5F         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003BC0 E0               [24]  306 	movx	a,@dptr
      003BC1 FF               [12]  307 	mov	r7,a
      003BC2 7E 00            [12]  308 	mov	r6,#0x00
      003BC4 90 05 60         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003BC7 E0               [24]  310 	movx	a,@dptr
      003BC8 6E               [12]  311 	xrl	a,r6
      003BC9 F0               [24]  312 	movx	@dptr,a
      003BCA A3               [24]  313 	inc	dptr
      003BCB E0               [24]  314 	movx	a,@dptr
      003BCC 6F               [12]  315 	xrl	a,r7
      003BCD F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BCE 7F 00            [12]  318 	mov	r7,#0x00
      003BD0                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003BD0 90 05 60         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003BD3 12 43 0E         [24]  322 	lcall	_ak820_outline_0096
      003BD6 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003BD9 ED               [12]  324 	mov	a,r5
      003BDA 2D               [12]  325 	add	a,r5
      003BDB FB               [12]  326 	mov	r3,a
      003BDC EE               [12]  327 	mov	a,r6
      003BDD 33               [12]  328 	rlc	a
      003BDE FC               [12]  329 	mov	r4,a
      003BDF 63 03 21         [24]  330 	xrl	ar3,#0x21
      003BE2 63 04 10         [24]  331 	xrl	ar4,#0x10
      003BE5 80 06            [24]  332 	sjmp	00107$
      003BE7                        333 00106$:
      003BE7 ED               [12]  334 	mov	a,r5
      003BE8 2D               [12]  335 	add	a,r5
      003BE9 FB               [12]  336 	mov	r3,a
      003BEA EE               [12]  337 	mov	a,r6
      003BEB 33               [12]  338 	rlc	a
      003BEC FC               [12]  339 	mov	r4,a
      003BED                        340 00107$:
      003BED 90 05 60         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003BF0 12 38 2B         [24]  342 	lcall	_ak820_outline_0075
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BF3 0F               [12]  344 	inc	r7
      003BF4 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003BF7 12 33 FC         [24]  347 	lcall	_ak820_outline_0122
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003BFA 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003BFB                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003BFB 90 05 62         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003BFE 74 FF            [12]  363 	mov	a,#0xff
      003C00 F0               [24]  364 	movx	@dptr,a
      003C01 A3               [24]  365 	inc	dptr
      003C02 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C03 7F 00            [12]  368 	mov	r7,#0x00
      003C05                        369 00102$:
      003C05 90 05 62         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003C08 12 43 0E         [24]  371 	lcall	_ak820_outline_0096
      003C0B 12 43 14         [24]  372 	lcall	_ak820_outline_0102
      003C0E 90 05 5F         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003C11 F0               [24]  374 	movx	@dptr,a
      003C12 12 38 6A         [24]  375 	lcall	_ak820_outline_0131
      003C15 C0 07            [24]  376 	push	ar7
      003C17 12 3B B4         [24]  377 	lcall	_crc_byte
      003C1A AD 82            [24]  378 	mov	r5, dpl
      003C1C AE 83            [24]  379 	mov	r6, dph
      003C1E D0 07            [24]  380 	pop	ar7
      003C20 90 05 62         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003C23 12 43 51         [24]  382 	lcall	_ak820_outline_0157
      003C26 0F               [12]  383 	inc	r7
      003C27 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C2A 12 38 6A         [24]  386 	lcall	_ak820_outline_0131
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C2D 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003C2E                        399 _write_page:
      003C2E 12 38 49         [24]  400 	lcall	_ak820_outline_0104
      003C31 90 05 64         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003C34 12 38 4E         [24]  402 	lcall	_ak820_outline_0105
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C37 90 05 64         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003C3A 12 37 A0         [24]  405 	lcall	_ak820_outline_0004
      003C3D C0 07            [24]  406 	push	ar7
      003C3F C0 06            [24]  407 	push	ar6
      003C41 12 39 C6         [24]  408 	lcall	_ak820_flash_erase
      003C44 E5 82            [12]  409 	mov	a, dpl
      003C46 D0 06            [24]  410 	pop	ar6
      003C48 D0 07            [24]  411 	pop	ar7
      003C4A 70 03            [24]  412 	jnz	00102$
      003C4C F5 82            [12]  413 	mov	dpl,a
      003C4E 22               [24]  414 	ret
      003C4F                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C4F 90 04 F5         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C52 74 19            [12]  418 	mov	a,#_page_data
      003C54 F0               [24]  419 	movx	@dptr,a
      003C55 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003C57 A3               [24]  421 	inc	dptr
      003C58 12 43 02         [24]  422 	lcall	_ak820_outline_0060
      003C5B 12 3A DA         [24]  423 	lcall	_ak820_flash_program_page
      003C5E E5 82            [12]  424 	mov	a, dpl
      003C60 70 03            [24]  425 	jnz	00120$
      003C62 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C64 22               [24]  428 	ret
      003C65                        429 00120$:
      003C65 7F 00            [12]  430 	mov	r7,#0x00
      003C67                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C67 8F 05            [24]  433 	mov	ar5,r7
      003C69 7E 00            [12]  434 	mov	r6,#0x00
      003C6B 90 05 64         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003C6E 12 38 43         [24]  436 	lcall	_ak820_outline_0100
      003C71 ED               [12]  437 	mov	a,r5
      003C72 2B               [12]  438 	add	a, r3
      003C73 FB               [12]  439 	mov	r3,a
      003C74 EE               [12]  440 	mov	a,r6
      003C75 3C               [12]  441 	addc	a, r4
      003C76 FC               [12]  442 	mov	r4,a
      003C77 12 33 FC         [24]  443 	lcall	_ak820_outline_0122
      003C7A 12 38 B9         [24]  444 	lcall	_ak820_flash_read
      003C7D AE 82            [24]  445 	mov	r6, dpl
      003C7F 12 43 14         [24]  446 	lcall	_ak820_outline_0102
      003C82 FD               [12]  447 	mov	r5,a
      003C83 EE               [12]  448 	mov	a,r6
      003C84 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003C87 80 04            [24]  450 	sjmp	00109$
      003C89                        451 00149$:
      003C89 75 82 00         [24]  452 	mov	dpl, #0x00
      003C8C 22               [24]  453 	ret
      003C8D                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C8D 0F               [12]  456 	inc	r7
      003C8E BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003C91 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003C94 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003C95                        472 _journal_header_valid:
      003C95 12 38 49         [24]  473 	lcall	_ak820_outline_0104
      003C98 90 05 66         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003C9B 12 38 4E         [24]  475 	lcall	_ak820_outline_0105
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003C9E 90 05 66         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003CA1 12 37 A0         [24]  478 	lcall	_ak820_outline_0004
      003CA4 E0               [24]  479 	movx	a,@dptr
      003CA5 FD               [12]  480 	mov	r5,a
      003CA6 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003CA9 80 04            [24]  482 	sjmp	00116$
      003CAB                        483 00138$:
      003CAB 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CAE 22               [24]  486 	ret
      003CAF                        487 00116$:
      003CAF 7D 01            [12]  488 	mov	r5,#0x01
      003CB1                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CB1 ED               [12]  491 	mov	a,r5
      003CB2 12 37 E7         [24]  492 	lcall	_ak820_outline_0016
      003CB5 FC               [12]  493 	mov	r4,a
      003CB6 8D 02            [24]  494 	mov	ar2,r5
      003CB8 7B 00            [12]  495 	mov	r3,#0x00
      003CBA 74 04            [12]  496 	mov	a,#0x04
      003CBC 2A               [12]  497 	add	a, r2
      003CBD FA               [12]  498 	mov	r2,a
      003CBE E4               [12]  499 	clr	a
      003CBF 3B               [12]  500 	addc	a, r3
      003CC0 FB               [12]  501 	mov	r3,a
      003CC1 EA               [12]  502 	mov	a,r2
      003CC2 2E               [12]  503 	add	a, r6
      003CC3 F5 82            [12]  504 	mov	dpl,a
      003CC5 EB               [12]  505 	mov	a,r3
      003CC6 3F               [12]  506 	addc	a, r7
      003CC7 F5 83            [12]  507 	mov	dph,a
      003CC9 E0               [24]  508 	movx	a,@dptr
      003CCA 62 04            [12]  509 	xrl	ar4,a
      003CCC BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      003CCF 80 04            [24]  511 	sjmp	00107$
      003CD1                        512 00139$:
      003CD1 75 82 00         [24]  513 	mov	dpl, #0x00
      003CD4 22               [24]  514 	ret
      003CD5                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CD5 0D               [12]  517 	inc	r5
      003CD6 BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003CD9 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003CDC 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      003CDD                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003CDD 7F 00            [12]  537 	mov	r7,#0x00
      003CDF                        538 00115$:
      003CDF EF               [12]  539 	mov	a,r7
      003CE0 24 68            [12]  540 	add	a, #_recover_journal_header_10000_46
      003CE2 FD               [12]  541 	mov	r5,a
      003CE3 E4               [12]  542 	clr	a
      003CE4 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003CE6 FE               [12]  544 	mov	r6,a
      003CE7 8F 04            [24]  545 	mov	ar4,r7
      003CE9 7B 00            [12]  546 	mov	r3,#0x00
      003CEB 74 40            [12]  547 	mov	a,#0x40
      003CED 2C               [12]  548 	add	a, r4
      003CEE FC               [12]  549 	mov	r4,a
      003CEF 74 EF            [12]  550 	mov	a,#0xef
      003CF1 3B               [12]  551 	addc	a, r3
      003CF2 FB               [12]  552 	mov	r3,a
      003CF3 12 43 5C         [24]  553 	lcall	_ak820_outline_0181
      003CF6 12 38 B9         [24]  554 	lcall	_ak820_flash_read
      003CF9 AC 82            [24]  555 	mov	r4, dpl
      003CFB 12 38 6A         [24]  556 	lcall	_ak820_outline_0131
      003CFE EC               [12]  557 	mov	a,r4
      003CFF F0               [24]  558 	movx	@dptr,a
      003D00 0F               [12]  559 	inc	r7
      003D01 BF 09 DB         [24]  560 	cjne	r7,#0x09,00115$
                                    561 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D04 90 05 68         [24]  562 	mov	dptr,#_recover_journal_header_10000_46
      003D07 12 3C 95         [24]  563 	lcall	_journal_header_valid
      003D0A E5 82            [12]  564 	mov	a, dpl
      003D0C 70 01            [24]  565 	jnz	00103$
      003D0E 22               [24]  566 	ret
      003D0F                        567 00103$:
                                    568 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D0F 90 05 69         [24]  569 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D12 E0               [24]  570 	movx	a,@dptr
      003D13 FF               [12]  571 	mov	r7,a
      003D14 7E 00            [12]  572 	mov	r6,#0x00
      003D16 90 05 6A         [24]  573 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D19 E0               [24]  574 	movx	a,@dptr
      003D1A FC               [12]  575 	mov	r4,a
      003D1B E4               [12]  576 	clr	a
      003D1C 42 07            [12]  577 	orl	ar7,a
      003D1E EC               [12]  578 	mov	a,r4
      003D1F 42 06            [12]  579 	orl	ar6,a
                                    580 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D21 90 05 6B         [24]  581 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D24 E0               [24]  582 	movx	a,@dptr
      003D25 FD               [12]  583 	mov	r5,a
      003D26 7C 00            [12]  584 	mov	r4,#0x00
      003D28 90 05 6C         [24]  585 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D2B E0               [24]  586 	movx	a,@dptr
      003D2C FA               [12]  587 	mov	r2,a
      003D2D E4               [12]  588 	clr	a
      003D2E 12 43 36         [24]  589 	lcall	_ak820_outline_0139
                                    590 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D31 C3               [12]  591 	clr	c
      003D32 EF               [12]  592 	mov	a,r7
      003D33 94 A0            [12]  593 	subb	a,#0xa0
      003D35 EE               [12]  594 	mov	a,r6
      003D36 94 00            [12]  595 	subb	a,#0x00
      003D38 40 06            [24]  596 	jc	00134$
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D3A 75 82 01         [24]  598 	mov	dpl, #0x01
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D3D 02 3B 4D         [24]  600 	ljmp	_nvm_fail
                                    601 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D40                        602 00134$:
      003D40 7B 00            [12]  603 	mov	r3,#0x00
      003D42                        604 00117$:
      003D42 C0 05            [24]  605 	push	ar5
      003D44 C0 04            [24]  606 	push	ar4
      003D46 EB               [12]  607 	mov	a,r3
      003D47 24 19            [12]  608 	add	a, #_page_data
      003D49 F9               [12]  609 	mov	r1,a
      003D4A E4               [12]  610 	clr	a
      003D4B 34 05            [12]  611 	addc	a, #(_page_data >> 8)
      003D4D FA               [12]  612 	mov	r2,a
      003D4E 8B 00            [24]  613 	mov	ar0,r3
      003D50 7D 00            [12]  614 	mov	r5,#0x00
      003D52 74 EF            [12]  615 	mov	a,#0xef
      003D54 2D               [12]  616 	add	a, r5
      003D55 FD               [12]  617 	mov	r5,a
      003D56 88 82            [24]  618 	mov	dpl, r0
      003D58 8D 83            [24]  619 	mov	dph, r5
      003D5A 12 38 B9         [24]  620 	lcall	_ak820_flash_read
      003D5D AD 82            [24]  621 	mov	r5, dpl
      003D5F 12 43 57         [24]  622 	lcall	_ak820_outline_0180
      003D62 ED               [12]  623 	mov	a,r5
      003D63 F0               [24]  624 	movx	@dptr,a
      003D64 0B               [12]  625 	inc	r3
      003D65 BB 40 02         [24]  626 	cjne	r3,#0x40,00190$
      003D68 80 06            [24]  627 	sjmp	00191$
      003D6A                        628 00190$:
      003D6A D0 04            [24]  629 	pop	ar4
      003D6C D0 05            [24]  630 	pop	ar5
      003D6E 80 D2            [24]  631 	sjmp	00117$
      003D70                        632 00191$:
      003D70 D0 04            [24]  633 	pop	ar4
      003D72 D0 05            [24]  634 	pop	ar5
                                    635 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003D74 C0 07            [24]  636 	push	ar7
      003D76 C0 06            [24]  637 	push	ar6
      003D78 C0 05            [24]  638 	push	ar5
      003D7A C0 04            [24]  639 	push	ar4
      003D7C 12 3B FB         [24]  640 	lcall	_page_crc
      003D7F AA 82            [24]  641 	mov	r2, dpl
      003D81 AB 83            [24]  642 	mov	r3, dph
      003D83 D0 04            [24]  643 	pop	ar4
      003D85 D0 05            [24]  644 	pop	ar5
      003D87 D0 06            [24]  645 	pop	ar6
      003D89 D0 07            [24]  646 	pop	ar7
      003D8B EA               [12]  647 	mov	a,r2
      003D8C B5 05 06         [24]  648 	cjne	a,ar5,00192$
      003D8F EB               [12]  649 	mov	a,r3
      003D90 B5 04 02         [24]  650 	cjne	a,ar4,00192$
      003D93 80 06            [24]  651 	sjmp	00113$
      003D95                        652 00192$:
      003D95 75 82 02         [24]  653 	mov	dpl, #0x02
      003D98 02 3B 4D         [24]  654 	ljmp	_nvm_fail
      003D9B                        655 00113$:
                                    656 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003D9B EE               [12]  657 	mov	a,r6
      003D9C 54 03            [12]  658 	anl	a,#0x03
      003D9E A2 E0            [12]  659 	mov	c,acc.0
      003DA0 CF               [12]  660 	xch	a,r7
      003DA1 13               [12]  661 	rrc	a
      003DA2 CF               [12]  662 	xch	a,r7
      003DA3 13               [12]  663 	rrc	a
      003DA4 A2 E0            [12]  664 	mov	c,acc.0
      003DA6 CF               [12]  665 	xch	a,r7
      003DA7 13               [12]  666 	rrc	a
      003DA8 CF               [12]  667 	xch	a,r7
      003DA9 13               [12]  668 	rrc	a
      003DAA CF               [12]  669 	xch	a,r7
      003DAB 24 C7            [12]  670 	add	a,#0xc7
      003DAD FE               [12]  671 	mov	r6,a
      003DAE 12 43 46         [24]  672 	lcall	_ak820_outline_0153
      003DB1 12 3C 2E         [24]  673 	lcall	_write_page
      003DB4 E5 82            [12]  674 	mov	a, dpl
      003DB6 70 06            [24]  675 	jnz	00110$
      003DB8 75 82 03         [24]  676 	mov	dpl, #0x03
      003DBB 02 3B 4D         [24]  677 	ljmp	_nvm_fail
      003DBE                        678 00110$:
                                    679 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DBE 90 EF 40         [24]  680 	mov	dptr,#0xef40
      003DC1 12 39 C6         [24]  681 	lcall	_ak820_flash_erase
      003DC4 E5 82            [12]  682 	mov	a, dpl
      003DC6 70 06            [24]  683 	jnz	00119$
      003DC8 75 82 04         [24]  684 	mov	dpl, #0x04
                                    685 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003DCB 02 3B 4D         [24]  686 	ljmp	_nvm_fail
      003DCE                        687 00119$:
      003DCE 22               [24]  688 	ret
                                    689 ;------------------------------------------------------------
                                    690 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    691 ;------------------------------------------------------------
                                    692 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    693 ;	-----------------------------------------
                                    694 ;	 function eeprom_driver_init
                                    695 ;	-----------------------------------------
      003DCF                        696 _eeprom_driver_init:
                                    697 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    698 ;	assignBit
      003DCF C2 09            [12]  699 	clr	_storage_failed
                                    700 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003DD1 90 05 5B         [24]  701 	mov	dptr,#_first_failure_stage
      003DD4 E4               [12]  702 	clr	a
      003DD5 F0               [24]  703 	movx	@dptr,a
                                    704 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    705 ;	assignBit
      003DD6 C2 08            [12]  706 	clr	_page_dirty
                                    707 ;	assignBit
      003DD8 C2 07            [12]  708 	clr	_page_valid
                                    709 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003DDA 90 05 5A         [24]  710 	mov	dptr,#_batch_depth
      003DDD E4               [12]  711 	clr	a
      003DDE F0               [24]  712 	movx	@dptr,a
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003DDF 12 3C DD         [24]  714 	lcall	_recover_journal
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    716 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003DE2 02 2A B7         [24]  717 	ljmp	_ak820_macro_init
                                    718 ;------------------------------------------------------------
                                    719 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    720 ;------------------------------------------------------------
                                    721 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    722 ;	-----------------------------------------
                                    723 ;	 function ak820_nvm_ok
                                    724 ;	-----------------------------------------
      003DE5                        725 _ak820_nvm_ok:
      003DE5 A2 09            [12]  726 	mov	c,_storage_failed
      003DE7 B3               [12]  727 	cpl	c
      003DE8 92 0A            [24]  728 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003DEA 12 38 86         [24]  729 	lcall	_ak820_outline_0166
      003DED 22               [24]  730 	ret
                                    731 ;------------------------------------------------------------
                                    732 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    733 ;------------------------------------------------------------
                                    734 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    735 ;	-----------------------------------------
                                    736 ;	 function ak820_nvm_schema_fault
                                    737 ;	-----------------------------------------
      003DEE                        738 _ak820_nvm_schema_fault:
      003DEE 75 82 10         [24]  739 	mov	dpl, #0x10
      003DF1 02 3B 4D         [24]  740 	ljmp	_nvm_fail
                                    741 ;------------------------------------------------------------
                                    742 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    743 ;------------------------------------------------------------
                                    744 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    745 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    746 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    747 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    748 ;------------------------------------------------------------
                                    749 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    750 ;	-----------------------------------------
                                    751 ;	 function ak820_nvm_flush
                                    752 ;	-----------------------------------------
      003DF4                        753 _ak820_nvm_flush:
                                    754 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003DF4 30 08 03         [24]  755 	jnb	_page_dirty,00101$
      003DF7 30 09 01         [24]  756 	jnb	_storage_failed,00102$
      003DFA                        757 00101$:
      003DFA 22               [24]  758 	ret
      003DFB                        759 00102$:
                                    760 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003DFB 12 3B FB         [24]  761 	lcall	_page_crc
      003DFE 12 43 2B         [24]  762 	lcall	_ak820_outline_0132
                                    763 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E01 90 05 71         [24]  764 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E04 74 A5            [12]  765 	mov	a,#0xa5
      003E06 F0               [24]  766 	movx	@dptr,a
                                    767 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E07 90 05 59         [24]  768 	mov	dptr,#_cached_page
      003E0A E0               [24]  769 	movx	a,@dptr
      003E0B 90 05 72         [24]  770 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E0E F0               [24]  771 	movx	@dptr,a
                                    772 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E0F 90 05 73         [24]  773 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E12 E4               [12]  774 	clr	a
      003E13 F0               [24]  775 	movx	@dptr,a
                                    776 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E14 8E 05            [24]  777 	mov	ar5,r6
      003E16 90 05 74         [24]  778 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E19 ED               [12]  779 	mov	a,r5
      003E1A F0               [24]  780 	movx	@dptr,a
                                    781 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E1B 8F 06            [24]  782 	mov	ar6,r7
      003E1D 90 05 75         [24]  783 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E20 EE               [12]  784 	mov	a,r6
      003E21 F0               [24]  785 	movx	@dptr,a
                                    786 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E22 7F 01            [12]  787 	mov	r7,#0x01
      003E24                        788 00128$:
      003E24 8F 06            [24]  789 	mov	ar6,r7
      003E26 EE               [12]  790 	mov	a,r6
      003E27 24 04            [12]  791 	add	a,#0x04
      003E29 FE               [12]  792 	mov	r6,a
      003E2A 33               [12]  793 	rlc	a
      003E2B 95 E0            [12]  794 	subb	a,acc
      003E2D FD               [12]  795 	mov	r5,a
      003E2E EE               [12]  796 	mov	a,r6
      003E2F 24 71            [12]  797 	add	a, #_ak820_nvm_flush_header_10000_62
      003E31 FE               [12]  798 	mov	r6,a
      003E32 ED               [12]  799 	mov	a,r5
      003E33 34 05            [12]  800 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E35 FD               [12]  801 	mov	r5,a
      003E36 12 42 E5         [24]  802 	lcall	_ak820_outline_0039
      003E39 FC               [12]  803 	mov	r4,a
      003E3A 63 04 FF         [24]  804 	xrl	ar4,#0xff
      003E3D 8E 82            [24]  805 	mov	dpl,r6
      003E3F 8D 83            [24]  806 	mov	dph,r5
      003E41 EC               [12]  807 	mov	a,r4
      003E42 F0               [24]  808 	movx	@dptr,a
      003E43 0F               [12]  809 	inc	r7
      003E44 BF 05 DD         [24]  810 	cjne	r7,#0x05,00128$
                                    811 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E47 90 05 7A         [24]  812 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E4A 74 05            [12]  813 	mov	a,#0x05
      003E4C F0               [24]  814 	movx	@dptr,a
                                    815 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E4D 90 EF 40         [24]  816 	mov	dptr,#0xef40
      003E50 12 39 C6         [24]  817 	lcall	_ak820_flash_erase
      003E53 E5 82            [12]  818 	mov	a, dpl
      003E55 70 03            [24]  819 	jnz	00269$
      003E57 02 3F 3E         [24]  820 	ljmp	00127$
      003E5A                        821 00269$:
                                    822 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E5A 90 05 7A         [24]  823 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E5D 74 06            [12]  824 	mov	a,#0x06
      003E5F F0               [24]  825 	movx	@dptr,a
                                    826 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E60 7F 00            [12]  827 	mov	r7,#0x00
      003E62                        828 00130$:
                                    829 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E62 12 42 F1         [24]  830 	lcall	_ak820_outline_0051
      003E65 12 38 B9         [24]  831 	lcall	_ak820_flash_read
      003E68 E5 82            [12]  832 	mov	a, dpl
      003E6A 60 03            [24]  833 	jz	00270$
      003E6C 02 3F 3E         [24]  834 	ljmp	00127$
      003E6F                        835 00270$:
                                    836 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E6F 0F               [12]  837 	inc	r7
      003E70 BF 40 EF         [24]  838 	cjne	r7,#0x40,00130$
                                    839 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003E73 90 05 7A         [24]  840 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E76 74 07            [12]  841 	mov	a,#0x07
      003E78 F0               [24]  842 	movx	@dptr,a
                                    843 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003E79 90 EF 00         [24]  844 	mov	dptr,#0xef00
      003E7C 12 3C 2E         [24]  845 	lcall	_write_page
      003E7F E5 82            [12]  846 	mov	a, dpl
      003E81 70 03            [24]  847 	jnz	00273$
      003E83 02 3F 3E         [24]  848 	ljmp	00127$
      003E86                        849 00273$:
                                    850 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003E86 90 05 7A         [24]  851 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E89 74 08            [12]  852 	mov	a,#0x08
      003E8B F0               [24]  853 	movx	@dptr,a
                                    854 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003E8C 7F 01            [12]  855 	mov	r7,#0x01
      003E8E                        856 00132$:
                                    857 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003E8E 12 42 E5         [24]  858 	lcall	_ak820_outline_0039
      003E91 FE               [12]  859 	mov	r6,a
      003E92 60 23            [24]  860 	jz	00133$
      003E94 8F 05            [24]  861 	mov	ar5,r7
      003E96 7C 00            [12]  862 	mov	r4,#0x00
      003E98 74 40            [12]  863 	mov	a,#0x40
      003E9A 2D               [12]  864 	add	a, r5
      003E9B FD               [12]  865 	mov	r5,a
      003E9C 74 EF            [12]  866 	mov	a,#0xef
      003E9E 3C               [12]  867 	addc	a, r4
      003E9F FC               [12]  868 	mov	r4,a
      003EA0 90 04 F2         [24]  869 	mov	dptr,#_ak820_flash_program_PARM_2
      003EA3 EE               [12]  870 	mov	a,r6
      003EA4 F0               [24]  871 	movx	@dptr,a
      003EA5 8D 82            [24]  872 	mov	dpl, r5
      003EA7 8C 83            [24]  873 	mov	dph, r4
      003EA9 C0 07            [24]  874 	push	ar7
      003EAB 12 3A 26         [24]  875 	lcall	_ak820_flash_program
      003EAE E5 82            [12]  876 	mov	a, dpl
      003EB0 D0 07            [24]  877 	pop	ar7
      003EB2 70 03            [24]  878 	jnz	00275$
      003EB4 02 3F 3E         [24]  879 	ljmp	00127$
      003EB7                        880 00275$:
      003EB7                        881 00133$:
                                    882 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EB7 0F               [12]  883 	inc	r7
      003EB8 BF 09 D3         [24]  884 	cjne	r7,#0x09,00132$
                                    885 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EBB 90 05 7A         [24]  886 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EBE 74 09            [12]  887 	mov	a,#0x09
      003EC0 F0               [24]  888 	movx	@dptr,a
                                    889 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EC1 7F 01            [12]  890 	mov	r7,#0x01
      003EC3                        891 00134$:
                                    892 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EC3 12 42 F1         [24]  893 	lcall	_ak820_outline_0051
      003EC6 12 38 B9         [24]  894 	lcall	_ak820_flash_read
      003EC9 AE 82            [24]  895 	mov	r6, dpl
      003ECB 12 42 E5         [24]  896 	lcall	_ak820_outline_0039
      003ECE FD               [12]  897 	mov	r5,a
      003ECF EE               [12]  898 	mov	a,r6
      003ED0 B5 05 6B         [24]  899 	cjne	a,ar5,00127$
                                    900 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003ED3 0F               [12]  901 	inc	r7
      003ED4 BF 09 EC         [24]  902 	cjne	r7,#0x09,00134$
                                    903 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003ED7 90 05 7A         [24]  904 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EDA 74 0A            [12]  905 	mov	a,#0x0a
      003EDC F0               [24]  906 	movx	@dptr,a
                                    907 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003EDD 90 05 71         [24]  908 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EE0 E0               [24]  909 	movx	a,@dptr
      003EE1 90 04 F2         [24]  910 	mov	dptr,#_ak820_flash_program_PARM_2
      003EE4 F0               [24]  911 	movx	@dptr,a
      003EE5 90 EF 40         [24]  912 	mov	dptr,#0xef40
      003EE8 12 3A 26         [24]  913 	lcall	_ak820_flash_program
      003EEB E5 82            [12]  914 	mov	a, dpl
      003EED 60 4F            [24]  915 	jz	00127$
                                    916 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003EEF 90 05 7A         [24]  917 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EF2 74 0B            [12]  918 	mov	a,#0x0b
      003EF4 F0               [24]  919 	movx	@dptr,a
                                    920 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003EF5 90 EF 40         [24]  921 	mov	dptr,#0xef40
      003EF8 12 38 B9         [24]  922 	lcall	_ak820_flash_read
      003EFB AF 82            [24]  923 	mov	r7, dpl
      003EFD 90 05 71         [24]  924 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F00 E0               [24]  925 	movx	a,@dptr
      003F01 FE               [12]  926 	mov	r6,a
      003F02 EF               [12]  927 	mov	a,r7
      003F03 B5 06 38         [24]  928 	cjne	a,ar6,00127$
                                    929 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F06 90 05 7A         [24]  930 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F09 74 0C            [12]  931 	mov	a,#0x0c
      003F0B F0               [24]  932 	movx	@dptr,a
                                    933 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F0C 90 05 59         [24]  934 	mov	dptr,#_cached_page
      003F0F E0               [24]  935 	movx	a,@dptr
      003F10 FE               [12]  936 	mov	r6,a
      003F11 E4               [12]  937 	clr	a
      003F12 C3               [12]  938 	clr	c
      003F13 CE               [12]  939 	xch	a,r6
      003F14 13               [12]  940 	rrc	a
      003F15 CE               [12]  941 	xch	a,r6
      003F16 13               [12]  942 	rrc	a
      003F17 A2 E0            [12]  943 	mov	c,acc.0
      003F19 CE               [12]  944 	xch	a,r6
      003F1A 13               [12]  945 	rrc	a
      003F1B CE               [12]  946 	xch	a,r6
      003F1C 13               [12]  947 	rrc	a
      003F1D CE               [12]  948 	xch	a,r6
      003F1E 24 C7            [12]  949 	add	a,#0xc7
      003F20 FF               [12]  950 	mov	r7,a
      003F21 12 43 20         [24]  951 	lcall	_ak820_outline_0117
      003F24 12 3C 2E         [24]  952 	lcall	_write_page
      003F27 E5 82            [12]  953 	mov	a, dpl
      003F29 60 13            [24]  954 	jz	00127$
                                    955 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F2B 90 05 7A         [24]  956 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F2E 74 0D            [12]  957 	mov	a,#0x0d
      003F30 F0               [24]  958 	movx	@dptr,a
                                    959 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F31 90 EF 40         [24]  960 	mov	dptr,#0xef40
      003F34 12 39 C6         [24]  961 	lcall	_ak820_flash_erase
      003F37 E5 82            [12]  962 	mov	a, dpl
      003F39 60 03            [24]  963 	jz	00127$
                                    964 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    965 ;	assignBit
      003F3B C2 08            [12]  966 	clr	_page_dirty
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    968 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F3D 22               [24]  969 	ret
      003F3E                        970 00127$:
                                    971 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F3E 90 05 7A         [24]  972 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F41 E0               [24]  973 	movx	a,@dptr
      003F42 F5 82            [12]  974 	mov	dpl,a
                                    975 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F44 02 3B 4D         [24]  976 	ljmp	_nvm_fail
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    979 ;------------------------------------------------------------
                                    980 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    981 ;	-----------------------------------------
                                    982 ;	 function ak820_nvm_begin
                                    983 ;	-----------------------------------------
      003F47                        984 _ak820_nvm_begin:
                                    985 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F47 90 05 5A         [24]  986 	mov	dptr,#_batch_depth
      003F4A E0               [24]  987 	movx	a,@dptr
      003F4B FF               [12]  988 	mov	r7,a
      003F4C BF FF 06         [24]  989 	cjne	r7,#0xff,00102$
      003F4F 75 82 0F         [24]  990 	mov	dpl, #0x0f
      003F52 02 3B 4D         [24]  991 	ljmp	_nvm_fail
      003F55                        992 00102$:
                                    993 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F55 90 05 5A         [24]  994 	mov	dptr,#_batch_depth
      003F58 EF               [12]  995 	mov	a,r7
      003F59 04               [12]  996 	inc	a
      003F5A F0               [24]  997 	movx	@dptr,a
                                    998 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F5B 22               [24]  999 	ret
                                   1000 ;------------------------------------------------------------
                                   1001 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1002 ;------------------------------------------------------------
                                   1003 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1004 ;	-----------------------------------------
                                   1005 ;	 function ak820_nvm_end
                                   1006 ;	-----------------------------------------
      003F5C                       1007 _ak820_nvm_end:
                                   1008 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F5C 90 05 5A         [24] 1009 	mov	dptr,#_batch_depth
      003F5F E0               [24] 1010 	movx	a,@dptr
      003F60 FF               [12] 1011 	mov	r7,a
      003F61 E0               [24] 1012 	movx	a,@dptr
      003F62 60 06            [24] 1013 	jz	00102$
      003F64 EF               [12] 1014 	mov	a,r7
      003F65 14               [12] 1015 	dec	a
      003F66 90 05 5A         [24] 1016 	mov	dptr,#_batch_depth
      003F69 F0               [24] 1017 	movx	@dptr,a
      003F6A                       1018 00102$:
                                   1019 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003F6A 90 05 5A         [24] 1020 	mov	dptr,#_batch_depth
      003F6D E0               [24] 1021 	movx	a,@dptr
      003F6E 70 03            [24] 1022 	jnz	00105$
                                   1023 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003F70 02 3D F4         [24] 1024 	ljmp	_ak820_nvm_flush
      003F73                       1025 00105$:
      003F73 22               [24] 1026 	ret
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'load_page'
                                   1029 ;------------------------------------------------------------
                                   1030 ;page          Allocated with name '_load_page_page_10000_87'
                                   1031 ;i             Allocated with name '_load_page_i_10000_88'
                                   1032 ;------------------------------------------------------------
                                   1033 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1034 ;	-----------------------------------------
                                   1035 ;	 function load_page
                                   1036 ;	-----------------------------------------
      003F74                       1037 _load_page:
      003F74 E5 82            [12] 1038 	mov	a,dpl
      003F76 90 05 7B         [24] 1039 	mov	dptr,#_load_page_page_10000_87
      003F79 F0               [24] 1040 	movx	@dptr,a
                                   1041 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003F7A 30 07 17         [24] 1042 	jnb	_page_valid,00102$
      003F7D 90 05 59         [24] 1043 	mov	dptr,#_cached_page
      003F80 E0               [24] 1044 	movx	a,@dptr
      003F81 FF               [12] 1045 	mov	r7,a
      003F82 90 05 7B         [24] 1046 	mov	dptr,#_load_page_page_10000_87
      003F85 E0               [24] 1047 	movx	a,@dptr
      003F86 FE               [12] 1048 	mov	r6,a
      003F87 EF               [12] 1049 	mov	a,r7
      003F88 B5 06 09         [24] 1050 	cjne	a,ar6,00102$
      003F8B A2 09            [12] 1051 	mov	c,_storage_failed
      003F8D B3               [12] 1052 	cpl	c
      003F8E 92 0B            [24] 1053 	mov  _load_page_sloc0_1_0,c
      003F90 12 38 86         [24] 1054 	lcall	_ak820_outline_0166
      003F93 22               [24] 1055 	ret
      003F94                       1056 00102$:
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003F94 12 3D F4         [24] 1058 	lcall	_ak820_nvm_flush
                                   1059 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003F97 30 09 04         [24] 1060 	jnb	_storage_failed,00119$
      003F9A 75 82 00         [24] 1061 	mov	dpl, #0x00
                                   1062 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F9D 22               [24] 1063 	ret
      003F9E                       1064 00119$:
      003F9E 7F 00            [12] 1065 	mov	r7,#0x00
      003FA0                       1066 00107$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003FA0 EF               [12] 1068 	mov	a,r7
      003FA1 24 19            [12] 1069 	add	a, #_page_data
      003FA3 FD               [12] 1070 	mov	r5,a
      003FA4 E4               [12] 1071 	clr	a
      003FA5 34 05            [12] 1072 	addc	a, #(_page_data >> 8)
      003FA7 FE               [12] 1073 	mov	r6,a
      003FA8 90 05 7B         [24] 1074 	mov	dptr,#_load_page_page_10000_87
      003FAB E0               [24] 1075 	movx	a,@dptr
      003FAC FC               [12] 1076 	mov	r4,a
      003FAD FA               [12] 1077 	mov	r2,a
      003FAE E4               [12] 1078 	clr	a
      003FAF C3               [12] 1079 	clr	c
      003FB0 CA               [12] 1080 	xch	a,r2
      003FB1 13               [12] 1081 	rrc	a
      003FB2 CA               [12] 1082 	xch	a,r2
      003FB3 13               [12] 1083 	rrc	a
      003FB4 A2 E0            [12] 1084 	mov	c,acc.0
      003FB6 CA               [12] 1085 	xch	a,r2
      003FB7 13               [12] 1086 	rrc	a
      003FB8 CA               [12] 1087 	xch	a,r2
      003FB9 13               [12] 1088 	rrc	a
      003FBA CA               [12] 1089 	xch	a,r2
      003FBB 24 C7            [12] 1090 	add	a,#0xc7
      003FBD FB               [12] 1091 	mov	r3,a
      003FBE 8F 01            [24] 1092 	mov	ar1,r7
      003FC0 89 00            [24] 1093 	mov	ar0,r1
      003FC2 79 00            [12] 1094 	mov	r1,#0x00
      003FC4 E8               [12] 1095 	mov	a,r0
      003FC5 2A               [12] 1096 	add	a, r2
      003FC6 FA               [12] 1097 	mov	r2,a
      003FC7 E9               [12] 1098 	mov	a,r1
      003FC8 3B               [12] 1099 	addc	a, r3
      003FC9 FB               [12] 1100 	mov	r3,a
      003FCA 12 43 3C         [24] 1101 	lcall	_ak820_outline_0140
      003FCD 12 38 B9         [24] 1102 	lcall	_ak820_flash_read
      003FD0 AB 82            [24] 1103 	mov	r3, dpl
      003FD2 12 38 6A         [24] 1104 	lcall	_ak820_outline_0131
      003FD5 EB               [12] 1105 	mov	a,r3
      003FD6 F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FD7 0F               [12] 1108 	inc	r7
      003FD8 BF 40 C5         [24] 1109 	cjne	r7,#0x40,00107$
                                   1110 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      003FDB 90 05 59         [24] 1111 	mov	dptr,#_cached_page
      003FDE EC               [12] 1112 	mov	a,r4
      003FDF F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1115 ;	assignBit
      003FE0 D2 07            [12] 1116 	setb	_page_valid
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      003FE2 75 82 01         [24] 1118 	mov	dpl, #0x01
                                   1119 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      003FE5 22               [24] 1120 	ret
                                   1121 ;------------------------------------------------------------
                                   1122 ;Allocation info for local variables in function 'read_offset'
                                   1123 ;------------------------------------------------------------
                                   1124 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1125 ;------------------------------------------------------------
                                   1126 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1127 ;	-----------------------------------------
                                   1128 ;	 function read_offset
                                   1129 ;	-----------------------------------------
      003FE6                       1130 _read_offset:
      003FE6 12 38 49         [24] 1131 	lcall	_ak820_outline_0104
      003FE9 90 05 7C         [24] 1132 	mov	dptr,#_read_offset_offset_10000_93
      003FEC 12 38 4E         [24] 1133 	lcall	_ak820_outline_0105
                                   1134 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      003FEF 90 05 7C         [24] 1135 	mov	dptr,#_read_offset_offset_10000_93
      003FF2 12 38 00         [24] 1136 	lcall	_ak820_outline_0050
      003FF5 C3               [12] 1137 	clr	c
      003FF6 94 28            [12] 1138 	subb	a,#0x28
      003FF8 40 04            [24] 1139 	jc	00102$
      003FFA 75 82 00         [24] 1140 	mov	dpl, #0x00
      003FFD 22               [24] 1141 	ret
      003FFE                       1142 00102$:
                                   1143 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      003FFE 30 07 34         [24] 1144 	jnb	_page_valid,00104$
      004001 8E 04            [24] 1145 	mov	ar4,r6
      004003 EF               [12] 1146 	mov	a,r7
      004004 A2 E7            [12] 1147 	mov	c,acc.7
      004006 CC               [12] 1148 	xch	a,r4
      004007 33               [12] 1149 	rlc	a
      004008 CC               [12] 1150 	xch	a,r4
      004009 33               [12] 1151 	rlc	a
      00400A A2 E7            [12] 1152 	mov	c,acc.7
      00400C CC               [12] 1153 	xch	a,r4
      00400D 33               [12] 1154 	rlc	a
      00400E CC               [12] 1155 	xch	a,r4
      00400F 33               [12] 1156 	rlc	a
      004010 CC               [12] 1157 	xch	a,r4
      004011 54 03            [12] 1158 	anl	a,#0x03
      004013 FD               [12] 1159 	mov	r5,a
      004014 90 05 59         [24] 1160 	mov	dptr,#_cached_page
      004017 E0               [24] 1161 	movx	a,@dptr
      004018 FA               [12] 1162 	mov	r2,a
      004019 7B 00            [12] 1163 	mov	r3,#0x00
      00401B EC               [12] 1164 	mov	a,r4
      00401C B5 02 16         [24] 1165 	cjne	a,ar2,00104$
      00401F ED               [12] 1166 	mov	a,r5
      004020 B5 03 12         [24] 1167 	cjne	a,ar3,00104$
                                   1168 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004023 74 3F            [12] 1169 	mov	a,#0x3f
      004025 5E               [12] 1170 	anl	a,r6
      004026 7D 00            [12] 1171 	mov	r5,#0x00
      004028 24 19            [12] 1172 	add	a, #_page_data
      00402A F5 82            [12] 1173 	mov	dpl,a
      00402C ED               [12] 1174 	mov	a,r5
      00402D 34 05            [12] 1175 	addc	a, #(_page_data >> 8)
      00402F F5 83            [12] 1176 	mov	dph,a
      004031 E0               [24] 1177 	movx	a,@dptr
      004032 F5 82            [12] 1178 	mov	dpl,a
      004034 22               [24] 1179 	ret
      004035                       1180 00104$:
                                   1181 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004035 74 C7            [12] 1182 	mov	a,#0xc7
      004037 2F               [12] 1183 	add	a, r7
      004038 FF               [12] 1184 	mov	r7,a
      004039 12 43 20         [24] 1185 	lcall	_ak820_outline_0117
                                   1186 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      00403C 02 38 B9         [24] 1187 	ljmp	_ak820_flash_read
                                   1188 ;------------------------------------------------------------
                                   1189 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1190 ;------------------------------------------------------------
                                   1191 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1192 ;------------------------------------------------------------
                                   1193 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1194 ;	-----------------------------------------
                                   1195 ;	 function eeprom_read_byte
                                   1196 ;	-----------------------------------------
      00403F                       1197 _eeprom_read_byte:
      00403F C0 07            [24] 1198 	push	ar7
      004041 C0 06            [24] 1199 	push	ar6
      004043 12 42 DE         [24] 1200 	lcall	_ak820_outline_0036
      004046 90 05 7E         [24] 1201 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004049 12 37 DF         [24] 1202 	lcall	_ak820_outline_0015
                                   1203 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00404C 90 05 7E         [24] 1204 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00404F 12 37 A0         [24] 1205 	lcall	_ak820_outline_0004
      004052 C0 06            [24] 1206 	push	ar6
      004054 C0 05            [24] 1207 	push	ar5
      004056 C0 04            [24] 1208 	push	ar4
      004058 C0 03            [24] 1209 	push	ar3
      00405A C0 02            [24] 1210 	push	ar2
      00405C C0 01            [24] 1211 	push	ar1
      00405E C0 00            [24] 1212 	push	ar0
      004060 12 3F E6         [24] 1213 	lcall	_read_offset
      004063 AF 82            [24] 1214 	mov	r7, dpl
      004065 D0 00            [24] 1215 	pop	ar0
      004067 D0 01            [24] 1216 	pop	ar1
      004069 D0 02            [24] 1217 	pop	ar2
      00406B D0 03            [24] 1218 	pop	ar3
      00406D D0 04            [24] 1219 	pop	ar4
      00406F D0 05            [24] 1220 	pop	ar5
      004071 D0 06            [24] 1221 	pop	ar6
      004073 8F 82            [24] 1222 	mov	dpl, r7
                                   1223 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004075 D0 06            [24] 1224 	pop	ar6
      004077 D0 07            [24] 1225 	pop	ar7
      004079 22               [24] 1226 	ret
                                   1227 ;------------------------------------------------------------
                                   1228 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1229 ;------------------------------------------------------------
                                   1230 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1231 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1232 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1233 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1234 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1235 ;------------------------------------------------------------
                                   1236 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1237 ;	-----------------------------------------
                                   1238 ;	 function ak820_eeprom_read_block_xdata
                                   1239 ;	-----------------------------------------
      00407A                       1240 _ak820_eeprom_read_block_xdata:
      00407A 12 38 49         [24] 1241 	lcall	_ak820_outline_0104
      00407D 90 05 86         [24] 1242 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004080 12 38 4E         [24] 1243 	lcall	_ak820_outline_0105
                                   1244 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004083 90 05 81         [24] 1245 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004086 12 38 00         [24] 1246 	lcall	_ak820_outline_0050
                                   1247 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004089 90 05 86         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00408C 12 38 1F         [24] 1249 	lcall	_ak820_outline_0059
      00408F 90 05 88         [24] 1250 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004092 12 38 25         [24] 1251 	lcall	_ak820_outline_0070
                                   1252 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004095 90 05 84         [24] 1253 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004098 12 38 1F         [24] 1254 	lcall	_ak820_outline_0059
      00409B                       1255 00103$:
      00409B 8C 02            [24] 1256 	mov	ar2,r4
      00409D 8D 03            [24] 1257 	mov	ar3,r5
      00409F 1C               [12] 1258 	dec	r4
      0040A0 BC FF 01         [24] 1259 	cjne	r4,#0xff,00130$
      0040A3 1D               [12] 1260 	dec	r5
      0040A4                       1261 00130$:
      0040A4 EA               [12] 1262 	mov	a,r2
      0040A5 4B               [12] 1263 	orl	a,r3
      0040A6 60 5D            [24] 1264 	jz	00106$
                                   1265 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0040A8 8E 02            [24] 1266 	mov	ar2,r6
      0040AA 8F 03            [24] 1267 	mov	ar3,r7
      0040AC 74 D8            [12] 1268 	mov	a,#0x100 - 0x28
      0040AE 2B               [12] 1269 	add	a,r3
      0040AF 50 17            [24] 1270 	jnc	00102$
      0040B1 90 05 88         [24] 1271 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040B4 12 43 25         [24] 1272 	lcall	_ak820_outline_0120
      0040B7 12 43 3C         [24] 1273 	lcall	_ak820_outline_0140
      0040BA E4               [12] 1274 	clr	a
      0040BB F0               [24] 1275 	movx	@dptr,a
      0040BC 90 05 88         [24] 1276 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040BF 04               [12] 1277 	inc	a
      0040C0 2A               [12] 1278 	add	a, r2
      0040C1 F0               [24] 1279 	movx	@dptr,a
      0040C2 E4               [12] 1280 	clr	a
      0040C3 3B               [12] 1281 	addc	a, r3
      0040C4 A3               [24] 1282 	inc	dptr
      0040C5 F0               [24] 1283 	movx	@dptr,a
      0040C6 80 D3            [24] 1284 	sjmp	00103$
      0040C8                       1285 00102$:
                                   1286 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040C8 90 05 88         [24] 1287 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040CB 12 43 25         [24] 1288 	lcall	_ak820_outline_0120
      0040CE 12 43 20         [24] 1289 	lcall	_ak820_outline_0117
      0040D1 C0 07            [24] 1290 	push	ar7
      0040D3 C0 06            [24] 1291 	push	ar6
      0040D5 C0 05            [24] 1292 	push	ar5
      0040D7 C0 04            [24] 1293 	push	ar4
      0040D9 C0 03            [24] 1294 	push	ar3
      0040DB C0 02            [24] 1295 	push	ar2
      0040DD 12 3F E6         [24] 1296 	lcall	_read_offset
      0040E0 A9 82            [24] 1297 	mov	r1, dpl
      0040E2 D0 02            [24] 1298 	pop	ar2
      0040E4 D0 03            [24] 1299 	pop	ar3
      0040E6 D0 04            [24] 1300 	pop	ar4
      0040E8 D0 05            [24] 1301 	pop	ar5
      0040EA D0 06            [24] 1302 	pop	ar6
      0040EC D0 07            [24] 1303 	pop	ar7
      0040EE 12 43 3C         [24] 1304 	lcall	_ak820_outline_0140
      0040F1 E9               [12] 1305 	mov	a,r1
      0040F2 F0               [24] 1306 	movx	@dptr,a
      0040F3 90 05 88         [24] 1307 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040F6 74 01            [12] 1308 	mov	a,#0x01
      0040F8 2A               [12] 1309 	add	a, r2
      0040F9 F0               [24] 1310 	movx	@dptr,a
      0040FA E4               [12] 1311 	clr	a
      0040FB 3B               [12] 1312 	addc	a, r3
      0040FC A3               [24] 1313 	inc	dptr
      0040FD F0               [24] 1314 	movx	@dptr,a
                                   1315 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0040FE 0E               [12] 1316 	inc	r6
      0040FF BE 00 99         [24] 1317 	cjne	r6,#0x00,00103$
      004102 0F               [12] 1318 	inc	r7
      004103 80 96            [24] 1319 	sjmp	00103$
      004105                       1320 00106$:
                                   1321 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004105 22               [24] 1322 	ret
                                   1323 ;------------------------------------------------------------
                                   1324 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1325 ;------------------------------------------------------------
                                   1326 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1327 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1328 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1329 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1330 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1331 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1332 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1333 ;------------------------------------------------------------
                                   1334 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1335 ;	-----------------------------------------
                                   1336 ;	 function ak820_eeprom_write_block_xdata
                                   1337 ;	-----------------------------------------
      004106                       1338 _ak820_eeprom_write_block_xdata:
      004106 12 38 49         [24] 1339 	lcall	_ak820_outline_0104
      004109 90 05 8F         [24] 1340 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00410C 12 38 4E         [24] 1341 	lcall	_ak820_outline_0105
                                   1342 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00410F 90 05 8A         [24] 1343 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004112 12 38 00         [24] 1344 	lcall	_ak820_outline_0050
                                   1345 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004115 90 05 8F         [24] 1346 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004118 12 38 1F         [24] 1347 	lcall	_ak820_outline_0059
                                   1348 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00411B 8E 02            [24] 1349 	mov	ar2,r6
      00411D 8F 03            [24] 1350 	mov	ar3,r7
      00411F C3               [12] 1351 	clr	c
      004120 E4               [12] 1352 	clr	a
      004121 9A               [12] 1353 	subb	a,r2
      004122 74 28            [12] 1354 	mov	a,#0x28
      004124 9B               [12] 1355 	subb	a,r3
      004125 40 15            [24] 1356 	jc	00101$
                                   1357 ;	free result
      004127 E4               [12] 1358 	clr	a
      004128 C3               [12] 1359 	clr	c
      004129 9E               [12] 1360 	subb	a,r6
      00412A FA               [12] 1361 	mov	r2,a
      00412B 74 28            [12] 1362 	mov	a,#0x28
      00412D 9F               [12] 1363 	subb	a,r7
      00412E FB               [12] 1364 	mov	r3,a
      00412F 90 05 8D         [24] 1365 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004132 12 38 3D         [24] 1366 	lcall	_ak820_outline_0099
      004135 C3               [12] 1367 	clr	c
      004136 EA               [12] 1368 	mov	a,r2
      004137 98               [12] 1369 	subb	a,r0
      004138 EB               [12] 1370 	mov	a,r3
      004139 99               [12] 1371 	subb	a,r1
      00413A 50 06            [24] 1372 	jnc	00125$
                                   1373 ;	free result
      00413C                       1374 00101$:
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      00413C 75 82 0E         [24] 1376 	mov	dpl, #0x0e
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      00413F 02 3B 4D         [24] 1378 	ljmp	_nvm_fail
                                   1379 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004142                       1380 00125$:
      004142 90 05 8D         [24] 1381 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004145 12 43 25         [24] 1382 	lcall	_ak820_outline_0120
      004148                       1383 00108$:
      004148 8A 00            [24] 1384 	mov	ar0,r2
      00414A 8B 01            [24] 1385 	mov	ar1,r3
      00414C 1A               [12] 1386 	dec	r2
      00414D BA FF 01         [24] 1387 	cjne	r2,#0xff,00159$
      004150 1B               [12] 1388 	dec	r3
      004151                       1389 00159$:
      004151 E8               [12] 1390 	mov	a,r0
      004152 49               [12] 1391 	orl	a,r1
      004153 70 03            [24] 1392 	jnz	00160$
      004155 02 41 DF         [24] 1393 	ljmp	00110$
      004158                       1394 00160$:
                                   1395 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004158 C0 02            [24] 1396 	push	ar2
      00415A C0 03            [24] 1397 	push	ar3
      00415C 12 43 08         [24] 1398 	lcall	_ak820_outline_0091
      00415F F9               [12] 1399 	mov	r1,a
      004160 A3               [24] 1400 	inc	dptr
      004161 12 43 41         [24] 1401 	lcall	_ak820_outline_0145
                                   1402 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004164 8E 0C            [24] 1403 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004166 8F 0D            [24] 1404 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004168 A8 0C            [24] 1405 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00416A E5 0D            [12] 1406 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00416C A2 E7            [12] 1407 	mov	c,acc.7
      00416E C8               [12] 1408 	xch	a,r0
      00416F 33               [12] 1409 	rlc	a
      004170 C8               [12] 1410 	xch	a,r0
      004171 33               [12] 1411 	rlc	a
      004172 A2 E7            [12] 1412 	mov	c,acc.7
      004174 C8               [12] 1413 	xch	a,r0
      004175 33               [12] 1414 	rlc	a
      004176 C8               [12] 1415 	xch	a,r0
      004177 33               [12] 1416 	rlc	a
      004178 C8               [12] 1417 	xch	a,r0
      004179 54 03            [12] 1418 	anl	a,#0x03
      00417B FB               [12] 1419 	mov	r3,a
      00417C 88 82            [24] 1420 	mov	dpl, r0
      00417E C0 07            [24] 1421 	push	ar7
      004180 C0 06            [24] 1422 	push	ar6
      004182 C0 05            [24] 1423 	push	ar5
      004184 C0 04            [24] 1424 	push	ar4
      004186 C0 03            [24] 1425 	push	ar3
      004188 C0 02            [24] 1426 	push	ar2
      00418A C0 01            [24] 1427 	push	ar1
      00418C 12 3F 74         [24] 1428 	lcall	_load_page
      00418F E5 82            [12] 1429 	mov	a, dpl
      004191 D0 01            [24] 1430 	pop	ar1
      004193 D0 02            [24] 1431 	pop	ar2
      004195 D0 03            [24] 1432 	pop	ar3
      004197 D0 04            [24] 1433 	pop	ar4
      004199 D0 05            [24] 1434 	pop	ar5
      00419B D0 06            [24] 1435 	pop	ar6
      00419D D0 07            [24] 1436 	pop	ar7
      00419F D0 03            [24] 1437 	pop	ar3
      0041A1 D0 02            [24] 1438 	pop	ar2
      0041A3 70 01            [24] 1439 	jnz	00105$
      0041A5 22               [24] 1440 	ret
      0041A6                       1441 00105$:
                                   1442 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0041A6 C0 06            [24] 1443 	push	ar6
      0041A8 C0 07            [24] 1444 	push	ar7
      0041AA 74 3F            [12] 1445 	mov	a,#0x3f
      0041AC 55 0C            [12] 1446 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041AE 7F 00            [12] 1447 	mov	r7,#0x00
      0041B0 24 19            [12] 1448 	add	a, #_page_data
      0041B2 F5 0C            [12] 1449 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041B4 EF               [12] 1450 	mov	a,r7
      0041B5 34 05            [12] 1451 	addc	a, #(_page_data >> 8)
      0041B7 F5 0D            [12] 1452 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041B9 85 0C 82         [24] 1453 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041BC 85 0D 83         [24] 1454 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041BF E0               [24] 1455 	movx	a,@dptr
      0041C0 B5 01 06         [24] 1456 	cjne	a,ar1,00162$
      0041C3 D0 07            [24] 1457 	pop	ar7
      0041C5 D0 06            [24] 1458 	pop	ar6
      0041C7 80 0E            [24] 1459 	sjmp	00107$
      0041C9                       1460 00162$:
      0041C9 D0 07            [24] 1461 	pop	ar7
      0041CB D0 06            [24] 1462 	pop	ar6
                                   1463 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      0041CD 85 0C 82         [24] 1464 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041D0 85 0D 83         [24] 1465 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041D3 E9               [12] 1466 	mov	a,r1
      0041D4 F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1469 ;	assignBit
      0041D5 D2 08            [12] 1470 	setb	_page_dirty
      0041D7                       1471 00107$:
                                   1472 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      0041D7 0E               [12] 1473 	inc	r6
      0041D8 BE 00 01         [24] 1474 	cjne	r6,#0x00,00163$
      0041DB 0F               [12] 1475 	inc	r7
      0041DC                       1476 00163$:
      0041DC 02 41 48         [24] 1477 	ljmp	00108$
      0041DF                       1478 00110$:
                                   1479 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      0041DF 90 05 5A         [24] 1480 	mov	dptr,#_batch_depth
      0041E2 E0               [24] 1481 	movx	a,@dptr
      0041E3 70 03            [24] 1482 	jnz	00113$
                                   1483 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      0041E5 02 3D F4         [24] 1484 	ljmp	_ak820_nvm_flush
      0041E8                       1485 00113$:
      0041E8 22               [24] 1486 	ret
                                   1487 ;------------------------------------------------------------
                                   1488 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1489 ;------------------------------------------------------------
                                   1490 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1491 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1492 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1493 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1494 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1495 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1496 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1497 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1498 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1499 ;------------------------------------------------------------
                                   1500 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1501 ;	-----------------------------------------
                                   1502 ;	 function ak820_eeprom_update_block_xdata
                                   1503 ;	-----------------------------------------
      0041E9                       1504 _ak820_eeprom_update_block_xdata:
      0041E9 12 38 49         [24] 1505 	lcall	_ak820_outline_0104
      0041EC 90 05 96         [24] 1506 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041EF 12 38 4E         [24] 1507 	lcall	_ak820_outline_0105
                                   1508 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0041F2 90 05 96         [24] 1509 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041F5 12 38 00         [24] 1510 	lcall	_ak820_outline_0050
                                   1511 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0041F8 90 05 91         [24] 1512 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0041FB E0               [24] 1513 	movx	a,@dptr
      0041FC F5 12            [12] 1514 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0041FE A3               [24] 1515 	inc	dptr
      0041FF E0               [24] 1516 	movx	a,@dptr
      004200 F5 13            [12] 1517 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004202 A3               [24] 1518 	inc	dptr
      004203 E0               [24] 1519 	movx	a,@dptr
      004204 F5 14            [12] 1520 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004206 A9 12            [24] 1521 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004208 AA 13            [24] 1522 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1523 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00420A E4               [12] 1524 	clr	a
      00420B F5 0E            [12] 1525 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      00420D F5 0F            [12] 1526 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00420F                       1527 00105$:
      00420F 90 05 94         [24] 1528 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004212 E0               [24] 1529 	movx	a,@dptr
      004213 F5 10            [12] 1530 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004215 A3               [24] 1531 	inc	dptr
      004216 E0               [24] 1532 	movx	a,@dptr
      004217 F5 11            [12] 1533 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004219 C3               [12] 1534 	clr	c
      00421A E5 0E            [12] 1535 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00421C 95 10            [12] 1536 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00421E E5 0F            [12] 1537 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004220 95 11            [12] 1538 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004222 50 68            [24] 1539 	jnc	00107$
                                   1540 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004224 89 00            [24] 1541 	mov	ar0,r1
      004226 8A 05            [24] 1542 	mov	ar5,r2
      004228 E5 0E            [12] 1543 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00422A 28               [12] 1544 	add	a, r0
      00422B F8               [12] 1545 	mov	r0,a
      00422C E5 0F            [12] 1546 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00422E 3D               [12] 1547 	addc	a, r5
      00422F FD               [12] 1548 	mov	r5,a
      004230 88 82            [24] 1549 	mov	dpl, r0
      004232 8D 83            [24] 1550 	mov	dph, r5
      004234 C0 07            [24] 1551 	push	ar7
      004236 C0 06            [24] 1552 	push	ar6
      004238 C0 02            [24] 1553 	push	ar2
      00423A C0 01            [24] 1554 	push	ar1
      00423C 12 3F E6         [24] 1555 	lcall	_read_offset
      00423F AD 82            [24] 1556 	mov	r5, dpl
      004241 D0 01            [24] 1557 	pop	ar1
      004243 D0 02            [24] 1558 	pop	ar2
      004245 D0 06            [24] 1559 	pop	ar6
      004247 D0 07            [24] 1560 	pop	ar7
      004249 E5 0E            [12] 1561 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00424B 2E               [12] 1562 	add	a, r6
      00424C F5 82            [12] 1563 	mov	dpl,a
      00424E E5 0F            [12] 1564 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004250 3F               [12] 1565 	addc	a, r7
      004251 F5 83            [12] 1566 	mov	dph,a
      004253 E0               [24] 1567 	movx	a,@dptr
      004254 FC               [12] 1568 	mov	r4,a
      004255 ED               [12] 1569 	mov	a,r5
      004256 B5 04 02         [24] 1570 	cjne	a,ar4,00131$
      004259 80 27            [24] 1571 	sjmp	00106$
      00425B                       1572 00131$:
                                   1573 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00425B 90 05 96         [24] 1574 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00425E E0               [24] 1575 	movx	a,@dptr
      00425F F8               [12] 1576 	mov	r0,a
      004260 A3               [24] 1577 	inc	dptr
      004261 E0               [24] 1578 	movx	a,@dptr
      004262 FD               [12] 1579 	mov	r5,a
      004263 90 05 8A         [24] 1580 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004266 E5 12            [12] 1581 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004268 F0               [24] 1582 	movx	@dptr,a
      004269 E5 13            [12] 1583 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00426B A3               [24] 1584 	inc	dptr
      00426C F0               [24] 1585 	movx	@dptr,a
      00426D E5 14            [12] 1586 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      00426F A3               [24] 1587 	inc	dptr
      004270 F0               [24] 1588 	movx	@dptr,a
      004271 90 05 8D         [24] 1589 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004274 E5 10            [12] 1590 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004276 F0               [24] 1591 	movx	@dptr,a
      004277 E5 11            [12] 1592 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004279 A3               [24] 1593 	inc	dptr
      00427A F0               [24] 1594 	movx	@dptr,a
      00427B 88 82            [24] 1595 	mov	dpl, r0
      00427D 8D 83            [24] 1596 	mov	dph, r5
                                   1597 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      00427F 02 41 06         [24] 1598 	ljmp	_ak820_eeprom_write_block_xdata
      004282                       1599 00106$:
                                   1600 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004282 05 0E            [12] 1601 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004284 E4               [12] 1602 	clr	a
      004285 B5 0E 87         [24] 1603 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004288 05 0F            [12] 1604 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00428A 80 83            [24] 1605 	sjmp	00105$
      00428C                       1606 00107$:
                                   1607 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00428C 22               [24] 1608 	ret
                                   1609 ;------------------------------------------------------------
                                   1610 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1611 ;------------------------------------------------------------
                                   1612 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1613 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1614 ;------------------------------------------------------------
                                   1615 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1616 ;	-----------------------------------------
                                   1617 ;	 function eeprom_driver_erase
                                   1618 ;	-----------------------------------------
      00428D                       1619 _eeprom_driver_erase:
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00428D 12 3D F4         [24] 1621 	lcall	_ak820_nvm_flush
                                   1622 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004290 7F 00            [12] 1623 	mov	r7,#0x00
      004292                       1624 00111$:
      004292 BF A0 01         [24] 1625 	cjne	r7,#0xa0,00165$
      004295 22               [24] 1626 	ret
      004296                       1627 00165$:
      004296 20 09 32         [24] 1628 	jb	_storage_failed,00113$
                                   1629 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004299 8F 82            [24] 1630 	mov	dpl, r7
      00429B C0 07            [24] 1631 	push	ar7
      00429D 12 3F 74         [24] 1632 	lcall	_load_page
      0042A0 E5 82            [12] 1633 	mov	a, dpl
      0042A2 D0 07            [24] 1634 	pop	ar7
      0042A4 70 01            [24] 1635 	jnz	00126$
                                   1636 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042A6 22               [24] 1637 	ret
      0042A7                       1638 00126$:
      0042A7 7E 00            [12] 1639 	mov	r6,#0x00
      0042A9                       1640 00107$:
                                   1641 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0042A9 EE               [12] 1642 	mov	a,r6
      0042AA 24 19            [12] 1643 	add	a, #_page_data
      0042AC FC               [12] 1644 	mov	r4,a
      0042AD E4               [12] 1645 	clr	a
      0042AE 34 05            [12] 1646 	addc	a, #(_page_data >> 8)
      0042B0 FD               [12] 1647 	mov	r5,a
      0042B1 12 43 08         [24] 1648 	lcall	_ak820_outline_0091
      0042B4 60 07            [24] 1649 	jz	00108$
      0042B6 12 38 60         [24] 1650 	lcall	_ak820_outline_0121
      0042B9 E4               [12] 1651 	clr	a
      0042BA F0               [24] 1652 	movx	@dptr,a
                                   1653 ;	assignBit
      0042BB D2 08            [12] 1654 	setb	_page_dirty
      0042BD                       1655 00108$:
                                   1656 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042BD 0E               [12] 1657 	inc	r6
      0042BE BE 40 E8         [24] 1658 	cjne	r6,#0x40,00107$
                                   1659 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042C1 C0 07            [24] 1660 	push	ar7
      0042C3 12 3D F4         [24] 1661 	lcall	_ak820_nvm_flush
      0042C6 D0 07            [24] 1662 	pop	ar7
                                   1663 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042C8 0F               [12] 1664 	inc	r7
      0042C9 80 C7            [24] 1665 	sjmp	00111$
      0042CB                       1666 00113$:
                                   1667 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0042CB 22               [24] 1668 	ret
                                   1669 	.area CSEG    (CODE)
                                   1670 	.area CONST   (CODE)
                                   1671 	.area XINIT   (CODE)
                                   1672 	.area CABS    (ABS,CODE)
                                   1673 
                                   1674 ; Experimental exact instruction outlining.
                                   1675 	.globl _ak820_outline_0004
                                   1676 	.globl _ak820_outline_0009
                                   1677 	.globl _ak820_outline_0015
                                   1678 	.globl _ak820_outline_0016
                                   1679 	.globl _ak820_outline_0029
                                   1680 	.globl _ak820_outline_0036
                                   1681 	.globl _ak820_outline_0039
                                   1682 	.globl _ak820_outline_0050
                                   1683 	.globl _ak820_outline_0051
                                   1684 	.globl _ak820_outline_0059
                                   1685 	.globl _ak820_outline_0060
                                   1686 	.globl _ak820_outline_0070
                                   1687 	.globl _ak820_outline_0075
                                   1688 	.globl _ak820_outline_0091
                                   1689 	.globl _ak820_outline_0096
                                   1690 	.globl _ak820_outline_0099
                                   1691 	.globl _ak820_outline_0100
                                   1692 	.globl _ak820_outline_0102
                                   1693 	.globl _ak820_outline_0104
                                   1694 	.globl _ak820_outline_0105
                                   1695 	.globl _ak820_outline_0117
                                   1696 	.globl _ak820_outline_0120
                                   1697 	.globl _ak820_outline_0121
                                   1698 	.globl _ak820_outline_0122
                                   1699 	.globl _ak820_outline_0131
                                   1700 	.globl _ak820_outline_0132
                                   1701 	.globl _ak820_outline_0134
                                   1702 	.globl _ak820_outline_0139
                                   1703 	.globl _ak820_outline_0140
                                   1704 	.globl _ak820_outline_0145
                                   1705 	.globl _ak820_outline_0153
                                   1706 	.globl _ak820_outline_0156
                                   1707 	.globl _ak820_outline_0157
                                   1708 	.globl _ak820_outline_0166
                                   1709 	.globl _ak820_outline_0180
                                   1710 	.globl _ak820_outline_0181
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0009
      0042CC                       1714 _ak820_outline_0009:
      0042CC 8E 82            [24] 1715 	mov	dpl,r6
      0042CE 8F 83            [24] 1716 	mov	dph,r7
      0042D0 A3               [24] 1717 	inc	dptr
      0042D1 A3               [24] 1718 	inc	dptr
      0042D2 A3               [24] 1719 	inc	dptr
      0042D3 A3               [24] 1720 	inc	dptr
      0042D4 A3               [24] 1721 	inc	dptr
      0042D5 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0029
      0042D6                       1726 _ak820_outline_0029:
      0042D6 F0               [24] 1727 	movx	@dptr,a
      0042D7 8E 82            [24] 1728 	mov	dpl,r6
      0042D9 8F 83            [24] 1729 	mov	dph,r7
      0042DB A3               [24] 1730 	inc	dptr
      0042DC A3               [24] 1731 	inc	dptr
      0042DD 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0036
      0042DE                       1736 _ak820_outline_0036:
      0042DE AF F0            [24] 1737 	mov	r7,b
      0042E0 AE 83            [24] 1738 	mov	r6,dph
      0042E2 E5 82            [12] 1739 	mov	a,dpl
      0042E4 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0039
      0042E5                       1744 _ak820_outline_0039:
      0042E5 EF               [12] 1745 	mov	a,r7
      0042E6 24 71            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      0042E8 F5 82            [12] 1747 	mov	dpl,a
      0042EA E4               [12] 1748 	clr	a
      0042EB 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      0042ED F5 83            [12] 1750 	mov	dph,a
      0042EF E0               [24] 1751 	movx	a,@dptr
      0042F0 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0051
      0042F1                       1756 _ak820_outline_0051:
      0042F1 8F 06            [24] 1757 	mov	ar6,r7
      0042F3 7D 00            [12] 1758 	mov	r5,#0x00
      0042F5 74 40            [12] 1759 	mov	a,#0x40
      0042F7 2E               [12] 1760 	add	a,r6
      0042F8 FE               [12] 1761 	mov	r6,a
      0042F9 74 EF            [12] 1762 	mov	a,#0xef
      0042FB 3D               [12] 1763 	addc	a,r5
      0042FC FD               [12] 1764 	mov	r5,a
      0042FD 8E 82            [24] 1765 	mov	dpl,r6
      0042FF 8D 83            [24] 1766 	mov	dph,r5
      004301 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0060
      004302                       1771 _ak820_outline_0060:
      004302 F0               [24] 1772 	movx	@dptr,a
      004303 8E 82            [24] 1773 	mov	dpl,r6
      004305 8F 83            [24] 1774 	mov	dph,r7
      004307 22               [24] 1775 	ret
                                   1776 
                                   1777 	.area CSEG (CODE)
                                   1778 ; function ak820_outline_0091
      004308                       1779 _ak820_outline_0091:
      004308 8C 82            [24] 1780 	mov	dpl,r4
      00430A 8D 83            [24] 1781 	mov	dph,r5
      00430C E0               [24] 1782 	movx	a,@dptr
      00430D 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0096
      00430E                       1787 _ak820_outline_0096:
      00430E E0               [24] 1788 	movx	a,@dptr
      00430F FD               [12] 1789 	mov	r5,a
      004310 A3               [24] 1790 	inc	dptr
      004311 E0               [24] 1791 	movx	a,@dptr
      004312 FE               [12] 1792 	mov	r6,a
      004313 22               [24] 1793 	ret
                                   1794 
                                   1795 	.area CSEG (CODE)
                                   1796 ; function ak820_outline_0102
      004314                       1797 _ak820_outline_0102:
      004314 EF               [12] 1798 	mov	a,r7
      004315 24 19            [12] 1799 	add	a,#_page_data
      004317 F5 82            [12] 1800 	mov	dpl,a
      004319 E4               [12] 1801 	clr	a
      00431A 34 05            [12] 1802 	addc	a,#(_page_data>>8)
      00431C F5 83            [12] 1803 	mov	dph,a
      00431E E0               [24] 1804 	movx	a,@dptr
      00431F 22               [24] 1805 	ret
                                   1806 
                                   1807 	.area CSEG (CODE)
                                   1808 ; function ak820_outline_0117
      004320                       1809 _ak820_outline_0117:
      004320 8E 82            [24] 1810 	mov	dpl,r6
      004322 8F 83            [24] 1811 	mov	dph,r7
      004324 22               [24] 1812 	ret
                                   1813 
                                   1814 	.area CSEG (CODE)
                                   1815 ; function ak820_outline_0120
      004325                       1816 _ak820_outline_0120:
      004325 E0               [24] 1817 	movx	a,@dptr
      004326 FA               [12] 1818 	mov	r2,a
      004327 A3               [24] 1819 	inc	dptr
      004328 E0               [24] 1820 	movx	a,@dptr
      004329 FB               [12] 1821 	mov	r3,a
      00432A 22               [24] 1822 	ret
                                   1823 
                                   1824 	.area CSEG (CODE)
                                   1825 ; function ak820_outline_0132
      00432B                       1826 _ak820_outline_0132:
      00432B AE 82            [24] 1827 	mov	r6,dpl
      00432D AF 83            [24] 1828 	mov	r7,dph
      00432F 22               [24] 1829 	ret
                                   1830 
                                   1831 	.area CSEG (CODE)
                                   1832 ; function ak820_outline_0134
      004330                       1833 _ak820_outline_0134:
      004330 2E               [12] 1834 	add	a,r6
      004331 FE               [12] 1835 	mov	r6,a
      004332 E4               [12] 1836 	clr	a
      004333 3F               [12] 1837 	addc	a,r7
      004334 FF               [12] 1838 	mov	r7,a
      004335 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0139
      004336                       1843 _ak820_outline_0139:
      004336 42 05            [12] 1844 	orl	ar5,a
      004338 EA               [12] 1845 	mov	a,r2
      004339 42 04            [12] 1846 	orl	ar4,a
      00433B 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0140
      00433C                       1851 _ak820_outline_0140:
      00433C 8A 82            [24] 1852 	mov	dpl,r2
      00433E 8B 83            [24] 1853 	mov	dph,r3
      004340 22               [24] 1854 	ret
                                   1855 
                                   1856 	.area CSEG (CODE)
                                   1857 ; function ak820_outline_0145
      004341                       1858 _ak820_outline_0145:
      004341 AC 82            [24] 1859 	mov	r4,dpl
      004343 AD 83            [24] 1860 	mov	r5,dph
      004345 22               [24] 1861 	ret
                                   1862 
                                   1863 	.area CSEG (CODE)
                                   1864 ; function ak820_outline_0153
      004346                       1865 _ak820_outline_0153:
      004346 8F 82            [24] 1866 	mov	dpl,r7
      004348 8E 83            [24] 1867 	mov	dph,r6
      00434A 22               [24] 1868 	ret
                                   1869 
                                   1870 	.area CSEG (CODE)
                                   1871 ; function ak820_outline_0156
      00434B                       1872 _ak820_outline_0156:
      00434B 2E               [12] 1873 	add	a,r6
      00434C FC               [12] 1874 	mov	r4,a
      00434D E4               [12] 1875 	clr	a
      00434E 3F               [12] 1876 	addc	a,r7
      00434F FD               [12] 1877 	mov	r5,a
      004350 22               [24] 1878 	ret
                                   1879 
                                   1880 	.area CSEG (CODE)
                                   1881 ; function ak820_outline_0157
      004351                       1882 _ak820_outline_0157:
      004351 ED               [12] 1883 	mov	a,r5
      004352 F0               [24] 1884 	movx	@dptr,a
      004353 EE               [12] 1885 	mov	a,r6
      004354 A3               [24] 1886 	inc	dptr
      004355 F0               [24] 1887 	movx	@dptr,a
      004356 22               [24] 1888 	ret
                                   1889 
                                   1890 	.area CSEG (CODE)
                                   1891 ; function ak820_outline_0180
      004357                       1892 _ak820_outline_0180:
      004357 89 82            [24] 1893 	mov	dpl,r1
      004359 8A 83            [24] 1894 	mov	dph,r2
      00435B 22               [24] 1895 	ret
                                   1896 
                                   1897 	.area CSEG (CODE)
                                   1898 ; function ak820_outline_0181
      00435C                       1899 _ak820_outline_0181:
      00435C 8C 82            [24] 1900 	mov	dpl,r4
      00435E 8B 83            [24] 1901 	mov	dph,r3
      004360 22               [24] 1902 	ret
