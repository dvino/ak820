                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_gui_process
                                    269 	.globl _ak820_macro_change
                                    270 	.globl _add_owned_mods
                                    271 	.globl _del_owned_mods
                                    272 	.globl _add_owned_weak_mods
                                    273 	.globl _del_owned_weak_mods
                                    274 	.globl _clear_owned_mods
                                    275 	.globl _clear_owned_keys
                                    276 	.globl _add_owned_key
                                    277 	.globl _del_owned_key
                                    278 	.globl _clear_owned_usages
                                    279 	.globl _owned_usage_key
                                    280 	.globl _send_keyboard_report
                                    281 	.globl _get_mods
                                    282 	.globl _clear_mods
                                    283 	.globl _get_weak_mods
                                    284 	.globl _add_weak_mods
                                    285 	.globl _del_weak_mods
                                    286 	.globl _clear_weak_mods
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 	.area	OSEG    (OVR,DATA)
      000054                        553 _change_owned_sloc1_1_0:
      000054                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      00001E                        568 _gui_disabled:
      00001E                        569 	.ds 1
      00001F                        570 _ctrl_gui_swapped:
      00001F                        571 	.ds 1
      000020                        572 _ak820_gui_process_sloc0_1_0:
      000020                        573 	.ds 1
      000021                        574 _ak820_macro_change_sloc0_1_0:
      000021                        575 	.ds 1
      000022                        576 _change_owned_sloc0_1_0:
      000022                        577 	.ds 1
      000023                        578 _owned_usage_key_sloc0_1_0:
      000023                        579 	.ds 1
                                    580 ;--------------------------------------------------------
                                    581 ; paged external ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area PSEG    (PAG,XDATA)
                                    584 ;--------------------------------------------------------
                                    585 ; uninitialized external ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area XSEG    (XDATA)
      000968                        588 _ak820_gui_process_PARM_2:
      000968                        589 	.ds 1
      000969                        590 _ak820_gui_process_code_10000_294:
      000969                        591 	.ds 2
      00096B                        592 _owned_mod_refs:
      00096B                        593 	.ds 8
      000973                        594 _owned_weak_refs:
      000973                        595 	.ds 8
      00097B                        596 _owned_mods:
      00097B                        597 	.ds 1
      00097C                        598 _owned_weak_mods:
      00097C                        599 	.ds 1
      00097D                        600 _macro_mods:
      00097D                        601 	.ds 2
      00097F                        602 _ak820_macro_primitive::
      00097F                        603 	.ds 1
      000980                        604 _ak820_macro_cancelled::
      000980                        605 	.ds 1
      000981                        606 _ak820_macro_change_PARM_2:
      000981                        607 	.ds 1
      000982                        608 _ak820_macro_change_PARM_3:
      000982                        609 	.ds 1
      000983                        610 _ak820_macro_change_bits_10000_303:
      000983                        611 	.ds 2
      000985                        612 _change_owned_PARM_2:
      000985                        613 	.ds 1
      000986                        614 _change_owned_mods_10000_308:
      000986                        615 	.ds 1
      000987                        616 _change_owned_result_10001_312:
      000987                        617 	.ds 1
      000988                        618 _change_owned_bit_20001_313:
      000988                        619 	.ds 1
      000989                        620 _add_owned_mods_mods_10000_321:
      000989                        621 	.ds 1
      00098A                        622 _del_owned_mods_mods_10000_323:
      00098A                        623 	.ds 1
      00098B                        624 _add_owned_weak_mods_mods_10000_325:
      00098B                        625 	.ds 1
      00098C                        626 _del_owned_weak_mods_mods_10000_327:
      00098C                        627 	.ds 1
      00098D                        628 _key_refs:
      00098D                        629 	.ds 165
      000A32                        630 _distinct_keys:
      000A32                        631 	.ds 1
      000A33                        632 _macro_keys:
      000A33                        633 	.ds 21
      000A48                        634 _add_owned_key_code_10000_336:
      000A48                        635 	.ds 1
      000A49                        636 _del_owned_key_code_10000_351:
      000A49                        637 	.ds 1
      000A4A                        638 _usage_refs:
      000A4A                        639 	.ds 30
      000A68                        640 _usage_order:
      000A68                        641 	.ds 30
      000A86                        642 _usage_lengths:
      000A86                        643 	.ds 2
      000A88                        644 _macro_usages:
      000A88                        645 	.ds 4
      000A8C                        646 _owned_usage_key_PARM_2:
      000A8C                        647 	.ds 1
      000A8D                        648 _owned_usage_key_code_10000_378:
      000A8D                        649 	.ds 1
      000A8E                        650 _owned_usage_key___200000085_20000_379:
      000A8E                        651 	.ds 2
      000A90                        652 _owned_usage_key_which_10000_379:
      000A90                        653 	.ds 1
      000A91                        654 _owned_usage_key_count_10000_379:
      000A91                        655 	.ds 1
      000A92                        656 _owned_usage_key_pos_30001_386:
      000A92                        657 	.ds 1
      000A93                        658 _owned_usage_key_key_40000_391:
      000A93                        659 	.ds 1
      000A94                        660 _send_keyboard_report_last_report_10001_401:
      000A94                        661 	.ds 32
      000AB4                        662 _send_keyboard_report_changed_10001_401:
      000AB4                        663 	.ds 1
      000AB5                        664 _add_weak_mods_mods_10000_419:
      000AB5                        665 	.ds 1
      000AB6                        666 _del_weak_mods_mods_10000_421:
      000AB6                        667 	.ds 1
                                    668 ;--------------------------------------------------------
                                    669 ; absolute external ram data
                                    670 ;--------------------------------------------------------
                                    671 	.area XABS    (ABS,XDATA)
                                    672 ;--------------------------------------------------------
                                    673 ; initialized external ram data
                                    674 ;--------------------------------------------------------
                                    675 	.area XISEG   (XDATA)
      000D96                        676 _real_mods:
      000D96                        677 	.ds 1
      000D97                        678 _weak_mods:
      000D97                        679 	.ds 1
      000D98                        680 _actual_keyboard_report::
      000D98                        681 	.ds 32
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function ak820_gui_process
                                    724 ;	-----------------------------------------
      007AA9                        725 _ak820_gui_process:
      007AA9 12 38 49         [24]  726 	lcall	_ak820_outline_0104
      007AAC 90 09 69         [24]  727 	mov	dptr,#_ak820_gui_process_code_10000_294
      007AAF 12 38 4E         [24]  728 	lcall	_ak820_outline_0105
                                    729 ;	quantum/action_util.c:71: if (code == QK_MAGIC_SWAP_CTL_GUI || code == QK_MAGIC_UNSWAP_CTL_GUI || code == QK_MAGIC_TOGGLE_CTL_GUI) {
      007AB2 90 09 69         [24]  730 	mov	dptr,#_ak820_gui_process_code_10000_294
      007AB5 12 38 00         [24]  731 	lcall	_ak820_outline_0050
      007AB8 E4               [12]  732 	clr	a
      007AB9 BE 1B 04         [24]  733 	cjne	r6,#0x1b,00167$
      007ABC BF 70 01         [24]  734 	cjne	r7,#0x70,00167$
      007ABF 04               [12]  735 	inc	a
      007AC0                        736 00167$:
      007AC0 FD               [12]  737 	mov	r5,a
      007AC1 70 0E            [24]  738 	jnz	00103$
      007AC3 BE 1C 05         [24]  739 	cjne	r6,#0x1c,00170$
      007AC6 BF 70 02         [24]  740 	cjne	r7,#0x70,00170$
      007AC9 80 06            [24]  741 	sjmp	00103$
      007ACB                        742 00170$:
      007ACB BE 1D 27         [24]  743 	cjne	r6,#0x1d,00104$
      007ACE BF 70 24         [24]  744 	cjne	r7,#0x70,00104$
      007AD1                        745 00103$:
                                    746 ;	quantum/action_util.c:72: if (pressed) {
      007AD1 90 09 68         [24]  747 	mov	dptr,#_ak820_gui_process_PARM_2
      007AD4 E0               [24]  748 	movx	a,@dptr
      007AD5 60 1A            [24]  749 	jz	00102$
                                    750 ;	quantum/action_util.c:73: ctrl_gui_swapped = code == QK_MAGIC_TOGGLE_CTL_GUI ? !ctrl_gui_swapped : code == QK_MAGIC_SWAP_CTL_GUI;
      007AD7 BE 1D 0D         [24]  751 	cjne	r6,#0x1d,00114$
      007ADA BF 70 0A         [24]  752 	cjne	r7,#0x70,00114$
      007ADD A2 1F            [12]  753 	mov	c,_ctrl_gui_swapped
      007ADF B3               [12]  754 	cpl	c
      007AE0 92 20            [24]  755 	mov  _ak820_gui_process_sloc0_1_0,c
      007AE2 E4               [12]  756 	clr	a
      007AE3 33               [12]  757 	rlc	a
      007AE4 FC               [12]  758 	mov	r4,a
      007AE5 80 02            [24]  759 	sjmp	00115$
      007AE7                        760 00114$:
      007AE7 8D 04            [24]  761 	mov	ar4,r5
      007AE9                        762 00115$:
                                    763 ;	assignBit
      007AE9 EC               [12]  764 	mov	a,r4
      007AEA 24 FF            [12]  765 	add	a,#0xff
      007AEC 92 1F            [24]  766 	mov	_ctrl_gui_swapped,c
                                    767 ;	quantum/action_util.c:74: send_keyboard_report();
      007AEE 12 7F AD         [24]  768 	lcall	_send_keyboard_report
      007AF1                        769 00102$:
                                    770 ;	quantum/action_util.c:76: return false;
      007AF1 75 82 00         [24]  771 	mov	dpl, #0x00
      007AF4 22               [24]  772 	ret
      007AF5                        773 00104$:
                                    774 ;	quantum/action_util.c:80: if (code < QK_MAGIC_GUI_ON || code > QK_MAGIC_TOGGLE_GUI) return true;
      007AF5 C3               [12]  775 	clr	c
      007AF6 EE               [12]  776 	mov	a,r6
      007AF7 94 09            [12]  777 	subb	a,#0x09
      007AF9 EF               [12]  778 	mov	a,r7
      007AFA 94 70            [12]  779 	subb	a,#0x70
      007AFC 40 08            [24]  780 	jc	00107$
      007AFE 74 0B            [12]  781 	mov	a,#0x0b
      007B00 9E               [12]  782 	subb	a,r6
      007B01 74 70            [12]  783 	mov	a,#0x70
      007B03 9F               [12]  784 	subb	a,r7
      007B04 50 04            [24]  785 	jnc	00108$
                                    786 ;	free result
      007B06                        787 00107$:
      007B06 75 82 01         [24]  788 	mov	dpl, #0x01
      007B09 22               [24]  789 	ret
      007B0A                        790 00108$:
                                    791 ;	quantum/action_util.c:81: if (pressed) {
      007B0A 90 09 68         [24]  792 	mov	dptr,#_ak820_gui_process_PARM_2
      007B0D E0               [24]  793 	movx	a,@dptr
      007B0E 60 21            [24]  794 	jz	00111$
                                    795 ;	quantum/action_util.c:82: gui_disabled = code == QK_MAGIC_TOGGLE_GUI ? !gui_disabled : code == QK_MAGIC_GUI_OFF;
      007B10 BE 0B 0D         [24]  796 	cjne	r6,#0x0b,00116$
      007B13 BF 70 0A         [24]  797 	cjne	r7,#0x70,00116$
      007B16 A2 1E            [12]  798 	mov	c,_gui_disabled
      007B18 B3               [12]  799 	cpl	c
      007B19 92 20            [24]  800 	mov  _ak820_gui_process_sloc0_1_0,c
      007B1B E4               [12]  801 	clr	a
      007B1C 33               [12]  802 	rlc	a
      007B1D FD               [12]  803 	mov	r5,a
      007B1E 80 09            [24]  804 	sjmp	00117$
      007B20                        805 00116$:
      007B20 E4               [12]  806 	clr	a
      007B21 BE 0A 04         [24]  807 	cjne	r6,#0x0a,00181$
      007B24 BF 70 01         [24]  808 	cjne	r7,#0x70,00181$
      007B27 04               [12]  809 	inc	a
      007B28                        810 00181$:
      007B28 FD               [12]  811 	mov	r5,a
      007B29                        812 00117$:
                                    813 ;	assignBit
      007B29 ED               [12]  814 	mov	a,r5
      007B2A 24 FF            [12]  815 	add	a,#0xff
      007B2C 92 1E            [24]  816 	mov	_gui_disabled,c
                                    817 ;	quantum/action_util.c:83: send_keyboard_report();
      007B2E 12 7F AD         [24]  818 	lcall	_send_keyboard_report
      007B31                        819 00111$:
                                    820 ;	quantum/action_util.c:85: return false;
      007B31 75 82 00         [24]  821 	mov	dpl, #0x00
                                    822 ;	quantum/action_util.c:89: }
      007B34 22               [24]  823 	ret
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'ak820_macro_change'
                                    826 ;------------------------------------------------------------
                                    827 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    828 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    829 ;bits          Allocated with name '_ak820_macro_change_bits_10000_303'
                                    830 ;mask          Allocated with name '_ak820_macro_change_mask_10001_306'
                                    831 ;------------------------------------------------------------
                                    832 ;	quantum/action_util.c:98: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    833 ;	-----------------------------------------
                                    834 ;	 function ak820_macro_change
                                    835 ;	-----------------------------------------
      007B35                        836 _ak820_macro_change:
      007B35 12 38 49         [24]  837 	lcall	_ak820_outline_0104
      007B38 90 09 83         [24]  838 	mov	dptr,#_ak820_macro_change_bits_10000_303
      007B3B 12 38 4E         [24]  839 	lcall	_ak820_outline_0105
                                    840 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      007B3E 90 09 7F         [24]  841 	mov	dptr,#_ak820_macro_primitive
      007B41 E0               [24]  842 	movx	a,@dptr
      007B42 70 04            [24]  843 	jnz	00102$
      007B44 75 82 01         [24]  844 	mov	dpl, #0x01
      007B47 22               [24]  845 	ret
      007B48                        846 00102$:
                                    847 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      007B48 90 09 81         [24]  848 	mov	dptr,#_ak820_macro_change_PARM_2
      007B4B E0               [24]  849 	movx	a,@dptr
      007B4C FF               [12]  850 	mov	r7,a
      007B4D 74 07            [12]  851 	mov	a,#0x07
      007B4F 5F               [12]  852 	anl	a,r7
      007B50 12 76 4E         [24]  853 	lcall	_ak820_outline_0062
      007B53 80 02            [24]  854 	sjmp	00123$
      007B55                        855 00122$:
      007B55 25 E0            [12]  856 	add	a,acc
      007B57                        857 00123$:
      007B57 D5 F0 FB         [24]  858 	djnz	b,00122$
      007B5A FE               [12]  859 	mov	r6,a
                                    860 ;	quantum/action_util.c:101: bits += index >> 3;
      007B5B EF               [12]  861 	mov	a,r7
      007B5C 12 56 FC         [24]  862 	lcall	_ak820_outline_0168
      007B5F FF               [12]  863 	mov	r7,a
      007B60 90 09 83         [24]  864 	mov	dptr,#_ak820_macro_change_bits_10000_303
      007B63 12 38 1F         [24]  865 	lcall	_ak820_outline_0059
      007B66 90 09 83         [24]  866 	mov	dptr,#_ak820_macro_change_bits_10000_303
      007B69 EF               [12]  867 	mov	a,r7
      007B6A 2C               [12]  868 	add	a, r4
      007B6B F0               [24]  869 	movx	@dptr,a
      007B6C E4               [12]  870 	clr	a
      007B6D 3D               [12]  871 	addc	a, r5
      007B6E A3               [24]  872 	inc	dptr
      007B6F F0               [24]  873 	movx	@dptr,a
                                    874 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      007B70 90 09 83         [24]  875 	mov	dptr,#_ak820_macro_change_bits_10000_303
      007B73 E0               [24]  876 	movx	a,@dptr
      007B74 FD               [12]  877 	mov	r5,a
      007B75 A3               [24]  878 	inc	dptr
      007B76 E0               [24]  879 	movx	a,@dptr
      007B77 FF               [12]  880 	mov	r7,a
      007B78 12 80 FA         [24]  881 	lcall	_ak820_outline_0185
      007B7B E0               [24]  882 	movx	a,@dptr
      007B7C FC               [12]  883 	mov	r4,a
      007B7D EE               [12]  884 	mov	a,r6
      007B7E 5C               [12]  885 	anl	a,r4
      007B7F B4 01 00         [24]  886 	cjne	a,#0x01,00124$
      007B82                        887 00124$:
      007B82 B3               [12]  888 	cpl	c
      007B83 92 21            [24]  889 	mov	_ak820_macro_change_sloc0_1_0,c
      007B85 90 09 82         [24]  890 	mov	dptr,#_ak820_macro_change_PARM_3
      007B88 E0               [24]  891 	movx	a,@dptr
      007B89 FB               [12]  892 	mov	r3,a
      007B8A A2 21            [12]  893 	mov	c,_ak820_macro_change_sloc0_1_0
      007B8C E4               [12]  894 	clr	a
      007B8D 33               [12]  895 	rlc	a
      007B8E B5 03 04         [24]  896 	cjne	a,ar3,00104$
      007B91 75 82 00         [24]  897 	mov	dpl, #0x00
      007B94 22               [24]  898 	ret
      007B95                        899 00104$:
                                    900 ;	quantum/action_util.c:103: *bits ^= mask;
      007B95 EC               [12]  901 	mov	a,r4
      007B96 62 06            [12]  902 	xrl	ar6,a
      007B98 12 80 FA         [24]  903 	lcall	_ak820_outline_0185
      007B9B EE               [12]  904 	mov	a,r6
      007B9C F0               [24]  905 	movx	@dptr,a
                                    906 ;	quantum/action_util.c:104: return true;
      007B9D 75 82 01         [24]  907 	mov	dpl, #0x01
                                    908 ;	quantum/action_util.c:105: }
      007BA0 22               [24]  909 	ret
                                    910 ;------------------------------------------------------------
                                    911 ;Allocation info for local variables in function 'change_owned'
                                    912 ;------------------------------------------------------------
                                    913 ;mode          Allocated with name '_change_owned_PARM_2'
                                    914 ;mods          Allocated with name '_change_owned_mods_10000_308'
                                    915 ;kind          Allocated with name '_change_owned_kind_10000_309'
                                    916 ;pressed       Allocated with name '_change_owned_pressed_10000_309'
                                    917 ;refs          Allocated with name '_change_owned_refs_10000_309'
                                    918 ;old           Allocated with name '_change_owned_old_30000_311'
                                    919 ;result        Allocated with name '_change_owned_result_10001_312'
                                    920 ;i             Allocated with name '_change_owned_i_20001_313'
                                    921 ;bit           Allocated with name '_change_owned_bit_20001_313'
                                    922 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    923 ;------------------------------------------------------------
                                    924 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    925 ;	-----------------------------------------
                                    926 ;	 function change_owned
                                    927 ;	-----------------------------------------
      007BA1                        928 _change_owned:
      007BA1 E5 82            [12]  929 	mov	a,dpl
      007BA3 90 09 86         [24]  930 	mov	dptr,#_change_owned_mods_10000_308
      007BA6 F0               [24]  931 	movx	@dptr,a
                                    932 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      007BA7 90 09 85         [24]  933 	mov	dptr,#_change_owned_PARM_2
      007BAA E0               [24]  934 	movx	a,@dptr
      007BAB FF               [12]  935 	mov	r7,a
      007BAC C3               [12]  936 	clr	c
      007BAD 13               [12]  937 	rrc	a
      007BAE FE               [12]  938 	mov	r6,a
                                    939 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      007BAF 53 07 01         [24]  940 	anl	ar7,#0x01
      007BB2 EF               [12]  941 	mov	a,r7
      007BB3 B4 01 00         [24]  942 	cjne	a,#0x01,00205$
      007BB6                        943 00205$:
      007BB6 92 22            [24]  944 	mov  _change_owned_sloc0_1_0,c
      007BB8 B3               [12]  945 	cpl	c
      007BB9 E4               [12]  946 	clr	a
      007BBA 33               [12]  947 	rlc	a
      007BBB F5 54            [12]  948 	mov	_change_owned_sloc1_1_0,a
                                    949 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007BBD EE               [12]  950 	mov	a,r6
      007BBE 60 06            [24]  951 	jz	00121$
      007BC0 7D 73            [12]  952 	mov	r5,#_owned_weak_refs
      007BC2 7F 09            [12]  953 	mov	r7,#(_owned_weak_refs >> 8)
      007BC4 80 04            [24]  954 	sjmp	00122$
      007BC6                        955 00121$:
      007BC6 7D 6B            [12]  956 	mov	r5,#_owned_mod_refs
      007BC8 7F 09            [12]  957 	mov	r7,#(_owned_mod_refs >> 8)
      007BCA                        958 00122$:
                                    959 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      007BCA 90 09 7F         [24]  960 	mov	dptr,#_ak820_macro_primitive
      007BCD E0               [24]  961 	movx	a,@dptr
      007BCE 60 37            [24]  962 	jz	00102$
                                    963 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      007BD0 EE               [12]  964 	mov	a,r6
      007BD1 24 7D            [12]  965 	add	a, #_macro_mods
      007BD3 FB               [12]  966 	mov	r3,a
      007BD4 E4               [12]  967 	clr	a
      007BD5 34 09            [12]  968 	addc	a, #(_macro_mods >> 8)
      007BD7 FC               [12]  969 	mov	r4,a
      007BD8 12 48 7A         [24]  970 	lcall	_ak820_outline_0064
                                    971 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007BDB E5 54            [12]  972 	mov	a,_change_owned_sloc1_1_0
      007BDD 60 0A            [24]  973 	jz	00123$
      007BDF 90 09 86         [24]  974 	mov	dptr,#_change_owned_mods_10000_308
      007BE2 E0               [24]  975 	movx	a,@dptr
      007BE3 F9               [12]  976 	mov	r1,a
      007BE4 EA               [12]  977 	mov	a,r2
      007BE5 42 01            [12]  978 	orl	ar1,a
      007BE7 80 07            [24]  979 	sjmp	00124$
      007BE9                        980 00123$:
      007BE9 90 09 86         [24]  981 	mov	dptr,#_change_owned_mods_10000_308
      007BEC E0               [24]  982 	movx	a,@dptr
      007BED F4               [12]  983 	cpl	a
      007BEE 5A               [12]  984 	anl	a,r2
      007BEF F9               [12]  985 	mov	r1,a
      007BF0                        986 00124$:
      007BF0 12 33 FC         [24]  987 	lcall	_ak820_outline_0122
      007BF3 E9               [12]  988 	mov	a,r1
      007BF4 F0               [24]  989 	movx	@dptr,a
                                    990 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      007BF5 E5 54            [12]  991 	mov	a,_change_owned_sloc1_1_0
      007BF7 60 06            [24]  992 	jz	00125$
      007BF9 74 FF            [12]  993 	mov	a,#0xff
      007BFB 6A               [12]  994 	xrl	a,r2
      007BFC FC               [12]  995 	mov	r4,a
      007BFD 80 02            [24]  996 	sjmp	00126$
      007BFF                        997 00125$:
      007BFF 8A 04            [24]  998 	mov	ar4,r2
      007C01                        999 00126$:
      007C01 90 09 86         [24] 1000 	mov	dptr,#_change_owned_mods_10000_308
      007C04 E0               [24] 1001 	movx	a,@dptr
      007C05 5C               [12] 1002 	anl	a,r4
      007C06 F0               [24] 1003 	movx	@dptr,a
      007C07                       1004 00102$:
                                   1005 ;	quantum/action_util.c:115: uint8_t result = 0;
      007C07 90 09 87         [24] 1006 	mov	dptr,#_change_owned_result_10001_312
      007C0A E4               [12] 1007 	clr	a
      007C0B F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007C0C 90 09 88         [24] 1010 	mov	dptr,#_change_owned_bit_20001_313
      007C0F 04               [12] 1011 	inc	a
      007C10 F0               [24] 1012 	movx	@dptr,a
      007C11 90 09 86         [24] 1013 	mov	dptr,#_change_owned_mods_10000_308
      007C14 E0               [24] 1014 	movx	a,@dptr
      007C15 FC               [12] 1015 	mov	r4,a
      007C16 7B 00            [12] 1016 	mov	r3,#0x00
      007C18                       1017 00117$:
      007C18 BB 08 00         [24] 1018 	cjne	r3,#0x08,00210$
      007C1B                       1019 00210$:
      007C1B 50 3F            [24] 1020 	jnc	00112$
                                   1021 ;	quantum/action_util.c:117: if (mods & bit) {
      007C1D 90 09 88         [24] 1022 	mov	dptr,#_change_owned_bit_20001_313
      007C20 E0               [24] 1023 	movx	a,@dptr
      007C21 5C               [12] 1024 	anl	a,r4
      007C22 60 1C            [24] 1025 	jz	00109$
                                   1026 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      007C24 E5 54            [12] 1027 	mov	a,_change_owned_sloc1_1_0
      007C26 60 0C            [24] 1028 	jz	00106$
      007C28 EB               [12] 1029 	mov	a,r3
      007C29 2D               [12] 1030 	add	a, r5
      007C2A 12 37 D5         [24] 1031 	lcall	_ak820_outline_0013
      007C2D F8               [12] 1032 	mov	r0,a
      007C2E 08               [12] 1033 	inc	r0
      007C2F 12 80 AE         [24] 1034 	lcall	_ak820_outline_0063
      007C32 80 0C            [24] 1035 	sjmp	00109$
      007C34                       1036 00106$:
                                   1037 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      007C34 EB               [12] 1038 	mov	a,r3
      007C35 2D               [12] 1039 	add	a, r5
      007C36 12 37 D5         [24] 1040 	lcall	_ak820_outline_0013
      007C39 F8               [12] 1041 	mov	r0,a
      007C3A 60 04            [24] 1042 	jz	00109$
      007C3C 18               [12] 1043 	dec	r0
      007C3D 12 80 AE         [24] 1044 	lcall	_ak820_outline_0063
      007C40                       1045 00109$:
                                   1046 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      007C40 EB               [12] 1047 	mov	a,r3
      007C41 2D               [12] 1048 	add	a, r5
      007C42 12 37 D5         [24] 1049 	lcall	_ak820_outline_0013
      007C45 60 0B            [24] 1050 	jz	00118$
      007C47 90 09 88         [24] 1051 	mov	dptr,#_change_owned_bit_20001_313
      007C4A E0               [24] 1052 	movx	a,@dptr
      007C4B FA               [12] 1053 	mov	r2,a
      007C4C 90 09 87         [24] 1054 	mov	dptr,#_change_owned_result_10001_312
      007C4F E0               [24] 1055 	movx	a,@dptr
      007C50 4A               [12] 1056 	orl	a,r2
      007C51 F0               [24] 1057 	movx	@dptr,a
      007C52                       1058 00118$:
                                   1059 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007C52 0B               [12] 1060 	inc	r3
      007C53 90 09 88         [24] 1061 	mov	dptr,#_change_owned_bit_20001_313
      007C56 E0               [24] 1062 	movx	a,@dptr
      007C57 25 E0            [12] 1063 	add	a,acc
      007C59 F0               [24] 1064 	movx	@dptr,a
      007C5A 80 BC            [24] 1065 	sjmp	00117$
      007C5C                       1066 00112$:
                                   1067 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      007C5C EE               [12] 1068 	mov	a,r6
      007C5D 60 09            [24] 1069 	jz	00114$
      007C5F 90 09 87         [24] 1070 	mov	dptr,#_change_owned_result_10001_312
      007C62 E0               [24] 1071 	movx	a,@dptr
      007C63 90 09 7C         [24] 1072 	mov	dptr,#_owned_weak_mods
      007C66 F0               [24] 1073 	movx	@dptr,a
      007C67 22               [24] 1074 	ret
      007C68                       1075 00114$:
                                   1076 ;	quantum/action_util.c:124: else owned_mods = result;
      007C68 90 09 87         [24] 1077 	mov	dptr,#_change_owned_result_10001_312
      007C6B E0               [24] 1078 	movx	a,@dptr
      007C6C 90 09 7B         [24] 1079 	mov	dptr,#_owned_mods
      007C6F F0               [24] 1080 	movx	@dptr,a
                                   1081 ;	quantum/action_util.c:125: }
      007C70 22               [24] 1082 	ret
                                   1083 ;------------------------------------------------------------
                                   1084 ;Allocation info for local variables in function 'add_owned_mods'
                                   1085 ;------------------------------------------------------------
                                   1086 ;mods          Allocated with name '_add_owned_mods_mods_10000_321'
                                   1087 ;------------------------------------------------------------
                                   1088 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1089 ;	-----------------------------------------
                                   1090 ;	 function add_owned_mods
                                   1091 ;	-----------------------------------------
      007C71                       1092 _add_owned_mods:
      007C71 E5 82            [12] 1093 	mov	a,dpl
      007C73 90 09 89         [24] 1094 	mov	dptr,#_add_owned_mods_mods_10000_321
      007C76 12 80 CE         [24] 1095 	lcall	_ak820_outline_0114
      007C79 74 01            [12] 1096 	mov	a,#0x01
      007C7B F0               [24] 1097 	movx	@dptr,a
      007C7C 8F 82            [24] 1098 	mov	dpl, r7
      007C7E 02 7B A1         [24] 1099 	ljmp	_change_owned
                                   1100 ;------------------------------------------------------------
                                   1101 ;Allocation info for local variables in function 'del_owned_mods'
                                   1102 ;------------------------------------------------------------
                                   1103 ;mods          Allocated with name '_del_owned_mods_mods_10000_323'
                                   1104 ;------------------------------------------------------------
                                   1105 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1106 ;	-----------------------------------------
                                   1107 ;	 function del_owned_mods
                                   1108 ;	-----------------------------------------
      007C81                       1109 _del_owned_mods:
      007C81 E5 82            [12] 1110 	mov	a,dpl
      007C83 90 09 8A         [24] 1111 	mov	dptr,#_del_owned_mods_mods_10000_323
      007C86 12 80 CE         [24] 1112 	lcall	_ak820_outline_0114
      007C89 E4               [12] 1113 	clr	a
      007C8A F0               [24] 1114 	movx	@dptr,a
      007C8B 8F 82            [24] 1115 	mov	dpl, r7
      007C8D 02 7B A1         [24] 1116 	ljmp	_change_owned
                                   1117 ;------------------------------------------------------------
                                   1118 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1119 ;------------------------------------------------------------
                                   1120 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_325'
                                   1121 ;------------------------------------------------------------
                                   1122 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1123 ;	-----------------------------------------
                                   1124 ;	 function add_owned_weak_mods
                                   1125 ;	-----------------------------------------
      007C90                       1126 _add_owned_weak_mods:
      007C90 E5 82            [12] 1127 	mov	a,dpl
      007C92 90 09 8B         [24] 1128 	mov	dptr,#_add_owned_weak_mods_mods_10000_325
      007C95 12 80 CE         [24] 1129 	lcall	_ak820_outline_0114
      007C98 74 03            [12] 1130 	mov	a,#0x03
      007C9A F0               [24] 1131 	movx	@dptr,a
      007C9B 8F 82            [24] 1132 	mov	dpl, r7
      007C9D 02 7B A1         [24] 1133 	ljmp	_change_owned
                                   1134 ;------------------------------------------------------------
                                   1135 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1136 ;------------------------------------------------------------
                                   1137 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_327'
                                   1138 ;------------------------------------------------------------
                                   1139 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1140 ;	-----------------------------------------
                                   1141 ;	 function del_owned_weak_mods
                                   1142 ;	-----------------------------------------
      007CA0                       1143 _del_owned_weak_mods:
      007CA0 E5 82            [12] 1144 	mov	a,dpl
      007CA2 90 09 8C         [24] 1145 	mov	dptr,#_del_owned_weak_mods_mods_10000_327
      007CA5 12 80 CE         [24] 1146 	lcall	_ak820_outline_0114
      007CA8 74 02            [12] 1147 	mov	a,#0x02
      007CAA F0               [24] 1148 	movx	@dptr,a
      007CAB 8F 82            [24] 1149 	mov	dpl, r7
      007CAD 02 7B A1         [24] 1150 	ljmp	_change_owned
                                   1151 ;------------------------------------------------------------
                                   1152 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1153 ;------------------------------------------------------------
                                   1154 ;i             Allocated with name '_clear_owned_mods_i_20000_331'
                                   1155 ;------------------------------------------------------------
                                   1156 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1157 ;	-----------------------------------------
                                   1158 ;	 function clear_owned_mods
                                   1159 ;	-----------------------------------------
      007CB0                       1160 _clear_owned_mods:
                                   1161 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007CB0 7F 00            [12] 1162 	mov	r7,#0x00
      007CB2                       1163 00103$:
      007CB2 BF 08 00         [24] 1164 	cjne	r7,#0x08,00122$
      007CB5                       1165 00122$:
      007CB5 50 1A            [24] 1166 	jnc	00101$
      007CB7 EF               [12] 1167 	mov	a,r7
      007CB8 24 6B            [12] 1168 	add	a, #_owned_mod_refs
      007CBA FD               [12] 1169 	mov	r5,a
      007CBB E4               [12] 1170 	clr	a
      007CBC 34 09            [12] 1171 	addc	a, #(_owned_mod_refs >> 8)
      007CBE FE               [12] 1172 	mov	r6,a
      007CBF EF               [12] 1173 	mov	a,r7
      007CC0 24 73            [12] 1174 	add	a, #_owned_weak_refs
      007CC2 F5 82            [12] 1175 	mov	dpl,a
      007CC4 E4               [12] 1176 	clr	a
      007CC5 34 09            [12] 1177 	addc	a, #(_owned_weak_refs >> 8)
      007CC7 F5 83            [12] 1178 	mov	dph,a
      007CC9 E4               [12] 1179 	clr	a
      007CCA F0               [24] 1180 	movx	@dptr,a
      007CCB 12 80 D5         [24] 1181 	lcall	_ak820_outline_0119
      007CCE 0F               [12] 1182 	inc	r7
      007CCF 80 E1            [24] 1183 	sjmp	00103$
      007CD1                       1184 00101$:
                                   1185 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007CD1 90 09 7E         [24] 1186 	mov	dptr,#(_macro_mods + 0x0001)
      007CD4 E4               [12] 1187 	clr	a
      007CD5 F0               [24] 1188 	movx	@dptr,a
      007CD6 90 09 7D         [24] 1189 	mov	dptr,#_macro_mods
      007CD9 F0               [24] 1190 	movx	@dptr,a
      007CDA 90 09 7C         [24] 1191 	mov	dptr,#_owned_weak_mods
      007CDD F0               [24] 1192 	movx	@dptr,a
      007CDE 90 09 7B         [24] 1193 	mov	dptr,#_owned_mods
      007CE1 F0               [24] 1194 	movx	@dptr,a
                                   1195 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      007CE2 90 09 80         [24] 1196 	mov	dptr,#_ak820_macro_cancelled
      007CE5 04               [12] 1197 	inc	a
      007CE6 F0               [24] 1198 	movx	@dptr,a
                                   1199 ;	quantum/action_util.c:134: }
      007CE7 22               [24] 1200 	ret
                                   1201 ;------------------------------------------------------------
                                   1202 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1203 ;------------------------------------------------------------
                                   1204 ;i             Allocated with name '_clear_owned_keys_i_20000_334'
                                   1205 ;i             Allocated with name '_clear_owned_keys_i_20000_335'
                                   1206 ;------------------------------------------------------------
                                   1207 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1208 ;	-----------------------------------------
                                   1209 ;	 function clear_owned_keys
                                   1210 ;	-----------------------------------------
      007CE8                       1211 _clear_owned_keys:
                                   1212 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007CE8 7F 00            [12] 1213 	mov	r7,#0x00
      007CEA                       1214 00104$:
      007CEA EF               [12] 1215 	mov	a,r7
      007CEB 24 5B            [12] 1216 	add	a,#0xff - 0xa4
      007CED 40 0D            [24] 1217 	jc	00101$
                                   1218 ;	free result
      007CEF EF               [12] 1219 	mov	a,r7
      007CF0 24 8D            [12] 1220 	add	a, #_key_refs
      007CF2 F5 82            [12] 1221 	mov	dpl,a
      007CF4 E4               [12] 1222 	clr	a
      007CF5 34 09            [12] 1223 	addc	a, #(_key_refs >> 8)
      007CF7 12 7A 9A         [24] 1224 	lcall	_ak820_outline_0158
      007CFA 80 EE            [24] 1225 	sjmp	00104$
      007CFC                       1226 00101$:
                                   1227 ;	quantum/action_util.c:142: distinct_keys = 0;
      007CFC 90 0A 32         [24] 1228 	mov	dptr,#_distinct_keys
      007CFF E4               [12] 1229 	clr	a
      007D00 F0               [24] 1230 	movx	@dptr,a
                                   1231 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007D01 FF               [12] 1232 	mov	r7,a
      007D02                       1233 00107$:
      007D02 BF 15 00         [24] 1234 	cjne	r7,#0x15,00142$
      007D05                       1235 00142$:
      007D05 50 0D            [24] 1236 	jnc	00109$
      007D07 EF               [12] 1237 	mov	a,r7
      007D08 24 33            [12] 1238 	add	a, #_macro_keys
      007D0A F5 82            [12] 1239 	mov	dpl,a
      007D0C E4               [12] 1240 	clr	a
      007D0D 34 0A            [12] 1241 	addc	a, #(_macro_keys >> 8)
      007D0F 12 7A 9A         [24] 1242 	lcall	_ak820_outline_0158
      007D12 80 EE            [24] 1243 	sjmp	00107$
      007D14                       1244 00109$:
                                   1245 ;	quantum/action_util.c:144: }
      007D14 22               [24] 1246 	ret
                                   1247 ;------------------------------------------------------------
                                   1248 ;Allocation info for local variables in function 'add_owned_key'
                                   1249 ;------------------------------------------------------------
                                   1250 ;code          Allocated with name '_add_owned_key_code_10000_336'
                                   1251 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_345'
                                   1252 ;key           Allocated with name '_add_owned_key_key_50000_346'
                                   1253 ;i             Allocated with name '_add_owned_key_i_40000_344'
                                   1254 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_348'
                                   1255 ;key           Allocated with name '_add_owned_key_key_40000_349'
                                   1256 ;------------------------------------------------------------
                                   1257 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1258 ;	-----------------------------------------
                                   1259 ;	 function add_owned_key
                                   1260 ;	-----------------------------------------
      007D15                       1261 _add_owned_key:
      007D15 E5 82            [12] 1262 	mov	a,dpl
      007D17 90 0A 48         [24] 1263 	mov	dptr,#_add_owned_key_code_10000_336
      007D1A 12 80 E6         [24] 1264 	lcall	_ak820_outline_0130
                                   1265 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007D1D 74 01            [12] 1266 	mov	a,#0x01
      007D1F F0               [24] 1267 	movx	@dptr,a
      007D20 90 0A 33         [24] 1268 	mov	dptr,#_macro_keys
      007D23 C0 07            [24] 1269 	push	ar7
      007D25 12 7B 35         [24] 1270 	lcall	_ak820_macro_change
      007D28 E5 82            [12] 1271 	mov	a, dpl
      007D2A D0 07            [24] 1272 	pop	ar7
      007D2C 70 03            [24] 1273 	jnz	00102$
      007D2E F5 82            [12] 1274 	mov	dpl,a
      007D30 22               [24] 1275 	ret
      007D31                       1276 00102$:
                                   1277 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      007D31 12 80 A0         [24] 1278 	lcall	_ak820_outline_0028
      007D34 FC               [12] 1279 	mov	r4,a
      007D35 04               [12] 1280 	inc	a
      007D36 12 80 D5         [24] 1281 	lcall	_ak820_outline_0119
      007D39 EC               [12] 1282 	mov	a,r4
      007D3A 60 04            [24] 1283 	jz	00104$
      007D3C 75 82 00         [24] 1284 	mov	dpl, #0x00
      007D3F 22               [24] 1285 	ret
      007D40                       1286 00104$:
                                   1287 ;	quantum/action_util.c:148: ++distinct_keys;
      007D40 90 0A 32         [24] 1288 	mov	dptr,#_distinct_keys
      007D43 E0               [24] 1289 	movx	a,@dptr
      007D44 24 01            [12] 1290 	add	a, #0x01
      007D46 F0               [24] 1291 	movx	@dptr,a
                                   1292 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007D47 90 0D 85         [24] 1293 	mov	dptr,#_keyboard_protocol
      007D4A E0               [24] 1294 	movx	a,@dptr
      007D4B 60 11            [24] 1295 	jz	00106$
      007D4D 90 0A B7         [24] 1296 	mov	dptr,#_keymap_config
      007D50 E0               [24] 1297 	movx	a,@dptr
      007D51 30 E7 0A         [24] 1298 	jnb	acc.7,00106$
                                   1299 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007D54 12 80 F1         [24] 1300 	lcall	_ak820_outline_0172
      007D57 12 6E 7A         [24] 1301 	lcall	_add_key_to_report
                                   1302 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007D5A 75 82 01         [24] 1303 	mov	dpl, #0x01
      007D5D 22               [24] 1304 	ret
      007D5E                       1305 00106$:
                                   1306 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007D5E 90 0A 32         [24] 1307 	mov	dptr,#_distinct_keys
      007D61 E0               [24] 1308 	movx	a,@dptr
      007D62 24 F9            [12] 1309 	add	a,#0xff - 0x06
      007D64 50 17            [24] 1310 	jnc	00110$
                                   1311 ;	free result
                                   1312 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007D66 7F 00            [12] 1313 	mov	r7,#0x00
      007D68                       1314 00115$:
      007D68 BF 06 00         [24] 1315 	cjne	r7,#0x06,00174$
      007D6B                       1316 00174$:
      007D6B 50 1E            [24] 1317 	jnc	00111$
      007D6D EF               [12] 1318 	mov	a,r7
      007D6E 24 9A            [12] 1319 	add	a, #(_actual_keyboard_report + 0x0002)
      007D70 F5 82            [12] 1320 	mov	dpl,a
      007D72 E4               [12] 1321 	clr	a
      007D73 34 0D            [12] 1322 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007D75 F5 83            [12] 1323 	mov	dph,a
      007D77 74 01            [12] 1324 	mov	a,#0x01
      007D79 F0               [24] 1325 	movx	@dptr,a
      007D7A 0F               [12] 1326 	inc	r7
      007D7B 80 EB            [24] 1327 	sjmp	00115$
      007D7D                       1328 00110$:
                                   1329 ;	quantum/action_util.c:154: } else add_key(code);
      007D7D 90 0A 48         [24] 1330 	mov	dptr,#_add_owned_key_code_10000_336
      007D80 E0               [24] 1331 	movx	a,@dptr
                                   1332 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007D81 90 07 FB         [24] 1333 	mov	dptr,#_add_key_to_report_PARM_2
      007D84 F0               [24] 1334 	movx	@dptr,a
      007D85 90 0D 98         [24] 1335 	mov	dptr,#_actual_keyboard_report
      007D88 12 6E 7A         [24] 1336 	lcall	_add_key_to_report
                                   1337 ;	quantum/action_util.c:154: } else add_key(code);
      007D8B                       1338 00111$:
                                   1339 ;	quantum/action_util.c:155: return true;
      007D8B 75 82 01         [24] 1340 	mov	dpl, #0x01
                                   1341 ;	quantum/action_util.c:156: }
      007D8E 22               [24] 1342 	ret
                                   1343 ;------------------------------------------------------------
                                   1344 ;Allocation info for local variables in function 'del_owned_key'
                                   1345 ;------------------------------------------------------------
                                   1346 ;code          Allocated with name '_del_owned_key_code_10000_351'
                                   1347 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_362'
                                   1348 ;key           Allocated with name '_del_owned_key_key_50000_363'
                                   1349 ;key           Allocated with name '_del_owned_key_key_40000_360'
                                   1350 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_368'
                                   1351 ;key           Allocated with name '_del_owned_key_key_70000_369'
                                   1352 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_371'
                                   1353 ;key           Allocated with name '_del_owned_key_key_40000_372'
                                   1354 ;------------------------------------------------------------
                                   1355 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1356 ;	-----------------------------------------
                                   1357 ;	 function del_owned_key
                                   1358 ;	-----------------------------------------
      007D8F                       1359 _del_owned_key:
      007D8F E5 82            [12] 1360 	mov	a,dpl
      007D91 90 0A 49         [24] 1361 	mov	dptr,#_del_owned_key_code_10000_351
      007D94 12 80 E6         [24] 1362 	lcall	_ak820_outline_0130
                                   1363 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007D97 E4               [12] 1364 	clr	a
      007D98 F0               [24] 1365 	movx	@dptr,a
      007D99 90 0A 33         [24] 1366 	mov	dptr,#_macro_keys
      007D9C C0 07            [24] 1367 	push	ar7
      007D9E 12 7B 35         [24] 1368 	lcall	_ak820_macro_change
      007DA1 E5 82            [12] 1369 	mov	a, dpl
      007DA3 D0 07            [24] 1370 	pop	ar7
      007DA5 70 03            [24] 1371 	jnz	00102$
      007DA7 F5 82            [12] 1372 	mov	dpl,a
      007DA9 22               [24] 1373 	ret
      007DAA                       1374 00102$:
                                   1375 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      007DAA 12 80 A0         [24] 1376 	lcall	_ak820_outline_0028
      007DAD FC               [12] 1377 	mov	r4,a
      007DAE 60 09            [24] 1378 	jz	00103$
      007DB0 1C               [12] 1379 	dec	r4
      007DB1 12 38 6A         [24] 1380 	lcall	_ak820_outline_0131
      007DB4 EC               [12] 1381 	mov	a,r4
      007DB5 F0               [24] 1382 	movx	@dptr,a
      007DB6 EC               [12] 1383 	mov	a,r4
      007DB7 60 04            [24] 1384 	jz	00104$
      007DB9                       1385 00103$:
      007DB9 75 82 00         [24] 1386 	mov	dpl, #0x00
      007DBC 22               [24] 1387 	ret
      007DBD                       1388 00104$:
                                   1389 ;	quantum/action_util.c:160: --distinct_keys;
      007DBD 90 0A 32         [24] 1390 	mov	dptr,#_distinct_keys
      007DC0 E0               [24] 1391 	movx	a,@dptr
      007DC1 14               [12] 1392 	dec	a
      007DC2 F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007DC3 90 0D 85         [24] 1395 	mov	dptr,#_keyboard_protocol
      007DC6 E0               [24] 1396 	movx	a,@dptr
      007DC7 60 16            [24] 1397 	jz	00107$
      007DC9 90 0A B7         [24] 1398 	mov	dptr,#_keymap_config
      007DCC E0               [24] 1399 	movx	a,@dptr
      007DCD 30 E7 0F         [24] 1400 	jnb	acc.7,00107$
                                   1401 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007DD0 90 07 FE         [24] 1402 	mov	dptr,#_del_key_from_report_PARM_2
      007DD3 EF               [12] 1403 	mov	a,r7
      007DD4 F0               [24] 1404 	movx	@dptr,a
      007DD5 90 0D 98         [24] 1405 	mov	dptr,#_actual_keyboard_report
      007DD8 12 6E B0         [24] 1406 	lcall	_del_key_from_report
                                   1407 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007DDB 75 82 01         [24] 1408 	mov	dpl, #0x01
      007DDE 22               [24] 1409 	ret
      007DDF                       1410 00107$:
                                   1411 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007DDF 90 0A 32         [24] 1412 	mov	dptr,#_distinct_keys
      007DE2 E0               [24] 1413 	movx	a,@dptr
      007DE3 FF               [12] 1414 	mov  r7,a
      007DE4 24 F9            [12] 1415 	add	a,#0xff - 0x06
      007DE6 50 04            [24] 1416 	jnc	00110$
                                   1417 ;	free result
      007DE8 75 82 01         [24] 1418 	mov	dpl, #0x01
      007DEB 22               [24] 1419 	ret
      007DEC                       1420 00110$:
                                   1421 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007DEC BF 06 1F         [24] 1422 	cjne	r7,#0x06,00115$
                                   1423 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007DEF 90 0D 98         [24] 1424 	mov	dptr,#_actual_keyboard_report
      007DF2 12 6E E6         [24] 1425 	lcall	_clear_keys_from_report
                                   1426 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007DF5 7F 04            [12] 1427 	mov	r7,#0x04
      007DF7                       1428 00122$:
      007DF7 EF               [12] 1429 	mov	a,r7
      007DF8 24 5B            [12] 1430 	add	a,#0xff - 0xa4
      007DFA 40 20            [24] 1431 	jc	00116$
                                   1432 ;	free result
      007DFC 12 80 A0         [24] 1433 	lcall	_ak820_outline_0028
      007DFF 60 0A            [24] 1434 	jz	00123$
                                   1435 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007E01 12 80 F1         [24] 1436 	lcall	_ak820_outline_0172
      007E04 C0 07            [24] 1437 	push	ar7
      007E06 12 6E 7A         [24] 1438 	lcall	_add_key_to_report
      007E09 D0 07            [24] 1439 	pop	ar7
                                   1440 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007E0B                       1441 00123$:
      007E0B 0F               [12] 1442 	inc	r7
      007E0C 80 E9            [24] 1443 	sjmp	00122$
      007E0E                       1444 00115$:
                                   1445 ;	quantum/action_util.c:169: } else del_key(code);
      007E0E 90 0A 49         [24] 1446 	mov	dptr,#_del_owned_key_code_10000_351
      007E11 E0               [24] 1447 	movx	a,@dptr
                                   1448 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007E12 90 07 FE         [24] 1449 	mov	dptr,#_del_key_from_report_PARM_2
      007E15 F0               [24] 1450 	movx	@dptr,a
      007E16 90 0D 98         [24] 1451 	mov	dptr,#_actual_keyboard_report
      007E19 12 6E B0         [24] 1452 	lcall	_del_key_from_report
                                   1453 ;	quantum/action_util.c:169: } else del_key(code);
      007E1C                       1454 00116$:
                                   1455 ;	quantum/action_util.c:170: return true;
      007E1C 75 82 01         [24] 1456 	mov	dpl, #0x01
                                   1457 ;	quantum/action_util.c:171: }
      007E1F 22               [24] 1458 	ret
                                   1459 ;------------------------------------------------------------
                                   1460 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1461 ;------------------------------------------------------------
                                   1462 ;i             Allocated with name '_clear_owned_usages_i_20000_376'
                                   1463 ;i             Allocated with name '_clear_owned_usages_i_20000_377'
                                   1464 ;------------------------------------------------------------
                                   1465 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1466 ;	-----------------------------------------
                                   1467 ;	 function clear_owned_usages
                                   1468 ;	-----------------------------------------
      007E20                       1469 _clear_owned_usages:
                                   1470 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007E20 7F 00            [12] 1471 	mov	r7,#0x00
      007E22                       1472 00104$:
      007E22 BF 1E 00         [24] 1473 	cjne	r7,#0x1e,00141$
      007E25                       1474 00141$:
      007E25 50 14            [24] 1475 	jnc	00101$
      007E27 EF               [12] 1476 	mov	a,r7
      007E28 24 4A            [12] 1477 	add	a, #_usage_refs
      007E2A FD               [12] 1478 	mov	r5,a
      007E2B E4               [12] 1479 	clr	a
      007E2C 34 0A            [12] 1480 	addc	a, #(_usage_refs >> 8)
      007E2E FE               [12] 1481 	mov	r6,a
      007E2F EF               [12] 1482 	mov	a,r7
      007E30 12 80 B5         [24] 1483 	lcall	_ak820_outline_0067
      007E33 E4               [12] 1484 	clr	a
      007E34 F0               [24] 1485 	movx	@dptr,a
      007E35 12 80 D5         [24] 1486 	lcall	_ak820_outline_0119
      007E38 0F               [12] 1487 	inc	r7
      007E39 80 E7            [24] 1488 	sjmp	00104$
      007E3B                       1489 00101$:
                                   1490 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      007E3B 90 0A 87         [24] 1491 	mov	dptr,#(_usage_lengths + 0x0001)
      007E3E E4               [12] 1492 	clr	a
      007E3F F0               [24] 1493 	movx	@dptr,a
      007E40 90 0A 86         [24] 1494 	mov	dptr,#_usage_lengths
      007E43 F0               [24] 1495 	movx	@dptr,a
                                   1496 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007E44 FF               [12] 1497 	mov	r7,a
      007E45                       1498 00107$:
      007E45 BF 04 00         [24] 1499 	cjne	r7,#0x04,00143$
      007E48                       1500 00143$:
      007E48 50 0D            [24] 1501 	jnc	00109$
      007E4A EF               [12] 1502 	mov	a,r7
      007E4B 24 88            [12] 1503 	add	a, #_macro_usages
      007E4D F5 82            [12] 1504 	mov	dpl,a
      007E4F E4               [12] 1505 	clr	a
      007E50 34 0A            [12] 1506 	addc	a, #(_macro_usages >> 8)
      007E52 12 7A 9A         [24] 1507 	lcall	_ak820_outline_0158
      007E55 80 EE            [24] 1508 	sjmp	00107$
      007E57                       1509 00109$:
                                   1510 ;	quantum/action_util.c:185: }
      007E57 22               [24] 1511 	ret
                                   1512 ;------------------------------------------------------------
                                   1513 ;Allocation info for local variables in function 'owned_usage_key'
                                   1514 ;------------------------------------------------------------
                                   1515 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1516 ;code          Allocated with name '_owned_usage_key_code_10000_378'
                                   1517 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_379'
                                   1518 ;which         Allocated with name '_owned_usage_key_which_10000_379'
                                   1519 ;base          Allocated with name '_owned_usage_key_base_10000_379'
                                   1520 ;count         Allocated with name '_owned_usage_key_count_10000_379'
                                   1521 ;index         Allocated with name '_owned_usage_key_index_10000_379'
                                   1522 ;pos           Allocated with name '_owned_usage_key_pos_30001_386'
                                   1523 ;i             Allocated with name '_owned_usage_key_i_40001_387'
                                   1524 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_390'
                                   1525 ;key           Allocated with name '_owned_usage_key_key_40000_391'
                                   1526 ;------------------------------------------------------------
                                   1527 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1528 ;	-----------------------------------------
                                   1529 ;	 function owned_usage_key
                                   1530 ;	-----------------------------------------
      007E58                       1531 _owned_usage_key:
      007E58 E5 82            [12] 1532 	mov	a,dpl
      007E5A 90 0A 8D         [24] 1533 	mov	dptr,#_owned_usage_key_code_10000_378
      007E5D F0               [24] 1534 	movx	@dptr,a
                                   1535 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      007E5E E0               [24] 1536 	movx	a,@dptr
      007E5F FF               [12] 1537 	mov	r7,a
      007E60 BF A8 00         [24] 1538 	cjne	r7,#0xa8,00244$
      007E63                       1539 00244$:
      007E63 B3               [12] 1540 	cpl	c
      007E64 92 23            [24] 1541 	mov	_owned_usage_key_sloc0_1_0,c
      007E66 E4               [12] 1542 	clr	a
      007E67 33               [12] 1543 	rlc	a
      007E68 FF               [12] 1544 	mov	r7,a
      007E69 90 0A 90         [24] 1545 	mov	dptr,#_owned_usage_key_which_10000_379
      007E6C F0               [24] 1546 	movx	@dptr,a
                                   1547 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      007E6D EF               [12] 1548 	mov	a,r7
      007E6E 60 02            [24] 1549 	jz	00129$
      007E70 74 03            [12] 1550 	mov	a,#0x03
      007E72                       1551 00129$:
      007E72 FE               [12] 1552 	mov	r6,a
                                   1553 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      007E73 EF               [12] 1554 	mov	a,r7
      007E74 24 86            [12] 1555 	add	a, #_usage_lengths
      007E76 FD               [12] 1556 	mov	r5,a
      007E77 E4               [12] 1557 	clr	a
      007E78 34 0A            [12] 1558 	addc	a, #(_usage_lengths >> 8)
      007E7A FF               [12] 1559 	mov	r7,a
      007E7B 12 80 FA         [24] 1560 	lcall	_ak820_outline_0185
      007E7E E0               [24] 1561 	movx	a,@dptr
      007E7F FC               [12] 1562 	mov	r4,a
                                   1563 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      007E80 90 0A 8D         [24] 1564 	mov	dptr,#_owned_usage_key_code_10000_378
      007E83 E0               [24] 1565 	movx	a,@dptr
      007E84 24 5B            [12] 1566 	add	a,#0x5b
      007E86 FB               [12] 1567 	mov	r3,a
                                   1568 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007E87 90 0A 8C         [24] 1569 	mov	dptr,#_owned_usage_key_PARM_2
      007E8A E0               [24] 1570 	movx	a,@dptr
      007E8B FA               [12] 1571 	mov	r2,a
      007E8C 90 09 81         [24] 1572 	mov	dptr,#_ak820_macro_change_PARM_2
      007E8F EB               [12] 1573 	mov	a,r3
      007E90 F0               [24] 1574 	movx	@dptr,a
      007E91 90 09 82         [24] 1575 	mov	dptr,#_ak820_macro_change_PARM_3
      007E94 EA               [12] 1576 	mov	a,r2
      007E95 F0               [24] 1577 	movx	@dptr,a
      007E96 90 0A 88         [24] 1578 	mov	dptr,#_macro_usages
      007E99 C0 07            [24] 1579 	push	ar7
      007E9B C0 06            [24] 1580 	push	ar6
      007E9D C0 05            [24] 1581 	push	ar5
      007E9F C0 04            [24] 1582 	push	ar4
      007EA1 C0 03            [24] 1583 	push	ar3
      007EA3 C0 02            [24] 1584 	push	ar2
      007EA5 12 7B 35         [24] 1585 	lcall	_ak820_macro_change
      007EA8 E5 82            [12] 1586 	mov	a, dpl
      007EAA D0 02            [24] 1587 	pop	ar2
      007EAC D0 03            [24] 1588 	pop	ar3
      007EAE D0 04            [24] 1589 	pop	ar4
      007EB0 D0 05            [24] 1590 	pop	ar5
      007EB2 D0 06            [24] 1591 	pop	ar6
      007EB4 D0 07            [24] 1592 	pop	ar7
      007EB6 70 01            [24] 1593 	jnz	00102$
      007EB8 22               [24] 1594 	ret
      007EB9                       1595 00102$:
                                   1596 ;	quantum/action_util.c:192: if (pressed) {
      007EB9 EA               [12] 1597 	mov	a,r2
      007EBA 60 1B            [24] 1598 	jz	00115$
                                   1599 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      007EBC 12 80 BF         [24] 1600 	lcall	_ak820_outline_0073
      007EBF 04               [12] 1601 	inc	a
      007EC0 12 6B FD         [24] 1602 	lcall	_ak820_outline_0136
      007EC3 E8               [12] 1603 	mov	a,r0
      007EC4 60 01            [24] 1604 	jz	00104$
      007EC6 22               [24] 1605 	ret
      007EC7                       1606 00104$:
                                   1607 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      007EC7 90 0A 91         [24] 1608 	mov	dptr,#_owned_usage_key_count_10000_379
      007ECA EC               [12] 1609 	mov	a,r4
      007ECB 04               [12] 1610 	inc	a
      007ECC F0               [24] 1611 	movx	@dptr,a
      007ECD EC               [12] 1612 	mov	a,r4
      007ECE 2E               [12] 1613 	add	a, r6
      007ECF 12 80 B5         [24] 1614 	lcall	_ak820_outline_0067
      007ED2 EB               [12] 1615 	mov	a,r3
      007ED3 F0               [24] 1616 	movx	@dptr,a
      007ED4 02 7F 38         [24] 1617 	ljmp	00116$
      007ED7                       1618 00115$:
                                   1619 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      007ED7 12 80 BF         [24] 1620 	lcall	_ak820_outline_0073
      007EDA 60 07            [24] 1621 	jz	00105$
      007EDC 18               [12] 1622 	dec	r0
      007EDD 12 80 AE         [24] 1623 	lcall	_ak820_outline_0063
      007EE0 E8               [12] 1624 	mov	a,r0
      007EE1 60 01            [24] 1625 	jz	00106$
      007EE3                       1626 00105$:
      007EE3 22               [24] 1627 	ret
      007EE4                       1628 00106$:
                                   1629 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      007EE4 7A 00            [12] 1630 	mov	r2,#0x00
      007EE6                       1631 00108$:
      007EE6 EA               [12] 1632 	mov	a,r2
      007EE7 2E               [12] 1633 	add	a, r6
      007EE8 12 80 B5         [24] 1634 	lcall	_ak820_outline_0067
      007EEB E0               [24] 1635 	movx	a,@dptr
      007EEC B5 03 02         [24] 1636 	cjne	a,ar3,00251$
      007EEF 80 03            [24] 1637 	sjmp	00167$
      007EF1                       1638 00251$:
      007EF1 0A               [12] 1639 	inc	r2
      007EF2 80 F2            [24] 1640 	sjmp	00108$
      007EF4                       1641 00167$:
      007EF4 90 0A 92         [24] 1642 	mov	dptr,#_owned_usage_key_pos_30001_386
      007EF7 EA               [12] 1643 	mov	a,r2
      007EF8 F0               [24] 1644 	movx	@dptr,a
                                   1645 ;	quantum/action_util.c:199: --count;
      007EF9 1C               [12] 1646 	dec	r4
      007EFA 90 0A 91         [24] 1647 	mov	dptr,#_owned_usage_key_count_10000_379
      007EFD EC               [12] 1648 	mov	a,r4
      007EFE F0               [24] 1649 	movx	@dptr,a
                                   1650 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007EFF 8A 03            [24] 1651 	mov	ar3,r2
      007F01                       1652 00125$:
      007F01 C3               [12] 1653 	clr	c
      007F02 EB               [12] 1654 	mov	a,r3
      007F03 9C               [12] 1655 	subb	a,r4
      007F04 50 23            [24] 1656 	jnc	00111$
      007F06 C0 05            [24] 1657 	push	ar5
      007F08 C0 07            [24] 1658 	push	ar7
      007F0A EB               [12] 1659 	mov	a,r3
      007F0B 2E               [12] 1660 	add	a, r6
      007F0C FA               [12] 1661 	mov	r2,a
      007F0D 24 68            [12] 1662 	add	a, #_usage_order
      007F0F F8               [12] 1663 	mov	r0,a
      007F10 E4               [12] 1664 	clr	a
      007F11 34 0A            [12] 1665 	addc	a, #(_usage_order >> 8)
      007F13 F9               [12] 1666 	mov	r1,a
      007F14 0A               [12] 1667 	inc	r2
      007F15 EA               [12] 1668 	mov	a,r2
      007F16 33               [12] 1669 	rlc	a
      007F17 95 E0            [12] 1670 	subb	a,acc
      007F19 FF               [12] 1671 	mov	r7,a
      007F1A EA               [12] 1672 	mov	a,r2
      007F1B 12 80 DB         [24] 1673 	lcall	_ak820_outline_0124
      007F1E 12 38 75         [24] 1674 	lcall	_ak820_outline_0152
      007F21 F0               [24] 1675 	movx	@dptr,a
      007F22 0B               [12] 1676 	inc	r3
      007F23 D0 07            [24] 1677 	pop	ar7
      007F25 D0 05            [24] 1678 	pop	ar5
      007F27 80 D8            [24] 1679 	sjmp	00125$
      007F29                       1680 00111$:
                                   1681 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      007F29 12 80 FA         [24] 1682 	lcall	_ak820_outline_0185
      007F2C EC               [12] 1683 	mov	a,r4
      007F2D F0               [24] 1684 	movx	@dptr,a
                                   1685 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      007F2E 90 0A 92         [24] 1686 	mov	dptr,#_owned_usage_key_pos_30001_386
      007F31 E0               [24] 1687 	movx	a,@dptr
      007F32 B5 04 02         [24] 1688 	cjne	a,ar4,00253$
      007F35 80 01            [24] 1689 	sjmp	00116$
      007F37                       1690 00253$:
      007F37 22               [24] 1691 	ret
      007F38                       1692 00116$:
                                   1693 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      007F38 90 0A 91         [24] 1694 	mov	dptr,#_owned_usage_key_count_10000_379
      007F3B E0               [24] 1695 	movx	a,@dptr
      007F3C FC               [12] 1696 	mov	r4,a
      007F3D 12 80 FA         [24] 1697 	lcall	_ak820_outline_0185
      007F40 F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007F41 EC               [12] 1700 	mov	a,r4
      007F42 60 15            [24] 1701 	jz	00131$
      007F44 EC               [12] 1702 	mov	a,r4
      007F45 2E               [12] 1703 	add	a, r6
      007F46 FE               [12] 1704 	mov	r6,a
      007F47 1E               [12] 1705 	dec	r6
      007F48 EE               [12] 1706 	mov	a,r6
      007F49 33               [12] 1707 	rlc	a
      007F4A 95 E0            [12] 1708 	subb	a,acc
      007F4C FF               [12] 1709 	mov	r7,a
      007F4D EE               [12] 1710 	mov	a,r6
      007F4E 12 80 DB         [24] 1711 	lcall	_ak820_outline_0124
      007F51 24 A5            [12] 1712 	add	a,#0xa5
      007F53 FE               [12] 1713 	mov	r6,a
      007F54 33               [12] 1714 	rlc	a
      007F55 95 E0            [12] 1715 	subb	a,acc
      007F57 80 02            [24] 1716 	sjmp	00132$
      007F59                       1717 00131$:
      007F59 7E 00            [12] 1718 	mov	r6,#0x00
      007F5B                       1719 00132$:
      007F5B 90 0A 8D         [24] 1720 	mov	dptr,#_owned_usage_key_code_10000_378
      007F5E EE               [12] 1721 	mov	a,r6
      007F5F F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007F60 90 0A 90         [24] 1724 	mov	dptr,#_owned_usage_key_which_10000_379
      007F63 E0               [24] 1725 	movx	a,@dptr
      007F64 60 18            [24] 1726 	jz	00118$
      007F66 EE               [12] 1727 	mov	a,r6
      007F67 60 0B            [24] 1728 	jz	00133$
      007F69 8E 82            [24] 1729 	mov	dpl, r6
      007F6B 12 6D 36         [24] 1730 	lcall	_KEYCODE2CONSUMER
      007F6E AD 82            [24] 1731 	mov	r5, dpl
      007F70 AF 83            [24] 1732 	mov	r7, dph
      007F72 80 04            [24] 1733 	sjmp	00134$
      007F74                       1734 00133$:
      007F74 7D 00            [12] 1735 	mov	r5,#0x00
      007F76 7F 00            [12] 1736 	mov	r7,#0x00
      007F78                       1737 00134$:
      007F78 12 80 FA         [24] 1738 	lcall	_ak820_outline_0185
      007F7B 02 6C F0         [24] 1739 	ljmp	_host_consumer_send
      007F7E                       1740 00118$:
                                   1741 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007F7E EE               [12] 1742 	mov	a,r6
      007F7F 60 22            [24] 1743 	jz	00135$
                                   1744 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007F81 BE A5 00         [24] 1745 	cjne	r6,#0xa5,00258$
      007F84                       1746 00258$:
      007F84 40 05            [24] 1747 	jc	00121$
      007F86 EE               [12] 1748 	mov	a,r6
      007F87 24 58            [12] 1749 	add	a,#0xff - 0xa7
      007F89 50 08            [24] 1750 	jnc	00122$
                                   1751 ;	free result
      007F8B                       1752 00121$:
      007F8B 90 0A 8E         [24] 1753 	mov	dptr,#_owned_usage_key___200000085_20000_379
      007F8E 12 4F 19         [24] 1754 	lcall	_ak820_outline_0179
      007F91 80 09            [24] 1755 	sjmp	00123$
      007F93                       1756 00122$:
                                   1757 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007F93 74 DC            [12] 1758 	mov	a,#0xdc
      007F95 2E               [12] 1759 	add	a, r6
      007F96 90 0A 8E         [24] 1760 	mov	dptr,#_owned_usage_key___200000085_20000_379
      007F99 12 38 65         [24] 1761 	lcall	_ak820_outline_0123
                                   1762 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007F9C                       1763 00123$:
      007F9C 90 0A 8E         [24] 1764 	mov	dptr,#_owned_usage_key___200000085_20000_379
      007F9F E0               [24] 1765 	movx	a,@dptr
      007FA0 FF               [12] 1766 	mov	r7,a
      007FA1 80 02            [24] 1767 	sjmp	00136$
      007FA3                       1768 00135$:
      007FA3 7F 00            [12] 1769 	mov	r7,#0x00
      007FA5                       1770 00136$:
      007FA5 7E 00            [12] 1771 	mov	r6,#0x00
      007FA7 12 43 46         [24] 1772 	lcall	_ak820_outline_0153
                                   1773 ;	quantum/action_util.c:208: }
      007FAA 02 6C C0         [24] 1774 	ljmp	_host_system_send
                                   1775 ;------------------------------------------------------------
                                   1776 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1777 ;------------------------------------------------------------
                                   1778 ;mods          Allocated with name '_send_keyboard_report_mods_30000_399'
                                   1779 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_401'
                                   1780 ;changed       Allocated with name '_send_keyboard_report_changed_10001_401'
                                   1781 ;dest          Allocated with name '_send_keyboard_report_dest_10001_401'
                                   1782 ;src           Allocated with name '_send_keyboard_report_src_10001_401'
                                   1783 ;i             Allocated with name '_send_keyboard_report_i_20001_402'
                                   1784 ;------------------------------------------------------------
                                   1785 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1786 ;	-----------------------------------------
                                   1787 ;	 function send_keyboard_report
                                   1788 ;	-----------------------------------------
      007FAD                       1789 _send_keyboard_report:
                                   1790 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      007FAD 90 0D 96         [24] 1791 	mov	dptr,#_real_mods
      007FB0 E0               [24] 1792 	movx	a,@dptr
      007FB1 FF               [12] 1793 	mov	r7,a
      007FB2 90 0D 98         [24] 1794 	mov	dptr,#_actual_keyboard_report
      007FB5 F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      007FB6 90 0D 97         [24] 1797 	mov	dptr,#_weak_mods
      007FB9 E0               [24] 1798 	movx	a,@dptr
      007FBA 42 07            [12] 1799 	orl	ar7,a
      007FBC 90 0D 98         [24] 1800 	mov	dptr,#_actual_keyboard_report
      007FBF EF               [12] 1801 	mov	a,r7
      007FC0 F0               [24] 1802 	movx	@dptr,a
                                   1803 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      007FC1 90 09 7C         [24] 1804 	mov	dptr,#_owned_weak_mods
      007FC4 E0               [24] 1805 	movx	a,@dptr
      007FC5 FE               [12] 1806 	mov	r6,a
      007FC6 90 09 7B         [24] 1807 	mov	dptr,#_owned_mods
      007FC9 E0               [24] 1808 	movx	a,@dptr
      007FCA 4E               [12] 1809 	orl	a,r6
      007FCB 42 07            [12] 1810 	orl	ar7,a
      007FCD 90 0D 98         [24] 1811 	mov	dptr,#_actual_keyboard_report
      007FD0 EF               [12] 1812 	mov	a,r7
      007FD1 F0               [24] 1813 	movx	@dptr,a
                                   1814 ;	quantum/action_util.c:469: if (ctrl_gui_swapped) {
      007FD2 30 1F 31         [24] 1815 	jnb	_ctrl_gui_swapped,00102$
                                   1816 ;	quantum/action_util.c:470: uint8_t mods = keyboard_report->mods;
      007FD5 90 0D 98         [24] 1817 	mov	dptr,#_actual_keyboard_report
      007FD8 E0               [24] 1818 	movx	a,@dptr
      007FD9 FF               [12] 1819 	mov	r7,a
                                   1820 ;	quantum/action_util.c:471: keyboard_report->mods = (mods & 0x66) | ((mods & 0x11) << 3) | ((mods & 0x88) >> 3);
      007FDA 74 66            [12] 1821 	mov	a,#0x66
      007FDC 5F               [12] 1822 	anl	a,r7
      007FDD FE               [12] 1823 	mov	r6,a
      007FDE 8F 05            [24] 1824 	mov	ar5,r7
      007FE0 53 05 11         [24] 1825 	anl	ar5,#0x11
      007FE3 ED               [12] 1826 	mov	a,r5
      007FE4 12 38 90         [24] 1827 	lcall	_ak820_outline_0184
      007FE7 42 06            [12] 1828 	orl	ar6,a
      007FE9 53 07 88         [24] 1829 	anl	ar7,#0x88
      007FEC E4               [12] 1830 	clr	a
      007FED 23               [12] 1831 	rl	a
      007FEE CF               [12] 1832 	xch	a,r7
      007FEF 12 56 FC         [24] 1833 	lcall	_ak820_outline_0168
      007FF2 6F               [12] 1834 	xrl	a,r7
      007FF3 CF               [12] 1835 	xch	a,r7
      007FF4 54 1F            [12] 1836 	anl	a,#0x1f
      007FF6 CF               [12] 1837 	xch	a,r7
      007FF7 6F               [12] 1838 	xrl	a,r7
      007FF8 CF               [12] 1839 	xch	a,r7
      007FF9 30 E4 02         [24] 1840 	jnb	acc.4,00159$
      007FFC 44 E0            [12] 1841 	orl	a,#0xffffffe0
      007FFE                       1842 00159$:
      007FFE EF               [12] 1843 	mov	a,r7
      007FFF 42 06            [12] 1844 	orl	ar6,a
      008001 90 0D 98         [24] 1845 	mov	dptr,#_actual_keyboard_report
      008004 EE               [12] 1846 	mov	a,r6
      008005 F0               [24] 1847 	movx	@dptr,a
      008006                       1848 00102$:
                                   1849 ;	quantum/action_util.c:475: if (gui_disabled) keyboard_report->mods &= ~(MOD_BIT(KC_LGUI) | MOD_BIT(KC_RGUI));
      008006 30 1E 07         [24] 1850 	jnb	_gui_disabled,00104$
      008009 90 0D 98         [24] 1851 	mov	dptr,#_actual_keyboard_report
      00800C E0               [24] 1852 	movx	a,@dptr
      00800D 54 77            [12] 1853 	anl	a,#0x77
      00800F F0               [24] 1854 	movx	@dptr,a
      008010                       1855 00104$:
                                   1856 ;	quantum/action_util.c:515: bool changed = false;
      008010 90 0A B4         [24] 1857 	mov	dptr,#_send_keyboard_report_changed_10001_401
      008013 E4               [12] 1858 	clr	a
      008014 F0               [24] 1859 	movx	@dptr,a
                                   1860 ;	quantum/action_util.c:517: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1861 ;	quantum/action_util.c:518: const uint8_t __xdata *src = (const uint8_t __xdata *)AK820_REPORT_OUT;
                                   1862 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008015 FF               [12] 1863 	mov	r7,a
      008016                       1864 00111$:
      008016 BF 20 00         [24] 1865 	cjne	r7,#0x20,00161$
      008019                       1866 00161$:
      008019 50 2A            [24] 1867 	jnc	00107$
                                   1868 ;	quantum/action_util.c:524: if (dest[i] != src[i]) {
      00801B EF               [12] 1869 	mov	a,r7
      00801C 24 94            [12] 1870 	add	a, #_send_keyboard_report_last_report_10001_401
      00801E FD               [12] 1871 	mov	r5,a
      00801F E4               [12] 1872 	clr	a
      008020 34 0A            [12] 1873 	addc	a, #(_send_keyboard_report_last_report_10001_401 >> 8)
      008022 12 48 6C         [24] 1874 	lcall	_ak820_outline_0056
      008025 EF               [12] 1875 	mov	a,r7
      008026 24 98            [12] 1876 	add	a, #_actual_keyboard_report
      008028 F5 82            [12] 1877 	mov	dpl,a
      00802A E4               [12] 1878 	clr	a
      00802B 34 0D            [12] 1879 	addc	a, #(_actual_keyboard_report >> 8)
      00802D F5 83            [12] 1880 	mov	dph,a
      00802F E0               [24] 1881 	movx	a,@dptr
      008030 FB               [12] 1882 	mov	r3,a
      008031 EC               [12] 1883 	mov	a,r4
      008032 B5 03 02         [24] 1884 	cjne	a,ar3,00163$
      008035 80 0B            [24] 1885 	sjmp	00112$
      008037                       1886 00163$:
                                   1887 ;	quantum/action_util.c:525: dest[i] = src[i];
      008037 12 38 6A         [24] 1888 	lcall	_ak820_outline_0131
      00803A EB               [12] 1889 	mov	a,r3
      00803B F0               [24] 1890 	movx	@dptr,a
                                   1891 ;	quantum/action_util.c:526: changed = true;
      00803C 90 0A B4         [24] 1892 	mov	dptr,#_send_keyboard_report_changed_10001_401
      00803F 74 01            [12] 1893 	mov	a,#0x01
      008041 F0               [24] 1894 	movx	@dptr,a
      008042                       1895 00112$:
                                   1896 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008042 0F               [12] 1897 	inc	r7
      008043 80 D1            [24] 1898 	sjmp	00111$
      008045                       1899 00107$:
                                   1900 ;	quantum/action_util.c:529: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      008045 90 0A B4         [24] 1901 	mov	dptr,#_send_keyboard_report_changed_10001_401
      008048 E0               [24] 1902 	movx	a,@dptr
      008049 60 09            [24] 1903 	jz	00113$
      00804B 90 0D 98         [24] 1904 	mov	dptr,#_actual_keyboard_report
      00804E 75 F0 00         [24] 1905 	mov	b, #0x00
                                   1906 ;	quantum/action_util.c:538: }
      008051 02 6C 35         [24] 1907 	ljmp	_host_keyboard_send
      008054                       1908 00113$:
      008054 22               [24] 1909 	ret
                                   1910 ;------------------------------------------------------------
                                   1911 ;Allocation info for local variables in function 'get_mods'
                                   1912 ;------------------------------------------------------------
                                   1913 ;	quantum/action_util.c:544: uint8_t get_mods(void) {
                                   1914 ;	-----------------------------------------
                                   1915 ;	 function get_mods
                                   1916 ;	-----------------------------------------
      008055                       1917 _get_mods:
      008055 C0 07            [24] 1918 	push	ar7
                                   1919 ;	quantum/action_util.c:549: ;
      008057 90 09 7B         [24] 1920 	mov	dptr,#_owned_mods
      00805A E0               [24] 1921 	movx	a,@dptr
      00805B FF               [12] 1922 	mov	r7,a
      00805C 90 0D 96         [24] 1923 	mov	dptr,#_real_mods
      00805F 12 7A 94         [24] 1924 	lcall	_ak820_outline_0138
                                   1925 ;	quantum/action_util.c:550: }
      008062 D0 07            [24] 1926 	pop	ar7
      008064 22               [24] 1927 	ret
                                   1928 ;------------------------------------------------------------
                                   1929 ;Allocation info for local variables in function 'add_mods'
                                   1930 ;------------------------------------------------------------
                                   1931 ;mods          Allocated with name '_add_mods_mods_10000_409'
                                   1932 ;------------------------------------------------------------
                                   1933 ;	quantum/action_util.c:555: void add_mods(uint8_t mods) {
                                   1934 ;	-----------------------------------------
                                   1935 ;	 function clear_mods
                                   1936 ;	-----------------------------------------
      008065                       1937 _clear_mods:
                                   1938 ;	quantum/action_util.c:577: real_mods = 0;
      008065 90 0D 96         [24] 1939 	mov	dptr,#_real_mods
      008068 E4               [12] 1940 	clr	a
      008069 F0               [24] 1941 	movx	@dptr,a
                                   1942 ;	quantum/action_util.c:578: }
      00806A 22               [24] 1943 	ret
                                   1944 ;------------------------------------------------------------
                                   1945 ;Allocation info for local variables in function 'get_weak_mods'
                                   1946 ;------------------------------------------------------------
                                   1947 ;	quantum/action_util.c:584: uint8_t get_weak_mods(void) {
                                   1948 ;	-----------------------------------------
                                   1949 ;	 function get_weak_mods
                                   1950 ;	-----------------------------------------
      00806B                       1951 _get_weak_mods:
      00806B C0 07            [24] 1952 	push	ar7
                                   1953 ;	quantum/action_util.c:589: ;
      00806D 90 09 7C         [24] 1954 	mov	dptr,#_owned_weak_mods
      008070 E0               [24] 1955 	movx	a,@dptr
      008071 FF               [12] 1956 	mov	r7,a
      008072 90 0D 97         [24] 1957 	mov	dptr,#_weak_mods
      008075 12 7A 94         [24] 1958 	lcall	_ak820_outline_0138
                                   1959 ;	quantum/action_util.c:590: }
      008078 D0 07            [24] 1960 	pop	ar7
      00807A 22               [24] 1961 	ret
                                   1962 ;------------------------------------------------------------
                                   1963 ;Allocation info for local variables in function 'add_weak_mods'
                                   1964 ;------------------------------------------------------------
                                   1965 ;mods          Allocated with name '_add_weak_mods_mods_10000_419'
                                   1966 ;------------------------------------------------------------
                                   1967 ;	quantum/action_util.c:595: void add_weak_mods(uint8_t mods) {
                                   1968 ;	-----------------------------------------
                                   1969 ;	 function add_weak_mods
                                   1970 ;	-----------------------------------------
      00807B                       1971 _add_weak_mods:
      00807B E5 82            [12] 1972 	mov	a,dpl
      00807D 90 0A B5         [24] 1973 	mov	dptr,#_add_weak_mods_mods_10000_419
      008080 F0               [24] 1974 	movx	@dptr,a
                                   1975 ;	quantum/action_util.c:596: weak_mods |= mods;
      008081 E0               [24] 1976 	movx	a,@dptr
      008082 FF               [12] 1977 	mov	r7,a
      008083 90 0D 97         [24] 1978 	mov	dptr,#_weak_mods
      008086 E0               [24] 1979 	movx	a,@dptr
      008087 4F               [12] 1980 	orl	a,r7
      008088 F0               [24] 1981 	movx	@dptr,a
                                   1982 ;	quantum/action_util.c:597: }
      008089 22               [24] 1983 	ret
                                   1984 ;------------------------------------------------------------
                                   1985 ;Allocation info for local variables in function 'del_weak_mods'
                                   1986 ;------------------------------------------------------------
                                   1987 ;mods          Allocated with name '_del_weak_mods_mods_10000_421'
                                   1988 ;------------------------------------------------------------
                                   1989 ;	quantum/action_util.c:602: void del_weak_mods(uint8_t mods) {
                                   1990 ;	-----------------------------------------
                                   1991 ;	 function del_weak_mods
                                   1992 ;	-----------------------------------------
      00808A                       1993 _del_weak_mods:
      00808A E5 82            [12] 1994 	mov	a,dpl
      00808C 90 0A B6         [24] 1995 	mov	dptr,#_del_weak_mods_mods_10000_421
      00808F F0               [24] 1996 	movx	@dptr,a
                                   1997 ;	quantum/action_util.c:603: weak_mods &= ~mods;
      008090 E0               [24] 1998 	movx	a,@dptr
      008091 F4               [12] 1999 	cpl	a
      008092 FF               [12] 2000 	mov	r7,a
      008093 90 0D 97         [24] 2001 	mov	dptr,#_weak_mods
      008096 E0               [24] 2002 	movx	a,@dptr
      008097 5F               [12] 2003 	anl	a,r7
      008098 F0               [24] 2004 	movx	@dptr,a
                                   2005 ;	quantum/action_util.c:604: }
      008099 22               [24] 2006 	ret
                                   2007 ;------------------------------------------------------------
                                   2008 ;Allocation info for local variables in function 'set_weak_mods'
                                   2009 ;------------------------------------------------------------
                                   2010 ;mods          Allocated with name '_set_weak_mods_mods_10000_423'
                                   2011 ;------------------------------------------------------------
                                   2012 ;	quantum/action_util.c:609: void set_weak_mods(uint8_t mods) {
                                   2013 ;	-----------------------------------------
                                   2014 ;	 function clear_weak_mods
                                   2015 ;	-----------------------------------------
      00809A                       2016 _clear_weak_mods:
                                   2017 ;	quantum/action_util.c:617: weak_mods = 0;
      00809A 90 0D 97         [24] 2018 	mov	dptr,#_weak_mods
      00809D E4               [12] 2019 	clr	a
      00809E F0               [24] 2020 	movx	@dptr,a
                                   2021 ;	quantum/action_util.c:618: }
      00809F 22               [24] 2022 	ret
                                   2023 ;------------------------------------------------------------
                                   2024 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   2025 ;------------------------------------------------------------
                                   2026 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_427'
                                   2027 ;------------------------------------------------------------
                                   2028 ;	quantum/action_util.c:700: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   2029 ;	-----------------------------------------
                                   2030 	.area CSEG    (CODE)
                                   2031 	.area CONST   (CODE)
                                   2032 	.area XINIT   (CODE)
      00BFCD                       2033 __xinit__real_mods:
      00BFCD 00                    2034 	.db #0x00	; 0
      00BFCE                       2035 __xinit__weak_mods:
      00BFCE 00                    2036 	.db #0x00	; 0
      00BFCF                       2037 __xinit__actual_keyboard_report:
      00BFCF 00                    2038 	.db #0x00	; 0
      00BFD0 00                    2039 	.db #0x00	; 0
      00BFD1 00                    2040 	.db #0x00	; 0
      00BFD2 00                    2041 	.db #0x00	; 0
      00BFD3 00                    2042 	.db #0x00	; 0
      00BFD4 00                    2043 	.db #0x00	; 0
      00BFD5 00                    2044 	.db #0x00	; 0
      00BFD6 00                    2045 	.db #0x00	; 0
      00BFD7 00                    2046 	.db 0x00
      00BFD8 00                    2047 	.db 0x00
      00BFD9 00                    2048 	.db 0x00
      00BFDA 00                    2049 	.db 0x00
      00BFDB 00                    2050 	.db 0x00
      00BFDC 00                    2051 	.db 0x00
      00BFDD 00                    2052 	.db 0x00
      00BFDE 00                    2053 	.db 0x00
      00BFDF 00                    2054 	.db 0x00
      00BFE0 00                    2055 	.db 0x00
      00BFE1 00                    2056 	.db 0x00
      00BFE2 00                    2057 	.db 0x00
      00BFE3 00                    2058 	.db 0x00
      00BFE4 00                    2059 	.db 0x00
      00BFE5 00                    2060 	.db 0x00
      00BFE6 00                    2061 	.db 0x00
      00BFE7 00                    2062 	.db 0x00
      00BFE8 00                    2063 	.db 0x00
      00BFE9 00                    2064 	.db 0x00
      00BFEA 00                    2065 	.db 0x00
      00BFEB 00                    2066 	.db 0x00
      00BFEC 00                    2067 	.db 0x00
      00BFED 00                    2068 	.db 0x00
      00BFEE 00                    2069 	.db 0x00
                                   2070 	.area CABS    (ABS,CODE)
                                   2071 
                                   2072 ; Experimental exact instruction outlining.
                                   2073 	.globl _ak820_outline_0013
                                   2074 	.globl _ak820_outline_0028
                                   2075 	.globl _ak820_outline_0050
                                   2076 	.globl _ak820_outline_0056
                                   2077 	.globl _ak820_outline_0059
                                   2078 	.globl _ak820_outline_0062
                                   2079 	.globl _ak820_outline_0063
                                   2080 	.globl _ak820_outline_0064
                                   2081 	.globl _ak820_outline_0067
                                   2082 	.globl _ak820_outline_0073
                                   2083 	.globl _ak820_outline_0104
                                   2084 	.globl _ak820_outline_0105
                                   2085 	.globl _ak820_outline_0114
                                   2086 	.globl _ak820_outline_0119
                                   2087 	.globl _ak820_outline_0122
                                   2088 	.globl _ak820_outline_0123
                                   2089 	.globl _ak820_outline_0124
                                   2090 	.globl _ak820_outline_0130
                                   2091 	.globl _ak820_outline_0131
                                   2092 	.globl _ak820_outline_0136
                                   2093 	.globl _ak820_outline_0138
                                   2094 	.globl _ak820_outline_0152
                                   2095 	.globl _ak820_outline_0153
                                   2096 	.globl _ak820_outline_0158
                                   2097 	.globl _ak820_outline_0168
                                   2098 	.globl _ak820_outline_0172
                                   2099 	.globl _ak820_outline_0179
                                   2100 	.globl _ak820_outline_0184
                                   2101 	.globl _ak820_outline_0185
                                   2102 
                                   2103 	.area CSEG (CODE)
                                   2104 ; function ak820_outline_0028
      0080A0                       2105 _ak820_outline_0028:
      0080A0 EF               [12] 2106 	mov	a,r7
      0080A1 24 8D            [12] 2107 	add	a,#_key_refs
      0080A3 FD               [12] 2108 	mov	r5,a
      0080A4 E4               [12] 2109 	clr	a
      0080A5 34 09            [12] 2110 	addc	a,#(_key_refs>>8)
      0080A7 FE               [12] 2111 	mov	r6,a
      0080A8 8D 82            [24] 2112 	mov	dpl,r5
      0080AA 8E 83            [24] 2113 	mov	dph,r6
      0080AC E0               [24] 2114 	movx	a,@dptr
      0080AD 22               [24] 2115 	ret
                                   2116 
                                   2117 	.area CSEG (CODE)
                                   2118 ; function ak820_outline_0063
      0080AE                       2119 _ak820_outline_0063:
      0080AE 89 82            [24] 2120 	mov	dpl,r1
      0080B0 8A 83            [24] 2121 	mov	dph,r2
      0080B2 E8               [12] 2122 	mov	a,r0
      0080B3 F0               [24] 2123 	movx	@dptr,a
      0080B4 22               [24] 2124 	ret
                                   2125 
                                   2126 	.area CSEG (CODE)
                                   2127 ; function ak820_outline_0067
      0080B5                       2128 _ak820_outline_0067:
      0080B5 24 68            [12] 2129 	add	a,#_usage_order
      0080B7 F5 82            [12] 2130 	mov	dpl,a
      0080B9 E4               [12] 2131 	clr	a
      0080BA 34 0A            [12] 2132 	addc	a,#(_usage_order>>8)
      0080BC F5 83            [12] 2133 	mov	dph,a
      0080BE 22               [24] 2134 	ret
                                   2135 
                                   2136 	.area CSEG (CODE)
                                   2137 ; function ak820_outline_0073
      0080BF                       2138 _ak820_outline_0073:
      0080BF EB               [12] 2139 	mov	a,r3
      0080C0 24 4A            [12] 2140 	add	a,#_usage_refs
      0080C2 F9               [12] 2141 	mov	r1,a
      0080C3 E4               [12] 2142 	clr	a
      0080C4 34 0A            [12] 2143 	addc	a,#(_usage_refs>>8)
      0080C6 FA               [12] 2144 	mov	r2,a
      0080C7 89 82            [24] 2145 	mov	dpl,r1
      0080C9 8A 83            [24] 2146 	mov	dph,r2
      0080CB E0               [24] 2147 	movx	a,@dptr
      0080CC F8               [12] 2148 	mov	r0,a
      0080CD 22               [24] 2149 	ret
                                   2150 
                                   2151 	.area CSEG (CODE)
                                   2152 ; function ak820_outline_0114
      0080CE                       2153 _ak820_outline_0114:
      0080CE F0               [24] 2154 	movx	@dptr,a
      0080CF E0               [24] 2155 	movx	a,@dptr
      0080D0 FF               [12] 2156 	mov	r7,a
      0080D1 90 09 85         [24] 2157 	mov	dptr,#_change_owned_PARM_2
      0080D4 22               [24] 2158 	ret
                                   2159 
                                   2160 	.area CSEG (CODE)
                                   2161 ; function ak820_outline_0119
      0080D5                       2162 _ak820_outline_0119:
      0080D5 8D 82            [24] 2163 	mov	dpl,r5
      0080D7 8E 83            [24] 2164 	mov	dph,r6
      0080D9 F0               [24] 2165 	movx	@dptr,a
      0080DA 22               [24] 2166 	ret
                                   2167 
                                   2168 	.area CSEG (CODE)
                                   2169 ; function ak820_outline_0124
      0080DB                       2170 _ak820_outline_0124:
      0080DB 24 68            [12] 2171 	add	a,#_usage_order
      0080DD F5 82            [12] 2172 	mov	dpl,a
      0080DF EF               [12] 2173 	mov	a,r7
      0080E0 34 0A            [12] 2174 	addc	a,#(_usage_order>>8)
      0080E2 F5 83            [12] 2175 	mov	dph,a
      0080E4 E0               [24] 2176 	movx	a,@dptr
      0080E5 22               [24] 2177 	ret
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0130
      0080E6                       2181 _ak820_outline_0130:
      0080E6 F0               [24] 2182 	movx	@dptr,a
      0080E7 E0               [24] 2183 	movx	a,@dptr
      0080E8 FF               [12] 2184 	mov	r7,a
      0080E9 90 09 81         [24] 2185 	mov	dptr,#_ak820_macro_change_PARM_2
      0080EC F0               [24] 2186 	movx	@dptr,a
      0080ED 90 09 82         [24] 2187 	mov	dptr,#_ak820_macro_change_PARM_3
      0080F0 22               [24] 2188 	ret
                                   2189 
                                   2190 	.area CSEG (CODE)
                                   2191 ; function ak820_outline_0172
      0080F1                       2192 _ak820_outline_0172:
      0080F1 90 07 FB         [24] 2193 	mov	dptr,#_add_key_to_report_PARM_2
      0080F4 EF               [12] 2194 	mov	a,r7
      0080F5 F0               [24] 2195 	movx	@dptr,a
      0080F6 90 0D 98         [24] 2196 	mov	dptr,#_actual_keyboard_report
      0080F9 22               [24] 2197 	ret
                                   2198 
                                   2199 	.area CSEG (CODE)
                                   2200 ; function ak820_outline_0185
      0080FA                       2201 _ak820_outline_0185:
      0080FA 8D 82            [24] 2202 	mov	dpl,r5
      0080FC 8F 83            [24] 2203 	mov	dph,r7
      0080FE 22               [24] 2204 	ret
