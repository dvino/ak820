                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000C5F                        569 _g_direct_mode_colors::
      000C5F                        570 	.ds 246
      000D55                        571 _get_supported_PARM_2:
      000D55                        572 	.ds 1
      000D56                        573 _get_supported_args_10000_255:
      000D56                        574 	.ds 2
      000D58                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000D58                        576 	.ds 2
      000D5A                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000D5A                        578 	.ds 2
      000D5C                        579 _set_mode_mode_10000_275:
      000D5C                        580 	.ds 2
      000D5E                        581 _get_matrix_pos_for_led_PARM_2:
      000D5E                        582 	.ds 2
      000D60                        583 _get_matrix_pos_for_led_led_10000_280:
      000D60                        584 	.ds 2
      000D62                        585 _fast_set_leds_PARM_2:
      000D62                        586 	.ds 1
      000D63                        587 _fast_set_leds_args_10000_282:
      000D63                        588 	.ds 2
      000D65                        589 _fast_set_leds_first_index_10001_285:
      000D65                        590 	.ds 2
      000D67                        591 _fast_set_leds_num_leds_10001_285:
      000D67                        592 	.ds 1
      000D68                        593 _vialrgb_get_value_PARM_2:
      000D68                        594 	.ds 1
      000D69                        595 _vialrgb_get_value_data_10000_291:
      000D69                        596 	.ds 3
      000D6C                        597 _vialrgb_set_value_PARM_2:
      000D6C                        598 	.ds 1
      000D6D                        599 _vialrgb_set_value_data_10000_302:
      000D6D                        600 	.ds 3
      000D70                        601 _vialrgb_save_PARM_2:
      000D70                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B154                        654 _get_supported:
      00B154 12 38 49         [24]  655 	lcall	_ak820_outline_0104
      00B157 90 0D 56         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B15A 12 38 4E         [24]  657 	lcall	_ak820_outline_0105
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B15D 90 0D 56         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B160 12 37 A0         [24]  660 	lcall	_ak820_outline_0004
      00B163 E0               [24]  661 	movx	a,@dptr
      00B164 FD               [12]  662 	mov	r5,a
      00B165 7C 00            [12]  663 	mov	r4,#0x00
      00B167 12 38 53         [24]  664 	lcall	_ak820_outline_0109
      00B16A FA               [12]  665 	mov	r2,a
      00B16B E4               [12]  666 	clr	a
      00B16C 12 43 36         [24]  667 	lcall	_ak820_outline_0139
                                    668 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B16F 90 0D 55         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00B172 E0               [24]  670 	movx	a,@dptr
      00B173 FB               [12]  671 	mov	r3,a
      00B174 7A 00            [12]  672 	mov	r2,#0x00
      00B176                        673 00107$:
      00B176 C3               [12]  674 	clr	c
      00B177 EA               [12]  675 	mov	a,r2
      00B178 9B               [12]  676 	subb	a,r3
      00B179 50 0A            [24]  677 	jnc	00101$
      00B17B EA               [12]  678 	mov	a,r2
      00B17C 12 37 F0         [24]  679 	lcall	_ak820_outline_0030
      00B17F 74 FF            [12]  680 	mov	a,#0xff
      00B181 F0               [24]  681 	movx	@dptr,a
      00B182 0A               [12]  682 	inc	r2
      00B183 80 F1            [24]  683 	sjmp	00107$
      00B185                        684 00101$:
                                    685 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B185 8D 06            [24]  686 	mov	ar6,r5
      00B187 8C 07            [24]  687 	mov	ar7,r4
      00B189 8B 05            [24]  688 	mov	ar5,r3
      00B18B 90 0D 56         [24]  689 	mov	dptr,#_get_supported_args_10000_255
      00B18E 12 38 43         [24]  690 	lcall	_ak820_outline_0100
      00B191 7A 00            [12]  691 	mov	r2,#0x00
      00B193                        692 00110$:
      00B193 BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00B196                        694 00159$:
      00B196 50 46            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B198 EA               [12]  697 	mov	a,r2
      00B199 75 F0 02         [24]  698 	mov	b,#0x02
      00B19C A4               [48]  699 	mul	ab
      00B19D 24 FC            [12]  700 	add	a, #_supported_modes
      00B19F F5 82            [12]  701 	mov	dpl,a
      00B1A1 74 BD            [12]  702 	mov	a,#(_supported_modes >> 8)
      00B1A3 12 56 DD         [24]  703 	lcall	_ak820_outline_0106
      00B1A6 F8               [12]  704 	mov	r0,a
      00B1A7 79 00            [12]  705 	mov	r1,#0x00
                                    706 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B1A9 C3               [12]  707 	clr	c
      00B1AA EE               [12]  708 	mov	a,r6
      00B1AB 98               [12]  709 	subb	a,r0
      00B1AC EF               [12]  710 	mov	a,r7
      00B1AD 99               [12]  711 	subb	a,r1
      00B1AE 50 2B            [24]  712 	jnc	00111$
                                    713 ;	free result
      00B1B0 BD 02 00         [24]  714 	cjne	r5,#0x02,00162$
      00B1B3                        715 00162$:
      00B1B3 40 26            [24]  716 	jc	00111$
                                    717 ;	quantum/vialrgb.c:49: args[0] = id;
      00B1B5 C0 06            [24]  718 	push	ar6
      00B1B7 C0 07            [24]  719 	push	ar7
      00B1B9 88 07            [24]  720 	mov	ar7,r0
      00B1BB 12 33 FC         [24]  721 	lcall	_ak820_outline_0122
      00B1BE EF               [12]  722 	mov	a,r7
      00B1BF F0               [24]  723 	movx	@dptr,a
                                    724 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B1C0 12 33 FC         [24]  725 	lcall	_ak820_outline_0122
      00B1C3 A3               [24]  726 	inc	dptr
      00B1C4 89 00            [24]  727 	mov	ar0,r1
      00B1C6 E8               [12]  728 	mov	a,r0
      00B1C7 F0               [24]  729 	movx	@dptr,a
                                    730 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B1C8 1D               [12]  731 	dec	r5
      00B1C9 1D               [12]  732 	dec	r5
                                    733 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B1CA 74 02            [12]  734 	mov	a,#0x02
      00B1CC 2B               [12]  735 	add	a, r3
      00B1CD FB               [12]  736 	mov	r3,a
      00B1CE E4               [12]  737 	clr	a
      00B1CF 3C               [12]  738 	addc	a, r4
      00B1D0 FC               [12]  739 	mov	r4,a
      00B1D1 90 0D 56         [24]  740 	mov	dptr,#_get_supported_args_10000_255
      00B1D4 12 38 2B         [24]  741 	lcall	_ak820_outline_0075
                                    742 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B1D7 D0 07            [24]  743 	pop	ar7
      00B1D9 D0 06            [24]  744 	pop	ar6
                                    745 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B1DB                        746 00111$:
                                    747 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B1DB 0A               [12]  748 	inc	r2
      00B1DC 80 B5            [24]  749 	sjmp	00110$
      00B1DE                        750 00127$:
      00B1DE 90 0D 56         [24]  751 	mov	dptr,#_get_supported_args_10000_255
      00B1E1 12 38 2B         [24]  752 	lcall	_ak820_outline_0075
                                    753 ;	quantum/vialrgb.c:55: }
      00B1E4 22               [24]  754 	ret
                                    755 ;------------------------------------------------------------
                                    756 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    757 ;------------------------------------------------------------
                                    758 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    759 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    760 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    761 ;------------------------------------------------------------
                                    762 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function qmk_id_to_vialrgb_id
                                    765 ;	-----------------------------------------
      00B1E5                        766 _qmk_id_to_vialrgb_id:
      00B1E5 12 38 49         [24]  767 	lcall	_ak820_outline_0104
      00B1E8 90 0D 58         [24]  768 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B1EB 12 38 4E         [24]  769 	lcall	_ak820_outline_0105
                                    770 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B1EE 90 0D 58         [24]  771 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B1F1 12 38 00         [24]  772 	lcall	_ak820_outline_0050
      00B1F4 7D 00            [12]  773 	mov	r5,#0x00
      00B1F6                        774 00105$:
      00B1F6 BD 07 00         [24]  775 	cjne	r5,#0x07,00130$
      00B1F9                        776 00130$:
      00B1F9 50 19            [24]  777 	jnc	00103$
                                    778 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B1FB 12 B6 1B         [24]  779 	lcall	_ak820_outline_0044
      00B1FE A3               [24]  780 	inc	dptr
      00B1FF E4               [12]  781 	clr	a
      00B200 93               [24]  782 	movc	a,@a+dptr
                                    783 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B201 7A 00            [12]  784 	mov	r2,#0x00
      00B203 B5 06 0B         [24]  785 	cjne	a,ar6,00106$
      00B206 EA               [12]  786 	mov	a,r2
      00B207 B5 07 07         [24]  787 	cjne	a,ar7,00106$
                                    788 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B20A 12 33 FC         [24]  789 	lcall	_ak820_outline_0122
      00B20D 12 B6 47         [24]  790 	lcall	_ak820_outline_0141
      00B210 22               [24]  791 	ret
      00B211                        792 00106$:
                                    793 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B211 0D               [12]  794 	inc	r5
      00B212 80 E2            [24]  795 	sjmp	00105$
      00B214                        796 00103$:
                                    797 ;	quantum/vialrgb.c:63: return 0;
      00B214 90 00 00         [24]  798 	mov	dptr,#0x0000
                                    799 ;	quantum/vialrgb.c:64: }
      00B217 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    803 ;------------------------------------------------------------
                                    804 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    805 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    806 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function vialrgb_id_to_qmk_id
                                    811 ;	-----------------------------------------
      00B218                        812 _vialrgb_id_to_qmk_id:
      00B218 12 38 49         [24]  813 	lcall	_ak820_outline_0104
      00B21B 90 0D 5A         [24]  814 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B21E 12 38 4E         [24]  815 	lcall	_ak820_outline_0105
                                    816 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B221 90 0D 5A         [24]  817 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B224 12 38 00         [24]  818 	lcall	_ak820_outline_0050
      00B227 7D 00            [12]  819 	mov	r5,#0x00
      00B229                        820 00105$:
      00B229 BD 07 00         [24]  821 	cjne	r5,#0x07,00130$
      00B22C                        822 00130$:
      00B22C 50 19            [24]  823 	jnc	00103$
                                    824 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B22E 12 B6 1B         [24]  825 	lcall	_ak820_outline_0044
      00B231 E4               [12]  826 	clr	a
      00B232 93               [24]  827 	movc	a,@a+dptr
                                    828 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B233 7A 00            [12]  829 	mov	r2,#0x00
      00B235 B5 06 0C         [24]  830 	cjne	a,ar6,00106$
      00B238 EA               [12]  831 	mov	a,r2
      00B239 B5 07 08         [24]  832 	cjne	a,ar7,00106$
                                    833 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B23C 12 33 FC         [24]  834 	lcall	_ak820_outline_0122
      00B23F A3               [24]  835 	inc	dptr
      00B240 12 B6 47         [24]  836 	lcall	_ak820_outline_0141
      00B243 22               [24]  837 	ret
      00B244                        838 00106$:
                                    839 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B244 0D               [12]  840 	inc	r5
      00B245 80 E2            [24]  841 	sjmp	00105$
      00B247                        842 00103$:
                                    843 ;	quantum/vialrgb.c:72: return 0;
      00B247 90 00 00         [24]  844 	mov	dptr,#0x0000
                                    845 ;	quantum/vialrgb.c:73: }
      00B24A 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'get_mode'
                                    849 ;------------------------------------------------------------
                                    850 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    851 ;	-----------------------------------------
                                    852 ;	 function get_mode
                                    853 ;	-----------------------------------------
      00B24B                        854 _get_mode:
                                    855 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B24B 12 54 C3         [24]  856 	lcall	_rgb_matrix_is_enabled
      00B24E E5 82            [12]  857 	mov	a, dpl
      00B250 70 04            [24]  858 	jnz	00102$
                                    859 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B252 90 00 00         [24]  860 	mov	dptr,#0x0000
      00B255 22               [24]  861 	ret
      00B256                        862 00102$:
                                    863 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B256 12 54 C9         [24]  864 	lcall	_rgb_matrix_get_mode
      00B259 7E 00            [12]  865 	mov	r6,#0x00
      00B25B 8E 83            [24]  866 	mov	dph, r6
                                    867 ;	quantum/vialrgb.c:80: }
      00B25D 02 B1 E5         [24]  868 	ljmp	_qmk_id_to_vialrgb_id
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'set_mode'
                                    871 ;------------------------------------------------------------
                                    872 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    873 ;------------------------------------------------------------
                                    874 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function set_mode
                                    877 ;	-----------------------------------------
      00B260                        878 _set_mode:
      00B260 12 38 49         [24]  879 	lcall	_ak820_outline_0104
      00B263 90 0D 5C         [24]  880 	mov	dptr,#_set_mode_mode_10000_275
      00B266 12 38 4E         [24]  881 	lcall	_ak820_outline_0105
                                    882 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B269 90 0D 5C         [24]  883 	mov	dptr,#_set_mode_mode_10000_275
      00B26C 12 38 00         [24]  884 	lcall	_ak820_outline_0050
      00B26F 90 0D 5C         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00B272 12 6D 2E         [24]  886 	lcall	_ak820_outline_0035
      00B275 70 03            [24]  887 	jnz	00102$
                                    888 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B277 02 55 16         [24]  889 	ljmp	_rgb_matrix_disable_noeeprom
      00B27A                        890 00102$:
                                    891 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B27A C0 07            [24]  892 	push	ar7
      00B27C C0 06            [24]  893 	push	ar6
      00B27E 12 55 05         [24]  894 	lcall	_rgb_matrix_enable_noeeprom
      00B281 D0 06            [24]  895 	pop	ar6
      00B283 D0 07            [24]  896 	pop	ar7
                                    897 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B285 12 43 20         [24]  898 	lcall	_ak820_outline_0117
      00B288 12 B2 18         [24]  899 	lcall	_vialrgb_id_to_qmk_id
                                    900 ;	quantum/vialrgb.c:90: }
      00B28B 02 55 1F         [24]  901 	ljmp	_rgb_matrix_mode_noeeprom
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    904 ;------------------------------------------------------------
                                    905 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    906 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    907 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    908 ;------------------------------------------------------------
                                    909 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    910 ;	-----------------------------------------
                                    911 ;	 function get_matrix_pos_for_led
                                    912 ;	-----------------------------------------
      00B28E                        913 _get_matrix_pos_for_led:
      00B28E 12 38 49         [24]  914 	lcall	_ak820_outline_0104
      00B291 90 0D 60         [24]  915 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B294 12 38 4E         [24]  916 	lcall	_ak820_outline_0105
                                    917 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B297 90 0D 60         [24]  918 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B29A 12 38 00         [24]  919 	lcall	_ak820_outline_0050
      00B29D EE               [12]  920 	mov	a,r6
      00B29E 24 03            [12]  921 	add	a, #_ak820_rgb_slots
      00B2A0 F5 82            [12]  922 	mov	dpl,a
      00B2A2 EF               [12]  923 	mov	a,r7
      00B2A3 34 B8            [12]  924 	addc	a, #(_ak820_rgb_slots >> 8)
      00B2A5 F5 83            [12]  925 	mov	dph,a
      00B2A7 E4               [12]  926 	clr	a
      00B2A8 93               [24]  927 	movc	a,@a+dptr
      00B2A9 FF               [12]  928 	mov	r7,a
                                    929 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B2AA 90 0D 5E         [24]  930 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B2AD 12 43 0E         [24]  931 	lcall	_ak820_outline_0096
      00B2B0 EF               [12]  932 	mov	a,r7
      00B2B1 12 56 FC         [24]  933 	lcall	_ak820_outline_0168
      00B2B4 12 80 D5         [24]  934 	lcall	_ak820_outline_0119
                                    935 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B2B7 12 38 6A         [24]  936 	lcall	_ak820_outline_0131
      00B2BA A3               [24]  937 	inc	dptr
      00B2BB 53 07 07         [24]  938 	anl	ar7,#0x07
      00B2BE EF               [12]  939 	mov	a,r7
      00B2BF F0               [24]  940 	movx	@dptr,a
                                    941 ;	quantum/vialrgb.c:110: }
      00B2C0 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'fast_set_leds'
                                    945 ;------------------------------------------------------------
                                    946 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    947 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    948 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    949 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    950 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    951 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    952 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    953 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    954 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function fast_set_leds
                                    959 ;	-----------------------------------------
      00B2C1                        960 _fast_set_leds:
      00B2C1 12 38 49         [24]  961 	lcall	_ak820_outline_0104
      00B2C4 90 0D 63         [24]  962 	mov	dptr,#_fast_set_leds_args_10000_282
      00B2C7 12 38 4E         [24]  963 	lcall	_ak820_outline_0105
                                    964 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B2CA 90 0D 62         [24]  965 	mov	dptr,#_fast_set_leds_PARM_2
      00B2CD E0               [24]  966 	movx	a,@dptr
      00B2CE FF               [12]  967 	mov	r7,a
      00B2CF BF 03 00         [24]  968 	cjne	r7,#0x03,00159$
      00B2D2                        969 00159$:
      00B2D2 50 01            [24]  970 	jnc	00102$
      00B2D4 22               [24]  971 	ret
      00B2D5                        972 00102$:
                                    973 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B2D5 90 0D 63         [24]  974 	mov	dptr,#_fast_set_leds_args_10000_282
      00B2D8 E0               [24]  975 	movx	a,@dptr
      00B2D9 FD               [12]  976 	mov	r5,a
      00B2DA A3               [24]  977 	inc	dptr
      00B2DB E0               [24]  978 	movx	a,@dptr
      00B2DC 12 48 6C         [24]  979 	lcall	_ak820_outline_0056
      00B2DF 7B 00            [12]  980 	mov	r3,#0x00
      00B2E1 12 38 6A         [24]  981 	lcall	_ak820_outline_0131
      00B2E4 A3               [24]  982 	inc	dptr
      00B2E5 E0               [24]  983 	movx	a,@dptr
      00B2E6 FA               [12]  984 	mov	r2,a
      00B2E7 79 00            [12]  985 	mov	r1,#0x00
      00B2E9 90 0D 65         [24]  986 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B2EC E9               [12]  987 	mov	a,r1
      00B2ED 4C               [12]  988 	orl	a,r4
      00B2EE F0               [24]  989 	movx	@dptr,a
      00B2EF EA               [12]  990 	mov	a,r2
      00B2F0 4B               [12]  991 	orl	a,r3
      00B2F1 A3               [24]  992 	inc	dptr
      00B2F2 F0               [24]  993 	movx	@dptr,a
                                    994 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B2F3 12 38 6A         [24]  995 	lcall	_ak820_outline_0131
      00B2F6 A3               [24]  996 	inc	dptr
      00B2F7 A3               [24]  997 	inc	dptr
      00B2F8 E0               [24]  998 	movx	a,@dptr
      00B2F9 90 0D 67         [24]  999 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B2FC F0               [24] 1000 	movx	@dptr,a
                                   1001 ;	quantum/vialrgb.c:119: length -= 3;
      00B2FD EF               [12] 1002 	mov	a,r7
      00B2FE 24 FD            [12] 1003 	add	a,#0xfd
      00B300 90 0D 62         [24] 1004 	mov	dptr,#_fast_set_leds_PARM_2
      00B303 F0               [24] 1005 	movx	@dptr,a
                                   1006 ;	quantum/vialrgb.c:120: args += 3;
      00B304 90 0D 63         [24] 1007 	mov	dptr,#_fast_set_leds_args_10000_282
      00B307 74 03            [12] 1008 	mov	a,#0x03
      00B309 2D               [12] 1009 	add	a, r5
      00B30A F0               [24] 1010 	movx	@dptr,a
      00B30B E4               [12] 1011 	clr	a
      00B30C 3E               [12] 1012 	addc	a, r6
      00B30D A3               [24] 1013 	inc	dptr
      00B30E F0               [24] 1014 	movx	@dptr,a
                                   1015 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B30F 90 0D 67         [24] 1016 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B312 E0               [24] 1017 	movx	a,@dptr
      00B313 FF               [12] 1018 	mov	r7,a
      00B314 75 F0 03         [24] 1019 	mov	b,#0x03
      00B317 A4               [48] 1020 	mul	ab
      00B318 FE               [12] 1021 	mov	r6,a
      00B319 AD F0            [24] 1022 	mov	r5,b
      00B31B 90 0D 62         [24] 1023 	mov	dptr,#_fast_set_leds_PARM_2
      00B31E E0               [24] 1024 	movx	a,@dptr
      00B31F FB               [12] 1025 	mov	r3,a
      00B320 7C 00            [12] 1026 	mov	r4,#0x00
      00B322 C3               [12] 1027 	clr	c
      00B323 EB               [12] 1028 	mov	a,r3
      00B324 9E               [12] 1029 	subb	a,r6
      00B325 EC               [12] 1030 	mov	a,r4
      00B326 9D               [12] 1031 	subb	a,r5
      00B327 40 13            [24] 1032 	jc	00103$
                                   1033 ;	free result
      00B329 90 0D 65         [24] 1034 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B32C 12 43 0E         [24] 1035 	lcall	_ak820_outline_0096
      00B32F 8D 03            [24] 1036 	mov	ar3,r5
      00B331 8E 04            [24] 1037 	mov	ar4,r6
      00B333 C3               [12] 1038 	clr	c
      00B334 EB               [12] 1039 	mov	a,r3
      00B335 94 52            [12] 1040 	subb	a,#0x52
      00B337 EC               [12] 1041 	mov	a,r4
      00B338 94 00            [12] 1042 	subb	a,#0x00
      00B33A 40 01            [24] 1043 	jc	00104$
      00B33C                       1044 00103$:
      00B33C 22               [24] 1045 	ret
      00B33D                       1046 00104$:
                                   1047 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B33D 74 52            [12] 1048 	mov	a,#0x52
      00B33F C3               [12] 1049 	clr	c
      00B340 9D               [12] 1050 	subb	a,r5
      00B341 FB               [12] 1051 	mov	r3,a
      00B342 E4               [12] 1052 	clr	a
      00B343 9E               [12] 1053 	subb	a,r6
      00B344 FC               [12] 1054 	mov	r4,a
      00B345 7A 00            [12] 1055 	mov	r2,#0x00
      00B347 C3               [12] 1056 	clr	c
      00B348 EB               [12] 1057 	mov	a,r3
      00B349 9F               [12] 1058 	subb	a,r7
      00B34A EC               [12] 1059 	mov	a,r4
      00B34B 9A               [12] 1060 	subb	a,r2
      00B34C 50 08            [24] 1061 	jnc	00127$
                                   1062 ;	free result
      00B34E 90 0D 67         [24] 1063 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B351 74 52            [12] 1064 	mov	a,#0x52
      00B353 C3               [12] 1065 	clr	c
      00B354 9D               [12] 1066 	subb	a,r5
      00B355 F0               [24] 1067 	movx	@dptr,a
                                   1068 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B356                       1069 00127$:
      00B356 90 0D 67         [24] 1070 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B359 E0               [24] 1071 	movx	a,@dptr
      00B35A FF               [12] 1072 	mov	r7,a
      00B35B 90 0D 65         [24] 1073 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B35E 12 43 0E         [24] 1074 	lcall	_ak820_outline_0096
      00B361 7C 00            [12] 1075 	mov	r4,#0x00
      00B363                       1076 00110$:
      00B363 C3               [12] 1077 	clr	c
      00B364 EC               [12] 1078 	mov	a,r4
      00B365 9F               [12] 1079 	subb	a,r7
      00B366 40 01            [24] 1080 	jc	00164$
      00B368 22               [24] 1081 	ret
      00B369                       1082 00164$:
                                   1083 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B369 C0 07            [24] 1084 	push	ar7
      00B36B 90 0D 7F         [24] 1085 	mov	dptr,#__mulint_PARM_2
      00B36E 12 43 51         [24] 1086 	lcall	_ak820_outline_0157
      00B371 90 00 03         [24] 1087 	mov	dptr,#0x0003
      00B374 C0 07            [24] 1088 	push	ar7
      00B376 C0 06            [24] 1089 	push	ar6
      00B378 C0 05            [24] 1090 	push	ar5
      00B37A C0 04            [24] 1091 	push	ar4
      00B37C 12 B7 B3         [24] 1092 	lcall	__mulint
      00B37F AA 82            [24] 1093 	mov	r2, dpl
      00B381 AB 83            [24] 1094 	mov	r3, dph
      00B383 D0 04            [24] 1095 	pop	ar4
      00B385 D0 05            [24] 1096 	pop	ar5
      00B387 D0 06            [24] 1097 	pop	ar6
      00B389 D0 07            [24] 1098 	pop	ar7
      00B38B 0D               [12] 1099 	inc	r5
      00B38C BD 00 01         [24] 1100 	cjne	r5,#0x00,00165$
      00B38F 0E               [12] 1101 	inc	r6
      00B390                       1102 00165$:
      00B390 EA               [12] 1103 	mov	a,r2
      00B391 24 5F            [12] 1104 	add	a, #_g_direct_mode_colors
      00B393 FA               [12] 1105 	mov	r2,a
      00B394 EB               [12] 1106 	mov	a,r3
      00B395 34 0C            [12] 1107 	addc	a, #(_g_direct_mode_colors >> 8)
      00B397 FB               [12] 1108 	mov	r3,a
                                   1109 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B398 8A 4A            [24] 1110 	mov	_fast_set_leds_sloc0_1_0,r2
      00B39A 8B 4B            [24] 1111 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B39C 12 B6 2D         [24] 1112 	lcall	_ak820_outline_0080
      00B39F F8               [12] 1113 	mov	r0,a
      00B3A0 12 B6 3B         [24] 1114 	lcall	_ak820_outline_0103
      00B3A3 85 4A 82         [24] 1115 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B3A6 85 4B 83         [24] 1116 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B3A9 E8               [12] 1117 	mov	a,r0
      00B3AA F0               [24] 1118 	movx	@dptr,a
                                   1119 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B3AB 74 01            [12] 1120 	mov	a,#0x01
      00B3AD 2A               [12] 1121 	add	a, r2
      00B3AE F5 4A            [12] 1122 	mov	_fast_set_leds_sloc0_1_0,a
      00B3B0 E4               [12] 1123 	clr	a
      00B3B1 3B               [12] 1124 	addc	a, r3
      00B3B2 F5 4B            [12] 1125 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B3B4 90 0D 63         [24] 1126 	mov	dptr,#_fast_set_leds_args_10000_282
      00B3B7 E0               [24] 1127 	movx	a,@dptr
      00B3B8 F8               [12] 1128 	mov	r0,a
      00B3B9 A3               [24] 1129 	inc	dptr
      00B3BA E0               [24] 1130 	movx	a,@dptr
      00B3BB FF               [12] 1131 	mov	r7,a
      00B3BC 88 82            [24] 1132 	mov	dpl,r0
      00B3BE 8F 83            [24] 1133 	mov	dph,r7
      00B3C0 E0               [24] 1134 	movx	a,@dptr
      00B3C1 F9               [12] 1135 	mov	r1,a
      00B3C2 90 0D 63         [24] 1136 	mov	dptr,#_fast_set_leds_args_10000_282
      00B3C5 74 01            [12] 1137 	mov	a,#0x01
      00B3C7 28               [12] 1138 	add	a, r0
      00B3C8 F0               [24] 1139 	movx	@dptr,a
      00B3C9 E4               [12] 1140 	clr	a
      00B3CA 3F               [12] 1141 	addc	a, r7
      00B3CB A3               [24] 1142 	inc	dptr
      00B3CC F0               [24] 1143 	movx	@dptr,a
      00B3CD 85 4A 82         [24] 1144 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B3D0 85 4B 83         [24] 1145 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B3D3 E9               [12] 1146 	mov	a,r1
      00B3D4 F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B3D5 12 B6 2D         [24] 1149 	lcall	_ak820_outline_0080
      00B3D8 F5 4A            [12] 1150 	mov	_fast_set_leds_sloc0_1_0,a
      00B3DA 12 B6 3B         [24] 1151 	lcall	_ak820_outline_0103
                                   1152 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B3DD 74 02            [12] 1153 	mov	a,#0x02
      00B3DF 2A               [12] 1154 	add	a, r2
      00B3E0 F5 4C            [12] 1155 	mov	_fast_set_leds_sloc1_1_0,a
      00B3E2 E4               [12] 1156 	clr	a
      00B3E3 3B               [12] 1157 	addc	a, r3
      00B3E4 F5 4D            [12] 1158 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B3E6 C3               [12] 1159 	clr	c
      00B3E7 74 A0            [12] 1160 	mov	a,#0xa0
      00B3E9 95 4A            [12] 1161 	subb	a,_fast_set_leds_sloc0_1_0
      00B3EB D0 07            [24] 1162 	pop	ar7
      00B3ED 50 04            [24] 1163 	jnc	00114$
                                   1164 ;	free result
      00B3EF 7B A0            [12] 1165 	mov	r3,#0xa0
      00B3F1 80 04            [24] 1166 	sjmp	00115$
      00B3F3                       1167 00114$:
      00B3F3 AA 4A            [24] 1168 	mov	r2,_fast_set_leds_sloc0_1_0
      00B3F5 8A 03            [24] 1169 	mov	ar3,r2
      00B3F7                       1170 00115$:
      00B3F7 85 4C 82         [24] 1171 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B3FA 85 4D 83         [24] 1172 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B3FD EB               [12] 1173 	mov	a,r3
      00B3FE F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B3FF 0C               [12] 1176 	inc	r4
                                   1177 ;	quantum/vialrgb.c:133: }
      00B400 02 B3 63         [24] 1178 	ljmp	00110$
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1183 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1184 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1185 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1186 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1187 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1188 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1189 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function vialrgb_get_value
                                   1194 ;	-----------------------------------------
      00B403                       1195 _vialrgb_get_value:
      00B403 12 42 DE         [24] 1196 	lcall	_ak820_outline_0036
      00B406 90 0D 69         [24] 1197 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B409 12 37 DF         [24] 1198 	lcall	_ak820_outline_0015
                                   1199 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B40C 90 0D 68         [24] 1200 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B40F E0               [24] 1201 	movx	a,@dptr
      00B410 FF               [12] 1202 	mov	r7,a
      00B411 BF 20 02         [24] 1203 	cjne	r7,#0x20,00162$
      00B414 80 01            [24] 1204 	sjmp	00102$
      00B416                       1205 00162$:
      00B416 22               [24] 1206 	ret
      00B417                       1207 00102$:
                                   1208 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B417 90 0D 69         [24] 1209 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B41A 12 B6 07         [24] 1210 	lcall	_ak820_outline_0042
                                   1211 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1212 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B41D BA 40 02         [24] 1213 	cjne	r2,#0x40,00163$
      00B420 80 18            [24] 1214 	sjmp	00103$
      00B422                       1215 00163$:
      00B422 BA 41 02         [24] 1216 	cjne	r2,#0x41,00164$
      00B425 80 26            [24] 1217 	sjmp	00104$
      00B427                       1218 00164$:
      00B427 BA 42 03         [24] 1219 	cjne	r2,#0x42,00165$
      00B42A 02 B4 DF         [24] 1220 	ljmp	00105$
      00B42D                       1221 00165$:
      00B42D BA 43 03         [24] 1222 	cjne	r2,#0x43,00166$
      00B430 02 B4 EC         [24] 1223 	ljmp	00106$
      00B433                       1224 00166$:
      00B433 BA 44 03         [24] 1225 	cjne	r2,#0x44,00167$
      00B436 02 B4 F8         [24] 1226 	ljmp	00107$
      00B439                       1227 00167$:
      00B439 22               [24] 1228 	ret
                                   1229 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B43A                       1230 00103$:
                                   1231 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B43A 12 33 FC         [24] 1232 	lcall	_ak820_outline_0122
      00B43D 74 01            [12] 1233 	mov	a,#0x01
      00B43F F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B440 12 B5 FF         [24] 1236 	lcall	_ak820_outline_0034
      00B443 E4               [12] 1237 	clr	a
      00B444 F0               [24] 1238 	movx	@dptr,a
                                   1239 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B445 12 B5 FF         [24] 1240 	lcall	_ak820_outline_0034
      00B448 A3               [24] 1241 	inc	dptr
      00B449 74 A0            [12] 1242 	mov	a,#0xa0
      00B44B F0               [24] 1243 	movx	@dptr,a
                                   1244 ;	quantum/vialrgb.c:147: break;
      00B44C 22               [24] 1245 	ret
                                   1246 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B44D                       1247 00104$:
                                   1248 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B44D C0 06            [24] 1249 	push	ar6
      00B44F C0 05            [24] 1250 	push	ar5
      00B451 C0 04            [24] 1251 	push	ar4
      00B453 C0 03            [24] 1252 	push	ar3
      00B455 12 B2 4B         [24] 1253 	lcall	_get_mode
      00B458 A9 82            [24] 1254 	mov	r1, dpl
      00B45A AA 83            [24] 1255 	mov	r2, dph
      00B45C D0 03            [24] 1256 	pop	ar3
      00B45E D0 04            [24] 1257 	pop	ar4
      00B460 D0 05            [24] 1258 	pop	ar5
      00B462 D0 06            [24] 1259 	pop	ar6
                                   1260 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B464 89 00            [24] 1261 	mov	ar0,r1
      00B466 12 33 FC         [24] 1262 	lcall	_ak820_outline_0122
      00B469 E8               [12] 1263 	mov	a,r0
      00B46A F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B46B 12 B5 FF         [24] 1266 	lcall	_ak820_outline_0034
      00B46E 8A 01            [24] 1267 	mov	ar1,r2
      00B470 E9               [12] 1268 	mov	a,r1
      00B471 F0               [24] 1269 	movx	@dptr,a
                                   1270 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B472 74 04            [12] 1271 	mov	a,#0x04
      00B474 12 8E 60         [24] 1272 	lcall	_ak820_outline_0133
      00B477 C0 06            [24] 1273 	push	ar6
      00B479 C0 05            [24] 1274 	push	ar5
      00B47B C0 02            [24] 1275 	push	ar2
      00B47D C0 01            [24] 1276 	push	ar1
      00B47F 12 54 E4         [24] 1277 	lcall	_rgb_matrix_get_speed
      00B482 A8 82            [24] 1278 	mov	r0, dpl
      00B484 D0 01            [24] 1279 	pop	ar1
      00B486 D0 02            [24] 1280 	pop	ar2
      00B488 D0 05            [24] 1281 	pop	ar5
      00B48A D0 06            [24] 1282 	pop	ar6
      00B48C 12 80 AE         [24] 1283 	lcall	_ak820_outline_0063
                                   1284 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B48F 74 05            [12] 1285 	mov	a,#0x05
      00B491 12 8E 60         [24] 1286 	lcall	_ak820_outline_0133
      00B494 C0 06            [24] 1287 	push	ar6
      00B496 C0 05            [24] 1288 	push	ar5
      00B498 C0 02            [24] 1289 	push	ar2
      00B49A C0 01            [24] 1290 	push	ar1
      00B49C 12 54 CF         [24] 1291 	lcall	_rgb_matrix_get_hue
      00B49F A8 82            [24] 1292 	mov	r0, dpl
      00B4A1 D0 01            [24] 1293 	pop	ar1
      00B4A3 D0 02            [24] 1294 	pop	ar2
      00B4A5 D0 05            [24] 1295 	pop	ar5
      00B4A7 D0 06            [24] 1296 	pop	ar6
      00B4A9 12 80 AE         [24] 1297 	lcall	_ak820_outline_0063
                                   1298 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B4AC 74 06            [12] 1299 	mov	a,#0x06
      00B4AE 12 8E 60         [24] 1300 	lcall	_ak820_outline_0133
      00B4B1 C0 06            [24] 1301 	push	ar6
      00B4B3 C0 05            [24] 1302 	push	ar5
      00B4B5 C0 02            [24] 1303 	push	ar2
      00B4B7 C0 01            [24] 1304 	push	ar1
      00B4B9 12 54 D6         [24] 1305 	lcall	_rgb_matrix_get_sat
      00B4BC A8 82            [24] 1306 	mov	r0, dpl
      00B4BE D0 01            [24] 1307 	pop	ar1
      00B4C0 D0 02            [24] 1308 	pop	ar2
      00B4C2 D0 05            [24] 1309 	pop	ar5
      00B4C4 D0 06            [24] 1310 	pop	ar6
      00B4C6 12 80 AE         [24] 1311 	lcall	_ak820_outline_0063
                                   1312 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B4C9 74 07            [12] 1313 	mov	a,#0x07
      00B4CB 12 8E 60         [24] 1314 	lcall	_ak820_outline_0133
      00B4CE C0 02            [24] 1315 	push	ar2
      00B4D0 C0 01            [24] 1316 	push	ar1
      00B4D2 12 54 DD         [24] 1317 	lcall	_rgb_matrix_get_val
      00B4D5 A8 82            [24] 1318 	mov	r0, dpl
      00B4D7 D0 01            [24] 1319 	pop	ar1
      00B4D9 D0 02            [24] 1320 	pop	ar2
      00B4DB 12 80 AE         [24] 1321 	lcall	_ak820_outline_0063
                                   1322 ;	quantum/vialrgb.c:156: break;
      00B4DE 22               [24] 1323 	ret
                                   1324 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B4DF                       1325 00105$:
                                   1326 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B4DF EF               [12] 1327 	mov	a,r7
      00B4E0 24 FE            [12] 1328 	add	a,#0xfe
      00B4E2 90 0D 55         [24] 1329 	mov	dptr,#_get_supported_PARM_2
      00B4E5 F0               [24] 1330 	movx	@dptr,a
      00B4E6 12 33 FC         [24] 1331 	lcall	_ak820_outline_0122
                                   1332 ;	quantum/vialrgb.c:160: break;
      00B4E9 02 B1 54         [24] 1333 	ljmp	_get_supported
                                   1334 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B4EC                       1335 00106$:
                                   1336 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B4EC 12 33 FC         [24] 1337 	lcall	_ak820_outline_0122
      00B4EF 74 52            [12] 1338 	mov	a,#0x52
      00B4F1 F0               [24] 1339 	movx	@dptr,a
                                   1340 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B4F2 12 B5 FF         [24] 1341 	lcall	_ak820_outline_0034
      00B4F5 E4               [12] 1342 	clr	a
      00B4F6 F0               [24] 1343 	movx	@dptr,a
                                   1344 ;	quantum/vialrgb.c:166: break;
      00B4F7 22               [24] 1345 	ret
                                   1346 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00B4F8                       1347 00107$:
                                   1348 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B4F8 12 33 FC         [24] 1349 	lcall	_ak820_outline_0122
      00B4FB E0               [24] 1350 	movx	a,@dptr
      00B4FC FF               [12] 1351 	mov	r7,a
      00B4FD 7A 00            [12] 1352 	mov	r2,#0x00
      00B4FF 74 03            [12] 1353 	mov	a,#0x03
      00B501 2D               [12] 1354 	add	a, r5
      00B502 F8               [12] 1355 	mov	r0,a
      00B503 E4               [12] 1356 	clr	a
      00B504 3E               [12] 1357 	addc	a, r6
      00B505 F9               [12] 1358 	mov	r1,a
      00B506 C0 03            [24] 1359 	push	ar3
      00B508 C0 04            [24] 1360 	push	ar4
      00B50A 12 38 75         [24] 1361 	lcall	_ak820_outline_0152
      00B50D E0               [24] 1362 	movx	a,@dptr
      00B50E FB               [12] 1363 	mov	r3,a
      00B50F E4               [12] 1364 	clr	a
      00B510 4F               [12] 1365 	orl	a,r7
      00B511 F5 4E            [12] 1366 	mov	_vialrgb_get_value_sloc0_1_0,a
      00B513 EB               [12] 1367 	mov	a,r3
      00B514 4A               [12] 1368 	orl	a,r2
      00B515 F5 4F            [12] 1369 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1370 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00B517 AC 4E            [24] 1371 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00B519 AF 4F            [24] 1372 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B51B C3               [12] 1373 	clr	c
      00B51C EC               [12] 1374 	mov	a,r4
      00B51D 94 52            [12] 1375 	subb	a,#0x52
      00B51F EF               [12] 1376 	mov	a,r7
      00B520 94 00            [12] 1377 	subb	a,#0x00
      00B522 D0 04            [24] 1378 	pop	ar4
      00B524 D0 03            [24] 1379 	pop	ar3
      00B526 40 01            [24] 1380 	jc	00109$
      00B528 22               [24] 1381 	ret
      00B529                       1382 00109$:
                                   1383 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00B529 E5 4E            [12] 1384 	mov	a,_vialrgb_get_value_sloc0_1_0
      00B52B 25 4E            [12] 1385 	add	a,_vialrgb_get_value_sloc0_1_0
      00B52D FA               [12] 1386 	mov	r2,a
      00B52E E5 4F            [12] 1387 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B530 33               [12] 1388 	rlc	a
      00B531 FF               [12] 1389 	mov	r7,a
      00B532 EA               [12] 1390 	mov	a,r2
      00B533 24 BD            [12] 1391 	add	a, #_ak820_led_points
      00B535 F5 50            [12] 1392 	mov	_vialrgb_get_value_sloc1_1_0,a
      00B537 EF               [12] 1393 	mov	a,r7
      00B538 34 BA            [12] 1394 	addc	a, #(_ak820_led_points >> 8)
      00B53A F5 51            [12] 1395 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00B53C 85 50 82         [24] 1396 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B53F 85 51 83         [24] 1397 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B542 E4               [12] 1398 	clr	a
      00B543 93               [24] 1399 	movc	a,@a+dptr
      00B544 12 33 FC         [24] 1400 	lcall	_ak820_outline_0122
      00B547 F0               [24] 1401 	movx	@dptr,a
                                   1402 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00B548 85 50 82         [24] 1403 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B54B 85 51 83         [24] 1404 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B54E A3               [24] 1405 	inc	dptr
      00B54F E4               [12] 1406 	clr	a
      00B550 93               [24] 1407 	movc	a,@a+dptr
      00B551 12 38 75         [24] 1408 	lcall	_ak820_outline_0152
      00B554 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00B555 12 B5 FF         [24] 1411 	lcall	_ak820_outline_0034
      00B558 A3               [24] 1412 	inc	dptr
      00B559 74 04            [12] 1413 	mov	a,#0x04
      00B55B F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00B55C 90 0D 5E         [24] 1416 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B55F 04               [12] 1417 	inc	a
      00B560 2D               [12] 1418 	add	a, r5
      00B561 F0               [24] 1419 	movx	@dptr,a
      00B562 E4               [12] 1420 	clr	a
      00B563 3E               [12] 1421 	addc	a, r6
      00B564 A3               [24] 1422 	inc	dptr
      00B565 F0               [24] 1423 	movx	@dptr,a
      00B566 85 4E 82         [24] 1424 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00B569 85 4F 83         [24] 1425 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1426 ;	quantum/vialrgb.c:187: }
                                   1427 ;	quantum/vialrgb.c:188: }
      00B56C 02 B2 8E         [24] 1428 	ljmp	_get_matrix_pos_for_led
                                   1429 ;------------------------------------------------------------
                                   1430 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1431 ;------------------------------------------------------------
                                   1432 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1433 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1434 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1435 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1436 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1437 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1438 ;------------------------------------------------------------
                                   1439 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1440 ;	-----------------------------------------
                                   1441 ;	 function vialrgb_set_value
                                   1442 ;	-----------------------------------------
      00B56F                       1443 _vialrgb_set_value:
      00B56F 12 42 DE         [24] 1444 	lcall	_ak820_outline_0036
      00B572 90 0D 6D         [24] 1445 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B575 12 37 DF         [24] 1446 	lcall	_ak820_outline_0015
                                   1447 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00B578 90 0D 6C         [24] 1448 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B57B E0               [24] 1449 	movx	a,@dptr
      00B57C FF               [12] 1450 	mov	r7,a
      00B57D BF 20 02         [24] 1451 	cjne	r7,#0x20,00129$
      00B580 80 01            [24] 1452 	sjmp	00102$
      00B582                       1453 00129$:
      00B582 22               [24] 1454 	ret
      00B583                       1455 00102$:
                                   1456 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B583 90 0D 6D         [24] 1457 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B586 12 B6 07         [24] 1458 	lcall	_ak820_outline_0042
                                   1459 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1460 ;	quantum/vialrgb.c:196: switch (cmd) {
      00B589 BA 41 02         [24] 1461 	cjne	r2,#0x41,00130$
      00B58C 80 06            [24] 1462 	sjmp	00103$
      00B58E                       1463 00130$:
      00B58E BA 42 02         [24] 1464 	cjne	r2,#0x42,00131$
      00B591 80 5C            [24] 1465 	sjmp	00104$
      00B593                       1466 00131$:
      00B593 22               [24] 1467 	ret
                                   1468 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00B594                       1469 00103$:
                                   1470 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00B594 12 48 7A         [24] 1471 	lcall	_ak820_outline_0064
      00B597 12 B5 FF         [24] 1472 	lcall	_ak820_outline_0034
      00B59A E0               [24] 1473 	movx	a,@dptr
      00B59B F8               [12] 1474 	mov	r0,a
      00B59C 79 00            [12] 1475 	mov	r1,#0x00
      00B59E 88 53            [24] 1476 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00B5A0 89 52            [24] 1477 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00B5A2 8A 01            [24] 1478 	mov	ar1,r2
      00B5A4 7A 00            [12] 1479 	mov	r2,#0x00
      00B5A6 E5 53            [12] 1480 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00B5A8 42 02            [12] 1481 	orl	ar2,a
                                   1482 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00B5AA 12 43 57         [24] 1483 	lcall	_ak820_outline_0180
      00B5AD C0 06            [24] 1484 	push	ar6
      00B5AF C0 05            [24] 1485 	push	ar5
      00B5B1 12 B2 60         [24] 1486 	lcall	_set_mode
      00B5B4 D0 05            [24] 1487 	pop	ar5
      00B5B6 D0 06            [24] 1488 	pop	ar6
                                   1489 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00B5B8 12 B5 FF         [24] 1490 	lcall	_ak820_outline_0034
      00B5BB A3               [24] 1491 	inc	dptr
      00B5BC E0               [24] 1492 	movx	a,@dptr
      00B5BD F5 82            [12] 1493 	mov	dpl,a
      00B5BF C0 06            [24] 1494 	push	ar6
      00B5C1 C0 05            [24] 1495 	push	ar5
      00B5C3 12 55 B2         [24] 1496 	lcall	_rgb_matrix_set_speed_noeeprom
      00B5C6 D0 05            [24] 1497 	pop	ar5
      00B5C8 D0 06            [24] 1498 	pop	ar6
                                   1499 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00B5CA 12 B5 FF         [24] 1500 	lcall	_ak820_outline_0034
      00B5CD A3               [24] 1501 	inc	dptr
      00B5CE A3               [24] 1502 	inc	dptr
      00B5CF E0               [24] 1503 	movx	a,@dptr
      00B5D0 F9               [12] 1504 	mov	r1,a
      00B5D1 7A 00            [12] 1505 	mov	r2,#0x00
      00B5D3 74 06            [12] 1506 	mov	a,#0x06
      00B5D5 12 B6 51         [24] 1507 	lcall	_ak820_outline_0169
      00B5D8 F8               [12] 1508 	mov	r0,a
      00B5D9 74 07            [12] 1509 	mov	a,#0x07
      00B5DB 12 B6 51         [24] 1510 	lcall	_ak820_outline_0169
      00B5DE FE               [12] 1511 	mov	r6,a
      00B5DF 90 07 2C         [24] 1512 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00B5E2 E8               [12] 1513 	mov	a,r0
      00B5E3 F0               [24] 1514 	movx	@dptr,a
      00B5E4 90 07 2D         [24] 1515 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00B5E7 EE               [12] 1516 	mov	a,r6
      00B5E8 F0               [24] 1517 	movx	@dptr,a
      00B5E9 12 43 57         [24] 1518 	lcall	_ak820_outline_0180
                                   1519 ;	quantum/vialrgb.c:202: break;
                                   1520 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00B5EC 02 55 83         [24] 1521 	ljmp	_rgb_matrix_sethsv_noeeprom
      00B5EF                       1522 00104$:
                                   1523 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00B5EF EF               [12] 1524 	mov	a,r7
      00B5F0 24 FE            [12] 1525 	add	a,#0xfe
      00B5F2 90 0D 62         [24] 1526 	mov	dptr,#_fast_set_leds_PARM_2
      00B5F5 F0               [24] 1527 	movx	@dptr,a
      00B5F6 12 33 FC         [24] 1528 	lcall	_ak820_outline_0122
                                   1529 ;	quantum/vialrgb.c:210: }
                                   1530 ;	quantum/vialrgb.c:211: }
      00B5F9 02 B2 C1         [24] 1531 	ljmp	_fast_set_leds
                                   1532 ;------------------------------------------------------------
                                   1533 ;Allocation info for local variables in function 'vialrgb_save'
                                   1534 ;------------------------------------------------------------
                                   1535 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1536 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1537 ;------------------------------------------------------------
                                   1538 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1539 ;	-----------------------------------------
                                   1540 ;	 function vialrgb_save
                                   1541 ;	-----------------------------------------
      00B5FC                       1542 _vialrgb_save:
                                   1543 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1544 ;	quantum/vialrgb.c:218: }
      00B5FC 02 50 0A         [24] 1545 	ljmp	_eeconfig_update_rgb_matrix
                                   1546 	.area CSEG    (CODE)
                                   1547 	.area CONST   (CODE)
                                   1548 	.area CONST   (CODE)
      00BDFC                       1549 _supported_modes:
      00BDFC 00                    1550 	.db #0x00	; 0
      00BDFD 00                    1551 	.db #0x00	; 0
      00BDFE 01                    1552 	.db #0x01	; 1
      00BDFF 05                    1553 	.db #0x05	; 5
      00BE00 02                    1554 	.db #0x02	; 2
      00BE01 01                    1555 	.db #0x01	; 1
      00BE02 06                    1556 	.db #0x06	; 6
      00BE03 02                    1557 	.db #0x02	; 2
      00BE04 0D                    1558 	.db #0x0d	; 13
      00BE05 03                    1559 	.db #0x03	; 3
      00BE06 0E                    1560 	.db #0x0e	; 14
      00BE07 04                    1561 	.db #0x04	; 4
      00BE08 1F                    1562 	.db #0x1f	; 31
      00BE09 06                    1563 	.db #0x06	; 6
                                   1564 	.area CSEG    (CODE)
                                   1565 	.area XINIT   (CODE)
                                   1566 	.area CABS    (ABS,CODE)
                                   1567 
                                   1568 ; Experimental exact instruction outlining.
                                   1569 	.globl _ak820_outline_0004
                                   1570 	.globl _ak820_outline_0015
                                   1571 	.globl _ak820_outline_0030
                                   1572 	.globl _ak820_outline_0034
                                   1573 	.globl _ak820_outline_0035
                                   1574 	.globl _ak820_outline_0036
                                   1575 	.globl _ak820_outline_0042
                                   1576 	.globl _ak820_outline_0044
                                   1577 	.globl _ak820_outline_0050
                                   1578 	.globl _ak820_outline_0056
                                   1579 	.globl _ak820_outline_0063
                                   1580 	.globl _ak820_outline_0064
                                   1581 	.globl _ak820_outline_0075
                                   1582 	.globl _ak820_outline_0080
                                   1583 	.globl _ak820_outline_0096
                                   1584 	.globl _ak820_outline_0100
                                   1585 	.globl _ak820_outline_0103
                                   1586 	.globl _ak820_outline_0104
                                   1587 	.globl _ak820_outline_0105
                                   1588 	.globl _ak820_outline_0106
                                   1589 	.globl _ak820_outline_0109
                                   1590 	.globl _ak820_outline_0117
                                   1591 	.globl _ak820_outline_0119
                                   1592 	.globl _ak820_outline_0122
                                   1593 	.globl _ak820_outline_0131
                                   1594 	.globl _ak820_outline_0133
                                   1595 	.globl _ak820_outline_0139
                                   1596 	.globl _ak820_outline_0141
                                   1597 	.globl _ak820_outline_0152
                                   1598 	.globl _ak820_outline_0157
                                   1599 	.globl _ak820_outline_0168
                                   1600 	.globl _ak820_outline_0169
                                   1601 	.globl _ak820_outline_0180
                                   1602 
                                   1603 	.area CSEG (CODE)
                                   1604 ; function ak820_outline_0034
      00B5FF                       1605 _ak820_outline_0034:
      00B5FF 8D 82            [24] 1606 	mov	dpl,r5
      00B601 8E 83            [24] 1607 	mov	dph,r6
      00B603 A3               [24] 1608 	inc	dptr
      00B604 A3               [24] 1609 	inc	dptr
      00B605 A3               [24] 1610 	inc	dptr
      00B606 22               [24] 1611 	ret
                                   1612 
                                   1613 	.area CSEG (CODE)
                                   1614 ; function ak820_outline_0042
      00B607                       1615 _ak820_outline_0042:
      00B607 E0               [24] 1616 	movx	a,@dptr
      00B608 FD               [12] 1617 	mov	r5,a
      00B609 A3               [24] 1618 	inc	dptr
      00B60A E0               [24] 1619 	movx	a,@dptr
      00B60B FE               [12] 1620 	mov	r6,a
      00B60C 74 02            [12] 1621 	mov	a,#0x02
      00B60E 2D               [12] 1622 	add	a,r5
      00B60F FB               [12] 1623 	mov	r3,a
      00B610 E4               [12] 1624 	clr	a
      00B611 3E               [12] 1625 	addc	a,r6
      00B612 FC               [12] 1626 	mov	r4,a
      00B613 8D 82            [24] 1627 	mov	dpl,r5
      00B615 8E 83            [24] 1628 	mov	dph,r6
      00B617 A3               [24] 1629 	inc	dptr
      00B618 E0               [24] 1630 	movx	a,@dptr
      00B619 FA               [12] 1631 	mov	r2,a
      00B61A 22               [24] 1632 	ret
                                   1633 
                                   1634 	.area CSEG (CODE)
                                   1635 ; function ak820_outline_0044
      00B61B                       1636 _ak820_outline_0044:
      00B61B ED               [12] 1637 	mov	a,r5
      00B61C 75 F0 02         [24] 1638 	mov	b,#0x02
      00B61F A4               [48] 1639 	mul	ab
      00B620 24 FC            [12] 1640 	add	a,#_supported_modes
      00B622 FB               [12] 1641 	mov	r3,a
      00B623 74 BD            [12] 1642 	mov	a,#(_supported_modes>>8)
      00B625 35 F0            [12] 1643 	addc	a,b
      00B627 FC               [12] 1644 	mov	r4,a
      00B628 8B 82            [24] 1645 	mov	dpl,r3
      00B62A 8C 83            [24] 1646 	mov	dph,r4
      00B62C 22               [24] 1647 	ret
                                   1648 
                                   1649 	.area CSEG (CODE)
                                   1650 ; function ak820_outline_0080
      00B62D                       1651 _ak820_outline_0080:
      00B62D 90 0D 63         [24] 1652 	mov	dptr,#_fast_set_leds_args_10000_282
      00B630 E0               [24] 1653 	movx	a,@dptr
      00B631 F9               [12] 1654 	mov	r1,a
      00B632 A3               [24] 1655 	inc	dptr
      00B633 E0               [24] 1656 	movx	a,@dptr
      00B634 FF               [12] 1657 	mov	r7,a
      00B635 89 82            [24] 1658 	mov	dpl,r1
      00B637 8F 83            [24] 1659 	mov	dph,r7
      00B639 E0               [24] 1660 	movx	a,@dptr
      00B63A 22               [24] 1661 	ret
                                   1662 
                                   1663 	.area CSEG (CODE)
                                   1664 ; function ak820_outline_0103
      00B63B                       1665 _ak820_outline_0103:
      00B63B 90 0D 63         [24] 1666 	mov	dptr,#_fast_set_leds_args_10000_282
      00B63E 74 01            [12] 1667 	mov	a,#0x01
      00B640 29               [12] 1668 	add	a,r1
      00B641 F0               [24] 1669 	movx	@dptr,a
      00B642 E4               [12] 1670 	clr	a
      00B643 3F               [12] 1671 	addc	a,r7
      00B644 A3               [24] 1672 	inc	dptr
      00B645 F0               [24] 1673 	movx	@dptr,a
      00B646 22               [24] 1674 	ret
                                   1675 
                                   1676 	.area CSEG (CODE)
                                   1677 ; function ak820_outline_0141
      00B647                       1678 _ak820_outline_0141:
      00B647 E4               [12] 1679 	clr	a
      00B648 93               [24] 1680 	movc	a,@a+dptr
      00B649 FC               [12] 1681 	mov	r4,a
      00B64A 7B 00            [12] 1682 	mov	r3,#0x00
      00B64C 8C 82            [24] 1683 	mov	dpl,r4
      00B64E 8B 83            [24] 1684 	mov	dph,r3
      00B650 22               [24] 1685 	ret
                                   1686 
                                   1687 	.area CSEG (CODE)
                                   1688 ; function ak820_outline_0169
      00B651                       1689 _ak820_outline_0169:
      00B651 2D               [12] 1690 	add	a,r5
      00B652 F5 82            [12] 1691 	mov	dpl,a
      00B654 E4               [12] 1692 	clr	a
      00B655 3E               [12] 1693 	addc	a,r6
      00B656 F5 83            [12] 1694 	mov	dph,a
      00B658 E0               [24] 1695 	movx	a,@dptr
      00B659 22               [24] 1696 	ret
