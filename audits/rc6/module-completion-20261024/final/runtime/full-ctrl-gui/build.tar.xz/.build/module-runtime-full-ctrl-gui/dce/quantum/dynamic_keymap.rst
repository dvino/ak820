                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000025                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000025                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000AD1                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AD1                        628 	.ds 1
      000AD2                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AD2                        630 	.ds 1
      000AD3                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_365:
      000AD3                        632 	.ds 1
      000AD4                        633 _dynamic_keymap_get_keycode_PARM_2:
      000AD4                        634 	.ds 1
      000AD5                        635 _dynamic_keymap_get_keycode_PARM_3:
      000AD5                        636 	.ds 1
      000AD6                        637 _dynamic_keymap_get_keycode_layer_10000_367:
      000AD6                        638 	.ds 1
      000AD7                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AD7                        640 	.ds 1
      000AD8                        641 _dynamic_keymap_set_keycode_PARM_3:
      000AD8                        642 	.ds 1
      000AD9                        643 _dynamic_keymap_set_keycode_PARM_4:
      000AD9                        644 	.ds 2
      000ADB                        645 _dynamic_keymap_set_keycode_layer_10000_371:
      000ADB                        646 	.ds 1
      000ADC                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000ADC                        648 	.ds 1
      000ADD                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_375:
      000ADD                        650 	.ds 1
      000ADE                        651 _dynamic_keymap_get_encoder_PARM_2:
      000ADE                        652 	.ds 1
      000ADF                        653 _dynamic_keymap_get_encoder_PARM_3:
      000ADF                        654 	.ds 1
      000AE0                        655 _dynamic_keymap_get_encoder_layer_10000_377:
      000AE0                        656 	.ds 1
      000AE1                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AE1                        658 	.ds 1
      000AE2                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AE2                        660 	.ds 1
      000AE3                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AE3                        662 	.ds 2
      000AE5                        663 _dynamic_keymap_set_encoder_layer_10000_381:
      000AE5                        664 	.ds 1
      000AE6                        665 _dynamic_keymap_get_combo_PARM_2:
      000AE6                        666 	.ds 3
      000AE9                        667 _dynamic_keymap_get_combo_index_10000_385:
      000AE9                        668 	.ds 1
      000AEA                        669 _dynamic_keymap_set_combo_PARM_2:
      000AEA                        670 	.ds 3
      000AED                        671 _dynamic_keymap_set_combo_index_10000_391:
      000AED                        672 	.ds 1
      000AEE                        673 _dynamic_keymap_set_combo_stored_10002_396:
      000AEE                        674 	.ds 10
      000AF8                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_399:
      000AF8                        676 	.ds 1
      000AF9                        677 _dynamic_keymap_reset_combo_10001_408:
      000AF9                        678 	.ds 10
      000B03                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B03                        680 	.ds 2
      000B05                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B05                        682 	.ds 2
      000B07                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B07                        684 	.ds 2
      000B09                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B09                        686 	.ds 3
      000B0C                        687 _ak820_dynamic_read_buffer_base_10000_410:
      000B0C                        688 	.ds 2
      000B0E                        689 _ak820_dynamic_read_buffer_available_10000_411:
      000B0E                        690 	.ds 1
      000B0F                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B0F                        692 	.ds 2
      000B11                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B11                        694 	.ds 3
      000B14                        695 _dynamic_keymap_get_buffer_offset_10000_417:
      000B14                        696 	.ds 2
      000B16                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B16                        698 	.ds 2
      000B18                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B18                        700 	.ds 3
      000B1B                        701 _dynamic_keymap_set_buffer_offset_10000_419:
      000B1B                        702 	.ds 2
      000B1D                        703 _dynamic_keymap_set_buffer_chk_offset_30001_426:
      000B1D                        704 	.ds 1
      000B1E                        705 _dynamic_keymap_set_buffer_chk_sz_30001_426:
      000B1E                        706 	.ds 1
      000B1F                        707 _dynamic_keymap_set_buffer_i_40001_433:
      000B1F                        708 	.ds 1
      000B20                        709 _keycode_at_keymap_location_PARM_2:
      000B20                        710 	.ds 1
      000B21                        711 _keycode_at_keymap_location_PARM_3:
      000B21                        712 	.ds 1
      000B22                        713 _keycode_at_keymap_location_layer_num_10000_437:
      000B22                        714 	.ds 1
      000B23                        715 _keycode_at_encodermap_location_PARM_2:
      000B23                        716 	.ds 1
      000B24                        717 _keycode_at_encodermap_location_PARM_3:
      000B24                        718 	.ds 1
      000B25                        719 _keycode_at_encodermap_location_layer_num_10000_441:
      000B25                        720 	.ds 1
      000B26                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B26                        722 	.ds 2
      000B28                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B28                        724 	.ds 3
      000B2B                        725 _dynamic_keymap_macro_get_buffer_offset_10000_449:
      000B2B                        726 	.ds 2
      000B2D                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B2D                        728 	.ds 2
      000B2F                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B2F                        730 	.ds 3
      000B32                        731 _dynamic_keymap_macro_set_buffer_offset_10000_451:
      000B32                        732 	.ds 2
      000B34                        733 _decode_keycode_kc_10000_455:
      000B34                        734 	.ds 2
      000B36                        735 _dynamic_keymap_macro_send_id_10000_458:
      000B36                        736 	.ds 1
      000B37                        737 _dynamic_keymap_macro_send_sending_10000_459:
      000B37                        738 	.ds 1
      000B38                        739 _dynamic_keymap_macro_send_p_10001_464:
      000B38                        740 	.ds 2
      000B3A                        741 _dynamic_keymap_macro_send_data_10003_471:
      000B3A                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      00838F                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      00838F 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      008392 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_365'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008393                        810 _dynamic_keymap_key_to_eeprom_address:
      008393 E5 82            [12]  811 	mov	a,dpl
      008395 90 0A D3         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_365
      008398 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008399 E0               [24]  815 	movx	a,@dptr
      00839A FF               [12]  816 	mov	r7,a
      00839B 7E 00            [12]  817 	mov	r6,#0x00
      00839D 74 40            [12]  818 	mov	a,#0x40
      00839F 12 43 30         [24]  819 	lcall	_ak820_outline_0134
      0083A2 7D 00            [12]  820 	mov	r5,#0x00
      0083A4 90 0A D1         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0083A7 E0               [24]  822 	movx	a,@dptr
      0083A8 75 F0 10         [24]  823 	mov	b,#0x10
      0083AB A4               [48]  824 	mul	ab
      0083AC 2E               [12]  825 	add	a, r6
      0083AD FE               [12]  826 	mov	r6,a
      0083AE EF               [12]  827 	mov	a,r7
      0083AF 35 F0            [12]  828 	addc	a, b
      0083B1 FF               [12]  829 	mov	r7,a
      0083B2 90 0A D2         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0083B5 E0               [24]  831 	movx	a,@dptr
      0083B6 7C 00            [12]  832 	mov	r4,#0x00
      0083B8 25 E0            [12]  833 	add	a,acc
      0083BA FB               [12]  834 	mov	r3,a
      0083BB EC               [12]  835 	mov	a,r4
      0083BC 33               [12]  836 	rlc	a
      0083BD FC               [12]  837 	mov	r4,a
      0083BE EB               [12]  838 	mov	a,r3
      0083BF 2E               [12]  839 	add	a, r6
      0083C0 FE               [12]  840 	mov	r6,a
      0083C1 EC               [12]  841 	mov	a,r4
      0083C2 3F               [12]  842 	addc	a, r7
      0083C3 FF               [12]  843 	mov	r7,a
      0083C4 12 43 20         [24]  844 	lcall	_ak820_outline_0117
      0083C7 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      0083C9 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_367'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_370'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_370'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      0083CA                        861 _dynamic_keymap_get_keycode:
      0083CA E5 82            [12]  862 	mov	a,dpl
      0083CC 90 0A D6         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_367
      0083CF F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0083D0 E0               [24]  866 	movx	a,@dptr
      0083D1 FF               [12]  867 	mov	r7,a
      0083D2 BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      0083D5                        869 00121$:
      0083D5 50 14            [24]  870 	jnc	00101$
      0083D7 90 0A D4         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0083DA E0               [24]  872 	movx	a,@dptr
      0083DB FE               [12]  873 	mov	r6,a
      0083DC BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      0083DF                        875 00123$:
      0083DF 50 0A            [24]  876 	jnc	00101$
      0083E1 90 0A D5         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0083E4 E0               [24]  878 	movx	a,@dptr
      0083E5 FD               [12]  879 	mov	r5,a
      0083E6 BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      0083E9                        881 00125$:
      0083E9 40 04            [24]  882 	jc	00102$
      0083EB                        883 00101$:
      0083EB 90 00 00         [24]  884 	mov	dptr,#0x0000
      0083EE 22               [24]  885 	ret
      0083EF                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0083EF 12 8E 41         [24]  888 	lcall	_ak820_outline_0094
      0083F2 12 83 93         [24]  889 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      0083F5 12 8E 4E         [24]  891 	lcall	_ak820_outline_0113
      0083F8 12 40 3F         [24]  892 	lcall	_eeprom_read_byte
      0083FB AB 82            [24]  893 	mov	r3,dpl
      0083FD 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      0083FF 0D               [12]  896 	inc	r5
      008400 BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      008403 0E               [12]  898 	inc	r6
      008404                        899 00127$:
      008404 12 4E D0         [24]  900 	lcall	_ak820_outline_0043
      008407 12 40 3F         [24]  901 	lcall	_eeprom_read_byte
      00840A AF 82            [24]  902 	mov	r7, dpl
      00840C 7E 00            [12]  903 	mov	r6,#0x00
      00840E EF               [12]  904 	mov	a,r7
      00840F 42 04            [12]  905 	orl	ar4,a
      008411 EE               [12]  906 	mov	a,r6
      008412 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      008414 12 43 5C         [24]  909 	lcall	_ak820_outline_0181
                                    910 ;	quantum/dynamic_keymap.c:215: }
      008417 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_371'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_374'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      008418                        925 _dynamic_keymap_set_keycode:
      008418 E5 82            [12]  926 	mov	a,dpl
      00841A 90 0A DB         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_371
      00841D F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      00841E E0               [24]  930 	movx	a,@dptr
      00841F FF               [12]  931 	mov	r7,a
      008420 BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      008423                        933 00121$:
      008423 50 14            [24]  934 	jnc	00101$
      008425 90 0A D7         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008428 E0               [24]  936 	movx	a,@dptr
      008429 FE               [12]  937 	mov	r6,a
      00842A BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      00842D                        939 00123$:
      00842D 50 0A            [24]  940 	jnc	00101$
      00842F 90 0A D8         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008432 E0               [24]  942 	movx	a,@dptr
      008433 FD               [12]  943 	mov	r5,a
      008434 BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      008437                        945 00125$:
      008437 40 01            [24]  946 	jc	00102$
      008439                        947 00101$:
      008439 22               [24]  948 	ret
      00843A                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00843A 12 8E 41         [24]  951 	lcall	_ak820_outline_0094
      00843D 12 83 93         [24]  952 	lcall	_dynamic_keymap_key_to_eeprom_address
      008440 12 8E 4E         [24]  953 	lcall	_ak820_outline_0113
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008443 90 0A D9         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008446 E0               [24]  956 	movx	a,@dptr
      008447 FB               [12]  957 	mov	r3,a
      008448 A3               [24]  958 	inc	dptr
      008449 E0               [24]  959 	movx	a,@dptr
      00844A 90 06 97         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      00844D F0               [24]  961 	movx	@dptr,a
      00844E 12 4E D0         [24]  962 	lcall	_ak820_outline_0043
      008451 12 4D BA         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008454 0D               [12]  965 	inc	r5
      008455 BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      008458 0E               [12]  967 	inc	r6
      008459                        968 00127$:
      008459 90 06 97         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      00845C EB               [12]  970 	mov	a,r3
      00845D F0               [24]  971 	movx	@dptr,a
      00845E 12 4E D0         [24]  972 	lcall	_ak820_outline_0043
                                    973 ;	quantum/dynamic_keymap.c:223: }
      008461 02 4D BA         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      008464                        985 _dynamic_keymap_encoder_to_eeprom_address:
      008464 E5 82            [12]  986 	mov	a,dpl
      008466 90 0A DD         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375
      008469 F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      00846A E0               [24]  990 	movx	a,@dptr
      00846B 75 F0 04         [24]  991 	mov	b,#0x04
      00846E A4               [48]  992 	mul	ab
      00846F 24 40            [12]  993 	add	a, #0x40
      008471 FD               [12]  994 	mov	r5,a
      008472 74 06            [12]  995 	mov	a,#0x06
      008474 35 F0            [12]  996 	addc	a, b
      008476 FE               [12]  997 	mov	r6,a
      008477 7F 00            [12]  998 	mov	r7,#0x00
      008479 90 0A DC         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00847C E0               [24] 1000 	movx	a,@dptr
      00847D 75 F0 04         [24] 1001 	mov	b,#0x04
      008480 A4               [48] 1002 	mul	ab
      008481 2D               [12] 1003 	add	a, r5
      008482 FD               [12] 1004 	mov	r5,a
      008483 EE               [12] 1005 	mov	a,r6
      008484 35 F0            [12] 1006 	addc	a, b
      008486 FE               [12] 1007 	mov	r6,a
      008487 12 4E D0         [24] 1008 	lcall	_ak820_outline_0043
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      00848A 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_377'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_380'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_380'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      00848B                       1024 _dynamic_keymap_get_encoder:
      00848B E5 82            [12] 1025 	mov	a,dpl
      00848D 90 0A E0         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_377
      008490 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008491 E0               [24] 1029 	movx	a,@dptr
      008492 FF               [12] 1030 	mov	r7,a
      008493 BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      008496                       1032 00131$:
      008496 50 0A            [24] 1033 	jnc	00101$
      008498 90 0A DE         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00849B E0               [24] 1035 	movx	a,@dptr
      00849C FE               [12] 1036 	mov	r6,a
      00849D BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      0084A0                       1038 00133$:
      0084A0 40 04            [24] 1039 	jc	00102$
      0084A2                       1040 00101$:
      0084A2 90 00 00         [24] 1041 	mov	dptr,#0x0000
      0084A5 22               [24] 1042 	ret
      0084A6                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0084A6 90 0A DC         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0084A9 E4               [12] 1046 	clr	a
      0084AA F0               [24] 1047 	movx	@dptr,a
      0084AB 8F 82            [24] 1048 	mov	dpl, r7
      0084AD 12 84 64         [24] 1049 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0084B0 12 8E 4E         [24] 1050 	lcall	_ak820_outline_0113
                                   1051 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      0084B3 90 0A DF         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0084B6 E0               [24] 1053 	movx	a,@dptr
      0084B7 FC               [12] 1054 	mov	r4,a
      0084B8 E0               [24] 1055 	movx	a,@dptr
      0084B9 60 04            [24] 1056 	jz	00106$
      0084BB 7B 00            [12] 1057 	mov	r3,#0x00
      0084BD 80 02            [24] 1058 	sjmp	00107$
      0084BF                       1059 00106$:
      0084BF 7B 02            [12] 1060 	mov	r3,#0x02
      0084C1                       1061 00107$:
      0084C1 EB               [12] 1062 	mov	a,r3
      0084C2 12 8E 1F         [24] 1063 	lcall	_ak820_outline_0024
      0084C5 12 40 3F         [24] 1064 	lcall	_eeprom_read_byte
      0084C8 AA 82            [24] 1065 	mov	r2,dpl
      0084CA 7B 00            [12] 1066 	mov	r3,#0x00
                                   1067 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0084CC EC               [12] 1068 	mov	a,r4
      0084CD 60 04            [24] 1069 	jz	00108$
      0084CF 7C 00            [12] 1070 	mov	r4,#0x00
      0084D1 80 02            [24] 1071 	sjmp	00109$
      0084D3                       1072 00108$:
      0084D3 7C 02            [12] 1073 	mov	r4,#0x02
      0084D5                       1074 00109$:
      0084D5 EC               [12] 1075 	mov	a,r4
      0084D6 12 38 7A         [24] 1076 	lcall	_ak820_outline_0155
      0084D9 0D               [12] 1077 	inc	r5
      0084DA BD 00 01         [24] 1078 	cjne	r5,#0x00,00137$
      0084DD 0E               [12] 1079 	inc	r6
      0084DE                       1080 00137$:
      0084DE 12 4E D0         [24] 1081 	lcall	_ak820_outline_0043
      0084E1 12 40 3F         [24] 1082 	lcall	_eeprom_read_byte
      0084E4 AF 82            [24] 1083 	mov	r7, dpl
      0084E6 7E 00            [12] 1084 	mov	r6,#0x00
      0084E8 EF               [12] 1085 	mov	a,r7
      0084E9 42 03            [12] 1086 	orl	ar3,a
      0084EB EE               [12] 1087 	mov	a,r6
      0084EC 42 02            [12] 1088 	orl	ar2,a
                                   1089 ;	quantum/dynamic_keymap.c:236: return keycode;
      0084EE 8B 82            [24] 1090 	mov	dpl, r3
      0084F0 8A 83            [24] 1091 	mov	dph, r2
                                   1092 ;	quantum/dynamic_keymap.c:237: }
      0084F2 22               [24] 1093 	ret
                                   1094 ;------------------------------------------------------------
                                   1095 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1096 ;------------------------------------------------------------
                                   1097 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1098 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1099 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1100 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1101 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_381'
                                   1102 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_384'
                                   1103 ;------------------------------------------------------------
                                   1104 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1105 ;	-----------------------------------------
                                   1106 ;	 function dynamic_keymap_set_encoder
                                   1107 ;	-----------------------------------------
      0084F3                       1108 _dynamic_keymap_set_encoder:
      0084F3 E5 82            [12] 1109 	mov	a,dpl
      0084F5 90 0A E5         [24] 1110 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_381
      0084F8 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      0084F9 E0               [24] 1113 	movx	a,@dptr
      0084FA FF               [12] 1114 	mov	r7,a
      0084FB BF 06 00         [24] 1115 	cjne	r7,#0x06,00131$
      0084FE                       1116 00131$:
      0084FE 50 0A            [24] 1117 	jnc	00101$
      008500 90 0A E1         [24] 1118 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008503 E0               [24] 1119 	movx	a,@dptr
      008504 FE               [12] 1120 	mov	r6,a
      008505 BE 01 00         [24] 1121 	cjne	r6,#0x01,00133$
      008508                       1122 00133$:
      008508 40 01            [24] 1123 	jc	00102$
      00850A                       1124 00101$:
      00850A 22               [24] 1125 	ret
      00850B                       1126 00102$:
                                   1127 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00850B 90 0A DC         [24] 1128 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00850E E4               [12] 1129 	clr	a
      00850F F0               [24] 1130 	movx	@dptr,a
      008510 8F 82            [24] 1131 	mov	dpl, r7
      008512 12 84 64         [24] 1132 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008515 12 8E 4E         [24] 1133 	lcall	_ak820_outline_0113
                                   1134 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008518 90 0A E2         [24] 1135 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00851B E0               [24] 1136 	movx	a,@dptr
      00851C FC               [12] 1137 	mov	r4,a
      00851D E0               [24] 1138 	movx	a,@dptr
      00851E 60 04            [24] 1139 	jz	00106$
      008520 7B 00            [12] 1140 	mov	r3,#0x00
      008522 80 02            [24] 1141 	sjmp	00107$
      008524                       1142 00106$:
      008524 7B 02            [12] 1143 	mov	r3,#0x02
      008526                       1144 00107$:
      008526 EB               [12] 1145 	mov	a,r3
      008527 12 8E 60         [24] 1146 	lcall	_ak820_outline_0133
      00852A 8F 03            [24] 1147 	mov	ar3,r7
      00852C 90 0A E3         [24] 1148 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00852F E0               [24] 1149 	movx	a,@dptr
      008530 F5 29            [12] 1150 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008532 A3               [24] 1151 	inc	dptr
      008533 E0               [24] 1152 	movx	a,@dptr
      008534 F5 2A            [12] 1153 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008536 90 06 97         [24] 1154 	mov	dptr,#_eeprom_update_byte_PARM_2
      008539 F0               [24] 1155 	movx	@dptr,a
      00853A 12 43 57         [24] 1156 	lcall	_ak820_outline_0180
      00853D 8B F0            [24] 1157 	mov	b, r3
      00853F 12 4D BA         [24] 1158 	lcall	_eeprom_update_byte
                                   1159 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008542 EC               [12] 1160 	mov	a,r4
      008543 60 04            [24] 1161 	jz	00108$
      008545 7C 00            [12] 1162 	mov	r4,#0x00
      008547 80 02            [24] 1163 	sjmp	00109$
      008549                       1164 00108$:
      008549 7C 02            [12] 1165 	mov	r4,#0x02
      00854B                       1166 00109$:
      00854B EC               [12] 1167 	mov	a,r4
      00854C 12 38 7A         [24] 1168 	lcall	_ak820_outline_0155
      00854F 0D               [12] 1169 	inc	r5
      008550 BD 00 01         [24] 1170 	cjne	r5,#0x00,00137$
      008553 0E               [12] 1171 	inc	r6
      008554                       1172 00137$:
      008554 90 06 97         [24] 1173 	mov	dptr,#_eeprom_update_byte_PARM_2
      008557 E5 29            [12] 1174 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008559 F0               [24] 1175 	movx	@dptr,a
      00855A 12 4E D0         [24] 1176 	lcall	_ak820_outline_0043
                                   1177 ;	quantum/dynamic_keymap.c:245: }
      00855D 02 4D BA         [24] 1178 	ljmp	_eeprom_update_byte
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1183 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1184 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_385'
                                   1185 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_386'
                                   1186 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_388'
                                   1187 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_389'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function dynamic_keymap_get_combo
                                   1192 ;	-----------------------------------------
      008560                       1193 _dynamic_keymap_get_combo:
      008560 E5 82            [12] 1194 	mov	a,dpl
      008562 90 0A E9         [24] 1195 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008565 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008566 90 0A E6         [24] 1198 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008569 12 38 00         [24] 1199 	lcall	_ak820_outline_0050
                                   1200 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      00856C 90 0A E9         [24] 1201 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      00856F E0               [24] 1202 	movx	a,@dptr
      008570 FD               [12] 1203 	mov	r5,a
      008571 BD 08 00         [24] 1204 	cjne	r5,#0x08,00132$
      008574                       1205 00132$:
      008574 40 04            [24] 1206 	jc	00102$
                                   1207 ;	quantum/dynamic_keymap.c:315: return -1;
      008576 90 FF FF         [24] 1208 	mov	dptr,#0xffff
      008579 22               [24] 1209 	ret
      00857A                       1210 00102$:
                                   1211 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00857A 12 8E 2D         [24] 1212 	lcall	_ak820_outline_0077
                                   1213 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      00857D 8E 02            [24] 1214 	mov	ar2,r6
      00857F 8F 03            [24] 1215 	mov	ar3,r7
      008581 90 05 81         [24] 1216 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008584 12 38 25         [24] 1217 	lcall	_ak820_outline_0070
      008587 E4               [12] 1218 	clr	a
      008588 A3               [24] 1219 	inc	dptr
      008589 F0               [24] 1220 	movx	@dptr,a
      00858A 90 05 84         [24] 1221 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00858D 74 0A            [12] 1222 	mov	a,#0x0a
      00858F 12 38 65         [24] 1223 	lcall	_ak820_outline_0123
      008592 12 43 3C         [24] 1224 	lcall	_ak820_outline_0140
      008595 C0 07            [24] 1225 	push	ar7
      008597 C0 06            [24] 1226 	push	ar6
      008599 12 40 7A         [24] 1227 	lcall	_ak820_eeprom_read_block_xdata
      00859C D0 06            [24] 1228 	pop	ar6
      00859E D0 07            [24] 1229 	pop	ar7
                                   1230 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      0085A0 74 04            [12] 1231 	mov	a,#0x04
      0085A2 12 48 1B         [24] 1232 	lcall	_ak820_outline_0011
      0085A5 FA               [12] 1233 	mov	r2,a
      0085A6 A3               [24] 1234 	inc	dptr
      0085A7 E0               [24] 1235 	movx	a,@dptr
      0085A8 FB               [12] 1236 	mov	r3,a
      0085A9 BA 20 14         [24] 1237 	cjne	r2,#0x20,00108$
      0085AC BB 08 11         [24] 1238 	cjne	r3,#0x08,00108$
      0085AF 74 06            [12] 1239 	mov	a,#0x06
      0085B1 12 37 E7         [24] 1240 	lcall	_ak820_outline_0016
      0085B4 FA               [12] 1241 	mov	r2,a
      0085B5 A3               [24] 1242 	inc	dptr
      0085B6 E0               [24] 1243 	movx	a,@dptr
      0085B7 FB               [12] 1244 	mov	r3,a
      0085B8 BA 01 05         [24] 1245 	cjne	r2,#0x01,00136$
      0085BB BB 00 02         [24] 1246 	cjne	r3,#0x00,00136$
      0085BE 80 05            [24] 1247 	sjmp	00109$
      0085C0                       1248 00136$:
      0085C0                       1249 00108$:
      0085C0 75 2B 00         [24] 1250 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      0085C3 80 03            [24] 1251 	sjmp	00110$
      0085C5                       1252 00109$:
      0085C5 75 2B 01         [24] 1253 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      0085C8                       1254 00110$:
                                   1255 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      0085C8 74 06            [12] 1256 	mov	a,#0x06
      0085CA 12 37 F0         [24] 1257 	lcall	_ak820_outline_0030
      0085CD E4               [12] 1258 	clr	a
      0085CE F0               [24] 1259 	movx	@dptr,a
      0085CF A3               [24] 1260 	inc	dptr
      0085D0 12 38 31         [24] 1261 	lcall	_ak820_outline_0095
      0085D3 F0               [24] 1262 	movx	@dptr,a
      0085D4 A3               [24] 1263 	inc	dptr
      0085D5 F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      0085D6 E5 2B            [12] 1266 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      0085D8 60 12            [24] 1267 	jz	00103$
      0085DA 12 43 20         [24] 1268 	lcall	_ak820_outline_0117
      0085DD C0 07            [24] 1269 	push	ar7
      0085DF C0 06            [24] 1270 	push	ar6
      0085E1 12 34 68         [24] 1271 	lcall	_ak820_combo_valid
      0085E4 E5 82            [12] 1272 	mov	a, dpl
      0085E6 D0 06            [24] 1273 	pop	ar6
      0085E8 D0 07            [24] 1274 	pop	ar7
      0085EA 70 17            [24] 1275 	jnz	00104$
      0085EC                       1276 00103$:
      0085EC 7D 00            [12] 1277 	mov	r5,#0x00
      0085EE 90 0D 7B         [24] 1278 	mov	dptr,#_memset_PARM_2
      0085F1 E4               [12] 1279 	clr	a
      0085F2 F0               [24] 1280 	movx	@dptr,a
      0085F3 90 0D 7C         [24] 1281 	mov	dptr,#_memset_PARM_3
      0085F6 74 0A            [12] 1282 	mov	a,#0x0a
      0085F8 F0               [24] 1283 	movx	@dptr,a
      0085F9 E4               [12] 1284 	clr	a
      0085FA A3               [24] 1285 	inc	dptr
      0085FB 12 43 02         [24] 1286 	lcall	_ak820_outline_0060
      0085FE 8D F0            [24] 1287 	mov	b, r5
      008600 12 B7 70         [24] 1288 	lcall	_memset
      008603                       1289 00104$:
                                   1290 ;	quantum/dynamic_keymap.c:329: return 0;
      008603 90 00 00         [24] 1291 	mov	dptr,#0x0000
                                   1292 ;	quantum/dynamic_keymap.c:330: }
      008606 22               [24] 1293 	ret
                                   1294 ;------------------------------------------------------------
                                   1295 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1296 ;------------------------------------------------------------
                                   1297 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1298 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_391'
                                   1299 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_392'
                                   1300 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_395'
                                   1301 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_396'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1304 ;	-----------------------------------------
                                   1305 ;	 function dynamic_keymap_set_combo
                                   1306 ;	-----------------------------------------
      008607                       1307 _dynamic_keymap_set_combo:
      008607 E5 82            [12] 1308 	mov	a,dpl
      008609 90 0A ED         [24] 1309 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      00860C F0               [24] 1310 	movx	@dptr,a
                                   1311 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      00860D 90 0A EA         [24] 1312 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008610 12 37 A0         [24] 1313 	lcall	_ak820_outline_0004
                                   1314 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008613 C0 07            [24] 1315 	push	ar7
      008615 C0 06            [24] 1316 	push	ar6
      008617 12 34 68         [24] 1317 	lcall	_ak820_combo_valid
      00861A E5 82            [12] 1318 	mov	a, dpl
      00861C D0 06            [24] 1319 	pop	ar6
      00861E D0 07            [24] 1320 	pop	ar7
      008620 60 07            [24] 1321 	jz	00101$
      008622 12 3D E5         [24] 1322 	lcall	_ak820_nvm_ok
      008625 E5 82            [12] 1323 	mov	a, dpl
      008627 70 04            [24] 1324 	jnz	00102$
      008629                       1325 00101$:
      008629 90 FF FF         [24] 1326 	mov	dptr,#0xffff
      00862C 22               [24] 1327 	ret
      00862D                       1328 00102$:
                                   1329 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      00862D 90 0A ED         [24] 1330 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008630 E0               [24] 1331 	movx	a,@dptr
      008631 FD               [12] 1332 	mov	r5,a
      008632 BD 08 00         [24] 1333 	cjne	r5,#0x08,00133$
      008635                       1334 00133$:
      008635 40 04            [24] 1335 	jc	00105$
                                   1336 ;	quantum/dynamic_keymap.c:342: return -1;
      008637 90 FF FF         [24] 1337 	mov	dptr,#0xffff
      00863A 22               [24] 1338 	ret
      00863B                       1339 00105$:
                                   1340 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00863B 12 8E 2D         [24] 1341 	lcall	_ak820_outline_0077
                                   1342 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      00863E C0 07            [24] 1343 	push	ar7
      008640 C0 06            [24] 1344 	push	ar6
      008642 C0 05            [24] 1345 	push	ar5
      008644 C0 04            [24] 1346 	push	ar4
      008646 12 75 EB         [24] 1347 	lcall	_clear_keyboard
      008649 D0 04            [24] 1348 	pop	ar4
      00864B D0 05            [24] 1349 	pop	ar5
      00864D D0 06            [24] 1350 	pop	ar6
      00864F D0 07            [24] 1351 	pop	ar7
                                   1352 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008651 90 0D 73         [24] 1353 	mov	dptr,#___memcpy_PARM_2
      008654 12 48 74         [24] 1354 	lcall	_ak820_outline_0058
      008657 E4               [12] 1355 	clr	a
      008658 A3               [24] 1356 	inc	dptr
      008659 F0               [24] 1357 	movx	@dptr,a
      00865A 90 0D 76         [24] 1358 	mov	dptr,#___memcpy_PARM_3
      00865D 74 0A            [12] 1359 	mov	a,#0x0a
      00865F 12 38 65         [24] 1360 	lcall	_ak820_outline_0123
      008662 90 0A EE         [24] 1361 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008665 F5 F0            [12] 1362 	mov	b,a
      008667 C0 05            [24] 1363 	push	ar5
      008669 C0 04            [24] 1364 	push	ar4
      00866B 12 B6 FA         [24] 1365 	lcall	___memcpy
      00866E D0 04            [24] 1366 	pop	ar4
      008670 D0 05            [24] 1367 	pop	ar5
                                   1368 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008672 90 0A F2         [24] 1369 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0004)
      008675 74 20            [12] 1370 	mov	a,#0x20
      008677 F0               [24] 1371 	movx	@dptr,a
      008678 74 08            [12] 1372 	mov	a,#0x08
      00867A A3               [24] 1373 	inc	dptr
      00867B F0               [24] 1374 	movx	@dptr,a
                                   1375 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      00867C 90 0A F4         [24] 1376 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0006)
      00867F 74 01            [12] 1377 	mov	a,#0x01
      008681 12 38 65         [24] 1378 	lcall	_ak820_outline_0123
                                   1379 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008684 90 05 8A         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008687 12 38 25         [24] 1381 	lcall	_ak820_outline_0070
      00868A E4               [12] 1382 	clr	a
      00868B A3               [24] 1383 	inc	dptr
      00868C F0               [24] 1384 	movx	@dptr,a
      00868D 90 05 8D         [24] 1385 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008690 74 0A            [12] 1386 	mov	a,#0x0a
      008692 12 38 65         [24] 1387 	lcall	_ak820_outline_0123
      008695 90 0A EE         [24] 1388 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008698 12 41 06         [24] 1389 	lcall	_ak820_eeprom_write_block_xdata
                                   1390 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      00869B 12 3D F4         [24] 1391 	lcall	_ak820_nvm_flush
                                   1392 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      00869E 12 3D E5         [24] 1393 	lcall	_ak820_nvm_ok
      0086A1 E5 82            [12] 1394 	mov	a, dpl
      0086A3 70 04            [24] 1395 	jnz	00107$
      0086A5 90 FF FF         [24] 1396 	mov	dptr,#0xffff
      0086A8 22               [24] 1397 	ret
      0086A9                       1398 00107$:
                                   1399 ;	quantum/dynamic_keymap.c:360: return 0;
      0086A9 90 00 00         [24] 1400 	mov	dptr,#0x0000
                                   1401 ;	quantum/dynamic_keymap.c:361: }
      0086AC 22               [24] 1402 	ret
                                   1403 ;------------------------------------------------------------
                                   1404 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1405 ;------------------------------------------------------------
                                   1406 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_399'
                                   1407 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_400'
                                   1408 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_402'
                                   1409 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_404'
                                   1410 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_406'
                                   1411 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_408'
                                   1412 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_409'
                                   1413 ;------------------------------------------------------------
                                   1414 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1415 ;	-----------------------------------------
                                   1416 ;	 function dynamic_keymap_reset
                                   1417 ;	-----------------------------------------
      0086AD                       1418 _dynamic_keymap_reset:
                                   1419 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      0086AD 90 0D F3         [24] 1420 	mov	dptr,#_vial_unlocked
      0086B0 E0               [24] 1421 	movx	a,@dptr
      0086B1 90 0A F8         [24] 1422 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      0086B4 F0               [24] 1423 	movx	@dptr,a
                                   1424 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      0086B5 90 0D F3         [24] 1425 	mov	dptr,#_vial_unlocked
      0086B8 74 01            [12] 1426 	mov	a,#0x01
      0086BA F0               [24] 1427 	movx	@dptr,a
                                   1428 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0086BB 7F 00            [12] 1429 	mov	r7,#0x00
      0086BD                       1430 00116$:
      0086BD BF 06 00         [24] 1431 	cjne	r7,#0x06,00198$
      0086C0                       1432 00198$:
      0086C0 40 03            [24] 1433 	jc	00199$
      0086C2 02 87 70         [24] 1434 	ljmp	00104$
      0086C5                       1435 00199$:
                                   1436 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0086C5 7E 00            [12] 1437 	mov	r6,#0x00
      0086C7                       1438 00110$:
      0086C7 BE 10 00         [24] 1439 	cjne	r6,#0x10,00200$
      0086CA                       1440 00200$:
      0086CA 50 4D            [24] 1441 	jnc	00102$
                                   1442 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0086CC 7D 00            [12] 1443 	mov	r5,#0x00
      0086CE                       1444 00107$:
      0086CE BD 08 00         [24] 1445 	cjne	r5,#0x08,00202$
      0086D1                       1446 00202$:
      0086D1 50 43            [24] 1447 	jnc	00111$
                                   1448 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      0086D3 90 0B 94         [24] 1449 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      0086D6 EE               [12] 1450 	mov	a,r6
      0086D7 F0               [24] 1451 	movx	@dptr,a
      0086D8 90 0B 95         [24] 1452 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      0086DB ED               [12] 1453 	mov	a,r5
      0086DC F0               [24] 1454 	movx	@dptr,a
      0086DD 8F 82            [24] 1455 	mov	dpl, r7
      0086DF C0 07            [24] 1456 	push	ar7
      0086E1 C0 06            [24] 1457 	push	ar6
      0086E3 C0 05            [24] 1458 	push	ar5
      0086E5 12 96 76         [24] 1459 	lcall	_keycode_at_keymap_location_raw
      0086E8 AB 82            [24] 1460 	mov	r3, dpl
      0086EA AC 83            [24] 1461 	mov	r4, dph
      0086EC D0 05            [24] 1462 	pop	ar5
      0086EE D0 06            [24] 1463 	pop	ar6
      0086F0 D0 07            [24] 1464 	pop	ar7
      0086F2 90 0A D7         [24] 1465 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0086F5 EE               [12] 1466 	mov	a,r6
      0086F6 F0               [24] 1467 	movx	@dptr,a
      0086F7 90 0A D8         [24] 1468 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0086FA ED               [12] 1469 	mov	a,r5
      0086FB F0               [24] 1470 	movx	@dptr,a
      0086FC 90 0A D9         [24] 1471 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0086FF 12 38 2B         [24] 1472 	lcall	_ak820_outline_0075
      008702 8F 82            [24] 1473 	mov	dpl, r7
      008704 C0 07            [24] 1474 	push	ar7
      008706 C0 06            [24] 1475 	push	ar6
      008708 C0 05            [24] 1476 	push	ar5
      00870A 12 84 18         [24] 1477 	lcall	_dynamic_keymap_set_keycode
      00870D D0 05            [24] 1478 	pop	ar5
      00870F D0 06            [24] 1479 	pop	ar6
      008711 D0 07            [24] 1480 	pop	ar7
                                   1481 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008713 0D               [12] 1482 	inc	r5
      008714 80 B8            [24] 1483 	sjmp	00107$
      008716                       1484 00111$:
                                   1485 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008716 0E               [12] 1486 	inc	r6
      008717 80 AE            [24] 1487 	sjmp	00110$
      008719                       1488 00102$:
                                   1489 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008719 7E 00            [12] 1490 	mov	r6,#0x00
      00871B                       1491 00113$:
      00871B BE 01 00         [24] 1492 	cjne	r6,#0x01,00204$
      00871E                       1493 00204$:
      00871E 50 4C            [24] 1494 	jnc	00117$
                                   1495 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008720 12 8E 7C         [24] 1496 	lcall	_ak820_outline_0175
      008723 04               [12] 1497 	inc	a
      008724 F0               [24] 1498 	movx	@dptr,a
      008725 8F 82            [24] 1499 	mov	dpl, r7
      008727 C0 07            [24] 1500 	push	ar7
      008729 12 96 BB         [24] 1501 	lcall	_keycode_at_encodermap_location_raw
      00872C 12 43 41         [24] 1502 	lcall	_ak820_outline_0145
      00872F D0 07            [24] 1503 	pop	ar7
      008731 12 8E 73         [24] 1504 	lcall	_ak820_outline_0174
      008734 04               [12] 1505 	inc	a
      008735 F0               [24] 1506 	movx	@dptr,a
      008736 90 0A E3         [24] 1507 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008739 12 38 25         [24] 1508 	lcall	_ak820_outline_0070
      00873C 8F 82            [24] 1509 	mov	dpl, r7
      00873E C0 07            [24] 1510 	push	ar7
      008740 12 84 F3         [24] 1511 	lcall	_dynamic_keymap_set_encoder
      008743 D0 07            [24] 1512 	pop	ar7
                                   1513 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008745 12 8E 7C         [24] 1514 	lcall	_ak820_outline_0175
      008748 F0               [24] 1515 	movx	@dptr,a
      008749 8F 82            [24] 1516 	mov	dpl, r7
      00874B C0 07            [24] 1517 	push	ar7
      00874D 12 96 BB         [24] 1518 	lcall	_keycode_at_encodermap_location_raw
      008750 12 43 41         [24] 1519 	lcall	_ak820_outline_0145
      008753 D0 07            [24] 1520 	pop	ar7
      008755 12 8E 73         [24] 1521 	lcall	_ak820_outline_0174
      008758 F0               [24] 1522 	movx	@dptr,a
      008759 90 0A E3         [24] 1523 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00875C 12 38 25         [24] 1524 	lcall	_ak820_outline_0070
      00875F 8F 82            [24] 1525 	mov	dpl, r7
      008761 C0 07            [24] 1526 	push	ar7
      008763 12 84 F3         [24] 1527 	lcall	_dynamic_keymap_set_encoder
      008766 D0 07            [24] 1528 	pop	ar7
                                   1529 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008768 7E 01            [12] 1530 	mov	r6,#0x01
      00876A 80 AF            [24] 1531 	sjmp	00113$
      00876C                       1532 00117$:
                                   1533 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      00876C 0F               [12] 1534 	inc	r7
      00876D 02 86 BD         [24] 1535 	ljmp	00116$
      008770                       1536 00104$:
                                   1537 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008770 90 0A F9         [24] 1538 	mov	dptr,#_dynamic_keymap_reset_combo_10001_408
      008773 12 4F 19         [24] 1539 	lcall	_ak820_outline_0179
      008776 90 0A FB         [24] 1540 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0002)
      008779 F0               [24] 1541 	movx	@dptr,a
      00877A A3               [24] 1542 	inc	dptr
      00877B F0               [24] 1543 	movx	@dptr,a
      00877C 90 0A FD         [24] 1544 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0004)
      00877F F0               [24] 1545 	movx	@dptr,a
      008780 A3               [24] 1546 	inc	dptr
      008781 F0               [24] 1547 	movx	@dptr,a
      008782 90 0A FF         [24] 1548 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0006)
      008785 F0               [24] 1549 	movx	@dptr,a
      008786 A3               [24] 1550 	inc	dptr
      008787 F0               [24] 1551 	movx	@dptr,a
      008788 90 0B 01         [24] 1552 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0008)
      00878B F0               [24] 1553 	movx	@dptr,a
      00878C A3               [24] 1554 	inc	dptr
      00878D F0               [24] 1555 	movx	@dptr,a
                                   1556 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      00878E FF               [12] 1557 	mov	r7,a
      00878F                       1558 00119$:
      00878F BF 08 00         [24] 1559 	cjne	r7,#0x08,00206$
      008792                       1560 00206$:
      008792 50 17            [24] 1561 	jnc	00105$
                                   1562 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008794 90 0A EA         [24] 1563 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008797 74 F9            [12] 1564 	mov	a,#_dynamic_keymap_reset_combo_10001_408
      008799 F0               [24] 1565 	movx	@dptr,a
      00879A 74 0A            [12] 1566 	mov	a,#(_dynamic_keymap_reset_combo_10001_408 >> 8)
      00879C 12 38 5A         [24] 1567 	lcall	_ak820_outline_0118
      00879F 8F 82            [24] 1568 	mov	dpl, r7
      0087A1 C0 07            [24] 1569 	push	ar7
      0087A3 12 86 07         [24] 1570 	lcall	_dynamic_keymap_set_combo
      0087A6 D0 07            [24] 1571 	pop	ar7
                                   1572 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0087A8 0F               [12] 1573 	inc	r7
      0087A9 80 E4            [24] 1574 	sjmp	00119$
      0087AB                       1575 00105$:
                                   1576 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      0087AB 90 0A F8         [24] 1577 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      0087AE E0               [24] 1578 	movx	a,@dptr
      0087AF 90 0D F3         [24] 1579 	mov	dptr,#_vial_unlocked
      0087B2 F0               [24] 1580 	movx	@dptr,a
                                   1581 ;	quantum/dynamic_keymap.c:468: }
      0087B3 22               [24] 1582 	ret
                                   1583 ;------------------------------------------------------------
                                   1584 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1585 ;------------------------------------------------------------
                                   1586 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1587 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1588 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1589 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1590 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1591 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_410'
                                   1592 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_411'
                                   1593 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_411'
                                   1594 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_414'
                                   1595 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_416'
                                   1596 ;------------------------------------------------------------
                                   1597 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1598 ;	-----------------------------------------
                                   1599 ;	 function ak820_dynamic_read_buffer
                                   1600 ;	-----------------------------------------
      0087B4                       1601 _ak820_dynamic_read_buffer:
      0087B4 12 38 49         [24] 1602 	lcall	_ak820_outline_0104
      0087B7 90 0B 0C         [24] 1603 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      0087BA 12 38 4E         [24] 1604 	lcall	_ak820_outline_0105
                                   1605 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0087BD 90 0B 09         [24] 1606 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0087C0 12 38 00         [24] 1607 	lcall	_ak820_outline_0050
                                   1608 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      0087C3 90 0B 0E         [24] 1609 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      0087C6 E4               [12] 1610 	clr	a
      0087C7 F0               [24] 1611 	movx	@dptr,a
                                   1612 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      0087C8 90 0B 07         [24] 1613 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0087CB 12 38 1F         [24] 1614 	lcall	_ak820_outline_0059
      0087CE 8C 02            [24] 1615 	mov	ar2,r4
      0087D0 8D 03            [24] 1616 	mov	ar3,r5
      0087D2 C3               [12] 1617 	clr	c
      0087D3 74 1C            [12] 1618 	mov	a,#0x1c
      0087D5 9A               [12] 1619 	subb	a,r2
      0087D6 E4               [12] 1620 	clr	a
      0087D7 9B               [12] 1621 	subb	a,r3
      0087D8 50 01            [24] 1622 	jnc	00102$
                                   1623 ;	free result
      0087DA 22               [24] 1624 	ret
      0087DB                       1625 00102$:
                                   1626 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      0087DB 90 0B 05         [24] 1627 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0087DE 12 43 25         [24] 1628 	lcall	_ak820_outline_0120
      0087E1 90 0B 03         [24] 1629 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0087E4 12 38 3D         [24] 1630 	lcall	_ak820_outline_0099
      0087E7 C3               [12] 1631 	clr	c
      0087E8 EA               [12] 1632 	mov	a,r2
      0087E9 98               [12] 1633 	subb	a,r0
      0087EA EB               [12] 1634 	mov	a,r3
      0087EB 99               [12] 1635 	subb	a,r1
      0087EC 50 17            [24] 1636 	jnc	00104$
                                   1637 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      0087EE E8               [12] 1638 	mov	a,r0
      0087EF C3               [12] 1639 	clr	c
      0087F0 9A               [12] 1640 	subb	a,r2
      0087F1 F8               [12] 1641 	mov	r0,a
      0087F2 E9               [12] 1642 	mov	a,r1
      0087F3 9B               [12] 1643 	subb	a,r3
      0087F4 F9               [12] 1644 	mov	r1,a
                                   1645 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      0087F5 C3               [12] 1646 	clr	c
      0087F6 E8               [12] 1647 	mov	a,r0
      0087F7 9C               [12] 1648 	subb	a,r4
      0087F8 E9               [12] 1649 	mov	a,r1
      0087F9 9D               [12] 1650 	subb	a,r5
      0087FA 40 04            [24] 1651 	jc	00114$
      0087FC 8C 00            [24] 1652 	mov	ar0,r4
      0087FE 8D 01            [24] 1653 	mov	ar1,r5
      008800                       1654 00114$:
      008800 90 0B 0E         [24] 1655 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008803 E8               [12] 1656 	mov	a,r0
      008804 F0               [24] 1657 	movx	@dptr,a
      008805                       1658 00104$:
                                   1659 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008805 90 0B 0E         [24] 1660 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008808 E0               [24] 1661 	movx	a,@dptr
      008809 F5 2C            [12] 1662 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      00880B E0               [24] 1663 	movx	a,@dptr
      00880C 60 42            [24] 1664 	jz	00106$
      00880E C0 04            [24] 1665 	push	ar4
      008810 C0 05            [24] 1666 	push	ar5
      008812 8E 00            [24] 1667 	mov	ar0,r6
      008814 8F 05            [24] 1668 	mov	ar5,r7
      008816 90 0B 0C         [24] 1669 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008819 E0               [24] 1670 	movx	a,@dptr
      00881A F9               [12] 1671 	mov	r1,a
      00881B A3               [24] 1672 	inc	dptr
      00881C E0               [24] 1673 	movx	a,@dptr
      00881D FC               [12] 1674 	mov	r4,a
      00881E EA               [12] 1675 	mov	a,r2
      00881F 29               [12] 1676 	add	a, r1
      008820 FA               [12] 1677 	mov	r2,a
      008821 EB               [12] 1678 	mov	a,r3
      008822 3C               [12] 1679 	addc	a, r4
      008823 FB               [12] 1680 	mov	r3,a
      008824 90 05 81         [24] 1681 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008827 EA               [12] 1682 	mov	a,r2
      008828 F0               [24] 1683 	movx	@dptr,a
      008829 EB               [12] 1684 	mov	a,r3
      00882A 12 38 5A         [24] 1685 	lcall	_ak820_outline_0118
      00882D 90 05 84         [24] 1686 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008830 E5 2C            [12] 1687 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008832 12 38 65         [24] 1688 	lcall	_ak820_outline_0123
      008835 88 82            [24] 1689 	mov	dpl, r0
      008837 8D 83            [24] 1690 	mov	dph, r5
      008839 C0 07            [24] 1691 	push	ar7
      00883B C0 06            [24] 1692 	push	ar6
      00883D C0 05            [24] 1693 	push	ar5
      00883F C0 04            [24] 1694 	push	ar4
      008841 12 40 7A         [24] 1695 	lcall	_ak820_eeprom_read_block_xdata
      008844 D0 04            [24] 1696 	pop	ar4
      008846 D0 05            [24] 1697 	pop	ar5
      008848 D0 06            [24] 1698 	pop	ar6
      00884A D0 07            [24] 1699 	pop	ar7
                                   1700 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      00884C D0 05            [24] 1701 	pop	ar5
      00884E D0 04            [24] 1702 	pop	ar4
                                   1703 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008850                       1704 00106$:
                                   1705 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008850 90 0B 0E         [24] 1706 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008853 E0               [24] 1707 	movx	a,@dptr
      008854 FB               [12] 1708 	mov	r3,a
      008855                       1709 00109$:
      008855 8B 01            [24] 1710 	mov	ar1,r3
      008857 7A 00            [12] 1711 	mov	r2,#0x00
      008859 C3               [12] 1712 	clr	c
      00885A E9               [12] 1713 	mov	a,r1
      00885B 9C               [12] 1714 	subb	a,r4
      00885C EA               [12] 1715 	mov	a,r2
      00885D 9D               [12] 1716 	subb	a,r5
      00885E 50 09            [24] 1717 	jnc	00111$
      008860 EB               [12] 1718 	mov	a,r3
      008861 12 37 F0         [24] 1719 	lcall	_ak820_outline_0030
      008864 E4               [12] 1720 	clr	a
      008865 F0               [24] 1721 	movx	@dptr,a
      008866 0B               [12] 1722 	inc	r3
      008867 80 EC            [24] 1723 	sjmp	00109$
      008869                       1724 00111$:
                                   1725 ;	quantum/dynamic_keymap.c:483: }
      008869 22               [24] 1726 	ret
                                   1727 ;------------------------------------------------------------
                                   1728 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1729 ;------------------------------------------------------------
                                   1730 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1731 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1732 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_417'
                                   1733 ;------------------------------------------------------------
                                   1734 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1735 ;	-----------------------------------------
                                   1736 ;	 function dynamic_keymap_get_buffer
                                   1737 ;	-----------------------------------------
      00886A                       1738 _dynamic_keymap_get_buffer:
      00886A 12 38 49         [24] 1739 	lcall	_ak820_outline_0104
      00886D 90 0B 14         [24] 1740 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008870 12 38 4E         [24] 1741 	lcall	_ak820_outline_0105
                                   1742 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008873 90 0B 14         [24] 1743 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008876 12 38 00         [24] 1744 	lcall	_ak820_outline_0050
      008879 90 0B 0F         [24] 1745 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00887C 12 38 1F         [24] 1746 	lcall	_ak820_outline_0059
      00887F 90 0B 11         [24] 1747 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008882 12 4E F9         [24] 1748 	lcall	_ak820_outline_0086
      008885 90 0B 03         [24] 1749 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008888 E4               [12] 1750 	clr	a
      008889 F0               [24] 1751 	movx	@dptr,a
      00888A 74 06            [12] 1752 	mov	a,#0x06
      00888C A3               [24] 1753 	inc	dptr
      00888D F0               [24] 1754 	movx	@dptr,a
      00888E 90 0B 05         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008891 12 48 74         [24] 1756 	lcall	_ak820_outline_0058
      008894 90 0B 07         [24] 1757 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008897 12 38 25         [24] 1758 	lcall	_ak820_outline_0070
      00889A 90 0B 09         [24] 1759 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      00889D E9               [12] 1760 	mov	a,r1
      00889E 12 4F 12         [24] 1761 	lcall	_ak820_outline_0151
      0088A1 F0               [24] 1762 	movx	@dptr,a
      0088A2 90 00 40         [24] 1763 	mov	dptr,#0x0040
                                   1764 ;	quantum/dynamic_keymap.c:511: }
      0088A5 02 87 B4         [24] 1765 	ljmp	_ak820_dynamic_read_buffer
                                   1766 ;------------------------------------------------------------
                                   1767 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1768 ;------------------------------------------------------------
                                   1769 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1770 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1771 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1772 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1773 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1774 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_419'
                                   1775 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_420'
                                   1776 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_420'
                                   1777 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_420'
                                   1778 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_423'
                                   1779 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_426'
                                   1780 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_426'
                                   1781 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_428'
                                   1782 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_431'
                                   1783 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_433'
                                   1784 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_434'
                                   1785 ;------------------------------------------------------------
                                   1786 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1787 ;	-----------------------------------------
                                   1788 ;	 function dynamic_keymap_set_buffer
                                   1789 ;	-----------------------------------------
      0088A8                       1790 _dynamic_keymap_set_buffer:
      0088A8 12 38 49         [24] 1791 	lcall	_ak820_outline_0104
      0088AB 90 0B 1B         [24] 1792 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      0088AE 12 38 4E         [24] 1793 	lcall	_ak820_outline_0105
                                   1794 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      0088B1 90 0B 1B         [24] 1795 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      0088B4 12 37 CB         [24] 1796 	lcall	_ak820_outline_0010
      0088B7 74 40            [12] 1797 	mov	a,#0x40
      0088B9 2C               [12] 1798 	add	a, r4
      0088BA FA               [12] 1799 	mov	r2,a
      0088BB E4               [12] 1800 	clr	a
      0088BC 3D               [12] 1801 	addc	a, r5
      0088BD FB               [12] 1802 	mov	r3,a
                                   1803 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0088BE 90 0B 18         [24] 1804 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      0088C1 12 38 3D         [24] 1805 	lcall	_ak820_outline_0099
                                   1806 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      0088C4 90 0B 16         [24] 1807 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      0088C7 E0               [24] 1808 	movx	a,@dptr
      0088C8 F5 2D            [12] 1809 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      0088CA A3               [24] 1810 	inc	dptr
      0088CB E0               [24] 1811 	movx	a,@dptr
      0088CC F5 2E            [12] 1812 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      0088CE E5 2D            [12] 1813 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0088D0 45 2E            [12] 1814 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0088D2 70 01            [24] 1815 	jnz	00102$
      0088D4 22               [24] 1816 	ret
      0088D5                       1817 00102$:
                                   1818 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      0088D5 85 2D 2F         [24] 1819 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      0088D8 85 2E 30         [24] 1820 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0088DB C3               [12] 1821 	clr	c
      0088DC 74 1C            [12] 1822 	mov	a,#0x1c
      0088DE 95 2F            [12] 1823 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      0088E0 E4               [12] 1824 	clr	a
      0088E1 95 30            [12] 1825 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      0088E3 50 01            [24] 1826 	jnc	00104$
                                   1827 ;	free result
      0088E5 22               [24] 1828 	ret
      0088E6                       1829 00104$:
                                   1830 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      0088E6 85 2D 31         [24] 1831 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1832 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      0088E9 74 FA            [12] 1833 	mov	a,#0x100 - 0x06
      0088EB 2F               [12] 1834 	add	a,r7
      0088EC 40 11            [24] 1835 	jc	00105$
      0088EE E4               [12] 1836 	clr	a
      0088EF C3               [12] 1837 	clr	c
      0088F0 9E               [12] 1838 	subb	a,r6
      0088F1 FE               [12] 1839 	mov	r6,a
      0088F2 74 06            [12] 1840 	mov	a,#0x06
      0088F4 9F               [12] 1841 	subb	a,r7
      0088F5 FF               [12] 1842 	mov	r7,a
      0088F6 C3               [12] 1843 	clr	c
      0088F7 EE               [12] 1844 	mov	a,r6
      0088F8 95 2D            [12] 1845 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0088FA EF               [12] 1846 	mov	a,r7
      0088FB 95 2E            [12] 1847 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0088FD 50 01            [24] 1848 	jnc	00106$
      0088FF                       1849 00105$:
                                   1850 ;	quantum/dynamic_keymap.c:529: return;
      0088FF 22               [24] 1851 	ret
      008900                       1852 00106$:
                                   1853 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008900 90 0D F3         [24] 1854 	mov	dptr,#_vial_unlocked
      008903 E0               [24] 1855 	movx	a,@dptr
      008904 60 03            [24] 1856 	jz	00207$
      008906 02 8A 14         [24] 1857 	ljmp	00120$
      008909                       1858 00207$:
                                   1859 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008909 90 0B 1D         [24] 1860 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      00890C E4               [12] 1861 	clr	a
      00890D F0               [24] 1862 	movx	@dptr,a
                                   1863 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      00890E 90 0B 1E         [24] 1864 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008911 E5 31            [12] 1865 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008913 F0               [24] 1866 	movx	@dptr,a
                                   1867 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008914 EC               [12] 1868 	mov	a,r4
      008915 30 E0 33         [24] 1869 	jnb	acc.0,00111$
                                   1870 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008918 EA               [12] 1871 	mov	a,r2
      008919 24 FF            [12] 1872 	add	a,#0xff
      00891B FE               [12] 1873 	mov	r6,a
      00891C EB               [12] 1874 	mov	a,r3
      00891D 34 FF            [12] 1875 	addc	a,#0xff
      00891F FF               [12] 1876 	mov	r7,a
      008920 7D 00            [12] 1877 	mov	r5,#0x00
      008922 12 43 20         [24] 1878 	lcall	_ak820_outline_0117
      008925 8D F0            [24] 1879 	mov	b, r5
      008927 12 40 3F         [24] 1880 	lcall	_eeprom_read_byte
      00892A AE 82            [24] 1881 	mov	r6,dpl
      00892C 7F 00            [12] 1882 	mov	r7,#0x00
      00892E 12 38 75         [24] 1883 	lcall	_ak820_outline_0152
      008931 E0               [24] 1884 	movx	a,@dptr
      008932 7C 00            [12] 1885 	mov	r4,#0x00
      008934 42 07            [12] 1886 	orl	ar7,a
      008936 EC               [12] 1887 	mov	a,r4
      008937 42 06            [12] 1888 	orl	ar6,a
                                   1889 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008939 BF 00 09         [24] 1890 	cjne	r7,#0x00,00109$
      00893C BE 7C 06         [24] 1891 	cjne	r6,#0x7c,00109$
                                   1892 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      00893F 12 38 75         [24] 1893 	lcall	_ak820_outline_0152
      008942 74 FF            [12] 1894 	mov	a,#0xff
      008944 F0               [24] 1895 	movx	@dptr,a
      008945                       1896 00109$:
                                   1897 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008945 90 0B 1D         [24] 1898 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008948 74 01            [12] 1899 	mov	a,#0x01
      00894A F0               [24] 1900 	movx	@dptr,a
      00894B                       1901 00111$:
                                   1902 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      00894B 90 0B 1B         [24] 1903 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      00894E 12 38 00         [24] 1904 	lcall	_ak820_outline_0050
      008951 E5 2D            [12] 1905 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008953 2E               [12] 1906 	add	a, r6
      008954 FE               [12] 1907 	mov	r6,a
      008955 E5 2E            [12] 1908 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008957 3F               [12] 1909 	addc	a, r7
      008958 EE               [12] 1910 	mov	a,r6
      008959 30 E0 5A         [24] 1911 	jnb	acc.0,00115$
                                   1912 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      00895C AE 31            [24] 1913 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      00895E 7F 00            [12] 1914 	mov	r7,#0x00
      008960 EE               [12] 1915 	mov	a,r6
      008961 24 FF            [12] 1916 	add	a,#0xff
      008963 FC               [12] 1917 	mov	r4,a
      008964 EF               [12] 1918 	mov	a,r7
      008965 34 FF            [12] 1919 	addc	a,#0xff
      008967 FD               [12] 1920 	mov	r5,a
      008968 EC               [12] 1921 	mov	a,r4
      008969 28               [12] 1922 	add	a, r0
      00896A F5 82            [12] 1923 	mov	dpl,a
      00896C ED               [12] 1924 	mov	a,r5
      00896D 39               [12] 1925 	addc	a, r1
      00896E F5 83            [12] 1926 	mov	dph,a
      008970 E0               [24] 1927 	movx	a,@dptr
      008971 FC               [12] 1928 	mov	r4,a
      008972 7D 00            [12] 1929 	mov	r5,#0x00
      008974 E5 31            [12] 1930 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008976 2A               [12] 1931 	add	a, r2
      008977 FA               [12] 1932 	mov	r2,a
      008978 E4               [12] 1933 	clr	a
      008979 3B               [12] 1934 	addc	a, r3
      00897A FB               [12] 1935 	mov	r3,a
      00897B C0 00            [24] 1936 	push	ar0
      00897D C0 01            [24] 1937 	push	ar1
      00897F 8B 01            [24] 1938 	mov	ar1,r3
      008981 7B 00            [12] 1939 	mov	r3,#0x00
      008983 8A 82            [24] 1940 	mov	dpl, r2
      008985 89 83            [24] 1941 	mov	dph, r1
      008987 8B F0            [24] 1942 	mov	b, r3
      008989 12 40 3F         [24] 1943 	lcall	_eeprom_read_byte
      00898C AB 82            [24] 1944 	mov	r3, dpl
      00898E 7A 00            [12] 1945 	mov	r2,#0x00
      008990 EB               [12] 1946 	mov	a,r3
      008991 12 43 36         [24] 1947 	lcall	_ak820_outline_0139
                                   1948 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008994 BD 00 05         [24] 1949 	cjne	r5,#0x00,00212$
      008997 BC 7C 02         [24] 1950 	cjne	r4,#0x7c,00212$
      00899A 80 06            [24] 1951 	sjmp	00213$
      00899C                       1952 00212$:
      00899C D0 01            [24] 1953 	pop	ar1
      00899E D0 00            [24] 1954 	pop	ar0
      0089A0 80 0D            [24] 1955 	sjmp	00113$
      0089A2                       1956 00213$:
      0089A2 D0 01            [24] 1957 	pop	ar1
      0089A4 D0 00            [24] 1958 	pop	ar0
                                   1959 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      0089A6 1E               [12] 1960 	dec	r6
      0089A7 BE FF 01         [24] 1961 	cjne	r6,#0xff,00214$
      0089AA 1F               [12] 1962 	dec	r7
      0089AB                       1963 00214$:
      0089AB EE               [12] 1964 	mov	a,r6
      0089AC 12 8E 55         [24] 1965 	lcall	_ak820_outline_0127
      0089AF                       1966 00113$:
                                   1967 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      0089AF E5 31            [12] 1968 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0089B1 14               [12] 1969 	dec	a
      0089B2 90 0B 1E         [24] 1970 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      0089B5 F0               [24] 1971 	movx	@dptr,a
      0089B6                       1972 00115$:
                                   1973 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      0089B6 90 0B 1D         [24] 1974 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      0089B9 E0               [24] 1975 	movx	a,@dptr
      0089BA 90 0B 1F         [24] 1976 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      0089BD F0               [24] 1977 	movx	@dptr,a
      0089BE                       1978 00122$:
      0089BE 90 0B 1F         [24] 1979 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      0089C1 E0               [24] 1980 	movx	a,@dptr
      0089C2 FF               [12] 1981 	mov	r7,a
      0089C3 90 0B 1E         [24] 1982 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      0089C6 E0               [24] 1983 	movx	a,@dptr
      0089C7 FE               [12] 1984 	mov	r6,a
      0089C8 C3               [12] 1985 	clr	c
      0089C9 EF               [12] 1986 	mov	a,r7
      0089CA 9E               [12] 1987 	subb	a,r6
      0089CB 50 47            [24] 1988 	jnc	00120$
                                   1989 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      0089CD EF               [12] 1990 	mov	a,r7
      0089CE 28               [12] 1991 	add	a, r0
      0089CF FD               [12] 1992 	mov	r5,a
      0089D0 E4               [12] 1993 	clr	a
      0089D1 39               [12] 1994 	addc	a, r1
      0089D2 12 48 6C         [24] 1995 	lcall	_ak820_outline_0056
      0089D5 7B 00            [12] 1996 	mov	r3,#0x00
      0089D7 8C 2E            [24] 1997 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      0089D9 8B 2D            [24] 1998 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      0089DB 8F 02            [24] 1999 	mov	ar2,r7
      0089DD 7F 00            [12] 2000 	mov	r7,#0x00
      0089DF 74 01            [12] 2001 	mov	a,#0x01
      0089E1 2A               [12] 2002 	add	a, r2
      0089E2 FB               [12] 2003 	mov	r3,a
      0089E3 E4               [12] 2004 	clr	a
      0089E4 3F               [12] 2005 	addc	a, r7
      0089E5 FC               [12] 2006 	mov	r4,a
      0089E6 EB               [12] 2007 	mov	a,r3
      0089E7 28               [12] 2008 	add	a, r0
      0089E8 F5 82            [12] 2009 	mov	dpl,a
      0089EA EC               [12] 2010 	mov	a,r4
      0089EB 39               [12] 2011 	addc	a, r1
      0089EC F5 83            [12] 2012 	mov	dph,a
      0089EE E0               [24] 2013 	movx	a,@dptr
      0089EF FC               [12] 2014 	mov	r4,a
      0089F0 7B 00            [12] 2015 	mov	r3,#0x00
      0089F2 E5 2E            [12] 2016 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0089F4 42 03            [12] 2017 	orl	ar3,a
                                   2018 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      0089F6 BC 00 12         [24] 2019 	cjne	r4,#0x00,00123$
      0089F9 BB 7C 0F         [24] 2020 	cjne	r3,#0x7c,00123$
                                   2021 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      0089FC 12 38 6A         [24] 2022 	lcall	_ak820_outline_0131
      0089FF 74 FF            [12] 2023 	mov	a,#0xff
      008A01 F0               [24] 2024 	movx	@dptr,a
                                   2025 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008A02 0A               [12] 2026 	inc	r2
      008A03 BA 00 01         [24] 2027 	cjne	r2,#0x00,00218$
      008A06 0F               [12] 2028 	inc	r7
      008A07                       2029 00218$:
      008A07 EA               [12] 2030 	mov	a,r2
      008A08 12 8E 55         [24] 2031 	lcall	_ak820_outline_0127
      008A0B                       2032 00123$:
                                   2033 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008A0B 90 0B 1F         [24] 2034 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008A0E E0               [24] 2035 	movx	a,@dptr
      008A0F 24 02            [12] 2036 	add	a,#0x02
      008A11 F0               [24] 2037 	movx	@dptr,a
      008A12 80 AA            [24] 2038 	sjmp	00122$
      008A14                       2039 00120$:
                                   2040 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008A14 90 0B 1B         [24] 2041 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008A17 12 38 00         [24] 2042 	lcall	_ak820_outline_0050
      008A1A 74 40            [12] 2043 	mov	a,#0x40
      008A1C 12 43 30         [24] 2044 	lcall	_ak820_outline_0134
      008A1F 90 05 8A         [24] 2045 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008A22 12 48 74         [24] 2046 	lcall	_ak820_outline_0058
      008A25 E4               [12] 2047 	clr	a
      008A26 A3               [24] 2048 	inc	dptr
      008A27 F0               [24] 2049 	movx	@dptr,a
      008A28 90 05 8D         [24] 2050 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008A2B E5 2F            [12] 2051 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008A2D F0               [24] 2052 	movx	@dptr,a
      008A2E E5 30            [12] 2053 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008A30 A3               [24] 2054 	inc	dptr
      008A31 F0               [24] 2055 	movx	@dptr,a
      008A32 12 38 75         [24] 2056 	lcall	_ak820_outline_0152
                                   2057 ;	quantum/dynamic_keymap.c:584: }
      008A35 02 41 06         [24] 2058 	ljmp	_ak820_eeprom_write_block_xdata
                                   2059 ;------------------------------------------------------------
                                   2060 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2061 ;------------------------------------------------------------
                                   2062 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2063 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2064 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_437'
                                   2065 ;------------------------------------------------------------
                                   2066 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2067 ;	-----------------------------------------
                                   2068 ;	 function keycode_at_keymap_location
                                   2069 ;	-----------------------------------------
      008A38                       2070 _keycode_at_keymap_location:
      008A38 E5 82            [12] 2071 	mov	a,dpl
      008A3A 90 0B 22         [24] 2072 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_437
      008A3D F0               [24] 2073 	movx	@dptr,a
                                   2074 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008A3E E0               [24] 2075 	movx	a,@dptr
      008A3F FF               [12] 2076 	mov	r7,a
      008A40 BF 06 00         [24] 2077 	cjne	r7,#0x06,00128$
      008A43                       2078 00128$:
      008A43 50 23            [24] 2079 	jnc	00102$
      008A45 90 0B 20         [24] 2080 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008A48 E0               [24] 2081 	movx	a,@dptr
      008A49 FE               [12] 2082 	mov	r6,a
      008A4A BE 10 00         [24] 2083 	cjne	r6,#0x10,00130$
      008A4D                       2084 00130$:
      008A4D 50 19            [24] 2085 	jnc	00102$
      008A4F 90 0B 21         [24] 2086 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008A52 E0               [24] 2087 	movx	a,@dptr
      008A53 FD               [12] 2088 	mov	r5,a
      008A54 BD 08 00         [24] 2089 	cjne	r5,#0x08,00132$
      008A57                       2090 00132$:
      008A57 50 0F            [24] 2091 	jnc	00102$
                                   2092 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008A59 90 0A D4         [24] 2093 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008A5C EE               [12] 2094 	mov	a,r6
      008A5D F0               [24] 2095 	movx	@dptr,a
      008A5E 90 0A D5         [24] 2096 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008A61 ED               [12] 2097 	mov	a,r5
      008A62 F0               [24] 2098 	movx	@dptr,a
      008A63 8F 82            [24] 2099 	mov	dpl, r7
      008A65 02 83 CA         [24] 2100 	ljmp	_dynamic_keymap_get_keycode
      008A68                       2101 00102$:
                                   2102 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008A68 90 00 00         [24] 2103 	mov	dptr,#0x0000
                                   2104 ;	quantum/dynamic_keymap.c:591: }
      008A6B 22               [24] 2105 	ret
                                   2106 ;------------------------------------------------------------
                                   2107 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2108 ;------------------------------------------------------------
                                   2109 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2110 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2111 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_441'
                                   2112 ;------------------------------------------------------------
                                   2113 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2114 ;	-----------------------------------------
                                   2115 ;	 function keycode_at_encodermap_location
                                   2116 ;	-----------------------------------------
      008A6C                       2117 _keycode_at_encodermap_location:
      008A6C E5 82            [12] 2118 	mov	a,dpl
      008A6E 90 0B 25         [24] 2119 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_441
      008A71 F0               [24] 2120 	movx	@dptr,a
                                   2121 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008A72 E0               [24] 2122 	movx	a,@dptr
      008A73 FF               [12] 2123 	mov	r7,a
      008A74 BF 06 00         [24] 2124 	cjne	r7,#0x06,00120$
      008A77                       2125 00120$:
      008A77 50 1E            [24] 2126 	jnc	00102$
      008A79 90 0B 23         [24] 2127 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008A7C E0               [24] 2128 	movx	a,@dptr
      008A7D FE               [12] 2129 	mov	r6,a
      008A7E BE 01 00         [24] 2130 	cjne	r6,#0x01,00122$
      008A81                       2131 00122$:
      008A81 50 14            [24] 2132 	jnc	00102$
                                   2133 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008A83 90 0B 24         [24] 2134 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008A86 E0               [24] 2135 	movx	a,@dptr
      008A87 FE               [12] 2136 	mov	r6,a
      008A88 90 0A DE         [24] 2137 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008A8B E4               [12] 2138 	clr	a
      008A8C F0               [24] 2139 	movx	@dptr,a
      008A8D 90 0A DF         [24] 2140 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008A90 EE               [12] 2141 	mov	a,r6
      008A91 F0               [24] 2142 	movx	@dptr,a
      008A92 8F 82            [24] 2143 	mov	dpl, r7
      008A94 02 84 8B         [24] 2144 	ljmp	_dynamic_keymap_get_encoder
      008A97                       2145 00102$:
                                   2146 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008A97 90 00 00         [24] 2147 	mov	dptr,#0x0000
                                   2148 ;	quantum/dynamic_keymap.c:599: }
      008A9A 22               [24] 2149 	ret
                                   2150 ;------------------------------------------------------------
                                   2151 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2152 ;------------------------------------------------------------
                                   2153 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2154 ;	-----------------------------------------
                                   2155 ;	 function dynamic_keymap_macro_get_count
                                   2156 ;	-----------------------------------------
      008A9B                       2157 _dynamic_keymap_macro_get_count:
                                   2158 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008A9B 75 82 10         [24] 2159 	mov	dpl, #0x10
                                   2160 ;	quantum/dynamic_keymap.c:604: }
      008A9E 22               [24] 2161 	ret
                                   2162 ;------------------------------------------------------------
                                   2163 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2164 ;------------------------------------------------------------
                                   2165 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2166 ;	-----------------------------------------
                                   2167 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2168 ;	-----------------------------------------
      008A9F                       2169 _dynamic_keymap_macro_get_buffer_size:
                                   2170 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008A9F 90 20 00         [24] 2171 	mov	dptr,#0x2000
                                   2172 ;	quantum/dynamic_keymap.c:608: }
      008AA2 22               [24] 2173 	ret
                                   2174 ;------------------------------------------------------------
                                   2175 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2176 ;------------------------------------------------------------
                                   2177 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2178 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2179 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2180 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_449'
                                   2181 ;------------------------------------------------------------
                                   2182 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2183 ;	-----------------------------------------
                                   2184 ;	 function dynamic_keymap_macro_get_buffer
                                   2185 ;	-----------------------------------------
      008AA3                       2186 _dynamic_keymap_macro_get_buffer:
      008AA3 12 38 49         [24] 2187 	lcall	_ak820_outline_0104
      008AA6 90 0B 2B         [24] 2188 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008AA9 12 38 4E         [24] 2189 	lcall	_ak820_outline_0105
                                   2190 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008AAC 12 2B 2B         [24] 2191 	lcall	_ak820_macro_length
      008AAF 12 43 2B         [24] 2192 	lcall	_ak820_outline_0132
      008AB2 90 0B 2B         [24] 2193 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008AB5 12 38 1F         [24] 2194 	lcall	_ak820_outline_0059
      008AB8 90 0B 26         [24] 2195 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008ABB E0               [24] 2196 	movx	a,@dptr
      008ABC F5 32            [12] 2197 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008ABE A3               [24] 2198 	inc	dptr
      008ABF E0               [24] 2199 	movx	a,@dptr
      008AC0 F5 33            [12] 2200 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008AC2 90 0B 28         [24] 2201 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008AC5 12 38 3D         [24] 2202 	lcall	_ak820_outline_0099
      008AC8 A3               [24] 2203 	inc	dptr
      008AC9 E0               [24] 2204 	movx	a,@dptr
      008ACA FB               [12] 2205 	mov	r3,a
      008ACB 90 0B 03         [24] 2206 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008ACE 12 48 74         [24] 2207 	lcall	_ak820_outline_0058
      008AD1 90 0B 05         [24] 2208 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008AD4 12 38 25         [24] 2209 	lcall	_ak820_outline_0070
      008AD7 90 0B 07         [24] 2210 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008ADA E5 32            [12] 2211 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008ADC F0               [24] 2212 	movx	@dptr,a
      008ADD E5 33            [12] 2213 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008ADF A3               [24] 2214 	inc	dptr
      008AE0 F0               [24] 2215 	movx	@dptr,a
      008AE1 90 0B 09         [24] 2216 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008AE4 E8               [12] 2217 	mov	a,r0
      008AE5 F0               [24] 2218 	movx	@dptr,a
      008AE6 E9               [12] 2219 	mov	a,r1
      008AE7 A3               [24] 2220 	inc	dptr
      008AE8 F0               [24] 2221 	movx	@dptr,a
      008AE9 EB               [12] 2222 	mov	a,r3
      008AEA A3               [24] 2223 	inc	dptr
      008AEB F0               [24] 2224 	movx	@dptr,a
      008AEC 90 08 00         [24] 2225 	mov	dptr,#0x0800
                                   2226 ;	quantum/dynamic_keymap.c:635: }
      008AEF 02 87 B4         [24] 2227 	ljmp	_ak820_dynamic_read_buffer
                                   2228 ;------------------------------------------------------------
                                   2229 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2230 ;------------------------------------------------------------
                                   2231 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2232 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2233 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_451'
                                   2234 ;------------------------------------------------------------
                                   2235 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2236 ;	-----------------------------------------
                                   2237 ;	 function dynamic_keymap_macro_set_buffer
                                   2238 ;	-----------------------------------------
      008AF2                       2239 _dynamic_keymap_macro_set_buffer:
      008AF2 12 38 49         [24] 2240 	lcall	_ak820_outline_0104
      008AF5 90 0B 32         [24] 2241 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008AF8 12 38 4E         [24] 2242 	lcall	_ak820_outline_0105
                                   2243 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      008AFB 90 0B 32         [24] 2244 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008AFE 12 38 00         [24] 2245 	lcall	_ak820_outline_0050
      008B01 90 0B 2D         [24] 2246 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008B04 12 38 1F         [24] 2247 	lcall	_ak820_outline_0059
      008B07 90 0B 2F         [24] 2248 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008B0A 12 4E F9         [24] 2249 	lcall	_ak820_outline_0086
      008B0D 90 05 10         [24] 2250 	mov	dptr,#_ak820_macro_write_PARM_2
      008B10 12 38 25         [24] 2251 	lcall	_ak820_outline_0070
      008B13 90 05 12         [24] 2252 	mov	dptr,#_ak820_macro_write_PARM_3
      008B16 E9               [12] 2253 	mov	a,r1
      008B17 12 4F 12         [24] 2254 	lcall	_ak820_outline_0151
      008B1A 12 43 02         [24] 2255 	lcall	_ak820_outline_0060
                                   2256 ;	quantum/dynamic_keymap.c:640: }
      008B1D 02 2B 45         [24] 2257 	ljmp	_ak820_macro_write
                                   2258 ;------------------------------------------------------------
                                   2259 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2260 ;------------------------------------------------------------
                                   2261 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2262 ;	-----------------------------------------
                                   2263 ;	 function dynamic_keymap_macro_reset
                                   2264 ;	-----------------------------------------
      008B20                       2265 _dynamic_keymap_macro_reset:
                                   2266 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2267 ;	quantum/dynamic_keymap.c:666: }
      008B20 02 2E 64         [24] 2268 	ljmp	_ak820_macro_reset
                                   2269 ;------------------------------------------------------------
                                   2270 ;Allocation info for local variables in function 'decode_keycode'
                                   2271 ;------------------------------------------------------------
                                   2272 ;kc            Allocated with name '_decode_keycode_kc_10000_455'
                                   2273 ;------------------------------------------------------------
                                   2274 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2275 ;	-----------------------------------------
                                   2276 ;	 function decode_keycode
                                   2277 ;	-----------------------------------------
      008B23                       2278 _decode_keycode:
      008B23 12 38 49         [24] 2279 	lcall	_ak820_outline_0104
      008B26 90 0B 34         [24] 2280 	mov	dptr,#_decode_keycode_kc_10000_455
      008B29 12 38 4E         [24] 2281 	lcall	_ak820_outline_0105
                                   2282 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      008B2C 90 0B 34         [24] 2283 	mov	dptr,#_decode_keycode_kc_10000_455
      008B2F 12 37 CB         [24] 2284 	lcall	_ak820_outline_0010
      008B32 C3               [12] 2285 	clr	c
      008B33 E4               [12] 2286 	clr	a
      008B34 9C               [12] 2287 	subb	a,r4
      008B35 74 FF            [12] 2288 	mov	a,#0xff
      008B37 9D               [12] 2289 	subb	a,r5
      008B38 50 08            [24] 2290 	jnc	00102$
                                   2291 ;	free result
                                   2292 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      008B3A 8C 05            [24] 2293 	mov	ar5,r4
      008B3C 7C 00            [12] 2294 	mov	r4,#0x00
      008B3E 12 38 60         [24] 2295 	lcall	_ak820_outline_0121
      008B41 22               [24] 2296 	ret
      008B42                       2297 00102$:
                                   2298 ;	quantum/dynamic_keymap.c:672: return kc;
      008B42 12 43 20         [24] 2299 	lcall	_ak820_outline_0117
                                   2300 ;	quantum/dynamic_keymap.c:673: }
      008B45 22               [24] 2301 	ret
                                   2302 ;------------------------------------------------------------
                                   2303 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2304 ;------------------------------------------------------------
                                   2305 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_458'
                                   2306 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_459'
                                   2307 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_464'
                                   2308 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_465'
                                   2309 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_471'
                                   2310 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_489'
                                   2311 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_493'
                                   2312 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_493'
                                   2313 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_495'
                                   2314 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_497'
                                   2315 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_501'
                                   2316 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_503'
                                   2317 ;------------------------------------------------------------
                                   2318 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2319 ;	-----------------------------------------
                                   2320 ;	 function dynamic_keymap_macro_send
                                   2321 ;	-----------------------------------------
      008B46                       2322 _dynamic_keymap_macro_send:
      008B46 E5 82            [12] 2323 	mov	a,dpl
      008B48 90 0B 36         [24] 2324 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008B4B F0               [24] 2325 	movx	@dptr,a
                                   2326 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      008B4C 90 0B 37         [24] 2327 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008B4F E0               [24] 2328 	movx	a,@dptr
      008B50 60 01            [24] 2329 	jz	00102$
      008B52 22               [24] 2330 	ret
      008B53                       2331 00102$:
                                   2332 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008B53 90 0B 36         [24] 2333 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008B56 E0               [24] 2334 	movx	a,@dptr
      008B57 FF               [12] 2335 	mov	r7,a
      008B58 BF 10 00         [24] 2336 	cjne	r7,#0x10,00422$
      008B5B                       2337 00422$:
      008B5B 40 01            [24] 2338 	jc	00104$
                                   2339 ;	quantum/dynamic_keymap.c:683: return;
      008B5D 22               [24] 2340 	ret
      008B5E                       2341 00104$:
                                   2342 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      008B5E C0 07            [24] 2343 	push	ar7
      008B60 12 2A F2         [24] 2344 	lcall	_ak820_macro_ready
      008B63 E5 82            [12] 2345 	mov	a, dpl
      008B65 D0 07            [24] 2346 	pop	ar7
      008B67 70 01            [24] 2347 	jnz	00106$
      008B69 22               [24] 2348 	ret
      008B6A                       2349 00106$:
                                   2350 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008B6A 90 0B 38         [24] 2351 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008B6D E4               [12] 2352 	clr	a
      008B6E F0               [24] 2353 	movx	@dptr,a
      008B6F 74 08            [12] 2354 	mov	a,#0x08
      008B71 A3               [24] 2355 	inc	dptr
      008B72 F0               [24] 2356 	movx	@dptr,a
                                   2357 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008B73 C0 07            [24] 2358 	push	ar7
      008B75 12 2B 2B         [24] 2359 	lcall	_ak820_macro_length
      008B78 AD 82            [24] 2360 	mov	r5, dpl
      008B7A AE 83            [24] 2361 	mov	r6, dph
      008B7C D0 07            [24] 2362 	pop	ar7
      008B7E 74 08            [12] 2363 	mov	a,#0x08
      008B80 2E               [12] 2364 	add	a, r6
      008B81 FE               [12] 2365 	mov	r6,a
                                   2366 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      008B82 7B 00            [12] 2367 	mov	r3,#0x00
      008B84 7C 08            [12] 2368 	mov	r4,#0x08
      008B86                       2369 00111$:
      008B86 EF               [12] 2370 	mov	a,r7
      008B87 60 31            [24] 2371 	jz	00113$
                                   2372 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008B89 EB               [12] 2373 	mov	a,r3
      008B8A B5 05 05         [24] 2374 	cjne	a,ar5,00108$
      008B8D EC               [12] 2375 	mov	a,r4
      008B8E B5 06 01         [24] 2376 	cjne	a,ar6,00108$
                                   2377 ;	quantum/dynamic_keymap.c:717: return;
      008B91 22               [24] 2378 	ret
      008B92                       2379 00108$:
                                   2380 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008B92 8B 01            [24] 2381 	mov	ar1,r3
      008B94 8C 02            [24] 2382 	mov	ar2,r4
      008B96 8A 00            [24] 2383 	mov	ar0,r2
      008B98 7A 00            [12] 2384 	mov	r2,#0x00
      008B9A 89 82            [24] 2385 	mov	dpl, r1
      008B9C 88 83            [24] 2386 	mov	dph, r0
      008B9E 8A F0            [24] 2387 	mov	b, r2
      008BA0 12 40 3F         [24] 2388 	lcall	_eeprom_read_byte
      008BA3 E5 82            [12] 2389 	mov	a, dpl
      008BA5 70 06            [24] 2390 	jnz	00110$
                                   2391 ;	quantum/dynamic_keymap.c:720: --id;
      008BA7 1F               [12] 2392 	dec	r7
      008BA8 90 0B 36         [24] 2393 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008BAB EF               [12] 2394 	mov	a,r7
      008BAC F0               [24] 2395 	movx	@dptr,a
      008BAD                       2396 00110$:
                                   2397 ;	quantum/dynamic_keymap.c:722: ++p;
      008BAD 0B               [12] 2398 	inc	r3
      008BAE BB 00 01         [24] 2399 	cjne	r3,#0x00,00429$
      008BB1 0C               [12] 2400 	inc	r4
      008BB2                       2401 00429$:
      008BB2 90 0B 38         [24] 2402 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008BB5 12 38 2B         [24] 2403 	lcall	_ak820_outline_0075
      008BB8 80 CC            [24] 2404 	sjmp	00111$
      008BBA                       2405 00113$:
                                   2406 ;	quantum/dynamic_keymap.c:728: sending = true;
      008BBA 90 0B 37         [24] 2407 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008BBD 74 01            [12] 2408 	mov	a,#0x01
      008BBF F0               [24] 2409 	movx	@dptr,a
                                   2410 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      008BC0 12 8E 6D         [24] 2411 	lcall	_ak820_outline_0160
      008BC3 90 09 80         [24] 2412 	mov	dptr,#_ak820_macro_cancelled
      008BC6 F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      008BC7 90 0B 3A         [24] 2415 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008BCA F0               [24] 2416 	movx	@dptr,a
      008BCB 90 0B 3B         [24] 2417 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008BCE F0               [24] 2418 	movx	@dptr,a
      008BCF 90 0B 3C         [24] 2419 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008BD2 F0               [24] 2420 	movx	@dptr,a
      008BD3 90 0B 3D         [24] 2421 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008BD6 F0               [24] 2422 	movx	@dptr,a
                                   2423 ;	quantum/dynamic_keymap.c:738: while (p < end
      008BD7                       2424 00167$:
                                   2425 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      008BD7 90 0B 38         [24] 2426 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008BDA E0               [24] 2427 	movx	a,@dptr
      008BDB FC               [12] 2428 	mov	r4,a
      008BDC A3               [24] 2429 	inc	dptr
      008BDD E0               [24] 2430 	movx	a,@dptr
      008BDE FF               [12] 2431 	mov	r7,a
      008BDF C3               [12] 2432 	clr	c
      008BE0 EC               [12] 2433 	mov	a,r4
      008BE1 9D               [12] 2434 	subb	a,r5
      008BE2 EF               [12] 2435 	mov	a,r7
      008BE3 9E               [12] 2436 	subb	a,r6
      008BE4 40 03            [24] 2437 	jc	00430$
      008BE6 02 8D FB         [24] 2438 	ljmp	00169$
      008BE9                       2439 00430$:
      008BE9 90 09 80         [24] 2440 	mov	dptr,#_ak820_macro_cancelled
      008BEC E0               [24] 2441 	movx	a,@dptr
      008BED 60 03            [24] 2442 	jz	00431$
      008BEF 02 8D FB         [24] 2443 	ljmp	00169$
      008BF2                       2444 00431$:
                                   2445 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008BF2 8C 02            [24] 2446 	mov	ar2,r4
      008BF4 8F 03            [24] 2447 	mov	ar3,r7
      008BF6 90 0B 38         [24] 2448 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008BF9 74 01            [12] 2449 	mov	a,#0x01
      008BFB 2C               [12] 2450 	add	a, r4
      008BFC F0               [24] 2451 	movx	@dptr,a
      008BFD E4               [12] 2452 	clr	a
      008BFE 3F               [12] 2453 	addc	a, r7
      008BFF A3               [24] 2454 	inc	dptr
      008C00 F0               [24] 2455 	movx	@dptr,a
      008C01 7F 00            [12] 2456 	mov	r7,#0x00
      008C03 12 43 3C         [24] 2457 	lcall	_ak820_outline_0140
      008C06 8F F0            [24] 2458 	mov	b, r7
      008C08 12 40 3F         [24] 2459 	lcall	_eeprom_read_byte
      008C0B AF 82            [24] 2460 	mov	r7, dpl
      008C0D 90 0B 3A         [24] 2461 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008C10 EF               [12] 2462 	mov	a,r7
      008C11 F0               [24] 2463 	movx	@dptr,a
                                   2464 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      008C12 90 0B 3B         [24] 2465 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008C15 E4               [12] 2466 	clr	a
      008C16 F0               [24] 2467 	movx	@dptr,a
                                   2468 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      008C17 90 0B 3A         [24] 2469 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008C1A E0               [24] 2470 	movx	a,@dptr
      008C1B 70 03            [24] 2471 	jnz	00432$
      008C1D 02 8D FB         [24] 2472 	ljmp	00169$
      008C20                       2473 00432$:
                                   2474 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      008C20 90 0B 3A         [24] 2475 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008C23 E0               [24] 2476 	movx	a,@dptr
      008C24 FF               [12] 2477 	mov	r7,a
      008C25 BF 01 02         [24] 2478 	cjne	r7,#0x01,00433$
      008C28 80 03            [24] 2479 	sjmp	00434$
      008C2A                       2480 00433$:
      008C2A 02 8D DD         [24] 2481 	ljmp	00164$
      008C2D                       2482 00434$:
                                   2483 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008C2D 12 8E 03         [24] 2484 	lcall	_ak820_outline_0000
      008C30 12 40 3F         [24] 2485 	lcall	_eeprom_read_byte
      008C33 AF 82            [24] 2486 	mov	r7, dpl
      008C35 90 0B 3B         [24] 2487 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008C38 EF               [12] 2488 	mov	a,r7
      008C39 F0               [24] 2489 	movx	@dptr,a
                                   2490 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      008C3A EF               [12] 2491 	mov	a,r7
      008C3B 70 03            [24] 2492 	jnz	00435$
      008C3D 02 8D FB         [24] 2493 	ljmp	00169$
      008C40                       2494 00435$:
                                   2495 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008C40 12 8E 3B         [24] 2496 	lcall	_ak820_outline_0088
      008C43 BF 01 02         [24] 2497 	cjne	r7,#0x01,00436$
      008C46 80 13            [24] 2498 	sjmp	00151$
      008C48                       2499 00436$:
      008C48 12 8E 3B         [24] 2500 	lcall	_ak820_outline_0088
      008C4B BF 02 02         [24] 2501 	cjne	r7,#0x02,00437$
      008C4E 80 0B            [24] 2502 	sjmp	00151$
      008C50                       2503 00437$:
      008C50 12 8E 3B         [24] 2504 	lcall	_ak820_outline_0088
      008C53 BF 03 02         [24] 2505 	cjne	r7,#0x03,00438$
      008C56 80 03            [24] 2506 	sjmp	00439$
      008C58                       2507 00438$:
      008C58 02 8C BC         [24] 2508 	ljmp	00152$
      008C5B                       2509 00439$:
      008C5B                       2510 00151$:
                                   2511 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008C5B 12 8E 03         [24] 2512 	lcall	_ak820_outline_0000
      008C5E 12 40 3F         [24] 2513 	lcall	_eeprom_read_byte
      008C61 12 8E 85         [24] 2514 	lcall	_ak820_outline_0178
                                   2515 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      008C64 70 03            [24] 2516 	jnz	00440$
      008C66 02 8B D7         [24] 2517 	ljmp	00167$
      008C69                       2518 00440$:
                                   2519 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008C69 12 8E 3B         [24] 2520 	lcall	_ak820_outline_0088
      008C6C BF 01 03         [24] 2521 	cjne	r7,#0x01,00441$
      008C6F D3               [12] 2522 	setb	c
      008C70 80 01            [24] 2523 	sjmp	00442$
      008C72                       2524 00441$:
      008C72 C3               [12] 2525 	clr	c
      008C73                       2526 00442$:
      008C73 92 25            [24] 2527 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008C75 90 09 7F         [24] 2528 	mov	dptr,#_ak820_macro_primitive
      008C78 B3               [12] 2529 	cpl	c
      008C79 E4               [12] 2530 	clr	a
      008C7A 33               [12] 2531 	rlc	a
      008C7B F0               [24] 2532 	movx	@dptr,a
                                   2533 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008C7C 12 8E 3B         [24] 2534 	lcall	_ak820_outline_0088
      008C7F BF 01 10         [24] 2535 	cjne	r7,#0x01,00122$
      008C82 12 8E 66         [24] 2536 	lcall	_ak820_outline_0147
      008C85 C0 06            [24] 2537 	push	ar6
      008C87 C0 05            [24] 2538 	push	ar5
      008C89 12 75 7E         [24] 2539 	lcall	_tap_code
      008C8C D0 05            [24] 2540 	pop	ar5
      008C8E D0 06            [24] 2541 	pop	ar6
      008C90 80 24            [24] 2542 	sjmp	00123$
      008C92                       2543 00122$:
                                   2544 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008C92 12 8E 3B         [24] 2545 	lcall	_ak820_outline_0088
      008C95 BF 02 10         [24] 2546 	cjne	r7,#0x02,00119$
      008C98 12 8E 66         [24] 2547 	lcall	_ak820_outline_0147
      008C9B C0 06            [24] 2548 	push	ar6
      008C9D C0 05            [24] 2549 	push	ar5
      008C9F 12 74 78         [24] 2550 	lcall	_register_code
      008CA2 D0 05            [24] 2551 	pop	ar5
      008CA4 D0 06            [24] 2552 	pop	ar6
      008CA6 80 0E            [24] 2553 	sjmp	00123$
      008CA8                       2554 00119$:
                                   2555 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      008CA8 12 8E 66         [24] 2556 	lcall	_ak820_outline_0147
      008CAB C0 06            [24] 2557 	push	ar6
      008CAD C0 05            [24] 2558 	push	ar5
      008CAF 12 74 E5         [24] 2559 	lcall	_unregister_code
      008CB2 D0 05            [24] 2560 	pop	ar5
      008CB4 D0 06            [24] 2561 	pop	ar6
      008CB6                       2562 00123$:
                                   2563 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      008CB6 12 8E 6D         [24] 2564 	lcall	_ak820_outline_0160
      008CB9 02 8B D7         [24] 2565 	ljmp	00167$
      008CBC                       2566 00152$:
                                   2567 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008CBC 12 8E 3B         [24] 2568 	lcall	_ak820_outline_0088
      008CBF BF 05 02         [24] 2569 	cjne	r7,#0x05,00447$
      008CC2 80 13            [24] 2570 	sjmp	00146$
      008CC4                       2571 00447$:
      008CC4 12 8E 3B         [24] 2572 	lcall	_ak820_outline_0088
      008CC7 BF 06 02         [24] 2573 	cjne	r7,#0x06,00448$
      008CCA 80 0B            [24] 2574 	sjmp	00146$
      008CCC                       2575 00448$:
      008CCC 12 8E 3B         [24] 2576 	lcall	_ak820_outline_0088
      008CCF BF 07 02         [24] 2577 	cjne	r7,#0x07,00449$
      008CD2 80 03            [24] 2578 	sjmp	00450$
      008CD4                       2579 00449$:
      008CD4 02 8D 7D         [24] 2580 	ljmp	00147$
      008CD7                       2581 00450$:
      008CD7                       2582 00146$:
                                   2583 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008CD7 12 8E 03         [24] 2584 	lcall	_ak820_outline_0000
      008CDA 12 40 3F         [24] 2585 	lcall	_eeprom_read_byte
      008CDD 12 8E 85         [24] 2586 	lcall	_ak820_outline_0178
                                   2587 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      008CE0 70 03            [24] 2588 	jnz	00451$
      008CE2 02 8B D7         [24] 2589 	ljmp	00167$
      008CE5                       2590 00451$:
                                   2591 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008CE5 12 8E 03         [24] 2592 	lcall	_ak820_outline_0000
      008CE8 12 40 3F         [24] 2593 	lcall	_eeprom_read_byte
      008CEB AF 82            [24] 2594 	mov	r7, dpl
      008CED 90 0B 3D         [24] 2595 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008CF0 EF               [12] 2596 	mov	a,r7
      008CF1 F0               [24] 2597 	movx	@dptr,a
                                   2598 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      008CF2 EF               [12] 2599 	mov	a,r7
      008CF3 70 03            [24] 2600 	jnz	00452$
      008CF5 02 8B D7         [24] 2601 	ljmp	00167$
      008CF8                       2602 00452$:
                                   2603 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008CF8 90 0B 3C         [24] 2604 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008CFB E0               [24] 2605 	movx	a,@dptr
      008CFC FF               [12] 2606 	mov	r7,a
      008CFD 90 0B 3D         [24] 2607 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008D00 E0               [24] 2608 	movx	a,@dptr
      008D01 FB               [12] 2609 	mov	r3,a
      008D02 E4               [12] 2610 	clr	a
      008D03 FC               [12] 2611 	mov	r4,a
      008D04 FA               [12] 2612 	mov	r2,a
      008D05 EF               [12] 2613 	mov	a,r7
      008D06 42 04            [12] 2614 	orl	ar4,a
      008D08 EA               [12] 2615 	mov	a,r2
      008D09 42 03            [12] 2616 	orl	ar3,a
                                   2617 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      008D0B 12 43 5C         [24] 2618 	lcall	_ak820_outline_0181
      008D0E C0 06            [24] 2619 	push	ar6
      008D10 C0 05            [24] 2620 	push	ar5
      008D12 12 8B 23         [24] 2621 	lcall	_decode_keycode
      008D15 AC 82            [24] 2622 	mov	r4, dpl
      008D17 AF 83            [24] 2623 	mov	r7, dph
      008D19 D0 05            [24] 2624 	pop	ar5
      008D1B D0 06            [24] 2625 	pop	ar6
                                   2626 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008D1D 90 0B 3B         [24] 2627 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008D20 E0               [24] 2628 	movx	a,@dptr
      008D21 FB               [12] 2629 	mov	r3,a
      008D22 BB 05 03         [24] 2630 	cjne	r3,#0x05,00453$
      008D25 D3               [12] 2631 	setb	c
      008D26 80 01            [24] 2632 	sjmp	00454$
      008D28                       2633 00453$:
      008D28 C3               [12] 2634 	clr	c
      008D29                       2635 00454$:
      008D29 92 25            [24] 2636 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008D2B 90 09 7F         [24] 2637 	mov	dptr,#_ak820_macro_primitive
      008D2E B3               [12] 2638 	cpl	c
      008D2F E4               [12] 2639 	clr	a
      008D30 33               [12] 2640 	rlc	a
      008D31 F0               [24] 2641 	movx	@dptr,a
                                   2642 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      008D32 90 0B 3B         [24] 2643 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008D35 E0               [24] 2644 	movx	a,@dptr
      008D36 FB               [12] 2645 	mov	r3,a
      008D37 BB 05 02         [24] 2646 	cjne	r3,#0x05,00455$
      008D3A 80 0A            [24] 2647 	sjmp	00126$
      008D3C                       2648 00455$:
      008D3C BB 06 02         [24] 2649 	cjne	r3,#0x06,00456$
      008D3F 80 16            [24] 2650 	sjmp	00127$
      008D41                       2651 00456$:
                                   2652 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      008D41 BB 07 33         [24] 2653 	cjne	r3,#0x07,00129$
      008D44 80 22            [24] 2654 	sjmp	00128$
      008D46                       2655 00126$:
                                   2656 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      008D46 8C 82            [24] 2657 	mov	dpl, r4
      008D48 8F 83            [24] 2658 	mov	dph, r7
      008D4A C0 06            [24] 2659 	push	ar6
      008D4C C0 05            [24] 2660 	push	ar5
      008D4E 12 B0 F6         [24] 2661 	lcall	_vial_keycode_tap
      008D51 D0 05            [24] 2662 	pop	ar5
      008D53 D0 06            [24] 2663 	pop	ar6
                                   2664 ;	quantum/dynamic_keymap.c:795: break;
                                   2665 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      008D55 80 20            [24] 2666 	sjmp	00129$
      008D57                       2667 00127$:
                                   2668 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      008D57 8C 82            [24] 2669 	mov	dpl, r4
      008D59 8F 83            [24] 2670 	mov	dph, r7
      008D5B C0 06            [24] 2671 	push	ar6
      008D5D C0 05            [24] 2672 	push	ar5
      008D5F 12 B0 2B         [24] 2673 	lcall	_vial_keycode_down
      008D62 D0 05            [24] 2674 	pop	ar5
      008D64 D0 06            [24] 2675 	pop	ar6
                                   2676 ;	quantum/dynamic_keymap.c:798: break;
                                   2677 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      008D66 80 0F            [24] 2678 	sjmp	00129$
      008D68                       2679 00128$:
                                   2680 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      008D68 8C 82            [24] 2681 	mov	dpl, r4
      008D6A 8F 83            [24] 2682 	mov	dph, r7
      008D6C C0 06            [24] 2683 	push	ar6
      008D6E C0 05            [24] 2684 	push	ar5
      008D70 12 B0 91         [24] 2685 	lcall	_vial_keycode_up
      008D73 D0 05            [24] 2686 	pop	ar5
      008D75 D0 06            [24] 2687 	pop	ar6
                                   2688 ;	quantum/dynamic_keymap.c:802: }
      008D77                       2689 00129$:
                                   2690 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      008D77 12 8E 6D         [24] 2691 	lcall	_ak820_outline_0160
      008D7A 02 8B D7         [24] 2692 	ljmp	00167$
      008D7D                       2693 00147$:
                                   2694 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      008D7D 12 8E 3B         [24] 2695 	lcall	_ak820_outline_0088
      008D80 BF 04 02         [24] 2696 	cjne	r7,#0x04,00458$
      008D83 80 03            [24] 2697 	sjmp	00459$
      008D85                       2698 00458$:
      008D85 02 8B D7         [24] 2699 	ljmp	00167$
      008D88                       2700 00459$:
                                   2701 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008D88 12 8E 03         [24] 2702 	lcall	_ak820_outline_0000
      008D8B 12 40 3F         [24] 2703 	lcall	_eeprom_read_byte
      008D8E AF 82            [24] 2704 	mov	r7, dpl
                                   2705 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008D90 90 0B 38         [24] 2706 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008D93 12 38 43         [24] 2707 	lcall	_ak820_outline_0100
      008D96 90 0B 38         [24] 2708 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008D99 74 01            [12] 2709 	mov	a,#0x01
      008D9B 2B               [12] 2710 	add	a, r3
      008D9C F0               [24] 2711 	movx	@dptr,a
      008D9D E4               [12] 2712 	clr	a
      008D9E 3C               [12] 2713 	addc	a, r4
      008D9F A3               [24] 2714 	inc	dptr
      008DA0 F0               [24] 2715 	movx	@dptr,a
      008DA1 7A 00            [12] 2716 	mov	r2,#0x00
      008DA3 12 33 FC         [24] 2717 	lcall	_ak820_outline_0122
      008DA6 8A F0            [24] 2718 	mov	b, r2
      008DA8 12 40 3F         [24] 2719 	lcall	_eeprom_read_byte
      008DAB AC 82            [24] 2720 	mov	r4, dpl
                                   2721 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      008DAD EF               [12] 2722 	mov	a,r7
      008DAE 60 4B            [24] 2723 	jz	00169$
      008DB0 EC               [12] 2724 	mov	a,r4
      008DB1 60 48            [24] 2725 	jz	00169$
                                   2726 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008DB3 1F               [12] 2727 	dec	r7
      008DB4 1C               [12] 2728 	dec	r4
      008DB5 EC               [12] 2729 	mov	a,r4
      008DB6 75 F0 FF         [24] 2730 	mov	b,#0xff
      008DB9 A4               [48] 2731 	mul	ab
      008DBA FC               [12] 2732 	mov	r4,a
      008DBB AB F0            [24] 2733 	mov	r3,b
      008DBD 7A 00            [12] 2734 	mov	r2,#0x00
      008DBF EC               [12] 2735 	mov	a,r4
      008DC0 2F               [12] 2736 	add	a, r7
      008DC1 FC               [12] 2737 	mov	r4,a
      008DC2 EB               [12] 2738 	mov	a,r3
      008DC3 3A               [12] 2739 	addc	a, r2
      008DC4 FB               [12] 2740 	mov	r3,a
                                   2741 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      008DC5                       2742 00141$:
      008DC5 8C 02            [24] 2743 	mov	ar2,r4
      008DC7 8B 07            [24] 2744 	mov	ar7,r3
      008DC9 1C               [12] 2745 	dec	r4
      008DCA BC FF 01         [24] 2746 	cjne	r4,#0xff,00462$
      008DCD 1B               [12] 2747 	dec	r3
      008DCE                       2748 00462$:
      008DCE EA               [12] 2749 	mov	a,r2
      008DCF 4F               [12] 2750 	orl	a,r7
      008DD0 70 03            [24] 2751 	jnz	00463$
      008DD2 02 8B D7         [24] 2752 	ljmp	00167$
      008DD5                       2753 00463$:
      008DD5 90 00 01         [24] 2754 	mov	dptr,#0x0001
      008DD8 12 58 9A         [24] 2755 	lcall	_mDelaymS
      008DDB 80 E8            [24] 2756 	sjmp	00141$
      008DDD                       2757 00164$:
                                   2758 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      008DDD 90 0B 3A         [24] 2759 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008DE0 E0               [24] 2760 	movx	a,@dptr
      008DE1 FF               [12] 2761 	mov	r7,a
      008DE2 BF 80 00         [24] 2762 	cjne	r7,#0x80,00464$
      008DE5                       2763 00464$:
      008DE5 50 14            [24] 2764 	jnc	00169$
                                   2765 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      008DE7 90 0B 3A         [24] 2766 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008DEA E0               [24] 2767 	movx	a,@dptr
      008DEB F5 82            [12] 2768 	mov	dpl,a
      008DED C0 06            [24] 2769 	push	ar6
      008DEF C0 05            [24] 2770 	push	ar5
      008DF1 12 A3 93         [24] 2771 	lcall	_send_char
      008DF4 D0 05            [24] 2772 	pop	ar5
      008DF6 D0 06            [24] 2773 	pop	ar6
                                   2774 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008DF8 02 8B D7         [24] 2775 	ljmp	00167$
      008DFB                       2776 00169$:
                                   2777 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      008DFB 12 8E 6D         [24] 2778 	lcall	_ak820_outline_0160
                                   2779 ;	quantum/dynamic_keymap.c:837: sending = false;
      008DFE 90 0B 37         [24] 2780 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008E01 F0               [24] 2781 	movx	@dptr,a
                                   2782 ;	quantum/dynamic_keymap.c:839: }
      008E02 22               [24] 2783 	ret
                                   2784 	.area CSEG    (CODE)
                                   2785 	.area CONST   (CODE)
                                   2786 	.area XINIT   (CODE)
                                   2787 	.area CABS    (ABS,CODE)
                                   2788 
                                   2789 ; Experimental exact instruction outlining.
                                   2790 	.globl _ak820_outline_0000
                                   2791 	.globl _ak820_outline_0004
                                   2792 	.globl _ak820_outline_0010
                                   2793 	.globl _ak820_outline_0011
                                   2794 	.globl _ak820_outline_0016
                                   2795 	.globl _ak820_outline_0024
                                   2796 	.globl _ak820_outline_0030
                                   2797 	.globl _ak820_outline_0043
                                   2798 	.globl _ak820_outline_0050
                                   2799 	.globl _ak820_outline_0056
                                   2800 	.globl _ak820_outline_0058
                                   2801 	.globl _ak820_outline_0059
                                   2802 	.globl _ak820_outline_0060
                                   2803 	.globl _ak820_outline_0070
                                   2804 	.globl _ak820_outline_0075
                                   2805 	.globl _ak820_outline_0077
                                   2806 	.globl _ak820_outline_0086
                                   2807 	.globl _ak820_outline_0088
                                   2808 	.globl _ak820_outline_0094
                                   2809 	.globl _ak820_outline_0095
                                   2810 	.globl _ak820_outline_0099
                                   2811 	.globl _ak820_outline_0100
                                   2812 	.globl _ak820_outline_0104
                                   2813 	.globl _ak820_outline_0105
                                   2814 	.globl _ak820_outline_0113
                                   2815 	.globl _ak820_outline_0117
                                   2816 	.globl _ak820_outline_0118
                                   2817 	.globl _ak820_outline_0120
                                   2818 	.globl _ak820_outline_0121
                                   2819 	.globl _ak820_outline_0122
                                   2820 	.globl _ak820_outline_0123
                                   2821 	.globl _ak820_outline_0127
                                   2822 	.globl _ak820_outline_0131
                                   2823 	.globl _ak820_outline_0132
                                   2824 	.globl _ak820_outline_0133
                                   2825 	.globl _ak820_outline_0134
                                   2826 	.globl _ak820_outline_0139
                                   2827 	.globl _ak820_outline_0140
                                   2828 	.globl _ak820_outline_0145
                                   2829 	.globl _ak820_outline_0147
                                   2830 	.globl _ak820_outline_0151
                                   2831 	.globl _ak820_outline_0152
                                   2832 	.globl _ak820_outline_0155
                                   2833 	.globl _ak820_outline_0160
                                   2834 	.globl _ak820_outline_0174
                                   2835 	.globl _ak820_outline_0175
                                   2836 	.globl _ak820_outline_0178
                                   2837 	.globl _ak820_outline_0179
                                   2838 	.globl _ak820_outline_0180
                                   2839 	.globl _ak820_outline_0181
                                   2840 
                                   2841 	.area CSEG (CODE)
                                   2842 ; function ak820_outline_0000
      008E03                       2843 _ak820_outline_0000:
      008E03 90 0B 38         [24] 2844 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008E06 E0               [24] 2845 	movx	a,@dptr
      008E07 FC               [12] 2846 	mov	r4,a
      008E08 A3               [24] 2847 	inc	dptr
      008E09 E0               [24] 2848 	movx	a,@dptr
      008E0A FF               [12] 2849 	mov	r7,a
      008E0B 90 0B 38         [24] 2850 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008E0E 74 01            [12] 2851 	mov	a,#0x01
      008E10 2C               [12] 2852 	add	a,r4
      008E11 F0               [24] 2853 	movx	@dptr,a
      008E12 E4               [12] 2854 	clr	a
      008E13 3F               [12] 2855 	addc	a,r7
      008E14 A3               [24] 2856 	inc	dptr
      008E15 F0               [24] 2857 	movx	@dptr,a
      008E16 7B 00            [12] 2858 	mov	r3,#0x00
      008E18 8C 82            [24] 2859 	mov	dpl,r4
      008E1A 8F 83            [24] 2860 	mov	dph,r7
      008E1C 8B F0            [24] 2861 	mov	b,r3
      008E1E 22               [24] 2862 	ret
                                   2863 
                                   2864 	.area CSEG (CODE)
                                   2865 ; function ak820_outline_0024
      008E1F                       2866 _ak820_outline_0024:
      008E1F 2D               [12] 2867 	add	a,r5
      008E20 F9               [12] 2868 	mov	r1,a
      008E21 E4               [12] 2869 	clr	a
      008E22 3E               [12] 2870 	addc	a,r6
      008E23 FA               [12] 2871 	mov	r2,a
      008E24 8F 03            [24] 2872 	mov	ar3,r7
      008E26 89 82            [24] 2873 	mov	dpl,r1
      008E28 8A 83            [24] 2874 	mov	dph,r2
      008E2A 8B F0            [24] 2875 	mov	b,r3
      008E2C 22               [24] 2876 	ret
                                   2877 
                                   2878 	.area CSEG (CODE)
                                   2879 ; function ak820_outline_0077
      008E2D                       2880 _ak820_outline_0077:
      008E2D ED               [12] 2881 	mov	a,r5
      008E2E 75 F0 0A         [24] 2882 	mov	b,#0x0a
      008E31 A4               [48] 2883 	mul	ab
      008E32 24 58            [12] 2884 	add	a,#0x58
      008E34 FC               [12] 2885 	mov	r4,a
      008E35 74 06            [12] 2886 	mov	a,#0x06
      008E37 35 F0            [12] 2887 	addc	a,b
      008E39 FD               [12] 2888 	mov	r5,a
      008E3A 22               [24] 2889 	ret
                                   2890 
                                   2891 	.area CSEG (CODE)
                                   2892 ; function ak820_outline_0088
      008E3B                       2893 _ak820_outline_0088:
      008E3B 90 0B 3B         [24] 2894 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0001)
      008E3E E0               [24] 2895 	movx	a,@dptr
      008E3F FF               [12] 2896 	mov	r7,a
      008E40 22               [24] 2897 	ret
                                   2898 
                                   2899 	.area CSEG (CODE)
                                   2900 ; function ak820_outline_0094
      008E41                       2901 _ak820_outline_0094:
      008E41 90 0A D1         [24] 2902 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008E44 EE               [12] 2903 	mov	a,r6
      008E45 F0               [24] 2904 	movx	@dptr,a
      008E46 90 0A D2         [24] 2905 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008E49 ED               [12] 2906 	mov	a,r5
      008E4A F0               [24] 2907 	movx	@dptr,a
      008E4B 8F 82            [24] 2908 	mov	dpl,r7
      008E4D 22               [24] 2909 	ret
                                   2910 
                                   2911 	.area CSEG (CODE)
                                   2912 ; function ak820_outline_0113
      008E4E                       2913 _ak820_outline_0113:
      008E4E AD 82            [24] 2914 	mov	r5,dpl
      008E50 AE 83            [24] 2915 	mov	r6,dph
      008E52 AF F0            [24] 2916 	mov	r7,b
      008E54 22               [24] 2917 	ret
                                   2918 
                                   2919 	.area CSEG (CODE)
                                   2920 ; function ak820_outline_0127
      008E55                       2921 _ak820_outline_0127:
      008E55 28               [12] 2922 	add	a,r0
      008E56 F5 82            [12] 2923 	mov	dpl,a
      008E58 EF               [12] 2924 	mov	a,r7
      008E59 39               [12] 2925 	addc	a,r1
      008E5A F5 83            [12] 2926 	mov	dph,a
      008E5C 74 FF            [12] 2927 	mov	a,#0xff
      008E5E F0               [24] 2928 	movx	@dptr,a
      008E5F 22               [24] 2929 	ret
                                   2930 
                                   2931 	.area CSEG (CODE)
                                   2932 ; function ak820_outline_0133
      008E60                       2933 _ak820_outline_0133:
      008E60 2D               [12] 2934 	add	a,r5
      008E61 F9               [12] 2935 	mov	r1,a
      008E62 E4               [12] 2936 	clr	a
      008E63 3E               [12] 2937 	addc	a,r6
      008E64 FA               [12] 2938 	mov	r2,a
      008E65 22               [24] 2939 	ret
                                   2940 
                                   2941 	.area CSEG (CODE)
                                   2942 ; function ak820_outline_0147
      008E66                       2943 _ak820_outline_0147:
      008E66 90 0B 3C         [24] 2944 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      008E69 E0               [24] 2945 	movx	a,@dptr
      008E6A F5 82            [12] 2946 	mov	dpl,a
      008E6C 22               [24] 2947 	ret
                                   2948 
                                   2949 	.area CSEG (CODE)
                                   2950 ; function ak820_outline_0160
      008E6D                       2951 _ak820_outline_0160:
      008E6D 90 09 7F         [24] 2952 	mov	dptr,#_ak820_macro_primitive
      008E70 E4               [12] 2953 	clr	a
      008E71 F0               [24] 2954 	movx	@dptr,a
      008E72 22               [24] 2955 	ret
                                   2956 
                                   2957 	.area CSEG (CODE)
                                   2958 ; function ak820_outline_0174
      008E73                       2959 _ak820_outline_0174:
      008E73 90 0A E1         [24] 2960 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008E76 E4               [12] 2961 	clr	a
      008E77 F0               [24] 2962 	movx	@dptr,a
      008E78 90 0A E2         [24] 2963 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008E7B 22               [24] 2964 	ret
                                   2965 
                                   2966 	.area CSEG (CODE)
                                   2967 ; function ak820_outline_0175
      008E7C                       2968 _ak820_outline_0175:
      008E7C 90 0B 97         [24] 2969 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      008E7F E4               [12] 2970 	clr	a
      008E80 F0               [24] 2971 	movx	@dptr,a
      008E81 90 0B 98         [24] 2972 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      008E84 22               [24] 2973 	ret
                                   2974 
                                   2975 	.area CSEG (CODE)
                                   2976 ; function ak820_outline_0178
      008E85                       2977 _ak820_outline_0178:
      008E85 AF 82            [24] 2978 	mov	r7,dpl
      008E87 90 0B 3C         [24] 2979 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      008E8A EF               [12] 2980 	mov	a,r7
      008E8B F0               [24] 2981 	movx	@dptr,a
      008E8C EF               [12] 2982 	mov	a,r7
      008E8D 22               [24] 2983 	ret
