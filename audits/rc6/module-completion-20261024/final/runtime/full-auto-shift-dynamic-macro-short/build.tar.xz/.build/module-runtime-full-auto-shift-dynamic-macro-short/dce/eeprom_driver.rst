                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      0006E1                         85 _eeprom_read_word_addr_10000_91:
      0006E1                         86 	.ds 3
      0006E4                         87 _eeprom_read_word_ret_10000_92:
      0006E4                         88 	.ds 2
      0006E6                         89 _eeprom_read_dword_addr_10000_93:
      0006E6                         90 	.ds 3
      0006E9                         91 _eeprom_read_dword_ret_10000_94:
      0006E9                         92 	.ds 4
      0006ED                         93 _eeprom_write_byte_PARM_2:
      0006ED                         94 	.ds 1
      0006EE                         95 _eeprom_write_byte_addr_10000_95:
      0006EE                         96 	.ds 3
      0006F1                         97 _eeprom_write_word_PARM_2:
      0006F1                         98 	.ds 2
      0006F3                         99 _eeprom_write_word_addr_10000_97:
      0006F3                        100 	.ds 3
      0006F6                        101 _eeprom_write_dword_PARM_2:
      0006F6                        102 	.ds 4
      0006FA                        103 _eeprom_write_dword_addr_10000_99:
      0006FA                        104 	.ds 3
      0006FD                        105 _eeprom_update_byte_PARM_2:
      0006FD                        106 	.ds 1
      0006FE                        107 _eeprom_update_byte_addr_10000_107:
      0006FE                        108 	.ds 3
      000701                        109 _eeprom_update_word_PARM_2:
      000701                        110 	.ds 2
      000703                        111 _eeprom_update_word_addr_10000_111:
      000703                        112 	.ds 3
      000706                        113 _eeprom_update_dword_PARM_2:
      000706                        114 	.ds 4
      00070A                        115 _eeprom_update_dword_addr_10000_115:
      00070A                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      005269                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      005269 12 48 59         [24]  170 	lcall	_ak820_outline_0036
      00526C 90 06 E1         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      00526F 12 3A 1F         [24]  172 	lcall	_ak820_outline_0015
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      005272 90 06 E4         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005275 12 54 74         [24]  175 	lcall	_ak820_outline_0178
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      005278 90 06 E1         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      00527B 12 54 22         [24]  178 	lcall	_ak820_outline_0021
      00527E 90 05 E7         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005281 ED               [12]  180 	mov	a,r5
      005282 12 3A 1F         [24]  181 	lcall	_ak820_outline_0015
      005285 90 05 EA         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005288 12 54 66         [24]  183 	lcall	_ak820_outline_0107
      00528B 90 06 E4         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      00528E 12 45 F5         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      005291 90 06 E4         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005294 12 54 5D         [24]  188 	lcall	_ak820_outline_0089
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      005297 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      005298                        201 _eeprom_read_dword:
      005298 12 48 59         [24]  202 	lcall	_ak820_outline_0036
      00529B 90 06 E6         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      00529E 12 3A 1F         [24]  204 	lcall	_ak820_outline_0015
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      0052A1 90 06 E9         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0052A4 12 54 32         [24]  207 	lcall	_ak820_outline_0049
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      0052A7 90 06 E6         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0052AA 12 54 22         [24]  210 	lcall	_ak820_outline_0021
      0052AD 90 05 E7         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0052B0 ED               [12]  212 	mov	a,r5
      0052B1 12 3A 1F         [24]  213 	lcall	_ak820_outline_0015
      0052B4 90 05 EA         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0052B7 74 04            [12]  215 	mov	a,#0x04
      0052B9 12 3A A5         [24]  216 	lcall	_ak820_outline_0123
      0052BC 90 06 E9         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0052BF 12 45 F5         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      0052C2 90 06 E9         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0052C5 12 54 3B         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      0052C8 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      0052C9                        234 _eeprom_write_byte:
      0052C9 12 48 59         [24]  235 	lcall	_ak820_outline_0036
      0052CC 90 06 EE         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0052CF 12 3A 1F         [24]  237 	lcall	_ak820_outline_0015
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      0052D2 90 06 EE         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0052D5 12 53 FC         [24]  240 	lcall	_ak820_outline_0002
      0052D8 74 01            [12]  241 	mov	a,#0x01
      0052DA 12 3A A5         [24]  242 	lcall	_ak820_outline_0123
      0052DD 90 06 ED         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      0052E0 02 46 81         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      0052E3                        256 _eeprom_write_word:
      0052E3 12 48 59         [24]  257 	lcall	_ak820_outline_0036
      0052E6 90 06 F3         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      0052E9 12 3A 1F         [24]  259 	lcall	_ak820_outline_0015
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      0052EC 90 06 F3         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      0052EF 12 53 FC         [24]  262 	lcall	_ak820_outline_0002
      0052F2 12 54 66         [24]  263 	lcall	_ak820_outline_0107
      0052F5 90 06 F1         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      0052F8 02 46 81         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      0052FB                        277 _eeprom_write_dword:
      0052FB 12 48 59         [24]  278 	lcall	_ak820_outline_0036
      0052FE 90 06 FA         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005301 12 3A 1F         [24]  280 	lcall	_ak820_outline_0015
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      005304 90 06 FA         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005307 12 53 FC         [24]  283 	lcall	_ak820_outline_0002
      00530A 74 04            [12]  284 	mov	a,#0x04
      00530C 12 3A A5         [24]  285 	lcall	_ak820_outline_0123
      00530F 90 06 F6         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      005312 02 46 81         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      005315                        307 _eeprom_update_byte:
      005315 C0 07            [24]  308 	push	ar7
      005317 C0 06            [24]  309 	push	ar6
      005319 C0 05            [24]  310 	push	ar5
      00531B C0 04            [24]  311 	push	ar4
      00531D 12 48 59         [24]  312 	lcall	_ak820_outline_0036
      005320 90 06 FE         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005323 12 3A 1F         [24]  314 	lcall	_ak820_outline_0015
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      005326 90 06 FE         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005329 12 54 13         [24]  317 	lcall	_ak820_outline_0003
      00532C 12 45 BA         [24]  318 	lcall	_eeprom_read_byte
      00532F AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      005331 90 06 FD         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      005334 E0               [24]  322 	movx	a,@dptr
      005335 FE               [12]  323 	mov	r6,a
      005336 EF               [12]  324 	mov	a,r7
      005337 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      00533A 80 35            [24]  326 	sjmp	00103$
      00533C                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      00533C 90 06 FE         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00533F 12 3A 5F         [24]  330 	lcall	_ak820_outline_0059
      005342 A3               [24]  331 	inc	dptr
      005343 E0               [24]  332 	movx	a,@dptr
      005344 FF               [12]  333 	mov	r7,a
      005345 90 06 ED         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      005348 EE               [12]  335 	mov	a,r6
      005349 12 3A 7E         [24]  336 	lcall	_ak820_outline_0098
      00534C 8F F0            [24]  337 	mov	b, r7
      00534E C0 07            [24]  338 	push	ar7
      005350 C0 06            [24]  339 	push	ar6
      005352 C0 05            [24]  340 	push	ar5
      005354 C0 04            [24]  341 	push	ar4
      005356 C0 03            [24]  342 	push	ar3
      005358 C0 02            [24]  343 	push	ar2
      00535A C0 01            [24]  344 	push	ar1
      00535C C0 00            [24]  345 	push	ar0
      00535E 12 52 C9         [24]  346 	lcall	_eeprom_write_byte
      005361 D0 00            [24]  347 	pop	ar0
      005363 D0 01            [24]  348 	pop	ar1
      005365 D0 02            [24]  349 	pop	ar2
      005367 D0 03            [24]  350 	pop	ar3
      005369 D0 04            [24]  351 	pop	ar4
      00536B D0 05            [24]  352 	pop	ar5
      00536D D0 06            [24]  353 	pop	ar6
      00536F D0 07            [24]  354 	pop	ar7
      005371                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      005371 D0 04            [24]  357 	pop	ar4
      005373 D0 05            [24]  358 	pop	ar5
      005375 D0 06            [24]  359 	pop	ar6
      005377 D0 07            [24]  360 	pop	ar7
      005379 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      00537A                        373 _eeprom_update_word:
      00537A 12 48 59         [24]  374 	lcall	_ak820_outline_0036
      00537D 90 07 03         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005380 12 3A 1F         [24]  376 	lcall	_ak820_outline_0015
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      005383 90 07 03         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005386 12 54 13         [24]  379 	lcall	_ak820_outline_0003
      005389 12 52 69         [24]  380 	lcall	_eeprom_read_word
      00538C 12 48 AD         [24]  381 	lcall	_ak820_outline_0131
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      00538F 90 07 01         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      005392 12 3A 5F         [24]  384 	lcall	_ak820_outline_0059
      005395 EE               [12]  385 	mov	a,r6
      005396 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      005399 EF               [12]  387 	mov	a,r7
      00539A B5 05 01         [24]  388 	cjne	a,ar5,00112$
      00539D 22               [24]  389 	ret
      00539E                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      00539E 90 07 03         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0053A1 E0               [24]  393 	movx	a,@dptr
      0053A2 FB               [12]  394 	mov	r3,a
      0053A3 A3               [24]  395 	inc	dptr
      0053A4 12 3A 40         [24]  396 	lcall	_ak820_outline_0051
      0053A7 90 06 F1         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      0053AA 12 3A 65         [24]  398 	lcall	_ak820_outline_0070
      0053AD 8B 82            [24]  399 	mov	dpl, r3
      0053AF 8E 83            [24]  400 	mov	dph, r6
      0053B1 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      0053B3 02 52 E3         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      0053B6                        415 _eeprom_update_dword:
      0053B6 12 48 59         [24]  416 	lcall	_ak820_outline_0036
      0053B9 90 07 0A         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0053BC 12 3A 1F         [24]  418 	lcall	_ak820_outline_0015
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      0053BF 90 07 0A         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0053C2 12 54 13         [24]  421 	lcall	_ak820_outline_0003
      0053C5 12 52 98         [24]  422 	lcall	_eeprom_read_dword
      0053C8 12 54 4C         [24]  423 	lcall	_ak820_outline_0056
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      0053CB 90 07 06         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      0053CE E0               [24]  426 	movx	a,@dptr
      0053CF F8               [12]  427 	mov	r0,a
      0053D0 A3               [24]  428 	inc	dptr
      0053D1 12 54 54         [24]  429 	lcall	_ak820_outline_0088
      0053D4 EC               [12]  430 	mov	a,r4
      0053D5 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      0053D8 ED               [12]  432 	mov	a,r5
      0053D9 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      0053DC EE               [12]  434 	mov	a,r6
      0053DD B5 02 05         [24]  435 	cjne	a,ar2,00112$
      0053E0 EF               [12]  436 	mov	a,r7
      0053E1 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      0053E4 22               [24]  438 	ret
      0053E5                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      0053E5 90 07 0A         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0053E8 12 54 22         [24]  442 	lcall	_ak820_outline_0021
      0053EB 90 06 F6         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      0053EE E8               [12]  444 	mov	a,r0
      0053EF F0               [24]  445 	movx	@dptr,a
      0053F0 E9               [12]  446 	mov	a,r1
      0053F1 A3               [24]  447 	inc	dptr
      0053F2 12 54 6D         [24]  448 	lcall	_ak820_outline_0151
      0053F5 F0               [24]  449 	movx	@dptr,a
      0053F6 12 54 2B         [24]  450 	lcall	_ak820_outline_0044
                                    451 ;	drivers/eeprom/eeprom_driver.c:101: }
      0053F9 02 52 FB         [24]  452 	ljmp	_eeprom_write_dword
                                    453 	.area CSEG    (CODE)
                                    454 	.area CONST   (CODE)
                                    455 	.area XINIT   (CODE)
                                    456 	.area CABS    (ABS,CODE)
                                    457 
                                    458 ; Experimental exact instruction outlining.
                                    459 	.globl _ak820_outline_0002
                                    460 	.globl _ak820_outline_0003
                                    461 	.globl _ak820_outline_0015
                                    462 	.globl _ak820_outline_0021
                                    463 	.globl _ak820_outline_0036
                                    464 	.globl _ak820_outline_0044
                                    465 	.globl _ak820_outline_0049
                                    466 	.globl _ak820_outline_0051
                                    467 	.globl _ak820_outline_0054
                                    468 	.globl _ak820_outline_0056
                                    469 	.globl _ak820_outline_0059
                                    470 	.globl _ak820_outline_0070
                                    471 	.globl _ak820_outline_0088
                                    472 	.globl _ak820_outline_0089
                                    473 	.globl _ak820_outline_0098
                                    474 	.globl _ak820_outline_0107
                                    475 	.globl _ak820_outline_0123
                                    476 	.globl _ak820_outline_0131
                                    477 	.globl _ak820_outline_0151
                                    478 	.globl _ak820_outline_0178
                                    479 
                                    480 	.area CSEG (CODE)
                                    481 ; function ak820_outline_0002
      0053FC                        482 _ak820_outline_0002:
      0053FC E0               [24]  483 	movx	a,@dptr
      0053FD FD               [12]  484 	mov	r5,a
      0053FE A3               [24]  485 	inc	dptr
      0053FF E0               [24]  486 	movx	a,@dptr
      005400 FE               [12]  487 	mov	r6,a
      005401 A3               [24]  488 	inc	dptr
      005402 E0               [24]  489 	movx	a,@dptr
      005403 FF               [12]  490 	mov	r7,a
      005404 90 05 F0         [24]  491 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      005407 ED               [12]  492 	mov	a,r5
      005408 F0               [24]  493 	movx	@dptr,a
      005409 EE               [12]  494 	mov	a,r6
      00540A A3               [24]  495 	inc	dptr
      00540B F0               [24]  496 	movx	@dptr,a
      00540C EF               [12]  497 	mov	a,r7
      00540D A3               [24]  498 	inc	dptr
      00540E F0               [24]  499 	movx	@dptr,a
      00540F 90 05 F3         [24]  500 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      005412 22               [24]  501 	ret
                                    502 
                                    503 	.area CSEG (CODE)
                                    504 ; function ak820_outline_0003
      005413                        505 _ak820_outline_0003:
      005413 E0               [24]  506 	movx	a,@dptr
      005414 FD               [12]  507 	mov	r5,a
      005415 A3               [24]  508 	inc	dptr
      005416 E0               [24]  509 	movx	a,@dptr
      005417 FE               [12]  510 	mov	r6,a
      005418 A3               [24]  511 	inc	dptr
      005419 E0               [24]  512 	movx	a,@dptr
      00541A FF               [12]  513 	mov	r7,a
      00541B 8D 82            [24]  514 	mov	dpl,r5
      00541D 8E 83            [24]  515 	mov	dph,r6
      00541F 8F F0            [24]  516 	mov	b,r7
      005421 22               [24]  517 	ret
                                    518 
                                    519 	.area CSEG (CODE)
                                    520 ; function ak820_outline_0021
      005422                        521 _ak820_outline_0021:
      005422 E0               [24]  522 	movx	a,@dptr
      005423 FD               [12]  523 	mov	r5,a
      005424 A3               [24]  524 	inc	dptr
      005425 E0               [24]  525 	movx	a,@dptr
      005426 FE               [12]  526 	mov	r6,a
      005427 A3               [24]  527 	inc	dptr
      005428 E0               [24]  528 	movx	a,@dptr
      005429 FF               [12]  529 	mov	r7,a
      00542A 22               [24]  530 	ret
                                    531 
                                    532 	.area CSEG (CODE)
                                    533 ; function ak820_outline_0044
      00542B                        534 _ak820_outline_0044:
      00542B 8D 82            [24]  535 	mov	dpl,r5
      00542D 8E 83            [24]  536 	mov	dph,r6
      00542F 8F F0            [24]  537 	mov	b,r7
      005431 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0049
      005432                        542 _ak820_outline_0049:
      005432 E4               [12]  543 	clr	a
      005433 F0               [24]  544 	movx	@dptr,a
      005434 A3               [24]  545 	inc	dptr
      005435 F0               [24]  546 	movx	@dptr,a
      005436 A3               [24]  547 	inc	dptr
      005437 F0               [24]  548 	movx	@dptr,a
      005438 A3               [24]  549 	inc	dptr
      005439 F0               [24]  550 	movx	@dptr,a
      00543A 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0054
      00543B                        555 _ak820_outline_0054:
      00543B E0               [24]  556 	movx	a,@dptr
      00543C FC               [12]  557 	mov	r4,a
      00543D A3               [24]  558 	inc	dptr
      00543E E0               [24]  559 	movx	a,@dptr
      00543F FD               [12]  560 	mov	r5,a
      005440 A3               [24]  561 	inc	dptr
      005441 E0               [24]  562 	movx	a,@dptr
      005442 FE               [12]  563 	mov	r6,a
      005443 A3               [24]  564 	inc	dptr
      005444 E0               [24]  565 	movx	a,@dptr
      005445 8C 82            [24]  566 	mov	dpl,r4
      005447 8D 83            [24]  567 	mov	dph,r5
      005449 8E F0            [24]  568 	mov	b,r6
      00544B 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0056
      00544C                        573 _ak820_outline_0056:
      00544C AC 82            [24]  574 	mov	r4,dpl
      00544E AD 83            [24]  575 	mov	r5,dph
      005450 AE F0            [24]  576 	mov	r6,b
      005452 FF               [12]  577 	mov	r7,a
      005453 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0088
      005454                        582 _ak820_outline_0088:
      005454 E0               [24]  583 	movx	a,@dptr
      005455 F9               [12]  584 	mov	r1,a
      005456 A3               [24]  585 	inc	dptr
      005457 E0               [24]  586 	movx	a,@dptr
      005458 FA               [12]  587 	mov	r2,a
      005459 A3               [24]  588 	inc	dptr
      00545A E0               [24]  589 	movx	a,@dptr
      00545B FB               [12]  590 	mov	r3,a
      00545C 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0089
      00545D                        595 _ak820_outline_0089:
      00545D E0               [24]  596 	movx	a,@dptr
      00545E FE               [12]  597 	mov	r6,a
      00545F A3               [24]  598 	inc	dptr
      005460 E0               [24]  599 	movx	a,@dptr
      005461 8E 82            [24]  600 	mov	dpl,r6
      005463 F5 83            [12]  601 	mov	dph,a
      005465 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0107
      005466                        606 _ak820_outline_0107:
      005466 74 02            [12]  607 	mov	a,#0x02
      005468 F0               [24]  608 	movx	@dptr,a
      005469 E4               [12]  609 	clr	a
      00546A A3               [24]  610 	inc	dptr
      00546B F0               [24]  611 	movx	@dptr,a
      00546C 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0151
      00546D                        616 _ak820_outline_0151:
      00546D F0               [24]  617 	movx	@dptr,a
      00546E EA               [12]  618 	mov	a,r2
      00546F A3               [24]  619 	inc	dptr
      005470 F0               [24]  620 	movx	@dptr,a
      005471 EB               [12]  621 	mov	a,r3
      005472 A3               [24]  622 	inc	dptr
      005473 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0178
      005474                        627 _ak820_outline_0178:
      005474 E4               [12]  628 	clr	a
      005475 F0               [24]  629 	movx	@dptr,a
      005476 A3               [24]  630 	inc	dptr
      005477 F0               [24]  631 	movx	@dptr,a
      005478 22               [24]  632 	ret
