;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module repeat_key
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _unregister_weak_mods
	.globl _register_weak_mods
	.globl _process_record
	.globl _memset
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _get_alt_repeat_key_keycode_user_PARM_2
	.globl _set_last_record_PARM_2
	.globl _repeat_key_cancel
	.globl _set_last_mods
	.globl _set_last_record
	.globl _get_repeat_key_count
	.globl _repeat_key_invoke
	.globl _get_alt_repeat_key_keycode
	.globl _alt_repeat_key_invoke
	.globl _get_alt_repeat_key_keycode_user
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_last_record:
	.ds 9
_ak820_repeat_invoking:
	.ds 1
_registered_record:
	.ds 9
_registered_repeat_count:
	.ds 1
_registered_mods:
	.ds 1
_set_last_mods_mods_10000_170:
	.ds 1
_set_last_record_PARM_2:
	.ds 2
_set_last_record_keycode_10000_172:
	.ds 2
_update_last_repeat_count_dir_10000_174:
	.ds 1
_repeat_invoke_PARM_2:
	.ds 1
_repeat_invoke_event_10000_182:
	.ds 2
_repeat_key_invoke_event_10000_197:
	.ds 2
_find_alt_keycode_PARM_2:
	.ds 1
_find_alt_keycode_PARM_3:
	.ds 1
_find_alt_keycode_table_10000_199:
	.ds 3
_get_alt_repeat_key_keycode_keycode_10000_206:
	.ds 2
_get_alt_repeat_key_keycode_mods_10000_206:
	.ds 1
_get_alt_repeat_key_keycode_alt_keycode_10000_206:
	.ds 2
_alt_repeat_key_invoke_event_10000_220:
	.ds 2
_get_alt_repeat_key_keycode_user_PARM_2:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_last_mods:
	.ds 1
_last_repeat_count:
	.ds 1
_processing_repeat_count:
	.ds 1
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'repeat_key_cancel'
;------------------------------------------------------------
;	quantum/repeat_key.c:44: void repeat_key_cancel(void) {
;	-----------------------------------------
;	 function repeat_key_cancel
;	-----------------------------------------
_repeat_key_cancel:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	quantum/repeat_key.c:45: registered_record.keycode = 0;
	mov	dptr,#(_registered_record + 0x0007)
	lcall	_ak820_outline_0178
;	quantum/repeat_key.c:46: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'get_last_keycode'
;------------------------------------------------------------
;	quantum/repeat_key.c:48: uint16_t get_last_keycode(void) {
;	-----------------------------------------
;	 function set_last_mods
;	-----------------------------------------
_set_last_mods:
	mov	a,dpl
	mov	dptr,#_set_last_mods_mods_10000_170
	movx	@dptr,a
;	quantum/repeat_key.c:66: last_mods = mods;
	movx	a,@dptr
	mov	dptr,#_last_mods
	movx	@dptr,a
;	quantum/repeat_key.c:67: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'set_last_record'
;------------------------------------------------------------
;record        Allocated with name '_set_last_record_PARM_2'
;keycode       Allocated with name '_set_last_record_keycode_10000_172'
;------------------------------------------------------------
;	quantum/repeat_key.c:69: void set_last_record(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record) {
;	-----------------------------------------
;	 function set_last_record
;	-----------------------------------------
_set_last_record:
	lcall	_ak820_outline_0104
	mov	dptr,#_set_last_record_keycode_10000_172
	lcall	_ak820_outline_0105
;	quantum/repeat_key.c:70: last_record         = *record;
	mov	dptr,#_set_last_record_PARM_2
	lcall	_ak820_outline_0057
	mov	dptr,#___memcpy_PARM_2
	mov	a,r5
	lcall	_ak820_outline_0015
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x09
	lcall	_ak820_outline_0123
	mov	dptr,#_last_record
	mov	b,a
	lcall	___memcpy
;	quantum/repeat_key.c:71: last_record.keycode = keycode;
	mov	dptr,#_set_last_record_keycode_10000_172
	lcall	_ak820_outline_0051
	mov	dptr,#(_last_record + 0x0007)
	lcall	_ak820_outline_0058
;	quantum/repeat_key.c:72: last_repeat_count   = 0;
	mov	dptr,#_last_repeat_count
	clr	a
	movx	@dptr,a
;	quantum/repeat_key.c:73: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'update_last_repeat_count'
;------------------------------------------------------------
;dir           Allocated with name '_update_last_repeat_count_dir_10000_174'
;------------------------------------------------------------
;	quantum/repeat_key.c:76: static void update_last_repeat_count(int8_t dir) {
;	-----------------------------------------
;	 function update_last_repeat_count
;	-----------------------------------------
_update_last_repeat_count:
	mov	a,dpl
	mov	dptr,#_update_last_repeat_count_dir_10000_174
	movx	@dptr,a
;	quantum/repeat_key.c:77: if ((dir < 0) != (last_repeat_count < 0)) {
	movx	a,@dptr
	mov	r7,a
	rlc	a
	clr	a
	rlc	a
	mov	r6,a
	mov	dptr,#_last_repeat_count
	movx	a,@dptr
	mov	r5,a
	rlc	a
	clr	a
	rlc	a
	mov	r4,a
	mov	a,r6
	cjne	a,ar4,00131$
	sjmp	00104$
00131$:
;	quantum/repeat_key.c:78: last_repeat_count = dir;
	mov	dptr,#_last_repeat_count
	mov	a,r7
	movx	@dptr,a
	ret
00104$:
;	quantum/repeat_key.c:79: } else if (dir < 0 ? last_repeat_count > -127 : last_repeat_count < 127) {
	mov	a,r6
	jz	00108$
	clr	c
	mov	a,#(0x81 ^ 0x80)
	mov	b,r5
	xrl	b,#0x80
	subb	a,b
	clr	a
	rlc	a
	mov	r7,a
;	free result
	sjmp	00109$
00108$:
	clr	c
	mov	a,r5
	xrl	a,#0x80
	subb	a,#0xff
	clr	a
	rlc	a
	mov	r7,a
00109$:
	mov	a,r7
	jz	00106$
;	quantum/repeat_key.c:80: last_repeat_count += dir;
	mov	dptr,#_update_last_repeat_count_dir_10000_174
	movx	a,@dptr
	mov	dptr,#_last_repeat_count
	add	a, r5
	movx	@dptr,a
00106$:
;	quantum/repeat_key.c:82: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'get_repeat_key_count'
;------------------------------------------------------------
;	quantum/repeat_key.c:84: int8_t get_repeat_key_count(void) {
;	-----------------------------------------
;	 function get_repeat_key_count
;	-----------------------------------------
_get_repeat_key_count:
;	quantum/repeat_key.c:85: return processing_repeat_count;
	mov	dptr,#_processing_repeat_count
	movx	a,@dptr
	mov	dpl,a
;	quantum/repeat_key.c:86: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'repeat_invoke'
;------------------------------------------------------------
;alternate     Allocated with name '_repeat_invoke_PARM_2'
;event         Allocated with name '_repeat_invoke_event_10000_182'
;------------------------------------------------------------
;	quantum/repeat_key.c:88: static void repeat_invoke(const keyevent_t AK820_RECORD_MEM *event, bool alternate) {
;	-----------------------------------------
;	 function repeat_invoke
;	-----------------------------------------
_repeat_invoke:
	lcall	_ak820_outline_0104
	mov	dptr,#_repeat_invoke_event_10000_182
	lcall	_ak820_outline_0105
;	quantum/repeat_key.c:97: if (ak820_repeat_invoking) return;
	mov	dptr,#_ak820_repeat_invoking
	movx	a,@dptr
	jz	00102$
	ret
00102$:
;	quantum/repeat_key.c:99: if (processing_repeat_count) {
	mov	dptr,#_processing_repeat_count
	movx	a,@dptr
	jz	00104$
;	quantum/repeat_key.c:100: return;
	ret
00104$:
;	quantum/repeat_key.c:103: if (event->pressed) {
	mov	dptr,#_repeat_invoke_event_10000_182
	lcall	_ak820_outline_0051
	mov	a,#0x05
	lcall	_ak820_outline_0011
	jnz	00197$
	ajmp	00117$
00197$:
;	quantum/repeat_key.c:106: if (registered_record.keycode || !last_record.keycode) return;
	mov	dptr,#(_registered_record + 0x0007)
	lcall	_ak820_outline_0165
	jnz	00105$
	mov	dptr,#(_last_record + 0x0007)
	lcall	_ak820_outline_0165
	jnz	00106$
00105$:
	ret
00106$:
;	quantum/repeat_key.c:107: registered_record = last_record;
	mov	dptr,#___memcpy_PARM_2
	mov	a,#_last_record
	movx	@dptr,a
	mov	a,#(_last_record >> 8)
	lcall	_ak820_outline_0117
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x09
	lcall	_ak820_outline_0123
	mov	dptr,#_registered_record
	mov	b,a
	lcall	___memcpy
;	quantum/repeat_key.c:108: registered_mods = last_mods;
	mov	dptr,#_last_mods
	movx	a,@dptr
	mov	dptr,#_registered_mods
	movx	@dptr,a
;	quantum/repeat_key.c:110: if (alternate) {
	mov	dptr,#_repeat_invoke_PARM_2
	movx	a,@dptr
	mov	r5,a
	movx	a,@dptr
	jz	00111$
;	quantum/repeat_key.c:111: registered_record.keycode = get_alt_repeat_key_keycode();
	push	ar5
	acall	_get_alt_repeat_key_keycode
	mov	r3, dpl
	mov	r4, dph
	pop	ar5
	mov	dptr,#(_registered_record + 0x0007)
	lcall	_ak820_outline_0077
;	quantum/repeat_key.c:112: if (!registered_record.keycode) return;
	mov	a,r3
	orl	a,r4
	jnz	00109$
	ret
00109$:
;	quantum/repeat_key.c:114: registered_mods = 0;
	mov	dptr,#_registered_mods
	clr	a
	movx	@dptr,a
00111$:
;	quantum/repeat_key.c:117: update_last_repeat_count(alternate ? -1 : 1);
	mov	a,r5
	jz	00123$
	mov	r5,#0xff
	sjmp	00124$
00123$:
	mov	r5,#0x01
00124$:
	mov	dpl, r5
	acall	_update_last_repeat_count
;	quantum/repeat_key.c:118: register_weak_mods(registered_mods);
	mov	dptr,#_registered_mods
	movx	a,@dptr
	mov	dpl,a
	lcall	_register_weak_mods
;	quantum/repeat_key.c:119: registered_repeat_count = last_repeat_count;
	mov	dptr,#_last_repeat_count
	movx	a,@dptr
	mov	dptr,#_registered_repeat_count
	movx	@dptr,a
	sjmp	00118$
00117$:
;	quantum/repeat_key.c:122: if (!registered_record.keycode || event->key.row != registered_record.event.key.row ||
	mov	dptr,#(_registered_record + 0x0007)
	lcall	_ak820_outline_0165
	jz	00112$
	lcall	_ak820_outline_0075
	mov	r5,a
	mov	dptr,#(_registered_record + 0x0001)
	movx	a,@dptr
	mov	r4,a
	mov	a,r5
	cjne	a,ar4,00112$
;	quantum/repeat_key.c:123: event->key.col != registered_record.event.key.col) return;
	lcall	_ak820_outline_0093
	mov	r7,a
	mov	dptr,#_registered_record
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	cjne	a,ar6,00206$
	sjmp	00118$
00206$:
00112$:
	ret
00118$:
;	quantum/repeat_key.c:127: registered_record.event = *event;
	mov	dptr,#_repeat_invoke_event_10000_182
	lcall	_ak820_outline_0057
	mov	dptr,#___memcpy_PARM_2
	mov	a,r5
	lcall	_ak820_outline_0015
	mov	dptr,#___memcpy_PARM_3
	lcall	_ak820_outline_0108
	mov	dptr,#_registered_record
	mov	b,a
	lcall	___memcpy
;	quantum/repeat_key.c:128: processing_repeat_count = registered_repeat_count;
	mov	dptr,#_registered_repeat_count
	movx	a,@dptr
	mov	dptr,#_processing_repeat_count
	movx	@dptr,a
;	quantum/repeat_key.c:130: ak820_repeat_invoking = true;
	mov	dptr,#_ak820_repeat_invoking
	mov	a,#0x01
	movx	@dptr,a
;	quantum/repeat_key.c:132: process_record(&registered_record);
	mov	dptr,#_registered_record
	lcall	_process_record
;	quantum/repeat_key.c:134: ak820_repeat_invoking = false;
	mov	dptr,#_ak820_repeat_invoking
	clr	a
	movx	@dptr,a
;	quantum/repeat_key.c:136: processing_repeat_count = 0;
	mov	dptr,#_processing_repeat_count
	movx	@dptr,a
;	quantum/repeat_key.c:142: if (!registered_record.event.pressed) {
	mov	dptr,#(_registered_record + 0x0005)
	movx	a,@dptr
	jnz	00121$
;	quantum/repeat_key.c:143: unregister_weak_mods(registered_mods);
	mov	dptr,#_registered_mods
	movx	a,@dptr
	mov	dpl,a
	lcall	_unregister_weak_mods
;	quantum/repeat_key.c:144: registered_record.keycode = 0;
	mov	dptr,#(_registered_record + 0x0007)
	lcall	_ak820_outline_0178
00121$:
;	quantum/repeat_key.c:146: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'repeat_key_invoke'
;------------------------------------------------------------
;event         Allocated with name '_repeat_key_invoke_event_10000_197'
;------------------------------------------------------------
;	quantum/repeat_key.c:148: void repeat_key_invoke(const keyevent_t AK820_RECORD_MEM *event) {
;	-----------------------------------------
;	 function repeat_key_invoke
;	-----------------------------------------
_repeat_key_invoke:
	lcall	_ak820_outline_0104
	mov	dptr,#_repeat_key_invoke_event_10000_197
	lcall	_ak820_outline_0105
;	quantum/repeat_key.c:149: repeat_invoke(event, false);
	mov	dptr,#_repeat_key_invoke_event_10000_197
	lcall	_ak820_outline_0051
	mov	dptr,#_repeat_invoke_PARM_2
	clr	a
	lcall	_ak820_outline_0060
;	quantum/repeat_key.c:150: }
	ajmp	_repeat_invoke
;------------------------------------------------------------
;Allocation info for local variables in function 'find_alt_keycode'
;------------------------------------------------------------
;table_size_bytes Allocated with name '_find_alt_keycode_PARM_2'
;target        Allocated with name '_find_alt_keycode_PARM_3'
;table         Allocated with name '_find_alt_keycode_table_10000_199'
;keycodes      Allocated with name '_find_alt_keycode_keycodes_10000_200'
;i             Allocated with name '_find_alt_keycode_i_20000_201'
;------------------------------------------------------------
;	quantum/repeat_key.c:166: static uint8_t find_alt_keycode(const uint8_t (*table)[2], uint8_t table_size_bytes, uint8_t target) {
;	-----------------------------------------
;	 function find_alt_keycode
;	-----------------------------------------
_find_alt_keycode:
	lcall	_ak820_outline_0036
	mov	dptr,#_find_alt_keycode_table_10000_199
	lcall	_ak820_outline_0015
;	quantum/repeat_key.c:167: const uint8_t* keycodes = (const uint8_t*)table;
	mov	dptr,#_find_alt_keycode_table_10000_199
	lcall	_ak820_outline_0021
;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
	mov	r4,#0x00
00105$:
	mov	dptr,#_find_alt_keycode_PARM_2
	movx	a,@dptr
	mov	r3,a
	clr	c
	mov	a,r4
	subb	a,r3
	jnc	00103$
;	quantum/repeat_key.c:169: if (target == pgm_read_byte(keycodes + i)) {
	mov	a,r4
	lcall	_ak820_outline_0024
	lcall	__gptrget
	mov	r1,a
	mov	dptr,#_find_alt_keycode_PARM_3
	movx	a,@dptr
	cjne	a,ar1,00106$
;	quantum/repeat_key.c:171: return pgm_read_byte(keycodes + (i ^ 1));
	mov	a,#0x01
	xrl	a,r4
	lcall	_ak820_outline_0024
	lcall	__gptrget
	mov	dpl,a
	ret
00106$:
;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
	inc	r4
	sjmp	00105$
00103$:
;	quantum/repeat_key.c:174: return KC_NO;
	mov	dpl, #0x00
;	quantum/repeat_key.c:175: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'get_alt_repeat_key_keycode'
;------------------------------------------------------------
;keycode       Allocated with name '_get_alt_repeat_key_keycode_keycode_10000_206'
;mods          Allocated with name '_get_alt_repeat_key_keycode_mods_10000_206'
;alt_keycode   Allocated with name '_get_alt_repeat_key_keycode_alt_keycode_10000_206'
;------------------------------------------------------------
;	quantum/repeat_key.c:177: uint16_t get_alt_repeat_key_keycode(void) {
;	-----------------------------------------
;	 function get_alt_repeat_key_keycode
;	-----------------------------------------
_get_alt_repeat_key_keycode:
;	quantum/repeat_key.c:178: uint16_t keycode = last_record.keycode;
	mov	dptr,#(_last_record + 0x0007)
	lcall	_ak820_outline_0051
	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
	lcall	_ak820_outline_0058
;	quantum/repeat_key.c:179: uint8_t  mods    = last_mods;
	mov	dptr,#_last_mods
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
	movx	@dptr,a
;	quantum/repeat_key.c:183: uint16_t alt_keycode = get_alt_repeat_key_keycode_user(keycode, mods);
	mov	dptr,#_get_alt_repeat_key_keycode_user_PARM_2
	mov	a,r5
	lcall	_ak820_outline_0060
	push	ar7
	push	ar6
	lcall	_get_alt_repeat_key_keycode_user
	lcall	_ak820_outline_0141
	pop	ar6
	pop	ar7
;	quantum/repeat_key.c:185: if (alt_keycode != KC_TRANSPARENT) {
	mov	ar2,r4
	mov	ar3,r5
	cjne	r2,#0x01,00176$
	cjne	r3,#0x00,00176$
	sjmp	00102$
00176$:
;	quantum/repeat_key.c:186: return alt_keycode;
	lcall	_ak820_outline_0121
	ret
00102$:
;	quantum/repeat_key.c:191: mods = ((mods & 0xf0) ? /* set right hand bit */ 0x10 : 0)
	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
	movx	a,@dptr
	anl	a,#0xf0
	jz	00118$
	mov	a,#0x10
00118$:
	mov	r5,a
;	quantum/repeat_key.c:193: | (((mods >> 4) | mods) & 0xf);
	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
	movx	a,@dptr
	mov	r4,a
	swap	a
	anl	a,#0x0f
	orl	a,r4
	anl	a,#0x0f
	orl	a,r5
	movx	@dptr,a
;	quantum/repeat_key.c:196: if (keycode >= QK_MODS && keycode <= QK_MODS_MAX) {
	mov	ar4,r6
	mov	ar5,r7
	mov	a,#0x100 - 0x01
	add	a,r5
	jnc	00115$
	clr	c
	mov	a,#0xff
	subb	a,r4
	mov	a,#0x1f
	subb	a,r5
	jc	00115$
;	free result
;	quantum/repeat_key.c:197: mods |= QK_MODS_GET_MODS(keycode);
	mov	ar6,r7
	anl	ar6,#0x1f
	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
	movx	a,@dptr
	orl	a,r6
	movx	@dptr,a
;	quantum/repeat_key.c:198: keycode = QK_MODS_GET_BASIC_KEYCODE(keycode);
	mov	r5,#0x00
	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
	lcall	_ak820_outline_0070
;	quantum/repeat_key.c:214: if (IS_QK_BASIC(keycode)) {
00115$:
	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
	lcall	_ak820_outline_0010
	clr	c
	mov	a,#0xff
	subb	a,r4
	clr	a
	subb	a,r5
	jnc	00180$
	ljmp	00114$
00180$:
;	free result
;	quantum/repeat_key.c:215: if ((mods & (MOD_LCTL | MOD_LALT | MOD_LGUI))) {
	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
	movx	a,@dptr
	anl	a,#0x0d
	jz	00107$
;	quantum/repeat_key.c:230: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
	mov	ar5,r6
	mov	dptr,#_find_alt_keycode_PARM_2
	mov	a,#0x0a
	movx	@dptr,a
	mov	dptr,#_find_alt_keycode_PARM_3
	mov	a,r5
	movx	@dptr,a
	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_214
	mov	b, #0x80
	lcall	_find_alt_keycode
	mov	r5, dpl
	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
	mov	a,r5
	lcall	_ak820_outline_0123
	sjmp	00108$
00107$:
;	quantum/repeat_key.c:243: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
	mov	dptr,#_find_alt_keycode_PARM_2
	mov	a,#0x08
	movx	@dptr,a
	mov	dptr,#_find_alt_keycode_PARM_3
	mov	a,r6
	movx	@dptr,a
	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_215
	mov	b, #0x80
	lcall	_find_alt_keycode
	mov	r7, dpl
	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
	mov	a,r7
	lcall	_ak820_outline_0123
00108$:
;	quantum/repeat_key.c:246: if (!alt_keycode) {
	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
	lcall	_ak820_outline_0035
	jnz	00110$
;	quantum/repeat_key.c:271: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_find_alt_keycode_PARM_2
	mov	a,#0x16
	movx	@dptr,a
	mov	dptr,#_find_alt_keycode_PARM_3
	mov	a,r7
	movx	@dptr,a
	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_217
	mov	b, #0x80
	lcall	_find_alt_keycode
	mov	r7, dpl
	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
	mov	a,r7
	lcall	_ak820_outline_0123
00110$:
;	quantum/repeat_key.c:274: if (alt_keycode) {
	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
	lcall	_ak820_outline_0051
	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
	lcall	_ak820_outline_0035
	jz	00114$
;	quantum/repeat_key.c:276: return (mods << 8) | alt_keycode;
	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
	movx	a,@dptr
	mov	r5,a
	clr	a
	orl	ar6,a
	mov	a,r5
	orl	ar7,a
	lcall	_ak820_outline_0116
	ret
00114$:
;	quantum/repeat_key.c:280: return KC_NO; // No alternate key found.
	mov	dptr,#0x0000
;	quantum/repeat_key.c:281: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'alt_repeat_key_invoke'
;------------------------------------------------------------
;event         Allocated with name '_alt_repeat_key_invoke_event_10000_220'
;------------------------------------------------------------
;	quantum/repeat_key.c:283: void alt_repeat_key_invoke(const keyevent_t AK820_RECORD_MEM *event) {
;	-----------------------------------------
;	 function alt_repeat_key_invoke
;	-----------------------------------------
_alt_repeat_key_invoke:
	lcall	_ak820_outline_0104
	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
	lcall	_ak820_outline_0105
;	quantum/repeat_key.c:285: repeat_invoke(event, true);
	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
	lcall	_ak820_outline_0051
	mov	dptr,#_repeat_invoke_PARM_2
	lcall	_ak820_outline_0043
;	quantum/repeat_key.c:286: }
	ljmp	_repeat_invoke
;------------------------------------------------------------
;Allocation info for local variables in function 'get_alt_repeat_key_keycode_user'
;------------------------------------------------------------
;mods          Allocated with name '_get_alt_repeat_key_keycode_user_PARM_2'
;keycode       Allocated with name '_get_alt_repeat_key_keycode_user_keycode_10000_222'
;------------------------------------------------------------
;	quantum/repeat_key.c:289: __attribute__((weak)) uint16_t get_alt_repeat_key_keycode_user(uint16_t keycode, uint8_t mods) {
;	-----------------------------------------
;	 function get_alt_repeat_key_keycode_user
;	-----------------------------------------
_get_alt_repeat_key_keycode_user:
;	quantum/repeat_key.c:290: return KC_TRANSPARENT;
	mov	dptr,#0x0001
;	quantum/repeat_key.c:291: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area CONST   (CODE)
_get_alt_repeat_key_keycode_pairs_50000_214:
	.db #0x09	; 9
	.db #0x05	; 5
	.db #0x07	; 7
	.db #0x18	; 24
	.db #0x11	; 17
	.db #0x13	; 19
	.db #0x04	; 4
	.db #0x08	; 8
	.db #0x12	; 18
	.db #0x0c	; 12
	.area CSEG    (CODE)
	.area CONST   (CODE)
_get_alt_repeat_key_keycode_pairs_50000_215:
	.db #0x0d	; 13
	.db #0x0e	; 14
	.db #0x0b	; 11
	.db #0x0f	; 15
	.db #0x1a	; 26
	.db #0x05	; 5
	.db #0x08	; 8
	.db #0x05	; 5
	.area CSEG    (CODE)
	.area CONST   (CODE)
_get_alt_repeat_key_keycode_pairs_50000_217:
	.db #0x50	; 80	'P'
	.db #0x4f	; 79	'O'
	.db #0x52	; 82	'R'
	.db #0x51	; 81	'Q'
	.db #0x4a	; 74	'J'
	.db #0x4d	; 77	'M'
	.db #0x4b	; 75	'K'
	.db #0x4e	; 78	'N'
	.db #0x2a	; 42
	.db #0x4c	; 76	'L'
	.db #0x2f	; 47
	.db #0x30	; 48	'0'
	.db #0xb6	; 182
	.db #0xb7	; 183
	.db #0xab	; 171
	.db #0xac	; 172
	.db #0xbb	; 187
	.db #0xbc	; 188
	.db #0xa9	; 169
	.db #0xaa	; 170
	.db #0xbd	; 189
	.db #0xbe	; 190
	.area CSEG    (CODE)
	.area XINIT   (CODE)
__xinit__last_mods:
	.db #0x00	; 0
__xinit__last_repeat_count:
	.db #0x00	;  0
__xinit__processing_repeat_count:
	.db #0x00	;  0
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0010
	.globl _ak820_outline_0011
	.globl _ak820_outline_0015
	.globl _ak820_outline_0021
	.globl _ak820_outline_0024
	.globl _ak820_outline_0035
	.globl _ak820_outline_0036
	.globl _ak820_outline_0043
	.globl _ak820_outline_0051
	.globl _ak820_outline_0057
	.globl _ak820_outline_0058
	.globl _ak820_outline_0060
	.globl _ak820_outline_0070
	.globl _ak820_outline_0075
	.globl _ak820_outline_0077
	.globl _ak820_outline_0093
	.globl _ak820_outline_0104
	.globl _ak820_outline_0105
	.globl _ak820_outline_0108
	.globl _ak820_outline_0116
	.globl _ak820_outline_0117
	.globl _ak820_outline_0121
	.globl _ak820_outline_0123
	.globl _ak820_outline_0141
	.globl _ak820_outline_0165
	.globl _ak820_outline_0178
