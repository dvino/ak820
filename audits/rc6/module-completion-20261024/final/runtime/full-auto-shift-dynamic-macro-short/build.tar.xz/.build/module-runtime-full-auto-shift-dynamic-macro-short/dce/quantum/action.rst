                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_autoshift_cancel
                                     14 	.globl _ak820_autoshift_process
                                     15 	.globl _ak820_autoshift_before
                                     16 	.globl _ak820_oneshot_cancel
                                     17 	.globl _ak820_oneshot_post
                                     18 	.globl _ak820_oneshot_process
                                     19 	.globl _ak820_tapping_source
                                     20 	.globl _ak820_tapping_cancel
                                     21 	.globl _ak820_tapping_process
                                     22 	.globl _ak820_tapping_before
                                     23 	.globl _ak820_dynamic_macro_cancel
                                     24 	.globl _ak820_dynamic_macro_task
                                     25 	.globl _ak820_dynamic_macro_observe
                                     26 	.globl _ak820_dynamic_macro_process
                                     27 	.globl _pre_process_record_quantum
                                     28 	.globl _get_record_keycode
                                     29 	.globl _get_repeat_key_count
                                     30 	.globl _repeat_key_cancel
                                     31 	.globl _clear_owned_usages
                                     32 	.globl _owned_usage_key
                                     33 	.globl _clear_owned_keys
                                     34 	.globl _del_owned_key
                                     35 	.globl _add_owned_key
                                     36 	.globl _clear_owned_mods
                                     37 	.globl _del_owned_weak_mods
                                     38 	.globl _add_owned_weak_mods
                                     39 	.globl _del_owned_mods
                                     40 	.globl _add_owned_mods
                                     41 	.globl _clear_weak_mods
                                     42 	.globl _clear_mods
                                     43 	.globl _send_keyboard_report
                                     44 	.globl _layer_hold_clear
                                     45 	.globl _layer_hold_off
                                     46 	.globl _layer_hold_on
                                     47 	.globl _ak820_resolve_key
                                     48 	.globl _layer_xor
                                     49 	.globl _layer_and
                                     50 	.globl _layer_or
                                     51 	.globl _layer_off
                                     52 	.globl _layer_on
                                     53 	.globl _layer_move
                                     54 	.globl _layer_clear
                                     55 	.globl _layer_state_set
                                     56 	.globl _default_layer_xor
                                     57 	.globl _default_layer_and
                                     58 	.globl _default_layer_or
                                     59 	.globl _default_layer_set
                                     60 	.globl _process_record_quantum
                                     61 	.globl _action_for_keycode
                                     62 	.globl _mDelaymS
                                     63 	.globl _host_consumer_send
                                     64 	.globl _host_system_send
                                     65 	.globl _host_keyboard_leds
                                     66 	.globl _led_set
                                     67 	.globl _clear_keys_from_report
                                     68 	.globl ___memcpy
                                     69 	.globl _ADC_START
                                     70 	.globl _S0_R_FIFO
                                     71 	.globl _S0_T_FIFO
                                     72 	.globl _S0_FREE
                                     73 	.globl _S0_IF_BYTE
                                     74 	.globl _S0_IF_FIRST
                                     75 	.globl _S0_IF_OV
                                     76 	.globl _S0_FST_ACT
                                     77 	.globl _CP_RL2
                                     78 	.globl _C_T2
                                     79 	.globl _TR2
                                     80 	.globl _EXEN2
                                     81 	.globl _TCLK
                                     82 	.globl _RCLK
                                     83 	.globl _EXF2
                                     84 	.globl _CAP1F
                                     85 	.globl _TF2
                                     86 	.globl _RI
                                     87 	.globl _TI
                                     88 	.globl _RB8
                                     89 	.globl _TB8
                                     90 	.globl _REN
                                     91 	.globl _SM2
                                     92 	.globl _SM1
                                     93 	.globl _SM0
                                     94 	.globl _IT0
                                     95 	.globl _IE0
                                     96 	.globl _IT1
                                     97 	.globl _IE1
                                     98 	.globl _TR0
                                     99 	.globl _TF0
                                    100 	.globl _TR1
                                    101 	.globl _TF1
                                    102 	.globl _P4_0
                                    103 	.globl _P4_1
                                    104 	.globl _P4_2
                                    105 	.globl _P4_3
                                    106 	.globl _P4_4
                                    107 	.globl _P4_5
                                    108 	.globl _P4_6
                                    109 	.globl _RXD
                                    110 	.globl _TXD
                                    111 	.globl _INT0
                                    112 	.globl _INT1
                                    113 	.globl _T0
                                    114 	.globl _T1
                                    115 	.globl _MOSI1
                                    116 	.globl _MISO1
                                    117 	.globl _SCK1
                                    118 	.globl _P3_0
                                    119 	.globl _P3_1
                                    120 	.globl _P3_2
                                    121 	.globl _P3_3
                                    122 	.globl _P3_4
                                    123 	.globl _P3_5
                                    124 	.globl _P3_6
                                    125 	.globl _P3_7
                                    126 	.globl _CAP1_
                                    127 	.globl _T2_
                                    128 	.globl _CAP2_
                                    129 	.globl _T2EX_
                                    130 	.globl _RXD1
                                    131 	.globl _TXD1
                                    132 	.globl _P2_0
                                    133 	.globl _P2_1
                                    134 	.globl _P2_2
                                    135 	.globl _P2_3
                                    136 	.globl _P2_4
                                    137 	.globl _P2_5
                                    138 	.globl _P2_6
                                    139 	.globl _P2_7
                                    140 	.globl _AIN0
                                    141 	.globl _AIN1
                                    142 	.globl _AIN2
                                    143 	.globl _AIN3
                                    144 	.globl _AIN4
                                    145 	.globl _AIN5
                                    146 	.globl _AIN6
                                    147 	.globl _AIN7
                                    148 	.globl _CAP1
                                    149 	.globl _T2
                                    150 	.globl _CAP2
                                    151 	.globl _T2EX
                                    152 	.globl _INT0_
                                    153 	.globl _SCS
                                    154 	.globl _MOSI
                                    155 	.globl _MISO
                                    156 	.globl _SCK
                                    157 	.globl _RXD1_
                                    158 	.globl _TXD1_
                                    159 	.globl _P1_0
                                    160 	.globl _P1_1
                                    161 	.globl _P1_2
                                    162 	.globl _P1_3
                                    163 	.globl _P1_4
                                    164 	.globl _P1_5
                                    165 	.globl _P1_6
                                    166 	.globl _P1_7
                                    167 	.globl _AIN8
                                    168 	.globl _AIN9
                                    169 	.globl _AIN10
                                    170 	.globl _AIN11
                                    171 	.globl _AIN12
                                    172 	.globl _AIN13
                                    173 	.globl _RXD_
                                    174 	.globl _TXD_
                                    175 	.globl _SCL0
                                    176 	.globl _SDA0
                                    177 	.globl _P0_0
                                    178 	.globl _P0_1
                                    179 	.globl _P0_2
                                    180 	.globl _P0_3
                                    181 	.globl _P0_4
                                    182 	.globl _P0_5
                                    183 	.globl _P0_6
                                    184 	.globl _P0_7
                                    185 	.globl _IE_SPI0
                                    186 	.globl _IE_USB
                                    187 	.globl _IE_ADC
                                    188 	.globl _IE_UART1
                                    189 	.globl _IE_PWM_I2C
                                    190 	.globl _IE_GPIO
                                    191 	.globl _IE_WDOG
                                    192 	.globl _PX0
                                    193 	.globl _PT0
                                    194 	.globl _PX1
                                    195 	.globl _PT1
                                    196 	.globl _PS
                                    197 	.globl _PT2
                                    198 	.globl _PL_FLAG
                                    199 	.globl _PH_FLAG
                                    200 	.globl _EX0
                                    201 	.globl _ET0
                                    202 	.globl _EX1
                                    203 	.globl _ET1
                                    204 	.globl _ES
                                    205 	.globl _ET2
                                    206 	.globl _E_DIS
                                    207 	.globl _EA
                                    208 	.globl _P
                                    209 	.globl _F1
                                    210 	.globl _OV
                                    211 	.globl _RS0
                                    212 	.globl _RS1
                                    213 	.globl _F0
                                    214 	.globl _AC
                                    215 	.globl _CY
                                    216 	.globl _I2CS_INT_ST
                                    217 	.globl _I2CX_INT
                                    218 	.globl _LED_STATUS
                                    219 	.globl _LED_DMA_H
                                    220 	.globl _LED_DMA_L
                                    221 	.globl _LED_DMA
                                    222 	.globl _LED_PWM_OE
                                    223 	.globl _LED_COMMON
                                    224 	.globl _ADC_CHAN
                                    225 	.globl _ADC_DAT_H
                                    226 	.globl _ADC_DAT_L
                                    227 	.globl _ADC_DAT
                                    228 	.globl _ADC_CTRL
                                    229 	.globl _SPI1_CK_SE
                                    230 	.globl _SPI1_CTRL
                                    231 	.globl _SPI1_DATA
                                    232 	.globl _SPI1_STAT
                                    233 	.globl _SIF1
                                    234 	.globl _SBAUD1
                                    235 	.globl _SBUF1
                                    236 	.globl _SCON1
                                    237 	.globl _SPI0_SETUP
                                    238 	.globl _SPI0_CK_SE
                                    239 	.globl _SPI0_CTRL
                                    240 	.globl _SPI0_DATA
                                    241 	.globl _SPI0_STAT
                                    242 	.globl _T2CAP1H
                                    243 	.globl _T2CAP1L
                                    244 	.globl _T2CAP1
                                    245 	.globl _TH2
                                    246 	.globl _TL2
                                    247 	.globl _T2COUNT
                                    248 	.globl _RCAP2H
                                    249 	.globl _RCAP2L
                                    250 	.globl _RCAP2
                                    251 	.globl _T2MOD
                                    252 	.globl _T2CON
                                    253 	.globl _SBUF
                                    254 	.globl _SCON
                                    255 	.globl _TH1
                                    256 	.globl _TH0
                                    257 	.globl _TL1
                                    258 	.globl _TL0
                                    259 	.globl _TMOD
                                    260 	.globl _TCON
                                    261 	.globl _XBUS_AUX
                                    262 	.globl _P7
                                    263 	.globl _P6_DIR
                                    264 	.globl _P6_OUT_PU
                                    265 	.globl _P6_IN
                                    266 	.globl _P5_DIR
                                    267 	.globl _P5_OUT_PU
                                    268 	.globl _P5_IN
                                    269 	.globl _P4_LED_KEY
                                    270 	.globl _P4_DIR_PU
                                    271 	.globl _P4_MOD_OC
                                    272 	.globl _P4
                                    273 	.globl _P3_DIR_PU
                                    274 	.globl _P3_MOD_OC
                                    275 	.globl _P3
                                    276 	.globl _P2_DIR_PU
                                    277 	.globl _P2_MOD_OC
                                    278 	.globl _P2
                                    279 	.globl _P1_DIR_PU
                                    280 	.globl _P1_MOD_OC
                                    281 	.globl _P1
                                    282 	.globl _P0_DIR_PU
                                    283 	.globl _P0_MOD_OC
                                    284 	.globl _P0
                                    285 	.globl _ROM_CTRL
                                    286 	.globl _ROM_DATA_HH
                                    287 	.globl _ROM_DATA_HL
                                    288 	.globl _ROM_DATA_HI
                                    289 	.globl _ROM_ADDR_H
                                    290 	.globl _ROM_ADDR_L
                                    291 	.globl _ROM_ADDR
                                    292 	.globl _GPIO_IE
                                    293 	.globl _IP_EX
                                    294 	.globl _IE_EX
                                    295 	.globl _IP
                                    296 	.globl _IE
                                    297 	.globl _WDOG_COUNT
                                    298 	.globl _RESET_KEEP
                                    299 	.globl _WAKE_CTRL
                                    300 	.globl _CLOCK_CFG
                                    301 	.globl _POWER_CFG
                                    302 	.globl _PCON
                                    303 	.globl _GLOBAL_CFG
                                    304 	.globl _SAFE_MOD
                                    305 	.globl _DPH
                                    306 	.globl _DPL
                                    307 	.globl _SP
                                    308 	.globl _A_INV
                                    309 	.globl _B
                                    310 	.globl _ACC
                                    311 	.globl _PSW
                                    312 	.globl _disable_action_cache
                                    313 	.globl _tap_code_delay_PARM_2
                                    314 	.globl _process_action_PARM_2
                                    315 	.globl _action_exec_PARM_1
                                    316 	.globl _tp_buttons
                                    317 	.globl _action_exec
                                    318 	.globl _ak820_action_exec
                                    319 	.globl _process_record
                                    320 	.globl _process_record_handler
                                    321 	.globl _process_action
                                    322 	.globl _register_code
                                    323 	.globl _unregister_code
                                    324 	.globl _tap_code_delay
                                    325 	.globl _tap_code
                                    326 	.globl _register_mods
                                    327 	.globl _unregister_mods
                                    328 	.globl _register_weak_mods
                                    329 	.globl _unregister_weak_mods
                                    330 	.globl _clear_keyboard
                                    331 	.globl _clear_keyboard_but_mods
                                    332 	.globl _clear_keyboard_but_mods_and_keys
                                    333 ;--------------------------------------------------------
                                    334 ; special function registers
                                    335 ;--------------------------------------------------------
                                    336 	.area RSEG    (ABS,DATA)
      000000                        337 	.org 0x0000
                           0000D0   338 _PSW	=	0x00d0
                           0000E0   339 _ACC	=	0x00e0
                           0000F0   340 _B	=	0x00f0
                           0000FD   341 _A_INV	=	0x00fd
                           000081   342 _SP	=	0x0081
                           000082   343 _DPL	=	0x0082
                           000083   344 _DPH	=	0x0083
                           0000A1   345 _SAFE_MOD	=	0x00a1
                           0000B1   346 _GLOBAL_CFG	=	0x00b1
                           000087   347 _PCON	=	0x0087
                           0000BA   348 _POWER_CFG	=	0x00ba
                           0000B9   349 _CLOCK_CFG	=	0x00b9
                           0000A9   350 _WAKE_CTRL	=	0x00a9
                           0000FE   351 _RESET_KEEP	=	0x00fe
                           0000FF   352 _WDOG_COUNT	=	0x00ff
                           0000A8   353 _IE	=	0x00a8
                           0000B8   354 _IP	=	0x00b8
                           0000E8   355 _IE_EX	=	0x00e8
                           0000E9   356 _IP_EX	=	0x00e9
                           0000B2   357 _GPIO_IE	=	0x00b2
                           008584   358 _ROM_ADDR	=	0x8584
                           000084   359 _ROM_ADDR_L	=	0x0084
                           000085   360 _ROM_ADDR_H	=	0x0085
                           008F8E   361 _ROM_DATA_HI	=	0x8f8e
                           00008E   362 _ROM_DATA_HL	=	0x008e
                           00008F   363 _ROM_DATA_HH	=	0x008f
                           000086   364 _ROM_CTRL	=	0x0086
                           000080   365 _P0	=	0x0080
                           0000C4   366 _P0_MOD_OC	=	0x00c4
                           0000C5   367 _P0_DIR_PU	=	0x00c5
                           000090   368 _P1	=	0x0090
                           000092   369 _P1_MOD_OC	=	0x0092
                           000093   370 _P1_DIR_PU	=	0x0093
                           0000A0   371 _P2	=	0x00a0
                           000094   372 _P2_MOD_OC	=	0x0094
                           000095   373 _P2_DIR_PU	=	0x0095
                           0000B0   374 _P3	=	0x00b0
                           000096   375 _P3_MOD_OC	=	0x0096
                           000097   376 _P3_DIR_PU	=	0x0097
                           0000C0   377 _P4	=	0x00c0
                           0000C2   378 _P4_MOD_OC	=	0x00c2
                           0000C3   379 _P4_DIR_PU	=	0x00c3
                           0000C1   380 _P4_LED_KEY	=	0x00c1
                           0000AA   381 _P5_IN	=	0x00aa
                           0000AB   382 _P5_OUT_PU	=	0x00ab
                           0000AC   383 _P5_DIR	=	0x00ac
                           0000AD   384 _P6_IN	=	0x00ad
                           0000AE   385 _P6_OUT_PU	=	0x00ae
                           0000AF   386 _P6_DIR	=	0x00af
                           0000F1   387 _P7	=	0x00f1
                           0000A2   388 _XBUS_AUX	=	0x00a2
                           000088   389 _TCON	=	0x0088
                           000089   390 _TMOD	=	0x0089
                           00008A   391 _TL0	=	0x008a
                           00008B   392 _TL1	=	0x008b
                           00008C   393 _TH0	=	0x008c
                           00008D   394 _TH1	=	0x008d
                           000098   395 _SCON	=	0x0098
                           000099   396 _SBUF	=	0x0099
                           0000C8   397 _T2CON	=	0x00c8
                           0000C9   398 _T2MOD	=	0x00c9
                           00CBCA   399 _RCAP2	=	0xcbca
                           0000CA   400 _RCAP2L	=	0x00ca
                           0000CB   401 _RCAP2H	=	0x00cb
                           00CDCC   402 _T2COUNT	=	0xcdcc
                           0000CC   403 _TL2	=	0x00cc
                           0000CD   404 _TH2	=	0x00cd
                           00CFCE   405 _T2CAP1	=	0xcfce
                           0000CE   406 _T2CAP1L	=	0x00ce
                           0000CF   407 _T2CAP1H	=	0x00cf
                           0000F8   408 _SPI0_STAT	=	0x00f8
                           0000F9   409 _SPI0_DATA	=	0x00f9
                           0000FA   410 _SPI0_CTRL	=	0x00fa
                           0000FB   411 _SPI0_CK_SE	=	0x00fb
                           0000FC   412 _SPI0_SETUP	=	0x00fc
                           0000BC   413 _SCON1	=	0x00bc
                           0000BD   414 _SBUF1	=	0x00bd
                           0000BE   415 _SBAUD1	=	0x00be
                           0000BF   416 _SIF1	=	0x00bf
                           0000B4   417 _SPI1_STAT	=	0x00b4
                           0000B5   418 _SPI1_DATA	=	0x00b5
                           0000B6   419 _SPI1_CTRL	=	0x00b6
                           0000B7   420 _SPI1_CK_SE	=	0x00b7
                           0000F3   421 _ADC_CTRL	=	0x00f3
                           00F5F4   422 _ADC_DAT	=	0xf5f4
                           0000F4   423 _ADC_DAT_L	=	0x00f4
                           0000F5   424 _ADC_DAT_H	=	0x00f5
                           0000F6   425 _ADC_CHAN	=	0x00f6
                           0000A6   426 _LED_COMMON	=	0x00a6
                           0000A7   427 _LED_PWM_OE	=	0x00a7
                           00C7C6   428 _LED_DMA	=	0xc7c6
                           0000C6   429 _LED_DMA_L	=	0x00c6
                           0000C7   430 _LED_DMA_H	=	0x00c7
                           0000F7   431 _LED_STATUS	=	0x00f7
                           0000B3   432 _I2CX_INT	=	0x00b3
                           0000BB   433 _I2CS_INT_ST	=	0x00bb
                                    434 ;--------------------------------------------------------
                                    435 ; special function bits
                                    436 ;--------------------------------------------------------
                                    437 	.area RSEG    (ABS,DATA)
      000000                        438 	.org 0x0000
                           0000D7   439 _CY	=	0x00d7
                           0000D6   440 _AC	=	0x00d6
                           0000D5   441 _F0	=	0x00d5
                           0000D4   442 _RS1	=	0x00d4
                           0000D3   443 _RS0	=	0x00d3
                           0000D2   444 _OV	=	0x00d2
                           0000D1   445 _F1	=	0x00d1
                           0000D0   446 _P	=	0x00d0
                           0000AF   447 _EA	=	0x00af
                           0000AE   448 _E_DIS	=	0x00ae
                           0000AD   449 _ET2	=	0x00ad
                           0000AC   450 _ES	=	0x00ac
                           0000AB   451 _ET1	=	0x00ab
                           0000AA   452 _EX1	=	0x00aa
                           0000A9   453 _ET0	=	0x00a9
                           0000A8   454 _EX0	=	0x00a8
                           0000BF   455 _PH_FLAG	=	0x00bf
                           0000BE   456 _PL_FLAG	=	0x00be
                           0000BD   457 _PT2	=	0x00bd
                           0000BC   458 _PS	=	0x00bc
                           0000BB   459 _PT1	=	0x00bb
                           0000BA   460 _PX1	=	0x00ba
                           0000B9   461 _PT0	=	0x00b9
                           0000B8   462 _PX0	=	0x00b8
                           0000EF   463 _IE_WDOG	=	0x00ef
                           0000EE   464 _IE_GPIO	=	0x00ee
                           0000ED   465 _IE_PWM_I2C	=	0x00ed
                           0000EC   466 _IE_UART1	=	0x00ec
                           0000EB   467 _IE_ADC	=	0x00eb
                           0000E9   468 _IE_USB	=	0x00e9
                           0000E8   469 _IE_SPI0	=	0x00e8
                           000087   470 _P0_7	=	0x0087
                           000086   471 _P0_6	=	0x0086
                           000085   472 _P0_5	=	0x0085
                           000084   473 _P0_4	=	0x0084
                           000083   474 _P0_3	=	0x0083
                           000082   475 _P0_2	=	0x0082
                           000081   476 _P0_1	=	0x0081
                           000080   477 _P0_0	=	0x0080
                           000081   478 _SDA0	=	0x0081
                           000080   479 _SCL0	=	0x0080
                           000083   480 _TXD_	=	0x0083
                           000082   481 _RXD_	=	0x0082
                           000085   482 _AIN13	=	0x0085
                           000084   483 _AIN12	=	0x0084
                           000083   484 _AIN11	=	0x0083
                           000082   485 _AIN10	=	0x0082
                           000081   486 _AIN9	=	0x0081
                           000080   487 _AIN8	=	0x0080
                           000097   488 _P1_7	=	0x0097
                           000096   489 _P1_6	=	0x0096
                           000095   490 _P1_5	=	0x0095
                           000094   491 _P1_4	=	0x0094
                           000093   492 _P1_3	=	0x0093
                           000092   493 _P1_2	=	0x0092
                           000091   494 _P1_1	=	0x0091
                           000090   495 _P1_0	=	0x0090
                           000097   496 _TXD1_	=	0x0097
                           000096   497 _RXD1_	=	0x0096
                           000097   498 _SCK	=	0x0097
                           000096   499 _MISO	=	0x0096
                           000095   500 _MOSI	=	0x0095
                           000094   501 _SCS	=	0x0094
                           000092   502 _INT0_	=	0x0092
                           000091   503 _T2EX	=	0x0091
                           000091   504 _CAP2	=	0x0091
                           000090   505 _T2	=	0x0090
                           000090   506 _CAP1	=	0x0090
                           000097   507 _AIN7	=	0x0097
                           000096   508 _AIN6	=	0x0096
                           000095   509 _AIN5	=	0x0095
                           000094   510 _AIN4	=	0x0094
                           000093   511 _AIN3	=	0x0093
                           000092   512 _AIN2	=	0x0092
                           000091   513 _AIN1	=	0x0091
                           000090   514 _AIN0	=	0x0090
                           0000A7   515 _P2_7	=	0x00a7
                           0000A6   516 _P2_6	=	0x00a6
                           0000A5   517 _P2_5	=	0x00a5
                           0000A4   518 _P2_4	=	0x00a4
                           0000A3   519 _P2_3	=	0x00a3
                           0000A2   520 _P2_2	=	0x00a2
                           0000A1   521 _P2_1	=	0x00a1
                           0000A0   522 _P2_0	=	0x00a0
                           0000A7   523 _TXD1	=	0x00a7
                           0000A6   524 _RXD1	=	0x00a6
                           0000A5   525 _T2EX_	=	0x00a5
                           0000A5   526 _CAP2_	=	0x00a5
                           0000A4   527 _T2_	=	0x00a4
                           0000A4   528 _CAP1_	=	0x00a4
                           0000B7   529 _P3_7	=	0x00b7
                           0000B6   530 _P3_6	=	0x00b6
                           0000B5   531 _P3_5	=	0x00b5
                           0000B4   532 _P3_4	=	0x00b4
                           0000B3   533 _P3_3	=	0x00b3
                           0000B2   534 _P3_2	=	0x00b2
                           0000B1   535 _P3_1	=	0x00b1
                           0000B0   536 _P3_0	=	0x00b0
                           0000B7   537 _SCK1	=	0x00b7
                           0000B6   538 _MISO1	=	0x00b6
                           0000B5   539 _MOSI1	=	0x00b5
                           0000B5   540 _T1	=	0x00b5
                           0000B4   541 _T0	=	0x00b4
                           0000B3   542 _INT1	=	0x00b3
                           0000B2   543 _INT0	=	0x00b2
                           0000B1   544 _TXD	=	0x00b1
                           0000B0   545 _RXD	=	0x00b0
                           0000C6   546 _P4_6	=	0x00c6
                           0000C5   547 _P4_5	=	0x00c5
                           0000C4   548 _P4_4	=	0x00c4
                           0000C3   549 _P4_3	=	0x00c3
                           0000C2   550 _P4_2	=	0x00c2
                           0000C1   551 _P4_1	=	0x00c1
                           0000C0   552 _P4_0	=	0x00c0
                           00008F   553 _TF1	=	0x008f
                           00008E   554 _TR1	=	0x008e
                           00008D   555 _TF0	=	0x008d
                           00008C   556 _TR0	=	0x008c
                           00008B   557 _IE1	=	0x008b
                           00008A   558 _IT1	=	0x008a
                           000089   559 _IE0	=	0x0089
                           000088   560 _IT0	=	0x0088
                           00009F   561 _SM0	=	0x009f
                           00009E   562 _SM1	=	0x009e
                           00009D   563 _SM2	=	0x009d
                           00009C   564 _REN	=	0x009c
                           00009B   565 _TB8	=	0x009b
                           00009A   566 _RB8	=	0x009a
                           000099   567 _TI	=	0x0099
                           000098   568 _RI	=	0x0098
                           0000CF   569 _TF2	=	0x00cf
                           0000CF   570 _CAP1F	=	0x00cf
                           0000CE   571 _EXF2	=	0x00ce
                           0000CD   572 _RCLK	=	0x00cd
                           0000CC   573 _TCLK	=	0x00cc
                           0000CB   574 _EXEN2	=	0x00cb
                           0000CA   575 _TR2	=	0x00ca
                           0000C9   576 _C_T2	=	0x00c9
                           0000C8   577 _CP_RL2	=	0x00c8
                           0000FF   578 _S0_FST_ACT	=	0x00ff
                           0000FE   579 _S0_IF_OV	=	0x00fe
                           0000FD   580 _S0_IF_FIRST	=	0x00fd
                           0000FC   581 _S0_IF_BYTE	=	0x00fc
                           0000FB   582 _S0_FREE	=	0x00fb
                           0000FA   583 _S0_T_FIFO	=	0x00fa
                           0000F8   584 _S0_R_FIFO	=	0x00f8
                           0000F7   585 _ADC_START	=	0x00f7
                                    586 ;--------------------------------------------------------
                                    587 ; overlayable register banks
                                    588 ;--------------------------------------------------------
                                    589 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        590 	.ds 8
                                    591 ;--------------------------------------------------------
                                    592 ; internal ram data
                                    593 ;--------------------------------------------------------
                                    594 	.area DSEG    (DATA)
      000027                        595 _process_record_sloc0_1_0:
      000027                        596 	.ds 1
      000028                        597 _process_action_sloc0_1_0:
      000028                        598 	.ds 1
                                    599 ;--------------------------------------------------------
                                    600 ; overlayable items in internal ram
                                    601 ;--------------------------------------------------------
                                    602 ;--------------------------------------------------------
                                    603 ; indirectly addressable internal ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area ISEG    (DATA)
                                    606 ;--------------------------------------------------------
                                    607 ; absolute internal ram data
                                    608 ;--------------------------------------------------------
                                    609 	.area IABS    (ABS,DATA)
                                    610 	.area IABS    (ABS,DATA)
                                    611 ;--------------------------------------------------------
                                    612 ; bit data
                                    613 ;--------------------------------------------------------
                                    614 	.area BSEG    (BIT)
      000020                        615 _process_action_sloc1_1_0:
      000020                        616 	.ds 1
                                    617 ;--------------------------------------------------------
                                    618 ; paged external ram data
                                    619 ;--------------------------------------------------------
                                    620 	.area PSEG    (PAG,XDATA)
                                    621 ;--------------------------------------------------------
                                    622 ; uninitialized external ram data
                                    623 ;--------------------------------------------------------
                                    624 	.area XSEG    (XDATA)
      000870                        625 _tp_buttons::
      000870                        626 	.ds 2
      000872                        627 _action_exec_PARM_1:
      000872                        628 	.ds 6
      000878                        629 _action_exec_record_10001_633:
      000878                        630 	.ds 9
      000881                        631 _ak820_action_exec_event_10000_638:
      000881                        632 	.ds 2
      000883                        633 _ak820_action_exec_snapshot_10000_639:
      000883                        634 	.ds 6
      000889                        635 _process_record_record_argument_10000_642:
      000889                        636 	.ds 2
      00088B                        637 _process_record_handler_record_argument_10000_651:
      00088B                        638 	.ds 2
      00088D                        639 _process_record_handler_action_10000_652:
      00088D                        640 	.ds 2
      00088F                        641 _process_action_PARM_2:
      00088F                        642 	.ds 2
      000891                        643 _process_action_record_argument_10000_663:
      000891                        644 	.ds 2
      000893                        645 _process_action_on_40000_686:
      000893                        646 	.ds 1
      000894                        647 _register_code_code_10000_720:
      000894                        648 	.ds 1
      000895                        649 _unregister_code_code_10000_734:
      000895                        650 	.ds 1
      000896                        651 _tap_code_delay_PARM_2:
      000896                        652 	.ds 2
      000898                        653 _tap_code_delay_code_10000_747:
      000898                        654 	.ds 1
      000899                        655 _tap_code_code_10000_754:
      000899                        656 	.ds 1
      00089A                        657 _register_mods_mods_10000_756:
      00089A                        658 	.ds 1
      00089B                        659 _unregister_mods_mods_10000_760:
      00089B                        660 	.ds 1
      00089C                        661 _register_weak_mods_mods_10000_764:
      00089C                        662 	.ds 1
      00089D                        663 _unregister_weak_mods_mods_10000_768:
      00089D                        664 	.ds 1
                                    665 ;--------------------------------------------------------
                                    666 ; absolute external ram data
                                    667 ;--------------------------------------------------------
                                    668 	.area XABS    (ABS,XDATA)
                                    669 ;--------------------------------------------------------
                                    670 ; initialized external ram data
                                    671 ;--------------------------------------------------------
                                    672 	.area XISEG   (XDATA)
      000DF7                        673 _disable_action_cache::
      000DF7                        674 	.ds 1
                                    675 	.area HOME    (CODE)
                                    676 	.area GSINIT0 (CODE)
                                    677 	.area GSINIT1 (CODE)
                                    678 	.area GSINIT2 (CODE)
                                    679 	.area GSINIT3 (CODE)
                                    680 	.area GSINIT4 (CODE)
                                    681 	.area GSINIT5 (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 	.area GSFINAL (CODE)
                                    684 	.area CSEG    (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; global & static initialisations
                                    687 ;--------------------------------------------------------
                                    688 	.area HOME    (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area GSINIT  (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; Home
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area HOME    (CODE)
                                    697 ;--------------------------------------------------------
                                    698 ; code
                                    699 ;--------------------------------------------------------
                                    700 	.area CSEG    (CODE)
                                    701 ;------------------------------------------------------------
                                    702 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    703 ;------------------------------------------------------------
                                    704 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    705 ;------------------------------------------------------------
                                    706 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    707 ;	-----------------------------------------
                           000007   708 	ar7 = 0x07
                           000006   709 	ar6 = 0x06
                           000005   710 	ar5 = 0x05
                           000004   711 	ar4 = 0x04
                           000003   712 	ar3 = 0x03
                           000002   713 	ar2 = 0x02
                           000001   714 	ar1 = 0x01
                           000000   715 	ar0 = 0x00
                                    716 ;	 function action_exec
                                    717 ;	-----------------------------------------
      007525                        718 _action_exec:
                                    719 ;	quantum/action.c:98: ak820_dynamic_macro_task(event.time);
      007525 90 08 74         [24]  720 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007528 12 39 E0         [24]  721 	lcall	_ak820_outline_0004
      00752B 12 3D 20         [24]  722 	lcall	_ak820_dynamic_macro_task
                                    723 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      00752E 90 08 74         [24]  724 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007531 12 39 E0         [24]  725 	lcall	_ak820_outline_0004
      007534 12 37 FD         [24]  726 	lcall	_ak820_combo_tick
                                    727 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      007537 90 08 72         [24]  728 	mov	dptr,#_action_exec_PARM_1
      00753A 12 49 A6         [24]  729 	lcall	_ak820_tapping_before
      00753D E5 82            [12]  730 	mov	a, dpl
      00753F 70 01            [24]  731 	jnz	00102$
      007541 22               [24]  732 	ret
      007542                        733 00102$:
                                    734 ;	quantum/action.c:110: if (!ak820_autoshift_before(&event)) return;
      007542 90 08 72         [24]  735 	mov	dptr,#_action_exec_PARM_1
      007545 12 31 2A         [24]  736 	lcall	_ak820_autoshift_before
      007548 E5 82            [12]  737 	mov	a, dpl
      00754A 70 01            [24]  738 	jnz	00104$
      00754C 22               [24]  739 	ret
      00754D                        740 00104$:
                                    741 ;	quantum/action.c:126: if (event.pressed) {
      00754D 90 08 77         [24]  742 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007550 E0               [24]  743 	movx	a,@dptr
      007551 60 03            [24]  744 	jz	00106$
                                    745 ;	quantum/action.c:128: clear_weak_mods();
      007553 12 85 BD         [24]  746 	lcall	_clear_weak_mods
      007556                        747 00106$:
                                    748 ;	quantum/action.c:140: record.event = event;
      007556 90 0D D6         [24]  749 	mov	dptr,#___memcpy_PARM_2
      007559 74 72            [12]  750 	mov	a,#_action_exec_PARM_1
      00755B F0               [24]  751 	movx	@dptr,a
      00755C 74 08            [12]  752 	mov	a,#(_action_exec_PARM_1 >> 8)
      00755E 12 7C 4F         [24]  753 	lcall	_ak820_outline_0050
      007561 12 7C 6F         [24]  754 	lcall	_ak820_outline_0108
      007564 90 08 78         [24]  755 	mov	dptr,#_action_exec_record_10001_633
      007567 F5 F0            [12]  756 	mov	b,a
      007569 12 BB 7E         [24]  757 	lcall	___memcpy
                                    758 ;	quantum/action.c:142: record.tap.count = 0;
      00756C 90 08 7E         [24]  759 	mov	dptr,#(_action_exec_record_10001_633 + 0x0006)
      00756F E0               [24]  760 	movx	a,@dptr
      007570 54 0F            [12]  761 	anl	a,#0x0f
      007572 F0               [24]  762 	movx	@dptr,a
                                    763 ;	quantum/action.c:147: record.keycode = 0;
      007573 90 08 7F         [24]  764 	mov	dptr,#(_action_exec_record_10001_633 + 0x0007)
      007576 12 54 74         [24]  765 	lcall	_ak820_outline_0178
                                    766 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007579 90 08 7C         [24]  767 	mov	dptr,#(_action_exec_record_10001_633 + 0x0004)
      00757C E0               [24]  768 	movx	a,@dptr
      00757D 60 0A            [24]  769 	jz	00111$
      00757F 90 08 78         [24]  770 	mov	dptr,#_action_exec_record_10001_633
      007582 12 A2 DE         [24]  771 	lcall	_pre_process_record_quantum
      007585 E5 82            [12]  772 	mov	a, dpl
      007587 60 1B            [24]  773 	jz	00114$
      007589                        774 00111$:
                                    775 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      007589 90 08 78         [24]  776 	mov	dptr,#_action_exec_record_10001_633
      00758C 12 4A 90         [24]  777 	lcall	_ak820_tapping_process
      00758F E5 82            [12]  778 	mov	a, dpl
      007591 70 01            [24]  779 	jnz	00108$
      007593 22               [24]  780 	ret
      007594                        781 00108$:
                                    782 ;	quantum/action.c:182: if (!ak820_autoshift_process(&record)) return;
      007594 90 08 78         [24]  783 	mov	dptr,#_action_exec_record_10001_633
      007597 12 32 30         [24]  784 	lcall	_ak820_autoshift_process
      00759A E5 82            [12]  785 	mov	a, dpl
      00759C 70 01            [24]  786 	jnz	00110$
      00759E 22               [24]  787 	ret
      00759F                        788 00110$:
                                    789 ;	quantum/action.c:185: process_record(&record);
      00759F 90 08 78         [24]  790 	mov	dptr,#_action_exec_record_10001_633
                                    791 ;	quantum/action.c:200: }
      0075A2 A1 E1            [12]  792 	ajmp	_process_record
      0075A4                        793 00114$:
      0075A4 22               [24]  794 	ret
                                    795 ;------------------------------------------------------------
                                    796 ;Allocation info for local variables in function 'ak820_action_exec'
                                    797 ;------------------------------------------------------------
                                    798 ;event         Allocated with name '_ak820_action_exec_event_10000_638'
                                    799 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_639'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function ak820_action_exec
                                    804 ;	-----------------------------------------
      0075A5                        805 _ak820_action_exec:
      0075A5 12 3A 8A         [24]  806 	lcall	_ak820_outline_0104
      0075A8 90 08 81         [24]  807 	mov	dptr,#_ak820_action_exec_event_10000_638
      0075AB 12 3A 8F         [24]  808 	lcall	_ak820_outline_0105
                                    809 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      0075AE 90 08 81         [24]  810 	mov	dptr,#_ak820_action_exec_event_10000_638
      0075B1 12 3A 57         [24]  811 	lcall	_ak820_outline_0057
      0075B4 90 0D D6         [24]  812 	mov	dptr,#___memcpy_PARM_2
      0075B7 ED               [12]  813 	mov	a,r5
      0075B8 12 3A 1F         [24]  814 	lcall	_ak820_outline_0015
      0075BB 90 0D D9         [24]  815 	mov	dptr,#___memcpy_PARM_3
      0075BE 12 7C 6F         [24]  816 	lcall	_ak820_outline_0108
      0075C1 90 08 83         [24]  817 	mov	dptr,#_ak820_action_exec_snapshot_10000_639
      0075C4 F5 F0            [12]  818 	mov	b,a
      0075C6 12 BB 7E         [24]  819 	lcall	___memcpy
                                    820 ;	quantum/action.c:207: action_exec(snapshot);
      0075C9 90 0D D6         [24]  821 	mov	dptr,#___memcpy_PARM_2
      0075CC 74 83            [12]  822 	mov	a,#_ak820_action_exec_snapshot_10000_639
      0075CE F0               [24]  823 	movx	@dptr,a
      0075CF 74 08            [12]  824 	mov	a,#(_ak820_action_exec_snapshot_10000_639 >> 8)
      0075D1 12 7C 4F         [24]  825 	lcall	_ak820_outline_0050
      0075D4 12 7C 6F         [24]  826 	lcall	_ak820_outline_0108
      0075D7 90 08 72         [24]  827 	mov	dptr,#_action_exec_PARM_1
      0075DA F5 F0            [12]  828 	mov	b,a
      0075DC 12 BB 7E         [24]  829 	lcall	___memcpy
                                    830 ;	quantum/action.c:208: }
      0075DF A1 25            [12]  831 	ajmp	_action_exec
                                    832 ;------------------------------------------------------------
                                    833 ;Allocation info for local variables in function 'process_record_nocache'
                                    834 ;------------------------------------------------------------
                                    835 ;record        Allocated with name '_process_record_nocache_record_10000_640'
                                    836 ;------------------------------------------------------------
                                    837 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    838 ;	-----------------------------------------
                                    839 ;	 function process_record
                                    840 ;	-----------------------------------------
      0075E1                        841 _process_record:
      0075E1 12 3A 8A         [24]  842 	lcall	_ak820_outline_0104
      0075E4 90 08 89         [24]  843 	mov	dptr,#_process_record_record_argument_10000_642
      0075E7 12 3A 8F         [24]  844 	lcall	_ak820_outline_0105
                                    845 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0075EA 90 08 89         [24]  846 	mov	dptr,#_process_record_record_argument_10000_642
      0075ED 12 3A 40         [24]  847 	lcall	_ak820_outline_0051
                                    848 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      0075F0 74 04            [12]  849 	mov	a,#0x04
      0075F2 12 4D 60         [24]  850 	lcall	_ak820_outline_0011
      0075F5 70 01            [24]  851 	jnz	00102$
                                    852 ;	quantum/action.c:354: return;
      0075F7 22               [24]  853 	ret
      0075F8                        854 00102$:
                                    855 ;	quantum/action.c:358: if (record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !ak820_macro_primitive &&
      0075F8 12 3A 6B         [24]  856 	lcall	_ak820_outline_0075
      0075FB FD               [12]  857 	mov	r5,a
      0075FC BD 10 00         [24]  858 	cjne	r5,#0x10,00192$
      0075FF                        859 00192$:
      0075FF 50 3D            [24]  860 	jnc	00104$
      007601 12 3A 78         [24]  861 	lcall	_ak820_outline_0093
      007604 FD               [12]  862 	mov	r5,a
      007605 BD 08 00         [24]  863 	cjne	r5,#0x08,00194$
      007608                        864 00194$:
      007608 50 34            [24]  865 	jnc	00104$
      00760A 90 09 E2         [24]  866 	mov	dptr,#_ak820_macro_primitive
      00760D E0               [24]  867 	movx	a,@dptr
      00760E 70 2E            [24]  868 	jnz	00104$
                                    869 ;	quantum/action.c:359: !ak820_dynamic_macro_process(get_record_keycode(record, true), record->event.pressed)) return;
      007610 90 0C 38         [24]  870 	mov	dptr,#_get_record_keycode_PARM_2
      007613 12 4D 9F         [24]  871 	lcall	_ak820_outline_0043
      007616 C0 07            [24]  872 	push	ar7
      007618 C0 06            [24]  873 	push	ar6
      00761A 12 A2 A0         [24]  874 	lcall	_get_record_keycode
      00761D 12 48 C3         [24]  875 	lcall	_ak820_outline_0141
      007620 D0 06            [24]  876 	pop	ar6
      007622 D0 07            [24]  877 	pop	ar7
      007624 12 48 47         [24]  878 	lcall	_ak820_outline_0009
      007627 E0               [24]  879 	movx	a,@dptr
      007628 90 04 BA         [24]  880 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      00762B 12 3A 7E         [24]  881 	lcall	_ak820_outline_0098
      00762E C0 07            [24]  882 	push	ar7
      007630 C0 06            [24]  883 	push	ar6
      007632 12 3B 87         [24]  884 	lcall	_ak820_dynamic_macro_process
      007635 E5 82            [12]  885 	mov	a, dpl
      007637 D0 06            [24]  886 	pop	ar6
      007639 D0 07            [24]  887 	pop	ar7
      00763B 70 01            [24]  888 	jnz	00104$
      00763D 22               [24]  889 	ret
      00763E                        890 00104$:
                                    891 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      00763E 8E 04            [24]  892 	mov	ar4,r6
      007640 8F 05            [24]  893 	mov	ar5,r7
      007642 90 0D D6         [24]  894 	mov	dptr,#___memcpy_PARM_2
      007645 EC               [12]  895 	mov	a,r4
      007646 F0               [24]  896 	movx	@dptr,a
      007647 ED               [12]  897 	mov	a,r5
      007648 12 7C 4F         [24]  898 	lcall	_ak820_outline_0050
      00764B 12 54 66         [24]  899 	lcall	_ak820_outline_0107
      00764E 90 06 86         [24]  900 	mov	dptr,#_ak820_tapping_source_PARM_1
      007651 F5 F0            [12]  901 	mov	b,a
      007653 C0 07            [24]  902 	push	ar7
      007655 C0 06            [24]  903 	push	ar6
      007657 12 BB 7E         [24]  904 	lcall	___memcpy
      00765A 12 48 E3         [24]  905 	lcall	_ak820_tapping_source
      00765D AD 82            [24]  906 	mov	r5, dpl
      00765F D0 06            [24]  907 	pop	ar6
      007661 D0 07            [24]  908 	pop	ar7
                                    909 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      007663 12 48 47         [24]  910 	lcall	_ak820_outline_0009
      007666 E0               [24]  911 	movx	a,@dptr
      007667 FC               [12]  912 	mov	r4,a
                                    913 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      007668 74 07            [12]  914 	mov	a,#0x07
      00766A 2E               [12]  915 	add	a, r6
      00766B FA               [12]  916 	mov	r2,a
      00766C E4               [12]  917 	clr	a
      00766D 3F               [12]  918 	addc	a, r7
      00766E FB               [12]  919 	mov	r3,a
      00766F 90 0C 38         [24]  920 	mov	dptr,#_get_record_keycode_PARM_2
      007672 12 4D 9F         [24]  921 	lcall	_ak820_outline_0043
      007675 C0 07            [24]  922 	push	ar7
      007677 C0 06            [24]  923 	push	ar6
      007679 C0 05            [24]  924 	push	ar5
      00767B C0 04            [24]  925 	push	ar4
      00767D C0 03            [24]  926 	push	ar3
      00767F C0 02            [24]  927 	push	ar2
      007681 12 A2 A0         [24]  928 	lcall	_get_record_keycode
      007684 A8 82            [24]  929 	mov	r0, dpl
      007686 A9 83            [24]  930 	mov	r1, dph
      007688 D0 02            [24]  931 	pop	ar2
      00768A D0 03            [24]  932 	pop	ar3
      00768C D0 04            [24]  933 	pop	ar4
      00768E D0 05            [24]  934 	pop	ar5
      007690 D0 06            [24]  935 	pop	ar6
      007692 D0 07            [24]  936 	pop	ar7
      007694 12 48 BE         [24]  937 	lcall	_ak820_outline_0140
      007697 E8               [12]  938 	mov	a,r0
      007698 F0               [24]  939 	movx	@dptr,a
      007699 E9               [12]  940 	mov	a,r1
      00769A A3               [24]  941 	inc	dptr
      00769B F0               [24]  942 	movx	@dptr,a
                                    943 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      00769C 74 07            [12]  944 	mov	a,#0x07
      00769E 12 3A 27         [24]  945 	lcall	_ak820_outline_0016
      0076A1 FA               [12]  946 	mov	r2,a
      0076A2 A3               [24]  947 	inc	dptr
      0076A3 E0               [24]  948 	movx	a,@dptr
      0076A4 FB               [12]  949 	mov	r3,a
      0076A5 90 06 96         [24]  950 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0076A8 ED               [12]  951 	mov	a,r5
      0076A9 F0               [24]  952 	movx	@dptr,a
      0076AA 90 06 97         [24]  953 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0076AD EC               [12]  954 	mov	a,r4
      0076AE F0               [24]  955 	movx	@dptr,a
      0076AF 12 48 BE         [24]  956 	lcall	_ak820_outline_0140
      0076B2 C0 07            [24]  957 	push	ar7
      0076B4 C0 06            [24]  958 	push	ar6
      0076B6 C0 05            [24]  959 	push	ar5
      0076B8 C0 04            [24]  960 	push	ar4
      0076BA 12 4C 2C         [24]  961 	lcall	_ak820_oneshot_process
      0076BD E5 82            [12]  962 	mov	a, dpl
      0076BF D0 04            [24]  963 	pop	ar4
      0076C1 D0 05            [24]  964 	pop	ar5
      0076C3 D0 06            [24]  965 	pop	ar6
      0076C5 D0 07            [24]  966 	pop	ar7
      0076C7 70 01            [24]  967 	jnz	00109$
      0076C9 22               [24]  968 	ret
      0076CA                        969 00109$:
                                    970 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      0076CA 12 48 A2         [24]  971 	lcall	_ak820_outline_0116
      0076CD C0 07            [24]  972 	push	ar7
      0076CF C0 06            [24]  973 	push	ar6
      0076D1 C0 05            [24]  974 	push	ar5
      0076D3 C0 04            [24]  975 	push	ar4
      0076D5 12 A3 1F         [24]  976 	lcall	_process_record_quantum
      0076D8 E5 82            [12]  977 	mov	a, dpl
      0076DA D0 04            [24]  978 	pop	ar4
      0076DC D0 05            [24]  979 	pop	ar5
      0076DE D0 06            [24]  980 	pop	ar6
      0076E0 D0 07            [24]  981 	pop	ar7
      0076E2 70 0A            [24]  982 	jnz	00111$
                                    983 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0076E4 90 05 FE         [24]  984 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0076E7 EC               [12]  985 	mov	a,r4
      0076E8 F0               [24]  986 	movx	@dptr,a
      0076E9 8D 82            [24]  987 	mov	dpl, r5
                                    988 ;	quantum/action.c:376: return;
      0076EB 02 2E BB         [24]  989 	ljmp	_ak820_oneshot_post
      0076EE                        990 00111$:
                                    991 ;	quantum/action.c:380: ak820_dynamic_macro_source = record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !get_repeat_key_count() && !ak820_macro_primitive;
      0076EE 12 3A 6B         [24]  992 	lcall	_ak820_outline_0075
      0076F1 FB               [12]  993 	mov	r3,a
      0076F2 BB 10 00         [24]  994 	cjne	r3,#0x10,00200$
      0076F5                        995 00200$:
      0076F5 50 16            [24]  996 	jnc	00114$
      0076F7 12 3A 78         [24]  997 	lcall	_ak820_outline_0093
      0076FA FB               [12]  998 	mov	r3,a
      0076FB BB 08 00         [24]  999 	cjne	r3,#0x08,00202$
      0076FE                       1000 00202$:
      0076FE 50 0D            [24] 1001 	jnc	00114$
      007700 12 A5 9B         [24] 1002 	lcall	_get_repeat_key_count
      007703 E5 82            [12] 1003 	mov	a, dpl
      007705 70 06            [24] 1004 	jnz	00114$
      007707 90 09 E2         [24] 1005 	mov	dptr,#_ak820_macro_primitive
      00770A E0               [24] 1006 	movx	a,@dptr
      00770B 60 05            [24] 1007 	jz	00115$
      00770D                       1008 00114$:
      00770D 75 27 00         [24] 1009 	mov	_process_record_sloc0_1_0,#0x00
      007710 80 03            [24] 1010 	sjmp	00116$
      007712                       1011 00115$:
      007712 75 27 01         [24] 1012 	mov	_process_record_sloc0_1_0,#0x01
      007715                       1013 00116$:
      007715 90 04 B9         [24] 1014 	mov	dptr,#_ak820_dynamic_macro_source
      007718 E5 27            [12] 1015 	mov	a,_process_record_sloc0_1_0
      00771A 12 48 7D         [24] 1016 	lcall	_ak820_outline_0060
                                   1017 ;	quantum/action.c:382: process_record_handler(record);
      00771D C0 05            [24] 1018 	push	ar5
      00771F C0 04            [24] 1019 	push	ar4
      007721 F1 36            [24] 1020 	acall	_process_record_handler
      007723 D0 04            [24] 1021 	pop	ar4
      007725 D0 05            [24] 1022 	pop	ar5
                                   1023 ;	quantum/action.c:384: ak820_dynamic_macro_source = false;
      007727 90 04 B9         [24] 1024 	mov	dptr,#_ak820_dynamic_macro_source
      00772A E4               [12] 1025 	clr	a
      00772B F0               [24] 1026 	movx	@dptr,a
                                   1027 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00772C 90 05 FE         [24] 1028 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00772F EC               [12] 1029 	mov	a,r4
      007730 F0               [24] 1030 	movx	@dptr,a
      007731 8D 82            [24] 1031 	mov	dpl, r5
                                   1032 ;	quantum/action.c:392: }
      007733 02 2E BB         [24] 1033 	ljmp	_ak820_oneshot_post
                                   1034 ;------------------------------------------------------------
                                   1035 ;Allocation info for local variables in function 'process_record_handler'
                                   1036 ;------------------------------------------------------------
                                   1037 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_651'
                                   1038 ;record        Allocated with name '_process_record_handler_record_10000_652'
                                   1039 ;action        Allocated with name '_process_record_handler_action_10000_652'
                                   1040 ;------------------------------------------------------------
                                   1041 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1042 ;	-----------------------------------------
                                   1043 ;	 function process_record_handler
                                   1044 ;	-----------------------------------------
      007736                       1045 _process_record_handler:
      007736 12 3A 8A         [24] 1046 	lcall	_ak820_outline_0104
      007739 90 08 8B         [24] 1047 	mov	dptr,#_process_record_handler_record_argument_10000_651
      00773C 12 3A 8F         [24] 1048 	lcall	_ak820_outline_0105
                                   1049 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00773F 90 08 8B         [24] 1050 	mov	dptr,#_process_record_handler_record_argument_10000_651
      007742 12 39 F7         [24] 1051 	lcall	_ak820_outline_0008
                                   1052 ;	quantum/action.c:405: if (record->keycode) {
      007745 4C               [12] 1053 	orl	a,r4
      007746 60 19            [24] 1054 	jz	00102$
                                   1055 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      007748 12 3A A0         [24] 1056 	lcall	_ak820_outline_0121
      00774B C0 07            [24] 1057 	push	ar7
      00774D C0 06            [24] 1058 	push	ar6
      00774F 12 99 80         [24] 1059 	lcall	_action_for_keycode
      007752 12 48 C3         [24] 1060 	lcall	_ak820_outline_0141
      007755 D0 06            [24] 1061 	pop	ar6
      007757 D0 07            [24] 1062 	pop	ar7
      007759 90 08 8D         [24] 1063 	mov	dptr,#_process_record_handler_action_10000_652
      00775C 12 3A 65         [24] 1064 	lcall	_ak820_outline_0070
      00775F 80 2B            [24] 1065 	sjmp	00104$
      007761                       1066 00102$:
                                   1067 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007761 12 7C 37         [24] 1068 	lcall	_ak820_outline_0019
      007764 7A 00            [12] 1069 	mov	r2,#0x00
      007766 12 48 B8         [24] 1070 	lcall	_ak820_outline_0139
      007769 12 48 47         [24] 1071 	lcall	_ak820_outline_0009
      00776C E0               [24] 1072 	movx	a,@dptr
      00776D 90 09 C8         [24] 1073 	mov	dptr,#_ak820_resolve_key_PARM_2
      007770 F0               [24] 1074 	movx	@dptr,a
      007771 8D 82            [24] 1075 	mov	dpl, r5
      007773 8C 83            [24] 1076 	mov	dph, r4
      007775 C0 07            [24] 1077 	push	ar7
      007777 C0 06            [24] 1078 	push	ar6
      007779 12 7F C2         [24] 1079 	lcall	_ak820_resolve_key
      00777C 12 99 80         [24] 1080 	lcall	_action_for_keycode
      00777F 12 48 C3         [24] 1081 	lcall	_ak820_outline_0141
      007782 D0 06            [24] 1082 	pop	ar6
      007784 D0 07            [24] 1083 	pop	ar7
      007786 90 08 8D         [24] 1084 	mov	dptr,#_process_record_handler_action_10000_652
      007789 12 3A 65         [24] 1085 	lcall	_ak820_outline_0070
                                   1086 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      00778C                       1087 00104$:
                                   1088 ;	quantum/action.c:429: process_action(record, action);
      00778C 90 0D D6         [24] 1089 	mov	dptr,#___memcpy_PARM_2
      00778F 74 8D            [12] 1090 	mov	a,#_process_record_handler_action_10000_652
      007791 F0               [24] 1091 	movx	@dptr,a
      007792 74 08            [12] 1092 	mov	a,#(_process_record_handler_action_10000_652 >> 8)
      007794 12 7C 4F         [24] 1093 	lcall	_ak820_outline_0050
      007797 12 54 66         [24] 1094 	lcall	_ak820_outline_0107
      00779A 90 08 8F         [24] 1095 	mov	dptr,#_process_action_PARM_2
      00779D F5 F0            [12] 1096 	mov	b,a
      00779F C0 07            [24] 1097 	push	ar7
      0077A1 C0 06            [24] 1098 	push	ar6
      0077A3 12 BB 7E         [24] 1099 	lcall	___memcpy
      0077A6 D0 06            [24] 1100 	pop	ar6
      0077A8 D0 07            [24] 1101 	pop	ar7
      0077AA 12 48 A2         [24] 1102 	lcall	_ak820_outline_0116
                                   1103 ;	quantum/action.c:430: }
      0077AD E1 AF            [24] 1104 	ajmp	_process_action
                                   1105 ;------------------------------------------------------------
                                   1106 ;Allocation info for local variables in function 'register_mouse'
                                   1107 ;------------------------------------------------------------
                                   1108 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1109 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_660'
                                   1110 ;------------------------------------------------------------
                                   1111 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1112 ;	-----------------------------------------
                                   1113 ;	 function process_action
                                   1114 ;	-----------------------------------------
      0077AF                       1115 _process_action:
      0077AF 12 3A 8A         [24] 1116 	lcall	_ak820_outline_0104
      0077B2 90 08 91         [24] 1117 	mov	dptr,#_process_action_record_argument_10000_663
      0077B5 12 3A 8F         [24] 1118 	lcall	_ak820_outline_0105
                                   1119 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0077B8 90 08 91         [24] 1120 	mov	dptr,#_process_action_record_argument_10000_663
      0077BB 12 39 E0         [24] 1121 	lcall	_ak820_outline_0004
                                   1122 ;	quantum/action.c:501: pressed = record->event.pressed;
      0077BE A3               [24] 1123 	inc	dptr
      0077BF A3               [24] 1124 	inc	dptr
      0077C0 A3               [24] 1125 	inc	dptr
      0077C1 A3               [24] 1126 	inc	dptr
      0077C2 A3               [24] 1127 	inc	dptr
      0077C3 E0               [24] 1128 	movx	a,@dptr
      0077C4 F5 28            [12] 1129 	mov	_process_action_sloc0_1_0,a
                                   1130 ;	quantum/action.c:525: switch (action.kind.id) {
      0077C6 90 08 90         [24] 1131 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0077C9 E0               [24] 1132 	movx	a,@dptr
      0077CA C4               [12] 1133 	swap	a
      0077CB 54 0F            [12] 1134 	anl	a,#0x0f
      0077CD FD               [12] 1135 	mov  r5,a
      0077CE 24 F4            [12] 1136 	add	a,#0xff - 0x0b
      0077D0 50 03            [24] 1137 	jnc	00434$
      0077D2 02 7A 50         [24] 1138 	ljmp	00181$
      0077D5                       1139 00434$:
                                   1140 ;	free result
      0077D5 ED               [12] 1141 	mov	a,r5
      0077D6 24 0A            [12] 1142 	add	a,#(00435$-3-.)
      0077D8 83               [24] 1143 	movc	a,@a+pc
      0077D9 F5 82            [12] 1144 	mov	dpl,a
      0077DB ED               [12] 1145 	mov	a,r5
      0077DC 24 10            [12] 1146 	add	a,#(00436$-3-.)
      0077DE 83               [24] 1147 	movc	a,@a+pc
      0077DF F5 83            [12] 1148 	mov	dph,a
      0077E1 E4               [12] 1149 	clr	a
      0077E2 73               [24] 1150 	jmp	@a+dptr
      0077E3                       1151 00435$:
      0077E3 FB                    1152 	.db	00102$
      0077E4 FB                    1153 	.db	00102$
      0077E5 50                    1154 	.db	00181$
      0077E6 50                    1155 	.db	00181$
      0077E7 85                    1156 	.db	00123$
      0077E8 50                    1157 	.db	00181$
      0077E9 50                    1158 	.db	00181$
      0077EA 50                    1159 	.db	00181$
      0077EB E5                    1160 	.db	00131$
      0077EC B7                    1161 	.db	00147$
      0077ED DD                    1162 	.db	00152$
      0077EE DD                    1163 	.db	00152$
      0077EF                       1164 00436$:
      0077EF 77                    1165 	.db	00102$>>8
      0077F0 77                    1166 	.db	00102$>>8
      0077F1 7A                    1167 	.db	00181$>>8
      0077F2 7A                    1168 	.db	00181$>>8
      0077F3 78                    1169 	.db	00123$>>8
      0077F4 7A                    1170 	.db	00181$>>8
      0077F5 7A                    1171 	.db	00181$>>8
      0077F6 7A                    1172 	.db	00181$>>8
      0077F7 78                    1173 	.db	00131$>>8
      0077F8 79                    1174 	.db	00147$>>8
      0077F9 79                    1175 	.db	00152$>>8
      0077FA 79                    1176 	.db	00152$>>8
                                   1177 ;	quantum/action.c:528: case ACT_RMODS: {
      0077FB                       1178 00102$:
                                   1179 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0077FB 90 08 90         [24] 1180 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0077FE E0               [24] 1181 	movx	a,@dptr
      0077FF 54 F0            [12] 1182 	anl	a,#0xf0
      007801 70 06            [24] 1183 	jnz	00194$
      007803 12 7C 76         [24] 1184 	lcall	_ak820_outline_0109
      007806 FD               [12] 1185 	mov	r5,a
      007807 80 07            [24] 1186 	sjmp	00195$
      007809                       1187 00194$:
      007809 12 7C 76         [24] 1188 	lcall	_ak820_outline_0109
      00780C C4               [12] 1189 	swap	a
      00780D 54 F0            [12] 1190 	anl	a,#0xf0
      00780F FD               [12] 1191 	mov	r5,a
      007810                       1192 00195$:
                                   1193 ;	quantum/action.c:531: if (pressed) {
      007810 E5 28            [12] 1194 	mov	a,_process_action_sloc0_1_0
      007812 60 35            [24] 1195 	jz	00119$
                                   1196 ;	quantum/action.c:532: if (mods) {
      007814 ED               [12] 1197 	mov	a,r5
      007815 60 29            [24] 1198 	jz	00110$
                                   1199 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007817 12 7C 88         [24] 1200 	lcall	_ak820_outline_0154
      00781A FC               [12] 1201 	mov	r4,a
      00781B BC E0 00         [24] 1202 	cjne	r4,#0xe0,00440$
      00781E                       1203 00440$:
      00781E 40 07            [24] 1204 	jc	00108$
      007820 12 7C 88         [24] 1205 	lcall	_ak820_outline_0154
      007823 24 18            [12] 1206 	add	a,#0xff - 0xe7
      007825 50 0A            [24] 1207 	jnc	00104$
                                   1208 ;	free result
      007827                       1209 00108$:
      007827 7B 8F            [12] 1210 	mov	r3,#_process_action_PARM_2
      007829 7C 08            [12] 1211 	mov	r4,#(_process_action_PARM_2 >> 8)
      00782B 12 36 42         [24] 1212 	lcall	_ak820_outline_0122
      00782E E0               [24] 1213 	movx	a,@dptr
      00782F 70 07            [24] 1214 	jnz	00105$
      007831                       1215 00104$:
                                   1216 ;	quantum/action.c:537: add_owned_mods(mods);
      007831 8D 82            [24] 1217 	mov	dpl, r5
      007833 12 81 DC         [24] 1218 	lcall	_add_owned_mods
      007836 80 05            [24] 1219 	sjmp	00106$
      007838                       1220 00105$:
                                   1221 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      007838 8D 82            [24] 1222 	mov	dpl, r5
      00783A 12 81 F8         [24] 1223 	lcall	_add_owned_weak_mods
      00783D                       1224 00106$:
                                   1225 ;	quantum/action.c:541: send_keyboard_report();
      00783D 12 85 0D         [24] 1226 	lcall	_send_keyboard_report
      007840                       1227 00110$:
                                   1228 ;	quantum/action.c:543: register_code(action.key.code);
      007840 12 7C 5F         [24] 1229 	lcall	_ak820_outline_0076
      007843 12 7A 67         [24] 1230 	lcall	_register_code
      007846 02 7A 50         [24] 1231 	ljmp	00181$
      007849                       1232 00119$:
                                   1233 ;	quantum/action.c:545: unregister_code(action.key.code);
      007849 12 7C 5F         [24] 1234 	lcall	_ak820_outline_0076
      00784C C0 05            [24] 1235 	push	ar5
      00784E 12 7A E3         [24] 1236 	lcall	_unregister_code
      007851 D0 05            [24] 1237 	pop	ar5
                                   1238 ;	quantum/action.c:546: if (mods) {
      007853 ED               [12] 1239 	mov	a,r5
      007854 70 03            [24] 1240 	jnz	00444$
      007856 02 7A 50         [24] 1241 	ljmp	00181$
      007859                       1242 00444$:
                                   1243 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007859 12 7C 88         [24] 1244 	lcall	_ak820_outline_0154
      00785C FC               [12] 1245 	mov	r4,a
      00785D BC E0 00         [24] 1246 	cjne	r4,#0xe0,00445$
      007860                       1247 00445$:
      007860 40 07            [24] 1248 	jc	00115$
      007862 12 7C 88         [24] 1249 	lcall	_ak820_outline_0154
      007865 24 18            [12] 1250 	add	a,#0xff - 0xe7
      007867 50 0A            [24] 1251 	jnc	00111$
                                   1252 ;	free result
      007869                       1253 00115$:
      007869 7B 8F            [12] 1254 	mov	r3,#_process_action_PARM_2
      00786B 7C 08            [12] 1255 	mov	r4,#(_process_action_PARM_2 >> 8)
      00786D 12 36 42         [24] 1256 	lcall	_ak820_outline_0122
      007870 E0               [24] 1257 	movx	a,@dptr
      007871 70 07            [24] 1258 	jnz	00112$
      007873                       1259 00111$:
                                   1260 ;	quantum/action.c:548: del_owned_mods(mods);
      007873 8D 82            [24] 1261 	mov	dpl, r5
      007875 12 81 EB         [24] 1262 	lcall	_del_owned_mods
      007878 80 05            [24] 1263 	sjmp	00113$
      00787A                       1264 00112$:
                                   1265 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      00787A 8D 82            [24] 1266 	mov	dpl, r5
      00787C 12 82 07         [24] 1267 	lcall	_del_owned_weak_mods
      00787F                       1268 00113$:
                                   1269 ;	quantum/action.c:552: send_keyboard_report();
      00787F 12 85 0D         [24] 1270 	lcall	_send_keyboard_report
                                   1271 ;	quantum/action.c:555: } break;
      007882 02 7A 50         [24] 1272 	ljmp	00181$
                                   1273 ;	quantum/action.c:632: case ACT_USAGE:
      007885                       1274 00123$:
                                   1275 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007885 74 07            [12] 1276 	mov	a,#0x07
      007887 12 3A 30         [24] 1277 	lcall	_ak820_outline_0030
      00788A 12 3A 0B         [24] 1278 	lcall	_ak820_outline_0010
      00788D C3               [12] 1279 	clr	c
      00788E EC               [12] 1280 	mov	a,r4
      00788F 94 A5            [12] 1281 	subb	a,#0xa5
      007891 ED               [12] 1282 	mov	a,r5
      007892 94 00            [12] 1283 	subb	a,#0x00
      007894 40 15            [24] 1284 	jc	00125$
      007896 74 C2            [12] 1285 	mov	a,#0xc2
      007898 9C               [12] 1286 	subb	a,r4
      007899 E4               [12] 1287 	clr	a
      00789A 9D               [12] 1288 	subb	a,r5
      00789B 40 0E            [24] 1289 	jc	00125$
                                   1290 ;	free result
                                   1291 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      00789D 90 0A EF         [24] 1292 	mov	dptr,#_owned_usage_key_PARM_2
      0078A0 E5 28            [12] 1293 	mov	a,_process_action_sloc0_1_0
      0078A2 F0               [24] 1294 	movx	@dptr,a
      0078A3 8E 82            [24] 1295 	mov	dpl, r6
      0078A5 12 83 BA         [24] 1296 	lcall	_owned_usage_key
                                   1297 ;	quantum/action.c:640: break;
      0078A8 02 7A 50         [24] 1298 	ljmp	00181$
      0078AB                       1299 00125$:
                                   1300 ;	quantum/action.c:643: switch (action.usage.page) {
      0078AB 12 7C 66         [24] 1301 	lcall	_ak820_outline_0086
      0078AE FF               [12] 1302 	mov	r7,a
      0078AF 60 08            [24] 1303 	jz	00127$
      0078B1 BF 01 02         [24] 1304 	cjne	r7,#0x01,00452$
      0078B4 80 19            [24] 1305 	sjmp	00128$
      0078B6                       1306 00452$:
      0078B6 02 7A 50         [24] 1307 	ljmp	00181$
                                   1308 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0078B9                       1309 00127$:
                                   1310 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0078B9 E5 28            [12] 1311 	mov	a,_process_action_sloc0_1_0
      0078BB 60 05            [24] 1312 	jz	00196$
      0078BD 12 7C 7D         [24] 1313 	lcall	_ak820_outline_0129
      0078C0 80 04            [24] 1314 	sjmp	00197$
      0078C2                       1315 00196$:
      0078C2 7E 00            [12] 1316 	mov	r6,#0x00
      0078C4 7F 00            [12] 1317 	mov	r7,#0x00
      0078C6                       1318 00197$:
      0078C6 12 48 A2         [24] 1319 	lcall	_ak820_outline_0116
      0078C9 12 72 24         [24] 1320 	lcall	_host_system_send
                                   1321 ;	quantum/action.c:646: break;
      0078CC 02 7A 50         [24] 1322 	ljmp	00181$
                                   1323 ;	quantum/action.c:647: case PAGE_CONSUMER:
      0078CF                       1324 00128$:
                                   1325 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      0078CF E5 28            [12] 1326 	mov	a,_process_action_sloc0_1_0
      0078D1 60 05            [24] 1327 	jz	00198$
      0078D3 12 7C 7D         [24] 1328 	lcall	_ak820_outline_0129
      0078D6 80 04            [24] 1329 	sjmp	00199$
      0078D8                       1330 00198$:
      0078D8 7E 00            [12] 1331 	mov	r6,#0x00
      0078DA 7F 00            [12] 1332 	mov	r7,#0x00
      0078DC                       1333 00199$:
      0078DC 12 48 A2         [24] 1334 	lcall	_ak820_outline_0116
      0078DF 12 72 53         [24] 1335 	lcall	_host_consumer_send
                                   1336 ;	quantum/action.c:651: break;
      0078E2 02 7A 50         [24] 1337 	ljmp	00181$
                                   1338 ;	quantum/action.c:658: case ACT_LAYER: {
      0078E5                       1339 00131$:
                                   1340 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      0078E5 90 08 90         [24] 1341 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0078E8 E0               [24] 1342 	movx	a,@dptr
      0078E9 54 03            [12] 1343 	anl	a,#0x03
      0078EB 90 08 93         [24] 1344 	mov	dptr,#_process_action_on_40000_686
      0078EE F0               [24] 1345 	movx	@dptr,a
                                   1346 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0078EF E0               [24] 1347 	movx	a,@dptr
      0078F0 FF               [12] 1348 	mov	r7,a
      0078F1 60 11            [24] 1349 	jz	00200$
      0078F3 E5 28            [12] 1350 	mov	a,_process_action_sloc0_1_0
      0078F5 60 07            [24] 1351 	jz	00202$
      0078F7 8F 06            [24] 1352 	mov	ar6,r7
      0078F9 53 06 01         [24] 1353 	anl	ar6,#0x01
      0078FC 80 10            [24] 1354 	sjmp	00201$
      0078FE                       1355 00202$:
      0078FE 74 02            [12] 1356 	mov	a,#0x02
      007900 5F               [12] 1357 	anl	a,r7
      007901 FE               [12] 1358 	mov	r6,a
      007902 80 0A            [24] 1359 	sjmp	00201$
      007904                       1360 00200$:
      007904 E5 28            [12] 1361 	mov	a,_process_action_sloc0_1_0
      007906 B4 01 00         [24] 1362 	cjne	a,#0x01,00457$
      007909                       1363 00457$:
      007909 92 20            [24] 1364 	mov  _process_action_sloc1_1_0,c
      00790B E4               [12] 1365 	clr	a
      00790C 33               [12] 1366 	rlc	a
      00790D FE               [12] 1367 	mov	r6,a
      00790E                       1368 00201$:
      00790E EE               [12] 1369 	mov	a,r6
      00790F 70 03            [24] 1370 	jnz	00458$
      007911 02 7A 50         [24] 1371 	ljmp	00181$
      007914                       1372 00458$:
                                   1373 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007914 12 7C 88         [24] 1374 	lcall	_ak820_outline_0154
      007917 C4               [12] 1375 	swap	a
      007918 03               [12] 1376 	rr	a
      007919 54 07            [12] 1377 	anl	a,#0x07
      00791B 25 E0            [12] 1378 	add	a,acc
      00791D 25 E0            [12] 1379 	add	a,acc
      00791F FF               [12] 1380 	mov	r7,a
                                   1381 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007920 12 7C 88         [24] 1382 	lcall	_ak820_outline_0154
      007923 54 0F            [12] 1383 	anl	a,#0x0f
      007925 FE               [12] 1384 	mov	r6,a
      007926 8F F0            [24] 1385 	mov	b,r7
      007928 05 F0            [12] 1386 	inc	b
      00792A EE               [12] 1387 	mov	a,r6
      00792B 80 02            [24] 1388 	sjmp	00460$
      00792D                       1389 00459$:
      00792D 25 E0            [12] 1390 	add	a,acc
      00792F                       1391 00460$:
      00792F D5 F0 FB         [24] 1392 	djnz	b,00459$
      007932 FE               [12] 1393 	mov	r6,a
                                   1394 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007933 12 7C 88         [24] 1395 	lcall	_ak820_outline_0154
      007936 30 E4 11         [24] 1396 	jnb	acc.4,00204$
      007939 8F F0            [24] 1397 	mov	b,r7
      00793B 05 F0            [12] 1398 	inc	b
      00793D 74 0F            [12] 1399 	mov	a,#0x0f
      00793F 80 02            [24] 1400 	sjmp	00463$
      007941                       1401 00462$:
      007941 25 E0            [12] 1402 	add	a,acc
      007943                       1403 00463$:
      007943 D5 F0 FB         [24] 1404 	djnz	b,00462$
      007946 F4               [12] 1405 	cpl	a
      007947 FF               [12] 1406 	mov	r7,a
      007948 80 02            [24] 1407 	sjmp	00205$
      00794A                       1408 00204$:
      00794A 7F 00            [12] 1409 	mov	r7,#0x00
      00794C                       1410 00205$:
                                   1411 ;	quantum/action.c:666: bits |= mask;
      00794C EE               [12] 1412 	mov	a,r6
      00794D 42 07            [12] 1413 	orl	ar7,a
                                   1414 ;	quantum/action.c:667: if (!on) {
      00794F 90 08 93         [24] 1415 	mov	dptr,#_process_action_on_40000_686
      007952 E0               [24] 1416 	movx	a,@dptr
      007953 70 31            [24] 1417 	jnz	00143$
                                   1418 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      007955 12 7C 66         [24] 1419 	lcall	_ak820_outline_0086
      007958 FE               [12] 1420 	mov	r6,a
      007959 2E               [12] 1421 	add	a,r6
                                   1422 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      00795A 90 79 5E         [24] 1423 	mov	dptr,#00465$
      00795D 73               [24] 1424 	jmp	@a+dptr
      00795E                       1425 00465$:
      00795E 80 06            [24] 1426 	sjmp	00132$
      007960 80 0C            [24] 1427 	sjmp	00133$
      007962 80 12            [24] 1428 	sjmp	00134$
      007964 80 18            [24] 1429 	sjmp	00135$
      007966                       1430 00132$:
      007966 8F 82            [24] 1431 	mov	dpl, r7
      007968 12 7C E3         [24] 1432 	lcall	_default_layer_and
      00796B 02 7A 50         [24] 1433 	ljmp	00181$
                                   1434 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      00796E                       1435 00133$:
      00796E 8F 82            [24] 1436 	mov	dpl, r7
      007970 12 7C D3         [24] 1437 	lcall	_default_layer_or
      007973 02 7A 50         [24] 1438 	ljmp	00181$
                                   1439 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      007976                       1440 00134$:
      007976 8F 82            [24] 1441 	mov	dpl, r7
      007978 12 7C F8         [24] 1442 	lcall	_default_layer_xor
      00797B 02 7A 50         [24] 1443 	ljmp	00181$
                                   1444 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      00797E                       1445 00135$:
      00797E 8F 82            [24] 1446 	mov	dpl, r7
      007980 12 7C C9         [24] 1447 	lcall	_default_layer_set
                                   1448 ;	quantum/action.c:673: }
      007983 02 7A 50         [24] 1449 	ljmp	00181$
      007986                       1450 00143$:
                                   1451 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      007986 12 7C 66         [24] 1452 	lcall	_ak820_outline_0086
      007989 FE               [12] 1453 	mov	r6,a
      00798A 2E               [12] 1454 	add	a,r6
                                   1455 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      00798B 90 79 8F         [24] 1456 	mov	dptr,#00466$
      00798E 73               [24] 1457 	jmp	@a+dptr
      00798F                       1458 00466$:
      00798F 80 06            [24] 1459 	sjmp	00137$
      007991 80 0C            [24] 1460 	sjmp	00138$
      007993 80 12            [24] 1461 	sjmp	00139$
      007995 80 18            [24] 1462 	sjmp	00140$
      007997                       1463 00137$:
      007997 8F 82            [24] 1464 	mov	dpl, r7
      007999 12 7E 6F         [24] 1465 	lcall	_layer_and
      00799C 02 7A 50         [24] 1466 	ljmp	00181$
                                   1467 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      00799F                       1468 00138$:
      00799F 8F 82            [24] 1469 	mov	dpl, r7
      0079A1 12 7E 5F         [24] 1470 	lcall	_layer_or
      0079A4 02 7A 50         [24] 1471 	ljmp	00181$
                                   1472 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      0079A7                       1473 00139$:
      0079A7 8F 82            [24] 1474 	mov	dpl, r7
      0079A9 12 7E 84         [24] 1475 	lcall	_layer_xor
      0079AC 02 7A 50         [24] 1476 	ljmp	00181$
                                   1477 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      0079AF                       1478 00140$:
      0079AF 8F 82            [24] 1479 	mov	dpl, r7
      0079B1 12 7E 01         [24] 1480 	lcall	_layer_state_set
                                   1481 ;	quantum/action.c:683: break;
      0079B4 02 7A 50         [24] 1482 	ljmp	00181$
                                   1483 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      0079B7                       1484 00147$:
                                   1485 ;	quantum/action.c:686: if (pressed) {
      0079B7 E5 28            [12] 1486 	mov	a,_process_action_sloc0_1_0
      0079B9 60 11            [24] 1487 	jz	00149$
                                   1488 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      0079BB 12 7C 76         [24] 1489 	lcall	_ak820_outline_0109
      0079BE F5 82            [12] 1490 	mov	dpl,a
      0079C0 12 7D 66         [24] 1491 	lcall	_layer_hold_on
                                   1492 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      0079C3 12 7C 5F         [24] 1493 	lcall	_ak820_outline_0076
      0079C6 12 7B A2         [24] 1494 	lcall	_register_mods
      0079C9 02 7A 50         [24] 1495 	ljmp	00181$
      0079CC                       1496 00149$:
                                   1497 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      0079CC 12 7C 5F         [24] 1498 	lcall	_ak820_outline_0076
      0079CF 12 7B B6         [24] 1499 	lcall	_unregister_mods
                                   1500 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      0079D2 12 7C 76         [24] 1501 	lcall	_ak820_outline_0109
      0079D5 F5 82            [12] 1502 	mov	dpl,a
      0079D7 12 7D 9D         [24] 1503 	lcall	_layer_hold_off
                                   1504 ;	quantum/action.c:693: break;
      0079DA 02 7A 50         [24] 1505 	ljmp	00181$
                                   1506 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      0079DD                       1507 00152$:
                                   1508 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      0079DD 12 7C 88         [24] 1509 	lcall	_ak820_outline_0154
      0079E0 FF               [12] 1510 	mov	r7,a
      0079E1 BF F1 02         [24] 1511 	cjne	r7,#0xf1,00468$
      0079E4 80 0A            [24] 1512 	sjmp	00154$
      0079E6                       1513 00468$:
      0079E6 BF F2 02         [24] 1514 	cjne	r7,#0xf2,00469$
      0079E9 80 19            [24] 1515 	sjmp	00155$
      0079EB                       1516 00469$:
                                   1517 ;	quantum/action.c:712: momentary_layer_action:
      0079EB BF F3 3B         [24] 1518 	cjne	r7,#0xf3,00160$
      0079EE 80 28            [24] 1519 	sjmp	00156$
      0079F0                       1520 00154$:
                                   1521 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0079F0 E5 28            [12] 1522 	mov	a,_process_action_sloc0_1_0
      0079F2 60 08            [24] 1523 	jz	00206$
      0079F4 12 7C 46         [24] 1524 	lcall	_ak820_outline_0038
      0079F7 12 7D 66         [24] 1525 	lcall	_layer_hold_on
      0079FA 80 54            [24] 1526 	sjmp	00181$
      0079FC                       1527 00206$:
      0079FC 12 7C 46         [24] 1528 	lcall	_ak820_outline_0038
      0079FF 12 7D 9D         [24] 1529 	lcall	_layer_hold_off
                                   1530 ;	quantum/action.c:714: break;
                                   1531 ;	quantum/action.c:715: case OP_OFF_ON:
      007A02 80 4C            [24] 1532 	sjmp	00181$
      007A04                       1533 00155$:
                                   1534 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007A04 E5 28            [12] 1535 	mov	a,_process_action_sloc0_1_0
      007A06 60 08            [24] 1536 	jz	00208$
      007A08 12 7C 46         [24] 1537 	lcall	_ak820_outline_0038
      007A0B 12 7E 42         [24] 1538 	lcall	_layer_off
      007A0E 80 40            [24] 1539 	sjmp	00181$
      007A10                       1540 00208$:
      007A10 12 7C 46         [24] 1541 	lcall	_ak820_outline_0038
      007A13 12 7E 28         [24] 1542 	lcall	_layer_on
                                   1543 ;	quantum/action.c:717: break;
                                   1544 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007A16 80 38            [24] 1545 	sjmp	00181$
      007A18                       1546 00156$:
                                   1547 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007A18 E5 28            [12] 1548 	mov	a,_process_action_sloc0_1_0
      007A1A 60 08            [24] 1549 	jz	00210$
      007A1C 12 7C 46         [24] 1550 	lcall	_ak820_outline_0038
      007A1F 12 7E 13         [24] 1551 	lcall	_layer_move
      007A22 80 2C            [24] 1552 	sjmp	00181$
      007A24                       1553 00210$:
      007A24 12 7E 0E         [24] 1554 	lcall	_layer_clear
                                   1555 ;	quantum/action.c:720: break;
                                   1556 ;	quantum/action.c:766: default:
      007A27 80 27            [24] 1557 	sjmp	00181$
      007A29                       1558 00160$:
                                   1559 ;	quantum/action.c:773: if (pressed) {
      007A29 E5 28            [12] 1560 	mov	a,_process_action_sloc0_1_0
      007A2B 60 08            [24] 1561 	jz	00163$
                                   1562 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007A2D 12 7C 5F         [24] 1563 	lcall	_ak820_outline_0076
      007A30 12 7A 67         [24] 1564 	lcall	_register_code
                                   1565 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007A33 80 1B            [24] 1566 	sjmp	00181$
      007A35                       1567 00163$:
                                   1568 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007A35 12 7C 88         [24] 1569 	lcall	_ak820_outline_0154
      007A38 FF               [12] 1570 	mov	r7,a
      007A39 BF 39 0E         [24] 1571 	cjne	r7,#0x39,00175$
                                   1572 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      007A3C 7F 50            [12] 1573 	mov	r7,#0x50
      007A3E                       1574 00187$:
      007A3E EF               [12] 1575 	mov	a,r7
      007A3F 60 09            [24] 1576 	jz	00175$
      007A41 90 00 01         [24] 1577 	mov	dptr,#0x0001
      007A44 12 5D DC         [24] 1578 	lcall	_mDelaymS
      007A47 1F               [12] 1579 	dec	r7
                                   1580 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      007A48 80 F4            [24] 1581 	sjmp	00187$
      007A4A                       1582 00175$:
                                   1583 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      007A4A 12 7C 5F         [24] 1584 	lcall	_ak820_outline_0076
      007A4D 12 7A E3         [24] 1585 	lcall	_unregister_code
                                   1586 ;	quantum/action.c:866: }
      007A50                       1587 00181$:
                                   1588 ;	quantum/action.c:887: switch (action.kind.id) {
      007A50 90 08 90         [24] 1589 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007A53 E0               [24] 1590 	movx	a,@dptr
      007A54 C4               [12] 1591 	swap	a
      007A55 54 0F            [12] 1592 	anl	a,#0x0f
      007A57 FF               [12] 1593 	mov	r7,a
      007A58 BF 08 02         [24] 1594 	cjne	r7,#0x08,00478$
      007A5B 80 03            [24] 1595 	sjmp	00183$
      007A5D                       1596 00478$:
      007A5D BF 09 06         [24] 1597 	cjne	r7,#0x09,00192$
                                   1598 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007A60                       1599 00183$:
                                   1600 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007A60 12 71 89         [24] 1601 	lcall	_host_keyboard_leds
                                   1602 ;	quantum/action.c:898: }
                                   1603 ;	quantum/action.c:951: }
      007A63 02 9C 33         [24] 1604 	ljmp	_led_set
      007A66                       1605 00192$:
      007A66 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'register_code'
                                   1609 ;------------------------------------------------------------
                                   1610 ;code          Allocated with name '_register_code_code_10000_720'
                                   1611 ;------------------------------------------------------------
                                   1612 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1613 ;	-----------------------------------------
                                   1614 ;	 function register_code
                                   1615 ;	-----------------------------------------
      007A67                       1616 _register_code:
      007A67 E5 82            [12] 1617 	mov	a,dpl
      007A69 90 08 94         [24] 1618 	mov	dptr,#_register_code_code_10000_720
      007A6C F0               [24] 1619 	movx	@dptr,a
                                   1620 ;	quantum/action.c:958: if (code == KC_NO) {
      007A6D E0               [24] 1621 	movx	a,@dptr
      007A6E FF               [12] 1622 	mov	r7,a
      007A6F 70 01            [24] 1623 	jnz	00123$
                                   1624 ;	quantum/action.c:959: return;
      007A71 22               [24] 1625 	ret
      007A72                       1626 00123$:
                                   1627 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007A72 BF 04 00         [24] 1628 	cjne	r7,#0x04,00186$
      007A75                       1629 00186$:
      007A75 40 21            [24] 1630 	jc	00119$
      007A77 EF               [12] 1631 	mov	a,r7
      007A78 24 5B            [12] 1632 	add	a,#0xff - 0xa4
      007A7A 40 1C            [24] 1633 	jc	00119$
                                   1634 ;	free result
                                   1635 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      007A7C 8F 82            [24] 1636 	mov	dpl, r7
      007A7E C0 07            [24] 1637 	push	ar7
      007A80 12 82 7B         [24] 1638 	lcall	_add_owned_key
      007A83 E5 82            [12] 1639 	mov	a, dpl
      007A85 D0 07            [24] 1640 	pop	ar7
      007A87 70 01            [24] 1641 	jnz	00104$
      007A89 22               [24] 1642 	ret
      007A8A                       1643 00104$:
                                   1644 ;	quantum/action.c:1001: ak820_dynamic_macro_observe(code, true);
      007A8A 90 04 BD         [24] 1645 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007A8D 74 01            [12] 1646 	mov	a,#0x01
      007A8F F0               [24] 1647 	movx	@dptr,a
      007A90 8F 82            [24] 1648 	mov	dpl, r7
      007A92 12 3C 35         [24] 1649 	lcall	_ak820_dynamic_macro_observe
                                   1650 ;	quantum/action.c:1013: send_keyboard_report();
      007A95 02 85 0D         [24] 1651 	ljmp	_send_keyboard_report
      007A98                       1652 00119$:
                                   1653 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      007A98 12 7C 8D         [24] 1654 	lcall	_ak820_outline_0162
      007A9B BF E0 00         [24] 1655 	cjne	r7,#0xe0,00190$
      007A9E                       1656 00190$:
      007A9E 40 1A            [24] 1657 	jc	00115$
      007AA0 EF               [12] 1658 	mov	a,r7
      007AA1 24 18            [12] 1659 	add	a,#0xff - 0xe7
      007AA3 40 15            [24] 1660 	jc	00115$
                                   1661 ;	free result
                                   1662 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      007AA5 74 07            [12] 1663 	mov	a,#0x07
      007AA7 5F               [12] 1664 	anl	a,r7
      007AA8 12 7C 58         [24] 1665 	lcall	_ak820_outline_0062
      007AAB 80 02            [24] 1666 	sjmp	00194$
      007AAD                       1667 00193$:
      007AAD 25 E0            [12] 1668 	add	a,acc
      007AAF                       1669 00194$:
      007AAF D5 F0 FB         [24] 1670 	djnz	b,00193$
      007AB2 F5 82            [12] 1671 	mov	dpl,a
      007AB4 12 81 DC         [24] 1672 	lcall	_add_owned_mods
                                   1673 ;	quantum/action.c:1016: send_keyboard_report();
      007AB7 02 85 0D         [24] 1674 	ljmp	_send_keyboard_report
      007ABA                       1675 00115$:
                                   1676 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007ABA 12 7C 8D         [24] 1677 	lcall	_ak820_outline_0162
      007ABD BF A5 00         [24] 1678 	cjne	r7,#0xa5,00195$
      007AC0                       1679 00195$:
      007AC0 40 05            [24] 1680 	jc	00113$
      007AC2 EF               [12] 1681 	mov	a,r7
      007AC3 24 58            [12] 1682 	add	a,#0xff - 0xa7
      007AC5 50 0D            [24] 1683 	jnc	00108$
                                   1684 ;	free result
      007AC7                       1685 00113$:
      007AC7 12 7C 8D         [24] 1686 	lcall	_ak820_outline_0162
      007ACA BF A8 00         [24] 1687 	cjne	r7,#0xa8,00198$
      007ACD                       1688 00198$:
      007ACD 40 13            [24] 1689 	jc	00125$
      007ACF EF               [12] 1690 	mov	a,r7
      007AD0 24 3D            [12] 1691 	add	a,#0xff - 0xc2
      007AD2 40 0E            [24] 1692 	jc	00125$
                                   1693 ;	free result
      007AD4                       1694 00108$:
                                   1695 ;	quantum/action.c:1021: owned_usage_key(code, true);
      007AD4 12 7C 8D         [24] 1696 	lcall	_ak820_outline_0162
      007AD7 90 0A EF         [24] 1697 	mov	dptr,#_owned_usage_key_PARM_2
      007ADA 74 01            [12] 1698 	mov	a,#0x01
      007ADC F0               [24] 1699 	movx	@dptr,a
      007ADD 8F 82            [24] 1700 	mov	dpl, r7
                                   1701 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1702 ;	quantum/action.c:1031: }
      007ADF 02 83 BA         [24] 1703 	ljmp	_owned_usage_key
      007AE2                       1704 00125$:
      007AE2 22               [24] 1705 	ret
                                   1706 ;------------------------------------------------------------
                                   1707 ;Allocation info for local variables in function 'unregister_code'
                                   1708 ;------------------------------------------------------------
                                   1709 ;code          Allocated with name '_unregister_code_code_10000_734'
                                   1710 ;------------------------------------------------------------
                                   1711 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1712 ;	-----------------------------------------
                                   1713 ;	 function unregister_code
                                   1714 ;	-----------------------------------------
      007AE3                       1715 _unregister_code:
      007AE3 E5 82            [12] 1716 	mov	a,dpl
      007AE5 90 08 95         [24] 1717 	mov	dptr,#_unregister_code_code_10000_734
      007AE8 F0               [24] 1718 	movx	@dptr,a
                                   1719 ;	quantum/action.c:1038: if (code == KC_NO) {
      007AE9 E0               [24] 1720 	movx	a,@dptr
      007AEA FF               [12] 1721 	mov	r7,a
      007AEB 70 01            [24] 1722 	jnz	00121$
                                   1723 ;	quantum/action.c:1039: return;
      007AED 22               [24] 1724 	ret
      007AEE                       1725 00121$:
                                   1726 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      007AEE BF 04 00         [24] 1727 	cjne	r7,#0x04,00184$
      007AF1                       1728 00184$:
      007AF1 40 1F            [24] 1729 	jc	00117$
      007AF3 EF               [12] 1730 	mov	a,r7
      007AF4 24 5B            [12] 1731 	add	a,#0xff - 0xa4
      007AF6 40 1A            [24] 1732 	jc	00117$
                                   1733 ;	free result
                                   1734 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      007AF8 8F 82            [24] 1735 	mov	dpl, r7
      007AFA C0 07            [24] 1736 	push	ar7
      007AFC 12 82 F4         [24] 1737 	lcall	_del_owned_key
      007AFF E5 82            [12] 1738 	mov	a, dpl
      007B01 D0 07            [24] 1739 	pop	ar7
      007B03 70 01            [24] 1740 	jnz	00102$
      007B05 22               [24] 1741 	ret
      007B06                       1742 00102$:
                                   1743 ;	quantum/action.c:1075: ak820_dynamic_macro_observe(code, false);
      007B06 90 04 BD         [24] 1744 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007B09 12 7C 99         [24] 1745 	lcall	_ak820_outline_0184
      007B0C 12 3C 35         [24] 1746 	lcall	_ak820_dynamic_macro_observe
                                   1747 ;	quantum/action.c:1080: send_keyboard_report();
      007B0F 02 85 0D         [24] 1748 	ljmp	_send_keyboard_report
      007B12                       1749 00117$:
                                   1750 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007B12 12 7C 93         [24] 1751 	lcall	_ak820_outline_0163
      007B15 BF E0 00         [24] 1752 	cjne	r7,#0xe0,00188$
      007B18                       1753 00188$:
      007B18 40 1A            [24] 1754 	jc	00113$
      007B1A EF               [12] 1755 	mov	a,r7
      007B1B 24 18            [12] 1756 	add	a,#0xff - 0xe7
      007B1D 40 15            [24] 1757 	jc	00113$
                                   1758 ;	free result
                                   1759 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007B1F 74 07            [12] 1760 	mov	a,#0x07
      007B21 5F               [12] 1761 	anl	a,r7
      007B22 12 7C 58         [24] 1762 	lcall	_ak820_outline_0062
      007B25 80 02            [24] 1763 	sjmp	00192$
      007B27                       1764 00191$:
      007B27 25 E0            [12] 1765 	add	a,acc
      007B29                       1766 00192$:
      007B29 D5 F0 FB         [24] 1767 	djnz	b,00191$
      007B2C F5 82            [12] 1768 	mov	dpl,a
      007B2E 12 81 EB         [24] 1769 	lcall	_del_owned_mods
                                   1770 ;	quantum/action.c:1083: send_keyboard_report();
      007B31 02 85 0D         [24] 1771 	ljmp	_send_keyboard_report
      007B34                       1772 00113$:
                                   1773 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007B34 12 7C 93         [24] 1774 	lcall	_ak820_outline_0163
      007B37 BF A5 00         [24] 1775 	cjne	r7,#0xa5,00193$
      007B3A                       1776 00193$:
      007B3A 40 05            [24] 1777 	jc	00111$
      007B3C EF               [12] 1778 	mov	a,r7
      007B3D 24 58            [12] 1779 	add	a,#0xff - 0xa7
      007B3F 50 0D            [24] 1780 	jnc	00106$
                                   1781 ;	free result
      007B41                       1782 00111$:
      007B41 12 7C 93         [24] 1783 	lcall	_ak820_outline_0163
      007B44 BF A8 00         [24] 1784 	cjne	r7,#0xa8,00196$
      007B47                       1785 00196$:
      007B47 40 11            [24] 1786 	jc	00123$
      007B49 EF               [12] 1787 	mov	a,r7
      007B4A 24 3D            [12] 1788 	add	a,#0xff - 0xc2
      007B4C 40 0C            [24] 1789 	jc	00123$
                                   1790 ;	free result
      007B4E                       1791 00106$:
                                   1792 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007B4E 12 7C 93         [24] 1793 	lcall	_ak820_outline_0163
      007B51 90 0A EF         [24] 1794 	mov	dptr,#_owned_usage_key_PARM_2
      007B54 12 7C 99         [24] 1795 	lcall	_ak820_outline_0184
                                   1796 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1797 ;	quantum/action.c:1098: }
      007B57 02 83 BA         [24] 1798 	ljmp	_owned_usage_key
      007B5A                       1799 00123$:
      007B5A 22               [24] 1800 	ret
                                   1801 ;------------------------------------------------------------
                                   1802 ;Allocation info for local variables in function 'tap_code_delay'
                                   1803 ;------------------------------------------------------------
                                   1804 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1805 ;code          Allocated with name '_tap_code_delay_code_10000_747'
                                   1806 ;i             Allocated with name '_tap_code_delay_i_20000_749'
                                   1807 ;i             Allocated with name '_tap_code_delay_i_50000_752'
                                   1808 ;------------------------------------------------------------
                                   1809 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1810 ;	-----------------------------------------
                                   1811 ;	 function tap_code_delay
                                   1812 ;	-----------------------------------------
      007B5B                       1813 _tap_code_delay:
      007B5B E5 82            [12] 1814 	mov	a,dpl
      007B5D 90 08 98         [24] 1815 	mov	dptr,#_tap_code_delay_code_10000_747
      007B60 F0               [24] 1816 	movx	@dptr,a
                                   1817 ;	quantum/action.c:1106: register_code(code);
      007B61 E0               [24] 1818 	movx	a,@dptr
      007B62 FF               [12] 1819 	mov	r7,a
      007B63 F5 82            [12] 1820 	mov	dpl,a
      007B65 C0 07            [24] 1821 	push	ar7
      007B67 51 67            [12] 1822 	acall	_register_code
      007B69 D0 07            [24] 1823 	pop	ar7
                                   1824 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007B6B 90 08 96         [24] 1825 	mov	dptr,#_tap_code_delay_PARM_2
      007B6E 12 48 90         [24] 1826 	lcall	_ak820_outline_0094
      007B71                       1827 00110$:
      007B71 ED               [12] 1828 	mov	a,r5
      007B72 4E               [12] 1829 	orl	a,r6
      007B73 60 0D            [24] 1830 	jz	00105$
                                   1831 ;	quantum/action.c:1108: wait_ms(1);
      007B75 90 00 01         [24] 1832 	mov	dptr,#0x0001
      007B78 12 5D DC         [24] 1833 	lcall	_mDelaymS
                                   1834 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007B7B 1D               [12] 1835 	dec	r5
      007B7C BD FF 01         [24] 1836 	cjne	r5,#0xff,00141$
      007B7F 1E               [12] 1837 	dec	r6
      007B80                       1838 00141$:
      007B80 80 EF            [24] 1839 	sjmp	00110$
      007B82                       1840 00105$:
                                   1841 ;	quantum/action.c:1110: unregister_code(code);
      007B82 8F 82            [24] 1842 	mov	dpl, r7
                                   1843 ;	quantum/action.c:1111: }
      007B84 41 E3            [12] 1844 	ajmp	_unregister_code
                                   1845 ;------------------------------------------------------------
                                   1846 ;Allocation info for local variables in function 'tap_code'
                                   1847 ;------------------------------------------------------------
                                   1848 ;code          Allocated with name '_tap_code_code_10000_754'
                                   1849 ;------------------------------------------------------------
                                   1850 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1851 ;	-----------------------------------------
                                   1852 ;	 function tap_code
                                   1853 ;	-----------------------------------------
      007B86                       1854 _tap_code:
      007B86 E5 82            [12] 1855 	mov	a,dpl
      007B88 90 08 99         [24] 1856 	mov	dptr,#_tap_code_code_10000_754
      007B8B F0               [24] 1857 	movx	@dptr,a
                                   1858 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007B8C E0               [24] 1859 	movx	a,@dptr
      007B8D FF               [12] 1860 	mov	r7,a
      007B8E BF 39 04         [24] 1861 	cjne	r7,#0x39,00103$
      007B91 7E 50            [12] 1862 	mov	r6,#0x50
      007B93 80 02            [24] 1863 	sjmp	00104$
      007B95                       1864 00103$:
      007B95 7E 00            [12] 1865 	mov	r6,#0x00
      007B97                       1866 00104$:
      007B97 90 08 96         [24] 1867 	mov	dptr,#_tap_code_delay_PARM_2
      007B9A EE               [12] 1868 	mov	a,r6
      007B9B 12 3A A5         [24] 1869 	lcall	_ak820_outline_0123
      007B9E 8F 82            [24] 1870 	mov	dpl, r7
                                   1871 ;	quantum/action.c:1119: }
      007BA0 61 5B            [12] 1872 	ajmp	_tap_code_delay
                                   1873 ;------------------------------------------------------------
                                   1874 ;Allocation info for local variables in function 'register_mods'
                                   1875 ;------------------------------------------------------------
                                   1876 ;mods          Allocated with name '_register_mods_mods_10000_756'
                                   1877 ;------------------------------------------------------------
                                   1878 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1879 ;	-----------------------------------------
                                   1880 ;	 function register_mods
                                   1881 ;	-----------------------------------------
      007BA2                       1882 _register_mods:
      007BA2 E5 82            [12] 1883 	mov	a,dpl
      007BA4 90 08 9A         [24] 1884 	mov	dptr,#_register_mods_mods_10000_756
      007BA7 F0               [24] 1885 	movx	@dptr,a
                                   1886 ;	quantum/action.c:1126: if (mods) {
      007BA8 E0               [24] 1887 	movx	a,@dptr
      007BA9 FF               [12] 1888 	mov	r7,a
      007BAA E0               [24] 1889 	movx	a,@dptr
      007BAB 60 08            [24] 1890 	jz	00103$
                                   1891 ;	quantum/action.c:1127: add_owned_mods(mods);
      007BAD 8F 82            [24] 1892 	mov	dpl, r7
      007BAF 12 81 DC         [24] 1893 	lcall	_add_owned_mods
                                   1894 ;	quantum/action.c:1128: send_keyboard_report();
                                   1895 ;	quantum/action.c:1130: }
      007BB2 02 85 0D         [24] 1896 	ljmp	_send_keyboard_report
      007BB5                       1897 00103$:
      007BB5 22               [24] 1898 	ret
                                   1899 ;------------------------------------------------------------
                                   1900 ;Allocation info for local variables in function 'unregister_mods'
                                   1901 ;------------------------------------------------------------
                                   1902 ;mods          Allocated with name '_unregister_mods_mods_10000_760'
                                   1903 ;------------------------------------------------------------
                                   1904 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1905 ;	-----------------------------------------
                                   1906 ;	 function unregister_mods
                                   1907 ;	-----------------------------------------
      007BB6                       1908 _unregister_mods:
      007BB6 E5 82            [12] 1909 	mov	a,dpl
      007BB8 90 08 9B         [24] 1910 	mov	dptr,#_unregister_mods_mods_10000_760
      007BBB F0               [24] 1911 	movx	@dptr,a
                                   1912 ;	quantum/action.c:1137: if (mods) {
      007BBC E0               [24] 1913 	movx	a,@dptr
      007BBD FF               [12] 1914 	mov	r7,a
      007BBE E0               [24] 1915 	movx	a,@dptr
      007BBF 60 08            [24] 1916 	jz	00103$
                                   1917 ;	quantum/action.c:1138: del_owned_mods(mods);
      007BC1 8F 82            [24] 1918 	mov	dpl, r7
      007BC3 12 81 EB         [24] 1919 	lcall	_del_owned_mods
                                   1920 ;	quantum/action.c:1139: send_keyboard_report();
                                   1921 ;	quantum/action.c:1141: }
      007BC6 02 85 0D         [24] 1922 	ljmp	_send_keyboard_report
      007BC9                       1923 00103$:
      007BC9 22               [24] 1924 	ret
                                   1925 ;------------------------------------------------------------
                                   1926 ;Allocation info for local variables in function 'register_weak_mods'
                                   1927 ;------------------------------------------------------------
                                   1928 ;mods          Allocated with name '_register_weak_mods_mods_10000_764'
                                   1929 ;------------------------------------------------------------
                                   1930 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1931 ;	-----------------------------------------
                                   1932 ;	 function register_weak_mods
                                   1933 ;	-----------------------------------------
      007BCA                       1934 _register_weak_mods:
      007BCA E5 82            [12] 1935 	mov	a,dpl
      007BCC 90 08 9C         [24] 1936 	mov	dptr,#_register_weak_mods_mods_10000_764
      007BCF F0               [24] 1937 	movx	@dptr,a
                                   1938 ;	quantum/action.c:1148: if (mods) {
      007BD0 E0               [24] 1939 	movx	a,@dptr
      007BD1 FF               [12] 1940 	mov	r7,a
      007BD2 E0               [24] 1941 	movx	a,@dptr
      007BD3 60 08            [24] 1942 	jz	00103$
                                   1943 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      007BD5 8F 82            [24] 1944 	mov	dpl, r7
      007BD7 12 81 F8         [24] 1945 	lcall	_add_owned_weak_mods
                                   1946 ;	quantum/action.c:1150: send_keyboard_report();
                                   1947 ;	quantum/action.c:1152: }
      007BDA 02 85 0D         [24] 1948 	ljmp	_send_keyboard_report
      007BDD                       1949 00103$:
      007BDD 22               [24] 1950 	ret
                                   1951 ;------------------------------------------------------------
                                   1952 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1953 ;------------------------------------------------------------
                                   1954 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_768'
                                   1955 ;------------------------------------------------------------
                                   1956 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1957 ;	-----------------------------------------
                                   1958 ;	 function unregister_weak_mods
                                   1959 ;	-----------------------------------------
      007BDE                       1960 _unregister_weak_mods:
      007BDE E5 82            [12] 1961 	mov	a,dpl
      007BE0 90 08 9D         [24] 1962 	mov	dptr,#_unregister_weak_mods_mods_10000_768
      007BE3 F0               [24] 1963 	movx	@dptr,a
                                   1964 ;	quantum/action.c:1159: if (mods) {
      007BE4 E0               [24] 1965 	movx	a,@dptr
      007BE5 FF               [12] 1966 	mov	r7,a
      007BE6 E0               [24] 1967 	movx	a,@dptr
      007BE7 60 08            [24] 1968 	jz	00103$
                                   1969 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      007BE9 8F 82            [24] 1970 	mov	dpl, r7
      007BEB 12 82 07         [24] 1971 	lcall	_del_owned_weak_mods
                                   1972 ;	quantum/action.c:1161: send_keyboard_report();
                                   1973 ;	quantum/action.c:1163: }
      007BEE 02 85 0D         [24] 1974 	ljmp	_send_keyboard_report
      007BF1                       1975 00103$:
      007BF1 22               [24] 1976 	ret
                                   1977 ;------------------------------------------------------------
                                   1978 ;Allocation info for local variables in function 'clear_keyboard'
                                   1979 ;------------------------------------------------------------
                                   1980 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1981 ;	-----------------------------------------
                                   1982 ;	 function clear_keyboard
                                   1983 ;	-----------------------------------------
      007BF2                       1984 _clear_keyboard:
                                   1985 ;	quantum/action.c:1170: clear_mods();
      007BF2 12 85 88         [24] 1986 	lcall	_clear_mods
                                   1987 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1988 ;	quantum/action.c:1172: }
      007BF5 61 F7            [12] 1989 	ajmp	_clear_keyboard_but_mods
                                   1990 ;------------------------------------------------------------
                                   1991 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1992 ;------------------------------------------------------------
                                   1993 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1994 ;	-----------------------------------------
                                   1995 ;	 function clear_keyboard_but_mods
                                   1996 ;	-----------------------------------------
      007BF7                       1997 _clear_keyboard_but_mods:
                                   1998 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007BF7 90 0D FC         [24] 1999 	mov	dptr,#_actual_keyboard_report
      007BFA 12 74 43         [24] 2000 	lcall	_clear_keys_from_report
                                   2001 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   2002 ;	quantum/action.c:1181: }
      007BFD 61 FF            [12] 2003 	ajmp	_clear_keyboard_but_mods_and_keys
                                   2004 ;------------------------------------------------------------
                                   2005 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2006 ;------------------------------------------------------------
                                   2007 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   2008 ;	-----------------------------------------
                                   2009 ;	 function clear_keyboard_but_mods_and_keys
                                   2010 ;	-----------------------------------------
      007BFF                       2011 _clear_keyboard_but_mods_and_keys:
                                   2012 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007BFF 12 4C 0B         [24] 2013 	lcall	_ak820_tapping_cancel
                                   2014 ;	quantum/action.c:1200: ak820_dynamic_macro_cancel();
      007C02 12 3B 76         [24] 2015 	lcall	_ak820_dynamic_macro_cancel
                                   2016 ;	quantum/action.c:1203: ak820_autoshift_cancel();
      007C05 12 33 45         [24] 2017 	lcall	_ak820_autoshift_cancel
                                   2018 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007C08 12 2E F0         [24] 2019 	lcall	_ak820_oneshot_cancel
                                   2020 ;	quantum/action.c:1209: ak820_combo_cancel();
      007C0B 12 37 6D         [24] 2021 	lcall	_ak820_combo_cancel
                                   2022 ;	quantum/action.c:1212: repeat_key_cancel();
      007C0E 12 A5 07         [24] 2023 	lcall	_repeat_key_cancel
                                   2024 ;	quantum/action.c:1214: clear_owned_mods();
      007C11 12 82 16         [24] 2025 	lcall	_clear_owned_mods
                                   2026 ;	quantum/action.c:1215: clear_owned_keys();
      007C14 12 82 4E         [24] 2027 	lcall	_clear_owned_keys
                                   2028 ;	quantum/action.c:1216: clear_owned_usages();
      007C17 12 83 82         [24] 2029 	lcall	_clear_owned_usages
                                   2030 ;	quantum/action.c:1217: layer_hold_clear();
      007C1A B1 D4            [12] 2031 	acall	_layer_hold_clear
                                   2032 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007C1C 12 A0 BA         [24] 2033 	lcall	_clear_macro_tri_layer
                                   2034 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007C1F 90 0D FC         [24] 2035 	mov	dptr,#_actual_keyboard_report
      007C22 12 74 43         [24] 2036 	lcall	_clear_keys_from_report
                                   2037 ;	quantum/action.c:1224: host_system_send(0);
      007C25 90 00 00         [24] 2038 	mov	dptr,#0x0000
      007C28 12 72 24         [24] 2039 	lcall	_host_system_send
                                   2040 ;	quantum/action.c:1225: host_consumer_send(0);
      007C2B 90 00 00         [24] 2041 	mov	dptr,#0x0000
      007C2E 12 72 53         [24] 2042 	lcall	_host_consumer_send
                                   2043 ;	quantum/action.c:1227: clear_weak_mods();
      007C31 12 85 BD         [24] 2044 	lcall	_clear_weak_mods
                                   2045 ;	quantum/action.c:1228: send_keyboard_report();
                                   2046 ;	quantum/action.c:1236: }
      007C34 02 85 0D         [24] 2047 	ljmp	_send_keyboard_report
                                   2048 ;------------------------------------------------------------
                                   2049 ;Allocation info for local variables in function 'is_tap_record'
                                   2050 ;------------------------------------------------------------
                                   2051 ;record        Allocated with name '_is_tap_record_record_10000_784'
                                   2052 ;action        Allocated with name '_is_tap_record_action_10001_788'
                                   2053 ;------------------------------------------------------------
                                   2054 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   2055 ;	-----------------------------------------
                                   2056 	.area CSEG    (CODE)
                                   2057 	.area CONST   (CODE)
                                   2058 	.area XINIT   (CODE)
      00C44F                       2059 __xinit__disable_action_cache:
      00C44F 00                    2060 	.db #0x00	;  0
                                   2061 	.area CABS    (ABS,CODE)
                                   2062 
                                   2063 ; Experimental exact instruction outlining.
                                   2064 	.globl _ak820_outline_0004
                                   2065 	.globl _ak820_outline_0008
                                   2066 	.globl _ak820_outline_0009
                                   2067 	.globl _ak820_outline_0010
                                   2068 	.globl _ak820_outline_0011
                                   2069 	.globl _ak820_outline_0015
                                   2070 	.globl _ak820_outline_0016
                                   2071 	.globl _ak820_outline_0019
                                   2072 	.globl _ak820_outline_0030
                                   2073 	.globl _ak820_outline_0038
                                   2074 	.globl _ak820_outline_0043
                                   2075 	.globl _ak820_outline_0050
                                   2076 	.globl _ak820_outline_0051
                                   2077 	.globl _ak820_outline_0057
                                   2078 	.globl _ak820_outline_0060
                                   2079 	.globl _ak820_outline_0062
                                   2080 	.globl _ak820_outline_0070
                                   2081 	.globl _ak820_outline_0075
                                   2082 	.globl _ak820_outline_0076
                                   2083 	.globl _ak820_outline_0086
                                   2084 	.globl _ak820_outline_0093
                                   2085 	.globl _ak820_outline_0094
                                   2086 	.globl _ak820_outline_0098
                                   2087 	.globl _ak820_outline_0104
                                   2088 	.globl _ak820_outline_0105
                                   2089 	.globl _ak820_outline_0107
                                   2090 	.globl _ak820_outline_0108
                                   2091 	.globl _ak820_outline_0109
                                   2092 	.globl _ak820_outline_0116
                                   2093 	.globl _ak820_outline_0121
                                   2094 	.globl _ak820_outline_0122
                                   2095 	.globl _ak820_outline_0123
                                   2096 	.globl _ak820_outline_0129
                                   2097 	.globl _ak820_outline_0139
                                   2098 	.globl _ak820_outline_0140
                                   2099 	.globl _ak820_outline_0141
                                   2100 	.globl _ak820_outline_0154
                                   2101 	.globl _ak820_outline_0162
                                   2102 	.globl _ak820_outline_0163
                                   2103 	.globl _ak820_outline_0178
                                   2104 	.globl _ak820_outline_0184
                                   2105 
                                   2106 	.area CSEG (CODE)
                                   2107 ; function ak820_outline_0019
      007C37                       2108 _ak820_outline_0019:
      007C37 8E 82            [24] 2109 	mov	dpl,r6
      007C39 8F 83            [24] 2110 	mov	dph,r7
      007C3B A3               [24] 2111 	inc	dptr
      007C3C E0               [24] 2112 	movx	a,@dptr
      007C3D FC               [12] 2113 	mov	r4,a
      007C3E 7D 00            [12] 2114 	mov	r5,#0x00
      007C40 8E 82            [24] 2115 	mov	dpl,r6
      007C42 8F 83            [24] 2116 	mov	dph,r7
      007C44 E0               [24] 2117 	movx	a,@dptr
      007C45 22               [24] 2118 	ret
                                   2119 
                                   2120 	.area CSEG (CODE)
                                   2121 ; function ak820_outline_0038
      007C46                       2122 _ak820_outline_0038:
      007C46 90 08 90         [24] 2123 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C49 E0               [24] 2124 	movx	a,@dptr
      007C4A 54 1F            [12] 2125 	anl	a,#0x1f
      007C4C F5 82            [12] 2126 	mov	dpl,a
      007C4E 22               [24] 2127 	ret
                                   2128 
                                   2129 	.area CSEG (CODE)
                                   2130 ; function ak820_outline_0050
      007C4F                       2131 _ak820_outline_0050:
      007C4F A3               [24] 2132 	inc	dptr
      007C50 F0               [24] 2133 	movx	@dptr,a
      007C51 E4               [12] 2134 	clr	a
      007C52 A3               [24] 2135 	inc	dptr
      007C53 F0               [24] 2136 	movx	@dptr,a
      007C54 90 0D D9         [24] 2137 	mov	dptr,#___memcpy_PARM_3
      007C57 22               [24] 2138 	ret
                                   2139 
                                   2140 	.area CSEG (CODE)
                                   2141 ; function ak820_outline_0062
      007C58                       2142 _ak820_outline_0062:
      007C58 F5 F0            [12] 2143 	mov	b,a
      007C5A 05 F0            [12] 2144 	inc	b
      007C5C 74 01            [12] 2145 	mov	a,#0x01
      007C5E 22               [24] 2146 	ret
                                   2147 
                                   2148 	.area CSEG (CODE)
                                   2149 ; function ak820_outline_0076
      007C5F                       2150 _ak820_outline_0076:
      007C5F 90 08 8F         [24] 2151 	mov	dptr,#_process_action_PARM_2
      007C62 E0               [24] 2152 	movx	a,@dptr
      007C63 F5 82            [12] 2153 	mov	dpl,a
      007C65 22               [24] 2154 	ret
                                   2155 
                                   2156 	.area CSEG (CODE)
                                   2157 ; function ak820_outline_0086
      007C66                       2158 _ak820_outline_0086:
      007C66 90 08 90         [24] 2159 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C69 E0               [24] 2160 	movx	a,@dptr
      007C6A 03               [12] 2161 	rr	a
      007C6B 03               [12] 2162 	rr	a
      007C6C 54 03            [12] 2163 	anl	a,#0x03
      007C6E 22               [24] 2164 	ret
                                   2165 
                                   2166 	.area CSEG (CODE)
                                   2167 ; function ak820_outline_0108
      007C6F                       2168 _ak820_outline_0108:
      007C6F 74 06            [12] 2169 	mov	a,#0x06
      007C71 F0               [24] 2170 	movx	@dptr,a
      007C72 E4               [12] 2171 	clr	a
      007C73 A3               [24] 2172 	inc	dptr
      007C74 F0               [24] 2173 	movx	@dptr,a
      007C75 22               [24] 2174 	ret
                                   2175 
                                   2176 	.area CSEG (CODE)
                                   2177 ; function ak820_outline_0109
      007C76                       2178 _ak820_outline_0109:
      007C76 90 08 90         [24] 2179 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C79 E0               [24] 2180 	movx	a,@dptr
      007C7A 54 0F            [12] 2181 	anl	a,#0x0f
      007C7C 22               [24] 2182 	ret
                                   2183 
                                   2184 	.area CSEG (CODE)
                                   2185 ; function ak820_outline_0129
      007C7D                       2186 _ak820_outline_0129:
      007C7D 90 08 8F         [24] 2187 	mov	dptr,#_process_action_PARM_2
      007C80 E0               [24] 2188 	movx	a,@dptr
      007C81 FE               [12] 2189 	mov	r6,a
      007C82 A3               [24] 2190 	inc	dptr
      007C83 E0               [24] 2191 	movx	a,@dptr
      007C84 54 03            [12] 2192 	anl	a,#0x03
      007C86 FF               [12] 2193 	mov	r7,a
      007C87 22               [24] 2194 	ret
                                   2195 
                                   2196 	.area CSEG (CODE)
                                   2197 ; function ak820_outline_0154
      007C88                       2198 _ak820_outline_0154:
      007C88 90 08 8F         [24] 2199 	mov	dptr,#_process_action_PARM_2
      007C8B E0               [24] 2200 	movx	a,@dptr
      007C8C 22               [24] 2201 	ret
                                   2202 
                                   2203 	.area CSEG (CODE)
                                   2204 ; function ak820_outline_0162
      007C8D                       2205 _ak820_outline_0162:
      007C8D 90 08 94         [24] 2206 	mov	dptr,#_register_code_code_10000_720
      007C90 E0               [24] 2207 	movx	a,@dptr
      007C91 FF               [12] 2208 	mov	r7,a
      007C92 22               [24] 2209 	ret
                                   2210 
                                   2211 	.area CSEG (CODE)
                                   2212 ; function ak820_outline_0163
      007C93                       2213 _ak820_outline_0163:
      007C93 90 08 95         [24] 2214 	mov	dptr,#_unregister_code_code_10000_734
      007C96 E0               [24] 2215 	movx	a,@dptr
      007C97 FF               [12] 2216 	mov	r7,a
      007C98 22               [24] 2217 	ret
                                   2218 
                                   2219 	.area CSEG (CODE)
                                   2220 ; function ak820_outline_0184
      007C99                       2221 _ak820_outline_0184:
      007C99 E4               [12] 2222 	clr	a
      007C9A F0               [24] 2223 	movx	@dptr,a
      007C9B 8F 82            [24] 2224 	mov	dpl,r7
      007C9D 22               [24] 2225 	ret
