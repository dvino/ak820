                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_dynamic_macro
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_keyboard_report_pending
                                     12 	.globl _get_repeat_key_count
                                     13 	.globl _del_owned_key
                                     14 	.globl _add_owned_key
                                     15 	.globl _del_owned_mods
                                     16 	.globl _add_owned_mods
                                     17 	.globl _get_weak_mods
                                     18 	.globl _get_mods
                                     19 	.globl _send_keyboard_report
                                     20 	.globl _timer_read
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_dynamic_macro_observe_PARM_2
                                    265 	.globl _ak820_dynamic_macro_process_PARM_2
                                    266 	.globl _ak820_dynamic_macro_source
                                    267 	.globl _ak820_dynamic_macro_cancel
                                    268 	.globl _ak820_dynamic_macro_process
                                    269 	.globl _ak820_dynamic_macro_observe
                                    270 	.globl _ak820_dynamic_macro_task
                                    271 ;--------------------------------------------------------
                                    272 ; special function registers
                                    273 ;--------------------------------------------------------
                                    274 	.area RSEG    (ABS,DATA)
      000000                        275 	.org 0x0000
                           0000D0   276 _PSW	=	0x00d0
                           0000E0   277 _ACC	=	0x00e0
                           0000F0   278 _B	=	0x00f0
                           0000FD   279 _A_INV	=	0x00fd
                           000081   280 _SP	=	0x0081
                           000082   281 _DPL	=	0x0082
                           000083   282 _DPH	=	0x0083
                           0000A1   283 _SAFE_MOD	=	0x00a1
                           0000B1   284 _GLOBAL_CFG	=	0x00b1
                           000087   285 _PCON	=	0x0087
                           0000BA   286 _POWER_CFG	=	0x00ba
                           0000B9   287 _CLOCK_CFG	=	0x00b9
                           0000A9   288 _WAKE_CTRL	=	0x00a9
                           0000FE   289 _RESET_KEEP	=	0x00fe
                           0000FF   290 _WDOG_COUNT	=	0x00ff
                           0000A8   291 _IE	=	0x00a8
                           0000B8   292 _IP	=	0x00b8
                           0000E8   293 _IE_EX	=	0x00e8
                           0000E9   294 _IP_EX	=	0x00e9
                           0000B2   295 _GPIO_IE	=	0x00b2
                           008584   296 _ROM_ADDR	=	0x8584
                           000084   297 _ROM_ADDR_L	=	0x0084
                           000085   298 _ROM_ADDR_H	=	0x0085
                           008F8E   299 _ROM_DATA_HI	=	0x8f8e
                           00008E   300 _ROM_DATA_HL	=	0x008e
                           00008F   301 _ROM_DATA_HH	=	0x008f
                           000086   302 _ROM_CTRL	=	0x0086
                           000080   303 _P0	=	0x0080
                           0000C4   304 _P0_MOD_OC	=	0x00c4
                           0000C5   305 _P0_DIR_PU	=	0x00c5
                           000090   306 _P1	=	0x0090
                           000092   307 _P1_MOD_OC	=	0x0092
                           000093   308 _P1_DIR_PU	=	0x0093
                           0000A0   309 _P2	=	0x00a0
                           000094   310 _P2_MOD_OC	=	0x0094
                           000095   311 _P2_DIR_PU	=	0x0095
                           0000B0   312 _P3	=	0x00b0
                           000096   313 _P3_MOD_OC	=	0x0096
                           000097   314 _P3_DIR_PU	=	0x0097
                           0000C0   315 _P4	=	0x00c0
                           0000C2   316 _P4_MOD_OC	=	0x00c2
                           0000C3   317 _P4_DIR_PU	=	0x00c3
                           0000C1   318 _P4_LED_KEY	=	0x00c1
                           0000AA   319 _P5_IN	=	0x00aa
                           0000AB   320 _P5_OUT_PU	=	0x00ab
                           0000AC   321 _P5_DIR	=	0x00ac
                           0000AD   322 _P6_IN	=	0x00ad
                           0000AE   323 _P6_OUT_PU	=	0x00ae
                           0000AF   324 _P6_DIR	=	0x00af
                           0000F1   325 _P7	=	0x00f1
                           0000A2   326 _XBUS_AUX	=	0x00a2
                           000088   327 _TCON	=	0x0088
                           000089   328 _TMOD	=	0x0089
                           00008A   329 _TL0	=	0x008a
                           00008B   330 _TL1	=	0x008b
                           00008C   331 _TH0	=	0x008c
                           00008D   332 _TH1	=	0x008d
                           000098   333 _SCON	=	0x0098
                           000099   334 _SBUF	=	0x0099
                           0000C8   335 _T2CON	=	0x00c8
                           0000C9   336 _T2MOD	=	0x00c9
                           00CBCA   337 _RCAP2	=	0xcbca
                           0000CA   338 _RCAP2L	=	0x00ca
                           0000CB   339 _RCAP2H	=	0x00cb
                           00CDCC   340 _T2COUNT	=	0xcdcc
                           0000CC   341 _TL2	=	0x00cc
                           0000CD   342 _TH2	=	0x00cd
                           00CFCE   343 _T2CAP1	=	0xcfce
                           0000CE   344 _T2CAP1L	=	0x00ce
                           0000CF   345 _T2CAP1H	=	0x00cf
                           0000F8   346 _SPI0_STAT	=	0x00f8
                           0000F9   347 _SPI0_DATA	=	0x00f9
                           0000FA   348 _SPI0_CTRL	=	0x00fa
                           0000FB   349 _SPI0_CK_SE	=	0x00fb
                           0000FC   350 _SPI0_SETUP	=	0x00fc
                           0000BC   351 _SCON1	=	0x00bc
                           0000BD   352 _SBUF1	=	0x00bd
                           0000BE   353 _SBAUD1	=	0x00be
                           0000BF   354 _SIF1	=	0x00bf
                           0000B4   355 _SPI1_STAT	=	0x00b4
                           0000B5   356 _SPI1_DATA	=	0x00b5
                           0000B6   357 _SPI1_CTRL	=	0x00b6
                           0000B7   358 _SPI1_CK_SE	=	0x00b7
                           0000F3   359 _ADC_CTRL	=	0x00f3
                           00F5F4   360 _ADC_DAT	=	0xf5f4
                           0000F4   361 _ADC_DAT_L	=	0x00f4
                           0000F5   362 _ADC_DAT_H	=	0x00f5
                           0000F6   363 _ADC_CHAN	=	0x00f6
                           0000A6   364 _LED_COMMON	=	0x00a6
                           0000A7   365 _LED_PWM_OE	=	0x00a7
                           00C7C6   366 _LED_DMA	=	0xc7c6
                           0000C6   367 _LED_DMA_L	=	0x00c6
                           0000C7   368 _LED_DMA_H	=	0x00c7
                           0000F7   369 _LED_STATUS	=	0x00f7
                           0000B3   370 _I2CX_INT	=	0x00b3
                           0000BB   371 _I2CS_INT_ST	=	0x00bb
                                    372 ;--------------------------------------------------------
                                    373 ; special function bits
                                    374 ;--------------------------------------------------------
                                    375 	.area RSEG    (ABS,DATA)
      000000                        376 	.org 0x0000
                           0000D7   377 _CY	=	0x00d7
                           0000D6   378 _AC	=	0x00d6
                           0000D5   379 _F0	=	0x00d5
                           0000D4   380 _RS1	=	0x00d4
                           0000D3   381 _RS0	=	0x00d3
                           0000D2   382 _OV	=	0x00d2
                           0000D1   383 _F1	=	0x00d1
                           0000D0   384 _P	=	0x00d0
                           0000AF   385 _EA	=	0x00af
                           0000AE   386 _E_DIS	=	0x00ae
                           0000AD   387 _ET2	=	0x00ad
                           0000AC   388 _ES	=	0x00ac
                           0000AB   389 _ET1	=	0x00ab
                           0000AA   390 _EX1	=	0x00aa
                           0000A9   391 _ET0	=	0x00a9
                           0000A8   392 _EX0	=	0x00a8
                           0000BF   393 _PH_FLAG	=	0x00bf
                           0000BE   394 _PL_FLAG	=	0x00be
                           0000BD   395 _PT2	=	0x00bd
                           0000BC   396 _PS	=	0x00bc
                           0000BB   397 _PT1	=	0x00bb
                           0000BA   398 _PX1	=	0x00ba
                           0000B9   399 _PT0	=	0x00b9
                           0000B8   400 _PX0	=	0x00b8
                           0000EF   401 _IE_WDOG	=	0x00ef
                           0000EE   402 _IE_GPIO	=	0x00ee
                           0000ED   403 _IE_PWM_I2C	=	0x00ed
                           0000EC   404 _IE_UART1	=	0x00ec
                           0000EB   405 _IE_ADC	=	0x00eb
                           0000E9   406 _IE_USB	=	0x00e9
                           0000E8   407 _IE_SPI0	=	0x00e8
                           000087   408 _P0_7	=	0x0087
                           000086   409 _P0_6	=	0x0086
                           000085   410 _P0_5	=	0x0085
                           000084   411 _P0_4	=	0x0084
                           000083   412 _P0_3	=	0x0083
                           000082   413 _P0_2	=	0x0082
                           000081   414 _P0_1	=	0x0081
                           000080   415 _P0_0	=	0x0080
                           000081   416 _SDA0	=	0x0081
                           000080   417 _SCL0	=	0x0080
                           000083   418 _TXD_	=	0x0083
                           000082   419 _RXD_	=	0x0082
                           000085   420 _AIN13	=	0x0085
                           000084   421 _AIN12	=	0x0084
                           000083   422 _AIN11	=	0x0083
                           000082   423 _AIN10	=	0x0082
                           000081   424 _AIN9	=	0x0081
                           000080   425 _AIN8	=	0x0080
                           000097   426 _P1_7	=	0x0097
                           000096   427 _P1_6	=	0x0096
                           000095   428 _P1_5	=	0x0095
                           000094   429 _P1_4	=	0x0094
                           000093   430 _P1_3	=	0x0093
                           000092   431 _P1_2	=	0x0092
                           000091   432 _P1_1	=	0x0091
                           000090   433 _P1_0	=	0x0090
                           000097   434 _TXD1_	=	0x0097
                           000096   435 _RXD1_	=	0x0096
                           000097   436 _SCK	=	0x0097
                           000096   437 _MISO	=	0x0096
                           000095   438 _MOSI	=	0x0095
                           000094   439 _SCS	=	0x0094
                           000092   440 _INT0_	=	0x0092
                           000091   441 _T2EX	=	0x0091
                           000091   442 _CAP2	=	0x0091
                           000090   443 _T2	=	0x0090
                           000090   444 _CAP1	=	0x0090
                           000097   445 _AIN7	=	0x0097
                           000096   446 _AIN6	=	0x0096
                           000095   447 _AIN5	=	0x0095
                           000094   448 _AIN4	=	0x0094
                           000093   449 _AIN3	=	0x0093
                           000092   450 _AIN2	=	0x0092
                           000091   451 _AIN1	=	0x0091
                           000090   452 _AIN0	=	0x0090
                           0000A7   453 _P2_7	=	0x00a7
                           0000A6   454 _P2_6	=	0x00a6
                           0000A5   455 _P2_5	=	0x00a5
                           0000A4   456 _P2_4	=	0x00a4
                           0000A3   457 _P2_3	=	0x00a3
                           0000A2   458 _P2_2	=	0x00a2
                           0000A1   459 _P2_1	=	0x00a1
                           0000A0   460 _P2_0	=	0x00a0
                           0000A7   461 _TXD1	=	0x00a7
                           0000A6   462 _RXD1	=	0x00a6
                           0000A5   463 _T2EX_	=	0x00a5
                           0000A5   464 _CAP2_	=	0x00a5
                           0000A4   465 _T2_	=	0x00a4
                           0000A4   466 _CAP1_	=	0x00a4
                           0000B7   467 _P3_7	=	0x00b7
                           0000B6   468 _P3_6	=	0x00b6
                           0000B5   469 _P3_5	=	0x00b5
                           0000B4   470 _P3_4	=	0x00b4
                           0000B3   471 _P3_3	=	0x00b3
                           0000B2   472 _P3_2	=	0x00b2
                           0000B1   473 _P3_1	=	0x00b1
                           0000B0   474 _P3_0	=	0x00b0
                           0000B7   475 _SCK1	=	0x00b7
                           0000B6   476 _MISO1	=	0x00b6
                           0000B5   477 _MOSI1	=	0x00b5
                           0000B5   478 _T1	=	0x00b5
                           0000B4   479 _T0	=	0x00b4
                           0000B3   480 _INT1	=	0x00b3
                           0000B2   481 _INT0	=	0x00b2
                           0000B1   482 _TXD	=	0x00b1
                           0000B0   483 _RXD	=	0x00b0
                           0000C6   484 _P4_6	=	0x00c6
                           0000C5   485 _P4_5	=	0x00c5
                           0000C4   486 _P4_4	=	0x00c4
                           0000C3   487 _P4_3	=	0x00c3
                           0000C2   488 _P4_2	=	0x00c2
                           0000C1   489 _P4_1	=	0x00c1
                           0000C0   490 _P4_0	=	0x00c0
                           00008F   491 _TF1	=	0x008f
                           00008E   492 _TR1	=	0x008e
                           00008D   493 _TF0	=	0x008d
                           00008C   494 _TR0	=	0x008c
                           00008B   495 _IE1	=	0x008b
                           00008A   496 _IT1	=	0x008a
                           000089   497 _IE0	=	0x0089
                           000088   498 _IT0	=	0x0088
                           00009F   499 _SM0	=	0x009f
                           00009E   500 _SM1	=	0x009e
                           00009D   501 _SM2	=	0x009d
                           00009C   502 _REN	=	0x009c
                           00009B   503 _TB8	=	0x009b
                           00009A   504 _RB8	=	0x009a
                           000099   505 _TI	=	0x0099
                           000098   506 _RI	=	0x0098
                           0000CF   507 _TF2	=	0x00cf
                           0000CF   508 _CAP1F	=	0x00cf
                           0000CE   509 _EXF2	=	0x00ce
                           0000CD   510 _RCLK	=	0x00cd
                           0000CC   511 _TCLK	=	0x00cc
                           0000CB   512 _EXEN2	=	0x00cb
                           0000CA   513 _TR2	=	0x00ca
                           0000C9   514 _C_T2	=	0x00c9
                           0000C8   515 _CP_RL2	=	0x00c8
                           0000FF   516 _S0_FST_ACT	=	0x00ff
                           0000FE   517 _S0_IF_OV	=	0x00fe
                           0000FD   518 _S0_IF_FIRST	=	0x00fd
                           0000FC   519 _S0_IF_BYTE	=	0x00fc
                           0000FB   520 _S0_FREE	=	0x00fb
                           0000FA   521 _S0_T_FIFO	=	0x00fa
                           0000F8   522 _S0_R_FIFO	=	0x00f8
                           0000F7   523 _ADC_START	=	0x00f7
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable register banks
                                    526 ;--------------------------------------------------------
                                    527 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        528 	.ds 8
                                    529 ;--------------------------------------------------------
                                    530 ; internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area DSEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; overlayable items in internal ram
                                    535 ;--------------------------------------------------------
                                    536 ;--------------------------------------------------------
                                    537 ; indirectly addressable internal ram data
                                    538 ;--------------------------------------------------------
                                    539 	.area ISEG    (DATA)
                                    540 ;--------------------------------------------------------
                                    541 ; absolute internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area IABS    (ABS,DATA)
                                    544 	.area IABS    (ABS,DATA)
                                    545 ;--------------------------------------------------------
                                    546 ; bit data
                                    547 ;--------------------------------------------------------
                                    548 	.area BSEG    (BIT)
                                    549 ;--------------------------------------------------------
                                    550 ; paged external ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area PSEG    (PAG,XDATA)
                                    553 ;--------------------------------------------------------
                                    554 ; uninitialized external ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area XSEG    (XDATA)
      000470                        557 _dm_taps:
      000470                        558 	.ds 64
      0004B0                        559 _dm_lengths:
      0004B0                        560 	.ds 2
      0004B2                        561 _dm_record:
      0004B2                        562 	.ds 1
      0004B3                        563 _dm_play:
      0004B3                        564 	.ds 1
      0004B4                        565 _dm_index:
      0004B4                        566 	.ds 1
      0004B5                        567 _dm_down:
      0004B5                        568 	.ds 1
      0004B6                        569 _dm_mods:
      0004B6                        570 	.ds 1
      0004B7                        571 _dm_time:
      0004B7                        572 	.ds 2
      0004B9                        573 _ak820_dynamic_macro_source::
      0004B9                        574 	.ds 1
      0004BA                        575 _ak820_dynamic_macro_process_PARM_2:
      0004BA                        576 	.ds 1
      0004BB                        577 _ak820_dynamic_macro_process_code_10000_602:
      0004BB                        578 	.ds 2
      0004BD                        579 _ak820_dynamic_macro_observe_PARM_2:
      0004BD                        580 	.ds 1
      0004BE                        581 _ak820_dynamic_macro_observe_code_10000_611:
      0004BE                        582 	.ds 1
      0004BF                        583 _ak820_dynamic_macro_observe_slot_10001_614:
      0004BF                        584 	.ds 1
      0004C0                        585 _ak820_dynamic_macro_observe_base_10001_614:
      0004C0                        586 	.ds 1
      0004C1                        587 _ak820_dynamic_macro_observe_i_30001_616:
      0004C1                        588 	.ds 1
      0004C2                        589 _ak820_dynamic_macro_task_now_10000_623:
      0004C2                        590 	.ds 2
      0004C4                        591 _ak820_dynamic_macro_task_i_40000_630:
      0004C4                        592 	.ds 1
      0004C5                        593 _ak820_dynamic_macro_task_code_40000_630:
      0004C5                        594 	.ds 1
                                    595 ;--------------------------------------------------------
                                    596 ; absolute external ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area XABS    (ABS,XDATA)
                                    599 ;--------------------------------------------------------
                                    600 ; initialized external ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area XISEG   (XDATA)
                                    603 	.area HOME    (CODE)
                                    604 	.area GSINIT0 (CODE)
                                    605 	.area GSINIT1 (CODE)
                                    606 	.area GSINIT2 (CODE)
                                    607 	.area GSINIT3 (CODE)
                                    608 	.area GSINIT4 (CODE)
                                    609 	.area GSINIT5 (CODE)
                                    610 	.area GSINIT  (CODE)
                                    611 	.area GSFINAL (CODE)
                                    612 	.area CSEG    (CODE)
                                    613 ;--------------------------------------------------------
                                    614 ; global & static initialisations
                                    615 ;--------------------------------------------------------
                                    616 	.area HOME    (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area GSINIT  (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; Home
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area HOME    (CODE)
                                    625 ;--------------------------------------------------------
                                    626 ; code
                                    627 ;--------------------------------------------------------
                                    628 	.area CSEG    (CODE)
                                    629 ;------------------------------------------------------------
                                    630 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    631 ;------------------------------------------------------------
                                    632 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    633 ;------------------------------------------------------------
                                    634 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    635 ;	-----------------------------------------
                           000007   636 	ar7 = 0x07
                           000006   637 	ar6 = 0x06
                           000005   638 	ar5 = 0x05
                           000004   639 	ar4 = 0x04
                           000003   640 	ar3 = 0x03
                           000002   641 	ar2 = 0x02
                           000001   642 	ar1 = 0x01
                           000000   643 	ar0 = 0x00
                                    644 ;	 function dm_finish
                                    645 ;	-----------------------------------------
      003AD5                        646 _dm_finish:
                                    647 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:17: if (dm_record) {
      003AD5 90 04 B2         [24]  648 	mov	dptr,#_dm_record
      003AD8 E0               [24]  649 	movx	a,@dptr
      003AD9 FF               [12]  650 	mov	r7,a
      003ADA E0               [24]  651 	movx	a,@dptr
      003ADB 70 01            [24]  652 	jnz	00140$
      003ADD 22               [24]  653 	ret
      003ADE                        654 00140$:
                                    655 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:18: uint8_t slot = dm_record - 1, base = slot * 16, out = 0;
      003ADE 1F               [12]  656 	dec	r7
      003ADF EF               [12]  657 	mov	a,r7
      003AE0 C4               [12]  658 	swap	a
      003AE1 54 F0            [12]  659 	anl	a,#0xf0
      003AE3 FE               [12]  660 	mov	r6,a
                                    661 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:19: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003AE4 EF               [12]  662 	mov	a,r7
      003AE5 24 B0            [12]  663 	add	a, #_dm_lengths
      003AE7 FD               [12]  664 	mov	r5,a
      003AE8 E4               [12]  665 	clr	a
      003AE9 34 04            [12]  666 	addc	a, #(_dm_lengths >> 8)
      003AEB FF               [12]  667 	mov	r7,a
      003AEC 7C 00            [12]  668 	mov	r4,#0x00
      003AEE 7B 00            [12]  669 	mov	r3,#0x00
      003AF0                        670 00107$:
      003AF0 8D 82            [24]  671 	mov	dpl,r5
      003AF2 8F 83            [24]  672 	mov	dph,r7
      003AF4 E0               [24]  673 	movx	a,@dptr
      003AF5 FA               [12]  674 	mov	r2,a
      003AF6 C3               [12]  675 	clr	c
      003AF7 EB               [12]  676 	mov	a,r3
      003AF8 9A               [12]  677 	subb	a,r2
      003AF9 50 6F            [24]  678 	jnc	00103$
                                    679 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:20: if (!(dm_taps[base + i].code & 0x80)) {
      003AFB EB               [12]  680 	mov	a,r3
      003AFC 2E               [12]  681 	add	a, r6
      003AFD 75 F0 02         [24]  682 	mov	b,#0x02
      003B00 A4               [48]  683 	mul	ab
      003B01 24 70            [12]  684 	add	a, #_dm_taps
      003B03 F5 82            [12]  685 	mov	dpl,a
      003B05 74 04            [12]  686 	mov	a,#(_dm_taps >> 8)
      003B07 35 F0            [12]  687 	addc	a, b
      003B09 F5 83            [12]  688 	mov	dph,a
      003B0B E0               [24]  689 	movx	a,@dptr
      003B0C 20 E7 58         [24]  690 	jb	acc.7,00108$
                                    691 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:21: dm_taps[base + out] = dm_taps[base + i];
      003B0F C0 05            [24]  692 	push	ar5
      003B11 C0 07            [24]  693 	push	ar7
      003B13 EC               [12]  694 	mov	a,r4
      003B14 2E               [12]  695 	add	a, r6
      003B15 75 F0 02         [24]  696 	mov	b,#0x02
      003B18 A4               [48]  697 	mul	ab
      003B19 24 70            [12]  698 	add	a, #_dm_taps
      003B1B F9               [12]  699 	mov	r1,a
      003B1C 74 04            [12]  700 	mov	a,#(_dm_taps >> 8)
      003B1E 35 F0            [12]  701 	addc	a, b
      003B20 F8               [12]  702 	mov	r0,a
      003B21 7A 00            [12]  703 	mov	r2,#0x00
      003B23 EB               [12]  704 	mov	a,r3
      003B24 2E               [12]  705 	add	a, r6
      003B25 75 F0 02         [24]  706 	mov	b,#0x02
      003B28 A4               [48]  707 	mul	ab
      003B29 24 70            [12]  708 	add	a, #_dm_taps
      003B2B FD               [12]  709 	mov	r5,a
      003B2C 74 04            [12]  710 	mov	a,#(_dm_taps >> 8)
      003B2E 35 F0            [12]  711 	addc	a, b
      003B30 FF               [12]  712 	mov	r7,a
      003B31 90 0D D6         [24]  713 	mov	dptr,#___memcpy_PARM_2
      003B34 ED               [12]  714 	mov	a,r5
      003B35 F0               [24]  715 	movx	@dptr,a
      003B36 EF               [12]  716 	mov	a,r7
      003B37 A3               [24]  717 	inc	dptr
      003B38 F0               [24]  718 	movx	@dptr,a
      003B39 E4               [12]  719 	clr	a
      003B3A A3               [24]  720 	inc	dptr
      003B3B F0               [24]  721 	movx	@dptr,a
      003B3C 90 0D D9         [24]  722 	mov	dptr,#___memcpy_PARM_3
      003B3F 74 02            [12]  723 	mov	a,#0x02
      003B41 F0               [24]  724 	movx	@dptr,a
      003B42 E4               [12]  725 	clr	a
      003B43 A3               [24]  726 	inc	dptr
      003B44 F0               [24]  727 	movx	@dptr,a
      003B45 89 82            [24]  728 	mov	dpl, r1
      003B47 88 83            [24]  729 	mov	dph, r0
      003B49 8A F0            [24]  730 	mov	b, r2
      003B4B C0 07            [24]  731 	push	ar7
      003B4D C0 06            [24]  732 	push	ar6
      003B4F C0 05            [24]  733 	push	ar5
      003B51 C0 04            [24]  734 	push	ar4
      003B53 C0 03            [24]  735 	push	ar3
      003B55 12 BB 7E         [24]  736 	lcall	___memcpy
      003B58 D0 03            [24]  737 	pop	ar3
      003B5A D0 04            [24]  738 	pop	ar4
      003B5C D0 05            [24]  739 	pop	ar5
      003B5E D0 06            [24]  740 	pop	ar6
      003B60 D0 07            [24]  741 	pop	ar7
                                    742 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:22: ++out;
      003B62 0C               [12]  743 	inc	r4
                                    744 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:26: dm_record = 0;
      003B63 D0 07            [24]  745 	pop	ar7
      003B65 D0 05            [24]  746 	pop	ar5
                                    747 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:22: ++out;
      003B67                        748 00108$:
                                    749 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:19: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003B67 0B               [12]  750 	inc	r3
      003B68 80 86            [24]  751 	sjmp	00107$
      003B6A                        752 00103$:
                                    753 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:25: dm_lengths[slot] = out;
      003B6A 8D 82            [24]  754 	mov	dpl,r5
      003B6C 8F 83            [24]  755 	mov	dph,r7
      003B6E EC               [12]  756 	mov	a,r4
      003B6F F0               [24]  757 	movx	@dptr,a
                                    758 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:26: dm_record = 0;
      003B70 90 04 B2         [24]  759 	mov	dptr,#_dm_record
      003B73 E4               [12]  760 	clr	a
      003B74 F0               [24]  761 	movx	@dptr,a
                                    762 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:28: }
      003B75 22               [24]  763 	ret
                                    764 ;------------------------------------------------------------
                                    765 ;Allocation info for local variables in function 'ak820_dynamic_macro_cancel'
                                    766 ;------------------------------------------------------------
                                    767 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:29: void ak820_dynamic_macro_cancel(void) {
                                    768 ;	-----------------------------------------
                                    769 ;	 function ak820_dynamic_macro_cancel
                                    770 ;	-----------------------------------------
      003B76                        771 _ak820_dynamic_macro_cancel:
                                    772 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:30: dm_finish();
      003B76 12 3A D5         [24]  773 	lcall	_dm_finish
                                    774 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:33: dm_play = dm_down = 0;
      003B79 90 04 B5         [24]  775 	mov	dptr,#_dm_down
      003B7C E4               [12]  776 	clr	a
      003B7D F0               [24]  777 	movx	@dptr,a
      003B7E 90 04 B3         [24]  778 	mov	dptr,#_dm_play
      003B81 F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:34: ak820_dynamic_macro_source = false;
      003B82 90 04 B9         [24]  781 	mov	dptr,#_ak820_dynamic_macro_source
      003B85 F0               [24]  782 	movx	@dptr,a
                                    783 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:35: }
      003B86 22               [24]  784 	ret
                                    785 ;------------------------------------------------------------
                                    786 ;Allocation info for local variables in function 'ak820_dynamic_macro_process'
                                    787 ;------------------------------------------------------------
                                    788 ;pressed       Allocated with name '_ak820_dynamic_macro_process_PARM_2'
                                    789 ;code          Allocated with name '_ak820_dynamic_macro_process_code_10000_602'
                                    790 ;------------------------------------------------------------
                                    791 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:36: bool ak820_dynamic_macro_process(uint16_t code, bool pressed) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function ak820_dynamic_macro_process
                                    794 ;	-----------------------------------------
      003B87                        795 _ak820_dynamic_macro_process:
      003B87 AF 83            [24]  796 	mov	r7,dph
      003B89 E5 82            [12]  797 	mov	a,dpl
      003B8B 90 04 BB         [24]  798 	mov	dptr,#_ak820_dynamic_macro_process_code_10000_602
      003B8E F0               [24]  799 	movx	@dptr,a
      003B8F EF               [12]  800 	mov	a,r7
      003B90 A3               [24]  801 	inc	dptr
      003B91 F0               [24]  802 	movx	@dptr,a
                                    803 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:37: if (code < QK_DYNAMIC_MACRO_RECORD_START_1 || code > QK_DYNAMIC_MACRO_PLAY_2) return true;
      003B92 90 04 BB         [24]  804 	mov	dptr,#_ak820_dynamic_macro_process_code_10000_602
      003B95 E0               [24]  805 	movx	a,@dptr
      003B96 FE               [12]  806 	mov	r6,a
      003B97 A3               [24]  807 	inc	dptr
      003B98 E0               [24]  808 	movx	a,@dptr
      003B99 FF               [12]  809 	mov	r7,a
      003B9A 8E 04            [24]  810 	mov	ar4,r6
      003B9C 8F 05            [24]  811 	mov	ar5,r7
      003B9E C3               [12]  812 	clr	c
      003B9F EC               [12]  813 	mov	a,r4
      003BA0 94 53            [12]  814 	subb	a,#0x53
      003BA2 ED               [12]  815 	mov	a,r5
      003BA3 94 7C            [12]  816 	subb	a,#0x7c
      003BA5 40 08            [24]  817 	jc	00101$
      003BA7 74 57            [12]  818 	mov	a,#0x57
      003BA9 9C               [12]  819 	subb	a,r4
      003BAA 74 7C            [12]  820 	mov	a,#0x7c
      003BAC 9D               [12]  821 	subb	a,r5
      003BAD 50 04            [24]  822 	jnc	00102$
                                    823 ;	free result
      003BAF                        824 00101$:
      003BAF 75 82 01         [24]  825 	mov	dpl, #0x01
      003BB2 22               [24]  826 	ret
      003BB3                        827 00102$:
                                    828 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:38: if (!pressed || get_repeat_key_count()) return false;
      003BB3 90 04 BA         [24]  829 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      003BB6 E0               [24]  830 	movx	a,@dptr
      003BB7 60 07            [24]  831 	jz	00104$
      003BB9 12 A5 9B         [24]  832 	lcall	_get_repeat_key_count
      003BBC E5 82            [12]  833 	mov	a, dpl
      003BBE 60 04            [24]  834 	jz	00105$
      003BC0                        835 00104$:
      003BC0 75 82 00         [24]  836 	mov	dpl, #0x00
      003BC3 22               [24]  837 	ret
      003BC4                        838 00105$:
                                    839 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:41: if (dm_play) return false;
      003BC4 90 04 B3         [24]  840 	mov	dptr,#_dm_play
      003BC7 E0               [24]  841 	movx	a,@dptr
      003BC8 60 04            [24]  842 	jz	00108$
      003BCA 75 82 00         [24]  843 	mov	dpl, #0x00
      003BCD 22               [24]  844 	ret
      003BCE                        845 00108$:
                                    846 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:42: dm_finish();
      003BCE C0 07            [24]  847 	push	ar7
      003BD0 C0 06            [24]  848 	push	ar6
      003BD2 C0 05            [24]  849 	push	ar5
      003BD4 C0 04            [24]  850 	push	ar4
      003BD6 12 3A D5         [24]  851 	lcall	_dm_finish
      003BD9 D0 04            [24]  852 	pop	ar4
      003BDB D0 05            [24]  853 	pop	ar5
      003BDD D0 06            [24]  854 	pop	ar6
      003BDF D0 07            [24]  855 	pop	ar7
                                    856 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:43: if (code <= QK_DYNAMIC_MACRO_RECORD_START_2) {
      003BE1 C3               [12]  857 	clr	c
      003BE2 74 54            [12]  858 	mov	a,#0x54
      003BE4 9C               [12]  859 	subb	a,r4
      003BE5 74 7C            [12]  860 	mov	a,#0x7c
      003BE7 9D               [12]  861 	subb	a,r5
      003BE8 40 1E            [24]  862 	jc	00112$
                                    863 ;	free result
                                    864 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:44: dm_record = code - QK_DYNAMIC_MACRO_RECORD_START_1 + 1;
      003BEA 8E 03            [24]  865 	mov	ar3,r6
      003BEC 74 AE            [12]  866 	mov	a,#0xae
      003BEE 2B               [12]  867 	add	a, r3
      003BEF FB               [12]  868 	mov	r3,a
      003BF0 90 04 B2         [24]  869 	mov	dptr,#_dm_record
      003BF3 F0               [24]  870 	movx	@dptr,a
                                    871 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:45: dm_lengths[dm_record - 1] = 0;
      003BF4 1B               [12]  872 	dec	r3
      003BF5 EB               [12]  873 	mov	a,r3
      003BF6 33               [12]  874 	rlc	a
      003BF7 95 E0            [12]  875 	subb	a,acc
      003BF9 FA               [12]  876 	mov	r2,a
      003BFA EB               [12]  877 	mov	a,r3
      003BFB 24 B0            [12]  878 	add	a, #_dm_lengths
      003BFD F5 82            [12]  879 	mov	dpl,a
      003BFF EA               [12]  880 	mov	a,r2
      003C00 34 04            [12]  881 	addc	a, #(_dm_lengths >> 8)
      003C02 F5 83            [12]  882 	mov	dph,a
      003C04 E4               [12]  883 	clr	a
      003C05 F0               [24]  884 	movx	@dptr,a
      003C06 80 29            [24]  885 	sjmp	00113$
      003C08                        886 00112$:
                                    887 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:46: } else if (code >= QK_DYNAMIC_MACRO_PLAY_1) {
      003C08 C3               [12]  888 	clr	c
      003C09 EC               [12]  889 	mov	a,r4
      003C0A 94 56            [12]  890 	subb	a,#0x56
      003C0C ED               [12]  891 	mov	a,r5
      003C0D 94 7C            [12]  892 	subb	a,#0x7c
      003C0F 40 20            [24]  893 	jc	00113$
                                    894 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:47: dm_play = code - QK_DYNAMIC_MACRO_PLAY_1 + 1;
      003C11 90 04 B3         [24]  895 	mov	dptr,#_dm_play
      003C14 74 AB            [12]  896 	mov	a,#0xab
      003C16 2E               [12]  897 	add	a, r6
      003C17 F0               [24]  898 	movx	@dptr,a
                                    899 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:48: dm_index = dm_down = 0;
      003C18 90 04 B5         [24]  900 	mov	dptr,#_dm_down
      003C1B E4               [12]  901 	clr	a
      003C1C F0               [24]  902 	movx	@dptr,a
      003C1D 90 04 B4         [24]  903 	mov	dptr,#_dm_index
      003C20 F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:49: dm_time = timer_read();
      003C21 12 4E 52         [24]  906 	lcall	_timer_read
      003C24 E5 82            [12]  907 	mov	a, dpl
      003C26 85 83 F0         [24]  908 	mov	b, dph
      003C29 90 04 B7         [24]  909 	mov	dptr,#_dm_time
      003C2C F0               [24]  910 	movx	@dptr,a
      003C2D E5 F0            [12]  911 	mov	a,b
      003C2F A3               [24]  912 	inc	dptr
      003C30 F0               [24]  913 	movx	@dptr,a
      003C31                        914 00113$:
                                    915 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:51: return false;
      003C31 75 82 00         [24]  916 	mov	dpl, #0x00
                                    917 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:52: }
      003C34 22               [24]  918 	ret
                                    919 ;------------------------------------------------------------
                                    920 ;Allocation info for local variables in function 'ak820_dynamic_macro_observe'
                                    921 ;------------------------------------------------------------
                                    922 ;pressed       Allocated with name '_ak820_dynamic_macro_observe_PARM_2'
                                    923 ;code          Allocated with name '_ak820_dynamic_macro_observe_code_10000_611'
                                    924 ;slot          Allocated with name '_ak820_dynamic_macro_observe_slot_10001_614'
                                    925 ;base          Allocated with name '_ak820_dynamic_macro_observe_base_10001_614'
                                    926 ;i             Allocated with name '_ak820_dynamic_macro_observe_i_30001_616'
                                    927 ;i             Allocated with name '_ak820_dynamic_macro_observe_i_40001_619'
                                    928 ;------------------------------------------------------------
                                    929 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:53: void ak820_dynamic_macro_observe(uint8_t code, bool pressed) {
                                    930 ;	-----------------------------------------
                                    931 ;	 function ak820_dynamic_macro_observe
                                    932 ;	-----------------------------------------
      003C35                        933 _ak820_dynamic_macro_observe:
      003C35 E5 82            [12]  934 	mov	a,dpl
      003C37 90 04 BE         [24]  935 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_611
      003C3A F0               [24]  936 	movx	@dptr,a
                                    937 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:54: if (!dm_record || !ak820_dynamic_macro_source || code < KC_A || code >= 0x80) return;
      003C3B 90 04 B2         [24]  938 	mov	dptr,#_dm_record
      003C3E E0               [24]  939 	movx	a,@dptr
      003C3F FF               [12]  940 	mov	r7,a
      003C40 E0               [24]  941 	movx	a,@dptr
      003C41 60 15            [24]  942 	jz	00101$
      003C43 90 04 B9         [24]  943 	mov	dptr,#_ak820_dynamic_macro_source
      003C46 E0               [24]  944 	movx	a,@dptr
      003C47 60 0F            [24]  945 	jz	00101$
      003C49 90 04 BE         [24]  946 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_611
      003C4C E0               [24]  947 	movx	a,@dptr
      003C4D FE               [12]  948 	mov	r6,a
      003C4E BE 04 00         [24]  949 	cjne	r6,#0x04,00177$
      003C51                        950 00177$:
      003C51 40 05            [24]  951 	jc	00101$
      003C53 BE 80 00         [24]  952 	cjne	r6,#0x80,00179$
      003C56                        953 00179$:
      003C56 40 01            [24]  954 	jc	00102$
      003C58                        955 00101$:
      003C58 22               [24]  956 	ret
      003C59                        957 00102$:
                                    958 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:55: uint8_t slot = dm_record - 1, base = slot * 16;
      003C59 1F               [12]  959 	dec	r7
      003C5A 90 04 BF         [24]  960 	mov	dptr,#_ak820_dynamic_macro_observe_slot_10001_614
      003C5D EF               [12]  961 	mov	a,r7
      003C5E F0               [24]  962 	movx	@dptr,a
      003C5F EF               [12]  963 	mov	a,r7
      003C60 C4               [12]  964 	swap	a
      003C61 54 F0            [12]  965 	anl	a,#0xf0
      003C63 FD               [12]  966 	mov	r5,a
      003C64 90 04 C0         [24]  967 	mov	dptr,#_ak820_dynamic_macro_observe_base_10001_614
      003C67 F0               [24]  968 	movx	@dptr,a
                                    969 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:56: if (pressed) {
      003C68 90 04 BD         [24]  970 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      003C6B E0               [24]  971 	movx	a,@dptr
      003C6C 60 67            [24]  972 	jz	00134$
                                    973 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:57: uint8_t i = dm_lengths[slot];
      003C6E EF               [12]  974 	mov	a,r7
      003C6F 24 B0            [12]  975 	add	a, #_dm_lengths
      003C71 F5 82            [12]  976 	mov	dpl,a
      003C73 E4               [12]  977 	clr	a
      003C74 34 04            [12]  978 	addc	a, #(_dm_lengths >> 8)
      003C76 F5 83            [12]  979 	mov	dph,a
      003C78 E0               [24]  980 	movx	a,@dptr
      003C79 FC               [12]  981 	mov	r4,a
      003C7A 90 04 C1         [24]  982 	mov	dptr,#_ak820_dynamic_macro_observe_i_30001_616
      003C7D F0               [24]  983 	movx	@dptr,a
                                    984 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:58: if (i == 16) return; /* Full: retain first 16; still accept releases. */
      003C7E BC 10 01         [24]  985 	cjne	r4,#0x10,00107$
      003C81 22               [24]  986 	ret
      003C82                        987 00107$:
                                    988 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:59: dm_taps[base + i].code = code | 0x80;
      003C82 EC               [12]  989 	mov	a,r4
      003C83 2D               [12]  990 	add	a, r5
      003C84 75 F0 02         [24]  991 	mov	b,#0x02
      003C87 A4               [48]  992 	mul	ab
      003C88 24 70            [12]  993 	add	a, #_dm_taps
      003C8A F5 82            [12]  994 	mov	dpl,a
      003C8C 74 04            [12]  995 	mov	a,#(_dm_taps >> 8)
      003C8E 35 F0            [12]  996 	addc	a, b
      003C90 F5 83            [12]  997 	mov	dph,a
      003C92 43 06 80         [24]  998 	orl	ar6,#0x80
      003C95 EE               [12]  999 	mov	a,r6
      003C96 F0               [24] 1000 	movx	@dptr,a
                                   1001 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:60: dm_taps[base + i].mods = get_mods() | get_weak_mods();
      003C97 90 04 C1         [24] 1002 	mov	dptr,#_ak820_dynamic_macro_observe_i_30001_616
      003C9A E0               [24] 1003 	movx	a,@dptr
      003C9B FE               [12] 1004 	mov	r6,a
      003C9C 90 04 C0         [24] 1005 	mov	dptr,#_ak820_dynamic_macro_observe_base_10001_614
      003C9F E0               [24] 1006 	movx	a,@dptr
      003CA0 2E               [12] 1007 	add	a, r6
      003CA1 75 F0 02         [24] 1008 	mov	b,#0x02
      003CA4 A4               [48] 1009 	mul	ab
      003CA5 24 70            [12] 1010 	add	a, #_dm_taps
      003CA7 FB               [12] 1011 	mov	r3,a
      003CA8 74 04            [12] 1012 	mov	a,#(_dm_taps >> 8)
      003CAA 35 F0            [12] 1013 	addc	a, b
      003CAC FC               [12] 1014 	mov	r4,a
      003CAD 0B               [12] 1015 	inc	r3
      003CAE BB 00 01         [24] 1016 	cjne	r3,#0x00,00184$
      003CB1 0C               [12] 1017 	inc	r4
      003CB2                       1018 00184$:
      003CB2 12 85 78         [24] 1019 	lcall	_get_mods
      003CB5 AA 82            [24] 1020 	mov	r2, dpl
      003CB7 12 85 8E         [24] 1021 	lcall	_get_weak_mods
      003CBA E5 82            [12] 1022 	mov	a,dpl
      003CBC 42 02            [12] 1023 	orl	ar2,a
      003CBE 8B 82            [24] 1024 	mov	dpl,r3
      003CC0 8C 83            [24] 1025 	mov	dph,r4
      003CC2 EA               [12] 1026 	mov	a,r2
      003CC3 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:61: dm_lengths[slot] = i + 1;
      003CC4 90 04 BF         [24] 1029 	mov	dptr,#_ak820_dynamic_macro_observe_slot_10001_614
      003CC7 E0               [24] 1030 	movx	a,@dptr
      003CC8 24 B0            [12] 1031 	add	a, #_dm_lengths
      003CCA F5 82            [12] 1032 	mov	dpl,a
      003CCC E4               [12] 1033 	clr	a
      003CCD 34 04            [12] 1034 	addc	a, #(_dm_lengths >> 8)
      003CCF F5 83            [12] 1035 	mov	dph,a
      003CD1 0E               [12] 1036 	inc	r6
      003CD2 EE               [12] 1037 	mov	a,r6
      003CD3 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:63: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003CD4 22               [24] 1040 	ret
      003CD5                       1041 00134$:
      003CD5 EF               [12] 1042 	mov	a,r7
      003CD6 24 B0            [12] 1043 	add	a, #_dm_lengths
      003CD8 FE               [12] 1044 	mov	r6,a
      003CD9 E4               [12] 1045 	clr	a
      003CDA 34 04            [12] 1046 	addc	a, #(_dm_lengths >> 8)
      003CDC FF               [12] 1047 	mov	r7,a
      003CDD 7C 00            [12] 1048 	mov	r4,#0x00
      003CDF                       1049 00115$:
      003CDF 8E 82            [24] 1050 	mov	dpl,r6
      003CE1 8F 83            [24] 1051 	mov	dph,r7
      003CE3 E0               [24] 1052 	movx	a,@dptr
      003CE4 FB               [12] 1053 	mov	r3,a
      003CE5 C3               [12] 1054 	clr	c
      003CE6 EC               [12] 1055 	mov	a,r4
      003CE7 9B               [12] 1056 	subb	a,r3
      003CE8 50 35            [24] 1057 	jnc	00117$
                                   1058 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:64: if (dm_taps[base + i].code == (uint8_t)(code | 0x80)) {
      003CEA EC               [12] 1059 	mov	a,r4
      003CEB 2D               [12] 1060 	add	a, r5
      003CEC 75 F0 02         [24] 1061 	mov	b,#0x02
      003CEF A4               [48] 1062 	mul	ab
      003CF0 24 70            [12] 1063 	add	a, #_dm_taps
      003CF2 F5 82            [12] 1064 	mov	dpl,a
      003CF4 74 04            [12] 1065 	mov	a,#(_dm_taps >> 8)
      003CF6 35 F0            [12] 1066 	addc	a, b
      003CF8 F5 83            [12] 1067 	mov	dph,a
      003CFA E0               [24] 1068 	movx	a,@dptr
      003CFB FB               [12] 1069 	mov	r3,a
      003CFC 90 04 BE         [24] 1070 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_611
      003CFF E0               [24] 1071 	movx	a,@dptr
      003D00 FA               [12] 1072 	mov	r2,a
      003D01 74 80            [12] 1073 	mov	a,#0x80
      003D03 4A               [12] 1074 	orl	a,r2
      003D04 F9               [12] 1075 	mov	r1,a
      003D05 EB               [12] 1076 	mov	a,r3
      003D06 B5 01 13         [24] 1077 	cjne	a,ar1,00116$
                                   1078 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:65: dm_taps[base + i].code = code;
      003D09 EC               [12] 1079 	mov	a,r4
      003D0A 2D               [12] 1080 	add	a, r5
      003D0B 75 F0 02         [24] 1081 	mov	b,#0x02
      003D0E A4               [48] 1082 	mul	ab
      003D0F 24 70            [12] 1083 	add	a, #_dm_taps
      003D11 F5 82            [12] 1084 	mov	dpl,a
      003D13 74 04            [12] 1085 	mov	a,#(_dm_taps >> 8)
      003D15 35 F0            [12] 1086 	addc	a, b
      003D17 F5 83            [12] 1087 	mov	dph,a
      003D19 EA               [12] 1088 	mov	a,r2
      003D1A F0               [24] 1089 	movx	@dptr,a
                                   1090 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:66: break;
      003D1B 22               [24] 1091 	ret
      003D1C                       1092 00116$:
                                   1093 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:63: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003D1C 0C               [12] 1094 	inc	r4
      003D1D 80 C0            [24] 1095 	sjmp	00115$
      003D1F                       1096 00117$:
                                   1097 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:70: }
      003D1F 22               [24] 1098 	ret
                                   1099 ;------------------------------------------------------------
                                   1100 ;Allocation info for local variables in function 'ak820_dynamic_macro_task'
                                   1101 ;------------------------------------------------------------
                                   1102 ;now           Allocated with name '_ak820_dynamic_macro_task_now_10000_623'
                                   1103 ;i             Allocated with name '_ak820_dynamic_macro_task_i_40000_630'
                                   1104 ;code          Allocated with name '_ak820_dynamic_macro_task_code_40000_630'
                                   1105 ;------------------------------------------------------------
                                   1106 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:71: void ak820_dynamic_macro_task(uint16_t now) {
                                   1107 ;	-----------------------------------------
                                   1108 ;	 function ak820_dynamic_macro_task
                                   1109 ;	-----------------------------------------
      003D20                       1110 _ak820_dynamic_macro_task:
      003D20 AF 83            [24] 1111 	mov	r7,dph
      003D22 E5 82            [12] 1112 	mov	a,dpl
      003D24 90 04 C2         [24] 1113 	mov	dptr,#_ak820_dynamic_macro_task_now_10000_623
      003D27 F0               [24] 1114 	movx	@dptr,a
      003D28 EF               [12] 1115 	mov	a,r7
      003D29 A3               [24] 1116 	inc	dptr
      003D2A F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:72: if (!dm_play || ak820_macro_primitive || ak820_keyboard_report_pending() || (uint16_t)(now - dm_time) < 10) return;
      003D2B 90 04 B3         [24] 1119 	mov	dptr,#_dm_play
      003D2E E0               [24] 1120 	movx	a,@dptr
      003D2F 60 2D            [24] 1121 	jz	00101$
      003D31 90 09 E2         [24] 1122 	mov	dptr,#_ak820_macro_primitive
      003D34 E0               [24] 1123 	movx	a,@dptr
      003D35 70 27            [24] 1124 	jnz	00101$
      003D37 12 4E BA         [24] 1125 	lcall	_ak820_keyboard_report_pending
      003D3A E5 82            [12] 1126 	mov	a, dpl
      003D3C 70 20            [24] 1127 	jnz	00101$
      003D3E 90 04 B7         [24] 1128 	mov	dptr,#_dm_time
      003D41 E0               [24] 1129 	movx	a,@dptr
      003D42 FE               [12] 1130 	mov	r6,a
      003D43 A3               [24] 1131 	inc	dptr
      003D44 E0               [24] 1132 	movx	a,@dptr
      003D45 FF               [12] 1133 	mov	r7,a
      003D46 90 04 C2         [24] 1134 	mov	dptr,#_ak820_dynamic_macro_task_now_10000_623
      003D49 E0               [24] 1135 	movx	a,@dptr
      003D4A FC               [12] 1136 	mov	r4,a
      003D4B A3               [24] 1137 	inc	dptr
      003D4C E0               [24] 1138 	movx	a,@dptr
      003D4D FD               [12] 1139 	mov	r5,a
      003D4E EC               [12] 1140 	mov	a,r4
      003D4F C3               [12] 1141 	clr	c
      003D50 9E               [12] 1142 	subb	a,r6
      003D51 FE               [12] 1143 	mov	r6,a
      003D52 ED               [12] 1144 	mov	a,r5
      003D53 9F               [12] 1145 	subb	a,r7
      003D54 FF               [12] 1146 	mov	r7,a
      003D55 C3               [12] 1147 	clr	c
      003D56 EE               [12] 1148 	mov	a,r6
      003D57 94 0A            [12] 1149 	subb	a,#0x0a
      003D59 EF               [12] 1150 	mov	a,r7
      003D5A 94 00            [12] 1151 	subb	a,#0x00
      003D5C 50 01            [24] 1152 	jnc	00102$
      003D5E                       1153 00101$:
      003D5E 22               [24] 1154 	ret
      003D5F                       1155 00102$:
                                   1156 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:73: dm_time = now;
      003D5F 90 04 B7         [24] 1157 	mov	dptr,#_dm_time
      003D62 EC               [12] 1158 	mov	a,r4
      003D63 F0               [24] 1159 	movx	@dptr,a
      003D64 ED               [12] 1160 	mov	a,r5
      003D65 A3               [24] 1161 	inc	dptr
      003D66 F0               [24] 1162 	movx	@dptr,a
                                   1163 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:74: if (dm_down) {
      003D67 90 04 B5         [24] 1164 	mov	dptr,#_dm_down
      003D6A E0               [24] 1165 	movx	a,@dptr
      003D6B FF               [12] 1166 	mov	r7,a
      003D6C E0               [24] 1167 	movx	a,@dptr
      003D6D 60 16            [24] 1168 	jz	00112$
                                   1169 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:75: del_owned_key(dm_down);
      003D6F 8F 82            [24] 1170 	mov	dpl, r7
      003D71 12 82 F4         [24] 1171 	lcall	_del_owned_key
                                   1172 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:76: del_owned_mods(dm_mods);
      003D74 90 04 B6         [24] 1173 	mov	dptr,#_dm_mods
      003D77 E0               [24] 1174 	movx	a,@dptr
      003D78 F5 82            [12] 1175 	mov	dpl,a
      003D7A 12 81 EB         [24] 1176 	lcall	_del_owned_mods
                                   1177 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:77: dm_down = 0;
      003D7D 90 04 B5         [24] 1178 	mov	dptr,#_dm_down
      003D80 E4               [12] 1179 	clr	a
      003D81 F0               [24] 1180 	movx	@dptr,a
                                   1181 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:78: send_keyboard_report();
      003D82 02 85 0D         [24] 1182 	ljmp	_send_keyboard_report
      003D85                       1183 00112$:
                                   1184 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:79: } else if (dm_index == dm_lengths[dm_play - 1]) {
      003D85 90 04 B3         [24] 1185 	mov	dptr,#_dm_play
      003D88 E0               [24] 1186 	movx	a,@dptr
      003D89 FF               [12] 1187 	mov	r7,a
      003D8A 14               [12] 1188 	dec	a
      003D8B FE               [12] 1189 	mov	r6,a
      003D8C 33               [12] 1190 	rlc	a
      003D8D 95 E0            [12] 1191 	subb	a,acc
      003D8F FD               [12] 1192 	mov	r5,a
      003D90 EE               [12] 1193 	mov	a,r6
      003D91 24 B0            [12] 1194 	add	a, #_dm_lengths
      003D93 F5 82            [12] 1195 	mov	dpl,a
      003D95 ED               [12] 1196 	mov	a,r5
      003D96 34 04            [12] 1197 	addc	a, #(_dm_lengths >> 8)
      003D98 F5 83            [12] 1198 	mov	dph,a
      003D9A E0               [24] 1199 	movx	a,@dptr
      003D9B FE               [12] 1200 	mov	r6,a
      003D9C 90 04 B4         [24] 1201 	mov	dptr,#_dm_index
      003D9F E0               [24] 1202 	movx	a,@dptr
      003DA0 FD               [12] 1203 	mov	r5,a
      003DA1 B5 06 06         [24] 1204 	cjne	a,ar6,00109$
                                   1205 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:80: dm_play = 0;
      003DA4 90 04 B3         [24] 1206 	mov	dptr,#_dm_play
      003DA7 E4               [12] 1207 	clr	a
      003DA8 F0               [24] 1208 	movx	@dptr,a
      003DA9 22               [24] 1209 	ret
      003DAA                       1210 00109$:
                                   1211 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:82: uint8_t i = (dm_play - 1) * 16 + dm_index++;
      003DAA 1F               [12] 1212 	dec	r7
      003DAB EF               [12] 1213 	mov	a,r7
      003DAC C4               [12] 1214 	swap	a
      003DAD 54 F0            [12] 1215 	anl	a,#0xf0
      003DAF FF               [12] 1216 	mov	r7,a
      003DB0 8D 06            [24] 1217 	mov	ar6,r5
      003DB2 90 04 B4         [24] 1218 	mov	dptr,#_dm_index
      003DB5 ED               [12] 1219 	mov	a,r5
      003DB6 04               [12] 1220 	inc	a
      003DB7 F0               [24] 1221 	movx	@dptr,a
      003DB8 EE               [12] 1222 	mov	a,r6
      003DB9 2F               [12] 1223 	add	a, r7
      003DBA FF               [12] 1224 	mov	r7,a
      003DBB 90 04 C4         [24] 1225 	mov	dptr,#_ak820_dynamic_macro_task_i_40000_630
      003DBE F0               [24] 1226 	movx	@dptr,a
                                   1227 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:83: uint8_t code = dm_taps[i].code;
      003DBF 8F E0            [24] 1228 	mov	acc,r7
      003DC1 75 F0 02         [24] 1229 	mov	b,#0x02
      003DC4 A4               [48] 1230 	mul	ab
      003DC5 24 70            [12] 1231 	add	a, #_dm_taps
      003DC7 F5 82            [12] 1232 	mov	dpl,a
      003DC9 74 04            [12] 1233 	mov	a,#(_dm_taps >> 8)
      003DCB 35 F0            [12] 1234 	addc	a, b
      003DCD F5 83            [12] 1235 	mov	dph,a
      003DCF E0               [24] 1236 	movx	a,@dptr
      003DD0 FF               [12] 1237 	mov	r7,a
      003DD1 90 04 C5         [24] 1238 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_630
      003DD4 F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:86: if (!add_owned_key(code)) {
      003DD5 8F 82            [24] 1241 	mov	dpl, r7
      003DD7 12 82 7B         [24] 1242 	lcall	_add_owned_key
      003DDA E5 82            [12] 1243 	mov	a, dpl
      003DDC 70 09            [24] 1244 	jnz	00107$
                                   1245 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:87: del_owned_key(code);
      003DDE 90 04 C5         [24] 1246 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_630
      003DE1 E0               [24] 1247 	movx	a,@dptr
      003DE2 F5 82            [12] 1248 	mov	dpl,a
                                   1249 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:88: return;
      003DE4 02 82 F4         [24] 1250 	ljmp	_del_owned_key
      003DE7                       1251 00107$:
                                   1252 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:90: dm_down = code;
      003DE7 90 04 C5         [24] 1253 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_630
      003DEA E0               [24] 1254 	movx	a,@dptr
      003DEB 90 04 B5         [24] 1255 	mov	dptr,#_dm_down
      003DEE F0               [24] 1256 	movx	@dptr,a
                                   1257 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:91: dm_mods = dm_taps[i].mods;
      003DEF 90 04 C4         [24] 1258 	mov	dptr,#_ak820_dynamic_macro_task_i_40000_630
      003DF2 E0               [24] 1259 	movx	a,@dptr
      003DF3 75 F0 02         [24] 1260 	mov	b,#0x02
      003DF6 A4               [48] 1261 	mul	ab
      003DF7 24 70            [12] 1262 	add	a, #_dm_taps
      003DF9 FE               [12] 1263 	mov	r6,a
      003DFA 74 04            [12] 1264 	mov	a,#(_dm_taps >> 8)
      003DFC 35 F0            [12] 1265 	addc	a, b
      003DFE FF               [12] 1266 	mov	r7,a
      003DFF 8E 82            [24] 1267 	mov	dpl,r6
      003E01 8F 83            [24] 1268 	mov	dph,r7
      003E03 A3               [24] 1269 	inc	dptr
      003E04 E0               [24] 1270 	movx	a,@dptr
      003E05 FF               [12] 1271 	mov	r7,a
      003E06 90 04 B6         [24] 1272 	mov	dptr,#_dm_mods
      003E09 F0               [24] 1273 	movx	@dptr,a
                                   1274 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:92: add_owned_mods(dm_mods);
      003E0A 8F 82            [24] 1275 	mov	dpl, r7
      003E0C 12 81 DC         [24] 1276 	lcall	_add_owned_mods
                                   1277 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:93: send_keyboard_report();
                                   1278 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:95: }
      003E0F 02 85 0D         [24] 1279 	ljmp	_send_keyboard_report
                                   1280 	.area CSEG    (CODE)
                                   1281 	.area CONST   (CODE)
                                   1282 	.area XINIT   (CODE)
                                   1283 	.area CABS    (ABS,CODE)
