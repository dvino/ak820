                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_keyboard_blocked
                                    286 	.globl _ak820_usb_take_keyboard_reset
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
      000016                        549 _control_setup_sloc1_1_0:
      000016                        550 	.ds 1
      000017                        551 _control_setup_sloc3_1_0:
      000017                        552 	.ds 2
      000019                        553 _control_setup_sloc4_1_0:
      000019                        554 	.ds 2
      00001B                        555 _ak820_usb_send_sloc0_1_0:
      00001B                        556 	.ds 2
      00001D                        557 _ak820_usb_send_sloc1_1_0:
      00001D                        558 	.ds 1
      00001E                        559 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        560 	.ds 2
                                    561 ;--------------------------------------------------------
                                    562 ; overlayable items in internal ram
                                    563 ;--------------------------------------------------------
                                    564 ;--------------------------------------------------------
                                    565 ; indirectly addressable internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area ISEG    (DATA)
                                    568 ;--------------------------------------------------------
                                    569 ; absolute internal ram data
                                    570 ;--------------------------------------------------------
                                    571 	.area IABS    (ABS,DATA)
                                    572 	.area IABS    (ABS,DATA)
                                    573 ;--------------------------------------------------------
                                    574 ; bit data
                                    575 ;--------------------------------------------------------
                                    576 	.area BSEG    (BIT)
      000016                        577 _control_setup_valid_interface_10000_287:
      000016                        578 	.ds 1
      000017                        579 _control_setup_zero_index_10000_287:
      000017                        580 	.ds 1
      000018                        581 _control_setup_zero_value_10000_287:
      000018                        582 	.ds 1
      000019                        583 _control_setup_zero_length_10000_287:
      000019                        584 	.ds 1
      00001A                        585 _control_setup_sloc0_1_0:
      00001A                        586 	.ds 1
      00001B                        587 _control_setup_sloc2_1_0:
      00001B                        588 	.ds 1
      00001C                        589 _ak820_usb_try_send_sloc0_1_0:
      00001C                        590 	.ds 1
      00001D                        591 _ak820_usb_raw_task_sloc1_1_0:
      00001D                        592 	.ds 1
      00001E                        593 _ak820_usb_keyboard_blocked_sloc0_1_0:
      00001E                        594 	.ds 1
      00001F                        595 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001F                        596 	.ds 1
                                    597 ;--------------------------------------------------------
                                    598 ; paged external ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area PSEG    (PAG,XDATA)
                                    601 ;--------------------------------------------------------
                                    602 ; uninitialized external ram data
                                    603 ;--------------------------------------------------------
                                    604 	.area XSEG    (XDATA)
      0007C7                        605 _D0SetupReqCode::
      0007C7                        606 	.ds 1
      0007C8                        607 _D0SetupLen::
      0007C8                        608 	.ds 2
      0007CA                        609 _pD0Descr::
      0007CA                        610 	.ds 3
      0007CD                        611 _D0UsbConfig::
      0007CD                        612 	.ds 1
      0007CE                        613 _USB_EnumStatus::
      0007CE                        614 	.ds 1
      0007CF                        615 _USB_SleepStatus::
      0007CF                        616 	.ds 1
      0007D0                        617 _MCU_Sleep_Operate::
      0007D0                        618 	.ds 1
      0007D1                        619 _KB_USB_UpStatus::
      0007D1                        620 	.ds 1
      0007D2                        621 _KB_USB_SetReport::
      0007D2                        622 	.ds 1
      0007D3                        623 _ak820_boot_stage::
      0007D3                        624 	.ds 1
      0007D4                        625 _ak820_main_heartbeat::
      0007D4                        626 	.ds 1
      0007D5                        627 _raw_state:
      0007D5                        628 	.ds 1
      0007D6                        629 _raw_buffer:
      0007D6                        630 	.ds 32
      0007F6                        631 _raw_reply_without_nvm:
      0007F6                        632 	.ds 1
      0007F7                        633 _keyboard_reset:
      0007F7                        634 	.ds 1
      0007F8                        635 _input_snapshot:
      0007F8                        636 	.ds 46
      000826                        637 _control_phase:
      000826                        638 	.ds 1
      000827                        639 _output_kind:
      000827                        640 	.ds 1
      000828                        641 _output_report_id:
      000828                        642 	.ds 1
      000829                        643 _control_zlp:
      000829                        644 	.ds 1
      00082A                        645 _control_pointer:
      00082A                        646 	.ds 2
      00082C                        647 _descriptor_select_PARM_2:
      00082C                        648 	.ds 1
      00082D                        649 _descriptor_select_PARM_3:
      00082D                        650 	.ds 2
      00082F                        651 _descriptor_select_type_10000_269:
      00082F                        652 	.ds 1
      000830                        653 _control_setup_length_10000_287:
      000830                        654 	.ds 2
      000832                        655 _control_setup_offset_10000_287:
      000832                        656 	.ds 1
      000833                        657 _ak820_usb_send_PARM_2:
      000833                        658 	.ds 2
      000835                        659 _ak820_usb_send_PARM_3:
      000835                        660 	.ds 1
      000836                        661 _ak820_usb_send_endpoint_10000_423:
      000836                        662 	.ds 1
      000837                        663 _ak820_usb_send_offset_10000_424:
      000837                        664 	.ds 1
      000838                        665 _ak820_usb_try_send_PARM_2:
      000838                        666 	.ds 2
      00083A                        667 _ak820_usb_try_send_PARM_3:
      00083A                        668 	.ds 1
      00083B                        669 _ak820_usb_try_send_endpoint_10000_444:
      00083B                        670 	.ds 1
      00083C                        671 _ak820_usb_try_send_sent_10000_445:
      00083C                        672 	.ds 1
      00083D                        673 _ak820_usb_raw_send_PARM_2:
      00083D                        674 	.ds 1
      00083E                        675 _ak820_usb_raw_send_report_10000_460:
      00083E                        676 	.ds 3
                                    677 ;--------------------------------------------------------
                                    678 ; absolute external ram data
                                    679 ;--------------------------------------------------------
                                    680 	.area XABS    (ABS,XDATA)
                                    681 ;--------------------------------------------------------
                                    682 ; initialized external ram data
                                    683 ;--------------------------------------------------------
                                    684 	.area XISEG   (XDATA)
                                    685 	.area HOME    (CODE)
                                    686 	.area GSINIT0 (CODE)
                                    687 	.area GSINIT1 (CODE)
                                    688 	.area GSINIT2 (CODE)
                                    689 	.area GSINIT3 (CODE)
                                    690 	.area GSINIT4 (CODE)
                                    691 	.area GSINIT5 (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 	.area GSFINAL (CODE)
                                    694 	.area CSEG    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; global & static initialisations
                                    697 ;--------------------------------------------------------
                                    698 	.area HOME    (CODE)
                                    699 	.area GSINIT  (CODE)
                                    700 	.area GSFINAL (CODE)
                                    701 	.area GSINIT  (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; Home
                                    704 ;--------------------------------------------------------
                                    705 	.area HOME    (CODE)
                                    706 	.area HOME    (CODE)
                                    707 ;--------------------------------------------------------
                                    708 ; code
                                    709 ;--------------------------------------------------------
                                    710 	.area CSEG    (CODE)
                                    711 ;------------------------------------------------------------
                                    712 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    713 ;------------------------------------------------------------
                                    714 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_46'
                                    715 ;------------------------------------------------------------
                                    716 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    717 ;	-----------------------------------------
                           000007   718 	ar7 = 0x07
                           000006   719 	ar6 = 0x06
                           000005   720 	ar5 = 0x05
                           000004   721 	ar4 = 0x04
                           000003   722 	ar3 = 0x03
                           000002   723 	ar2 = 0x02
                           000001   724 	ar1 = 0x01
                           000000   725 	ar0 = 0x00
                                    726 ;	 function raw_abort
                                    727 ;	-----------------------------------------
      005F3F                        728 _raw_abort:
                                    729 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005F3F 90 07 D5         [24]  730 	mov	dptr,#_raw_state
      005F42 E0               [24]  731 	movx	a,@dptr
      005F43 FF               [12]  732 	mov	r7,a
      005F44 BF 03 02         [24]  733 	cjne	r7,#0x03,00130$
      005F47 80 1C            [24]  734 	sjmp	00101$
      005F49                        735 00130$:
      005F49 90 07 D5         [24]  736 	mov	dptr,#_raw_state
      005F4C E0               [24]  737 	movx	a,@dptr
      005F4D FF               [12]  738 	mov	r7,a
      005F4E BF 04 02         [24]  739 	cjne	r7,#0x04,00131$
      005F51 80 12            [24]  740 	sjmp	00101$
      005F53                        741 00131$:
                                    742 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005F53 90 07 D5         [24]  743 	mov	dptr,#_raw_state
      005F56 E0               [24]  744 	movx	a,@dptr
      005F57 FF               [12]  745 	mov	r7,a
      005F58 BF 06 02         [24]  746 	cjne	r7,#0x06,00132$
      005F5B 80 08            [24]  747 	sjmp	00101$
      005F5D                        748 00132$:
      005F5D 90 07 D5         [24]  749 	mov	dptr,#_raw_state
      005F60 E0               [24]  750 	movx	a,@dptr
      005F61 FF               [12]  751 	mov	r7,a
      005F62 BF 07 08         [24]  752 	cjne	r7,#0x07,00102$
      005F65                        753 00101$:
                                    754 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      005F65 90 07 D5         [24]  755 	mov	dptr,#_raw_state
      005F68 74 07            [12]  756 	mov	a,#0x07
      005F6A F0               [24]  757 	movx	@dptr,a
      005F6B 80 05            [24]  758 	sjmp	00103$
      005F6D                        759 00102$:
                                    760 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      005F6D 90 07 D5         [24]  761 	mov	dptr,#_raw_state
      005F70 E4               [12]  762 	clr	a
      005F71 F0               [24]  763 	movx	@dptr,a
      005F72                        764 00103$:
                                    765 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      005F72 90 08 27         [24]  766 	mov	dptr,#_output_kind
      005F75 E4               [12]  767 	clr	a
      005F76 F0               [24]  768 	movx	@dptr,a
                                    769 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      005F77 22               [24]  770 	ret
                                    771 ;------------------------------------------------------------
                                    772 ;Allocation info for local variables in function 'raw_complete'
                                    773 ;------------------------------------------------------------
                                    774 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    775 ;	-----------------------------------------
                                    776 ;	 function raw_complete
                                    777 ;	-----------------------------------------
      005F78                        778 _raw_complete:
                                    779 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005F78 90 07 D5         [24]  780 	mov	dptr,#_raw_state
      005F7B E0               [24]  781 	movx	a,@dptr
      005F7C FF               [12]  782 	mov	r7,a
      005F7D BF 04 07         [24]  783 	cjne	r7,#0x04,00104$
      005F80 90 07 D5         [24]  784 	mov	dptr,#_raw_state
      005F83 74 06            [12]  785 	mov	a,#0x06
      005F85 F0               [24]  786 	movx	@dptr,a
      005F86 22               [24]  787 	ret
      005F87                        788 00104$:
                                    789 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005F87 90 07 D5         [24]  790 	mov	dptr,#_raw_state
      005F8A E0               [24]  791 	movx	a,@dptr
      005F8B FF               [12]  792 	mov	r7,a
      005F8C BF 05 05         [24]  793 	cjne	r7,#0x05,00106$
      005F8F 90 07 D5         [24]  794 	mov	dptr,#_raw_state
      005F92 E4               [12]  795 	clr	a
      005F93 F0               [24]  796 	movx	@dptr,a
      005F94                        797 00106$:
                                    798 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      005F94 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'endpoints_reset'
                                    802 ;------------------------------------------------------------
                                    803 ;i             Allocated with name '_endpoints_reset_i_10000_259'
                                    804 ;------------------------------------------------------------
                                    805 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    806 ;	-----------------------------------------
                                    807 ;	 function endpoints_reset
                                    808 ;	-----------------------------------------
      005F95                        809 _endpoints_reset:
                                    810 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      005F95 90 22 0C         [24]  811 	mov	dptr,#0x220c
      005F98 74 01            [12]  812 	mov	a,#0x01
      005F9A F0               [24]  813 	movx	@dptr,a
                                    814 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F9B F5 82            [12]  815 	mov	dpl,a
      005F9D 74 12            [12]  816 	mov	a,#0x12
      005F9F F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005FA0 A3               [24]  819 	inc	dptr
      005FA1 F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005FA2 A3               [24]  822 	inc	dptr
      005FA3 F0               [24]  823 	movx	@dptr,a
                                    824 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005FA4 90 22 0B         [24]  825 	mov	dptr,#0x220b
      005FA7 E4               [12]  826 	clr	a
      005FA8 F0               [24]  827 	movx	@dptr,a
      005FA9 15 82            [12]  828 	dec	dpl
      005FAB F0               [24]  829 	movx	@dptr,a
      005FAC 15 82            [12]  830 	dec	dpl
      005FAE F0               [24]  831 	movx	@dptr,a
                                    832 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005FAF FF               [12]  833 	mov	r7,a
      005FB0                        834 00103$:
      005FB0 EF               [12]  835 	mov	a,r7
      005FB1 24 F8            [12]  836 	add	a, #_input_snapshot
      005FB3 F5 82            [12]  837 	mov	dpl,a
      005FB5 E4               [12]  838 	clr	a
      005FB6 34 07            [12]  839 	addc	a, #(_input_snapshot >> 8)
      005FB8 F5 83            [12]  840 	mov	dph,a
      005FBA E4               [12]  841 	clr	a
      005FBB F0               [24]  842 	movx	@dptr,a
      005FBC 0F               [12]  843 	inc	r7
      005FBD BF 2E 00         [24]  844 	cjne	r7,#0x2e,00139$
      005FC0                        845 00139$:
      005FC0 40 EE            [24]  846 	jc	00103$
                                    847 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005FC2 90 08 00         [24]  848 	mov	dptr,#(_input_snapshot + 0x0008)
      005FC5 74 06            [12]  849 	mov	a,#0x06
      005FC7 F0               [24]  850 	movx	@dptr,a
                                    851 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005FC8 90 08 20         [24]  852 	mov	dptr,#(_input_snapshot + 0x0028)
      005FCB 03               [12]  853 	rr	a
      005FCC F0               [24]  854 	movx	@dptr,a
                                    855 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005FCD 90 08 23         [24]  856 	mov	dptr,#(_input_snapshot + 0x002b)
      005FD0 04               [12]  857 	inc	a
      005FD1 F0               [24]  858 	movx	@dptr,a
                                    859 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005FD2 7F 00            [12]  860 	mov	r7,#0x00
      005FD4                        861 00105$:
      005FD4 8F 06            [24]  862 	mov	ar6,r7
      005FD6 74 C0            [12]  863 	mov	a,#0xc0
      005FD8 2E               [12]  864 	add	a, r6
      005FD9 F5 82            [12]  865 	mov	dpl,a
      005FDB 74 10            [12]  866 	mov	a,#0x10
      005FDD 24 00            [12]  867 	add	a, #0x00
      005FDF F5 83            [12]  868 	mov	dph,a
      005FE1 E4               [12]  869 	clr	a
      005FE2 F0               [24]  870 	movx	@dptr,a
      005FE3 0F               [12]  871 	inc	r7
      005FE4 BF 20 00         [24]  872 	cjne	r7,#0x20,00141$
      005FE7                        873 00141$:
      005FE7 40 EB            [24]  874 	jc	00105$
                                    875 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    876 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      005FE9 02 5F 3F         [24]  877 	ljmp	_raw_abort
                                    878 ;------------------------------------------------------------
                                    879 ;Allocation info for local variables in function 'control_stall'
                                    880 ;------------------------------------------------------------
                                    881 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    882 ;	-----------------------------------------
                                    883 ;	 function control_stall
                                    884 ;	-----------------------------------------
      005FEC                        885 _control_stall:
                                    886 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005FEC 90 07 D5         [24]  887 	mov	dptr,#_raw_state
      005FEF E0               [24]  888 	movx	a,@dptr
      005FF0 FF               [12]  889 	mov	r7,a
      005FF1 BF 01 05         [24]  890 	cjne	r7,#0x01,00102$
      005FF4 90 07 D5         [24]  891 	mov	dptr,#_raw_state
      005FF7 E4               [12]  892 	clr	a
      005FF8 F0               [24]  893 	movx	@dptr,a
      005FF9                        894 00102$:
                                    895 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      005FF9 90 08 27         [24]  896 	mov	dptr,#_output_kind
      005FFC E4               [12]  897 	clr	a
      005FFD F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      005FFE 90 08 26         [24]  900 	mov	dptr,#_control_phase
      006001 F0               [24]  901 	movx	@dptr,a
                                    902 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      006002 90 07 C7         [24]  903 	mov	dptr,#_D0SetupReqCode
      006005 14               [12]  904 	dec	a
      006006 F0               [24]  905 	movx	@dptr,a
                                    906 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      006007 90 22 00         [24]  907 	mov	dptr,#0x2200
      00600A 74 CF            [12]  908 	mov	a,#0xcf
      00600C F0               [24]  909 	movx	@dptr,a
                                    910 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      00600D 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'control_next'
                                    914 ;------------------------------------------------------------
                                    915 ;i             Allocated with name '_control_next_i_10000_266'
                                    916 ;length        Allocated with name '_control_next_length_10000_266'
                                    917 ;------------------------------------------------------------
                                    918 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function control_next
                                    921 ;	-----------------------------------------
      00600E                        922 _control_next:
                                    923 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      00600E 90 07 C8         [24]  924 	mov	dptr,#_D0SetupLen
      006011 E0               [24]  925 	movx	a,@dptr
      006012 FE               [12]  926 	mov	r6,a
      006013 A3               [24]  927 	inc	dptr
      006014 E0               [24]  928 	movx	a,@dptr
      006015 FF               [12]  929 	mov	r7,a
      006016 C3               [12]  930 	clr	c
      006017 74 40            [12]  931 	mov	a,#0x40
      006019 9E               [12]  932 	subb	a,r6
      00601A E4               [12]  933 	clr	a
      00601B 9F               [12]  934 	subb	a,r7
      00601C 50 04            [24]  935 	jnc	00109$
                                    936 ;	free result
      00601E 7E 40            [12]  937 	mov	r6,#0x40
      006020 80 07            [24]  938 	sjmp	00110$
      006022                        939 00109$:
      006022 90 07 C8         [24]  940 	mov	dptr,#_D0SetupLen
      006025 E0               [24]  941 	movx	a,@dptr
      006026 FE               [12]  942 	mov	r6,a
      006027 A3               [24]  943 	inc	dptr
      006028 E0               [24]  944 	movx	a,@dptr
      006029                        945 00110$:
                                    946 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      006029 7F 00            [12]  947 	mov	r7,#0x00
      00602B                        948 00105$:
      00602B C3               [12]  949 	clr	c
      00602C EF               [12]  950 	mov	a,r7
      00602D 9E               [12]  951 	subb	a,r6
      00602E 50 2A            [24]  952 	jnc	00101$
      006030 8F 04            [24]  953 	mov	ar4,r7
      006032 74 10            [12]  954 	mov	a,#0x10
      006034 24 00            [12]  955 	add	a, #0x00
      006036 FD               [12]  956 	mov	r5,a
      006037 90 08 2A         [24]  957 	mov	dptr,#_control_pointer
      00603A E0               [24]  958 	movx	a,@dptr
      00603B FA               [12]  959 	mov	r2,a
      00603C A3               [24]  960 	inc	dptr
      00603D E0               [24]  961 	movx	a,@dptr
      00603E FB               [12]  962 	mov	r3,a
      00603F 8A 82            [24]  963 	mov	dpl,r2
      006041 8B 83            [24]  964 	mov	dph,r3
      006043 E4               [12]  965 	clr	a
      006044 93               [24]  966 	movc	a,@a+dptr
      006045 F9               [12]  967 	mov	r1,a
      006046 90 08 2A         [24]  968 	mov	dptr,#_control_pointer
      006049 74 01            [12]  969 	mov	a,#0x01
      00604B 2A               [12]  970 	add	a, r2
      00604C F0               [24]  971 	movx	@dptr,a
      00604D E4               [12]  972 	clr	a
      00604E 3B               [12]  973 	addc	a, r3
      00604F A3               [24]  974 	inc	dptr
      006050 F0               [24]  975 	movx	@dptr,a
      006051 8C 82            [24]  976 	mov	dpl,r4
      006053 8D 83            [24]  977 	mov	dph,r5
      006055 E9               [12]  978 	mov	a,r1
      006056 F0               [24]  979 	movx	@dptr,a
      006057 0F               [12]  980 	inc	r7
      006058 80 D1            [24]  981 	sjmp	00105$
      00605A                        982 00101$:
                                    983 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      00605A 8E 05            [24]  984 	mov	ar5,r6
      00605C 7F 00            [12]  985 	mov	r7,#0x00
      00605E 90 07 C8         [24]  986 	mov	dptr,#_D0SetupLen
      006061 E0               [24]  987 	movx	a,@dptr
      006062 FB               [12]  988 	mov	r3,a
      006063 A3               [24]  989 	inc	dptr
      006064 E0               [24]  990 	movx	a,@dptr
      006065 FC               [12]  991 	mov	r4,a
      006066 EB               [12]  992 	mov	a,r3
      006067 C3               [12]  993 	clr	c
      006068 9D               [12]  994 	subb	a,r5
      006069 FB               [12]  995 	mov	r3,a
      00606A EC               [12]  996 	mov	a,r4
      00606B 9F               [12]  997 	subb	a,r7
      00606C FC               [12]  998 	mov	r4,a
      00606D 90 07 C8         [24]  999 	mov	dptr,#_D0SetupLen
      006070 EB               [12] 1000 	mov	a,r3
      006071 F0               [24] 1001 	movx	@dptr,a
      006072 EC               [12] 1002 	mov	a,r4
      006073 A3               [24] 1003 	inc	dptr
      006074 F0               [24] 1004 	movx	@dptr,a
                                   1005 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      006075 EE               [12] 1006 	mov	a,r6
      006076 70 05            [24] 1007 	jnz	00103$
      006078 90 08 29         [24] 1008 	mov	dptr,#_control_zlp
      00607B E4               [12] 1009 	clr	a
      00607C F0               [24] 1010 	movx	@dptr,a
      00607D                       1011 00103$:
                                   1012 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      00607D 90 22 08         [24] 1013 	mov	dptr,#0x2208
      006080 EE               [12] 1014 	mov	a,r6
      006081 F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      006082 90 22 00         [24] 1017 	mov	dptr,#0x2200
      006085 E0               [24] 1018 	movx	a,@dptr
      006086 54 C0            [12] 1019 	anl	a,#0xc0
      006088 F0               [24] 1020 	movx	@dptr,a
                                   1021 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      006089 22               [24] 1022 	ret
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'descriptor_select'
                                   1025 ;------------------------------------------------------------
                                   1026 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1027 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1028 ;type          Allocated with name '_descriptor_select_type_10000_269'
                                   1029 ;hid           Allocated with name '_descriptor_select_hid_30000_282'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function descriptor_select
                                   1034 ;	-----------------------------------------
      00608A                       1035 _descriptor_select:
      00608A E5 82            [12] 1036 	mov	a,dpl
      00608C 90 08 2F         [24] 1037 	mov	dptr,#_descriptor_select_type_10000_269
      00608F F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      006090 E0               [24] 1040 	movx	a,@dptr
      006091 FF               [12] 1041 	mov	r7,a
      006092 BF 01 20         [24] 1042 	cjne	r7,#0x01,00102$
      006095 90 08 2C         [24] 1043 	mov	dptr,#_descriptor_select_PARM_2
      006098 E0               [24] 1044 	movx	a,@dptr
      006099 70 1A            [24] 1045 	jnz	00102$
      00609B 90 08 2D         [24] 1046 	mov	dptr,#_descriptor_select_PARM_3
      00609E E0               [24] 1047 	movx	a,@dptr
      00609F F5 F0            [12] 1048 	mov	b,a
      0060A1 A3               [24] 1049 	inc	dptr
      0060A2 E0               [24] 1050 	movx	a,@dptr
      0060A3 45 F0            [12] 1051 	orl	a,b
      0060A5 70 0E            [24] 1052 	jnz	00102$
                                   1053 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      0060A7 90 08 2A         [24] 1054 	mov	dptr,#_control_pointer
      0060AA 74 6E            [12] 1055 	mov	a,#_DeviceDescriptor
      0060AC F0               [24] 1056 	movx	@dptr,a
      0060AD 74 C3            [12] 1057 	mov	a,#(_DeviceDescriptor >> 8)
      0060AF A3               [24] 1058 	inc	dptr
      0060B0 F0               [24] 1059 	movx	@dptr,a
                                   1060 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      0060B1 90 00 12         [24] 1061 	mov	dptr,#0x0012
      0060B4 22               [24] 1062 	ret
      0060B5                       1063 00102$:
                                   1064 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      0060B5 90 08 2F         [24] 1065 	mov	dptr,#_descriptor_select_type_10000_269
      0060B8 E0               [24] 1066 	movx	a,@dptr
      0060B9 FF               [12] 1067 	mov	r7,a
      0060BA BF 02 20         [24] 1068 	cjne	r7,#0x02,00106$
      0060BD 90 08 2C         [24] 1069 	mov	dptr,#_descriptor_select_PARM_2
      0060C0 E0               [24] 1070 	movx	a,@dptr
      0060C1 70 1A            [24] 1071 	jnz	00106$
      0060C3 90 08 2D         [24] 1072 	mov	dptr,#_descriptor_select_PARM_3
      0060C6 E0               [24] 1073 	movx	a,@dptr
      0060C7 F5 F0            [12] 1074 	mov	b,a
      0060C9 A3               [24] 1075 	inc	dptr
      0060CA E0               [24] 1076 	movx	a,@dptr
      0060CB 45 F0            [12] 1077 	orl	a,b
      0060CD 70 0E            [24] 1078 	jnz	00106$
                                   1079 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      0060CF 90 08 2A         [24] 1080 	mov	dptr,#_control_pointer
      0060D2 74 80            [12] 1081 	mov	a,#_ConfigurationDescriptor
      0060D4 F0               [24] 1082 	movx	@dptr,a
      0060D5 74 C3            [12] 1083 	mov	a,#(_ConfigurationDescriptor >> 8)
      0060D7 A3               [24] 1084 	inc	dptr
      0060D8 F0               [24] 1085 	movx	@dptr,a
                                   1086 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      0060D9 90 00 54         [24] 1087 	mov	dptr,#0x0054
      0060DC 22               [24] 1088 	ret
      0060DD                       1089 00106$:
                                   1090 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      0060DD 90 08 2F         [24] 1091 	mov	dptr,#_descriptor_select_type_10000_269
      0060E0 E0               [24] 1092 	movx	a,@dptr
      0060E1 FF               [12] 1093 	mov	r7,a
      0060E2 BF 03 02         [24] 1094 	cjne	r7,#0x03,00238$
      0060E5 80 03            [24] 1095 	sjmp	00239$
      0060E7                       1096 00238$:
      0060E7 02 61 81         [24] 1097 	ljmp	00119$
      0060EA                       1098 00239$:
                                   1099 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      0060EA 90 08 2D         [24] 1100 	mov	dptr,#_descriptor_select_PARM_3
      0060ED E0               [24] 1101 	movx	a,@dptr
      0060EE FD               [12] 1102 	mov	r5,a
      0060EF A3               [24] 1103 	inc	dptr
      0060F0 E0               [24] 1104 	movx	a,@dptr
      0060F1 FE               [12] 1105 	mov	r6,a
      0060F2 90 08 2D         [24] 1106 	mov	dptr,#_descriptor_select_PARM_3
      0060F5 E0               [24] 1107 	movx	a,@dptr
      0060F6 F5 F0            [12] 1108 	mov	b,a
      0060F8 A3               [24] 1109 	inc	dptr
      0060F9 E0               [24] 1110 	movx	a,@dptr
      0060FA 45 F0            [12] 1111 	orl	a,b
      0060FC 60 0C            [24] 1112 	jz	00110$
      0060FE BD 09 05         [24] 1113 	cjne	r5,#0x09,00241$
      006101 BE 04 02         [24] 1114 	cjne	r6,#0x04,00241$
      006104 80 04            [24] 1115 	sjmp	00110$
      006106                       1116 00241$:
      006106 90 00 00         [24] 1117 	mov	dptr,#0x0000
      006109 22               [24] 1118 	ret
      00610A                       1119 00110$:
                                   1120 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      00610A 90 08 2C         [24] 1121 	mov	dptr,#_descriptor_select_PARM_2
      00610D E0               [24] 1122 	movx	a,@dptr
      00610E FE               [12] 1123 	mov  r6,a
      00610F 24 FC            [12] 1124 	add	a,#0xff - 0x03
      006111 40 6A            [24] 1125 	jc	00116$
                                   1126 ;	free result
      006113 EE               [12] 1127 	mov	a,r6
      006114 2E               [12] 1128 	add	a,r6
                                   1129 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      006115 90 61 19         [24] 1130 	mov	dptr,#00243$
      006118 73               [24] 1131 	jmp	@a+dptr
      006119                       1132 00243$:
      006119 80 06            [24] 1133 	sjmp	00112$
      00611B 80 1B            [24] 1134 	sjmp	00113$
      00611D 80 30            [24] 1135 	sjmp	00114$
      00611F 80 45            [24] 1136 	sjmp	00115$
      006121                       1137 00112$:
      006121 90 08 2A         [24] 1138 	mov	dptr,#_control_pointer
      006124 74 D4            [12] 1139 	mov	a,#_LanguageString
      006126 F0               [24] 1140 	movx	@dptr,a
      006127 74 C3            [12] 1141 	mov	a,#(_LanguageString >> 8)
      006129 A3               [24] 1142 	inc	dptr
      00612A F0               [24] 1143 	movx	@dptr,a
      00612B 90 C3 D4         [24] 1144 	mov	dptr,#_LanguageString
      00612E E4               [12] 1145 	clr	a
      00612F 93               [24] 1146 	movc	a,@a+dptr
      006130 FE               [12] 1147 	mov	r6,a
      006131 7D 00            [12] 1148 	mov	r5,#0x00
      006133 8E 82            [24] 1149 	mov	dpl, r6
      006135 8D 83            [24] 1150 	mov	dph, r5
      006137 22               [24] 1151 	ret
                                   1152 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      006138                       1153 00113$:
      006138 90 08 2A         [24] 1154 	mov	dptr,#_control_pointer
      00613B 74 D8            [12] 1155 	mov	a,#_ManufacturerString
      00613D F0               [24] 1156 	movx	@dptr,a
      00613E 74 C3            [12] 1157 	mov	a,#(_ManufacturerString >> 8)
      006140 A3               [24] 1158 	inc	dptr
      006141 F0               [24] 1159 	movx	@dptr,a
      006142 90 C3 D8         [24] 1160 	mov	dptr,#_ManufacturerString
      006145 E4               [12] 1161 	clr	a
      006146 93               [24] 1162 	movc	a,@a+dptr
      006147 FE               [12] 1163 	mov	r6,a
      006148 7D 00            [12] 1164 	mov	r5,#0x00
      00614A 8E 82            [24] 1165 	mov	dpl, r6
      00614C 8D 83            [24] 1166 	mov	dph, r5
      00614E 22               [24] 1167 	ret
                                   1168 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      00614F                       1169 00114$:
      00614F 90 08 2A         [24] 1170 	mov	dptr,#_control_pointer
      006152 74 E6            [12] 1171 	mov	a,#_ProductString
      006154 F0               [24] 1172 	movx	@dptr,a
      006155 74 C3            [12] 1173 	mov	a,#(_ProductString >> 8)
      006157 A3               [24] 1174 	inc	dptr
      006158 F0               [24] 1175 	movx	@dptr,a
      006159 90 C3 E6         [24] 1176 	mov	dptr,#_ProductString
      00615C E4               [12] 1177 	clr	a
      00615D 93               [24] 1178 	movc	a,@a+dptr
      00615E FE               [12] 1179 	mov	r6,a
      00615F 7D 00            [12] 1180 	mov	r5,#0x00
      006161 8E 82            [24] 1181 	mov	dpl, r6
      006163 8D 83            [24] 1182 	mov	dph, r5
      006165 22               [24] 1183 	ret
                                   1184 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      006166                       1185 00115$:
      006166 90 08 2A         [24] 1186 	mov	dptr,#_control_pointer
      006169 74 1E            [12] 1187 	mov	a,#_SerialNumberString
      00616B F0               [24] 1188 	movx	@dptr,a
      00616C 74 C4            [12] 1189 	mov	a,#(_SerialNumberString >> 8)
      00616E A3               [24] 1190 	inc	dptr
      00616F F0               [24] 1191 	movx	@dptr,a
      006170 90 C4 1E         [24] 1192 	mov	dptr,#_SerialNumberString
      006173 E4               [12] 1193 	clr	a
      006174 93               [24] 1194 	movc	a,@a+dptr
      006175 FE               [12] 1195 	mov	r6,a
      006176 7D 00            [12] 1196 	mov	r5,#0x00
      006178 8E 82            [24] 1197 	mov	dpl, r6
      00617A 8D 83            [24] 1198 	mov	dph, r5
      00617C 22               [24] 1199 	ret
                                   1200 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      00617D                       1201 00116$:
      00617D 90 00 00         [24] 1202 	mov	dptr,#0x0000
      006180 22               [24] 1203 	ret
                                   1204 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      006181                       1205 00119$:
                                   1206 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      006181 90 08 2C         [24] 1207 	mov	dptr,#_descriptor_select_PARM_2
      006184 E0               [24] 1208 	movx	a,@dptr
      006185 70 11            [24] 1209 	jnz	00120$
      006187 90 08 2D         [24] 1210 	mov	dptr,#_descriptor_select_PARM_3
      00618A E0               [24] 1211 	movx	a,@dptr
      00618B FD               [12] 1212 	mov	r5,a
      00618C A3               [24] 1213 	inc	dptr
      00618D E0               [24] 1214 	movx	a,@dptr
      00618E FE               [12] 1215 	mov	r6,a
      00618F C3               [12] 1216 	clr	c
      006190 ED               [12] 1217 	mov	a,r5
      006191 94 03            [12] 1218 	subb	a,#0x03
      006193 EE               [12] 1219 	mov	a,r6
      006194 94 00            [12] 1220 	subb	a,#0x00
      006196 40 04            [24] 1221 	jc	00121$
      006198                       1222 00120$:
      006198 90 00 00         [24] 1223 	mov	dptr,#0x0000
      00619B 22               [24] 1224 	ret
      00619C                       1225 00121$:
                                   1226 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      00619C BF 22 02         [24] 1227 	cjne	r7,#0x22,00246$
      00619F 80 03            [24] 1228 	sjmp	00127$
      0061A1                       1229 00246$:
      0061A1 BF 21 5D         [24] 1230 	cjne	r7,#0x21,00128$
      0061A4                       1231 00127$:
                                   1232 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      0061A4 ED               [12] 1233 	mov	a,r5
      0061A5 75 F0 04         [24] 1234 	mov	b,#0x04
      0061A8 A4               [48] 1235 	mul	ab
      0061A9 24 F7            [12] 1236 	add	a, #_interface_descriptors
      0061AB FE               [12] 1237 	mov	r6,a
      0061AC 74 BC            [12] 1238 	mov	a,#(_interface_descriptors >> 8)
      0061AE 35 F0            [12] 1239 	addc	a, b
      0061B0 FF               [12] 1240 	mov	r7,a
      0061B1 8E 82            [24] 1241 	mov	dpl,r6
      0061B3 8F 83            [24] 1242 	mov	dph,r7
      0061B5 A3               [24] 1243 	inc	dptr
      0061B6 A3               [24] 1244 	inc	dptr
      0061B7 E4               [12] 1245 	clr	a
      0061B8 93               [24] 1246 	movc	a,@a+dptr
      0061B9 FC               [12] 1247 	mov	r4,a
      0061BA A3               [24] 1248 	inc	dptr
      0061BB E4               [12] 1249 	clr	a
      0061BC 93               [24] 1250 	movc	a,@a+dptr
                                   1251 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      0061BD FD               [12] 1252 	mov	r5,a
      0061BE 4C               [12] 1253 	orl	a,r4
      0061BF 70 04            [24] 1254 	jnz	00124$
      0061C1 90 00 00         [24] 1255 	mov	dptr,#0x0000
      0061C4 22               [24] 1256 	ret
      0061C5                       1257 00124$:
                                   1258 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      0061C5 90 08 2F         [24] 1259 	mov	dptr,#_descriptor_select_type_10000_269
      0061C8 E0               [24] 1260 	movx	a,@dptr
      0061C9 FB               [12] 1261 	mov	r3,a
      0061CA BB 22 28         [24] 1262 	cjne	r3,#0x22,00126$
                                   1263 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      0061CD 8E 82            [24] 1264 	mov	dpl,r6
      0061CF 8F 83            [24] 1265 	mov	dph,r7
      0061D1 E4               [12] 1266 	clr	a
      0061D2 93               [24] 1267 	movc	a,@a+dptr
      0061D3 FE               [12] 1268 	mov	r6,a
      0061D4 A3               [24] 1269 	inc	dptr
      0061D5 E4               [12] 1270 	clr	a
      0061D6 93               [24] 1271 	movc	a,@a+dptr
      0061D7 FF               [12] 1272 	mov	r7,a
      0061D8 90 08 2A         [24] 1273 	mov	dptr,#_control_pointer
      0061DB EE               [12] 1274 	mov	a,r6
      0061DC F0               [24] 1275 	movx	@dptr,a
      0061DD EF               [12] 1276 	mov	a,r7
      0061DE A3               [24] 1277 	inc	dptr
      0061DF F0               [24] 1278 	movx	@dptr,a
                                   1279 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      0061E0 74 07            [12] 1280 	mov	a,#0x07
      0061E2 2C               [12] 1281 	add	a, r4
      0061E3 F5 82            [12] 1282 	mov	dpl,a
      0061E5 E4               [12] 1283 	clr	a
      0061E6 3D               [12] 1284 	addc	a, r5
      0061E7 F5 83            [12] 1285 	mov	dph,a
      0061E9 E4               [12] 1286 	clr	a
      0061EA 93               [24] 1287 	movc	a,@a+dptr
      0061EB FE               [12] 1288 	mov	r6,a
      0061EC A3               [24] 1289 	inc	dptr
      0061ED E4               [12] 1290 	clr	a
      0061EE 93               [24] 1291 	movc	a,@a+dptr
      0061EF FF               [12] 1292 	mov	r7,a
      0061F0 8E 82            [24] 1293 	mov	dpl, r6
      0061F2 8F 83            [24] 1294 	mov	dph, r7
      0061F4 22               [24] 1295 	ret
      0061F5                       1296 00126$:
                                   1297 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      0061F5 90 08 2A         [24] 1298 	mov	dptr,#_control_pointer
      0061F8 EC               [12] 1299 	mov	a,r4
      0061F9 F0               [24] 1300 	movx	@dptr,a
      0061FA ED               [12] 1301 	mov	a,r5
      0061FB A3               [24] 1302 	inc	dptr
      0061FC F0               [24] 1303 	movx	@dptr,a
                                   1304 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      0061FD 90 00 09         [24] 1305 	mov	dptr,#0x0009
      006200 22               [24] 1306 	ret
      006201                       1307 00128$:
                                   1308 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      006201 90 00 00         [24] 1309 	mov	dptr,#0x0000
                                   1310 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      006204 22               [24] 1311 	ret
                                   1312 ;------------------------------------------------------------
                                   1313 ;Allocation info for local variables in function 'control_setup'
                                   1314 ;------------------------------------------------------------
                                   1315 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1316 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1317 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1318 ;type          Allocated with name '_control_setup_type_10000_287'
                                   1319 ;value         Allocated with name '_control_setup_value_10000_287'
                                   1320 ;index         Allocated with name '_control_setup_index_10000_287'
                                   1321 ;length        Allocated with name '_control_setup_length_10000_287'
                                   1322 ;endpoint      Allocated with name '_control_setup_endpoint_10000_287'
                                   1323 ;i             Allocated with name '_control_setup_i_10000_287'
                                   1324 ;offset        Allocated with name '_control_setup_offset_10000_287'
                                   1325 ;report_id     Allocated with name '_control_setup_report_id_10000_287'
                                   1326 ;------------------------------------------------------------
                                   1327 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1328 ;	-----------------------------------------
                                   1329 ;	 function control_setup
                                   1330 ;	-----------------------------------------
      006205                       1331 _control_setup:
                                   1332 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      006205 90 10 00         [24] 1333 	mov	dptr,#0x1000
      006208 E0               [24] 1334 	movx	a,@dptr
      006209 FF               [12] 1335 	mov	r7,a
                                   1336 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      00620A A3               [24] 1337 	inc	dptr
      00620B A3               [24] 1338 	inc	dptr
      00620C E0               [24] 1339 	movx	a,@dptr
      00620D FE               [12] 1340 	mov	r6,a
      00620E A3               [24] 1341 	inc	dptr
      00620F E0               [24] 1342 	movx	a,@dptr
      006210 FC               [12] 1343 	mov	r4,a
      006211 7D 00            [12] 1344 	mov	r5,#0x00
      006213 8E 03            [24] 1345 	mov	ar3,r6
      006215 7E 00            [12] 1346 	mov	r6,#0x00
      006217 ED               [12] 1347 	mov	a,r5
      006218 4B               [12] 1348 	orl	a,r3
      006219 FD               [12] 1349 	mov	r5,a
      00621A EC               [12] 1350 	mov	a,r4
      00621B 4E               [12] 1351 	orl	a,r6
      00621C FE               [12] 1352 	mov	r6,a
                                   1353 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      00621D A3               [24] 1354 	inc	dptr
      00621E E0               [24] 1355 	movx	a,@dptr
      00621F FC               [12] 1356 	mov	r4,a
      006220 A3               [24] 1357 	inc	dptr
      006221 E0               [24] 1358 	movx	a,@dptr
      006222 FA               [12] 1359 	mov	r2,a
      006223 7B 00            [12] 1360 	mov	r3,#0x00
      006225 8C 01            [24] 1361 	mov	ar1,r4
      006227 7C 00            [12] 1362 	mov	r4,#0x00
      006229 EB               [12] 1363 	mov	a,r3
      00622A 49               [12] 1364 	orl	a,r1
      00622B FB               [12] 1365 	mov	r3,a
      00622C EA               [12] 1366 	mov	a,r2
      00622D 4C               [12] 1367 	orl	a,r4
      00622E FC               [12] 1368 	mov	r4,a
                                   1369 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      00622F C3               [12] 1370 	clr	c
      006230 EB               [12] 1371 	mov	a,r3
      006231 94 03            [12] 1372 	subb	a,#0x03
      006233 EC               [12] 1373 	mov	a,r4
      006234 94 00            [12] 1374 	subb	a,#0x00
      006236 92 16            [24] 1375 	mov	_control_setup_valid_interface_10000_287,c
                                   1376 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      006238 EB               [12] 1377 	mov	a,r3
      006239 4C               [12] 1378 	orl	a,r4
      00623A B4 01 00         [24] 1379 	cjne	a,#0x01,01201$
      00623D                       1380 01201$:
      00623D 92 17            [24] 1381 	mov	_control_setup_zero_index_10000_287,c
                                   1382 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      00623F ED               [12] 1383 	mov	a,r5
      006240 4E               [12] 1384 	orl	a,r6
      006241 B4 01 00         [24] 1385 	cjne	a,#0x01,01202$
      006244                       1386 01202$:
                                   1387 ;	assignBit
      006244 92 1A            [24] 1388 	mov  _control_setup_sloc0_1_0,c
      006246 92 18            [24] 1389 	mov	_control_setup_zero_value_10000_287,c
                                   1390 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      006248 90 08 32         [24] 1391 	mov	dptr,#_control_setup_offset_10000_287
      00624B E4               [12] 1392 	clr	a
      00624C F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      00624D 90 07 D5         [24] 1395 	mov	dptr,#_raw_state
      006250 E0               [24] 1396 	movx	a,@dptr
      006251 FA               [12] 1397 	mov	r2,a
      006252 BA 01 05         [24] 1398 	cjne	r2,#0x01,00102$
      006255 90 07 D5         [24] 1399 	mov	dptr,#_raw_state
      006258 E4               [12] 1400 	clr	a
      006259 F0               [24] 1401 	movx	@dptr,a
      00625A                       1402 00102$:
                                   1403 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      00625A C0 07            [24] 1404 	push	ar7
      00625C 90 08 27         [24] 1405 	mov	dptr,#_output_kind
      00625F E4               [12] 1406 	clr	a
      006260 F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      006261 90 08 26         [24] 1409 	mov	dptr,#_control_phase
      006264 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      006265 90 08 29         [24] 1412 	mov	dptr,#_control_zlp
      006268 F0               [24] 1413 	movx	@dptr,a
                                   1414 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      006269 90 10 01         [24] 1415 	mov	dptr,#0x1001
      00626C E0               [24] 1416 	movx	a,@dptr
      00626D 90 07 C7         [24] 1417 	mov	dptr,#_D0SetupReqCode
      006270 F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      006271 90 10 06         [24] 1420 	mov	dptr,#0x1006
      006274 E0               [24] 1421 	movx	a,@dptr
      006275 FA               [12] 1422 	mov	r2,a
      006276 A3               [24] 1423 	inc	dptr
      006277 E0               [24] 1424 	movx	a,@dptr
      006278 F9               [12] 1425 	mov	r1,a
      006279 78 00            [12] 1426 	mov	r0,#0x00
      00627B 7F 00            [12] 1427 	mov	r7,#0x00
      00627D 90 07 C8         [24] 1428 	mov	dptr,#_D0SetupLen
      006280 E8               [12] 1429 	mov	a,r0
      006281 4A               [12] 1430 	orl	a,r2
      006282 F0               [24] 1431 	movx	@dptr,a
      006283 E9               [12] 1432 	mov	a,r1
      006284 4F               [12] 1433 	orl	a,r7
      006285 A3               [24] 1434 	inc	dptr
      006286 F0               [24] 1435 	movx	@dptr,a
                                   1436 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      006287 90 07 C8         [24] 1437 	mov	dptr,#_D0SetupLen
      00628A E0               [24] 1438 	movx	a,@dptr
      00628B FA               [12] 1439 	mov	r2,a
      00628C A3               [24] 1440 	inc	dptr
      00628D E0               [24] 1441 	movx	a,@dptr
      00628E 4A               [12] 1442 	orl	a,r2
      00628F B4 01 00         [24] 1443 	cjne	a,#0x01,01205$
      006292                       1444 01205$:
      006292 92 19            [24] 1445 	mov	_control_setup_zero_length_10000_287,c
                                   1446 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006294 90 22 00         [24] 1447 	mov	dptr,#0x2200
      006297 74 C2            [12] 1448 	mov	a,#0xc2
      006299 F0               [24] 1449 	movx	@dptr,a
                                   1450 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      00629A 90 22 08         [24] 1451 	mov	dptr,#0x2208
      00629D E4               [12] 1452 	clr	a
      00629E F0               [24] 1453 	movx	@dptr,a
                                   1454 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      00629F 90 07 C7         [24] 1455 	mov	dptr,#_D0SetupReqCode
      0062A2 E0               [24] 1456 	movx	a,@dptr
      0062A3 F5 16            [12] 1457 	mov	_control_setup_sloc1_1_0,a
      0062A5 C3               [12] 1458 	clr	c
      0062A6 74 0B            [12] 1459 	mov	a,#0x0b
      0062A8 95 16            [12] 1460 	subb	a,_control_setup_sloc1_1_0
      0062AA D0 07            [24] 1461 	pop	ar7
      0062AC 50 03            [24] 1462 	jnc	01206$
      0062AE 02 5F EC         [24] 1463 	ljmp	_control_stall
      0062B1                       1464 01206$:
                                   1465 ;	free result
      0062B1 E5 16            [12] 1466 	mov	a,_control_setup_sloc1_1_0
      0062B3 F5 F0            [12] 1467 	mov	b,a
      0062B5 24 0B            [12] 1468 	add	a,#(01207$-3-.)
      0062B7 83               [24] 1469 	movc	a,@a+pc
      0062B8 F5 82            [12] 1470 	mov	dpl,a
      0062BA E5 F0            [12] 1471 	mov	a,b
      0062BC 24 10            [12] 1472 	add	a,#(01208$-3-.)
      0062BE 83               [24] 1473 	movc	a,@a+pc
      0062BF F5 83            [12] 1474 	mov	dph,a
      0062C1 E4               [12] 1475 	clr	a
      0062C2 73               [24] 1476 	jmp	@a+dptr
      0062C3                       1477 01207$:
      0062C3 6B                    1478 	.db	00188$
      0062C4 11                    1479 	.db	00205$
      0062C5 54                    1480 	.db	00282$
      0062C6 11                    1481 	.db	00205$
      0062C7 98                    1482 	.db	00290$
      0062C8 95                    1483 	.db	00116$
      0062C9 DB                    1484 	.db	00103$
      0062CA 98                    1485 	.db	00290$
      0062CB 9A                    1486 	.db	00150$
      0062CC BE                    1487 	.db	00123$
      0062CD CA                    1488 	.db	00157$
      0062CE 1D                    1489 	.db	00173$
      0062CF                       1490 01208$:
      0062CF 65                    1491 	.db	00188$>>8
      0062D0 66                    1492 	.db	00205$>>8
      0062D1 69                    1493 	.db	00282$>>8
      0062D2 66                    1494 	.db	00205$>>8
      0062D3 69                    1495 	.db	00290$>>8
      0062D4 63                    1496 	.db	00116$>>8
      0062D5 62                    1497 	.db	00103$>>8
      0062D6 69                    1498 	.db	00290$>>8
      0062D7 64                    1499 	.db	00150$>>8
      0062D8 63                    1500 	.db	00123$>>8
      0062D9 64                    1501 	.db	00157$>>8
      0062DA 65                    1502 	.db	00173$>>8
                                   1503 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      0062DB                       1504 00103$:
                                   1505 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      0062DB BF 80 02         [24] 1506 	cjne	r7,#0x80,01209$
      0062DE 80 08            [24] 1507 	sjmp	00112$
      0062E0                       1508 01209$:
      0062E0 BF 81 02         [24] 1509 	cjne	r7,#0x81,01210$
      0062E3 80 03            [24] 1510 	sjmp	01211$
      0062E5                       1511 01210$:
      0062E5 02 5F EC         [24] 1512 	ljmp	_control_stall
      0062E8                       1513 01211$:
      0062E8                       1514 00112$:
                                   1515 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      0062E8 8E 01            [24] 1516 	mov	ar1,r6
      0062EA B9 21 02         [24] 1517 	cjne	r1,#0x21,01212$
      0062ED 80 09            [24] 1518 	sjmp	00301$
      0062EF                       1519 01212$:
      0062EF B9 22 02         [24] 1520 	cjne	r1,#0x22,01213$
      0062F2 80 04            [24] 1521 	sjmp	00301$
      0062F4                       1522 01213$:
                                   1523 ;	assignBit
      0062F4 C2 1B            [12] 1524 	clr	_control_setup_sloc2_1_0
      0062F6 80 02            [24] 1525 	sjmp	00302$
      0062F8                       1526 00301$:
                                   1527 ;	assignBit
      0062F8 D2 1B            [12] 1528 	setb	_control_setup_sloc2_1_0
      0062FA                       1529 00302$:
      0062FA E4               [12] 1530 	clr	a
      0062FB BF 81 01         [24] 1531 	cjne	r7,#0x81,01214$
      0062FE 04               [12] 1532 	inc	a
      0062FF                       1533 01214$:
      0062FF FA               [12] 1534 	mov	r2,a
      006300 A2 1B            [12] 1535 	mov	c,_control_setup_sloc2_1_0
      006302 E4               [12] 1536 	clr	a
      006303 33               [12] 1537 	rlc	a
      006304 B5 02 02         [24] 1538 	cjne	a,ar2,01216$
      006307 80 03            [24] 1539 	sjmp	00105$
      006309                       1540 01216$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      006309 02 5F EC         [24] 1542 	ljmp	_control_stall
      00630C                       1543 00105$:
                                   1544 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      00630C 8E 02            [24] 1545 	mov	ar2,r6
      00630E 90 08 2C         [24] 1546 	mov	dptr,#_descriptor_select_PARM_2
      006311 ED               [12] 1547 	mov	a,r5
      006312 F0               [24] 1548 	movx	@dptr,a
      006313 90 08 2D         [24] 1549 	mov	dptr,#_descriptor_select_PARM_3
      006316 EB               [12] 1550 	mov	a,r3
      006317 F0               [24] 1551 	movx	@dptr,a
      006318 EC               [12] 1552 	mov	a,r4
      006319 A3               [24] 1553 	inc	dptr
      00631A F0               [24] 1554 	movx	@dptr,a
      00631B 8A 82            [24] 1555 	mov	dpl, r2
      00631D 12 60 8A         [24] 1556 	lcall	_descriptor_select
      006320 85 82 17         [24] 1557 	mov	_control_setup_sloc3_1_0,dpl
      006323 85 83 18         [24] 1558 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1559 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      006326 E5 17            [12] 1560 	mov	a,_control_setup_sloc3_1_0
      006328 45 18            [12] 1561 	orl	a,(_control_setup_sloc3_1_0 + 1)
      00632A 70 03            [24] 1562 	jnz	00107$
      00632C 02 5F EC         [24] 1563 	ljmp	_control_stall
      00632F                       1564 00107$:
                                   1565 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      00632F 90 07 C8         [24] 1566 	mov	dptr,#_D0SetupLen
      006332 E0               [24] 1567 	movx	a,@dptr
      006333 F8               [12] 1568 	mov	r0,a
      006334 A3               [24] 1569 	inc	dptr
      006335 E0               [24] 1570 	movx	a,@dptr
      006336 FA               [12] 1571 	mov	r2,a
      006337 C3               [12] 1572 	clr	c
      006338 E5 17            [12] 1573 	mov	a,_control_setup_sloc3_1_0
      00633A 98               [12] 1574 	subb	a,r0
      00633B E5 18            [12] 1575 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00633D 9A               [12] 1576 	subb	a,r2
      00633E 50 06            [24] 1577 	jnc	00303$
      006340 E5 17            [12] 1578 	mov	a,_control_setup_sloc3_1_0
      006342 54 3F            [12] 1579 	anl	a,#0x3f
      006344 60 04            [24] 1580 	jz	00304$
      006346                       1581 00303$:
                                   1582 ;	assignBit
      006346 C2 1B            [12] 1583 	clr	_control_setup_sloc2_1_0
      006348 80 02            [24] 1584 	sjmp	00305$
      00634A                       1585 00304$:
                                   1586 ;	assignBit
      00634A D2 1B            [12] 1587 	setb	_control_setup_sloc2_1_0
      00634C                       1588 00305$:
      00634C 90 08 29         [24] 1589 	mov	dptr,#_control_zlp
      00634F A2 1B            [12] 1590 	mov	c,_control_setup_sloc2_1_0
      006351 E4               [12] 1591 	clr	a
      006352 33               [12] 1592 	rlc	a
      006353 F0               [24] 1593 	movx	@dptr,a
                                   1594 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      006354 90 07 C8         [24] 1595 	mov	dptr,#_D0SetupLen
      006357 E0               [24] 1596 	movx	a,@dptr
      006358 F9               [12] 1597 	mov	r1,a
      006359 A3               [24] 1598 	inc	dptr
      00635A E0               [24] 1599 	movx	a,@dptr
      00635B FA               [12] 1600 	mov	r2,a
      00635C C3               [12] 1601 	clr	c
      00635D E5 17            [12] 1602 	mov	a,_control_setup_sloc3_1_0
      00635F 99               [12] 1603 	subb	a,r1
      006360 E5 18            [12] 1604 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006362 9A               [12] 1605 	subb	a,r2
      006363 50 0A            [24] 1606 	jnc	00109$
                                   1607 ;	free result
      006365 90 07 C8         [24] 1608 	mov	dptr,#_D0SetupLen
      006368 E5 17            [12] 1609 	mov	a,_control_setup_sloc3_1_0
      00636A F0               [24] 1610 	movx	@dptr,a
      00636B E5 18            [12] 1611 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00636D A3               [24] 1612 	inc	dptr
      00636E F0               [24] 1613 	movx	@dptr,a
      00636F                       1614 00109$:
                                   1615 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      00636F 90 07 C8         [24] 1616 	mov	dptr,#_D0SetupLen
      006372 E0               [24] 1617 	movx	a,@dptr
      006373 F9               [12] 1618 	mov	r1,a
      006374 A3               [24] 1619 	inc	dptr
      006375 E0               [24] 1620 	movx	a,@dptr
      006376 49               [12] 1621 	orl	a,r1
      006377 60 04            [24] 1622 	jz	00306$
      006379 7A 01            [12] 1623 	mov	r2,#0x01
      00637B 80 02            [24] 1624 	sjmp	00307$
      00637D                       1625 00306$:
      00637D 7A 02            [12] 1626 	mov	r2,#0x02
      00637F                       1627 00307$:
      00637F 90 08 26         [24] 1628 	mov	dptr,#_control_phase
      006382 EA               [12] 1629 	mov	a,r2
      006383 F0               [24] 1630 	movx	@dptr,a
                                   1631 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      006384 90 07 C8         [24] 1632 	mov	dptr,#_D0SetupLen
      006387 E0               [24] 1633 	movx	a,@dptr
      006388 F9               [12] 1634 	mov	r1,a
      006389 A3               [24] 1635 	inc	dptr
      00638A E0               [24] 1636 	movx	a,@dptr
      00638B 49               [12] 1637 	orl	a,r1
      00638C 60 03            [24] 1638 	jz	00111$
                                   1639 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      00638E 02 60 0E         [24] 1640 	ljmp	_control_next
      006391                       1641 00111$:
      006391 22               [24] 1642 	ret
                                   1643 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      006392 02 5F EC         [24] 1644 	ljmp	_control_stall
                                   1645 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      006395                       1646 00116$:
                                   1647 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      006395 EF               [12] 1648 	mov	a,r7
      006396 70 23            [24] 1649 	jnz	00118$
      006398 30 17 20         [24] 1650 	jnb	_control_setup_zero_index_10000_287,00118$
      00639B 30 19 1D         [24] 1651 	jnb	_control_setup_zero_length_10000_287,00118$
      00639E 8D 01            [24] 1652 	mov	ar1,r5
      0063A0 8E 02            [24] 1653 	mov	ar2,r6
      0063A2 C3               [12] 1654 	clr	c
      0063A3 74 7F            [12] 1655 	mov	a,#0x7f
      0063A5 99               [12] 1656 	subb	a,r1
      0063A6 E4               [12] 1657 	clr	a
      0063A7 9A               [12] 1658 	subb	a,r2
      0063A8 40 11            [24] 1659 	jc	00118$
                                   1660 ;	free result
                                   1661 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      0063AA 90 07 C8         [24] 1662 	mov	dptr,#_D0SetupLen
      0063AD ED               [12] 1663 	mov	a,r5
      0063AE F0               [24] 1664 	movx	@dptr,a
      0063AF EE               [12] 1665 	mov	a,r6
      0063B0 A3               [24] 1666 	inc	dptr
      0063B1 F0               [24] 1667 	movx	@dptr,a
                                   1668 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      0063B2 90 08 26         [24] 1669 	mov	dptr,#_control_phase
      0063B5 74 03            [12] 1670 	mov	a,#0x03
      0063B7 F0               [24] 1671 	movx	@dptr,a
      0063B8 02 69 9B         [24] 1672 	ljmp	00291$
      0063BB                       1673 00118$:
                                   1674 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      0063BB 02 5F EC         [24] 1675 	ljmp	_control_stall
                                   1676 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      0063BE                       1677 00123$:
                                   1678 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      0063BE EF               [12] 1679 	mov	a,r7
      0063BF 70 3C            [24] 1680 	jnz	00145$
      0063C1 30 17 39         [24] 1681 	jnb	_control_setup_zero_index_10000_287,00145$
      0063C4 30 19 36         [24] 1682 	jnb	_control_setup_zero_length_10000_287,00145$
      0063C7 8D 01            [24] 1683 	mov	ar1,r5
      0063C9 8E 02            [24] 1684 	mov	ar2,r6
      0063CB C3               [12] 1685 	clr	c
      0063CC 74 01            [12] 1686 	mov	a,#0x01
      0063CE 99               [12] 1687 	subb	a,r1
      0063CF E4               [12] 1688 	clr	a
      0063D0 9A               [12] 1689 	subb	a,r2
      0063D1 40 2A            [24] 1690 	jc	00145$
                                   1691 ;	free result
                                   1692 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      0063D3 C0 06            [24] 1693 	push	ar6
      0063D5 C0 05            [24] 1694 	push	ar5
      0063D7 12 5F 95         [24] 1695 	lcall	_endpoints_reset
      0063DA D0 05            [24] 1696 	pop	ar5
      0063DC D0 06            [24] 1697 	pop	ar6
                                   1698 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      0063DE 90 07 CD         [24] 1699 	mov	dptr,#_D0UsbConfig
      0063E1 ED               [12] 1700 	mov	a,r5
      0063E2 F0               [24] 1701 	movx	@dptr,a
                                   1702 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      0063E3 A2 1A            [12] 1703 	mov	c,_control_setup_sloc0_1_0
      0063E5 B3               [12] 1704 	cpl	c
      0063E6 92 1B            [24] 1705 	mov	_control_setup_sloc2_1_0,c
      0063E8 90 07 CE         [24] 1706 	mov	dptr,#_USB_EnumStatus
      0063EB E4               [12] 1707 	clr	a
      0063EC 33               [12] 1708 	rlc	a
      0063ED F0               [24] 1709 	movx	@dptr,a
                                   1710 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      0063EE 90 07 F7         [24] 1711 	mov	dptr,#_keyboard_reset
      0063F1 74 01            [12] 1712 	mov	a,#0x01
      0063F3 F0               [24] 1713 	movx	@dptr,a
                                   1714 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      0063F4 90 08 26         [24] 1715 	mov	dptr,#_control_phase
      0063F7 74 03            [12] 1716 	mov	a,#0x03
      0063F9 F0               [24] 1717 	movx	@dptr,a
      0063FA 02 69 9B         [24] 1718 	ljmp	00291$
      0063FD                       1719 00145$:
                                   1720 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      0063FD BF 21 02         [24] 1721 	cjne	r7,#0x21,01231$
      006400 80 03            [24] 1722 	sjmp	01232$
      006402                       1723 01231$:
      006402 02 5F EC         [24] 1724 	ljmp	_control_stall
      006405                       1725 01232$:
      006405 90 07 CD         [24] 1726 	mov	dptr,#_D0UsbConfig
      006408 E0               [24] 1727 	movx	a,@dptr
      006409 70 03            [24] 1728 	jnz	01233$
      00640B 02 5F EC         [24] 1729 	ljmp	_control_stall
      00640E                       1730 01233$:
                                   1731 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      00640E BB 01 2D         [24] 1732 	cjne	r3,#0x01,00135$
      006411 BC 00 2A         [24] 1733 	cjne	r4,#0x00,00135$
      006414 8D 01            [24] 1734 	mov	ar1,r5
      006416 8E 02            [24] 1735 	mov	ar2,r6
      006418 B9 00 23         [24] 1736 	cjne	r1,#0x00,00135$
      00641B BA 02 20         [24] 1737 	cjne	r2,#0x02,00135$
      00641E 90 07 C8         [24] 1738 	mov	dptr,#_D0SetupLen
      006421 E0               [24] 1739 	movx	a,@dptr
      006422 F9               [12] 1740 	mov	r1,a
      006423 A3               [24] 1741 	inc	dptr
      006424 E0               [24] 1742 	movx	a,@dptr
      006425 FA               [12] 1743 	mov	r2,a
      006426 B9 20 15         [24] 1744 	cjne	r1,#0x20,00135$
      006429 BA 00 12         [24] 1745 	cjne	r2,#0x00,00135$
      00642C 90 07 D5         [24] 1746 	mov	dptr,#_raw_state
      00642F E0               [24] 1747 	movx	a,@dptr
      006430 70 0C            [24] 1748 	jnz	00135$
                                   1749 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      006432 90 07 D5         [24] 1750 	mov	dptr,#_raw_state
      006435 74 01            [12] 1751 	mov	a,#0x01
      006437 F0               [24] 1752 	movx	@dptr,a
                                   1753 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      006438 90 08 27         [24] 1754 	mov	dptr,#_output_kind
      00643B F0               [24] 1755 	movx	@dptr,a
      00643C 80 52            [24] 1756 	sjmp	00136$
      00643E                       1757 00135$:
                                   1758 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      00643E EB               [12] 1759 	mov	a,r3
      00643F 4C               [12] 1760 	orl	a,r4
      006440 70 20            [24] 1761 	jnz	00130$
      006442 8D 01            [24] 1762 	mov	ar1,r5
      006444 8E 02            [24] 1763 	mov	ar2,r6
      006446 B9 00 19         [24] 1764 	cjne	r1,#0x00,00130$
      006449 BA 02 16         [24] 1765 	cjne	r2,#0x02,00130$
      00644C 90 07 C8         [24] 1766 	mov	dptr,#_D0SetupLen
      00644F E0               [24] 1767 	movx	a,@dptr
      006450 F9               [12] 1768 	mov	r1,a
      006451 A3               [24] 1769 	inc	dptr
      006452 E0               [24] 1770 	movx	a,@dptr
      006453 FA               [12] 1771 	mov	r2,a
      006454 B9 01 0B         [24] 1772 	cjne	r1,#0x01,00130$
      006457 BA 00 08         [24] 1773 	cjne	r2,#0x00,00130$
                                   1774 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      00645A 90 08 27         [24] 1775 	mov	dptr,#_output_kind
      00645D 74 02            [12] 1776 	mov	a,#0x02
      00645F F0               [24] 1777 	movx	@dptr,a
      006460 80 2E            [24] 1778 	sjmp	00136$
      006462                       1779 00130$:
                                   1780 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      006462 BB 02 28         [24] 1781 	cjne	r3,#0x02,00125$
      006465 BC 00 25         [24] 1782 	cjne	r4,#0x00,00125$
      006468 8D 01            [24] 1783 	mov	ar1,r5
      00646A 8E 02            [24] 1784 	mov	ar2,r6
      00646C B9 06 1E         [24] 1785 	cjne	r1,#0x06,00125$
      00646F BA 02 1B         [24] 1786 	cjne	r2,#0x02,00125$
      006472 90 07 C8         [24] 1787 	mov	dptr,#_D0SetupLen
      006475 E0               [24] 1788 	movx	a,@dptr
      006476 F9               [12] 1789 	mov	r1,a
      006477 A3               [24] 1790 	inc	dptr
      006478 E0               [24] 1791 	movx	a,@dptr
      006479 FA               [12] 1792 	mov	r2,a
      00647A B9 02 10         [24] 1793 	cjne	r1,#0x02,00125$
      00647D BA 00 0D         [24] 1794 	cjne	r2,#0x00,00125$
                                   1795 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      006480 90 08 27         [24] 1796 	mov	dptr,#_output_kind
      006483 74 03            [12] 1797 	mov	a,#0x03
      006485 F0               [24] 1798 	movx	@dptr,a
                                   1799 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      006486 90 08 28         [24] 1800 	mov	dptr,#_output_report_id
      006489 23               [12] 1801 	rl	a
      00648A F0               [24] 1802 	movx	@dptr,a
      00648B 80 03            [24] 1803 	sjmp	00136$
      00648D                       1804 00125$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      00648D 02 5F EC         [24] 1806 	ljmp	_control_stall
      006490                       1807 00136$:
                                   1808 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      006490 90 08 26         [24] 1809 	mov	dptr,#_control_phase
      006493 74 04            [12] 1810 	mov	a,#0x04
      006495 F0               [24] 1811 	movx	@dptr,a
                                   1812 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      006496 22               [24] 1813 	ret
                                   1814 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      006497 02 5F EC         [24] 1815 	ljmp	_control_stall
                                   1816 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      00649A                       1817 00150$:
                                   1818 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      00649A BF 80 2A         [24] 1819 	cjne	r7,#0x80,00152$
      00649D 30 17 27         [24] 1820 	jnb	_control_setup_zero_index_10000_287,00152$
      0064A0 30 18 24         [24] 1821 	jnb	_control_setup_zero_value_10000_287,00152$
      0064A3 90 07 C8         [24] 1822 	mov	dptr,#_D0SetupLen
      0064A6 E0               [24] 1823 	movx	a,@dptr
      0064A7 F9               [12] 1824 	mov	r1,a
      0064A8 A3               [24] 1825 	inc	dptr
      0064A9 E0               [24] 1826 	movx	a,@dptr
      0064AA FA               [12] 1827 	mov	r2,a
      0064AB B9 01 19         [24] 1828 	cjne	r1,#0x01,00152$
      0064AE BA 00 16         [24] 1829 	cjne	r2,#0x00,00152$
                                   1830 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      0064B1 90 07 CD         [24] 1831 	mov	dptr,#_D0UsbConfig
      0064B4 E0               [24] 1832 	movx	a,@dptr
      0064B5 90 10 00         [24] 1833 	mov	dptr,#0x1000
      0064B8 F0               [24] 1834 	movx	@dptr,a
                                   1835 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      0064B9 90 22 08         [24] 1836 	mov	dptr,#0x2208
      0064BC 74 01            [12] 1837 	mov	a,#0x01
      0064BE F0               [24] 1838 	movx	@dptr,a
                                   1839 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      0064BF 90 08 26         [24] 1840 	mov	dptr,#_control_phase
      0064C2 04               [12] 1841 	inc	a
      0064C3 F0               [24] 1842 	movx	@dptr,a
      0064C4 02 69 9B         [24] 1843 	ljmp	00291$
      0064C7                       1844 00152$:
                                   1845 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      0064C7 02 5F EC         [24] 1846 	ljmp	_control_stall
                                   1847 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      0064CA                       1848 00157$:
                                   1849 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      0064CA BF 81 2C         [24] 1850 	cjne	r7,#0x81,00167$
      0064CD 30 16 29         [24] 1851 	jnb	_control_setup_valid_interface_10000_287,00167$
      0064D0 30 18 26         [24] 1852 	jnb	_control_setup_zero_value_10000_287,00167$
      0064D3 90 07 C8         [24] 1853 	mov	dptr,#_D0SetupLen
      0064D6 E0               [24] 1854 	movx	a,@dptr
      0064D7 F9               [12] 1855 	mov	r1,a
      0064D8 A3               [24] 1856 	inc	dptr
      0064D9 E0               [24] 1857 	movx	a,@dptr
      0064DA FA               [12] 1858 	mov	r2,a
      0064DB B9 01 1B         [24] 1859 	cjne	r1,#0x01,00167$
      0064DE BA 00 18         [24] 1860 	cjne	r2,#0x00,00167$
      0064E1 90 07 CD         [24] 1861 	mov	dptr,#_D0UsbConfig
      0064E4 E0               [24] 1862 	movx	a,@dptr
      0064E5 60 12            [24] 1863 	jz	00167$
                                   1864 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      0064E7 90 10 00         [24] 1865 	mov	dptr,#0x1000
      0064EA E4               [12] 1866 	clr	a
      0064EB F0               [24] 1867 	movx	@dptr,a
                                   1868 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      0064EC 90 22 08         [24] 1869 	mov	dptr,#0x2208
      0064EF 04               [12] 1870 	inc	a
      0064F0 F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      0064F1 90 08 26         [24] 1873 	mov	dptr,#_control_phase
      0064F4 04               [12] 1874 	inc	a
      0064F5 F0               [24] 1875 	movx	@dptr,a
      0064F6 02 69 9B         [24] 1876 	ljmp	00291$
      0064F9                       1877 00167$:
                                   1878 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      0064F9 30 16 1E         [24] 1879 	jnb	_control_setup_valid_interface_10000_287,00161$
      0064FC 90 07 CD         [24] 1880 	mov	dptr,#_D0UsbConfig
      0064FF E0               [24] 1881 	movx	a,@dptr
      006500 60 18            [24] 1882 	jz	00161$
      006502 BF 21 15         [24] 1883 	cjne	r7,#0x21,00161$
      006505 30 19 12         [24] 1884 	jnb	_control_setup_zero_length_10000_287,00161$
                                   1885 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006508 EB               [12] 1886 	mov	a,r3
      006509 4C               [12] 1887 	orl	a,r4
      00650A 70 05            [24] 1888 	jnz	00159$
      00650C 90 06 A5         [24] 1889 	mov	dptr,#_keyboard_idle
      00650F EE               [12] 1890 	mov	a,r6
      006510 F0               [24] 1891 	movx	@dptr,a
      006511                       1892 00159$:
                                   1893 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      006511 90 08 26         [24] 1894 	mov	dptr,#_control_phase
      006514 74 03            [12] 1895 	mov	a,#0x03
      006516 F0               [24] 1896 	movx	@dptr,a
      006517 02 69 9B         [24] 1897 	ljmp	00291$
      00651A                       1898 00161$:
                                   1899 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      00651A 02 5F EC         [24] 1900 	ljmp	_control_stall
                                   1901 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      00651D                       1902 00173$:
                                   1903 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      00651D BF 01 18         [24] 1904 	cjne	r7,#0x01,00182$
      006520 30 16 15         [24] 1905 	jnb	_control_setup_valid_interface_10000_287,00182$
      006523 30 18 12         [24] 1906 	jnb	_control_setup_zero_value_10000_287,00182$
      006526 30 19 0F         [24] 1907 	jnb	_control_setup_zero_length_10000_287,00182$
      006529 90 07 CD         [24] 1908 	mov	dptr,#_D0UsbConfig
      00652C E0               [24] 1909 	movx	a,@dptr
      00652D 60 09            [24] 1910 	jz	00182$
                                   1911 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      00652F 90 08 26         [24] 1912 	mov	dptr,#_control_phase
      006532 74 03            [12] 1913 	mov	a,#0x03
      006534 F0               [24] 1914 	movx	@dptr,a
      006535 02 69 9B         [24] 1915 	ljmp	00291$
      006538                       1916 00182$:
                                   1917 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006538 EB               [12] 1918 	mov	a,r3
      006539 4C               [12] 1919 	orl	a,r4
      00653A 70 2C            [24] 1920 	jnz	00175$
      00653C 90 07 CD         [24] 1921 	mov	dptr,#_D0UsbConfig
      00653F E0               [24] 1922 	movx	a,@dptr
      006540 60 26            [24] 1923 	jz	00175$
      006542 BF 21 23         [24] 1924 	cjne	r7,#0x21,00175$
      006545 30 19 20         [24] 1925 	jnb	_control_setup_zero_length_10000_287,00175$
      006548 8D 01            [24] 1926 	mov	ar1,r5
      00654A 8E 02            [24] 1927 	mov	ar2,r6
      00654C C3               [12] 1928 	clr	c
      00654D 74 01            [12] 1929 	mov	a,#0x01
      00654F 99               [12] 1930 	subb	a,r1
      006550 E4               [12] 1931 	clr	a
      006551 9A               [12] 1932 	subb	a,r2
      006552 40 14            [24] 1933 	jc	00175$
                                   1934 ;	free result
                                   1935 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      006554 90 0D E9         [24] 1936 	mov	dptr,#_keyboard_protocol
      006557 ED               [12] 1937 	mov	a,r5
      006558 F0               [24] 1938 	movx	@dptr,a
                                   1939 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      006559 90 07 F7         [24] 1940 	mov	dptr,#_keyboard_reset
      00655C 74 01            [12] 1941 	mov	a,#0x01
      00655E F0               [24] 1942 	movx	@dptr,a
                                   1943 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      00655F 90 08 26         [24] 1944 	mov	dptr,#_control_phase
      006562 74 03            [12] 1945 	mov	a,#0x03
      006564 F0               [24] 1946 	movx	@dptr,a
      006565 02 69 9B         [24] 1947 	ljmp	00291$
      006568                       1948 00175$:
                                   1949 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      006568 02 5F EC         [24] 1950 	ljmp	_control_stall
                                   1951 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      00656B                       1952 00188$:
                                   1953 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      00656B 20 18 03         [24] 1954 	jb	_control_setup_zero_value_10000_287,01283$
      00656E 02 5F EC         [24] 1955 	ljmp	_control_stall
      006571                       1956 01283$:
      006571 90 07 C8         [24] 1957 	mov	dptr,#_D0SetupLen
      006574 E0               [24] 1958 	movx	a,@dptr
      006575 F9               [12] 1959 	mov	r1,a
      006576 A3               [24] 1960 	inc	dptr
      006577 E0               [24] 1961 	movx	a,@dptr
      006578 FA               [12] 1962 	mov	r2,a
      006579 B9 02 05         [24] 1963 	cjne	r1,#0x02,01284$
      00657C BA 00 02         [24] 1964 	cjne	r2,#0x00,01284$
      00657F 80 03            [24] 1965 	sjmp	01285$
      006581                       1966 01284$:
      006581 02 5F EC         [24] 1967 	ljmp	_control_stall
      006584                       1968 01285$:
                                   1969 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      006584 E4               [12] 1970 	clr	a
      006585 BF 80 01         [24] 1971 	cjne	r7,#0x80,01286$
      006588 04               [12] 1972 	inc	a
      006589                       1973 01286$:
      006589 FA               [12] 1974 	mov	r2,a
      00658A 60 03            [24] 1975 	jz	00196$
      00658C 20 17 35         [24] 1976 	jb	_control_setup_zero_index_10000_287,00189$
      00658F                       1977 00196$:
      00658F BF 81 09         [24] 1978 	cjne	r7,#0x81,00202$
      006592 30 16 06         [24] 1979 	jnb	_control_setup_valid_interface_10000_287,00202$
      006595 90 07 CD         [24] 1980 	mov	dptr,#_D0UsbConfig
      006598 E0               [24] 1981 	movx	a,@dptr
      006599 70 29            [24] 1982 	jnz	00189$
      00659B                       1983 00202$:
                                   1984 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      00659B BF 82 70         [24] 1985 	cjne	r7,#0x82,00190$
      00659E 90 07 CD         [24] 1986 	mov	dptr,#_D0UsbConfig
      0065A1 E0               [24] 1987 	movx	a,@dptr
      0065A2 60 6A            [24] 1988 	jz	00190$
      0065A4 EB               [12] 1989 	mov	a,r3
      0065A5 4C               [12] 1990 	orl	a,r4
      0065A6 60 1C            [24] 1991 	jz	00189$
      0065A8 8B 00            [24] 1992 	mov	ar0,r3
      0065AA 8C 01            [24] 1993 	mov	ar1,r4
      0065AC B8 80 05         [24] 1994 	cjne	r0,#0x80,01298$
      0065AF B9 00 02         [24] 1995 	cjne	r1,#0x00,01298$
      0065B2 80 10            [24] 1996 	sjmp	00189$
      0065B4                       1997 01298$:
      0065B4 C3               [12] 1998 	clr	c
      0065B5 E8               [12] 1999 	mov	a,r0
      0065B6 94 81            [12] 2000 	subb	a,#0x81
      0065B8 E9               [12] 2001 	mov	a,r1
      0065B9 94 00            [12] 2002 	subb	a,#0x00
      0065BB 40 51            [24] 2003 	jc	00190$
      0065BD 74 83            [12] 2004 	mov	a,#0x83
      0065BF 98               [12] 2005 	subb	a,r0
      0065C0 E4               [12] 2006 	clr	a
      0065C1 99               [12] 2007 	subb	a,r1
      0065C2 40 4A            [24] 2008 	jc	00190$
                                   2009 ;	free result
      0065C4                       2010 00189$:
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      0065C4 8B 01            [24] 2012 	mov	ar1,r3
      0065C6 53 01 07         [24] 2013 	anl	ar1,#0x07
                                   2014 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0065C9 EA               [12] 2015 	mov	a,r2
      0065CA 60 0B            [24] 2016 	jz	00308$
      0065CC 90 07 CF         [24] 2017 	mov	dptr,#_USB_SleepStatus
      0065CF E0               [24] 2018 	movx	a,@dptr
      0065D0 54 01            [12] 2019 	anl	a,#0x01
      0065D2 25 E0            [12] 2020 	add	a,acc
      0065D4 FA               [12] 2021 	mov	r2,a
      0065D5 80 22            [24] 2022 	sjmp	00309$
      0065D7                       2023 00308$:
                                   2024 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0065D7 BF 82 1B         [24] 2025 	cjne	r7,#0x82,00310$
      0065DA E9               [12] 2026 	mov	a,r1
      0065DB 60 18            [24] 2027 	jz	00310$
      0065DD 89 00            [24] 2028 	mov	ar0,r1
      0065DF 79 00            [12] 2029 	mov	r1,#0x00
      0065E1 74 22            [12] 2030 	mov	a,#0x22
      0065E3 29               [12] 2031 	add	a, r1
      0065E4 F9               [12] 2032 	mov	r1,a
      0065E5 88 82            [24] 2033 	mov	dpl,r0
      0065E7 89 83            [24] 2034 	mov	dph,r1
      0065E9 E0               [24] 2035 	movx	a,@dptr
      0065EA F9               [12] 2036 	mov	r1,a
      0065EB 53 01 03         [24] 2037 	anl	ar1,#0x03
      0065EE B9 03 04         [24] 2038 	cjne	r1,#0x03,00310$
      0065F1 79 01            [12] 2039 	mov	r1,#0x01
      0065F3 80 02            [24] 2040 	sjmp	00311$
      0065F5                       2041 00310$:
      0065F5 79 00            [12] 2042 	mov	r1,#0x00
      0065F7                       2043 00311$:
      0065F7 89 02            [24] 2044 	mov	ar2,r1
      0065F9                       2045 00309$:
      0065F9 90 10 00         [24] 2046 	mov	dptr,#0x1000
      0065FC EA               [12] 2047 	mov	a,r2
      0065FD F0               [24] 2048 	movx	@dptr,a
                                   2049 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      0065FE A3               [24] 2050 	inc	dptr
      0065FF E4               [12] 2051 	clr	a
      006600 F0               [24] 2052 	movx	@dptr,a
                                   2053 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      006601 90 22 08         [24] 2054 	mov	dptr,#0x2208
      006604 74 02            [12] 2055 	mov	a,#0x02
      006606 F0               [24] 2056 	movx	@dptr,a
                                   2057 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      006607 90 08 26         [24] 2058 	mov	dptr,#_control_phase
      00660A F0               [24] 2059 	movx	@dptr,a
      00660B 02 69 9B         [24] 2060 	ljmp	00291$
      00660E                       2061 00190$:
                                   2062 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      00660E 02 5F EC         [24] 2063 	ljmp	_control_stall
                                   2064 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      006611                       2065 00205$:
                                   2066 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      006611 20 19 03         [24] 2067 	jb	_control_setup_zero_length_10000_287,01307$
      006614 02 66 A4         [24] 2068 	ljmp	00279$
      006617                       2069 01307$:
      006617 90 07 CD         [24] 2070 	mov	dptr,#_D0UsbConfig
      00661A E0               [24] 2071 	movx	a,@dptr
      00661B 70 03            [24] 2072 	jnz	01308$
      00661D 02 66 A4         [24] 2073 	ljmp	00279$
      006620                       2074 01308$:
                                   2075 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      006620 EF               [12] 2076 	mov	a,r7
      006621 70 29            [24] 2077 	jnz	00218$
      006623 8D 01            [24] 2078 	mov	ar1,r5
      006625 8E 02            [24] 2079 	mov	ar2,r6
      006627 B9 01 22         [24] 2080 	cjne	r1,#0x01,00218$
      00662A BA 00 1F         [24] 2081 	cjne	r2,#0x00,00218$
      00662D 30 17 1C         [24] 2082 	jnb	_control_setup_zero_index_10000_287,00218$
                                   2083 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006630 90 07 C7         [24] 2084 	mov	dptr,#_D0SetupReqCode
      006633 E0               [24] 2085 	movx	a,@dptr
      006634 FA               [12] 2086 	mov	r2,a
      006635 BA 03 0A         [24] 2087 	cjne	r2,#0x03,00207$
      006638 90 07 CF         [24] 2088 	mov	dptr,#_USB_SleepStatus
      00663B E0               [24] 2089 	movx	a,@dptr
      00663C 43 E0 01         [24] 2090 	orl	acc,#0x01
      00663F F0               [24] 2091 	movx	@dptr,a
      006640 80 59            [24] 2092 	sjmp	00219$
      006642                       2093 00207$:
                                   2094 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      006642 90 07 CF         [24] 2095 	mov	dptr,#_USB_SleepStatus
      006645 E0               [24] 2096 	movx	a,@dptr
      006646 53 E0 FE         [24] 2097 	anl	acc,#0xfe
      006649 F0               [24] 2098 	movx	@dptr,a
      00664A 80 4F            [24] 2099 	sjmp	00219$
      00664C                       2100 00218$:
                                   2101 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      00664C BF 02 49         [24] 2102 	cjne	r7,#0x02,00212$
      00664F 30 18 46         [24] 2103 	jnb	_control_setup_zero_value_10000_287,00212$
      006652 8B 01            [24] 2104 	mov	ar1,r3
      006654 8C 02            [24] 2105 	mov	ar2,r4
      006656 C3               [12] 2106 	clr	c
      006657 E9               [12] 2107 	mov	a,r1
      006658 94 81            [12] 2108 	subb	a,#0x81
      00665A EA               [12] 2109 	mov	a,r2
      00665B 94 00            [12] 2110 	subb	a,#0x00
      00665D 40 39            [24] 2111 	jc	00212$
      00665F 74 83            [12] 2112 	mov	a,#0x83
      006661 99               [12] 2113 	subb	a,r1
      006662 E4               [12] 2114 	clr	a
      006663 9A               [12] 2115 	subb	a,r2
      006664 40 32            [24] 2116 	jc	00212$
                                   2117 ;	free result
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      006666 8B 02            [24] 2119 	mov	ar2,r3
      006668 53 02 07         [24] 2120 	anl	ar2,#0x07
                                   2121 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      00666B 8A 00            [24] 2122 	mov	ar0,r2
      00666D 79 00            [12] 2123 	mov	r1,#0x00
      00666F 74 22            [12] 2124 	mov	a,#0x22
      006671 29               [12] 2125 	add	a, r1
      006672 F9               [12] 2126 	mov	r1,a
      006673 88 17            [24] 2127 	mov	_control_setup_sloc3_1_0,r0
      006675 89 18            [24] 2128 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006677 90 07 C7         [24] 2129 	mov	dptr,#_D0SetupReqCode
      00667A E0               [24] 2130 	movx	a,@dptr
      00667B F9               [12] 2131 	mov	r1,a
      00667C B9 03 04         [24] 2132 	cjne	r1,#0x03,00318$
      00667F 79 03            [12] 2133 	mov	r1,#0x03
      006681 80 02            [24] 2134 	sjmp	00319$
      006683                       2135 00318$:
      006683 79 02            [12] 2136 	mov	r1,#0x02
      006685                       2137 00319$:
      006685 43 01 10         [24] 2138 	orl	ar1,#0x10
      006688 85 17 82         [24] 2139 	mov	dpl,_control_setup_sloc3_1_0
      00668B 85 18 83         [24] 2140 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00668E E9               [12] 2141 	mov	a,r1
      00668F F0               [24] 2142 	movx	@dptr,a
                                   2143 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006690 BA 03 08         [24] 2144 	cjne	r2,#0x03,00219$
      006693 12 5F 78         [24] 2145 	lcall	_raw_complete
      006696 80 03            [24] 2146 	sjmp	00219$
      006698                       2147 00212$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      006698 02 5F EC         [24] 2149 	ljmp	_control_stall
      00669B                       2150 00219$:
                                   2151 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      00669B 90 08 26         [24] 2152 	mov	dptr,#_control_phase
      00669E 74 03            [12] 2153 	mov	a,#0x03
      0066A0 F0               [24] 2154 	movx	@dptr,a
      0066A1 02 69 9B         [24] 2155 	ljmp	00291$
      0066A4                       2156 00279$:
                                   2157 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      0066A4 E4               [12] 2158 	clr	a
      0066A5 BF A1 01         [24] 2159 	cjne	r7,#0xa1,01324$
      0066A8 04               [12] 2160 	inc	a
      0066A9                       2161 01324$:
      0066A9 FA               [12] 2162 	mov	r2,a
      0066AA 70 03            [24] 2163 	jnz	01326$
      0066AC 02 69 16         [24] 2164 	ljmp	00273$
      0066AF                       2165 01326$:
      0066AF 90 07 C7         [24] 2166 	mov	dptr,#_D0SetupReqCode
      0066B2 E0               [24] 2167 	movx	a,@dptr
      0066B3 F9               [12] 2168 	mov	r1,a
      0066B4 B9 01 02         [24] 2169 	cjne	r1,#0x01,01327$
      0066B7 80 03            [24] 2170 	sjmp	01328$
      0066B9                       2171 01327$:
      0066B9 02 69 16         [24] 2172 	ljmp	00273$
      0066BC                       2173 01328$:
      0066BC 90 07 CD         [24] 2174 	mov	dptr,#_D0UsbConfig
      0066BF E0               [24] 2175 	movx	a,@dptr
      0066C0 70 03            [24] 2176 	jnz	01329$
      0066C2 02 69 16         [24] 2177 	ljmp	00273$
      0066C5                       2178 01329$:
      0066C5 90 07 C8         [24] 2179 	mov	dptr,#_D0SetupLen
      0066C8 E0               [24] 2180 	movx	a,@dptr
      0066C9 F8               [12] 2181 	mov	r0,a
      0066CA A3               [24] 2182 	inc	dptr
      0066CB E0               [24] 2183 	movx	a,@dptr
      0066CC 48               [12] 2184 	orl	a,r0
      0066CD 70 03            [24] 2185 	jnz	01330$
      0066CF 02 69 16         [24] 2186 	ljmp	00273$
      0066D2                       2187 01330$:
                                   2188 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      0066D2 C0 03            [24] 2189 	push	ar3
      0066D4 C0 04            [24] 2190 	push	ar4
      0066D6 8D 01            [24] 2191 	mov	ar1,r5
                                   2192 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      0066D8 8E 00            [24] 2193 	mov	ar0,r6
      0066DA B8 01 03         [24] 2194 	cjne	r0,#0x01,01331$
      0066DD E8               [12] 2195 	mov	a,r0
      0066DE 80 01            [24] 2196 	sjmp	01332$
      0066E0                       2197 01331$:
      0066E0 E4               [12] 2198 	clr	a
      0066E1                       2199 01332$:
      0066E1 F5 17            [12] 2200 	mov	_control_setup_sloc3_1_0,a
      0066E3 D0 04            [24] 2201 	pop	ar4
      0066E5 D0 03            [24] 2202 	pop	ar3
      0066E7 E5 17            [12] 2203 	mov	a,_control_setup_sloc3_1_0
      0066E9 60 17            [24] 2204 	jz	00251$
      0066EB EB               [12] 2205 	mov	a,r3
      0066EC 4C               [12] 2206 	orl	a,r4
      0066ED 70 13            [24] 2207 	jnz	00251$
      0066EF E9               [12] 2208 	mov	a,r1
      0066F0 70 10            [24] 2209 	jnz	00251$
                                   2210 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      0066F2 90 08 30         [24] 2211 	mov	dptr,#_control_setup_length_10000_287
      0066F5 74 08            [12] 2212 	mov	a,#0x08
      0066F7 F0               [24] 2213 	movx	@dptr,a
      0066F8 E4               [12] 2214 	clr	a
      0066F9 A3               [24] 2215 	inc	dptr
      0066FA F0               [24] 2216 	movx	@dptr,a
                                   2217 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      0066FB 90 08 32         [24] 2218 	mov	dptr,#_control_setup_offset_10000_287
      0066FE F0               [24] 2219 	movx	@dptr,a
      0066FF 02 68 86         [24] 2220 	ljmp	00252$
      006702                       2221 00251$:
                                   2222 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      006702 E5 17            [12] 2223 	mov	a,_control_setup_sloc3_1_0
      006704 60 27            [24] 2224 	jz	00245$
      006706 BB 02 24         [24] 2225 	cjne	r3,#0x02,00245$
      006709 BC 00 21         [24] 2226 	cjne	r4,#0x00,00245$
                                   2227 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      00670C B9 07 00         [24] 2228 	cjne	r1,#0x07,01339$
      00670F                       2229 01339$:
      00670F 50 1C            [24] 2230 	jnc	00245$
      006711 E9               [12] 2231 	mov	a,r1
      006712 90 BC F0         [24] 2232 	mov	dptr,#_shared_lengths
      006715 93               [24] 2233 	movc	a,@a+dptr
      006716 F8               [12] 2234 	mov	r0,a
      006717 60 14            [24] 2235 	jz	00245$
                                   2236 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      006719 90 08 30         [24] 2237 	mov	dptr,#_control_setup_length_10000_287
      00671C E8               [12] 2238 	mov	a,r0
      00671D F0               [24] 2239 	movx	@dptr,a
      00671E E4               [12] 2240 	clr	a
      00671F A3               [24] 2241 	inc	dptr
      006720 F0               [24] 2242 	movx	@dptr,a
                                   2243 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      006721 E9               [12] 2244 	mov	a,r1
      006722 90 BC E9         [24] 2245 	mov	dptr,#_shared_offsets
      006725 93               [24] 2246 	movc	a,@a+dptr
      006726 90 08 32         [24] 2247 	mov	dptr,#_control_setup_offset_10000_287
      006729 F0               [24] 2248 	movx	@dptr,a
      00672A 02 68 86         [24] 2249 	ljmp	00252$
      00672D                       2250 00245$:
                                   2251 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      00672D E5 17            [12] 2252 	mov	a,_control_setup_sloc3_1_0
      00672F 60 7A            [24] 2253 	jz	00240$
      006731 BB 01 77         [24] 2254 	cjne	r3,#0x01,00240$
      006734 BC 00 74         [24] 2255 	cjne	r4,#0x00,00240$
      006737 E9               [12] 2256 	mov	a,r1
      006738 70 71            [24] 2257 	jnz	00240$
                                   2258 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      00673A 90 07 C8         [24] 2259 	mov	dptr,#_D0SetupLen
      00673D E0               [24] 2260 	movx	a,@dptr
      00673E F8               [12] 2261 	mov	r0,a
      00673F A3               [24] 2262 	inc	dptr
      006740 E0               [24] 2263 	movx	a,@dptr
      006741 F9               [12] 2264 	mov	r1,a
      006742 C3               [12] 2265 	clr	c
      006743 E8               [12] 2266 	mov	a,r0
      006744 94 20            [12] 2267 	subb	a,#0x20
      006746 E9               [12] 2268 	mov	a,r1
      006747 94 00            [12] 2269 	subb	a,#0x00
      006749 50 0A            [24] 2270 	jnc	00320$
      00674B 90 07 C8         [24] 2271 	mov	dptr,#_D0SetupLen
      00674E E0               [24] 2272 	movx	a,@dptr
      00674F F8               [12] 2273 	mov	r0,a
      006750 A3               [24] 2274 	inc	dptr
      006751 E0               [24] 2275 	movx	a,@dptr
      006752 F9               [12] 2276 	mov	r1,a
      006753 80 04            [24] 2277 	sjmp	00321$
      006755                       2278 00320$:
      006755 78 20            [12] 2279 	mov	r0,#0x20
      006757 79 00            [12] 2280 	mov	r1,#0x00
      006759                       2281 00321$:
                                   2282 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006759 75 17 00         [24] 2283 	mov	_control_setup_sloc3_1_0,#0x00
      00675C                       2284 00293$:
      00675C C0 03            [24] 2285 	push	ar3
      00675E C0 04            [24] 2286 	push	ar4
      006760 AB 17            [24] 2287 	mov	r3,_control_setup_sloc3_1_0
      006762 7C 00            [12] 2288 	mov	r4,#0x00
      006764 C3               [12] 2289 	clr	c
      006765 EB               [12] 2290 	mov	a,r3
      006766 98               [12] 2291 	subb	a,r0
      006767 EC               [12] 2292 	mov	a,r4
      006768 99               [12] 2293 	subb	a,r1
      006769 D0 04            [24] 2294 	pop	ar4
      00676B D0 03            [24] 2295 	pop	ar3
      00676D 50 32            [24] 2296 	jnc	00222$
      00676F C0 00            [24] 2297 	push	ar0
      006771 C0 01            [24] 2298 	push	ar1
      006773 85 17 19         [24] 2299 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006776 74 10            [12] 2300 	mov	a,#0x10
      006778 24 00            [12] 2301 	add	a, #0x00
      00677A F5 1A            [12] 2302 	mov	(_control_setup_sloc4_1_0 + 1),a
      00677C A8 17            [24] 2303 	mov	r0,_control_setup_sloc3_1_0
      00677E 79 00            [12] 2304 	mov	r1,#0x00
      006780 74 C0            [12] 2305 	mov	a,#0xc0
      006782 28               [12] 2306 	add	a, r0
      006783 F8               [12] 2307 	mov	r0,a
      006784 E4               [12] 2308 	clr	a
      006785 39               [12] 2309 	addc	a, r1
      006786 F9               [12] 2310 	mov	r1,a
      006787 88 82            [24] 2311 	mov	dpl,r0
      006789 74 10            [12] 2312 	mov	a,#0x10
      00678B 29               [12] 2313 	add	a, r1
      00678C F5 83            [12] 2314 	mov	dph,a
      00678E E0               [24] 2315 	movx	a,@dptr
      00678F 85 19 82         [24] 2316 	mov	dpl,_control_setup_sloc4_1_0
      006792 85 1A 83         [24] 2317 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006795 F0               [24] 2318 	movx	@dptr,a
      006796 E5 17            [12] 2319 	mov	a,_control_setup_sloc3_1_0
      006798 04               [12] 2320 	inc	a
      006799 F5 17            [12] 2321 	mov	_control_setup_sloc3_1_0,a
      00679B D0 01            [24] 2322 	pop	ar1
      00679D D0 00            [24] 2323 	pop	ar0
      00679F 80 BB            [24] 2324 	sjmp	00293$
      0067A1                       2325 00222$:
                                   2326 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      0067A1 90 08 30         [24] 2327 	mov	dptr,#_control_setup_length_10000_287
      0067A4 E4               [12] 2328 	clr	a
      0067A5 F0               [24] 2329 	movx	@dptr,a
      0067A6 A3               [24] 2330 	inc	dptr
      0067A7 F0               [24] 2331 	movx	@dptr,a
      0067A8 02 68 86         [24] 2332 	ljmp	00252$
      0067AB                       2333 00240$:
                                   2334 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      0067AB 8D 00            [24] 2335 	mov	ar0,r5
      0067AD 8E 01            [24] 2336 	mov	ar1,r6
      0067AF B8 00 21         [24] 2337 	cjne	r0,#0x00,00236$
      0067B2 B9 02 1E         [24] 2338 	cjne	r1,#0x02,00236$
      0067B5 EB               [12] 2339 	mov	a,r3
      0067B6 4C               [12] 2340 	orl	a,r4
      0067B7 70 1A            [24] 2341 	jnz	00236$
                                   2342 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      0067B9 90 07 D2         [24] 2343 	mov	dptr,#_KB_USB_SetReport
      0067BC E0               [24] 2344 	movx	a,@dptr
      0067BD 90 10 00         [24] 2345 	mov	dptr,#0x1000
      0067C0 F0               [24] 2346 	movx	@dptr,a
                                   2347 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      0067C1 90 08 30         [24] 2348 	mov	dptr,#_control_setup_length_10000_287
      0067C4 E4               [12] 2349 	clr	a
      0067C5 F0               [24] 2350 	movx	@dptr,a
      0067C6 A3               [24] 2351 	inc	dptr
      0067C7 F0               [24] 2352 	movx	@dptr,a
                                   2353 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      0067C8 90 07 C8         [24] 2354 	mov	dptr,#_D0SetupLen
      0067CB 04               [12] 2355 	inc	a
      0067CC F0               [24] 2356 	movx	@dptr,a
      0067CD E4               [12] 2357 	clr	a
      0067CE A3               [24] 2358 	inc	dptr
      0067CF F0               [24] 2359 	movx	@dptr,a
      0067D0 02 68 86         [24] 2360 	ljmp	00252$
      0067D3                       2361 00236$:
                                   2362 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      0067D3 B8 06 41         [24] 2363 	cjne	r0,#0x06,00232$
      0067D6 B9 02 3E         [24] 2364 	cjne	r1,#0x02,00232$
      0067D9 BB 02 3B         [24] 2365 	cjne	r3,#0x02,00232$
      0067DC BC 00 38         [24] 2366 	cjne	r4,#0x00,00232$
                                   2367 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      0067DF C0 03            [24] 2368 	push	ar3
      0067E1 C0 04            [24] 2369 	push	ar4
      0067E3 90 10 00         [24] 2370 	mov	dptr,#0x1000
      0067E6 74 06            [12] 2371 	mov	a,#0x06
      0067E8 F0               [24] 2372 	movx	@dptr,a
                                   2373 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      0067E9 90 07 D2         [24] 2374 	mov	dptr,#_KB_USB_SetReport
      0067EC E0               [24] 2375 	movx	a,@dptr
      0067ED 90 10 01         [24] 2376 	mov	dptr,#0x1001
      0067F0 F0               [24] 2377 	movx	@dptr,a
                                   2378 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      0067F1 90 08 30         [24] 2379 	mov	dptr,#_control_setup_length_10000_287
      0067F4 E4               [12] 2380 	clr	a
      0067F5 F0               [24] 2381 	movx	@dptr,a
      0067F6 A3               [24] 2382 	inc	dptr
      0067F7 F0               [24] 2383 	movx	@dptr,a
                                   2384 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      0067F8 90 07 C8         [24] 2385 	mov	dptr,#_D0SetupLen
      0067FB E0               [24] 2386 	movx	a,@dptr
      0067FC FB               [12] 2387 	mov	r3,a
      0067FD A3               [24] 2388 	inc	dptr
      0067FE E0               [24] 2389 	movx	a,@dptr
      0067FF FC               [12] 2390 	mov	r4,a
      006800 C3               [12] 2391 	clr	c
      006801 74 02            [12] 2392 	mov	a,#0x02
      006803 9B               [12] 2393 	subb	a,r3
      006804 E4               [12] 2394 	clr	a
      006805 9C               [12] 2395 	subb	a,r4
      006806 D0 04            [24] 2396 	pop	ar4
      006808 D0 03            [24] 2397 	pop	ar3
      00680A 50 7A            [24] 2398 	jnc	00252$
                                   2399 ;	free result
      00680C 90 07 C8         [24] 2400 	mov	dptr,#_D0SetupLen
      00680F 74 02            [12] 2401 	mov	a,#0x02
      006811 F0               [24] 2402 	movx	@dptr,a
      006812 E4               [12] 2403 	clr	a
      006813 A3               [24] 2404 	inc	dptr
      006814 F0               [24] 2405 	movx	@dptr,a
      006815 80 6F            [24] 2406 	sjmp	00252$
      006817                       2407 00232$:
                                   2408 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      006817 B8 00 69         [24] 2409 	cjne	r0,#0x00,00228$
      00681A B9 03 66         [24] 2410 	cjne	r1,#0x03,00228$
      00681D BB 01 63         [24] 2411 	cjne	r3,#0x01,00228$
      006820 BC 00 60         [24] 2412 	cjne	r4,#0x00,00228$
                                   2413 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      006823 90 10 00         [24] 2414 	mov	dptr,#0x1000
      006826 74 41            [12] 2415 	mov	a,#0x41
      006828 F0               [24] 2416 	movx	@dptr,a
                                   2417 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      006829 A3               [24] 2418 	inc	dptr
      00682A 74 4B            [12] 2419 	mov	a,#0x4b
      00682C F0               [24] 2420 	movx	@dptr,a
                                   2421 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      00682D A3               [24] 2422 	inc	dptr
      00682E 74 42            [12] 2423 	mov	a,#0x42
      006830 F0               [24] 2424 	movx	@dptr,a
                                   2425 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      006831 A3               [24] 2426 	inc	dptr
      006832 74 54            [12] 2427 	mov	a,#0x54
      006834 F0               [24] 2428 	movx	@dptr,a
                                   2429 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      006835 A3               [24] 2430 	inc	dptr
      006836 74 01            [12] 2431 	mov	a,#0x01
      006838 F0               [24] 2432 	movx	@dptr,a
                                   2433 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      006839 90 07 D3         [24] 2434 	mov	dptr,#_ak820_boot_stage
      00683C E0               [24] 2435 	movx	a,@dptr
      00683D 90 10 05         [24] 2436 	mov	dptr,#0x1005
      006840 F0               [24] 2437 	movx	@dptr,a
                                   2438 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006841 90 07 D4         [24] 2439 	mov	dptr,#_ak820_main_heartbeat
      006844 E0               [24] 2440 	movx	a,@dptr
      006845 90 10 06         [24] 2441 	mov	dptr,#0x1006
      006848 F0               [24] 2442 	movx	@dptr,a
                                   2443 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      006849 90 07 CE         [24] 2444 	mov	dptr,#_USB_EnumStatus
      00684C E0               [24] 2445 	movx	a,@dptr
      00684D 60 02            [24] 2446 	jz	00322$
      00684F 74 01            [12] 2447 	mov	a,#0x01
      006851                       2448 00322$:
      006851 F9               [12] 2449 	mov	r1,a
      006852 90 07 CF         [24] 2450 	mov	dptr,#_USB_SleepStatus
      006855 E0               [24] 2451 	movx	a,@dptr
      006856 54 02            [12] 2452 	anl	a,#0x02
      006858 F8               [12] 2453 	mov	r0,a
      006859 E9               [12] 2454 	mov	a,r1
      00685A 42 00            [12] 2455 	orl	ar0,a
      00685C 90 10 07         [24] 2456 	mov	dptr,#0x1007
      00685F E8               [12] 2457 	mov	a,r0
      006860 F0               [24] 2458 	movx	@dptr,a
                                   2459 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      006861 90 08 30         [24] 2460 	mov	dptr,#_control_setup_length_10000_287
      006864 E4               [12] 2461 	clr	a
      006865 F0               [24] 2462 	movx	@dptr,a
      006866 A3               [24] 2463 	inc	dptr
      006867 F0               [24] 2464 	movx	@dptr,a
                                   2465 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      006868 90 07 C8         [24] 2466 	mov	dptr,#_D0SetupLen
      00686B E0               [24] 2467 	movx	a,@dptr
      00686C F8               [12] 2468 	mov	r0,a
      00686D A3               [24] 2469 	inc	dptr
      00686E E0               [24] 2470 	movx	a,@dptr
      00686F F9               [12] 2471 	mov	r1,a
      006870 C3               [12] 2472 	clr	c
      006871 74 08            [12] 2473 	mov	a,#0x08
      006873 98               [12] 2474 	subb	a,r0
      006874 E4               [12] 2475 	clr	a
      006875 99               [12] 2476 	subb	a,r1
      006876 50 0E            [24] 2477 	jnc	00252$
                                   2478 ;	free result
      006878 90 07 C8         [24] 2479 	mov	dptr,#_D0SetupLen
      00687B 74 08            [12] 2480 	mov	a,#0x08
      00687D F0               [24] 2481 	movx	@dptr,a
      00687E E4               [12] 2482 	clr	a
      00687F A3               [24] 2483 	inc	dptr
      006880 F0               [24] 2484 	movx	@dptr,a
      006881 80 03            [24] 2485 	sjmp	00252$
      006883                       2486 00228$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      006883 02 5F EC         [24] 2488 	ljmp	_control_stall
      006886                       2489 00252$:
                                   2490 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      006886 90 08 30         [24] 2491 	mov	dptr,#_control_setup_length_10000_287
      006889 E0               [24] 2492 	movx	a,@dptr
      00688A F5 19            [12] 2493 	mov	_control_setup_sloc4_1_0,a
      00688C A3               [24] 2494 	inc	dptr
      00688D E0               [24] 2495 	movx	a,@dptr
      00688E F5 1A            [12] 2496 	mov	(_control_setup_sloc4_1_0 + 1),a
      006890 E5 19            [12] 2497 	mov	a,_control_setup_sloc4_1_0
      006892 45 1A            [12] 2498 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006894 60 50            [24] 2499 	jz	00262$
                                   2500 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      006896 90 07 C8         [24] 2501 	mov	dptr,#_D0SetupLen
      006899 E0               [24] 2502 	movx	a,@dptr
      00689A F8               [12] 2503 	mov	r0,a
      00689B A3               [24] 2504 	inc	dptr
      00689C E0               [24] 2505 	movx	a,@dptr
      00689D F9               [12] 2506 	mov	r1,a
      00689E C3               [12] 2507 	clr	c
      00689F E5 19            [12] 2508 	mov	a,_control_setup_sloc4_1_0
      0068A1 98               [12] 2509 	subb	a,r0
      0068A2 E5 1A            [12] 2510 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0068A4 99               [12] 2511 	subb	a,r1
      0068A5 50 0A            [24] 2512 	jnc	00559$
                                   2513 ;	free result
      0068A7 90 07 C8         [24] 2514 	mov	dptr,#_D0SetupLen
      0068AA E5 19            [12] 2515 	mov	a,_control_setup_sloc4_1_0
      0068AC F0               [24] 2516 	movx	@dptr,a
      0068AD E5 1A            [12] 2517 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0068AF A3               [24] 2518 	inc	dptr
      0068B0 F0               [24] 2519 	movx	@dptr,a
                                   2520 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      0068B1                       2521 00559$:
      0068B1 75 19 00         [24] 2522 	mov	_control_setup_sloc4_1_0,#0x00
      0068B4                       2523 00296$:
      0068B4 90 07 C8         [24] 2524 	mov	dptr,#_D0SetupLen
      0068B7 E0               [24] 2525 	movx	a,@dptr
      0068B8 F8               [12] 2526 	mov	r0,a
      0068B9 C3               [12] 2527 	clr	c
      0068BA E5 19            [12] 2528 	mov	a,_control_setup_sloc4_1_0
      0068BC 98               [12] 2529 	subb	a,r0
      0068BD 50 46            [24] 2530 	jnc	00263$
      0068BF 85 19 17         [24] 2531 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      0068C2 74 10            [12] 2532 	mov	a,#0x10
      0068C4 24 00            [12] 2533 	add	a, #0x00
      0068C6 F5 18            [12] 2534 	mov	(_control_setup_sloc3_1_0 + 1),a
      0068C8 90 08 32         [24] 2535 	mov	dptr,#_control_setup_offset_10000_287
      0068CB E0               [24] 2536 	movx	a,@dptr
      0068CC 25 19            [12] 2537 	add	a, _control_setup_sloc4_1_0
      0068CE 24 F8            [12] 2538 	add	a, #_input_snapshot
      0068D0 F5 82            [12] 2539 	mov	dpl,a
      0068D2 E4               [12] 2540 	clr	a
      0068D3 34 07            [12] 2541 	addc	a,#(_input_snapshot >> 8)
      0068D5 F5 83            [12] 2542 	mov	dph,a
      0068D7 E0               [24] 2543 	movx	a,@dptr
      0068D8 85 17 82         [24] 2544 	mov	dpl,_control_setup_sloc3_1_0
      0068DB 85 18 83         [24] 2545 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0068DE F0               [24] 2546 	movx	@dptr,a
      0068DF E5 19            [12] 2547 	mov	a,_control_setup_sloc4_1_0
      0068E1 04               [12] 2548 	inc	a
      0068E2 F5 19            [12] 2549 	mov	_control_setup_sloc4_1_0,a
      0068E4 80 CE            [24] 2550 	sjmp	00296$
      0068E6                       2551 00262$:
                                   2552 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      0068E6 BB 01 1C         [24] 2553 	cjne	r3,#0x01,00263$
      0068E9 BC 00 19         [24] 2554 	cjne	r4,#0x00,00263$
      0068EC 90 07 C8         [24] 2555 	mov	dptr,#_D0SetupLen
      0068EF E0               [24] 2556 	movx	a,@dptr
      0068F0 F8               [12] 2557 	mov	r0,a
      0068F1 A3               [24] 2558 	inc	dptr
      0068F2 E0               [24] 2559 	movx	a,@dptr
      0068F3 F9               [12] 2560 	mov	r1,a
      0068F4 C3               [12] 2561 	clr	c
      0068F5 74 20            [12] 2562 	mov	a,#0x20
      0068F7 98               [12] 2563 	subb	a,r0
      0068F8 E4               [12] 2564 	clr	a
      0068F9 99               [12] 2565 	subb	a,r1
      0068FA 50 09            [24] 2566 	jnc	00263$
                                   2567 ;	free result
      0068FC 90 07 C8         [24] 2568 	mov	dptr,#_D0SetupLen
      0068FF 74 20            [12] 2569 	mov	a,#0x20
      006901 F0               [24] 2570 	movx	@dptr,a
      006902 E4               [12] 2571 	clr	a
      006903 A3               [24] 2572 	inc	dptr
      006904 F0               [24] 2573 	movx	@dptr,a
      006905                       2574 00263$:
                                   2575 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      006905 90 07 C8         [24] 2576 	mov	dptr,#_D0SetupLen
      006908 E0               [24] 2577 	movx	a,@dptr
      006909 90 22 08         [24] 2578 	mov	dptr,#0x2208
      00690C F0               [24] 2579 	movx	@dptr,a
                                   2580 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      00690D 90 08 26         [24] 2581 	mov	dptr,#_control_phase
      006910 74 02            [12] 2582 	mov	a,#0x02
      006912 F0               [24] 2583 	movx	@dptr,a
      006913 02 69 9B         [24] 2584 	ljmp	00291$
      006916                       2585 00273$:
                                   2586 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      006916 EB               [12] 2587 	mov	a,r3
      006917 4C               [12] 2588 	orl	a,r4
      006918 70 37            [24] 2589 	jnz	00265$
      00691A 90 07 CD         [24] 2590 	mov	dptr,#_D0UsbConfig
      00691D E0               [24] 2591 	movx	a,@dptr
      00691E 60 31            [24] 2592 	jz	00265$
      006920 EA               [12] 2593 	mov	a,r2
      006921 60 2E            [24] 2594 	jz	00265$
      006923 90 07 C7         [24] 2595 	mov	dptr,#_D0SetupReqCode
      006926 E0               [24] 2596 	movx	a,@dptr
      006927 FA               [12] 2597 	mov	r2,a
      006928 BA 03 26         [24] 2598 	cjne	r2,#0x03,00265$
      00692B 30 18 23         [24] 2599 	jnb	_control_setup_zero_value_10000_287,00265$
      00692E 90 07 C8         [24] 2600 	mov	dptr,#_D0SetupLen
      006931 E0               [24] 2601 	movx	a,@dptr
      006932 F9               [12] 2602 	mov	r1,a
      006933 A3               [24] 2603 	inc	dptr
      006934 E0               [24] 2604 	movx	a,@dptr
      006935 FA               [12] 2605 	mov	r2,a
      006936 B9 01 18         [24] 2606 	cjne	r1,#0x01,00265$
      006939 BA 00 15         [24] 2607 	cjne	r2,#0x00,00265$
                                   2608 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      00693C 90 0D E9         [24] 2609 	mov	dptr,#_keyboard_protocol
      00693F E0               [24] 2610 	movx	a,@dptr
      006940 90 10 00         [24] 2611 	mov	dptr,#0x1000
      006943 F0               [24] 2612 	movx	@dptr,a
                                   2613 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      006944 90 22 08         [24] 2614 	mov	dptr,#0x2208
      006947 74 01            [12] 2615 	mov	a,#0x01
      006949 F0               [24] 2616 	movx	@dptr,a
                                   2617 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      00694A 90 08 26         [24] 2618 	mov	dptr,#_control_phase
      00694D 04               [12] 2619 	inc	a
      00694E F0               [24] 2620 	movx	@dptr,a
      00694F 80 4A            [24] 2621 	sjmp	00291$
      006951                       2622 00265$:
                                   2623 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      006951 02 5F EC         [24] 2625 	ljmp	_control_stall
      006954                       2626 00282$:
                                   2627 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006954 30 16 3E         [24] 2628 	jnb	_control_setup_valid_interface_10000_287,00284$
      006957 90 07 CD         [24] 2629 	mov	dptr,#_D0UsbConfig
      00695A E0               [24] 2630 	movx	a,@dptr
      00695B 60 38            [24] 2631 	jz	00284$
      00695D BF A1 35         [24] 2632 	cjne	r7,#0xa1,00284$
      006960 8E 05            [24] 2633 	mov	ar5,r6
      006962 7E 00            [12] 2634 	mov	r6,#0x00
      006964 ED               [12] 2635 	mov	a,r5
      006965 4E               [12] 2636 	orl	a,r6
      006966 70 2D            [24] 2637 	jnz	00284$
      006968 90 07 C8         [24] 2638 	mov	dptr,#_D0SetupLen
      00696B E0               [24] 2639 	movx	a,@dptr
      00696C FE               [12] 2640 	mov	r6,a
      00696D A3               [24] 2641 	inc	dptr
      00696E E0               [24] 2642 	movx	a,@dptr
      00696F FF               [12] 2643 	mov	r7,a
      006970 BE 01 22         [24] 2644 	cjne	r6,#0x01,00284$
      006973 BF 00 1F         [24] 2645 	cjne	r7,#0x00,00284$
                                   2646 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006976 EB               [12] 2647 	mov	a,r3
      006977 4C               [12] 2648 	orl	a,r4
      006978 70 07            [24] 2649 	jnz	00324$
      00697A 90 06 A5         [24] 2650 	mov	dptr,#_keyboard_idle
      00697D E0               [24] 2651 	movx	a,@dptr
      00697E FF               [12] 2652 	mov	r7,a
      00697F 80 02            [24] 2653 	sjmp	00325$
      006981                       2654 00324$:
      006981 7F 00            [12] 2655 	mov	r7,#0x00
      006983                       2656 00325$:
      006983 90 10 00         [24] 2657 	mov	dptr,#0x1000
      006986 EF               [12] 2658 	mov	a,r7
      006987 F0               [24] 2659 	movx	@dptr,a
                                   2660 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      006988 90 22 08         [24] 2661 	mov	dptr,#0x2208
      00698B 74 01            [12] 2662 	mov	a,#0x01
      00698D F0               [24] 2663 	movx	@dptr,a
                                   2664 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      00698E 90 08 26         [24] 2665 	mov	dptr,#_control_phase
      006991 04               [12] 2666 	inc	a
      006992 F0               [24] 2667 	movx	@dptr,a
      006993 80 06            [24] 2668 	sjmp	00291$
      006995                       2669 00284$:
                                   2670 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      006995 02 5F EC         [24] 2672 	ljmp	_control_stall
      006998                       2673 00290$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      006998 02 5F EC         [24] 2675 	ljmp	_control_stall
      00699B                       2676 00291$:
                                   2677 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      00699B 90 22 00         [24] 2678 	mov	dptr,#0x2200
      00699E 74 C0            [12] 2679 	mov	a,#0xc0
      0069A0 F0               [24] 2680 	movx	@dptr,a
                                   2681 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      0069A1 22               [24] 2682 	ret
                                   2683 ;------------------------------------------------------------
                                   2684 ;Allocation info for local variables in function 'control_out'
                                   2685 ;------------------------------------------------------------
                                   2686 ;i             Allocated with name '_control_out_i_10000_371'
                                   2687 ;------------------------------------------------------------
                                   2688 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2689 ;	-----------------------------------------
                                   2690 ;	 function control_out
                                   2691 ;	-----------------------------------------
      0069A2                       2692 _control_out:
                                   2693 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      0069A2 90 22 0F         [24] 2694 	mov	dptr,#0x220f
      0069A5 E0               [24] 2695 	movx	a,@dptr
      0069A6 20 E6 01         [24] 2696 	jb	acc.6,00102$
      0069A9 22               [24] 2697 	ret
      0069AA                       2698 00102$:
                                   2699 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      0069AA 90 08 26         [24] 2700 	mov	dptr,#_control_phase
      0069AD E0               [24] 2701 	movx	a,@dptr
      0069AE FF               [12] 2702 	mov	r7,a
      0069AF BF 02 12         [24] 2703 	cjne	r7,#0x02,00104$
      0069B2 90 22 0E         [24] 2704 	mov	dptr,#0x220e
      0069B5 E0               [24] 2705 	movx	a,@dptr
      0069B6 70 0C            [24] 2706 	jnz	00104$
                                   2707 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      0069B8 90 08 26         [24] 2708 	mov	dptr,#_control_phase
      0069BB E4               [12] 2709 	clr	a
      0069BC F0               [24] 2710 	movx	@dptr,a
                                   2711 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0069BD 90 22 00         [24] 2712 	mov	dptr,#0x2200
      0069C0 74 02            [12] 2713 	mov	a,#0x02
      0069C2 F0               [24] 2714 	movx	@dptr,a
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      0069C3 22               [24] 2716 	ret
      0069C4                       2717 00104$:
                                   2718 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      0069C4 BF 04 19         [24] 2719 	cjne	r7,#0x04,00106$
      0069C7 90 22 0E         [24] 2720 	mov	dptr,#0x220e
      0069CA E0               [24] 2721 	movx	a,@dptr
      0069CB FF               [12] 2722 	mov	r7,a
      0069CC 90 07 C8         [24] 2723 	mov	dptr,#_D0SetupLen
      0069CF E0               [24] 2724 	movx	a,@dptr
      0069D0 FD               [12] 2725 	mov	r5,a
      0069D1 A3               [24] 2726 	inc	dptr
      0069D2 E0               [24] 2727 	movx	a,@dptr
      0069D3 FE               [12] 2728 	mov	r6,a
      0069D4 7C 00            [12] 2729 	mov	r4,#0x00
      0069D6 EF               [12] 2730 	mov	a,r7
      0069D7 B5 05 06         [24] 2731 	cjne	a,ar5,00209$
      0069DA EC               [12] 2732 	mov	a,r4
      0069DB B5 06 02         [24] 2733 	cjne	a,ar6,00209$
      0069DE 80 03            [24] 2734 	sjmp	00107$
      0069E0                       2735 00209$:
      0069E0                       2736 00106$:
      0069E0 02 5F EC         [24] 2737 	ljmp	_control_stall
      0069E3                       2738 00107$:
                                   2739 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      0069E3 90 08 27         [24] 2740 	mov	dptr,#_output_kind
      0069E6 E0               [24] 2741 	movx	a,@dptr
      0069E7 FF               [12] 2742 	mov	r7,a
      0069E8 BF 01 2E         [24] 2743 	cjne	r7,#0x01,00118$
      0069EB 90 07 D5         [24] 2744 	mov	dptr,#_raw_state
      0069EE E0               [24] 2745 	movx	a,@dptr
      0069EF FE               [12] 2746 	mov	r6,a
      0069F0 BE 01 26         [24] 2747 	cjne	r6,#0x01,00118$
                                   2748 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      0069F3 7E 00            [12] 2749 	mov	r6,#0x00
      0069F5                       2750 00121$:
      0069F5 EE               [12] 2751 	mov	a,r6
      0069F6 24 D6            [12] 2752 	add	a, #_raw_buffer
      0069F8 FC               [12] 2753 	mov	r4,a
      0069F9 E4               [12] 2754 	clr	a
      0069FA 34 07            [12] 2755 	addc	a, #(_raw_buffer >> 8)
      0069FC FD               [12] 2756 	mov	r5,a
      0069FD 8E 82            [24] 2757 	mov	dpl,r6
      0069FF 74 10            [12] 2758 	mov	a,#0x10
      006A01 24 00            [12] 2759 	add	a, #0x00
      006A03 F5 83            [12] 2760 	mov	dph,a
      006A05 E0               [24] 2761 	movx	a,@dptr
      006A06 8C 82            [24] 2762 	mov	dpl,r4
      006A08 8D 83            [24] 2763 	mov	dph,r5
      006A0A F0               [24] 2764 	movx	@dptr,a
      006A0B 0E               [12] 2765 	inc	r6
      006A0C BE 20 00         [24] 2766 	cjne	r6,#0x20,00214$
      006A0F                       2767 00214$:
      006A0F 40 E4            [24] 2768 	jc	00121$
                                   2769 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006A11 90 07 D5         [24] 2770 	mov	dptr,#_raw_state
      006A14 74 02            [12] 2771 	mov	a,#0x02
      006A16 F0               [24] 2772 	movx	@dptr,a
      006A17 80 2B            [24] 2773 	sjmp	00119$
      006A19                       2774 00118$:
                                   2775 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      006A19 BF 02 0A         [24] 2776 	cjne	r7,#0x02,00115$
                                   2777 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      006A1C 90 10 00         [24] 2778 	mov	dptr,#0x1000
      006A1F E0               [24] 2779 	movx	a,@dptr
      006A20 90 07 D2         [24] 2780 	mov	dptr,#_KB_USB_SetReport
      006A23 F0               [24] 2781 	movx	@dptr,a
      006A24 80 1E            [24] 2782 	sjmp	00119$
      006A26                       2783 00115$:
                                   2784 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006A26 BF 03 18         [24] 2785 	cjne	r7,#0x03,00111$
      006A29 90 10 00         [24] 2786 	mov	dptr,#0x1000
      006A2C E0               [24] 2787 	movx	a,@dptr
      006A2D FF               [12] 2788 	mov	r7,a
      006A2E 90 08 28         [24] 2789 	mov	dptr,#_output_report_id
      006A31 E0               [24] 2790 	movx	a,@dptr
      006A32 FE               [12] 2791 	mov	r6,a
      006A33 EF               [12] 2792 	mov	a,r7
      006A34 B5 06 0A         [24] 2793 	cjne	a,ar6,00111$
                                   2794 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      006A37 90 10 01         [24] 2795 	mov	dptr,#0x1001
      006A3A E0               [24] 2796 	movx	a,@dptr
      006A3B 90 07 D2         [24] 2797 	mov	dptr,#_KB_USB_SetReport
      006A3E F0               [24] 2798 	movx	@dptr,a
      006A3F 80 03            [24] 2799 	sjmp	00119$
      006A41                       2800 00111$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      006A41 02 5F EC         [24] 2802 	ljmp	_control_stall
      006A44                       2803 00119$:
                                   2804 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006A44 90 08 27         [24] 2805 	mov	dptr,#_output_kind
      006A47 E4               [12] 2806 	clr	a
      006A48 F0               [24] 2807 	movx	@dptr,a
                                   2808 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      006A49 90 07 C8         [24] 2809 	mov	dptr,#_D0SetupLen
      006A4C F0               [24] 2810 	movx	@dptr,a
      006A4D A3               [24] 2811 	inc	dptr
      006A4E F0               [24] 2812 	movx	@dptr,a
                                   2813 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      006A4F 90 08 26         [24] 2814 	mov	dptr,#_control_phase
      006A52 74 03            [12] 2815 	mov	a,#0x03
      006A54 F0               [24] 2816 	movx	@dptr,a
                                   2817 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      006A55 90 22 08         [24] 2818 	mov	dptr,#0x2208
      006A58 E4               [12] 2819 	clr	a
      006A59 F0               [24] 2820 	movx	@dptr,a
                                   2821 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006A5A F5 82            [12] 2822 	mov	dpl,a
      006A5C 74 48            [12] 2823 	mov	a,#0x48
      006A5E F0               [24] 2824 	movx	@dptr,a
                                   2825 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      006A5F 22               [24] 2826 	ret
                                   2827 ;------------------------------------------------------------
                                   2828 ;Allocation info for local variables in function 'control_in'
                                   2829 ;------------------------------------------------------------
                                   2830 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2831 ;	-----------------------------------------
                                   2832 ;	 function control_in
                                   2833 ;	-----------------------------------------
      006A60                       2834 _control_in:
                                   2835 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      006A60 90 08 26         [24] 2836 	mov	dptr,#_control_phase
      006A63 E0               [24] 2837 	movx	a,@dptr
      006A64 FF               [12] 2838 	mov	r7,a
      006A65 BF 01 22         [24] 2839 	cjne	r7,#0x01,00109$
                                   2840 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      006A68 90 07 C8         [24] 2841 	mov	dptr,#_D0SetupLen
      006A6B E0               [24] 2842 	movx	a,@dptr
      006A6C FD               [12] 2843 	mov	r5,a
      006A6D A3               [24] 2844 	inc	dptr
      006A6E E0               [24] 2845 	movx	a,@dptr
      006A6F 4D               [12] 2846 	orl	a,r5
      006A70 70 06            [24] 2847 	jnz	00101$
      006A72 90 08 29         [24] 2848 	mov	dptr,#_control_zlp
      006A75 E0               [24] 2849 	movx	a,@dptr
      006A76 60 0A            [24] 2850 	jz	00102$
      006A78                       2851 00101$:
                                   2852 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      006A78 90 22 00         [24] 2853 	mov	dptr,#0x2200
      006A7B E0               [24] 2854 	movx	a,@dptr
      006A7C 64 40            [12] 2855 	xrl	a,#0x40
      006A7E F0               [24] 2856 	movx	@dptr,a
                                   2857 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      006A7F 02 60 0E         [24] 2859 	ljmp	_control_next
      006A82                       2860 00102$:
                                   2861 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      006A82 90 08 26         [24] 2862 	mov	dptr,#_control_phase
      006A85 74 02            [12] 2863 	mov	a,#0x02
      006A87 F0               [24] 2864 	movx	@dptr,a
      006A88 80 18            [24] 2865 	sjmp	00110$
      006A8A                       2866 00109$:
                                   2867 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      006A8A BF 03 15         [24] 2868 	cjne	r7,#0x03,00110$
                                   2869 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006A8D 90 07 C7         [24] 2870 	mov	dptr,#_D0SetupReqCode
      006A90 E0               [24] 2871 	movx	a,@dptr
      006A91 FF               [12] 2872 	mov	r7,a
      006A92 BF 05 08         [24] 2873 	cjne	r7,#0x05,00105$
      006A95 90 07 C8         [24] 2874 	mov	dptr,#_D0SetupLen
      006A98 E0               [24] 2875 	movx	a,@dptr
      006A99 90 22 07         [24] 2876 	mov	dptr,#0x2207
      006A9C F0               [24] 2877 	movx	@dptr,a
      006A9D                       2878 00105$:
                                   2879 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      006A9D 90 08 26         [24] 2880 	mov	dptr,#_control_phase
      006AA0 E4               [12] 2881 	clr	a
      006AA1 F0               [24] 2882 	movx	@dptr,a
      006AA2                       2883 00110$:
                                   2884 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006AA2 90 22 00         [24] 2885 	mov	dptr,#0x2200
      006AA5 74 82            [12] 2886 	mov	a,#0x82
      006AA7 F0               [24] 2887 	movx	@dptr,a
                                   2888 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      006AA8 22               [24] 2889 	ret
                                   2890 ;------------------------------------------------------------
                                   2891 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2892 ;------------------------------------------------------------
                                   2893 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_395'
                                   2894 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_395'
                                   2895 ;------------------------------------------------------------
                                   2896 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2897 ;	-----------------------------------------
                                   2898 ;	 function USB_DeviceInterrupt
                                   2899 ;	-----------------------------------------
      006AA9                       2900 _USB_DeviceInterrupt:
                                   2901 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      006AA9                       2902 00129$:
                                   2903 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      006AA9 90 22 3D         [24] 2904 	mov	dptr,#0x223d
      006AAC E0               [24] 2905 	movx	a,@dptr
      006AAD 30 E0 4B         [24] 2906 	jnb	acc.0,00127$
                                   2907 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      006AB0 12 5F 95         [24] 2908 	lcall	_endpoints_reset
                                   2909 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006AB3 90 22 07         [24] 2910 	mov	dptr,#0x2207
      006AB6 E4               [12] 2911 	clr	a
      006AB7 F0               [24] 2912 	movx	@dptr,a
                                   2913 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006AB8 90 07 CF         [24] 2914 	mov	dptr,#_USB_SleepStatus
      006ABB F0               [24] 2915 	movx	@dptr,a
      006ABC 90 07 CE         [24] 2916 	mov	dptr,#_USB_EnumStatus
      006ABF F0               [24] 2917 	movx	@dptr,a
      006AC0 90 07 CD         [24] 2918 	mov	dptr,#_D0UsbConfig
      006AC3 F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      006AC4 90 07 D2         [24] 2921 	mov	dptr,#_KB_USB_SetReport
      006AC7 F0               [24] 2922 	movx	@dptr,a
                                   2923 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      006AC8 90 0D E9         [24] 2924 	mov	dptr,#_keyboard_protocol
      006ACB 04               [12] 2925 	inc	a
      006ACC F0               [24] 2926 	movx	@dptr,a
                                   2927 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      006ACD 90 06 A5         [24] 2928 	mov	dptr,#_keyboard_idle
      006AD0 E4               [12] 2929 	clr	a
      006AD1 F0               [24] 2930 	movx	@dptr,a
                                   2931 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      006AD2 90 07 F7         [24] 2932 	mov	dptr,#_keyboard_reset
      006AD5 04               [12] 2933 	inc	a
      006AD6 F0               [24] 2934 	movx	@dptr,a
                                   2935 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      006AD7 90 07 C7         [24] 2936 	mov	dptr,#_D0SetupReqCode
      006ADA 74 FF            [12] 2937 	mov	a,#0xff
      006ADC F0               [24] 2938 	movx	@dptr,a
                                   2939 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      006ADD 90 07 C8         [24] 2940 	mov	dptr,#_D0SetupLen
      006AE0 E4               [12] 2941 	clr	a
      006AE1 F0               [24] 2942 	movx	@dptr,a
      006AE2 A3               [24] 2943 	inc	dptr
      006AE3 F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      006AE4 90 08 26         [24] 2946 	mov	dptr,#_control_phase
      006AE7 F0               [24] 2947 	movx	@dptr,a
                                   2948 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006AE8 90 22 00         [24] 2949 	mov	dptr,#0x2200
      006AEB 74 02            [12] 2950 	mov	a,#0x02
      006AED F0               [24] 2951 	movx	@dptr,a
                                   2952 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      006AEE 90 22 0F         [24] 2953 	mov	dptr,#0x220f
      006AF1 E4               [12] 2954 	clr	a
      006AF2 F0               [24] 2955 	movx	@dptr,a
                                   2956 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006AF3 90 22 3D         [24] 2957 	mov	dptr,#0x223d
      006AF6 04               [12] 2958 	inc	a
      006AF7 F0               [24] 2959 	movx	@dptr,a
      006AF8 02 6B 8E         [24] 2960 	ljmp	00130$
      006AFB                       2961 00127$:
                                   2962 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006AFB 90 22 3D         [24] 2963 	mov	dptr,#0x223d
      006AFE E0               [24] 2964 	movx	a,@dptr
      006AFF 30 E5 60         [24] 2965 	jnb	acc.5,00124$
                                   2966 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006B02 90 22 0F         [24] 2967 	mov	dptr,#0x220f
      006B05 E0               [24] 2968 	movx	a,@dptr
      006B06 FF               [12] 2969 	mov	r7,a
                                   2970 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      006B07 74 07            [12] 2971 	mov	a,#0x07
      006B09 5F               [12] 2972 	anl	a,r7
      006B0A FE               [12] 2973 	mov	r6,a
                                   2974 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006B0B EF               [12] 2975 	mov	a,r7
      006B0C 54 18            [12] 2976 	anl	a,#0x18
      006B0E 70 08            [24] 2977 	jnz	00115$
      006B10 EE               [12] 2978 	mov	a,r6
      006B11 70 05            [24] 2979 	jnz	00115$
                                   2980 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006B13 12 69 A2         [24] 2981 	lcall	_control_out
      006B16 80 43            [24] 2982 	sjmp	00116$
      006B18                       2983 00115$:
                                   2984 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006B18 8F 05            [24] 2985 	mov	ar5,r7
      006B1A 74 18            [12] 2986 	mov	a,#0x18
      006B1C 5D               [12] 2987 	anl	a,r5
      006B1D FC               [12] 2988 	mov	r4,a
      006B1E BC 10 2D         [24] 2989 	cjne	r4,#0x10,00112$
                                   2990 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      006B21 EE               [12] 2991 	mov	a,r6
      006B22 70 05            [24] 2992 	jnz	00106$
      006B24 12 6A 60         [24] 2993 	lcall	_control_in
      006B27 80 32            [24] 2994 	sjmp	00116$
      006B29                       2995 00106$:
                                   2996 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      006B29 EE               [12] 2997 	mov	a,r6
      006B2A 24 FC            [12] 2998 	add	a,#0xff - 0x03
      006B2C 40 2D            [24] 2999 	jc	00116$
                                   3000 ;	free result
                                   3001 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006B2E 8E 04            [24] 3002 	mov	ar4,r6
      006B30 7B 00            [12] 3003 	mov	r3,#0x00
      006B32 74 22            [12] 3004 	mov	a,#0x22
      006B34 2B               [12] 3005 	add	a, r3
      006B35 FB               [12] 3006 	mov	r3,a
      006B36 8C 82            [24] 3007 	mov	dpl,r4
      006B38 8B 83            [24] 3008 	mov	dph,r3
      006B3A E0               [24] 3009 	movx	a,@dptr
      006B3B FA               [12] 3010 	mov	r2,a
      006B3C 74 FC            [12] 3011 	mov	a,#0xfc
      006B3E 5A               [12] 3012 	anl	a,r2
      006B3F 44 02            [12] 3013 	orl	a,#0x02
      006B41 8C 82            [24] 3014 	mov	dpl,r4
      006B43 8B 83            [24] 3015 	mov	dph,r3
      006B45 F0               [24] 3016 	movx	@dptr,a
                                   3017 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006B46 BE 03 12         [24] 3018 	cjne	r6,#0x03,00116$
      006B49 12 5F 78         [24] 3019 	lcall	_raw_complete
      006B4C 80 0D            [24] 3020 	sjmp	00116$
      006B4E                       3021 00112$:
                                   3022 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006B4E 53 05 18         [24] 3023 	anl	ar5,#0x18
      006B51 BD 18 07         [24] 3024 	cjne	r5,#0x18,00116$
      006B54 EF               [12] 3025 	mov	a,r7
      006B55 30 E5 03         [24] 3026 	jnb	acc.5,00116$
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      006B58 12 62 05         [24] 3028 	lcall	_control_setup
      006B5B                       3029 00116$:
                                   3030 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      006B5B 90 22 0F         [24] 3031 	mov	dptr,#0x220f
      006B5E E4               [12] 3032 	clr	a
      006B5F F0               [24] 3033 	movx	@dptr,a
      006B60 80 2C            [24] 3034 	sjmp	00130$
      006B62                       3035 00124$:
                                   3036 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006B62 90 22 3D         [24] 3037 	mov	dptr,#0x223d
      006B65 E0               [24] 3038 	movx	a,@dptr
      006B66 30 E2 25         [24] 3039 	jnb	acc.2,00130$
                                   3040 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006B69 90 22 3D         [24] 3041 	mov	dptr,#0x223d
      006B6C E0               [24] 3042 	movx	a,@dptr
      006B6D 30 E3 0A         [24] 3043 	jnb	acc.3,00119$
      006B70 90 07 CF         [24] 3044 	mov	dptr,#_USB_SleepStatus
      006B73 E0               [24] 3045 	movx	a,@dptr
      006B74 43 E0 02         [24] 3046 	orl	acc,#0x02
      006B77 F0               [24] 3047 	movx	@dptr,a
      006B78 80 0E            [24] 3048 	sjmp	00120$
      006B7A                       3049 00119$:
                                   3050 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      006B7A 90 07 CF         [24] 3051 	mov	dptr,#_USB_SleepStatus
      006B7D E0               [24] 3052 	movx	a,@dptr
      006B7E 53 E0 FD         [24] 3053 	anl	acc,#0xfd
      006B81 F0               [24] 3054 	movx	@dptr,a
                                   3055 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006B82 90 07 F7         [24] 3056 	mov	dptr,#_keyboard_reset
      006B85 74 01            [12] 3057 	mov	a,#0x01
      006B87 F0               [24] 3058 	movx	@dptr,a
      006B88                       3059 00120$:
                                   3060 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      006B88 90 22 3D         [24] 3061 	mov	dptr,#0x223d
      006B8B 74 04            [12] 3062 	mov	a,#0x04
      006B8D F0               [24] 3063 	movx	@dptr,a
      006B8E                       3064 00130$:
                                   3065 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006B8E 90 22 3D         [24] 3066 	mov	dptr,#0x223d
      006B91 E0               [24] 3067 	movx	a,@dptr
      006B92 54 25            [12] 3068 	anl	a,#0x25
      006B94 60 03            [24] 3069 	jz	00242$
      006B96 02 6A A9         [24] 3070 	ljmp	00129$
      006B99                       3071 00242$:
                                   3072 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      006B99 22               [24] 3073 	ret
                                   3074 ;------------------------------------------------------------
                                   3075 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3076 ;------------------------------------------------------------
                                   3077 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3078 ;	-----------------------------------------
                                   3079 ;	 function USB_Device_Init
                                   3080 ;	-----------------------------------------
      006B9A                       3081 _USB_Device_Init:
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3083 ;	assignBit
      006B9A C2 E9            [12] 3084 	clr	_IE_USB
                                   3085 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      006B9C 90 22 3C         [24] 3086 	mov	dptr,#0x223c
      006B9F E4               [12] 3087 	clr	a
      006BA0 F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      006BA1 90 07 D5         [24] 3090 	mov	dptr,#_raw_state
      006BA4 F0               [24] 3091 	movx	@dptr,a
                                   3092 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      006BA5 12 5F 95         [24] 3093 	lcall	_endpoints_reset
                                   3094 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006BA8 90 07 CF         [24] 3095 	mov	dptr,#_USB_SleepStatus
      006BAB E4               [12] 3096 	clr	a
      006BAC F0               [24] 3097 	movx	@dptr,a
      006BAD 90 07 CE         [24] 3098 	mov	dptr,#_USB_EnumStatus
      006BB0 F0               [24] 3099 	movx	@dptr,a
      006BB1 90 07 CD         [24] 3100 	mov	dptr,#_D0UsbConfig
      006BB4 F0               [24] 3101 	movx	@dptr,a
      006BB5 90 22 07         [24] 3102 	mov	dptr,#0x2207
      006BB8 F0               [24] 3103 	movx	@dptr,a
                                   3104 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006BB9 90 07 D0         [24] 3105 	mov	dptr,#_MCU_Sleep_Operate
      006BBC F0               [24] 3106 	movx	@dptr,a
      006BBD 90 07 D1         [24] 3107 	mov	dptr,#_KB_USB_UpStatus
      006BC0 F0               [24] 3108 	movx	@dptr,a
      006BC1 90 07 D2         [24] 3109 	mov	dptr,#_KB_USB_SetReport
      006BC4 F0               [24] 3110 	movx	@dptr,a
                                   3111 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      006BC5 90 0D E9         [24] 3112 	mov	dptr,#_keyboard_protocol
      006BC8 04               [12] 3113 	inc	a
      006BC9 F0               [24] 3114 	movx	@dptr,a
                                   3115 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      006BCA 90 06 A5         [24] 3116 	mov	dptr,#_keyboard_idle
      006BCD E4               [12] 3117 	clr	a
      006BCE F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006BCF 90 07 F7         [24] 3120 	mov	dptr,#_keyboard_reset
      006BD2 F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      006BD3 90 08 26         [24] 3123 	mov	dptr,#_control_phase
      006BD6 F0               [24] 3124 	movx	@dptr,a
                                   3125 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      006BD7 90 07 C7         [24] 3126 	mov	dptr,#_D0SetupReqCode
      006BDA 14               [12] 3127 	dec	a
      006BDB F0               [24] 3128 	movx	@dptr,a
                                   3129 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      006BDC 90 07 C8         [24] 3130 	mov	dptr,#_D0SetupLen
      006BDF E4               [12] 3131 	clr	a
      006BE0 F0               [24] 3132 	movx	@dptr,a
      006BE1 A3               [24] 3133 	inc	dptr
      006BE2 F0               [24] 3134 	movx	@dptr,a
                                   3135 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006BE3 90 22 00         [24] 3136 	mov	dptr,#0x2200
      006BE6 74 02            [12] 3137 	mov	a,#0x02
      006BE8 F0               [24] 3138 	movx	@dptr,a
                                   3139 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      006BE9 90 22 37         [24] 3140 	mov	dptr,#0x2237
      006BEC 74 7F            [12] 3141 	mov	a,#0x7f
      006BEE F0               [24] 3142 	movx	@dptr,a
                                   3143 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      006BEF 90 22 3D         [24] 3144 	mov	dptr,#0x223d
      006BF2 74 FF            [12] 3145 	mov	a,#0xff
      006BF4 F0               [24] 3146 	movx	@dptr,a
                                   3147 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006BF5 90 22 3B         [24] 3148 	mov	dptr,#0x223b
      006BF8 74 07            [12] 3149 	mov	a,#0x07
      006BFA F0               [24] 3150 	movx	@dptr,a
                                   3151 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      006BFB A3               [24] 3152 	inc	dptr
      006BFC 74 80            [12] 3153 	mov	a,#0x80
      006BFE F0               [24] 3154 	movx	@dptr,a
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3156 ;	assignBit
      006BFF D2 E9            [12] 3157 	setb	_IE_USB
                                   3158 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006C01 22               [24] 3159 	ret
                                   3160 ;------------------------------------------------------------
                                   3161 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3162 ;------------------------------------------------------------
                                   3163 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_418'
                                   3164 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_421'
                                   3165 ;------------------------------------------------------------
                                   3166 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3167 ;	-----------------------------------------
                                   3168 ;	 function USB_WakeUp_PC
                                   3169 ;	-----------------------------------------
      006C02                       3170 _USB_WakeUp_PC:
                                   3171 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      006C02 90 07 CF         [24] 3172 	mov	dptr,#_USB_SleepStatus
      006C05 E0               [24] 3173 	movx	a,@dptr
      006C06 FF               [12] 3174 	mov	r7,a
      006C07 BF 03 22         [24] 3175 	cjne	r7,#0x03,00110$
                                   3176 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006C0A 90 22 3C         [24] 3177 	mov	dptr,#0x223c
      006C0D E0               [24] 3178 	movx	a,@dptr
      006C0E FF               [12] 3179 	mov	r7,a
                                   3180 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006C0F E0               [24] 3181 	movx	a,@dptr
      006C10 FE               [12] 3182 	mov	r6,a
      006C11 63 06 C0         [24] 3183 	xrl	ar6,#0xc0
      006C14 90 22 3C         [24] 3184 	mov	dptr,#0x223c
      006C17 EE               [12] 3185 	mov	a,r6
      006C18 F0               [24] 3186 	movx	@dptr,a
                                   3187 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      006C19 7E 0A            [12] 3188 	mov	r6,#0x0a
      006C1B                       3189 00108$:
      006C1B EE               [12] 3190 	mov	a,r6
      006C1C 60 09            [24] 3191 	jz	00105$
      006C1E 90 00 01         [24] 3192 	mov	dptr,#0x0001
      006C21 12 5D DC         [24] 3193 	lcall	_mDelaymS
      006C24 1E               [12] 3194 	dec	r6
      006C25 80 F4            [24] 3195 	sjmp	00108$
      006C27                       3196 00105$:
                                   3197 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006C27 90 22 3C         [24] 3198 	mov	dptr,#0x223c
      006C2A EF               [12] 3199 	mov	a,r7
      006C2B F0               [24] 3200 	movx	@dptr,a
      006C2C                       3201 00110$:
                                   3202 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006C2C 22               [24] 3203 	ret
                                   3204 ;------------------------------------------------------------
                                   3205 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3206 ;------------------------------------------------------------
                                   3207 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3208 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3209 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3210 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3211 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_423'
                                   3212 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_424'
                                   3213 ;i             Allocated with name '_ak820_usb_send_i_10000_424'
                                   3214 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_424'
                                   3215 ;offset        Allocated with name '_ak820_usb_send_offset_10000_424'
                                   3216 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_424'
                                   3217 ;i             Allocated with name '_ak820_usb_send_i_30000_436'
                                   3218 ;------------------------------------------------------------
                                   3219 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3220 ;	-----------------------------------------
                                   3221 ;	 function ak820_usb_send
                                   3222 ;	-----------------------------------------
      006C2D                       3223 _ak820_usb_send:
      006C2D E5 82            [12] 3224 	mov	a,dpl
      006C2F 90 08 36         [24] 3225 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006C32 F0               [24] 3226 	movx	@dptr,a
                                   3227 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      006C33 90 08 37         [24] 3228 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006C36 74 2E            [12] 3229 	mov	a,#0x2e
      006C38 F0               [24] 3230 	movx	@dptr,a
                                   3231 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006C39 90 08 36         [24] 3232 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006C3C E0               [24] 3233 	movx	a,@dptr
      006C3D FF               [12] 3234 	mov	r7,a
      006C3E BF 01 00         [24] 3235 	cjne	r7,#0x01,00306$
      006C41                       3236 00306$:
      006C41 40 14            [24] 3237 	jc	00101$
      006C43 EF               [12] 3238 	mov	a,r7
      006C44 24 FC            [12] 3239 	add	a,#0xff - 0x03
      006C46 40 0F            [24] 3240 	jc	00101$
                                   3241 ;	free result
      006C48 90 08 35         [24] 3242 	mov	dptr,#_ak820_usb_send_PARM_3
      006C4B E0               [24] 3243 	movx	a,@dptr
      006C4C FE               [12] 3244 	mov  r6,a
      006C4D 24 BF            [12] 3245 	add	a,#0xff - 0x40
      006C4F 40 06            [24] 3246 	jc	00101$
                                   3247 ;	free result
      006C51 90 07 CE         [24] 3248 	mov	dptr,#_USB_EnumStatus
      006C54 E0               [24] 3249 	movx	a,@dptr
      006C55 70 04            [24] 3250 	jnz	00102$
      006C57                       3251 00101$:
      006C57 75 82 00         [24] 3252 	mov	dpl, #0x00
      006C5A 22               [24] 3253 	ret
      006C5B                       3254 00102$:
                                   3255 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006C5B BF 01 10         [24] 3256 	cjne	r7,#0x01,00118$
                                   3257 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006C5E BE 08 02         [24] 3258 	cjne	r6,#0x08,00313$
      006C61 80 04            [24] 3259 	sjmp	00107$
      006C63                       3260 00313$:
      006C63 75 82 00         [24] 3261 	mov	dpl, #0x00
      006C66 22               [24] 3262 	ret
      006C67                       3263 00107$:
                                   3264 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006C67 90 08 37         [24] 3265 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006C6A E4               [12] 3266 	clr	a
      006C6B F0               [24] 3267 	movx	@dptr,a
      006C6C 80 3C            [24] 3268 	sjmp	00119$
      006C6E                       3269 00118$:
                                   3270 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006C6E BF 02 30         [24] 3271 	cjne	r7,#0x02,00115$
                                   3272 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006C71 90 08 33         [24] 3273 	mov	dptr,#_ak820_usb_send_PARM_2
      006C74 E0               [24] 3274 	movx	a,@dptr
      006C75 FD               [12] 3275 	mov	r5,a
      006C76 A3               [24] 3276 	inc	dptr
      006C77 E0               [24] 3277 	movx	a,@dptr
      006C78 FF               [12] 3278 	mov	r7,a
      006C79 8D 82            [24] 3279 	mov	dpl,r5
      006C7B 8F 83            [24] 3280 	mov	dph,r7
      006C7D E0               [24] 3281 	movx	a,@dptr
      006C7E FF               [12] 3282 	mov	r7,a
                                   3283 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006C7F BF 07 00         [24] 3284 	cjne	r7,#0x07,00316$
      006C82                       3285 00316$:
      006C82 50 0E            [24] 3286 	jnc	00108$
      006C84 EF               [12] 3287 	mov	a,r7
      006C85 90 BC F0         [24] 3288 	mov	dptr,#_shared_lengths
      006C88 93               [24] 3289 	movc	a,@a+dptr
      006C89 FD               [12] 3290 	mov	r5,a
      006C8A 60 06            [24] 3291 	jz	00108$
      006C8C EE               [12] 3292 	mov	a,r6
      006C8D B5 05 02         [24] 3293 	cjne	a,ar5,00319$
      006C90 80 04            [24] 3294 	sjmp	00109$
      006C92                       3295 00319$:
      006C92                       3296 00108$:
      006C92 75 82 00         [24] 3297 	mov	dpl, #0x00
      006C95 22               [24] 3298 	ret
      006C96                       3299 00109$:
                                   3300 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006C96 EF               [12] 3301 	mov	a,r7
      006C97 90 BC E9         [24] 3302 	mov	dptr,#_shared_offsets
      006C9A 93               [24] 3303 	movc	a,@a+dptr
      006C9B 90 08 37         [24] 3304 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006C9E F0               [24] 3305 	movx	@dptr,a
      006C9F 80 09            [24] 3306 	sjmp	00119$
      006CA1                       3307 00115$:
                                   3308 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006CA1 BE 20 02         [24] 3309 	cjne	r6,#0x20,00320$
      006CA4 80 04            [24] 3310 	sjmp	00119$
      006CA6                       3311 00320$:
      006CA6 75 82 00         [24] 3312 	mov	dpl, #0x00
      006CA9 22               [24] 3313 	ret
      006CAA                       3314 00119$:
                                   3315 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006CAA 90 07 CF         [24] 3316 	mov	dptr,#_USB_SleepStatus
      006CAD E0               [24] 3317 	movx	a,@dptr
      006CAE 30 E1 07         [24] 3318 	jnb	acc.1,00184$
      006CB1 12 6C 02         [24] 3319 	lcall	_USB_WakeUp_PC
      006CB4 75 82 00         [24] 3320 	mov	dpl, #0x00
      006CB7 22               [24] 3321 	ret
                                   3322 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006CB8                       3323 00184$:
      006CB8 7F FA            [12] 3324 	mov	r7,#0xfa
      006CBA                       3325 00127$:
      006CBA 90 08 36         [24] 3326 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006CBD E0               [24] 3327 	movx	a,@dptr
      006CBE FC               [12] 3328 	mov	r4,a
      006CBF 7D 00            [12] 3329 	mov	r5,#0x00
      006CC1 8C 02            [24] 3330 	mov	ar2,r4
      006CC3 74 22            [12] 3331 	mov	a,#0x22
      006CC5 2D               [12] 3332 	add	a, r5
      006CC6 FB               [12] 3333 	mov	r3,a
      006CC7 8A 82            [24] 3334 	mov	dpl,r2
      006CC9 8B 83            [24] 3335 	mov	dph,r3
      006CCB E0               [24] 3336 	movx	a,@dptr
      006CCC 54 03            [12] 3337 	anl	a,#0x03
      006CCE 70 14            [24] 3338 	jnz	00129$
      006CD0 8F 03            [24] 3339 	mov	ar3,r7
      006CD2 1F               [12] 3340 	dec	r7
      006CD3 EB               [12] 3341 	mov	a,r3
      006CD4 60 0E            [24] 3342 	jz	00129$
      006CD6 7B 28            [12] 3343 	mov	r3,#0x28
      006CD8                       3344 00141$:
      006CD8 EB               [12] 3345 	mov	a,r3
      006CD9 60 DF            [24] 3346 	jz	00127$
      006CDB 90 00 01         [24] 3347 	mov	dptr,#0x0001
      006CDE 12 5D 98         [24] 3348 	lcall	_mDelayuS
      006CE1 1B               [12] 3349 	dec	r3
      006CE2 80 F4            [24] 3350 	sjmp	00141$
      006CE4                       3351 00129$:
                                   3352 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      006CE4 A2 AF            [12] 3353 	mov	c,_EA
      006CE6 E4               [12] 3354 	clr	a
      006CE7 33               [12] 3355 	rlc	a
      006CE8 FF               [12] 3356 	mov	r7,a
                                   3357 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3358 ;	assignBit
      006CE9 C2 AF            [12] 3359 	clr	_EA
                                   3360 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006CEB 90 07 CE         [24] 3361 	mov	dptr,#_USB_EnumStatus
      006CEE E0               [24] 3362 	movx	a,@dptr
      006CEF 60 25            [24] 3363 	jz	00130$
      006CF1 90 08 36         [24] 3364 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006CF4 E0               [24] 3365 	movx	a,@dptr
      006CF5 FB               [12] 3366 	mov	r3,a
      006CF6 F9               [12] 3367 	mov	r1,a
      006CF7 7A 00            [12] 3368 	mov	r2,#0x00
      006CF9 74 22            [12] 3369 	mov	a,#0x22
      006CFB 2A               [12] 3370 	add	a, r2
      006CFC FA               [12] 3371 	mov	r2,a
      006CFD 89 82            [24] 3372 	mov	dpl,r1
      006CFF 8A 83            [24] 3373 	mov	dph,r2
      006D01 E0               [24] 3374 	movx	a,@dptr
      006D02 FA               [12] 3375 	mov	r2,a
      006D03 53 02 03         [24] 3376 	anl	ar2,#0x03
      006D06 BA 02 0D         [24] 3377 	cjne	r2,#0x02,00130$
                                   3378 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006D09 BB 03 13         [24] 3379 	cjne	r3,#0x03,00192$
      006D0C 90 07 D5         [24] 3380 	mov	dptr,#_raw_state
      006D0F E0               [24] 3381 	movx	a,@dptr
      006D10 FB               [12] 3382 	mov	r3,a
      006D11 BB 03 02         [24] 3383 	cjne	r3,#0x03,00331$
      006D14 80 09            [24] 3384 	sjmp	00192$
      006D16                       3385 00331$:
      006D16                       3386 00130$:
                                   3387 ;	assignBit
      006D16 EF               [12] 3388 	mov	a,r7
      006D17 24 FF            [12] 3389 	add	a,#0xff
      006D19 92 AF            [24] 3390 	mov	_EA,c
      006D1B 75 82 00         [24] 3391 	mov	dpl, #0x00
      006D1E 22               [24] 3392 	ret
                                   3393 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006D1F                       3394 00192$:
      006D1F 7B 00            [12] 3395 	mov	r3,#0x00
      006D21                       3396 00144$:
      006D21 C3               [12] 3397 	clr	c
      006D22 EB               [12] 3398 	mov	a,r3
      006D23 9E               [12] 3399 	subb	a,r6
      006D24 50 67            [24] 3400 	jnc	00137$
                                   3401 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006D26 C0 07            [24] 3402 	push	ar7
      006D28 90 08 36         [24] 3403 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006D2B E0               [24] 3404 	movx	a,@dptr
      006D2C F9               [12] 3405 	mov	r1,a
      006D2D E4               [12] 3406 	clr	a
      006D2E C3               [12] 3407 	clr	c
      006D2F C9               [12] 3408 	xch	a,r1
      006D30 13               [12] 3409 	rrc	a
      006D31 C9               [12] 3410 	xch	a,r1
      006D32 13               [12] 3411 	rrc	a
      006D33 A2 E0            [12] 3412 	mov	c,acc.0
      006D35 C9               [12] 3413 	xch	a,r1
      006D36 13               [12] 3414 	rrc	a
      006D37 C9               [12] 3415 	xch	a,r1
      006D38 13               [12] 3416 	rrc	a
      006D39 C9               [12] 3417 	xch	a,r1
      006D3A FA               [12] 3418 	mov	r2,a
      006D3B 8B 00            [24] 3419 	mov	ar0,r3
      006D3D 7F 00            [12] 3420 	mov	r7,#0x00
      006D3F E8               [12] 3421 	mov	a,r0
      006D40 29               [12] 3422 	add	a, r1
      006D41 F9               [12] 3423 	mov	r1,a
      006D42 EF               [12] 3424 	mov	a,r7
      006D43 3A               [12] 3425 	addc	a, r2
      006D44 24 10            [12] 3426 	add	a,#0x10
      006D46 FA               [12] 3427 	mov	r2,a
      006D47 90 08 33         [24] 3428 	mov	dptr,#_ak820_usb_send_PARM_2
      006D4A E0               [24] 3429 	movx	a,@dptr
      006D4B F8               [12] 3430 	mov	r0,a
      006D4C A3               [24] 3431 	inc	dptr
      006D4D E0               [24] 3432 	movx	a,@dptr
      006D4E FF               [12] 3433 	mov	r7,a
      006D4F EB               [12] 3434 	mov	a,r3
      006D50 28               [12] 3435 	add	a, r0
      006D51 F5 1B            [12] 3436 	mov	_ak820_usb_send_sloc0_1_0,a
      006D53 E4               [12] 3437 	clr	a
      006D54 3F               [12] 3438 	addc	a, r7
      006D55 F5 1C            [12] 3439 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006D57 85 1B 82         [24] 3440 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006D5A 85 1C 83         [24] 3441 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006D5D E0               [24] 3442 	movx	a,@dptr
      006D5E 89 82            [24] 3443 	mov	dpl,r1
      006D60 8A 83            [24] 3444 	mov	dph,r2
      006D62 F0               [24] 3445 	movx	@dptr,a
                                   3446 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006D63 90 08 37         [24] 3447 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006D66 E0               [24] 3448 	movx	a,@dptr
      006D67 F5 1D            [12] 3449 	mov	_ak820_usb_send_sloc1_1_0,a
      006D69 74 2E            [12] 3450 	mov	a,#0x2e
      006D6B B5 1D 04         [24] 3451 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006D6E D0 07            [24] 3452 	pop	ar7
      006D70 80 18            [24] 3453 	sjmp	00145$
      006D72                       3454 00333$:
      006D72 D0 07            [24] 3455 	pop	ar7
      006D74 EB               [12] 3456 	mov	a,r3
      006D75 25 1D            [12] 3457 	add	a, _ak820_usb_send_sloc1_1_0
      006D77 24 F8            [12] 3458 	add	a, #_input_snapshot
      006D79 F9               [12] 3459 	mov	r1,a
      006D7A E4               [12] 3460 	clr	a
      006D7B 34 07            [12] 3461 	addc	a,#(_input_snapshot >> 8)
      006D7D FA               [12] 3462 	mov	r2,a
      006D7E 85 1B 82         [24] 3463 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006D81 85 1C 83         [24] 3464 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006D84 E0               [24] 3465 	movx	a,@dptr
      006D85 89 82            [24] 3466 	mov	dpl,r1
      006D87 8A 83            [24] 3467 	mov	dph,r2
      006D89 F0               [24] 3468 	movx	@dptr,a
      006D8A                       3469 00145$:
                                   3470 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006D8A 0B               [12] 3471 	inc	r3
      006D8B 80 94            [24] 3472 	sjmp	00144$
      006D8D                       3473 00137$:
                                   3474 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006D8D 90 08 36         [24] 3475 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006D90 E0               [24] 3476 	movx	a,@dptr
      006D91 FB               [12] 3477 	mov	r3,a
      006D92 F9               [12] 3478 	mov	r1,a
      006D93 7A 00            [12] 3479 	mov	r2,#0x00
      006D95 74 08            [12] 3480 	mov	a,#0x08
      006D97 29               [12] 3481 	add	a, r1
      006D98 F9               [12] 3482 	mov	r1,a
      006D99 74 22            [12] 3483 	mov	a,#0x22
      006D9B 3A               [12] 3484 	addc	a, r2
      006D9C FA               [12] 3485 	mov	r2,a
      006D9D 89 82            [24] 3486 	mov	dpl,r1
      006D9F 8A 83            [24] 3487 	mov	dph,r2
      006DA1 EE               [12] 3488 	mov	a,r6
      006DA2 F0               [24] 3489 	movx	@dptr,a
                                   3490 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006DA3 BB 03 06         [24] 3491 	cjne	r3,#0x03,00139$
      006DA6 90 07 D5         [24] 3492 	mov	dptr,#_raw_state
      006DA9 74 04            [12] 3493 	mov	a,#0x04
      006DAB F0               [24] 3494 	movx	@dptr,a
      006DAC                       3495 00139$:
                                   3496 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006DAC 74 22            [12] 3497 	mov	a,#0x22
      006DAE 2D               [12] 3498 	add	a, r5
      006DAF FD               [12] 3499 	mov	r5,a
      006DB0 8C 82            [24] 3500 	mov	dpl,r4
      006DB2 8D 83            [24] 3501 	mov	dph,r5
      006DB4 E0               [24] 3502 	movx	a,@dptr
      006DB5 FE               [12] 3503 	mov	r6,a
      006DB6 53 06 FC         [24] 3504 	anl	ar6,#0xfc
      006DB9 8C 82            [24] 3505 	mov	dpl,r4
      006DBB 8D 83            [24] 3506 	mov	dph,r5
      006DBD EE               [12] 3507 	mov	a,r6
      006DBE F0               [24] 3508 	movx	@dptr,a
                                   3509 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3510 ;	assignBit
      006DBF EF               [12] 3511 	mov	a,r7
      006DC0 24 FF            [12] 3512 	add	a,#0xff
      006DC2 92 AF            [24] 3513 	mov	_EA,c
                                   3514 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006DC4 75 82 01         [24] 3515 	mov	dpl, #0x01
                                   3516 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006DC7 22               [24] 3517 	ret
                                   3518 ;------------------------------------------------------------
                                   3519 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3520 ;------------------------------------------------------------
                                   3521 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3522 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3523 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_444'
                                   3524 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_445'
                                   3525 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_445'
                                   3526 ;------------------------------------------------------------
                                   3527 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3528 ;	-----------------------------------------
                                   3529 ;	 function ak820_usb_try_send
                                   3530 ;	-----------------------------------------
      006DC8                       3531 _ak820_usb_try_send:
      006DC8 E5 82            [12] 3532 	mov	a,dpl
      006DCA 90 08 3B         [24] 3533 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006DCD F0               [24] 3534 	movx	@dptr,a
                                   3535 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3536 ;	assignBit
      006DCE A2 AF            [12] 3537 	mov	c,_EA
      006DD0 92 1C            [24] 3538 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3539 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006DD2 90 08 3C         [24] 3540 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006DD5 E4               [12] 3541 	clr	a
      006DD6 F0               [24] 3542 	movx	@dptr,a
                                   3543 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3544 ;	assignBit
      006DD7 C2 AF            [12] 3545 	clr	_EA
                                   3546 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006DD9 90 08 3B         [24] 3547 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006DDC E0               [24] 3548 	movx	a,@dptr
      006DDD FF               [12] 3549 	mov	r7,a
      006DDE BF 01 00         [24] 3550 	cjne	r7,#0x01,00152$
      006DE1                       3551 00152$:
      006DE1 40 4E            [24] 3552 	jc	00102$
      006DE3 EF               [12] 3553 	mov	a,r7
      006DE4 24 FD            [12] 3554 	add	a,#0xff - 0x02
      006DE6 40 49            [24] 3555 	jc	00102$
                                   3556 ;	free result
      006DE8 90 07 CE         [24] 3557 	mov	dptr,#_USB_EnumStatus
      006DEB E0               [24] 3558 	movx	a,@dptr
      006DEC 60 43            [24] 3559 	jz	00102$
                                   3560 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006DEE 90 07 CF         [24] 3561 	mov	dptr,#_USB_SleepStatus
      006DF1 E0               [24] 3562 	movx	a,@dptr
      006DF2 20 E1 3C         [24] 3563 	jb	acc.1,00102$
      006DF5 90 07 F7         [24] 3564 	mov	dptr,#_keyboard_reset
      006DF8 E0               [24] 3565 	movx	a,@dptr
                                   3566 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006DF9 70 36            [24] 3567 	jnz	00102$
      006DFB 8F 06            [24] 3568 	mov	ar6,r7
      006DFD 24 22            [12] 3569 	add	a,#0x22
      006DFF FD               [12] 3570 	mov	r5,a
      006E00 8E 82            [24] 3571 	mov	dpl,r6
      006E02 8D 83            [24] 3572 	mov	dph,r5
      006E04 E0               [24] 3573 	movx	a,@dptr
      006E05 FE               [12] 3574 	mov	r6,a
      006E06 53 06 03         [24] 3575 	anl	ar6,#0x03
      006E09 BE 02 25         [24] 3576 	cjne	r6,#0x02,00102$
                                   3577 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006E0C 90 08 38         [24] 3578 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006E0F E0               [24] 3579 	movx	a,@dptr
      006E10 FD               [12] 3580 	mov	r5,a
      006E11 A3               [24] 3581 	inc	dptr
      006E12 E0               [24] 3582 	movx	a,@dptr
      006E13 FE               [12] 3583 	mov	r6,a
      006E14 90 08 3A         [24] 3584 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006E17 E0               [24] 3585 	movx	a,@dptr
      006E18 FC               [12] 3586 	mov	r4,a
      006E19 90 08 33         [24] 3587 	mov	dptr,#_ak820_usb_send_PARM_2
      006E1C ED               [12] 3588 	mov	a,r5
      006E1D F0               [24] 3589 	movx	@dptr,a
      006E1E EE               [12] 3590 	mov	a,r6
      006E1F A3               [24] 3591 	inc	dptr
      006E20 F0               [24] 3592 	movx	@dptr,a
      006E21 90 08 35         [24] 3593 	mov	dptr,#_ak820_usb_send_PARM_3
      006E24 EC               [12] 3594 	mov	a,r4
      006E25 F0               [24] 3595 	movx	@dptr,a
      006E26 8F 82            [24] 3596 	mov	dpl, r7
      006E28 12 6C 2D         [24] 3597 	lcall	_ak820_usb_send
      006E2B E5 82            [12] 3598 	mov	a, dpl
      006E2D 90 08 3C         [24] 3599 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006E30 F0               [24] 3600 	movx	@dptr,a
      006E31                       3601 00102$:
                                   3602 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3603 ;	assignBit
      006E31 A2 1C            [12] 3604 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006E33 92 AF            [24] 3605 	mov	_EA,c
                                   3606 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006E35 90 08 3C         [24] 3607 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006E38 E0               [24] 3608 	movx	a,@dptr
                                   3609 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006E39 F5 82            [12] 3610 	mov	dpl,a
      006E3B 22               [24] 3611 	ret
                                   3612 ;------------------------------------------------------------
                                   3613 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3614 ;------------------------------------------------------------
                                   3615 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3616 ;	-----------------------------------------
                                   3617 ;	 function raw_request_is_nonpersistent
                                   3618 ;	-----------------------------------------
      006E3C                       3619 _raw_request_is_nonpersistent:
                                   3620 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006E3C 90 07 D6         [24] 3621 	mov	dptr,#_raw_buffer
      006E3F E0               [24] 3622 	movx	a,@dptr
      006E40 FF               [12] 3623 	mov	r7,a
      006E41 BF 01 02         [24] 3624 	cjne	r7,#0x01,00302$
      006E44 80 35            [24] 3625 	sjmp	00108$
      006E46                       3626 00302$:
      006E46 BF 02 02         [24] 3627 	cjne	r7,#0x02,00303$
      006E49 80 34            [24] 3628 	sjmp	00109$
      006E4B                       3629 00303$:
      006E4B BF 04 02         [24] 3630 	cjne	r7,#0x04,00304$
      006E4E 80 2B            [24] 3631 	sjmp	00108$
      006E50                       3632 00304$:
      006E50 BF 08 02         [24] 3633 	cjne	r7,#0x08,00305$
      006E53 80 47            [24] 3634 	sjmp	00116$
      006E55                       3635 00305$:
      006E55 BF 0B 02         [24] 3636 	cjne	r7,#0x0b,00306$
      006E58 80 21            [24] 3637 	sjmp	00108$
      006E5A                       3638 00306$:
      006E5A BF 0C 02         [24] 3639 	cjne	r7,#0x0c,00307$
      006E5D 80 1C            [24] 3640 	sjmp	00108$
      006E5F                       3641 00307$:
      006E5F BF 0D 02         [24] 3642 	cjne	r7,#0x0d,00308$
      006E62 80 17            [24] 3643 	sjmp	00108$
      006E64                       3644 00308$:
      006E64 BF 0E 02         [24] 3645 	cjne	r7,#0x0e,00309$
      006E67 80 12            [24] 3646 	sjmp	00108$
      006E69                       3647 00309$:
      006E69 BF 11 02         [24] 3648 	cjne	r7,#0x11,00310$
      006E6C 80 0D            [24] 3649 	sjmp	00108$
      006E6E                       3650 00310$:
      006E6E BF 12 02         [24] 3651 	cjne	r7,#0x12,00311$
      006E71 80 08            [24] 3652 	sjmp	00108$
      006E73                       3653 00311$:
      006E73 BF FE 02         [24] 3654 	cjne	r7,#0xfe,00312$
      006E76 80 46            [24] 3655 	sjmp	00124$
      006E78                       3656 00312$:
      006E78 02 6F 13         [24] 3657 	ljmp	00144$
                                   3658 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006E7B                       3659 00108$:
                                   3660 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006E7B 75 82 01         [24] 3661 	mov	dpl, #0x01
      006E7E 22               [24] 3662 	ret
                                   3663 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006E7F                       3664 00109$:
                                   3665 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006E7F 12 71 67         [24] 3666 	lcall	_ak820_outline_0159
      006E82 BF 01 02         [24] 3667 	cjne	r7,#0x01,00313$
      006E85 80 0D            [24] 3668 	sjmp	00113$
      006E87                       3669 00313$:
      006E87 BF 02 02         [24] 3670 	cjne	r7,#0x02,00314$
      006E8A 80 08            [24] 3671 	sjmp	00113$
      006E8C                       3672 00314$:
      006E8C BF 03 02         [24] 3673 	cjne	r7,#0x03,00315$
      006E8F 80 03            [24] 3674 	sjmp	00113$
      006E91                       3675 00315$:
      006E91 BF 04 04         [24] 3676 	cjne	r7,#0x04,00114$
                                   3677 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006E94                       3678 00113$:
                                   3679 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006E94 75 82 01         [24] 3680 	mov	dpl, #0x01
      006E97 22               [24] 3681 	ret
                                   3682 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006E98                       3683 00114$:
      006E98 75 82 00         [24] 3684 	mov	dpl, #0x00
      006E9B 22               [24] 3685 	ret
                                   3686 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006E9C                       3687 00116$:
                                   3688 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006E9C 12 71 67         [24] 3689 	lcall	_ak820_outline_0159
      006E9F BF 40 02         [24] 3690 	cjne	r7,#0x40,00318$
      006EA2 80 12            [24] 3691 	sjmp	00121$
      006EA4                       3692 00318$:
      006EA4 BF 41 02         [24] 3693 	cjne	r7,#0x41,00319$
      006EA7 80 0D            [24] 3694 	sjmp	00121$
      006EA9                       3695 00319$:
      006EA9 BF 42 02         [24] 3696 	cjne	r7,#0x42,00320$
      006EAC 80 08            [24] 3697 	sjmp	00121$
      006EAE                       3698 00320$:
      006EAE BF 43 02         [24] 3699 	cjne	r7,#0x43,00321$
      006EB1 80 03            [24] 3700 	sjmp	00121$
      006EB3                       3701 00321$:
      006EB3 BF 44 04         [24] 3702 	cjne	r7,#0x44,00122$
                                   3703 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006EB6                       3704 00121$:
                                   3705 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006EB6 75 82 01         [24] 3706 	mov	dpl, #0x01
                                   3707 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006EB9 22               [24] 3708 	ret
      006EBA                       3709 00122$:
      006EBA 75 82 00         [24] 3710 	mov	dpl, #0x00
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006EBD 22               [24] 3712 	ret
      006EBE                       3713 00124$:
                                   3714 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006EBE 12 71 67         [24] 3715 	lcall	_ak820_outline_0159
      006EC1 24 F2            [12] 3716 	add	a,#0xff - 0x0d
      006EC3 40 4A            [24] 3717 	jc	00142$
                                   3718 ;	free result
      006EC5 EF               [12] 3719 	mov	a,r7
      006EC6 24 0A            [12] 3720 	add	a,#(00325$-3-.)
      006EC8 83               [24] 3721 	movc	a,@a+pc
      006EC9 F5 82            [12] 3722 	mov	dpl,a
      006ECB EF               [12] 3723 	mov	a,r7
      006ECC 24 12            [12] 3724 	add	a,#(00326$-3-.)
      006ECE 83               [24] 3725 	movc	a,@a+pc
      006ECF F5 83            [12] 3726 	mov	dph,a
      006ED1 E4               [12] 3727 	clr	a
      006ED2 73               [24] 3728 	jmp	@a+dptr
      006ED3                       3729 00325$:
      006ED3 EF                    3730 	.db	00134$
      006ED4 EF                    3731 	.db	00134$
      006ED5 EF                    3732 	.db	00134$
      006ED6 EF                    3733 	.db	00134$
      006ED7 0F                    3734 	.db	00142$
      006ED8 EF                    3735 	.db	00134$
      006ED9 EF                    3736 	.db	00134$
      006EDA EF                    3737 	.db	00134$
      006EDB EF                    3738 	.db	00134$
      006EDC EF                    3739 	.db	00134$
      006EDD EF                    3740 	.db	00134$
      006EDE 0F                    3741 	.db	00142$
      006EDF 0F                    3742 	.db	00142$
      006EE0 F3                    3743 	.db	00135$
      006EE1                       3744 00326$:
      006EE1 6E                    3745 	.db	00134$>>8
      006EE2 6E                    3746 	.db	00134$>>8
      006EE3 6E                    3747 	.db	00134$>>8
      006EE4 6E                    3748 	.db	00134$>>8
      006EE5 6F                    3749 	.db	00142$>>8
      006EE6 6E                    3750 	.db	00134$>>8
      006EE7 6E                    3751 	.db	00134$>>8
      006EE8 6E                    3752 	.db	00134$>>8
      006EE9 6E                    3753 	.db	00134$>>8
      006EEA 6E                    3754 	.db	00134$>>8
      006EEB 6E                    3755 	.db	00134$>>8
      006EEC 6F                    3756 	.db	00142$>>8
      006EED 6F                    3757 	.db	00142$>>8
      006EEE 6E                    3758 	.db	00135$>>8
                                   3759 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006EEF                       3760 00134$:
                                   3761 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006EEF 75 82 01         [24] 3762 	mov	dpl, #0x01
                                   3763 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006EF2 22               [24] 3764 	ret
      006EF3                       3765 00135$:
                                   3766 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006EF3 90 07 D8         [24] 3767 	mov	dptr,#(_raw_buffer + 0x0002)
      006EF6 E0               [24] 3768 	movx	a,@dptr
      006EF7 FF               [12] 3769 	mov	r7,a
      006EF8 60 0D            [24] 3770 	jz	00139$
      006EFA BF 01 02         [24] 3771 	cjne	r7,#0x01,00328$
      006EFD 80 08            [24] 3772 	sjmp	00139$
      006EFF                       3773 00328$:
      006EFF BF 03 02         [24] 3774 	cjne	r7,#0x03,00329$
      006F02 80 03            [24] 3775 	sjmp	00139$
      006F04                       3776 00329$:
      006F04 BF 05 04         [24] 3777 	cjne	r7,#0x05,00140$
                                   3778 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006F07                       3779 00139$:
                                   3780 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006F07 75 82 01         [24] 3781 	mov	dpl, #0x01
                                   3782 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006F0A 22               [24] 3783 	ret
      006F0B                       3784 00140$:
      006F0B 75 82 00         [24] 3785 	mov	dpl, #0x00
                                   3786 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006F0E 22               [24] 3787 	ret
      006F0F                       3788 00142$:
      006F0F 75 82 00         [24] 3789 	mov	dpl, #0x00
                                   3790 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006F12 22               [24] 3791 	ret
      006F13                       3792 00144$:
      006F13 75 82 00         [24] 3793 	mov	dpl, #0x00
                                   3794 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3795 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      006F16 22               [24] 3796 	ret
                                   3797 ;------------------------------------------------------------
                                   3798 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3799 ;------------------------------------------------------------
                                   3800 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3801 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_460'
                                   3802 ;------------------------------------------------------------
                                   3803 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3804 ;	-----------------------------------------
                                   3805 ;	 function ak820_usb_raw_send
                                   3806 ;	-----------------------------------------
      006F17                       3807 _ak820_usb_raw_send:
      006F17 12 48 59         [24] 3808 	lcall	_ak820_outline_0036
      006F1A 90 08 3E         [24] 3809 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006F1D 12 3A 1F         [24] 3810 	lcall	_ak820_outline_0015
                                   3811 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      006F20 90 08 3D         [24] 3812 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006F23 E0               [24] 3813 	movx	a,@dptr
      006F24 FF               [12] 3814 	mov	r7,a
      006F25 BF 20 2B         [24] 3815 	cjne	r7,#0x20,00106$
                                   3816 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      006F28 C0 07            [24] 3817 	push	ar7
      006F2A 12 43 6F         [24] 3818 	lcall	_ak820_nvm_flush
      006F2D D0 07            [24] 3819 	pop	ar7
                                   3820 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006F2F 90 07 F6         [24] 3821 	mov	dptr,#_raw_reply_without_nvm
      006F32 E0               [24] 3822 	movx	a,@dptr
      006F33 70 07            [24] 3823 	jnz	00103$
      006F35 12 43 60         [24] 3824 	lcall	_ak820_nvm_ok
      006F38 E5 82            [12] 3825 	mov	a, dpl
      006F3A 60 17            [24] 3826 	jz	00106$
      006F3C                       3827 00103$:
      006F3C 90 08 3E         [24] 3828 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006F3F 12 48 90         [24] 3829 	lcall	_ak820_outline_0094
      006F42 90 08 33         [24] 3830 	mov	dptr,#_ak820_usb_send_PARM_2
      006F45 12 48 D3         [24] 3831 	lcall	_ak820_outline_0157
      006F48 90 08 35         [24] 3832 	mov	dptr,#_ak820_usb_send_PARM_3
      006F4B EF               [12] 3833 	mov	a,r7
      006F4C F0               [24] 3834 	movx	@dptr,a
      006F4D 75 82 03         [24] 3835 	mov	dpl, #0x03
                                   3836 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      006F50 02 6C 2D         [24] 3837 	ljmp	_ak820_usb_send
      006F53                       3838 00106$:
      006F53 22               [24] 3839 	ret
                                   3840 ;------------------------------------------------------------
                                   3841 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3842 ;------------------------------------------------------------
                                   3843 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3844 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_465'
                                   3845 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_465'
                                   3846 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_465'
                                   3847 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_465'
                                   3848 ;------------------------------------------------------------
                                   3849 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3850 ;	-----------------------------------------
                                   3851 ;	 function ak820_usb_raw_task
                                   3852 ;	-----------------------------------------
      006F54                       3853 _ak820_usb_raw_task:
                                   3854 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      006F54 A2 AF            [12] 3855 	mov	c,_EA
      006F56 E4               [12] 3856 	clr	a
      006F57 33               [12] 3857 	rlc	a
      006F58 FF               [12] 3858 	mov	r7,a
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3860 ;	assignBit
      006F59 C2 AF            [12] 3861 	clr	_EA
                                   3862 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006F5B 90 07 CE         [24] 3863 	mov	dptr,#_USB_EnumStatus
      006F5E E0               [24] 3864 	movx	a,@dptr
      006F5F 60 0A            [24] 3865 	jz	00101$
      006F61 90 07 D5         [24] 3866 	mov	dptr,#_raw_state
      006F64 E0               [24] 3867 	movx	a,@dptr
      006F65 FE               [12] 3868 	mov	r6,a
      006F66 BE 02 02         [24] 3869 	cjne	r6,#0x02,00270$
      006F69 80 06            [24] 3870 	sjmp	00102$
      006F6B                       3871 00270$:
      006F6B                       3872 00101$:
                                   3873 ;	assignBit
      006F6B EF               [12] 3874 	mov	a,r7
      006F6C 24 FF            [12] 3875 	add	a,#0xff
      006F6E 92 AF            [24] 3876 	mov	_EA,c
      006F70 22               [24] 3877 	ret
      006F71                       3878 00102$:
                                   3879 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      006F71 90 07 D5         [24] 3880 	mov	dptr,#_raw_state
      006F74 74 03            [12] 3881 	mov	a,#0x03
      006F76 F0               [24] 3882 	movx	@dptr,a
                                   3883 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3884 ;	assignBit
      006F77 EF               [12] 3885 	mov	a,r7
      006F78 24 FF            [12] 3886 	add	a,#0xff
      006F7A 92 AF            [24] 3887 	mov	_EA,c
                                   3888 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006F7C 90 07 D6         [24] 3889 	mov	dptr,#_raw_buffer
      006F7F E0               [24] 3890 	movx	a,@dptr
      006F80 FF               [12] 3891 	mov	r7,a
      006F81 E4               [12] 3892 	clr	a
      006F82 BF FD 01         [24] 3893 	cjne	r7,#0xfd,00271$
      006F85 04               [12] 3894 	inc	a
      006F86                       3895 00271$:
      006F86 FF               [12] 3896 	mov	r7,a
      006F87 70 03            [24] 3897 	jnz	00273$
      006F89 02 70 29         [24] 3898 	ljmp	00118$
      006F8C                       3899 00273$:
      006F8C 90 07 D7         [24] 3900 	mov	dptr,#(_raw_buffer + 0x0001)
      006F8F E0               [24] 3901 	movx	a,@dptr
      006F90 60 03            [24] 3902 	jz	00274$
      006F92 02 70 29         [24] 3903 	ljmp	00118$
      006F95                       3904 00274$:
                                   3905 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006F95 90 07 D8         [24] 3906 	mov	dptr,#(_raw_buffer + 0x0002)
      006F98 E0               [24] 3907 	movx	a,@dptr
      006F99 FD               [12] 3908 	mov	r5,a
      006F9A 7E 00            [12] 3909 	mov	r6,#0x00
      006F9C 90 07 D9         [24] 3910 	mov	dptr,#(_raw_buffer + 0x0003)
      006F9F E0               [24] 3911 	movx	a,@dptr
      006FA0 7B 00            [12] 3912 	mov	r3,#0x00
      006FA2 42 06            [12] 3913 	orl	ar6,a
      006FA4 EB               [12] 3914 	mov	a,r3
      006FA5 42 05            [12] 3915 	orl	ar5,a
                                   3916 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      006FA7 90 07 DA         [24] 3917 	mov	dptr,#(_raw_buffer + 0x0004)
      006FAA E0               [24] 3918 	movx	a,@dptr
      006FAB FC               [12] 3919 	mov	r4,a
                                   3920 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006FAC 7B 05            [12] 3921 	mov	r3,#0x05
      006FAE                       3922 00128$:
      006FAE EB               [12] 3923 	mov	a,r3
      006FAF 12 71 55         [24] 3924 	lcall	_ak820_outline_0101
      006FB2 0B               [12] 3925 	inc	r3
      006FB3 BB 20 00         [24] 3926 	cjne	r3,#0x20,00275$
      006FB6                       3927 00275$:
      006FB6 40 F6            [24] 3928 	jc	00128$
                                   3929 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006FB8 EC               [12] 3930 	mov	a,r4
      006FB9 24 E4            [12] 3931 	add	a,#0xff - 0x1b
      006FBB 40 1C            [24] 3932 	jc	00106$
                                   3933 ;	free result
      006FBD EC               [12] 3934 	mov	a,r4
      006FBE 60 26            [24] 3935 	jz	00165$
      006FC0 8C 03            [24] 3936 	mov	ar3,r4
      006FC2 1B               [12] 3937 	dec	r3
      006FC3 7A 00            [12] 3938 	mov	r2,#0x00
      006FC5 74 FF            [12] 3939 	mov	a,#0xff
      006FC7 C3               [12] 3940 	clr	c
      006FC8 9B               [12] 3941 	subb	a,r3
      006FC9 FB               [12] 3942 	mov	r3,a
      006FCA 74 FF            [12] 3943 	mov	a,#0xff
      006FCC 9A               [12] 3944 	subb	a,r2
      006FCD FA               [12] 3945 	mov	r2,a
      006FCE 8E 00            [24] 3946 	mov	ar0,r6
      006FD0 8D 01            [24] 3947 	mov	ar1,r5
      006FD2 C3               [12] 3948 	clr	c
      006FD3 EB               [12] 3949 	mov	a,r3
      006FD4 98               [12] 3950 	subb	a,r0
      006FD5 EA               [12] 3951 	mov	a,r2
      006FD6 99               [12] 3952 	subb	a,r1
      006FD7 50 0D            [24] 3953 	jnc	00165$
                                   3954 ;	free result
      006FD9                       3955 00106$:
                                   3956 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      006FD9 90 07 D7         [24] 3957 	mov	dptr,#(_raw_buffer + 0x0001)
      006FDC 74 FF            [12] 3958 	mov	a,#0xff
      006FDE F0               [24] 3959 	movx	@dptr,a
                                   3960 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      006FDF 90 07 DA         [24] 3961 	mov	dptr,#(_raw_buffer + 0x0004)
      006FE2 E4               [12] 3962 	clr	a
      006FE3 F0               [24] 3963 	movx	@dptr,a
                                   3964 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006FE4 80 3A            [24] 3965 	sjmp	00108$
      006FE6                       3966 00165$:
      006FE6 7B 00            [12] 3967 	mov	r3,#0x00
      006FE8                       3968 00131$:
      006FE8 C3               [12] 3969 	clr	c
      006FE9 EB               [12] 3970 	mov	a,r3
      006FEA 9C               [12] 3971 	subb	a,r4
      006FEB 50 33            [24] 3972 	jnc	00108$
      006FED C0 04            [24] 3973 	push	ar4
      006FEF 8B 02            [24] 3974 	mov	ar2,r3
      006FF1 74 05            [12] 3975 	mov	a,#0x05
      006FF3 2A               [12] 3976 	add	a, r2
      006FF4 F9               [12] 3977 	mov	r1,a
      006FF5 33               [12] 3978 	rlc	a
      006FF6 95 E0            [12] 3979 	subb	a,acc
      006FF8 FA               [12] 3980 	mov	r2,a
      006FF9 E9               [12] 3981 	mov	a,r1
      006FFA 24 D6            [12] 3982 	add	a, #_raw_buffer
      006FFC F9               [12] 3983 	mov	r1,a
      006FFD EA               [12] 3984 	mov	a,r2
      006FFE 34 07            [12] 3985 	addc	a, #(_raw_buffer >> 8)
      007000 FA               [12] 3986 	mov	r2,a
      007001 8B 1E            [24] 3987 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      007003 75 1F 00         [24] 3988 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      007006 8E 00            [24] 3989 	mov	ar0,r6
      007008 8D 04            [24] 3990 	mov	ar4,r5
      00700A E5 1E            [12] 3991 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      00700C 28               [12] 3992 	add	a, r0
      00700D F8               [12] 3993 	mov	r0,a
      00700E E5 1F            [12] 3994 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      007010 3C               [12] 3995 	addc	a, r4
      007011 FC               [12] 3996 	mov	r4,a
      007012 88 82            [24] 3997 	mov	dpl,r0
      007014 8C 83            [24] 3998 	mov	dph,r4
      007016 E4               [12] 3999 	clr	a
      007017 93               [24] 4000 	movc	a,@a+dptr
      007018 12 71 61         [24] 4001 	lcall	_ak820_outline_0136
      00701B 0B               [12] 4002 	inc	r3
      00701C D0 04            [24] 4003 	pop	ar4
      00701E 80 C8            [24] 4004 	sjmp	00131$
      007020                       4005 00108$:
                                   4006 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      007020 12 71 41         [24] 4007 	lcall	_ak820_outline_0041
      007023 12 6C 2D         [24] 4008 	lcall	_ak820_usb_send
      007026 02 70 CF         [24] 4009 	ljmp	00119$
      007029                       4010 00118$:
                                   4011 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      007029 EF               [12] 4012 	mov	a,r7
      00702A 70 03            [24] 4013 	jnz	00281$
      00702C 02 70 AC         [24] 4014 	ljmp	00114$
      00702F                       4015 00281$:
      00702F 12 71 67         [24] 4016 	lcall	_ak820_outline_0159
      007032 BF 01 02         [24] 4017 	cjne	r7,#0x01,00282$
      007035 80 03            [24] 4018 	sjmp	00283$
      007037                       4019 00282$:
      007037 02 70 AC         [24] 4020 	ljmp	00114$
      00703A                       4021 00283$:
                                   4022 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      00703A 7F 02            [12] 4023 	mov	r7,#0x02
      00703C                       4024 00133$:
      00703C EF               [12] 4025 	mov	a,r7
      00703D 12 71 55         [24] 4026 	lcall	_ak820_outline_0101
      007040 0F               [12] 4027 	inc	r7
      007041 BF 20 00         [24] 4028 	cjne	r7,#0x20,00284$
      007044                       4029 00284$:
      007044 40 F6            [24] 4030 	jc	00133$
                                   4031 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      007046 90 07 D8         [24] 4032 	mov	dptr,#(_raw_buffer + 0x0002)
      007049 74 01            [12] 4033 	mov	a,#0x01
      00704B F0               [24] 4034 	movx	@dptr,a
                                   4035 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      00704C 90 07 D9         [24] 4036 	mov	dptr,#(_raw_buffer + 0x0003)
      00704F 74 A8            [12] 4037 	mov	a,#0xa8
      007051 F0               [24] 4038 	movx	@dptr,a
                                   4039 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      007052 90 07 DA         [24] 4040 	mov	dptr,#(_raw_buffer + 0x0004)
      007055 12 40 DE         [24] 4041 	lcall	_ak820_nvm_diagnostic
                                   4042 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      007058 7F 00            [12] 4043 	mov	r7,#0x00
      00705A                       4044 00135$:
      00705A 8F 06            [24] 4045 	mov	ar6,r7
      00705C 74 0B            [12] 4046 	mov	a,#0x0b
      00705E 2E               [12] 4047 	add	a, r6
      00705F 24 D6            [12] 4048 	add	a,#_raw_buffer
      007061 FE               [12] 4049 	mov	r6,a
      007062 E4               [12] 4050 	clr	a
      007063 34 07            [12] 4051 	addc	a, #(_raw_buffer >> 8)
      007065 FD               [12] 4052 	mov	r5,a
      007066 EF               [12] 4053 	mov	a,r7
      007067 24 C6            [12] 4054 	add	a, #_ak820_flash_diagnostic
      007069 F5 82            [12] 4055 	mov	dpl,a
      00706B E4               [12] 4056 	clr	a
      00706C 34 04            [12] 4057 	addc	a, #(_ak820_flash_diagnostic >> 8)
      00706E F5 83            [12] 4058 	mov	dph,a
      007070 E0               [24] 4059 	movx	a,@dptr
      007071 8E 82            [24] 4060 	mov	dpl,r6
      007073 8D 83            [24] 4061 	mov	dph,r5
      007075 F0               [24] 4062 	movx	@dptr,a
      007076 0F               [12] 4063 	inc	r7
      007077 BF 06 00         [24] 4064 	cjne	r7,#0x06,00286$
      00707A                       4065 00286$:
      00707A 40 DE            [24] 4066 	jc	00135$
                                   4067 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      00707C 90 0E 57         [24] 4068 	mov	dptr,#_vial_unlocked
      00707F E0               [24] 4069 	movx	a,@dptr
      007080 90 07 E7         [24] 4070 	mov	dptr,#(_raw_buffer + 0x0011)
      007083 F0               [24] 4071 	movx	@dptr,a
                                   4072 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      007084 90 0E 58         [24] 4073 	mov	dptr,#_vial_unlock_in_progress
      007087 E0               [24] 4074 	movx	a,@dptr
      007088 90 07 E8         [24] 4075 	mov	dptr,#(_raw_buffer + 0x0012)
      00708B F0               [24] 4076 	movx	@dptr,a
                                   4077 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      00708C 90 07 CE         [24] 4078 	mov	dptr,#_USB_EnumStatus
      00708F E0               [24] 4079 	movx	a,@dptr
      007090 90 07 E9         [24] 4080 	mov	dptr,#(_raw_buffer + 0x0013)
      007093 F0               [24] 4081 	movx	@dptr,a
                                   4082 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      007094 90 07 CF         [24] 4083 	mov	dptr,#_USB_SleepStatus
      007097 E0               [24] 4084 	movx	a,@dptr
      007098 90 07 EA         [24] 4085 	mov	dptr,#(_raw_buffer + 0x0014)
      00709B F0               [24] 4086 	movx	@dptr,a
                                   4087 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      00709C 90 07 D5         [24] 4088 	mov	dptr,#_raw_state
      00709F E0               [24] 4089 	movx	a,@dptr
      0070A0 90 07 EB         [24] 4090 	mov	dptr,#(_raw_buffer + 0x0015)
      0070A3 F0               [24] 4091 	movx	@dptr,a
                                   4092 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      0070A4 12 71 41         [24] 4093 	lcall	_ak820_outline_0041
      0070A7 12 6C 2D         [24] 4094 	lcall	_ak820_usb_send
      0070AA 80 23            [24] 4095 	sjmp	00119$
      0070AC                       4096 00114$:
                                   4097 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      0070AC 12 6E 3C         [24] 4098 	lcall	_raw_request_is_nonpersistent
      0070AF E5 82            [12] 4099 	mov	a, dpl
      0070B1 90 07 F6         [24] 4100 	mov	dptr,#_raw_reply_without_nvm
      0070B4 F0               [24] 4101 	movx	@dptr,a
                                   4102 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      0070B5 12 44 C2         [24] 4103 	lcall	_ak820_nvm_begin
                                   4104 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      0070B8 90 0C 88         [24] 4105 	mov	dptr,#_raw_hid_receive_PARM_2
      0070BB 74 20            [12] 4106 	mov	a,#0x20
      0070BD F0               [24] 4107 	movx	@dptr,a
      0070BE 90 07 D6         [24] 4108 	mov	dptr,#_raw_buffer
      0070C1 75 F0 00         [24] 4109 	mov	b, #0x00
      0070C4 12 AA 2E         [24] 4110 	lcall	_raw_hid_receive
                                   4111 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      0070C7 12 44 D7         [24] 4112 	lcall	_ak820_nvm_end
                                   4113 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      0070CA 90 07 F6         [24] 4114 	mov	dptr,#_raw_reply_without_nvm
      0070CD E4               [12] 4115 	clr	a
      0070CE F0               [24] 4116 	movx	@dptr,a
      0070CF                       4117 00119$:
                                   4118 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4119 ;	assignBit
      0070CF A2 AF            [12] 4120 	mov	c,_EA
      0070D1 92 1D            [24] 4121 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4123 ;	assignBit
      0070D3 C2 AF            [12] 4124 	clr	_EA
                                   4125 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      0070D5 12 71 6D         [24] 4126 	lcall	_ak820_outline_0161
      0070D8 BF 04 08         [24] 4127 	cjne	r7,#0x04,00126$
      0070DB 90 07 D5         [24] 4128 	mov	dptr,#_raw_state
      0070DE 74 05            [12] 4129 	mov	a,#0x05
      0070E0 F0               [24] 4130 	movx	@dptr,a
      0070E1 80 1B            [24] 4131 	sjmp	00127$
      0070E3                       4132 00126$:
                                   4133 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      0070E3 12 71 6D         [24] 4134 	lcall	_ak820_outline_0161
      0070E6 BF 03 02         [24] 4135 	cjne	r7,#0x03,00290$
      0070E9 80 0E            [24] 4136 	sjmp	00121$
      0070EB                       4137 00290$:
      0070EB 12 71 6D         [24] 4138 	lcall	_ak820_outline_0161
      0070EE BF 06 02         [24] 4139 	cjne	r7,#0x06,00291$
      0070F1 80 06            [24] 4140 	sjmp	00121$
      0070F3                       4141 00291$:
      0070F3 12 71 6D         [24] 4142 	lcall	_ak820_outline_0161
      0070F6 BF 07 05         [24] 4143 	cjne	r7,#0x07,00127$
      0070F9                       4144 00121$:
      0070F9 90 07 D5         [24] 4145 	mov	dptr,#_raw_state
      0070FC E4               [12] 4146 	clr	a
      0070FD F0               [24] 4147 	movx	@dptr,a
      0070FE                       4148 00127$:
                                   4149 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4150 ;	assignBit
      0070FE A2 1D            [12] 4151 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      007100 92 AF            [24] 4152 	mov	_EA,c
                                   4153 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      007102 22               [24] 4154 	ret
                                   4155 ;------------------------------------------------------------
                                   4156 ;Allocation info for local variables in function 'ak820_usb_keyboard_blocked'
                                   4157 ;------------------------------------------------------------
                                   4158 ;	tmk_core/protocol/ch555/usb_ak820.c:707: bool ak820_usb_keyboard_blocked(void) {
                                   4159 ;	-----------------------------------------
                                   4160 ;	 function ak820_usb_keyboard_blocked
                                   4161 ;	-----------------------------------------
      007103                       4162 _ak820_usb_keyboard_blocked:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:708: return !USB_EnumStatus || (USB_SleepStatus & 2) || keyboard_reset;
      007103 90 07 CE         [24] 4164 	mov	dptr,#_USB_EnumStatus
      007106 E0               [24] 4165 	movx	a,@dptr
      007107 60 13            [24] 4166 	jz	00104$
      007109 90 07 CF         [24] 4167 	mov	dptr,#_USB_SleepStatus
      00710C E0               [24] 4168 	movx	a,@dptr
      00710D 03               [12] 4169 	rr	a
      00710E 54 01            [12] 4170 	anl	a,#0x01
      007110 70 0A            [24] 4171 	jnz	00104$
      007112 90 07 F7         [24] 4172 	mov	dptr,#_keyboard_reset
      007115 E0               [24] 4173 	movx	a,@dptr
      007116 70 04            [24] 4174 	jnz	00104$
                                   4175 ;	assignBit
      007118 C2 1E            [12] 4176 	clr	_ak820_usb_keyboard_blocked_sloc0_1_0
      00711A 80 02            [24] 4177 	sjmp	00105$
      00711C                       4178 00104$:
                                   4179 ;	assignBit
      00711C D2 1E            [12] 4180 	setb	_ak820_usb_keyboard_blocked_sloc0_1_0
      00711E                       4181 00105$:
      00711E A2 1E            [12] 4182 	mov	c,_ak820_usb_keyboard_blocked_sloc0_1_0
      007120 E4               [12] 4183 	clr	a
      007121 33               [12] 4184 	rlc	a
      007122 F5 82            [12] 4185 	mov	dpl, a
                                   4186 ;	tmk_core/protocol/ch555/usb_ak820.c:709: }
      007124 22               [24] 4187 	ret
                                   4188 ;------------------------------------------------------------
                                   4189 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4190 ;------------------------------------------------------------
                                   4191 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_485'
                                   4192 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_485'
                                   4193 ;------------------------------------------------------------
                                   4194 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4195 ;	-----------------------------------------
                                   4196 ;	 function ak820_usb_take_keyboard_reset
                                   4197 ;	-----------------------------------------
      007125                       4198 _ak820_usb_take_keyboard_reset:
                                   4199 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4200 ;	assignBit
      007125 A2 AF            [12] 4201 	mov	c,_EA
      007127 92 1F            [24] 4202 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4203 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4204 ;	assignBit
      007129 C2 AF            [12] 4205 	clr	_EA
                                   4206 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      00712B 90 07 F7         [24] 4207 	mov	dptr,#_keyboard_reset
      00712E E0               [24] 4208 	movx	a,@dptr
      00712F FF               [12] 4209 	mov	r7,a
                                   4210 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      007130 E4               [12] 4211 	clr	a
      007131 F0               [24] 4212 	movx	@dptr,a
                                   4213 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4214 ;	assignBit
      007132 A2 1F            [12] 4215 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      007134 92 AF            [24] 4216 	mov	_EA,c
                                   4217 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      007136 EF               [12] 4218 	mov	a,r7
      007137 B4 01 00         [24] 4219 	cjne	a,#0x01,00103$
      00713A                       4220 00103$:
      00713A B3               [12] 4221 	cpl	c
      00713B 92 1F            [24] 4222 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      00713D 12 3A C6         [24] 4223 	lcall	_ak820_outline_0166
                                   4224 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      007140 22               [24] 4225 	ret
                                   4226 	.area CSEG    (CODE)
                                   4227 	.area CONST   (CODE)
                                   4228 	.area CONST   (CODE)
      00BCE9                       4229 _shared_offsets:
      00BCE9 00                    4230 	.db #0x00	; 0
      00BCEA 00                    4231 	.db #0x00	; 0
      00BCEB 28                    4232 	.db #0x28	; 40
      00BCEC 28                    4233 	.db #0x28	; 40
      00BCED 2B                    4234 	.db #0x2b	; 43
      00BCEE 00                    4235 	.db #0x00	; 0
      00BCEF 08                    4236 	.db #0x08	; 8
                                   4237 	.area CSEG    (CODE)
                                   4238 	.area CONST   (CODE)
      00BCF0                       4239 _shared_lengths:
      00BCF0 00                    4240 	.db #0x00	; 0
      00BCF1 00                    4241 	.db #0x00	; 0
      00BCF2 00                    4242 	.db #0x00	; 0
      00BCF3 03                    4243 	.db #0x03	; 3
      00BCF4 03                    4244 	.db #0x03	; 3
      00BCF5 00                    4245 	.db #0x00	; 0
      00BCF6 20                    4246 	.db #0x20	; 32
                                   4247 	.area CSEG    (CODE)
                                   4248 	.area CONST   (CODE)
      00BCF7                       4249 _interface_descriptors:
      00BCF7 92 C2                 4250 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BCF9 92 C3                 4251 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BCFB 45 C3                 4252 	.byte _RawReport, (_RawReport >> 8)
      00BCFD AB C3                 4253 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BCFF D7 C2                 4254 	.byte _SharedReport, (_SharedReport >> 8)
      00BD01 C4 C3                 4255 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4256 	.area CSEG    (CODE)
                                   4257 	.area XINIT   (CODE)
                                   4258 	.area CABS    (ABS,CODE)
                                   4259 
                                   4260 ; Experimental exact instruction outlining.
                                   4261 	.globl _ak820_outline_0015
                                   4262 	.globl _ak820_outline_0036
                                   4263 	.globl _ak820_outline_0041
                                   4264 	.globl _ak820_outline_0094
                                   4265 	.globl _ak820_outline_0101
                                   4266 	.globl _ak820_outline_0136
                                   4267 	.globl _ak820_outline_0157
                                   4268 	.globl _ak820_outline_0159
                                   4269 	.globl _ak820_outline_0161
                                   4270 	.globl _ak820_outline_0166
                                   4271 
                                   4272 	.area CSEG (CODE)
                                   4273 ; function ak820_outline_0041
      007141                       4274 _ak820_outline_0041:
      007141 90 08 33         [24] 4275 	mov	dptr,#_ak820_usb_send_PARM_2
      007144 74 D6            [12] 4276 	mov	a,#_raw_buffer
      007146 F0               [24] 4277 	movx	@dptr,a
      007147 74 07            [12] 4278 	mov	a,#(_raw_buffer>>8)
      007149 A3               [24] 4279 	inc	dptr
      00714A F0               [24] 4280 	movx	@dptr,a
      00714B 90 08 35         [24] 4281 	mov	dptr,#_ak820_usb_send_PARM_3
      00714E 74 20            [12] 4282 	mov	a,#0x20
      007150 F0               [24] 4283 	movx	@dptr,a
      007151 75 82 03         [24] 4284 	mov	dpl,#0x03
      007154 22               [24] 4285 	ret
                                   4286 
                                   4287 	.area CSEG (CODE)
                                   4288 ; function ak820_outline_0101
      007155                       4289 _ak820_outline_0101:
      007155 24 D6            [12] 4290 	add	a,#_raw_buffer
      007157 F5 82            [12] 4291 	mov	dpl,a
      007159 E4               [12] 4292 	clr	a
      00715A 34 07            [12] 4293 	addc	a,#(_raw_buffer>>8)
      00715C F5 83            [12] 4294 	mov	dph,a
      00715E E4               [12] 4295 	clr	a
      00715F F0               [24] 4296 	movx	@dptr,a
      007160 22               [24] 4297 	ret
                                   4298 
                                   4299 	.area CSEG (CODE)
                                   4300 ; function ak820_outline_0136
      007161                       4301 _ak820_outline_0136:
      007161 89 82            [24] 4302 	mov	dpl,r1
      007163 8A 83            [24] 4303 	mov	dph,r2
      007165 F0               [24] 4304 	movx	@dptr,a
      007166 22               [24] 4305 	ret
                                   4306 
                                   4307 	.area CSEG (CODE)
                                   4308 ; function ak820_outline_0159
      007167                       4309 _ak820_outline_0159:
      007167 90 07 D7         [24] 4310 	mov	dptr,#(_raw_buffer+0x0001)
      00716A E0               [24] 4311 	movx	a,@dptr
      00716B FF               [12] 4312 	mov	r7,a
      00716C 22               [24] 4313 	ret
                                   4314 
                                   4315 	.area CSEG (CODE)
                                   4316 ; function ak820_outline_0161
      00716D                       4317 _ak820_outline_0161:
      00716D 90 07 D5         [24] 4318 	mov	dptr,#_raw_state
      007170 E0               [24] 4319 	movx	a,@dptr
      007171 FF               [12] 4320 	mov	r7,a
      007172 22               [24] 4321 	ret
