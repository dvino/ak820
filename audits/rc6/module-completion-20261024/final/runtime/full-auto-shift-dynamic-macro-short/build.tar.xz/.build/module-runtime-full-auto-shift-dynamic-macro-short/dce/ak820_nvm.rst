                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000008                         91 _page_valid:
      000008                         92 	.ds 1
      000009                         93 _page_dirty:
      000009                         94 	.ds 1
      00000A                         95 _storage_failed:
      00000A                         96 	.ds 1
      00000B                         97 _ak820_nvm_ok_sloc0_1_0:
      00000B                         98 	.ds 1
      00000C                         99 _load_page_sloc0_1_0:
      00000C                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00057F                        109 _page_data:
      00057F                        110 	.ds 64
      0005BF                        111 _cached_page:
      0005BF                        112 	.ds 1
      0005C0                        113 _batch_depth:
      0005C0                        114 	.ds 1
      0005C1                        115 _first_failure_stage:
      0005C1                        116 	.ds 1
      0005C2                        117 _nvm_fail_stage_10000_20:
      0005C2                        118 	.ds 1
      0005C3                        119 _ak820_nvm_diagnostic_out_10000_23:
      0005C3                        120 	.ds 2
      0005C5                        121 _crc_byte_PARM_2:
      0005C5                        122 	.ds 1
      0005C6                        123 _crc_byte_crc_10000_25:
      0005C6                        124 	.ds 2
      0005C8                        125 _page_crc_crc_10000_30:
      0005C8                        126 	.ds 2
      0005CA                        127 _write_page_address_10000_32:
      0005CA                        128 	.ds 2
      0005CC                        129 _journal_header_valid_header_10000_39:
      0005CC                        130 	.ds 2
      0005CE                        131 _recover_journal_header_10000_46:
      0005CE                        132 	.ds 9
      0005D7                        133 _ak820_nvm_flush_header_10000_62:
      0005D7                        134 	.ds 9
      0005E0                        135 _ak820_nvm_flush_stage_10000_62:
      0005E0                        136 	.ds 1
      0005E1                        137 _load_page_page_10000_87:
      0005E1                        138 	.ds 1
      0005E2                        139 _read_offset_offset_10000_93:
      0005E2                        140 	.ds 2
      0005E4                        141 _eeprom_read_byte_addr_10000_97:
      0005E4                        142 	.ds 3
      0005E7                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      0005E7                        144 	.ds 3
      0005EA                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      0005EA                        146 	.ds 2
      0005EC                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      0005EC                        148 	.ds 2
      0005EE                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      0005EE                        150 	.ds 2
      0005F0                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      0005F0                        152 	.ds 3
      0005F3                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005F3                        154 	.ds 2
      0005F5                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005F5                        156 	.ds 2
      0005F7                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005F7                        158 	.ds 3
      0005FA                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005FA                        160 	.ds 2
      0005FC                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005FC                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      0040CA                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      0040CA E5 82            [12]  215 	mov	a,dpl
      0040CC 90 05 C2         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      0040CF F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      0040D0 20 0A 08         [24]  219 	jb	_storage_failed,00102$
      0040D3 90 05 C2         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      0040D6 E0               [24]  221 	movx	a,@dptr
      0040D7 90 05 C1         [24]  222 	mov	dptr,#_first_failure_stage
      0040DA F0               [24]  223 	movx	@dptr,a
      0040DB                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      0040DB D2 0A            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      0040DD 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      0040DE                        239 _ak820_nvm_diagnostic:
      0040DE 12 3A 8A         [24]  240 	lcall	_ak820_outline_0104
      0040E1 90 05 C3         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      0040E4 12 3A 8F         [24]  242 	lcall	_ak820_outline_0105
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      0040E7 90 05 C3         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      0040EA 12 3A 40         [24]  245 	lcall	_ak820_outline_0051
      0040ED A2 0A            [12]  246 	mov	c,_storage_failed
      0040EF E4               [12]  247 	clr	a
      0040F0 33               [12]  248 	rlc	a
      0040F1 12 48 A2         [24]  249 	lcall	_ak820_outline_0116
      0040F4 12 48 7D         [24]  250 	lcall	_ak820_outline_0060
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      0040F7 A3               [24]  252 	inc	dptr
      0040F8 A2 08            [12]  253 	mov	c,_page_valid
      0040FA E4               [12]  254 	clr	a
      0040FB 33               [12]  255 	rlc	a
      0040FC 12 48 51         [24]  256 	lcall	_ak820_outline_0029
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      0040FF A2 09            [12]  258 	mov	c,_page_dirty
      004101 E4               [12]  259 	clr	a
      004102 33               [12]  260 	rlc	a
      004103 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      004104 74 03            [12]  263 	mov	a,#0x03
      004106 12 48 CD         [24]  264 	lcall	_ak820_outline_0156
      004109 90 05 C0         [24]  265 	mov	dptr,#_batch_depth
      00410C E0               [24]  266 	movx	a,@dptr
      00410D 12 3A A0         [24]  267 	lcall	_ak820_outline_0121
      004110 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      004111 74 04            [12]  270 	mov	a,#0x04
      004113 12 48 CD         [24]  271 	lcall	_ak820_outline_0156
      004116 90 05 BF         [24]  272 	mov	dptr,#_cached_page
      004119 E0               [24]  273 	movx	a,@dptr
      00411A 12 3A A0         [24]  274 	lcall	_ak820_outline_0121
      00411D F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      00411E 12 48 47         [24]  277 	lcall	_ak820_outline_0009
      004121 E4               [12]  278 	clr	a
      004122 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      004123 74 06            [12]  281 	mov	a,#0x06
      004125 12 48 B2         [24]  282 	lcall	_ak820_outline_0134
      004128 90 05 C1         [24]  283 	mov	dptr,#_first_failure_stage
      00412B E0               [24]  284 	movx	a,@dptr
      00412C 12 48 A2         [24]  285 	lcall	_ak820_outline_0116
      00412F F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      004130 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      004131                        300 _crc_byte:
      004131 12 3A 8A         [24]  301 	lcall	_ak820_outline_0104
      004134 90 05 C6         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      004137 12 3A 8F         [24]  303 	lcall	_ak820_outline_0105
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      00413A 90 05 C5         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      00413D E0               [24]  306 	movx	a,@dptr
      00413E FF               [12]  307 	mov	r7,a
      00413F 7E 00            [12]  308 	mov	r6,#0x00
      004141 90 05 C6         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      004144 E0               [24]  310 	movx	a,@dptr
      004145 6E               [12]  311 	xrl	a,r6
      004146 F0               [24]  312 	movx	@dptr,a
      004147 A3               [24]  313 	inc	dptr
      004148 E0               [24]  314 	movx	a,@dptr
      004149 6F               [12]  315 	xrl	a,r7
      00414A F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      00414B 7F 00            [12]  318 	mov	r7,#0x00
      00414D                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      00414D 90 05 C6         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      004150 12 48 90         [24]  322 	lcall	_ak820_outline_0094
      004153 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      004156 ED               [12]  324 	mov	a,r5
      004157 2D               [12]  325 	add	a,r5
      004158 FB               [12]  326 	mov	r3,a
      004159 EE               [12]  327 	mov	a,r6
      00415A 33               [12]  328 	rlc	a
      00415B FC               [12]  329 	mov	r4,a
      00415C 63 03 21         [24]  330 	xrl	ar3,#0x21
      00415F 63 04 10         [24]  331 	xrl	ar4,#0x10
      004162 80 06            [24]  332 	sjmp	00107$
      004164                        333 00106$:
      004164 ED               [12]  334 	mov	a,r5
      004165 2D               [12]  335 	add	a,r5
      004166 FB               [12]  336 	mov	r3,a
      004167 EE               [12]  337 	mov	a,r6
      004168 33               [12]  338 	rlc	a
      004169 FC               [12]  339 	mov	r4,a
      00416A                        340 00107$:
      00416A 90 05 C6         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      00416D 12 3A 72         [24]  342 	lcall	_ak820_outline_0077
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      004170 0F               [12]  344 	inc	r7
      004171 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      004174 12 36 42         [24]  347 	lcall	_ak820_outline_0122
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      004177 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      004178                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      004178 90 05 C8         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      00417B 74 FF            [12]  363 	mov	a,#0xff
      00417D F0               [24]  364 	movx	@dptr,a
      00417E A3               [24]  365 	inc	dptr
      00417F F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      004180 7F 00            [12]  368 	mov	r7,#0x00
      004182                        369 00102$:
      004182 90 05 C8         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      004185 12 48 90         [24]  371 	lcall	_ak820_outline_0094
      004188 12 48 96         [24]  372 	lcall	_ak820_outline_0102
      00418B 90 05 C5         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      00418E F0               [24]  374 	movx	@dptr,a
      00418F 12 3A AA         [24]  375 	lcall	_ak820_outline_0132
      004192 C0 07            [24]  376 	push	ar7
      004194 12 41 31         [24]  377 	lcall	_crc_byte
      004197 AD 82            [24]  378 	mov	r5, dpl
      004199 AE 83            [24]  379 	mov	r6, dph
      00419B D0 07            [24]  380 	pop	ar7
      00419D 90 05 C8         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      0041A0 12 48 D3         [24]  382 	lcall	_ak820_outline_0157
      0041A3 0F               [12]  383 	inc	r7
      0041A4 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      0041A7 12 3A AA         [24]  386 	lcall	_ak820_outline_0132
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      0041AA 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      0041AB                        399 _write_page:
      0041AB 12 3A 8A         [24]  400 	lcall	_ak820_outline_0104
      0041AE 90 05 CA         [24]  401 	mov	dptr,#_write_page_address_10000_32
      0041B1 12 3A 8F         [24]  402 	lcall	_ak820_outline_0105
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      0041B4 90 05 CA         [24]  404 	mov	dptr,#_write_page_address_10000_32
      0041B7 12 39 E0         [24]  405 	lcall	_ak820_outline_0004
      0041BA C0 07            [24]  406 	push	ar7
      0041BC C0 06            [24]  407 	push	ar6
      0041BE 12 3F 43         [24]  408 	lcall	_ak820_flash_erase
      0041C1 E5 82            [12]  409 	mov	a, dpl
      0041C3 D0 06            [24]  410 	pop	ar6
      0041C5 D0 07            [24]  411 	pop	ar7
      0041C7 70 03            [24]  412 	jnz	00102$
      0041C9 F5 82            [12]  413 	mov	dpl,a
      0041CB 22               [24]  414 	ret
      0041CC                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      0041CC 90 05 5B         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      0041CF 74 7F            [12]  418 	mov	a,#_page_data
      0041D1 F0               [24]  419 	movx	@dptr,a
      0041D2 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      0041D4 A3               [24]  421 	inc	dptr
      0041D5 12 48 7D         [24]  422 	lcall	_ak820_outline_0060
      0041D8 12 40 57         [24]  423 	lcall	_ak820_flash_program_page
      0041DB E5 82            [12]  424 	mov	a, dpl
      0041DD 70 03            [24]  425 	jnz	00120$
      0041DF F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0041E1 22               [24]  428 	ret
      0041E2                        429 00120$:
      0041E2 7F 00            [12]  430 	mov	r7,#0x00
      0041E4                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      0041E4 8F 05            [24]  433 	mov	ar5,r7
      0041E6 7E 00            [12]  434 	mov	r6,#0x00
      0041E8 90 05 CA         [24]  435 	mov	dptr,#_write_page_address_10000_32
      0041EB 12 3A 9A         [24]  436 	lcall	_ak820_outline_0120
      0041EE ED               [12]  437 	mov	a,r5
      0041EF 2B               [12]  438 	add	a, r3
      0041F0 FB               [12]  439 	mov	r3,a
      0041F1 EE               [12]  440 	mov	a,r6
      0041F2 3C               [12]  441 	addc	a, r4
      0041F3 FC               [12]  442 	mov	r4,a
      0041F4 12 36 42         [24]  443 	lcall	_ak820_outline_0122
      0041F7 12 3E 36         [24]  444 	lcall	_ak820_flash_read
      0041FA AE 82            [24]  445 	mov	r6, dpl
      0041FC 12 48 96         [24]  446 	lcall	_ak820_outline_0102
      0041FF FD               [12]  447 	mov	r5,a
      004200 EE               [12]  448 	mov	a,r6
      004201 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      004204 80 04            [24]  450 	sjmp	00109$
      004206                        451 00149$:
      004206 75 82 00         [24]  452 	mov	dpl, #0x00
      004209 22               [24]  453 	ret
      00420A                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00420A 0F               [12]  456 	inc	r7
      00420B BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      00420E 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      004211 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      004212                        472 _journal_header_valid:
      004212 12 3A 8A         [24]  473 	lcall	_ak820_outline_0104
      004215 90 05 CC         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      004218 12 3A 8F         [24]  475 	lcall	_ak820_outline_0105
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      00421B 90 05 CC         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      00421E 12 39 E0         [24]  478 	lcall	_ak820_outline_0004
      004221 E0               [24]  479 	movx	a,@dptr
      004222 FD               [12]  480 	mov	r5,a
      004223 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      004226 80 04            [24]  482 	sjmp	00116$
      004228                        483 00138$:
      004228 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      00422B 22               [24]  486 	ret
      00422C                        487 00116$:
      00422C 7D 01            [12]  488 	mov	r5,#0x01
      00422E                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      00422E ED               [12]  491 	mov	a,r5
      00422F 12 3A 27         [24]  492 	lcall	_ak820_outline_0016
      004232 FC               [12]  493 	mov	r4,a
      004233 8D 02            [24]  494 	mov	ar2,r5
      004235 7B 00            [12]  495 	mov	r3,#0x00
      004237 74 04            [12]  496 	mov	a,#0x04
      004239 2A               [12]  497 	add	a, r2
      00423A FA               [12]  498 	mov	r2,a
      00423B E4               [12]  499 	clr	a
      00423C 3B               [12]  500 	addc	a, r3
      00423D FB               [12]  501 	mov	r3,a
      00423E EA               [12]  502 	mov	a,r2
      00423F 2E               [12]  503 	add	a, r6
      004240 F5 82            [12]  504 	mov	dpl,a
      004242 EB               [12]  505 	mov	a,r3
      004243 3F               [12]  506 	addc	a, r7
      004244 F5 83            [12]  507 	mov	dph,a
      004246 E0               [24]  508 	movx	a,@dptr
      004247 62 04            [12]  509 	xrl	ar4,a
      004249 BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      00424C 80 04            [24]  511 	sjmp	00107$
      00424E                        512 00139$:
      00424E 75 82 00         [24]  513 	mov	dpl, #0x00
      004251 22               [24]  514 	ret
      004252                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      004252 0D               [12]  517 	inc	r5
      004253 BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      004256 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      004259 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      00425A                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      00425A 7F 00            [12]  537 	mov	r7,#0x00
      00425C                        538 00115$:
      00425C EF               [12]  539 	mov	a,r7
      00425D 24 CE            [12]  540 	add	a, #_recover_journal_header_10000_46
      00425F FD               [12]  541 	mov	r5,a
      004260 E4               [12]  542 	clr	a
      004261 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      004263 FE               [12]  544 	mov	r6,a
      004264 8F 04            [24]  545 	mov	ar4,r7
      004266 7B 00            [12]  546 	mov	r3,#0x00
      004268 74 40            [12]  547 	mov	a,#0x40
      00426A 2C               [12]  548 	add	a, r4
      00426B FC               [12]  549 	mov	r4,a
      00426C 74 EF            [12]  550 	mov	a,#0xef
      00426E 3B               [12]  551 	addc	a, r3
      00426F FB               [12]  552 	mov	r3,a
      004270 12 48 DE         [24]  553 	lcall	_ak820_outline_0180
      004273 12 3E 36         [24]  554 	lcall	_ak820_flash_read
      004276 AC 82            [24]  555 	mov	r4, dpl
      004278 12 48 83         [24]  556 	lcall	_ak820_outline_0064
      00427B 0F               [12]  557 	inc	r7
      00427C BF 09 DD         [24]  558 	cjne	r7,#0x09,00115$
                                    559 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      00427F 90 05 CE         [24]  560 	mov	dptr,#_recover_journal_header_10000_46
      004282 12 42 12         [24]  561 	lcall	_journal_header_valid
      004285 E5 82            [12]  562 	mov	a, dpl
      004287 70 01            [24]  563 	jnz	00103$
      004289 22               [24]  564 	ret
      00428A                        565 00103$:
                                    566 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      00428A 90 05 CF         [24]  567 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      00428D E0               [24]  568 	movx	a,@dptr
      00428E FF               [12]  569 	mov	r7,a
      00428F 7E 00            [12]  570 	mov	r6,#0x00
      004291 90 05 D0         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      004294 E0               [24]  572 	movx	a,@dptr
      004295 FC               [12]  573 	mov	r4,a
      004296 E4               [12]  574 	clr	a
      004297 42 07            [12]  575 	orl	ar7,a
      004299 EC               [12]  576 	mov	a,r4
      00429A 42 06            [12]  577 	orl	ar6,a
                                    578 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      00429C 90 05 D1         [24]  579 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      00429F E0               [24]  580 	movx	a,@dptr
      0042A0 FD               [12]  581 	mov	r5,a
      0042A1 7C 00            [12]  582 	mov	r4,#0x00
      0042A3 90 05 D2         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      0042A6 E0               [24]  584 	movx	a,@dptr
      0042A7 FA               [12]  585 	mov	r2,a
      0042A8 E4               [12]  586 	clr	a
      0042A9 12 48 B8         [24]  587 	lcall	_ak820_outline_0139
                                    588 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      0042AC C3               [12]  589 	clr	c
      0042AD EF               [12]  590 	mov	a,r7
      0042AE 94 A0            [12]  591 	subb	a,#0xa0
      0042B0 EE               [12]  592 	mov	a,r6
      0042B1 94 00            [12]  593 	subb	a,#0x00
      0042B3 40 06            [24]  594 	jc	00134$
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      0042B5 75 82 01         [24]  596 	mov	dpl, #0x01
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      0042B8 02 40 CA         [24]  598 	ljmp	_nvm_fail
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      0042BB                        600 00134$:
      0042BB 7B 00            [12]  601 	mov	r3,#0x00
      0042BD                        602 00117$:
      0042BD C0 05            [24]  603 	push	ar5
      0042BF C0 04            [24]  604 	push	ar4
      0042C1 EB               [12]  605 	mov	a,r3
      0042C2 24 7F            [12]  606 	add	a, #_page_data
      0042C4 F9               [12]  607 	mov	r1,a
      0042C5 E4               [12]  608 	clr	a
      0042C6 34 05            [12]  609 	addc	a, #(_page_data >> 8)
      0042C8 FA               [12]  610 	mov	r2,a
      0042C9 8B 00            [24]  611 	mov	ar0,r3
      0042CB 7D 00            [12]  612 	mov	r5,#0x00
      0042CD 74 EF            [12]  613 	mov	a,#0xef
      0042CF 2D               [12]  614 	add	a, r5
      0042D0 FD               [12]  615 	mov	r5,a
      0042D1 88 82            [24]  616 	mov	dpl, r0
      0042D3 8D 83            [24]  617 	mov	dph, r5
      0042D5 12 3E 36         [24]  618 	lcall	_ak820_flash_read
      0042D8 AD 82            [24]  619 	mov	r5, dpl
      0042DA 12 48 D9         [24]  620 	lcall	_ak820_outline_0179
      0042DD ED               [12]  621 	mov	a,r5
      0042DE F0               [24]  622 	movx	@dptr,a
      0042DF 0B               [12]  623 	inc	r3
      0042E0 BB 40 02         [24]  624 	cjne	r3,#0x40,00190$
      0042E3 80 06            [24]  625 	sjmp	00191$
      0042E5                        626 00190$:
      0042E5 D0 04            [24]  627 	pop	ar4
      0042E7 D0 05            [24]  628 	pop	ar5
      0042E9 80 D2            [24]  629 	sjmp	00117$
      0042EB                        630 00191$:
      0042EB D0 04            [24]  631 	pop	ar4
      0042ED D0 05            [24]  632 	pop	ar5
                                    633 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      0042EF C0 07            [24]  634 	push	ar7
      0042F1 C0 06            [24]  635 	push	ar6
      0042F3 C0 05            [24]  636 	push	ar5
      0042F5 C0 04            [24]  637 	push	ar4
      0042F7 12 41 78         [24]  638 	lcall	_page_crc
      0042FA AA 82            [24]  639 	mov	r2, dpl
      0042FC AB 83            [24]  640 	mov	r3, dph
      0042FE D0 04            [24]  641 	pop	ar4
      004300 D0 05            [24]  642 	pop	ar5
      004302 D0 06            [24]  643 	pop	ar6
      004304 D0 07            [24]  644 	pop	ar7
      004306 EA               [12]  645 	mov	a,r2
      004307 B5 05 06         [24]  646 	cjne	a,ar5,00192$
      00430A EB               [12]  647 	mov	a,r3
      00430B B5 04 02         [24]  648 	cjne	a,ar4,00192$
      00430E 80 06            [24]  649 	sjmp	00113$
      004310                        650 00192$:
      004310 75 82 02         [24]  651 	mov	dpl, #0x02
      004313 02 40 CA         [24]  652 	ljmp	_nvm_fail
      004316                        653 00113$:
                                    654 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      004316 EE               [12]  655 	mov	a,r6
      004317 54 03            [12]  656 	anl	a,#0x03
      004319 A2 E0            [12]  657 	mov	c,acc.0
      00431B CF               [12]  658 	xch	a,r7
      00431C 13               [12]  659 	rrc	a
      00431D CF               [12]  660 	xch	a,r7
      00431E 13               [12]  661 	rrc	a
      00431F A2 E0            [12]  662 	mov	c,acc.0
      004321 CF               [12]  663 	xch	a,r7
      004322 13               [12]  664 	rrc	a
      004323 CF               [12]  665 	xch	a,r7
      004324 13               [12]  666 	rrc	a
      004325 CF               [12]  667 	xch	a,r7
      004326 24 C7            [12]  668 	add	a,#0xc7
      004328 FE               [12]  669 	mov	r6,a
      004329 12 48 C8         [24]  670 	lcall	_ak820_outline_0153
      00432C 12 41 AB         [24]  671 	lcall	_write_page
      00432F E5 82            [12]  672 	mov	a, dpl
      004331 70 06            [24]  673 	jnz	00110$
      004333 75 82 03         [24]  674 	mov	dpl, #0x03
      004336 02 40 CA         [24]  675 	ljmp	_nvm_fail
      004339                        676 00110$:
                                    677 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      004339 90 EF 40         [24]  678 	mov	dptr,#0xef40
      00433C 12 3F 43         [24]  679 	lcall	_ak820_flash_erase
      00433F E5 82            [12]  680 	mov	a, dpl
      004341 70 06            [24]  681 	jnz	00119$
      004343 75 82 04         [24]  682 	mov	dpl, #0x04
                                    683 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      004346 02 40 CA         [24]  684 	ljmp	_nvm_fail
      004349                        685 00119$:
      004349 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    689 ;------------------------------------------------------------
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    691 ;	-----------------------------------------
                                    692 ;	 function eeprom_driver_init
                                    693 ;	-----------------------------------------
      00434A                        694 _eeprom_driver_init:
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    696 ;	assignBit
      00434A C2 0A            [12]  697 	clr	_storage_failed
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      00434C 90 05 C1         [24]  699 	mov	dptr,#_first_failure_stage
      00434F E4               [12]  700 	clr	a
      004350 F0               [24]  701 	movx	@dptr,a
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    703 ;	assignBit
      004351 C2 09            [12]  704 	clr	_page_dirty
                                    705 ;	assignBit
      004353 C2 08            [12]  706 	clr	_page_valid
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      004355 90 05 C0         [24]  708 	mov	dptr,#_batch_depth
      004358 E4               [12]  709 	clr	a
      004359 F0               [24]  710 	movx	@dptr,a
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      00435A 12 42 5A         [24]  712 	lcall	_recover_journal
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      00435D 02 2A B7         [24]  715 	ljmp	_ak820_macro_init
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_nvm_ok
                                    722 ;	-----------------------------------------
      004360                        723 _ak820_nvm_ok:
      004360 A2 0A            [12]  724 	mov	c,_storage_failed
      004362 B3               [12]  725 	cpl	c
      004363 92 0B            [24]  726 	mov  _ak820_nvm_ok_sloc0_1_0,c
      004365 12 3A C6         [24]  727 	lcall	_ak820_outline_0166
      004368 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    731 ;------------------------------------------------------------
                                    732 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    733 ;	-----------------------------------------
                                    734 ;	 function ak820_nvm_schema_fault
                                    735 ;	-----------------------------------------
      004369                        736 _ak820_nvm_schema_fault:
      004369 75 82 10         [24]  737 	mov	dpl, #0x10
      00436C 02 40 CA         [24]  738 	ljmp	_nvm_fail
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    741 ;------------------------------------------------------------
                                    742 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    743 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    744 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    745 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_flush
                                    750 ;	-----------------------------------------
      00436F                        751 _ak820_nvm_flush:
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      00436F 30 09 03         [24]  753 	jnb	_page_dirty,00101$
      004372 30 0A 01         [24]  754 	jnb	_storage_failed,00102$
      004375                        755 00101$:
      004375 22               [24]  756 	ret
      004376                        757 00102$:
                                    758 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      004376 12 41 78         [24]  759 	lcall	_page_crc
      004379 12 48 AD         [24]  760 	lcall	_ak820_outline_0131
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      00437C 90 05 D7         [24]  762 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      00437F 74 A5            [12]  763 	mov	a,#0xa5
      004381 F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      004382 90 05 BF         [24]  766 	mov	dptr,#_cached_page
      004385 E0               [24]  767 	movx	a,@dptr
      004386 90 05 D8         [24]  768 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      004389 F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      00438A 90 05 D9         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      00438D E4               [12]  772 	clr	a
      00438E F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      00438F 8E 05            [24]  775 	mov	ar5,r6
      004391 90 05 DA         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      004394 ED               [12]  777 	mov	a,r5
      004395 F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      004396 8F 06            [24]  780 	mov	ar6,r7
      004398 90 05 DB         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      00439B EE               [12]  782 	mov	a,r6
      00439C F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      00439D 7F 01            [12]  785 	mov	r7,#0x01
      00439F                        786 00128$:
      00439F 8F 06            [24]  787 	mov	ar6,r7
      0043A1 EE               [12]  788 	mov	a,r6
      0043A2 24 04            [12]  789 	add	a,#0x04
      0043A4 FE               [12]  790 	mov	r6,a
      0043A5 33               [12]  791 	rlc	a
      0043A6 95 E0            [12]  792 	subb	a,acc
      0043A8 FD               [12]  793 	mov	r5,a
      0043A9 EE               [12]  794 	mov	a,r6
      0043AA 24 D7            [12]  795 	add	a, #_ak820_nvm_flush_header_10000_62
      0043AC FE               [12]  796 	mov	r6,a
      0043AD ED               [12]  797 	mov	a,r5
      0043AE 34 05            [12]  798 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      0043B0 FD               [12]  799 	mov	r5,a
      0043B1 12 48 60         [24]  800 	lcall	_ak820_outline_0039
      0043B4 FC               [12]  801 	mov	r4,a
      0043B5 63 04 FF         [24]  802 	xrl	ar4,#0xff
      0043B8 8E 82            [24]  803 	mov	dpl,r6
      0043BA 8D 83            [24]  804 	mov	dph,r5
      0043BC EC               [12]  805 	mov	a,r4
      0043BD F0               [24]  806 	movx	@dptr,a
      0043BE 0F               [12]  807 	inc	r7
      0043BF BF 05 DD         [24]  808 	cjne	r7,#0x05,00128$
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      0043C2 90 05 E0         [24]  810 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0043C5 74 05            [12]  811 	mov	a,#0x05
      0043C7 F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0043C8 90 EF 40         [24]  814 	mov	dptr,#0xef40
      0043CB 12 3F 43         [24]  815 	lcall	_ak820_flash_erase
      0043CE E5 82            [12]  816 	mov	a, dpl
      0043D0 70 03            [24]  817 	jnz	00269$
      0043D2 02 44 B9         [24]  818 	ljmp	00127$
      0043D5                        819 00269$:
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      0043D5 90 05 E0         [24]  821 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0043D8 74 06            [12]  822 	mov	a,#0x06
      0043DA F0               [24]  823 	movx	@dptr,a
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0043DB 7F 00            [12]  825 	mov	r7,#0x00
      0043DD                        826 00130$:
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      0043DD 12 48 6C         [24]  828 	lcall	_ak820_outline_0052
      0043E0 12 3E 36         [24]  829 	lcall	_ak820_flash_read
      0043E3 E5 82            [12]  830 	mov	a, dpl
      0043E5 60 03            [24]  831 	jz	00270$
      0043E7 02 44 B9         [24]  832 	ljmp	00127$
      0043EA                        833 00270$:
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0043EA 0F               [12]  835 	inc	r7
      0043EB BF 40 EF         [24]  836 	cjne	r7,#0x40,00130$
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      0043EE 90 05 E0         [24]  838 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0043F1 74 07            [12]  839 	mov	a,#0x07
      0043F3 F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      0043F4 90 EF 00         [24]  842 	mov	dptr,#0xef00
      0043F7 12 41 AB         [24]  843 	lcall	_write_page
      0043FA E5 82            [12]  844 	mov	a, dpl
      0043FC 70 03            [24]  845 	jnz	00273$
      0043FE 02 44 B9         [24]  846 	ljmp	00127$
      004401                        847 00273$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      004401 90 05 E0         [24]  849 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004404 74 08            [12]  850 	mov	a,#0x08
      004406 F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004407 7F 01            [12]  853 	mov	r7,#0x01
      004409                        854 00132$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      004409 12 48 60         [24]  856 	lcall	_ak820_outline_0039
      00440C FE               [12]  857 	mov	r6,a
      00440D 60 23            [24]  858 	jz	00133$
      00440F 8F 05            [24]  859 	mov	ar5,r7
      004411 7C 00            [12]  860 	mov	r4,#0x00
      004413 74 40            [12]  861 	mov	a,#0x40
      004415 2D               [12]  862 	add	a, r5
      004416 FD               [12]  863 	mov	r5,a
      004417 74 EF            [12]  864 	mov	a,#0xef
      004419 3C               [12]  865 	addc	a, r4
      00441A FC               [12]  866 	mov	r4,a
      00441B 90 05 58         [24]  867 	mov	dptr,#_ak820_flash_program_PARM_2
      00441E EE               [12]  868 	mov	a,r6
      00441F F0               [24]  869 	movx	@dptr,a
      004420 8D 82            [24]  870 	mov	dpl, r5
      004422 8C 83            [24]  871 	mov	dph, r4
      004424 C0 07            [24]  872 	push	ar7
      004426 12 3F A3         [24]  873 	lcall	_ak820_flash_program
      004429 E5 82            [12]  874 	mov	a, dpl
      00442B D0 07            [24]  875 	pop	ar7
      00442D 70 03            [24]  876 	jnz	00275$
      00442F 02 44 B9         [24]  877 	ljmp	00127$
      004432                        878 00275$:
      004432                        879 00133$:
                                    880 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004432 0F               [12]  881 	inc	r7
      004433 BF 09 D3         [24]  882 	cjne	r7,#0x09,00132$
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      004436 90 05 E0         [24]  884 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004439 74 09            [12]  885 	mov	a,#0x09
      00443B F0               [24]  886 	movx	@dptr,a
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      00443C 7F 01            [12]  888 	mov	r7,#0x01
      00443E                        889 00134$:
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      00443E 12 48 6C         [24]  891 	lcall	_ak820_outline_0052
      004441 12 3E 36         [24]  892 	lcall	_ak820_flash_read
      004444 AE 82            [24]  893 	mov	r6, dpl
      004446 12 48 60         [24]  894 	lcall	_ak820_outline_0039
      004449 FD               [12]  895 	mov	r5,a
      00444A EE               [12]  896 	mov	a,r6
      00444B B5 05 6B         [24]  897 	cjne	a,ar5,00127$
                                    898 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      00444E 0F               [12]  899 	inc	r7
      00444F BF 09 EC         [24]  900 	cjne	r7,#0x09,00134$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      004452 90 05 E0         [24]  902 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004455 74 0A            [12]  903 	mov	a,#0x0a
      004457 F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      004458 90 05 D7         [24]  906 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      00445B E0               [24]  907 	movx	a,@dptr
      00445C 90 05 58         [24]  908 	mov	dptr,#_ak820_flash_program_PARM_2
      00445F F0               [24]  909 	movx	@dptr,a
      004460 90 EF 40         [24]  910 	mov	dptr,#0xef40
      004463 12 3F A3         [24]  911 	lcall	_ak820_flash_program
      004466 E5 82            [12]  912 	mov	a, dpl
      004468 60 4F            [24]  913 	jz	00127$
                                    914 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      00446A 90 05 E0         [24]  915 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00446D 74 0B            [12]  916 	mov	a,#0x0b
      00446F F0               [24]  917 	movx	@dptr,a
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      004470 90 EF 40         [24]  919 	mov	dptr,#0xef40
      004473 12 3E 36         [24]  920 	lcall	_ak820_flash_read
      004476 AF 82            [24]  921 	mov	r7, dpl
      004478 90 05 D7         [24]  922 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      00447B E0               [24]  923 	movx	a,@dptr
      00447C FE               [12]  924 	mov	r6,a
      00447D EF               [12]  925 	mov	a,r7
      00447E B5 06 38         [24]  926 	cjne	a,ar6,00127$
                                    927 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      004481 90 05 E0         [24]  928 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004484 74 0C            [12]  929 	mov	a,#0x0c
      004486 F0               [24]  930 	movx	@dptr,a
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      004487 90 05 BF         [24]  932 	mov	dptr,#_cached_page
      00448A E0               [24]  933 	movx	a,@dptr
      00448B FE               [12]  934 	mov	r6,a
      00448C E4               [12]  935 	clr	a
      00448D C3               [12]  936 	clr	c
      00448E CE               [12]  937 	xch	a,r6
      00448F 13               [12]  938 	rrc	a
      004490 CE               [12]  939 	xch	a,r6
      004491 13               [12]  940 	rrc	a
      004492 A2 E0            [12]  941 	mov	c,acc.0
      004494 CE               [12]  942 	xch	a,r6
      004495 13               [12]  943 	rrc	a
      004496 CE               [12]  944 	xch	a,r6
      004497 13               [12]  945 	rrc	a
      004498 CE               [12]  946 	xch	a,r6
      004499 24 C7            [12]  947 	add	a,#0xc7
      00449B FF               [12]  948 	mov	r7,a
      00449C 12 48 A2         [24]  949 	lcall	_ak820_outline_0116
      00449F 12 41 AB         [24]  950 	lcall	_write_page
      0044A2 E5 82            [12]  951 	mov	a, dpl
      0044A4 60 13            [24]  952 	jz	00127$
                                    953 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      0044A6 90 05 E0         [24]  954 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0044A9 74 0D            [12]  955 	mov	a,#0x0d
      0044AB F0               [24]  956 	movx	@dptr,a
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0044AC 90 EF 40         [24]  958 	mov	dptr,#0xef40
      0044AF 12 3F 43         [24]  959 	lcall	_ak820_flash_erase
      0044B2 E5 82            [12]  960 	mov	a, dpl
      0044B4 60 03            [24]  961 	jz	00127$
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    963 ;	assignBit
      0044B6 C2 09            [12]  964 	clr	_page_dirty
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      0044B8 22               [24]  967 	ret
      0044B9                        968 00127$:
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      0044B9 90 05 E0         [24]  970 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0044BC E0               [24]  971 	movx	a,@dptr
      0044BD F5 82            [12]  972 	mov	dpl,a
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      0044BF 02 40 CA         [24]  974 	ljmp	_nvm_fail
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    977 ;------------------------------------------------------------
                                    978 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function ak820_nvm_begin
                                    981 ;	-----------------------------------------
      0044C2                        982 _ak820_nvm_begin:
                                    983 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      0044C2 90 05 C0         [24]  984 	mov	dptr,#_batch_depth
      0044C5 E0               [24]  985 	movx	a,@dptr
      0044C6 FF               [12]  986 	mov	r7,a
      0044C7 BF FF 06         [24]  987 	cjne	r7,#0xff,00102$
      0044CA 75 82 0F         [24]  988 	mov	dpl, #0x0f
      0044CD 02 40 CA         [24]  989 	ljmp	_nvm_fail
      0044D0                        990 00102$:
                                    991 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      0044D0 90 05 C0         [24]  992 	mov	dptr,#_batch_depth
      0044D3 EF               [12]  993 	mov	a,r7
      0044D4 04               [12]  994 	inc	a
      0044D5 F0               [24]  995 	movx	@dptr,a
                                    996 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      0044D6 22               [24]  997 	ret
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function ak820_nvm_end
                                   1004 ;	-----------------------------------------
      0044D7                       1005 _ak820_nvm_end:
                                   1006 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      0044D7 90 05 C0         [24] 1007 	mov	dptr,#_batch_depth
      0044DA E0               [24] 1008 	movx	a,@dptr
      0044DB FF               [12] 1009 	mov	r7,a
      0044DC E0               [24] 1010 	movx	a,@dptr
      0044DD 60 06            [24] 1011 	jz	00102$
      0044DF EF               [12] 1012 	mov	a,r7
      0044E0 14               [12] 1013 	dec	a
      0044E1 90 05 C0         [24] 1014 	mov	dptr,#_batch_depth
      0044E4 F0               [24] 1015 	movx	@dptr,a
      0044E5                       1016 00102$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      0044E5 90 05 C0         [24] 1018 	mov	dptr,#_batch_depth
      0044E8 E0               [24] 1019 	movx	a,@dptr
      0044E9 70 03            [24] 1020 	jnz	00105$
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      0044EB 02 43 6F         [24] 1022 	ljmp	_ak820_nvm_flush
      0044EE                       1023 00105$:
      0044EE 22               [24] 1024 	ret
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'load_page'
                                   1027 ;------------------------------------------------------------
                                   1028 ;page          Allocated with name '_load_page_page_10000_87'
                                   1029 ;i             Allocated with name '_load_page_i_10000_88'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function load_page
                                   1034 ;	-----------------------------------------
      0044EF                       1035 _load_page:
      0044EF E5 82            [12] 1036 	mov	a,dpl
      0044F1 90 05 E1         [24] 1037 	mov	dptr,#_load_page_page_10000_87
      0044F4 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      0044F5 30 08 17         [24] 1040 	jnb	_page_valid,00102$
      0044F8 90 05 BF         [24] 1041 	mov	dptr,#_cached_page
      0044FB E0               [24] 1042 	movx	a,@dptr
      0044FC FF               [12] 1043 	mov	r7,a
      0044FD 90 05 E1         [24] 1044 	mov	dptr,#_load_page_page_10000_87
      004500 E0               [24] 1045 	movx	a,@dptr
      004501 FE               [12] 1046 	mov	r6,a
      004502 EF               [12] 1047 	mov	a,r7
      004503 B5 06 09         [24] 1048 	cjne	a,ar6,00102$
      004506 A2 0A            [12] 1049 	mov	c,_storage_failed
      004508 B3               [12] 1050 	cpl	c
      004509 92 0C            [24] 1051 	mov  _load_page_sloc0_1_0,c
      00450B 12 3A C6         [24] 1052 	lcall	_ak820_outline_0166
      00450E 22               [24] 1053 	ret
      00450F                       1054 00102$:
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      00450F 12 43 6F         [24] 1056 	lcall	_ak820_nvm_flush
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      004512 30 0A 04         [24] 1058 	jnb	_storage_failed,00119$
      004515 75 82 00         [24] 1059 	mov	dpl, #0x00
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004518 22               [24] 1061 	ret
      004519                       1062 00119$:
      004519 7F 00            [12] 1063 	mov	r7,#0x00
      00451B                       1064 00107$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      00451B EF               [12] 1066 	mov	a,r7
      00451C 24 7F            [12] 1067 	add	a, #_page_data
      00451E FD               [12] 1068 	mov	r5,a
      00451F E4               [12] 1069 	clr	a
      004520 34 05            [12] 1070 	addc	a, #(_page_data >> 8)
      004522 FE               [12] 1071 	mov	r6,a
      004523 90 05 E1         [24] 1072 	mov	dptr,#_load_page_page_10000_87
      004526 E0               [24] 1073 	movx	a,@dptr
      004527 FC               [12] 1074 	mov	r4,a
      004528 FA               [12] 1075 	mov	r2,a
      004529 E4               [12] 1076 	clr	a
      00452A C3               [12] 1077 	clr	c
      00452B CA               [12] 1078 	xch	a,r2
      00452C 13               [12] 1079 	rrc	a
      00452D CA               [12] 1080 	xch	a,r2
      00452E 13               [12] 1081 	rrc	a
      00452F A2 E0            [12] 1082 	mov	c,acc.0
      004531 CA               [12] 1083 	xch	a,r2
      004532 13               [12] 1084 	rrc	a
      004533 CA               [12] 1085 	xch	a,r2
      004534 13               [12] 1086 	rrc	a
      004535 CA               [12] 1087 	xch	a,r2
      004536 24 C7            [12] 1088 	add	a,#0xc7
      004538 FB               [12] 1089 	mov	r3,a
      004539 8F 01            [24] 1090 	mov	ar1,r7
      00453B 89 00            [24] 1091 	mov	ar0,r1
      00453D 79 00            [12] 1092 	mov	r1,#0x00
      00453F E8               [12] 1093 	mov	a,r0
      004540 2A               [12] 1094 	add	a, r2
      004541 FA               [12] 1095 	mov	r2,a
      004542 E9               [12] 1096 	mov	a,r1
      004543 3B               [12] 1097 	addc	a, r3
      004544 FB               [12] 1098 	mov	r3,a
      004545 12 48 BE         [24] 1099 	lcall	_ak820_outline_0140
      004548 12 3E 36         [24] 1100 	lcall	_ak820_flash_read
      00454B AB 82            [24] 1101 	mov	r3, dpl
      00454D 12 3A AA         [24] 1102 	lcall	_ak820_outline_0132
      004550 EB               [12] 1103 	mov	a,r3
      004551 F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004552 0F               [12] 1106 	inc	r7
      004553 BF 40 C5         [24] 1107 	cjne	r7,#0x40,00107$
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004556 90 05 BF         [24] 1109 	mov	dptr,#_cached_page
      004559 EC               [12] 1110 	mov	a,r4
      00455A F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1113 ;	assignBit
      00455B D2 08            [12] 1114 	setb	_page_valid
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      00455D 75 82 01         [24] 1116 	mov	dpl, #0x01
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004560 22               [24] 1118 	ret
                                   1119 ;------------------------------------------------------------
                                   1120 ;Allocation info for local variables in function 'read_offset'
                                   1121 ;------------------------------------------------------------
                                   1122 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1123 ;------------------------------------------------------------
                                   1124 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1125 ;	-----------------------------------------
                                   1126 ;	 function read_offset
                                   1127 ;	-----------------------------------------
      004561                       1128 _read_offset:
      004561 12 3A 8A         [24] 1129 	lcall	_ak820_outline_0104
      004564 90 05 E2         [24] 1130 	mov	dptr,#_read_offset_offset_10000_93
      004567 12 3A 8F         [24] 1131 	lcall	_ak820_outline_0105
                                   1132 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      00456A 90 05 E2         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      00456D 12 3A 40         [24] 1134 	lcall	_ak820_outline_0051
      004570 C3               [12] 1135 	clr	c
      004571 94 28            [12] 1136 	subb	a,#0x28
      004573 40 04            [24] 1137 	jc	00102$
      004575 75 82 00         [24] 1138 	mov	dpl, #0x00
      004578 22               [24] 1139 	ret
      004579                       1140 00102$:
                                   1141 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004579 30 08 34         [24] 1142 	jnb	_page_valid,00104$
      00457C 8E 04            [24] 1143 	mov	ar4,r6
      00457E EF               [12] 1144 	mov	a,r7
      00457F A2 E7            [12] 1145 	mov	c,acc.7
      004581 CC               [12] 1146 	xch	a,r4
      004582 33               [12] 1147 	rlc	a
      004583 CC               [12] 1148 	xch	a,r4
      004584 33               [12] 1149 	rlc	a
      004585 A2 E7            [12] 1150 	mov	c,acc.7
      004587 CC               [12] 1151 	xch	a,r4
      004588 33               [12] 1152 	rlc	a
      004589 CC               [12] 1153 	xch	a,r4
      00458A 33               [12] 1154 	rlc	a
      00458B CC               [12] 1155 	xch	a,r4
      00458C 54 03            [12] 1156 	anl	a,#0x03
      00458E FD               [12] 1157 	mov	r5,a
      00458F 90 05 BF         [24] 1158 	mov	dptr,#_cached_page
      004592 E0               [24] 1159 	movx	a,@dptr
      004593 FA               [12] 1160 	mov	r2,a
      004594 7B 00            [12] 1161 	mov	r3,#0x00
      004596 EC               [12] 1162 	mov	a,r4
      004597 B5 02 16         [24] 1163 	cjne	a,ar2,00104$
      00459A ED               [12] 1164 	mov	a,r5
      00459B B5 03 12         [24] 1165 	cjne	a,ar3,00104$
                                   1166 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      00459E 74 3F            [12] 1167 	mov	a,#0x3f
      0045A0 5E               [12] 1168 	anl	a,r6
      0045A1 7D 00            [12] 1169 	mov	r5,#0x00
      0045A3 24 7F            [12] 1170 	add	a, #_page_data
      0045A5 F5 82            [12] 1171 	mov	dpl,a
      0045A7 ED               [12] 1172 	mov	a,r5
      0045A8 34 05            [12] 1173 	addc	a, #(_page_data >> 8)
      0045AA F5 83            [12] 1174 	mov	dph,a
      0045AC E0               [24] 1175 	movx	a,@dptr
      0045AD F5 82            [12] 1176 	mov	dpl,a
      0045AF 22               [24] 1177 	ret
      0045B0                       1178 00104$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0045B0 74 C7            [12] 1180 	mov	a,#0xc7
      0045B2 2F               [12] 1181 	add	a, r7
      0045B3 FF               [12] 1182 	mov	r7,a
      0045B4 12 48 A2         [24] 1183 	lcall	_ak820_outline_0116
                                   1184 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0045B7 02 3E 36         [24] 1185 	ljmp	_ak820_flash_read
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1188 ;------------------------------------------------------------
                                   1189 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function eeprom_read_byte
                                   1194 ;	-----------------------------------------
      0045BA                       1195 _eeprom_read_byte:
      0045BA C0 07            [24] 1196 	push	ar7
      0045BC C0 06            [24] 1197 	push	ar6
      0045BE 12 48 59         [24] 1198 	lcall	_ak820_outline_0036
      0045C1 90 05 E4         [24] 1199 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0045C4 12 3A 1F         [24] 1200 	lcall	_ak820_outline_0015
                                   1201 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0045C7 90 05 E4         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0045CA 12 39 E0         [24] 1203 	lcall	_ak820_outline_0004
      0045CD C0 06            [24] 1204 	push	ar6
      0045CF C0 05            [24] 1205 	push	ar5
      0045D1 C0 04            [24] 1206 	push	ar4
      0045D3 C0 03            [24] 1207 	push	ar3
      0045D5 C0 02            [24] 1208 	push	ar2
      0045D7 C0 01            [24] 1209 	push	ar1
      0045D9 C0 00            [24] 1210 	push	ar0
      0045DB 12 45 61         [24] 1211 	lcall	_read_offset
      0045DE AF 82            [24] 1212 	mov	r7, dpl
      0045E0 D0 00            [24] 1213 	pop	ar0
      0045E2 D0 01            [24] 1214 	pop	ar1
      0045E4 D0 02            [24] 1215 	pop	ar2
      0045E6 D0 03            [24] 1216 	pop	ar3
      0045E8 D0 04            [24] 1217 	pop	ar4
      0045EA D0 05            [24] 1218 	pop	ar5
      0045EC D0 06            [24] 1219 	pop	ar6
      0045EE 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0045F0 D0 06            [24] 1222 	pop	ar6
      0045F2 D0 07            [24] 1223 	pop	ar7
      0045F4 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1227 ;------------------------------------------------------------
                                   1228 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1229 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1230 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1231 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1232 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1233 ;------------------------------------------------------------
                                   1234 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1235 ;	-----------------------------------------
                                   1236 ;	 function ak820_eeprom_read_block_xdata
                                   1237 ;	-----------------------------------------
      0045F5                       1238 _ak820_eeprom_read_block_xdata:
      0045F5 12 3A 8A         [24] 1239 	lcall	_ak820_outline_0104
      0045F8 90 05 EC         [24] 1240 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0045FB 12 3A 8F         [24] 1241 	lcall	_ak820_outline_0105
                                   1242 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0045FE 90 05 E7         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004601 12 3A 40         [24] 1244 	lcall	_ak820_outline_0051
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004604 90 05 EC         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004607 12 3A 5F         [24] 1247 	lcall	_ak820_outline_0059
      00460A 90 05 EE         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00460D 12 3A 65         [24] 1249 	lcall	_ak820_outline_0070
                                   1250 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004610 90 05 EA         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004613 12 3A 5F         [24] 1252 	lcall	_ak820_outline_0059
      004616                       1253 00103$:
      004616 8C 02            [24] 1254 	mov	ar2,r4
      004618 8D 03            [24] 1255 	mov	ar3,r5
      00461A 1C               [12] 1256 	dec	r4
      00461B BC FF 01         [24] 1257 	cjne	r4,#0xff,00130$
      00461E 1D               [12] 1258 	dec	r5
      00461F                       1259 00130$:
      00461F EA               [12] 1260 	mov	a,r2
      004620 4B               [12] 1261 	orl	a,r3
      004621 60 5D            [24] 1262 	jz	00106$
                                   1263 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      004623 8E 02            [24] 1264 	mov	ar2,r6
      004625 8F 03            [24] 1265 	mov	ar3,r7
      004627 74 D8            [12] 1266 	mov	a,#0x100 - 0x28
      004629 2B               [12] 1267 	add	a,r3
      00462A 50 17            [24] 1268 	jnc	00102$
      00462C 90 05 EE         [24] 1269 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00462F 12 48 A7         [24] 1270 	lcall	_ak820_outline_0119
      004632 12 48 BE         [24] 1271 	lcall	_ak820_outline_0140
      004635 E4               [12] 1272 	clr	a
      004636 F0               [24] 1273 	movx	@dptr,a
      004637 90 05 EE         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00463A 04               [12] 1275 	inc	a
      00463B 2A               [12] 1276 	add	a, r2
      00463C F0               [24] 1277 	movx	@dptr,a
      00463D E4               [12] 1278 	clr	a
      00463E 3B               [12] 1279 	addc	a, r3
      00463F A3               [24] 1280 	inc	dptr
      004640 F0               [24] 1281 	movx	@dptr,a
      004641 80 D3            [24] 1282 	sjmp	00103$
      004643                       1283 00102$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004643 90 05 EE         [24] 1285 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004646 12 48 A7         [24] 1286 	lcall	_ak820_outline_0119
      004649 12 48 A2         [24] 1287 	lcall	_ak820_outline_0116
      00464C C0 07            [24] 1288 	push	ar7
      00464E C0 06            [24] 1289 	push	ar6
      004650 C0 05            [24] 1290 	push	ar5
      004652 C0 04            [24] 1291 	push	ar4
      004654 C0 03            [24] 1292 	push	ar3
      004656 C0 02            [24] 1293 	push	ar2
      004658 12 45 61         [24] 1294 	lcall	_read_offset
      00465B A9 82            [24] 1295 	mov	r1, dpl
      00465D D0 02            [24] 1296 	pop	ar2
      00465F D0 03            [24] 1297 	pop	ar3
      004661 D0 04            [24] 1298 	pop	ar4
      004663 D0 05            [24] 1299 	pop	ar5
      004665 D0 06            [24] 1300 	pop	ar6
      004667 D0 07            [24] 1301 	pop	ar7
      004669 12 48 BE         [24] 1302 	lcall	_ak820_outline_0140
      00466C E9               [12] 1303 	mov	a,r1
      00466D F0               [24] 1304 	movx	@dptr,a
      00466E 90 05 EE         [24] 1305 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004671 74 01            [12] 1306 	mov	a,#0x01
      004673 2A               [12] 1307 	add	a, r2
      004674 F0               [24] 1308 	movx	@dptr,a
      004675 E4               [12] 1309 	clr	a
      004676 3B               [12] 1310 	addc	a, r3
      004677 A3               [24] 1311 	inc	dptr
      004678 F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004679 0E               [12] 1314 	inc	r6
      00467A BE 00 99         [24] 1315 	cjne	r6,#0x00,00103$
      00467D 0F               [12] 1316 	inc	r7
      00467E 80 96            [24] 1317 	sjmp	00103$
      004680                       1318 00106$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004680 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1325 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1326 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1327 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1328 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1329 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1330 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function ak820_eeprom_write_block_xdata
                                   1335 ;	-----------------------------------------
      004681                       1336 _ak820_eeprom_write_block_xdata:
      004681 12 3A 8A         [24] 1337 	lcall	_ak820_outline_0104
      004684 90 05 F5         [24] 1338 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004687 12 3A 8F         [24] 1339 	lcall	_ak820_outline_0105
                                   1340 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00468A 90 05 F0         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00468D 12 3A 40         [24] 1342 	lcall	_ak820_outline_0051
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004690 90 05 F5         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004693 12 3A 5F         [24] 1345 	lcall	_ak820_outline_0059
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004696 8E 02            [24] 1347 	mov	ar2,r6
      004698 8F 03            [24] 1348 	mov	ar3,r7
      00469A C3               [12] 1349 	clr	c
      00469B E4               [12] 1350 	clr	a
      00469C 9A               [12] 1351 	subb	a,r2
      00469D 74 28            [12] 1352 	mov	a,#0x28
      00469F 9B               [12] 1353 	subb	a,r3
      0046A0 40 15            [24] 1354 	jc	00101$
                                   1355 ;	free result
      0046A2 E4               [12] 1356 	clr	a
      0046A3 C3               [12] 1357 	clr	c
      0046A4 9E               [12] 1358 	subb	a,r6
      0046A5 FA               [12] 1359 	mov	r2,a
      0046A6 74 28            [12] 1360 	mov	a,#0x28
      0046A8 9F               [12] 1361 	subb	a,r7
      0046A9 FB               [12] 1362 	mov	r3,a
      0046AA 90 05 F3         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0046AD 12 3A 84         [24] 1364 	lcall	_ak820_outline_0100
      0046B0 C3               [12] 1365 	clr	c
      0046B1 EA               [12] 1366 	mov	a,r2
      0046B2 98               [12] 1367 	subb	a,r0
      0046B3 EB               [12] 1368 	mov	a,r3
      0046B4 99               [12] 1369 	subb	a,r1
      0046B5 50 06            [24] 1370 	jnc	00125$
                                   1371 ;	free result
      0046B7                       1372 00101$:
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0046B7 75 82 0E         [24] 1374 	mov	dpl, #0x0e
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0046BA 02 40 CA         [24] 1376 	ljmp	_nvm_fail
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0046BD                       1378 00125$:
      0046BD 90 05 F3         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0046C0 12 48 A7         [24] 1380 	lcall	_ak820_outline_0119
      0046C3                       1381 00108$:
      0046C3 8A 00            [24] 1382 	mov	ar0,r2
      0046C5 8B 01            [24] 1383 	mov	ar1,r3
      0046C7 1A               [12] 1384 	dec	r2
      0046C8 BA FF 01         [24] 1385 	cjne	r2,#0xff,00159$
      0046CB 1B               [12] 1386 	dec	r3
      0046CC                       1387 00159$:
      0046CC E8               [12] 1388 	mov	a,r0
      0046CD 49               [12] 1389 	orl	a,r1
      0046CE 70 03            [24] 1390 	jnz	00160$
      0046D0 02 47 5A         [24] 1391 	ljmp	00110$
      0046D3                       1392 00160$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0046D3 C0 02            [24] 1394 	push	ar2
      0046D5 C0 03            [24] 1395 	push	ar3
      0046D7 12 48 8A         [24] 1396 	lcall	_ak820_outline_0092
      0046DA F9               [12] 1397 	mov	r1,a
      0046DB A3               [24] 1398 	inc	dptr
      0046DC 12 48 C3         [24] 1399 	lcall	_ak820_outline_0141
                                   1400 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0046DF 8E 0C            [24] 1401 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0046E1 8F 0D            [24] 1402 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0046E3 A8 0C            [24] 1403 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0046E5 E5 0D            [12] 1404 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0046E7 A2 E7            [12] 1405 	mov	c,acc.7
      0046E9 C8               [12] 1406 	xch	a,r0
      0046EA 33               [12] 1407 	rlc	a
      0046EB C8               [12] 1408 	xch	a,r0
      0046EC 33               [12] 1409 	rlc	a
      0046ED A2 E7            [12] 1410 	mov	c,acc.7
      0046EF C8               [12] 1411 	xch	a,r0
      0046F0 33               [12] 1412 	rlc	a
      0046F1 C8               [12] 1413 	xch	a,r0
      0046F2 33               [12] 1414 	rlc	a
      0046F3 C8               [12] 1415 	xch	a,r0
      0046F4 54 03            [12] 1416 	anl	a,#0x03
      0046F6 FB               [12] 1417 	mov	r3,a
      0046F7 88 82            [24] 1418 	mov	dpl, r0
      0046F9 C0 07            [24] 1419 	push	ar7
      0046FB C0 06            [24] 1420 	push	ar6
      0046FD C0 05            [24] 1421 	push	ar5
      0046FF C0 04            [24] 1422 	push	ar4
      004701 C0 03            [24] 1423 	push	ar3
      004703 C0 02            [24] 1424 	push	ar2
      004705 C0 01            [24] 1425 	push	ar1
      004707 12 44 EF         [24] 1426 	lcall	_load_page
      00470A E5 82            [12] 1427 	mov	a, dpl
      00470C D0 01            [24] 1428 	pop	ar1
      00470E D0 02            [24] 1429 	pop	ar2
      004710 D0 03            [24] 1430 	pop	ar3
      004712 D0 04            [24] 1431 	pop	ar4
      004714 D0 05            [24] 1432 	pop	ar5
      004716 D0 06            [24] 1433 	pop	ar6
      004718 D0 07            [24] 1434 	pop	ar7
      00471A D0 03            [24] 1435 	pop	ar3
      00471C D0 02            [24] 1436 	pop	ar2
      00471E 70 01            [24] 1437 	jnz	00105$
      004720 22               [24] 1438 	ret
      004721                       1439 00105$:
                                   1440 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004721 C0 06            [24] 1441 	push	ar6
      004723 C0 07            [24] 1442 	push	ar7
      004725 74 3F            [12] 1443 	mov	a,#0x3f
      004727 55 0C            [12] 1444 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004729 7F 00            [12] 1445 	mov	r7,#0x00
      00472B 24 7F            [12] 1446 	add	a, #_page_data
      00472D F5 0C            [12] 1447 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      00472F EF               [12] 1448 	mov	a,r7
      004730 34 05            [12] 1449 	addc	a, #(_page_data >> 8)
      004732 F5 0D            [12] 1450 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      004734 85 0C 82         [24] 1451 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004737 85 0D 83         [24] 1452 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00473A E0               [24] 1453 	movx	a,@dptr
      00473B B5 01 06         [24] 1454 	cjne	a,ar1,00162$
      00473E D0 07            [24] 1455 	pop	ar7
      004740 D0 06            [24] 1456 	pop	ar6
      004742 80 0E            [24] 1457 	sjmp	00107$
      004744                       1458 00162$:
      004744 D0 07            [24] 1459 	pop	ar7
      004746 D0 06            [24] 1460 	pop	ar6
                                   1461 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004748 85 0C 82         [24] 1462 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00474B 85 0D 83         [24] 1463 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00474E E9               [12] 1464 	mov	a,r1
      00474F F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1467 ;	assignBit
      004750 D2 09            [12] 1468 	setb	_page_dirty
      004752                       1469 00107$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004752 0E               [12] 1471 	inc	r6
      004753 BE 00 01         [24] 1472 	cjne	r6,#0x00,00163$
      004756 0F               [12] 1473 	inc	r7
      004757                       1474 00163$:
      004757 02 46 C3         [24] 1475 	ljmp	00108$
      00475A                       1476 00110$:
                                   1477 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00475A 90 05 C0         [24] 1478 	mov	dptr,#_batch_depth
      00475D E0               [24] 1479 	movx	a,@dptr
      00475E 70 03            [24] 1480 	jnz	00113$
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004760 02 43 6F         [24] 1482 	ljmp	_ak820_nvm_flush
      004763                       1483 00113$:
      004763 22               [24] 1484 	ret
                                   1485 ;------------------------------------------------------------
                                   1486 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1487 ;------------------------------------------------------------
                                   1488 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1489 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1490 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1491 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1492 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1493 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1494 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1495 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1496 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1497 ;------------------------------------------------------------
                                   1498 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1499 ;	-----------------------------------------
                                   1500 ;	 function ak820_eeprom_update_block_xdata
                                   1501 ;	-----------------------------------------
      004764                       1502 _ak820_eeprom_update_block_xdata:
      004764 12 3A 8A         [24] 1503 	lcall	_ak820_outline_0104
      004767 90 05 FC         [24] 1504 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00476A 12 3A 8F         [24] 1505 	lcall	_ak820_outline_0105
                                   1506 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      00476D 90 05 FC         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004770 12 3A 40         [24] 1508 	lcall	_ak820_outline_0051
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004773 90 05 F7         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004776 E0               [24] 1511 	movx	a,@dptr
      004777 F5 12            [12] 1512 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004779 A3               [24] 1513 	inc	dptr
      00477A E0               [24] 1514 	movx	a,@dptr
      00477B F5 13            [12] 1515 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      00477D A3               [24] 1516 	inc	dptr
      00477E E0               [24] 1517 	movx	a,@dptr
      00477F F5 14            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004781 A9 12            [24] 1519 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004783 AA 13            [24] 1520 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1521 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004785 E4               [12] 1522 	clr	a
      004786 F5 0E            [12] 1523 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004788 F5 0F            [12] 1524 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00478A                       1525 00105$:
      00478A 90 05 FA         [24] 1526 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00478D E0               [24] 1527 	movx	a,@dptr
      00478E F5 10            [12] 1528 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004790 A3               [24] 1529 	inc	dptr
      004791 E0               [24] 1530 	movx	a,@dptr
      004792 F5 11            [12] 1531 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004794 C3               [12] 1532 	clr	c
      004795 E5 0E            [12] 1533 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004797 95 10            [12] 1534 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004799 E5 0F            [12] 1535 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00479B 95 11            [12] 1536 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00479D 50 68            [24] 1537 	jnc	00107$
                                   1538 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      00479F 89 00            [24] 1539 	mov	ar0,r1
      0047A1 8A 05            [24] 1540 	mov	ar5,r2
      0047A3 E5 0E            [12] 1541 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0047A5 28               [12] 1542 	add	a, r0
      0047A6 F8               [12] 1543 	mov	r0,a
      0047A7 E5 0F            [12] 1544 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0047A9 3D               [12] 1545 	addc	a, r5
      0047AA FD               [12] 1546 	mov	r5,a
      0047AB 88 82            [24] 1547 	mov	dpl, r0
      0047AD 8D 83            [24] 1548 	mov	dph, r5
      0047AF C0 07            [24] 1549 	push	ar7
      0047B1 C0 06            [24] 1550 	push	ar6
      0047B3 C0 02            [24] 1551 	push	ar2
      0047B5 C0 01            [24] 1552 	push	ar1
      0047B7 12 45 61         [24] 1553 	lcall	_read_offset
      0047BA AD 82            [24] 1554 	mov	r5, dpl
      0047BC D0 01            [24] 1555 	pop	ar1
      0047BE D0 02            [24] 1556 	pop	ar2
      0047C0 D0 06            [24] 1557 	pop	ar6
      0047C2 D0 07            [24] 1558 	pop	ar7
      0047C4 E5 0E            [12] 1559 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0047C6 2E               [12] 1560 	add	a, r6
      0047C7 F5 82            [12] 1561 	mov	dpl,a
      0047C9 E5 0F            [12] 1562 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0047CB 3F               [12] 1563 	addc	a, r7
      0047CC F5 83            [12] 1564 	mov	dph,a
      0047CE E0               [24] 1565 	movx	a,@dptr
      0047CF FC               [12] 1566 	mov	r4,a
      0047D0 ED               [12] 1567 	mov	a,r5
      0047D1 B5 04 02         [24] 1568 	cjne	a,ar4,00131$
      0047D4 80 27            [24] 1569 	sjmp	00106$
      0047D6                       1570 00131$:
                                   1571 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      0047D6 90 05 FC         [24] 1572 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0047D9 E0               [24] 1573 	movx	a,@dptr
      0047DA F8               [12] 1574 	mov	r0,a
      0047DB A3               [24] 1575 	inc	dptr
      0047DC E0               [24] 1576 	movx	a,@dptr
      0047DD FD               [12] 1577 	mov	r5,a
      0047DE 90 05 F0         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0047E1 E5 12            [12] 1579 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0047E3 F0               [24] 1580 	movx	@dptr,a
      0047E4 E5 13            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0047E6 A3               [24] 1582 	inc	dptr
      0047E7 F0               [24] 1583 	movx	@dptr,a
      0047E8 E5 14            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0047EA A3               [24] 1585 	inc	dptr
      0047EB F0               [24] 1586 	movx	@dptr,a
      0047EC 90 05 F3         [24] 1587 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0047EF E5 10            [12] 1588 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0047F1 F0               [24] 1589 	movx	@dptr,a
      0047F2 E5 11            [12] 1590 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0047F4 A3               [24] 1591 	inc	dptr
      0047F5 F0               [24] 1592 	movx	@dptr,a
      0047F6 88 82            [24] 1593 	mov	dpl, r0
      0047F8 8D 83            [24] 1594 	mov	dph, r5
                                   1595 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0047FA 02 46 81         [24] 1596 	ljmp	_ak820_eeprom_write_block_xdata
      0047FD                       1597 00106$:
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0047FD 05 0E            [12] 1599 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0047FF E4               [12] 1600 	clr	a
      004800 B5 0E 87         [24] 1601 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004803 05 0F            [12] 1602 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004805 80 83            [24] 1603 	sjmp	00105$
      004807                       1604 00107$:
                                   1605 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      004807 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1609 ;------------------------------------------------------------
                                   1610 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1611 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function eeprom_driver_erase
                                   1616 ;	-----------------------------------------
      004808                       1617 _eeprom_driver_erase:
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      004808 12 43 6F         [24] 1619 	lcall	_ak820_nvm_flush
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00480B 7F 00            [12] 1621 	mov	r7,#0x00
      00480D                       1622 00111$:
      00480D BF A0 01         [24] 1623 	cjne	r7,#0xa0,00165$
      004810 22               [24] 1624 	ret
      004811                       1625 00165$:
      004811 20 0A 32         [24] 1626 	jb	_storage_failed,00113$
                                   1627 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004814 8F 82            [24] 1628 	mov	dpl, r7
      004816 C0 07            [24] 1629 	push	ar7
      004818 12 44 EF         [24] 1630 	lcall	_load_page
      00481B E5 82            [12] 1631 	mov	a, dpl
      00481D D0 07            [24] 1632 	pop	ar7
      00481F 70 01            [24] 1633 	jnz	00126$
                                   1634 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004821 22               [24] 1635 	ret
      004822                       1636 00126$:
      004822 7E 00            [12] 1637 	mov	r6,#0x00
      004824                       1638 00107$:
                                   1639 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      004824 EE               [12] 1640 	mov	a,r6
      004825 24 7F            [12] 1641 	add	a, #_page_data
      004827 FC               [12] 1642 	mov	r4,a
      004828 E4               [12] 1643 	clr	a
      004829 34 05            [12] 1644 	addc	a, #(_page_data >> 8)
      00482B FD               [12] 1645 	mov	r5,a
      00482C 12 48 8A         [24] 1646 	lcall	_ak820_outline_0092
      00482F 60 07            [24] 1647 	jz	00108$
      004831 12 3A A0         [24] 1648 	lcall	_ak820_outline_0121
      004834 E4               [12] 1649 	clr	a
      004835 F0               [24] 1650 	movx	@dptr,a
                                   1651 ;	assignBit
      004836 D2 09            [12] 1652 	setb	_page_dirty
      004838                       1653 00108$:
                                   1654 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004838 0E               [12] 1655 	inc	r6
      004839 BE 40 E8         [24] 1656 	cjne	r6,#0x40,00107$
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      00483C C0 07            [24] 1658 	push	ar7
      00483E 12 43 6F         [24] 1659 	lcall	_ak820_nvm_flush
      004841 D0 07            [24] 1660 	pop	ar7
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004843 0F               [12] 1662 	inc	r7
      004844 80 C7            [24] 1663 	sjmp	00111$
      004846                       1664 00113$:
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004846 22               [24] 1666 	ret
                                   1667 	.area CSEG    (CODE)
                                   1668 	.area CONST   (CODE)
                                   1669 	.area XINIT   (CODE)
                                   1670 	.area CABS    (ABS,CODE)
                                   1671 
                                   1672 ; Experimental exact instruction outlining.
                                   1673 	.globl _ak820_outline_0004
                                   1674 	.globl _ak820_outline_0009
                                   1675 	.globl _ak820_outline_0015
                                   1676 	.globl _ak820_outline_0016
                                   1677 	.globl _ak820_outline_0029
                                   1678 	.globl _ak820_outline_0036
                                   1679 	.globl _ak820_outline_0039
                                   1680 	.globl _ak820_outline_0051
                                   1681 	.globl _ak820_outline_0052
                                   1682 	.globl _ak820_outline_0059
                                   1683 	.globl _ak820_outline_0060
                                   1684 	.globl _ak820_outline_0064
                                   1685 	.globl _ak820_outline_0070
                                   1686 	.globl _ak820_outline_0077
                                   1687 	.globl _ak820_outline_0092
                                   1688 	.globl _ak820_outline_0094
                                   1689 	.globl _ak820_outline_0100
                                   1690 	.globl _ak820_outline_0102
                                   1691 	.globl _ak820_outline_0104
                                   1692 	.globl _ak820_outline_0105
                                   1693 	.globl _ak820_outline_0116
                                   1694 	.globl _ak820_outline_0119
                                   1695 	.globl _ak820_outline_0120
                                   1696 	.globl _ak820_outline_0121
                                   1697 	.globl _ak820_outline_0122
                                   1698 	.globl _ak820_outline_0131
                                   1699 	.globl _ak820_outline_0132
                                   1700 	.globl _ak820_outline_0134
                                   1701 	.globl _ak820_outline_0139
                                   1702 	.globl _ak820_outline_0140
                                   1703 	.globl _ak820_outline_0141
                                   1704 	.globl _ak820_outline_0153
                                   1705 	.globl _ak820_outline_0156
                                   1706 	.globl _ak820_outline_0157
                                   1707 	.globl _ak820_outline_0166
                                   1708 	.globl _ak820_outline_0179
                                   1709 	.globl _ak820_outline_0180
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0009
      004847                       1713 _ak820_outline_0009:
      004847 8E 82            [24] 1714 	mov	dpl,r6
      004849 8F 83            [24] 1715 	mov	dph,r7
      00484B A3               [24] 1716 	inc	dptr
      00484C A3               [24] 1717 	inc	dptr
      00484D A3               [24] 1718 	inc	dptr
      00484E A3               [24] 1719 	inc	dptr
      00484F A3               [24] 1720 	inc	dptr
      004850 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0029
      004851                       1725 _ak820_outline_0029:
      004851 F0               [24] 1726 	movx	@dptr,a
      004852 8E 82            [24] 1727 	mov	dpl,r6
      004854 8F 83            [24] 1728 	mov	dph,r7
      004856 A3               [24] 1729 	inc	dptr
      004857 A3               [24] 1730 	inc	dptr
      004858 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0036
      004859                       1735 _ak820_outline_0036:
      004859 AF F0            [24] 1736 	mov	r7,b
      00485B AE 83            [24] 1737 	mov	r6,dph
      00485D E5 82            [12] 1738 	mov	a,dpl
      00485F 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0039
      004860                       1743 _ak820_outline_0039:
      004860 EF               [12] 1744 	mov	a,r7
      004861 24 D7            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      004863 F5 82            [12] 1746 	mov	dpl,a
      004865 E4               [12] 1747 	clr	a
      004866 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004868 F5 83            [12] 1749 	mov	dph,a
      00486A E0               [24] 1750 	movx	a,@dptr
      00486B 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0052
      00486C                       1755 _ak820_outline_0052:
      00486C 8F 06            [24] 1756 	mov	ar6,r7
      00486E 7D 00            [12] 1757 	mov	r5,#0x00
      004870 74 40            [12] 1758 	mov	a,#0x40
      004872 2E               [12] 1759 	add	a,r6
      004873 FE               [12] 1760 	mov	r6,a
      004874 74 EF            [12] 1761 	mov	a,#0xef
      004876 3D               [12] 1762 	addc	a,r5
      004877 FD               [12] 1763 	mov	r5,a
      004878 8E 82            [24] 1764 	mov	dpl,r6
      00487A 8D 83            [24] 1765 	mov	dph,r5
      00487C 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0060
      00487D                       1770 _ak820_outline_0060:
      00487D F0               [24] 1771 	movx	@dptr,a
      00487E 8E 82            [24] 1772 	mov	dpl,r6
      004880 8F 83            [24] 1773 	mov	dph,r7
      004882 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0064
      004883                       1778 _ak820_outline_0064:
      004883 8D 82            [24] 1779 	mov	dpl,r5
      004885 8E 83            [24] 1780 	mov	dph,r6
      004887 EC               [12] 1781 	mov	a,r4
      004888 F0               [24] 1782 	movx	@dptr,a
      004889 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0092
      00488A                       1787 _ak820_outline_0092:
      00488A 8C 82            [24] 1788 	mov	dpl,r4
      00488C 8D 83            [24] 1789 	mov	dph,r5
      00488E E0               [24] 1790 	movx	a,@dptr
      00488F 22               [24] 1791 	ret
                                   1792 
                                   1793 	.area CSEG (CODE)
                                   1794 ; function ak820_outline_0094
      004890                       1795 _ak820_outline_0094:
      004890 E0               [24] 1796 	movx	a,@dptr
      004891 FD               [12] 1797 	mov	r5,a
      004892 A3               [24] 1798 	inc	dptr
      004893 E0               [24] 1799 	movx	a,@dptr
      004894 FE               [12] 1800 	mov	r6,a
      004895 22               [24] 1801 	ret
                                   1802 
                                   1803 	.area CSEG (CODE)
                                   1804 ; function ak820_outline_0102
      004896                       1805 _ak820_outline_0102:
      004896 EF               [12] 1806 	mov	a,r7
      004897 24 7F            [12] 1807 	add	a,#_page_data
      004899 F5 82            [12] 1808 	mov	dpl,a
      00489B E4               [12] 1809 	clr	a
      00489C 34 05            [12] 1810 	addc	a,#(_page_data>>8)
      00489E F5 83            [12] 1811 	mov	dph,a
      0048A0 E0               [24] 1812 	movx	a,@dptr
      0048A1 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0116
      0048A2                       1817 _ak820_outline_0116:
      0048A2 8E 82            [24] 1818 	mov	dpl,r6
      0048A4 8F 83            [24] 1819 	mov	dph,r7
      0048A6 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0119
      0048A7                       1824 _ak820_outline_0119:
      0048A7 E0               [24] 1825 	movx	a,@dptr
      0048A8 FA               [12] 1826 	mov	r2,a
      0048A9 A3               [24] 1827 	inc	dptr
      0048AA E0               [24] 1828 	movx	a,@dptr
      0048AB FB               [12] 1829 	mov	r3,a
      0048AC 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0131
      0048AD                       1834 _ak820_outline_0131:
      0048AD AE 82            [24] 1835 	mov	r6,dpl
      0048AF AF 83            [24] 1836 	mov	r7,dph
      0048B1 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0134
      0048B2                       1841 _ak820_outline_0134:
      0048B2 2E               [12] 1842 	add	a,r6
      0048B3 FE               [12] 1843 	mov	r6,a
      0048B4 E4               [12] 1844 	clr	a
      0048B5 3F               [12] 1845 	addc	a,r7
      0048B6 FF               [12] 1846 	mov	r7,a
      0048B7 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0139
      0048B8                       1851 _ak820_outline_0139:
      0048B8 42 05            [12] 1852 	orl	ar5,a
      0048BA EA               [12] 1853 	mov	a,r2
      0048BB 42 04            [12] 1854 	orl	ar4,a
      0048BD 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0140
      0048BE                       1859 _ak820_outline_0140:
      0048BE 8A 82            [24] 1860 	mov	dpl,r2
      0048C0 8B 83            [24] 1861 	mov	dph,r3
      0048C2 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0141
      0048C3                       1866 _ak820_outline_0141:
      0048C3 AC 82            [24] 1867 	mov	r4,dpl
      0048C5 AD 83            [24] 1868 	mov	r5,dph
      0048C7 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0153
      0048C8                       1873 _ak820_outline_0153:
      0048C8 8F 82            [24] 1874 	mov	dpl,r7
      0048CA 8E 83            [24] 1875 	mov	dph,r6
      0048CC 22               [24] 1876 	ret
                                   1877 
                                   1878 	.area CSEG (CODE)
                                   1879 ; function ak820_outline_0156
      0048CD                       1880 _ak820_outline_0156:
      0048CD 2E               [12] 1881 	add	a,r6
      0048CE FC               [12] 1882 	mov	r4,a
      0048CF E4               [12] 1883 	clr	a
      0048D0 3F               [12] 1884 	addc	a,r7
      0048D1 FD               [12] 1885 	mov	r5,a
      0048D2 22               [24] 1886 	ret
                                   1887 
                                   1888 	.area CSEG (CODE)
                                   1889 ; function ak820_outline_0157
      0048D3                       1890 _ak820_outline_0157:
      0048D3 ED               [12] 1891 	mov	a,r5
      0048D4 F0               [24] 1892 	movx	@dptr,a
      0048D5 EE               [12] 1893 	mov	a,r6
      0048D6 A3               [24] 1894 	inc	dptr
      0048D7 F0               [24] 1895 	movx	@dptr,a
      0048D8 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0179
      0048D9                       1900 _ak820_outline_0179:
      0048D9 89 82            [24] 1901 	mov	dpl,r1
      0048DB 8A 83            [24] 1902 	mov	dph,r2
      0048DD 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0180
      0048DE                       1907 _ak820_outline_0180:
      0048DE 8C 82            [24] 1908 	mov	dpl,r4
      0048E0 8B 83            [24] 1909 	mov	dph,r3
      0048E2 22               [24] 1910 	ret
