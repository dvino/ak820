                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _ak820_resolve_key
                                     24 	.globl _default_layer_set
                                     25 	.globl _clear_keyboard
                                     26 	.globl _unregister_weak_mods
                                     27 	.globl _register_weak_mods
                                     28 	.globl _unregister_mods
                                     29 	.globl _register_mods
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _eeconfig_disable
                                     33 	.globl _rgb_matrix_set_suspend_state
                                     34 	.globl _rgb_matrix_task
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _process_record_quantum_helper_PARM_2
                                    280 	.globl _get_record_keycode_PARM_2
                                    281 	.globl _register_code16
                                    282 	.globl _unregister_code16
                                    283 	.globl _reset_keyboard
                                    284 	.globl _soft_reset_keyboard
                                    285 	.globl _get_record_keycode
                                    286 	.globl _pre_process_record_quantum
                                    287 	.globl _process_record_quantum
                                    288 	.globl _process_record_quantum_helper
                                    289 	.globl _shutdown_user
                                    290 ;--------------------------------------------------------
                                    291 ; special function registers
                                    292 ;--------------------------------------------------------
                                    293 	.area RSEG    (ABS,DATA)
      000000                        294 	.org 0x0000
                           0000D0   295 _PSW	=	0x00d0
                           0000E0   296 _ACC	=	0x00e0
                           0000F0   297 _B	=	0x00f0
                           0000FD   298 _A_INV	=	0x00fd
                           000081   299 _SP	=	0x0081
                           000082   300 _DPL	=	0x0082
                           000083   301 _DPH	=	0x0083
                           0000A1   302 _SAFE_MOD	=	0x00a1
                           0000B1   303 _GLOBAL_CFG	=	0x00b1
                           000087   304 _PCON	=	0x0087
                           0000BA   305 _POWER_CFG	=	0x00ba
                           0000B9   306 _CLOCK_CFG	=	0x00b9
                           0000A9   307 _WAKE_CTRL	=	0x00a9
                           0000FE   308 _RESET_KEEP	=	0x00fe
                           0000FF   309 _WDOG_COUNT	=	0x00ff
                           0000A8   310 _IE	=	0x00a8
                           0000B8   311 _IP	=	0x00b8
                           0000E8   312 _IE_EX	=	0x00e8
                           0000E9   313 _IP_EX	=	0x00e9
                           0000B2   314 _GPIO_IE	=	0x00b2
                           008584   315 _ROM_ADDR	=	0x8584
                           000084   316 _ROM_ADDR_L	=	0x0084
                           000085   317 _ROM_ADDR_H	=	0x0085
                           008F8E   318 _ROM_DATA_HI	=	0x8f8e
                           00008E   319 _ROM_DATA_HL	=	0x008e
                           00008F   320 _ROM_DATA_HH	=	0x008f
                           000086   321 _ROM_CTRL	=	0x0086
                           000080   322 _P0	=	0x0080
                           0000C4   323 _P0_MOD_OC	=	0x00c4
                           0000C5   324 _P0_DIR_PU	=	0x00c5
                           000090   325 _P1	=	0x0090
                           000092   326 _P1_MOD_OC	=	0x0092
                           000093   327 _P1_DIR_PU	=	0x0093
                           0000A0   328 _P2	=	0x00a0
                           000094   329 _P2_MOD_OC	=	0x0094
                           000095   330 _P2_DIR_PU	=	0x0095
                           0000B0   331 _P3	=	0x00b0
                           000096   332 _P3_MOD_OC	=	0x0096
                           000097   333 _P3_DIR_PU	=	0x0097
                           0000C0   334 _P4	=	0x00c0
                           0000C2   335 _P4_MOD_OC	=	0x00c2
                           0000C3   336 _P4_DIR_PU	=	0x00c3
                           0000C1   337 _P4_LED_KEY	=	0x00c1
                           0000AA   338 _P5_IN	=	0x00aa
                           0000AB   339 _P5_OUT_PU	=	0x00ab
                           0000AC   340 _P5_DIR	=	0x00ac
                           0000AD   341 _P6_IN	=	0x00ad
                           0000AE   342 _P6_OUT_PU	=	0x00ae
                           0000AF   343 _P6_DIR	=	0x00af
                           0000F1   344 _P7	=	0x00f1
                           0000A2   345 _XBUS_AUX	=	0x00a2
                           000088   346 _TCON	=	0x0088
                           000089   347 _TMOD	=	0x0089
                           00008A   348 _TL0	=	0x008a
                           00008B   349 _TL1	=	0x008b
                           00008C   350 _TH0	=	0x008c
                           00008D   351 _TH1	=	0x008d
                           000098   352 _SCON	=	0x0098
                           000099   353 _SBUF	=	0x0099
                           0000C8   354 _T2CON	=	0x00c8
                           0000C9   355 _T2MOD	=	0x00c9
                           00CBCA   356 _RCAP2	=	0xcbca
                           0000CA   357 _RCAP2L	=	0x00ca
                           0000CB   358 _RCAP2H	=	0x00cb
                           00CDCC   359 _T2COUNT	=	0xcdcc
                           0000CC   360 _TL2	=	0x00cc
                           0000CD   361 _TH2	=	0x00cd
                           00CFCE   362 _T2CAP1	=	0xcfce
                           0000CE   363 _T2CAP1L	=	0x00ce
                           0000CF   364 _T2CAP1H	=	0x00cf
                           0000F8   365 _SPI0_STAT	=	0x00f8
                           0000F9   366 _SPI0_DATA	=	0x00f9
                           0000FA   367 _SPI0_CTRL	=	0x00fa
                           0000FB   368 _SPI0_CK_SE	=	0x00fb
                           0000FC   369 _SPI0_SETUP	=	0x00fc
                           0000BC   370 _SCON1	=	0x00bc
                           0000BD   371 _SBUF1	=	0x00bd
                           0000BE   372 _SBAUD1	=	0x00be
                           0000BF   373 _SIF1	=	0x00bf
                           0000B4   374 _SPI1_STAT	=	0x00b4
                           0000B5   375 _SPI1_DATA	=	0x00b5
                           0000B6   376 _SPI1_CTRL	=	0x00b6
                           0000B7   377 _SPI1_CK_SE	=	0x00b7
                           0000F3   378 _ADC_CTRL	=	0x00f3
                           00F5F4   379 _ADC_DAT	=	0xf5f4
                           0000F4   380 _ADC_DAT_L	=	0x00f4
                           0000F5   381 _ADC_DAT_H	=	0x00f5
                           0000F6   382 _ADC_CHAN	=	0x00f6
                           0000A6   383 _LED_COMMON	=	0x00a6
                           0000A7   384 _LED_PWM_OE	=	0x00a7
                           00C7C6   385 _LED_DMA	=	0xc7c6
                           0000C6   386 _LED_DMA_L	=	0x00c6
                           0000C7   387 _LED_DMA_H	=	0x00c7
                           0000F7   388 _LED_STATUS	=	0x00f7
                           0000B3   389 _I2CX_INT	=	0x00b3
                           0000BB   390 _I2CS_INT_ST	=	0x00bb
                                    391 ;--------------------------------------------------------
                                    392 ; special function bits
                                    393 ;--------------------------------------------------------
                                    394 	.area RSEG    (ABS,DATA)
      000000                        395 	.org 0x0000
                           0000D7   396 _CY	=	0x00d7
                           0000D6   397 _AC	=	0x00d6
                           0000D5   398 _F0	=	0x00d5
                           0000D4   399 _RS1	=	0x00d4
                           0000D3   400 _RS0	=	0x00d3
                           0000D2   401 _OV	=	0x00d2
                           0000D1   402 _F1	=	0x00d1
                           0000D0   403 _P	=	0x00d0
                           0000AF   404 _EA	=	0x00af
                           0000AE   405 _E_DIS	=	0x00ae
                           0000AD   406 _ET2	=	0x00ad
                           0000AC   407 _ES	=	0x00ac
                           0000AB   408 _ET1	=	0x00ab
                           0000AA   409 _EX1	=	0x00aa
                           0000A9   410 _ET0	=	0x00a9
                           0000A8   411 _EX0	=	0x00a8
                           0000BF   412 _PH_FLAG	=	0x00bf
                           0000BE   413 _PL_FLAG	=	0x00be
                           0000BD   414 _PT2	=	0x00bd
                           0000BC   415 _PS	=	0x00bc
                           0000BB   416 _PT1	=	0x00bb
                           0000BA   417 _PX1	=	0x00ba
                           0000B9   418 _PT0	=	0x00b9
                           0000B8   419 _PX0	=	0x00b8
                           0000EF   420 _IE_WDOG	=	0x00ef
                           0000EE   421 _IE_GPIO	=	0x00ee
                           0000ED   422 _IE_PWM_I2C	=	0x00ed
                           0000EC   423 _IE_UART1	=	0x00ec
                           0000EB   424 _IE_ADC	=	0x00eb
                           0000E9   425 _IE_USB	=	0x00e9
                           0000E8   426 _IE_SPI0	=	0x00e8
                           000087   427 _P0_7	=	0x0087
                           000086   428 _P0_6	=	0x0086
                           000085   429 _P0_5	=	0x0085
                           000084   430 _P0_4	=	0x0084
                           000083   431 _P0_3	=	0x0083
                           000082   432 _P0_2	=	0x0082
                           000081   433 _P0_1	=	0x0081
                           000080   434 _P0_0	=	0x0080
                           000081   435 _SDA0	=	0x0081
                           000080   436 _SCL0	=	0x0080
                           000083   437 _TXD_	=	0x0083
                           000082   438 _RXD_	=	0x0082
                           000085   439 _AIN13	=	0x0085
                           000084   440 _AIN12	=	0x0084
                           000083   441 _AIN11	=	0x0083
                           000082   442 _AIN10	=	0x0082
                           000081   443 _AIN9	=	0x0081
                           000080   444 _AIN8	=	0x0080
                           000097   445 _P1_7	=	0x0097
                           000096   446 _P1_6	=	0x0096
                           000095   447 _P1_5	=	0x0095
                           000094   448 _P1_4	=	0x0094
                           000093   449 _P1_3	=	0x0093
                           000092   450 _P1_2	=	0x0092
                           000091   451 _P1_1	=	0x0091
                           000090   452 _P1_0	=	0x0090
                           000097   453 _TXD1_	=	0x0097
                           000096   454 _RXD1_	=	0x0096
                           000097   455 _SCK	=	0x0097
                           000096   456 _MISO	=	0x0096
                           000095   457 _MOSI	=	0x0095
                           000094   458 _SCS	=	0x0094
                           000092   459 _INT0_	=	0x0092
                           000091   460 _T2EX	=	0x0091
                           000091   461 _CAP2	=	0x0091
                           000090   462 _T2	=	0x0090
                           000090   463 _CAP1	=	0x0090
                           000097   464 _AIN7	=	0x0097
                           000096   465 _AIN6	=	0x0096
                           000095   466 _AIN5	=	0x0095
                           000094   467 _AIN4	=	0x0094
                           000093   468 _AIN3	=	0x0093
                           000092   469 _AIN2	=	0x0092
                           000091   470 _AIN1	=	0x0091
                           000090   471 _AIN0	=	0x0090
                           0000A7   472 _P2_7	=	0x00a7
                           0000A6   473 _P2_6	=	0x00a6
                           0000A5   474 _P2_5	=	0x00a5
                           0000A4   475 _P2_4	=	0x00a4
                           0000A3   476 _P2_3	=	0x00a3
                           0000A2   477 _P2_2	=	0x00a2
                           0000A1   478 _P2_1	=	0x00a1
                           0000A0   479 _P2_0	=	0x00a0
                           0000A7   480 _TXD1	=	0x00a7
                           0000A6   481 _RXD1	=	0x00a6
                           0000A5   482 _T2EX_	=	0x00a5
                           0000A5   483 _CAP2_	=	0x00a5
                           0000A4   484 _T2_	=	0x00a4
                           0000A4   485 _CAP1_	=	0x00a4
                           0000B7   486 _P3_7	=	0x00b7
                           0000B6   487 _P3_6	=	0x00b6
                           0000B5   488 _P3_5	=	0x00b5
                           0000B4   489 _P3_4	=	0x00b4
                           0000B3   490 _P3_3	=	0x00b3
                           0000B2   491 _P3_2	=	0x00b2
                           0000B1   492 _P3_1	=	0x00b1
                           0000B0   493 _P3_0	=	0x00b0
                           0000B7   494 _SCK1	=	0x00b7
                           0000B6   495 _MISO1	=	0x00b6
                           0000B5   496 _MOSI1	=	0x00b5
                           0000B5   497 _T1	=	0x00b5
                           0000B4   498 _T0	=	0x00b4
                           0000B3   499 _INT1	=	0x00b3
                           0000B2   500 _INT0	=	0x00b2
                           0000B1   501 _TXD	=	0x00b1
                           0000B0   502 _RXD	=	0x00b0
                           0000C6   503 _P4_6	=	0x00c6
                           0000C5   504 _P4_5	=	0x00c5
                           0000C4   505 _P4_4	=	0x00c4
                           0000C3   506 _P4_3	=	0x00c3
                           0000C2   507 _P4_2	=	0x00c2
                           0000C1   508 _P4_1	=	0x00c1
                           0000C0   509 _P4_0	=	0x00c0
                           00008F   510 _TF1	=	0x008f
                           00008E   511 _TR1	=	0x008e
                           00008D   512 _TF0	=	0x008d
                           00008C   513 _TR0	=	0x008c
                           00008B   514 _IE1	=	0x008b
                           00008A   515 _IT1	=	0x008a
                           000089   516 _IE0	=	0x0089
                           000088   517 _IT0	=	0x0088
                           00009F   518 _SM0	=	0x009f
                           00009E   519 _SM1	=	0x009e
                           00009D   520 _SM2	=	0x009d
                           00009C   521 _REN	=	0x009c
                           00009B   522 _TB8	=	0x009b
                           00009A   523 _RB8	=	0x009a
                           000099   524 _TI	=	0x0099
                           000098   525 _RI	=	0x0098
                           0000CF   526 _TF2	=	0x00cf
                           0000CF   527 _CAP1F	=	0x00cf
                           0000CE   528 _EXF2	=	0x00ce
                           0000CD   529 _RCLK	=	0x00cd
                           0000CC   530 _TCLK	=	0x00cc
                           0000CB   531 _EXEN2	=	0x00cb
                           0000CA   532 _TR2	=	0x00ca
                           0000C9   533 _C_T2	=	0x00c9
                           0000C8   534 _CP_RL2	=	0x00c8
                           0000FF   535 _S0_FST_ACT	=	0x00ff
                           0000FE   536 _S0_IF_OV	=	0x00fe
                           0000FD   537 _S0_IF_FIRST	=	0x00fd
                           0000FC   538 _S0_IF_BYTE	=	0x00fc
                           0000FB   539 _S0_FREE	=	0x00fb
                           0000FA   540 _S0_T_FIFO	=	0x00fa
                           0000F8   541 _S0_R_FIFO	=	0x00f8
                           0000F7   542 _ADC_START	=	0x00f7
                                    543 ;--------------------------------------------------------
                                    544 ; overlayable register banks
                                    545 ;--------------------------------------------------------
                                    546 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        547 	.ds 8
                                    548 ;--------------------------------------------------------
                                    549 ; internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area DSEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; overlayable items in internal ram
                                    554 ;--------------------------------------------------------
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      000023                        568 _get_record_keycode_sloc0_1_0:
      000023                        569 	.ds 1
      000024                        570 _pre_process_record_quantum_sloc0_1_0:
      000024                        571 	.ds 1
      000025                        572 _process_ak820_nkro_sloc0_1_0:
      000025                        573 	.ds 1
                                    574 ;--------------------------------------------------------
                                    575 ; paged external ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area PSEG    (PAG,XDATA)
                                    578 ;--------------------------------------------------------
                                    579 ; uninitialized external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area XSEG    (XDATA)
      000BCC                        582 _extract_mod_bits_code_10000_599:
      000BCC                        583 	.ds 2
      000BCE                        584 _register_code16_code_10000_605:
      000BCE                        585 	.ds 2
      000BD0                        586 _unregister_code16_code_10000_610:
      000BD0                        587 	.ds 2
      000BD2                        588 _get_record_keycode_PARM_2:
      000BD2                        589 	.ds 1
      000BD3                        590 _get_record_keycode_record_argument_10000_648:
      000BD3                        591 	.ds 2
      000BD5                        592 _pre_process_record_quantum_record_argument_10000_654:
      000BD5                        593 	.ds 2
      000BD7                        594 _process_record_quantum_record_10000_658:
      000BD7                        595 	.ds 2
      000BD9                        596 _process_ak820_nkro_PARM_2:
      000BD9                        597 	.ds 3
      000BDC                        598 _process_ak820_nkro_keycode_10000_660:
      000BDC                        599 	.ds 2
      000BDE                        600 _process_record_quantum_helper_PARM_2:
      000BDE                        601 	.ds 2
      000BE0                        602 _process_record_quantum_helper_keycode_10000_665:
      000BE0                        603 	.ds 2
      000BE2                        604 _get_u8_str_last_num_10000_691:
      000BE2                        605 	.ds 1
      000BE3                        606 _get_u16_str_last_num_10000_695:
      000BE3                        607 	.ds 2
                                    608 ;--------------------------------------------------------
                                    609 ; absolute external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area XABS    (ABS,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; initialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XISEG   (XDATA)
                                    616 	.area HOME    (CODE)
                                    617 	.area GSINIT0 (CODE)
                                    618 	.area GSINIT1 (CODE)
                                    619 	.area GSINIT2 (CODE)
                                    620 	.area GSINIT3 (CODE)
                                    621 	.area GSINIT4 (CODE)
                                    622 	.area GSINIT5 (CODE)
                                    623 	.area GSINIT  (CODE)
                                    624 	.area GSFINAL (CODE)
                                    625 	.area CSEG    (CODE)
                                    626 ;--------------------------------------------------------
                                    627 ; global & static initialisations
                                    628 ;--------------------------------------------------------
                                    629 	.area HOME    (CODE)
                                    630 	.area GSINIT  (CODE)
                                    631 	.area GSFINAL (CODE)
                                    632 	.area GSINIT  (CODE)
                                    633 ;------------------------------------------------------------
                                    634 ;Allocation info for local variables in function 'get_u8_str'
                                    635 ;------------------------------------------------------------
                                    636 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    637 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_690'
                                    638 ;buf           Allocated with name '_get_u8_str_buf_10000_691'
                                    639 ;last_num      Allocated with name '_get_u8_str_last_num_10000_691'
                                    640 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_691'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/quantum.c:789: static uint8_t last_num = 0xFF;
      0030F3 90 0B E2         [24]  643 	mov	dptr,#_get_u8_str_last_num_10000_691
      0030F6 74 FF            [12]  644 	mov	a,#0xff
      0030F8 F0               [24]  645 	movx	@dptr,a
                                    646 ;------------------------------------------------------------
                                    647 ;Allocation info for local variables in function 'get_u16_str'
                                    648 ;------------------------------------------------------------
                                    649 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    650 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_694'
                                    651 ;buf           Allocated with name '_get_u16_str_buf_10000_695'
                                    652 ;last_num      Allocated with name '_get_u16_str_last_num_10000_695'
                                    653 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_695'
                                    654 ;------------------------------------------------------------
                                    655 ;	quantum/quantum.c:809: static uint16_t last_num = 0xFF;
      0030F9 90 0B E3         [24]  656 	mov	dptr,#_get_u16_str_last_num_10000_695
      0030FC 74 FF            [12]  657 	mov	a,#0xff
      0030FE F0               [24]  658 	movx	@dptr,a
      0030FF E4               [12]  659 	clr	a
      003100 A3               [24]  660 	inc	dptr
      003101 F0               [24]  661 	movx	@dptr,a
                                    662 ;--------------------------------------------------------
                                    663 ; Home
                                    664 ;--------------------------------------------------------
                                    665 	.area HOME    (CODE)
                                    666 	.area HOME    (CODE)
                                    667 ;--------------------------------------------------------
                                    668 ; code
                                    669 ;--------------------------------------------------------
                                    670 	.area CSEG    (CODE)
                                    671 ;------------------------------------------------------------
                                    672 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    673 ;------------------------------------------------------------
                                    674 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    675 ;------------------------------------------------------------
                                    676 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    677 ;	-----------------------------------------
                           000007   678 	ar7 = 0x07
                           000006   679 	ar6 = 0x06
                           000005   680 	ar5 = 0x05
                           000004   681 	ar4 = 0x04
                           000003   682 	ar3 = 0x03
                           000002   683 	ar2 = 0x02
                           000001   684 	ar1 = 0x01
                           000000   685 	ar0 = 0x00
                                    686 ;	 function extract_mod_bits
                                    687 ;	-----------------------------------------
      009B40                        688 _extract_mod_bits:
      009B40 12 38 3B         [24]  689 	lcall	_ak820_outline_0103
      009B43 90 0B CC         [24]  690 	mov	dptr,#_extract_mod_bits_code_10000_599
      009B46 12 38 40         [24]  691 	lcall	_ak820_outline_0104
                                    692 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      009B49 90 0B CC         [24]  693 	mov	dptr,#_extract_mod_bits_code_10000_599
      009B4C E0               [24]  694 	movx	a,@dptr
      009B4D A3               [24]  695 	inc	dptr
      009B4E E0               [24]  696 	movx	a,@dptr
                                    697 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009B4F FF               [12]  698 	mov	r7,a
      009B50 60 05            [24]  699 	jz	00101$
      009B52 EF               [12]  700 	mov	a,r7
      009B53 24 E0            [12]  701 	add	a,#0xff - 0x1f
      009B55 50 04            [24]  702 	jnc	00102$
                                    703 ;	free result
      009B57                        704 00101$:
      009B57 75 82 00         [24]  705 	mov	dpl, #0x00
      009B5A 22               [24]  706 	ret
      009B5B                        707 00102$:
                                    708 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009B5B EF               [12]  709 	mov	a,r7
      009B5C 30 E4 07         [24]  710 	jnb	acc.4,00106$
      009B5F EF               [12]  711 	mov	a,r7
      009B60 C4               [12]  712 	swap	a
      009B61 54 F0            [12]  713 	anl	a,#0xf0
      009B63 FE               [12]  714 	mov	r6,a
      009B64 80 02            [24]  715 	sjmp	00107$
      009B66                        716 00106$:
      009B66 8F 06            [24]  717 	mov	ar6,r7
      009B68                        718 00107$:
      009B68 8E 82            [24]  719 	mov	dpl, r6
                                    720 ;	quantum/quantum.c:143: }
      009B6A 22               [24]  721 	ret
                                    722 ;------------------------------------------------------------
                                    723 ;Allocation info for local variables in function 'do_code16'
                                    724 ;------------------------------------------------------------
                                    725 ;f             Allocated with name '_do_code16_PARM_2'
                                    726 ;code          Allocated with name '_do_code16_code_10000_602'
                                    727 ;------------------------------------------------------------
                                    728 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    729 ;	-----------------------------------------
                                    730 ;	 function register_code16
                                    731 ;	-----------------------------------------
      009B6B                        732 _register_code16:
      009B6B 12 38 3B         [24]  733 	lcall	_ak820_outline_0103
      009B6E 90 0B CE         [24]  734 	mov	dptr,#_register_code16_code_10000_605
      009B71 12 38 40         [24]  735 	lcall	_ak820_outline_0104
                                    736 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      009B74 90 0B CE         [24]  737 	mov	dptr,#_register_code16_code_10000_605
      009B77 12 37 98         [24]  738 	lcall	_ak820_outline_0004
      009B7A C0 07            [24]  739 	push	ar7
      009B7C C0 06            [24]  740 	push	ar6
      009B7E 71 40            [12]  741 	acall	_extract_mod_bits
      009B80 AD 82            [24]  742 	mov	r5, dpl
      009B82 D0 06            [24]  743 	pop	ar6
      009B84 D0 07            [24]  744 	pop	ar7
                                    745 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009B86 12 99 81         [24]  746 	lcall	_ak820_outline_0114
      009B89 40 07            [24]  747 	jc	00105$
      009B8B 74 E7            [12]  748 	mov	a,#0xe7
      009B8D 9E               [12]  749 	subb	a,r6
      009B8E E4               [12]  750 	clr	a
      009B8F 9F               [12]  751 	subb	a,r7
      009B90 50 08            [24]  752 	jnc	00101$
                                    753 ;	free result
      009B92                        754 00105$:
      009B92 90 0B CE         [24]  755 	mov	dptr,#_register_code16_code_10000_605
      009B95 12 6C C6         [24]  756 	lcall	_ak820_outline_0035
      009B98 70 07            [24]  757 	jnz	00102$
      009B9A                        758 00101$:
                                    759 ;	quantum/quantum.c:153: register_mods(mods);
      009B9A 8D 82            [24]  760 	mov	dpl, r5
      009B9C 12 75 29         [24]  761 	lcall	_register_mods
      009B9F 80 05            [24]  762 	sjmp	00103$
      009BA1                        763 00102$:
                                    764 ;	quantum/quantum.c:155: register_weak_mods(mods);
      009BA1 8D 82            [24]  765 	mov	dpl, r5
      009BA3 12 75 51         [24]  766 	lcall	_register_weak_mods
      009BA6                        767 00103$:
                                    768 ;	quantum/quantum.c:157: register_code(code);
      009BA6 90 0B CE         [24]  769 	mov	dptr,#_register_code16_code_10000_605
      009BA9 E0               [24]  770 	movx	a,@dptr
      009BAA F5 82            [12]  771 	mov	dpl,a
                                    772 ;	quantum/quantum.c:167: }
      009BAC 02 74 09         [24]  773 	ljmp	_register_code
                                    774 ;------------------------------------------------------------
                                    775 ;Allocation info for local variables in function 'unregister_code16'
                                    776 ;------------------------------------------------------------
                                    777 ;code          Allocated with name '_unregister_code16_code_10000_610'
                                    778 ;mods          Allocated with name '_unregister_code16_mods_10000_611'
                                    779 ;------------------------------------------------------------
                                    780 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    781 ;	-----------------------------------------
                                    782 ;	 function unregister_code16
                                    783 ;	-----------------------------------------
      009BAF                        784 _unregister_code16:
      009BAF 12 38 3B         [24]  785 	lcall	_ak820_outline_0103
      009BB2 90 0B D0         [24]  786 	mov	dptr,#_unregister_code16_code_10000_610
      009BB5 12 38 40         [24]  787 	lcall	_ak820_outline_0104
                                    788 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      009BB8 90 0B D0         [24]  789 	mov	dptr,#_unregister_code16_code_10000_610
      009BBB 12 37 98         [24]  790 	lcall	_ak820_outline_0004
      009BBE C0 07            [24]  791 	push	ar7
      009BC0 C0 06            [24]  792 	push	ar6
      009BC2 71 40            [12]  793 	acall	_extract_mod_bits
      009BC4 AD 82            [24]  794 	mov	r5, dpl
      009BC6 D0 06            [24]  795 	pop	ar6
                                    796 ;	quantum/quantum.c:172: unregister_code(code);
      009BC8 8E 04            [24]  797 	mov	ar4,r6
      009BCA 8C 82            [24]  798 	mov	dpl, r4
      009BCC C0 06            [24]  799 	push	ar6
      009BCE C0 05            [24]  800 	push	ar5
      009BD0 12 74 76         [24]  801 	lcall	_unregister_code
      009BD3 D0 05            [24]  802 	pop	ar5
      009BD5 D0 06            [24]  803 	pop	ar6
      009BD7 D0 07            [24]  804 	pop	ar7
                                    805 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009BD9 12 99 81         [24]  806 	lcall	_ak820_outline_0114
      009BDC 40 07            [24]  807 	jc	00105$
      009BDE 74 E7            [12]  808 	mov	a,#0xe7
      009BE0 9E               [12]  809 	subb	a,r6
      009BE1 E4               [12]  810 	clr	a
      009BE2 9F               [12]  811 	subb	a,r7
      009BE3 50 08            [24]  812 	jnc	00101$
                                    813 ;	free result
      009BE5                        814 00105$:
      009BE5 90 0B D0         [24]  815 	mov	dptr,#_unregister_code16_code_10000_610
      009BE8 12 6C C6         [24]  816 	lcall	_ak820_outline_0035
      009BEB 70 05            [24]  817 	jnz	00102$
      009BED                        818 00101$:
                                    819 ;	quantum/quantum.c:174: unregister_mods(mods);
      009BED 8D 82            [24]  820 	mov	dpl, r5
      009BEF 02 75 3D         [24]  821 	ljmp	_unregister_mods
      009BF2                        822 00102$:
                                    823 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      009BF2 8D 82            [24]  824 	mov	dpl, r5
                                    825 ;	quantum/quantum.c:187: }
      009BF4 02 75 65         [24]  826 	ljmp	_unregister_weak_mods
                                    827 ;------------------------------------------------------------
                                    828 ;Allocation info for local variables in function 'tap_code16_delay'
                                    829 ;------------------------------------------------------------
                                    830 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    831 ;code          Allocated with name '_tap_code16_delay_code_10000_615'
                                    832 ;i             Allocated with name '_tap_code16_delay_i_20000_617'
                                    833 ;i             Allocated with name '_tap_code16_delay_i_50000_620'
                                    834 ;------------------------------------------------------------
                                    835 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    836 ;	-----------------------------------------
                                    837 ;	 function shutdown_quantum
                                    838 ;	-----------------------------------------
      009BF7                        839 _shutdown_quantum:
                                    840 ;	quantum/quantum.c:237: clear_keyboard();
      009BF7 12 75 79         [24]  841 	lcall	_clear_keyboard
                                    842 ;	quantum/quantum.c:252: shutdown_user();
      009BFA D1 6C            [12]  843 	acall	_shutdown_user
                                    844 ;	quantum/quantum.c:253: wait_ms(250);
      009BFC 7F FA            [12]  845 	mov	r7,#0xfa
      009BFE                        846 00106$:
      009BFE EF               [12]  847 	mov	a,r7
      009BFF 60 09            [24]  848 	jz	00108$
      009C01 90 00 01         [24]  849 	mov	dptr,#0x0001
      009C04 12 58 34         [24]  850 	lcall	_mDelaymS
      009C07 1F               [12]  851 	dec	r7
      009C08 80 F4            [24]  852 	sjmp	00106$
      009C0A                        853 00108$:
                                    854 ;	quantum/quantum.c:258: }
      009C0A 22               [24]  855 	ret
                                    856 ;------------------------------------------------------------
                                    857 ;Allocation info for local variables in function 'reset_keyboard'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function reset_keyboard
                                    862 ;	-----------------------------------------
      009C0B                        863 _reset_keyboard:
                                    864 ;	quantum/quantum.c:261: shutdown_quantum();
      009C0B 71 F7            [12]  865 	acall	_shutdown_quantum
                                    866 ;	quantum/quantum.c:262: bootloader_jump();
                                    867 ;	quantum/quantum.c:263: }
      009C0D 02 34 0E         [24]  868 	ljmp	_bootloader_jump
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                    871 ;------------------------------------------------------------
                                    872 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                    873 ;	-----------------------------------------
                                    874 ;	 function soft_reset_keyboard
                                    875 ;	-----------------------------------------
      009C10                        876 _soft_reset_keyboard:
                                    877 ;	quantum/quantum.c:266: shutdown_quantum();
      009C10 71 F7            [12]  878 	acall	_shutdown_quantum
                                    879 ;	quantum/quantum.c:267: mcu_reset();
                                    880 ;	quantum/quantum.c:268: }
      009C12 02 34 01         [24]  881 	ljmp	_mcu_reset
                                    882 ;------------------------------------------------------------
                                    883 ;Allocation info for local variables in function 'get_record_keycode'
                                    884 ;------------------------------------------------------------
                                    885 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                    886 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_648'
                                    887 ;record        Allocated with name '_get_record_keycode_record_10000_649'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function get_record_keycode
                                    892 ;	-----------------------------------------
      009C15                        893 _get_record_keycode:
      009C15 12 38 3B         [24]  894 	lcall	_ak820_outline_0103
      009C18 90 0B D3         [24]  895 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009C1B 12 38 40         [24]  896 	lcall	_ak820_outline_0104
                                    897 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009C1E 90 0B D3         [24]  898 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009C21 12 37 AF         [24]  899 	lcall	_ak820_outline_0008
                                    900 ;	quantum/quantum.c:278: if (record->keycode) {
      009C24 4C               [12]  901 	orl	a,r4
      009C25 60 04            [24]  902 	jz	00102$
                                    903 ;	quantum/quantum.c:279: return record->keycode;
      009C27 12 38 4C         [24]  904 	lcall	_ak820_outline_0117
      009C2A 22               [24]  905 	ret
      009C2B                        906 00102$:
                                    907 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      009C2B 12 75 B8         [24]  908 	lcall	_ak820_outline_0019
      009C2E 7A 00            [12]  909 	mov	r2,#0x00
      009C30 12 43 2D         [24]  910 	lcall	_ak820_outline_0138
      009C33 12 37 A2         [24]  911 	lcall	_ak820_outline_0005
      009C36 60 06            [24]  912 	jz	00105$
      009C38 90 0B D2         [24]  913 	mov	dptr,#_get_record_keycode_PARM_2
      009C3B E0               [24]  914 	movx	a,@dptr
      009C3C 70 04            [24]  915 	jnz	00106$
      009C3E                        916 00105$:
                                    917 ;	assignBit
      009C3E C2 23            [12]  918 	clr	_get_record_keycode_sloc0_1_0
      009C40 80 02            [24]  919 	sjmp	00107$
      009C42                        920 00106$:
                                    921 ;	assignBit
      009C42 D2 23            [12]  922 	setb	_get_record_keycode_sloc0_1_0
      009C44                        923 00107$:
      009C44 90 09 62         [24]  924 	mov	dptr,#_ak820_resolve_key_PARM_2
      009C47 A2 23            [12]  925 	mov	c,_get_record_keycode_sloc0_1_0
      009C49 E4               [12]  926 	clr	a
      009C4A 33               [12]  927 	rlc	a
      009C4B F0               [24]  928 	movx	@dptr,a
      009C4C 8D 82            [24]  929 	mov	dpl, r5
      009C4E 8C 83            [24]  930 	mov	dph, r4
                                    931 ;	quantum/quantum.c:287: }
      009C50 02 79 43         [24]  932 	ljmp	_ak820_resolve_key
                                    933 ;------------------------------------------------------------
                                    934 ;Allocation info for local variables in function 'get_event_keycode'
                                    935 ;------------------------------------------------------------
                                    936 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                    937 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_652'
                                    938 ;------------------------------------------------------------
                                    939 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                    940 ;	-----------------------------------------
                                    941 ;	 function pre_process_record_quantum
                                    942 ;	-----------------------------------------
      009C53                        943 _pre_process_record_quantum:
      009C53 12 38 3B         [24]  944 	lcall	_ak820_outline_0103
      009C56 90 0B D5         [24]  945 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009C59 12 38 40         [24]  946 	lcall	_ak820_outline_0104
                                    947 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009C5C 90 0B D5         [24]  948 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009C5F 12 37 F8         [24]  949 	lcall	_ak820_outline_0050
                                    950 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      009C62 90 0B D2         [24]  951 	mov	dptr,#_get_record_keycode_PARM_2
      009C65 12 48 1F         [24]  952 	lcall	_ak820_outline_0054
      009C68 C0 07            [24]  953 	push	ar7
      009C6A C0 06            [24]  954 	push	ar6
      009C6C 91 15            [12]  955 	acall	_get_record_keycode
      009C6E 12 43 38         [24]  956 	lcall	_ak820_outline_0144
      009C71 D0 06            [24]  957 	pop	ar6
      009C73 D0 07            [24]  958 	pop	ar7
                                    959 ;	quantum/quantum.c:334: record->keycode = keycode;
      009C75 74 07            [12]  960 	mov	a,#0x07
      009C77 12 37 E8         [24]  961 	lcall	_ak820_outline_0030
      009C7A EC               [12]  962 	mov	a,r4
      009C7B F0               [24]  963 	movx	@dptr,a
      009C7C ED               [12]  964 	mov	a,r5
      009C7D A3               [24]  965 	inc	dptr
      009C7E 12 42 F2         [24]  966 	lcall	_ak820_outline_0060
                                    967 ;	quantum/quantum.c:361: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      009C81 12 35 ED         [24]  968 	lcall	_ak820_combo_process
      009C84 E5 82            [12]  969 	mov	a, dpl
      009C86 70 04            [24]  970 	jnz	00104$
                                    971 ;	quantum/quantum.c:366: true;
                                    972 ;	assignBit
      009C88 C2 24            [12]  973 	clr	_pre_process_record_quantum_sloc0_1_0
      009C8A 80 02            [24]  974 	sjmp	00105$
      009C8C                        975 00104$:
                                    976 ;	assignBit
      009C8C D2 24            [12]  977 	setb	_pre_process_record_quantum_sloc0_1_0
      009C8E                        978 00105$:
      009C8E A2 24            [12]  979 	mov	c,_pre_process_record_quantum_sloc0_1_0
      009C90 12 38 78         [24]  980 	lcall	_ak820_outline_0166
                                    981 ;	quantum/quantum.c:367: }
      009C93 22               [24]  982 	ret
                                    983 ;------------------------------------------------------------
                                    984 ;Allocation info for local variables in function 'post_process_record_quantum'
                                    985 ;------------------------------------------------------------
                                    986 ;record        Allocated with name '_post_process_record_quantum_record_10000_656'
                                    987 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_657'
                                    988 ;------------------------------------------------------------
                                    989 ;	quantum/quantum.c:370: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                    990 ;	-----------------------------------------
                                    991 ;	 function process_record_quantum
                                    992 ;	-----------------------------------------
      009C94                        993 _process_record_quantum:
      009C94 12 38 3B         [24]  994 	lcall	_ak820_outline_0103
      009C97 90 0B D7         [24]  995 	mov	dptr,#_process_record_quantum_record_10000_658
      009C9A 12 38 40         [24]  996 	lcall	_ak820_outline_0104
                                    997 ;	quantum/quantum.c:377: uint16_t keycode = get_record_keycode(record, false);
      009C9D 90 0B D7         [24]  998 	mov	dptr,#_process_record_quantum_record_10000_658
      009CA0 12 37 F8         [24]  999 	lcall	_ak820_outline_0050
      009CA3 90 0B D2         [24] 1000 	mov	dptr,#_get_record_keycode_PARM_2
      009CA6 E4               [12] 1001 	clr	a
      009CA7 12 42 F2         [24] 1002 	lcall	_ak820_outline_0060
      009CAA 91 15            [12] 1003 	acall	_get_record_keycode
      009CAC 12 43 22         [24] 1004 	lcall	_ak820_outline_0130
                                   1005 ;	quantum/quantum.c:381: return process_record_quantum_helper(keycode, record);
      009CAF 90 0B D7         [24] 1006 	mov	dptr,#_process_record_quantum_record_10000_658
      009CB2 12 38 17         [24] 1007 	lcall	_ak820_outline_0059
      009CB5 90 0B DE         [24] 1008 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009CB8 EC               [12] 1009 	mov	a,r4
      009CB9 F0               [24] 1010 	movx	@dptr,a
      009CBA ED               [12] 1011 	mov	a,r5
      009CBB A3               [24] 1012 	inc	dptr
      009CBC 12 42 F2         [24] 1013 	lcall	_ak820_outline_0060
                                   1014 ;	quantum/quantum.c:382: }
      009CBF A1 2C            [24] 1015 	ajmp	_process_record_quantum_helper
                                   1016 ;------------------------------------------------------------
                                   1017 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1018 ;------------------------------------------------------------
                                   1019 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1020 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_660'
                                   1021 ;record        Allocated with name '_process_ak820_nkro_record_10000_661'
                                   1022 ;------------------------------------------------------------
                                   1023 ;	quantum/quantum.c:399: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1024 ;	-----------------------------------------
                                   1025 ;	 function process_ak820_nkro
                                   1026 ;	-----------------------------------------
      009CC1                       1027 _process_ak820_nkro:
      009CC1 12 38 3B         [24] 1028 	lcall	_ak820_outline_0103
      009CC4 90 0B DC         [24] 1029 	mov	dptr,#_process_ak820_nkro_keycode_10000_660
      009CC7 12 38 40         [24] 1030 	lcall	_ak820_outline_0104
                                   1031 ;	quantum/quantum.c:401: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009CCA 90 0B D9         [24] 1032 	mov	dptr,#_process_ak820_nkro_PARM_2
      009CCD 12 37 F8         [24] 1033 	lcall	_ak820_outline_0050
                                   1034 ;	quantum/quantum.c:405: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      009CD0 90 0B DC         [24] 1035 	mov	dptr,#_process_ak820_nkro_keycode_10000_660
      009CD3 12 38 17         [24] 1036 	lcall	_ak820_outline_0059
      009CD6 C3               [12] 1037 	clr	c
      009CD7 EC               [12] 1038 	mov	a,r4
      009CD8 94 11            [12] 1039 	subb	a,#0x11
      009CDA ED               [12] 1040 	mov	a,r5
      009CDB 94 70            [12] 1041 	subb	a,#0x70
      009CDD 40 08            [24] 1042 	jc	00101$
      009CDF 74 13            [12] 1043 	mov	a,#0x13
      009CE1 9C               [12] 1044 	subb	a,r4
      009CE2 74 70            [12] 1045 	mov	a,#0x70
      009CE4 9D               [12] 1046 	subb	a,r5
      009CE5 50 04            [24] 1047 	jnc	00102$
                                   1048 ;	free result
      009CE7                       1049 00101$:
      009CE7 75 82 01         [24] 1050 	mov	dpl, #0x01
      009CEA 22               [24] 1051 	ret
      009CEB                       1052 00102$:
                                   1053 ;	quantum/quantum.c:406: if (record->event.pressed) {
      009CEB 12 37 A2         [24] 1054 	lcall	_ak820_outline_0005
      009CEE 60 38            [24] 1055 	jz	00105$
                                   1056 ;	quantum/quantum.c:407: clear_keyboard();
      009CF0 C0 05            [24] 1057 	push	ar5
      009CF2 C0 04            [24] 1058 	push	ar4
      009CF4 12 75 79         [24] 1059 	lcall	_clear_keyboard
      009CF7 D0 04            [24] 1060 	pop	ar4
      009CF9 D0 05            [24] 1061 	pop	ar5
                                   1062 ;	quantum/quantum.c:408: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      009CFB BC 13 14         [24] 1063 	cjne	r4,#0x13,00108$
      009CFE BD 70 11         [24] 1064 	cjne	r5,#0x70,00108$
      009D01 90 0A B4         [24] 1065 	mov	dptr,#_keymap_config
      009D04 E0               [24] 1066 	movx	a,@dptr
      009D05 23               [12] 1067 	rl	a
      009D06 54 01            [12] 1068 	anl	a,#0x01
      009D08 B4 01 00         [24] 1069 	cjne	a,#0x01,00136$
      009D0B                       1070 00136$:
      009D0B 92 25            [24] 1071 	mov  _process_ak820_nkro_sloc0_1_0,c
      009D0D E4               [12] 1072 	clr	a
      009D0E 33               [12] 1073 	rlc	a
      009D0F FF               [12] 1074 	mov	r7,a
      009D10 80 09            [24] 1075 	sjmp	00109$
      009D12                       1076 00108$:
      009D12 E4               [12] 1077 	clr	a
      009D13 BC 11 04         [24] 1078 	cjne	r4,#0x11,00137$
      009D16 BD 70 01         [24] 1079 	cjne	r5,#0x70,00137$
      009D19 04               [12] 1080 	inc	a
      009D1A                       1081 00137$:
      009D1A FF               [12] 1082 	mov	r7,a
      009D1B                       1083 00109$:
                                   1084 ;	assignBit
      009D1B EF               [12] 1085 	mov	a,r7
      009D1C 24 FF            [12] 1086 	add	a,#0xff
      009D1E E4               [12] 1087 	clr	a
      009D1F 33               [12] 1088 	rlc	a
      009D20 90 0A B4         [24] 1089 	mov	dptr,#_keymap_config
      009D23 13               [12] 1090 	rrc	a
      009D24 E0               [24] 1091 	movx	a,@dptr
      009D25 92 E7            [24] 1092 	mov	acc.7,c
      009D27 F0               [24] 1093 	movx	@dptr,a
      009D28                       1094 00105$:
                                   1095 ;	quantum/quantum.c:410: return false;
      009D28 75 82 00         [24] 1096 	mov	dpl, #0x00
                                   1097 ;	quantum/quantum.c:411: }
      009D2B 22               [24] 1098 	ret
                                   1099 ;------------------------------------------------------------
                                   1100 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1101 ;------------------------------------------------------------
                                   1102 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1103 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_665'
                                   1104 ;record        Allocated with name '_process_record_quantum_helper_record_10000_666'
                                   1105 ;------------------------------------------------------------
                                   1106 ;	quantum/quantum.c:414: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1107 ;	-----------------------------------------
                                   1108 ;	 function process_record_quantum_helper
                                   1109 ;	-----------------------------------------
      009D2C                       1110 _process_record_quantum_helper:
      009D2C 12 38 3B         [24] 1111 	lcall	_ak820_outline_0103
      009D2F 90 0B E0         [24] 1112 	mov	dptr,#_process_record_quantum_helper_keycode_10000_665
      009D32 12 38 40         [24] 1113 	lcall	_ak820_outline_0104
                                   1114 ;	quantum/quantum.c:416: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009D35 90 0B DE         [24] 1115 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009D38 12 37 F8         [24] 1116 	lcall	_ak820_outline_0050
                                   1117 ;	quantum/quantum.c:459: process_ak820_nkro(keycode, record) &&
      009D3B 90 0B E0         [24] 1118 	mov	dptr,#_process_record_quantum_helper_keycode_10000_665
      009D3E 12 38 17         [24] 1119 	lcall	_ak820_outline_0059
      009D41 90 0B D9         [24] 1120 	mov	dptr,#_process_ak820_nkro_PARM_2
      009D44 12 9E 6D         [24] 1121 	lcall	_ak820_outline_0006
      009D47 C0 07            [24] 1122 	push	ar7
      009D49 C0 06            [24] 1123 	push	ar6
      009D4B C0 05            [24] 1124 	push	ar5
      009D4D C0 04            [24] 1125 	push	ar4
      009D4F 91 C1            [24] 1126 	acall	_process_ak820_nkro
      009D51 E5 82            [12] 1127 	mov	a, dpl
      009D53 D0 04            [24] 1128 	pop	ar4
      009D55 D0 05            [24] 1129 	pop	ar5
      009D57 D0 06            [24] 1130 	pop	ar6
      009D59 D0 07            [24] 1131 	pop	ar7
      009D5B 70 02            [24] 1132 	jnz	00196$
      009D5D C1 32            [24] 1133 	ajmp	00101$
      009D5F                       1134 00196$:
                                   1135 ;	quantum/quantum.c:470: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      009D5F 90 0B B7         [24] 1136 	mov	dptr,#_process_last_key_PARM_2
      009D62 12 48 2F         [24] 1137 	lcall	_ak820_outline_0058
      009D65 12 38 4C         [24] 1138 	lcall	_ak820_outline_0117
      009D68 C0 07            [24] 1139 	push	ar7
      009D6A C0 06            [24] 1140 	push	ar6
      009D6C C0 05            [24] 1141 	push	ar5
      009D6E C0 04            [24] 1142 	push	ar4
      009D70 11 C6            [12] 1143 	acall	_process_last_key
      009D72 E5 82            [12] 1144 	mov	a, dpl
      009D74 D0 04            [24] 1145 	pop	ar4
      009D76 D0 05            [24] 1146 	pop	ar5
      009D78 D0 06            [24] 1147 	pop	ar6
      009D7A D0 07            [24] 1148 	pop	ar7
      009D7C 70 02            [24] 1149 	jnz	00197$
      009D7E C1 32            [24] 1150 	ajmp	00101$
      009D80                       1151 00197$:
      009D80 90 0B BC         [24] 1152 	mov	dptr,#_process_repeat_key_PARM_2
      009D83 12 48 2F         [24] 1153 	lcall	_ak820_outline_0058
      009D86 12 38 4C         [24] 1154 	lcall	_ak820_outline_0117
      009D89 C0 07            [24] 1155 	push	ar7
      009D8B C0 06            [24] 1156 	push	ar6
      009D8D C0 05            [24] 1157 	push	ar5
      009D8F C0 04            [24] 1158 	push	ar4
      009D91 31 3B            [12] 1159 	acall	_process_repeat_key
      009D93 E5 82            [12] 1160 	mov	a, dpl
      009D95 D0 04            [24] 1161 	pop	ar4
      009D97 D0 05            [24] 1162 	pop	ar5
      009D99 D0 06            [24] 1163 	pop	ar6
      009D9B D0 07            [24] 1164 	pop	ar7
      009D9D 70 02            [24] 1165 	jnz	00198$
      009D9F C1 32            [24] 1166 	ajmp	00101$
      009DA1                       1167 00198$:
                                   1168 ;	quantum/quantum.c:479: process_record_via(keycode, record) &&
      009DA1 90 0C 19         [24] 1169 	mov	dptr,#_process_record_via_PARM_2
      009DA4 12 9E 6D         [24] 1170 	lcall	_ak820_outline_0006
      009DA7 C0 07            [24] 1171 	push	ar7
      009DA9 C0 06            [24] 1172 	push	ar6
      009DAB C0 05            [24] 1173 	push	ar5
      009DAD C0 04            [24] 1174 	push	ar4
      009DAF 12 A3 4F         [24] 1175 	lcall	_process_record_via
      009DB2 E5 82            [12] 1176 	mov	a, dpl
      009DB4 D0 04            [24] 1177 	pop	ar4
      009DB6 D0 05            [24] 1178 	pop	ar5
      009DB8 D0 06            [24] 1179 	pop	ar6
      009DBA D0 07            [24] 1180 	pop	ar7
      009DBC 70 02            [24] 1181 	jnz	00199$
      009DBE C1 32            [24] 1182 	ajmp	00101$
      009DC0                       1183 00199$:
                                   1184 ;	quantum/quantum.c:514: process_caps_word(keycode, record) &&
      009DC0 90 0B A0         [24] 1185 	mov	dptr,#_process_caps_word_PARM_2
      009DC3 12 9E 6D         [24] 1186 	lcall	_ak820_outline_0006
      009DC6 C0 07            [24] 1187 	push	ar7
      009DC8 C0 06            [24] 1188 	push	ar6
      009DCA C0 05            [24] 1189 	push	ar5
      009DCC C0 04            [24] 1190 	push	ar4
      009DCE 12 96 66         [24] 1191 	lcall	_process_caps_word
      009DD1 E5 82            [12] 1192 	mov	a, dpl
      009DD3 D0 04            [24] 1193 	pop	ar4
      009DD5 D0 05            [24] 1194 	pop	ar5
      009DD7 D0 06            [24] 1195 	pop	ar6
      009DD9 D0 07            [24] 1196 	pop	ar7
      009DDB 60 55            [24] 1197 	jz	00101$
                                   1198 ;	quantum/quantum.c:544: process_grave_esc(keycode, record) &&
      009DDD 90 0B A5         [24] 1199 	mov	dptr,#_process_grave_esc_PARM_2
      009DE0 12 9E 6D         [24] 1200 	lcall	_ak820_outline_0006
      009DE3 C0 07            [24] 1201 	push	ar7
      009DE5 C0 06            [24] 1202 	push	ar6
      009DE7 C0 05            [24] 1203 	push	ar5
      009DE9 C0 04            [24] 1204 	push	ar4
      009DEB 12 97 79         [24] 1205 	lcall	_process_grave_esc
      009DEE E5 82            [12] 1206 	mov	a, dpl
      009DF0 D0 04            [24] 1207 	pop	ar4
      009DF2 D0 05            [24] 1208 	pop	ar5
      009DF4 D0 06            [24] 1209 	pop	ar6
      009DF6 D0 07            [24] 1210 	pop	ar7
      009DF8 60 38            [24] 1211 	jz	00101$
                                   1212 ;	quantum/quantum.c:547: process_rgb(keycode, record) &&
      009DFA 90 0B C0         [24] 1213 	mov	dptr,#_process_rgb_PARM_2
      009DFD 12 9E 6D         [24] 1214 	lcall	_ak820_outline_0006
      009E00 C0 07            [24] 1215 	push	ar7
      009E02 C0 06            [24] 1216 	push	ar6
      009E04 C0 05            [24] 1217 	push	ar5
      009E06 C0 04            [24] 1218 	push	ar4
      009E08 31 89            [12] 1219 	acall	_process_rgb
      009E0A E5 82            [12] 1220 	mov	a, dpl
      009E0C D0 04            [24] 1221 	pop	ar4
      009E0E D0 05            [24] 1222 	pop	ar5
      009E10 D0 06            [24] 1223 	pop	ar6
      009E12 D0 07            [24] 1224 	pop	ar7
      009E14 60 1C            [24] 1225 	jz	00101$
                                   1226 ;	quantum/quantum.c:559: process_tri_layer(keycode, record) &&
      009E16 90 0B C6         [24] 1227 	mov	dptr,#_process_tri_layer_PARM_2
      009E19 12 9E 6D         [24] 1228 	lcall	_ak820_outline_0006
      009E1C C0 07            [24] 1229 	push	ar7
      009E1E C0 06            [24] 1230 	push	ar6
      009E20 C0 05            [24] 1231 	push	ar5
      009E22 C0 04            [24] 1232 	push	ar4
      009E24 51 3A            [12] 1233 	acall	_process_tri_layer
      009E26 E5 82            [12] 1234 	mov	a, dpl
      009E28 D0 04            [24] 1235 	pop	ar4
      009E2A D0 05            [24] 1236 	pop	ar5
      009E2C D0 06            [24] 1237 	pop	ar6
      009E2E D0 07            [24] 1238 	pop	ar7
      009E30 70 04            [24] 1239 	jnz	00102$
                                   1240 ;	quantum/quantum.c:561: true)) {
      009E32                       1241 00101$:
                                   1242 ;	quantum/quantum.c:562: return false;
      009E32 75 82 00         [24] 1243 	mov	dpl, #0x00
      009E35 22               [24] 1244 	ret
      009E36                       1245 00102$:
                                   1246 ;	quantum/quantum.c:565: if (record->event.pressed) {
      009E36 12 37 A2         [24] 1247 	lcall	_ak820_outline_0005
      009E39 60 2D            [24] 1248 	jz	00116$
                                   1249 ;	quantum/quantum.c:566: switch (keycode) {
      009E3B BC 00 05         [24] 1250 	cjne	r4,#0x00,00205$
      009E3E BD 7C 02         [24] 1251 	cjne	r5,#0x7c,00205$
      009E41 80 10            [24] 1252 	sjmp	00111$
      009E43                       1253 00205$:
      009E43 BC 01 05         [24] 1254 	cjne	r4,#0x01,00206$
      009E46 BD 7C 02         [24] 1255 	cjne	r5,#0x7c,00206$
      009E49 80 0E            [24] 1256 	sjmp	00112$
      009E4B                       1257 00206$:
                                   1258 ;	quantum/quantum.c:568: case QK_BOOTLOADER:
      009E4B BC 03 1A         [24] 1259 	cjne	r4,#0x03,00116$
      009E4E BD 7C 17         [24] 1260 	cjne	r5,#0x7c,00116$
      009E51 80 0C            [24] 1261 	sjmp	00113$
      009E53                       1262 00111$:
                                   1263 ;	quantum/quantum.c:569: reset_keyboard();
      009E53 91 0B            [12] 1264 	acall	_reset_keyboard
                                   1265 ;	quantum/quantum.c:570: return false;
      009E55 75 82 00         [24] 1266 	mov	dpl, #0x00
                                   1267 ;	quantum/quantum.c:571: case QK_REBOOT:
      009E58 22               [24] 1268 	ret
      009E59                       1269 00112$:
                                   1270 ;	quantum/quantum.c:572: soft_reset_keyboard();
      009E59 91 10            [12] 1271 	acall	_soft_reset_keyboard
                                   1272 ;	quantum/quantum.c:573: return false;
      009E5B 75 82 00         [24] 1273 	mov	dpl, #0x00
                                   1274 ;	quantum/quantum.c:585: case QK_CLEAR_EEPROM:
      009E5E 22               [24] 1275 	ret
      009E5F                       1276 00113$:
                                   1277 ;	quantum/quantum.c:592: eeconfig_disable();
      009E5F 12 8D F0         [24] 1278 	lcall	_eeconfig_disable
                                   1279 ;	quantum/quantum.c:593: soft_reset_keyboard();
      009E62 91 10            [12] 1280 	acall	_soft_reset_keyboard
                                   1281 ;	quantum/quantum.c:595: return false;
      009E64 75 82 00         [24] 1282 	mov	dpl, #0x00
                                   1283 ;	quantum/quantum.c:650: }
      009E67 22               [24] 1284 	ret
      009E68                       1285 00116$:
                                   1286 ;	quantum/quantum.c:654: return true;
      009E68 75 82 01         [24] 1287 	mov	dpl, #0x01
                                   1288 ;	quantum/quantum.c:658: }
      009E6B 22               [24] 1289 	ret
                                   1290 ;------------------------------------------------------------
                                   1291 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1292 ;------------------------------------------------------------
                                   1293 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_673'
                                   1294 ;------------------------------------------------------------
                                   1295 ;	quantum/quantum.c:660: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1296 ;	-----------------------------------------
                                   1297 ;	 function shutdown_user
                                   1298 ;	-----------------------------------------
      009E6C                       1299 _shutdown_user:
      009E6C 22               [24] 1300 	ret
                                   1301 ;------------------------------------------------------------
                                   1302 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1303 ;------------------------------------------------------------
                                   1304 ;	quantum/quantum.c:676: void suspend_power_down_quantum(void) {
                                   1305 ;	-----------------------------------------
                                   1306 	.area CSEG    (CODE)
                                   1307 	.area CONST   (CODE)
                                   1308 	.area XINIT   (CODE)
                                   1309 	.area CABS    (ABS,CODE)
                                   1310 
                                   1311 ; Experimental exact instruction outlining.
                                   1312 	.globl _ak820_outline_0004
                                   1313 	.globl _ak820_outline_0005
                                   1314 	.globl _ak820_outline_0006
                                   1315 	.globl _ak820_outline_0008
                                   1316 	.globl _ak820_outline_0019
                                   1317 	.globl _ak820_outline_0030
                                   1318 	.globl _ak820_outline_0035
                                   1319 	.globl _ak820_outline_0050
                                   1320 	.globl _ak820_outline_0054
                                   1321 	.globl _ak820_outline_0058
                                   1322 	.globl _ak820_outline_0059
                                   1323 	.globl _ak820_outline_0060
                                   1324 	.globl _ak820_outline_0103
                                   1325 	.globl _ak820_outline_0104
                                   1326 	.globl _ak820_outline_0114
                                   1327 	.globl _ak820_outline_0117
                                   1328 	.globl _ak820_outline_0130
                                   1329 	.globl _ak820_outline_0138
                                   1330 	.globl _ak820_outline_0144
                                   1331 	.globl _ak820_outline_0166
                                   1332 
                                   1333 	.area CSEG (CODE)
                                   1334 ; function ak820_outline_0006
      009E6D                       1335 _ak820_outline_0006:
      009E6D EE               [12] 1336 	mov	a,r6
      009E6E F0               [24] 1337 	movx	@dptr,a
      009E6F EF               [12] 1338 	mov	a,r7
      009E70 A3               [24] 1339 	inc	dptr
      009E71 F0               [24] 1340 	movx	@dptr,a
      009E72 E4               [12] 1341 	clr	a
      009E73 A3               [24] 1342 	inc	dptr
      009E74 F0               [24] 1343 	movx	@dptr,a
      009E75 8C 82            [24] 1344 	mov	dpl,r4
      009E77 8D 83            [24] 1345 	mov	dph,r5
      009E79 22               [24] 1346 	ret
