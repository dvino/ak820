                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module process_repeat_key
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_weak_mods
                                     12 	.globl _get_mods
                                     13 	.globl _alt_repeat_key_invoke
                                     14 	.globl _repeat_key_invoke
                                     15 	.globl _get_repeat_key_count
                                     16 	.globl _set_last_record
                                     17 	.globl _set_last_mods
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _process_repeat_key_PARM_2
                                    262 	.globl _process_last_key_PARM_2
                                    263 	.globl _remember_last_key_user_PARM_3
                                    264 	.globl _remember_last_key_user_PARM_2
                                    265 	.globl _remember_last_key_user
                                    266 	.globl _process_last_key
                                    267 	.globl _process_repeat_key
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 ;--------------------------------------------------------
                                    534 ; indirectly addressable internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area ISEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; absolute internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area IABS    (ABS,DATA)
                                    541 	.area IABS    (ABS,DATA)
                                    542 ;--------------------------------------------------------
                                    543 ; bit data
                                    544 ;--------------------------------------------------------
                                    545 	.area BSEG    (BIT)
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      000BAA                        554 _remember_last_key_user_PARM_2:
      000BAA                        555 	.ds 3
      000BAD                        556 _remember_last_key_user_PARM_3:
      000BAD                        557 	.ds 3
      000BB0                        558 _remember_last_key_PARM_2:
      000BB0                        559 	.ds 2
      000BB2                        560 _remember_last_key_PARM_3:
      000BB2                        561 	.ds 3
      000BB5                        562 _remember_last_key_keycode_10000_239:
      000BB5                        563 	.ds 2
      000BB7                        564 _process_last_key_PARM_2:
      000BB7                        565 	.ds 2
      000BB9                        566 _process_last_key_keycode_10000_242:
      000BB9                        567 	.ds 2
      000BBB                        568 _process_last_key_remembered_mods_30000_247:
      000BBB                        569 	.ds 1
      000BBC                        570 _process_repeat_key_PARM_2:
      000BBC                        571 	.ds 2
      000BBE                        572 _process_repeat_key_keycode_10000_250:
      000BBE                        573 	.ds 2
                                    574 ;--------------------------------------------------------
                                    575 ; absolute external ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area XABS    (ABS,XDATA)
                                    578 ;--------------------------------------------------------
                                    579 ; initialized external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area XISEG   (XDATA)
                                    582 	.area HOME    (CODE)
                                    583 	.area GSINIT0 (CODE)
                                    584 	.area GSINIT1 (CODE)
                                    585 	.area GSINIT2 (CODE)
                                    586 	.area GSINIT3 (CODE)
                                    587 	.area GSINIT4 (CODE)
                                    588 	.area GSINIT5 (CODE)
                                    589 	.area GSINIT  (CODE)
                                    590 	.area GSFINAL (CODE)
                                    591 	.area CSEG    (CODE)
                                    592 ;--------------------------------------------------------
                                    593 ; global & static initialisations
                                    594 ;--------------------------------------------------------
                                    595 	.area HOME    (CODE)
                                    596 	.area GSINIT  (CODE)
                                    597 	.area GSFINAL (CODE)
                                    598 	.area GSINIT  (CODE)
                                    599 ;--------------------------------------------------------
                                    600 ; Home
                                    601 ;--------------------------------------------------------
                                    602 	.area HOME    (CODE)
                                    603 	.area HOME    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; code
                                    606 ;--------------------------------------------------------
                                    607 	.area CSEG    (CODE)
                                    608 ;------------------------------------------------------------
                                    609 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    610 ;------------------------------------------------------------
                                    611 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_165'
                                    612 ;------------------------------------------------------------
                                    613 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    614 ;	-----------------------------------------
                           000007   615 	ar7 = 0x07
                           000006   616 	ar6 = 0x06
                           000005   617 	ar5 = 0x05
                           000004   618 	ar4 = 0x04
                           000003   619 	ar3 = 0x03
                           000002   620 	ar2 = 0x02
                           000001   621 	ar1 = 0x01
                           000000   622 	ar0 = 0x00
                                    623 ;	 function remember_last_key_user
                                    624 ;	-----------------------------------------
      009822                        625 _remember_last_key_user:
                                    626 ;	quantum/process_keycode/process_repeat_key.c:23: return true;
      009822 75 82 01         [24]  627 	mov	dpl, #0x01
                                    628 ;	quantum/process_keycode/process_repeat_key.c:24: }
      009825 22               [24]  629 	ret
                                    630 ;------------------------------------------------------------
                                    631 ;Allocation info for local variables in function 'remember_last_key'
                                    632 ;------------------------------------------------------------
                                    633 ;record        Allocated with name '_remember_last_key_PARM_2'
                                    634 ;remembered_mods Allocated with name '_remember_last_key_PARM_3'
                                    635 ;keycode       Allocated with name '_remember_last_key_keycode_10000_239'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/process_keycode/process_repeat_key.c:26: static bool remember_last_key(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record, uint8_t* remembered_mods) {
                                    638 ;	-----------------------------------------
                                    639 ;	 function remember_last_key
                                    640 ;	-----------------------------------------
      009826                        641 _remember_last_key:
      009826 12 38 3B         [24]  642 	lcall	_ak820_outline_0103
      009829 90 0B B5         [24]  643 	mov	dptr,#_remember_last_key_keycode_10000_239
      00982C 12 38 40         [24]  644 	lcall	_ak820_outline_0104
                                    645 ;	quantum/process_keycode/process_repeat_key.c:36: if (keycode == KC_NO || keycode == KC_TRANSPARENT ||
      00982F 90 0B B5         [24]  646 	mov	dptr,#_remember_last_key_keycode_10000_239
      009832 12 37 F8         [24]  647 	lcall	_ak820_outline_0050
      009835 90 0B B5         [24]  648 	mov	dptr,#_remember_last_key_keycode_10000_239
      009838 12 6C C6         [24]  649 	lcall	_ak820_outline_0035
      00983B 60 5C            [24]  650 	jz	00101$
      00983D BE 01 05         [24]  651 	cjne	r6,#0x01,00180$
      009840 BF 00 02         [24]  652 	cjne	r7,#0x00,00180$
      009843 80 54            [24]  653 	sjmp	00101$
      009845                        654 00180$:
                                    655 ;	quantum/process_keycode/process_repeat_key.c:39: (keycode >= QK_LAYER_MOD && keycode <= QK_LAYER_TAP_TOGGLE_MAX) ||
      009845 74 B0            [12]  656 	mov	a,#0x100 - 0x50
      009847 2F               [12]  657 	add	a,r7
      009848 50 09            [24]  658 	jnc	00107$
      00984A C3               [12]  659 	clr	c
      00984B 74 DF            [12]  660 	mov	a,#0xdf
      00984D 9E               [12]  661 	subb	a,r6
      00984E 74 52            [12]  662 	mov	a,#0x52
      009850 9F               [12]  663 	subb	a,r7
      009851 50 46            [24]  664 	jnc	00101$
                                    665 ;	free result
      009853                        666 00107$:
                                    667 ;	quantum/process_keycode/process_repeat_key.c:52: (keycode >= KC_LCTL && keycode <= KC_RGUI) ||
      009853 90 0B B5         [24]  668 	mov	dptr,#_remember_last_key_keycode_10000_239
      009856 12 37 F8         [24]  669 	lcall	_ak820_outline_0050
      009859 12 99 81         [24]  670 	lcall	_ak820_outline_0114
      00985C 40 07            [24]  671 	jc	00108$
      00985E 74 E7            [12]  672 	mov	a,#0xe7
      009860 9E               [12]  673 	subb	a,r6
      009861 E4               [12]  674 	clr	a
      009862 9F               [12]  675 	subb	a,r7
      009863 50 34            [24]  676 	jnc	00101$
                                    677 ;	free result
      009865                        678 00108$:
                                    679 ;	quantum/process_keycode/process_repeat_key.c:53: keycode == KC_HYPR || keycode == KC_MEH || keycode == QK_REPEAT_KEY
      009865 90 0B B5         [24]  680 	mov	dptr,#_remember_last_key_keycode_10000_239
      009868 12 37 C3         [24]  681 	lcall	_ak820_outline_0009
      00986B BC 00 05         [24]  682 	cjne	r4,#0x00,00185$
      00986E BD 0F 02         [24]  683 	cjne	r5,#0x0f,00185$
      009871 80 26            [24]  684 	sjmp	00101$
      009873                        685 00185$:
      009873 BC 00 05         [24]  686 	cjne	r4,#0x00,00186$
      009876 BD 07 02         [24]  687 	cjne	r5,#0x07,00186$
      009879 80 1E            [24]  688 	sjmp	00101$
      00987B                        689 00186$:
                                    690 ;	quantum/process_keycode/process_repeat_key.c:55: || keycode == QK_ALT_REPEAT_KEY
      00987B BC 79 05         [24]  691 	cjne	r4,#0x79,00187$
      00987E BD 7C 02         [24]  692 	cjne	r5,#0x7c,00187$
      009881 80 16            [24]  693 	sjmp	00101$
      009883                        694 00187$:
                                    695 ;	quantum/process_keycode/process_repeat_key.c:62: || keycode == QK_TRI_LAYER_LOWER || keycode == QK_TRI_LAYER_UPPER
      009883 BC 7A 05         [24]  696 	cjne	r4,#0x7a,00188$
      009886 BD 7C 02         [24]  697 	cjne	r5,#0x7c,00188$
      009889 80 0E            [24]  698 	sjmp	00101$
      00988B                        699 00188$:
      00988B BC 77 05         [24]  700 	cjne	r4,#0x77,00189$
      00988E BD 7C 02         [24]  701 	cjne	r5,#0x7c,00189$
      009891 80 06            [24]  702 	sjmp	00101$
      009893                        703 00189$:
                                    704 ;	quantum/process_keycode/process_repeat_key.c:64: ) return false;
      009893 BC 78 07         [24]  705 	cjne	r4,#0x78,00102$
      009896 BD 7C 04         [24]  706 	cjne	r5,#0x7c,00102$
      009899                        707 00101$:
      009899 75 82 00         [24]  708 	mov	dpl, #0x00
      00989C 22               [24]  709 	ret
      00989D                        710 00102$:
                                    711 ;	quantum/process_keycode/process_repeat_key.c:77: return remember_last_key_user(keycode, record, remembered_mods);
      00989D 90 0B B0         [24]  712 	mov	dptr,#_remember_last_key_PARM_2
      0098A0 12 38 51         [24]  713 	lcall	_ak820_outline_0120
      0098A3 7D 00            [12]  714 	mov	r5,#0x00
      0098A5 90 0B B2         [24]  715 	mov	dptr,#_remember_last_key_PARM_3
      0098A8 12 38 35         [24]  716 	lcall	_ak820_outline_0099
      0098AB A3               [24]  717 	inc	dptr
      0098AC E0               [24]  718 	movx	a,@dptr
      0098AD FA               [12]  719 	mov	r2,a
      0098AE 90 0B AA         [24]  720 	mov	dptr,#_remember_last_key_user_PARM_2
      0098B1 12 38 23         [24]  721 	lcall	_ak820_outline_0076
      0098B4 ED               [12]  722 	mov	a,r5
      0098B5 A3               [24]  723 	inc	dptr
      0098B6 F0               [24]  724 	movx	@dptr,a
      0098B7 90 0B AD         [24]  725 	mov	dptr,#_remember_last_key_user_PARM_3
      0098BA E8               [12]  726 	mov	a,r0
      0098BB F0               [24]  727 	movx	@dptr,a
      0098BC E9               [12]  728 	mov	a,r1
      0098BD A3               [24]  729 	inc	dptr
      0098BE F0               [24]  730 	movx	@dptr,a
      0098BF EA               [12]  731 	mov	a,r2
      0098C0 A3               [24]  732 	inc	dptr
      0098C1 12 42 F2         [24]  733 	lcall	_ak820_outline_0060
                                    734 ;	quantum/process_keycode/process_repeat_key.c:78: }
      0098C4 01 22            [12]  735 	ajmp	_remember_last_key_user
                                    736 ;------------------------------------------------------------
                                    737 ;Allocation info for local variables in function 'process_last_key'
                                    738 ;------------------------------------------------------------
                                    739 ;record        Allocated with name '_process_last_key_PARM_2'
                                    740 ;keycode       Allocated with name '_process_last_key_keycode_10000_242'
                                    741 ;remembered_mods Allocated with name '_process_last_key_remembered_mods_30000_247'
                                    742 ;------------------------------------------------------------
                                    743 ;	quantum/process_keycode/process_repeat_key.c:80: bool process_last_key(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record) {
                                    744 ;	-----------------------------------------
                                    745 ;	 function process_last_key
                                    746 ;	-----------------------------------------
      0098C6                        747 _process_last_key:
      0098C6 12 38 3B         [24]  748 	lcall	_ak820_outline_0103
      0098C9 90 0B B9         [24]  749 	mov	dptr,#_process_last_key_keycode_10000_242
      0098CC 12 38 40         [24]  750 	lcall	_ak820_outline_0104
                                    751 ;	quantum/process_keycode/process_repeat_key.c:81: if (get_repeat_key_count()) {
      0098CF F1 0E            [12]  752 	acall	_get_repeat_key_count
      0098D1 E5 82            [12]  753 	mov	a, dpl
      0098D3 60 04            [24]  754 	jz	00102$
                                    755 ;	quantum/process_keycode/process_repeat_key.c:82: return true;
      0098D5 75 82 01         [24]  756 	mov	dpl, #0x01
      0098D8 22               [24]  757 	ret
      0098D9                        758 00102$:
                                    759 ;	quantum/process_keycode/process_repeat_key.c:85: if (record->event.pressed) {
      0098D9 90 0B B7         [24]  760 	mov	dptr,#_process_last_key_PARM_2
      0098DC 12 37 F8         [24]  761 	lcall	_ak820_outline_0050
      0098DF 74 05            [12]  762 	mov	a,#0x05
      0098E1 12 47 D5         [24]  763 	lcall	_ak820_outline_0011
      0098E4 60 51            [24]  764 	jz	00106$
                                    765 ;	quantum/process_keycode/process_repeat_key.c:86: uint8_t remembered_mods = get_mods() | get_weak_mods();
      0098E6 12 7E F6         [24]  766 	lcall	_get_mods
      0098E9 AD 82            [24]  767 	mov	r5, dpl
      0098EB 12 7F 0C         [24]  768 	lcall	_get_weak_mods
      0098EE AC 82            [24]  769 	mov	r4, dpl
      0098F0 90 0B BB         [24]  770 	mov	dptr,#_process_last_key_remembered_mods_30000_247
      0098F3 EC               [12]  771 	mov	a,r4
      0098F4 4D               [12]  772 	orl	a,r5
      0098F5 F0               [24]  773 	movx	@dptr,a
                                    774 ;	quantum/process_keycode/process_repeat_key.c:91: if (remember_last_key(keycode, record, &remembered_mods)) {
      0098F6 90 0B B9         [24]  775 	mov	dptr,#_process_last_key_keycode_10000_242
      0098F9 12 38 17         [24]  776 	lcall	_ak820_outline_0059
      0098FC 90 0B B0         [24]  777 	mov	dptr,#_remember_last_key_PARM_2
      0098FF 12 48 2F         [24]  778 	lcall	_ak820_outline_0058
      009902 90 0B B2         [24]  779 	mov	dptr,#_remember_last_key_PARM_3
      009905 74 BB            [12]  780 	mov	a,#_process_last_key_remembered_mods_30000_247
      009907 F0               [24]  781 	movx	@dptr,a
      009908 74 0B            [12]  782 	mov	a,#(_process_last_key_remembered_mods_30000_247 >> 8)
      00990A 12 38 29         [24]  783 	lcall	_ak820_outline_0096
      00990D 12 38 4C         [24]  784 	lcall	_ak820_outline_0117
      009910 C0 05            [24]  785 	push	ar5
      009912 C0 04            [24]  786 	push	ar4
      009914 11 26            [12]  787 	acall	_remember_last_key
      009916 E5 82            [12]  788 	mov	a, dpl
      009918 D0 04            [24]  789 	pop	ar4
      00991A D0 05            [24]  790 	pop	ar5
      00991C 60 19            [24]  791 	jz	00106$
                                    792 ;	quantum/process_keycode/process_repeat_key.c:92: set_last_record(keycode, record);
      00991E 90 0B B7         [24]  793 	mov	dptr,#_process_last_key_PARM_2
      009921 12 37 F8         [24]  794 	lcall	_ak820_outline_0050
      009924 90 0B FB         [24]  795 	mov	dptr,#_set_last_record_PARM_2
      009927 12 48 2F         [24]  796 	lcall	_ak820_outline_0058
      00992A 12 38 4C         [24]  797 	lcall	_ak820_outline_0117
      00992D D1 8D            [12]  798 	acall	_set_last_record
                                    799 ;	quantum/process_keycode/process_repeat_key.c:93: set_last_mods(remembered_mods);
      00992F 90 0B BB         [24]  800 	mov	dptr,#_process_last_key_remembered_mods_30000_247
      009932 E0               [24]  801 	movx	a,@dptr
      009933 F5 82            [12]  802 	mov	dpl,a
      009935 D1 81            [12]  803 	acall	_set_last_mods
      009937                        804 00106$:
                                    805 ;	quantum/process_keycode/process_repeat_key.c:97: return true;
      009937 75 82 01         [24]  806 	mov	dpl, #0x01
                                    807 ;	quantum/process_keycode/process_repeat_key.c:98: }
      00993A 22               [24]  808 	ret
                                    809 ;------------------------------------------------------------
                                    810 ;Allocation info for local variables in function 'process_repeat_key'
                                    811 ;------------------------------------------------------------
                                    812 ;record        Allocated with name '_process_repeat_key_PARM_2'
                                    813 ;keycode       Allocated with name '_process_repeat_key_keycode_10000_250'
                                    814 ;------------------------------------------------------------
                                    815 ;	quantum/process_keycode/process_repeat_key.c:100: bool process_repeat_key(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record) {
                                    816 ;	-----------------------------------------
                                    817 ;	 function process_repeat_key
                                    818 ;	-----------------------------------------
      00993B                        819 _process_repeat_key:
      00993B 12 38 3B         [24]  820 	lcall	_ak820_outline_0103
      00993E 90 0B BE         [24]  821 	mov	dptr,#_process_repeat_key_keycode_10000_250
      009941 12 38 40         [24]  822 	lcall	_ak820_outline_0104
                                    823 ;	quantum/process_keycode/process_repeat_key.c:101: if (get_repeat_key_count()) {
      009944 F1 0E            [12]  824 	acall	_get_repeat_key_count
      009946 E5 82            [12]  825 	mov	a, dpl
      009948 60 04            [24]  826 	jz	00102$
                                    827 ;	quantum/process_keycode/process_repeat_key.c:102: return true;
      00994A 75 82 01         [24]  828 	mov	dpl, #0x01
      00994D 22               [24]  829 	ret
      00994E                        830 00102$:
                                    831 ;	quantum/process_keycode/process_repeat_key.c:105: if (keycode == QK_REPEAT_KEY) {
      00994E 90 0B BE         [24]  832 	mov	dptr,#_process_repeat_key_keycode_10000_250
      009951 12 37 F8         [24]  833 	lcall	_ak820_outline_0050
      009954 BE 79 13         [24]  834 	cjne	r6,#0x79,00106$
      009957 BF 7C 10         [24]  835 	cjne	r7,#0x7c,00106$
                                    836 ;	quantum/process_keycode/process_repeat_key.c:106: repeat_key_invoke(&record->event);
      00995A 90 0B BC         [24]  837 	mov	dptr,#_process_repeat_key_PARM_2
      00995D 12 38 17         [24]  838 	lcall	_ak820_outline_0059
      009960 12 38 4C         [24]  839 	lcall	_ak820_outline_0117
      009963 12 A0 27         [24]  840 	lcall	_repeat_key_invoke
                                    841 ;	quantum/process_keycode/process_repeat_key.c:107: return false;
      009966 75 82 00         [24]  842 	mov	dpl, #0x00
      009969 22               [24]  843 	ret
      00996A                        844 00106$:
                                    845 ;	quantum/process_keycode/process_repeat_key.c:109: } else if (keycode == QK_ALT_REPEAT_KEY) {
      00996A BE 7A 10         [24]  846 	cjne	r6,#0x7a,00107$
      00996D BF 7C 0D         [24]  847 	cjne	r7,#0x7c,00107$
                                    848 ;	quantum/process_keycode/process_repeat_key.c:110: alt_repeat_key_invoke(&record->event);
      009970 90 0B BC         [24]  849 	mov	dptr,#_process_repeat_key_PARM_2
      009973 12 37 98         [24]  850 	lcall	_ak820_outline_0004
      009976 12 A1 91         [24]  851 	lcall	_alt_repeat_key_invoke
                                    852 ;	quantum/process_keycode/process_repeat_key.c:111: return false;
      009979 75 82 00         [24]  853 	mov	dpl, #0x00
      00997C 22               [24]  854 	ret
      00997D                        855 00107$:
                                    856 ;	quantum/process_keycode/process_repeat_key.c:115: return true;
      00997D 75 82 01         [24]  857 	mov	dpl, #0x01
                                    858 ;	quantum/process_keycode/process_repeat_key.c:116: }
      009980 22               [24]  859 	ret
                                    860 	.area CSEG    (CODE)
                                    861 	.area CONST   (CODE)
                                    862 	.area XINIT   (CODE)
                                    863 	.area CABS    (ABS,CODE)
                                    864 
                                    865 ; Experimental exact instruction outlining.
                                    866 	.globl _ak820_outline_0004
                                    867 	.globl _ak820_outline_0009
                                    868 	.globl _ak820_outline_0011
                                    869 	.globl _ak820_outline_0035
                                    870 	.globl _ak820_outline_0050
                                    871 	.globl _ak820_outline_0058
                                    872 	.globl _ak820_outline_0059
                                    873 	.globl _ak820_outline_0060
                                    874 	.globl _ak820_outline_0076
                                    875 	.globl _ak820_outline_0096
                                    876 	.globl _ak820_outline_0099
                                    877 	.globl _ak820_outline_0103
                                    878 	.globl _ak820_outline_0104
                                    879 	.globl _ak820_outline_0114
                                    880 	.globl _ak820_outline_0117
                                    881 	.globl _ak820_outline_0120
                                    882 
                                    883 	.area CSEG (CODE)
                                    884 ; function ak820_outline_0114
      009981                        885 _ak820_outline_0114:
      009981 C3               [12]  886 	clr	c
      009982 EE               [12]  887 	mov	a,r6
      009983 94 E0            [12]  888 	subb	a,#0xe0
      009985 EF               [12]  889 	mov	a,r7
      009986 94 00            [12]  890 	subb	a,#0x00
      009988 22               [24]  891 	ret
