                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000053                        551 _change_owned_sloc1_1_0:
      000053                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      00001E                        566 _ak820_macro_change_sloc0_1_0:
      00001E                        567 	.ds 1
      00001F                        568 _change_owned_sloc0_1_0:
      00001F                        569 	.ds 1
      000020                        570 _owned_usage_key_sloc0_1_0:
      000020                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000968                        580 _owned_mod_refs:
      000968                        581 	.ds 8
      000970                        582 _owned_weak_refs:
      000970                        583 	.ds 8
      000978                        584 _owned_mods:
      000978                        585 	.ds 1
      000979                        586 _owned_weak_mods:
      000979                        587 	.ds 1
      00097A                        588 _macro_mods:
      00097A                        589 	.ds 2
      00097C                        590 _ak820_macro_primitive::
      00097C                        591 	.ds 1
      00097D                        592 _ak820_macro_cancelled::
      00097D                        593 	.ds 1
      00097E                        594 _ak820_macro_change_PARM_2:
      00097E                        595 	.ds 1
      00097F                        596 _ak820_macro_change_PARM_3:
      00097F                        597 	.ds 1
      000980                        598 _ak820_macro_change_bits_10000_293:
      000980                        599 	.ds 2
      000982                        600 _change_owned_PARM_2:
      000982                        601 	.ds 1
      000983                        602 _change_owned_mods_10000_298:
      000983                        603 	.ds 1
      000984                        604 _change_owned_result_10001_302:
      000984                        605 	.ds 1
      000985                        606 _change_owned_bit_20001_303:
      000985                        607 	.ds 1
      000986                        608 _add_owned_mods_mods_10000_311:
      000986                        609 	.ds 1
      000987                        610 _del_owned_mods_mods_10000_313:
      000987                        611 	.ds 1
      000988                        612 _add_owned_weak_mods_mods_10000_315:
      000988                        613 	.ds 1
      000989                        614 _del_owned_weak_mods_mods_10000_317:
      000989                        615 	.ds 1
      00098A                        616 _key_refs:
      00098A                        617 	.ds 165
      000A2F                        618 _distinct_keys:
      000A2F                        619 	.ds 1
      000A30                        620 _macro_keys:
      000A30                        621 	.ds 21
      000A45                        622 _add_owned_key_code_10000_326:
      000A45                        623 	.ds 1
      000A46                        624 _del_owned_key_code_10000_341:
      000A46                        625 	.ds 1
      000A47                        626 _usage_refs:
      000A47                        627 	.ds 30
      000A65                        628 _usage_order:
      000A65                        629 	.ds 30
      000A83                        630 _usage_lengths:
      000A83                        631 	.ds 2
      000A85                        632 _macro_usages:
      000A85                        633 	.ds 4
      000A89                        634 _owned_usage_key_PARM_2:
      000A89                        635 	.ds 1
      000A8A                        636 _owned_usage_key_code_10000_368:
      000A8A                        637 	.ds 1
      000A8B                        638 _owned_usage_key___200000085_20000_369:
      000A8B                        639 	.ds 2
      000A8D                        640 _owned_usage_key_which_10000_369:
      000A8D                        641 	.ds 1
      000A8E                        642 _owned_usage_key_count_10000_369:
      000A8E                        643 	.ds 1
      000A8F                        644 _owned_usage_key_pos_30001_376:
      000A8F                        645 	.ds 1
      000A90                        646 _owned_usage_key_key_40000_381:
      000A90                        647 	.ds 1
      000A91                        648 _send_keyboard_report_last_report_10001_388:
      000A91                        649 	.ds 32
      000AB1                        650 _send_keyboard_report_changed_10001_388:
      000AB1                        651 	.ds 1
      000AB2                        652 _add_weak_mods_mods_10000_406:
      000AB2                        653 	.ds 1
      000AB3                        654 _del_weak_mods_mods_10000_408:
      000AB3                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000D93                        664 _real_mods:
      000D93                        665 	.ds 1
      000D94                        666 _weak_mods:
      000D94                        667 	.ds 1
      000D95                        668 _actual_keyboard_report::
      000D95                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007A1E                        713 _ak820_macro_change:
      007A1E 12 38 3B         [24]  714 	lcall	_ak820_outline_0103
      007A21 90 09 80         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007A24 12 38 40         [24]  716 	lcall	_ak820_outline_0104
                                    717 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      007A27 90 09 7C         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007A2A E0               [24]  719 	movx	a,@dptr
      007A2B 70 04            [24]  720 	jnz	00102$
      007A2D 75 82 01         [24]  721 	mov	dpl, #0x01
      007A30 22               [24]  722 	ret
      007A31                        723 00102$:
                                    724 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      007A31 90 09 7E         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      007A34 E0               [24]  726 	movx	a,@dptr
      007A35 FF               [12]  727 	mov	r7,a
      007A36 74 07            [12]  728 	mov	a,#0x07
      007A38 5F               [12]  729 	anl	a,r7
      007A39 12 75 D9         [24]  730 	lcall	_ak820_outline_0062
      007A3C 80 02            [24]  731 	sjmp	00123$
      007A3E                        732 00122$:
      007A3E 25 E0            [12]  733 	add	a,acc
      007A40                        734 00123$:
      007A40 D5 F0 FB         [24]  735 	djnz	b,00122$
      007A43 FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:101: bits += index >> 3;
      007A44 EF               [12]  738 	mov	a,r7
      007A45 12 56 AD         [24]  739 	lcall	_ak820_outline_0182
      007A48 FF               [12]  740 	mov	r7,a
      007A49 90 09 80         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007A4C 12 38 17         [24]  742 	lcall	_ak820_outline_0059
      007A4F 90 09 80         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007A52 EF               [12]  744 	mov	a,r7
      007A53 2C               [12]  745 	add	a, r4
      007A54 F0               [24]  746 	movx	@dptr,a
      007A55 E4               [12]  747 	clr	a
      007A56 3D               [12]  748 	addc	a, r5
      007A57 A3               [24]  749 	inc	dptr
      007A58 F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      007A59 90 09 80         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007A5C E0               [24]  753 	movx	a,@dptr
      007A5D FD               [12]  754 	mov	r5,a
      007A5E A3               [24]  755 	inc	dptr
      007A5F E0               [24]  756 	movx	a,@dptr
      007A60 FF               [12]  757 	mov	r7,a
      007A61 12 7F 9B         [24]  758 	lcall	_ak820_outline_0183
      007A64 E0               [24]  759 	movx	a,@dptr
      007A65 FC               [12]  760 	mov	r4,a
      007A66 EE               [12]  761 	mov	a,r6
      007A67 5C               [12]  762 	anl	a,r4
      007A68 B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      007A6B                        764 00124$:
      007A6B B3               [12]  765 	cpl	c
      007A6C 92 1E            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      007A6E 90 09 7F         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      007A71 E0               [24]  768 	movx	a,@dptr
      007A72 FB               [12]  769 	mov	r3,a
      007A73 A2 1E            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      007A75 E4               [12]  771 	clr	a
      007A76 33               [12]  772 	rlc	a
      007A77 B5 03 04         [24]  773 	cjne	a,ar3,00104$
      007A7A 75 82 00         [24]  774 	mov	dpl, #0x00
      007A7D 22               [24]  775 	ret
      007A7E                        776 00104$:
                                    777 ;	quantum/action_util.c:103: *bits ^= mask;
      007A7E EC               [12]  778 	mov	a,r4
      007A7F 62 06            [12]  779 	xrl	ar6,a
      007A81 12 7F 9B         [24]  780 	lcall	_ak820_outline_0183
      007A84 EE               [12]  781 	mov	a,r6
      007A85 F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:104: return true;
      007A86 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:105: }
      007A89 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      007A8A                        805 _change_owned:
      007A8A E5 82            [12]  806 	mov	a,dpl
      007A8C 90 09 83         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      007A8F F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      007A90 90 09 82         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007A93 E0               [24]  811 	movx	a,@dptr
      007A94 FF               [12]  812 	mov	r7,a
      007A95 C3               [12]  813 	clr	c
      007A96 13               [12]  814 	rrc	a
      007A97 FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      007A98 53 07 01         [24]  817 	anl	ar7,#0x01
      007A9B EF               [12]  818 	mov	a,r7
      007A9C B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007A9F                        820 00205$:
      007A9F 92 1F            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007AA1 B3               [12]  822 	cpl	c
      007AA2 E4               [12]  823 	clr	a
      007AA3 33               [12]  824 	rlc	a
      007AA4 F5 53            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007AA6 EE               [12]  827 	mov	a,r6
      007AA7 60 06            [24]  828 	jz	00121$
      007AA9 7D 70            [12]  829 	mov	r5,#_owned_weak_refs
      007AAB 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      007AAD 80 04            [24]  831 	sjmp	00122$
      007AAF                        832 00121$:
      007AAF 7D 68            [12]  833 	mov	r5,#_owned_mod_refs
      007AB1 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007AB3                        835 00122$:
                                    836 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      007AB3 90 09 7C         [24]  837 	mov	dptr,#_ak820_macro_primitive
      007AB6 E0               [24]  838 	movx	a,@dptr
      007AB7 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      007AB9 EE               [12]  841 	mov	a,r6
      007ABA 24 7A            [12]  842 	add	a, #_macro_mods
      007ABC FB               [12]  843 	mov	r3,a
      007ABD E4               [12]  844 	clr	a
      007ABE 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007AC0 12 48 27         [24]  846 	lcall	_ak820_outline_0055
                                    847 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007AC3 E5 53            [12]  848 	mov	a,_change_owned_sloc1_1_0
      007AC5 60 0A            [24]  849 	jz	00123$
      007AC7 90 09 83         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      007ACA E0               [24]  851 	movx	a,@dptr
      007ACB F9               [12]  852 	mov	r1,a
      007ACC EA               [12]  853 	mov	a,r2
      007ACD 42 01            [12]  854 	orl	ar1,a
      007ACF 80 07            [24]  855 	sjmp	00124$
      007AD1                        856 00123$:
      007AD1 90 09 83         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      007AD4 E0               [24]  858 	movx	a,@dptr
      007AD5 F4               [12]  859 	cpl	a
      007AD6 5A               [12]  860 	anl	a,r2
      007AD7 F9               [12]  861 	mov	r1,a
      007AD8                        862 00124$:
      007AD8 12 33 FC         [24]  863 	lcall	_ak820_outline_0121
      007ADB E9               [12]  864 	mov	a,r1
      007ADC F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      007ADD E5 53            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007ADF 60 06            [24]  868 	jz	00125$
      007AE1 74 FF            [12]  869 	mov	a,#0xff
      007AE3 6A               [12]  870 	xrl	a,r2
      007AE4 FC               [12]  871 	mov	r4,a
      007AE5 80 02            [24]  872 	sjmp	00126$
      007AE7                        873 00125$:
      007AE7 8A 04            [24]  874 	mov	ar4,r2
      007AE9                        875 00126$:
      007AE9 90 09 83         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      007AEC E0               [24]  877 	movx	a,@dptr
      007AED 5C               [12]  878 	anl	a,r4
      007AEE F0               [24]  879 	movx	@dptr,a
      007AEF                        880 00102$:
                                    881 ;	quantum/action_util.c:115: uint8_t result = 0;
      007AEF 90 09 84         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      007AF2 E4               [12]  883 	clr	a
      007AF3 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007AF4 90 09 85         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      007AF7 04               [12]  887 	inc	a
      007AF8 F0               [24]  888 	movx	@dptr,a
      007AF9 90 09 83         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      007AFC E0               [24]  890 	movx	a,@dptr
      007AFD FC               [12]  891 	mov	r4,a
      007AFE 7B 00            [12]  892 	mov	r3,#0x00
      007B00                        893 00117$:
      007B00 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      007B03                        895 00210$:
      007B03 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:117: if (mods & bit) {
      007B05 90 09 85         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      007B08 E0               [24]  899 	movx	a,@dptr
      007B09 5C               [12]  900 	anl	a,r4
      007B0A 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      007B0C E5 53            [12]  903 	mov	a,_change_owned_sloc1_1_0
      007B0E 60 0C            [24]  904 	jz	00106$
      007B10 EB               [12]  905 	mov	a,r3
      007B11 2D               [12]  906 	add	a, r5
      007B12 12 37 CD         [24]  907 	lcall	_ak820_outline_0013
      007B15 F8               [12]  908 	mov	r0,a
      007B16 08               [12]  909 	inc	r0
      007B17 12 7F 4F         [24]  910 	lcall	_ak820_outline_0063
      007B1A 80 0C            [24]  911 	sjmp	00109$
      007B1C                        912 00106$:
                                    913 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      007B1C EB               [12]  914 	mov	a,r3
      007B1D 2D               [12]  915 	add	a, r5
      007B1E 12 37 CD         [24]  916 	lcall	_ak820_outline_0013
      007B21 F8               [12]  917 	mov	r0,a
      007B22 60 04            [24]  918 	jz	00109$
      007B24 18               [12]  919 	dec	r0
      007B25 12 7F 4F         [24]  920 	lcall	_ak820_outline_0063
      007B28                        921 00109$:
                                    922 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      007B28 EB               [12]  923 	mov	a,r3
      007B29 2D               [12]  924 	add	a, r5
      007B2A 12 37 CD         [24]  925 	lcall	_ak820_outline_0013
      007B2D 60 0B            [24]  926 	jz	00118$
      007B2F 90 09 85         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      007B32 E0               [24]  928 	movx	a,@dptr
      007B33 FA               [12]  929 	mov	r2,a
      007B34 90 09 84         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      007B37 E0               [24]  931 	movx	a,@dptr
      007B38 4A               [12]  932 	orl	a,r2
      007B39 F0               [24]  933 	movx	@dptr,a
      007B3A                        934 00118$:
                                    935 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007B3A 0B               [12]  936 	inc	r3
      007B3B 90 09 85         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      007B3E E0               [24]  938 	movx	a,@dptr
      007B3F 25 E0            [12]  939 	add	a,acc
      007B41 F0               [24]  940 	movx	@dptr,a
      007B42 80 BC            [24]  941 	sjmp	00117$
      007B44                        942 00112$:
                                    943 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      007B44 EE               [12]  944 	mov	a,r6
      007B45 60 09            [24]  945 	jz	00114$
      007B47 90 09 84         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      007B4A E0               [24]  947 	movx	a,@dptr
      007B4B 90 09 79         [24]  948 	mov	dptr,#_owned_weak_mods
      007B4E F0               [24]  949 	movx	@dptr,a
      007B4F 22               [24]  950 	ret
      007B50                        951 00114$:
                                    952 ;	quantum/action_util.c:124: else owned_mods = result;
      007B50 90 09 84         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      007B53 E0               [24]  954 	movx	a,@dptr
      007B54 90 09 78         [24]  955 	mov	dptr,#_owned_mods
      007B57 F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:125: }
      007B58 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      007B59                        968 _add_owned_mods:
      007B59 E5 82            [12]  969 	mov	a,dpl
      007B5B 90 09 86         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      007B5E 12 7F 6F         [24]  971 	lcall	_ak820_outline_0113
      007B61 74 01            [12]  972 	mov	a,#0x01
      007B63 F0               [24]  973 	movx	@dptr,a
      007B64 8F 82            [24]  974 	mov	dpl, r7
      007B66 41 8A            [12]  975 	ajmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      007B68                        985 _del_owned_mods:
      007B68 E5 82            [12]  986 	mov	a,dpl
      007B6A 90 09 87         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      007B6D 12 7F 6F         [24]  988 	lcall	_ak820_outline_0113
      007B70 E4               [12]  989 	clr	a
      007B71 F0               [24]  990 	movx	@dptr,a
      007B72 8F 82            [24]  991 	mov	dpl, r7
      007B74 41 8A            [12]  992 	ajmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      007B76                       1002 _add_owned_weak_mods:
      007B76 E5 82            [12] 1003 	mov	a,dpl
      007B78 90 09 88         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      007B7B 12 7F 6F         [24] 1005 	lcall	_ak820_outline_0113
      007B7E 74 03            [12] 1006 	mov	a,#0x03
      007B80 F0               [24] 1007 	movx	@dptr,a
      007B81 8F 82            [24] 1008 	mov	dpl, r7
      007B83 41 8A            [12] 1009 	ajmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      007B85                       1019 _del_owned_weak_mods:
      007B85 E5 82            [12] 1020 	mov	a,dpl
      007B87 90 09 89         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      007B8A 12 7F 6F         [24] 1022 	lcall	_ak820_outline_0113
      007B8D 74 02            [12] 1023 	mov	a,#0x02
      007B8F F0               [24] 1024 	movx	@dptr,a
      007B90 8F 82            [24] 1025 	mov	dpl, r7
      007B92 41 8A            [12] 1026 	ajmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      007B94                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007B94 7F 00            [12] 1038 	mov	r7,#0x00
      007B96                       1039 00103$:
      007B96 BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      007B99                       1041 00122$:
      007B99 50 1A            [24] 1042 	jnc	00101$
      007B9B EF               [12] 1043 	mov	a,r7
      007B9C 24 68            [12] 1044 	add	a, #_owned_mod_refs
      007B9E FD               [12] 1045 	mov	r5,a
      007B9F E4               [12] 1046 	clr	a
      007BA0 34 09            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      007BA2 FE               [12] 1048 	mov	r6,a
      007BA3 EF               [12] 1049 	mov	a,r7
      007BA4 24 70            [12] 1050 	add	a, #_owned_weak_refs
      007BA6 F5 82            [12] 1051 	mov	dpl,a
      007BA8 E4               [12] 1052 	clr	a
      007BA9 34 09            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      007BAB F5 83            [12] 1054 	mov	dph,a
      007BAD E4               [12] 1055 	clr	a
      007BAE F0               [24] 1056 	movx	@dptr,a
      007BAF 12 7F 76         [24] 1057 	lcall	_ak820_outline_0118
      007BB2 0F               [12] 1058 	inc	r7
      007BB3 80 E1            [24] 1059 	sjmp	00103$
      007BB5                       1060 00101$:
                                   1061 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007BB5 90 09 7B         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      007BB8 E4               [12] 1063 	clr	a
      007BB9 F0               [24] 1064 	movx	@dptr,a
      007BBA 90 09 7A         [24] 1065 	mov	dptr,#_macro_mods
      007BBD F0               [24] 1066 	movx	@dptr,a
      007BBE 90 09 79         [24] 1067 	mov	dptr,#_owned_weak_mods
      007BC1 F0               [24] 1068 	movx	@dptr,a
      007BC2 90 09 78         [24] 1069 	mov	dptr,#_owned_mods
      007BC5 F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      007BC6 90 09 7D         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      007BC9 04               [12] 1073 	inc	a
      007BCA F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:134: }
      007BCB 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      007BCC                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007BCC 7F 00            [12] 1089 	mov	r7,#0x00
      007BCE                       1090 00104$:
      007BCE EF               [12] 1091 	mov	a,r7
      007BCF 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      007BD1 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      007BD3 EF               [12] 1095 	mov	a,r7
      007BD4 24 8A            [12] 1096 	add	a, #_key_refs
      007BD6 F5 82            [12] 1097 	mov	dpl,a
      007BD8 E4               [12] 1098 	clr	a
      007BD9 34 09            [12] 1099 	addc	a, #(_key_refs >> 8)
      007BDB 12 7A 0F         [24] 1100 	lcall	_ak820_outline_0157
      007BDE 80 EE            [24] 1101 	sjmp	00104$
      007BE0                       1102 00101$:
                                   1103 ;	quantum/action_util.c:142: distinct_keys = 0;
      007BE0 90 0A 2F         [24] 1104 	mov	dptr,#_distinct_keys
      007BE3 E4               [12] 1105 	clr	a
      007BE4 F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007BE5 FF               [12] 1108 	mov	r7,a
      007BE6                       1109 00107$:
      007BE6 BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      007BE9                       1111 00142$:
      007BE9 50 0D            [24] 1112 	jnc	00109$
      007BEB EF               [12] 1113 	mov	a,r7
      007BEC 24 30            [12] 1114 	add	a, #_macro_keys
      007BEE F5 82            [12] 1115 	mov	dpl,a
      007BF0 E4               [12] 1116 	clr	a
      007BF1 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      007BF3 12 7A 0F         [24] 1118 	lcall	_ak820_outline_0157
      007BF6 80 EE            [24] 1119 	sjmp	00107$
      007BF8                       1120 00109$:
                                   1121 ;	quantum/action_util.c:144: }
      007BF8 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      007BF9                       1137 _add_owned_key:
      007BF9 E5 82            [12] 1138 	mov	a,dpl
      007BFB 90 0A 45         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      007BFE 12 7F 87         [24] 1140 	lcall	_ak820_outline_0129
                                   1141 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007C01 74 01            [12] 1142 	mov	a,#0x01
      007C03 F0               [24] 1143 	movx	@dptr,a
      007C04 90 0A 30         [24] 1144 	mov	dptr,#_macro_keys
      007C07 C0 07            [24] 1145 	push	ar7
      007C09 51 1E            [12] 1146 	acall	_ak820_macro_change
      007C0B E5 82            [12] 1147 	mov	a, dpl
      007C0D D0 07            [24] 1148 	pop	ar7
      007C0F 70 03            [24] 1149 	jnz	00102$
      007C11 F5 82            [12] 1150 	mov	dpl,a
      007C13 22               [24] 1151 	ret
      007C14                       1152 00102$:
                                   1153 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      007C14 12 7F 41         [24] 1154 	lcall	_ak820_outline_0028
      007C17 FC               [12] 1155 	mov	r4,a
      007C18 04               [12] 1156 	inc	a
      007C19 12 7F 76         [24] 1157 	lcall	_ak820_outline_0118
      007C1C EC               [12] 1158 	mov	a,r4
      007C1D 60 04            [24] 1159 	jz	00104$
      007C1F 75 82 00         [24] 1160 	mov	dpl, #0x00
      007C22 22               [24] 1161 	ret
      007C23                       1162 00104$:
                                   1163 ;	quantum/action_util.c:148: ++distinct_keys;
      007C23 90 0A 2F         [24] 1164 	mov	dptr,#_distinct_keys
      007C26 E0               [24] 1165 	movx	a,@dptr
      007C27 24 01            [12] 1166 	add	a, #0x01
      007C29 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007C2A 90 0D 82         [24] 1169 	mov	dptr,#_keyboard_protocol
      007C2D E0               [24] 1170 	movx	a,@dptr
      007C2E 60 11            [24] 1171 	jz	00106$
      007C30 90 0A B4         [24] 1172 	mov	dptr,#_keymap_config
      007C33 E0               [24] 1173 	movx	a,@dptr
      007C34 30 E7 0A         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007C37 12 7F 92         [24] 1176 	lcall	_ak820_outline_0171
      007C3A 12 6E 11         [24] 1177 	lcall	_add_key_to_report
                                   1178 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007C3D 75 82 01         [24] 1179 	mov	dpl, #0x01
      007C40 22               [24] 1180 	ret
      007C41                       1181 00106$:
                                   1182 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007C41 90 0A 2F         [24] 1183 	mov	dptr,#_distinct_keys
      007C44 E0               [24] 1184 	movx	a,@dptr
      007C45 24 F9            [12] 1185 	add	a,#0xff - 0x06
      007C47 50 17            [24] 1186 	jnc	00110$
                                   1187 ;	free result
                                   1188 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007C49 7F 00            [12] 1189 	mov	r7,#0x00
      007C4B                       1190 00115$:
      007C4B BF 06 00         [24] 1191 	cjne	r7,#0x06,00174$
      007C4E                       1192 00174$:
      007C4E 50 1E            [24] 1193 	jnc	00111$
      007C50 EF               [12] 1194 	mov	a,r7
      007C51 24 97            [12] 1195 	add	a, #(_actual_keyboard_report + 0x0002)
      007C53 F5 82            [12] 1196 	mov	dpl,a
      007C55 E4               [12] 1197 	clr	a
      007C56 34 0D            [12] 1198 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007C58 F5 83            [12] 1199 	mov	dph,a
      007C5A 74 01            [12] 1200 	mov	a,#0x01
      007C5C F0               [24] 1201 	movx	@dptr,a
      007C5D 0F               [12] 1202 	inc	r7
      007C5E 80 EB            [24] 1203 	sjmp	00115$
      007C60                       1204 00110$:
                                   1205 ;	quantum/action_util.c:154: } else add_key(code);
      007C60 90 0A 45         [24] 1206 	mov	dptr,#_add_owned_key_code_10000_326
      007C63 E0               [24] 1207 	movx	a,@dptr
                                   1208 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007C64 90 07 FB         [24] 1209 	mov	dptr,#_add_key_to_report_PARM_2
      007C67 F0               [24] 1210 	movx	@dptr,a
      007C68 90 0D 95         [24] 1211 	mov	dptr,#_actual_keyboard_report
      007C6B 12 6E 11         [24] 1212 	lcall	_add_key_to_report
                                   1213 ;	quantum/action_util.c:154: } else add_key(code);
      007C6E                       1214 00111$:
                                   1215 ;	quantum/action_util.c:155: return true;
      007C6E 75 82 01         [24] 1216 	mov	dpl, #0x01
                                   1217 ;	quantum/action_util.c:156: }
      007C71 22               [24] 1218 	ret
                                   1219 ;------------------------------------------------------------
                                   1220 ;Allocation info for local variables in function 'del_owned_key'
                                   1221 ;------------------------------------------------------------
                                   1222 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1223 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1224 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1225 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1226 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1227 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1228 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1229 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function del_owned_key
                                   1234 ;	-----------------------------------------
      007C72                       1235 _del_owned_key:
      007C72 E5 82            [12] 1236 	mov	a,dpl
      007C74 90 0A 46         [24] 1237 	mov	dptr,#_del_owned_key_code_10000_341
      007C77 12 7F 87         [24] 1238 	lcall	_ak820_outline_0129
                                   1239 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007C7A E4               [12] 1240 	clr	a
      007C7B F0               [24] 1241 	movx	@dptr,a
      007C7C 90 0A 30         [24] 1242 	mov	dptr,#_macro_keys
      007C7F C0 07            [24] 1243 	push	ar7
      007C81 51 1E            [12] 1244 	acall	_ak820_macro_change
      007C83 E5 82            [12] 1245 	mov	a, dpl
      007C85 D0 07            [24] 1246 	pop	ar7
      007C87 70 03            [24] 1247 	jnz	00102$
      007C89 F5 82            [12] 1248 	mov	dpl,a
      007C8B 22               [24] 1249 	ret
      007C8C                       1250 00102$:
                                   1251 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      007C8C 12 7F 41         [24] 1252 	lcall	_ak820_outline_0028
      007C8F FC               [12] 1253 	mov	r4,a
      007C90 60 07            [24] 1254 	jz	00103$
      007C92 1C               [12] 1255 	dec	r4
      007C93 12 42 F8         [24] 1256 	lcall	_ak820_outline_0064
      007C96 EC               [12] 1257 	mov	a,r4
      007C97 60 04            [24] 1258 	jz	00104$
      007C99                       1259 00103$:
      007C99 75 82 00         [24] 1260 	mov	dpl, #0x00
      007C9C 22               [24] 1261 	ret
      007C9D                       1262 00104$:
                                   1263 ;	quantum/action_util.c:160: --distinct_keys;
      007C9D 90 0A 2F         [24] 1264 	mov	dptr,#_distinct_keys
      007CA0 E0               [24] 1265 	movx	a,@dptr
      007CA1 14               [12] 1266 	dec	a
      007CA2 F0               [24] 1267 	movx	@dptr,a
                                   1268 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007CA3 90 0D 82         [24] 1269 	mov	dptr,#_keyboard_protocol
      007CA6 E0               [24] 1270 	movx	a,@dptr
      007CA7 60 16            [24] 1271 	jz	00107$
      007CA9 90 0A B4         [24] 1272 	mov	dptr,#_keymap_config
      007CAC E0               [24] 1273 	movx	a,@dptr
      007CAD 30 E7 0F         [24] 1274 	jnb	acc.7,00107$
                                   1275 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007CB0 90 07 FE         [24] 1276 	mov	dptr,#_del_key_from_report_PARM_2
      007CB3 EF               [12] 1277 	mov	a,r7
      007CB4 F0               [24] 1278 	movx	@dptr,a
      007CB5 90 0D 95         [24] 1279 	mov	dptr,#_actual_keyboard_report
      007CB8 12 6E 45         [24] 1280 	lcall	_del_key_from_report
                                   1281 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007CBB 75 82 01         [24] 1282 	mov	dpl, #0x01
      007CBE 22               [24] 1283 	ret
      007CBF                       1284 00107$:
                                   1285 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007CBF 90 0A 2F         [24] 1286 	mov	dptr,#_distinct_keys
      007CC2 E0               [24] 1287 	movx	a,@dptr
      007CC3 FF               [12] 1288 	mov  r7,a
      007CC4 24 F9            [12] 1289 	add	a,#0xff - 0x06
      007CC6 50 04            [24] 1290 	jnc	00110$
                                   1291 ;	free result
      007CC8 75 82 01         [24] 1292 	mov	dpl, #0x01
      007CCB 22               [24] 1293 	ret
      007CCC                       1294 00110$:
                                   1295 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007CCC BF 06 1F         [24] 1296 	cjne	r7,#0x06,00115$
                                   1297 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007CCF 90 0D 95         [24] 1298 	mov	dptr,#_actual_keyboard_report
      007CD2 12 6E 79         [24] 1299 	lcall	_clear_keys_from_report
                                   1300 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007CD5 7F 04            [12] 1301 	mov	r7,#0x04
      007CD7                       1302 00122$:
      007CD7 EF               [12] 1303 	mov	a,r7
      007CD8 24 5B            [12] 1304 	add	a,#0xff - 0xa4
      007CDA 40 20            [24] 1305 	jc	00116$
                                   1306 ;	free result
      007CDC 12 7F 41         [24] 1307 	lcall	_ak820_outline_0028
      007CDF 60 0A            [24] 1308 	jz	00123$
                                   1309 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007CE1 12 7F 92         [24] 1310 	lcall	_ak820_outline_0171
      007CE4 C0 07            [24] 1311 	push	ar7
      007CE6 12 6E 11         [24] 1312 	lcall	_add_key_to_report
      007CE9 D0 07            [24] 1313 	pop	ar7
                                   1314 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007CEB                       1315 00123$:
      007CEB 0F               [12] 1316 	inc	r7
      007CEC 80 E9            [24] 1317 	sjmp	00122$
      007CEE                       1318 00115$:
                                   1319 ;	quantum/action_util.c:169: } else del_key(code);
      007CEE 90 0A 46         [24] 1320 	mov	dptr,#_del_owned_key_code_10000_341
      007CF1 E0               [24] 1321 	movx	a,@dptr
                                   1322 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007CF2 90 07 FE         [24] 1323 	mov	dptr,#_del_key_from_report_PARM_2
      007CF5 F0               [24] 1324 	movx	@dptr,a
      007CF6 90 0D 95         [24] 1325 	mov	dptr,#_actual_keyboard_report
      007CF9 12 6E 45         [24] 1326 	lcall	_del_key_from_report
                                   1327 ;	quantum/action_util.c:169: } else del_key(code);
      007CFC                       1328 00116$:
                                   1329 ;	quantum/action_util.c:170: return true;
      007CFC 75 82 01         [24] 1330 	mov	dpl, #0x01
                                   1331 ;	quantum/action_util.c:171: }
      007CFF 22               [24] 1332 	ret
                                   1333 ;------------------------------------------------------------
                                   1334 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1335 ;------------------------------------------------------------
                                   1336 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1337 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1338 ;------------------------------------------------------------
                                   1339 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1340 ;	-----------------------------------------
                                   1341 ;	 function clear_owned_usages
                                   1342 ;	-----------------------------------------
      007D00                       1343 _clear_owned_usages:
                                   1344 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007D00 7F 00            [12] 1345 	mov	r7,#0x00
      007D02                       1346 00104$:
      007D02 BF 1E 00         [24] 1347 	cjne	r7,#0x1e,00141$
      007D05                       1348 00141$:
      007D05 50 14            [24] 1349 	jnc	00101$
      007D07 EF               [12] 1350 	mov	a,r7
      007D08 24 47            [12] 1351 	add	a, #_usage_refs
      007D0A FD               [12] 1352 	mov	r5,a
      007D0B E4               [12] 1353 	clr	a
      007D0C 34 0A            [12] 1354 	addc	a, #(_usage_refs >> 8)
      007D0E FE               [12] 1355 	mov	r6,a
      007D0F EF               [12] 1356 	mov	a,r7
      007D10 12 7F 56         [24] 1357 	lcall	_ak820_outline_0067
      007D13 E4               [12] 1358 	clr	a
      007D14 F0               [24] 1359 	movx	@dptr,a
      007D15 12 7F 76         [24] 1360 	lcall	_ak820_outline_0118
      007D18 0F               [12] 1361 	inc	r7
      007D19 80 E7            [24] 1362 	sjmp	00104$
      007D1B                       1363 00101$:
                                   1364 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      007D1B 90 0A 84         [24] 1365 	mov	dptr,#(_usage_lengths + 0x0001)
      007D1E E4               [12] 1366 	clr	a
      007D1F F0               [24] 1367 	movx	@dptr,a
      007D20 90 0A 83         [24] 1368 	mov	dptr,#_usage_lengths
      007D23 F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007D24 FF               [12] 1371 	mov	r7,a
      007D25                       1372 00107$:
      007D25 BF 04 00         [24] 1373 	cjne	r7,#0x04,00143$
      007D28                       1374 00143$:
      007D28 50 0D            [24] 1375 	jnc	00109$
      007D2A EF               [12] 1376 	mov	a,r7
      007D2B 24 85            [12] 1377 	add	a, #_macro_usages
      007D2D F5 82            [12] 1378 	mov	dpl,a
      007D2F E4               [12] 1379 	clr	a
      007D30 34 0A            [12] 1380 	addc	a, #(_macro_usages >> 8)
      007D32 12 7A 0F         [24] 1381 	lcall	_ak820_outline_0157
      007D35 80 EE            [24] 1382 	sjmp	00107$
      007D37                       1383 00109$:
                                   1384 ;	quantum/action_util.c:185: }
      007D37 22               [24] 1385 	ret
                                   1386 ;------------------------------------------------------------
                                   1387 ;Allocation info for local variables in function 'owned_usage_key'
                                   1388 ;------------------------------------------------------------
                                   1389 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1390 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1391 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1392 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1393 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1394 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1395 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1396 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1397 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1398 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1399 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function owned_usage_key
                                   1404 ;	-----------------------------------------
      007D38                       1405 _owned_usage_key:
      007D38 E5 82            [12] 1406 	mov	a,dpl
      007D3A 90 0A 8A         [24] 1407 	mov	dptr,#_owned_usage_key_code_10000_368
      007D3D F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      007D3E E0               [24] 1410 	movx	a,@dptr
      007D3F FF               [12] 1411 	mov	r7,a
      007D40 BF A8 00         [24] 1412 	cjne	r7,#0xa8,00244$
      007D43                       1413 00244$:
      007D43 B3               [12] 1414 	cpl	c
      007D44 92 20            [24] 1415 	mov	_owned_usage_key_sloc0_1_0,c
      007D46 E4               [12] 1416 	clr	a
      007D47 33               [12] 1417 	rlc	a
      007D48 FF               [12] 1418 	mov	r7,a
      007D49 90 0A 8D         [24] 1419 	mov	dptr,#_owned_usage_key_which_10000_369
      007D4C F0               [24] 1420 	movx	@dptr,a
                                   1421 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      007D4D EF               [12] 1422 	mov	a,r7
      007D4E 60 02            [24] 1423 	jz	00129$
      007D50 74 03            [12] 1424 	mov	a,#0x03
      007D52                       1425 00129$:
      007D52 FE               [12] 1426 	mov	r6,a
                                   1427 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      007D53 EF               [12] 1428 	mov	a,r7
      007D54 24 83            [12] 1429 	add	a, #_usage_lengths
      007D56 FD               [12] 1430 	mov	r5,a
      007D57 E4               [12] 1431 	clr	a
      007D58 34 0A            [12] 1432 	addc	a, #(_usage_lengths >> 8)
      007D5A FF               [12] 1433 	mov	r7,a
      007D5B 12 7F 9B         [24] 1434 	lcall	_ak820_outline_0183
      007D5E E0               [24] 1435 	movx	a,@dptr
      007D5F FC               [12] 1436 	mov	r4,a
                                   1437 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      007D60 90 0A 8A         [24] 1438 	mov	dptr,#_owned_usage_key_code_10000_368
      007D63 E0               [24] 1439 	movx	a,@dptr
      007D64 24 5B            [12] 1440 	add	a,#0x5b
      007D66 FB               [12] 1441 	mov	r3,a
                                   1442 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007D67 90 0A 89         [24] 1443 	mov	dptr,#_owned_usage_key_PARM_2
      007D6A E0               [24] 1444 	movx	a,@dptr
      007D6B FA               [12] 1445 	mov	r2,a
      007D6C 90 09 7E         [24] 1446 	mov	dptr,#_ak820_macro_change_PARM_2
      007D6F EB               [12] 1447 	mov	a,r3
      007D70 F0               [24] 1448 	movx	@dptr,a
      007D71 90 09 7F         [24] 1449 	mov	dptr,#_ak820_macro_change_PARM_3
      007D74 EA               [12] 1450 	mov	a,r2
      007D75 F0               [24] 1451 	movx	@dptr,a
      007D76 90 0A 85         [24] 1452 	mov	dptr,#_macro_usages
      007D79 C0 07            [24] 1453 	push	ar7
      007D7B C0 06            [24] 1454 	push	ar6
      007D7D C0 05            [24] 1455 	push	ar5
      007D7F C0 04            [24] 1456 	push	ar4
      007D81 C0 03            [24] 1457 	push	ar3
      007D83 C0 02            [24] 1458 	push	ar2
      007D85 51 1E            [12] 1459 	acall	_ak820_macro_change
      007D87 E5 82            [12] 1460 	mov	a, dpl
      007D89 D0 02            [24] 1461 	pop	ar2
      007D8B D0 03            [24] 1462 	pop	ar3
      007D8D D0 04            [24] 1463 	pop	ar4
      007D8F D0 05            [24] 1464 	pop	ar5
      007D91 D0 06            [24] 1465 	pop	ar6
      007D93 D0 07            [24] 1466 	pop	ar7
      007D95 70 01            [24] 1467 	jnz	00102$
      007D97 22               [24] 1468 	ret
      007D98                       1469 00102$:
                                   1470 ;	quantum/action_util.c:192: if (pressed) {
      007D98 EA               [12] 1471 	mov	a,r2
      007D99 60 1A            [24] 1472 	jz	00115$
                                   1473 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      007D9B 12 7F 60         [24] 1474 	lcall	_ak820_outline_0073
      007D9E 04               [12] 1475 	inc	a
      007D9F 12 6B 97         [24] 1476 	lcall	_ak820_outline_0135
      007DA2 E8               [12] 1477 	mov	a,r0
      007DA3 60 01            [24] 1478 	jz	00104$
      007DA5 22               [24] 1479 	ret
      007DA6                       1480 00104$:
                                   1481 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      007DA6 90 0A 8E         [24] 1482 	mov	dptr,#_owned_usage_key_count_10000_369
      007DA9 EC               [12] 1483 	mov	a,r4
      007DAA 04               [12] 1484 	inc	a
      007DAB F0               [24] 1485 	movx	@dptr,a
      007DAC EC               [12] 1486 	mov	a,r4
      007DAD 2E               [12] 1487 	add	a, r6
      007DAE 12 7F 56         [24] 1488 	lcall	_ak820_outline_0067
      007DB1 EB               [12] 1489 	mov	a,r3
      007DB2 F0               [24] 1490 	movx	@dptr,a
      007DB3 C1 16            [12] 1491 	ajmp	00116$
      007DB5                       1492 00115$:
                                   1493 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      007DB5 12 7F 60         [24] 1494 	lcall	_ak820_outline_0073
      007DB8 60 07            [24] 1495 	jz	00105$
      007DBA 18               [12] 1496 	dec	r0
      007DBB 12 7F 4F         [24] 1497 	lcall	_ak820_outline_0063
      007DBE E8               [12] 1498 	mov	a,r0
      007DBF 60 01            [24] 1499 	jz	00106$
      007DC1                       1500 00105$:
      007DC1 22               [24] 1501 	ret
      007DC2                       1502 00106$:
                                   1503 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      007DC2 7A 00            [12] 1504 	mov	r2,#0x00
      007DC4                       1505 00108$:
      007DC4 EA               [12] 1506 	mov	a,r2
      007DC5 2E               [12] 1507 	add	a, r6
      007DC6 12 7F 56         [24] 1508 	lcall	_ak820_outline_0067
      007DC9 E0               [24] 1509 	movx	a,@dptr
      007DCA B5 03 02         [24] 1510 	cjne	a,ar3,00251$
      007DCD 80 03            [24] 1511 	sjmp	00167$
      007DCF                       1512 00251$:
      007DCF 0A               [12] 1513 	inc	r2
      007DD0 80 F2            [24] 1514 	sjmp	00108$
      007DD2                       1515 00167$:
      007DD2 90 0A 8F         [24] 1516 	mov	dptr,#_owned_usage_key_pos_30001_376
      007DD5 EA               [12] 1517 	mov	a,r2
      007DD6 F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	quantum/action_util.c:199: --count;
      007DD7 1C               [12] 1520 	dec	r4
      007DD8 90 0A 8E         [24] 1521 	mov	dptr,#_owned_usage_key_count_10000_369
      007DDB EC               [12] 1522 	mov	a,r4
      007DDC F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007DDD 8A 03            [24] 1525 	mov	ar3,r2
      007DDF                       1526 00125$:
      007DDF C3               [12] 1527 	clr	c
      007DE0 EB               [12] 1528 	mov	a,r3
      007DE1 9C               [12] 1529 	subb	a,r4
      007DE2 50 23            [24] 1530 	jnc	00111$
      007DE4 C0 05            [24] 1531 	push	ar5
      007DE6 C0 07            [24] 1532 	push	ar7
      007DE8 EB               [12] 1533 	mov	a,r3
      007DE9 2E               [12] 1534 	add	a, r6
      007DEA FA               [12] 1535 	mov	r2,a
      007DEB 24 65            [12] 1536 	add	a, #_usage_order
      007DED F8               [12] 1537 	mov	r0,a
      007DEE E4               [12] 1538 	clr	a
      007DEF 34 0A            [12] 1539 	addc	a, #(_usage_order >> 8)
      007DF1 F9               [12] 1540 	mov	r1,a
      007DF2 0A               [12] 1541 	inc	r2
      007DF3 EA               [12] 1542 	mov	a,r2
      007DF4 33               [12] 1543 	rlc	a
      007DF5 95 E0            [12] 1544 	subb	a,acc
      007DF7 FF               [12] 1545 	mov	r7,a
      007DF8 EA               [12] 1546 	mov	a,r2
      007DF9 12 7F 7C         [24] 1547 	lcall	_ak820_outline_0123
      007DFC 12 38 67         [24] 1548 	lcall	_ak820_outline_0151
      007DFF F0               [24] 1549 	movx	@dptr,a
      007E00 0B               [12] 1550 	inc	r3
      007E01 D0 07            [24] 1551 	pop	ar7
      007E03 D0 05            [24] 1552 	pop	ar5
      007E05 80 D8            [24] 1553 	sjmp	00125$
      007E07                       1554 00111$:
                                   1555 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      007E07 12 7F 9B         [24] 1556 	lcall	_ak820_outline_0183
      007E0A EC               [12] 1557 	mov	a,r4
      007E0B F0               [24] 1558 	movx	@dptr,a
                                   1559 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      007E0C 90 0A 8F         [24] 1560 	mov	dptr,#_owned_usage_key_pos_30001_376
      007E0F E0               [24] 1561 	movx	a,@dptr
      007E10 B5 04 02         [24] 1562 	cjne	a,ar4,00253$
      007E13 80 01            [24] 1563 	sjmp	00116$
      007E15                       1564 00253$:
      007E15 22               [24] 1565 	ret
      007E16                       1566 00116$:
                                   1567 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      007E16 90 0A 8E         [24] 1568 	mov	dptr,#_owned_usage_key_count_10000_369
      007E19 E0               [24] 1569 	movx	a,@dptr
      007E1A FC               [12] 1570 	mov	r4,a
      007E1B 12 7F 9B         [24] 1571 	lcall	_ak820_outline_0183
      007E1E F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007E1F EC               [12] 1574 	mov	a,r4
      007E20 60 15            [24] 1575 	jz	00131$
      007E22 EC               [12] 1576 	mov	a,r4
      007E23 2E               [12] 1577 	add	a, r6
      007E24 FE               [12] 1578 	mov	r6,a
      007E25 1E               [12] 1579 	dec	r6
      007E26 EE               [12] 1580 	mov	a,r6
      007E27 33               [12] 1581 	rlc	a
      007E28 95 E0            [12] 1582 	subb	a,acc
      007E2A FF               [12] 1583 	mov	r7,a
      007E2B EE               [12] 1584 	mov	a,r6
      007E2C 12 7F 7C         [24] 1585 	lcall	_ak820_outline_0123
      007E2F 24 A5            [12] 1586 	add	a,#0xa5
      007E31 FE               [12] 1587 	mov	r6,a
      007E32 33               [12] 1588 	rlc	a
      007E33 95 E0            [12] 1589 	subb	a,acc
      007E35 80 02            [24] 1590 	sjmp	00132$
      007E37                       1591 00131$:
      007E37 7E 00            [12] 1592 	mov	r6,#0x00
      007E39                       1593 00132$:
      007E39 90 0A 8A         [24] 1594 	mov	dptr,#_owned_usage_key_code_10000_368
      007E3C EE               [12] 1595 	mov	a,r6
      007E3D F0               [24] 1596 	movx	@dptr,a
                                   1597 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007E3E 90 0A 8D         [24] 1598 	mov	dptr,#_owned_usage_key_which_10000_369
      007E41 E0               [24] 1599 	movx	a,@dptr
      007E42 60 18            [24] 1600 	jz	00118$
      007E44 EE               [12] 1601 	mov	a,r6
      007E45 60 0B            [24] 1602 	jz	00133$
      007E47 8E 82            [24] 1603 	mov	dpl, r6
      007E49 12 6C CE         [24] 1604 	lcall	_KEYCODE2CONSUMER
      007E4C AD 82            [24] 1605 	mov	r5, dpl
      007E4E AF 83            [24] 1606 	mov	r7, dph
      007E50 80 04            [24] 1607 	sjmp	00134$
      007E52                       1608 00133$:
      007E52 7D 00            [12] 1609 	mov	r5,#0x00
      007E54 7F 00            [12] 1610 	mov	r7,#0x00
      007E56                       1611 00134$:
      007E56 12 7F 9B         [24] 1612 	lcall	_ak820_outline_0183
      007E59 02 6C 89         [24] 1613 	ljmp	_host_consumer_send
      007E5C                       1614 00118$:
                                   1615 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007E5C EE               [12] 1616 	mov	a,r6
      007E5D 60 22            [24] 1617 	jz	00135$
                                   1618 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007E5F BE A5 00         [24] 1619 	cjne	r6,#0xa5,00258$
      007E62                       1620 00258$:
      007E62 40 05            [24] 1621 	jc	00121$
      007E64 EE               [12] 1622 	mov	a,r6
      007E65 24 58            [12] 1623 	add	a,#0xff - 0xa7
      007E67 50 08            [24] 1624 	jnc	00122$
                                   1625 ;	free result
      007E69                       1626 00121$:
      007E69 90 0A 8B         [24] 1627 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007E6C 12 4E CE         [24] 1628 	lcall	_ak820_outline_0165
      007E6F 80 09            [24] 1629 	sjmp	00123$
      007E71                       1630 00122$:
                                   1631 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007E71 74 DC            [12] 1632 	mov	a,#0xdc
      007E73 2E               [12] 1633 	add	a, r6
      007E74 90 0A 8B         [24] 1634 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007E77 12 38 57         [24] 1635 	lcall	_ak820_outline_0122
                                   1636 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007E7A                       1637 00123$:
      007E7A 90 0A 8B         [24] 1638 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007E7D E0               [24] 1639 	movx	a,@dptr
      007E7E FF               [12] 1640 	mov	r7,a
      007E7F 80 02            [24] 1641 	sjmp	00136$
      007E81                       1642 00135$:
      007E81 7F 00            [12] 1643 	mov	r7,#0x00
      007E83                       1644 00136$:
      007E83 7E 00            [12] 1645 	mov	r6,#0x00
      007E85 12 43 3D         [24] 1646 	lcall	_ak820_outline_0152
                                   1647 ;	quantum/action_util.c:208: }
      007E88 02 6C 5A         [24] 1648 	ljmp	_host_system_send
                                   1649 ;------------------------------------------------------------
                                   1650 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1651 ;------------------------------------------------------------
                                   1652 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1653 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1654 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1655 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1656 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1657 ;------------------------------------------------------------
                                   1658 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1659 ;	-----------------------------------------
                                   1660 ;	 function send_keyboard_report
                                   1661 ;	-----------------------------------------
      007E8B                       1662 _send_keyboard_report:
                                   1663 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      007E8B 90 0D 93         [24] 1664 	mov	dptr,#_real_mods
      007E8E E0               [24] 1665 	movx	a,@dptr
      007E8F FF               [12] 1666 	mov	r7,a
      007E90 90 0D 95         [24] 1667 	mov	dptr,#_actual_keyboard_report
      007E93 F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      007E94 90 0D 94         [24] 1670 	mov	dptr,#_weak_mods
      007E97 E0               [24] 1671 	movx	a,@dptr
      007E98 42 07            [12] 1672 	orl	ar7,a
      007E9A 90 0D 95         [24] 1673 	mov	dptr,#_actual_keyboard_report
      007E9D EF               [12] 1674 	mov	a,r7
      007E9E F0               [24] 1675 	movx	@dptr,a
                                   1676 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      007E9F 90 09 79         [24] 1677 	mov	dptr,#_owned_weak_mods
      007EA2 E0               [24] 1678 	movx	a,@dptr
      007EA3 FE               [12] 1679 	mov	r6,a
      007EA4 90 09 78         [24] 1680 	mov	dptr,#_owned_mods
      007EA7 E0               [24] 1681 	movx	a,@dptr
      007EA8 4E               [12] 1682 	orl	a,r6
      007EA9 42 07            [12] 1683 	orl	ar7,a
      007EAB 90 0D 95         [24] 1684 	mov	dptr,#_actual_keyboard_report
      007EAE EF               [12] 1685 	mov	a,r7
      007EAF F0               [24] 1686 	movx	@dptr,a
                                   1687 ;	quantum/action_util.c:515: bool changed = false;
      007EB0 90 0A B1         [24] 1688 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007EB3 E4               [12] 1689 	clr	a
      007EB4 F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:517: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1692 ;	quantum/action_util.c:518: const uint8_t __xdata *src = (const uint8_t __xdata *)AK820_REPORT_OUT;
                                   1693 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007EB5 FF               [12] 1694 	mov	r7,a
      007EB6                       1695 00107$:
      007EB6 BF 20 00         [24] 1696 	cjne	r7,#0x20,00140$
      007EB9                       1697 00140$:
      007EB9 50 2B            [24] 1698 	jnc	00103$
                                   1699 ;	quantum/action_util.c:524: if (dest[i] != src[i]) {
      007EBB EF               [12] 1700 	mov	a,r7
      007EBC 24 91            [12] 1701 	add	a, #_send_keyboard_report_last_report_10001_388
      007EBE FD               [12] 1702 	mov	r5,a
      007EBF E4               [12] 1703 	clr	a
      007EC0 34 0A            [12] 1704 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      007EC2 FE               [12] 1705 	mov	r6,a
      007EC3 12 48 35         [24] 1706 	lcall	_ak820_outline_0074
      007EC6 EF               [12] 1707 	mov	a,r7
      007EC7 24 95            [12] 1708 	add	a, #_actual_keyboard_report
      007EC9 F5 82            [12] 1709 	mov	dpl,a
      007ECB E4               [12] 1710 	clr	a
      007ECC 34 0D            [12] 1711 	addc	a, #(_actual_keyboard_report >> 8)
      007ECE F5 83            [12] 1712 	mov	dph,a
      007ED0 E0               [24] 1713 	movx	a,@dptr
      007ED1 FB               [12] 1714 	mov	r3,a
      007ED2 EC               [12] 1715 	mov	a,r4
      007ED3 B5 03 02         [24] 1716 	cjne	a,ar3,00142$
      007ED6 80 0B            [24] 1717 	sjmp	00108$
      007ED8                       1718 00142$:
                                   1719 ;	quantum/action_util.c:525: dest[i] = src[i];
      007ED8 12 38 5C         [24] 1720 	lcall	_ak820_outline_0131
      007EDB EB               [12] 1721 	mov	a,r3
      007EDC F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	quantum/action_util.c:526: changed = true;
      007EDD 90 0A B1         [24] 1724 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007EE0 74 01            [12] 1725 	mov	a,#0x01
      007EE2 F0               [24] 1726 	movx	@dptr,a
      007EE3                       1727 00108$:
                                   1728 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007EE3 0F               [12] 1729 	inc	r7
      007EE4 80 D0            [24] 1730 	sjmp	00107$
      007EE6                       1731 00103$:
                                   1732 ;	quantum/action_util.c:529: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      007EE6 90 0A B1         [24] 1733 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007EE9 E0               [24] 1734 	movx	a,@dptr
      007EEA 60 09            [24] 1735 	jz	00109$
      007EEC 90 0D 95         [24] 1736 	mov	dptr,#_actual_keyboard_report
      007EEF 75 F0 00         [24] 1737 	mov	b, #0x00
                                   1738 ;	quantum/action_util.c:538: }
      007EF2 02 6B CF         [24] 1739 	ljmp	_host_keyboard_send
      007EF5                       1740 00109$:
      007EF5 22               [24] 1741 	ret
                                   1742 ;------------------------------------------------------------
                                   1743 ;Allocation info for local variables in function 'get_mods'
                                   1744 ;------------------------------------------------------------
                                   1745 ;	quantum/action_util.c:544: uint8_t get_mods(void) {
                                   1746 ;	-----------------------------------------
                                   1747 ;	 function get_mods
                                   1748 ;	-----------------------------------------
      007EF6                       1749 _get_mods:
      007EF6 C0 07            [24] 1750 	push	ar7
                                   1751 ;	quantum/action_util.c:549: ;
      007EF8 90 09 78         [24] 1752 	mov	dptr,#_owned_mods
      007EFB E0               [24] 1753 	movx	a,@dptr
      007EFC FF               [12] 1754 	mov	r7,a
      007EFD 90 0D 93         [24] 1755 	mov	dptr,#_real_mods
      007F00 12 7A 09         [24] 1756 	lcall	_ak820_outline_0137
                                   1757 ;	quantum/action_util.c:550: }
      007F03 D0 07            [24] 1758 	pop	ar7
      007F05 22               [24] 1759 	ret
                                   1760 ;------------------------------------------------------------
                                   1761 ;Allocation info for local variables in function 'add_mods'
                                   1762 ;------------------------------------------------------------
                                   1763 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1764 ;------------------------------------------------------------
                                   1765 ;	quantum/action_util.c:555: void add_mods(uint8_t mods) {
                                   1766 ;	-----------------------------------------
                                   1767 ;	 function clear_mods
                                   1768 ;	-----------------------------------------
      007F06                       1769 _clear_mods:
                                   1770 ;	quantum/action_util.c:577: real_mods = 0;
      007F06 90 0D 93         [24] 1771 	mov	dptr,#_real_mods
      007F09 E4               [12] 1772 	clr	a
      007F0A F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	quantum/action_util.c:578: }
      007F0B 22               [24] 1775 	ret
                                   1776 ;------------------------------------------------------------
                                   1777 ;Allocation info for local variables in function 'get_weak_mods'
                                   1778 ;------------------------------------------------------------
                                   1779 ;	quantum/action_util.c:584: uint8_t get_weak_mods(void) {
                                   1780 ;	-----------------------------------------
                                   1781 ;	 function get_weak_mods
                                   1782 ;	-----------------------------------------
      007F0C                       1783 _get_weak_mods:
      007F0C C0 07            [24] 1784 	push	ar7
                                   1785 ;	quantum/action_util.c:589: ;
      007F0E 90 09 79         [24] 1786 	mov	dptr,#_owned_weak_mods
      007F11 E0               [24] 1787 	movx	a,@dptr
      007F12 FF               [12] 1788 	mov	r7,a
      007F13 90 0D 94         [24] 1789 	mov	dptr,#_weak_mods
      007F16 12 7A 09         [24] 1790 	lcall	_ak820_outline_0137
                                   1791 ;	quantum/action_util.c:590: }
      007F19 D0 07            [24] 1792 	pop	ar7
      007F1B 22               [24] 1793 	ret
                                   1794 ;------------------------------------------------------------
                                   1795 ;Allocation info for local variables in function 'add_weak_mods'
                                   1796 ;------------------------------------------------------------
                                   1797 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action_util.c:595: void add_weak_mods(uint8_t mods) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function add_weak_mods
                                   1802 ;	-----------------------------------------
      007F1C                       1803 _add_weak_mods:
      007F1C E5 82            [12] 1804 	mov	a,dpl
      007F1E 90 0A B2         [24] 1805 	mov	dptr,#_add_weak_mods_mods_10000_406
      007F21 F0               [24] 1806 	movx	@dptr,a
                                   1807 ;	quantum/action_util.c:596: weak_mods |= mods;
      007F22 E0               [24] 1808 	movx	a,@dptr
      007F23 FF               [12] 1809 	mov	r7,a
      007F24 90 0D 94         [24] 1810 	mov	dptr,#_weak_mods
      007F27 E0               [24] 1811 	movx	a,@dptr
      007F28 4F               [12] 1812 	orl	a,r7
      007F29 F0               [24] 1813 	movx	@dptr,a
                                   1814 ;	quantum/action_util.c:597: }
      007F2A 22               [24] 1815 	ret
                                   1816 ;------------------------------------------------------------
                                   1817 ;Allocation info for local variables in function 'del_weak_mods'
                                   1818 ;------------------------------------------------------------
                                   1819 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1820 ;------------------------------------------------------------
                                   1821 ;	quantum/action_util.c:602: void del_weak_mods(uint8_t mods) {
                                   1822 ;	-----------------------------------------
                                   1823 ;	 function del_weak_mods
                                   1824 ;	-----------------------------------------
      007F2B                       1825 _del_weak_mods:
      007F2B E5 82            [12] 1826 	mov	a,dpl
      007F2D 90 0A B3         [24] 1827 	mov	dptr,#_del_weak_mods_mods_10000_408
      007F30 F0               [24] 1828 	movx	@dptr,a
                                   1829 ;	quantum/action_util.c:603: weak_mods &= ~mods;
      007F31 E0               [24] 1830 	movx	a,@dptr
      007F32 F4               [12] 1831 	cpl	a
      007F33 FF               [12] 1832 	mov	r7,a
      007F34 90 0D 94         [24] 1833 	mov	dptr,#_weak_mods
      007F37 E0               [24] 1834 	movx	a,@dptr
      007F38 5F               [12] 1835 	anl	a,r7
      007F39 F0               [24] 1836 	movx	@dptr,a
                                   1837 ;	quantum/action_util.c:604: }
      007F3A 22               [24] 1838 	ret
                                   1839 ;------------------------------------------------------------
                                   1840 ;Allocation info for local variables in function 'set_weak_mods'
                                   1841 ;------------------------------------------------------------
                                   1842 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1843 ;------------------------------------------------------------
                                   1844 ;	quantum/action_util.c:609: void set_weak_mods(uint8_t mods) {
                                   1845 ;	-----------------------------------------
                                   1846 ;	 function clear_weak_mods
                                   1847 ;	-----------------------------------------
      007F3B                       1848 _clear_weak_mods:
                                   1849 ;	quantum/action_util.c:617: weak_mods = 0;
      007F3B 90 0D 94         [24] 1850 	mov	dptr,#_weak_mods
      007F3E E4               [12] 1851 	clr	a
      007F3F F0               [24] 1852 	movx	@dptr,a
                                   1853 ;	quantum/action_util.c:618: }
      007F40 22               [24] 1854 	ret
                                   1855 ;------------------------------------------------------------
                                   1856 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1857 ;------------------------------------------------------------
                                   1858 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1859 ;------------------------------------------------------------
                                   1860 ;	quantum/action_util.c:700: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1861 ;	-----------------------------------------
                                   1862 	.area CSEG    (CODE)
                                   1863 	.area CONST   (CODE)
                                   1864 	.area XINIT   (CODE)
      00BDC0                       1865 __xinit__real_mods:
      00BDC0 00                    1866 	.db #0x00	; 0
      00BDC1                       1867 __xinit__weak_mods:
      00BDC1 00                    1868 	.db #0x00	; 0
      00BDC2                       1869 __xinit__actual_keyboard_report:
      00BDC2 00                    1870 	.db #0x00	; 0
      00BDC3 00                    1871 	.db #0x00	; 0
      00BDC4 00                    1872 	.db #0x00	; 0
      00BDC5 00                    1873 	.db #0x00	; 0
      00BDC6 00                    1874 	.db #0x00	; 0
      00BDC7 00                    1875 	.db #0x00	; 0
      00BDC8 00                    1876 	.db #0x00	; 0
      00BDC9 00                    1877 	.db #0x00	; 0
      00BDCA 00                    1878 	.db 0x00
      00BDCB 00                    1879 	.db 0x00
      00BDCC 00                    1880 	.db 0x00
      00BDCD 00                    1881 	.db 0x00
      00BDCE 00                    1882 	.db 0x00
      00BDCF 00                    1883 	.db 0x00
      00BDD0 00                    1884 	.db 0x00
      00BDD1 00                    1885 	.db 0x00
      00BDD2 00                    1886 	.db 0x00
      00BDD3 00                    1887 	.db 0x00
      00BDD4 00                    1888 	.db 0x00
      00BDD5 00                    1889 	.db 0x00
      00BDD6 00                    1890 	.db 0x00
      00BDD7 00                    1891 	.db 0x00
      00BDD8 00                    1892 	.db 0x00
      00BDD9 00                    1893 	.db 0x00
      00BDDA 00                    1894 	.db 0x00
      00BDDB 00                    1895 	.db 0x00
      00BDDC 00                    1896 	.db 0x00
      00BDDD 00                    1897 	.db 0x00
      00BDDE 00                    1898 	.db 0x00
      00BDDF 00                    1899 	.db 0x00
      00BDE0 00                    1900 	.db 0x00
      00BDE1 00                    1901 	.db 0x00
                                   1902 	.area CABS    (ABS,CODE)
                                   1903 
                                   1904 ; Experimental exact instruction outlining.
                                   1905 	.globl _ak820_outline_0013
                                   1906 	.globl _ak820_outline_0028
                                   1907 	.globl _ak820_outline_0055
                                   1908 	.globl _ak820_outline_0059
                                   1909 	.globl _ak820_outline_0062
                                   1910 	.globl _ak820_outline_0063
                                   1911 	.globl _ak820_outline_0064
                                   1912 	.globl _ak820_outline_0067
                                   1913 	.globl _ak820_outline_0073
                                   1914 	.globl _ak820_outline_0074
                                   1915 	.globl _ak820_outline_0103
                                   1916 	.globl _ak820_outline_0104
                                   1917 	.globl _ak820_outline_0113
                                   1918 	.globl _ak820_outline_0118
                                   1919 	.globl _ak820_outline_0121
                                   1920 	.globl _ak820_outline_0122
                                   1921 	.globl _ak820_outline_0123
                                   1922 	.globl _ak820_outline_0129
                                   1923 	.globl _ak820_outline_0131
                                   1924 	.globl _ak820_outline_0135
                                   1925 	.globl _ak820_outline_0137
                                   1926 	.globl _ak820_outline_0151
                                   1927 	.globl _ak820_outline_0152
                                   1928 	.globl _ak820_outline_0157
                                   1929 	.globl _ak820_outline_0165
                                   1930 	.globl _ak820_outline_0171
                                   1931 	.globl _ak820_outline_0182
                                   1932 	.globl _ak820_outline_0183
                                   1933 
                                   1934 	.area CSEG (CODE)
                                   1935 ; function ak820_outline_0028
      007F41                       1936 _ak820_outline_0028:
      007F41 EF               [12] 1937 	mov	a,r7
      007F42 24 8A            [12] 1938 	add	a,#_key_refs
      007F44 FD               [12] 1939 	mov	r5,a
      007F45 E4               [12] 1940 	clr	a
      007F46 34 09            [12] 1941 	addc	a,#(_key_refs>>8)
      007F48 FE               [12] 1942 	mov	r6,a
      007F49 8D 82            [24] 1943 	mov	dpl,r5
      007F4B 8E 83            [24] 1944 	mov	dph,r6
      007F4D E0               [24] 1945 	movx	a,@dptr
      007F4E 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0063
      007F4F                       1950 _ak820_outline_0063:
      007F4F 89 82            [24] 1951 	mov	dpl,r1
      007F51 8A 83            [24] 1952 	mov	dph,r2
      007F53 E8               [12] 1953 	mov	a,r0
      007F54 F0               [24] 1954 	movx	@dptr,a
      007F55 22               [24] 1955 	ret
                                   1956 
                                   1957 	.area CSEG (CODE)
                                   1958 ; function ak820_outline_0067
      007F56                       1959 _ak820_outline_0067:
      007F56 24 65            [12] 1960 	add	a,#_usage_order
      007F58 F5 82            [12] 1961 	mov	dpl,a
      007F5A E4               [12] 1962 	clr	a
      007F5B 34 0A            [12] 1963 	addc	a,#(_usage_order>>8)
      007F5D F5 83            [12] 1964 	mov	dph,a
      007F5F 22               [24] 1965 	ret
                                   1966 
                                   1967 	.area CSEG (CODE)
                                   1968 ; function ak820_outline_0073
      007F60                       1969 _ak820_outline_0073:
      007F60 EB               [12] 1970 	mov	a,r3
      007F61 24 47            [12] 1971 	add	a,#_usage_refs
      007F63 F9               [12] 1972 	mov	r1,a
      007F64 E4               [12] 1973 	clr	a
      007F65 34 0A            [12] 1974 	addc	a,#(_usage_refs>>8)
      007F67 FA               [12] 1975 	mov	r2,a
      007F68 89 82            [24] 1976 	mov	dpl,r1
      007F6A 8A 83            [24] 1977 	mov	dph,r2
      007F6C E0               [24] 1978 	movx	a,@dptr
      007F6D F8               [12] 1979 	mov	r0,a
      007F6E 22               [24] 1980 	ret
                                   1981 
                                   1982 	.area CSEG (CODE)
                                   1983 ; function ak820_outline_0113
      007F6F                       1984 _ak820_outline_0113:
      007F6F F0               [24] 1985 	movx	@dptr,a
      007F70 E0               [24] 1986 	movx	a,@dptr
      007F71 FF               [12] 1987 	mov	r7,a
      007F72 90 09 82         [24] 1988 	mov	dptr,#_change_owned_PARM_2
      007F75 22               [24] 1989 	ret
                                   1990 
                                   1991 	.area CSEG (CODE)
                                   1992 ; function ak820_outline_0118
      007F76                       1993 _ak820_outline_0118:
      007F76 8D 82            [24] 1994 	mov	dpl,r5
      007F78 8E 83            [24] 1995 	mov	dph,r6
      007F7A F0               [24] 1996 	movx	@dptr,a
      007F7B 22               [24] 1997 	ret
                                   1998 
                                   1999 	.area CSEG (CODE)
                                   2000 ; function ak820_outline_0123
      007F7C                       2001 _ak820_outline_0123:
      007F7C 24 65            [12] 2002 	add	a,#_usage_order
      007F7E F5 82            [12] 2003 	mov	dpl,a
      007F80 EF               [12] 2004 	mov	a,r7
      007F81 34 0A            [12] 2005 	addc	a,#(_usage_order>>8)
      007F83 F5 83            [12] 2006 	mov	dph,a
      007F85 E0               [24] 2007 	movx	a,@dptr
      007F86 22               [24] 2008 	ret
                                   2009 
                                   2010 	.area CSEG (CODE)
                                   2011 ; function ak820_outline_0129
      007F87                       2012 _ak820_outline_0129:
      007F87 F0               [24] 2013 	movx	@dptr,a
      007F88 E0               [24] 2014 	movx	a,@dptr
      007F89 FF               [12] 2015 	mov	r7,a
      007F8A 90 09 7E         [24] 2016 	mov	dptr,#_ak820_macro_change_PARM_2
      007F8D F0               [24] 2017 	movx	@dptr,a
      007F8E 90 09 7F         [24] 2018 	mov	dptr,#_ak820_macro_change_PARM_3
      007F91 22               [24] 2019 	ret
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0171
      007F92                       2023 _ak820_outline_0171:
      007F92 90 07 FB         [24] 2024 	mov	dptr,#_add_key_to_report_PARM_2
      007F95 EF               [12] 2025 	mov	a,r7
      007F96 F0               [24] 2026 	movx	@dptr,a
      007F97 90 0D 95         [24] 2027 	mov	dptr,#_actual_keyboard_report
      007F9A 22               [24] 2028 	ret
                                   2029 
                                   2030 	.area CSEG (CODE)
                                   2031 ; function ak820_outline_0183
      007F9B                       2032 _ak820_outline_0183:
      007F9B 8D 82            [24] 2033 	mov	dpl,r5
      007F9D 8F 83            [24] 2034 	mov	dph,r7
      007F9F 22               [24] 2035 	ret
