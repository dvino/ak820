                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         53 bits:
      000025                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000519                        109 _page_data:
      000519                        110 	.ds 64
      000559                        111 _cached_page:
      000559                        112 	.ds 1
      00055A                        113 _batch_depth:
      00055A                        114 	.ds 1
      00055B                        115 _first_failure_stage:
      00055B                        116 	.ds 1
      00055C                        117 _nvm_fail_stage_10000_20:
      00055C                        118 	.ds 1
      00055D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055D                        120 	.ds 2
      00055F                        121 _crc_byte_PARM_2:
      00055F                        122 	.ds 1
      000560                        123 _crc_byte_crc_10000_25:
      000560                        124 	.ds 2
      000562                        125 _page_crc_crc_10000_30:
      000562                        126 	.ds 2
      000564                        127 _write_page_address_10000_32:
      000564                        128 	.ds 2
      000566                        129 _journal_header_valid_header_10000_39:
      000566                        130 	.ds 2
      000568                        131 _recover_journal_header_10000_46:
      000568                        132 	.ds 9
      000571                        133 _ak820_nvm_flush_header_10000_62:
      000571                        134 	.ds 9
      00057A                        135 _ak820_nvm_flush_stage_10000_62:
      00057A                        136 	.ds 1
      00057B                        137 _load_page_page_10000_87:
      00057B                        138 	.ds 1
      00057C                        139 _read_offset_offset_10000_93:
      00057C                        140 	.ds 2
      00057E                        141 _eeprom_read_byte_addr_10000_97:
      00057E                        142 	.ds 3
      000581                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000584                        146 	.ds 2
      000586                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000586                        148 	.ds 2
      000588                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000588                        150 	.ds 2
      00058A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058A                        152 	.ds 3
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058D                        154 	.ds 2
      00058F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058F                        156 	.ds 2
      000591                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000591                        158 	.ds 3
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000594                        160 	.ds 2
      000596                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000596                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B3F                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B3F E5 82            [12]  215 	mov	a,dpl
      003B41 90 05 5C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B44 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B45 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003B48 90 05 5C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B4B E0               [24]  221 	movx	a,@dptr
      003B4C 90 05 5B         [24]  222 	mov	dptr,#_first_failure_stage
      003B4F F0               [24]  223 	movx	@dptr,a
      003B50                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B50 D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B52 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B53                        239 _ak820_nvm_diagnostic:
      003B53 12 38 3B         [24]  240 	lcall	_ak820_outline_0103
      003B56 90 05 5D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B59 12 38 40         [24]  242 	lcall	_ak820_outline_0104
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003B5C 90 05 5D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B5F 12 37 F8         [24]  245 	lcall	_ak820_outline_0050
      003B62 A2 09            [12]  246 	mov	c,_storage_failed
      003B64 E4               [12]  247 	clr	a
      003B65 33               [12]  248 	rlc	a
      003B66 12 43 17         [24]  249 	lcall	_ak820_outline_0116
      003B69 12 42 F2         [24]  250 	lcall	_ak820_outline_0060
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003B6C A3               [24]  252 	inc	dptr
      003B6D A2 07            [12]  253 	mov	c,_page_valid
      003B6F E4               [12]  254 	clr	a
      003B70 33               [12]  255 	rlc	a
      003B71 12 42 C6         [24]  256 	lcall	_ak820_outline_0029
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003B74 A2 08            [12]  258 	mov	c,_page_dirty
      003B76 E4               [12]  259 	clr	a
      003B77 33               [12]  260 	rlc	a
      003B78 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003B79 74 03            [12]  263 	mov	a,#0x03
      003B7B 12 43 42         [24]  264 	lcall	_ak820_outline_0155
      003B7E 90 05 5A         [24]  265 	mov	dptr,#_batch_depth
      003B81 E0               [24]  266 	movx	a,@dptr
      003B82 12 38 4C         [24]  267 	lcall	_ak820_outline_0117
      003B85 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003B86 74 04            [12]  270 	mov	a,#0x04
      003B88 12 43 42         [24]  271 	lcall	_ak820_outline_0155
      003B8B 90 05 59         [24]  272 	mov	dptr,#_cached_page
      003B8E E0               [24]  273 	movx	a,@dptr
      003B8F 12 38 4C         [24]  274 	lcall	_ak820_outline_0117
      003B92 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003B93 12 42 BC         [24]  277 	lcall	_ak820_outline_0010
      003B96 E4               [12]  278 	clr	a
      003B97 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003B98 74 06            [12]  281 	mov	a,#0x06
      003B9A 12 43 27         [24]  282 	lcall	_ak820_outline_0133
      003B9D 90 05 5B         [24]  283 	mov	dptr,#_first_failure_stage
      003BA0 E0               [24]  284 	movx	a,@dptr
      003BA1 12 43 17         [24]  285 	lcall	_ak820_outline_0116
      003BA4 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BA5 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003BA6                        300 _crc_byte:
      003BA6 12 38 3B         [24]  301 	lcall	_ak820_outline_0103
      003BA9 90 05 60         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003BAC 12 38 40         [24]  303 	lcall	_ak820_outline_0104
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BAF 90 05 5F         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003BB2 E0               [24]  306 	movx	a,@dptr
      003BB3 FF               [12]  307 	mov	r7,a
      003BB4 7E 00            [12]  308 	mov	r6,#0x00
      003BB6 90 05 60         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003BB9 E0               [24]  310 	movx	a,@dptr
      003BBA 6E               [12]  311 	xrl	a,r6
      003BBB F0               [24]  312 	movx	@dptr,a
      003BBC A3               [24]  313 	inc	dptr
      003BBD E0               [24]  314 	movx	a,@dptr
      003BBE 6F               [12]  315 	xrl	a,r7
      003BBF F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BC0 7F 00            [12]  318 	mov	r7,#0x00
      003BC2                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003BC2 90 05 60         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003BC5 12 43 05         [24]  322 	lcall	_ak820_outline_0092
      003BC8 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003BCB ED               [12]  324 	mov	a,r5
      003BCC 2D               [12]  325 	add	a,r5
      003BCD FB               [12]  326 	mov	r3,a
      003BCE EE               [12]  327 	mov	a,r6
      003BCF 33               [12]  328 	rlc	a
      003BD0 FC               [12]  329 	mov	r4,a
      003BD1 63 03 21         [24]  330 	xrl	ar3,#0x21
      003BD4 63 04 10         [24]  331 	xrl	ar4,#0x10
      003BD7 80 06            [24]  332 	sjmp	00107$
      003BD9                        333 00106$:
      003BD9 ED               [12]  334 	mov	a,r5
      003BDA 2D               [12]  335 	add	a,r5
      003BDB FB               [12]  336 	mov	r3,a
      003BDC EE               [12]  337 	mov	a,r6
      003BDD 33               [12]  338 	rlc	a
      003BDE FC               [12]  339 	mov	r4,a
      003BDF                        340 00107$:
      003BDF 90 05 60         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003BE2 12 38 23         [24]  342 	lcall	_ak820_outline_0076
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BE5 0F               [12]  344 	inc	r7
      003BE6 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003BE9 12 33 FC         [24]  347 	lcall	_ak820_outline_0121
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003BEC 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003BED                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003BED 90 05 62         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003BF0 74 FF            [12]  363 	mov	a,#0xff
      003BF2 F0               [24]  364 	movx	@dptr,a
      003BF3 A3               [24]  365 	inc	dptr
      003BF4 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003BF5 7F 00            [12]  368 	mov	r7,#0x00
      003BF7                        369 00102$:
      003BF7 90 05 62         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003BFA 12 43 05         [24]  371 	lcall	_ak820_outline_0092
      003BFD 12 43 0B         [24]  372 	lcall	_ak820_outline_0101
      003C00 90 05 5F         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003C03 F0               [24]  374 	movx	@dptr,a
      003C04 12 38 5C         [24]  375 	lcall	_ak820_outline_0131
      003C07 C0 07            [24]  376 	push	ar7
      003C09 12 3B A6         [24]  377 	lcall	_crc_byte
      003C0C AD 82            [24]  378 	mov	r5, dpl
      003C0E AE 83            [24]  379 	mov	r6, dph
      003C10 D0 07            [24]  380 	pop	ar7
      003C12 90 05 62         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003C15 12 43 48         [24]  382 	lcall	_ak820_outline_0156
      003C18 0F               [12]  383 	inc	r7
      003C19 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C1C 12 38 5C         [24]  386 	lcall	_ak820_outline_0131
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C1F 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003C20                        399 _write_page:
      003C20 12 38 3B         [24]  400 	lcall	_ak820_outline_0103
      003C23 90 05 64         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003C26 12 38 40         [24]  402 	lcall	_ak820_outline_0104
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C29 90 05 64         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003C2C 12 37 98         [24]  405 	lcall	_ak820_outline_0004
      003C2F C0 07            [24]  406 	push	ar7
      003C31 C0 06            [24]  407 	push	ar6
      003C33 12 39 B8         [24]  408 	lcall	_ak820_flash_erase
      003C36 E5 82            [12]  409 	mov	a, dpl
      003C38 D0 06            [24]  410 	pop	ar6
      003C3A D0 07            [24]  411 	pop	ar7
      003C3C 70 03            [24]  412 	jnz	00102$
      003C3E F5 82            [12]  413 	mov	dpl,a
      003C40 22               [24]  414 	ret
      003C41                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C41 90 04 F5         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C44 74 19            [12]  418 	mov	a,#_page_data
      003C46 F0               [24]  419 	movx	@dptr,a
      003C47 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003C49 A3               [24]  421 	inc	dptr
      003C4A 12 42 F2         [24]  422 	lcall	_ak820_outline_0060
      003C4D 12 3A CC         [24]  423 	lcall	_ak820_flash_program_page
      003C50 E5 82            [12]  424 	mov	a, dpl
      003C52 70 03            [24]  425 	jnz	00120$
      003C54 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C56 22               [24]  428 	ret
      003C57                        429 00120$:
      003C57 7F 00            [12]  430 	mov	r7,#0x00
      003C59                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C59 8F 05            [24]  433 	mov	ar5,r7
      003C5B 7E 00            [12]  434 	mov	r6,#0x00
      003C5D 90 05 64         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003C60 12 38 51         [24]  436 	lcall	_ak820_outline_0120
      003C63 ED               [12]  437 	mov	a,r5
      003C64 2B               [12]  438 	add	a, r3
      003C65 FB               [12]  439 	mov	r3,a
      003C66 EE               [12]  440 	mov	a,r6
      003C67 3C               [12]  441 	addc	a, r4
      003C68 FC               [12]  442 	mov	r4,a
      003C69 12 33 FC         [24]  443 	lcall	_ak820_outline_0121
      003C6C 12 38 AB         [24]  444 	lcall	_ak820_flash_read
      003C6F AE 82            [24]  445 	mov	r6, dpl
      003C71 12 43 0B         [24]  446 	lcall	_ak820_outline_0101
      003C74 FD               [12]  447 	mov	r5,a
      003C75 EE               [12]  448 	mov	a,r6
      003C76 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003C79 80 04            [24]  450 	sjmp	00109$
      003C7B                        451 00149$:
      003C7B 75 82 00         [24]  452 	mov	dpl, #0x00
      003C7E 22               [24]  453 	ret
      003C7F                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C7F 0F               [12]  456 	inc	r7
      003C80 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003C83 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003C86 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003C87                        472 _journal_header_valid:
      003C87 12 38 3B         [24]  473 	lcall	_ak820_outline_0103
      003C8A 90 05 66         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003C8D 12 38 40         [24]  475 	lcall	_ak820_outline_0104
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003C90 90 05 66         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003C93 12 37 98         [24]  478 	lcall	_ak820_outline_0004
      003C96 E0               [24]  479 	movx	a,@dptr
      003C97 FD               [12]  480 	mov	r5,a
      003C98 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003C9B 80 04            [24]  482 	sjmp	00116$
      003C9D                        483 00138$:
      003C9D 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CA0 22               [24]  486 	ret
      003CA1                        487 00116$:
      003CA1 7D 01            [12]  488 	mov	r5,#0x01
      003CA3                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CA3 ED               [12]  491 	mov	a,r5
      003CA4 12 37 DF         [24]  492 	lcall	_ak820_outline_0016
      003CA7 FC               [12]  493 	mov	r4,a
      003CA8 8D 02            [24]  494 	mov	ar2,r5
      003CAA 7B 00            [12]  495 	mov	r3,#0x00
      003CAC 74 04            [12]  496 	mov	a,#0x04
      003CAE 2A               [12]  497 	add	a, r2
      003CAF FA               [12]  498 	mov	r2,a
      003CB0 E4               [12]  499 	clr	a
      003CB1 3B               [12]  500 	addc	a, r3
      003CB2 FB               [12]  501 	mov	r3,a
      003CB3 EA               [12]  502 	mov	a,r2
      003CB4 2E               [12]  503 	add	a, r6
      003CB5 F5 82            [12]  504 	mov	dpl,a
      003CB7 EB               [12]  505 	mov	a,r3
      003CB8 3F               [12]  506 	addc	a, r7
      003CB9 F5 83            [12]  507 	mov	dph,a
      003CBB E0               [24]  508 	movx	a,@dptr
      003CBC 62 04            [12]  509 	xrl	ar4,a
      003CBE BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      003CC1 80 04            [24]  511 	sjmp	00107$
      003CC3                        512 00139$:
      003CC3 75 82 00         [24]  513 	mov	dpl, #0x00
      003CC6 22               [24]  514 	ret
      003CC7                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CC7 0D               [12]  517 	inc	r5
      003CC8 BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003CCB 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003CCE 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      003CCF                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003CCF 7F 00            [12]  537 	mov	r7,#0x00
      003CD1                        538 00115$:
      003CD1 EF               [12]  539 	mov	a,r7
      003CD2 24 68            [12]  540 	add	a, #_recover_journal_header_10000_46
      003CD4 FD               [12]  541 	mov	r5,a
      003CD5 E4               [12]  542 	clr	a
      003CD6 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003CD8 FE               [12]  544 	mov	r6,a
      003CD9 8F 04            [24]  545 	mov	ar4,r7
      003CDB 7B 00            [12]  546 	mov	r3,#0x00
      003CDD 74 40            [12]  547 	mov	a,#0x40
      003CDF 2C               [12]  548 	add	a, r4
      003CE0 FC               [12]  549 	mov	r4,a
      003CE1 74 EF            [12]  550 	mov	a,#0xef
      003CE3 3B               [12]  551 	addc	a, r3
      003CE4 FB               [12]  552 	mov	r3,a
      003CE5 12 43 53         [24]  553 	lcall	_ak820_outline_0179
      003CE8 12 38 AB         [24]  554 	lcall	_ak820_flash_read
      003CEB AC 82            [24]  555 	mov	r4, dpl
      003CED 12 42 F8         [24]  556 	lcall	_ak820_outline_0064
      003CF0 0F               [12]  557 	inc	r7
      003CF1 BF 09 DD         [24]  558 	cjne	r7,#0x09,00115$
                                    559 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003CF4 90 05 68         [24]  560 	mov	dptr,#_recover_journal_header_10000_46
      003CF7 12 3C 87         [24]  561 	lcall	_journal_header_valid
      003CFA E5 82            [12]  562 	mov	a, dpl
      003CFC 70 01            [24]  563 	jnz	00103$
      003CFE 22               [24]  564 	ret
      003CFF                        565 00103$:
                                    566 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003CFF 90 05 69         [24]  567 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D02 E0               [24]  568 	movx	a,@dptr
      003D03 FF               [12]  569 	mov	r7,a
      003D04 7E 00            [12]  570 	mov	r6,#0x00
      003D06 90 05 6A         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D09 E0               [24]  572 	movx	a,@dptr
      003D0A FC               [12]  573 	mov	r4,a
      003D0B E4               [12]  574 	clr	a
      003D0C 42 07            [12]  575 	orl	ar7,a
      003D0E EC               [12]  576 	mov	a,r4
      003D0F 42 06            [12]  577 	orl	ar6,a
                                    578 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D11 90 05 6B         [24]  579 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D14 E0               [24]  580 	movx	a,@dptr
      003D15 FD               [12]  581 	mov	r5,a
      003D16 7C 00            [12]  582 	mov	r4,#0x00
      003D18 90 05 6C         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D1B E0               [24]  584 	movx	a,@dptr
      003D1C FA               [12]  585 	mov	r2,a
      003D1D E4               [12]  586 	clr	a
      003D1E 12 43 2D         [24]  587 	lcall	_ak820_outline_0138
                                    588 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D21 C3               [12]  589 	clr	c
      003D22 EF               [12]  590 	mov	a,r7
      003D23 94 A0            [12]  591 	subb	a,#0xa0
      003D25 EE               [12]  592 	mov	a,r6
      003D26 94 00            [12]  593 	subb	a,#0x00
      003D28 40 06            [24]  594 	jc	00134$
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D2A 75 82 01         [24]  596 	mov	dpl, #0x01
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D2D 02 3B 3F         [24]  598 	ljmp	_nvm_fail
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D30                        600 00134$:
      003D30 7B 00            [12]  601 	mov	r3,#0x00
      003D32                        602 00117$:
      003D32 C0 05            [24]  603 	push	ar5
      003D34 C0 04            [24]  604 	push	ar4
      003D36 EB               [12]  605 	mov	a,r3
      003D37 24 19            [12]  606 	add	a, #_page_data
      003D39 F9               [12]  607 	mov	r1,a
      003D3A E4               [12]  608 	clr	a
      003D3B 34 05            [12]  609 	addc	a, #(_page_data >> 8)
      003D3D FA               [12]  610 	mov	r2,a
      003D3E 8B 00            [24]  611 	mov	ar0,r3
      003D40 7D 00            [12]  612 	mov	r5,#0x00
      003D42 74 EF            [12]  613 	mov	a,#0xef
      003D44 2D               [12]  614 	add	a, r5
      003D45 FD               [12]  615 	mov	r5,a
      003D46 88 82            [24]  616 	mov	dpl, r0
      003D48 8D 83            [24]  617 	mov	dph, r5
      003D4A 12 38 AB         [24]  618 	lcall	_ak820_flash_read
      003D4D AD 82            [24]  619 	mov	r5, dpl
      003D4F 12 43 4E         [24]  620 	lcall	_ak820_outline_0178
      003D52 ED               [12]  621 	mov	a,r5
      003D53 F0               [24]  622 	movx	@dptr,a
      003D54 0B               [12]  623 	inc	r3
      003D55 BB 40 02         [24]  624 	cjne	r3,#0x40,00190$
      003D58 80 06            [24]  625 	sjmp	00191$
      003D5A                        626 00190$:
      003D5A D0 04            [24]  627 	pop	ar4
      003D5C D0 05            [24]  628 	pop	ar5
      003D5E 80 D2            [24]  629 	sjmp	00117$
      003D60                        630 00191$:
      003D60 D0 04            [24]  631 	pop	ar4
      003D62 D0 05            [24]  632 	pop	ar5
                                    633 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003D64 C0 07            [24]  634 	push	ar7
      003D66 C0 06            [24]  635 	push	ar6
      003D68 C0 05            [24]  636 	push	ar5
      003D6A C0 04            [24]  637 	push	ar4
      003D6C 12 3B ED         [24]  638 	lcall	_page_crc
      003D6F AA 82            [24]  639 	mov	r2, dpl
      003D71 AB 83            [24]  640 	mov	r3, dph
      003D73 D0 04            [24]  641 	pop	ar4
      003D75 D0 05            [24]  642 	pop	ar5
      003D77 D0 06            [24]  643 	pop	ar6
      003D79 D0 07            [24]  644 	pop	ar7
      003D7B EA               [12]  645 	mov	a,r2
      003D7C B5 05 06         [24]  646 	cjne	a,ar5,00192$
      003D7F EB               [12]  647 	mov	a,r3
      003D80 B5 04 02         [24]  648 	cjne	a,ar4,00192$
      003D83 80 06            [24]  649 	sjmp	00113$
      003D85                        650 00192$:
      003D85 75 82 02         [24]  651 	mov	dpl, #0x02
      003D88 02 3B 3F         [24]  652 	ljmp	_nvm_fail
      003D8B                        653 00113$:
                                    654 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003D8B EE               [12]  655 	mov	a,r6
      003D8C 54 03            [12]  656 	anl	a,#0x03
      003D8E A2 E0            [12]  657 	mov	c,acc.0
      003D90 CF               [12]  658 	xch	a,r7
      003D91 13               [12]  659 	rrc	a
      003D92 CF               [12]  660 	xch	a,r7
      003D93 13               [12]  661 	rrc	a
      003D94 A2 E0            [12]  662 	mov	c,acc.0
      003D96 CF               [12]  663 	xch	a,r7
      003D97 13               [12]  664 	rrc	a
      003D98 CF               [12]  665 	xch	a,r7
      003D99 13               [12]  666 	rrc	a
      003D9A CF               [12]  667 	xch	a,r7
      003D9B 24 C7            [12]  668 	add	a,#0xc7
      003D9D FE               [12]  669 	mov	r6,a
      003D9E 12 43 3D         [24]  670 	lcall	_ak820_outline_0152
      003DA1 12 3C 20         [24]  671 	lcall	_write_page
      003DA4 E5 82            [12]  672 	mov	a, dpl
      003DA6 70 06            [24]  673 	jnz	00110$
      003DA8 75 82 03         [24]  674 	mov	dpl, #0x03
      003DAB 02 3B 3F         [24]  675 	ljmp	_nvm_fail
      003DAE                        676 00110$:
                                    677 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DAE 90 EF 40         [24]  678 	mov	dptr,#0xef40
      003DB1 12 39 B8         [24]  679 	lcall	_ak820_flash_erase
      003DB4 E5 82            [12]  680 	mov	a, dpl
      003DB6 70 06            [24]  681 	jnz	00119$
      003DB8 75 82 04         [24]  682 	mov	dpl, #0x04
                                    683 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003DBB 02 3B 3F         [24]  684 	ljmp	_nvm_fail
      003DBE                        685 00119$:
      003DBE 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    689 ;------------------------------------------------------------
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    691 ;	-----------------------------------------
                                    692 ;	 function eeprom_driver_init
                                    693 ;	-----------------------------------------
      003DBF                        694 _eeprom_driver_init:
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    696 ;	assignBit
      003DBF C2 09            [12]  697 	clr	_storage_failed
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003DC1 90 05 5B         [24]  699 	mov	dptr,#_first_failure_stage
      003DC4 E4               [12]  700 	clr	a
      003DC5 F0               [24]  701 	movx	@dptr,a
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    703 ;	assignBit
      003DC6 C2 08            [12]  704 	clr	_page_dirty
                                    705 ;	assignBit
      003DC8 C2 07            [12]  706 	clr	_page_valid
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003DCA 90 05 5A         [24]  708 	mov	dptr,#_batch_depth
      003DCD E4               [12]  709 	clr	a
      003DCE F0               [24]  710 	movx	@dptr,a
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003DCF 12 3C CF         [24]  712 	lcall	_recover_journal
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003DD2 02 2A B7         [24]  715 	ljmp	_ak820_macro_init
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_nvm_ok
                                    722 ;	-----------------------------------------
      003DD5                        723 _ak820_nvm_ok:
      003DD5 A2 09            [12]  724 	mov	c,_storage_failed
      003DD7 B3               [12]  725 	cpl	c
      003DD8 92 0A            [24]  726 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003DDA 12 38 78         [24]  727 	lcall	_ak820_outline_0166
      003DDD 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    731 ;------------------------------------------------------------
                                    732 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    733 ;	-----------------------------------------
                                    734 ;	 function ak820_nvm_schema_fault
                                    735 ;	-----------------------------------------
      003DDE                        736 _ak820_nvm_schema_fault:
      003DDE 75 82 10         [24]  737 	mov	dpl, #0x10
      003DE1 02 3B 3F         [24]  738 	ljmp	_nvm_fail
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    741 ;------------------------------------------------------------
                                    742 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    743 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    744 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    745 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_flush
                                    750 ;	-----------------------------------------
      003DE4                        751 _ak820_nvm_flush:
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003DE4 30 08 03         [24]  753 	jnb	_page_dirty,00101$
      003DE7 30 09 01         [24]  754 	jnb	_storage_failed,00102$
      003DEA                        755 00101$:
      003DEA 22               [24]  756 	ret
      003DEB                        757 00102$:
                                    758 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003DEB 12 3B ED         [24]  759 	lcall	_page_crc
      003DEE 12 43 22         [24]  760 	lcall	_ak820_outline_0130
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003DF1 90 05 71         [24]  762 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003DF4 74 A5            [12]  763 	mov	a,#0xa5
      003DF6 F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003DF7 90 05 59         [24]  766 	mov	dptr,#_cached_page
      003DFA E0               [24]  767 	movx	a,@dptr
      003DFB 90 05 72         [24]  768 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003DFE F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003DFF 90 05 73         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E02 E4               [12]  772 	clr	a
      003E03 F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E04 8E 05            [24]  775 	mov	ar5,r6
      003E06 90 05 74         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E09 ED               [12]  777 	mov	a,r5
      003E0A F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E0B 8F 06            [24]  780 	mov	ar6,r7
      003E0D 90 05 75         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E10 EE               [12]  782 	mov	a,r6
      003E11 F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E12 7F 01            [12]  785 	mov	r7,#0x01
      003E14                        786 00128$:
      003E14 8F 06            [24]  787 	mov	ar6,r7
      003E16 EE               [12]  788 	mov	a,r6
      003E17 24 04            [12]  789 	add	a,#0x04
      003E19 FE               [12]  790 	mov	r6,a
      003E1A 33               [12]  791 	rlc	a
      003E1B 95 E0            [12]  792 	subb	a,acc
      003E1D FD               [12]  793 	mov	r5,a
      003E1E EE               [12]  794 	mov	a,r6
      003E1F 24 71            [12]  795 	add	a, #_ak820_nvm_flush_header_10000_62
      003E21 FE               [12]  796 	mov	r6,a
      003E22 ED               [12]  797 	mov	a,r5
      003E23 34 05            [12]  798 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E25 FD               [12]  799 	mov	r5,a
      003E26 12 42 D5         [24]  800 	lcall	_ak820_outline_0039
      003E29 FC               [12]  801 	mov	r4,a
      003E2A 63 04 FF         [24]  802 	xrl	ar4,#0xff
      003E2D 8E 82            [24]  803 	mov	dpl,r6
      003E2F 8D 83            [24]  804 	mov	dph,r5
      003E31 EC               [12]  805 	mov	a,r4
      003E32 F0               [24]  806 	movx	@dptr,a
      003E33 0F               [12]  807 	inc	r7
      003E34 BF 05 DD         [24]  808 	cjne	r7,#0x05,00128$
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E37 90 05 7A         [24]  810 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E3A 74 05            [12]  811 	mov	a,#0x05
      003E3C F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E3D 90 EF 40         [24]  814 	mov	dptr,#0xef40
      003E40 12 39 B8         [24]  815 	lcall	_ak820_flash_erase
      003E43 E5 82            [12]  816 	mov	a, dpl
      003E45 70 03            [24]  817 	jnz	00269$
      003E47 02 3F 2E         [24]  818 	ljmp	00127$
      003E4A                        819 00269$:
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E4A 90 05 7A         [24]  821 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E4D 74 06            [12]  822 	mov	a,#0x06
      003E4F F0               [24]  823 	movx	@dptr,a
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E50 7F 00            [12]  825 	mov	r7,#0x00
      003E52                        826 00130$:
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E52 12 42 E1         [24]  828 	lcall	_ak820_outline_0051
      003E55 12 38 AB         [24]  829 	lcall	_ak820_flash_read
      003E58 E5 82            [12]  830 	mov	a, dpl
      003E5A 60 03            [24]  831 	jz	00270$
      003E5C 02 3F 2E         [24]  832 	ljmp	00127$
      003E5F                        833 00270$:
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E5F 0F               [12]  835 	inc	r7
      003E60 BF 40 EF         [24]  836 	cjne	r7,#0x40,00130$
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003E63 90 05 7A         [24]  838 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E66 74 07            [12]  839 	mov	a,#0x07
      003E68 F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003E69 90 EF 00         [24]  842 	mov	dptr,#0xef00
      003E6C 12 3C 20         [24]  843 	lcall	_write_page
      003E6F E5 82            [12]  844 	mov	a, dpl
      003E71 70 03            [24]  845 	jnz	00273$
      003E73 02 3F 2E         [24]  846 	ljmp	00127$
      003E76                        847 00273$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003E76 90 05 7A         [24]  849 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E79 74 08            [12]  850 	mov	a,#0x08
      003E7B F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003E7C 7F 01            [12]  853 	mov	r7,#0x01
      003E7E                        854 00132$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003E7E 12 42 D5         [24]  856 	lcall	_ak820_outline_0039
      003E81 FE               [12]  857 	mov	r6,a
      003E82 60 23            [24]  858 	jz	00133$
      003E84 8F 05            [24]  859 	mov	ar5,r7
      003E86 7C 00            [12]  860 	mov	r4,#0x00
      003E88 74 40            [12]  861 	mov	a,#0x40
      003E8A 2D               [12]  862 	add	a, r5
      003E8B FD               [12]  863 	mov	r5,a
      003E8C 74 EF            [12]  864 	mov	a,#0xef
      003E8E 3C               [12]  865 	addc	a, r4
      003E8F FC               [12]  866 	mov	r4,a
      003E90 90 04 F2         [24]  867 	mov	dptr,#_ak820_flash_program_PARM_2
      003E93 EE               [12]  868 	mov	a,r6
      003E94 F0               [24]  869 	movx	@dptr,a
      003E95 8D 82            [24]  870 	mov	dpl, r5
      003E97 8C 83            [24]  871 	mov	dph, r4
      003E99 C0 07            [24]  872 	push	ar7
      003E9B 12 3A 18         [24]  873 	lcall	_ak820_flash_program
      003E9E E5 82            [12]  874 	mov	a, dpl
      003EA0 D0 07            [24]  875 	pop	ar7
      003EA2 70 03            [24]  876 	jnz	00275$
      003EA4 02 3F 2E         [24]  877 	ljmp	00127$
      003EA7                        878 00275$:
      003EA7                        879 00133$:
                                    880 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EA7 0F               [12]  881 	inc	r7
      003EA8 BF 09 D3         [24]  882 	cjne	r7,#0x09,00132$
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EAB 90 05 7A         [24]  884 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EAE 74 09            [12]  885 	mov	a,#0x09
      003EB0 F0               [24]  886 	movx	@dptr,a
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EB1 7F 01            [12]  888 	mov	r7,#0x01
      003EB3                        889 00134$:
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EB3 12 42 E1         [24]  891 	lcall	_ak820_outline_0051
      003EB6 12 38 AB         [24]  892 	lcall	_ak820_flash_read
      003EB9 AE 82            [24]  893 	mov	r6, dpl
      003EBB 12 42 D5         [24]  894 	lcall	_ak820_outline_0039
      003EBE FD               [12]  895 	mov	r5,a
      003EBF EE               [12]  896 	mov	a,r6
      003EC0 B5 05 6B         [24]  897 	cjne	a,ar5,00127$
                                    898 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EC3 0F               [12]  899 	inc	r7
      003EC4 BF 09 EC         [24]  900 	cjne	r7,#0x09,00134$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003EC7 90 05 7A         [24]  902 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003ECA 74 0A            [12]  903 	mov	a,#0x0a
      003ECC F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003ECD 90 05 71         [24]  906 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003ED0 E0               [24]  907 	movx	a,@dptr
      003ED1 90 04 F2         [24]  908 	mov	dptr,#_ak820_flash_program_PARM_2
      003ED4 F0               [24]  909 	movx	@dptr,a
      003ED5 90 EF 40         [24]  910 	mov	dptr,#0xef40
      003ED8 12 3A 18         [24]  911 	lcall	_ak820_flash_program
      003EDB E5 82            [12]  912 	mov	a, dpl
      003EDD 60 4F            [24]  913 	jz	00127$
                                    914 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003EDF 90 05 7A         [24]  915 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EE2 74 0B            [12]  916 	mov	a,#0x0b
      003EE4 F0               [24]  917 	movx	@dptr,a
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003EE5 90 EF 40         [24]  919 	mov	dptr,#0xef40
      003EE8 12 38 AB         [24]  920 	lcall	_ak820_flash_read
      003EEB AF 82            [24]  921 	mov	r7, dpl
      003EED 90 05 71         [24]  922 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EF0 E0               [24]  923 	movx	a,@dptr
      003EF1 FE               [12]  924 	mov	r6,a
      003EF2 EF               [12]  925 	mov	a,r7
      003EF3 B5 06 38         [24]  926 	cjne	a,ar6,00127$
                                    927 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003EF6 90 05 7A         [24]  928 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EF9 74 0C            [12]  929 	mov	a,#0x0c
      003EFB F0               [24]  930 	movx	@dptr,a
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003EFC 90 05 59         [24]  932 	mov	dptr,#_cached_page
      003EFF E0               [24]  933 	movx	a,@dptr
      003F00 FE               [12]  934 	mov	r6,a
      003F01 E4               [12]  935 	clr	a
      003F02 C3               [12]  936 	clr	c
      003F03 CE               [12]  937 	xch	a,r6
      003F04 13               [12]  938 	rrc	a
      003F05 CE               [12]  939 	xch	a,r6
      003F06 13               [12]  940 	rrc	a
      003F07 A2 E0            [12]  941 	mov	c,acc.0
      003F09 CE               [12]  942 	xch	a,r6
      003F0A 13               [12]  943 	rrc	a
      003F0B CE               [12]  944 	xch	a,r6
      003F0C 13               [12]  945 	rrc	a
      003F0D CE               [12]  946 	xch	a,r6
      003F0E 24 C7            [12]  947 	add	a,#0xc7
      003F10 FF               [12]  948 	mov	r7,a
      003F11 12 43 17         [24]  949 	lcall	_ak820_outline_0116
      003F14 12 3C 20         [24]  950 	lcall	_write_page
      003F17 E5 82            [12]  951 	mov	a, dpl
      003F19 60 13            [24]  952 	jz	00127$
                                    953 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F1B 90 05 7A         [24]  954 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F1E 74 0D            [12]  955 	mov	a,#0x0d
      003F20 F0               [24]  956 	movx	@dptr,a
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F21 90 EF 40         [24]  958 	mov	dptr,#0xef40
      003F24 12 39 B8         [24]  959 	lcall	_ak820_flash_erase
      003F27 E5 82            [12]  960 	mov	a, dpl
      003F29 60 03            [24]  961 	jz	00127$
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    963 ;	assignBit
      003F2B C2 08            [12]  964 	clr	_page_dirty
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F2D 22               [24]  967 	ret
      003F2E                        968 00127$:
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F2E 90 05 7A         [24]  970 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F31 E0               [24]  971 	movx	a,@dptr
      003F32 F5 82            [12]  972 	mov	dpl,a
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F34 02 3B 3F         [24]  974 	ljmp	_nvm_fail
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    977 ;------------------------------------------------------------
                                    978 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function ak820_nvm_begin
                                    981 ;	-----------------------------------------
      003F37                        982 _ak820_nvm_begin:
                                    983 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F37 90 05 5A         [24]  984 	mov	dptr,#_batch_depth
      003F3A E0               [24]  985 	movx	a,@dptr
      003F3B FF               [12]  986 	mov	r7,a
      003F3C BF FF 06         [24]  987 	cjne	r7,#0xff,00102$
      003F3F 75 82 0F         [24]  988 	mov	dpl, #0x0f
      003F42 02 3B 3F         [24]  989 	ljmp	_nvm_fail
      003F45                        990 00102$:
                                    991 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F45 90 05 5A         [24]  992 	mov	dptr,#_batch_depth
      003F48 EF               [12]  993 	mov	a,r7
      003F49 04               [12]  994 	inc	a
      003F4A F0               [24]  995 	movx	@dptr,a
                                    996 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F4B 22               [24]  997 	ret
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function ak820_nvm_end
                                   1004 ;	-----------------------------------------
      003F4C                       1005 _ak820_nvm_end:
                                   1006 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F4C 90 05 5A         [24] 1007 	mov	dptr,#_batch_depth
      003F4F E0               [24] 1008 	movx	a,@dptr
      003F50 FF               [12] 1009 	mov	r7,a
      003F51 E0               [24] 1010 	movx	a,@dptr
      003F52 60 06            [24] 1011 	jz	00102$
      003F54 EF               [12] 1012 	mov	a,r7
      003F55 14               [12] 1013 	dec	a
      003F56 90 05 5A         [24] 1014 	mov	dptr,#_batch_depth
      003F59 F0               [24] 1015 	movx	@dptr,a
      003F5A                       1016 00102$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003F5A 90 05 5A         [24] 1018 	mov	dptr,#_batch_depth
      003F5D E0               [24] 1019 	movx	a,@dptr
      003F5E 70 03            [24] 1020 	jnz	00105$
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003F60 02 3D E4         [24] 1022 	ljmp	_ak820_nvm_flush
      003F63                       1023 00105$:
      003F63 22               [24] 1024 	ret
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'load_page'
                                   1027 ;------------------------------------------------------------
                                   1028 ;page          Allocated with name '_load_page_page_10000_87'
                                   1029 ;i             Allocated with name '_load_page_i_10000_88'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function load_page
                                   1034 ;	-----------------------------------------
      003F64                       1035 _load_page:
      003F64 E5 82            [12] 1036 	mov	a,dpl
      003F66 90 05 7B         [24] 1037 	mov	dptr,#_load_page_page_10000_87
      003F69 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003F6A 30 07 17         [24] 1040 	jnb	_page_valid,00102$
      003F6D 90 05 59         [24] 1041 	mov	dptr,#_cached_page
      003F70 E0               [24] 1042 	movx	a,@dptr
      003F71 FF               [12] 1043 	mov	r7,a
      003F72 90 05 7B         [24] 1044 	mov	dptr,#_load_page_page_10000_87
      003F75 E0               [24] 1045 	movx	a,@dptr
      003F76 FE               [12] 1046 	mov	r6,a
      003F77 EF               [12] 1047 	mov	a,r7
      003F78 B5 06 09         [24] 1048 	cjne	a,ar6,00102$
      003F7B A2 09            [12] 1049 	mov	c,_storage_failed
      003F7D B3               [12] 1050 	cpl	c
      003F7E 92 0B            [24] 1051 	mov  _load_page_sloc0_1_0,c
      003F80 12 38 78         [24] 1052 	lcall	_ak820_outline_0166
      003F83 22               [24] 1053 	ret
      003F84                       1054 00102$:
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003F84 12 3D E4         [24] 1056 	lcall	_ak820_nvm_flush
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003F87 30 09 04         [24] 1058 	jnb	_storage_failed,00119$
      003F8A 75 82 00         [24] 1059 	mov	dpl, #0x00
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F8D 22               [24] 1061 	ret
      003F8E                       1062 00119$:
      003F8E 7F 00            [12] 1063 	mov	r7,#0x00
      003F90                       1064 00107$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003F90 EF               [12] 1066 	mov	a,r7
      003F91 24 19            [12] 1067 	add	a, #_page_data
      003F93 FD               [12] 1068 	mov	r5,a
      003F94 E4               [12] 1069 	clr	a
      003F95 34 05            [12] 1070 	addc	a, #(_page_data >> 8)
      003F97 FE               [12] 1071 	mov	r6,a
      003F98 90 05 7B         [24] 1072 	mov	dptr,#_load_page_page_10000_87
      003F9B E0               [24] 1073 	movx	a,@dptr
      003F9C FC               [12] 1074 	mov	r4,a
      003F9D FA               [12] 1075 	mov	r2,a
      003F9E E4               [12] 1076 	clr	a
      003F9F C3               [12] 1077 	clr	c
      003FA0 CA               [12] 1078 	xch	a,r2
      003FA1 13               [12] 1079 	rrc	a
      003FA2 CA               [12] 1080 	xch	a,r2
      003FA3 13               [12] 1081 	rrc	a
      003FA4 A2 E0            [12] 1082 	mov	c,acc.0
      003FA6 CA               [12] 1083 	xch	a,r2
      003FA7 13               [12] 1084 	rrc	a
      003FA8 CA               [12] 1085 	xch	a,r2
      003FA9 13               [12] 1086 	rrc	a
      003FAA CA               [12] 1087 	xch	a,r2
      003FAB 24 C7            [12] 1088 	add	a,#0xc7
      003FAD FB               [12] 1089 	mov	r3,a
      003FAE 8F 01            [24] 1090 	mov	ar1,r7
      003FB0 89 00            [24] 1091 	mov	ar0,r1
      003FB2 79 00            [12] 1092 	mov	r1,#0x00
      003FB4 E8               [12] 1093 	mov	a,r0
      003FB5 2A               [12] 1094 	add	a, r2
      003FB6 FA               [12] 1095 	mov	r2,a
      003FB7 E9               [12] 1096 	mov	a,r1
      003FB8 3B               [12] 1097 	addc	a, r3
      003FB9 FB               [12] 1098 	mov	r3,a
      003FBA 12 43 33         [24] 1099 	lcall	_ak820_outline_0139
      003FBD 12 38 AB         [24] 1100 	lcall	_ak820_flash_read
      003FC0 AB 82            [24] 1101 	mov	r3, dpl
      003FC2 12 38 5C         [24] 1102 	lcall	_ak820_outline_0131
      003FC5 EB               [12] 1103 	mov	a,r3
      003FC6 F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FC7 0F               [12] 1106 	inc	r7
      003FC8 BF 40 C5         [24] 1107 	cjne	r7,#0x40,00107$
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      003FCB 90 05 59         [24] 1109 	mov	dptr,#_cached_page
      003FCE EC               [12] 1110 	mov	a,r4
      003FCF F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1113 ;	assignBit
      003FD0 D2 07            [12] 1114 	setb	_page_valid
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      003FD2 75 82 01         [24] 1116 	mov	dpl, #0x01
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      003FD5 22               [24] 1118 	ret
                                   1119 ;------------------------------------------------------------
                                   1120 ;Allocation info for local variables in function 'read_offset'
                                   1121 ;------------------------------------------------------------
                                   1122 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1123 ;------------------------------------------------------------
                                   1124 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1125 ;	-----------------------------------------
                                   1126 ;	 function read_offset
                                   1127 ;	-----------------------------------------
      003FD6                       1128 _read_offset:
      003FD6 12 38 3B         [24] 1129 	lcall	_ak820_outline_0103
      003FD9 90 05 7C         [24] 1130 	mov	dptr,#_read_offset_offset_10000_93
      003FDC 12 38 40         [24] 1131 	lcall	_ak820_outline_0104
                                   1132 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      003FDF 90 05 7C         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      003FE2 12 37 F8         [24] 1134 	lcall	_ak820_outline_0050
      003FE5 C3               [12] 1135 	clr	c
      003FE6 94 28            [12] 1136 	subb	a,#0x28
      003FE8 40 04            [24] 1137 	jc	00102$
      003FEA 75 82 00         [24] 1138 	mov	dpl, #0x00
      003FED 22               [24] 1139 	ret
      003FEE                       1140 00102$:
                                   1141 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      003FEE 30 07 34         [24] 1142 	jnb	_page_valid,00104$
      003FF1 8E 04            [24] 1143 	mov	ar4,r6
      003FF3 EF               [12] 1144 	mov	a,r7
      003FF4 A2 E7            [12] 1145 	mov	c,acc.7
      003FF6 CC               [12] 1146 	xch	a,r4
      003FF7 33               [12] 1147 	rlc	a
      003FF8 CC               [12] 1148 	xch	a,r4
      003FF9 33               [12] 1149 	rlc	a
      003FFA A2 E7            [12] 1150 	mov	c,acc.7
      003FFC CC               [12] 1151 	xch	a,r4
      003FFD 33               [12] 1152 	rlc	a
      003FFE CC               [12] 1153 	xch	a,r4
      003FFF 33               [12] 1154 	rlc	a
      004000 CC               [12] 1155 	xch	a,r4
      004001 54 03            [12] 1156 	anl	a,#0x03
      004003 FD               [12] 1157 	mov	r5,a
      004004 90 05 59         [24] 1158 	mov	dptr,#_cached_page
      004007 E0               [24] 1159 	movx	a,@dptr
      004008 FA               [12] 1160 	mov	r2,a
      004009 7B 00            [12] 1161 	mov	r3,#0x00
      00400B EC               [12] 1162 	mov	a,r4
      00400C B5 02 16         [24] 1163 	cjne	a,ar2,00104$
      00400F ED               [12] 1164 	mov	a,r5
      004010 B5 03 12         [24] 1165 	cjne	a,ar3,00104$
                                   1166 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004013 74 3F            [12] 1167 	mov	a,#0x3f
      004015 5E               [12] 1168 	anl	a,r6
      004016 7D 00            [12] 1169 	mov	r5,#0x00
      004018 24 19            [12] 1170 	add	a, #_page_data
      00401A F5 82            [12] 1171 	mov	dpl,a
      00401C ED               [12] 1172 	mov	a,r5
      00401D 34 05            [12] 1173 	addc	a, #(_page_data >> 8)
      00401F F5 83            [12] 1174 	mov	dph,a
      004021 E0               [24] 1175 	movx	a,@dptr
      004022 F5 82            [12] 1176 	mov	dpl,a
      004024 22               [24] 1177 	ret
      004025                       1178 00104$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004025 74 C7            [12] 1180 	mov	a,#0xc7
      004027 2F               [12] 1181 	add	a, r7
      004028 FF               [12] 1182 	mov	r7,a
      004029 12 43 17         [24] 1183 	lcall	_ak820_outline_0116
                                   1184 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      00402C 02 38 AB         [24] 1185 	ljmp	_ak820_flash_read
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1188 ;------------------------------------------------------------
                                   1189 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function eeprom_read_byte
                                   1194 ;	-----------------------------------------
      00402F                       1195 _eeprom_read_byte:
      00402F C0 07            [24] 1196 	push	ar7
      004031 C0 06            [24] 1197 	push	ar6
      004033 12 42 CE         [24] 1198 	lcall	_ak820_outline_0036
      004036 90 05 7E         [24] 1199 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004039 12 37 D7         [24] 1200 	lcall	_ak820_outline_0015
                                   1201 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00403C 90 05 7E         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00403F 12 37 98         [24] 1203 	lcall	_ak820_outline_0004
      004042 C0 06            [24] 1204 	push	ar6
      004044 C0 05            [24] 1205 	push	ar5
      004046 C0 04            [24] 1206 	push	ar4
      004048 C0 03            [24] 1207 	push	ar3
      00404A C0 02            [24] 1208 	push	ar2
      00404C C0 01            [24] 1209 	push	ar1
      00404E C0 00            [24] 1210 	push	ar0
      004050 12 3F D6         [24] 1211 	lcall	_read_offset
      004053 AF 82            [24] 1212 	mov	r7, dpl
      004055 D0 00            [24] 1213 	pop	ar0
      004057 D0 01            [24] 1214 	pop	ar1
      004059 D0 02            [24] 1215 	pop	ar2
      00405B D0 03            [24] 1216 	pop	ar3
      00405D D0 04            [24] 1217 	pop	ar4
      00405F D0 05            [24] 1218 	pop	ar5
      004061 D0 06            [24] 1219 	pop	ar6
      004063 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004065 D0 06            [24] 1222 	pop	ar6
      004067 D0 07            [24] 1223 	pop	ar7
      004069 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1227 ;------------------------------------------------------------
                                   1228 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1229 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1230 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1231 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1232 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1233 ;------------------------------------------------------------
                                   1234 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1235 ;	-----------------------------------------
                                   1236 ;	 function ak820_eeprom_read_block_xdata
                                   1237 ;	-----------------------------------------
      00406A                       1238 _ak820_eeprom_read_block_xdata:
      00406A 12 38 3B         [24] 1239 	lcall	_ak820_outline_0103
      00406D 90 05 86         [24] 1240 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004070 12 38 40         [24] 1241 	lcall	_ak820_outline_0104
                                   1242 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004073 90 05 81         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004076 12 37 F8         [24] 1244 	lcall	_ak820_outline_0050
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004079 90 05 86         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00407C 12 38 17         [24] 1247 	lcall	_ak820_outline_0059
      00407F 90 05 88         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004082 12 38 1D         [24] 1249 	lcall	_ak820_outline_0070
                                   1250 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004085 90 05 84         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004088 12 38 17         [24] 1252 	lcall	_ak820_outline_0059
      00408B                       1253 00103$:
      00408B 8C 02            [24] 1254 	mov	ar2,r4
      00408D 8D 03            [24] 1255 	mov	ar3,r5
      00408F 1C               [12] 1256 	dec	r4
      004090 BC FF 01         [24] 1257 	cjne	r4,#0xff,00130$
      004093 1D               [12] 1258 	dec	r5
      004094                       1259 00130$:
      004094 EA               [12] 1260 	mov	a,r2
      004095 4B               [12] 1261 	orl	a,r3
      004096 60 5D            [24] 1262 	jz	00106$
                                   1263 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      004098 8E 02            [24] 1264 	mov	ar2,r6
      00409A 8F 03            [24] 1265 	mov	ar3,r7
      00409C 74 D8            [12] 1266 	mov	a,#0x100 - 0x28
      00409E 2B               [12] 1267 	add	a,r3
      00409F 50 17            [24] 1268 	jnc	00102$
      0040A1 90 05 88         [24] 1269 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040A4 12 43 1C         [24] 1270 	lcall	_ak820_outline_0119
      0040A7 12 43 33         [24] 1271 	lcall	_ak820_outline_0139
      0040AA E4               [12] 1272 	clr	a
      0040AB F0               [24] 1273 	movx	@dptr,a
      0040AC 90 05 88         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040AF 04               [12] 1275 	inc	a
      0040B0 2A               [12] 1276 	add	a, r2
      0040B1 F0               [24] 1277 	movx	@dptr,a
      0040B2 E4               [12] 1278 	clr	a
      0040B3 3B               [12] 1279 	addc	a, r3
      0040B4 A3               [24] 1280 	inc	dptr
      0040B5 F0               [24] 1281 	movx	@dptr,a
      0040B6 80 D3            [24] 1282 	sjmp	00103$
      0040B8                       1283 00102$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040B8 90 05 88         [24] 1285 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040BB 12 43 1C         [24] 1286 	lcall	_ak820_outline_0119
      0040BE 12 43 17         [24] 1287 	lcall	_ak820_outline_0116
      0040C1 C0 07            [24] 1288 	push	ar7
      0040C3 C0 06            [24] 1289 	push	ar6
      0040C5 C0 05            [24] 1290 	push	ar5
      0040C7 C0 04            [24] 1291 	push	ar4
      0040C9 C0 03            [24] 1292 	push	ar3
      0040CB C0 02            [24] 1293 	push	ar2
      0040CD 12 3F D6         [24] 1294 	lcall	_read_offset
      0040D0 A9 82            [24] 1295 	mov	r1, dpl
      0040D2 D0 02            [24] 1296 	pop	ar2
      0040D4 D0 03            [24] 1297 	pop	ar3
      0040D6 D0 04            [24] 1298 	pop	ar4
      0040D8 D0 05            [24] 1299 	pop	ar5
      0040DA D0 06            [24] 1300 	pop	ar6
      0040DC D0 07            [24] 1301 	pop	ar7
      0040DE 12 43 33         [24] 1302 	lcall	_ak820_outline_0139
      0040E1 E9               [12] 1303 	mov	a,r1
      0040E2 F0               [24] 1304 	movx	@dptr,a
      0040E3 90 05 88         [24] 1305 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040E6 74 01            [12] 1306 	mov	a,#0x01
      0040E8 2A               [12] 1307 	add	a, r2
      0040E9 F0               [24] 1308 	movx	@dptr,a
      0040EA E4               [12] 1309 	clr	a
      0040EB 3B               [12] 1310 	addc	a, r3
      0040EC A3               [24] 1311 	inc	dptr
      0040ED F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0040EE 0E               [12] 1314 	inc	r6
      0040EF BE 00 99         [24] 1315 	cjne	r6,#0x00,00103$
      0040F2 0F               [12] 1316 	inc	r7
      0040F3 80 96            [24] 1317 	sjmp	00103$
      0040F5                       1318 00106$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0040F5 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1325 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1326 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1327 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1328 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1329 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1330 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function ak820_eeprom_write_block_xdata
                                   1335 ;	-----------------------------------------
      0040F6                       1336 _ak820_eeprom_write_block_xdata:
      0040F6 12 38 3B         [24] 1337 	lcall	_ak820_outline_0103
      0040F9 90 05 8F         [24] 1338 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0040FC 12 38 40         [24] 1339 	lcall	_ak820_outline_0104
                                   1340 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040FF 90 05 8A         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004102 12 37 F8         [24] 1342 	lcall	_ak820_outline_0050
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004105 90 05 8F         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004108 12 38 17         [24] 1345 	lcall	_ak820_outline_0059
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00410B 8E 02            [24] 1347 	mov	ar2,r6
      00410D 8F 03            [24] 1348 	mov	ar3,r7
      00410F C3               [12] 1349 	clr	c
      004110 E4               [12] 1350 	clr	a
      004111 9A               [12] 1351 	subb	a,r2
      004112 74 28            [12] 1352 	mov	a,#0x28
      004114 9B               [12] 1353 	subb	a,r3
      004115 40 15            [24] 1354 	jc	00101$
                                   1355 ;	free result
      004117 E4               [12] 1356 	clr	a
      004118 C3               [12] 1357 	clr	c
      004119 9E               [12] 1358 	subb	a,r6
      00411A FA               [12] 1359 	mov	r2,a
      00411B 74 28            [12] 1360 	mov	a,#0x28
      00411D 9F               [12] 1361 	subb	a,r7
      00411E FB               [12] 1362 	mov	r3,a
      00411F 90 05 8D         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004122 12 38 35         [24] 1364 	lcall	_ak820_outline_0099
      004125 C3               [12] 1365 	clr	c
      004126 EA               [12] 1366 	mov	a,r2
      004127 98               [12] 1367 	subb	a,r0
      004128 EB               [12] 1368 	mov	a,r3
      004129 99               [12] 1369 	subb	a,r1
      00412A 50 06            [24] 1370 	jnc	00125$
                                   1371 ;	free result
      00412C                       1372 00101$:
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      00412C 75 82 0E         [24] 1374 	mov	dpl, #0x0e
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      00412F 02 3B 3F         [24] 1376 	ljmp	_nvm_fail
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004132                       1378 00125$:
      004132 90 05 8D         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004135 12 43 1C         [24] 1380 	lcall	_ak820_outline_0119
      004138                       1381 00108$:
      004138 8A 00            [24] 1382 	mov	ar0,r2
      00413A 8B 01            [24] 1383 	mov	ar1,r3
      00413C 1A               [12] 1384 	dec	r2
      00413D BA FF 01         [24] 1385 	cjne	r2,#0xff,00159$
      004140 1B               [12] 1386 	dec	r3
      004141                       1387 00159$:
      004141 E8               [12] 1388 	mov	a,r0
      004142 49               [12] 1389 	orl	a,r1
      004143 70 03            [24] 1390 	jnz	00160$
      004145 02 41 CF         [24] 1391 	ljmp	00110$
      004148                       1392 00160$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004148 C0 02            [24] 1394 	push	ar2
      00414A C0 03            [24] 1395 	push	ar3
      00414C 12 42 FF         [24] 1396 	lcall	_ak820_outline_0091
      00414F F9               [12] 1397 	mov	r1,a
      004150 A3               [24] 1398 	inc	dptr
      004151 12 43 38         [24] 1399 	lcall	_ak820_outline_0144
                                   1400 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004154 8E 0C            [24] 1401 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004156 8F 0D            [24] 1402 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004158 A8 0C            [24] 1403 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00415A E5 0D            [12] 1404 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00415C A2 E7            [12] 1405 	mov	c,acc.7
      00415E C8               [12] 1406 	xch	a,r0
      00415F 33               [12] 1407 	rlc	a
      004160 C8               [12] 1408 	xch	a,r0
      004161 33               [12] 1409 	rlc	a
      004162 A2 E7            [12] 1410 	mov	c,acc.7
      004164 C8               [12] 1411 	xch	a,r0
      004165 33               [12] 1412 	rlc	a
      004166 C8               [12] 1413 	xch	a,r0
      004167 33               [12] 1414 	rlc	a
      004168 C8               [12] 1415 	xch	a,r0
      004169 54 03            [12] 1416 	anl	a,#0x03
      00416B FB               [12] 1417 	mov	r3,a
      00416C 88 82            [24] 1418 	mov	dpl, r0
      00416E C0 07            [24] 1419 	push	ar7
      004170 C0 06            [24] 1420 	push	ar6
      004172 C0 05            [24] 1421 	push	ar5
      004174 C0 04            [24] 1422 	push	ar4
      004176 C0 03            [24] 1423 	push	ar3
      004178 C0 02            [24] 1424 	push	ar2
      00417A C0 01            [24] 1425 	push	ar1
      00417C 12 3F 64         [24] 1426 	lcall	_load_page
      00417F E5 82            [12] 1427 	mov	a, dpl
      004181 D0 01            [24] 1428 	pop	ar1
      004183 D0 02            [24] 1429 	pop	ar2
      004185 D0 03            [24] 1430 	pop	ar3
      004187 D0 04            [24] 1431 	pop	ar4
      004189 D0 05            [24] 1432 	pop	ar5
      00418B D0 06            [24] 1433 	pop	ar6
      00418D D0 07            [24] 1434 	pop	ar7
      00418F D0 03            [24] 1435 	pop	ar3
      004191 D0 02            [24] 1436 	pop	ar2
      004193 70 01            [24] 1437 	jnz	00105$
      004195 22               [24] 1438 	ret
      004196                       1439 00105$:
                                   1440 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004196 C0 06            [24] 1441 	push	ar6
      004198 C0 07            [24] 1442 	push	ar7
      00419A 74 3F            [12] 1443 	mov	a,#0x3f
      00419C 55 0C            [12] 1444 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00419E 7F 00            [12] 1445 	mov	r7,#0x00
      0041A0 24 19            [12] 1446 	add	a, #_page_data
      0041A2 F5 0C            [12] 1447 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041A4 EF               [12] 1448 	mov	a,r7
      0041A5 34 05            [12] 1449 	addc	a, #(_page_data >> 8)
      0041A7 F5 0D            [12] 1450 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041A9 85 0C 82         [24] 1451 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041AC 85 0D 83         [24] 1452 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041AF E0               [24] 1453 	movx	a,@dptr
      0041B0 B5 01 06         [24] 1454 	cjne	a,ar1,00162$
      0041B3 D0 07            [24] 1455 	pop	ar7
      0041B5 D0 06            [24] 1456 	pop	ar6
      0041B7 80 0E            [24] 1457 	sjmp	00107$
      0041B9                       1458 00162$:
      0041B9 D0 07            [24] 1459 	pop	ar7
      0041BB D0 06            [24] 1460 	pop	ar6
                                   1461 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      0041BD 85 0C 82         [24] 1462 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041C0 85 0D 83         [24] 1463 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041C3 E9               [12] 1464 	mov	a,r1
      0041C4 F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1467 ;	assignBit
      0041C5 D2 08            [12] 1468 	setb	_page_dirty
      0041C7                       1469 00107$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      0041C7 0E               [12] 1471 	inc	r6
      0041C8 BE 00 01         [24] 1472 	cjne	r6,#0x00,00163$
      0041CB 0F               [12] 1473 	inc	r7
      0041CC                       1474 00163$:
      0041CC 02 41 38         [24] 1475 	ljmp	00108$
      0041CF                       1476 00110$:
                                   1477 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      0041CF 90 05 5A         [24] 1478 	mov	dptr,#_batch_depth
      0041D2 E0               [24] 1479 	movx	a,@dptr
      0041D3 70 03            [24] 1480 	jnz	00113$
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      0041D5 02 3D E4         [24] 1482 	ljmp	_ak820_nvm_flush
      0041D8                       1483 00113$:
      0041D8 22               [24] 1484 	ret
                                   1485 ;------------------------------------------------------------
                                   1486 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1487 ;------------------------------------------------------------
                                   1488 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1489 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1490 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1491 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1492 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1493 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1494 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1495 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1496 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1497 ;------------------------------------------------------------
                                   1498 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1499 ;	-----------------------------------------
                                   1500 ;	 function ak820_eeprom_update_block_xdata
                                   1501 ;	-----------------------------------------
      0041D9                       1502 _ak820_eeprom_update_block_xdata:
      0041D9 12 38 3B         [24] 1503 	lcall	_ak820_outline_0103
      0041DC 90 05 96         [24] 1504 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041DF 12 38 40         [24] 1505 	lcall	_ak820_outline_0104
                                   1506 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0041E2 90 05 96         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041E5 12 37 F8         [24] 1508 	lcall	_ak820_outline_0050
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0041E8 90 05 91         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0041EB E0               [24] 1511 	movx	a,@dptr
      0041EC F5 12            [12] 1512 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0041EE A3               [24] 1513 	inc	dptr
      0041EF E0               [24] 1514 	movx	a,@dptr
      0041F0 F5 13            [12] 1515 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0041F2 A3               [24] 1516 	inc	dptr
      0041F3 E0               [24] 1517 	movx	a,@dptr
      0041F4 F5 14            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0041F6 A9 12            [24] 1519 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0041F8 AA 13            [24] 1520 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1521 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0041FA E4               [12] 1522 	clr	a
      0041FB F5 0E            [12] 1523 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0041FD F5 0F            [12] 1524 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0041FF                       1525 00105$:
      0041FF 90 05 94         [24] 1526 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004202 E0               [24] 1527 	movx	a,@dptr
      004203 F5 10            [12] 1528 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004205 A3               [24] 1529 	inc	dptr
      004206 E0               [24] 1530 	movx	a,@dptr
      004207 F5 11            [12] 1531 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004209 C3               [12] 1532 	clr	c
      00420A E5 0E            [12] 1533 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00420C 95 10            [12] 1534 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00420E E5 0F            [12] 1535 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004210 95 11            [12] 1536 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004212 50 68            [24] 1537 	jnc	00107$
                                   1538 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004214 89 00            [24] 1539 	mov	ar0,r1
      004216 8A 05            [24] 1540 	mov	ar5,r2
      004218 E5 0E            [12] 1541 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00421A 28               [12] 1542 	add	a, r0
      00421B F8               [12] 1543 	mov	r0,a
      00421C E5 0F            [12] 1544 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00421E 3D               [12] 1545 	addc	a, r5
      00421F FD               [12] 1546 	mov	r5,a
      004220 88 82            [24] 1547 	mov	dpl, r0
      004222 8D 83            [24] 1548 	mov	dph, r5
      004224 C0 07            [24] 1549 	push	ar7
      004226 C0 06            [24] 1550 	push	ar6
      004228 C0 02            [24] 1551 	push	ar2
      00422A C0 01            [24] 1552 	push	ar1
      00422C 12 3F D6         [24] 1553 	lcall	_read_offset
      00422F AD 82            [24] 1554 	mov	r5, dpl
      004231 D0 01            [24] 1555 	pop	ar1
      004233 D0 02            [24] 1556 	pop	ar2
      004235 D0 06            [24] 1557 	pop	ar6
      004237 D0 07            [24] 1558 	pop	ar7
      004239 E5 0E            [12] 1559 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00423B 2E               [12] 1560 	add	a, r6
      00423C F5 82            [12] 1561 	mov	dpl,a
      00423E E5 0F            [12] 1562 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004240 3F               [12] 1563 	addc	a, r7
      004241 F5 83            [12] 1564 	mov	dph,a
      004243 E0               [24] 1565 	movx	a,@dptr
      004244 FC               [12] 1566 	mov	r4,a
      004245 ED               [12] 1567 	mov	a,r5
      004246 B5 04 02         [24] 1568 	cjne	a,ar4,00131$
      004249 80 27            [24] 1569 	sjmp	00106$
      00424B                       1570 00131$:
                                   1571 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00424B 90 05 96         [24] 1572 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00424E E0               [24] 1573 	movx	a,@dptr
      00424F F8               [12] 1574 	mov	r0,a
      004250 A3               [24] 1575 	inc	dptr
      004251 E0               [24] 1576 	movx	a,@dptr
      004252 FD               [12] 1577 	mov	r5,a
      004253 90 05 8A         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004256 E5 12            [12] 1579 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004258 F0               [24] 1580 	movx	@dptr,a
      004259 E5 13            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00425B A3               [24] 1582 	inc	dptr
      00425C F0               [24] 1583 	movx	@dptr,a
      00425D E5 14            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      00425F A3               [24] 1585 	inc	dptr
      004260 F0               [24] 1586 	movx	@dptr,a
      004261 90 05 8D         [24] 1587 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004264 E5 10            [12] 1588 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004266 F0               [24] 1589 	movx	@dptr,a
      004267 E5 11            [12] 1590 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004269 A3               [24] 1591 	inc	dptr
      00426A F0               [24] 1592 	movx	@dptr,a
      00426B 88 82            [24] 1593 	mov	dpl, r0
      00426D 8D 83            [24] 1594 	mov	dph, r5
                                   1595 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      00426F 02 40 F6         [24] 1596 	ljmp	_ak820_eeprom_write_block_xdata
      004272                       1597 00106$:
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004272 05 0E            [12] 1599 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004274 E4               [12] 1600 	clr	a
      004275 B5 0E 87         [24] 1601 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004278 05 0F            [12] 1602 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00427A 80 83            [24] 1603 	sjmp	00105$
      00427C                       1604 00107$:
                                   1605 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00427C 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1609 ;------------------------------------------------------------
                                   1610 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1611 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function eeprom_driver_erase
                                   1616 ;	-----------------------------------------
      00427D                       1617 _eeprom_driver_erase:
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00427D 12 3D E4         [24] 1619 	lcall	_ak820_nvm_flush
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004280 7F 00            [12] 1621 	mov	r7,#0x00
      004282                       1622 00111$:
      004282 BF A0 01         [24] 1623 	cjne	r7,#0xa0,00165$
      004285 22               [24] 1624 	ret
      004286                       1625 00165$:
      004286 20 09 32         [24] 1626 	jb	_storage_failed,00113$
                                   1627 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004289 8F 82            [24] 1628 	mov	dpl, r7
      00428B C0 07            [24] 1629 	push	ar7
      00428D 12 3F 64         [24] 1630 	lcall	_load_page
      004290 E5 82            [12] 1631 	mov	a, dpl
      004292 D0 07            [24] 1632 	pop	ar7
      004294 70 01            [24] 1633 	jnz	00126$
                                   1634 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004296 22               [24] 1635 	ret
      004297                       1636 00126$:
      004297 7E 00            [12] 1637 	mov	r6,#0x00
      004299                       1638 00107$:
                                   1639 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      004299 EE               [12] 1640 	mov	a,r6
      00429A 24 19            [12] 1641 	add	a, #_page_data
      00429C FC               [12] 1642 	mov	r4,a
      00429D E4               [12] 1643 	clr	a
      00429E 34 05            [12] 1644 	addc	a, #(_page_data >> 8)
      0042A0 FD               [12] 1645 	mov	r5,a
      0042A1 12 42 FF         [24] 1646 	lcall	_ak820_outline_0091
      0042A4 60 07            [24] 1647 	jz	00108$
      0042A6 12 38 4C         [24] 1648 	lcall	_ak820_outline_0117
      0042A9 E4               [12] 1649 	clr	a
      0042AA F0               [24] 1650 	movx	@dptr,a
                                   1651 ;	assignBit
      0042AB D2 08            [12] 1652 	setb	_page_dirty
      0042AD                       1653 00108$:
                                   1654 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042AD 0E               [12] 1655 	inc	r6
      0042AE BE 40 E8         [24] 1656 	cjne	r6,#0x40,00107$
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042B1 C0 07            [24] 1658 	push	ar7
      0042B3 12 3D E4         [24] 1659 	lcall	_ak820_nvm_flush
      0042B6 D0 07            [24] 1660 	pop	ar7
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042B8 0F               [12] 1662 	inc	r7
      0042B9 80 C7            [24] 1663 	sjmp	00111$
      0042BB                       1664 00113$:
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0042BB 22               [24] 1666 	ret
                                   1667 	.area CSEG    (CODE)
                                   1668 	.area CONST   (CODE)
                                   1669 	.area XINIT   (CODE)
                                   1670 	.area CABS    (ABS,CODE)
                                   1671 
                                   1672 ; Experimental exact instruction outlining.
                                   1673 	.globl _ak820_outline_0004
                                   1674 	.globl _ak820_outline_0010
                                   1675 	.globl _ak820_outline_0015
                                   1676 	.globl _ak820_outline_0016
                                   1677 	.globl _ak820_outline_0029
                                   1678 	.globl _ak820_outline_0036
                                   1679 	.globl _ak820_outline_0039
                                   1680 	.globl _ak820_outline_0050
                                   1681 	.globl _ak820_outline_0051
                                   1682 	.globl _ak820_outline_0059
                                   1683 	.globl _ak820_outline_0060
                                   1684 	.globl _ak820_outline_0064
                                   1685 	.globl _ak820_outline_0070
                                   1686 	.globl _ak820_outline_0076
                                   1687 	.globl _ak820_outline_0091
                                   1688 	.globl _ak820_outline_0092
                                   1689 	.globl _ak820_outline_0099
                                   1690 	.globl _ak820_outline_0101
                                   1691 	.globl _ak820_outline_0103
                                   1692 	.globl _ak820_outline_0104
                                   1693 	.globl _ak820_outline_0116
                                   1694 	.globl _ak820_outline_0117
                                   1695 	.globl _ak820_outline_0119
                                   1696 	.globl _ak820_outline_0120
                                   1697 	.globl _ak820_outline_0121
                                   1698 	.globl _ak820_outline_0130
                                   1699 	.globl _ak820_outline_0131
                                   1700 	.globl _ak820_outline_0133
                                   1701 	.globl _ak820_outline_0138
                                   1702 	.globl _ak820_outline_0139
                                   1703 	.globl _ak820_outline_0144
                                   1704 	.globl _ak820_outline_0152
                                   1705 	.globl _ak820_outline_0155
                                   1706 	.globl _ak820_outline_0156
                                   1707 	.globl _ak820_outline_0166
                                   1708 	.globl _ak820_outline_0178
                                   1709 	.globl _ak820_outline_0179
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0010
      0042BC                       1713 _ak820_outline_0010:
      0042BC 8E 82            [24] 1714 	mov	dpl,r6
      0042BE 8F 83            [24] 1715 	mov	dph,r7
      0042C0 A3               [24] 1716 	inc	dptr
      0042C1 A3               [24] 1717 	inc	dptr
      0042C2 A3               [24] 1718 	inc	dptr
      0042C3 A3               [24] 1719 	inc	dptr
      0042C4 A3               [24] 1720 	inc	dptr
      0042C5 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0029
      0042C6                       1725 _ak820_outline_0029:
      0042C6 F0               [24] 1726 	movx	@dptr,a
      0042C7 8E 82            [24] 1727 	mov	dpl,r6
      0042C9 8F 83            [24] 1728 	mov	dph,r7
      0042CB A3               [24] 1729 	inc	dptr
      0042CC A3               [24] 1730 	inc	dptr
      0042CD 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0036
      0042CE                       1735 _ak820_outline_0036:
      0042CE AF F0            [24] 1736 	mov	r7,b
      0042D0 AE 83            [24] 1737 	mov	r6,dph
      0042D2 E5 82            [12] 1738 	mov	a,dpl
      0042D4 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0039
      0042D5                       1743 _ak820_outline_0039:
      0042D5 EF               [12] 1744 	mov	a,r7
      0042D6 24 71            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      0042D8 F5 82            [12] 1746 	mov	dpl,a
      0042DA E4               [12] 1747 	clr	a
      0042DB 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      0042DD F5 83            [12] 1749 	mov	dph,a
      0042DF E0               [24] 1750 	movx	a,@dptr
      0042E0 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0051
      0042E1                       1755 _ak820_outline_0051:
      0042E1 8F 06            [24] 1756 	mov	ar6,r7
      0042E3 7D 00            [12] 1757 	mov	r5,#0x00
      0042E5 74 40            [12] 1758 	mov	a,#0x40
      0042E7 2E               [12] 1759 	add	a,r6
      0042E8 FE               [12] 1760 	mov	r6,a
      0042E9 74 EF            [12] 1761 	mov	a,#0xef
      0042EB 3D               [12] 1762 	addc	a,r5
      0042EC FD               [12] 1763 	mov	r5,a
      0042ED 8E 82            [24] 1764 	mov	dpl,r6
      0042EF 8D 83            [24] 1765 	mov	dph,r5
      0042F1 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0060
      0042F2                       1770 _ak820_outline_0060:
      0042F2 F0               [24] 1771 	movx	@dptr,a
      0042F3 8E 82            [24] 1772 	mov	dpl,r6
      0042F5 8F 83            [24] 1773 	mov	dph,r7
      0042F7 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0064
      0042F8                       1778 _ak820_outline_0064:
      0042F8 8D 82            [24] 1779 	mov	dpl,r5
      0042FA 8E 83            [24] 1780 	mov	dph,r6
      0042FC EC               [12] 1781 	mov	a,r4
      0042FD F0               [24] 1782 	movx	@dptr,a
      0042FE 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0091
      0042FF                       1787 _ak820_outline_0091:
      0042FF 8C 82            [24] 1788 	mov	dpl,r4
      004301 8D 83            [24] 1789 	mov	dph,r5
      004303 E0               [24] 1790 	movx	a,@dptr
      004304 22               [24] 1791 	ret
                                   1792 
                                   1793 	.area CSEG (CODE)
                                   1794 ; function ak820_outline_0092
      004305                       1795 _ak820_outline_0092:
      004305 E0               [24] 1796 	movx	a,@dptr
      004306 FD               [12] 1797 	mov	r5,a
      004307 A3               [24] 1798 	inc	dptr
      004308 E0               [24] 1799 	movx	a,@dptr
      004309 FE               [12] 1800 	mov	r6,a
      00430A 22               [24] 1801 	ret
                                   1802 
                                   1803 	.area CSEG (CODE)
                                   1804 ; function ak820_outline_0101
      00430B                       1805 _ak820_outline_0101:
      00430B EF               [12] 1806 	mov	a,r7
      00430C 24 19            [12] 1807 	add	a,#_page_data
      00430E F5 82            [12] 1808 	mov	dpl,a
      004310 E4               [12] 1809 	clr	a
      004311 34 05            [12] 1810 	addc	a,#(_page_data>>8)
      004313 F5 83            [12] 1811 	mov	dph,a
      004315 E0               [24] 1812 	movx	a,@dptr
      004316 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0116
      004317                       1817 _ak820_outline_0116:
      004317 8E 82            [24] 1818 	mov	dpl,r6
      004319 8F 83            [24] 1819 	mov	dph,r7
      00431B 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0119
      00431C                       1824 _ak820_outline_0119:
      00431C E0               [24] 1825 	movx	a,@dptr
      00431D FA               [12] 1826 	mov	r2,a
      00431E A3               [24] 1827 	inc	dptr
      00431F E0               [24] 1828 	movx	a,@dptr
      004320 FB               [12] 1829 	mov	r3,a
      004321 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0130
      004322                       1834 _ak820_outline_0130:
      004322 AE 82            [24] 1835 	mov	r6,dpl
      004324 AF 83            [24] 1836 	mov	r7,dph
      004326 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0133
      004327                       1841 _ak820_outline_0133:
      004327 2E               [12] 1842 	add	a,r6
      004328 FE               [12] 1843 	mov	r6,a
      004329 E4               [12] 1844 	clr	a
      00432A 3F               [12] 1845 	addc	a,r7
      00432B FF               [12] 1846 	mov	r7,a
      00432C 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0138
      00432D                       1851 _ak820_outline_0138:
      00432D 42 05            [12] 1852 	orl	ar5,a
      00432F EA               [12] 1853 	mov	a,r2
      004330 42 04            [12] 1854 	orl	ar4,a
      004332 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0139
      004333                       1859 _ak820_outline_0139:
      004333 8A 82            [24] 1860 	mov	dpl,r2
      004335 8B 83            [24] 1861 	mov	dph,r3
      004337 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0144
      004338                       1866 _ak820_outline_0144:
      004338 AC 82            [24] 1867 	mov	r4,dpl
      00433A AD 83            [24] 1868 	mov	r5,dph
      00433C 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0152
      00433D                       1873 _ak820_outline_0152:
      00433D 8F 82            [24] 1874 	mov	dpl,r7
      00433F 8E 83            [24] 1875 	mov	dph,r6
      004341 22               [24] 1876 	ret
                                   1877 
                                   1878 	.area CSEG (CODE)
                                   1879 ; function ak820_outline_0155
      004342                       1880 _ak820_outline_0155:
      004342 2E               [12] 1881 	add	a,r6
      004343 FC               [12] 1882 	mov	r4,a
      004344 E4               [12] 1883 	clr	a
      004345 3F               [12] 1884 	addc	a,r7
      004346 FD               [12] 1885 	mov	r5,a
      004347 22               [24] 1886 	ret
                                   1887 
                                   1888 	.area CSEG (CODE)
                                   1889 ; function ak820_outline_0156
      004348                       1890 _ak820_outline_0156:
      004348 ED               [12] 1891 	mov	a,r5
      004349 F0               [24] 1892 	movx	@dptr,a
      00434A EE               [12] 1893 	mov	a,r6
      00434B A3               [24] 1894 	inc	dptr
      00434C F0               [24] 1895 	movx	@dptr,a
      00434D 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0178
      00434E                       1900 _ak820_outline_0178:
      00434E 89 82            [24] 1901 	mov	dpl,r1
      004350 8A 83            [24] 1902 	mov	dph,r2
      004352 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0179
      004353                       1907 _ak820_outline_0179:
      004353 8C 82            [24] 1908 	mov	dpl,r4
      004355 8B 83            [24] 1909 	mov	dph,r3
      004357 22               [24] 1910 	ret
