                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         47 bits:
      000025                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00067B                         85 _eeprom_read_word_addr_10000_91:
      00067B                         86 	.ds 3
      00067E                         87 _eeprom_read_word_ret_10000_92:
      00067E                         88 	.ds 2
      000680                         89 _eeprom_read_dword_addr_10000_93:
      000680                         90 	.ds 3
      000683                         91 _eeprom_read_dword_ret_10000_94:
      000683                         92 	.ds 4
      000687                         93 _eeprom_write_byte_PARM_2:
      000687                         94 	.ds 1
      000688                         95 _eeprom_write_byte_addr_10000_95:
      000688                         96 	.ds 3
      00068B                         97 _eeprom_write_word_PARM_2:
      00068B                         98 	.ds 2
      00068D                         99 _eeprom_write_word_addr_10000_97:
      00068D                        100 	.ds 3
      000690                        101 _eeprom_write_dword_PARM_2:
      000690                        102 	.ds 4
      000694                        103 _eeprom_write_dword_addr_10000_99:
      000694                        104 	.ds 3
      000697                        105 _eeprom_update_byte_PARM_2:
      000697                        106 	.ds 1
      000698                        107 _eeprom_update_byte_addr_10000_107:
      000698                        108 	.ds 3
      00069B                        109 _eeprom_update_word_PARM_2:
      00069B                        110 	.ds 2
      00069D                        111 _eeprom_update_word_addr_10000_111:
      00069D                        112 	.ds 3
      0006A0                        113 _eeprom_update_dword_PARM_2:
      0006A0                        114 	.ds 4
      0006A4                        115 _eeprom_update_dword_addr_10000_115:
      0006A4                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004CC2                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004CC2 12 42 CE         [24]  170 	lcall	_ak820_outline_0036
      004CC5 90 06 7B         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004CC8 12 37 D7         [24]  172 	lcall	_ak820_outline_0015
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004CCB 90 06 7E         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004CCE 12 4E CE         [24]  175 	lcall	_ak820_outline_0165
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004CD1 90 06 7B         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004CD4 12 4E 7C         [24]  178 	lcall	_ak820_outline_0021
      004CD7 90 05 81         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004CDA ED               [12]  180 	mov	a,r5
      004CDB 12 37 D7         [24]  181 	lcall	_ak820_outline_0015
      004CDE 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004CE1 12 4E C0         [24]  183 	lcall	_ak820_outline_0106
      004CE4 90 06 7E         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004CE7 12 40 6A         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004CEA 90 06 7E         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004CED 12 4E B7         [24]  188 	lcall	_ak820_outline_0088
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004CF0 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004CF1                        201 _eeprom_read_dword:
      004CF1 12 42 CE         [24]  202 	lcall	_ak820_outline_0036
      004CF4 90 06 80         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004CF7 12 37 D7         [24]  204 	lcall	_ak820_outline_0015
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004CFA 90 06 83         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004CFD 12 4E 8C         [24]  207 	lcall	_ak820_outline_0048
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004D00 90 06 80         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004D03 12 4E 7C         [24]  210 	lcall	_ak820_outline_0021
      004D06 90 05 81         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004D09 ED               [12]  212 	mov	a,r5
      004D0A 12 37 D7         [24]  213 	lcall	_ak820_outline_0015
      004D0D 90 05 84         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004D10 74 04            [12]  215 	mov	a,#0x04
      004D12 12 38 57         [24]  216 	lcall	_ak820_outline_0122
      004D15 90 06 83         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D18 12 40 6A         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004D1B 90 06 83         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D1E 12 4E 95         [24]  221 	lcall	_ak820_outline_0053
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004D21 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004D22                        234 _eeprom_write_byte:
      004D22 12 42 CE         [24]  235 	lcall	_ak820_outline_0036
      004D25 90 06 88         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004D28 12 37 D7         [24]  237 	lcall	_ak820_outline_0015
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004D2B 90 06 88         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004D2E 12 4E 56         [24]  240 	lcall	_ak820_outline_0002
      004D31 74 01            [12]  241 	mov	a,#0x01
      004D33 12 38 57         [24]  242 	lcall	_ak820_outline_0122
      004D36 90 06 87         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004D39 02 40 F6         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004D3C                        256 _eeprom_write_word:
      004D3C 12 42 CE         [24]  257 	lcall	_ak820_outline_0036
      004D3F 90 06 8D         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004D42 12 37 D7         [24]  259 	lcall	_ak820_outline_0015
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004D45 90 06 8D         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004D48 12 4E 56         [24]  262 	lcall	_ak820_outline_0002
      004D4B 12 4E C0         [24]  263 	lcall	_ak820_outline_0106
      004D4E 90 06 8B         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004D51 02 40 F6         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004D54                        277 _eeprom_write_dword:
      004D54 12 42 CE         [24]  278 	lcall	_ak820_outline_0036
      004D57 90 06 94         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004D5A 12 37 D7         [24]  280 	lcall	_ak820_outline_0015
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004D5D 90 06 94         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004D60 12 4E 56         [24]  283 	lcall	_ak820_outline_0002
      004D63 74 04            [12]  284 	mov	a,#0x04
      004D65 12 38 57         [24]  285 	lcall	_ak820_outline_0122
      004D68 90 06 90         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004D6B 02 40 F6         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004D6E                        307 _eeprom_update_byte:
      004D6E C0 07            [24]  308 	push	ar7
      004D70 C0 06            [24]  309 	push	ar6
      004D72 C0 05            [24]  310 	push	ar5
      004D74 C0 04            [24]  311 	push	ar4
      004D76 12 42 CE         [24]  312 	lcall	_ak820_outline_0036
      004D79 90 06 98         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004D7C 12 37 D7         [24]  314 	lcall	_ak820_outline_0015
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004D7F 90 06 98         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004D82 12 4E 6D         [24]  317 	lcall	_ak820_outline_0003
      004D85 12 40 2F         [24]  318 	lcall	_eeprom_read_byte
      004D88 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004D8A 90 06 97         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004D8D E0               [24]  322 	movx	a,@dptr
      004D8E FE               [12]  323 	mov	r6,a
      004D8F EF               [12]  324 	mov	a,r7
      004D90 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004D93 80 36            [24]  326 	sjmp	00103$
      004D95                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004D95 90 06 98         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004D98 12 38 17         [24]  330 	lcall	_ak820_outline_0059
      004D9B A3               [24]  331 	inc	dptr
      004D9C E0               [24]  332 	movx	a,@dptr
      004D9D FF               [12]  333 	mov	r7,a
      004D9E 90 06 87         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004DA1 EE               [12]  335 	mov	a,r6
      004DA2 F0               [24]  336 	movx	@dptr,a
      004DA3 12 38 4C         [24]  337 	lcall	_ak820_outline_0117
      004DA6 8F F0            [24]  338 	mov	b, r7
      004DA8 C0 07            [24]  339 	push	ar7
      004DAA C0 06            [24]  340 	push	ar6
      004DAC C0 05            [24]  341 	push	ar5
      004DAE C0 04            [24]  342 	push	ar4
      004DB0 C0 03            [24]  343 	push	ar3
      004DB2 C0 02            [24]  344 	push	ar2
      004DB4 C0 01            [24]  345 	push	ar1
      004DB6 C0 00            [24]  346 	push	ar0
      004DB8 12 4D 22         [24]  347 	lcall	_eeprom_write_byte
      004DBB D0 00            [24]  348 	pop	ar0
      004DBD D0 01            [24]  349 	pop	ar1
      004DBF D0 02            [24]  350 	pop	ar2
      004DC1 D0 03            [24]  351 	pop	ar3
      004DC3 D0 04            [24]  352 	pop	ar4
      004DC5 D0 05            [24]  353 	pop	ar5
      004DC7 D0 06            [24]  354 	pop	ar6
      004DC9 D0 07            [24]  355 	pop	ar7
      004DCB                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      004DCB D0 04            [24]  358 	pop	ar4
      004DCD D0 05            [24]  359 	pop	ar5
      004DCF D0 06            [24]  360 	pop	ar6
      004DD1 D0 07            [24]  361 	pop	ar7
      004DD3 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      004DD4                        374 _eeprom_update_word:
      004DD4 12 42 CE         [24]  375 	lcall	_ak820_outline_0036
      004DD7 90 06 9D         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004DDA 12 37 D7         [24]  377 	lcall	_ak820_outline_0015
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004DDD 90 06 9D         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004DE0 12 4E 6D         [24]  380 	lcall	_ak820_outline_0003
      004DE3 12 4C C2         [24]  381 	lcall	_eeprom_read_word
      004DE6 12 43 22         [24]  382 	lcall	_ak820_outline_0130
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004DE9 90 06 9B         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      004DEC 12 38 17         [24]  385 	lcall	_ak820_outline_0059
      004DEF EE               [12]  386 	mov	a,r6
      004DF0 B5 04 05         [24]  387 	cjne	a,ar4,00112$
      004DF3 EF               [12]  388 	mov	a,r7
      004DF4 B5 05 01         [24]  389 	cjne	a,ar5,00112$
      004DF7 22               [24]  390 	ret
      004DF8                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004DF8 90 06 9D         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004DFB E0               [24]  394 	movx	a,@dptr
      004DFC FB               [12]  395 	mov	r3,a
      004DFD A3               [24]  396 	inc	dptr
      004DFE 12 37 F8         [24]  397 	lcall	_ak820_outline_0050
      004E01 90 06 8B         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      004E04 12 38 1D         [24]  399 	lcall	_ak820_outline_0070
      004E07 8B 82            [24]  400 	mov	dpl, r3
      004E09 8E 83            [24]  401 	mov	dph, r6
      004E0B 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      004E0D 02 4D 3C         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      004E10                        416 _eeprom_update_dword:
      004E10 12 42 CE         [24]  417 	lcall	_ak820_outline_0036
      004E13 90 06 A4         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E16 12 37 D7         [24]  419 	lcall	_ak820_outline_0015
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004E19 90 06 A4         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E1C 12 4E 6D         [24]  422 	lcall	_ak820_outline_0003
      004E1F 12 4C F1         [24]  423 	lcall	_eeprom_read_dword
      004E22 12 4E A6         [24]  424 	lcall	_ak820_outline_0056
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004E25 90 06 A0         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      004E28 E0               [24]  427 	movx	a,@dptr
      004E29 F8               [12]  428 	mov	r0,a
      004E2A A3               [24]  429 	inc	dptr
      004E2B 12 4E AE         [24]  430 	lcall	_ak820_outline_0087
      004E2E EC               [12]  431 	mov	a,r4
      004E2F B5 00 0D         [24]  432 	cjne	a,ar0,00112$
      004E32 ED               [12]  433 	mov	a,r5
      004E33 B5 01 09         [24]  434 	cjne	a,ar1,00112$
      004E36 EE               [12]  435 	mov	a,r6
      004E37 B5 02 05         [24]  436 	cjne	a,ar2,00112$
      004E3A EF               [12]  437 	mov	a,r7
      004E3B B5 03 01         [24]  438 	cjne	a,ar3,00112$
      004E3E 22               [24]  439 	ret
      004E3F                        440 00112$:
                                    441 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004E3F 90 06 A4         [24]  442 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E42 12 4E 7C         [24]  443 	lcall	_ak820_outline_0021
      004E45 90 06 90         [24]  444 	mov	dptr,#_eeprom_write_dword_PARM_2
      004E48 E8               [12]  445 	mov	a,r0
      004E49 F0               [24]  446 	movx	@dptr,a
      004E4A E9               [12]  447 	mov	a,r1
      004E4B A3               [24]  448 	inc	dptr
      004E4C 12 4E C7         [24]  449 	lcall	_ak820_outline_0150
      004E4F F0               [24]  450 	movx	@dptr,a
      004E50 12 4E 85         [24]  451 	lcall	_ak820_outline_0043
                                    452 ;	drivers/eeprom/eeprom_driver.c:101: }
      004E53 02 4D 54         [24]  453 	ljmp	_eeprom_write_dword
                                    454 	.area CSEG    (CODE)
                                    455 	.area CONST   (CODE)
                                    456 	.area XINIT   (CODE)
                                    457 	.area CABS    (ABS,CODE)
                                    458 
                                    459 ; Experimental exact instruction outlining.
                                    460 	.globl _ak820_outline_0002
                                    461 	.globl _ak820_outline_0003
                                    462 	.globl _ak820_outline_0015
                                    463 	.globl _ak820_outline_0021
                                    464 	.globl _ak820_outline_0036
                                    465 	.globl _ak820_outline_0043
                                    466 	.globl _ak820_outline_0048
                                    467 	.globl _ak820_outline_0050
                                    468 	.globl _ak820_outline_0053
                                    469 	.globl _ak820_outline_0056
                                    470 	.globl _ak820_outline_0059
                                    471 	.globl _ak820_outline_0070
                                    472 	.globl _ak820_outline_0087
                                    473 	.globl _ak820_outline_0088
                                    474 	.globl _ak820_outline_0106
                                    475 	.globl _ak820_outline_0117
                                    476 	.globl _ak820_outline_0122
                                    477 	.globl _ak820_outline_0130
                                    478 	.globl _ak820_outline_0150
                                    479 	.globl _ak820_outline_0165
                                    480 
                                    481 	.area CSEG (CODE)
                                    482 ; function ak820_outline_0002
      004E56                        483 _ak820_outline_0002:
      004E56 E0               [24]  484 	movx	a,@dptr
      004E57 FD               [12]  485 	mov	r5,a
      004E58 A3               [24]  486 	inc	dptr
      004E59 E0               [24]  487 	movx	a,@dptr
      004E5A FE               [12]  488 	mov	r6,a
      004E5B A3               [24]  489 	inc	dptr
      004E5C E0               [24]  490 	movx	a,@dptr
      004E5D FF               [12]  491 	mov	r7,a
      004E5E 90 05 8A         [24]  492 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004E61 ED               [12]  493 	mov	a,r5
      004E62 F0               [24]  494 	movx	@dptr,a
      004E63 EE               [12]  495 	mov	a,r6
      004E64 A3               [24]  496 	inc	dptr
      004E65 F0               [24]  497 	movx	@dptr,a
      004E66 EF               [12]  498 	mov	a,r7
      004E67 A3               [24]  499 	inc	dptr
      004E68 F0               [24]  500 	movx	@dptr,a
      004E69 90 05 8D         [24]  501 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004E6C 22               [24]  502 	ret
                                    503 
                                    504 	.area CSEG (CODE)
                                    505 ; function ak820_outline_0003
      004E6D                        506 _ak820_outline_0003:
      004E6D E0               [24]  507 	movx	a,@dptr
      004E6E FD               [12]  508 	mov	r5,a
      004E6F A3               [24]  509 	inc	dptr
      004E70 E0               [24]  510 	movx	a,@dptr
      004E71 FE               [12]  511 	mov	r6,a
      004E72 A3               [24]  512 	inc	dptr
      004E73 E0               [24]  513 	movx	a,@dptr
      004E74 FF               [12]  514 	mov	r7,a
      004E75 8D 82            [24]  515 	mov	dpl,r5
      004E77 8E 83            [24]  516 	mov	dph,r6
      004E79 8F F0            [24]  517 	mov	b,r7
      004E7B 22               [24]  518 	ret
                                    519 
                                    520 	.area CSEG (CODE)
                                    521 ; function ak820_outline_0021
      004E7C                        522 _ak820_outline_0021:
      004E7C E0               [24]  523 	movx	a,@dptr
      004E7D FD               [12]  524 	mov	r5,a
      004E7E A3               [24]  525 	inc	dptr
      004E7F E0               [24]  526 	movx	a,@dptr
      004E80 FE               [12]  527 	mov	r6,a
      004E81 A3               [24]  528 	inc	dptr
      004E82 E0               [24]  529 	movx	a,@dptr
      004E83 FF               [12]  530 	mov	r7,a
      004E84 22               [24]  531 	ret
                                    532 
                                    533 	.area CSEG (CODE)
                                    534 ; function ak820_outline_0043
      004E85                        535 _ak820_outline_0043:
      004E85 8D 82            [24]  536 	mov	dpl,r5
      004E87 8E 83            [24]  537 	mov	dph,r6
      004E89 8F F0            [24]  538 	mov	b,r7
      004E8B 22               [24]  539 	ret
                                    540 
                                    541 	.area CSEG (CODE)
                                    542 ; function ak820_outline_0048
      004E8C                        543 _ak820_outline_0048:
      004E8C E4               [12]  544 	clr	a
      004E8D F0               [24]  545 	movx	@dptr,a
      004E8E A3               [24]  546 	inc	dptr
      004E8F F0               [24]  547 	movx	@dptr,a
      004E90 A3               [24]  548 	inc	dptr
      004E91 F0               [24]  549 	movx	@dptr,a
      004E92 A3               [24]  550 	inc	dptr
      004E93 F0               [24]  551 	movx	@dptr,a
      004E94 22               [24]  552 	ret
                                    553 
                                    554 	.area CSEG (CODE)
                                    555 ; function ak820_outline_0053
      004E95                        556 _ak820_outline_0053:
      004E95 E0               [24]  557 	movx	a,@dptr
      004E96 FC               [12]  558 	mov	r4,a
      004E97 A3               [24]  559 	inc	dptr
      004E98 E0               [24]  560 	movx	a,@dptr
      004E99 FD               [12]  561 	mov	r5,a
      004E9A A3               [24]  562 	inc	dptr
      004E9B E0               [24]  563 	movx	a,@dptr
      004E9C FE               [12]  564 	mov	r6,a
      004E9D A3               [24]  565 	inc	dptr
      004E9E E0               [24]  566 	movx	a,@dptr
      004E9F 8C 82            [24]  567 	mov	dpl,r4
      004EA1 8D 83            [24]  568 	mov	dph,r5
      004EA3 8E F0            [24]  569 	mov	b,r6
      004EA5 22               [24]  570 	ret
                                    571 
                                    572 	.area CSEG (CODE)
                                    573 ; function ak820_outline_0056
      004EA6                        574 _ak820_outline_0056:
      004EA6 AC 82            [24]  575 	mov	r4,dpl
      004EA8 AD 83            [24]  576 	mov	r5,dph
      004EAA AE F0            [24]  577 	mov	r6,b
      004EAC FF               [12]  578 	mov	r7,a
      004EAD 22               [24]  579 	ret
                                    580 
                                    581 	.area CSEG (CODE)
                                    582 ; function ak820_outline_0087
      004EAE                        583 _ak820_outline_0087:
      004EAE E0               [24]  584 	movx	a,@dptr
      004EAF F9               [12]  585 	mov	r1,a
      004EB0 A3               [24]  586 	inc	dptr
      004EB1 E0               [24]  587 	movx	a,@dptr
      004EB2 FA               [12]  588 	mov	r2,a
      004EB3 A3               [24]  589 	inc	dptr
      004EB4 E0               [24]  590 	movx	a,@dptr
      004EB5 FB               [12]  591 	mov	r3,a
      004EB6 22               [24]  592 	ret
                                    593 
                                    594 	.area CSEG (CODE)
                                    595 ; function ak820_outline_0088
      004EB7                        596 _ak820_outline_0088:
      004EB7 E0               [24]  597 	movx	a,@dptr
      004EB8 FE               [12]  598 	mov	r6,a
      004EB9 A3               [24]  599 	inc	dptr
      004EBA E0               [24]  600 	movx	a,@dptr
      004EBB 8E 82            [24]  601 	mov	dpl,r6
      004EBD F5 83            [12]  602 	mov	dph,a
      004EBF 22               [24]  603 	ret
                                    604 
                                    605 	.area CSEG (CODE)
                                    606 ; function ak820_outline_0106
      004EC0                        607 _ak820_outline_0106:
      004EC0 74 02            [12]  608 	mov	a,#0x02
      004EC2 F0               [24]  609 	movx	@dptr,a
      004EC3 E4               [12]  610 	clr	a
      004EC4 A3               [24]  611 	inc	dptr
      004EC5 F0               [24]  612 	movx	@dptr,a
      004EC6 22               [24]  613 	ret
                                    614 
                                    615 	.area CSEG (CODE)
                                    616 ; function ak820_outline_0150
      004EC7                        617 _ak820_outline_0150:
      004EC7 F0               [24]  618 	movx	@dptr,a
      004EC8 EA               [12]  619 	mov	a,r2
      004EC9 A3               [24]  620 	inc	dptr
      004ECA F0               [24]  621 	movx	@dptr,a
      004ECB EB               [12]  622 	mov	a,r3
      004ECC A3               [24]  623 	inc	dptr
      004ECD 22               [24]  624 	ret
                                    625 
                                    626 	.area CSEG (CODE)
                                    627 ; function ak820_outline_0165
      004ECE                        628 _ak820_outline_0165:
      004ECE E4               [12]  629 	clr	a
      004ECF F0               [24]  630 	movx	@dptr,a
      004ED0 A3               [24]  631 	inc	dptr
      004ED1 F0               [24]  632 	movx	@dptr,a
      004ED2 22               [24]  633 	ret
