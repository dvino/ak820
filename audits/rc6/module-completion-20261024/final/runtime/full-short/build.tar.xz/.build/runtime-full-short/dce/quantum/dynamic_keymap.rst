                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000028                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000028                        588 	.ds 2
      00002A                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002A                        590 	.ds 1
      00002B                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002B                        592 	.ds 1
      00002C                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002C                        594 	.ds 2
      00002E                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002E                        596 	.ds 2
      000030                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000030                        598 	.ds 1
      000031                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000031                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000022                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000022                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000ACE                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000ACE                        628 	.ds 1
      000ACF                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000ACF                        630 	.ds 1
      000AD0                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_364:
      000AD0                        632 	.ds 1
      000AD1                        633 _dynamic_keymap_get_keycode_PARM_2:
      000AD1                        634 	.ds 1
      000AD2                        635 _dynamic_keymap_get_keycode_PARM_3:
      000AD2                        636 	.ds 1
      000AD3                        637 _dynamic_keymap_get_keycode_layer_10000_366:
      000AD3                        638 	.ds 1
      000AD4                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AD4                        640 	.ds 1
      000AD5                        641 _dynamic_keymap_set_keycode_PARM_3:
      000AD5                        642 	.ds 1
      000AD6                        643 _dynamic_keymap_set_keycode_PARM_4:
      000AD6                        644 	.ds 2
      000AD8                        645 _dynamic_keymap_set_keycode_layer_10000_370:
      000AD8                        646 	.ds 1
      000AD9                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000AD9                        648 	.ds 1
      000ADA                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_374:
      000ADA                        650 	.ds 1
      000ADB                        651 _dynamic_keymap_get_encoder_PARM_2:
      000ADB                        652 	.ds 1
      000ADC                        653 _dynamic_keymap_get_encoder_PARM_3:
      000ADC                        654 	.ds 1
      000ADD                        655 _dynamic_keymap_get_encoder_layer_10000_376:
      000ADD                        656 	.ds 1
      000ADE                        657 _dynamic_keymap_set_encoder_PARM_2:
      000ADE                        658 	.ds 1
      000ADF                        659 _dynamic_keymap_set_encoder_PARM_3:
      000ADF                        660 	.ds 1
      000AE0                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AE0                        662 	.ds 2
      000AE2                        663 _dynamic_keymap_set_encoder_layer_10000_380:
      000AE2                        664 	.ds 1
      000AE3                        665 _dynamic_keymap_get_combo_PARM_2:
      000AE3                        666 	.ds 3
      000AE6                        667 _dynamic_keymap_get_combo_index_10000_384:
      000AE6                        668 	.ds 1
      000AE7                        669 _dynamic_keymap_set_combo_PARM_2:
      000AE7                        670 	.ds 3
      000AEA                        671 _dynamic_keymap_set_combo_index_10000_390:
      000AEA                        672 	.ds 1
      000AEB                        673 _dynamic_keymap_set_combo_stored_10002_395:
      000AEB                        674 	.ds 10
      000AF5                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_398:
      000AF5                        676 	.ds 1
      000AF6                        677 _dynamic_keymap_reset_combo_10001_407:
      000AF6                        678 	.ds 10
      000B00                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B00                        680 	.ds 2
      000B02                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B02                        682 	.ds 2
      000B04                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B04                        684 	.ds 2
      000B06                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B06                        686 	.ds 3
      000B09                        687 _ak820_dynamic_read_buffer_base_10000_409:
      000B09                        688 	.ds 2
      000B0B                        689 _ak820_dynamic_read_buffer_available_10000_410:
      000B0B                        690 	.ds 1
      000B0C                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B0C                        692 	.ds 2
      000B0E                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B0E                        694 	.ds 3
      000B11                        695 _dynamic_keymap_get_buffer_offset_10000_416:
      000B11                        696 	.ds 2
      000B13                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B13                        698 	.ds 2
      000B15                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B15                        700 	.ds 3
      000B18                        701 _dynamic_keymap_set_buffer_offset_10000_418:
      000B18                        702 	.ds 2
      000B1A                        703 _dynamic_keymap_set_buffer_chk_offset_30001_425:
      000B1A                        704 	.ds 1
      000B1B                        705 _dynamic_keymap_set_buffer_chk_sz_30001_425:
      000B1B                        706 	.ds 1
      000B1C                        707 _dynamic_keymap_set_buffer_i_40001_432:
      000B1C                        708 	.ds 1
      000B1D                        709 _keycode_at_keymap_location_PARM_2:
      000B1D                        710 	.ds 1
      000B1E                        711 _keycode_at_keymap_location_PARM_3:
      000B1E                        712 	.ds 1
      000B1F                        713 _keycode_at_keymap_location_layer_num_10000_436:
      000B1F                        714 	.ds 1
      000B20                        715 _keycode_at_encodermap_location_PARM_2:
      000B20                        716 	.ds 1
      000B21                        717 _keycode_at_encodermap_location_PARM_3:
      000B21                        718 	.ds 1
      000B22                        719 _keycode_at_encodermap_location_layer_num_10000_440:
      000B22                        720 	.ds 1
      000B23                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B23                        722 	.ds 2
      000B25                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B25                        724 	.ds 3
      000B28                        725 _dynamic_keymap_macro_get_buffer_offset_10000_448:
      000B28                        726 	.ds 2
      000B2A                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B2A                        728 	.ds 2
      000B2C                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B2C                        730 	.ds 3
      000B2F                        731 _dynamic_keymap_macro_set_buffer_offset_10000_450:
      000B2F                        732 	.ds 2
      000B31                        733 _decode_keycode_kc_10000_454:
      000B31                        734 	.ds 2
      000B33                        735 _dynamic_keymap_macro_send_id_10000_457:
      000B33                        736 	.ds 1
      000B34                        737 _dynamic_keymap_macro_send_sending_10000_458:
      000B34                        738 	.ds 1
      000B35                        739 _dynamic_keymap_macro_send_p_10001_463:
      000B35                        740 	.ds 2
      000B37                        741 _dynamic_keymap_macro_send_data_10003_470:
      000B37                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      00822F                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      00822F 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      008232 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_364'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008233                        810 _dynamic_keymap_key_to_eeprom_address:
      008233 E5 82            [12]  811 	mov	a,dpl
      008235 90 0A D0         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_364
      008238 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008239 E0               [24]  815 	movx	a,@dptr
      00823A FF               [12]  816 	mov	r7,a
      00823B 7E 00            [12]  817 	mov	r6,#0x00
      00823D 74 40            [12]  818 	mov	a,#0x40
      00823F 12 43 27         [24]  819 	lcall	_ak820_outline_0133
      008242 7D 00            [12]  820 	mov	r5,#0x00
      008244 90 0A CE         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008247 E0               [24]  822 	movx	a,@dptr
      008248 75 F0 10         [24]  823 	mov	b,#0x10
      00824B A4               [48]  824 	mul	ab
      00824C 2E               [12]  825 	add	a, r6
      00824D FE               [12]  826 	mov	r6,a
      00824E EF               [12]  827 	mov	a,r7
      00824F 35 F0            [12]  828 	addc	a, b
      008251 FF               [12]  829 	mov	r7,a
      008252 90 0A CF         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008255 E0               [24]  831 	movx	a,@dptr
      008256 7C 00            [12]  832 	mov	r4,#0x00
      008258 25 E0            [12]  833 	add	a,acc
      00825A FB               [12]  834 	mov	r3,a
      00825B EC               [12]  835 	mov	a,r4
      00825C 33               [12]  836 	rlc	a
      00825D FC               [12]  837 	mov	r4,a
      00825E EB               [12]  838 	mov	a,r3
      00825F 2E               [12]  839 	add	a, r6
      008260 FE               [12]  840 	mov	r6,a
      008261 EC               [12]  841 	mov	a,r4
      008262 3F               [12]  842 	addc	a, r7
      008263 FF               [12]  843 	mov	r7,a
      008264 12 43 17         [24]  844 	lcall	_ak820_outline_0116
      008267 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      008269 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_366'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_369'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_369'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      00826A                        861 _dynamic_keymap_get_keycode:
      00826A E5 82            [12]  862 	mov	a,dpl
      00826C 90 0A D3         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_366
      00826F F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008270 E0               [24]  866 	movx	a,@dptr
      008271 FF               [12]  867 	mov	r7,a
      008272 BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      008275                        869 00121$:
      008275 50 14            [24]  870 	jnc	00101$
      008277 90 0A D1         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00827A E0               [24]  872 	movx	a,@dptr
      00827B FE               [12]  873 	mov	r6,a
      00827C BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      00827F                        875 00123$:
      00827F 50 0A            [24]  876 	jnc	00101$
      008281 90 0A D2         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008284 E0               [24]  878 	movx	a,@dptr
      008285 FD               [12]  879 	mov	r5,a
      008286 BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      008289                        881 00125$:
      008289 40 04            [24]  882 	jc	00102$
      00828B                        883 00101$:
      00828B 90 00 00         [24]  884 	mov	dptr,#0x0000
      00828E 22               [24]  885 	ret
      00828F                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00828F 12 8C C7         [24]  888 	lcall	_ak820_outline_0095
      008292 51 33            [12]  889 	acall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008294 12 8C D4         [24]  891 	lcall	_ak820_outline_0112
      008297 12 40 2F         [24]  892 	lcall	_eeprom_read_byte
      00829A AB 82            [24]  893 	mov	r3,dpl
      00829C 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      00829E 0D               [12]  896 	inc	r5
      00829F BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      0082A2 0E               [12]  898 	inc	r6
      0082A3                        899 00127$:
      0082A3 12 4E 85         [24]  900 	lcall	_ak820_outline_0043
      0082A6 12 40 2F         [24]  901 	lcall	_eeprom_read_byte
      0082A9 AF 82            [24]  902 	mov	r7, dpl
      0082AB 7E 00            [12]  903 	mov	r6,#0x00
      0082AD EF               [12]  904 	mov	a,r7
      0082AE 42 04            [12]  905 	orl	ar4,a
      0082B0 EE               [12]  906 	mov	a,r6
      0082B1 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      0082B3 12 43 53         [24]  909 	lcall	_ak820_outline_0179
                                    910 ;	quantum/dynamic_keymap.c:215: }
      0082B6 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_370'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_373'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      0082B7                        925 _dynamic_keymap_set_keycode:
      0082B7 E5 82            [12]  926 	mov	a,dpl
      0082B9 90 0A D8         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_370
      0082BC F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      0082BD E0               [24]  930 	movx	a,@dptr
      0082BE FF               [12]  931 	mov	r7,a
      0082BF BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      0082C2                        933 00121$:
      0082C2 50 14            [24]  934 	jnc	00101$
      0082C4 90 0A D4         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0082C7 E0               [24]  936 	movx	a,@dptr
      0082C8 FE               [12]  937 	mov	r6,a
      0082C9 BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      0082CC                        939 00123$:
      0082CC 50 0A            [24]  940 	jnc	00101$
      0082CE 90 0A D5         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0082D1 E0               [24]  942 	movx	a,@dptr
      0082D2 FD               [12]  943 	mov	r5,a
      0082D3 BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      0082D6                        945 00125$:
      0082D6 40 01            [24]  946 	jc	00102$
      0082D8                        947 00101$:
      0082D8 22               [24]  948 	ret
      0082D9                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0082D9 12 8C C7         [24]  951 	lcall	_ak820_outline_0095
      0082DC 51 33            [12]  952 	acall	_dynamic_keymap_key_to_eeprom_address
      0082DE 12 8C D4         [24]  953 	lcall	_ak820_outline_0112
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0082E1 90 0A D6         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0082E4 E0               [24]  956 	movx	a,@dptr
      0082E5 FB               [12]  957 	mov	r3,a
      0082E6 A3               [24]  958 	inc	dptr
      0082E7 E0               [24]  959 	movx	a,@dptr
      0082E8 90 06 97         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      0082EB F0               [24]  961 	movx	@dptr,a
      0082EC 12 4E 85         [24]  962 	lcall	_ak820_outline_0043
      0082EF 12 4D 6E         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0082F2 0D               [12]  965 	inc	r5
      0082F3 BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      0082F6 0E               [12]  967 	inc	r6
      0082F7                        968 00127$:
      0082F7 90 06 97         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      0082FA EB               [12]  970 	mov	a,r3
      0082FB F0               [24]  971 	movx	@dptr,a
      0082FC 12 4E 85         [24]  972 	lcall	_ak820_outline_0043
                                    973 ;	quantum/dynamic_keymap.c:223: }
      0082FF 02 4D 6E         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      008302                        985 _dynamic_keymap_encoder_to_eeprom_address:
      008302 E5 82            [12]  986 	mov	a,dpl
      008304 90 0A DA         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374
      008307 F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008308 E0               [24]  990 	movx	a,@dptr
      008309 75 F0 04         [24]  991 	mov	b,#0x04
      00830C A4               [48]  992 	mul	ab
      00830D 24 40            [12]  993 	add	a, #0x40
      00830F FD               [12]  994 	mov	r5,a
      008310 74 06            [12]  995 	mov	a,#0x06
      008312 35 F0            [12]  996 	addc	a, b
      008314 FE               [12]  997 	mov	r6,a
      008315 7F 00            [12]  998 	mov	r7,#0x00
      008317 90 0A D9         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00831A E0               [24] 1000 	movx	a,@dptr
      00831B 75 F0 04         [24] 1001 	mov	b,#0x04
      00831E A4               [48] 1002 	mul	ab
      00831F 2D               [12] 1003 	add	a, r5
      008320 FD               [12] 1004 	mov	r5,a
      008321 EE               [12] 1005 	mov	a,r6
      008322 35 F0            [12] 1006 	addc	a, b
      008324 FE               [12] 1007 	mov	r6,a
      008325 12 4E 85         [24] 1008 	lcall	_ak820_outline_0043
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      008328 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_376'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_379'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_379'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      008329                       1024 _dynamic_keymap_get_encoder:
      008329 E5 82            [12] 1025 	mov	a,dpl
      00832B 90 0A DD         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_376
      00832E F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      00832F E0               [24] 1029 	movx	a,@dptr
      008330 FF               [12] 1030 	mov	r7,a
      008331 BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      008334                       1032 00131$:
      008334 50 0A            [24] 1033 	jnc	00101$
      008336 90 0A DB         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008339 E0               [24] 1035 	movx	a,@dptr
      00833A FE               [12] 1036 	mov	r6,a
      00833B BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      00833E                       1038 00133$:
      00833E 40 04            [24] 1039 	jc	00102$
      008340                       1040 00101$:
      008340 90 00 00         [24] 1041 	mov	dptr,#0x0000
      008343 22               [24] 1042 	ret
      008344                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008344 90 0A D9         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008347 E4               [12] 1046 	clr	a
      008348 F0               [24] 1047 	movx	@dptr,a
      008349 8F 82            [24] 1048 	mov	dpl, r7
      00834B 71 02            [12] 1049 	acall	_dynamic_keymap_encoder_to_eeprom_address
      00834D 12 8C D4         [24] 1050 	lcall	_ak820_outline_0112
                                   1051 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008350 90 0A DC         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008353 E0               [24] 1053 	movx	a,@dptr
      008354 FC               [12] 1054 	mov	r4,a
      008355 E0               [24] 1055 	movx	a,@dptr
      008356 60 04            [24] 1056 	jz	00106$
      008358 7B 00            [12] 1057 	mov	r3,#0x00
      00835A 80 02            [24] 1058 	sjmp	00107$
      00835C                       1059 00106$:
      00835C 7B 02            [12] 1060 	mov	r3,#0x02
      00835E                       1061 00107$:
      00835E EB               [12] 1062 	mov	a,r3
      00835F 12 8C A5         [24] 1063 	lcall	_ak820_outline_0024
      008362 12 40 2F         [24] 1064 	lcall	_eeprom_read_byte
      008365 AA 82            [24] 1065 	mov	r2,dpl
      008367 7B 00            [12] 1066 	mov	r3,#0x00
                                   1067 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008369 EC               [12] 1068 	mov	a,r4
      00836A 60 04            [24] 1069 	jz	00108$
      00836C 7C 00            [12] 1070 	mov	r4,#0x00
      00836E 80 02            [24] 1071 	sjmp	00109$
      008370                       1072 00108$:
      008370 7C 02            [12] 1073 	mov	r4,#0x02
      008372                       1074 00109$:
      008372 EC               [12] 1075 	mov	a,r4
      008373 12 38 6C         [24] 1076 	lcall	_ak820_outline_0154
      008376 0D               [12] 1077 	inc	r5
      008377 BD 00 01         [24] 1078 	cjne	r5,#0x00,00137$
      00837A 0E               [12] 1079 	inc	r6
      00837B                       1080 00137$:
      00837B 12 4E 85         [24] 1081 	lcall	_ak820_outline_0043
      00837E 12 40 2F         [24] 1082 	lcall	_eeprom_read_byte
      008381 AF 82            [24] 1083 	mov	r7, dpl
      008383 7E 00            [12] 1084 	mov	r6,#0x00
      008385 EF               [12] 1085 	mov	a,r7
      008386 42 03            [12] 1086 	orl	ar3,a
      008388 EE               [12] 1087 	mov	a,r6
      008389 42 02            [12] 1088 	orl	ar2,a
                                   1089 ;	quantum/dynamic_keymap.c:236: return keycode;
      00838B 8B 82            [24] 1090 	mov	dpl, r3
      00838D 8A 83            [24] 1091 	mov	dph, r2
                                   1092 ;	quantum/dynamic_keymap.c:237: }
      00838F 22               [24] 1093 	ret
                                   1094 ;------------------------------------------------------------
                                   1095 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1096 ;------------------------------------------------------------
                                   1097 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1098 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1099 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1100 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1101 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_380'
                                   1102 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_383'
                                   1103 ;------------------------------------------------------------
                                   1104 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1105 ;	-----------------------------------------
                                   1106 ;	 function dynamic_keymap_set_encoder
                                   1107 ;	-----------------------------------------
      008390                       1108 _dynamic_keymap_set_encoder:
      008390 E5 82            [12] 1109 	mov	a,dpl
      008392 90 0A E2         [24] 1110 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_380
      008395 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008396 E0               [24] 1113 	movx	a,@dptr
      008397 FF               [12] 1114 	mov	r7,a
      008398 BF 06 00         [24] 1115 	cjne	r7,#0x06,00131$
      00839B                       1116 00131$:
      00839B 50 0A            [24] 1117 	jnc	00101$
      00839D 90 0A DE         [24] 1118 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0083A0 E0               [24] 1119 	movx	a,@dptr
      0083A1 FE               [12] 1120 	mov	r6,a
      0083A2 BE 01 00         [24] 1121 	cjne	r6,#0x01,00133$
      0083A5                       1122 00133$:
      0083A5 40 01            [24] 1123 	jc	00102$
      0083A7                       1124 00101$:
      0083A7 22               [24] 1125 	ret
      0083A8                       1126 00102$:
                                   1127 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0083A8 90 0A D9         [24] 1128 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0083AB E4               [12] 1129 	clr	a
      0083AC F0               [24] 1130 	movx	@dptr,a
      0083AD 8F 82            [24] 1131 	mov	dpl, r7
      0083AF 71 02            [12] 1132 	acall	_dynamic_keymap_encoder_to_eeprom_address
      0083B1 12 8C D4         [24] 1133 	lcall	_ak820_outline_0112
                                   1134 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      0083B4 90 0A DF         [24] 1135 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0083B7 E0               [24] 1136 	movx	a,@dptr
      0083B8 FC               [12] 1137 	mov	r4,a
      0083B9 E0               [24] 1138 	movx	a,@dptr
      0083BA 60 04            [24] 1139 	jz	00106$
      0083BC 7B 00            [12] 1140 	mov	r3,#0x00
      0083BE 80 02            [24] 1141 	sjmp	00107$
      0083C0                       1142 00106$:
      0083C0 7B 02            [12] 1143 	mov	r3,#0x02
      0083C2                       1144 00107$:
      0083C2 EB               [12] 1145 	mov	a,r3
      0083C3 12 8C E6         [24] 1146 	lcall	_ak820_outline_0132
      0083C6 8F 03            [24] 1147 	mov	ar3,r7
      0083C8 90 0A E0         [24] 1148 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0083CB E0               [24] 1149 	movx	a,@dptr
      0083CC F5 28            [12] 1150 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      0083CE A3               [24] 1151 	inc	dptr
      0083CF E0               [24] 1152 	movx	a,@dptr
      0083D0 F5 29            [12] 1153 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      0083D2 90 06 97         [24] 1154 	mov	dptr,#_eeprom_update_byte_PARM_2
      0083D5 F0               [24] 1155 	movx	@dptr,a
      0083D6 12 43 4E         [24] 1156 	lcall	_ak820_outline_0178
      0083D9 8B F0            [24] 1157 	mov	b, r3
      0083DB 12 4D 6E         [24] 1158 	lcall	_eeprom_update_byte
                                   1159 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0083DE EC               [12] 1160 	mov	a,r4
      0083DF 60 04            [24] 1161 	jz	00108$
      0083E1 7C 00            [12] 1162 	mov	r4,#0x00
      0083E3 80 02            [24] 1163 	sjmp	00109$
      0083E5                       1164 00108$:
      0083E5 7C 02            [12] 1165 	mov	r4,#0x02
      0083E7                       1166 00109$:
      0083E7 EC               [12] 1167 	mov	a,r4
      0083E8 12 38 6C         [24] 1168 	lcall	_ak820_outline_0154
      0083EB 0D               [12] 1169 	inc	r5
      0083EC BD 00 01         [24] 1170 	cjne	r5,#0x00,00137$
      0083EF 0E               [12] 1171 	inc	r6
      0083F0                       1172 00137$:
      0083F0 90 06 97         [24] 1173 	mov	dptr,#_eeprom_update_byte_PARM_2
      0083F3 E5 28            [12] 1174 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      0083F5 F0               [24] 1175 	movx	@dptr,a
      0083F6 12 4E 85         [24] 1176 	lcall	_ak820_outline_0043
                                   1177 ;	quantum/dynamic_keymap.c:245: }
      0083F9 02 4D 6E         [24] 1178 	ljmp	_eeprom_update_byte
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1183 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1184 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_384'
                                   1185 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_385'
                                   1186 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_387'
                                   1187 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_388'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function dynamic_keymap_get_combo
                                   1192 ;	-----------------------------------------
      0083FC                       1193 _dynamic_keymap_get_combo:
      0083FC E5 82            [12] 1194 	mov	a,dpl
      0083FE 90 0A E6         [24] 1195 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      008401 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008402 90 0A E3         [24] 1198 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008405 12 37 F8         [24] 1199 	lcall	_ak820_outline_0050
                                   1200 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008408 90 0A E6         [24] 1201 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      00840B E0               [24] 1202 	movx	a,@dptr
      00840C FD               [12] 1203 	mov	r5,a
      00840D BD 08 00         [24] 1204 	cjne	r5,#0x08,00132$
      008410                       1205 00132$:
      008410 40 04            [24] 1206 	jc	00102$
                                   1207 ;	quantum/dynamic_keymap.c:315: return -1;
      008412 90 FF FF         [24] 1208 	mov	dptr,#0xffff
      008415 22               [24] 1209 	ret
      008416                       1210 00102$:
                                   1211 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008416 12 8C B3         [24] 1212 	lcall	_ak820_outline_0078
                                   1213 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008419 8E 02            [24] 1214 	mov	ar2,r6
      00841B 8F 03            [24] 1215 	mov	ar3,r7
      00841D 90 05 81         [24] 1216 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008420 12 38 1D         [24] 1217 	lcall	_ak820_outline_0070
      008423 E4               [12] 1218 	clr	a
      008424 A3               [24] 1219 	inc	dptr
      008425 F0               [24] 1220 	movx	@dptr,a
      008426 90 05 84         [24] 1221 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008429 74 0A            [12] 1222 	mov	a,#0x0a
      00842B 12 38 57         [24] 1223 	lcall	_ak820_outline_0122
      00842E 12 43 33         [24] 1224 	lcall	_ak820_outline_0139
      008431 C0 07            [24] 1225 	push	ar7
      008433 C0 06            [24] 1226 	push	ar6
      008435 12 40 6A         [24] 1227 	lcall	_ak820_eeprom_read_block_xdata
      008438 D0 06            [24] 1228 	pop	ar6
      00843A D0 07            [24] 1229 	pop	ar7
                                   1230 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      00843C 74 04            [12] 1231 	mov	a,#0x04
      00843E 12 47 D5         [24] 1232 	lcall	_ak820_outline_0011
      008441 FA               [12] 1233 	mov	r2,a
      008442 A3               [24] 1234 	inc	dptr
      008443 E0               [24] 1235 	movx	a,@dptr
      008444 FB               [12] 1236 	mov	r3,a
      008445 BA 20 14         [24] 1237 	cjne	r2,#0x20,00108$
      008448 BB 08 11         [24] 1238 	cjne	r3,#0x08,00108$
      00844B 74 06            [12] 1239 	mov	a,#0x06
      00844D 12 37 DF         [24] 1240 	lcall	_ak820_outline_0016
      008450 FA               [12] 1241 	mov	r2,a
      008451 A3               [24] 1242 	inc	dptr
      008452 E0               [24] 1243 	movx	a,@dptr
      008453 FB               [12] 1244 	mov	r3,a
      008454 BA 01 05         [24] 1245 	cjne	r2,#0x01,00136$
      008457 BB 00 02         [24] 1246 	cjne	r3,#0x00,00136$
      00845A 80 05            [24] 1247 	sjmp	00109$
      00845C                       1248 00136$:
      00845C                       1249 00108$:
      00845C 75 2A 00         [24] 1250 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      00845F 80 03            [24] 1251 	sjmp	00110$
      008461                       1252 00109$:
      008461 75 2A 01         [24] 1253 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008464                       1254 00110$:
                                   1255 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008464 74 06            [12] 1256 	mov	a,#0x06
      008466 12 37 E8         [24] 1257 	lcall	_ak820_outline_0030
      008469 12 4E CE         [24] 1258 	lcall	_ak820_outline_0165
      00846C 12 38 4C         [24] 1259 	lcall	_ak820_outline_0117
      00846F F0               [24] 1260 	movx	@dptr,a
      008470 A3               [24] 1261 	inc	dptr
      008471 F0               [24] 1262 	movx	@dptr,a
                                   1263 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008472 E5 2A            [12] 1264 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008474 60 12            [24] 1265 	jz	00103$
      008476 12 43 17         [24] 1266 	lcall	_ak820_outline_0116
      008479 C0 07            [24] 1267 	push	ar7
      00847B C0 06            [24] 1268 	push	ar6
      00847D 12 34 68         [24] 1269 	lcall	_ak820_combo_valid
      008480 E5 82            [12] 1270 	mov	a, dpl
      008482 D0 06            [24] 1271 	pop	ar6
      008484 D0 07            [24] 1272 	pop	ar7
      008486 70 17            [24] 1273 	jnz	00104$
      008488                       1274 00103$:
      008488 7D 00            [12] 1275 	mov	r5,#0x00
      00848A 90 0D 78         [24] 1276 	mov	dptr,#_memset_PARM_2
      00848D E4               [12] 1277 	clr	a
      00848E F0               [24] 1278 	movx	@dptr,a
      00848F 90 0D 79         [24] 1279 	mov	dptr,#_memset_PARM_3
      008492 74 0A            [12] 1280 	mov	a,#0x0a
      008494 F0               [24] 1281 	movx	@dptr,a
      008495 E4               [12] 1282 	clr	a
      008496 A3               [24] 1283 	inc	dptr
      008497 12 42 F2         [24] 1284 	lcall	_ak820_outline_0060
      00849A 8D F0            [24] 1285 	mov	b, r5
      00849C 12 B5 63         [24] 1286 	lcall	_memset
      00849F                       1287 00104$:
                                   1288 ;	quantum/dynamic_keymap.c:329: return 0;
      00849F 90 00 00         [24] 1289 	mov	dptr,#0x0000
                                   1290 ;	quantum/dynamic_keymap.c:330: }
      0084A2 22               [24] 1291 	ret
                                   1292 ;------------------------------------------------------------
                                   1293 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1294 ;------------------------------------------------------------
                                   1295 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1296 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_390'
                                   1297 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_391'
                                   1298 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_394'
                                   1299 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_395'
                                   1300 ;------------------------------------------------------------
                                   1301 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1302 ;	-----------------------------------------
                                   1303 ;	 function dynamic_keymap_set_combo
                                   1304 ;	-----------------------------------------
      0084A3                       1305 _dynamic_keymap_set_combo:
      0084A3 E5 82            [12] 1306 	mov	a,dpl
      0084A5 90 0A EA         [24] 1307 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      0084A8 F0               [24] 1308 	movx	@dptr,a
                                   1309 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0084A9 90 0A E7         [24] 1310 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0084AC 12 37 98         [24] 1311 	lcall	_ak820_outline_0004
                                   1312 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      0084AF C0 07            [24] 1313 	push	ar7
      0084B1 C0 06            [24] 1314 	push	ar6
      0084B3 12 34 68         [24] 1315 	lcall	_ak820_combo_valid
      0084B6 E5 82            [12] 1316 	mov	a, dpl
      0084B8 D0 06            [24] 1317 	pop	ar6
      0084BA D0 07            [24] 1318 	pop	ar7
      0084BC 60 07            [24] 1319 	jz	00101$
      0084BE 12 3D D5         [24] 1320 	lcall	_ak820_nvm_ok
      0084C1 E5 82            [12] 1321 	mov	a, dpl
      0084C3 70 04            [24] 1322 	jnz	00102$
      0084C5                       1323 00101$:
      0084C5 90 FF FF         [24] 1324 	mov	dptr,#0xffff
      0084C8 22               [24] 1325 	ret
      0084C9                       1326 00102$:
                                   1327 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      0084C9 90 0A EA         [24] 1328 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      0084CC E0               [24] 1329 	movx	a,@dptr
      0084CD FD               [12] 1330 	mov	r5,a
      0084CE BD 08 00         [24] 1331 	cjne	r5,#0x08,00133$
      0084D1                       1332 00133$:
      0084D1 40 04            [24] 1333 	jc	00105$
                                   1334 ;	quantum/dynamic_keymap.c:342: return -1;
      0084D3 90 FF FF         [24] 1335 	mov	dptr,#0xffff
      0084D6 22               [24] 1336 	ret
      0084D7                       1337 00105$:
                                   1338 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0084D7 12 8C B3         [24] 1339 	lcall	_ak820_outline_0078
                                   1340 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      0084DA C0 07            [24] 1341 	push	ar7
      0084DC C0 06            [24] 1342 	push	ar6
      0084DE C0 05            [24] 1343 	push	ar5
      0084E0 C0 04            [24] 1344 	push	ar4
      0084E2 12 75 79         [24] 1345 	lcall	_clear_keyboard
      0084E5 D0 04            [24] 1346 	pop	ar4
      0084E7 D0 05            [24] 1347 	pop	ar5
      0084E9 D0 06            [24] 1348 	pop	ar6
      0084EB D0 07            [24] 1349 	pop	ar7
                                   1350 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      0084ED 90 0D 70         [24] 1351 	mov	dptr,#___memcpy_PARM_2
      0084F0 12 48 2F         [24] 1352 	lcall	_ak820_outline_0058
      0084F3 E4               [12] 1353 	clr	a
      0084F4 A3               [24] 1354 	inc	dptr
      0084F5 F0               [24] 1355 	movx	@dptr,a
      0084F6 90 0D 73         [24] 1356 	mov	dptr,#___memcpy_PARM_3
      0084F9 74 0A            [12] 1357 	mov	a,#0x0a
      0084FB 12 38 57         [24] 1358 	lcall	_ak820_outline_0122
      0084FE 90 0A EB         [24] 1359 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008501 F5 F0            [12] 1360 	mov	b,a
      008503 C0 05            [24] 1361 	push	ar5
      008505 C0 04            [24] 1362 	push	ar4
      008507 12 B4 ED         [24] 1363 	lcall	___memcpy
      00850A D0 04            [24] 1364 	pop	ar4
      00850C D0 05            [24] 1365 	pop	ar5
                                   1366 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      00850E 90 0A EF         [24] 1367 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0004)
      008511 74 20            [12] 1368 	mov	a,#0x20
      008513 F0               [24] 1369 	movx	@dptr,a
      008514 74 08            [12] 1370 	mov	a,#0x08
      008516 A3               [24] 1371 	inc	dptr
      008517 F0               [24] 1372 	movx	@dptr,a
                                   1373 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008518 90 0A F1         [24] 1374 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0006)
      00851B 74 01            [12] 1375 	mov	a,#0x01
      00851D 12 38 57         [24] 1376 	lcall	_ak820_outline_0122
                                   1377 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008520 90 05 8A         [24] 1378 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008523 12 38 1D         [24] 1379 	lcall	_ak820_outline_0070
      008526 E4               [12] 1380 	clr	a
      008527 A3               [24] 1381 	inc	dptr
      008528 F0               [24] 1382 	movx	@dptr,a
      008529 90 05 8D         [24] 1383 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00852C 74 0A            [12] 1384 	mov	a,#0x0a
      00852E 12 38 57         [24] 1385 	lcall	_ak820_outline_0122
      008531 90 0A EB         [24] 1386 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008534 12 40 F6         [24] 1387 	lcall	_ak820_eeprom_write_block_xdata
                                   1388 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008537 12 3D E4         [24] 1389 	lcall	_ak820_nvm_flush
                                   1390 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      00853A 12 3D D5         [24] 1391 	lcall	_ak820_nvm_ok
      00853D E5 82            [12] 1392 	mov	a, dpl
      00853F 70 04            [24] 1393 	jnz	00107$
      008541 90 FF FF         [24] 1394 	mov	dptr,#0xffff
      008544 22               [24] 1395 	ret
      008545                       1396 00107$:
                                   1397 ;	quantum/dynamic_keymap.c:360: return 0;
      008545 90 00 00         [24] 1398 	mov	dptr,#0x0000
                                   1399 ;	quantum/dynamic_keymap.c:361: }
      008548 22               [24] 1400 	ret
                                   1401 ;------------------------------------------------------------
                                   1402 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1403 ;------------------------------------------------------------
                                   1404 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_398'
                                   1405 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_399'
                                   1406 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_401'
                                   1407 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_403'
                                   1408 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_405'
                                   1409 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_407'
                                   1410 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_408'
                                   1411 ;------------------------------------------------------------
                                   1412 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1413 ;	-----------------------------------------
                                   1414 ;	 function dynamic_keymap_reset
                                   1415 ;	-----------------------------------------
      008549                       1416 _dynamic_keymap_reset:
                                   1417 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008549 90 0D F0         [24] 1418 	mov	dptr,#_vial_unlocked
      00854C E0               [24] 1419 	movx	a,@dptr
      00854D 90 0A F5         [24] 1420 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      008550 F0               [24] 1421 	movx	@dptr,a
                                   1422 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008551 90 0D F0         [24] 1423 	mov	dptr,#_vial_unlocked
      008554 74 01            [12] 1424 	mov	a,#0x01
      008556 F0               [24] 1425 	movx	@dptr,a
                                   1426 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008557 7F 00            [12] 1427 	mov	r7,#0x00
      008559                       1428 00116$:
      008559 BF 06 00         [24] 1429 	cjne	r7,#0x06,00198$
      00855C                       1430 00198$:
      00855C 40 02            [24] 1431 	jc	00199$
      00855E C1 07            [12] 1432 	ajmp	00104$
      008560                       1433 00199$:
                                   1434 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008560 7E 00            [12] 1435 	mov	r6,#0x00
      008562                       1436 00110$:
      008562 BE 10 00         [24] 1437 	cjne	r6,#0x10,00200$
      008565                       1438 00200$:
      008565 50 4C            [24] 1439 	jnc	00102$
                                   1440 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008567 7D 00            [12] 1441 	mov	r5,#0x00
      008569                       1442 00107$:
      008569 BD 08 00         [24] 1443 	cjne	r5,#0x08,00202$
      00856C                       1444 00202$:
      00856C 50 42            [24] 1445 	jnc	00111$
                                   1446 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      00856E 90 0B 91         [24] 1447 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008571 EE               [12] 1448 	mov	a,r6
      008572 F0               [24] 1449 	movx	@dptr,a
      008573 90 0B 92         [24] 1450 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008576 ED               [12] 1451 	mov	a,r5
      008577 F0               [24] 1452 	movx	@dptr,a
      008578 8F 82            [24] 1453 	mov	dpl, r7
      00857A C0 07            [24] 1454 	push	ar7
      00857C C0 06            [24] 1455 	push	ar6
      00857E C0 05            [24] 1456 	push	ar5
      008580 12 94 DF         [24] 1457 	lcall	_keycode_at_keymap_location_raw
      008583 AB 82            [24] 1458 	mov	r3, dpl
      008585 AC 83            [24] 1459 	mov	r4, dph
      008587 D0 05            [24] 1460 	pop	ar5
      008589 D0 06            [24] 1461 	pop	ar6
      00858B D0 07            [24] 1462 	pop	ar7
      00858D 90 0A D4         [24] 1463 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008590 EE               [12] 1464 	mov	a,r6
      008591 F0               [24] 1465 	movx	@dptr,a
      008592 90 0A D5         [24] 1466 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008595 ED               [12] 1467 	mov	a,r5
      008596 F0               [24] 1468 	movx	@dptr,a
      008597 90 0A D6         [24] 1469 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00859A 12 38 23         [24] 1470 	lcall	_ak820_outline_0076
      00859D 8F 82            [24] 1471 	mov	dpl, r7
      00859F C0 07            [24] 1472 	push	ar7
      0085A1 C0 06            [24] 1473 	push	ar6
      0085A3 C0 05            [24] 1474 	push	ar5
      0085A5 51 B7            [12] 1475 	acall	_dynamic_keymap_set_keycode
      0085A7 D0 05            [24] 1476 	pop	ar5
      0085A9 D0 06            [24] 1477 	pop	ar6
      0085AB D0 07            [24] 1478 	pop	ar7
                                   1479 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0085AD 0D               [12] 1480 	inc	r5
      0085AE 80 B9            [24] 1481 	sjmp	00107$
      0085B0                       1482 00111$:
                                   1483 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0085B0 0E               [12] 1484 	inc	r6
      0085B1 80 AF            [24] 1485 	sjmp	00110$
      0085B3                       1486 00102$:
                                   1487 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0085B3 7E 00            [12] 1488 	mov	r6,#0x00
      0085B5                       1489 00113$:
      0085B5 BE 01 00         [24] 1490 	cjne	r6,#0x01,00204$
      0085B8                       1491 00204$:
      0085B8 50 4A            [24] 1492 	jnc	00117$
                                   1493 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      0085BA 12 8D 02         [24] 1494 	lcall	_ak820_outline_0174
      0085BD 04               [12] 1495 	inc	a
      0085BE F0               [24] 1496 	movx	@dptr,a
      0085BF 8F 82            [24] 1497 	mov	dpl, r7
      0085C1 C0 07            [24] 1498 	push	ar7
      0085C3 12 95 24         [24] 1499 	lcall	_keycode_at_encodermap_location_raw
      0085C6 12 43 38         [24] 1500 	lcall	_ak820_outline_0144
      0085C9 D0 07            [24] 1501 	pop	ar7
      0085CB 12 8C F9         [24] 1502 	lcall	_ak820_outline_0173
      0085CE 04               [12] 1503 	inc	a
      0085CF F0               [24] 1504 	movx	@dptr,a
      0085D0 90 0A E0         [24] 1505 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0085D3 12 38 1D         [24] 1506 	lcall	_ak820_outline_0070
      0085D6 8F 82            [24] 1507 	mov	dpl, r7
      0085D8 C0 07            [24] 1508 	push	ar7
      0085DA 71 90            [24] 1509 	acall	_dynamic_keymap_set_encoder
      0085DC D0 07            [24] 1510 	pop	ar7
                                   1511 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      0085DE 12 8D 02         [24] 1512 	lcall	_ak820_outline_0174
      0085E1 F0               [24] 1513 	movx	@dptr,a
      0085E2 8F 82            [24] 1514 	mov	dpl, r7
      0085E4 C0 07            [24] 1515 	push	ar7
      0085E6 12 95 24         [24] 1516 	lcall	_keycode_at_encodermap_location_raw
      0085E9 12 43 38         [24] 1517 	lcall	_ak820_outline_0144
      0085EC D0 07            [24] 1518 	pop	ar7
      0085EE 12 8C F9         [24] 1519 	lcall	_ak820_outline_0173
      0085F1 F0               [24] 1520 	movx	@dptr,a
      0085F2 90 0A E0         [24] 1521 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0085F5 12 38 1D         [24] 1522 	lcall	_ak820_outline_0070
      0085F8 8F 82            [24] 1523 	mov	dpl, r7
      0085FA C0 07            [24] 1524 	push	ar7
      0085FC 71 90            [24] 1525 	acall	_dynamic_keymap_set_encoder
      0085FE D0 07            [24] 1526 	pop	ar7
                                   1527 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008600 7E 01            [12] 1528 	mov	r6,#0x01
      008602 80 B1            [24] 1529 	sjmp	00113$
      008604                       1530 00117$:
                                   1531 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008604 0F               [12] 1532 	inc	r7
      008605 A1 59            [12] 1533 	ajmp	00116$
      008607                       1534 00104$:
                                   1535 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008607 90 0A F6         [24] 1536 	mov	dptr,#_dynamic_keymap_reset_combo_10001_407
      00860A 12 4E CE         [24] 1537 	lcall	_ak820_outline_0165
      00860D 90 0A F8         [24] 1538 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0002)
      008610 F0               [24] 1539 	movx	@dptr,a
      008611 A3               [24] 1540 	inc	dptr
      008612 F0               [24] 1541 	movx	@dptr,a
      008613 90 0A FA         [24] 1542 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0004)
      008616 F0               [24] 1543 	movx	@dptr,a
      008617 A3               [24] 1544 	inc	dptr
      008618 F0               [24] 1545 	movx	@dptr,a
      008619 90 0A FC         [24] 1546 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0006)
      00861C F0               [24] 1547 	movx	@dptr,a
      00861D A3               [24] 1548 	inc	dptr
      00861E F0               [24] 1549 	movx	@dptr,a
      00861F 90 0A FE         [24] 1550 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0008)
      008622 F0               [24] 1551 	movx	@dptr,a
      008623 A3               [24] 1552 	inc	dptr
      008624 F0               [24] 1553 	movx	@dptr,a
                                   1554 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008625 FF               [12] 1555 	mov	r7,a
      008626                       1556 00119$:
      008626 BF 08 00         [24] 1557 	cjne	r7,#0x08,00206$
      008629                       1558 00206$:
      008629 50 16            [24] 1559 	jnc	00105$
                                   1560 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      00862B 90 0A E7         [24] 1561 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00862E 74 F6            [12] 1562 	mov	a,#_dynamic_keymap_reset_combo_10001_407
      008630 F0               [24] 1563 	movx	@dptr,a
      008631 74 0A            [12] 1564 	mov	a,#(_dynamic_keymap_reset_combo_10001_407 >> 8)
      008633 12 38 29         [24] 1565 	lcall	_ak820_outline_0096
      008636 8F 82            [24] 1566 	mov	dpl, r7
      008638 C0 07            [24] 1567 	push	ar7
      00863A 91 A3            [24] 1568 	acall	_dynamic_keymap_set_combo
      00863C D0 07            [24] 1569 	pop	ar7
                                   1570 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      00863E 0F               [12] 1571 	inc	r7
      00863F 80 E5            [24] 1572 	sjmp	00119$
      008641                       1573 00105$:
                                   1574 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008641 90 0A F5         [24] 1575 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      008644 E0               [24] 1576 	movx	a,@dptr
      008645 90 0D F0         [24] 1577 	mov	dptr,#_vial_unlocked
      008648 F0               [24] 1578 	movx	@dptr,a
                                   1579 ;	quantum/dynamic_keymap.c:468: }
      008649 22               [24] 1580 	ret
                                   1581 ;------------------------------------------------------------
                                   1582 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1583 ;------------------------------------------------------------
                                   1584 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1585 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1586 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1587 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1588 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1589 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_409'
                                   1590 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_410'
                                   1591 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_410'
                                   1592 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_413'
                                   1593 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_415'
                                   1594 ;------------------------------------------------------------
                                   1595 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1596 ;	-----------------------------------------
                                   1597 ;	 function ak820_dynamic_read_buffer
                                   1598 ;	-----------------------------------------
      00864A                       1599 _ak820_dynamic_read_buffer:
      00864A 12 38 3B         [24] 1600 	lcall	_ak820_outline_0103
      00864D 90 0B 09         [24] 1601 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      008650 12 38 40         [24] 1602 	lcall	_ak820_outline_0104
                                   1603 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008653 90 0B 06         [24] 1604 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008656 12 37 F8         [24] 1605 	lcall	_ak820_outline_0050
                                   1606 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008659 90 0B 0B         [24] 1607 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      00865C E4               [12] 1608 	clr	a
      00865D F0               [24] 1609 	movx	@dptr,a
                                   1610 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      00865E 90 0B 04         [24] 1611 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008661 12 38 17         [24] 1612 	lcall	_ak820_outline_0059
      008664 8C 02            [24] 1613 	mov	ar2,r4
      008666 8D 03            [24] 1614 	mov	ar3,r5
      008668 C3               [12] 1615 	clr	c
      008669 74 1C            [12] 1616 	mov	a,#0x1c
      00866B 9A               [12] 1617 	subb	a,r2
      00866C E4               [12] 1618 	clr	a
      00866D 9B               [12] 1619 	subb	a,r3
      00866E 50 01            [24] 1620 	jnc	00102$
                                   1621 ;	free result
      008670 22               [24] 1622 	ret
      008671                       1623 00102$:
                                   1624 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008671 90 0B 02         [24] 1625 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008674 12 43 1C         [24] 1626 	lcall	_ak820_outline_0119
      008677 90 0B 00         [24] 1627 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00867A 12 38 35         [24] 1628 	lcall	_ak820_outline_0099
      00867D C3               [12] 1629 	clr	c
      00867E EA               [12] 1630 	mov	a,r2
      00867F 98               [12] 1631 	subb	a,r0
      008680 EB               [12] 1632 	mov	a,r3
      008681 99               [12] 1633 	subb	a,r1
      008682 50 17            [24] 1634 	jnc	00104$
                                   1635 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008684 E8               [12] 1636 	mov	a,r0
      008685 C3               [12] 1637 	clr	c
      008686 9A               [12] 1638 	subb	a,r2
      008687 F8               [12] 1639 	mov	r0,a
      008688 E9               [12] 1640 	mov	a,r1
      008689 9B               [12] 1641 	subb	a,r3
      00868A F9               [12] 1642 	mov	r1,a
                                   1643 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      00868B C3               [12] 1644 	clr	c
      00868C E8               [12] 1645 	mov	a,r0
      00868D 9C               [12] 1646 	subb	a,r4
      00868E E9               [12] 1647 	mov	a,r1
      00868F 9D               [12] 1648 	subb	a,r5
      008690 40 04            [24] 1649 	jc	00114$
      008692 8C 00            [24] 1650 	mov	ar0,r4
      008694 8D 01            [24] 1651 	mov	ar1,r5
      008696                       1652 00114$:
      008696 90 0B 0B         [24] 1653 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008699 E8               [12] 1654 	mov	a,r0
      00869A F0               [24] 1655 	movx	@dptr,a
      00869B                       1656 00104$:
                                   1657 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      00869B 90 0B 0B         [24] 1658 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      00869E E0               [24] 1659 	movx	a,@dptr
      00869F F5 2B            [12] 1660 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      0086A1 E0               [24] 1661 	movx	a,@dptr
      0086A2 60 42            [24] 1662 	jz	00106$
      0086A4 C0 04            [24] 1663 	push	ar4
      0086A6 C0 05            [24] 1664 	push	ar5
      0086A8 8E 00            [24] 1665 	mov	ar0,r6
      0086AA 8F 05            [24] 1666 	mov	ar5,r7
      0086AC 90 0B 09         [24] 1667 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      0086AF E0               [24] 1668 	movx	a,@dptr
      0086B0 F9               [12] 1669 	mov	r1,a
      0086B1 A3               [24] 1670 	inc	dptr
      0086B2 E0               [24] 1671 	movx	a,@dptr
      0086B3 FC               [12] 1672 	mov	r4,a
      0086B4 EA               [12] 1673 	mov	a,r2
      0086B5 29               [12] 1674 	add	a, r1
      0086B6 FA               [12] 1675 	mov	r2,a
      0086B7 EB               [12] 1676 	mov	a,r3
      0086B8 3C               [12] 1677 	addc	a, r4
      0086B9 FB               [12] 1678 	mov	r3,a
      0086BA 90 05 81         [24] 1679 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0086BD EA               [12] 1680 	mov	a,r2
      0086BE F0               [24] 1681 	movx	@dptr,a
      0086BF EB               [12] 1682 	mov	a,r3
      0086C0 12 38 29         [24] 1683 	lcall	_ak820_outline_0096
      0086C3 90 05 84         [24] 1684 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0086C6 E5 2B            [12] 1685 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      0086C8 12 38 57         [24] 1686 	lcall	_ak820_outline_0122
      0086CB 88 82            [24] 1687 	mov	dpl, r0
      0086CD 8D 83            [24] 1688 	mov	dph, r5
      0086CF C0 07            [24] 1689 	push	ar7
      0086D1 C0 06            [24] 1690 	push	ar6
      0086D3 C0 05            [24] 1691 	push	ar5
      0086D5 C0 04            [24] 1692 	push	ar4
      0086D7 12 40 6A         [24] 1693 	lcall	_ak820_eeprom_read_block_xdata
      0086DA D0 04            [24] 1694 	pop	ar4
      0086DC D0 05            [24] 1695 	pop	ar5
      0086DE D0 06            [24] 1696 	pop	ar6
      0086E0 D0 07            [24] 1697 	pop	ar7
                                   1698 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0086E2 D0 05            [24] 1699 	pop	ar5
      0086E4 D0 04            [24] 1700 	pop	ar4
                                   1701 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0086E6                       1702 00106$:
                                   1703 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0086E6 90 0B 0B         [24] 1704 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      0086E9 E0               [24] 1705 	movx	a,@dptr
      0086EA FB               [12] 1706 	mov	r3,a
      0086EB                       1707 00109$:
      0086EB 8B 01            [24] 1708 	mov	ar1,r3
      0086ED 7A 00            [12] 1709 	mov	r2,#0x00
      0086EF C3               [12] 1710 	clr	c
      0086F0 E9               [12] 1711 	mov	a,r1
      0086F1 9C               [12] 1712 	subb	a,r4
      0086F2 EA               [12] 1713 	mov	a,r2
      0086F3 9D               [12] 1714 	subb	a,r5
      0086F4 50 09            [24] 1715 	jnc	00111$
      0086F6 EB               [12] 1716 	mov	a,r3
      0086F7 12 37 E8         [24] 1717 	lcall	_ak820_outline_0030
      0086FA E4               [12] 1718 	clr	a
      0086FB F0               [24] 1719 	movx	@dptr,a
      0086FC 0B               [12] 1720 	inc	r3
      0086FD 80 EC            [24] 1721 	sjmp	00109$
      0086FF                       1722 00111$:
                                   1723 ;	quantum/dynamic_keymap.c:483: }
      0086FF 22               [24] 1724 	ret
                                   1725 ;------------------------------------------------------------
                                   1726 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1727 ;------------------------------------------------------------
                                   1728 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1729 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1730 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_416'
                                   1731 ;------------------------------------------------------------
                                   1732 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1733 ;	-----------------------------------------
                                   1734 ;	 function dynamic_keymap_get_buffer
                                   1735 ;	-----------------------------------------
      008700                       1736 _dynamic_keymap_get_buffer:
      008700 12 38 3B         [24] 1737 	lcall	_ak820_outline_0103
      008703 90 0B 11         [24] 1738 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008706 12 38 40         [24] 1739 	lcall	_ak820_outline_0104
                                   1740 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008709 90 0B 11         [24] 1741 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      00870C 12 37 F8         [24] 1742 	lcall	_ak820_outline_0050
      00870F 90 0B 0C         [24] 1743 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008712 12 38 17         [24] 1744 	lcall	_ak820_outline_0059
      008715 90 0B 0E         [24] 1745 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008718 12 4E AE         [24] 1746 	lcall	_ak820_outline_0087
      00871B 90 0B 00         [24] 1747 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00871E E4               [12] 1748 	clr	a
      00871F F0               [24] 1749 	movx	@dptr,a
      008720 74 06            [12] 1750 	mov	a,#0x06
      008722 A3               [24] 1751 	inc	dptr
      008723 F0               [24] 1752 	movx	@dptr,a
      008724 90 0B 02         [24] 1753 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008727 12 48 2F         [24] 1754 	lcall	_ak820_outline_0058
      00872A 90 0B 04         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      00872D 12 38 1D         [24] 1756 	lcall	_ak820_outline_0070
      008730 90 0B 06         [24] 1757 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008733 E9               [12] 1758 	mov	a,r1
      008734 12 4E C7         [24] 1759 	lcall	_ak820_outline_0150
      008737 F0               [24] 1760 	movx	@dptr,a
      008738 90 00 40         [24] 1761 	mov	dptr,#0x0040
                                   1762 ;	quantum/dynamic_keymap.c:511: }
      00873B C1 4A            [12] 1763 	ajmp	_ak820_dynamic_read_buffer
                                   1764 ;------------------------------------------------------------
                                   1765 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1766 ;------------------------------------------------------------
                                   1767 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1768 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1769 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1770 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1771 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1772 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_418'
                                   1773 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_419'
                                   1774 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_419'
                                   1775 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_419'
                                   1776 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_422'
                                   1777 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_425'
                                   1778 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_425'
                                   1779 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_427'
                                   1780 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_430'
                                   1781 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_432'
                                   1782 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_433'
                                   1783 ;------------------------------------------------------------
                                   1784 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1785 ;	-----------------------------------------
                                   1786 ;	 function dynamic_keymap_set_buffer
                                   1787 ;	-----------------------------------------
      00873D                       1788 _dynamic_keymap_set_buffer:
      00873D 12 38 3B         [24] 1789 	lcall	_ak820_outline_0103
      008740 90 0B 18         [24] 1790 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008743 12 38 40         [24] 1791 	lcall	_ak820_outline_0104
                                   1792 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008746 90 0B 18         [24] 1793 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008749 12 37 C3         [24] 1794 	lcall	_ak820_outline_0009
      00874C 74 40            [12] 1795 	mov	a,#0x40
      00874E 2C               [12] 1796 	add	a, r4
      00874F FA               [12] 1797 	mov	r2,a
      008750 E4               [12] 1798 	clr	a
      008751 3D               [12] 1799 	addc	a, r5
      008752 FB               [12] 1800 	mov	r3,a
                                   1801 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008753 90 0B 15         [24] 1802 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008756 12 38 35         [24] 1803 	lcall	_ak820_outline_0099
                                   1804 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008759 90 0B 13         [24] 1805 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00875C E0               [24] 1806 	movx	a,@dptr
      00875D F5 2C            [12] 1807 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      00875F A3               [24] 1808 	inc	dptr
      008760 E0               [24] 1809 	movx	a,@dptr
      008761 F5 2D            [12] 1810 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008763 E5 2C            [12] 1811 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008765 45 2D            [12] 1812 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008767 70 01            [24] 1813 	jnz	00102$
      008769 22               [24] 1814 	ret
      00876A                       1815 00102$:
                                   1816 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      00876A 85 2C 2E         [24] 1817 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      00876D 85 2D 2F         [24] 1818 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008770 C3               [12] 1819 	clr	c
      008771 74 1C            [12] 1820 	mov	a,#0x1c
      008773 95 2E            [12] 1821 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008775 E4               [12] 1822 	clr	a
      008776 95 2F            [12] 1823 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008778 50 01            [24] 1824 	jnc	00104$
                                   1825 ;	free result
      00877A 22               [24] 1826 	ret
      00877B                       1827 00104$:
                                   1828 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      00877B 85 2C 30         [24] 1829 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1830 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      00877E 74 FA            [12] 1831 	mov	a,#0x100 - 0x06
      008780 2F               [12] 1832 	add	a,r7
      008781 40 11            [24] 1833 	jc	00105$
      008783 E4               [12] 1834 	clr	a
      008784 C3               [12] 1835 	clr	c
      008785 9E               [12] 1836 	subb	a,r6
      008786 FE               [12] 1837 	mov	r6,a
      008787 74 06            [12] 1838 	mov	a,#0x06
      008789 9F               [12] 1839 	subb	a,r7
      00878A FF               [12] 1840 	mov	r7,a
      00878B C3               [12] 1841 	clr	c
      00878C EE               [12] 1842 	mov	a,r6
      00878D 95 2C            [12] 1843 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      00878F EF               [12] 1844 	mov	a,r7
      008790 95 2D            [12] 1845 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008792 50 01            [24] 1846 	jnc	00106$
      008794                       1847 00105$:
                                   1848 ;	quantum/dynamic_keymap.c:529: return;
      008794 22               [24] 1849 	ret
      008795                       1850 00106$:
                                   1851 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008795 90 0D F0         [24] 1852 	mov	dptr,#_vial_unlocked
      008798 E0               [24] 1853 	movx	a,@dptr
      008799 60 03            [24] 1854 	jz	00207$
      00879B 02 88 AA         [24] 1855 	ljmp	00120$
      00879E                       1856 00207$:
                                   1857 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      00879E 90 0B 1A         [24] 1858 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      0087A1 E4               [12] 1859 	clr	a
      0087A2 F0               [24] 1860 	movx	@dptr,a
                                   1861 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      0087A3 90 0B 1B         [24] 1862 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      0087A6 E5 30            [12] 1863 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0087A8 F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      0087A9 EC               [12] 1866 	mov	a,r4
      0087AA 30 E0 33         [24] 1867 	jnb	acc.0,00111$
                                   1868 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      0087AD EA               [12] 1869 	mov	a,r2
      0087AE 24 FF            [12] 1870 	add	a,#0xff
      0087B0 FE               [12] 1871 	mov	r6,a
      0087B1 EB               [12] 1872 	mov	a,r3
      0087B2 34 FF            [12] 1873 	addc	a,#0xff
      0087B4 FF               [12] 1874 	mov	r7,a
      0087B5 7D 00            [12] 1875 	mov	r5,#0x00
      0087B7 12 43 17         [24] 1876 	lcall	_ak820_outline_0116
      0087BA 8D F0            [24] 1877 	mov	b, r5
      0087BC 12 40 2F         [24] 1878 	lcall	_eeprom_read_byte
      0087BF AE 82            [24] 1879 	mov	r6,dpl
      0087C1 7F 00            [12] 1880 	mov	r7,#0x00
      0087C3 12 38 67         [24] 1881 	lcall	_ak820_outline_0151
      0087C6 E0               [24] 1882 	movx	a,@dptr
      0087C7 7C 00            [12] 1883 	mov	r4,#0x00
      0087C9 42 07            [12] 1884 	orl	ar7,a
      0087CB EC               [12] 1885 	mov	a,r4
      0087CC 42 06            [12] 1886 	orl	ar6,a
                                   1887 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      0087CE BF 00 09         [24] 1888 	cjne	r7,#0x00,00109$
      0087D1 BE 7C 06         [24] 1889 	cjne	r6,#0x7c,00109$
                                   1890 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      0087D4 12 38 67         [24] 1891 	lcall	_ak820_outline_0151
      0087D7 74 FF            [12] 1892 	mov	a,#0xff
      0087D9 F0               [24] 1893 	movx	@dptr,a
      0087DA                       1894 00109$:
                                   1895 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      0087DA 90 0B 1A         [24] 1896 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      0087DD 74 01            [12] 1897 	mov	a,#0x01
      0087DF F0               [24] 1898 	movx	@dptr,a
      0087E0                       1899 00111$:
                                   1900 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      0087E0 90 0B 18         [24] 1901 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      0087E3 12 37 F8         [24] 1902 	lcall	_ak820_outline_0050
      0087E6 E5 2C            [12] 1903 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0087E8 2E               [12] 1904 	add	a, r6
      0087E9 FE               [12] 1905 	mov	r6,a
      0087EA E5 2D            [12] 1906 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0087EC 3F               [12] 1907 	addc	a, r7
      0087ED EE               [12] 1908 	mov	a,r6
      0087EE 30 E0 5A         [24] 1909 	jnb	acc.0,00115$
                                   1910 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      0087F1 AE 30            [24] 1911 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      0087F3 7F 00            [12] 1912 	mov	r7,#0x00
      0087F5 EE               [12] 1913 	mov	a,r6
      0087F6 24 FF            [12] 1914 	add	a,#0xff
      0087F8 FC               [12] 1915 	mov	r4,a
      0087F9 EF               [12] 1916 	mov	a,r7
      0087FA 34 FF            [12] 1917 	addc	a,#0xff
      0087FC FD               [12] 1918 	mov	r5,a
      0087FD EC               [12] 1919 	mov	a,r4
      0087FE 28               [12] 1920 	add	a, r0
      0087FF F5 82            [12] 1921 	mov	dpl,a
      008801 ED               [12] 1922 	mov	a,r5
      008802 39               [12] 1923 	addc	a, r1
      008803 F5 83            [12] 1924 	mov	dph,a
      008805 E0               [24] 1925 	movx	a,@dptr
      008806 FC               [12] 1926 	mov	r4,a
      008807 7D 00            [12] 1927 	mov	r5,#0x00
      008809 E5 30            [12] 1928 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      00880B 2A               [12] 1929 	add	a, r2
      00880C FA               [12] 1930 	mov	r2,a
      00880D E4               [12] 1931 	clr	a
      00880E 3B               [12] 1932 	addc	a, r3
      00880F FB               [12] 1933 	mov	r3,a
      008810 C0 00            [24] 1934 	push	ar0
      008812 C0 01            [24] 1935 	push	ar1
      008814 8B 01            [24] 1936 	mov	ar1,r3
      008816 7B 00            [12] 1937 	mov	r3,#0x00
      008818 8A 82            [24] 1938 	mov	dpl, r2
      00881A 89 83            [24] 1939 	mov	dph, r1
      00881C 8B F0            [24] 1940 	mov	b, r3
      00881E 12 40 2F         [24] 1941 	lcall	_eeprom_read_byte
      008821 AB 82            [24] 1942 	mov	r3, dpl
      008823 7A 00            [12] 1943 	mov	r2,#0x00
      008825 EB               [12] 1944 	mov	a,r3
      008826 12 43 2D         [24] 1945 	lcall	_ak820_outline_0138
                                   1946 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008829 BD 00 05         [24] 1947 	cjne	r5,#0x00,00212$
      00882C BC 7C 02         [24] 1948 	cjne	r4,#0x7c,00212$
      00882F 80 06            [24] 1949 	sjmp	00213$
      008831                       1950 00212$:
      008831 D0 01            [24] 1951 	pop	ar1
      008833 D0 00            [24] 1952 	pop	ar0
      008835 80 0D            [24] 1953 	sjmp	00113$
      008837                       1954 00213$:
      008837 D0 01            [24] 1955 	pop	ar1
      008839 D0 00            [24] 1956 	pop	ar0
                                   1957 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      00883B 1E               [12] 1958 	dec	r6
      00883C BE FF 01         [24] 1959 	cjne	r6,#0xff,00214$
      00883F 1F               [12] 1960 	dec	r7
      008840                       1961 00214$:
      008840 EE               [12] 1962 	mov	a,r6
      008841 12 8C DB         [24] 1963 	lcall	_ak820_outline_0126
      008844                       1964 00113$:
                                   1965 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008844 E5 30            [12] 1966 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008846 14               [12] 1967 	dec	a
      008847 90 0B 1B         [24] 1968 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      00884A F0               [24] 1969 	movx	@dptr,a
      00884B                       1970 00115$:
                                   1971 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      00884B 90 0B 1A         [24] 1972 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      00884E E0               [24] 1973 	movx	a,@dptr
      00884F 90 0B 1C         [24] 1974 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008852 F0               [24] 1975 	movx	@dptr,a
      008853                       1976 00122$:
      008853 90 0B 1C         [24] 1977 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008856 E0               [24] 1978 	movx	a,@dptr
      008857 FF               [12] 1979 	mov	r7,a
      008858 90 0B 1B         [24] 1980 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      00885B E0               [24] 1981 	movx	a,@dptr
      00885C FE               [12] 1982 	mov	r6,a
      00885D C3               [12] 1983 	clr	c
      00885E EF               [12] 1984 	mov	a,r7
      00885F 9E               [12] 1985 	subb	a,r6
      008860 50 48            [24] 1986 	jnc	00120$
                                   1987 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008862 EF               [12] 1988 	mov	a,r7
      008863 28               [12] 1989 	add	a, r0
      008864 FD               [12] 1990 	mov	r5,a
      008865 E4               [12] 1991 	clr	a
      008866 39               [12] 1992 	addc	a, r1
      008867 FE               [12] 1993 	mov	r6,a
      008868 12 48 35         [24] 1994 	lcall	_ak820_outline_0074
      00886B 7B 00            [12] 1995 	mov	r3,#0x00
      00886D 8C 2D            [24] 1996 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      00886F 8B 2C            [24] 1997 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008871 8F 02            [24] 1998 	mov	ar2,r7
      008873 7F 00            [12] 1999 	mov	r7,#0x00
      008875 74 01            [12] 2000 	mov	a,#0x01
      008877 2A               [12] 2001 	add	a, r2
      008878 FB               [12] 2002 	mov	r3,a
      008879 E4               [12] 2003 	clr	a
      00887A 3F               [12] 2004 	addc	a, r7
      00887B FC               [12] 2005 	mov	r4,a
      00887C EB               [12] 2006 	mov	a,r3
      00887D 28               [12] 2007 	add	a, r0
      00887E F5 82            [12] 2008 	mov	dpl,a
      008880 EC               [12] 2009 	mov	a,r4
      008881 39               [12] 2010 	addc	a, r1
      008882 F5 83            [12] 2011 	mov	dph,a
      008884 E0               [24] 2012 	movx	a,@dptr
      008885 FC               [12] 2013 	mov	r4,a
      008886 7B 00            [12] 2014 	mov	r3,#0x00
      008888 E5 2D            [12] 2015 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00888A 42 03            [12] 2016 	orl	ar3,a
                                   2017 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      00888C BC 00 12         [24] 2018 	cjne	r4,#0x00,00123$
      00888F BB 7C 0F         [24] 2019 	cjne	r3,#0x7c,00123$
                                   2020 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008892 12 38 5C         [24] 2021 	lcall	_ak820_outline_0131
      008895 74 FF            [12] 2022 	mov	a,#0xff
      008897 F0               [24] 2023 	movx	@dptr,a
                                   2024 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008898 0A               [12] 2025 	inc	r2
      008899 BA 00 01         [24] 2026 	cjne	r2,#0x00,00218$
      00889C 0F               [12] 2027 	inc	r7
      00889D                       2028 00218$:
      00889D EA               [12] 2029 	mov	a,r2
      00889E 12 8C DB         [24] 2030 	lcall	_ak820_outline_0126
      0088A1                       2031 00123$:
                                   2032 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      0088A1 90 0B 1C         [24] 2033 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      0088A4 E0               [24] 2034 	movx	a,@dptr
      0088A5 24 02            [12] 2035 	add	a,#0x02
      0088A7 F0               [24] 2036 	movx	@dptr,a
      0088A8 80 A9            [24] 2037 	sjmp	00122$
      0088AA                       2038 00120$:
                                   2039 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      0088AA 90 0B 18         [24] 2040 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      0088AD 12 37 F8         [24] 2041 	lcall	_ak820_outline_0050
      0088B0 74 40            [12] 2042 	mov	a,#0x40
      0088B2 12 43 27         [24] 2043 	lcall	_ak820_outline_0133
      0088B5 90 05 8A         [24] 2044 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0088B8 12 48 2F         [24] 2045 	lcall	_ak820_outline_0058
      0088BB E4               [12] 2046 	clr	a
      0088BC A3               [24] 2047 	inc	dptr
      0088BD F0               [24] 2048 	movx	@dptr,a
      0088BE 90 05 8D         [24] 2049 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0088C1 E5 2E            [12] 2050 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      0088C3 F0               [24] 2051 	movx	@dptr,a
      0088C4 E5 2F            [12] 2052 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      0088C6 A3               [24] 2053 	inc	dptr
      0088C7 F0               [24] 2054 	movx	@dptr,a
      0088C8 12 38 67         [24] 2055 	lcall	_ak820_outline_0151
                                   2056 ;	quantum/dynamic_keymap.c:584: }
      0088CB 02 40 F6         [24] 2057 	ljmp	_ak820_eeprom_write_block_xdata
                                   2058 ;------------------------------------------------------------
                                   2059 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2060 ;------------------------------------------------------------
                                   2061 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2062 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2063 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_436'
                                   2064 ;------------------------------------------------------------
                                   2065 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2066 ;	-----------------------------------------
                                   2067 ;	 function keycode_at_keymap_location
                                   2068 ;	-----------------------------------------
      0088CE                       2069 _keycode_at_keymap_location:
      0088CE E5 82            [12] 2070 	mov	a,dpl
      0088D0 90 0B 1F         [24] 2071 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_436
      0088D3 F0               [24] 2072 	movx	@dptr,a
                                   2073 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      0088D4 E0               [24] 2074 	movx	a,@dptr
      0088D5 FF               [12] 2075 	mov	r7,a
      0088D6 BF 06 00         [24] 2076 	cjne	r7,#0x06,00128$
      0088D9                       2077 00128$:
      0088D9 50 23            [24] 2078 	jnc	00102$
      0088DB 90 0B 1D         [24] 2079 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      0088DE E0               [24] 2080 	movx	a,@dptr
      0088DF FE               [12] 2081 	mov	r6,a
      0088E0 BE 10 00         [24] 2082 	cjne	r6,#0x10,00130$
      0088E3                       2083 00130$:
      0088E3 50 19            [24] 2084 	jnc	00102$
      0088E5 90 0B 1E         [24] 2085 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      0088E8 E0               [24] 2086 	movx	a,@dptr
      0088E9 FD               [12] 2087 	mov	r5,a
      0088EA BD 08 00         [24] 2088 	cjne	r5,#0x08,00132$
      0088ED                       2089 00132$:
      0088ED 50 0F            [24] 2090 	jnc	00102$
                                   2091 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      0088EF 90 0A D1         [24] 2092 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0088F2 EE               [12] 2093 	mov	a,r6
      0088F3 F0               [24] 2094 	movx	@dptr,a
      0088F4 90 0A D2         [24] 2095 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0088F7 ED               [12] 2096 	mov	a,r5
      0088F8 F0               [24] 2097 	movx	@dptr,a
      0088F9 8F 82            [24] 2098 	mov	dpl, r7
      0088FB 02 82 6A         [24] 2099 	ljmp	_dynamic_keymap_get_keycode
      0088FE                       2100 00102$:
                                   2101 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      0088FE 90 00 00         [24] 2102 	mov	dptr,#0x0000
                                   2103 ;	quantum/dynamic_keymap.c:591: }
      008901 22               [24] 2104 	ret
                                   2105 ;------------------------------------------------------------
                                   2106 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2107 ;------------------------------------------------------------
                                   2108 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2109 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2110 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_440'
                                   2111 ;------------------------------------------------------------
                                   2112 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2113 ;	-----------------------------------------
                                   2114 ;	 function keycode_at_encodermap_location
                                   2115 ;	-----------------------------------------
      008902                       2116 _keycode_at_encodermap_location:
      008902 E5 82            [12] 2117 	mov	a,dpl
      008904 90 0B 22         [24] 2118 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_440
      008907 F0               [24] 2119 	movx	@dptr,a
                                   2120 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008908 E0               [24] 2121 	movx	a,@dptr
      008909 FF               [12] 2122 	mov	r7,a
      00890A BF 06 00         [24] 2123 	cjne	r7,#0x06,00120$
      00890D                       2124 00120$:
      00890D 50 1E            [24] 2125 	jnc	00102$
      00890F 90 0B 20         [24] 2126 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008912 E0               [24] 2127 	movx	a,@dptr
      008913 FE               [12] 2128 	mov	r6,a
      008914 BE 01 00         [24] 2129 	cjne	r6,#0x01,00122$
      008917                       2130 00122$:
      008917 50 14            [24] 2131 	jnc	00102$
                                   2132 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008919 90 0B 21         [24] 2133 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      00891C E0               [24] 2134 	movx	a,@dptr
      00891D FE               [12] 2135 	mov	r6,a
      00891E 90 0A DB         [24] 2136 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008921 E4               [12] 2137 	clr	a
      008922 F0               [24] 2138 	movx	@dptr,a
      008923 90 0A DC         [24] 2139 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008926 EE               [12] 2140 	mov	a,r6
      008927 F0               [24] 2141 	movx	@dptr,a
      008928 8F 82            [24] 2142 	mov	dpl, r7
      00892A 02 83 29         [24] 2143 	ljmp	_dynamic_keymap_get_encoder
      00892D                       2144 00102$:
                                   2145 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      00892D 90 00 00         [24] 2146 	mov	dptr,#0x0000
                                   2147 ;	quantum/dynamic_keymap.c:599: }
      008930 22               [24] 2148 	ret
                                   2149 ;------------------------------------------------------------
                                   2150 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2151 ;------------------------------------------------------------
                                   2152 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2153 ;	-----------------------------------------
                                   2154 ;	 function dynamic_keymap_macro_get_count
                                   2155 ;	-----------------------------------------
      008931                       2156 _dynamic_keymap_macro_get_count:
                                   2157 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008931 75 82 10         [24] 2158 	mov	dpl, #0x10
                                   2159 ;	quantum/dynamic_keymap.c:604: }
      008934 22               [24] 2160 	ret
                                   2161 ;------------------------------------------------------------
                                   2162 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2163 ;------------------------------------------------------------
                                   2164 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2165 ;	-----------------------------------------
                                   2166 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2167 ;	-----------------------------------------
      008935                       2168 _dynamic_keymap_macro_get_buffer_size:
                                   2169 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008935 90 20 00         [24] 2170 	mov	dptr,#0x2000
                                   2171 ;	quantum/dynamic_keymap.c:608: }
      008938 22               [24] 2172 	ret
                                   2173 ;------------------------------------------------------------
                                   2174 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2175 ;------------------------------------------------------------
                                   2176 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2177 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2178 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2179 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_448'
                                   2180 ;------------------------------------------------------------
                                   2181 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2182 ;	-----------------------------------------
                                   2183 ;	 function dynamic_keymap_macro_get_buffer
                                   2184 ;	-----------------------------------------
      008939                       2185 _dynamic_keymap_macro_get_buffer:
      008939 12 38 3B         [24] 2186 	lcall	_ak820_outline_0103
      00893C 90 0B 28         [24] 2187 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      00893F 12 38 40         [24] 2188 	lcall	_ak820_outline_0104
                                   2189 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008942 12 2B 2B         [24] 2190 	lcall	_ak820_macro_length
      008945 12 43 22         [24] 2191 	lcall	_ak820_outline_0130
      008948 90 0B 28         [24] 2192 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      00894B 12 38 17         [24] 2193 	lcall	_ak820_outline_0059
      00894E 90 0B 23         [24] 2194 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008951 E0               [24] 2195 	movx	a,@dptr
      008952 F5 31            [12] 2196 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008954 A3               [24] 2197 	inc	dptr
      008955 E0               [24] 2198 	movx	a,@dptr
      008956 F5 32            [12] 2199 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008958 90 0B 25         [24] 2200 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00895B 12 38 35         [24] 2201 	lcall	_ak820_outline_0099
      00895E A3               [24] 2202 	inc	dptr
      00895F E0               [24] 2203 	movx	a,@dptr
      008960 FB               [12] 2204 	mov	r3,a
      008961 90 0B 00         [24] 2205 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008964 12 48 2F         [24] 2206 	lcall	_ak820_outline_0058
      008967 90 0B 02         [24] 2207 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      00896A 12 38 1D         [24] 2208 	lcall	_ak820_outline_0070
      00896D 90 0B 04         [24] 2209 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008970 E5 31            [12] 2210 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008972 F0               [24] 2211 	movx	@dptr,a
      008973 E5 32            [12] 2212 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008975 A3               [24] 2213 	inc	dptr
      008976 F0               [24] 2214 	movx	@dptr,a
      008977 90 0B 06         [24] 2215 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      00897A E8               [12] 2216 	mov	a,r0
      00897B F0               [24] 2217 	movx	@dptr,a
      00897C E9               [12] 2218 	mov	a,r1
      00897D A3               [24] 2219 	inc	dptr
      00897E F0               [24] 2220 	movx	@dptr,a
      00897F EB               [12] 2221 	mov	a,r3
      008980 A3               [24] 2222 	inc	dptr
      008981 F0               [24] 2223 	movx	@dptr,a
      008982 90 08 00         [24] 2224 	mov	dptr,#0x0800
                                   2225 ;	quantum/dynamic_keymap.c:635: }
      008985 02 86 4A         [24] 2226 	ljmp	_ak820_dynamic_read_buffer
                                   2227 ;------------------------------------------------------------
                                   2228 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2229 ;------------------------------------------------------------
                                   2230 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2231 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2232 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_450'
                                   2233 ;------------------------------------------------------------
                                   2234 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2235 ;	-----------------------------------------
                                   2236 ;	 function dynamic_keymap_macro_set_buffer
                                   2237 ;	-----------------------------------------
      008988                       2238 _dynamic_keymap_macro_set_buffer:
      008988 12 38 3B         [24] 2239 	lcall	_ak820_outline_0103
      00898B 90 0B 2F         [24] 2240 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      00898E 12 38 40         [24] 2241 	lcall	_ak820_outline_0104
                                   2242 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      008991 90 0B 2F         [24] 2243 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      008994 12 37 F8         [24] 2244 	lcall	_ak820_outline_0050
      008997 90 0B 2A         [24] 2245 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00899A 12 38 17         [24] 2246 	lcall	_ak820_outline_0059
      00899D 90 0B 2C         [24] 2247 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      0089A0 12 4E AE         [24] 2248 	lcall	_ak820_outline_0087
      0089A3 90 05 10         [24] 2249 	mov	dptr,#_ak820_macro_write_PARM_2
      0089A6 12 38 1D         [24] 2250 	lcall	_ak820_outline_0070
      0089A9 90 05 12         [24] 2251 	mov	dptr,#_ak820_macro_write_PARM_3
      0089AC E9               [12] 2252 	mov	a,r1
      0089AD 12 4E C7         [24] 2253 	lcall	_ak820_outline_0150
      0089B0 12 42 F2         [24] 2254 	lcall	_ak820_outline_0060
                                   2255 ;	quantum/dynamic_keymap.c:640: }
      0089B3 02 2B 45         [24] 2256 	ljmp	_ak820_macro_write
                                   2257 ;------------------------------------------------------------
                                   2258 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2259 ;------------------------------------------------------------
                                   2260 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2261 ;	-----------------------------------------
                                   2262 ;	 function dynamic_keymap_macro_reset
                                   2263 ;	-----------------------------------------
      0089B6                       2264 _dynamic_keymap_macro_reset:
                                   2265 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2266 ;	quantum/dynamic_keymap.c:666: }
      0089B6 02 2E 64         [24] 2267 	ljmp	_ak820_macro_reset
                                   2268 ;------------------------------------------------------------
                                   2269 ;Allocation info for local variables in function 'decode_keycode'
                                   2270 ;------------------------------------------------------------
                                   2271 ;kc            Allocated with name '_decode_keycode_kc_10000_454'
                                   2272 ;------------------------------------------------------------
                                   2273 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2274 ;	-----------------------------------------
                                   2275 ;	 function decode_keycode
                                   2276 ;	-----------------------------------------
      0089B9                       2277 _decode_keycode:
      0089B9 12 38 3B         [24] 2278 	lcall	_ak820_outline_0103
      0089BC 90 0B 31         [24] 2279 	mov	dptr,#_decode_keycode_kc_10000_454
      0089BF 12 38 40         [24] 2280 	lcall	_ak820_outline_0104
                                   2281 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      0089C2 90 0B 31         [24] 2282 	mov	dptr,#_decode_keycode_kc_10000_454
      0089C5 12 37 C3         [24] 2283 	lcall	_ak820_outline_0009
      0089C8 C3               [12] 2284 	clr	c
      0089C9 E4               [12] 2285 	clr	a
      0089CA 9C               [12] 2286 	subb	a,r4
      0089CB 74 FF            [12] 2287 	mov	a,#0xff
      0089CD 9D               [12] 2288 	subb	a,r5
      0089CE 50 08            [24] 2289 	jnc	00102$
                                   2290 ;	free result
                                   2291 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      0089D0 8C 05            [24] 2292 	mov	ar5,r4
      0089D2 7C 00            [12] 2293 	mov	r4,#0x00
      0089D4 12 38 4C         [24] 2294 	lcall	_ak820_outline_0117
      0089D7 22               [24] 2295 	ret
      0089D8                       2296 00102$:
                                   2297 ;	quantum/dynamic_keymap.c:672: return kc;
      0089D8 12 43 17         [24] 2298 	lcall	_ak820_outline_0116
                                   2299 ;	quantum/dynamic_keymap.c:673: }
      0089DB 22               [24] 2300 	ret
                                   2301 ;------------------------------------------------------------
                                   2302 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2303 ;------------------------------------------------------------
                                   2304 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_457'
                                   2305 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_458'
                                   2306 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_463'
                                   2307 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_464'
                                   2308 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_470'
                                   2309 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_488'
                                   2310 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_492'
                                   2311 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_492'
                                   2312 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_494'
                                   2313 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_496'
                                   2314 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_500'
                                   2315 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_502'
                                   2316 ;------------------------------------------------------------
                                   2317 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2318 ;	-----------------------------------------
                                   2319 ;	 function dynamic_keymap_macro_send
                                   2320 ;	-----------------------------------------
      0089DC                       2321 _dynamic_keymap_macro_send:
      0089DC E5 82            [12] 2322 	mov	a,dpl
      0089DE 90 0B 33         [24] 2323 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      0089E1 F0               [24] 2324 	movx	@dptr,a
                                   2325 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      0089E2 90 0B 34         [24] 2326 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      0089E5 E0               [24] 2327 	movx	a,@dptr
      0089E6 60 01            [24] 2328 	jz	00102$
      0089E8 22               [24] 2329 	ret
      0089E9                       2330 00102$:
                                   2331 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      0089E9 90 0B 33         [24] 2332 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      0089EC E0               [24] 2333 	movx	a,@dptr
      0089ED FF               [12] 2334 	mov	r7,a
      0089EE BF 10 00         [24] 2335 	cjne	r7,#0x10,00422$
      0089F1                       2336 00422$:
      0089F1 40 01            [24] 2337 	jc	00104$
                                   2338 ;	quantum/dynamic_keymap.c:683: return;
      0089F3 22               [24] 2339 	ret
      0089F4                       2340 00104$:
                                   2341 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      0089F4 C0 07            [24] 2342 	push	ar7
      0089F6 12 2A F2         [24] 2343 	lcall	_ak820_macro_ready
      0089F9 E5 82            [12] 2344 	mov	a, dpl
      0089FB D0 07            [24] 2345 	pop	ar7
      0089FD 70 01            [24] 2346 	jnz	00106$
      0089FF 22               [24] 2347 	ret
      008A00                       2348 00106$:
                                   2349 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008A00 90 0B 35         [24] 2350 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008A03 E4               [12] 2351 	clr	a
      008A04 F0               [24] 2352 	movx	@dptr,a
      008A05 74 08            [12] 2353 	mov	a,#0x08
      008A07 A3               [24] 2354 	inc	dptr
      008A08 F0               [24] 2355 	movx	@dptr,a
                                   2356 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008A09 C0 07            [24] 2357 	push	ar7
      008A0B 12 2B 2B         [24] 2358 	lcall	_ak820_macro_length
      008A0E AD 82            [24] 2359 	mov	r5, dpl
      008A10 AE 83            [24] 2360 	mov	r6, dph
      008A12 D0 07            [24] 2361 	pop	ar7
      008A14 74 08            [12] 2362 	mov	a,#0x08
      008A16 2E               [12] 2363 	add	a, r6
      008A17 FE               [12] 2364 	mov	r6,a
                                   2365 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      008A18 7B 00            [12] 2366 	mov	r3,#0x00
      008A1A 7C 08            [12] 2367 	mov	r4,#0x08
      008A1C                       2368 00111$:
      008A1C EF               [12] 2369 	mov	a,r7
      008A1D 60 31            [24] 2370 	jz	00113$
                                   2371 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008A1F EB               [12] 2372 	mov	a,r3
      008A20 B5 05 05         [24] 2373 	cjne	a,ar5,00108$
      008A23 EC               [12] 2374 	mov	a,r4
      008A24 B5 06 01         [24] 2375 	cjne	a,ar6,00108$
                                   2376 ;	quantum/dynamic_keymap.c:717: return;
      008A27 22               [24] 2377 	ret
      008A28                       2378 00108$:
                                   2379 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008A28 8B 01            [24] 2380 	mov	ar1,r3
      008A2A 8C 02            [24] 2381 	mov	ar2,r4
      008A2C 8A 00            [24] 2382 	mov	ar0,r2
      008A2E 7A 00            [12] 2383 	mov	r2,#0x00
      008A30 89 82            [24] 2384 	mov	dpl, r1
      008A32 88 83            [24] 2385 	mov	dph, r0
      008A34 8A F0            [24] 2386 	mov	b, r2
      008A36 12 40 2F         [24] 2387 	lcall	_eeprom_read_byte
      008A39 E5 82            [12] 2388 	mov	a, dpl
      008A3B 70 06            [24] 2389 	jnz	00110$
                                   2390 ;	quantum/dynamic_keymap.c:720: --id;
      008A3D 1F               [12] 2391 	dec	r7
      008A3E 90 0B 33         [24] 2392 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008A41 EF               [12] 2393 	mov	a,r7
      008A42 F0               [24] 2394 	movx	@dptr,a
      008A43                       2395 00110$:
                                   2396 ;	quantum/dynamic_keymap.c:722: ++p;
      008A43 0B               [12] 2397 	inc	r3
      008A44 BB 00 01         [24] 2398 	cjne	r3,#0x00,00429$
      008A47 0C               [12] 2399 	inc	r4
      008A48                       2400 00429$:
      008A48 90 0B 35         [24] 2401 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008A4B 12 38 23         [24] 2402 	lcall	_ak820_outline_0076
      008A4E 80 CC            [24] 2403 	sjmp	00111$
      008A50                       2404 00113$:
                                   2405 ;	quantum/dynamic_keymap.c:728: sending = true;
      008A50 90 0B 34         [24] 2406 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008A53 74 01            [12] 2407 	mov	a,#0x01
      008A55 F0               [24] 2408 	movx	@dptr,a
                                   2409 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      008A56 12 8C F3         [24] 2410 	lcall	_ak820_outline_0159
      008A59 90 09 7D         [24] 2411 	mov	dptr,#_ak820_macro_cancelled
      008A5C F0               [24] 2412 	movx	@dptr,a
                                   2413 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      008A5D 90 0B 37         [24] 2414 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008A60 F0               [24] 2415 	movx	@dptr,a
      008A61 90 0B 38         [24] 2416 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008A64 F0               [24] 2417 	movx	@dptr,a
      008A65 90 0B 39         [24] 2418 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008A68 F0               [24] 2419 	movx	@dptr,a
      008A69 90 0B 3A         [24] 2420 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008A6C F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	quantum/dynamic_keymap.c:738: while (p < end
      008A6D                       2423 00167$:
                                   2424 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      008A6D 90 0B 35         [24] 2425 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008A70 E0               [24] 2426 	movx	a,@dptr
      008A71 FC               [12] 2427 	mov	r4,a
      008A72 A3               [24] 2428 	inc	dptr
      008A73 E0               [24] 2429 	movx	a,@dptr
      008A74 FF               [12] 2430 	mov	r7,a
      008A75 C3               [12] 2431 	clr	c
      008A76 EC               [12] 2432 	mov	a,r4
      008A77 9D               [12] 2433 	subb	a,r5
      008A78 EF               [12] 2434 	mov	a,r7
      008A79 9E               [12] 2435 	subb	a,r6
      008A7A 40 02            [24] 2436 	jc	00430$
      008A7C 81 81            [12] 2437 	ajmp	00169$
      008A7E                       2438 00430$:
      008A7E 90 09 7D         [24] 2439 	mov	dptr,#_ak820_macro_cancelled
      008A81 E0               [24] 2440 	movx	a,@dptr
      008A82 60 02            [24] 2441 	jz	00431$
      008A84 81 81            [12] 2442 	ajmp	00169$
      008A86                       2443 00431$:
                                   2444 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008A86 8C 02            [24] 2445 	mov	ar2,r4
      008A88 8F 03            [24] 2446 	mov	ar3,r7
      008A8A 90 0B 35         [24] 2447 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008A8D 74 01            [12] 2448 	mov	a,#0x01
      008A8F 2C               [12] 2449 	add	a, r4
      008A90 F0               [24] 2450 	movx	@dptr,a
      008A91 E4               [12] 2451 	clr	a
      008A92 3F               [12] 2452 	addc	a, r7
      008A93 A3               [24] 2453 	inc	dptr
      008A94 F0               [24] 2454 	movx	@dptr,a
      008A95 7F 00            [12] 2455 	mov	r7,#0x00
      008A97 12 43 33         [24] 2456 	lcall	_ak820_outline_0139
      008A9A 8F F0            [24] 2457 	mov	b, r7
      008A9C 12 40 2F         [24] 2458 	lcall	_eeprom_read_byte
      008A9F AF 82            [24] 2459 	mov	r7, dpl
      008AA1 90 0B 37         [24] 2460 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008AA4 EF               [12] 2461 	mov	a,r7
      008AA5 F0               [24] 2462 	movx	@dptr,a
                                   2463 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      008AA6 90 0B 38         [24] 2464 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008AA9 E4               [12] 2465 	clr	a
      008AAA F0               [24] 2466 	movx	@dptr,a
                                   2467 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      008AAB 90 0B 37         [24] 2468 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008AAE E0               [24] 2469 	movx	a,@dptr
      008AAF 70 02            [24] 2470 	jnz	00432$
      008AB1 81 81            [12] 2471 	ajmp	00169$
      008AB3                       2472 00432$:
                                   2473 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      008AB3 90 0B 37         [24] 2474 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008AB6 E0               [24] 2475 	movx	a,@dptr
      008AB7 FF               [12] 2476 	mov	r7,a
      008AB8 BF 01 02         [24] 2477 	cjne	r7,#0x01,00433$
      008ABB 80 02            [24] 2478 	sjmp	00434$
      008ABD                       2479 00433$:
      008ABD 81 64            [12] 2480 	ajmp	00164$
      008ABF                       2481 00434$:
                                   2482 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008ABF 12 8C 89         [24] 2483 	lcall	_ak820_outline_0000
      008AC2 12 40 2F         [24] 2484 	lcall	_eeprom_read_byte
      008AC5 AF 82            [24] 2485 	mov	r7, dpl
      008AC7 90 0B 38         [24] 2486 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008ACA EF               [12] 2487 	mov	a,r7
      008ACB F0               [24] 2488 	movx	@dptr,a
                                   2489 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      008ACC EF               [12] 2490 	mov	a,r7
      008ACD 70 02            [24] 2491 	jnz	00435$
      008ACF 81 81            [12] 2492 	ajmp	00169$
      008AD1                       2493 00435$:
                                   2494 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008AD1 12 8C C1         [24] 2495 	lcall	_ak820_outline_0089
      008AD4 BF 01 02         [24] 2496 	cjne	r7,#0x01,00436$
      008AD7 80 12            [24] 2497 	sjmp	00151$
      008AD9                       2498 00436$:
      008AD9 12 8C C1         [24] 2499 	lcall	_ak820_outline_0089
      008ADC BF 02 02         [24] 2500 	cjne	r7,#0x02,00437$
      008ADF 80 0A            [24] 2501 	sjmp	00151$
      008AE1                       2502 00437$:
      008AE1 12 8C C1         [24] 2503 	lcall	_ak820_outline_0089
      008AE4 BF 03 02         [24] 2504 	cjne	r7,#0x03,00438$
      008AE7 80 02            [24] 2505 	sjmp	00439$
      008AE9                       2506 00438$:
      008AE9 61 4A            [12] 2507 	ajmp	00152$
      008AEB                       2508 00439$:
      008AEB                       2509 00151$:
                                   2510 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008AEB 12 8C 89         [24] 2511 	lcall	_ak820_outline_0000
      008AEE 12 40 2F         [24] 2512 	lcall	_eeprom_read_byte
      008AF1 12 8D 0B         [24] 2513 	lcall	_ak820_outline_0177
                                   2514 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      008AF4 70 02            [24] 2515 	jnz	00440$
      008AF6 41 6D            [12] 2516 	ajmp	00167$
      008AF8                       2517 00440$:
                                   2518 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008AF8 12 8C C1         [24] 2519 	lcall	_ak820_outline_0089
      008AFB BF 01 03         [24] 2520 	cjne	r7,#0x01,00441$
      008AFE D3               [12] 2521 	setb	c
      008AFF 80 01            [24] 2522 	sjmp	00442$
      008B01                       2523 00441$:
      008B01 C3               [12] 2524 	clr	c
      008B02                       2525 00442$:
      008B02 92 22            [24] 2526 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008B04 90 09 7C         [24] 2527 	mov	dptr,#_ak820_macro_primitive
      008B07 B3               [12] 2528 	cpl	c
      008B08 E4               [12] 2529 	clr	a
      008B09 33               [12] 2530 	rlc	a
      008B0A F0               [24] 2531 	movx	@dptr,a
                                   2532 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008B0B 12 8C C1         [24] 2533 	lcall	_ak820_outline_0089
      008B0E BF 01 10         [24] 2534 	cjne	r7,#0x01,00122$
      008B11 12 8C EC         [24] 2535 	lcall	_ak820_outline_0146
      008B14 C0 06            [24] 2536 	push	ar6
      008B16 C0 05            [24] 2537 	push	ar5
      008B18 12 75 0D         [24] 2538 	lcall	_tap_code
      008B1B D0 05            [24] 2539 	pop	ar5
      008B1D D0 06            [24] 2540 	pop	ar6
      008B1F 80 24            [24] 2541 	sjmp	00123$
      008B21                       2542 00122$:
                                   2543 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008B21 12 8C C1         [24] 2544 	lcall	_ak820_outline_0089
      008B24 BF 02 10         [24] 2545 	cjne	r7,#0x02,00119$
      008B27 12 8C EC         [24] 2546 	lcall	_ak820_outline_0146
      008B2A C0 06            [24] 2547 	push	ar6
      008B2C C0 05            [24] 2548 	push	ar5
      008B2E 12 74 09         [24] 2549 	lcall	_register_code
      008B31 D0 05            [24] 2550 	pop	ar5
      008B33 D0 06            [24] 2551 	pop	ar6
      008B35 80 0E            [24] 2552 	sjmp	00123$
      008B37                       2553 00119$:
                                   2554 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      008B37 12 8C EC         [24] 2555 	lcall	_ak820_outline_0146
      008B3A C0 06            [24] 2556 	push	ar6
      008B3C C0 05            [24] 2557 	push	ar5
      008B3E 12 74 76         [24] 2558 	lcall	_unregister_code
      008B41 D0 05            [24] 2559 	pop	ar5
      008B43 D0 06            [24] 2560 	pop	ar6
      008B45                       2561 00123$:
                                   2562 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      008B45 12 8C F3         [24] 2563 	lcall	_ak820_outline_0159
      008B48 41 6D            [12] 2564 	ajmp	00167$
      008B4A                       2565 00152$:
                                   2566 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008B4A 12 8C C1         [24] 2567 	lcall	_ak820_outline_0089
      008B4D BF 05 02         [24] 2568 	cjne	r7,#0x05,00447$
      008B50 80 12            [24] 2569 	sjmp	00146$
      008B52                       2570 00447$:
      008B52 12 8C C1         [24] 2571 	lcall	_ak820_outline_0089
      008B55 BF 06 02         [24] 2572 	cjne	r7,#0x06,00448$
      008B58 80 0A            [24] 2573 	sjmp	00146$
      008B5A                       2574 00448$:
      008B5A 12 8C C1         [24] 2575 	lcall	_ak820_outline_0089
      008B5D BF 07 02         [24] 2576 	cjne	r7,#0x07,00449$
      008B60 80 02            [24] 2577 	sjmp	00450$
      008B62                       2578 00449$:
      008B62 81 06            [12] 2579 	ajmp	00147$
      008B64                       2580 00450$:
      008B64                       2581 00146$:
                                   2582 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008B64 12 8C 89         [24] 2583 	lcall	_ak820_outline_0000
      008B67 12 40 2F         [24] 2584 	lcall	_eeprom_read_byte
      008B6A 12 8D 0B         [24] 2585 	lcall	_ak820_outline_0177
                                   2586 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      008B6D 70 02            [24] 2587 	jnz	00451$
      008B6F 41 6D            [12] 2588 	ajmp	00167$
      008B71                       2589 00451$:
                                   2590 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008B71 12 8C 89         [24] 2591 	lcall	_ak820_outline_0000
      008B74 12 40 2F         [24] 2592 	lcall	_eeprom_read_byte
      008B77 AF 82            [24] 2593 	mov	r7, dpl
      008B79 90 0B 3A         [24] 2594 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008B7C EF               [12] 2595 	mov	a,r7
      008B7D F0               [24] 2596 	movx	@dptr,a
                                   2597 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      008B7E EF               [12] 2598 	mov	a,r7
      008B7F 70 02            [24] 2599 	jnz	00452$
      008B81 41 6D            [12] 2600 	ajmp	00167$
      008B83                       2601 00452$:
                                   2602 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008B83 90 0B 39         [24] 2603 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008B86 E0               [24] 2604 	movx	a,@dptr
      008B87 FF               [12] 2605 	mov	r7,a
      008B88 90 0B 3A         [24] 2606 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008B8B E0               [24] 2607 	movx	a,@dptr
      008B8C FB               [12] 2608 	mov	r3,a
      008B8D E4               [12] 2609 	clr	a
      008B8E FC               [12] 2610 	mov	r4,a
      008B8F FA               [12] 2611 	mov	r2,a
      008B90 EF               [12] 2612 	mov	a,r7
      008B91 42 04            [12] 2613 	orl	ar4,a
      008B93 EA               [12] 2614 	mov	a,r2
      008B94 42 03            [12] 2615 	orl	ar3,a
                                   2616 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      008B96 12 43 53         [24] 2617 	lcall	_ak820_outline_0179
      008B99 C0 06            [24] 2618 	push	ar6
      008B9B C0 05            [24] 2619 	push	ar5
      008B9D 31 B9            [12] 2620 	acall	_decode_keycode
      008B9F AC 82            [24] 2621 	mov	r4, dpl
      008BA1 AF 83            [24] 2622 	mov	r7, dph
      008BA3 D0 05            [24] 2623 	pop	ar5
      008BA5 D0 06            [24] 2624 	pop	ar6
                                   2625 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008BA7 90 0B 38         [24] 2626 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008BAA E0               [24] 2627 	movx	a,@dptr
      008BAB FB               [12] 2628 	mov	r3,a
      008BAC BB 05 03         [24] 2629 	cjne	r3,#0x05,00453$
      008BAF D3               [12] 2630 	setb	c
      008BB0 80 01            [24] 2631 	sjmp	00454$
      008BB2                       2632 00453$:
      008BB2 C3               [12] 2633 	clr	c
      008BB3                       2634 00454$:
      008BB3 92 22            [24] 2635 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008BB5 90 09 7C         [24] 2636 	mov	dptr,#_ak820_macro_primitive
      008BB8 B3               [12] 2637 	cpl	c
      008BB9 E4               [12] 2638 	clr	a
      008BBA 33               [12] 2639 	rlc	a
      008BBB F0               [24] 2640 	movx	@dptr,a
                                   2641 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      008BBC 90 0B 38         [24] 2642 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008BBF E0               [24] 2643 	movx	a,@dptr
      008BC0 FB               [12] 2644 	mov	r3,a
      008BC1 BB 05 02         [24] 2645 	cjne	r3,#0x05,00455$
      008BC4 80 0A            [24] 2646 	sjmp	00126$
      008BC6                       2647 00455$:
      008BC6 BB 06 02         [24] 2648 	cjne	r3,#0x06,00456$
      008BC9 80 16            [24] 2649 	sjmp	00127$
      008BCB                       2650 00456$:
                                   2651 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      008BCB BB 07 33         [24] 2652 	cjne	r3,#0x07,00129$
      008BCE 80 22            [24] 2653 	sjmp	00128$
      008BD0                       2654 00126$:
                                   2655 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      008BD0 8C 82            [24] 2656 	mov	dpl, r4
      008BD2 8F 83            [24] 2657 	mov	dph, r7
      008BD4 C0 06            [24] 2658 	push	ar6
      008BD6 C0 05            [24] 2659 	push	ar5
      008BD8 12 AE F4         [24] 2660 	lcall	_vial_keycode_tap
      008BDB D0 05            [24] 2661 	pop	ar5
      008BDD D0 06            [24] 2662 	pop	ar6
                                   2663 ;	quantum/dynamic_keymap.c:795: break;
                                   2664 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      008BDF 80 20            [24] 2665 	sjmp	00129$
      008BE1                       2666 00127$:
                                   2667 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      008BE1 8C 82            [24] 2668 	mov	dpl, r4
      008BE3 8F 83            [24] 2669 	mov	dph, r7
      008BE5 C0 06            [24] 2670 	push	ar6
      008BE7 C0 05            [24] 2671 	push	ar5
      008BE9 12 AE 29         [24] 2672 	lcall	_vial_keycode_down
      008BEC D0 05            [24] 2673 	pop	ar5
      008BEE D0 06            [24] 2674 	pop	ar6
                                   2675 ;	quantum/dynamic_keymap.c:798: break;
                                   2676 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      008BF0 80 0F            [24] 2677 	sjmp	00129$
      008BF2                       2678 00128$:
                                   2679 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      008BF2 8C 82            [24] 2680 	mov	dpl, r4
      008BF4 8F 83            [24] 2681 	mov	dph, r7
      008BF6 C0 06            [24] 2682 	push	ar6
      008BF8 C0 05            [24] 2683 	push	ar5
      008BFA 12 AE 8F         [24] 2684 	lcall	_vial_keycode_up
      008BFD D0 05            [24] 2685 	pop	ar5
      008BFF D0 06            [24] 2686 	pop	ar6
                                   2687 ;	quantum/dynamic_keymap.c:802: }
      008C01                       2688 00129$:
                                   2689 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      008C01 12 8C F3         [24] 2690 	lcall	_ak820_outline_0159
      008C04 41 6D            [12] 2691 	ajmp	00167$
      008C06                       2692 00147$:
                                   2693 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      008C06 12 8C C1         [24] 2694 	lcall	_ak820_outline_0089
      008C09 BF 04 02         [24] 2695 	cjne	r7,#0x04,00458$
      008C0C 80 02            [24] 2696 	sjmp	00459$
      008C0E                       2697 00458$:
      008C0E 41 6D            [12] 2698 	ajmp	00167$
      008C10                       2699 00459$:
                                   2700 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008C10 12 8C 89         [24] 2701 	lcall	_ak820_outline_0000
      008C13 12 40 2F         [24] 2702 	lcall	_eeprom_read_byte
      008C16 AF 82            [24] 2703 	mov	r7, dpl
                                   2704 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008C18 90 0B 35         [24] 2705 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008C1B 12 38 51         [24] 2706 	lcall	_ak820_outline_0120
      008C1E 90 0B 35         [24] 2707 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008C21 74 01            [12] 2708 	mov	a,#0x01
      008C23 2B               [12] 2709 	add	a, r3
      008C24 F0               [24] 2710 	movx	@dptr,a
      008C25 E4               [12] 2711 	clr	a
      008C26 3C               [12] 2712 	addc	a, r4
      008C27 A3               [24] 2713 	inc	dptr
      008C28 F0               [24] 2714 	movx	@dptr,a
      008C29 7A 00            [12] 2715 	mov	r2,#0x00
      008C2B 12 33 FC         [24] 2716 	lcall	_ak820_outline_0121
      008C2E 8A F0            [24] 2717 	mov	b, r2
      008C30 12 40 2F         [24] 2718 	lcall	_eeprom_read_byte
      008C33 AC 82            [24] 2719 	mov	r4, dpl
                                   2720 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      008C35 EF               [12] 2721 	mov	a,r7
      008C36 60 49            [24] 2722 	jz	00169$
      008C38 EC               [12] 2723 	mov	a,r4
      008C39 60 46            [24] 2724 	jz	00169$
                                   2725 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008C3B 1F               [12] 2726 	dec	r7
      008C3C 1C               [12] 2727 	dec	r4
      008C3D EC               [12] 2728 	mov	a,r4
      008C3E 75 F0 FF         [24] 2729 	mov	b,#0xff
      008C41 A4               [48] 2730 	mul	ab
      008C42 FC               [12] 2731 	mov	r4,a
      008C43 AB F0            [24] 2732 	mov	r3,b
      008C45 7A 00            [12] 2733 	mov	r2,#0x00
      008C47 EC               [12] 2734 	mov	a,r4
      008C48 2F               [12] 2735 	add	a, r7
      008C49 FC               [12] 2736 	mov	r4,a
      008C4A EB               [12] 2737 	mov	a,r3
      008C4B 3A               [12] 2738 	addc	a, r2
      008C4C FB               [12] 2739 	mov	r3,a
                                   2740 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      008C4D                       2741 00141$:
      008C4D 8C 02            [24] 2742 	mov	ar2,r4
      008C4F 8B 07            [24] 2743 	mov	ar7,r3
      008C51 1C               [12] 2744 	dec	r4
      008C52 BC FF 01         [24] 2745 	cjne	r4,#0xff,00462$
      008C55 1B               [12] 2746 	dec	r3
      008C56                       2747 00462$:
      008C56 EA               [12] 2748 	mov	a,r2
      008C57 4F               [12] 2749 	orl	a,r7
      008C58 70 02            [24] 2750 	jnz	00463$
      008C5A 41 6D            [12] 2751 	ajmp	00167$
      008C5C                       2752 00463$:
      008C5C 90 00 01         [24] 2753 	mov	dptr,#0x0001
      008C5F 12 58 34         [24] 2754 	lcall	_mDelaymS
      008C62 80 E9            [24] 2755 	sjmp	00141$
      008C64                       2756 00164$:
                                   2757 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      008C64 90 0B 37         [24] 2758 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008C67 E0               [24] 2759 	movx	a,@dptr
      008C68 FF               [12] 2760 	mov	r7,a
      008C69 BF 80 00         [24] 2761 	cjne	r7,#0x80,00464$
      008C6C                       2762 00464$:
      008C6C 50 13            [24] 2763 	jnc	00169$
                                   2764 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      008C6E 90 0B 37         [24] 2765 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008C71 E0               [24] 2766 	movx	a,@dptr
      008C72 F5 82            [12] 2767 	mov	dpl,a
      008C74 C0 06            [24] 2768 	push	ar6
      008C76 C0 05            [24] 2769 	push	ar5
      008C78 12 A1 AD         [24] 2770 	lcall	_send_char
      008C7B D0 05            [24] 2771 	pop	ar5
      008C7D D0 06            [24] 2772 	pop	ar6
                                   2773 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008C7F 41 6D            [12] 2774 	ajmp	00167$
      008C81                       2775 00169$:
                                   2776 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      008C81 12 8C F3         [24] 2777 	lcall	_ak820_outline_0159
                                   2778 ;	quantum/dynamic_keymap.c:837: sending = false;
      008C84 90 0B 34         [24] 2779 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008C87 F0               [24] 2780 	movx	@dptr,a
                                   2781 ;	quantum/dynamic_keymap.c:839: }
      008C88 22               [24] 2782 	ret
                                   2783 	.area CSEG    (CODE)
                                   2784 	.area CONST   (CODE)
                                   2785 	.area XINIT   (CODE)
                                   2786 	.area CABS    (ABS,CODE)
                                   2787 
                                   2788 ; Experimental exact instruction outlining.
                                   2789 	.globl _ak820_outline_0000
                                   2790 	.globl _ak820_outline_0004
                                   2791 	.globl _ak820_outline_0009
                                   2792 	.globl _ak820_outline_0011
                                   2793 	.globl _ak820_outline_0016
                                   2794 	.globl _ak820_outline_0024
                                   2795 	.globl _ak820_outline_0030
                                   2796 	.globl _ak820_outline_0043
                                   2797 	.globl _ak820_outline_0050
                                   2798 	.globl _ak820_outline_0058
                                   2799 	.globl _ak820_outline_0059
                                   2800 	.globl _ak820_outline_0060
                                   2801 	.globl _ak820_outline_0070
                                   2802 	.globl _ak820_outline_0074
                                   2803 	.globl _ak820_outline_0076
                                   2804 	.globl _ak820_outline_0078
                                   2805 	.globl _ak820_outline_0087
                                   2806 	.globl _ak820_outline_0089
                                   2807 	.globl _ak820_outline_0095
                                   2808 	.globl _ak820_outline_0096
                                   2809 	.globl _ak820_outline_0099
                                   2810 	.globl _ak820_outline_0103
                                   2811 	.globl _ak820_outline_0104
                                   2812 	.globl _ak820_outline_0112
                                   2813 	.globl _ak820_outline_0116
                                   2814 	.globl _ak820_outline_0117
                                   2815 	.globl _ak820_outline_0119
                                   2816 	.globl _ak820_outline_0120
                                   2817 	.globl _ak820_outline_0121
                                   2818 	.globl _ak820_outline_0122
                                   2819 	.globl _ak820_outline_0126
                                   2820 	.globl _ak820_outline_0130
                                   2821 	.globl _ak820_outline_0131
                                   2822 	.globl _ak820_outline_0132
                                   2823 	.globl _ak820_outline_0133
                                   2824 	.globl _ak820_outline_0138
                                   2825 	.globl _ak820_outline_0139
                                   2826 	.globl _ak820_outline_0144
                                   2827 	.globl _ak820_outline_0146
                                   2828 	.globl _ak820_outline_0150
                                   2829 	.globl _ak820_outline_0151
                                   2830 	.globl _ak820_outline_0154
                                   2831 	.globl _ak820_outline_0159
                                   2832 	.globl _ak820_outline_0165
                                   2833 	.globl _ak820_outline_0173
                                   2834 	.globl _ak820_outline_0174
                                   2835 	.globl _ak820_outline_0177
                                   2836 	.globl _ak820_outline_0178
                                   2837 	.globl _ak820_outline_0179
                                   2838 
                                   2839 	.area CSEG (CODE)
                                   2840 ; function ak820_outline_0000
      008C89                       2841 _ak820_outline_0000:
      008C89 90 0B 35         [24] 2842 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008C8C E0               [24] 2843 	movx	a,@dptr
      008C8D FC               [12] 2844 	mov	r4,a
      008C8E A3               [24] 2845 	inc	dptr
      008C8F E0               [24] 2846 	movx	a,@dptr
      008C90 FF               [12] 2847 	mov	r7,a
      008C91 90 0B 35         [24] 2848 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008C94 74 01            [12] 2849 	mov	a,#0x01
      008C96 2C               [12] 2850 	add	a,r4
      008C97 F0               [24] 2851 	movx	@dptr,a
      008C98 E4               [12] 2852 	clr	a
      008C99 3F               [12] 2853 	addc	a,r7
      008C9A A3               [24] 2854 	inc	dptr
      008C9B F0               [24] 2855 	movx	@dptr,a
      008C9C 7B 00            [12] 2856 	mov	r3,#0x00
      008C9E 8C 82            [24] 2857 	mov	dpl,r4
      008CA0 8F 83            [24] 2858 	mov	dph,r7
      008CA2 8B F0            [24] 2859 	mov	b,r3
      008CA4 22               [24] 2860 	ret
                                   2861 
                                   2862 	.area CSEG (CODE)
                                   2863 ; function ak820_outline_0024
      008CA5                       2864 _ak820_outline_0024:
      008CA5 2D               [12] 2865 	add	a,r5
      008CA6 F9               [12] 2866 	mov	r1,a
      008CA7 E4               [12] 2867 	clr	a
      008CA8 3E               [12] 2868 	addc	a,r6
      008CA9 FA               [12] 2869 	mov	r2,a
      008CAA 8F 03            [24] 2870 	mov	ar3,r7
      008CAC 89 82            [24] 2871 	mov	dpl,r1
      008CAE 8A 83            [24] 2872 	mov	dph,r2
      008CB0 8B F0            [24] 2873 	mov	b,r3
      008CB2 22               [24] 2874 	ret
                                   2875 
                                   2876 	.area CSEG (CODE)
                                   2877 ; function ak820_outline_0078
      008CB3                       2878 _ak820_outline_0078:
      008CB3 ED               [12] 2879 	mov	a,r5
      008CB4 75 F0 0A         [24] 2880 	mov	b,#0x0a
      008CB7 A4               [48] 2881 	mul	ab
      008CB8 24 58            [12] 2882 	add	a,#0x58
      008CBA FC               [12] 2883 	mov	r4,a
      008CBB 74 06            [12] 2884 	mov	a,#0x06
      008CBD 35 F0            [12] 2885 	addc	a,b
      008CBF FD               [12] 2886 	mov	r5,a
      008CC0 22               [24] 2887 	ret
                                   2888 
                                   2889 	.area CSEG (CODE)
                                   2890 ; function ak820_outline_0089
      008CC1                       2891 _ak820_outline_0089:
      008CC1 90 0B 38         [24] 2892 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0001)
      008CC4 E0               [24] 2893 	movx	a,@dptr
      008CC5 FF               [12] 2894 	mov	r7,a
      008CC6 22               [24] 2895 	ret
                                   2896 
                                   2897 	.area CSEG (CODE)
                                   2898 ; function ak820_outline_0095
      008CC7                       2899 _ak820_outline_0095:
      008CC7 90 0A CE         [24] 2900 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008CCA EE               [12] 2901 	mov	a,r6
      008CCB F0               [24] 2902 	movx	@dptr,a
      008CCC 90 0A CF         [24] 2903 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008CCF ED               [12] 2904 	mov	a,r5
      008CD0 F0               [24] 2905 	movx	@dptr,a
      008CD1 8F 82            [24] 2906 	mov	dpl,r7
      008CD3 22               [24] 2907 	ret
                                   2908 
                                   2909 	.area CSEG (CODE)
                                   2910 ; function ak820_outline_0112
      008CD4                       2911 _ak820_outline_0112:
      008CD4 AD 82            [24] 2912 	mov	r5,dpl
      008CD6 AE 83            [24] 2913 	mov	r6,dph
      008CD8 AF F0            [24] 2914 	mov	r7,b
      008CDA 22               [24] 2915 	ret
                                   2916 
                                   2917 	.area CSEG (CODE)
                                   2918 ; function ak820_outline_0126
      008CDB                       2919 _ak820_outline_0126:
      008CDB 28               [12] 2920 	add	a,r0
      008CDC F5 82            [12] 2921 	mov	dpl,a
      008CDE EF               [12] 2922 	mov	a,r7
      008CDF 39               [12] 2923 	addc	a,r1
      008CE0 F5 83            [12] 2924 	mov	dph,a
      008CE2 74 FF            [12] 2925 	mov	a,#0xff
      008CE4 F0               [24] 2926 	movx	@dptr,a
      008CE5 22               [24] 2927 	ret
                                   2928 
                                   2929 	.area CSEG (CODE)
                                   2930 ; function ak820_outline_0132
      008CE6                       2931 _ak820_outline_0132:
      008CE6 2D               [12] 2932 	add	a,r5
      008CE7 F9               [12] 2933 	mov	r1,a
      008CE8 E4               [12] 2934 	clr	a
      008CE9 3E               [12] 2935 	addc	a,r6
      008CEA FA               [12] 2936 	mov	r2,a
      008CEB 22               [24] 2937 	ret
                                   2938 
                                   2939 	.area CSEG (CODE)
                                   2940 ; function ak820_outline_0146
      008CEC                       2941 _ak820_outline_0146:
      008CEC 90 0B 39         [24] 2942 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008CEF E0               [24] 2943 	movx	a,@dptr
      008CF0 F5 82            [12] 2944 	mov	dpl,a
      008CF2 22               [24] 2945 	ret
                                   2946 
                                   2947 	.area CSEG (CODE)
                                   2948 ; function ak820_outline_0159
      008CF3                       2949 _ak820_outline_0159:
      008CF3 90 09 7C         [24] 2950 	mov	dptr,#_ak820_macro_primitive
      008CF6 E4               [12] 2951 	clr	a
      008CF7 F0               [24] 2952 	movx	@dptr,a
      008CF8 22               [24] 2953 	ret
                                   2954 
                                   2955 	.area CSEG (CODE)
                                   2956 ; function ak820_outline_0173
      008CF9                       2957 _ak820_outline_0173:
      008CF9 90 0A DE         [24] 2958 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008CFC E4               [12] 2959 	clr	a
      008CFD F0               [24] 2960 	movx	@dptr,a
      008CFE 90 0A DF         [24] 2961 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008D01 22               [24] 2962 	ret
                                   2963 
                                   2964 	.area CSEG (CODE)
                                   2965 ; function ak820_outline_0174
      008D02                       2966 _ak820_outline_0174:
      008D02 90 0B 94         [24] 2967 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      008D05 E4               [12] 2968 	clr	a
      008D06 F0               [24] 2969 	movx	@dptr,a
      008D07 90 0B 95         [24] 2970 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      008D0A 22               [24] 2971 	ret
                                   2972 
                                   2973 	.area CSEG (CODE)
                                   2974 ; function ak820_outline_0177
      008D0B                       2975 _ak820_outline_0177:
      008D0B AF 82            [24] 2976 	mov	r7,dpl
      008D0D 90 0B 39         [24] 2977 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008D10 EF               [12] 2978 	mov	a,r7
      008D11 F0               [24] 2979 	movx	@dptr,a
      008D12 EF               [12] 2980 	mov	a,r7
      008D13 22               [24] 2981 	ret
