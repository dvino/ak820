                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _register_mouse
                                     12 	.globl _ak820_combo_cancel
                                     13 	.globl _ak820_combo_tick
                                     14 	.globl _ak820_autoshift_cancel
                                     15 	.globl _ak820_autoshift_process
                                     16 	.globl _ak820_autoshift_before
                                     17 	.globl _ak820_oneshot_cancel
                                     18 	.globl _ak820_oneshot_post
                                     19 	.globl _ak820_oneshot_process
                                     20 	.globl _ak820_tapping_source
                                     21 	.globl _ak820_tapping_cancel
                                     22 	.globl _ak820_tapping_process
                                     23 	.globl _ak820_tapping_before
                                     24 	.globl _pre_process_record_quantum
                                     25 	.globl _get_record_keycode
                                     26 	.globl _repeat_key_cancel
                                     27 	.globl _clear_owned_usages
                                     28 	.globl _owned_usage_key
                                     29 	.globl _clear_owned_keys
                                     30 	.globl _del_owned_key
                                     31 	.globl _add_owned_key
                                     32 	.globl _clear_owned_mods
                                     33 	.globl _del_owned_weak_mods
                                     34 	.globl _add_owned_weak_mods
                                     35 	.globl _del_owned_mods
                                     36 	.globl _add_owned_mods
                                     37 	.globl _clear_weak_mods
                                     38 	.globl _clear_mods
                                     39 	.globl _send_keyboard_report
                                     40 	.globl _layer_hold_clear
                                     41 	.globl _layer_hold_off
                                     42 	.globl _layer_hold_on
                                     43 	.globl _ak820_resolve_key
                                     44 	.globl _layer_xor
                                     45 	.globl _layer_and
                                     46 	.globl _layer_or
                                     47 	.globl _layer_off
                                     48 	.globl _layer_on
                                     49 	.globl _layer_move
                                     50 	.globl _layer_clear
                                     51 	.globl _layer_state_set
                                     52 	.globl _default_layer_xor
                                     53 	.globl _default_layer_and
                                     54 	.globl _default_layer_or
                                     55 	.globl _default_layer_set
                                     56 	.globl _process_record_quantum
                                     57 	.globl _action_for_keycode
                                     58 	.globl _mousekey_send
                                     59 	.globl _mousekey_clear
                                     60 	.globl _mousekey_off
                                     61 	.globl _mousekey_on
                                     62 	.globl _mDelaymS
                                     63 	.globl _host_consumer_send
                                     64 	.globl _host_system_send
                                     65 	.globl _host_keyboard_leds
                                     66 	.globl _led_set
                                     67 	.globl _clear_keys_from_report
                                     68 	.globl ___memcpy
                                     69 	.globl _ADC_START
                                     70 	.globl _S0_R_FIFO
                                     71 	.globl _S0_T_FIFO
                                     72 	.globl _S0_FREE
                                     73 	.globl _S0_IF_BYTE
                                     74 	.globl _S0_IF_FIRST
                                     75 	.globl _S0_IF_OV
                                     76 	.globl _S0_FST_ACT
                                     77 	.globl _CP_RL2
                                     78 	.globl _C_T2
                                     79 	.globl _TR2
                                     80 	.globl _EXEN2
                                     81 	.globl _TCLK
                                     82 	.globl _RCLK
                                     83 	.globl _EXF2
                                     84 	.globl _CAP1F
                                     85 	.globl _TF2
                                     86 	.globl _RI
                                     87 	.globl _TI
                                     88 	.globl _RB8
                                     89 	.globl _TB8
                                     90 	.globl _REN
                                     91 	.globl _SM2
                                     92 	.globl _SM1
                                     93 	.globl _SM0
                                     94 	.globl _IT0
                                     95 	.globl _IE0
                                     96 	.globl _IT1
                                     97 	.globl _IE1
                                     98 	.globl _TR0
                                     99 	.globl _TF0
                                    100 	.globl _TR1
                                    101 	.globl _TF1
                                    102 	.globl _P4_0
                                    103 	.globl _P4_1
                                    104 	.globl _P4_2
                                    105 	.globl _P4_3
                                    106 	.globl _P4_4
                                    107 	.globl _P4_5
                                    108 	.globl _P4_6
                                    109 	.globl _RXD
                                    110 	.globl _TXD
                                    111 	.globl _INT0
                                    112 	.globl _INT1
                                    113 	.globl _T0
                                    114 	.globl _T1
                                    115 	.globl _MOSI1
                                    116 	.globl _MISO1
                                    117 	.globl _SCK1
                                    118 	.globl _P3_0
                                    119 	.globl _P3_1
                                    120 	.globl _P3_2
                                    121 	.globl _P3_3
                                    122 	.globl _P3_4
                                    123 	.globl _P3_5
                                    124 	.globl _P3_6
                                    125 	.globl _P3_7
                                    126 	.globl _CAP1_
                                    127 	.globl _T2_
                                    128 	.globl _CAP2_
                                    129 	.globl _T2EX_
                                    130 	.globl _RXD1
                                    131 	.globl _TXD1
                                    132 	.globl _P2_0
                                    133 	.globl _P2_1
                                    134 	.globl _P2_2
                                    135 	.globl _P2_3
                                    136 	.globl _P2_4
                                    137 	.globl _P2_5
                                    138 	.globl _P2_6
                                    139 	.globl _P2_7
                                    140 	.globl _AIN0
                                    141 	.globl _AIN1
                                    142 	.globl _AIN2
                                    143 	.globl _AIN3
                                    144 	.globl _AIN4
                                    145 	.globl _AIN5
                                    146 	.globl _AIN6
                                    147 	.globl _AIN7
                                    148 	.globl _CAP1
                                    149 	.globl _T2
                                    150 	.globl _CAP2
                                    151 	.globl _T2EX
                                    152 	.globl _INT0_
                                    153 	.globl _SCS
                                    154 	.globl _MOSI
                                    155 	.globl _MISO
                                    156 	.globl _SCK
                                    157 	.globl _RXD1_
                                    158 	.globl _TXD1_
                                    159 	.globl _P1_0
                                    160 	.globl _P1_1
                                    161 	.globl _P1_2
                                    162 	.globl _P1_3
                                    163 	.globl _P1_4
                                    164 	.globl _P1_5
                                    165 	.globl _P1_6
                                    166 	.globl _P1_7
                                    167 	.globl _AIN8
                                    168 	.globl _AIN9
                                    169 	.globl _AIN10
                                    170 	.globl _AIN11
                                    171 	.globl _AIN12
                                    172 	.globl _AIN13
                                    173 	.globl _RXD_
                                    174 	.globl _TXD_
                                    175 	.globl _SCL0
                                    176 	.globl _SDA0
                                    177 	.globl _P0_0
                                    178 	.globl _P0_1
                                    179 	.globl _P0_2
                                    180 	.globl _P0_3
                                    181 	.globl _P0_4
                                    182 	.globl _P0_5
                                    183 	.globl _P0_6
                                    184 	.globl _P0_7
                                    185 	.globl _IE_SPI0
                                    186 	.globl _IE_USB
                                    187 	.globl _IE_ADC
                                    188 	.globl _IE_UART1
                                    189 	.globl _IE_PWM_I2C
                                    190 	.globl _IE_GPIO
                                    191 	.globl _IE_WDOG
                                    192 	.globl _PX0
                                    193 	.globl _PT0
                                    194 	.globl _PX1
                                    195 	.globl _PT1
                                    196 	.globl _PS
                                    197 	.globl _PT2
                                    198 	.globl _PL_FLAG
                                    199 	.globl _PH_FLAG
                                    200 	.globl _EX0
                                    201 	.globl _ET0
                                    202 	.globl _EX1
                                    203 	.globl _ET1
                                    204 	.globl _ES
                                    205 	.globl _ET2
                                    206 	.globl _E_DIS
                                    207 	.globl _EA
                                    208 	.globl _P
                                    209 	.globl _F1
                                    210 	.globl _OV
                                    211 	.globl _RS0
                                    212 	.globl _RS1
                                    213 	.globl _F0
                                    214 	.globl _AC
                                    215 	.globl _CY
                                    216 	.globl _I2CS_INT_ST
                                    217 	.globl _I2CX_INT
                                    218 	.globl _LED_STATUS
                                    219 	.globl _LED_DMA_H
                                    220 	.globl _LED_DMA_L
                                    221 	.globl _LED_DMA
                                    222 	.globl _LED_PWM_OE
                                    223 	.globl _LED_COMMON
                                    224 	.globl _ADC_CHAN
                                    225 	.globl _ADC_DAT_H
                                    226 	.globl _ADC_DAT_L
                                    227 	.globl _ADC_DAT
                                    228 	.globl _ADC_CTRL
                                    229 	.globl _SPI1_CK_SE
                                    230 	.globl _SPI1_CTRL
                                    231 	.globl _SPI1_DATA
                                    232 	.globl _SPI1_STAT
                                    233 	.globl _SIF1
                                    234 	.globl _SBAUD1
                                    235 	.globl _SBUF1
                                    236 	.globl _SCON1
                                    237 	.globl _SPI0_SETUP
                                    238 	.globl _SPI0_CK_SE
                                    239 	.globl _SPI0_CTRL
                                    240 	.globl _SPI0_DATA
                                    241 	.globl _SPI0_STAT
                                    242 	.globl _T2CAP1H
                                    243 	.globl _T2CAP1L
                                    244 	.globl _T2CAP1
                                    245 	.globl _TH2
                                    246 	.globl _TL2
                                    247 	.globl _T2COUNT
                                    248 	.globl _RCAP2H
                                    249 	.globl _RCAP2L
                                    250 	.globl _RCAP2
                                    251 	.globl _T2MOD
                                    252 	.globl _T2CON
                                    253 	.globl _SBUF
                                    254 	.globl _SCON
                                    255 	.globl _TH1
                                    256 	.globl _TH0
                                    257 	.globl _TL1
                                    258 	.globl _TL0
                                    259 	.globl _TMOD
                                    260 	.globl _TCON
                                    261 	.globl _XBUS_AUX
                                    262 	.globl _P7
                                    263 	.globl _P6_DIR
                                    264 	.globl _P6_OUT_PU
                                    265 	.globl _P6_IN
                                    266 	.globl _P5_DIR
                                    267 	.globl _P5_OUT_PU
                                    268 	.globl _P5_IN
                                    269 	.globl _P4_LED_KEY
                                    270 	.globl _P4_DIR_PU
                                    271 	.globl _P4_MOD_OC
                                    272 	.globl _P4
                                    273 	.globl _P3_DIR_PU
                                    274 	.globl _P3_MOD_OC
                                    275 	.globl _P3
                                    276 	.globl _P2_DIR_PU
                                    277 	.globl _P2_MOD_OC
                                    278 	.globl _P2
                                    279 	.globl _P1_DIR_PU
                                    280 	.globl _P1_MOD_OC
                                    281 	.globl _P1
                                    282 	.globl _P0_DIR_PU
                                    283 	.globl _P0_MOD_OC
                                    284 	.globl _P0
                                    285 	.globl _ROM_CTRL
                                    286 	.globl _ROM_DATA_HH
                                    287 	.globl _ROM_DATA_HL
                                    288 	.globl _ROM_DATA_HI
                                    289 	.globl _ROM_ADDR_H
                                    290 	.globl _ROM_ADDR_L
                                    291 	.globl _ROM_ADDR
                                    292 	.globl _GPIO_IE
                                    293 	.globl _IP_EX
                                    294 	.globl _IE_EX
                                    295 	.globl _IP
                                    296 	.globl _IE
                                    297 	.globl _WDOG_COUNT
                                    298 	.globl _RESET_KEEP
                                    299 	.globl _WAKE_CTRL
                                    300 	.globl _CLOCK_CFG
                                    301 	.globl _POWER_CFG
                                    302 	.globl _PCON
                                    303 	.globl _GLOBAL_CFG
                                    304 	.globl _SAFE_MOD
                                    305 	.globl _DPH
                                    306 	.globl _DPL
                                    307 	.globl _SP
                                    308 	.globl _A_INV
                                    309 	.globl _B
                                    310 	.globl _ACC
                                    311 	.globl _PSW
                                    312 	.globl _disable_action_cache
                                    313 	.globl _tap_code_delay_PARM_2
                                    314 	.globl _process_action_PARM_2
                                    315 	.globl _register_mouse_PARM_2
                                    316 	.globl _action_exec_PARM_1
                                    317 	.globl _tp_buttons
                                    318 	.globl _action_exec
                                    319 	.globl _ak820_action_exec
                                    320 	.globl _process_record
                                    321 	.globl _process_record_handler
                                    322 	.globl _process_action
                                    323 	.globl _register_code
                                    324 	.globl _unregister_code
                                    325 	.globl _tap_code_delay
                                    326 	.globl _tap_code
                                    327 	.globl _register_mods
                                    328 	.globl _unregister_mods
                                    329 	.globl _register_weak_mods
                                    330 	.globl _unregister_weak_mods
                                    331 	.globl _clear_keyboard
                                    332 	.globl _clear_keyboard_but_mods
                                    333 	.globl _clear_keyboard_but_mods_and_keys
                                    334 ;--------------------------------------------------------
                                    335 ; special function registers
                                    336 ;--------------------------------------------------------
                                    337 	.area RSEG    (ABS,DATA)
      000000                        338 	.org 0x0000
                           0000D0   339 _PSW	=	0x00d0
                           0000E0   340 _ACC	=	0x00e0
                           0000F0   341 _B	=	0x00f0
                           0000FD   342 _A_INV	=	0x00fd
                           000081   343 _SP	=	0x0081
                           000082   344 _DPL	=	0x0082
                           000083   345 _DPH	=	0x0083
                           0000A1   346 _SAFE_MOD	=	0x00a1
                           0000B1   347 _GLOBAL_CFG	=	0x00b1
                           000087   348 _PCON	=	0x0087
                           0000BA   349 _POWER_CFG	=	0x00ba
                           0000B9   350 _CLOCK_CFG	=	0x00b9
                           0000A9   351 _WAKE_CTRL	=	0x00a9
                           0000FE   352 _RESET_KEEP	=	0x00fe
                           0000FF   353 _WDOG_COUNT	=	0x00ff
                           0000A8   354 _IE	=	0x00a8
                           0000B8   355 _IP	=	0x00b8
                           0000E8   356 _IE_EX	=	0x00e8
                           0000E9   357 _IP_EX	=	0x00e9
                           0000B2   358 _GPIO_IE	=	0x00b2
                           008584   359 _ROM_ADDR	=	0x8584
                           000084   360 _ROM_ADDR_L	=	0x0084
                           000085   361 _ROM_ADDR_H	=	0x0085
                           008F8E   362 _ROM_DATA_HI	=	0x8f8e
                           00008E   363 _ROM_DATA_HL	=	0x008e
                           00008F   364 _ROM_DATA_HH	=	0x008f
                           000086   365 _ROM_CTRL	=	0x0086
                           000080   366 _P0	=	0x0080
                           0000C4   367 _P0_MOD_OC	=	0x00c4
                           0000C5   368 _P0_DIR_PU	=	0x00c5
                           000090   369 _P1	=	0x0090
                           000092   370 _P1_MOD_OC	=	0x0092
                           000093   371 _P1_DIR_PU	=	0x0093
                           0000A0   372 _P2	=	0x00a0
                           000094   373 _P2_MOD_OC	=	0x0094
                           000095   374 _P2_DIR_PU	=	0x0095
                           0000B0   375 _P3	=	0x00b0
                           000096   376 _P3_MOD_OC	=	0x0096
                           000097   377 _P3_DIR_PU	=	0x0097
                           0000C0   378 _P4	=	0x00c0
                           0000C2   379 _P4_MOD_OC	=	0x00c2
                           0000C3   380 _P4_DIR_PU	=	0x00c3
                           0000C1   381 _P4_LED_KEY	=	0x00c1
                           0000AA   382 _P5_IN	=	0x00aa
                           0000AB   383 _P5_OUT_PU	=	0x00ab
                           0000AC   384 _P5_DIR	=	0x00ac
                           0000AD   385 _P6_IN	=	0x00ad
                           0000AE   386 _P6_OUT_PU	=	0x00ae
                           0000AF   387 _P6_DIR	=	0x00af
                           0000F1   388 _P7	=	0x00f1
                           0000A2   389 _XBUS_AUX	=	0x00a2
                           000088   390 _TCON	=	0x0088
                           000089   391 _TMOD	=	0x0089
                           00008A   392 _TL0	=	0x008a
                           00008B   393 _TL1	=	0x008b
                           00008C   394 _TH0	=	0x008c
                           00008D   395 _TH1	=	0x008d
                           000098   396 _SCON	=	0x0098
                           000099   397 _SBUF	=	0x0099
                           0000C8   398 _T2CON	=	0x00c8
                           0000C9   399 _T2MOD	=	0x00c9
                           00CBCA   400 _RCAP2	=	0xcbca
                           0000CA   401 _RCAP2L	=	0x00ca
                           0000CB   402 _RCAP2H	=	0x00cb
                           00CDCC   403 _T2COUNT	=	0xcdcc
                           0000CC   404 _TL2	=	0x00cc
                           0000CD   405 _TH2	=	0x00cd
                           00CFCE   406 _T2CAP1	=	0xcfce
                           0000CE   407 _T2CAP1L	=	0x00ce
                           0000CF   408 _T2CAP1H	=	0x00cf
                           0000F8   409 _SPI0_STAT	=	0x00f8
                           0000F9   410 _SPI0_DATA	=	0x00f9
                           0000FA   411 _SPI0_CTRL	=	0x00fa
                           0000FB   412 _SPI0_CK_SE	=	0x00fb
                           0000FC   413 _SPI0_SETUP	=	0x00fc
                           0000BC   414 _SCON1	=	0x00bc
                           0000BD   415 _SBUF1	=	0x00bd
                           0000BE   416 _SBAUD1	=	0x00be
                           0000BF   417 _SIF1	=	0x00bf
                           0000B4   418 _SPI1_STAT	=	0x00b4
                           0000B5   419 _SPI1_DATA	=	0x00b5
                           0000B6   420 _SPI1_CTRL	=	0x00b6
                           0000B7   421 _SPI1_CK_SE	=	0x00b7
                           0000F3   422 _ADC_CTRL	=	0x00f3
                           00F5F4   423 _ADC_DAT	=	0xf5f4
                           0000F4   424 _ADC_DAT_L	=	0x00f4
                           0000F5   425 _ADC_DAT_H	=	0x00f5
                           0000F6   426 _ADC_CHAN	=	0x00f6
                           0000A6   427 _LED_COMMON	=	0x00a6
                           0000A7   428 _LED_PWM_OE	=	0x00a7
                           00C7C6   429 _LED_DMA	=	0xc7c6
                           0000C6   430 _LED_DMA_L	=	0x00c6
                           0000C7   431 _LED_DMA_H	=	0x00c7
                           0000F7   432 _LED_STATUS	=	0x00f7
                           0000B3   433 _I2CX_INT	=	0x00b3
                           0000BB   434 _I2CS_INT_ST	=	0x00bb
                                    435 ;--------------------------------------------------------
                                    436 ; special function bits
                                    437 ;--------------------------------------------------------
                                    438 	.area RSEG    (ABS,DATA)
      000000                        439 	.org 0x0000
                           0000D7   440 _CY	=	0x00d7
                           0000D6   441 _AC	=	0x00d6
                           0000D5   442 _F0	=	0x00d5
                           0000D4   443 _RS1	=	0x00d4
                           0000D3   444 _RS0	=	0x00d3
                           0000D2   445 _OV	=	0x00d2
                           0000D1   446 _F1	=	0x00d1
                           0000D0   447 _P	=	0x00d0
                           0000AF   448 _EA	=	0x00af
                           0000AE   449 _E_DIS	=	0x00ae
                           0000AD   450 _ET2	=	0x00ad
                           0000AC   451 _ES	=	0x00ac
                           0000AB   452 _ET1	=	0x00ab
                           0000AA   453 _EX1	=	0x00aa
                           0000A9   454 _ET0	=	0x00a9
                           0000A8   455 _EX0	=	0x00a8
                           0000BF   456 _PH_FLAG	=	0x00bf
                           0000BE   457 _PL_FLAG	=	0x00be
                           0000BD   458 _PT2	=	0x00bd
                           0000BC   459 _PS	=	0x00bc
                           0000BB   460 _PT1	=	0x00bb
                           0000BA   461 _PX1	=	0x00ba
                           0000B9   462 _PT0	=	0x00b9
                           0000B8   463 _PX0	=	0x00b8
                           0000EF   464 _IE_WDOG	=	0x00ef
                           0000EE   465 _IE_GPIO	=	0x00ee
                           0000ED   466 _IE_PWM_I2C	=	0x00ed
                           0000EC   467 _IE_UART1	=	0x00ec
                           0000EB   468 _IE_ADC	=	0x00eb
                           0000E9   469 _IE_USB	=	0x00e9
                           0000E8   470 _IE_SPI0	=	0x00e8
                           000087   471 _P0_7	=	0x0087
                           000086   472 _P0_6	=	0x0086
                           000085   473 _P0_5	=	0x0085
                           000084   474 _P0_4	=	0x0084
                           000083   475 _P0_3	=	0x0083
                           000082   476 _P0_2	=	0x0082
                           000081   477 _P0_1	=	0x0081
                           000080   478 _P0_0	=	0x0080
                           000081   479 _SDA0	=	0x0081
                           000080   480 _SCL0	=	0x0080
                           000083   481 _TXD_	=	0x0083
                           000082   482 _RXD_	=	0x0082
                           000085   483 _AIN13	=	0x0085
                           000084   484 _AIN12	=	0x0084
                           000083   485 _AIN11	=	0x0083
                           000082   486 _AIN10	=	0x0082
                           000081   487 _AIN9	=	0x0081
                           000080   488 _AIN8	=	0x0080
                           000097   489 _P1_7	=	0x0097
                           000096   490 _P1_6	=	0x0096
                           000095   491 _P1_5	=	0x0095
                           000094   492 _P1_4	=	0x0094
                           000093   493 _P1_3	=	0x0093
                           000092   494 _P1_2	=	0x0092
                           000091   495 _P1_1	=	0x0091
                           000090   496 _P1_0	=	0x0090
                           000097   497 _TXD1_	=	0x0097
                           000096   498 _RXD1_	=	0x0096
                           000097   499 _SCK	=	0x0097
                           000096   500 _MISO	=	0x0096
                           000095   501 _MOSI	=	0x0095
                           000094   502 _SCS	=	0x0094
                           000092   503 _INT0_	=	0x0092
                           000091   504 _T2EX	=	0x0091
                           000091   505 _CAP2	=	0x0091
                           000090   506 _T2	=	0x0090
                           000090   507 _CAP1	=	0x0090
                           000097   508 _AIN7	=	0x0097
                           000096   509 _AIN6	=	0x0096
                           000095   510 _AIN5	=	0x0095
                           000094   511 _AIN4	=	0x0094
                           000093   512 _AIN3	=	0x0093
                           000092   513 _AIN2	=	0x0092
                           000091   514 _AIN1	=	0x0091
                           000090   515 _AIN0	=	0x0090
                           0000A7   516 _P2_7	=	0x00a7
                           0000A6   517 _P2_6	=	0x00a6
                           0000A5   518 _P2_5	=	0x00a5
                           0000A4   519 _P2_4	=	0x00a4
                           0000A3   520 _P2_3	=	0x00a3
                           0000A2   521 _P2_2	=	0x00a2
                           0000A1   522 _P2_1	=	0x00a1
                           0000A0   523 _P2_0	=	0x00a0
                           0000A7   524 _TXD1	=	0x00a7
                           0000A6   525 _RXD1	=	0x00a6
                           0000A5   526 _T2EX_	=	0x00a5
                           0000A5   527 _CAP2_	=	0x00a5
                           0000A4   528 _T2_	=	0x00a4
                           0000A4   529 _CAP1_	=	0x00a4
                           0000B7   530 _P3_7	=	0x00b7
                           0000B6   531 _P3_6	=	0x00b6
                           0000B5   532 _P3_5	=	0x00b5
                           0000B4   533 _P3_4	=	0x00b4
                           0000B3   534 _P3_3	=	0x00b3
                           0000B2   535 _P3_2	=	0x00b2
                           0000B1   536 _P3_1	=	0x00b1
                           0000B0   537 _P3_0	=	0x00b0
                           0000B7   538 _SCK1	=	0x00b7
                           0000B6   539 _MISO1	=	0x00b6
                           0000B5   540 _MOSI1	=	0x00b5
                           0000B5   541 _T1	=	0x00b5
                           0000B4   542 _T0	=	0x00b4
                           0000B3   543 _INT1	=	0x00b3
                           0000B2   544 _INT0	=	0x00b2
                           0000B1   545 _TXD	=	0x00b1
                           0000B0   546 _RXD	=	0x00b0
                           0000C6   547 _P4_6	=	0x00c6
                           0000C5   548 _P4_5	=	0x00c5
                           0000C4   549 _P4_4	=	0x00c4
                           0000C3   550 _P4_3	=	0x00c3
                           0000C2   551 _P4_2	=	0x00c2
                           0000C1   552 _P4_1	=	0x00c1
                           0000C0   553 _P4_0	=	0x00c0
                           00008F   554 _TF1	=	0x008f
                           00008E   555 _TR1	=	0x008e
                           00008D   556 _TF0	=	0x008d
                           00008C   557 _TR0	=	0x008c
                           00008B   558 _IE1	=	0x008b
                           00008A   559 _IT1	=	0x008a
                           000089   560 _IE0	=	0x0089
                           000088   561 _IT0	=	0x0088
                           00009F   562 _SM0	=	0x009f
                           00009E   563 _SM1	=	0x009e
                           00009D   564 _SM2	=	0x009d
                           00009C   565 _REN	=	0x009c
                           00009B   566 _TB8	=	0x009b
                           00009A   567 _RB8	=	0x009a
                           000099   568 _TI	=	0x0099
                           000098   569 _RI	=	0x0098
                           0000CF   570 _TF2	=	0x00cf
                           0000CF   571 _CAP1F	=	0x00cf
                           0000CE   572 _EXF2	=	0x00ce
                           0000CD   573 _RCLK	=	0x00cd
                           0000CC   574 _TCLK	=	0x00cc
                           0000CB   575 _EXEN2	=	0x00cb
                           0000CA   576 _TR2	=	0x00ca
                           0000C9   577 _C_T2	=	0x00c9
                           0000C8   578 _CP_RL2	=	0x00c8
                           0000FF   579 _S0_FST_ACT	=	0x00ff
                           0000FE   580 _S0_IF_OV	=	0x00fe
                           0000FD   581 _S0_IF_FIRST	=	0x00fd
                           0000FC   582 _S0_IF_BYTE	=	0x00fc
                           0000FB   583 _S0_FREE	=	0x00fb
                           0000FA   584 _S0_T_FIFO	=	0x00fa
                           0000F8   585 _S0_R_FIFO	=	0x00f8
                           0000F7   586 _ADC_START	=	0x00f7
                                    587 ;--------------------------------------------------------
                                    588 ; overlayable register banks
                                    589 ;--------------------------------------------------------
                                    590 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        591 	.ds 8
                                    592 ;--------------------------------------------------------
                                    593 ; internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area DSEG    (DATA)
      000027                        596 _process_action_sloc0_1_0:
      000027                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; overlayable items in internal ram
                                    600 ;--------------------------------------------------------
                                    601 ;--------------------------------------------------------
                                    602 ; indirectly addressable internal ram data
                                    603 ;--------------------------------------------------------
                                    604 	.area ISEG    (DATA)
                                    605 ;--------------------------------------------------------
                                    606 ; absolute internal ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area IABS    (ABS,DATA)
                                    609 	.area IABS    (ABS,DATA)
                                    610 ;--------------------------------------------------------
                                    611 ; bit data
                                    612 ;--------------------------------------------------------
                                    613 	.area BSEG    (BIT)
      00001E                        614 _process_action_sloc1_1_0:
      00001E                        615 	.ds 1
                                    616 ;--------------------------------------------------------
                                    617 ; paged external ram data
                                    618 ;--------------------------------------------------------
                                    619 	.area PSEG    (PAG,XDATA)
                                    620 ;--------------------------------------------------------
                                    621 ; uninitialized external ram data
                                    622 ;--------------------------------------------------------
                                    623 	.area XSEG    (XDATA)
      000836                        624 _tp_buttons::
      000836                        625 	.ds 2
      000838                        626 _action_exec_PARM_1:
      000838                        627 	.ds 6
      00083E                        628 _action_exec_record_10001_629:
      00083E                        629 	.ds 9
      000847                        630 _ak820_action_exec_event_10000_634:
      000847                        631 	.ds 2
      000849                        632 _ak820_action_exec_snapshot_10000_635:
      000849                        633 	.ds 6
      00084F                        634 _process_record_record_argument_10000_638:
      00084F                        635 	.ds 2
      000851                        636 _process_record_handler_record_argument_10000_646:
      000851                        637 	.ds 2
      000853                        638 _process_record_handler_action_10000_647:
      000853                        639 	.ds 2
      000855                        640 _register_mouse_PARM_2:
      000855                        641 	.ds 1
      000856                        642 _register_mouse_mouse_keycode_10000_655:
      000856                        643 	.ds 1
      000857                        644 _process_action_PARM_2:
      000857                        645 	.ds 2
      000859                        646 _process_action_record_argument_10000_662:
      000859                        647 	.ds 2
      00085B                        648 _process_action_on_40000_685:
      00085B                        649 	.ds 1
      00085C                        650 _register_code_code_10000_719:
      00085C                        651 	.ds 1
      00085D                        652 _unregister_code_code_10000_733:
      00085D                        653 	.ds 1
      00085E                        654 _tap_code_delay_PARM_2:
      00085E                        655 	.ds 2
      000860                        656 _tap_code_delay_code_10000_746:
      000860                        657 	.ds 1
      000861                        658 _tap_code_code_10000_753:
      000861                        659 	.ds 1
      000862                        660 _register_mods_mods_10000_755:
      000862                        661 	.ds 1
      000863                        662 _unregister_mods_mods_10000_759:
      000863                        663 	.ds 1
      000864                        664 _register_weak_mods_mods_10000_763:
      000864                        665 	.ds 1
      000865                        666 _unregister_weak_mods_mods_10000_767:
      000865                        667 	.ds 1
                                    668 ;--------------------------------------------------------
                                    669 ; absolute external ram data
                                    670 ;--------------------------------------------------------
                                    671 	.area XABS    (ABS,XDATA)
                                    672 ;--------------------------------------------------------
                                    673 ; initialized external ram data
                                    674 ;--------------------------------------------------------
                                    675 	.area XISEG   (XDATA)
      000DBF                        676 _disable_action_cache::
      000DBF                        677 	.ds 1
                                    678 	.area HOME    (CODE)
                                    679 	.area GSINIT0 (CODE)
                                    680 	.area GSINIT1 (CODE)
                                    681 	.area GSINIT2 (CODE)
                                    682 	.area GSINIT3 (CODE)
                                    683 	.area GSINIT4 (CODE)
                                    684 	.area GSINIT5 (CODE)
                                    685 	.area GSINIT  (CODE)
                                    686 	.area GSFINAL (CODE)
                                    687 	.area CSEG    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; global & static initialisations
                                    690 ;--------------------------------------------------------
                                    691 	.area HOME    (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 	.area GSFINAL (CODE)
                                    694 	.area GSINIT  (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; Home
                                    697 ;--------------------------------------------------------
                                    698 	.area HOME    (CODE)
                                    699 	.area HOME    (CODE)
                                    700 ;--------------------------------------------------------
                                    701 ; code
                                    702 ;--------------------------------------------------------
                                    703 	.area CSEG    (CODE)
                                    704 ;------------------------------------------------------------
                                    705 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    706 ;------------------------------------------------------------
                                    707 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    708 ;------------------------------------------------------------
                                    709 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    710 ;	-----------------------------------------
                           000007   711 	ar7 = 0x07
                           000006   712 	ar6 = 0x06
                           000005   713 	ar5 = 0x05
                           000004   714 	ar4 = 0x04
                           000003   715 	ar3 = 0x03
                           000002   716 	ar2 = 0x02
                           000001   717 	ar1 = 0x01
                           000000   718 	ar0 = 0x00
                                    719 ;	 function action_exec
                                    720 ;	-----------------------------------------
      00746A                        721 _action_exec:
                                    722 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      00746A 90 08 3A         [24]  723 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00746D 12 39 E7         [24]  724 	lcall	_ak820_outline_0004
      007470 12 37 FE         [24]  725 	lcall	_ak820_combo_tick
                                    726 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      007473 90 08 38         [24]  727 	mov	dptr,#_action_exec_PARM_1
      007476 12 46 6B         [24]  728 	lcall	_ak820_tapping_before
      007479 E5 82            [12]  729 	mov	a, dpl
      00747B 70 01            [24]  730 	jnz	00102$
      00747D 22               [24]  731 	ret
      00747E                        732 00102$:
                                    733 ;	quantum/action.c:110: if (!ak820_autoshift_before(&event)) return;
      00747E 90 08 38         [24]  734 	mov	dptr,#_action_exec_PARM_1
      007481 12 31 2A         [24]  735 	lcall	_ak820_autoshift_before
      007484 E5 82            [12]  736 	mov	a, dpl
      007486 70 01            [24]  737 	jnz	00104$
      007488 22               [24]  738 	ret
      007489                        739 00104$:
                                    740 ;	quantum/action.c:126: if (event.pressed) {
      007489 90 08 3D         [24]  741 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00748C E0               [24]  742 	movx	a,@dptr
      00748D 60 03            [24]  743 	jz	00106$
                                    744 ;	quantum/action.c:128: clear_weak_mods();
      00748F 12 84 F5         [24]  745 	lcall	_clear_weak_mods
      007492                        746 00106$:
                                    747 ;	quantum/action.c:140: record.event = event;
      007492 90 0D 9E         [24]  748 	mov	dptr,#___memcpy_PARM_2
      007495 74 38            [12]  749 	mov	a,#_action_exec_PARM_1
      007497 F0               [24]  750 	movx	@dptr,a
      007498 74 08            [12]  751 	mov	a,#(_action_exec_PARM_1 >> 8)
      00749A 12 7B 68         [24]  752 	lcall	_ak820_outline_0049
      00749D 12 7B 88         [24]  753 	lcall	_ak820_outline_0107
      0074A0 90 08 3E         [24]  754 	mov	dptr,#_action_exec_record_10001_629
      0074A3 F5 F0            [12]  755 	mov	b,a
      0074A5 12 BB 30         [24]  756 	lcall	___memcpy
                                    757 ;	quantum/action.c:142: record.tap.count = 0;
      0074A8 90 08 44         [24]  758 	mov	dptr,#(_action_exec_record_10001_629 + 0x0006)
      0074AB E0               [24]  759 	movx	a,@dptr
      0074AC 54 0F            [12]  760 	anl	a,#0x0f
      0074AE F0               [24]  761 	movx	@dptr,a
                                    762 ;	quantum/action.c:147: record.keycode = 0;
      0074AF 90 08 45         [24]  763 	mov	dptr,#(_action_exec_record_10001_629 + 0x0007)
      0074B2 12 51 51         [24]  764 	lcall	_ak820_outline_0165
                                    765 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0074B5 90 08 42         [24]  766 	mov	dptr,#(_action_exec_record_10001_629 + 0x0004)
      0074B8 E0               [24]  767 	movx	a,@dptr
      0074B9 60 0A            [24]  768 	jz	00111$
      0074BB 90 08 3E         [24]  769 	mov	dptr,#_action_exec_record_10001_629
      0074BE 12 A2 59         [24]  770 	lcall	_pre_process_record_quantum
      0074C1 E5 82            [12]  771 	mov	a, dpl
      0074C3 60 1C            [24]  772 	jz	00114$
      0074C5                        773 00111$:
                                    774 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      0074C5 90 08 3E         [24]  775 	mov	dptr,#_action_exec_record_10001_629
      0074C8 12 47 57         [24]  776 	lcall	_ak820_tapping_process
      0074CB E5 82            [12]  777 	mov	a, dpl
      0074CD 70 01            [24]  778 	jnz	00108$
      0074CF 22               [24]  779 	ret
      0074D0                        780 00108$:
                                    781 ;	quantum/action.c:182: if (!ak820_autoshift_process(&record)) return;
      0074D0 90 08 3E         [24]  782 	mov	dptr,#_action_exec_record_10001_629
      0074D3 12 32 30         [24]  783 	lcall	_ak820_autoshift_process
      0074D6 E5 82            [12]  784 	mov	a, dpl
      0074D8 70 01            [24]  785 	jnz	00110$
      0074DA 22               [24]  786 	ret
      0074DB                        787 00110$:
                                    788 ;	quantum/action.c:185: process_record(&record);
      0074DB 90 08 3E         [24]  789 	mov	dptr,#_action_exec_record_10001_629
                                    790 ;	quantum/action.c:200: }
      0074DE 02 75 1F         [24]  791 	ljmp	_process_record
      0074E1                        792 00114$:
      0074E1 22               [24]  793 	ret
                                    794 ;------------------------------------------------------------
                                    795 ;Allocation info for local variables in function 'ak820_action_exec'
                                    796 ;------------------------------------------------------------
                                    797 ;event         Allocated with name '_ak820_action_exec_event_10000_634'
                                    798 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_635'
                                    799 ;------------------------------------------------------------
                                    800 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    801 ;	-----------------------------------------
                                    802 ;	 function ak820_action_exec
                                    803 ;	-----------------------------------------
      0074E2                        804 _ak820_action_exec:
      0074E2 12 3A 8A         [24]  805 	lcall	_ak820_outline_0103
      0074E5 90 08 47         [24]  806 	mov	dptr,#_ak820_action_exec_event_10000_634
      0074E8 12 3A 8F         [24]  807 	lcall	_ak820_outline_0104
                                    808 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      0074EB 90 08 47         [24]  809 	mov	dptr,#_ak820_action_exec_event_10000_634
      0074EE 12 3A 5E         [24]  810 	lcall	_ak820_outline_0057
      0074F1 90 0D 9E         [24]  811 	mov	dptr,#___memcpy_PARM_2
      0074F4 ED               [12]  812 	mov	a,r5
      0074F5 12 3A 26         [24]  813 	lcall	_ak820_outline_0015
      0074F8 90 0D A1         [24]  814 	mov	dptr,#___memcpy_PARM_3
      0074FB 12 7B 88         [24]  815 	lcall	_ak820_outline_0107
      0074FE 90 08 49         [24]  816 	mov	dptr,#_ak820_action_exec_snapshot_10000_635
      007501 F5 F0            [12]  817 	mov	b,a
      007503 12 BB 30         [24]  818 	lcall	___memcpy
                                    819 ;	quantum/action.c:207: action_exec(snapshot);
      007506 90 0D 9E         [24]  820 	mov	dptr,#___memcpy_PARM_2
      007509 74 49            [12]  821 	mov	a,#_ak820_action_exec_snapshot_10000_635
      00750B F0               [24]  822 	movx	@dptr,a
      00750C 74 08            [12]  823 	mov	a,#(_ak820_action_exec_snapshot_10000_635 >> 8)
      00750E 12 7B 68         [24]  824 	lcall	_ak820_outline_0049
      007511 12 7B 88         [24]  825 	lcall	_ak820_outline_0107
      007514 90 08 38         [24]  826 	mov	dptr,#_action_exec_PARM_1
      007517 F5 F0            [12]  827 	mov	b,a
      007519 12 BB 30         [24]  828 	lcall	___memcpy
                                    829 ;	quantum/action.c:208: }
      00751C 02 74 6A         [24]  830 	ljmp	_action_exec
                                    831 ;------------------------------------------------------------
                                    832 ;Allocation info for local variables in function 'process_record_nocache'
                                    833 ;------------------------------------------------------------
                                    834 ;record        Allocated with name '_process_record_nocache_record_10000_636'
                                    835 ;------------------------------------------------------------
                                    836 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    837 ;	-----------------------------------------
                                    838 ;	 function process_record
                                    839 ;	-----------------------------------------
      00751F                        840 _process_record:
      00751F 12 3A 8A         [24]  841 	lcall	_ak820_outline_0103
      007522 90 08 4F         [24]  842 	mov	dptr,#_process_record_record_argument_10000_638
      007525 12 3A 8F         [24]  843 	lcall	_ak820_outline_0104
                                    844 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007528 90 08 4F         [24]  845 	mov	dptr,#_process_record_record_argument_10000_638
      00752B 12 3A 47         [24]  846 	lcall	_ak820_outline_0050
                                    847 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      00752E 74 04            [12]  848 	mov	a,#0x04
      007530 12 4A 2D         [24]  849 	lcall	_ak820_outline_0011
      007533 70 01            [24]  850 	jnz	00102$
                                    851 ;	quantum/action.c:354: return;
      007535 22               [24]  852 	ret
      007536                        853 00102$:
                                    854 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007536 8E 04            [24]  855 	mov	ar4,r6
      007538 8F 05            [24]  856 	mov	ar5,r7
      00753A 90 0D 9E         [24]  857 	mov	dptr,#___memcpy_PARM_2
      00753D EC               [12]  858 	mov	a,r4
      00753E F0               [24]  859 	movx	@dptr,a
      00753F ED               [12]  860 	mov	a,r5
      007540 12 7B 68         [24]  861 	lcall	_ak820_outline_0049
      007543 12 51 43         [24]  862 	lcall	_ak820_outline_0106
      007546 90 06 30         [24]  863 	mov	dptr,#_ak820_tapping_source_PARM_1
      007549 F5 F0            [12]  864 	mov	b,a
      00754B C0 07            [24]  865 	push	ar7
      00754D C0 06            [24]  866 	push	ar6
      00754F 12 BB 30         [24]  867 	lcall	___memcpy
      007552 12 45 A7         [24]  868 	lcall	_ak820_tapping_source
      007555 AD 82            [24]  869 	mov	r5, dpl
      007557 D0 06            [24]  870 	pop	ar6
      007559 D0 07            [24]  871 	pop	ar7
                                    872 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      00755B 12 45 0B         [24]  873 	lcall	_ak820_outline_0010
      00755E E0               [24]  874 	movx	a,@dptr
      00755F FC               [12]  875 	mov	r4,a
                                    876 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      007560 74 07            [12]  877 	mov	a,#0x07
      007562 2E               [12]  878 	add	a, r6
      007563 FA               [12]  879 	mov	r2,a
      007564 E4               [12]  880 	clr	a
      007565 3F               [12]  881 	addc	a, r7
      007566 FB               [12]  882 	mov	r3,a
      007567 90 0C 00         [24]  883 	mov	dptr,#_get_record_keycode_PARM_2
      00756A 12 4A 77         [24]  884 	lcall	_ak820_outline_0054
      00756D C0 07            [24]  885 	push	ar7
      00756F C0 06            [24]  886 	push	ar6
      007571 C0 05            [24]  887 	push	ar5
      007573 C0 04            [24]  888 	push	ar4
      007575 C0 03            [24]  889 	push	ar3
      007577 C0 02            [24]  890 	push	ar2
      007579 12 A2 1B         [24]  891 	lcall	_get_record_keycode
      00757C A8 82            [24]  892 	mov	r0, dpl
      00757E A9 83            [24]  893 	mov	r1, dph
      007580 D0 02            [24]  894 	pop	ar2
      007582 D0 03            [24]  895 	pop	ar3
      007584 D0 04            [24]  896 	pop	ar4
      007586 D0 05            [24]  897 	pop	ar5
      007588 D0 06            [24]  898 	pop	ar6
      00758A D0 07            [24]  899 	pop	ar7
      00758C 12 45 82         [24]  900 	lcall	_ak820_outline_0141
      00758F E8               [12]  901 	mov	a,r0
      007590 F0               [24]  902 	movx	@dptr,a
      007591 E9               [12]  903 	mov	a,r1
      007592 A3               [24]  904 	inc	dptr
      007593 F0               [24]  905 	movx	@dptr,a
                                    906 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007594 74 07            [12]  907 	mov	a,#0x07
      007596 12 3A 2E         [24]  908 	lcall	_ak820_outline_0016
      007599 FA               [12]  909 	mov	r2,a
      00759A A3               [24]  910 	inc	dptr
      00759B E0               [24]  911 	movx	a,@dptr
      00759C FB               [12]  912 	mov	r3,a
      00759D 90 06 40         [24]  913 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0075A0 ED               [12]  914 	mov	a,r5
      0075A1 F0               [24]  915 	movx	@dptr,a
      0075A2 90 06 41         [24]  916 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0075A5 EC               [12]  917 	mov	a,r4
      0075A6 F0               [24]  918 	movx	@dptr,a
      0075A7 12 45 82         [24]  919 	lcall	_ak820_outline_0141
      0075AA C0 07            [24]  920 	push	ar7
      0075AC C0 06            [24]  921 	push	ar6
      0075AE C0 05            [24]  922 	push	ar5
      0075B0 C0 04            [24]  923 	push	ar4
      0075B2 12 48 F7         [24]  924 	lcall	_ak820_oneshot_process
      0075B5 E5 82            [12]  925 	mov	a, dpl
      0075B7 D0 04            [24]  926 	pop	ar4
      0075B9 D0 05            [24]  927 	pop	ar5
      0075BB D0 06            [24]  928 	pop	ar6
      0075BD D0 07            [24]  929 	pop	ar7
      0075BF 70 01            [24]  930 	jnz	00104$
      0075C1 22               [24]  931 	ret
      0075C2                        932 00104$:
                                    933 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      0075C2 12 45 66         [24]  934 	lcall	_ak820_outline_0116
      0075C5 C0 07            [24]  935 	push	ar7
      0075C7 C0 06            [24]  936 	push	ar6
      0075C9 C0 05            [24]  937 	push	ar5
      0075CB C0 04            [24]  938 	push	ar4
      0075CD 12 A2 9B         [24]  939 	lcall	_process_record_quantum
      0075D0 E5 82            [12]  940 	mov	a, dpl
      0075D2 D0 04            [24]  941 	pop	ar4
      0075D4 D0 05            [24]  942 	pop	ar5
      0075D6 D0 06            [24]  943 	pop	ar6
      0075D8 D0 07            [24]  944 	pop	ar7
      0075DA 70 0A            [24]  945 	jnz	00106$
                                    946 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0075DC 90 05 A8         [24]  947 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0075DF EC               [12]  948 	mov	a,r4
      0075E0 F0               [24]  949 	movx	@dptr,a
      0075E1 8D 82            [24]  950 	mov	dpl, r5
                                    951 ;	quantum/action.c:376: return;
      0075E3 02 2E BB         [24]  952 	ljmp	_ak820_oneshot_post
      0075E6                        953 00106$:
                                    954 ;	quantum/action.c:382: process_record_handler(record);
      0075E6 12 45 66         [24]  955 	lcall	_ak820_outline_0116
      0075E9 C0 05            [24]  956 	push	ar5
      0075EB C0 04            [24]  957 	push	ar4
      0075ED 12 75 FE         [24]  958 	lcall	_process_record_handler
      0075F0 D0 04            [24]  959 	pop	ar4
      0075F2 D0 05            [24]  960 	pop	ar5
                                    961 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0075F4 90 05 A8         [24]  962 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0075F7 EC               [12]  963 	mov	a,r4
      0075F8 F0               [24]  964 	movx	@dptr,a
      0075F9 8D 82            [24]  965 	mov	dpl, r5
                                    966 ;	quantum/action.c:392: }
      0075FB 02 2E BB         [24]  967 	ljmp	_ak820_oneshot_post
                                    968 ;------------------------------------------------------------
                                    969 ;Allocation info for local variables in function 'process_record_handler'
                                    970 ;------------------------------------------------------------
                                    971 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_646'
                                    972 ;record        Allocated with name '_process_record_handler_record_10000_647'
                                    973 ;action        Allocated with name '_process_record_handler_action_10000_647'
                                    974 ;------------------------------------------------------------
                                    975 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    976 ;	-----------------------------------------
                                    977 ;	 function process_record_handler
                                    978 ;	-----------------------------------------
      0075FE                        979 _process_record_handler:
      0075FE 12 3A 8A         [24]  980 	lcall	_ak820_outline_0103
      007601 90 08 51         [24]  981 	mov	dptr,#_process_record_handler_record_argument_10000_646
      007604 12 3A 8F         [24]  982 	lcall	_ak820_outline_0104
                                    983 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007607 90 08 51         [24]  984 	mov	dptr,#_process_record_handler_record_argument_10000_646
      00760A 12 39 FE         [24]  985 	lcall	_ak820_outline_0008
                                    986 ;	quantum/action.c:405: if (record->keycode) {
      00760D 4C               [12]  987 	orl	a,r4
      00760E 60 19            [24]  988 	jz	00102$
                                    989 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      007610 12 3A 9B         [24]  990 	lcall	_ak820_outline_0117
      007613 C0 07            [24]  991 	push	ar7
      007615 C0 06            [24]  992 	push	ar6
      007617 12 98 EC         [24]  993 	lcall	_action_for_keycode
      00761A 12 45 87         [24]  994 	lcall	_ak820_outline_0147
      00761D D0 06            [24]  995 	pop	ar6
      00761F D0 07            [24]  996 	pop	ar7
      007621 90 08 53         [24]  997 	mov	dptr,#_process_record_handler_action_10000_647
      007624 12 3A 6C         [24]  998 	lcall	_ak820_outline_0070
      007627 80 2B            [24]  999 	sjmp	00104$
      007629                       1000 00102$:
                                   1001 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007629 12 7B 50         [24] 1002 	lcall	_ak820_outline_0019
      00762C 7A 00            [12] 1003 	mov	r2,#0x00
      00762E 12 45 7C         [24] 1004 	lcall	_ak820_outline_0140
      007631 12 45 0B         [24] 1005 	lcall	_ak820_outline_0010
      007634 E0               [24] 1006 	movx	a,@dptr
      007635 90 09 90         [24] 1007 	mov	dptr,#_ak820_resolve_key_PARM_2
      007638 F0               [24] 1008 	movx	@dptr,a
      007639 8D 82            [24] 1009 	mov	dpl, r5
      00763B 8C 83            [24] 1010 	mov	dph, r4
      00763D C0 07            [24] 1011 	push	ar7
      00763F C0 06            [24] 1012 	push	ar6
      007641 12 7E F2         [24] 1013 	lcall	_ak820_resolve_key
      007644 12 98 EC         [24] 1014 	lcall	_action_for_keycode
      007647 12 45 87         [24] 1015 	lcall	_ak820_outline_0147
      00764A D0 06            [24] 1016 	pop	ar6
      00764C D0 07            [24] 1017 	pop	ar7
      00764E 90 08 53         [24] 1018 	mov	dptr,#_process_record_handler_action_10000_647
      007651 12 3A 6C         [24] 1019 	lcall	_ak820_outline_0070
                                   1020 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      007654                       1021 00104$:
                                   1022 ;	quantum/action.c:429: process_action(record, action);
      007654 90 0D 9E         [24] 1023 	mov	dptr,#___memcpy_PARM_2
      007657 74 53            [12] 1024 	mov	a,#_process_record_handler_action_10000_647
      007659 F0               [24] 1025 	movx	@dptr,a
      00765A 74 08            [12] 1026 	mov	a,#(_process_record_handler_action_10000_647 >> 8)
      00765C 12 7B 68         [24] 1027 	lcall	_ak820_outline_0049
      00765F 12 51 43         [24] 1028 	lcall	_ak820_outline_0106
      007662 90 08 57         [24] 1029 	mov	dptr,#_process_action_PARM_2
      007665 F5 F0            [12] 1030 	mov	b,a
      007667 C0 07            [24] 1031 	push	ar7
      007669 C0 06            [24] 1032 	push	ar6
      00766B 12 BB 30         [24] 1033 	lcall	___memcpy
      00766E D0 06            [24] 1034 	pop	ar6
      007670 D0 07            [24] 1035 	pop	ar7
      007672 12 45 66         [24] 1036 	lcall	_ak820_outline_0116
                                   1037 ;	quantum/action.c:430: }
      007675 02 76 9B         [24] 1038 	ljmp	_process_action
                                   1039 ;------------------------------------------------------------
                                   1040 ;Allocation info for local variables in function 'register_mouse'
                                   1041 ;------------------------------------------------------------
                                   1042 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1043 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_655'
                                   1044 ;------------------------------------------------------------
                                   1045 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1046 ;	-----------------------------------------
                                   1047 ;	 function register_mouse
                                   1048 ;	-----------------------------------------
      007678                       1049 _register_mouse:
      007678 E5 82            [12] 1050 	mov	a,dpl
      00767A 90 08 56         [24] 1051 	mov	dptr,#_register_mouse_mouse_keycode_10000_655
      00767D F0               [24] 1052 	movx	@dptr,a
                                   1053 ;	quantum/action.c:445: if (pressed) {
      00767E 90 08 55         [24] 1054 	mov	dptr,#_register_mouse_PARM_2
      007681 E0               [24] 1055 	movx	a,@dptr
      007682 60 0B            [24] 1056 	jz	00102$
                                   1057 ;	quantum/action.c:446: mousekey_on(mouse_keycode);
      007684 90 08 56         [24] 1058 	mov	dptr,#_register_mouse_mouse_keycode_10000_655
      007687 E0               [24] 1059 	movx	a,@dptr
      007688 F5 82            [12] 1060 	mov	dpl,a
      00768A 12 51 A1         [24] 1061 	lcall	_mousekey_on
      00768D 80 09            [24] 1062 	sjmp	00103$
      00768F                       1063 00102$:
                                   1064 ;	quantum/action.c:448: mousekey_off(mouse_keycode);
      00768F 90 08 56         [24] 1065 	mov	dptr,#_register_mouse_mouse_keycode_10000_655
      007692 E0               [24] 1066 	movx	a,@dptr
      007693 F5 82            [12] 1067 	mov	dpl,a
      007695 12 52 15         [24] 1068 	lcall	_mousekey_off
      007698                       1069 00103$:
                                   1070 ;	quantum/action.c:469: mousekey_send();
                                   1071 ;	quantum/action.c:471: }
                                   1072 ;	quantum/action.c:487: }
      007698 02 52 74         [24] 1073 	ljmp	_mousekey_send
                                   1074 ;------------------------------------------------------------
                                   1075 ;Allocation info for local variables in function 'process_action'
                                   1076 ;------------------------------------------------------------
                                   1077 ;sloc0         Allocated with name '_process_action_sloc0_1_0'
                                   1078 ;action        Allocated with name '_process_action_PARM_2'
                                   1079 ;record_argument Allocated with name '_process_action_record_argument_10000_662'
                                   1080 ;record        Allocated with name '_process_action_record_10000_663'
                                   1081 ;pressed       Allocated with name '_process_action_pressed_10000_663'
                                   1082 ;mods          Allocated with name '_process_action_mods_10000_663'
                                   1083 ;on            Allocated with name '_process_action_on_40000_685'
                                   1084 ;shift         Allocated with name '_process_action_shift_60000_687'
                                   1085 ;bits          Allocated with name '_process_action_bits_60000_687'
                                   1086 ;mask          Allocated with name '_process_action_mask_60000_687'
                                   1087 ;i             Allocated with name '_process_action_i_110000_711'
                                   1088 ;i             Allocated with name '_process_action_i_110000_715'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	quantum/action.c:493: void process_action(keyrecord_t AK820_RECORD_MEM *record_argument, action_t action) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function process_action
                                   1093 ;	-----------------------------------------
      00769B                       1094 _process_action:
      00769B 12 3A 8A         [24] 1095 	lcall	_ak820_outline_0103
      00769E 90 08 59         [24] 1096 	mov	dptr,#_process_action_record_argument_10000_662
      0076A1 12 3A 8F         [24] 1097 	lcall	_ak820_outline_0104
                                   1098 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0076A4 90 08 59         [24] 1099 	mov	dptr,#_process_action_record_argument_10000_662
      0076A7 12 39 E7         [24] 1100 	lcall	_ak820_outline_0004
                                   1101 ;	quantum/action.c:501: pressed = record->event.pressed;
      0076AA A3               [24] 1102 	inc	dptr
      0076AB A3               [24] 1103 	inc	dptr
      0076AC A3               [24] 1104 	inc	dptr
      0076AD A3               [24] 1105 	inc	dptr
      0076AE A3               [24] 1106 	inc	dptr
      0076AF E0               [24] 1107 	movx	a,@dptr
      0076B0 F5 27            [12] 1108 	mov	_process_action_sloc0_1_0,a
                                   1109 ;	quantum/action.c:525: switch (action.kind.id) {
      0076B2 90 08 58         [24] 1110 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076B5 E0               [24] 1111 	movx	a,@dptr
      0076B6 C4               [12] 1112 	swap	a
      0076B7 54 0F            [12] 1113 	anl	a,#0x0f
      0076B9 FD               [12] 1114 	mov  r5,a
      0076BA 24 F4            [12] 1115 	add	a,#0xff - 0x0b
      0076BC 50 03            [24] 1116 	jnc	00434$
      0076BE 02 79 4E         [24] 1117 	ljmp	00181$
      0076C1                       1118 00434$:
                                   1119 ;	free result
      0076C1 ED               [12] 1120 	mov	a,r5
      0076C2 24 0A            [12] 1121 	add	a,#(00435$-3-.)
      0076C4 83               [24] 1122 	movc	a,@a+pc
      0076C5 F5 82            [12] 1123 	mov	dpl,a
      0076C7 ED               [12] 1124 	mov	a,r5
      0076C8 24 10            [12] 1125 	add	a,#(00436$-3-.)
      0076CA 83               [24] 1126 	movc	a,@a+pc
      0076CB F5 83            [12] 1127 	mov	dph,a
      0076CD E4               [12] 1128 	clr	a
      0076CE 73               [24] 1129 	jmp	@a+dptr
      0076CF                       1130 00435$:
      0076CF E7                    1131 	.db	00102$
      0076D0 E7                    1132 	.db	00102$
      0076D1 4E                    1133 	.db	00181$
      0076D2 4E                    1134 	.db	00181$
      0076D3 71                    1135 	.db	00123$
      0076D4 D1                    1136 	.db	00130$
      0076D5 4E                    1137 	.db	00181$
      0076D6 4E                    1138 	.db	00181$
      0076D7 E3                    1139 	.db	00131$
      0076D8 B5                    1140 	.db	00147$
      0076D9 DB                    1141 	.db	00152$
      0076DA DB                    1142 	.db	00152$
      0076DB                       1143 00436$:
      0076DB 76                    1144 	.db	00102$>>8
      0076DC 76                    1145 	.db	00102$>>8
      0076DD 79                    1146 	.db	00181$>>8
      0076DE 79                    1147 	.db	00181$>>8
      0076DF 77                    1148 	.db	00123$>>8
      0076E0 77                    1149 	.db	00130$>>8
      0076E1 79                    1150 	.db	00181$>>8
      0076E2 79                    1151 	.db	00181$>>8
      0076E3 77                    1152 	.db	00131$>>8
      0076E4 78                    1153 	.db	00147$>>8
      0076E5 78                    1154 	.db	00152$>>8
      0076E6 78                    1155 	.db	00152$>>8
                                   1156 ;	quantum/action.c:528: case ACT_RMODS: {
      0076E7                       1157 00102$:
                                   1158 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0076E7 90 08 58         [24] 1159 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076EA E0               [24] 1160 	movx	a,@dptr
      0076EB 54 F0            [12] 1161 	anl	a,#0xf0
      0076ED 70 06            [24] 1162 	jnz	00194$
      0076EF 12 7B 8F         [24] 1163 	lcall	_ak820_outline_0109
      0076F2 FD               [12] 1164 	mov	r5,a
      0076F3 80 07            [24] 1165 	sjmp	00195$
      0076F5                       1166 00194$:
      0076F5 12 7B 8F         [24] 1167 	lcall	_ak820_outline_0109
      0076F8 C4               [12] 1168 	swap	a
      0076F9 54 F0            [12] 1169 	anl	a,#0xf0
      0076FB FD               [12] 1170 	mov	r5,a
      0076FC                       1171 00195$:
                                   1172 ;	quantum/action.c:531: if (pressed) {
      0076FC E5 27            [12] 1173 	mov	a,_process_action_sloc0_1_0
      0076FE 60 35            [24] 1174 	jz	00119$
                                   1175 ;	quantum/action.c:532: if (mods) {
      007700 ED               [12] 1176 	mov	a,r5
      007701 60 29            [24] 1177 	jz	00110$
                                   1178 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007703 12 7B AD         [24] 1179 	lcall	_ak820_outline_0146
      007706 FC               [12] 1180 	mov	r4,a
      007707 BC E0 00         [24] 1181 	cjne	r4,#0xe0,00440$
      00770A                       1182 00440$:
      00770A 40 07            [24] 1183 	jc	00108$
      00770C 12 7B AD         [24] 1184 	lcall	_ak820_outline_0146
      00770F 24 18            [12] 1185 	add	a,#0xff - 0xe7
      007711 50 0A            [24] 1186 	jnc	00104$
                                   1187 ;	free result
      007713                       1188 00108$:
      007713 7B 57            [12] 1189 	mov	r3,#_process_action_PARM_2
      007715 7C 08            [12] 1190 	mov	r4,#(_process_action_PARM_2 >> 8)
      007717 12 36 42         [24] 1191 	lcall	_ak820_outline_0121
      00771A E0               [24] 1192 	movx	a,@dptr
      00771B 70 07            [24] 1193 	jnz	00105$
      00771D                       1194 00104$:
                                   1195 ;	quantum/action.c:537: add_owned_mods(mods);
      00771D 8D 82            [24] 1196 	mov	dpl, r5
      00771F 12 81 0C         [24] 1197 	lcall	_add_owned_mods
      007722 80 05            [24] 1198 	sjmp	00106$
      007724                       1199 00105$:
                                   1200 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      007724 8D 82            [24] 1201 	mov	dpl, r5
      007726 12 81 2A         [24] 1202 	lcall	_add_owned_weak_mods
      007729                       1203 00106$:
                                   1204 ;	quantum/action.c:541: send_keyboard_report();
      007729 12 84 45         [24] 1205 	lcall	_send_keyboard_report
      00772C                       1206 00110$:
                                   1207 ;	quantum/action.c:543: register_code(action.key.code);
      00772C 12 7B 78         [24] 1208 	lcall	_ak820_outline_0075
      00772F 12 79 65         [24] 1209 	lcall	_register_code
      007732 02 79 4E         [24] 1210 	ljmp	00181$
      007735                       1211 00119$:
                                   1212 ;	quantum/action.c:545: unregister_code(action.key.code);
      007735 12 7B 78         [24] 1213 	lcall	_ak820_outline_0075
      007738 C0 05            [24] 1214 	push	ar5
      00773A 12 79 EA         [24] 1215 	lcall	_unregister_code
      00773D D0 05            [24] 1216 	pop	ar5
                                   1217 ;	quantum/action.c:546: if (mods) {
      00773F ED               [12] 1218 	mov	a,r5
      007740 70 03            [24] 1219 	jnz	00444$
      007742 02 79 4E         [24] 1220 	ljmp	00181$
      007745                       1221 00444$:
                                   1222 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007745 12 7B AD         [24] 1223 	lcall	_ak820_outline_0146
      007748 FC               [12] 1224 	mov	r4,a
      007749 BC E0 00         [24] 1225 	cjne	r4,#0xe0,00445$
      00774C                       1226 00445$:
      00774C 40 07            [24] 1227 	jc	00115$
      00774E 12 7B AD         [24] 1228 	lcall	_ak820_outline_0146
      007751 24 18            [12] 1229 	add	a,#0xff - 0xe7
      007753 50 0A            [24] 1230 	jnc	00111$
                                   1231 ;	free result
      007755                       1232 00115$:
      007755 7B 57            [12] 1233 	mov	r3,#_process_action_PARM_2
      007757 7C 08            [12] 1234 	mov	r4,#(_process_action_PARM_2 >> 8)
      007759 12 36 42         [24] 1235 	lcall	_ak820_outline_0121
      00775C E0               [24] 1236 	movx	a,@dptr
      00775D 70 07            [24] 1237 	jnz	00112$
      00775F                       1238 00111$:
                                   1239 ;	quantum/action.c:548: del_owned_mods(mods);
      00775F 8D 82            [24] 1240 	mov	dpl, r5
      007761 12 81 1C         [24] 1241 	lcall	_del_owned_mods
      007764 80 05            [24] 1242 	sjmp	00113$
      007766                       1243 00112$:
                                   1244 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      007766 8D 82            [24] 1245 	mov	dpl, r5
      007768 12 81 3A         [24] 1246 	lcall	_del_owned_weak_mods
      00776B                       1247 00113$:
                                   1248 ;	quantum/action.c:552: send_keyboard_report();
      00776B 12 84 45         [24] 1249 	lcall	_send_keyboard_report
                                   1250 ;	quantum/action.c:555: } break;
      00776E 02 79 4E         [24] 1251 	ljmp	00181$
                                   1252 ;	quantum/action.c:632: case ACT_USAGE:
      007771                       1253 00123$:
                                   1254 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007771 74 07            [12] 1255 	mov	a,#0x07
      007773 12 3A 37         [24] 1256 	lcall	_ak820_outline_0030
      007776 12 3A 12         [24] 1257 	lcall	_ak820_outline_0009
      007779 C3               [12] 1258 	clr	c
      00777A EC               [12] 1259 	mov	a,r4
      00777B 94 A5            [12] 1260 	subb	a,#0xa5
      00777D ED               [12] 1261 	mov	a,r5
      00777E 94 00            [12] 1262 	subb	a,#0x00
      007780 40 15            [24] 1263 	jc	00125$
      007782 74 C2            [12] 1264 	mov	a,#0xc2
      007784 9C               [12] 1265 	subb	a,r4
      007785 E4               [12] 1266 	clr	a
      007786 9D               [12] 1267 	subb	a,r5
      007787 40 0E            [24] 1268 	jc	00125$
                                   1269 ;	free result
                                   1270 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      007789 90 0A B7         [24] 1271 	mov	dptr,#_owned_usage_key_PARM_2
      00778C E5 27            [12] 1272 	mov	a,_process_action_sloc0_1_0
      00778E F0               [24] 1273 	movx	@dptr,a
      00778F 8E 82            [24] 1274 	mov	dpl, r6
      007791 12 82 F0         [24] 1275 	lcall	_owned_usage_key
                                   1276 ;	quantum/action.c:640: break;
      007794 02 79 4E         [24] 1277 	ljmp	00181$
      007797                       1278 00125$:
                                   1279 ;	quantum/action.c:643: switch (action.usage.page) {
      007797 12 7B 7F         [24] 1280 	lcall	_ak820_outline_0085
      00779A FF               [12] 1281 	mov	r7,a
      00779B 60 08            [24] 1282 	jz	00127$
      00779D BF 01 02         [24] 1283 	cjne	r7,#0x01,00452$
      0077A0 80 19            [24] 1284 	sjmp	00128$
      0077A2                       1285 00452$:
      0077A2 02 79 4E         [24] 1286 	ljmp	00181$
                                   1287 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0077A5                       1288 00127$:
                                   1289 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0077A5 E5 27            [12] 1290 	mov	a,_process_action_sloc0_1_0
      0077A7 60 05            [24] 1291 	jz	00196$
      0077A9 12 7B 96         [24] 1292 	lcall	_ak820_outline_0128
      0077AC 80 04            [24] 1293 	sjmp	00197$
      0077AE                       1294 00196$:
      0077AE 7E 00            [12] 1295 	mov	r6,#0x00
      0077B0 7F 00            [12] 1296 	mov	r7,#0x00
      0077B2                       1297 00197$:
      0077B2 12 45 66         [24] 1298 	lcall	_ak820_outline_0116
      0077B5 12 71 63         [24] 1299 	lcall	_host_system_send
                                   1300 ;	quantum/action.c:646: break;
      0077B8 02 79 4E         [24] 1301 	ljmp	00181$
                                   1302 ;	quantum/action.c:647: case PAGE_CONSUMER:
      0077BB                       1303 00128$:
                                   1304 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      0077BB E5 27            [12] 1305 	mov	a,_process_action_sloc0_1_0
      0077BD 60 05            [24] 1306 	jz	00198$
      0077BF 12 7B 96         [24] 1307 	lcall	_ak820_outline_0128
      0077C2 80 04            [24] 1308 	sjmp	00199$
      0077C4                       1309 00198$:
      0077C4 7E 00            [12] 1310 	mov	r6,#0x00
      0077C6 7F 00            [12] 1311 	mov	r7,#0x00
      0077C8                       1312 00199$:
      0077C8 12 45 66         [24] 1313 	lcall	_ak820_outline_0116
      0077CB 12 71 93         [24] 1314 	lcall	_host_consumer_send
                                   1315 ;	quantum/action.c:651: break;
      0077CE 02 79 4E         [24] 1316 	ljmp	00181$
                                   1317 ;	quantum/action.c:654: case ACT_MOUSEKEY:
      0077D1                       1318 00130$:
                                   1319 ;	quantum/action.c:655: register_mouse(action.key.code, pressed);
      0077D1 12 7B AD         [24] 1320 	lcall	_ak820_outline_0146
      0077D4 FF               [12] 1321 	mov	r7,a
      0077D5 90 08 55         [24] 1322 	mov	dptr,#_register_mouse_PARM_2
      0077D8 E5 27            [12] 1323 	mov	a,_process_action_sloc0_1_0
      0077DA F0               [24] 1324 	movx	@dptr,a
      0077DB 8F 82            [24] 1325 	mov	dpl, r7
      0077DD 12 76 78         [24] 1326 	lcall	_register_mouse
                                   1327 ;	quantum/action.c:656: break;
      0077E0 02 79 4E         [24] 1328 	ljmp	00181$
                                   1329 ;	quantum/action.c:658: case ACT_LAYER: {
      0077E3                       1330 00131$:
                                   1331 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      0077E3 90 08 58         [24] 1332 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0077E6 E0               [24] 1333 	movx	a,@dptr
      0077E7 54 03            [12] 1334 	anl	a,#0x03
      0077E9 90 08 5B         [24] 1335 	mov	dptr,#_process_action_on_40000_685
      0077EC F0               [24] 1336 	movx	@dptr,a
                                   1337 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0077ED E0               [24] 1338 	movx	a,@dptr
      0077EE FF               [12] 1339 	mov	r7,a
      0077EF 60 11            [24] 1340 	jz	00200$
      0077F1 E5 27            [12] 1341 	mov	a,_process_action_sloc0_1_0
      0077F3 60 07            [24] 1342 	jz	00202$
      0077F5 8F 06            [24] 1343 	mov	ar6,r7
      0077F7 53 06 01         [24] 1344 	anl	ar6,#0x01
      0077FA 80 10            [24] 1345 	sjmp	00201$
      0077FC                       1346 00202$:
      0077FC 74 02            [12] 1347 	mov	a,#0x02
      0077FE 5F               [12] 1348 	anl	a,r7
      0077FF FE               [12] 1349 	mov	r6,a
      007800 80 0A            [24] 1350 	sjmp	00201$
      007802                       1351 00200$:
      007802 E5 27            [12] 1352 	mov	a,_process_action_sloc0_1_0
      007804 B4 01 00         [24] 1353 	cjne	a,#0x01,00457$
      007807                       1354 00457$:
      007807 92 1E            [24] 1355 	mov  _process_action_sloc1_1_0,c
      007809 E4               [12] 1356 	clr	a
      00780A 33               [12] 1357 	rlc	a
      00780B FE               [12] 1358 	mov	r6,a
      00780C                       1359 00201$:
      00780C EE               [12] 1360 	mov	a,r6
      00780D 70 03            [24] 1361 	jnz	00458$
      00780F 02 79 4E         [24] 1362 	ljmp	00181$
      007812                       1363 00458$:
                                   1364 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007812 12 7B AD         [24] 1365 	lcall	_ak820_outline_0146
      007815 C4               [12] 1366 	swap	a
      007816 03               [12] 1367 	rr	a
      007817 54 07            [12] 1368 	anl	a,#0x07
      007819 25 E0            [12] 1369 	add	a,acc
      00781B 25 E0            [12] 1370 	add	a,acc
      00781D FF               [12] 1371 	mov	r7,a
                                   1372 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00781E 12 7B AD         [24] 1373 	lcall	_ak820_outline_0146
      007821 54 0F            [12] 1374 	anl	a,#0x0f
      007823 FE               [12] 1375 	mov	r6,a
      007824 8F F0            [24] 1376 	mov	b,r7
      007826 05 F0            [12] 1377 	inc	b
      007828 EE               [12] 1378 	mov	a,r6
      007829 80 02            [24] 1379 	sjmp	00460$
      00782B                       1380 00459$:
      00782B 25 E0            [12] 1381 	add	a,acc
      00782D                       1382 00460$:
      00782D D5 F0 FB         [24] 1383 	djnz	b,00459$
      007830 FE               [12] 1384 	mov	r6,a
                                   1385 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007831 12 7B AD         [24] 1386 	lcall	_ak820_outline_0146
      007834 30 E4 11         [24] 1387 	jnb	acc.4,00204$
      007837 8F F0            [24] 1388 	mov	b,r7
      007839 05 F0            [12] 1389 	inc	b
      00783B 74 0F            [12] 1390 	mov	a,#0x0f
      00783D 80 02            [24] 1391 	sjmp	00463$
      00783F                       1392 00462$:
      00783F 25 E0            [12] 1393 	add	a,acc
      007841                       1394 00463$:
      007841 D5 F0 FB         [24] 1395 	djnz	b,00462$
      007844 F4               [12] 1396 	cpl	a
      007845 FF               [12] 1397 	mov	r7,a
      007846 80 02            [24] 1398 	sjmp	00205$
      007848                       1399 00204$:
      007848 7F 00            [12] 1400 	mov	r7,#0x00
      00784A                       1401 00205$:
                                   1402 ;	quantum/action.c:666: bits |= mask;
      00784A EE               [12] 1403 	mov	a,r6
      00784B 42 07            [12] 1404 	orl	ar7,a
                                   1405 ;	quantum/action.c:667: if (!on) {
      00784D 90 08 5B         [24] 1406 	mov	dptr,#_process_action_on_40000_685
      007850 E0               [24] 1407 	movx	a,@dptr
      007851 70 31            [24] 1408 	jnz	00143$
                                   1409 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      007853 12 7B 7F         [24] 1410 	lcall	_ak820_outline_0085
      007856 FE               [12] 1411 	mov	r6,a
      007857 2E               [12] 1412 	add	a,r6
                                   1413 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      007858 90 78 5C         [24] 1414 	mov	dptr,#00465$
      00785B 73               [24] 1415 	jmp	@a+dptr
      00785C                       1416 00465$:
      00785C 80 06            [24] 1417 	sjmp	00132$
      00785E 80 0C            [24] 1418 	sjmp	00133$
      007860 80 12            [24] 1419 	sjmp	00134$
      007862 80 18            [24] 1420 	sjmp	00135$
      007864                       1421 00132$:
      007864 8F 82            [24] 1422 	mov	dpl, r7
      007866 12 7C 01         [24] 1423 	lcall	_default_layer_and
      007869 02 79 4E         [24] 1424 	ljmp	00181$
                                   1425 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      00786C                       1426 00133$:
      00786C 8F 82            [24] 1427 	mov	dpl, r7
      00786E 12 7B F0         [24] 1428 	lcall	_default_layer_or
      007871 02 79 4E         [24] 1429 	ljmp	00181$
                                   1430 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      007874                       1431 00134$:
      007874 8F 82            [24] 1432 	mov	dpl, r7
      007876 12 7C 17         [24] 1433 	lcall	_default_layer_xor
      007879 02 79 4E         [24] 1434 	ljmp	00181$
                                   1435 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      00787C                       1436 00135$:
      00787C 8F 82            [24] 1437 	mov	dpl, r7
      00787E 12 7B E5         [24] 1438 	lcall	_default_layer_set
                                   1439 ;	quantum/action.c:673: }
      007881 02 79 4E         [24] 1440 	ljmp	00181$
      007884                       1441 00143$:
                                   1442 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      007884 12 7B 7F         [24] 1443 	lcall	_ak820_outline_0085
      007887 FE               [12] 1444 	mov	r6,a
      007888 2E               [12] 1445 	add	a,r6
                                   1446 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      007889 90 78 8D         [24] 1447 	mov	dptr,#00466$
      00788C 73               [24] 1448 	jmp	@a+dptr
      00788D                       1449 00466$:
      00788D 80 06            [24] 1450 	sjmp	00137$
      00788F 80 0C            [24] 1451 	sjmp	00138$
      007891 80 12            [24] 1452 	sjmp	00139$
      007893 80 18            [24] 1453 	sjmp	00140$
      007895                       1454 00137$:
      007895 8F 82            [24] 1455 	mov	dpl, r7
      007897 12 7D 9A         [24] 1456 	lcall	_layer_and
      00789A 02 79 4E         [24] 1457 	ljmp	00181$
                                   1458 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      00789D                       1459 00138$:
      00789D 8F 82            [24] 1460 	mov	dpl, r7
      00789F 12 7D 89         [24] 1461 	lcall	_layer_or
      0078A2 02 79 4E         [24] 1462 	ljmp	00181$
                                   1463 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      0078A5                       1464 00139$:
      0078A5 8F 82            [24] 1465 	mov	dpl, r7
      0078A7 12 7D B0         [24] 1466 	lcall	_layer_xor
      0078AA 02 79 4E         [24] 1467 	ljmp	00181$
                                   1468 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      0078AD                       1469 00140$:
      0078AD 8F 82            [24] 1470 	mov	dpl, r7
      0078AF 12 7D 26         [24] 1471 	lcall	_layer_state_set
                                   1472 ;	quantum/action.c:683: break;
      0078B2 02 79 4E         [24] 1473 	ljmp	00181$
                                   1474 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      0078B5                       1475 00147$:
                                   1476 ;	quantum/action.c:686: if (pressed) {
      0078B5 E5 27            [12] 1477 	mov	a,_process_action_sloc0_1_0
      0078B7 60 11            [24] 1478 	jz	00149$
                                   1479 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      0078B9 12 7B 8F         [24] 1480 	lcall	_ak820_outline_0109
      0078BC F5 82            [12] 1481 	mov	dpl,a
      0078BE 12 7C 87         [24] 1482 	lcall	_layer_hold_on
                                   1483 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      0078C1 12 7B 78         [24] 1484 	lcall	_ak820_outline_0075
      0078C4 12 7A B5         [24] 1485 	lcall	_register_mods
      0078C7 02 79 4E         [24] 1486 	ljmp	00181$
      0078CA                       1487 00149$:
                                   1488 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      0078CA 12 7B 78         [24] 1489 	lcall	_ak820_outline_0075
      0078CD 12 7A C9         [24] 1490 	lcall	_unregister_mods
                                   1491 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      0078D0 12 7B 8F         [24] 1492 	lcall	_ak820_outline_0109
      0078D3 F5 82            [12] 1493 	mov	dpl,a
      0078D5 12 7C BF         [24] 1494 	lcall	_layer_hold_off
                                   1495 ;	quantum/action.c:693: break;
      0078D8 02 79 4E         [24] 1496 	ljmp	00181$
                                   1497 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      0078DB                       1498 00152$:
                                   1499 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      0078DB 12 7B AD         [24] 1500 	lcall	_ak820_outline_0146
      0078DE FF               [12] 1501 	mov	r7,a
      0078DF BF F1 02         [24] 1502 	cjne	r7,#0xf1,00468$
      0078E2 80 0A            [24] 1503 	sjmp	00154$
      0078E4                       1504 00468$:
      0078E4 BF F2 02         [24] 1505 	cjne	r7,#0xf2,00469$
      0078E7 80 19            [24] 1506 	sjmp	00155$
      0078E9                       1507 00469$:
                                   1508 ;	quantum/action.c:712: momentary_layer_action:
      0078E9 BF F3 3B         [24] 1509 	cjne	r7,#0xf3,00160$
      0078EC 80 28            [24] 1510 	sjmp	00156$
      0078EE                       1511 00154$:
                                   1512 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0078EE E5 27            [12] 1513 	mov	a,_process_action_sloc0_1_0
      0078F0 60 08            [24] 1514 	jz	00206$
      0078F2 12 7B 5F         [24] 1515 	lcall	_ak820_outline_0038
      0078F5 12 7C 87         [24] 1516 	lcall	_layer_hold_on
      0078F8 80 54            [24] 1517 	sjmp	00181$
      0078FA                       1518 00206$:
      0078FA 12 7B 5F         [24] 1519 	lcall	_ak820_outline_0038
      0078FD 12 7C BF         [24] 1520 	lcall	_layer_hold_off
                                   1521 ;	quantum/action.c:714: break;
                                   1522 ;	quantum/action.c:715: case OP_OFF_ON:
      007900 80 4C            [24] 1523 	sjmp	00181$
      007902                       1524 00155$:
                                   1525 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007902 E5 27            [12] 1526 	mov	a,_process_action_sloc0_1_0
      007904 60 08            [24] 1527 	jz	00208$
      007906 12 7B 5F         [24] 1528 	lcall	_ak820_outline_0038
      007909 12 7D 6B         [24] 1529 	lcall	_layer_off
      00790C 80 40            [24] 1530 	sjmp	00181$
      00790E                       1531 00208$:
      00790E 12 7B 5F         [24] 1532 	lcall	_ak820_outline_0038
      007911 12 7D 50         [24] 1533 	lcall	_layer_on
                                   1534 ;	quantum/action.c:717: break;
                                   1535 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007914 80 38            [24] 1536 	sjmp	00181$
      007916                       1537 00156$:
                                   1538 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007916 E5 27            [12] 1539 	mov	a,_process_action_sloc0_1_0
      007918 60 08            [24] 1540 	jz	00210$
      00791A 12 7B 5F         [24] 1541 	lcall	_ak820_outline_0038
      00791D 12 7D 3A         [24] 1542 	lcall	_layer_move
      007920 80 2C            [24] 1543 	sjmp	00181$
      007922                       1544 00210$:
      007922 12 7D 34         [24] 1545 	lcall	_layer_clear
                                   1546 ;	quantum/action.c:720: break;
                                   1547 ;	quantum/action.c:766: default:
      007925 80 27            [24] 1548 	sjmp	00181$
      007927                       1549 00160$:
                                   1550 ;	quantum/action.c:773: if (pressed) {
      007927 E5 27            [12] 1551 	mov	a,_process_action_sloc0_1_0
      007929 60 08            [24] 1552 	jz	00163$
                                   1553 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      00792B 12 7B 78         [24] 1554 	lcall	_ak820_outline_0075
      00792E 12 79 65         [24] 1555 	lcall	_register_code
                                   1556 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007931 80 1B            [24] 1557 	sjmp	00181$
      007933                       1558 00163$:
                                   1559 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007933 12 7B AD         [24] 1560 	lcall	_ak820_outline_0146
      007936 FF               [12] 1561 	mov	r7,a
      007937 BF 39 0E         [24] 1562 	cjne	r7,#0x39,00175$
                                   1563 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      00793A 7F 50            [12] 1564 	mov	r7,#0x50
      00793C                       1565 00187$:
      00793C EF               [12] 1566 	mov	a,r7
      00793D 60 09            [24] 1567 	jz	00175$
      00793F 90 00 01         [24] 1568 	mov	dptr,#0x0001
      007942 12 5D 37         [24] 1569 	lcall	_mDelaymS
      007945 1F               [12] 1570 	dec	r7
                                   1571 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      007946 80 F4            [24] 1572 	sjmp	00187$
      007948                       1573 00175$:
                                   1574 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      007948 12 7B 78         [24] 1575 	lcall	_ak820_outline_0075
      00794B 12 79 EA         [24] 1576 	lcall	_unregister_code
                                   1577 ;	quantum/action.c:866: }
      00794E                       1578 00181$:
                                   1579 ;	quantum/action.c:887: switch (action.kind.id) {
      00794E 90 08 58         [24] 1580 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007951 E0               [24] 1581 	movx	a,@dptr
      007952 C4               [12] 1582 	swap	a
      007953 54 0F            [12] 1583 	anl	a,#0x0f
      007955 FF               [12] 1584 	mov	r7,a
      007956 BF 08 02         [24] 1585 	cjne	r7,#0x08,00478$
      007959 80 03            [24] 1586 	sjmp	00183$
      00795B                       1587 00478$:
      00795B BF 09 06         [24] 1588 	cjne	r7,#0x09,00192$
                                   1589 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      00795E                       1590 00183$:
                                   1591 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      00795E 12 70 C8         [24] 1592 	lcall	_host_keyboard_leds
                                   1593 ;	quantum/action.c:898: }
                                   1594 ;	quantum/action.c:951: }
      007961 02 9B A1         [24] 1595 	ljmp	_led_set
      007964                       1596 00192$:
      007964 22               [24] 1597 	ret
                                   1598 ;------------------------------------------------------------
                                   1599 ;Allocation info for local variables in function 'register_code'
                                   1600 ;------------------------------------------------------------
                                   1601 ;code          Allocated with name '_register_code_code_10000_719'
                                   1602 ;------------------------------------------------------------
                                   1603 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1604 ;	-----------------------------------------
                                   1605 ;	 function register_code
                                   1606 ;	-----------------------------------------
      007965                       1607 _register_code:
      007965 E5 82            [12] 1608 	mov	a,dpl
      007967 90 08 5C         [24] 1609 	mov	dptr,#_register_code_code_10000_719
      00796A F0               [24] 1610 	movx	@dptr,a
                                   1611 ;	quantum/action.c:958: if (code == KC_NO) {
      00796B E0               [24] 1612 	movx	a,@dptr
      00796C FF               [12] 1613 	mov	r7,a
      00796D 70 01            [24] 1614 	jnz	00123$
                                   1615 ;	quantum/action.c:959: return;
      00796F 22               [24] 1616 	ret
      007970                       1617 00123$:
                                   1618 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007970 BF 04 00         [24] 1619 	cjne	r7,#0x04,00198$
      007973                       1620 00198$:
      007973 40 12            [24] 1621 	jc	00119$
      007975 EF               [12] 1622 	mov	a,r7
      007976 24 5B            [12] 1623 	add	a,#0xff - 0xa4
      007978 40 0D            [24] 1624 	jc	00119$
                                   1625 ;	free result
                                   1626 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      00797A 8F 82            [24] 1627 	mov	dpl, r7
      00797C 12 81 AF         [24] 1628 	lcall	_add_owned_key
      00797F E5 82            [12] 1629 	mov	a, dpl
      007981 70 01            [24] 1630 	jnz	00104$
      007983 22               [24] 1631 	ret
      007984                       1632 00104$:
                                   1633 ;	quantum/action.c:1013: send_keyboard_report();
      007984 02 84 45         [24] 1634 	ljmp	_send_keyboard_report
      007987                       1635 00119$:
                                   1636 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      007987 12 7B A1         [24] 1637 	lcall	_ak820_outline_0137
      00798A BF E0 00         [24] 1638 	cjne	r7,#0xe0,00202$
      00798D                       1639 00202$:
      00798D 40 1A            [24] 1640 	jc	00115$
      00798F EF               [12] 1641 	mov	a,r7
      007990 24 18            [12] 1642 	add	a,#0xff - 0xe7
      007992 40 15            [24] 1643 	jc	00115$
                                   1644 ;	free result
                                   1645 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      007994 74 07            [12] 1646 	mov	a,#0x07
      007996 5F               [12] 1647 	anl	a,r7
      007997 12 7B 71         [24] 1648 	lcall	_ak820_outline_0062
      00799A 80 02            [24] 1649 	sjmp	00206$
      00799C                       1650 00205$:
      00799C 25 E0            [12] 1651 	add	a,acc
      00799E                       1652 00206$:
      00799E D5 F0 FB         [24] 1653 	djnz	b,00205$
      0079A1 F5 82            [12] 1654 	mov	dpl,a
      0079A3 12 81 0C         [24] 1655 	lcall	_add_owned_mods
                                   1656 ;	quantum/action.c:1016: send_keyboard_report();
      0079A6 02 84 45         [24] 1657 	ljmp	_send_keyboard_report
      0079A9                       1658 00115$:
                                   1659 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0079A9 12 7B A1         [24] 1660 	lcall	_ak820_outline_0137
      0079AC BF A5 00         [24] 1661 	cjne	r7,#0xa5,00207$
      0079AF                       1662 00207$:
      0079AF 40 05            [24] 1663 	jc	00113$
      0079B1 EF               [12] 1664 	mov	a,r7
      0079B2 24 58            [12] 1665 	add	a,#0xff - 0xa7
      0079B4 50 0D            [24] 1666 	jnc	00108$
                                   1667 ;	free result
      0079B6                       1668 00113$:
      0079B6 12 7B A1         [24] 1669 	lcall	_ak820_outline_0137
      0079B9 BF A8 00         [24] 1670 	cjne	r7,#0xa8,00210$
      0079BC                       1671 00210$:
      0079BC 40 13            [24] 1672 	jc	00109$
      0079BE EF               [12] 1673 	mov	a,r7
      0079BF 24 3D            [12] 1674 	add	a,#0xff - 0xc2
      0079C1 40 0E            [24] 1675 	jc	00109$
                                   1676 ;	free result
      0079C3                       1677 00108$:
                                   1678 ;	quantum/action.c:1021: owned_usage_key(code, true);
      0079C3 12 7B A1         [24] 1679 	lcall	_ak820_outline_0137
      0079C6 90 0A B7         [24] 1680 	mov	dptr,#_owned_usage_key_PARM_2
      0079C9 74 01            [12] 1681 	mov	a,#0x01
      0079CB F0               [24] 1682 	movx	@dptr,a
      0079CC 8F 82            [24] 1683 	mov	dpl, r7
      0079CE 02 82 F0         [24] 1684 	ljmp	_owned_usage_key
      0079D1                       1685 00109$:
                                   1686 ;	quantum/action.c:1028: } else if (IS_MOUSE_KEYCODE(code)) {
      0079D1 12 7B A1         [24] 1687 	lcall	_ak820_outline_0137
      0079D4 BF CD 00         [24] 1688 	cjne	r7,#0xcd,00213$
      0079D7                       1689 00213$:
      0079D7 40 10            [24] 1690 	jc	00125$
      0079D9 EF               [12] 1691 	mov	a,r7
      0079DA 24 20            [12] 1692 	add	a,#0xff - 0xdf
      0079DC 40 0B            [24] 1693 	jc	00125$
                                   1694 ;	free result
                                   1695 ;	quantum/action.c:1029: register_mouse(code, true);
      0079DE 90 08 55         [24] 1696 	mov	dptr,#_register_mouse_PARM_2
      0079E1 74 01            [12] 1697 	mov	a,#0x01
      0079E3 F0               [24] 1698 	movx	@dptr,a
      0079E4 8F 82            [24] 1699 	mov	dpl, r7
                                   1700 ;	quantum/action.c:1031: }
      0079E6 02 76 78         [24] 1701 	ljmp	_register_mouse
      0079E9                       1702 00125$:
      0079E9 22               [24] 1703 	ret
                                   1704 ;------------------------------------------------------------
                                   1705 ;Allocation info for local variables in function 'unregister_code'
                                   1706 ;------------------------------------------------------------
                                   1707 ;code          Allocated with name '_unregister_code_code_10000_733'
                                   1708 ;------------------------------------------------------------
                                   1709 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1710 ;	-----------------------------------------
                                   1711 ;	 function unregister_code
                                   1712 ;	-----------------------------------------
      0079EA                       1713 _unregister_code:
      0079EA E5 82            [12] 1714 	mov	a,dpl
      0079EC 90 08 5D         [24] 1715 	mov	dptr,#_unregister_code_code_10000_733
      0079EF F0               [24] 1716 	movx	@dptr,a
                                   1717 ;	quantum/action.c:1038: if (code == KC_NO) {
      0079F0 E0               [24] 1718 	movx	a,@dptr
      0079F1 FF               [12] 1719 	mov	r7,a
      0079F2 70 01            [24] 1720 	jnz	00121$
                                   1721 ;	quantum/action.c:1039: return;
      0079F4 22               [24] 1722 	ret
      0079F5                       1723 00121$:
                                   1724 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      0079F5 BF 04 00         [24] 1725 	cjne	r7,#0x04,00196$
      0079F8                       1726 00196$:
      0079F8 40 12            [24] 1727 	jc	00117$
      0079FA EF               [12] 1728 	mov	a,r7
      0079FB 24 5B            [12] 1729 	add	a,#0xff - 0xa4
      0079FD 40 0D            [24] 1730 	jc	00117$
                                   1731 ;	free result
                                   1732 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      0079FF 8F 82            [24] 1733 	mov	dpl, r7
      007A01 12 82 29         [24] 1734 	lcall	_del_owned_key
      007A04 E5 82            [12] 1735 	mov	a, dpl
      007A06 70 01            [24] 1736 	jnz	00102$
      007A08 22               [24] 1737 	ret
      007A09                       1738 00102$:
                                   1739 ;	quantum/action.c:1080: send_keyboard_report();
      007A09 02 84 45         [24] 1740 	ljmp	_send_keyboard_report
      007A0C                       1741 00117$:
                                   1742 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007A0C 12 7B A7         [24] 1743 	lcall	_ak820_outline_0138
      007A0F BF E0 00         [24] 1744 	cjne	r7,#0xe0,00200$
      007A12                       1745 00200$:
      007A12 40 1A            [24] 1746 	jc	00113$
      007A14 EF               [12] 1747 	mov	a,r7
      007A15 24 18            [12] 1748 	add	a,#0xff - 0xe7
      007A17 40 15            [24] 1749 	jc	00113$
                                   1750 ;	free result
                                   1751 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007A19 74 07            [12] 1752 	mov	a,#0x07
      007A1B 5F               [12] 1753 	anl	a,r7
      007A1C 12 7B 71         [24] 1754 	lcall	_ak820_outline_0062
      007A1F 80 02            [24] 1755 	sjmp	00204$
      007A21                       1756 00203$:
      007A21 25 E0            [12] 1757 	add	a,acc
      007A23                       1758 00204$:
      007A23 D5 F0 FB         [24] 1759 	djnz	b,00203$
      007A26 F5 82            [12] 1760 	mov	dpl,a
      007A28 12 81 1C         [24] 1761 	lcall	_del_owned_mods
                                   1762 ;	quantum/action.c:1083: send_keyboard_report();
      007A2B 02 84 45         [24] 1763 	ljmp	_send_keyboard_report
      007A2E                       1764 00113$:
                                   1765 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007A2E 12 7B A7         [24] 1766 	lcall	_ak820_outline_0138
      007A31 BF A5 00         [24] 1767 	cjne	r7,#0xa5,00205$
      007A34                       1768 00205$:
      007A34 40 05            [24] 1769 	jc	00111$
      007A36 EF               [12] 1770 	mov	a,r7
      007A37 24 58            [12] 1771 	add	a,#0xff - 0xa7
      007A39 50 0D            [24] 1772 	jnc	00106$
                                   1773 ;	free result
      007A3B                       1774 00111$:
      007A3B 12 7B A7         [24] 1775 	lcall	_ak820_outline_0138
      007A3E BF A8 00         [24] 1776 	cjne	r7,#0xa8,00208$
      007A41                       1777 00208$:
      007A41 40 11            [24] 1778 	jc	00107$
      007A43 EF               [12] 1779 	mov	a,r7
      007A44 24 3D            [12] 1780 	add	a,#0xff - 0xc2
      007A46 40 0C            [24] 1781 	jc	00107$
                                   1782 ;	free result
      007A48                       1783 00106$:
                                   1784 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007A48 12 7B A7         [24] 1785 	lcall	_ak820_outline_0138
      007A4B 90 0A B7         [24] 1786 	mov	dptr,#_owned_usage_key_PARM_2
      007A4E 12 7B B2         [24] 1787 	lcall	_ak820_outline_0183
      007A51 02 82 F0         [24] 1788 	ljmp	_owned_usage_key
      007A54                       1789 00107$:
                                   1790 ;	quantum/action.c:1095: } else if (IS_MOUSE_KEYCODE(code)) {
      007A54 12 7B A7         [24] 1791 	lcall	_ak820_outline_0138
      007A57 BF CD 00         [24] 1792 	cjne	r7,#0xcd,00211$
      007A5A                       1793 00211$:
      007A5A 40 0E            [24] 1794 	jc	00123$
      007A5C EF               [12] 1795 	mov	a,r7
      007A5D 24 20            [12] 1796 	add	a,#0xff - 0xdf
      007A5F 40 09            [24] 1797 	jc	00123$
                                   1798 ;	free result
                                   1799 ;	quantum/action.c:1096: register_mouse(code, false);
      007A61 90 08 55         [24] 1800 	mov	dptr,#_register_mouse_PARM_2
      007A64 12 7B B2         [24] 1801 	lcall	_ak820_outline_0183
                                   1802 ;	quantum/action.c:1098: }
      007A67 02 76 78         [24] 1803 	ljmp	_register_mouse
      007A6A                       1804 00123$:
      007A6A 22               [24] 1805 	ret
                                   1806 ;------------------------------------------------------------
                                   1807 ;Allocation info for local variables in function 'tap_code_delay'
                                   1808 ;------------------------------------------------------------
                                   1809 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1810 ;code          Allocated with name '_tap_code_delay_code_10000_746'
                                   1811 ;i             Allocated with name '_tap_code_delay_i_20000_748'
                                   1812 ;i             Allocated with name '_tap_code_delay_i_50000_751'
                                   1813 ;------------------------------------------------------------
                                   1814 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1815 ;	-----------------------------------------
                                   1816 ;	 function tap_code_delay
                                   1817 ;	-----------------------------------------
      007A6B                       1818 _tap_code_delay:
      007A6B E5 82            [12] 1819 	mov	a,dpl
      007A6D 90 08 60         [24] 1820 	mov	dptr,#_tap_code_delay_code_10000_746
      007A70 F0               [24] 1821 	movx	@dptr,a
                                   1822 ;	quantum/action.c:1106: register_code(code);
      007A71 E0               [24] 1823 	movx	a,@dptr
      007A72 FF               [12] 1824 	mov	r7,a
      007A73 F5 82            [12] 1825 	mov	dpl,a
      007A75 C0 07            [24] 1826 	push	ar7
      007A77 12 79 65         [24] 1827 	lcall	_register_code
      007A7A D0 07            [24] 1828 	pop	ar7
                                   1829 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007A7C 90 08 5E         [24] 1830 	mov	dptr,#_tap_code_delay_PARM_2
      007A7F 12 45 54         [24] 1831 	lcall	_ak820_outline_0092
      007A82                       1832 00110$:
      007A82 ED               [12] 1833 	mov	a,r5
      007A83 4E               [12] 1834 	orl	a,r6
      007A84 60 0D            [24] 1835 	jz	00105$
                                   1836 ;	quantum/action.c:1108: wait_ms(1);
      007A86 90 00 01         [24] 1837 	mov	dptr,#0x0001
      007A89 12 5D 37         [24] 1838 	lcall	_mDelaymS
                                   1839 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007A8C 1D               [12] 1840 	dec	r5
      007A8D BD FF 01         [24] 1841 	cjne	r5,#0xff,00141$
      007A90 1E               [12] 1842 	dec	r6
      007A91                       1843 00141$:
      007A91 80 EF            [24] 1844 	sjmp	00110$
      007A93                       1845 00105$:
                                   1846 ;	quantum/action.c:1110: unregister_code(code);
      007A93 8F 82            [24] 1847 	mov	dpl, r7
                                   1848 ;	quantum/action.c:1111: }
      007A95 02 79 EA         [24] 1849 	ljmp	_unregister_code
                                   1850 ;------------------------------------------------------------
                                   1851 ;Allocation info for local variables in function 'tap_code'
                                   1852 ;------------------------------------------------------------
                                   1853 ;code          Allocated with name '_tap_code_code_10000_753'
                                   1854 ;------------------------------------------------------------
                                   1855 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1856 ;	-----------------------------------------
                                   1857 ;	 function tap_code
                                   1858 ;	-----------------------------------------
      007A98                       1859 _tap_code:
      007A98 E5 82            [12] 1860 	mov	a,dpl
      007A9A 90 08 61         [24] 1861 	mov	dptr,#_tap_code_code_10000_753
      007A9D F0               [24] 1862 	movx	@dptr,a
                                   1863 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007A9E E0               [24] 1864 	movx	a,@dptr
      007A9F FF               [12] 1865 	mov	r7,a
      007AA0 BF 39 04         [24] 1866 	cjne	r7,#0x39,00103$
      007AA3 7E 50            [12] 1867 	mov	r6,#0x50
      007AA5 80 02            [24] 1868 	sjmp	00104$
      007AA7                       1869 00103$:
      007AA7 7E 00            [12] 1870 	mov	r6,#0x00
      007AA9                       1871 00104$:
      007AA9 90 08 5E         [24] 1872 	mov	dptr,#_tap_code_delay_PARM_2
      007AAC EE               [12] 1873 	mov	a,r6
      007AAD 12 3A A6         [24] 1874 	lcall	_ak820_outline_0122
      007AB0 8F 82            [24] 1875 	mov	dpl, r7
                                   1876 ;	quantum/action.c:1119: }
      007AB2 02 7A 6B         [24] 1877 	ljmp	_tap_code_delay
                                   1878 ;------------------------------------------------------------
                                   1879 ;Allocation info for local variables in function 'register_mods'
                                   1880 ;------------------------------------------------------------
                                   1881 ;mods          Allocated with name '_register_mods_mods_10000_755'
                                   1882 ;------------------------------------------------------------
                                   1883 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1884 ;	-----------------------------------------
                                   1885 ;	 function register_mods
                                   1886 ;	-----------------------------------------
      007AB5                       1887 _register_mods:
      007AB5 E5 82            [12] 1888 	mov	a,dpl
      007AB7 90 08 62         [24] 1889 	mov	dptr,#_register_mods_mods_10000_755
      007ABA F0               [24] 1890 	movx	@dptr,a
                                   1891 ;	quantum/action.c:1126: if (mods) {
      007ABB E0               [24] 1892 	movx	a,@dptr
      007ABC FF               [12] 1893 	mov	r7,a
      007ABD E0               [24] 1894 	movx	a,@dptr
      007ABE 60 08            [24] 1895 	jz	00103$
                                   1896 ;	quantum/action.c:1127: add_owned_mods(mods);
      007AC0 8F 82            [24] 1897 	mov	dpl, r7
      007AC2 12 81 0C         [24] 1898 	lcall	_add_owned_mods
                                   1899 ;	quantum/action.c:1128: send_keyboard_report();
                                   1900 ;	quantum/action.c:1130: }
      007AC5 02 84 45         [24] 1901 	ljmp	_send_keyboard_report
      007AC8                       1902 00103$:
      007AC8 22               [24] 1903 	ret
                                   1904 ;------------------------------------------------------------
                                   1905 ;Allocation info for local variables in function 'unregister_mods'
                                   1906 ;------------------------------------------------------------
                                   1907 ;mods          Allocated with name '_unregister_mods_mods_10000_759'
                                   1908 ;------------------------------------------------------------
                                   1909 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1910 ;	-----------------------------------------
                                   1911 ;	 function unregister_mods
                                   1912 ;	-----------------------------------------
      007AC9                       1913 _unregister_mods:
      007AC9 E5 82            [12] 1914 	mov	a,dpl
      007ACB 90 08 63         [24] 1915 	mov	dptr,#_unregister_mods_mods_10000_759
      007ACE F0               [24] 1916 	movx	@dptr,a
                                   1917 ;	quantum/action.c:1137: if (mods) {
      007ACF E0               [24] 1918 	movx	a,@dptr
      007AD0 FF               [12] 1919 	mov	r7,a
      007AD1 E0               [24] 1920 	movx	a,@dptr
      007AD2 60 08            [24] 1921 	jz	00103$
                                   1922 ;	quantum/action.c:1138: del_owned_mods(mods);
      007AD4 8F 82            [24] 1923 	mov	dpl, r7
      007AD6 12 81 1C         [24] 1924 	lcall	_del_owned_mods
                                   1925 ;	quantum/action.c:1139: send_keyboard_report();
                                   1926 ;	quantum/action.c:1141: }
      007AD9 02 84 45         [24] 1927 	ljmp	_send_keyboard_report
      007ADC                       1928 00103$:
      007ADC 22               [24] 1929 	ret
                                   1930 ;------------------------------------------------------------
                                   1931 ;Allocation info for local variables in function 'register_weak_mods'
                                   1932 ;------------------------------------------------------------
                                   1933 ;mods          Allocated with name '_register_weak_mods_mods_10000_763'
                                   1934 ;------------------------------------------------------------
                                   1935 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1936 ;	-----------------------------------------
                                   1937 ;	 function register_weak_mods
                                   1938 ;	-----------------------------------------
      007ADD                       1939 _register_weak_mods:
      007ADD E5 82            [12] 1940 	mov	a,dpl
      007ADF 90 08 64         [24] 1941 	mov	dptr,#_register_weak_mods_mods_10000_763
      007AE2 F0               [24] 1942 	movx	@dptr,a
                                   1943 ;	quantum/action.c:1148: if (mods) {
      007AE3 E0               [24] 1944 	movx	a,@dptr
      007AE4 FF               [12] 1945 	mov	r7,a
      007AE5 E0               [24] 1946 	movx	a,@dptr
      007AE6 60 08            [24] 1947 	jz	00103$
                                   1948 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      007AE8 8F 82            [24] 1949 	mov	dpl, r7
      007AEA 12 81 2A         [24] 1950 	lcall	_add_owned_weak_mods
                                   1951 ;	quantum/action.c:1150: send_keyboard_report();
                                   1952 ;	quantum/action.c:1152: }
      007AED 02 84 45         [24] 1953 	ljmp	_send_keyboard_report
      007AF0                       1954 00103$:
      007AF0 22               [24] 1955 	ret
                                   1956 ;------------------------------------------------------------
                                   1957 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1958 ;------------------------------------------------------------
                                   1959 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_767'
                                   1960 ;------------------------------------------------------------
                                   1961 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1962 ;	-----------------------------------------
                                   1963 ;	 function unregister_weak_mods
                                   1964 ;	-----------------------------------------
      007AF1                       1965 _unregister_weak_mods:
      007AF1 E5 82            [12] 1966 	mov	a,dpl
      007AF3 90 08 65         [24] 1967 	mov	dptr,#_unregister_weak_mods_mods_10000_767
      007AF6 F0               [24] 1968 	movx	@dptr,a
                                   1969 ;	quantum/action.c:1159: if (mods) {
      007AF7 E0               [24] 1970 	movx	a,@dptr
      007AF8 FF               [12] 1971 	mov	r7,a
      007AF9 E0               [24] 1972 	movx	a,@dptr
      007AFA 60 08            [24] 1973 	jz	00103$
                                   1974 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      007AFC 8F 82            [24] 1975 	mov	dpl, r7
      007AFE 12 81 3A         [24] 1976 	lcall	_del_owned_weak_mods
                                   1977 ;	quantum/action.c:1161: send_keyboard_report();
                                   1978 ;	quantum/action.c:1163: }
      007B01 02 84 45         [24] 1979 	ljmp	_send_keyboard_report
      007B04                       1980 00103$:
      007B04 22               [24] 1981 	ret
                                   1982 ;------------------------------------------------------------
                                   1983 ;Allocation info for local variables in function 'clear_keyboard'
                                   1984 ;------------------------------------------------------------
                                   1985 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1986 ;	-----------------------------------------
                                   1987 ;	 function clear_keyboard
                                   1988 ;	-----------------------------------------
      007B05                       1989 _clear_keyboard:
                                   1990 ;	quantum/action.c:1170: clear_mods();
      007B05 12 84 C0         [24] 1991 	lcall	_clear_mods
                                   1992 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1993 ;	quantum/action.c:1172: }
      007B08 02 7B 0B         [24] 1994 	ljmp	_clear_keyboard_but_mods
                                   1995 ;------------------------------------------------------------
                                   1996 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1997 ;------------------------------------------------------------
                                   1998 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1999 ;	-----------------------------------------
                                   2000 ;	 function clear_keyboard_but_mods
                                   2001 ;	-----------------------------------------
      007B0B                       2002 _clear_keyboard_but_mods:
                                   2003 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B0B 90 0D C4         [24] 2004 	mov	dptr,#_actual_keyboard_report
      007B0E 12 73 88         [24] 2005 	lcall	_clear_keys_from_report
                                   2006 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   2007 ;	quantum/action.c:1181: }
      007B11 02 7B 14         [24] 2008 	ljmp	_clear_keyboard_but_mods_and_keys
                                   2009 ;------------------------------------------------------------
                                   2010 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2011 ;------------------------------------------------------------
                                   2012 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   2013 ;	-----------------------------------------
                                   2014 ;	 function clear_keyboard_but_mods_and_keys
                                   2015 ;	-----------------------------------------
      007B14                       2016 _clear_keyboard_but_mods_and_keys:
                                   2017 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007B14 12 48 D6         [24] 2018 	lcall	_ak820_tapping_cancel
                                   2019 ;	quantum/action.c:1203: ak820_autoshift_cancel();
      007B17 12 33 45         [24] 2020 	lcall	_ak820_autoshift_cancel
                                   2021 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007B1A 12 2E F0         [24] 2022 	lcall	_ak820_oneshot_cancel
                                   2023 ;	quantum/action.c:1209: ak820_combo_cancel();
      007B1D 12 37 6D         [24] 2024 	lcall	_ak820_combo_cancel
                                   2025 ;	quantum/action.c:1212: repeat_key_cancel();
      007B20 12 A4 8F         [24] 2026 	lcall	_repeat_key_cancel
                                   2027 ;	quantum/action.c:1214: clear_owned_mods();
      007B23 12 81 4A         [24] 2028 	lcall	_clear_owned_mods
                                   2029 ;	quantum/action.c:1215: clear_owned_keys();
      007B26 12 81 82         [24] 2030 	lcall	_clear_owned_keys
                                   2031 ;	quantum/action.c:1216: clear_owned_usages();
      007B29 12 82 B8         [24] 2032 	lcall	_clear_owned_usages
                                   2033 ;	quantum/action.c:1217: layer_hold_clear();
      007B2C 12 7C F7         [24] 2034 	lcall	_layer_hold_clear
                                   2035 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007B2F 12 A0 2F         [24] 2036 	lcall	_clear_macro_tri_layer
                                   2037 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B32 90 0D C4         [24] 2038 	mov	dptr,#_actual_keyboard_report
      007B35 12 73 88         [24] 2039 	lcall	_clear_keys_from_report
                                   2040 ;	quantum/action.c:1224: host_system_send(0);
      007B38 90 00 00         [24] 2041 	mov	dptr,#0x0000
      007B3B 12 71 63         [24] 2042 	lcall	_host_system_send
                                   2043 ;	quantum/action.c:1225: host_consumer_send(0);
      007B3E 90 00 00         [24] 2044 	mov	dptr,#0x0000
      007B41 12 71 93         [24] 2045 	lcall	_host_consumer_send
                                   2046 ;	quantum/action.c:1227: clear_weak_mods();
      007B44 12 84 F5         [24] 2047 	lcall	_clear_weak_mods
                                   2048 ;	quantum/action.c:1228: send_keyboard_report();
      007B47 12 84 45         [24] 2049 	lcall	_send_keyboard_report
                                   2050 ;	quantum/action.c:1230: mousekey_clear();
      007B4A 12 53 AC         [24] 2051 	lcall	_mousekey_clear
                                   2052 ;	quantum/action.c:1231: mousekey_send();
                                   2053 ;	quantum/action.c:1236: }
      007B4D 02 52 74         [24] 2054 	ljmp	_mousekey_send
                                   2055 ;------------------------------------------------------------
                                   2056 ;Allocation info for local variables in function 'is_tap_record'
                                   2057 ;------------------------------------------------------------
                                   2058 ;record        Allocated with name '_is_tap_record_record_10000_783'
                                   2059 ;action        Allocated with name '_is_tap_record_action_10001_787'
                                   2060 ;------------------------------------------------------------
                                   2061 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   2062 ;	-----------------------------------------
                                   2063 	.area CSEG    (CODE)
                                   2064 	.area CONST   (CODE)
                                   2065 	.area XINIT   (CODE)
      00C452                       2066 __xinit__disable_action_cache:
      00C452 00                    2067 	.db #0x00	;  0
                                   2068 	.area CABS    (ABS,CODE)
                                   2069 
                                   2070 ; Experimental exact instruction outlining.
                                   2071 	.globl _ak820_outline_0004
                                   2072 	.globl _ak820_outline_0008
                                   2073 	.globl _ak820_outline_0009
                                   2074 	.globl _ak820_outline_0010
                                   2075 	.globl _ak820_outline_0011
                                   2076 	.globl _ak820_outline_0015
                                   2077 	.globl _ak820_outline_0016
                                   2078 	.globl _ak820_outline_0019
                                   2079 	.globl _ak820_outline_0030
                                   2080 	.globl _ak820_outline_0038
                                   2081 	.globl _ak820_outline_0049
                                   2082 	.globl _ak820_outline_0050
                                   2083 	.globl _ak820_outline_0054
                                   2084 	.globl _ak820_outline_0057
                                   2085 	.globl _ak820_outline_0062
                                   2086 	.globl _ak820_outline_0070
                                   2087 	.globl _ak820_outline_0075
                                   2088 	.globl _ak820_outline_0085
                                   2089 	.globl _ak820_outline_0092
                                   2090 	.globl _ak820_outline_0103
                                   2091 	.globl _ak820_outline_0104
                                   2092 	.globl _ak820_outline_0106
                                   2093 	.globl _ak820_outline_0107
                                   2094 	.globl _ak820_outline_0109
                                   2095 	.globl _ak820_outline_0116
                                   2096 	.globl _ak820_outline_0117
                                   2097 	.globl _ak820_outline_0121
                                   2098 	.globl _ak820_outline_0122
                                   2099 	.globl _ak820_outline_0128
                                   2100 	.globl _ak820_outline_0137
                                   2101 	.globl _ak820_outline_0138
                                   2102 	.globl _ak820_outline_0140
                                   2103 	.globl _ak820_outline_0141
                                   2104 	.globl _ak820_outline_0146
                                   2105 	.globl _ak820_outline_0147
                                   2106 	.globl _ak820_outline_0165
                                   2107 	.globl _ak820_outline_0183
                                   2108 
                                   2109 	.area CSEG (CODE)
                                   2110 ; function ak820_outline_0019
      007B50                       2111 _ak820_outline_0019:
      007B50 8E 82            [24] 2112 	mov	dpl,r6
      007B52 8F 83            [24] 2113 	mov	dph,r7
      007B54 A3               [24] 2114 	inc	dptr
      007B55 E0               [24] 2115 	movx	a,@dptr
      007B56 FC               [12] 2116 	mov	r4,a
      007B57 7D 00            [12] 2117 	mov	r5,#0x00
      007B59 8E 82            [24] 2118 	mov	dpl,r6
      007B5B 8F 83            [24] 2119 	mov	dph,r7
      007B5D E0               [24] 2120 	movx	a,@dptr
      007B5E 22               [24] 2121 	ret
                                   2122 
                                   2123 	.area CSEG (CODE)
                                   2124 ; function ak820_outline_0038
      007B5F                       2125 _ak820_outline_0038:
      007B5F 90 08 58         [24] 2126 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B62 E0               [24] 2127 	movx	a,@dptr
      007B63 54 1F            [12] 2128 	anl	a,#0x1f
      007B65 F5 82            [12] 2129 	mov	dpl,a
      007B67 22               [24] 2130 	ret
                                   2131 
                                   2132 	.area CSEG (CODE)
                                   2133 ; function ak820_outline_0049
      007B68                       2134 _ak820_outline_0049:
      007B68 A3               [24] 2135 	inc	dptr
      007B69 F0               [24] 2136 	movx	@dptr,a
      007B6A E4               [12] 2137 	clr	a
      007B6B A3               [24] 2138 	inc	dptr
      007B6C F0               [24] 2139 	movx	@dptr,a
      007B6D 90 0D A1         [24] 2140 	mov	dptr,#___memcpy_PARM_3
      007B70 22               [24] 2141 	ret
                                   2142 
                                   2143 	.area CSEG (CODE)
                                   2144 ; function ak820_outline_0062
      007B71                       2145 _ak820_outline_0062:
      007B71 F5 F0            [12] 2146 	mov	b,a
      007B73 05 F0            [12] 2147 	inc	b
      007B75 74 01            [12] 2148 	mov	a,#0x01
      007B77 22               [24] 2149 	ret
                                   2150 
                                   2151 	.area CSEG (CODE)
                                   2152 ; function ak820_outline_0075
      007B78                       2153 _ak820_outline_0075:
      007B78 90 08 57         [24] 2154 	mov	dptr,#_process_action_PARM_2
      007B7B E0               [24] 2155 	movx	a,@dptr
      007B7C F5 82            [12] 2156 	mov	dpl,a
      007B7E 22               [24] 2157 	ret
                                   2158 
                                   2159 	.area CSEG (CODE)
                                   2160 ; function ak820_outline_0085
      007B7F                       2161 _ak820_outline_0085:
      007B7F 90 08 58         [24] 2162 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B82 E0               [24] 2163 	movx	a,@dptr
      007B83 03               [12] 2164 	rr	a
      007B84 03               [12] 2165 	rr	a
      007B85 54 03            [12] 2166 	anl	a,#0x03
      007B87 22               [24] 2167 	ret
                                   2168 
                                   2169 	.area CSEG (CODE)
                                   2170 ; function ak820_outline_0107
      007B88                       2171 _ak820_outline_0107:
      007B88 74 06            [12] 2172 	mov	a,#0x06
      007B8A F0               [24] 2173 	movx	@dptr,a
      007B8B E4               [12] 2174 	clr	a
      007B8C A3               [24] 2175 	inc	dptr
      007B8D F0               [24] 2176 	movx	@dptr,a
      007B8E 22               [24] 2177 	ret
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0109
      007B8F                       2181 _ak820_outline_0109:
      007B8F 90 08 58         [24] 2182 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B92 E0               [24] 2183 	movx	a,@dptr
      007B93 54 0F            [12] 2184 	anl	a,#0x0f
      007B95 22               [24] 2185 	ret
                                   2186 
                                   2187 	.area CSEG (CODE)
                                   2188 ; function ak820_outline_0128
      007B96                       2189 _ak820_outline_0128:
      007B96 90 08 57         [24] 2190 	mov	dptr,#_process_action_PARM_2
      007B99 E0               [24] 2191 	movx	a,@dptr
      007B9A FE               [12] 2192 	mov	r6,a
      007B9B A3               [24] 2193 	inc	dptr
      007B9C E0               [24] 2194 	movx	a,@dptr
      007B9D 54 03            [12] 2195 	anl	a,#0x03
      007B9F FF               [12] 2196 	mov	r7,a
      007BA0 22               [24] 2197 	ret
                                   2198 
                                   2199 	.area CSEG (CODE)
                                   2200 ; function ak820_outline_0137
      007BA1                       2201 _ak820_outline_0137:
      007BA1 90 08 5C         [24] 2202 	mov	dptr,#_register_code_code_10000_719
      007BA4 E0               [24] 2203 	movx	a,@dptr
      007BA5 FF               [12] 2204 	mov	r7,a
      007BA6 22               [24] 2205 	ret
                                   2206 
                                   2207 	.area CSEG (CODE)
                                   2208 ; function ak820_outline_0138
      007BA7                       2209 _ak820_outline_0138:
      007BA7 90 08 5D         [24] 2210 	mov	dptr,#_unregister_code_code_10000_733
      007BAA E0               [24] 2211 	movx	a,@dptr
      007BAB FF               [12] 2212 	mov	r7,a
      007BAC 22               [24] 2213 	ret
                                   2214 
                                   2215 	.area CSEG (CODE)
                                   2216 ; function ak820_outline_0146
      007BAD                       2217 _ak820_outline_0146:
      007BAD 90 08 57         [24] 2218 	mov	dptr,#_process_action_PARM_2
      007BB0 E0               [24] 2219 	movx	a,@dptr
      007BB1 22               [24] 2220 	ret
                                   2221 
                                   2222 	.area CSEG (CODE)
                                   2223 ; function ak820_outline_0183
      007BB2                       2224 _ak820_outline_0183:
      007BB2 E4               [12] 2225 	clr	a
      007BB3 F0               [24] 2226 	movx	@dptr,a
      007BB4 8F 82            [24] 2227 	mov	dpl,r7
      007BB6 22               [24] 2228 	ret
