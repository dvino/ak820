                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00068E                         85 _eeprom_read_word_addr_10000_91:
      00068E                         86 	.ds 3
      000691                         87 _eeprom_read_word_ret_10000_92:
      000691                         88 	.ds 2
      000693                         89 _eeprom_read_dword_addr_10000_93:
      000693                         90 	.ds 3
      000696                         91 _eeprom_read_dword_ret_10000_94:
      000696                         92 	.ds 4
      00069A                         93 _eeprom_write_byte_PARM_2:
      00069A                         94 	.ds 1
      00069B                         95 _eeprom_write_byte_addr_10000_95:
      00069B                         96 	.ds 3
      00069E                         97 _eeprom_write_word_PARM_2:
      00069E                         98 	.ds 2
      0006A0                         99 _eeprom_write_word_addr_10000_97:
      0006A0                        100 	.ds 3
      0006A3                        101 _eeprom_write_dword_PARM_2:
      0006A3                        102 	.ds 4
      0006A7                        103 _eeprom_write_dword_addr_10000_99:
      0006A7                        104 	.ds 3
      0006AA                        105 _eeprom_update_byte_PARM_2:
      0006AA                        106 	.ds 1
      0006AB                        107 _eeprom_update_byte_addr_10000_107:
      0006AB                        108 	.ds 3
      0006AE                        109 _eeprom_update_word_PARM_2:
      0006AE                        110 	.ds 2
      0006B0                        111 _eeprom_update_word_addr_10000_111:
      0006B0                        112 	.ds 3
      0006B3                        113 _eeprom_update_dword_PARM_2:
      0006B3                        114 	.ds 4
      0006B7                        115 _eeprom_update_dword_addr_10000_115:
      0006B7                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004F45                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004F45 12 45 1D         [24]  170 	lcall	_ak820_outline_0036
      004F48 90 06 8E         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004F4B 12 3A 26         [24]  172 	lcall	_ak820_outline_0015
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004F4E 90 06 91         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004F51 12 51 51         [24]  175 	lcall	_ak820_outline_0165
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004F54 90 06 8E         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004F57 12 50 FF         [24]  178 	lcall	_ak820_outline_0021
      004F5A 90 05 91         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004F5D ED               [12]  180 	mov	a,r5
      004F5E 12 3A 26         [24]  181 	lcall	_ak820_outline_0015
      004F61 90 05 94         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004F64 12 51 43         [24]  183 	lcall	_ak820_outline_0106
      004F67 90 06 91         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004F6A 12 42 B9         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004F6D 90 06 91         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004F70 12 51 3A         [24]  188 	lcall	_ak820_outline_0088
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004F73 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004F74                        201 _eeprom_read_dword:
      004F74 12 45 1D         [24]  202 	lcall	_ak820_outline_0036
      004F77 90 06 93         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004F7A 12 3A 26         [24]  204 	lcall	_ak820_outline_0015
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004F7D 90 06 96         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004F80 12 51 0F         [24]  207 	lcall	_ak820_outline_0048
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004F83 90 06 93         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004F86 12 50 FF         [24]  210 	lcall	_ak820_outline_0021
      004F89 90 05 91         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004F8C ED               [12]  212 	mov	a,r5
      004F8D 12 3A 26         [24]  213 	lcall	_ak820_outline_0015
      004F90 90 05 94         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004F93 74 04            [12]  215 	mov	a,#0x04
      004F95 12 3A A6         [24]  216 	lcall	_ak820_outline_0122
      004F98 90 06 96         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004F9B 12 42 B9         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004F9E 90 06 96         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004FA1 12 51 18         [24]  221 	lcall	_ak820_outline_0053
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004FA4 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004FA5                        234 _eeprom_write_byte:
      004FA5 12 45 1D         [24]  235 	lcall	_ak820_outline_0036
      004FA8 90 06 9B         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004FAB 12 3A 26         [24]  237 	lcall	_ak820_outline_0015
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004FAE 90 06 9B         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004FB1 12 50 D9         [24]  240 	lcall	_ak820_outline_0002
      004FB4 74 01            [12]  241 	mov	a,#0x01
      004FB6 12 3A A6         [24]  242 	lcall	_ak820_outline_0122
      004FB9 90 06 9A         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004FBC 02 43 45         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004FBF                        256 _eeprom_write_word:
      004FBF 12 45 1D         [24]  257 	lcall	_ak820_outline_0036
      004FC2 90 06 A0         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004FC5 12 3A 26         [24]  259 	lcall	_ak820_outline_0015
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004FC8 90 06 A0         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004FCB 12 50 D9         [24]  262 	lcall	_ak820_outline_0002
      004FCE 12 51 43         [24]  263 	lcall	_ak820_outline_0106
      004FD1 90 06 9E         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004FD4 02 43 45         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004FD7                        277 _eeprom_write_dword:
      004FD7 12 45 1D         [24]  278 	lcall	_ak820_outline_0036
      004FDA 90 06 A7         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004FDD 12 3A 26         [24]  280 	lcall	_ak820_outline_0015
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004FE0 90 06 A7         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004FE3 12 50 D9         [24]  283 	lcall	_ak820_outline_0002
      004FE6 74 04            [12]  284 	mov	a,#0x04
      004FE8 12 3A A6         [24]  285 	lcall	_ak820_outline_0122
      004FEB 90 06 A3         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004FEE 02 43 45         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004FF1                        307 _eeprom_update_byte:
      004FF1 C0 07            [24]  308 	push	ar7
      004FF3 C0 06            [24]  309 	push	ar6
      004FF5 C0 05            [24]  310 	push	ar5
      004FF7 C0 04            [24]  311 	push	ar4
      004FF9 12 45 1D         [24]  312 	lcall	_ak820_outline_0036
      004FFC 90 06 AB         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004FFF 12 3A 26         [24]  314 	lcall	_ak820_outline_0015
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      005002 90 06 AB         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005005 12 50 F0         [24]  317 	lcall	_ak820_outline_0003
      005008 12 42 7E         [24]  318 	lcall	_eeprom_read_byte
      00500B AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      00500D 90 06 AA         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      005010 E0               [24]  322 	movx	a,@dptr
      005011 FE               [12]  323 	mov	r6,a
      005012 EF               [12]  324 	mov	a,r7
      005013 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      005016 80 36            [24]  326 	sjmp	00103$
      005018                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      005018 90 06 AB         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00501B 12 3A 66         [24]  330 	lcall	_ak820_outline_0059
      00501E A3               [24]  331 	inc	dptr
      00501F E0               [24]  332 	movx	a,@dptr
      005020 FF               [12]  333 	mov	r7,a
      005021 90 06 9A         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      005024 EE               [12]  335 	mov	a,r6
      005025 F0               [24]  336 	movx	@dptr,a
      005026 12 3A 9B         [24]  337 	lcall	_ak820_outline_0117
      005029 8F F0            [24]  338 	mov	b, r7
      00502B C0 07            [24]  339 	push	ar7
      00502D C0 06            [24]  340 	push	ar6
      00502F C0 05            [24]  341 	push	ar5
      005031 C0 04            [24]  342 	push	ar4
      005033 C0 03            [24]  343 	push	ar3
      005035 C0 02            [24]  344 	push	ar2
      005037 C0 01            [24]  345 	push	ar1
      005039 C0 00            [24]  346 	push	ar0
      00503B 12 4F A5         [24]  347 	lcall	_eeprom_write_byte
      00503E D0 00            [24]  348 	pop	ar0
      005040 D0 01            [24]  349 	pop	ar1
      005042 D0 02            [24]  350 	pop	ar2
      005044 D0 03            [24]  351 	pop	ar3
      005046 D0 04            [24]  352 	pop	ar4
      005048 D0 05            [24]  353 	pop	ar5
      00504A D0 06            [24]  354 	pop	ar6
      00504C D0 07            [24]  355 	pop	ar7
      00504E                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      00504E D0 04            [24]  358 	pop	ar4
      005050 D0 05            [24]  359 	pop	ar5
      005052 D0 06            [24]  360 	pop	ar6
      005054 D0 07            [24]  361 	pop	ar7
      005056 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      005057                        374 _eeprom_update_word:
      005057 12 45 1D         [24]  375 	lcall	_ak820_outline_0036
      00505A 90 06 B0         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      00505D 12 3A 26         [24]  377 	lcall	_ak820_outline_0015
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      005060 90 06 B0         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005063 12 50 F0         [24]  380 	lcall	_ak820_outline_0003
      005066 12 4F 45         [24]  381 	lcall	_eeprom_read_word
      005069 12 45 71         [24]  382 	lcall	_ak820_outline_0130
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      00506C 90 06 AE         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      00506F 12 3A 66         [24]  385 	lcall	_ak820_outline_0059
      005072 EE               [12]  386 	mov	a,r6
      005073 B5 04 05         [24]  387 	cjne	a,ar4,00112$
      005076 EF               [12]  388 	mov	a,r7
      005077 B5 05 01         [24]  389 	cjne	a,ar5,00112$
      00507A 22               [24]  390 	ret
      00507B                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      00507B 90 06 B0         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      00507E E0               [24]  394 	movx	a,@dptr
      00507F FB               [12]  395 	mov	r3,a
      005080 A3               [24]  396 	inc	dptr
      005081 12 3A 47         [24]  397 	lcall	_ak820_outline_0050
      005084 90 06 9E         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      005087 12 3A 6C         [24]  399 	lcall	_ak820_outline_0070
      00508A 8B 82            [24]  400 	mov	dpl, r3
      00508C 8E 83            [24]  401 	mov	dph, r6
      00508E 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      005090 02 4F BF         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      005093                        416 _eeprom_update_dword:
      005093 12 45 1D         [24]  417 	lcall	_ak820_outline_0036
      005096 90 06 B7         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005099 12 3A 26         [24]  419 	lcall	_ak820_outline_0015
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      00509C 90 06 B7         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00509F 12 50 F0         [24]  422 	lcall	_ak820_outline_0003
      0050A2 12 4F 74         [24]  423 	lcall	_eeprom_read_dword
      0050A5 12 51 29         [24]  424 	lcall	_ak820_outline_0056
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      0050A8 90 06 B3         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      0050AB E0               [24]  427 	movx	a,@dptr
      0050AC F8               [12]  428 	mov	r0,a
      0050AD A3               [24]  429 	inc	dptr
      0050AE 12 51 31         [24]  430 	lcall	_ak820_outline_0087
      0050B1 EC               [12]  431 	mov	a,r4
      0050B2 B5 00 0D         [24]  432 	cjne	a,ar0,00112$
      0050B5 ED               [12]  433 	mov	a,r5
      0050B6 B5 01 09         [24]  434 	cjne	a,ar1,00112$
      0050B9 EE               [12]  435 	mov	a,r6
      0050BA B5 02 05         [24]  436 	cjne	a,ar2,00112$
      0050BD EF               [12]  437 	mov	a,r7
      0050BE B5 03 01         [24]  438 	cjne	a,ar3,00112$
      0050C1 22               [24]  439 	ret
      0050C2                        440 00112$:
                                    441 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      0050C2 90 06 B7         [24]  442 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0050C5 12 50 FF         [24]  443 	lcall	_ak820_outline_0021
      0050C8 90 06 A3         [24]  444 	mov	dptr,#_eeprom_write_dword_PARM_2
      0050CB E8               [12]  445 	mov	a,r0
      0050CC F0               [24]  446 	movx	@dptr,a
      0050CD E9               [12]  447 	mov	a,r1
      0050CE A3               [24]  448 	inc	dptr
      0050CF 12 51 4A         [24]  449 	lcall	_ak820_outline_0153
      0050D2 F0               [24]  450 	movx	@dptr,a
      0050D3 12 51 08         [24]  451 	lcall	_ak820_outline_0043
                                    452 ;	drivers/eeprom/eeprom_driver.c:101: }
      0050D6 02 4F D7         [24]  453 	ljmp	_eeprom_write_dword
                                    454 	.area CSEG    (CODE)
                                    455 	.area CONST   (CODE)
                                    456 	.area XINIT   (CODE)
                                    457 	.area CABS    (ABS,CODE)
                                    458 
                                    459 ; Experimental exact instruction outlining.
                                    460 	.globl _ak820_outline_0002
                                    461 	.globl _ak820_outline_0003
                                    462 	.globl _ak820_outline_0015
                                    463 	.globl _ak820_outline_0021
                                    464 	.globl _ak820_outline_0036
                                    465 	.globl _ak820_outline_0043
                                    466 	.globl _ak820_outline_0048
                                    467 	.globl _ak820_outline_0050
                                    468 	.globl _ak820_outline_0053
                                    469 	.globl _ak820_outline_0056
                                    470 	.globl _ak820_outline_0059
                                    471 	.globl _ak820_outline_0070
                                    472 	.globl _ak820_outline_0087
                                    473 	.globl _ak820_outline_0088
                                    474 	.globl _ak820_outline_0106
                                    475 	.globl _ak820_outline_0117
                                    476 	.globl _ak820_outline_0122
                                    477 	.globl _ak820_outline_0130
                                    478 	.globl _ak820_outline_0153
                                    479 	.globl _ak820_outline_0165
                                    480 
                                    481 	.area CSEG (CODE)
                                    482 ; function ak820_outline_0002
      0050D9                        483 _ak820_outline_0002:
      0050D9 E0               [24]  484 	movx	a,@dptr
      0050DA FD               [12]  485 	mov	r5,a
      0050DB A3               [24]  486 	inc	dptr
      0050DC E0               [24]  487 	movx	a,@dptr
      0050DD FE               [12]  488 	mov	r6,a
      0050DE A3               [24]  489 	inc	dptr
      0050DF E0               [24]  490 	movx	a,@dptr
      0050E0 FF               [12]  491 	mov	r7,a
      0050E1 90 05 9A         [24]  492 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0050E4 ED               [12]  493 	mov	a,r5
      0050E5 F0               [24]  494 	movx	@dptr,a
      0050E6 EE               [12]  495 	mov	a,r6
      0050E7 A3               [24]  496 	inc	dptr
      0050E8 F0               [24]  497 	movx	@dptr,a
      0050E9 EF               [12]  498 	mov	a,r7
      0050EA A3               [24]  499 	inc	dptr
      0050EB F0               [24]  500 	movx	@dptr,a
      0050EC 90 05 9D         [24]  501 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0050EF 22               [24]  502 	ret
                                    503 
                                    504 	.area CSEG (CODE)
                                    505 ; function ak820_outline_0003
      0050F0                        506 _ak820_outline_0003:
      0050F0 E0               [24]  507 	movx	a,@dptr
      0050F1 FD               [12]  508 	mov	r5,a
      0050F2 A3               [24]  509 	inc	dptr
      0050F3 E0               [24]  510 	movx	a,@dptr
      0050F4 FE               [12]  511 	mov	r6,a
      0050F5 A3               [24]  512 	inc	dptr
      0050F6 E0               [24]  513 	movx	a,@dptr
      0050F7 FF               [12]  514 	mov	r7,a
      0050F8 8D 82            [24]  515 	mov	dpl,r5
      0050FA 8E 83            [24]  516 	mov	dph,r6
      0050FC 8F F0            [24]  517 	mov	b,r7
      0050FE 22               [24]  518 	ret
                                    519 
                                    520 	.area CSEG (CODE)
                                    521 ; function ak820_outline_0021
      0050FF                        522 _ak820_outline_0021:
      0050FF E0               [24]  523 	movx	a,@dptr
      005100 FD               [12]  524 	mov	r5,a
      005101 A3               [24]  525 	inc	dptr
      005102 E0               [24]  526 	movx	a,@dptr
      005103 FE               [12]  527 	mov	r6,a
      005104 A3               [24]  528 	inc	dptr
      005105 E0               [24]  529 	movx	a,@dptr
      005106 FF               [12]  530 	mov	r7,a
      005107 22               [24]  531 	ret
                                    532 
                                    533 	.area CSEG (CODE)
                                    534 ; function ak820_outline_0043
      005108                        535 _ak820_outline_0043:
      005108 8D 82            [24]  536 	mov	dpl,r5
      00510A 8E 83            [24]  537 	mov	dph,r6
      00510C 8F F0            [24]  538 	mov	b,r7
      00510E 22               [24]  539 	ret
                                    540 
                                    541 	.area CSEG (CODE)
                                    542 ; function ak820_outline_0048
      00510F                        543 _ak820_outline_0048:
      00510F E4               [12]  544 	clr	a
      005110 F0               [24]  545 	movx	@dptr,a
      005111 A3               [24]  546 	inc	dptr
      005112 F0               [24]  547 	movx	@dptr,a
      005113 A3               [24]  548 	inc	dptr
      005114 F0               [24]  549 	movx	@dptr,a
      005115 A3               [24]  550 	inc	dptr
      005116 F0               [24]  551 	movx	@dptr,a
      005117 22               [24]  552 	ret
                                    553 
                                    554 	.area CSEG (CODE)
                                    555 ; function ak820_outline_0053
      005118                        556 _ak820_outline_0053:
      005118 E0               [24]  557 	movx	a,@dptr
      005119 FC               [12]  558 	mov	r4,a
      00511A A3               [24]  559 	inc	dptr
      00511B E0               [24]  560 	movx	a,@dptr
      00511C FD               [12]  561 	mov	r5,a
      00511D A3               [24]  562 	inc	dptr
      00511E E0               [24]  563 	movx	a,@dptr
      00511F FE               [12]  564 	mov	r6,a
      005120 A3               [24]  565 	inc	dptr
      005121 E0               [24]  566 	movx	a,@dptr
      005122 8C 82            [24]  567 	mov	dpl,r4
      005124 8D 83            [24]  568 	mov	dph,r5
      005126 8E F0            [24]  569 	mov	b,r6
      005128 22               [24]  570 	ret
                                    571 
                                    572 	.area CSEG (CODE)
                                    573 ; function ak820_outline_0056
      005129                        574 _ak820_outline_0056:
      005129 AC 82            [24]  575 	mov	r4,dpl
      00512B AD 83            [24]  576 	mov	r5,dph
      00512D AE F0            [24]  577 	mov	r6,b
      00512F FF               [12]  578 	mov	r7,a
      005130 22               [24]  579 	ret
                                    580 
                                    581 	.area CSEG (CODE)
                                    582 ; function ak820_outline_0087
      005131                        583 _ak820_outline_0087:
      005131 E0               [24]  584 	movx	a,@dptr
      005132 F9               [12]  585 	mov	r1,a
      005133 A3               [24]  586 	inc	dptr
      005134 E0               [24]  587 	movx	a,@dptr
      005135 FA               [12]  588 	mov	r2,a
      005136 A3               [24]  589 	inc	dptr
      005137 E0               [24]  590 	movx	a,@dptr
      005138 FB               [12]  591 	mov	r3,a
      005139 22               [24]  592 	ret
                                    593 
                                    594 	.area CSEG (CODE)
                                    595 ; function ak820_outline_0088
      00513A                        596 _ak820_outline_0088:
      00513A E0               [24]  597 	movx	a,@dptr
      00513B FE               [12]  598 	mov	r6,a
      00513C A3               [24]  599 	inc	dptr
      00513D E0               [24]  600 	movx	a,@dptr
      00513E 8E 82            [24]  601 	mov	dpl,r6
      005140 F5 83            [12]  602 	mov	dph,a
      005142 22               [24]  603 	ret
                                    604 
                                    605 	.area CSEG (CODE)
                                    606 ; function ak820_outline_0106
      005143                        607 _ak820_outline_0106:
      005143 74 02            [12]  608 	mov	a,#0x02
      005145 F0               [24]  609 	movx	@dptr,a
      005146 E4               [12]  610 	clr	a
      005147 A3               [24]  611 	inc	dptr
      005148 F0               [24]  612 	movx	@dptr,a
      005149 22               [24]  613 	ret
                                    614 
                                    615 	.area CSEG (CODE)
                                    616 ; function ak820_outline_0153
      00514A                        617 _ak820_outline_0153:
      00514A F0               [24]  618 	movx	@dptr,a
      00514B EA               [12]  619 	mov	a,r2
      00514C A3               [24]  620 	inc	dptr
      00514D F0               [24]  621 	movx	@dptr,a
      00514E EB               [12]  622 	mov	a,r3
      00514F A3               [24]  623 	inc	dptr
      005150 22               [24]  624 	ret
                                    625 
                                    626 	.area CSEG (CODE)
                                    627 ; function ak820_outline_0165
      005151                        628 _ak820_outline_0165:
      005151 E4               [12]  629 	clr	a
      005152 F0               [24]  630 	movx	@dptr,a
      005153 A3               [24]  631 	inc	dptr
      005154 F0               [24]  632 	movx	@dptr,a
      005155 22               [24]  633 	ret
