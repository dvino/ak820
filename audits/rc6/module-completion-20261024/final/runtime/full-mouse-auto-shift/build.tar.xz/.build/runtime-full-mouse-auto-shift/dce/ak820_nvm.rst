                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000008                         91 _page_valid:
      000008                         92 	.ds 1
      000009                         93 _page_dirty:
      000009                         94 	.ds 1
      00000A                         95 _storage_failed:
      00000A                         96 	.ds 1
      00000B                         97 _ak820_nvm_ok_sloc0_1_0:
      00000B                         98 	.ds 1
      00000C                         99 _load_page_sloc0_1_0:
      00000C                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000529                        109 _page_data:
      000529                        110 	.ds 64
      000569                        111 _cached_page:
      000569                        112 	.ds 1
      00056A                        113 _batch_depth:
      00056A                        114 	.ds 1
      00056B                        115 _first_failure_stage:
      00056B                        116 	.ds 1
      00056C                        117 _nvm_fail_stage_10000_20:
      00056C                        118 	.ds 1
      00056D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00056D                        120 	.ds 2
      00056F                        121 _crc_byte_PARM_2:
      00056F                        122 	.ds 1
      000570                        123 _crc_byte_crc_10000_25:
      000570                        124 	.ds 2
      000572                        125 _page_crc_crc_10000_30:
      000572                        126 	.ds 2
      000574                        127 _write_page_address_10000_32:
      000574                        128 	.ds 2
      000576                        129 _journal_header_valid_header_10000_39:
      000576                        130 	.ds 2
      000578                        131 _recover_journal_header_10000_46:
      000578                        132 	.ds 9
      000581                        133 _ak820_nvm_flush_header_10000_62:
      000581                        134 	.ds 9
      00058A                        135 _ak820_nvm_flush_stage_10000_62:
      00058A                        136 	.ds 1
      00058B                        137 _load_page_page_10000_87:
      00058B                        138 	.ds 1
      00058C                        139 _read_offset_offset_10000_93:
      00058C                        140 	.ds 2
      00058E                        141 _eeprom_read_byte_addr_10000_97:
      00058E                        142 	.ds 3
      000591                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000591                        144 	.ds 3
      000594                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000594                        146 	.ds 2
      000596                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000596                        148 	.ds 2
      000598                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000598                        150 	.ds 2
      00059A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00059A                        152 	.ds 3
      00059D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00059D                        154 	.ds 2
      00059F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00059F                        156 	.ds 2
      0005A1                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005A1                        158 	.ds 3
      0005A4                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005A4                        160 	.ds 2
      0005A6                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005A6                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003D8E                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003D8E E5 82            [12]  215 	mov	a,dpl
      003D90 90 05 6C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003D93 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003D94 20 0A 08         [24]  219 	jb	_storage_failed,00102$
      003D97 90 05 6C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003D9A E0               [24]  221 	movx	a,@dptr
      003D9B 90 05 6B         [24]  222 	mov	dptr,#_first_failure_stage
      003D9E F0               [24]  223 	movx	@dptr,a
      003D9F                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003D9F D2 0A            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003DA1 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003DA2                        239 _ak820_nvm_diagnostic:
      003DA2 12 3A 8A         [24]  240 	lcall	_ak820_outline_0103
      003DA5 90 05 6D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003DA8 12 3A 8F         [24]  242 	lcall	_ak820_outline_0104
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003DAB 90 05 6D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003DAE 12 3A 47         [24]  245 	lcall	_ak820_outline_0050
      003DB1 A2 0A            [12]  246 	mov	c,_storage_failed
      003DB3 E4               [12]  247 	clr	a
      003DB4 33               [12]  248 	rlc	a
      003DB5 12 45 66         [24]  249 	lcall	_ak820_outline_0116
      003DB8 12 45 41         [24]  250 	lcall	_ak820_outline_0060
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003DBB A3               [24]  252 	inc	dptr
      003DBC A2 08            [12]  253 	mov	c,_page_valid
      003DBE E4               [12]  254 	clr	a
      003DBF 33               [12]  255 	rlc	a
      003DC0 12 45 15         [24]  256 	lcall	_ak820_outline_0029
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003DC3 A2 09            [12]  258 	mov	c,_page_dirty
      003DC5 E4               [12]  259 	clr	a
      003DC6 33               [12]  260 	rlc	a
      003DC7 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003DC8 74 03            [12]  263 	mov	a,#0x03
      003DCA 12 45 91         [24]  264 	lcall	_ak820_outline_0157
      003DCD 90 05 6A         [24]  265 	mov	dptr,#_batch_depth
      003DD0 E0               [24]  266 	movx	a,@dptr
      003DD1 12 3A 9B         [24]  267 	lcall	_ak820_outline_0117
      003DD4 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003DD5 74 04            [12]  270 	mov	a,#0x04
      003DD7 12 45 91         [24]  271 	lcall	_ak820_outline_0157
      003DDA 90 05 69         [24]  272 	mov	dptr,#_cached_page
      003DDD E0               [24]  273 	movx	a,@dptr
      003DDE 12 3A 9B         [24]  274 	lcall	_ak820_outline_0117
      003DE1 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003DE2 12 45 0B         [24]  277 	lcall	_ak820_outline_0010
      003DE5 E4               [12]  278 	clr	a
      003DE6 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003DE7 74 06            [12]  281 	mov	a,#0x06
      003DE9 12 45 76         [24]  282 	lcall	_ak820_outline_0133
      003DEC 90 05 6B         [24]  283 	mov	dptr,#_first_failure_stage
      003DEF E0               [24]  284 	movx	a,@dptr
      003DF0 12 45 66         [24]  285 	lcall	_ak820_outline_0116
      003DF3 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003DF4 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003DF5                        300 _crc_byte:
      003DF5 12 3A 8A         [24]  301 	lcall	_ak820_outline_0103
      003DF8 90 05 70         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003DFB 12 3A 8F         [24]  303 	lcall	_ak820_outline_0104
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003DFE 90 05 6F         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003E01 E0               [24]  306 	movx	a,@dptr
      003E02 FF               [12]  307 	mov	r7,a
      003E03 7E 00            [12]  308 	mov	r6,#0x00
      003E05 90 05 70         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003E08 E0               [24]  310 	movx	a,@dptr
      003E09 6E               [12]  311 	xrl	a,r6
      003E0A F0               [24]  312 	movx	@dptr,a
      003E0B A3               [24]  313 	inc	dptr
      003E0C E0               [24]  314 	movx	a,@dptr
      003E0D 6F               [12]  315 	xrl	a,r7
      003E0E F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E0F 7F 00            [12]  318 	mov	r7,#0x00
      003E11                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003E11 90 05 70         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003E14 12 45 54         [24]  322 	lcall	_ak820_outline_0092
      003E17 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003E1A ED               [12]  324 	mov	a,r5
      003E1B 2D               [12]  325 	add	a,r5
      003E1C FB               [12]  326 	mov	r3,a
      003E1D EE               [12]  327 	mov	a,r6
      003E1E 33               [12]  328 	rlc	a
      003E1F FC               [12]  329 	mov	r4,a
      003E20 63 03 21         [24]  330 	xrl	ar3,#0x21
      003E23 63 04 10         [24]  331 	xrl	ar4,#0x10
      003E26 80 06            [24]  332 	sjmp	00107$
      003E28                        333 00106$:
      003E28 ED               [12]  334 	mov	a,r5
      003E29 2D               [12]  335 	add	a,r5
      003E2A FB               [12]  336 	mov	r3,a
      003E2B EE               [12]  337 	mov	a,r6
      003E2C 33               [12]  338 	rlc	a
      003E2D FC               [12]  339 	mov	r4,a
      003E2E                        340 00107$:
      003E2E 90 05 70         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003E31 12 3A 72         [24]  342 	lcall	_ak820_outline_0076
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E34 0F               [12]  344 	inc	r7
      003E35 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003E38 12 36 42         [24]  347 	lcall	_ak820_outline_0121
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003E3B 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003E3C                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003E3C 90 05 72         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003E3F 74 FF            [12]  363 	mov	a,#0xff
      003E41 F0               [24]  364 	movx	@dptr,a
      003E42 A3               [24]  365 	inc	dptr
      003E43 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003E44 7F 00            [12]  368 	mov	r7,#0x00
      003E46                        369 00102$:
      003E46 90 05 72         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003E49 12 45 54         [24]  371 	lcall	_ak820_outline_0092
      003E4C 12 45 5A         [24]  372 	lcall	_ak820_outline_0101
      003E4F 90 05 6F         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003E52 F0               [24]  374 	movx	@dptr,a
      003E53 12 3A AB         [24]  375 	lcall	_ak820_outline_0131
      003E56 C0 07            [24]  376 	push	ar7
      003E58 12 3D F5         [24]  377 	lcall	_crc_byte
      003E5B AD 82            [24]  378 	mov	r5, dpl
      003E5D AE 83            [24]  379 	mov	r6, dph
      003E5F D0 07            [24]  380 	pop	ar7
      003E61 90 05 72         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003E64 12 45 97         [24]  382 	lcall	_ak820_outline_0158
      003E67 0F               [12]  383 	inc	r7
      003E68 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003E6B 12 3A AB         [24]  386 	lcall	_ak820_outline_0131
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003E6E 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003E6F                        399 _write_page:
      003E6F 12 3A 8A         [24]  400 	lcall	_ak820_outline_0103
      003E72 90 05 74         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003E75 12 3A 8F         [24]  402 	lcall	_ak820_outline_0104
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003E78 90 05 74         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003E7B 12 39 E7         [24]  405 	lcall	_ak820_outline_0004
      003E7E C0 07            [24]  406 	push	ar7
      003E80 C0 06            [24]  407 	push	ar6
      003E82 12 3C 07         [24]  408 	lcall	_ak820_flash_erase
      003E85 E5 82            [12]  409 	mov	a, dpl
      003E87 D0 06            [24]  410 	pop	ar6
      003E89 D0 07            [24]  411 	pop	ar7
      003E8B 70 03            [24]  412 	jnz	00102$
      003E8D F5 82            [12]  413 	mov	dpl,a
      003E8F 22               [24]  414 	ret
      003E90                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003E90 90 05 05         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003E93 74 29            [12]  418 	mov	a,#_page_data
      003E95 F0               [24]  419 	movx	@dptr,a
      003E96 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003E98 A3               [24]  421 	inc	dptr
      003E99 12 45 41         [24]  422 	lcall	_ak820_outline_0060
      003E9C 12 3D 1B         [24]  423 	lcall	_ak820_flash_program_page
      003E9F E5 82            [12]  424 	mov	a, dpl
      003EA1 70 03            [24]  425 	jnz	00120$
      003EA3 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EA5 22               [24]  428 	ret
      003EA6                        429 00120$:
      003EA6 7F 00            [12]  430 	mov	r7,#0x00
      003EA8                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003EA8 8F 05            [24]  433 	mov	ar5,r7
      003EAA 7E 00            [12]  434 	mov	r6,#0x00
      003EAC 90 05 74         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003EAF 12 3A A0         [24]  436 	lcall	_ak820_outline_0120
      003EB2 ED               [12]  437 	mov	a,r5
      003EB3 2B               [12]  438 	add	a, r3
      003EB4 FB               [12]  439 	mov	r3,a
      003EB5 EE               [12]  440 	mov	a,r6
      003EB6 3C               [12]  441 	addc	a, r4
      003EB7 FC               [12]  442 	mov	r4,a
      003EB8 12 36 42         [24]  443 	lcall	_ak820_outline_0121
      003EBB 12 3A FA         [24]  444 	lcall	_ak820_flash_read
      003EBE AE 82            [24]  445 	mov	r6, dpl
      003EC0 12 45 5A         [24]  446 	lcall	_ak820_outline_0101
      003EC3 FD               [12]  447 	mov	r5,a
      003EC4 EE               [12]  448 	mov	a,r6
      003EC5 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003EC8 80 04            [24]  450 	sjmp	00109$
      003ECA                        451 00149$:
      003ECA 75 82 00         [24]  452 	mov	dpl, #0x00
      003ECD 22               [24]  453 	ret
      003ECE                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003ECE 0F               [12]  456 	inc	r7
      003ECF BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003ED2 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003ED5 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003ED6                        472 _journal_header_valid:
      003ED6 12 3A 8A         [24]  473 	lcall	_ak820_outline_0103
      003ED9 90 05 76         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003EDC 12 3A 8F         [24]  475 	lcall	_ak820_outline_0104
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003EDF 90 05 76         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003EE2 12 39 E7         [24]  478 	lcall	_ak820_outline_0004
      003EE5 E0               [24]  479 	movx	a,@dptr
      003EE6 FD               [12]  480 	mov	r5,a
      003EE7 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003EEA 80 04            [24]  482 	sjmp	00116$
      003EEC                        483 00138$:
      003EEC 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003EEF 22               [24]  486 	ret
      003EF0                        487 00116$:
      003EF0 7D 01            [12]  488 	mov	r5,#0x01
      003EF2                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003EF2 ED               [12]  491 	mov	a,r5
      003EF3 12 3A 2E         [24]  492 	lcall	_ak820_outline_0016
      003EF6 FC               [12]  493 	mov	r4,a
      003EF7 8D 02            [24]  494 	mov	ar2,r5
      003EF9 7B 00            [12]  495 	mov	r3,#0x00
      003EFB 74 04            [12]  496 	mov	a,#0x04
      003EFD 2A               [12]  497 	add	a, r2
      003EFE FA               [12]  498 	mov	r2,a
      003EFF E4               [12]  499 	clr	a
      003F00 3B               [12]  500 	addc	a, r3
      003F01 FB               [12]  501 	mov	r3,a
      003F02 EA               [12]  502 	mov	a,r2
      003F03 2E               [12]  503 	add	a, r6
      003F04 F5 82            [12]  504 	mov	dpl,a
      003F06 EB               [12]  505 	mov	a,r3
      003F07 3F               [12]  506 	addc	a, r7
      003F08 F5 83            [12]  507 	mov	dph,a
      003F0A E0               [24]  508 	movx	a,@dptr
      003F0B 62 04            [12]  509 	xrl	ar4,a
      003F0D BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      003F10 80 04            [24]  511 	sjmp	00107$
      003F12                        512 00139$:
      003F12 75 82 00         [24]  513 	mov	dpl, #0x00
      003F15 22               [24]  514 	ret
      003F16                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F16 0D               [12]  517 	inc	r5
      003F17 BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003F1A 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003F1D 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      003F1E                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003F1E 7F 00            [12]  537 	mov	r7,#0x00
      003F20                        538 00115$:
      003F20 EF               [12]  539 	mov	a,r7
      003F21 24 78            [12]  540 	add	a, #_recover_journal_header_10000_46
      003F23 FD               [12]  541 	mov	r5,a
      003F24 E4               [12]  542 	clr	a
      003F25 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003F27 FE               [12]  544 	mov	r6,a
      003F28 8F 04            [24]  545 	mov	ar4,r7
      003F2A 7B 00            [12]  546 	mov	r3,#0x00
      003F2C 74 40            [12]  547 	mov	a,#0x40
      003F2E 2C               [12]  548 	add	a, r4
      003F2F FC               [12]  549 	mov	r4,a
      003F30 74 EF            [12]  550 	mov	a,#0xef
      003F32 3B               [12]  551 	addc	a, r3
      003F33 FB               [12]  552 	mov	r3,a
      003F34 12 45 A2         [24]  553 	lcall	_ak820_outline_0179
      003F37 12 3A FA         [24]  554 	lcall	_ak820_flash_read
      003F3A AC 82            [24]  555 	mov	r4, dpl
      003F3C 12 45 47         [24]  556 	lcall	_ak820_outline_0064
      003F3F 0F               [12]  557 	inc	r7
      003F40 BF 09 DD         [24]  558 	cjne	r7,#0x09,00115$
                                    559 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003F43 90 05 78         [24]  560 	mov	dptr,#_recover_journal_header_10000_46
      003F46 12 3E D6         [24]  561 	lcall	_journal_header_valid
      003F49 E5 82            [12]  562 	mov	a, dpl
      003F4B 70 01            [24]  563 	jnz	00103$
      003F4D 22               [24]  564 	ret
      003F4E                        565 00103$:
                                    566 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003F4E 90 05 79         [24]  567 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003F51 E0               [24]  568 	movx	a,@dptr
      003F52 FF               [12]  569 	mov	r7,a
      003F53 7E 00            [12]  570 	mov	r6,#0x00
      003F55 90 05 7A         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003F58 E0               [24]  572 	movx	a,@dptr
      003F59 FC               [12]  573 	mov	r4,a
      003F5A E4               [12]  574 	clr	a
      003F5B 42 07            [12]  575 	orl	ar7,a
      003F5D EC               [12]  576 	mov	a,r4
      003F5E 42 06            [12]  577 	orl	ar6,a
                                    578 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003F60 90 05 7B         [24]  579 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003F63 E0               [24]  580 	movx	a,@dptr
      003F64 FD               [12]  581 	mov	r5,a
      003F65 7C 00            [12]  582 	mov	r4,#0x00
      003F67 90 05 7C         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003F6A E0               [24]  584 	movx	a,@dptr
      003F6B FA               [12]  585 	mov	r2,a
      003F6C E4               [12]  586 	clr	a
      003F6D 12 45 7C         [24]  587 	lcall	_ak820_outline_0140
                                    588 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003F70 C3               [12]  589 	clr	c
      003F71 EF               [12]  590 	mov	a,r7
      003F72 94 A0            [12]  591 	subb	a,#0xa0
      003F74 EE               [12]  592 	mov	a,r6
      003F75 94 00            [12]  593 	subb	a,#0x00
      003F77 40 06            [24]  594 	jc	00134$
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003F79 75 82 01         [24]  596 	mov	dpl, #0x01
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003F7C 02 3D 8E         [24]  598 	ljmp	_nvm_fail
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003F7F                        600 00134$:
      003F7F 7B 00            [12]  601 	mov	r3,#0x00
      003F81                        602 00117$:
      003F81 C0 05            [24]  603 	push	ar5
      003F83 C0 04            [24]  604 	push	ar4
      003F85 EB               [12]  605 	mov	a,r3
      003F86 24 29            [12]  606 	add	a, #_page_data
      003F88 F9               [12]  607 	mov	r1,a
      003F89 E4               [12]  608 	clr	a
      003F8A 34 05            [12]  609 	addc	a, #(_page_data >> 8)
      003F8C FA               [12]  610 	mov	r2,a
      003F8D 8B 00            [24]  611 	mov	ar0,r3
      003F8F 7D 00            [12]  612 	mov	r5,#0x00
      003F91 74 EF            [12]  613 	mov	a,#0xef
      003F93 2D               [12]  614 	add	a, r5
      003F94 FD               [12]  615 	mov	r5,a
      003F95 88 82            [24]  616 	mov	dpl, r0
      003F97 8D 83            [24]  617 	mov	dph, r5
      003F99 12 3A FA         [24]  618 	lcall	_ak820_flash_read
      003F9C AD 82            [24]  619 	mov	r5, dpl
      003F9E 12 45 9D         [24]  620 	lcall	_ak820_outline_0178
      003FA1 ED               [12]  621 	mov	a,r5
      003FA2 F0               [24]  622 	movx	@dptr,a
      003FA3 0B               [12]  623 	inc	r3
      003FA4 BB 40 02         [24]  624 	cjne	r3,#0x40,00190$
      003FA7 80 06            [24]  625 	sjmp	00191$
      003FA9                        626 00190$:
      003FA9 D0 04            [24]  627 	pop	ar4
      003FAB D0 05            [24]  628 	pop	ar5
      003FAD 80 D2            [24]  629 	sjmp	00117$
      003FAF                        630 00191$:
      003FAF D0 04            [24]  631 	pop	ar4
      003FB1 D0 05            [24]  632 	pop	ar5
                                    633 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003FB3 C0 07            [24]  634 	push	ar7
      003FB5 C0 06            [24]  635 	push	ar6
      003FB7 C0 05            [24]  636 	push	ar5
      003FB9 C0 04            [24]  637 	push	ar4
      003FBB 12 3E 3C         [24]  638 	lcall	_page_crc
      003FBE AA 82            [24]  639 	mov	r2, dpl
      003FC0 AB 83            [24]  640 	mov	r3, dph
      003FC2 D0 04            [24]  641 	pop	ar4
      003FC4 D0 05            [24]  642 	pop	ar5
      003FC6 D0 06            [24]  643 	pop	ar6
      003FC8 D0 07            [24]  644 	pop	ar7
      003FCA EA               [12]  645 	mov	a,r2
      003FCB B5 05 06         [24]  646 	cjne	a,ar5,00192$
      003FCE EB               [12]  647 	mov	a,r3
      003FCF B5 04 02         [24]  648 	cjne	a,ar4,00192$
      003FD2 80 06            [24]  649 	sjmp	00113$
      003FD4                        650 00192$:
      003FD4 75 82 02         [24]  651 	mov	dpl, #0x02
      003FD7 02 3D 8E         [24]  652 	ljmp	_nvm_fail
      003FDA                        653 00113$:
                                    654 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003FDA EE               [12]  655 	mov	a,r6
      003FDB 54 03            [12]  656 	anl	a,#0x03
      003FDD A2 E0            [12]  657 	mov	c,acc.0
      003FDF CF               [12]  658 	xch	a,r7
      003FE0 13               [12]  659 	rrc	a
      003FE1 CF               [12]  660 	xch	a,r7
      003FE2 13               [12]  661 	rrc	a
      003FE3 A2 E0            [12]  662 	mov	c,acc.0
      003FE5 CF               [12]  663 	xch	a,r7
      003FE6 13               [12]  664 	rrc	a
      003FE7 CF               [12]  665 	xch	a,r7
      003FE8 13               [12]  666 	rrc	a
      003FE9 CF               [12]  667 	xch	a,r7
      003FEA 24 C7            [12]  668 	add	a,#0xc7
      003FEC FE               [12]  669 	mov	r6,a
      003FED 12 45 8C         [24]  670 	lcall	_ak820_outline_0155
      003FF0 12 3E 6F         [24]  671 	lcall	_write_page
      003FF3 E5 82            [12]  672 	mov	a, dpl
      003FF5 70 06            [24]  673 	jnz	00110$
      003FF7 75 82 03         [24]  674 	mov	dpl, #0x03
      003FFA 02 3D 8E         [24]  675 	ljmp	_nvm_fail
      003FFD                        676 00110$:
                                    677 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003FFD 90 EF 40         [24]  678 	mov	dptr,#0xef40
      004000 12 3C 07         [24]  679 	lcall	_ak820_flash_erase
      004003 E5 82            [12]  680 	mov	a, dpl
      004005 70 06            [24]  681 	jnz	00119$
      004007 75 82 04         [24]  682 	mov	dpl, #0x04
                                    683 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      00400A 02 3D 8E         [24]  684 	ljmp	_nvm_fail
      00400D                        685 00119$:
      00400D 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    689 ;------------------------------------------------------------
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    691 ;	-----------------------------------------
                                    692 ;	 function eeprom_driver_init
                                    693 ;	-----------------------------------------
      00400E                        694 _eeprom_driver_init:
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    696 ;	assignBit
      00400E C2 0A            [12]  697 	clr	_storage_failed
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      004010 90 05 6B         [24]  699 	mov	dptr,#_first_failure_stage
      004013 E4               [12]  700 	clr	a
      004014 F0               [24]  701 	movx	@dptr,a
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    703 ;	assignBit
      004015 C2 09            [12]  704 	clr	_page_dirty
                                    705 ;	assignBit
      004017 C2 08            [12]  706 	clr	_page_valid
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      004019 90 05 6A         [24]  708 	mov	dptr,#_batch_depth
      00401C E4               [12]  709 	clr	a
      00401D F0               [24]  710 	movx	@dptr,a
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      00401E 12 3F 1E         [24]  712 	lcall	_recover_journal
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      004021 02 2A B7         [24]  715 	ljmp	_ak820_macro_init
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_nvm_ok
                                    722 ;	-----------------------------------------
      004024                        723 _ak820_nvm_ok:
      004024 A2 0A            [12]  724 	mov	c,_storage_failed
      004026 B3               [12]  725 	cpl	c
      004027 92 0B            [24]  726 	mov  _ak820_nvm_ok_sloc0_1_0,c
      004029 12 3A C7         [24]  727 	lcall	_ak820_outline_0166
      00402C 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    731 ;------------------------------------------------------------
                                    732 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    733 ;	-----------------------------------------
                                    734 ;	 function ak820_nvm_schema_fault
                                    735 ;	-----------------------------------------
      00402D                        736 _ak820_nvm_schema_fault:
      00402D 75 82 10         [24]  737 	mov	dpl, #0x10
      004030 02 3D 8E         [24]  738 	ljmp	_nvm_fail
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    741 ;------------------------------------------------------------
                                    742 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    743 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    744 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    745 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_flush
                                    750 ;	-----------------------------------------
      004033                        751 _ak820_nvm_flush:
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      004033 30 09 03         [24]  753 	jnb	_page_dirty,00101$
      004036 30 0A 01         [24]  754 	jnb	_storage_failed,00102$
      004039                        755 00101$:
      004039 22               [24]  756 	ret
      00403A                        757 00102$:
                                    758 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      00403A 12 3E 3C         [24]  759 	lcall	_page_crc
      00403D 12 45 71         [24]  760 	lcall	_ak820_outline_0130
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      004040 90 05 81         [24]  762 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004043 74 A5            [12]  763 	mov	a,#0xa5
      004045 F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      004046 90 05 69         [24]  766 	mov	dptr,#_cached_page
      004049 E0               [24]  767 	movx	a,@dptr
      00404A 90 05 82         [24]  768 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      00404D F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      00404E 90 05 83         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      004051 E4               [12]  772 	clr	a
      004052 F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      004053 8E 05            [24]  775 	mov	ar5,r6
      004055 90 05 84         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      004058 ED               [12]  777 	mov	a,r5
      004059 F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      00405A 8F 06            [24]  780 	mov	ar6,r7
      00405C 90 05 85         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      00405F EE               [12]  782 	mov	a,r6
      004060 F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      004061 7F 01            [12]  785 	mov	r7,#0x01
      004063                        786 00128$:
      004063 8F 06            [24]  787 	mov	ar6,r7
      004065 EE               [12]  788 	mov	a,r6
      004066 24 04            [12]  789 	add	a,#0x04
      004068 FE               [12]  790 	mov	r6,a
      004069 33               [12]  791 	rlc	a
      00406A 95 E0            [12]  792 	subb	a,acc
      00406C FD               [12]  793 	mov	r5,a
      00406D EE               [12]  794 	mov	a,r6
      00406E 24 81            [12]  795 	add	a, #_ak820_nvm_flush_header_10000_62
      004070 FE               [12]  796 	mov	r6,a
      004071 ED               [12]  797 	mov	a,r5
      004072 34 05            [12]  798 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      004074 FD               [12]  799 	mov	r5,a
      004075 12 45 24         [24]  800 	lcall	_ak820_outline_0039
      004078 FC               [12]  801 	mov	r4,a
      004079 63 04 FF         [24]  802 	xrl	ar4,#0xff
      00407C 8E 82            [24]  803 	mov	dpl,r6
      00407E 8D 83            [24]  804 	mov	dph,r5
      004080 EC               [12]  805 	mov	a,r4
      004081 F0               [24]  806 	movx	@dptr,a
      004082 0F               [12]  807 	inc	r7
      004083 BF 05 DD         [24]  808 	cjne	r7,#0x05,00128$
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      004086 90 05 8A         [24]  810 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004089 74 05            [12]  811 	mov	a,#0x05
      00408B F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      00408C 90 EF 40         [24]  814 	mov	dptr,#0xef40
      00408F 12 3C 07         [24]  815 	lcall	_ak820_flash_erase
      004092 E5 82            [12]  816 	mov	a, dpl
      004094 70 03            [24]  817 	jnz	00269$
      004096 02 41 7D         [24]  818 	ljmp	00127$
      004099                        819 00269$:
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      004099 90 05 8A         [24]  821 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00409C 74 06            [12]  822 	mov	a,#0x06
      00409E F0               [24]  823 	movx	@dptr,a
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00409F 7F 00            [12]  825 	mov	r7,#0x00
      0040A1                        826 00130$:
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      0040A1 12 45 30         [24]  828 	lcall	_ak820_outline_0051
      0040A4 12 3A FA         [24]  829 	lcall	_ak820_flash_read
      0040A7 E5 82            [12]  830 	mov	a, dpl
      0040A9 60 03            [24]  831 	jz	00270$
      0040AB 02 41 7D         [24]  832 	ljmp	00127$
      0040AE                        833 00270$:
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0040AE 0F               [12]  835 	inc	r7
      0040AF BF 40 EF         [24]  836 	cjne	r7,#0x40,00130$
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      0040B2 90 05 8A         [24]  838 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040B5 74 07            [12]  839 	mov	a,#0x07
      0040B7 F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      0040B8 90 EF 00         [24]  842 	mov	dptr,#0xef00
      0040BB 12 3E 6F         [24]  843 	lcall	_write_page
      0040BE E5 82            [12]  844 	mov	a, dpl
      0040C0 70 03            [24]  845 	jnz	00273$
      0040C2 02 41 7D         [24]  846 	ljmp	00127$
      0040C5                        847 00273$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      0040C5 90 05 8A         [24]  849 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040C8 74 08            [12]  850 	mov	a,#0x08
      0040CA F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0040CB 7F 01            [12]  853 	mov	r7,#0x01
      0040CD                        854 00132$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      0040CD 12 45 24         [24]  856 	lcall	_ak820_outline_0039
      0040D0 FE               [12]  857 	mov	r6,a
      0040D1 60 23            [24]  858 	jz	00133$
      0040D3 8F 05            [24]  859 	mov	ar5,r7
      0040D5 7C 00            [12]  860 	mov	r4,#0x00
      0040D7 74 40            [12]  861 	mov	a,#0x40
      0040D9 2D               [12]  862 	add	a, r5
      0040DA FD               [12]  863 	mov	r5,a
      0040DB 74 EF            [12]  864 	mov	a,#0xef
      0040DD 3C               [12]  865 	addc	a, r4
      0040DE FC               [12]  866 	mov	r4,a
      0040DF 90 05 02         [24]  867 	mov	dptr,#_ak820_flash_program_PARM_2
      0040E2 EE               [12]  868 	mov	a,r6
      0040E3 F0               [24]  869 	movx	@dptr,a
      0040E4 8D 82            [24]  870 	mov	dpl, r5
      0040E6 8C 83            [24]  871 	mov	dph, r4
      0040E8 C0 07            [24]  872 	push	ar7
      0040EA 12 3C 67         [24]  873 	lcall	_ak820_flash_program
      0040ED E5 82            [12]  874 	mov	a, dpl
      0040EF D0 07            [24]  875 	pop	ar7
      0040F1 70 03            [24]  876 	jnz	00275$
      0040F3 02 41 7D         [24]  877 	ljmp	00127$
      0040F6                        878 00275$:
      0040F6                        879 00133$:
                                    880 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0040F6 0F               [12]  881 	inc	r7
      0040F7 BF 09 D3         [24]  882 	cjne	r7,#0x09,00132$
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      0040FA 90 05 8A         [24]  884 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040FD 74 09            [12]  885 	mov	a,#0x09
      0040FF F0               [24]  886 	movx	@dptr,a
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004100 7F 01            [12]  888 	mov	r7,#0x01
      004102                        889 00134$:
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      004102 12 45 30         [24]  891 	lcall	_ak820_outline_0051
      004105 12 3A FA         [24]  892 	lcall	_ak820_flash_read
      004108 AE 82            [24]  893 	mov	r6, dpl
      00410A 12 45 24         [24]  894 	lcall	_ak820_outline_0039
      00410D FD               [12]  895 	mov	r5,a
      00410E EE               [12]  896 	mov	a,r6
      00410F B5 05 6B         [24]  897 	cjne	a,ar5,00127$
                                    898 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004112 0F               [12]  899 	inc	r7
      004113 BF 09 EC         [24]  900 	cjne	r7,#0x09,00134$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      004116 90 05 8A         [24]  902 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004119 74 0A            [12]  903 	mov	a,#0x0a
      00411B F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      00411C 90 05 81         [24]  906 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      00411F E0               [24]  907 	movx	a,@dptr
      004120 90 05 02         [24]  908 	mov	dptr,#_ak820_flash_program_PARM_2
      004123 F0               [24]  909 	movx	@dptr,a
      004124 90 EF 40         [24]  910 	mov	dptr,#0xef40
      004127 12 3C 67         [24]  911 	lcall	_ak820_flash_program
      00412A E5 82            [12]  912 	mov	a, dpl
      00412C 60 4F            [24]  913 	jz	00127$
                                    914 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      00412E 90 05 8A         [24]  915 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004131 74 0B            [12]  916 	mov	a,#0x0b
      004133 F0               [24]  917 	movx	@dptr,a
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      004134 90 EF 40         [24]  919 	mov	dptr,#0xef40
      004137 12 3A FA         [24]  920 	lcall	_ak820_flash_read
      00413A AF 82            [24]  921 	mov	r7, dpl
      00413C 90 05 81         [24]  922 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      00413F E0               [24]  923 	movx	a,@dptr
      004140 FE               [12]  924 	mov	r6,a
      004141 EF               [12]  925 	mov	a,r7
      004142 B5 06 38         [24]  926 	cjne	a,ar6,00127$
                                    927 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      004145 90 05 8A         [24]  928 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004148 74 0C            [12]  929 	mov	a,#0x0c
      00414A F0               [24]  930 	movx	@dptr,a
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      00414B 90 05 69         [24]  932 	mov	dptr,#_cached_page
      00414E E0               [24]  933 	movx	a,@dptr
      00414F FE               [12]  934 	mov	r6,a
      004150 E4               [12]  935 	clr	a
      004151 C3               [12]  936 	clr	c
      004152 CE               [12]  937 	xch	a,r6
      004153 13               [12]  938 	rrc	a
      004154 CE               [12]  939 	xch	a,r6
      004155 13               [12]  940 	rrc	a
      004156 A2 E0            [12]  941 	mov	c,acc.0
      004158 CE               [12]  942 	xch	a,r6
      004159 13               [12]  943 	rrc	a
      00415A CE               [12]  944 	xch	a,r6
      00415B 13               [12]  945 	rrc	a
      00415C CE               [12]  946 	xch	a,r6
      00415D 24 C7            [12]  947 	add	a,#0xc7
      00415F FF               [12]  948 	mov	r7,a
      004160 12 45 66         [24]  949 	lcall	_ak820_outline_0116
      004163 12 3E 6F         [24]  950 	lcall	_write_page
      004166 E5 82            [12]  951 	mov	a, dpl
      004168 60 13            [24]  952 	jz	00127$
                                    953 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      00416A 90 05 8A         [24]  954 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00416D 74 0D            [12]  955 	mov	a,#0x0d
      00416F F0               [24]  956 	movx	@dptr,a
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      004170 90 EF 40         [24]  958 	mov	dptr,#0xef40
      004173 12 3C 07         [24]  959 	lcall	_ak820_flash_erase
      004176 E5 82            [12]  960 	mov	a, dpl
      004178 60 03            [24]  961 	jz	00127$
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    963 ;	assignBit
      00417A C2 09            [12]  964 	clr	_page_dirty
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      00417C 22               [24]  967 	ret
      00417D                        968 00127$:
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      00417D 90 05 8A         [24]  970 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004180 E0               [24]  971 	movx	a,@dptr
      004181 F5 82            [12]  972 	mov	dpl,a
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      004183 02 3D 8E         [24]  974 	ljmp	_nvm_fail
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    977 ;------------------------------------------------------------
                                    978 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function ak820_nvm_begin
                                    981 ;	-----------------------------------------
      004186                        982 _ak820_nvm_begin:
                                    983 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      004186 90 05 6A         [24]  984 	mov	dptr,#_batch_depth
      004189 E0               [24]  985 	movx	a,@dptr
      00418A FF               [12]  986 	mov	r7,a
      00418B BF FF 06         [24]  987 	cjne	r7,#0xff,00102$
      00418E 75 82 0F         [24]  988 	mov	dpl, #0x0f
      004191 02 3D 8E         [24]  989 	ljmp	_nvm_fail
      004194                        990 00102$:
                                    991 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      004194 90 05 6A         [24]  992 	mov	dptr,#_batch_depth
      004197 EF               [12]  993 	mov	a,r7
      004198 04               [12]  994 	inc	a
      004199 F0               [24]  995 	movx	@dptr,a
                                    996 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      00419A 22               [24]  997 	ret
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function ak820_nvm_end
                                   1004 ;	-----------------------------------------
      00419B                       1005 _ak820_nvm_end:
                                   1006 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      00419B 90 05 6A         [24] 1007 	mov	dptr,#_batch_depth
      00419E E0               [24] 1008 	movx	a,@dptr
      00419F FF               [12] 1009 	mov	r7,a
      0041A0 E0               [24] 1010 	movx	a,@dptr
      0041A1 60 06            [24] 1011 	jz	00102$
      0041A3 EF               [12] 1012 	mov	a,r7
      0041A4 14               [12] 1013 	dec	a
      0041A5 90 05 6A         [24] 1014 	mov	dptr,#_batch_depth
      0041A8 F0               [24] 1015 	movx	@dptr,a
      0041A9                       1016 00102$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      0041A9 90 05 6A         [24] 1018 	mov	dptr,#_batch_depth
      0041AC E0               [24] 1019 	movx	a,@dptr
      0041AD 70 03            [24] 1020 	jnz	00105$
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      0041AF 02 40 33         [24] 1022 	ljmp	_ak820_nvm_flush
      0041B2                       1023 00105$:
      0041B2 22               [24] 1024 	ret
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'load_page'
                                   1027 ;------------------------------------------------------------
                                   1028 ;page          Allocated with name '_load_page_page_10000_87'
                                   1029 ;i             Allocated with name '_load_page_i_10000_88'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function load_page
                                   1034 ;	-----------------------------------------
      0041B3                       1035 _load_page:
      0041B3 E5 82            [12] 1036 	mov	a,dpl
      0041B5 90 05 8B         [24] 1037 	mov	dptr,#_load_page_page_10000_87
      0041B8 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      0041B9 30 08 17         [24] 1040 	jnb	_page_valid,00102$
      0041BC 90 05 69         [24] 1041 	mov	dptr,#_cached_page
      0041BF E0               [24] 1042 	movx	a,@dptr
      0041C0 FF               [12] 1043 	mov	r7,a
      0041C1 90 05 8B         [24] 1044 	mov	dptr,#_load_page_page_10000_87
      0041C4 E0               [24] 1045 	movx	a,@dptr
      0041C5 FE               [12] 1046 	mov	r6,a
      0041C6 EF               [12] 1047 	mov	a,r7
      0041C7 B5 06 09         [24] 1048 	cjne	a,ar6,00102$
      0041CA A2 0A            [12] 1049 	mov	c,_storage_failed
      0041CC B3               [12] 1050 	cpl	c
      0041CD 92 0C            [24] 1051 	mov  _load_page_sloc0_1_0,c
      0041CF 12 3A C7         [24] 1052 	lcall	_ak820_outline_0166
      0041D2 22               [24] 1053 	ret
      0041D3                       1054 00102$:
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      0041D3 12 40 33         [24] 1056 	lcall	_ak820_nvm_flush
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      0041D6 30 0A 04         [24] 1058 	jnb	_storage_failed,00119$
      0041D9 75 82 00         [24] 1059 	mov	dpl, #0x00
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0041DC 22               [24] 1061 	ret
      0041DD                       1062 00119$:
      0041DD 7F 00            [12] 1063 	mov	r7,#0x00
      0041DF                       1064 00107$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      0041DF EF               [12] 1066 	mov	a,r7
      0041E0 24 29            [12] 1067 	add	a, #_page_data
      0041E2 FD               [12] 1068 	mov	r5,a
      0041E3 E4               [12] 1069 	clr	a
      0041E4 34 05            [12] 1070 	addc	a, #(_page_data >> 8)
      0041E6 FE               [12] 1071 	mov	r6,a
      0041E7 90 05 8B         [24] 1072 	mov	dptr,#_load_page_page_10000_87
      0041EA E0               [24] 1073 	movx	a,@dptr
      0041EB FC               [12] 1074 	mov	r4,a
      0041EC FA               [12] 1075 	mov	r2,a
      0041ED E4               [12] 1076 	clr	a
      0041EE C3               [12] 1077 	clr	c
      0041EF CA               [12] 1078 	xch	a,r2
      0041F0 13               [12] 1079 	rrc	a
      0041F1 CA               [12] 1080 	xch	a,r2
      0041F2 13               [12] 1081 	rrc	a
      0041F3 A2 E0            [12] 1082 	mov	c,acc.0
      0041F5 CA               [12] 1083 	xch	a,r2
      0041F6 13               [12] 1084 	rrc	a
      0041F7 CA               [12] 1085 	xch	a,r2
      0041F8 13               [12] 1086 	rrc	a
      0041F9 CA               [12] 1087 	xch	a,r2
      0041FA 24 C7            [12] 1088 	add	a,#0xc7
      0041FC FB               [12] 1089 	mov	r3,a
      0041FD 8F 01            [24] 1090 	mov	ar1,r7
      0041FF 89 00            [24] 1091 	mov	ar0,r1
      004201 79 00            [12] 1092 	mov	r1,#0x00
      004203 E8               [12] 1093 	mov	a,r0
      004204 2A               [12] 1094 	add	a, r2
      004205 FA               [12] 1095 	mov	r2,a
      004206 E9               [12] 1096 	mov	a,r1
      004207 3B               [12] 1097 	addc	a, r3
      004208 FB               [12] 1098 	mov	r3,a
      004209 12 45 82         [24] 1099 	lcall	_ak820_outline_0141
      00420C 12 3A FA         [24] 1100 	lcall	_ak820_flash_read
      00420F AB 82            [24] 1101 	mov	r3, dpl
      004211 12 3A AB         [24] 1102 	lcall	_ak820_outline_0131
      004214 EB               [12] 1103 	mov	a,r3
      004215 F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004216 0F               [12] 1106 	inc	r7
      004217 BF 40 C5         [24] 1107 	cjne	r7,#0x40,00107$
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00421A 90 05 69         [24] 1109 	mov	dptr,#_cached_page
      00421D EC               [12] 1110 	mov	a,r4
      00421E F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1113 ;	assignBit
      00421F D2 08            [12] 1114 	setb	_page_valid
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004221 75 82 01         [24] 1116 	mov	dpl, #0x01
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004224 22               [24] 1118 	ret
                                   1119 ;------------------------------------------------------------
                                   1120 ;Allocation info for local variables in function 'read_offset'
                                   1121 ;------------------------------------------------------------
                                   1122 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1123 ;------------------------------------------------------------
                                   1124 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1125 ;	-----------------------------------------
                                   1126 ;	 function read_offset
                                   1127 ;	-----------------------------------------
      004225                       1128 _read_offset:
      004225 12 3A 8A         [24] 1129 	lcall	_ak820_outline_0103
      004228 90 05 8C         [24] 1130 	mov	dptr,#_read_offset_offset_10000_93
      00422B 12 3A 8F         [24] 1131 	lcall	_ak820_outline_0104
                                   1132 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      00422E 90 05 8C         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      004231 12 3A 47         [24] 1134 	lcall	_ak820_outline_0050
      004234 C3               [12] 1135 	clr	c
      004235 94 28            [12] 1136 	subb	a,#0x28
      004237 40 04            [24] 1137 	jc	00102$
      004239 75 82 00         [24] 1138 	mov	dpl, #0x00
      00423C 22               [24] 1139 	ret
      00423D                       1140 00102$:
                                   1141 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      00423D 30 08 34         [24] 1142 	jnb	_page_valid,00104$
      004240 8E 04            [24] 1143 	mov	ar4,r6
      004242 EF               [12] 1144 	mov	a,r7
      004243 A2 E7            [12] 1145 	mov	c,acc.7
      004245 CC               [12] 1146 	xch	a,r4
      004246 33               [12] 1147 	rlc	a
      004247 CC               [12] 1148 	xch	a,r4
      004248 33               [12] 1149 	rlc	a
      004249 A2 E7            [12] 1150 	mov	c,acc.7
      00424B CC               [12] 1151 	xch	a,r4
      00424C 33               [12] 1152 	rlc	a
      00424D CC               [12] 1153 	xch	a,r4
      00424E 33               [12] 1154 	rlc	a
      00424F CC               [12] 1155 	xch	a,r4
      004250 54 03            [12] 1156 	anl	a,#0x03
      004252 FD               [12] 1157 	mov	r5,a
      004253 90 05 69         [24] 1158 	mov	dptr,#_cached_page
      004256 E0               [24] 1159 	movx	a,@dptr
      004257 FA               [12] 1160 	mov	r2,a
      004258 7B 00            [12] 1161 	mov	r3,#0x00
      00425A EC               [12] 1162 	mov	a,r4
      00425B B5 02 16         [24] 1163 	cjne	a,ar2,00104$
      00425E ED               [12] 1164 	mov	a,r5
      00425F B5 03 12         [24] 1165 	cjne	a,ar3,00104$
                                   1166 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004262 74 3F            [12] 1167 	mov	a,#0x3f
      004264 5E               [12] 1168 	anl	a,r6
      004265 7D 00            [12] 1169 	mov	r5,#0x00
      004267 24 29            [12] 1170 	add	a, #_page_data
      004269 F5 82            [12] 1171 	mov	dpl,a
      00426B ED               [12] 1172 	mov	a,r5
      00426C 34 05            [12] 1173 	addc	a, #(_page_data >> 8)
      00426E F5 83            [12] 1174 	mov	dph,a
      004270 E0               [24] 1175 	movx	a,@dptr
      004271 F5 82            [12] 1176 	mov	dpl,a
      004273 22               [24] 1177 	ret
      004274                       1178 00104$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004274 74 C7            [12] 1180 	mov	a,#0xc7
      004276 2F               [12] 1181 	add	a, r7
      004277 FF               [12] 1182 	mov	r7,a
      004278 12 45 66         [24] 1183 	lcall	_ak820_outline_0116
                                   1184 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      00427B 02 3A FA         [24] 1185 	ljmp	_ak820_flash_read
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1188 ;------------------------------------------------------------
                                   1189 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function eeprom_read_byte
                                   1194 ;	-----------------------------------------
      00427E                       1195 _eeprom_read_byte:
      00427E C0 07            [24] 1196 	push	ar7
      004280 C0 06            [24] 1197 	push	ar6
      004282 12 45 1D         [24] 1198 	lcall	_ak820_outline_0036
      004285 90 05 8E         [24] 1199 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004288 12 3A 26         [24] 1200 	lcall	_ak820_outline_0015
                                   1201 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00428B 90 05 8E         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00428E 12 39 E7         [24] 1203 	lcall	_ak820_outline_0004
      004291 C0 06            [24] 1204 	push	ar6
      004293 C0 05            [24] 1205 	push	ar5
      004295 C0 04            [24] 1206 	push	ar4
      004297 C0 03            [24] 1207 	push	ar3
      004299 C0 02            [24] 1208 	push	ar2
      00429B C0 01            [24] 1209 	push	ar1
      00429D C0 00            [24] 1210 	push	ar0
      00429F 12 42 25         [24] 1211 	lcall	_read_offset
      0042A2 AF 82            [24] 1212 	mov	r7, dpl
      0042A4 D0 00            [24] 1213 	pop	ar0
      0042A6 D0 01            [24] 1214 	pop	ar1
      0042A8 D0 02            [24] 1215 	pop	ar2
      0042AA D0 03            [24] 1216 	pop	ar3
      0042AC D0 04            [24] 1217 	pop	ar4
      0042AE D0 05            [24] 1218 	pop	ar5
      0042B0 D0 06            [24] 1219 	pop	ar6
      0042B2 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0042B4 D0 06            [24] 1222 	pop	ar6
      0042B6 D0 07            [24] 1223 	pop	ar7
      0042B8 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1227 ;------------------------------------------------------------
                                   1228 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1229 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1230 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1231 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1232 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1233 ;------------------------------------------------------------
                                   1234 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1235 ;	-----------------------------------------
                                   1236 ;	 function ak820_eeprom_read_block_xdata
                                   1237 ;	-----------------------------------------
      0042B9                       1238 _ak820_eeprom_read_block_xdata:
      0042B9 12 3A 8A         [24] 1239 	lcall	_ak820_outline_0103
      0042BC 90 05 96         [24] 1240 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0042BF 12 3A 8F         [24] 1241 	lcall	_ak820_outline_0104
                                   1242 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0042C2 90 05 91         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0042C5 12 3A 47         [24] 1244 	lcall	_ak820_outline_0050
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0042C8 90 05 96         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0042CB 12 3A 66         [24] 1247 	lcall	_ak820_outline_0059
      0042CE 90 05 98         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0042D1 12 3A 6C         [24] 1249 	lcall	_ak820_outline_0070
                                   1250 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0042D4 90 05 94         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0042D7 12 3A 66         [24] 1252 	lcall	_ak820_outline_0059
      0042DA                       1253 00103$:
      0042DA 8C 02            [24] 1254 	mov	ar2,r4
      0042DC 8D 03            [24] 1255 	mov	ar3,r5
      0042DE 1C               [12] 1256 	dec	r4
      0042DF BC FF 01         [24] 1257 	cjne	r4,#0xff,00130$
      0042E2 1D               [12] 1258 	dec	r5
      0042E3                       1259 00130$:
      0042E3 EA               [12] 1260 	mov	a,r2
      0042E4 4B               [12] 1261 	orl	a,r3
      0042E5 60 5D            [24] 1262 	jz	00106$
                                   1263 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0042E7 8E 02            [24] 1264 	mov	ar2,r6
      0042E9 8F 03            [24] 1265 	mov	ar3,r7
      0042EB 74 D8            [12] 1266 	mov	a,#0x100 - 0x28
      0042ED 2B               [12] 1267 	add	a,r3
      0042EE 50 17            [24] 1268 	jnc	00102$
      0042F0 90 05 98         [24] 1269 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0042F3 12 45 6B         [24] 1270 	lcall	_ak820_outline_0119
      0042F6 12 45 82         [24] 1271 	lcall	_ak820_outline_0141
      0042F9 E4               [12] 1272 	clr	a
      0042FA F0               [24] 1273 	movx	@dptr,a
      0042FB 90 05 98         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0042FE 04               [12] 1275 	inc	a
      0042FF 2A               [12] 1276 	add	a, r2
      004300 F0               [24] 1277 	movx	@dptr,a
      004301 E4               [12] 1278 	clr	a
      004302 3B               [12] 1279 	addc	a, r3
      004303 A3               [24] 1280 	inc	dptr
      004304 F0               [24] 1281 	movx	@dptr,a
      004305 80 D3            [24] 1282 	sjmp	00103$
      004307                       1283 00102$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004307 90 05 98         [24] 1285 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00430A 12 45 6B         [24] 1286 	lcall	_ak820_outline_0119
      00430D 12 45 66         [24] 1287 	lcall	_ak820_outline_0116
      004310 C0 07            [24] 1288 	push	ar7
      004312 C0 06            [24] 1289 	push	ar6
      004314 C0 05            [24] 1290 	push	ar5
      004316 C0 04            [24] 1291 	push	ar4
      004318 C0 03            [24] 1292 	push	ar3
      00431A C0 02            [24] 1293 	push	ar2
      00431C 12 42 25         [24] 1294 	lcall	_read_offset
      00431F A9 82            [24] 1295 	mov	r1, dpl
      004321 D0 02            [24] 1296 	pop	ar2
      004323 D0 03            [24] 1297 	pop	ar3
      004325 D0 04            [24] 1298 	pop	ar4
      004327 D0 05            [24] 1299 	pop	ar5
      004329 D0 06            [24] 1300 	pop	ar6
      00432B D0 07            [24] 1301 	pop	ar7
      00432D 12 45 82         [24] 1302 	lcall	_ak820_outline_0141
      004330 E9               [12] 1303 	mov	a,r1
      004331 F0               [24] 1304 	movx	@dptr,a
      004332 90 05 98         [24] 1305 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004335 74 01            [12] 1306 	mov	a,#0x01
      004337 2A               [12] 1307 	add	a, r2
      004338 F0               [24] 1308 	movx	@dptr,a
      004339 E4               [12] 1309 	clr	a
      00433A 3B               [12] 1310 	addc	a, r3
      00433B A3               [24] 1311 	inc	dptr
      00433C F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      00433D 0E               [12] 1314 	inc	r6
      00433E BE 00 99         [24] 1315 	cjne	r6,#0x00,00103$
      004341 0F               [12] 1316 	inc	r7
      004342 80 96            [24] 1317 	sjmp	00103$
      004344                       1318 00106$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004344 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1325 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1326 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1327 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1328 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1329 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1330 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function ak820_eeprom_write_block_xdata
                                   1335 ;	-----------------------------------------
      004345                       1336 _ak820_eeprom_write_block_xdata:
      004345 12 3A 8A         [24] 1337 	lcall	_ak820_outline_0103
      004348 90 05 9F         [24] 1338 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00434B 12 3A 8F         [24] 1339 	lcall	_ak820_outline_0104
                                   1340 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00434E 90 05 9A         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004351 12 3A 47         [24] 1342 	lcall	_ak820_outline_0050
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004354 90 05 9F         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004357 12 3A 66         [24] 1345 	lcall	_ak820_outline_0059
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00435A 8E 02            [24] 1347 	mov	ar2,r6
      00435C 8F 03            [24] 1348 	mov	ar3,r7
      00435E C3               [12] 1349 	clr	c
      00435F E4               [12] 1350 	clr	a
      004360 9A               [12] 1351 	subb	a,r2
      004361 74 28            [12] 1352 	mov	a,#0x28
      004363 9B               [12] 1353 	subb	a,r3
      004364 40 15            [24] 1354 	jc	00101$
                                   1355 ;	free result
      004366 E4               [12] 1356 	clr	a
      004367 C3               [12] 1357 	clr	c
      004368 9E               [12] 1358 	subb	a,r6
      004369 FA               [12] 1359 	mov	r2,a
      00436A 74 28            [12] 1360 	mov	a,#0x28
      00436C 9F               [12] 1361 	subb	a,r7
      00436D FB               [12] 1362 	mov	r3,a
      00436E 90 05 9D         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004371 12 3A 84         [24] 1364 	lcall	_ak820_outline_0099
      004374 C3               [12] 1365 	clr	c
      004375 EA               [12] 1366 	mov	a,r2
      004376 98               [12] 1367 	subb	a,r0
      004377 EB               [12] 1368 	mov	a,r3
      004378 99               [12] 1369 	subb	a,r1
      004379 50 06            [24] 1370 	jnc	00125$
                                   1371 ;	free result
      00437B                       1372 00101$:
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      00437B 75 82 0E         [24] 1374 	mov	dpl, #0x0e
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      00437E 02 3D 8E         [24] 1376 	ljmp	_nvm_fail
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004381                       1378 00125$:
      004381 90 05 9D         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004384 12 45 6B         [24] 1380 	lcall	_ak820_outline_0119
      004387                       1381 00108$:
      004387 8A 00            [24] 1382 	mov	ar0,r2
      004389 8B 01            [24] 1383 	mov	ar1,r3
      00438B 1A               [12] 1384 	dec	r2
      00438C BA FF 01         [24] 1385 	cjne	r2,#0xff,00159$
      00438F 1B               [12] 1386 	dec	r3
      004390                       1387 00159$:
      004390 E8               [12] 1388 	mov	a,r0
      004391 49               [12] 1389 	orl	a,r1
      004392 70 03            [24] 1390 	jnz	00160$
      004394 02 44 1E         [24] 1391 	ljmp	00110$
      004397                       1392 00160$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004397 C0 02            [24] 1394 	push	ar2
      004399 C0 03            [24] 1395 	push	ar3
      00439B 12 45 4E         [24] 1396 	lcall	_ak820_outline_0091
      00439E F9               [12] 1397 	mov	r1,a
      00439F A3               [24] 1398 	inc	dptr
      0043A0 12 45 87         [24] 1399 	lcall	_ak820_outline_0147
                                   1400 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0043A3 8E 0C            [24] 1401 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0043A5 8F 0D            [24] 1402 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0043A7 A8 0C            [24] 1403 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0043A9 E5 0D            [12] 1404 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0043AB A2 E7            [12] 1405 	mov	c,acc.7
      0043AD C8               [12] 1406 	xch	a,r0
      0043AE 33               [12] 1407 	rlc	a
      0043AF C8               [12] 1408 	xch	a,r0
      0043B0 33               [12] 1409 	rlc	a
      0043B1 A2 E7            [12] 1410 	mov	c,acc.7
      0043B3 C8               [12] 1411 	xch	a,r0
      0043B4 33               [12] 1412 	rlc	a
      0043B5 C8               [12] 1413 	xch	a,r0
      0043B6 33               [12] 1414 	rlc	a
      0043B7 C8               [12] 1415 	xch	a,r0
      0043B8 54 03            [12] 1416 	anl	a,#0x03
      0043BA FB               [12] 1417 	mov	r3,a
      0043BB 88 82            [24] 1418 	mov	dpl, r0
      0043BD C0 07            [24] 1419 	push	ar7
      0043BF C0 06            [24] 1420 	push	ar6
      0043C1 C0 05            [24] 1421 	push	ar5
      0043C3 C0 04            [24] 1422 	push	ar4
      0043C5 C0 03            [24] 1423 	push	ar3
      0043C7 C0 02            [24] 1424 	push	ar2
      0043C9 C0 01            [24] 1425 	push	ar1
      0043CB 12 41 B3         [24] 1426 	lcall	_load_page
      0043CE E5 82            [12] 1427 	mov	a, dpl
      0043D0 D0 01            [24] 1428 	pop	ar1
      0043D2 D0 02            [24] 1429 	pop	ar2
      0043D4 D0 03            [24] 1430 	pop	ar3
      0043D6 D0 04            [24] 1431 	pop	ar4
      0043D8 D0 05            [24] 1432 	pop	ar5
      0043DA D0 06            [24] 1433 	pop	ar6
      0043DC D0 07            [24] 1434 	pop	ar7
      0043DE D0 03            [24] 1435 	pop	ar3
      0043E0 D0 02            [24] 1436 	pop	ar2
      0043E2 70 01            [24] 1437 	jnz	00105$
      0043E4 22               [24] 1438 	ret
      0043E5                       1439 00105$:
                                   1440 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0043E5 C0 06            [24] 1441 	push	ar6
      0043E7 C0 07            [24] 1442 	push	ar7
      0043E9 74 3F            [12] 1443 	mov	a,#0x3f
      0043EB 55 0C            [12] 1444 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0043ED 7F 00            [12] 1445 	mov	r7,#0x00
      0043EF 24 29            [12] 1446 	add	a, #_page_data
      0043F1 F5 0C            [12] 1447 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0043F3 EF               [12] 1448 	mov	a,r7
      0043F4 34 05            [12] 1449 	addc	a, #(_page_data >> 8)
      0043F6 F5 0D            [12] 1450 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0043F8 85 0C 82         [24] 1451 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0043FB 85 0D 83         [24] 1452 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0043FE E0               [24] 1453 	movx	a,@dptr
      0043FF B5 01 06         [24] 1454 	cjne	a,ar1,00162$
      004402 D0 07            [24] 1455 	pop	ar7
      004404 D0 06            [24] 1456 	pop	ar6
      004406 80 0E            [24] 1457 	sjmp	00107$
      004408                       1458 00162$:
      004408 D0 07            [24] 1459 	pop	ar7
      00440A D0 06            [24] 1460 	pop	ar6
                                   1461 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00440C 85 0C 82         [24] 1462 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00440F 85 0D 83         [24] 1463 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004412 E9               [12] 1464 	mov	a,r1
      004413 F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1467 ;	assignBit
      004414 D2 09            [12] 1468 	setb	_page_dirty
      004416                       1469 00107$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004416 0E               [12] 1471 	inc	r6
      004417 BE 00 01         [24] 1472 	cjne	r6,#0x00,00163$
      00441A 0F               [12] 1473 	inc	r7
      00441B                       1474 00163$:
      00441B 02 43 87         [24] 1475 	ljmp	00108$
      00441E                       1476 00110$:
                                   1477 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00441E 90 05 6A         [24] 1478 	mov	dptr,#_batch_depth
      004421 E0               [24] 1479 	movx	a,@dptr
      004422 70 03            [24] 1480 	jnz	00113$
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004424 02 40 33         [24] 1482 	ljmp	_ak820_nvm_flush
      004427                       1483 00113$:
      004427 22               [24] 1484 	ret
                                   1485 ;------------------------------------------------------------
                                   1486 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1487 ;------------------------------------------------------------
                                   1488 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1489 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1490 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1491 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1492 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1493 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1494 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1495 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1496 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1497 ;------------------------------------------------------------
                                   1498 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1499 ;	-----------------------------------------
                                   1500 ;	 function ak820_eeprom_update_block_xdata
                                   1501 ;	-----------------------------------------
      004428                       1502 _ak820_eeprom_update_block_xdata:
      004428 12 3A 8A         [24] 1503 	lcall	_ak820_outline_0103
      00442B 90 05 A6         [24] 1504 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00442E 12 3A 8F         [24] 1505 	lcall	_ak820_outline_0104
                                   1506 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004431 90 05 A6         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004434 12 3A 47         [24] 1508 	lcall	_ak820_outline_0050
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004437 90 05 A1         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00443A E0               [24] 1511 	movx	a,@dptr
      00443B F5 12            [12] 1512 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      00443D A3               [24] 1513 	inc	dptr
      00443E E0               [24] 1514 	movx	a,@dptr
      00443F F5 13            [12] 1515 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004441 A3               [24] 1516 	inc	dptr
      004442 E0               [24] 1517 	movx	a,@dptr
      004443 F5 14            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004445 A9 12            [24] 1519 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004447 AA 13            [24] 1520 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1521 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004449 E4               [12] 1522 	clr	a
      00444A F5 0E            [12] 1523 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      00444C F5 0F            [12] 1524 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00444E                       1525 00105$:
      00444E 90 05 A4         [24] 1526 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004451 E0               [24] 1527 	movx	a,@dptr
      004452 F5 10            [12] 1528 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004454 A3               [24] 1529 	inc	dptr
      004455 E0               [24] 1530 	movx	a,@dptr
      004456 F5 11            [12] 1531 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004458 C3               [12] 1532 	clr	c
      004459 E5 0E            [12] 1533 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00445B 95 10            [12] 1534 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00445D E5 0F            [12] 1535 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00445F 95 11            [12] 1536 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004461 50 68            [24] 1537 	jnc	00107$
                                   1538 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004463 89 00            [24] 1539 	mov	ar0,r1
      004465 8A 05            [24] 1540 	mov	ar5,r2
      004467 E5 0E            [12] 1541 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004469 28               [12] 1542 	add	a, r0
      00446A F8               [12] 1543 	mov	r0,a
      00446B E5 0F            [12] 1544 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00446D 3D               [12] 1545 	addc	a, r5
      00446E FD               [12] 1546 	mov	r5,a
      00446F 88 82            [24] 1547 	mov	dpl, r0
      004471 8D 83            [24] 1548 	mov	dph, r5
      004473 C0 07            [24] 1549 	push	ar7
      004475 C0 06            [24] 1550 	push	ar6
      004477 C0 02            [24] 1551 	push	ar2
      004479 C0 01            [24] 1552 	push	ar1
      00447B 12 42 25         [24] 1553 	lcall	_read_offset
      00447E AD 82            [24] 1554 	mov	r5, dpl
      004480 D0 01            [24] 1555 	pop	ar1
      004482 D0 02            [24] 1556 	pop	ar2
      004484 D0 06            [24] 1557 	pop	ar6
      004486 D0 07            [24] 1558 	pop	ar7
      004488 E5 0E            [12] 1559 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00448A 2E               [12] 1560 	add	a, r6
      00448B F5 82            [12] 1561 	mov	dpl,a
      00448D E5 0F            [12] 1562 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00448F 3F               [12] 1563 	addc	a, r7
      004490 F5 83            [12] 1564 	mov	dph,a
      004492 E0               [24] 1565 	movx	a,@dptr
      004493 FC               [12] 1566 	mov	r4,a
      004494 ED               [12] 1567 	mov	a,r5
      004495 B5 04 02         [24] 1568 	cjne	a,ar4,00131$
      004498 80 27            [24] 1569 	sjmp	00106$
      00449A                       1570 00131$:
                                   1571 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00449A 90 05 A6         [24] 1572 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00449D E0               [24] 1573 	movx	a,@dptr
      00449E F8               [12] 1574 	mov	r0,a
      00449F A3               [24] 1575 	inc	dptr
      0044A0 E0               [24] 1576 	movx	a,@dptr
      0044A1 FD               [12] 1577 	mov	r5,a
      0044A2 90 05 9A         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0044A5 E5 12            [12] 1579 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0044A7 F0               [24] 1580 	movx	@dptr,a
      0044A8 E5 13            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0044AA A3               [24] 1582 	inc	dptr
      0044AB F0               [24] 1583 	movx	@dptr,a
      0044AC E5 14            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0044AE A3               [24] 1585 	inc	dptr
      0044AF F0               [24] 1586 	movx	@dptr,a
      0044B0 90 05 9D         [24] 1587 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0044B3 E5 10            [12] 1588 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0044B5 F0               [24] 1589 	movx	@dptr,a
      0044B6 E5 11            [12] 1590 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0044B8 A3               [24] 1591 	inc	dptr
      0044B9 F0               [24] 1592 	movx	@dptr,a
      0044BA 88 82            [24] 1593 	mov	dpl, r0
      0044BC 8D 83            [24] 1594 	mov	dph, r5
                                   1595 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0044BE 02 43 45         [24] 1596 	ljmp	_ak820_eeprom_write_block_xdata
      0044C1                       1597 00106$:
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0044C1 05 0E            [12] 1599 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044C3 E4               [12] 1600 	clr	a
      0044C4 B5 0E 87         [24] 1601 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0044C7 05 0F            [12] 1602 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044C9 80 83            [24] 1603 	sjmp	00105$
      0044CB                       1604 00107$:
                                   1605 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0044CB 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1609 ;------------------------------------------------------------
                                   1610 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1611 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function eeprom_driver_erase
                                   1616 ;	-----------------------------------------
      0044CC                       1617 _eeprom_driver_erase:
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0044CC 12 40 33         [24] 1619 	lcall	_ak820_nvm_flush
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0044CF 7F 00            [12] 1621 	mov	r7,#0x00
      0044D1                       1622 00111$:
      0044D1 BF A0 01         [24] 1623 	cjne	r7,#0xa0,00165$
      0044D4 22               [24] 1624 	ret
      0044D5                       1625 00165$:
      0044D5 20 0A 32         [24] 1626 	jb	_storage_failed,00113$
                                   1627 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0044D8 8F 82            [24] 1628 	mov	dpl, r7
      0044DA C0 07            [24] 1629 	push	ar7
      0044DC 12 41 B3         [24] 1630 	lcall	_load_page
      0044DF E5 82            [12] 1631 	mov	a, dpl
      0044E1 D0 07            [24] 1632 	pop	ar7
      0044E3 70 01            [24] 1633 	jnz	00126$
                                   1634 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0044E5 22               [24] 1635 	ret
      0044E6                       1636 00126$:
      0044E6 7E 00            [12] 1637 	mov	r6,#0x00
      0044E8                       1638 00107$:
                                   1639 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0044E8 EE               [12] 1640 	mov	a,r6
      0044E9 24 29            [12] 1641 	add	a, #_page_data
      0044EB FC               [12] 1642 	mov	r4,a
      0044EC E4               [12] 1643 	clr	a
      0044ED 34 05            [12] 1644 	addc	a, #(_page_data >> 8)
      0044EF FD               [12] 1645 	mov	r5,a
      0044F0 12 45 4E         [24] 1646 	lcall	_ak820_outline_0091
      0044F3 60 07            [24] 1647 	jz	00108$
      0044F5 12 3A 9B         [24] 1648 	lcall	_ak820_outline_0117
      0044F8 E4               [12] 1649 	clr	a
      0044F9 F0               [24] 1650 	movx	@dptr,a
                                   1651 ;	assignBit
      0044FA D2 09            [12] 1652 	setb	_page_dirty
      0044FC                       1653 00108$:
                                   1654 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0044FC 0E               [12] 1655 	inc	r6
      0044FD BE 40 E8         [24] 1656 	cjne	r6,#0x40,00107$
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004500 C0 07            [24] 1658 	push	ar7
      004502 12 40 33         [24] 1659 	lcall	_ak820_nvm_flush
      004505 D0 07            [24] 1660 	pop	ar7
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004507 0F               [12] 1662 	inc	r7
      004508 80 C7            [24] 1663 	sjmp	00111$
      00450A                       1664 00113$:
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      00450A 22               [24] 1666 	ret
                                   1667 	.area CSEG    (CODE)
                                   1668 	.area CONST   (CODE)
                                   1669 	.area XINIT   (CODE)
                                   1670 	.area CABS    (ABS,CODE)
                                   1671 
                                   1672 ; Experimental exact instruction outlining.
                                   1673 	.globl _ak820_outline_0004
                                   1674 	.globl _ak820_outline_0010
                                   1675 	.globl _ak820_outline_0015
                                   1676 	.globl _ak820_outline_0016
                                   1677 	.globl _ak820_outline_0029
                                   1678 	.globl _ak820_outline_0036
                                   1679 	.globl _ak820_outline_0039
                                   1680 	.globl _ak820_outline_0050
                                   1681 	.globl _ak820_outline_0051
                                   1682 	.globl _ak820_outline_0059
                                   1683 	.globl _ak820_outline_0060
                                   1684 	.globl _ak820_outline_0064
                                   1685 	.globl _ak820_outline_0070
                                   1686 	.globl _ak820_outline_0076
                                   1687 	.globl _ak820_outline_0091
                                   1688 	.globl _ak820_outline_0092
                                   1689 	.globl _ak820_outline_0099
                                   1690 	.globl _ak820_outline_0101
                                   1691 	.globl _ak820_outline_0103
                                   1692 	.globl _ak820_outline_0104
                                   1693 	.globl _ak820_outline_0116
                                   1694 	.globl _ak820_outline_0117
                                   1695 	.globl _ak820_outline_0119
                                   1696 	.globl _ak820_outline_0120
                                   1697 	.globl _ak820_outline_0121
                                   1698 	.globl _ak820_outline_0130
                                   1699 	.globl _ak820_outline_0131
                                   1700 	.globl _ak820_outline_0133
                                   1701 	.globl _ak820_outline_0140
                                   1702 	.globl _ak820_outline_0141
                                   1703 	.globl _ak820_outline_0147
                                   1704 	.globl _ak820_outline_0155
                                   1705 	.globl _ak820_outline_0157
                                   1706 	.globl _ak820_outline_0158
                                   1707 	.globl _ak820_outline_0166
                                   1708 	.globl _ak820_outline_0178
                                   1709 	.globl _ak820_outline_0179
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0010
      00450B                       1713 _ak820_outline_0010:
      00450B 8E 82            [24] 1714 	mov	dpl,r6
      00450D 8F 83            [24] 1715 	mov	dph,r7
      00450F A3               [24] 1716 	inc	dptr
      004510 A3               [24] 1717 	inc	dptr
      004511 A3               [24] 1718 	inc	dptr
      004512 A3               [24] 1719 	inc	dptr
      004513 A3               [24] 1720 	inc	dptr
      004514 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0029
      004515                       1725 _ak820_outline_0029:
      004515 F0               [24] 1726 	movx	@dptr,a
      004516 8E 82            [24] 1727 	mov	dpl,r6
      004518 8F 83            [24] 1728 	mov	dph,r7
      00451A A3               [24] 1729 	inc	dptr
      00451B A3               [24] 1730 	inc	dptr
      00451C 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0036
      00451D                       1735 _ak820_outline_0036:
      00451D AF F0            [24] 1736 	mov	r7,b
      00451F AE 83            [24] 1737 	mov	r6,dph
      004521 E5 82            [12] 1738 	mov	a,dpl
      004523 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0039
      004524                       1743 _ak820_outline_0039:
      004524 EF               [12] 1744 	mov	a,r7
      004525 24 81            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      004527 F5 82            [12] 1746 	mov	dpl,a
      004529 E4               [12] 1747 	clr	a
      00452A 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00452C F5 83            [12] 1749 	mov	dph,a
      00452E E0               [24] 1750 	movx	a,@dptr
      00452F 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0051
      004530                       1755 _ak820_outline_0051:
      004530 8F 06            [24] 1756 	mov	ar6,r7
      004532 7D 00            [12] 1757 	mov	r5,#0x00
      004534 74 40            [12] 1758 	mov	a,#0x40
      004536 2E               [12] 1759 	add	a,r6
      004537 FE               [12] 1760 	mov	r6,a
      004538 74 EF            [12] 1761 	mov	a,#0xef
      00453A 3D               [12] 1762 	addc	a,r5
      00453B FD               [12] 1763 	mov	r5,a
      00453C 8E 82            [24] 1764 	mov	dpl,r6
      00453E 8D 83            [24] 1765 	mov	dph,r5
      004540 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0060
      004541                       1770 _ak820_outline_0060:
      004541 F0               [24] 1771 	movx	@dptr,a
      004542 8E 82            [24] 1772 	mov	dpl,r6
      004544 8F 83            [24] 1773 	mov	dph,r7
      004546 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0064
      004547                       1778 _ak820_outline_0064:
      004547 8D 82            [24] 1779 	mov	dpl,r5
      004549 8E 83            [24] 1780 	mov	dph,r6
      00454B EC               [12] 1781 	mov	a,r4
      00454C F0               [24] 1782 	movx	@dptr,a
      00454D 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0091
      00454E                       1787 _ak820_outline_0091:
      00454E 8C 82            [24] 1788 	mov	dpl,r4
      004550 8D 83            [24] 1789 	mov	dph,r5
      004552 E0               [24] 1790 	movx	a,@dptr
      004553 22               [24] 1791 	ret
                                   1792 
                                   1793 	.area CSEG (CODE)
                                   1794 ; function ak820_outline_0092
      004554                       1795 _ak820_outline_0092:
      004554 E0               [24] 1796 	movx	a,@dptr
      004555 FD               [12] 1797 	mov	r5,a
      004556 A3               [24] 1798 	inc	dptr
      004557 E0               [24] 1799 	movx	a,@dptr
      004558 FE               [12] 1800 	mov	r6,a
      004559 22               [24] 1801 	ret
                                   1802 
                                   1803 	.area CSEG (CODE)
                                   1804 ; function ak820_outline_0101
      00455A                       1805 _ak820_outline_0101:
      00455A EF               [12] 1806 	mov	a,r7
      00455B 24 29            [12] 1807 	add	a,#_page_data
      00455D F5 82            [12] 1808 	mov	dpl,a
      00455F E4               [12] 1809 	clr	a
      004560 34 05            [12] 1810 	addc	a,#(_page_data>>8)
      004562 F5 83            [12] 1811 	mov	dph,a
      004564 E0               [24] 1812 	movx	a,@dptr
      004565 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0116
      004566                       1817 _ak820_outline_0116:
      004566 8E 82            [24] 1818 	mov	dpl,r6
      004568 8F 83            [24] 1819 	mov	dph,r7
      00456A 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0119
      00456B                       1824 _ak820_outline_0119:
      00456B E0               [24] 1825 	movx	a,@dptr
      00456C FA               [12] 1826 	mov	r2,a
      00456D A3               [24] 1827 	inc	dptr
      00456E E0               [24] 1828 	movx	a,@dptr
      00456F FB               [12] 1829 	mov	r3,a
      004570 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0130
      004571                       1834 _ak820_outline_0130:
      004571 AE 82            [24] 1835 	mov	r6,dpl
      004573 AF 83            [24] 1836 	mov	r7,dph
      004575 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0133
      004576                       1841 _ak820_outline_0133:
      004576 2E               [12] 1842 	add	a,r6
      004577 FE               [12] 1843 	mov	r6,a
      004578 E4               [12] 1844 	clr	a
      004579 3F               [12] 1845 	addc	a,r7
      00457A FF               [12] 1846 	mov	r7,a
      00457B 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0140
      00457C                       1851 _ak820_outline_0140:
      00457C 42 05            [12] 1852 	orl	ar5,a
      00457E EA               [12] 1853 	mov	a,r2
      00457F 42 04            [12] 1854 	orl	ar4,a
      004581 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0141
      004582                       1859 _ak820_outline_0141:
      004582 8A 82            [24] 1860 	mov	dpl,r2
      004584 8B 83            [24] 1861 	mov	dph,r3
      004586 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0147
      004587                       1866 _ak820_outline_0147:
      004587 AC 82            [24] 1867 	mov	r4,dpl
      004589 AD 83            [24] 1868 	mov	r5,dph
      00458B 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0155
      00458C                       1873 _ak820_outline_0155:
      00458C 8F 82            [24] 1874 	mov	dpl,r7
      00458E 8E 83            [24] 1875 	mov	dph,r6
      004590 22               [24] 1876 	ret
                                   1877 
                                   1878 	.area CSEG (CODE)
                                   1879 ; function ak820_outline_0157
      004591                       1880 _ak820_outline_0157:
      004591 2E               [12] 1881 	add	a,r6
      004592 FC               [12] 1882 	mov	r4,a
      004593 E4               [12] 1883 	clr	a
      004594 3F               [12] 1884 	addc	a,r7
      004595 FD               [12] 1885 	mov	r5,a
      004596 22               [24] 1886 	ret
                                   1887 
                                   1888 	.area CSEG (CODE)
                                   1889 ; function ak820_outline_0158
      004597                       1890 _ak820_outline_0158:
      004597 ED               [12] 1891 	mov	a,r5
      004598 F0               [24] 1892 	movx	@dptr,a
      004599 EE               [12] 1893 	mov	a,r6
      00459A A3               [24] 1894 	inc	dptr
      00459B F0               [24] 1895 	movx	@dptr,a
      00459C 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0178
      00459D                       1900 _ak820_outline_0178:
      00459D 89 82            [24] 1901 	mov	dpl,r1
      00459F 8A 83            [24] 1902 	mov	dph,r2
      0045A1 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0179
      0045A2                       1907 _ak820_outline_0179:
      0045A2 8C 82            [24] 1908 	mov	dpl,r4
      0045A4 8B 83            [24] 1909 	mov	dph,r3
      0045A6 22               [24] 1910 	ret
