                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _memset
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _del_key_from_report_PARM_2
                                    256 	.globl _add_key_to_report_PARM_2
                                    257 	.globl _del_key_bit_PARM_2
                                    258 	.globl _add_key_bit_PARM_2
                                    259 	.globl _del_key_byte_PARM_2
                                    260 	.globl _add_key_byte_PARM_2
                                    261 	.globl _KEYCODE2CONSUMER
                                    262 	.globl _add_key_byte
                                    263 	.globl _del_key_byte
                                    264 	.globl _add_key_bit
                                    265 	.globl _del_key_bit
                                    266 	.globl _add_key_to_report
                                    267 	.globl _del_key_from_report
                                    268 	.globl _clear_keys_from_report
                                    269 ;--------------------------------------------------------
                                    270 ; special function registers
                                    271 ;--------------------------------------------------------
                                    272 	.area RSEG    (ABS,DATA)
      000000                        273 	.org 0x0000
                           0000D0   274 _PSW	=	0x00d0
                           0000E0   275 _ACC	=	0x00e0
                           0000F0   276 _B	=	0x00f0
                           0000FD   277 _A_INV	=	0x00fd
                           000081   278 _SP	=	0x0081
                           000082   279 _DPL	=	0x0082
                           000083   280 _DPH	=	0x0083
                           0000A1   281 _SAFE_MOD	=	0x00a1
                           0000B1   282 _GLOBAL_CFG	=	0x00b1
                           000087   283 _PCON	=	0x0087
                           0000BA   284 _POWER_CFG	=	0x00ba
                           0000B9   285 _CLOCK_CFG	=	0x00b9
                           0000A9   286 _WAKE_CTRL	=	0x00a9
                           0000FE   287 _RESET_KEEP	=	0x00fe
                           0000FF   288 _WDOG_COUNT	=	0x00ff
                           0000A8   289 _IE	=	0x00a8
                           0000B8   290 _IP	=	0x00b8
                           0000E8   291 _IE_EX	=	0x00e8
                           0000E9   292 _IP_EX	=	0x00e9
                           0000B2   293 _GPIO_IE	=	0x00b2
                           008584   294 _ROM_ADDR	=	0x8584
                           000084   295 _ROM_ADDR_L	=	0x0084
                           000085   296 _ROM_ADDR_H	=	0x0085
                           008F8E   297 _ROM_DATA_HI	=	0x8f8e
                           00008E   298 _ROM_DATA_HL	=	0x008e
                           00008F   299 _ROM_DATA_HH	=	0x008f
                           000086   300 _ROM_CTRL	=	0x0086
                           000080   301 _P0	=	0x0080
                           0000C4   302 _P0_MOD_OC	=	0x00c4
                           0000C5   303 _P0_DIR_PU	=	0x00c5
                           000090   304 _P1	=	0x0090
                           000092   305 _P1_MOD_OC	=	0x0092
                           000093   306 _P1_DIR_PU	=	0x0093
                           0000A0   307 _P2	=	0x00a0
                           000094   308 _P2_MOD_OC	=	0x0094
                           000095   309 _P2_DIR_PU	=	0x0095
                           0000B0   310 _P3	=	0x00b0
                           000096   311 _P3_MOD_OC	=	0x0096
                           000097   312 _P3_DIR_PU	=	0x0097
                           0000C0   313 _P4	=	0x00c0
                           0000C2   314 _P4_MOD_OC	=	0x00c2
                           0000C3   315 _P4_DIR_PU	=	0x00c3
                           0000C1   316 _P4_LED_KEY	=	0x00c1
                           0000AA   317 _P5_IN	=	0x00aa
                           0000AB   318 _P5_OUT_PU	=	0x00ab
                           0000AC   319 _P5_DIR	=	0x00ac
                           0000AD   320 _P6_IN	=	0x00ad
                           0000AE   321 _P6_OUT_PU	=	0x00ae
                           0000AF   322 _P6_DIR	=	0x00af
                           0000F1   323 _P7	=	0x00f1
                           0000A2   324 _XBUS_AUX	=	0x00a2
                           000088   325 _TCON	=	0x0088
                           000089   326 _TMOD	=	0x0089
                           00008A   327 _TL0	=	0x008a
                           00008B   328 _TL1	=	0x008b
                           00008C   329 _TH0	=	0x008c
                           00008D   330 _TH1	=	0x008d
                           000098   331 _SCON	=	0x0098
                           000099   332 _SBUF	=	0x0099
                           0000C8   333 _T2CON	=	0x00c8
                           0000C9   334 _T2MOD	=	0x00c9
                           00CBCA   335 _RCAP2	=	0xcbca
                           0000CA   336 _RCAP2L	=	0x00ca
                           0000CB   337 _RCAP2H	=	0x00cb
                           00CDCC   338 _T2COUNT	=	0xcdcc
                           0000CC   339 _TL2	=	0x00cc
                           0000CD   340 _TH2	=	0x00cd
                           00CFCE   341 _T2CAP1	=	0xcfce
                           0000CE   342 _T2CAP1L	=	0x00ce
                           0000CF   343 _T2CAP1H	=	0x00cf
                           0000F8   344 _SPI0_STAT	=	0x00f8
                           0000F9   345 _SPI0_DATA	=	0x00f9
                           0000FA   346 _SPI0_CTRL	=	0x00fa
                           0000FB   347 _SPI0_CK_SE	=	0x00fb
                           0000FC   348 _SPI0_SETUP	=	0x00fc
                           0000BC   349 _SCON1	=	0x00bc
                           0000BD   350 _SBUF1	=	0x00bd
                           0000BE   351 _SBAUD1	=	0x00be
                           0000BF   352 _SIF1	=	0x00bf
                           0000B4   353 _SPI1_STAT	=	0x00b4
                           0000B5   354 _SPI1_DATA	=	0x00b5
                           0000B6   355 _SPI1_CTRL	=	0x00b6
                           0000B7   356 _SPI1_CK_SE	=	0x00b7
                           0000F3   357 _ADC_CTRL	=	0x00f3
                           00F5F4   358 _ADC_DAT	=	0xf5f4
                           0000F4   359 _ADC_DAT_L	=	0x00f4
                           0000F5   360 _ADC_DAT_H	=	0x00f5
                           0000F6   361 _ADC_CHAN	=	0x00f6
                           0000A6   362 _LED_COMMON	=	0x00a6
                           0000A7   363 _LED_PWM_OE	=	0x00a7
                           00C7C6   364 _LED_DMA	=	0xc7c6
                           0000C6   365 _LED_DMA_L	=	0x00c6
                           0000C7   366 _LED_DMA_H	=	0x00c7
                           0000F7   367 _LED_STATUS	=	0x00f7
                           0000B3   368 _I2CX_INT	=	0x00b3
                           0000BB   369 _I2CS_INT_ST	=	0x00bb
                                    370 ;--------------------------------------------------------
                                    371 ; special function bits
                                    372 ;--------------------------------------------------------
                                    373 	.area RSEG    (ABS,DATA)
      000000                        374 	.org 0x0000
                           0000D7   375 _CY	=	0x00d7
                           0000D6   376 _AC	=	0x00d6
                           0000D5   377 _F0	=	0x00d5
                           0000D4   378 _RS1	=	0x00d4
                           0000D3   379 _RS0	=	0x00d3
                           0000D2   380 _OV	=	0x00d2
                           0000D1   381 _F1	=	0x00d1
                           0000D0   382 _P	=	0x00d0
                           0000AF   383 _EA	=	0x00af
                           0000AE   384 _E_DIS	=	0x00ae
                           0000AD   385 _ET2	=	0x00ad
                           0000AC   386 _ES	=	0x00ac
                           0000AB   387 _ET1	=	0x00ab
                           0000AA   388 _EX1	=	0x00aa
                           0000A9   389 _ET0	=	0x00a9
                           0000A8   390 _EX0	=	0x00a8
                           0000BF   391 _PH_FLAG	=	0x00bf
                           0000BE   392 _PL_FLAG	=	0x00be
                           0000BD   393 _PT2	=	0x00bd
                           0000BC   394 _PS	=	0x00bc
                           0000BB   395 _PT1	=	0x00bb
                           0000BA   396 _PX1	=	0x00ba
                           0000B9   397 _PT0	=	0x00b9
                           0000B8   398 _PX0	=	0x00b8
                           0000EF   399 _IE_WDOG	=	0x00ef
                           0000EE   400 _IE_GPIO	=	0x00ee
                           0000ED   401 _IE_PWM_I2C	=	0x00ed
                           0000EC   402 _IE_UART1	=	0x00ec
                           0000EB   403 _IE_ADC	=	0x00eb
                           0000E9   404 _IE_USB	=	0x00e9
                           0000E8   405 _IE_SPI0	=	0x00e8
                           000087   406 _P0_7	=	0x0087
                           000086   407 _P0_6	=	0x0086
                           000085   408 _P0_5	=	0x0085
                           000084   409 _P0_4	=	0x0084
                           000083   410 _P0_3	=	0x0083
                           000082   411 _P0_2	=	0x0082
                           000081   412 _P0_1	=	0x0081
                           000080   413 _P0_0	=	0x0080
                           000081   414 _SDA0	=	0x0081
                           000080   415 _SCL0	=	0x0080
                           000083   416 _TXD_	=	0x0083
                           000082   417 _RXD_	=	0x0082
                           000085   418 _AIN13	=	0x0085
                           000084   419 _AIN12	=	0x0084
                           000083   420 _AIN11	=	0x0083
                           000082   421 _AIN10	=	0x0082
                           000081   422 _AIN9	=	0x0081
                           000080   423 _AIN8	=	0x0080
                           000097   424 _P1_7	=	0x0097
                           000096   425 _P1_6	=	0x0096
                           000095   426 _P1_5	=	0x0095
                           000094   427 _P1_4	=	0x0094
                           000093   428 _P1_3	=	0x0093
                           000092   429 _P1_2	=	0x0092
                           000091   430 _P1_1	=	0x0091
                           000090   431 _P1_0	=	0x0090
                           000097   432 _TXD1_	=	0x0097
                           000096   433 _RXD1_	=	0x0096
                           000097   434 _SCK	=	0x0097
                           000096   435 _MISO	=	0x0096
                           000095   436 _MOSI	=	0x0095
                           000094   437 _SCS	=	0x0094
                           000092   438 _INT0_	=	0x0092
                           000091   439 _T2EX	=	0x0091
                           000091   440 _CAP2	=	0x0091
                           000090   441 _T2	=	0x0090
                           000090   442 _CAP1	=	0x0090
                           000097   443 _AIN7	=	0x0097
                           000096   444 _AIN6	=	0x0096
                           000095   445 _AIN5	=	0x0095
                           000094   446 _AIN4	=	0x0094
                           000093   447 _AIN3	=	0x0093
                           000092   448 _AIN2	=	0x0092
                           000091   449 _AIN1	=	0x0091
                           000090   450 _AIN0	=	0x0090
                           0000A7   451 _P2_7	=	0x00a7
                           0000A6   452 _P2_6	=	0x00a6
                           0000A5   453 _P2_5	=	0x00a5
                           0000A4   454 _P2_4	=	0x00a4
                           0000A3   455 _P2_3	=	0x00a3
                           0000A2   456 _P2_2	=	0x00a2
                           0000A1   457 _P2_1	=	0x00a1
                           0000A0   458 _P2_0	=	0x00a0
                           0000A7   459 _TXD1	=	0x00a7
                           0000A6   460 _RXD1	=	0x00a6
                           0000A5   461 _T2EX_	=	0x00a5
                           0000A5   462 _CAP2_	=	0x00a5
                           0000A4   463 _T2_	=	0x00a4
                           0000A4   464 _CAP1_	=	0x00a4
                           0000B7   465 _P3_7	=	0x00b7
                           0000B6   466 _P3_6	=	0x00b6
                           0000B5   467 _P3_5	=	0x00b5
                           0000B4   468 _P3_4	=	0x00b4
                           0000B3   469 _P3_3	=	0x00b3
                           0000B2   470 _P3_2	=	0x00b2
                           0000B1   471 _P3_1	=	0x00b1
                           0000B0   472 _P3_0	=	0x00b0
                           0000B7   473 _SCK1	=	0x00b7
                           0000B6   474 _MISO1	=	0x00b6
                           0000B5   475 _MOSI1	=	0x00b5
                           0000B5   476 _T1	=	0x00b5
                           0000B4   477 _T0	=	0x00b4
                           0000B3   478 _INT1	=	0x00b3
                           0000B2   479 _INT0	=	0x00b2
                           0000B1   480 _TXD	=	0x00b1
                           0000B0   481 _RXD	=	0x00b0
                           0000C6   482 _P4_6	=	0x00c6
                           0000C5   483 _P4_5	=	0x00c5
                           0000C4   484 _P4_4	=	0x00c4
                           0000C3   485 _P4_3	=	0x00c3
                           0000C2   486 _P4_2	=	0x00c2
                           0000C1   487 _P4_1	=	0x00c1
                           0000C0   488 _P4_0	=	0x00c0
                           00008F   489 _TF1	=	0x008f
                           00008E   490 _TR1	=	0x008e
                           00008D   491 _TF0	=	0x008d
                           00008C   492 _TR0	=	0x008c
                           00008B   493 _IE1	=	0x008b
                           00008A   494 _IT1	=	0x008a
                           000089   495 _IE0	=	0x0089
                           000088   496 _IT0	=	0x0088
                           00009F   497 _SM0	=	0x009f
                           00009E   498 _SM1	=	0x009e
                           00009D   499 _SM2	=	0x009d
                           00009C   500 _REN	=	0x009c
                           00009B   501 _TB8	=	0x009b
                           00009A   502 _RB8	=	0x009a
                           000099   503 _TI	=	0x0099
                           000098   504 _RI	=	0x0098
                           0000CF   505 _TF2	=	0x00cf
                           0000CF   506 _CAP1F	=	0x00cf
                           0000CE   507 _EXF2	=	0x00ce
                           0000CD   508 _RCLK	=	0x00cd
                           0000CC   509 _TCLK	=	0x00cc
                           0000CB   510 _EXEN2	=	0x00cb
                           0000CA   511 _TR2	=	0x00ca
                           0000C9   512 _C_T2	=	0x00c9
                           0000C8   513 _CP_RL2	=	0x00c8
                           0000FF   514 _S0_FST_ACT	=	0x00ff
                           0000FE   515 _S0_IF_OV	=	0x00fe
                           0000FD   516 _S0_IF_FIRST	=	0x00fd
                           0000FC   517 _S0_IF_BYTE	=	0x00fc
                           0000FB   518 _S0_FREE	=	0x00fb
                           0000FA   519 _S0_T_FIFO	=	0x00fa
                           0000F8   520 _S0_R_FIFO	=	0x00f8
                           0000F7   521 _ADC_START	=	0x00f7
                                    522 ;--------------------------------------------------------
                                    523 ; overlayable register banks
                                    524 ;--------------------------------------------------------
                                    525 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        526 	.ds 8
                                    527 ;--------------------------------------------------------
                                    528 ; internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area DSEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; overlayable items in internal ram
                                    533 ;--------------------------------------------------------
                                    534 	.area	OSEG    (OVR,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; indirectly addressable internal ram data
                                    537 ;--------------------------------------------------------
                                    538 	.area ISEG    (DATA)
                                    539 ;--------------------------------------------------------
                                    540 ; absolute internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area IABS    (ABS,DATA)
                                    543 	.area IABS    (ABS,DATA)
                                    544 ;--------------------------------------------------------
                                    545 ; bit data
                                    546 ;--------------------------------------------------------
                                    547 	.area BSEG    (BIT)
                                    548 ;--------------------------------------------------------
                                    549 ; paged external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area PSEG    (PAG,XDATA)
                                    552 ;--------------------------------------------------------
                                    553 ; uninitialized external ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area XSEG    (XDATA)
      000819                        556 _KEYCODE2CONSUMER_key_10000_118:
      000819                        557 	.ds 1
      00081A                        558 _add_key_byte_PARM_2:
      00081A                        559 	.ds 1
      00081B                        560 _add_key_byte_report_arg_10000_145:
      00081B                        561 	.ds 2
      00081D                        562 _add_key_byte_empty_10000_146:
      00081D                        563 	.ds 1
      00081E                        564 _del_key_byte_PARM_2:
      00081E                        565 	.ds 1
      00081F                        566 _del_key_byte_report_arg_10000_157:
      00081F                        567 	.ds 2
      000821                        568 _add_key_bit_PARM_2:
      000821                        569 	.ds 1
      000822                        570 _add_key_bit_report_arg_10000_163:
      000822                        571 	.ds 2
      000824                        572 _del_key_bit_PARM_2:
      000824                        573 	.ds 1
      000825                        574 _del_key_bit_report_arg_10000_168:
      000825                        575 	.ds 2
      000827                        576 _add_key_to_report_PARM_2:
      000827                        577 	.ds 1
      000828                        578 _add_key_to_report_report_arg_10000_173:
      000828                        579 	.ds 2
      00082A                        580 _del_key_from_report_PARM_2:
      00082A                        581 	.ds 1
      00082B                        582 _del_key_from_report_report_arg_10000_177:
      00082B                        583 	.ds 2
      00082D                        584 _clear_keys_from_report_report_arg_10000_181:
      00082D                        585 	.ds 2
                                    586 ;--------------------------------------------------------
                                    587 ; absolute external ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area XABS    (ABS,XDATA)
                                    590 ;--------------------------------------------------------
                                    591 ; initialized external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area XISEG   (XDATA)
                                    594 	.area HOME    (CODE)
                                    595 	.area GSINIT0 (CODE)
                                    596 	.area GSINIT1 (CODE)
                                    597 	.area GSINIT2 (CODE)
                                    598 	.area GSINIT3 (CODE)
                                    599 	.area GSINIT4 (CODE)
                                    600 	.area GSINIT5 (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 	.area GSFINAL (CODE)
                                    603 	.area CSEG    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; global & static initialisations
                                    606 ;--------------------------------------------------------
                                    607 	.area HOME    (CODE)
                                    608 	.area GSINIT  (CODE)
                                    609 	.area GSFINAL (CODE)
                                    610 	.area GSINIT  (CODE)
                                    611 ;--------------------------------------------------------
                                    612 ; Home
                                    613 ;--------------------------------------------------------
                                    614 	.area HOME    (CODE)
                                    615 	.area HOME    (CODE)
                                    616 ;--------------------------------------------------------
                                    617 ; code
                                    618 ;--------------------------------------------------------
                                    619 	.area CSEG    (CODE)
                                    620 ;------------------------------------------------------------
                                    621 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    622 ;------------------------------------------------------------
                                    623 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    624 ;------------------------------------------------------------
                                    625 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    626 ;	-----------------------------------------
                           000007   627 	ar7 = 0x07
                           000006   628 	ar6 = 0x06
                           000005   629 	ar5 = 0x05
                           000004   630 	ar4 = 0x04
                           000003   631 	ar3 = 0x03
                           000002   632 	ar2 = 0x02
                           000001   633 	ar1 = 0x01
                           000000   634 	ar0 = 0x00
                                    635 ;	 function KEYCODE2CONSUMER
                                    636 ;	-----------------------------------------
      0071D9                        637 _KEYCODE2CONSUMER:
      0071D9 E5 82            [12]  638 	mov	a,dpl
      0071DB 90 08 19         [24]  639 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_118
      0071DE F0               [24]  640 	movx	@dptr,a
                                    641 ;	tmk_core/protocol/report.c:43: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      0071DF E0               [24]  642 	movx	a,@dptr
      0071E0 FF               [12]  643 	mov	r7,a
      0071E1 BF A8 00         [24]  644 	cjne	r7,#0xa8,00113$
      0071E4                        645 00113$:
      0071E4 40 05            [24]  646 	jc	00101$
      0071E6 EF               [12]  647 	mov	a,r7
      0071E7 24 3D            [12]  648 	add	a,#0xff - 0xc2
      0071E9 50 04            [24]  649 	jnc	00102$
                                    650 ;	free result
      0071EB                        651 00101$:
      0071EB 90 00 00         [24]  652 	mov	dptr,#0x0000
      0071EE 22               [24]  653 	ret
      0071EF                        654 00102$:
                                    655 ;	tmk_core/protocol/report.c:44: return usages[key - KC_AUDIO_MUTE];
      0071EF EF               [12]  656 	mov	a,r7
      0071F0 24 58            [12]  657 	add	a,#0x58
      0071F2 FF               [12]  658 	mov	r7,a
      0071F3 C2 D5            [12]  659 	clr	F0
      0071F5 75 F0 02         [24]  660 	mov	b,#0x02
      0071F8 EF               [12]  661 	mov	a,r7
      0071F9 30 E7 04         [24]  662 	jnb	acc.7,00116$
      0071FC B2 D5            [12]  663 	cpl	F0
      0071FE F4               [12]  664 	cpl	a
      0071FF 04               [12]  665 	inc	a
      007200                        666 00116$:
      007200 A4               [48]  667 	mul	ab
      007201 30 D5 03         [24]  668 	jnb	F0,00117$
      007204 12 73 E9         [24]  669 	lcall	_ak820_outline_0127
      007207                        670 00117$:
      007207 24 B5            [12]  671 	add	a, #_KEYCODE2CONSUMER_usages_10000_119
      007209 F5 82            [12]  672 	mov	dpl,a
      00720B 74 BC            [12]  673 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_119 >> 8)
      00720D 12 5B 7A         [24]  674 	lcall	_ak820_outline_0105
      007210 FE               [12]  675 	mov	r6,a
      007211 A3               [24]  676 	inc	dptr
      007212 E4               [12]  677 	clr	a
      007213 93               [24]  678 	movc	a,@a+dptr
                                    679 ;	tmk_core/protocol/report.c:45: }
      007214 8E 82            [24]  680 	mov	dpl,r6
      007216 F5 83            [12]  681 	mov	dph,a
      007218 22               [24]  682 	ret
                                    683 ;------------------------------------------------------------
                                    684 ;Allocation info for local variables in function 'has_anykey'
                                    685 ;------------------------------------------------------------
                                    686 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_121'
                                    687 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_122'
                                    688 ;cnt           Allocated with name '_has_anykey_cnt_10000_122'
                                    689 ;p             Allocated with name '_has_anykey_p_10000_122'
                                    690 ;lp            Allocated with name '_has_anykey_lp_10000_122'
                                    691 ;------------------------------------------------------------
                                    692 ;	tmk_core/protocol/report.c:62: uint8_t has_anykey(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                    693 ;	-----------------------------------------
                                    694 ;	 function add_key_byte
                                    695 ;	-----------------------------------------
      007219                        696 _add_key_byte:
      007219 12 3A 8A         [24]  697 	lcall	_ak820_outline_0103
      00721C 90 08 1B         [24]  698 	mov	dptr,#_add_key_byte_report_arg_10000_145
      00721F 12 3A 8F         [24]  699 	lcall	_ak820_outline_0104
                                    700 ;	tmk_core/protocol/report.c:139: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007222 90 08 1B         [24]  701 	mov	dptr,#_add_key_byte_report_arg_10000_145
      007225 12 3A 47         [24]  702 	lcall	_ak820_outline_0050
                                    703 ;	tmk_core/protocol/report.c:185: int8_t empty = -1;
      007228 90 08 1D         [24]  704 	mov	dptr,#_add_key_byte_empty_10000_146
      00722B 74 FF            [12]  705 	mov	a,#0xff
      00722D F0               [24]  706 	movx	@dptr,a
                                    707 ;	tmk_core/protocol/report.c:200: }
      00722E 7D 00            [12]  708 	mov	r5,#0x00
      007230                        709 00112$:
                                    710 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      007230 C3               [12]  711 	clr	c
      007231 ED               [12]  712 	mov	a,r5
      007232 64 80            [12]  713 	xrl	a,#0x80
      007234 94 86            [12]  714 	subb	a,#0x86
      007236 50 29            [24]  715 	jnc	00106$
                                    716 ;	tmk_core/protocol/report.c:187: if (keyboard_report->keys[i] == code) {
      007238 12 73 F4         [24]  717 	lcall	_ak820_outline_0143
      00723B F5 82            [12]  718 	mov	dpl,a
      00723D E4               [12]  719 	clr	a
      00723E 3C               [12]  720 	addc	a, r4
      00723F F5 83            [12]  721 	mov	dph,a
      007241 E0               [24]  722 	movx	a,@dptr
      007242 FC               [12]  723 	mov	r4,a
      007243 90 08 1A         [24]  724 	mov	dptr,#_add_key_byte_PARM_2
      007246 E0               [24]  725 	movx	a,@dptr
      007247 FB               [12]  726 	mov	r3,a
      007248 EC               [12]  727 	mov	a,r4
      007249 B5 03 02         [24]  728 	cjne	a,ar3,00167$
      00724C 80 13            [24]  729 	sjmp	00106$
      00724E                        730 00167$:
                                    731 ;	tmk_core/protocol/report.c:190: if (empty == -1 && keyboard_report->keys[i] == 0) {
      00724E 90 08 1D         [24]  732 	mov	dptr,#_add_key_byte_empty_10000_146
      007251 E0               [24]  733 	movx	a,@dptr
      007252 FB               [12]  734 	mov	r3,a
      007253 BB FF 08         [24]  735 	cjne	r3,#0xff,00113$
      007256 EC               [12]  736 	mov	a,r4
      007257 70 05            [24]  737 	jnz	00113$
                                    738 ;	tmk_core/protocol/report.c:191: empty = i;
      007259 90 08 1D         [24]  739 	mov	dptr,#_add_key_byte_empty_10000_146
      00725C ED               [12]  740 	mov	a,r5
      00725D F0               [24]  741 	movx	@dptr,a
      00725E                        742 00113$:
                                    743 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      00725E 0D               [12]  744 	inc	r5
      00725F 80 CF            [24]  745 	sjmp	00112$
      007261                        746 00106$:
                                    747 ;	tmk_core/protocol/report.c:194: if (i == KEYBOARD_REPORT_KEYS) {
      007261 BD 06 1D         [24]  748 	cjne	r5,#0x06,00114$
                                    749 ;	tmk_core/protocol/report.c:195: if (empty != -1) {
      007264 90 08 1D         [24]  750 	mov	dptr,#_add_key_byte_empty_10000_146
      007267 E0               [24]  751 	movx	a,@dptr
      007268 FD               [12]  752 	mov	r5,a
      007269 BD FF 01         [24]  753 	cjne	r5,#0xff,00173$
      00726C 22               [24]  754 	ret
      00726D                        755 00173$:
                                    756 ;	tmk_core/protocol/report.c:196: keyboard_report->keys[empty] = code;
      00726D 74 02            [12]  757 	mov	a,#0x02
      00726F 12 45 76         [24]  758 	lcall	_ak820_outline_0133
      007272 ED               [12]  759 	mov	a,r5
      007273 2E               [12]  760 	add	a, r6
      007274 FD               [12]  761 	mov	r5,a
      007275 E4               [12]  762 	clr	a
      007276 3F               [12]  763 	addc	a, r7
      007277 FC               [12]  764 	mov	r4,a
      007278 90 08 1A         [24]  765 	mov	dptr,#_add_key_byte_PARM_2
      00727B E0               [24]  766 	movx	a,@dptr
      00727C 8D 82            [24]  767 	mov	dpl,r5
      00727E 8C 83            [24]  768 	mov	dph,r4
      007280 F0               [24]  769 	movx	@dptr,a
      007281                        770 00114$:
                                    771 ;	tmk_core/protocol/report.c:200: }
      007281 22               [24]  772 	ret
                                    773 ;------------------------------------------------------------
                                    774 ;Allocation info for local variables in function 'del_key_byte'
                                    775 ;------------------------------------------------------------
                                    776 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    777 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_157'
                                    778 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_158'
                                    779 ;i             Allocated with name '_del_key_byte_i_20000_159'
                                    780 ;------------------------------------------------------------
                                    781 ;	tmk_core/protocol/report.c:206: void del_key_byte(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    782 ;	-----------------------------------------
                                    783 ;	 function del_key_byte
                                    784 ;	-----------------------------------------
      007282                        785 _del_key_byte:
      007282 12 3A 8A         [24]  786 	lcall	_ak820_outline_0103
      007285 90 08 1F         [24]  787 	mov	dptr,#_del_key_byte_report_arg_10000_157
      007288 12 3A 8F         [24]  788 	lcall	_ak820_outline_0104
                                    789 ;	tmk_core/protocol/report.c:207: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00728B 90 08 1F         [24]  790 	mov	dptr,#_del_key_byte_report_arg_10000_157
      00728E 12 3A 47         [24]  791 	lcall	_ak820_outline_0050
                                    792 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      007291 7D 00            [12]  793 	mov	r5,#0x00
      007293                        794 00105$:
      007293 BD 06 00         [24]  795 	cjne	r5,#0x06,00131$
      007296                        796 00131$:
      007296 50 1A            [24]  797 	jnc	00107$
                                    798 ;	tmk_core/protocol/report.c:235: if (keyboard_report->keys[i] == code) {
      007298 12 73 F4         [24]  799 	lcall	_ak820_outline_0143
      00729B FB               [12]  800 	mov	r3,a
      00729C E4               [12]  801 	clr	a
      00729D 3C               [12]  802 	addc	a, r4
      00729E 12 4A 7F         [24]  803 	lcall	_ak820_outline_0055
      0072A1 90 08 1E         [24]  804 	mov	dptr,#_del_key_byte_PARM_2
      0072A4 E0               [24]  805 	movx	a,@dptr
      0072A5 F9               [12]  806 	mov	r1,a
      0072A6 EA               [12]  807 	mov	a,r2
      0072A7 B5 01 05         [24]  808 	cjne	a,ar1,00106$
                                    809 ;	tmk_core/protocol/report.c:236: keyboard_report->keys[i] = 0;
      0072AA 12 36 42         [24]  810 	lcall	_ak820_outline_0121
      0072AD E4               [12]  811 	clr	a
      0072AE F0               [24]  812 	movx	@dptr,a
      0072AF                        813 00106$:
                                    814 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      0072AF 0D               [12]  815 	inc	r5
      0072B0 80 E1            [24]  816 	sjmp	00105$
      0072B2                        817 00107$:
                                    818 ;	tmk_core/protocol/report.c:240: }
      0072B2 22               [24]  819 	ret
                                    820 ;------------------------------------------------------------
                                    821 ;Allocation info for local variables in function 'add_key_bit'
                                    822 ;------------------------------------------------------------
                                    823 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    824 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_163'
                                    825 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_164'
                                    826 ;------------------------------------------------------------
                                    827 ;	tmk_core/protocol/report.c:247: void add_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function add_key_bit
                                    830 ;	-----------------------------------------
      0072B3                        831 _add_key_bit:
      0072B3 12 3A 8A         [24]  832 	lcall	_ak820_outline_0103
      0072B6 90 08 22         [24]  833 	mov	dptr,#_add_key_bit_report_arg_10000_163
      0072B9 12 3A 8F         [24]  834 	lcall	_ak820_outline_0104
                                    835 ;	tmk_core/protocol/report.c:248: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0072BC 90 08 22         [24]  836 	mov	dptr,#_add_key_bit_report_arg_10000_163
      0072BF 12 3A 47         [24]  837 	lcall	_ak820_outline_0050
                                    838 ;	tmk_core/protocol/report.c:249: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      0072C2 90 08 21         [24]  839 	mov	dptr,#_add_key_bit_PARM_2
      0072C5 E0               [24]  840 	movx	a,@dptr
      0072C6 FD               [12]  841 	mov	r5,a
      0072C7 12 5B B0         [24]  842 	lcall	_ak820_outline_0182
      0072CA FC               [12]  843 	mov	r4,a
      0072CB BC 1E 00         [24]  844 	cjne	r4,#0x1e,00112$
      0072CE                        845 00112$:
      0072CE 50 16            [24]  846 	jnc	00103$
                                    847 ;	tmk_core/protocol/report.c:250: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      0072D0 12 73 D2         [24]  848 	lcall	_ak820_outline_0031
      0072D3 80 02            [24]  849 	sjmp	00115$
      0072D5                        850 00114$:
      0072D5 25 E0            [12]  851 	add	a,acc
      0072D7                        852 00115$:
      0072D7 D5 F0 FB         [24]  853 	djnz	b,00114$
      0072DA FF               [12]  854 	mov	r7,a
      0072DB 12 45 A2         [24]  855 	lcall	_ak820_outline_0179
      0072DE E0               [24]  856 	movx	a,@dptr
      0072DF 42 07            [12]  857 	orl	ar7,a
      0072E1 12 45 A2         [24]  858 	lcall	_ak820_outline_0179
      0072E4 EF               [12]  859 	mov	a,r7
      0072E5 F0               [24]  860 	movx	@dptr,a
      0072E6                        861 00103$:
                                    862 ;	tmk_core/protocol/report.c:254: }
      0072E6 22               [24]  863 	ret
                                    864 ;------------------------------------------------------------
                                    865 ;Allocation info for local variables in function 'del_key_bit'
                                    866 ;------------------------------------------------------------
                                    867 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    868 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_168'
                                    869 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_169'
                                    870 ;------------------------------------------------------------
                                    871 ;	tmk_core/protocol/report.c:260: void del_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    872 ;	-----------------------------------------
                                    873 ;	 function del_key_bit
                                    874 ;	-----------------------------------------
      0072E7                        875 _del_key_bit:
      0072E7 12 3A 8A         [24]  876 	lcall	_ak820_outline_0103
      0072EA 90 08 25         [24]  877 	mov	dptr,#_del_key_bit_report_arg_10000_168
      0072ED 12 3A 8F         [24]  878 	lcall	_ak820_outline_0104
                                    879 ;	tmk_core/protocol/report.c:261: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0072F0 90 08 25         [24]  880 	mov	dptr,#_del_key_bit_report_arg_10000_168
      0072F3 12 3A 47         [24]  881 	lcall	_ak820_outline_0050
                                    882 ;	tmk_core/protocol/report.c:262: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      0072F6 90 08 24         [24]  883 	mov	dptr,#_del_key_bit_PARM_2
      0072F9 E0               [24]  884 	movx	a,@dptr
      0072FA FD               [12]  885 	mov	r5,a
      0072FB 12 5B B0         [24]  886 	lcall	_ak820_outline_0182
      0072FE FC               [12]  887 	mov	r4,a
      0072FF BC 1E 00         [24]  888 	cjne	r4,#0x1e,00112$
      007302                        889 00112$:
      007302 50 17            [24]  890 	jnc	00103$
                                    891 ;	tmk_core/protocol/report.c:263: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      007304 12 73 D2         [24]  892 	lcall	_ak820_outline_0031
      007307 80 02            [24]  893 	sjmp	00115$
      007309                        894 00114$:
      007309 25 E0            [12]  895 	add	a,acc
      00730B                        896 00115$:
      00730B D5 F0 FB         [24]  897 	djnz	b,00114$
      00730E F4               [12]  898 	cpl	a
      00730F FF               [12]  899 	mov	r7,a
      007310 12 45 A2         [24]  900 	lcall	_ak820_outline_0179
      007313 E0               [24]  901 	movx	a,@dptr
      007314 52 07            [12]  902 	anl	ar7,a
      007316 12 45 A2         [24]  903 	lcall	_ak820_outline_0179
      007319 EF               [12]  904 	mov	a,r7
      00731A F0               [24]  905 	movx	@dptr,a
      00731B                        906 00103$:
                                    907 ;	tmk_core/protocol/report.c:267: }
      00731B 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'add_key_to_report'
                                    911 ;------------------------------------------------------------
                                    912 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    913 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_173'
                                    914 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_174'
                                    915 ;------------------------------------------------------------
                                    916 ;	tmk_core/protocol/report.c:274: void add_key_to_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    917 ;	-----------------------------------------
                                    918 ;	 function add_key_to_report
                                    919 ;	-----------------------------------------
      00731C                        920 _add_key_to_report:
      00731C 12 3A 8A         [24]  921 	lcall	_ak820_outline_0103
      00731F 90 08 28         [24]  922 	mov	dptr,#_add_key_to_report_report_arg_10000_173
      007322 12 3A 8F         [24]  923 	lcall	_ak820_outline_0104
                                    924 ;	tmk_core/protocol/report.c:275: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007325 90 08 28         [24]  925 	mov	dptr,#_add_key_to_report_report_arg_10000_173
      007328 12 3A 47         [24]  926 	lcall	_ak820_outline_0050
                                    927 ;	tmk_core/protocol/report.c:277: if (keyboard_protocol && keymap_config.nkro) {
      00732B 90 0D B1         [24]  928 	mov	dptr,#_keyboard_protocol
      00732E E0               [24]  929 	movx	a,@dptr
      00732F 60 14            [24]  930 	jz	00102$
      007331 90 0A E2         [24]  931 	mov	dptr,#_keymap_config
      007334 E0               [24]  932 	movx	a,@dptr
      007335 30 E7 0D         [24]  933 	jnb	acc.7,00102$
                                    934 ;	tmk_core/protocol/report.c:278: add_key_bit(keyboard_report, key);
      007338 90 08 27         [24]  935 	mov	dptr,#_add_key_to_report_PARM_2
      00733B E0               [24]  936 	movx	a,@dptr
      00733C 90 08 21         [24]  937 	mov	dptr,#_add_key_bit_PARM_2
      00733F 12 45 41         [24]  938 	lcall	_ak820_outline_0060
                                    939 ;	tmk_core/protocol/report.c:279: return;
      007342 02 72 B3         [24]  940 	ljmp	_add_key_bit
      007345                        941 00102$:
                                    942 ;	tmk_core/protocol/report.c:282: add_key_byte(keyboard_report, key);
      007345 90 08 27         [24]  943 	mov	dptr,#_add_key_to_report_PARM_2
      007348 E0               [24]  944 	movx	a,@dptr
      007349 90 08 1A         [24]  945 	mov	dptr,#_add_key_byte_PARM_2
      00734C 12 45 41         [24]  946 	lcall	_ak820_outline_0060
                                    947 ;	tmk_core/protocol/report.c:283: }
      00734F 02 72 19         [24]  948 	ljmp	_add_key_byte
                                    949 ;------------------------------------------------------------
                                    950 ;Allocation info for local variables in function 'del_key_from_report'
                                    951 ;------------------------------------------------------------
                                    952 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    953 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_177'
                                    954 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_178'
                                    955 ;------------------------------------------------------------
                                    956 ;	tmk_core/protocol/report.c:289: void del_key_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function del_key_from_report
                                    959 ;	-----------------------------------------
      007352                        960 _del_key_from_report:
      007352 12 3A 8A         [24]  961 	lcall	_ak820_outline_0103
      007355 90 08 2B         [24]  962 	mov	dptr,#_del_key_from_report_report_arg_10000_177
      007358 12 3A 8F         [24]  963 	lcall	_ak820_outline_0104
                                    964 ;	tmk_core/protocol/report.c:290: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00735B 90 08 2B         [24]  965 	mov	dptr,#_del_key_from_report_report_arg_10000_177
      00735E 12 3A 47         [24]  966 	lcall	_ak820_outline_0050
                                    967 ;	tmk_core/protocol/report.c:292: if (keyboard_protocol && keymap_config.nkro) {
      007361 90 0D B1         [24]  968 	mov	dptr,#_keyboard_protocol
      007364 E0               [24]  969 	movx	a,@dptr
      007365 60 14            [24]  970 	jz	00102$
      007367 90 0A E2         [24]  971 	mov	dptr,#_keymap_config
      00736A E0               [24]  972 	movx	a,@dptr
      00736B 30 E7 0D         [24]  973 	jnb	acc.7,00102$
                                    974 ;	tmk_core/protocol/report.c:293: del_key_bit(keyboard_report, key);
      00736E 90 08 2A         [24]  975 	mov	dptr,#_del_key_from_report_PARM_2
      007371 E0               [24]  976 	movx	a,@dptr
      007372 90 08 24         [24]  977 	mov	dptr,#_del_key_bit_PARM_2
      007375 12 45 41         [24]  978 	lcall	_ak820_outline_0060
                                    979 ;	tmk_core/protocol/report.c:294: return;
      007378 02 72 E7         [24]  980 	ljmp	_del_key_bit
      00737B                        981 00102$:
                                    982 ;	tmk_core/protocol/report.c:297: del_key_byte(keyboard_report, key);
      00737B 90 08 2A         [24]  983 	mov	dptr,#_del_key_from_report_PARM_2
      00737E E0               [24]  984 	movx	a,@dptr
      00737F 90 08 1E         [24]  985 	mov	dptr,#_del_key_byte_PARM_2
      007382 12 45 41         [24]  986 	lcall	_ak820_outline_0060
                                    987 ;	tmk_core/protocol/report.c:298: }
      007385 02 72 82         [24]  988 	ljmp	_del_key_byte
                                    989 ;------------------------------------------------------------
                                    990 ;Allocation info for local variables in function 'clear_keys_from_report'
                                    991 ;------------------------------------------------------------
                                    992 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_181'
                                    993 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_182'
                                    994 ;------------------------------------------------------------
                                    995 ;	tmk_core/protocol/report.c:304: void clear_keys_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                    996 ;	-----------------------------------------
                                    997 ;	 function clear_keys_from_report
                                    998 ;	-----------------------------------------
      007388                        999 _clear_keys_from_report:
      007388 12 3A 8A         [24] 1000 	lcall	_ak820_outline_0103
      00738B 90 08 2D         [24] 1001 	mov	dptr,#_clear_keys_from_report_report_arg_10000_181
      00738E 12 3A 8F         [24] 1002 	lcall	_ak820_outline_0104
                                   1003 ;	tmk_core/protocol/report.c:305: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007391 90 08 2D         [24] 1004 	mov	dptr,#_clear_keys_from_report_report_arg_10000_181
      007394 12 3A 47         [24] 1005 	lcall	_ak820_outline_0050
                                   1006 ;	tmk_core/protocol/report.c:308: if (keyboard_protocol && keymap_config.nkro) {
      007397 90 0D B1         [24] 1007 	mov	dptr,#_keyboard_protocol
      00739A E0               [24] 1008 	movx	a,@dptr
      00739B 60 1E            [24] 1009 	jz	00102$
      00739D 90 0A E2         [24] 1010 	mov	dptr,#_keymap_config
      0073A0 E0               [24] 1011 	movx	a,@dptr
      0073A1 30 E7 17         [24] 1012 	jnb	acc.7,00102$
                                   1013 ;	tmk_core/protocol/report.c:309: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      0073A4 74 02            [12] 1014 	mov	a,#0x02
      0073A6 12 45 91         [24] 1015 	lcall	_ak820_outline_0157
      0073A9 7B 00            [12] 1016 	mov	r3,#0x00
      0073AB 12 73 FE         [24] 1017 	lcall	_ak820_outline_0176
      0073AE 74 1E            [12] 1018 	mov	a,#0x1e
      0073B0 12 3A A6         [24] 1019 	lcall	_ak820_outline_0122
      0073B3 12 3A 9B         [24] 1020 	lcall	_ak820_outline_0117
      0073B6 8B F0            [24] 1021 	mov	b, r3
                                   1022 ;	tmk_core/protocol/report.c:310: return;
      0073B8 02 BB A6         [24] 1023 	ljmp	_memset
      0073BB                       1024 00102$:
                                   1025 ;	tmk_core/protocol/report.c:313: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      0073BB 74 02            [12] 1026 	mov	a,#0x02
      0073BD 12 45 76         [24] 1027 	lcall	_ak820_outline_0133
      0073C0 7D 00            [12] 1028 	mov	r5,#0x00
      0073C2 12 73 FE         [24] 1029 	lcall	_ak820_outline_0176
      0073C5 74 06            [12] 1030 	mov	a,#0x06
      0073C7 F0               [24] 1031 	movx	@dptr,a
      0073C8 E4               [12] 1032 	clr	a
      0073C9 A3               [24] 1033 	inc	dptr
      0073CA 12 45 41         [24] 1034 	lcall	_ak820_outline_0060
      0073CD 8D F0            [24] 1035 	mov	b, r5
                                   1036 ;	tmk_core/protocol/report.c:314: }
      0073CF 02 BB A6         [24] 1037 	ljmp	_memset
                                   1038 ;------------------------------------------------------------
                                   1039 ;Allocation info for local variables in function 'has_mouse_report_changed'
                                   1040 ;------------------------------------------------------------
                                   1041 ;old_report    Allocated with name '_has_mouse_report_changed_PARM_2'
                                   1042 ;new_report    Allocated with name '_has_mouse_report_changed_new_report_10000_185'
                                   1043 ;changed       Allocated with name '_has_mouse_report_changed_changed_10000_186'
                                   1044 ;sloc0         Allocated with name '_has_mouse_report_changed_sloc0_1_0'
                                   1045 ;sloc1         Allocated with name '_has_mouse_report_changed_sloc1_1_0'
                                   1046 ;------------------------------------------------------------
                                   1047 ;	tmk_core/protocol/report.c:325: __attribute__((weak)) bool has_mouse_report_changed(report_mouse_t* new_report, report_mouse_t* old_report) {
                                   1048 ;	-----------------------------------------
                                   1049 	.area CSEG    (CODE)
                                   1050 	.area CONST   (CODE)
                                   1051 	.area CONST   (CODE)
      00BCB5                       1052 _KEYCODE2CONSUMER_usages_10000_119:
      00BCB5 E2 00                 1053 	.byte #0xe2, #0x00	; 226
      00BCB7 E9 00                 1054 	.byte #0xe9, #0x00	; 233
      00BCB9 EA 00                 1055 	.byte #0xea, #0x00	; 234
      00BCBB B5 00                 1056 	.byte #0xb5, #0x00	; 181
      00BCBD B6 00                 1057 	.byte #0xb6, #0x00	; 182
      00BCBF B7 00                 1058 	.byte #0xb7, #0x00	; 183
      00BCC1 CD 00                 1059 	.byte #0xcd, #0x00	; 205
      00BCC3 83 01                 1060 	.byte #0x83, #0x01	; 387
      00BCC5 CC 00                 1061 	.byte #0xcc, #0x00	; 204
      00BCC7 8A 01                 1062 	.byte #0x8a, #0x01	; 394
      00BCC9 92 01                 1063 	.byte #0x92, #0x01	; 402
      00BCCB 94 01                 1064 	.byte #0x94, #0x01	; 404
      00BCCD 21 02                 1065 	.byte #0x21, #0x02	; 545
      00BCCF 23 02                 1066 	.byte #0x23, #0x02	; 547
      00BCD1 24 02                 1067 	.byte #0x24, #0x02	; 548
      00BCD3 25 02                 1068 	.byte #0x25, #0x02	; 549
      00BCD5 26 02                 1069 	.byte #0x26, #0x02	; 550
      00BCD7 27 02                 1070 	.byte #0x27, #0x02	; 551
      00BCD9 2A 02                 1071 	.byte #0x2a, #0x02	; 554
      00BCDB B3 00                 1072 	.byte #0xb3, #0x00	; 179
      00BCDD B4 00                 1073 	.byte #0xb4, #0x00	; 180
      00BCDF 6F 00                 1074 	.byte #0x6f, #0x00	; 111
      00BCE1 70 00                 1075 	.byte #0x70, #0x00	; 112
      00BCE3 9F 01                 1076 	.byte #0x9f, #0x01	; 415
      00BCE5 CB 01                 1077 	.byte #0xcb, #0x01	; 459
      00BCE7 9F 02                 1078 	.byte #0x9f, #0x02	; 671
      00BCE9 A0 02                 1079 	.byte #0xa0, #0x02	; 672
                                   1080 	.area CSEG    (CODE)
                                   1081 	.area XINIT   (CODE)
                                   1082 	.area CABS    (ABS,CODE)
                                   1083 
                                   1084 ; Experimental exact instruction outlining.
                                   1085 	.globl _ak820_outline_0031
                                   1086 	.globl _ak820_outline_0050
                                   1087 	.globl _ak820_outline_0055
                                   1088 	.globl _ak820_outline_0060
                                   1089 	.globl _ak820_outline_0103
                                   1090 	.globl _ak820_outline_0104
                                   1091 	.globl _ak820_outline_0105
                                   1092 	.globl _ak820_outline_0117
                                   1093 	.globl _ak820_outline_0121
                                   1094 	.globl _ak820_outline_0122
                                   1095 	.globl _ak820_outline_0127
                                   1096 	.globl _ak820_outline_0133
                                   1097 	.globl _ak820_outline_0143
                                   1098 	.globl _ak820_outline_0157
                                   1099 	.globl _ak820_outline_0176
                                   1100 	.globl _ak820_outline_0179
                                   1101 	.globl _ak820_outline_0182
                                   1102 
                                   1103 	.area CSEG (CODE)
                                   1104 ; function ak820_outline_0031
      0073D2                       1105 _ak820_outline_0031:
      0073D2 74 02            [12] 1106 	mov	a,#0x02
      0073D4 2E               [12] 1107 	add	a,r6
      0073D5 FE               [12] 1108 	mov	r6,a
      0073D6 E4               [12] 1109 	clr	a
      0073D7 3F               [12] 1110 	addc	a,r7
      0073D8 FF               [12] 1111 	mov	r7,a
      0073D9 EC               [12] 1112 	mov	a,r4
      0073DA 2E               [12] 1113 	add	a,r6
      0073DB FC               [12] 1114 	mov	r4,a
      0073DC E4               [12] 1115 	clr	a
      0073DD 3F               [12] 1116 	addc	a,r7
      0073DE FB               [12] 1117 	mov	r3,a
      0073DF 74 07            [12] 1118 	mov	a,#0x07
      0073E1 5D               [12] 1119 	anl	a,r5
      0073E2 F5 F0            [12] 1120 	mov	b,a
      0073E4 05 F0            [12] 1121 	inc	b
      0073E6 74 01            [12] 1122 	mov	a,#0x01
      0073E8 22               [24] 1123 	ret
                                   1124 
                                   1125 	.area CSEG (CODE)
                                   1126 ; function ak820_outline_0127
      0073E9                       1127 _ak820_outline_0127:
      0073E9 F4               [12] 1128 	cpl	a
      0073EA 24 01            [12] 1129 	add	a,#0x01
      0073EC C5 F0            [12] 1130 	xch	a,b
      0073EE F4               [12] 1131 	cpl	a
      0073EF 34 00            [12] 1132 	addc	a,#0x00
      0073F1 C5 F0            [12] 1133 	xch	a,b
      0073F3 22               [24] 1134 	ret
                                   1135 
                                   1136 	.area CSEG (CODE)
                                   1137 ; function ak820_outline_0143
      0073F4                       1138 _ak820_outline_0143:
      0073F4 74 02            [12] 1139 	mov	a,#0x02
      0073F6 2E               [12] 1140 	add	a,r6
      0073F7 FB               [12] 1141 	mov	r3,a
      0073F8 E4               [12] 1142 	clr	a
      0073F9 3F               [12] 1143 	addc	a,r7
      0073FA FC               [12] 1144 	mov	r4,a
      0073FB ED               [12] 1145 	mov	a,r5
      0073FC 2B               [12] 1146 	add	a,r3
      0073FD 22               [24] 1147 	ret
                                   1148 
                                   1149 	.area CSEG (CODE)
                                   1150 ; function ak820_outline_0176
      0073FE                       1151 _ak820_outline_0176:
      0073FE 90 0D A6         [24] 1152 	mov	dptr,#_memset_PARM_2
      007401 E4               [12] 1153 	clr	a
      007402 F0               [24] 1154 	movx	@dptr,a
      007403 90 0D A7         [24] 1155 	mov	dptr,#_memset_PARM_3
      007406 22               [24] 1156 	ret
