                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module keyboard
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _quantum_task
                                     12 	.globl _switch_events
                                     13 	.globl _quantum_init
                                     14 	.globl _should_process_keypress
                                     15 	.globl _last_encoder_activity_trigger
                                     16 	.globl _last_matrix_activity_trigger
                                     17 	.globl _caps_word_task
                                     18 	.globl _vial_unlock_task
                                     19 	.globl _vial_init
                                     20 	.globl _eeprom_driver_init
                                     21 	.globl _via_init
                                     22 	.globl _encoder_read
                                     23 	.globl _encoder_init
                                     24 	.globl _rgb_matrix_init
                                     25 	.globl _rgb_matrix_task
                                     26 	.globl _process_rgb_matrix
                                     27 	.globl _mousekey_task
                                     28 	.globl _ak820_action_exec
                                     29 	.globl _print_set_sendchar
                                     30 	.globl _sendchar
                                     31 	.globl _led_task
                                     32 	.globl _led_init_ports
                                     33 	.globl _magic
                                     34 	.globl _matrix_print
                                     35 	.globl _matrix_get_row
                                     36 	.globl _matrix_scan
                                     37 	.globl _matrix_init
                                     38 	.globl _keyboard_post_init_user
                                     39 	.globl _timer_elapsed32
                                     40 	.globl _timer_read32
                                     41 	.globl _timer_read
                                     42 	.globl _timer_init
                                     43 	.globl _ADC_START
                                     44 	.globl _S0_R_FIFO
                                     45 	.globl _S0_T_FIFO
                                     46 	.globl _S0_FREE
                                     47 	.globl _S0_IF_BYTE
                                     48 	.globl _S0_IF_FIRST
                                     49 	.globl _S0_IF_OV
                                     50 	.globl _S0_FST_ACT
                                     51 	.globl _CP_RL2
                                     52 	.globl _C_T2
                                     53 	.globl _TR2
                                     54 	.globl _EXEN2
                                     55 	.globl _TCLK
                                     56 	.globl _RCLK
                                     57 	.globl _EXF2
                                     58 	.globl _CAP1F
                                     59 	.globl _TF2
                                     60 	.globl _RI
                                     61 	.globl _TI
                                     62 	.globl _RB8
                                     63 	.globl _TB8
                                     64 	.globl _REN
                                     65 	.globl _SM2
                                     66 	.globl _SM1
                                     67 	.globl _SM0
                                     68 	.globl _IT0
                                     69 	.globl _IE0
                                     70 	.globl _IT1
                                     71 	.globl _IE1
                                     72 	.globl _TR0
                                     73 	.globl _TF0
                                     74 	.globl _TR1
                                     75 	.globl _TF1
                                     76 	.globl _P4_0
                                     77 	.globl _P4_1
                                     78 	.globl _P4_2
                                     79 	.globl _P4_3
                                     80 	.globl _P4_4
                                     81 	.globl _P4_5
                                     82 	.globl _P4_6
                                     83 	.globl _RXD
                                     84 	.globl _TXD
                                     85 	.globl _INT0
                                     86 	.globl _INT1
                                     87 	.globl _T0
                                     88 	.globl _T1
                                     89 	.globl _MOSI1
                                     90 	.globl _MISO1
                                     91 	.globl _SCK1
                                     92 	.globl _P3_0
                                     93 	.globl _P3_1
                                     94 	.globl _P3_2
                                     95 	.globl _P3_3
                                     96 	.globl _P3_4
                                     97 	.globl _P3_5
                                     98 	.globl _P3_6
                                     99 	.globl _P3_7
                                    100 	.globl _CAP1_
                                    101 	.globl _T2_
                                    102 	.globl _CAP2_
                                    103 	.globl _T2EX_
                                    104 	.globl _RXD1
                                    105 	.globl _TXD1
                                    106 	.globl _P2_0
                                    107 	.globl _P2_1
                                    108 	.globl _P2_2
                                    109 	.globl _P2_3
                                    110 	.globl _P2_4
                                    111 	.globl _P2_5
                                    112 	.globl _P2_6
                                    113 	.globl _P2_7
                                    114 	.globl _AIN0
                                    115 	.globl _AIN1
                                    116 	.globl _AIN2
                                    117 	.globl _AIN3
                                    118 	.globl _AIN4
                                    119 	.globl _AIN5
                                    120 	.globl _AIN6
                                    121 	.globl _AIN7
                                    122 	.globl _CAP1
                                    123 	.globl _T2
                                    124 	.globl _CAP2
                                    125 	.globl _T2EX
                                    126 	.globl _INT0_
                                    127 	.globl _SCS
                                    128 	.globl _MOSI
                                    129 	.globl _MISO
                                    130 	.globl _SCK
                                    131 	.globl _RXD1_
                                    132 	.globl _TXD1_
                                    133 	.globl _P1_0
                                    134 	.globl _P1_1
                                    135 	.globl _P1_2
                                    136 	.globl _P1_3
                                    137 	.globl _P1_4
                                    138 	.globl _P1_5
                                    139 	.globl _P1_6
                                    140 	.globl _P1_7
                                    141 	.globl _AIN8
                                    142 	.globl _AIN9
                                    143 	.globl _AIN10
                                    144 	.globl _AIN11
                                    145 	.globl _AIN12
                                    146 	.globl _AIN13
                                    147 	.globl _RXD_
                                    148 	.globl _TXD_
                                    149 	.globl _SCL0
                                    150 	.globl _SDA0
                                    151 	.globl _P0_0
                                    152 	.globl _P0_1
                                    153 	.globl _P0_2
                                    154 	.globl _P0_3
                                    155 	.globl _P0_4
                                    156 	.globl _P0_5
                                    157 	.globl _P0_6
                                    158 	.globl _P0_7
                                    159 	.globl _IE_SPI0
                                    160 	.globl _IE_USB
                                    161 	.globl _IE_ADC
                                    162 	.globl _IE_UART1
                                    163 	.globl _IE_PWM_I2C
                                    164 	.globl _IE_GPIO
                                    165 	.globl _IE_WDOG
                                    166 	.globl _PX0
                                    167 	.globl _PT0
                                    168 	.globl _PX1
                                    169 	.globl _PT1
                                    170 	.globl _PS
                                    171 	.globl _PT2
                                    172 	.globl _PL_FLAG
                                    173 	.globl _PH_FLAG
                                    174 	.globl _EX0
                                    175 	.globl _ET0
                                    176 	.globl _EX1
                                    177 	.globl _ET1
                                    178 	.globl _ES
                                    179 	.globl _ET2
                                    180 	.globl _E_DIS
                                    181 	.globl _EA
                                    182 	.globl _P
                                    183 	.globl _F1
                                    184 	.globl _OV
                                    185 	.globl _RS0
                                    186 	.globl _RS1
                                    187 	.globl _F0
                                    188 	.globl _AC
                                    189 	.globl _CY
                                    190 	.globl _I2CS_INT_ST
                                    191 	.globl _I2CX_INT
                                    192 	.globl _LED_STATUS
                                    193 	.globl _LED_DMA_H
                                    194 	.globl _LED_DMA_L
                                    195 	.globl _LED_DMA
                                    196 	.globl _LED_PWM_OE
                                    197 	.globl _LED_COMMON
                                    198 	.globl _ADC_CHAN
                                    199 	.globl _ADC_DAT_H
                                    200 	.globl _ADC_DAT_L
                                    201 	.globl _ADC_DAT
                                    202 	.globl _ADC_CTRL
                                    203 	.globl _SPI1_CK_SE
                                    204 	.globl _SPI1_CTRL
                                    205 	.globl _SPI1_DATA
                                    206 	.globl _SPI1_STAT
                                    207 	.globl _SIF1
                                    208 	.globl _SBAUD1
                                    209 	.globl _SBUF1
                                    210 	.globl _SCON1
                                    211 	.globl _SPI0_SETUP
                                    212 	.globl _SPI0_CK_SE
                                    213 	.globl _SPI0_CTRL
                                    214 	.globl _SPI0_DATA
                                    215 	.globl _SPI0_STAT
                                    216 	.globl _T2CAP1H
                                    217 	.globl _T2CAP1L
                                    218 	.globl _T2CAP1
                                    219 	.globl _TH2
                                    220 	.globl _TL2
                                    221 	.globl _T2COUNT
                                    222 	.globl _RCAP2H
                                    223 	.globl _RCAP2L
                                    224 	.globl _RCAP2
                                    225 	.globl _T2MOD
                                    226 	.globl _T2CON
                                    227 	.globl _SBUF
                                    228 	.globl _SCON
                                    229 	.globl _TH1
                                    230 	.globl _TH0
                                    231 	.globl _TL1
                                    232 	.globl _TL0
                                    233 	.globl _TMOD
                                    234 	.globl _TCON
                                    235 	.globl _XBUS_AUX
                                    236 	.globl _P7
                                    237 	.globl _P6_DIR
                                    238 	.globl _P6_OUT_PU
                                    239 	.globl _P6_IN
                                    240 	.globl _P5_DIR
                                    241 	.globl _P5_OUT_PU
                                    242 	.globl _P5_IN
                                    243 	.globl _P4_LED_KEY
                                    244 	.globl _P4_DIR_PU
                                    245 	.globl _P4_MOD_OC
                                    246 	.globl _P4
                                    247 	.globl _P3_DIR_PU
                                    248 	.globl _P3_MOD_OC
                                    249 	.globl _P3
                                    250 	.globl _P2_DIR_PU
                                    251 	.globl _P2_MOD_OC
                                    252 	.globl _P2
                                    253 	.globl _P1_DIR_PU
                                    254 	.globl _P1_MOD_OC
                                    255 	.globl _P1
                                    256 	.globl _P0_DIR_PU
                                    257 	.globl _P0_MOD_OC
                                    258 	.globl _P0
                                    259 	.globl _ROM_CTRL
                                    260 	.globl _ROM_DATA_HH
                                    261 	.globl _ROM_DATA_HL
                                    262 	.globl _ROM_DATA_HI
                                    263 	.globl _ROM_ADDR_H
                                    264 	.globl _ROM_ADDR_L
                                    265 	.globl _ROM_ADDR
                                    266 	.globl _GPIO_IE
                                    267 	.globl _IP_EX
                                    268 	.globl _IE_EX
                                    269 	.globl _IP
                                    270 	.globl _IE
                                    271 	.globl _WDOG_COUNT
                                    272 	.globl _RESET_KEEP
                                    273 	.globl _WAKE_CTRL
                                    274 	.globl _CLOCK_CFG
                                    275 	.globl _POWER_CFG
                                    276 	.globl _PCON
                                    277 	.globl _GLOBAL_CFG
                                    278 	.globl _SAFE_MOD
                                    279 	.globl _DPH
                                    280 	.globl _DPL
                                    281 	.globl _SP
                                    282 	.globl _A_INV
                                    283 	.globl _B
                                    284 	.globl _ACC
                                    285 	.globl _PSW
                                    286 	.globl _switch_events_PARM_3
                                    287 	.globl _switch_events_PARM_2
                                    288 	.globl _keyboard_post_init_kb
                                    289 	.globl _matrix_can_read
                                    290 	.globl _keyboard_setup
                                    291 	.globl _is_keyboard_master
                                    292 	.globl _housekeeping_task
                                    293 	.globl _keyboard_init
                                    294 	.globl _keyboard_task
                                    295 ;--------------------------------------------------------
                                    296 ; special function registers
                                    297 ;--------------------------------------------------------
                                    298 	.area RSEG    (ABS,DATA)
      000000                        299 	.org 0x0000
                           0000D0   300 _PSW	=	0x00d0
                           0000E0   301 _ACC	=	0x00e0
                           0000F0   302 _B	=	0x00f0
                           0000FD   303 _A_INV	=	0x00fd
                           000081   304 _SP	=	0x0081
                           000082   305 _DPL	=	0x0082
                           000083   306 _DPH	=	0x0083
                           0000A1   307 _SAFE_MOD	=	0x00a1
                           0000B1   308 _GLOBAL_CFG	=	0x00b1
                           000087   309 _PCON	=	0x0087
                           0000BA   310 _POWER_CFG	=	0x00ba
                           0000B9   311 _CLOCK_CFG	=	0x00b9
                           0000A9   312 _WAKE_CTRL	=	0x00a9
                           0000FE   313 _RESET_KEEP	=	0x00fe
                           0000FF   314 _WDOG_COUNT	=	0x00ff
                           0000A8   315 _IE	=	0x00a8
                           0000B8   316 _IP	=	0x00b8
                           0000E8   317 _IE_EX	=	0x00e8
                           0000E9   318 _IP_EX	=	0x00e9
                           0000B2   319 _GPIO_IE	=	0x00b2
                           008584   320 _ROM_ADDR	=	0x8584
                           000084   321 _ROM_ADDR_L	=	0x0084
                           000085   322 _ROM_ADDR_H	=	0x0085
                           008F8E   323 _ROM_DATA_HI	=	0x8f8e
                           00008E   324 _ROM_DATA_HL	=	0x008e
                           00008F   325 _ROM_DATA_HH	=	0x008f
                           000086   326 _ROM_CTRL	=	0x0086
                           000080   327 _P0	=	0x0080
                           0000C4   328 _P0_MOD_OC	=	0x00c4
                           0000C5   329 _P0_DIR_PU	=	0x00c5
                           000090   330 _P1	=	0x0090
                           000092   331 _P1_MOD_OC	=	0x0092
                           000093   332 _P1_DIR_PU	=	0x0093
                           0000A0   333 _P2	=	0x00a0
                           000094   334 _P2_MOD_OC	=	0x0094
                           000095   335 _P2_DIR_PU	=	0x0095
                           0000B0   336 _P3	=	0x00b0
                           000096   337 _P3_MOD_OC	=	0x0096
                           000097   338 _P3_DIR_PU	=	0x0097
                           0000C0   339 _P4	=	0x00c0
                           0000C2   340 _P4_MOD_OC	=	0x00c2
                           0000C3   341 _P4_DIR_PU	=	0x00c3
                           0000C1   342 _P4_LED_KEY	=	0x00c1
                           0000AA   343 _P5_IN	=	0x00aa
                           0000AB   344 _P5_OUT_PU	=	0x00ab
                           0000AC   345 _P5_DIR	=	0x00ac
                           0000AD   346 _P6_IN	=	0x00ad
                           0000AE   347 _P6_OUT_PU	=	0x00ae
                           0000AF   348 _P6_DIR	=	0x00af
                           0000F1   349 _P7	=	0x00f1
                           0000A2   350 _XBUS_AUX	=	0x00a2
                           000088   351 _TCON	=	0x0088
                           000089   352 _TMOD	=	0x0089
                           00008A   353 _TL0	=	0x008a
                           00008B   354 _TL1	=	0x008b
                           00008C   355 _TH0	=	0x008c
                           00008D   356 _TH1	=	0x008d
                           000098   357 _SCON	=	0x0098
                           000099   358 _SBUF	=	0x0099
                           0000C8   359 _T2CON	=	0x00c8
                           0000C9   360 _T2MOD	=	0x00c9
                           00CBCA   361 _RCAP2	=	0xcbca
                           0000CA   362 _RCAP2L	=	0x00ca
                           0000CB   363 _RCAP2H	=	0x00cb
                           00CDCC   364 _T2COUNT	=	0xcdcc
                           0000CC   365 _TL2	=	0x00cc
                           0000CD   366 _TH2	=	0x00cd
                           00CFCE   367 _T2CAP1	=	0xcfce
                           0000CE   368 _T2CAP1L	=	0x00ce
                           0000CF   369 _T2CAP1H	=	0x00cf
                           0000F8   370 _SPI0_STAT	=	0x00f8
                           0000F9   371 _SPI0_DATA	=	0x00f9
                           0000FA   372 _SPI0_CTRL	=	0x00fa
                           0000FB   373 _SPI0_CK_SE	=	0x00fb
                           0000FC   374 _SPI0_SETUP	=	0x00fc
                           0000BC   375 _SCON1	=	0x00bc
                           0000BD   376 _SBUF1	=	0x00bd
                           0000BE   377 _SBAUD1	=	0x00be
                           0000BF   378 _SIF1	=	0x00bf
                           0000B4   379 _SPI1_STAT	=	0x00b4
                           0000B5   380 _SPI1_DATA	=	0x00b5
                           0000B6   381 _SPI1_CTRL	=	0x00b6
                           0000B7   382 _SPI1_CK_SE	=	0x00b7
                           0000F3   383 _ADC_CTRL	=	0x00f3
                           00F5F4   384 _ADC_DAT	=	0xf5f4
                           0000F4   385 _ADC_DAT_L	=	0x00f4
                           0000F5   386 _ADC_DAT_H	=	0x00f5
                           0000F6   387 _ADC_CHAN	=	0x00f6
                           0000A6   388 _LED_COMMON	=	0x00a6
                           0000A7   389 _LED_PWM_OE	=	0x00a7
                           00C7C6   390 _LED_DMA	=	0xc7c6
                           0000C6   391 _LED_DMA_L	=	0x00c6
                           0000C7   392 _LED_DMA_H	=	0x00c7
                           0000F7   393 _LED_STATUS	=	0x00f7
                           0000B3   394 _I2CX_INT	=	0x00b3
                           0000BB   395 _I2CS_INT_ST	=	0x00bb
                                    396 ;--------------------------------------------------------
                                    397 ; special function bits
                                    398 ;--------------------------------------------------------
                                    399 	.area RSEG    (ABS,DATA)
      000000                        400 	.org 0x0000
                           0000D7   401 _CY	=	0x00d7
                           0000D6   402 _AC	=	0x00d6
                           0000D5   403 _F0	=	0x00d5
                           0000D4   404 _RS1	=	0x00d4
                           0000D3   405 _RS0	=	0x00d3
                           0000D2   406 _OV	=	0x00d2
                           0000D1   407 _F1	=	0x00d1
                           0000D0   408 _P	=	0x00d0
                           0000AF   409 _EA	=	0x00af
                           0000AE   410 _E_DIS	=	0x00ae
                           0000AD   411 _ET2	=	0x00ad
                           0000AC   412 _ES	=	0x00ac
                           0000AB   413 _ET1	=	0x00ab
                           0000AA   414 _EX1	=	0x00aa
                           0000A9   415 _ET0	=	0x00a9
                           0000A8   416 _EX0	=	0x00a8
                           0000BF   417 _PH_FLAG	=	0x00bf
                           0000BE   418 _PL_FLAG	=	0x00be
                           0000BD   419 _PT2	=	0x00bd
                           0000BC   420 _PS	=	0x00bc
                           0000BB   421 _PT1	=	0x00bb
                           0000BA   422 _PX1	=	0x00ba
                           0000B9   423 _PT0	=	0x00b9
                           0000B8   424 _PX0	=	0x00b8
                           0000EF   425 _IE_WDOG	=	0x00ef
                           0000EE   426 _IE_GPIO	=	0x00ee
                           0000ED   427 _IE_PWM_I2C	=	0x00ed
                           0000EC   428 _IE_UART1	=	0x00ec
                           0000EB   429 _IE_ADC	=	0x00eb
                           0000E9   430 _IE_USB	=	0x00e9
                           0000E8   431 _IE_SPI0	=	0x00e8
                           000087   432 _P0_7	=	0x0087
                           000086   433 _P0_6	=	0x0086
                           000085   434 _P0_5	=	0x0085
                           000084   435 _P0_4	=	0x0084
                           000083   436 _P0_3	=	0x0083
                           000082   437 _P0_2	=	0x0082
                           000081   438 _P0_1	=	0x0081
                           000080   439 _P0_0	=	0x0080
                           000081   440 _SDA0	=	0x0081
                           000080   441 _SCL0	=	0x0080
                           000083   442 _TXD_	=	0x0083
                           000082   443 _RXD_	=	0x0082
                           000085   444 _AIN13	=	0x0085
                           000084   445 _AIN12	=	0x0084
                           000083   446 _AIN11	=	0x0083
                           000082   447 _AIN10	=	0x0082
                           000081   448 _AIN9	=	0x0081
                           000080   449 _AIN8	=	0x0080
                           000097   450 _P1_7	=	0x0097
                           000096   451 _P1_6	=	0x0096
                           000095   452 _P1_5	=	0x0095
                           000094   453 _P1_4	=	0x0094
                           000093   454 _P1_3	=	0x0093
                           000092   455 _P1_2	=	0x0092
                           000091   456 _P1_1	=	0x0091
                           000090   457 _P1_0	=	0x0090
                           000097   458 _TXD1_	=	0x0097
                           000096   459 _RXD1_	=	0x0096
                           000097   460 _SCK	=	0x0097
                           000096   461 _MISO	=	0x0096
                           000095   462 _MOSI	=	0x0095
                           000094   463 _SCS	=	0x0094
                           000092   464 _INT0_	=	0x0092
                           000091   465 _T2EX	=	0x0091
                           000091   466 _CAP2	=	0x0091
                           000090   467 _T2	=	0x0090
                           000090   468 _CAP1	=	0x0090
                           000097   469 _AIN7	=	0x0097
                           000096   470 _AIN6	=	0x0096
                           000095   471 _AIN5	=	0x0095
                           000094   472 _AIN4	=	0x0094
                           000093   473 _AIN3	=	0x0093
                           000092   474 _AIN2	=	0x0092
                           000091   475 _AIN1	=	0x0091
                           000090   476 _AIN0	=	0x0090
                           0000A7   477 _P2_7	=	0x00a7
                           0000A6   478 _P2_6	=	0x00a6
                           0000A5   479 _P2_5	=	0x00a5
                           0000A4   480 _P2_4	=	0x00a4
                           0000A3   481 _P2_3	=	0x00a3
                           0000A2   482 _P2_2	=	0x00a2
                           0000A1   483 _P2_1	=	0x00a1
                           0000A0   484 _P2_0	=	0x00a0
                           0000A7   485 _TXD1	=	0x00a7
                           0000A6   486 _RXD1	=	0x00a6
                           0000A5   487 _T2EX_	=	0x00a5
                           0000A5   488 _CAP2_	=	0x00a5
                           0000A4   489 _T2_	=	0x00a4
                           0000A4   490 _CAP1_	=	0x00a4
                           0000B7   491 _P3_7	=	0x00b7
                           0000B6   492 _P3_6	=	0x00b6
                           0000B5   493 _P3_5	=	0x00b5
                           0000B4   494 _P3_4	=	0x00b4
                           0000B3   495 _P3_3	=	0x00b3
                           0000B2   496 _P3_2	=	0x00b2
                           0000B1   497 _P3_1	=	0x00b1
                           0000B0   498 _P3_0	=	0x00b0
                           0000B7   499 _SCK1	=	0x00b7
                           0000B6   500 _MISO1	=	0x00b6
                           0000B5   501 _MOSI1	=	0x00b5
                           0000B5   502 _T1	=	0x00b5
                           0000B4   503 _T0	=	0x00b4
                           0000B3   504 _INT1	=	0x00b3
                           0000B2   505 _INT0	=	0x00b2
                           0000B1   506 _TXD	=	0x00b1
                           0000B0   507 _RXD	=	0x00b0
                           0000C6   508 _P4_6	=	0x00c6
                           0000C5   509 _P4_5	=	0x00c5
                           0000C4   510 _P4_4	=	0x00c4
                           0000C3   511 _P4_3	=	0x00c3
                           0000C2   512 _P4_2	=	0x00c2
                           0000C1   513 _P4_1	=	0x00c1
                           0000C0   514 _P4_0	=	0x00c0
                           00008F   515 _TF1	=	0x008f
                           00008E   516 _TR1	=	0x008e
                           00008D   517 _TF0	=	0x008d
                           00008C   518 _TR0	=	0x008c
                           00008B   519 _IE1	=	0x008b
                           00008A   520 _IT1	=	0x008a
                           000089   521 _IE0	=	0x0089
                           000088   522 _IT0	=	0x0088
                           00009F   523 _SM0	=	0x009f
                           00009E   524 _SM1	=	0x009e
                           00009D   525 _SM2	=	0x009d
                           00009C   526 _REN	=	0x009c
                           00009B   527 _TB8	=	0x009b
                           00009A   528 _RB8	=	0x009a
                           000099   529 _TI	=	0x0099
                           000098   530 _RI	=	0x0098
                           0000CF   531 _TF2	=	0x00cf
                           0000CF   532 _CAP1F	=	0x00cf
                           0000CE   533 _EXF2	=	0x00ce
                           0000CD   534 _RCLK	=	0x00cd
                           0000CC   535 _TCLK	=	0x00cc
                           0000CB   536 _EXEN2	=	0x00cb
                           0000CA   537 _TR2	=	0x00ca
                           0000C9   538 _C_T2	=	0x00c9
                           0000C8   539 _CP_RL2	=	0x00c8
                           0000FF   540 _S0_FST_ACT	=	0x00ff
                           0000FE   541 _S0_IF_OV	=	0x00fe
                           0000FD   542 _S0_IF_FIRST	=	0x00fd
                           0000FC   543 _S0_IF_BYTE	=	0x00fc
                           0000FB   544 _S0_FREE	=	0x00fb
                           0000FA   545 _S0_T_FIFO	=	0x00fa
                           0000F8   546 _S0_R_FIFO	=	0x00f8
                           0000F7   547 _ADC_START	=	0x00f7
                                    548 ;--------------------------------------------------------
                                    549 ; overlayable register banks
                                    550 ;--------------------------------------------------------
                                    551 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        552 	.ds 8
                                    553 ;--------------------------------------------------------
                                    554 ; internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area DSEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; overlayable items in internal ram
                                    559 ;--------------------------------------------------------
                                    560 	.area	OSEG    (OVR,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; indirectly addressable internal ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area ISEG    (DATA)
                                    565 ;--------------------------------------------------------
                                    566 ; absolute internal ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area IABS    (ABS,DATA)
                                    569 	.area IABS    (ABS,DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; bit data
                                    572 ;--------------------------------------------------------
                                    573 	.area BSEG    (BIT)
                                    574 ;--------------------------------------------------------
                                    575 ; paged external ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area PSEG    (PAG,XDATA)
                                    578 ;--------------------------------------------------------
                                    579 ; uninitialized external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area XSEG    (XDATA)
      000B87                        582 _switch_events_PARM_2:
      000B87                        583 	.ds 1
      000B88                        584 _switch_events_PARM_3:
      000B88                        585 	.ds 1
      000B89                        586 _switch_events_row_10000_500:
      000B89                        587 	.ds 1
      000B8A                        588 _generate_tick_event_last_tick_10000_503:
      000B8A                        589 	.ds 2
      000B8C                        590 _matrix_task_last_tick_60000_532:
      000B8C                        591 	.ds 2
      000B8E                        592 _matrix_task_dummy_event_70000_533:
      000B8E                        593 	.ds 6
      000B94                        594 _matrix_task_matrix_previous_10001_510:
      000B94                        595 	.ds 16
      000BA4                        596 _matrix_task_matrix_changed_10002_511:
      000BA4                        597 	.ds 1
      000BA5                        598 _matrix_task_last_tick_60002_536:
      000BA5                        599 	.ds 2
      000BA7                        600 _matrix_task_dummy_event_70002_537:
      000BA7                        601 	.ds 6
      000BAD                        602 _matrix_task_row_changes_30003_520:
      000BAD                        603 	.ds 1
      000BAE                        604 _matrix_task_col_mask_30004_523:
      000BAE                        605 	.ds 1
      000BAF                        606 _matrix_task_dummy_event_90004_529:
      000BAF                        607 	.ds 6
                                    608 ;--------------------------------------------------------
                                    609 ; absolute external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area XABS    (ABS,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; initialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XISEG   (XDATA)
      000DFD                        616 _last_input_modification_time:
      000DFD                        617 	.ds 4
      000E01                        618 _last_matrix_modification_time:
      000E01                        619 	.ds 4
      000E05                        620 _last_encoder_modification_time:
      000E05                        621 	.ds 4
      000E09                        622 _last_pointing_device_modification_time:
      000E09                        623 	.ds 4
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT0 (CODE)
                                    626 	.area GSINIT1 (CODE)
                                    627 	.area GSINIT2 (CODE)
                                    628 	.area GSINIT3 (CODE)
                                    629 	.area GSINIT4 (CODE)
                                    630 	.area GSINIT5 (CODE)
                                    631 	.area GSINIT  (CODE)
                                    632 	.area GSFINAL (CODE)
                                    633 	.area CSEG    (CODE)
                                    634 ;--------------------------------------------------------
                                    635 ; global & static initialisations
                                    636 ;--------------------------------------------------------
                                    637 	.area HOME    (CODE)
                                    638 	.area GSINIT  (CODE)
                                    639 	.area GSFINAL (CODE)
                                    640 	.area GSINIT  (CODE)
                                    641 ;------------------------------------------------------------
                                    642 ;Allocation info for local variables in function 'generate_tick_event'
                                    643 ;------------------------------------------------------------
                                    644 ;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_503'
                                    645 ;now           Allocated with name '_generate_tick_event_now_10000_503'
                                    646 ;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_505'
                                    647 ;------------------------------------------------------------
                                    648 ;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
      0030DA 90 0B 8A         [24]  649 	mov	dptr,#_generate_tick_event_last_tick_10000_503
      0030DD E4               [12]  650 	clr	a
      0030DE F0               [24]  651 	movx	@dptr,a
      0030DF A3               [24]  652 	inc	dptr
      0030E0 F0               [24]  653 	movx	@dptr,a
                                    654 ;------------------------------------------------------------
                                    655 ;Allocation info for local variables in function 'matrix_task'
                                    656 ;------------------------------------------------------------
                                    657 ;last_tick     Allocated with name '_matrix_task_last_tick_60000_532'
                                    658 ;now           Allocated with name '_matrix_task_now_60000_532'
                                    659 ;dummy_event   Allocated with name '_matrix_task_dummy_event_70000_533'
                                    660 ;matrix_previous Allocated with name '_matrix_task_matrix_previous_10001_510'
                                    661 ;matrix_changed Allocated with name '_matrix_task_matrix_changed_10002_511'
                                    662 ;row           Allocated with name '_matrix_task_row_20002_512'
                                    663 ;last_tick     Allocated with name '_matrix_task_last_tick_60002_536'
                                    664 ;now           Allocated with name '_matrix_task_now_60002_536'
                                    665 ;dummy_event   Allocated with name '_matrix_task_dummy_event_70002_537'
                                    666 ;process_keypress Allocated with name '_matrix_task_process_keypress_10003_518'
                                    667 ;row           Allocated with name '_matrix_task_row_20003_519'
                                    668 ;__400030089   Allocated with name '_matrix_task___400030089_40003_520'
                                    669 ;current_row   Allocated with name '_matrix_task_current_row_30003_520'
                                    670 ;row_changes   Allocated with name '_matrix_task_row_changes_30003_520'
                                    671 ;__500030090   Allocated with name '_matrix_task___500030090_50003_538'
                                    672 ;__500030091   Allocated with name '_matrix_task___500030091_50003_538'
                                    673 ;row           Allocated with name '_matrix_task_row_60003_539'
                                    674 ;rowdata       Allocated with name '_matrix_task_rowdata_60003_539'
                                    675 ;col_mask      Allocated with name '_matrix_task_col_mask_30004_523'
                                    676 ;col           Allocated with name '_matrix_task_col_40004_524'
                                    677 ;key_pressed   Allocated with name '_matrix_task_key_pressed_70004_527'
                                    678 ;dummy_event   Allocated with name '_matrix_task_dummy_event_90004_529'
                                    679 ;------------------------------------------------------------
                                    680 ;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
      0030E1 90 0B 8C         [24]  681 	mov	dptr,#_matrix_task_last_tick_60000_532
      0030E4 E4               [12]  682 	clr	a
      0030E5 F0               [24]  683 	movx	@dptr,a
      0030E6 A3               [24]  684 	inc	dptr
      0030E7 F0               [24]  685 	movx	@dptr,a
      0030E8 90 0B A5         [24]  686 	mov	dptr,#_matrix_task_last_tick_60002_536
      0030EB F0               [24]  687 	movx	@dptr,a
      0030EC A3               [24]  688 	inc	dptr
      0030ED F0               [24]  689 	movx	@dptr,a
                                    690 ;--------------------------------------------------------
                                    691 ; Home
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area HOME    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; code
                                    697 ;--------------------------------------------------------
                                    698 	.area CSEG    (CODE)
                                    699 ;------------------------------------------------------------
                                    700 ;Allocation info for local variables in function 'IS_KEYEVENT'
                                    701 ;------------------------------------------------------------
                                    702 ;event         Allocated with name '_IS_KEYEVENT_PARM_1'
                                    703 ;------------------------------------------------------------
                                    704 ;	quantum/keyboard.c:36: bool IS_KEYEVENT(const keyevent_t event) {
                                    705 ;	-----------------------------------------
                           000007   706 	ar7 = 0x07
                           000006   707 	ar6 = 0x06
                           000005   708 	ar5 = 0x05
                           000004   709 	ar4 = 0x04
                           000003   710 	ar3 = 0x03
                           000002   711 	ar2 = 0x02
                           000001   712 	ar1 = 0x01
                           000000   713 	ar0 = 0x00
                                    714 ;	 function last_matrix_activity_trigger
                                    715 ;	-----------------------------------------
      00969C                        716 _last_matrix_activity_trigger:
                                    717 ;	quantum/keyboard.c:190: last_matrix_modification_time = last_input_modification_time = sync_timer_read32();
      00969C 12 4A EE         [24]  718 	lcall	_timer_read32
      00969F 12 51 29         [24]  719 	lcall	_ak820_outline_0056
      0096A2 90 0D FD         [24]  720 	mov	dptr,#_last_input_modification_time
      0096A5 12 94 62         [24]  721 	lcall	_ak820_outline_0007
      0096A8 90 0E 01         [24]  722 	mov	dptr,#_last_matrix_modification_time
      0096AB 12 94 62         [24]  723 	lcall	_ak820_outline_0007
                                    724 ;	quantum/keyboard.c:191: }
      0096AE 22               [24]  725 	ret
                                    726 ;------------------------------------------------------------
                                    727 ;Allocation info for local variables in function 'last_encoder_activity_time'
                                    728 ;------------------------------------------------------------
                                    729 ;	quantum/keyboard.c:194: uint32_t        last_encoder_activity_time(void) {
                                    730 ;	-----------------------------------------
                                    731 ;	 function last_encoder_activity_trigger
                                    732 ;	-----------------------------------------
      0096AF                        733 _last_encoder_activity_trigger:
                                    734 ;	quantum/keyboard.c:201: last_encoder_modification_time = last_input_modification_time = sync_timer_read32();
      0096AF 12 4A EE         [24]  735 	lcall	_timer_read32
      0096B2 12 51 29         [24]  736 	lcall	_ak820_outline_0056
      0096B5 90 0D FD         [24]  737 	mov	dptr,#_last_input_modification_time
      0096B8 12 94 62         [24]  738 	lcall	_ak820_outline_0007
      0096BB 90 0E 05         [24]  739 	mov	dptr,#_last_encoder_modification_time
      0096BE 12 94 62         [24]  740 	lcall	_ak820_outline_0007
                                    741 ;	quantum/keyboard.c:202: }
      0096C1 22               [24]  742 	ret
                                    743 ;------------------------------------------------------------
                                    744 ;Allocation info for local variables in function 'last_pointing_device_activity_time'
                                    745 ;------------------------------------------------------------
                                    746 ;	quantum/keyboard.c:205: uint32_t        last_pointing_device_activity_time(void) {
                                    747 ;	-----------------------------------------
                                    748 ;	 function keyboard_post_init_kb
                                    749 ;	-----------------------------------------
      0096C2                        750 _keyboard_post_init_kb:
                                    751 ;	quantum/keyboard.c:345: keyboard_post_init_user();
                                    752 ;	quantum/keyboard.c:346: }
      0096C2 02 9A CE         [24]  753 	ljmp	_keyboard_post_init_user
                                    754 ;------------------------------------------------------------
                                    755 ;Allocation info for local variables in function 'matrix_can_read'
                                    756 ;------------------------------------------------------------
                                    757 ;	quantum/keyboard.c:352: __attribute__((weak)) bool matrix_can_read(void) {
                                    758 ;	-----------------------------------------
                                    759 ;	 function matrix_can_read
                                    760 ;	-----------------------------------------
      0096C5                        761 _matrix_can_read:
                                    762 ;	quantum/keyboard.c:353: return true;
      0096C5 75 82 01         [24]  763 	mov	dpl, #0x01
                                    764 ;	quantum/keyboard.c:354: }
      0096C8 22               [24]  765 	ret
                                    766 ;------------------------------------------------------------
                                    767 ;Allocation info for local variables in function 'keyboard_setup'
                                    768 ;------------------------------------------------------------
                                    769 ;	quantum/keyboard.c:360: void keyboard_setup(void) {
                                    770 ;	-----------------------------------------
                                    771 ;	 function keyboard_setup
                                    772 ;	-----------------------------------------
      0096C9                        773 _keyboard_setup:
                                    774 ;	quantum/keyboard.c:361: print_set_sendchar(sendchar);
      0096C9 90 9C 36         [24]  775 	mov	dptr,#_sendchar
      0096CC 12 9C 0A         [24]  776 	lcall	_print_set_sendchar
                                    777 ;	quantum/keyboard.c:363: eeprom_driver_init();
      0096CF 12 40 0E         [24]  778 	lcall	_eeprom_driver_init
                                    779 ;	quantum/keyboard.c:366: vial_init();
                                    780 ;	quantum/keyboard.c:372: keyboard_pre_init_kb();
                                    781 ;	quantum/keyboard.c:373: }
      0096D2 02 B0 4D         [24]  782 	ljmp	_vial_init
                                    783 ;------------------------------------------------------------
                                    784 ;Allocation info for local variables in function 'is_keyboard_master'
                                    785 ;------------------------------------------------------------
                                    786 ;	quantum/keyboard.c:381: __attribute__((weak)) bool is_keyboard_master(void) {
                                    787 ;	-----------------------------------------
                                    788 ;	 function is_keyboard_master
                                    789 ;	-----------------------------------------
      0096D5                        790 _is_keyboard_master:
                                    791 ;	quantum/keyboard.c:382: return true;
      0096D5 75 82 01         [24]  792 	mov	dpl, #0x01
                                    793 ;	quantum/keyboard.c:383: }
      0096D8 22               [24]  794 	ret
                                    795 ;------------------------------------------------------------
                                    796 ;Allocation info for local variables in function 'is_keyboard_left'
                                    797 ;------------------------------------------------------------
                                    798 ;	quantum/keyboard.c:389: __attribute__((weak)) bool is_keyboard_left(void) {
                                    799 ;	-----------------------------------------
                                    800 ;	 function should_process_keypress
                                    801 ;	-----------------------------------------
      0096D9                        802 _should_process_keypress:
                                    803 ;	quantum/keyboard.c:401: return is_keyboard_master();
                                    804 ;	quantum/keyboard.c:402: }
      0096D9 02 96 D5         [24]  805 	ljmp	_is_keyboard_master
                                    806 ;------------------------------------------------------------
                                    807 ;Allocation info for local variables in function 'housekeeping_task_kb'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/keyboard.c:409: __attribute__((weak)) void housekeeping_task_kb(void) {}
                                    810 ;	-----------------------------------------
                                    811 ;	 function housekeeping_task
                                    812 ;	-----------------------------------------
      0096DC                        813 _housekeeping_task:
                                    814 ;	quantum/keyboard.c:424: housekeeping_task_user();
                                    815 ;	quantum/keyboard.c:425: }
      0096DC 22               [24]  816 	ret
                                    817 ;------------------------------------------------------------
                                    818 ;Allocation info for local variables in function 'quantum_init'
                                    819 ;------------------------------------------------------------
                                    820 ;	quantum/keyboard.c:431: void quantum_init(void) {
                                    821 ;	-----------------------------------------
                                    822 ;	 function quantum_init
                                    823 ;	-----------------------------------------
      0096DD                        824 _quantum_init:
                                    825 ;	quantum/keyboard.c:432: magic();
      0096DD 12 85 86         [24]  826 	lcall	_magic
                                    827 ;	quantum/keyboard.c:433: led_init_ports();
      0096E0 12 9B A0         [24]  828 	lcall	_led_init_ports
                                    829 ;	quantum/keyboard.c:444: rgb_matrix_init();
                                    830 ;	quantum/keyboard.c:452: }
      0096E3 02 55 34         [24]  831 	ljmp	_rgb_matrix_init
                                    832 ;------------------------------------------------------------
                                    833 ;Allocation info for local variables in function 'keyboard_init'
                                    834 ;------------------------------------------------------------
                                    835 ;	quantum/keyboard.c:458: void keyboard_init(void) {
                                    836 ;	-----------------------------------------
                                    837 ;	 function keyboard_init
                                    838 ;	-----------------------------------------
      0096E6                        839 _keyboard_init:
                                    840 ;	quantum/keyboard.c:459: timer_init();
      0096E6 12 4A B0         [24]  841 	lcall	_timer_init
                                    842 ;	quantum/keyboard.c:462: via_init();
      0096E9 12 A9 13         [24]  843 	lcall	_via_init
                                    844 ;	quantum/keyboard.c:468: encoder_init();
      0096EC 12 94 A5         [24]  845 	lcall	_encoder_init
                                    846 ;	quantum/keyboard.c:470: matrix_init();
      0096EF 12 5E 43         [24]  847 	lcall	_matrix_init
                                    848 ;	quantum/keyboard.c:471: quantum_init();
      0096F2 12 96 DD         [24]  849 	lcall	_quantum_init
                                    850 ;	quantum/keyboard.c:521: keyboard_post_init_kb(); /* Always keep this last */
                                    851 ;	quantum/keyboard.c:522: }
      0096F5 02 96 C2         [24]  852 	ljmp	_keyboard_post_init_kb
                                    853 ;------------------------------------------------------------
                                    854 ;Allocation info for local variables in function 'switch_events'
                                    855 ;------------------------------------------------------------
                                    856 ;col           Allocated with name '_switch_events_PARM_2'
                                    857 ;pressed       Allocated with name '_switch_events_PARM_3'
                                    858 ;row           Allocated with name '_switch_events_row_10000_500'
                                    859 ;------------------------------------------------------------
                                    860 ;	quantum/keyboard.c:529: void switch_events(uint8_t row, uint8_t col, bool pressed) {
                                    861 ;	-----------------------------------------
                                    862 ;	 function switch_events
                                    863 ;	-----------------------------------------
      0096F8                        864 _switch_events:
      0096F8 E5 82            [12]  865 	mov	a,dpl
      0096FA 90 0B 89         [24]  866 	mov	dptr,#_switch_events_row_10000_500
      0096FD F0               [24]  867 	movx	@dptr,a
                                    868 ;	quantum/keyboard.c:534: process_rgb_matrix(row, col, pressed);
      0096FE E0               [24]  869 	movx	a,@dptr
      0096FF FF               [12]  870 	mov	r7,a
      009700 90 0B 87         [24]  871 	mov	dptr,#_switch_events_PARM_2
      009703 E0               [24]  872 	movx	a,@dptr
      009704 FE               [12]  873 	mov	r6,a
      009705 90 0B 88         [24]  874 	mov	dptr,#_switch_events_PARM_3
      009708 E0               [24]  875 	movx	a,@dptr
      009709 FD               [12]  876 	mov	r5,a
      00970A 90 07 4D         [24]  877 	mov	dptr,#_process_rgb_matrix_PARM_2
      00970D EE               [12]  878 	mov	a,r6
      00970E F0               [24]  879 	movx	@dptr,a
      00970F 90 07 4E         [24]  880 	mov	dptr,#_process_rgb_matrix_PARM_3
      009712 ED               [12]  881 	mov	a,r5
      009713 F0               [24]  882 	movx	@dptr,a
      009714 8F 82            [24]  883 	mov	dpl, r7
                                    884 ;	quantum/keyboard.c:536: }
      009716 02 58 C0         [24]  885 	ljmp	_process_rgb_matrix
                                    886 ;------------------------------------------------------------
                                    887 ;Allocation info for local variables in function 'generate_tick_event'
                                    888 ;------------------------------------------------------------
                                    889 ;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_503'
                                    890 ;now           Allocated with name '_generate_tick_event_now_10000_503'
                                    891 ;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_505'
                                    892 ;------------------------------------------------------------
                                    893 ;	quantum/keyboard.c:542: static inline void generate_tick_event(void) {
                                    894 ;	-----------------------------------------
                                    895 ;	 function matrix_task
                                    896 ;	-----------------------------------------
      009719                        897 _matrix_task:
                                    898 ;	quantum/keyboard.c:562: if (!matrix_can_read()) {
      009719 12 96 C5         [24]  899 	lcall	_matrix_can_read
      00971C E5 82            [12]  900 	mov	a, dpl
      00971E 70 4B            [24]  901 	jnz	00102$
                                    902 ;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
      009720 12 4B 1F         [24]  903 	lcall	_timer_read
      009723 12 45 71         [24]  904 	lcall	_ak820_outline_0130
                                    905 ;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
      009726 90 0B 8C         [24]  906 	mov	dptr,#_matrix_task_last_tick_60000_532
      009729 12 3A 66         [24]  907 	lcall	_ak820_outline_0059
      00972C EE               [12]  908 	mov	a,r6
      00972D C3               [12]  909 	clr	c
      00972E 9C               [12]  910 	subb	a,r4
      00972F FC               [12]  911 	mov	r4,a
      009730 EF               [12]  912 	mov	a,r7
      009731 9D               [12]  913 	subb	a,r5
      009732 4C               [12]  914 	orl	a,r4
      009733 60 32            [24]  915 	jz	00120$
                                    916 ;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
      009735 90 0B 8E         [24]  917 	mov	dptr,#_matrix_task_dummy_event_70000_533
      009738 E4               [12]  918 	clr	a
      009739 F0               [24]  919 	movx	@dptr,a
      00973A 90 0B 8F         [24]  920 	mov	dptr,#(_matrix_task_dummy_event_70000_533 + 0x0001)
      00973D F0               [24]  921 	movx	@dptr,a
      00973E 12 4B 1F         [24]  922 	lcall	_timer_read
      009741 12 45 87         [24]  923 	lcall	_ak820_outline_0147
      009744 90 0B 90         [24]  924 	mov	dptr,#(_matrix_task_dummy_event_70000_533 + 0x0002)
      009747 12 3A 6C         [24]  925 	lcall	_ak820_outline_0070
      00974A 90 0B 92         [24]  926 	mov	dptr,#(_matrix_task_dummy_event_70000_533 + 0x0004)
      00974D E4               [12]  927 	clr	a
      00974E F0               [24]  928 	movx	@dptr,a
      00974F 90 0B 93         [24]  929 	mov	dptr,#(_matrix_task_dummy_event_70000_533 + 0x0005)
      009752 F0               [24]  930 	movx	@dptr,a
                                    931 ;	quantum/keyboard.c:549: AK820_ACTION_EXEC(dummy_event);
      009753 90 0B 8E         [24]  932 	mov	dptr,#_matrix_task_dummy_event_70000_533
      009756 C0 07            [24]  933 	push	ar7
      009758 C0 06            [24]  934 	push	ar6
      00975A 12 74 E2         [24]  935 	lcall	_ak820_action_exec
      00975D D0 06            [24]  936 	pop	ar6
      00975F D0 07            [24]  937 	pop	ar7
                                    938 ;	quantum/keyboard.c:550: last_tick = now;
      009761 90 0B 8C         [24]  939 	mov	dptr,#_matrix_task_last_tick_60000_532
      009764 12 4A 87         [24]  940 	lcall	_ak820_outline_0058
                                    941 ;	quantum/keyboard.c:563: generate_tick_event();
      009767                        942 00120$:
                                    943 ;	quantum/keyboard.c:564: return false;
      009767 75 82 00         [24]  944 	mov	dpl, #0x00
      00976A 22               [24]  945 	ret
      00976B                        946 00102$:
                                    947 ;	quantum/keyboard.c:569: matrix_scan();
      00976B 12 5E 6C         [24]  948 	lcall	_matrix_scan
                                    949 ;	quantum/keyboard.c:573: vial_unlock_task();
      00976E 12 AF B8         [24]  950 	lcall	_vial_unlock_task
                                    951 ;	quantum/keyboard.c:575: bool matrix_changed = false;
      009771 90 0B A4         [24]  952 	mov	dptr,#_matrix_task_matrix_changed_10002_511
      009774 E4               [12]  953 	clr	a
      009775 F0               [24]  954 	movx	@dptr,a
                                    955 ;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
      009776 FF               [12]  956 	mov	r7,a
      009777                        957 00127$:
      009777 BF 10 00         [24]  958 	cjne	r7,#0x10,00247$
      00977A                        959 00247$:
      00977A 50 1F            [24]  960 	jnc	00103$
      00977C 90 0B A4         [24]  961 	mov	dptr,#_matrix_task_matrix_changed_10002_511
      00977F E0               [24]  962 	movx	a,@dptr
      009780 70 19            [24]  963 	jnz	00103$
                                    964 ;	quantum/keyboard.c:577: matrix_changed |= matrix_previous[row] ^ matrix_get_row(row);
      009782 EF               [12]  965 	mov	a,r7
      009783 12 98 E2         [24]  966 	lcall	_ak820_outline_0066
      009786 E0               [24]  967 	movx	a,@dptr
      009787 FE               [12]  968 	mov	r6,a
      009788 8F 82            [24]  969 	mov	dpl, r7
      00978A 12 5D F8         [24]  970 	lcall	_matrix_get_row
      00978D E5 82            [12]  971 	mov	a,dpl
      00978F 6E               [12]  972 	xrl	a,r6
                                    973 ;	assignBit
      009790 90 0B A4         [24]  974 	mov	dptr,#_matrix_task_matrix_changed_10002_511
      009793 24 FF            [12]  975 	add	a,#0xff
      009795 E4               [12]  976 	clr	a
      009796 33               [12]  977 	rlc	a
      009797 F0               [24]  978 	movx	@dptr,a
                                    979 ;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
      009798 0F               [12]  980 	inc	r7
      009799 80 DC            [24]  981 	sjmp	00127$
      00979B                        982 00103$:
                                    983 ;	quantum/keyboard.c:583: if (!matrix_changed) {
      00979B 90 0B A4         [24]  984 	mov	dptr,#_matrix_task_matrix_changed_10002_511
      00979E E0               [24]  985 	movx	a,@dptr
      00979F 70 4B            [24]  986 	jnz	00105$
                                    987 ;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
      0097A1 12 4B 1F         [24]  988 	lcall	_timer_read
      0097A4 12 45 71         [24]  989 	lcall	_ak820_outline_0130
                                    990 ;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
      0097A7 90 0B A5         [24]  991 	mov	dptr,#_matrix_task_last_tick_60002_536
      0097AA 12 3A 66         [24]  992 	lcall	_ak820_outline_0059
      0097AD EE               [12]  993 	mov	a,r6
      0097AE C3               [12]  994 	clr	c
      0097AF 9C               [12]  995 	subb	a,r4
      0097B0 FC               [12]  996 	mov	r4,a
      0097B1 EF               [12]  997 	mov	a,r7
      0097B2 9D               [12]  998 	subb	a,r5
      0097B3 4C               [12]  999 	orl	a,r4
      0097B4 60 32            [24] 1000 	jz	00123$
                                   1001 ;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
      0097B6 90 0B A7         [24] 1002 	mov	dptr,#_matrix_task_dummy_event_70002_537
      0097B9 E4               [12] 1003 	clr	a
      0097BA F0               [24] 1004 	movx	@dptr,a
      0097BB 90 0B A8         [24] 1005 	mov	dptr,#(_matrix_task_dummy_event_70002_537 + 0x0001)
      0097BE F0               [24] 1006 	movx	@dptr,a
      0097BF 12 4B 1F         [24] 1007 	lcall	_timer_read
      0097C2 12 45 87         [24] 1008 	lcall	_ak820_outline_0147
      0097C5 90 0B A9         [24] 1009 	mov	dptr,#(_matrix_task_dummy_event_70002_537 + 0x0002)
      0097C8 12 3A 6C         [24] 1010 	lcall	_ak820_outline_0070
      0097CB 90 0B AB         [24] 1011 	mov	dptr,#(_matrix_task_dummy_event_70002_537 + 0x0004)
      0097CE E4               [12] 1012 	clr	a
      0097CF F0               [24] 1013 	movx	@dptr,a
      0097D0 90 0B AC         [24] 1014 	mov	dptr,#(_matrix_task_dummy_event_70002_537 + 0x0005)
      0097D3 F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	quantum/keyboard.c:549: AK820_ACTION_EXEC(dummy_event);
      0097D4 90 0B A7         [24] 1017 	mov	dptr,#_matrix_task_dummy_event_70002_537
      0097D7 C0 07            [24] 1018 	push	ar7
      0097D9 C0 06            [24] 1019 	push	ar6
      0097DB 12 74 E2         [24] 1020 	lcall	_ak820_action_exec
      0097DE D0 06            [24] 1021 	pop	ar6
      0097E0 D0 07            [24] 1022 	pop	ar7
                                   1023 ;	quantum/keyboard.c:550: last_tick = now;
      0097E2 90 0B A5         [24] 1024 	mov	dptr,#_matrix_task_last_tick_60002_536
      0097E5 12 4A 87         [24] 1025 	lcall	_ak820_outline_0058
                                   1026 ;	quantum/keyboard.c:584: generate_tick_event();
      0097E8                       1027 00123$:
                                   1028 ;	quantum/keyboard.c:585: return matrix_changed;
      0097E8 75 82 00         [24] 1029 	mov	dpl, #0x00
      0097EB 22               [24] 1030 	ret
      0097EC                       1031 00105$:
                                   1032 ;	quantum/keyboard.c:588: if (debug_config.matrix) {
      0097EC 90 0E 11         [24] 1033 	mov	dptr,#_debug_config
      0097EF E0               [24] 1034 	movx	a,@dptr
      0097F0 30 E1 03         [24] 1035 	jnb	acc.1,00107$
                                   1036 ;	quantum/keyboard.c:589: matrix_print();
      0097F3 12 5E 98         [24] 1037 	lcall	_matrix_print
      0097F6                       1038 00107$:
                                   1039 ;	quantum/keyboard.c:592: const bool process_keypress = should_process_keypress();
      0097F6 12 96 D9         [24] 1040 	lcall	_should_process_keypress
      0097F9 AF 82            [24] 1041 	mov	r7, dpl
                                   1042 ;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      0097FB 7E 00            [12] 1043 	mov	r6,#0x00
      0097FD                       1044 00133$:
      0097FD BE 10 00         [24] 1045 	cjne	r6,#0x10,00253$
      009800                       1046 00253$:
      009800 40 03            [24] 1047 	jc	00254$
      009802 02 98 BB         [24] 1048 	ljmp	00117$
      009805                       1049 00254$:
                                   1050 ;	quantum/keyboard.c:595: const matrix_row_t current_row = matrix_get_row(row);
      009805 8E 82            [24] 1051 	mov	dpl, r6
      009807 12 5D F8         [24] 1052 	lcall	_matrix_get_row
      00980A AD 82            [24] 1053 	mov	r5, dpl
                                   1054 ;	quantum/keyboard.c:596: const matrix_row_t row_changes = current_row ^ matrix_previous[row];
      00980C EE               [12] 1055 	mov	a,r6
      00980D 12 98 E2         [24] 1056 	lcall	_ak820_outline_0066
      009810 E0               [24] 1057 	movx	a,@dptr
      009811 FC               [12] 1058 	mov	r4,a
      009812 ED               [12] 1059 	mov	a,r5
      009813 62 04            [12] 1060 	xrl	ar4,a
      009815 90 0B AD         [24] 1061 	mov	dptr,#_matrix_task_row_changes_30003_520
      009818 EC               [12] 1062 	mov	a,r4
      009819 F0               [24] 1063 	movx	@dptr,a
                                   1064 ;	quantum/keyboard.c:598: if (!row_changes || has_ghost_in_row(row, current_row)) {
      00981A EC               [12] 1065 	mov	a,r4
      00981B 70 03            [24] 1066 	jnz	00255$
      00981D 02 98 B7         [24] 1067 	ljmp	00116$
      009820                       1068 00255$:
                                   1069 ;	quantum/keyboard.c:602: matrix_row_t col_mask = 1;
      009820 90 0B AE         [24] 1070 	mov	dptr,#_matrix_task_col_mask_30004_523
      009823 74 01            [12] 1071 	mov	a,#0x01
      009825 F0               [24] 1072 	movx	@dptr,a
                                   1073 ;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
      009826 7C 00            [12] 1074 	mov	r4,#0x00
      009828                       1075 00130$:
      009828 BC 08 00         [24] 1076 	cjne	r4,#0x08,00256$
      00982B                       1077 00256$:
      00982B 40 03            [24] 1078 	jc	00257$
      00982D 02 98 B1         [24] 1079 	ljmp	00115$
      009830                       1080 00257$:
                                   1081 ;	quantum/keyboard.c:604: if (row_changes & col_mask) {
      009830 90 0B AD         [24] 1082 	mov	dptr,#_matrix_task_row_changes_30003_520
      009833 E0               [24] 1083 	movx	a,@dptr
      009834 FB               [12] 1084 	mov	r3,a
      009835 90 0B AE         [24] 1085 	mov	dptr,#_matrix_task_col_mask_30004_523
      009838 E0               [24] 1086 	movx	a,@dptr
      009839 FA               [12] 1087 	mov	r2,a
      00983A 5B               [12] 1088 	anl	a,r3
      00983B 60 69            [24] 1089 	jz	00131$
                                   1090 ;	quantum/keyboard.c:605: const bool key_pressed = current_row & col_mask;
      00983D ED               [12] 1091 	mov	a,r5
      00983E 52 02            [12] 1092 	anl	ar2,a
                                   1093 ;	assignBit
      009840 EA               [12] 1094 	mov	a,r2
      009841 24 FF            [12] 1095 	add	a,#0xff
      009843 E4               [12] 1096 	clr	a
      009844 33               [12] 1097 	rlc	a
      009845 FA               [12] 1098 	mov	r2,a
                                   1099 ;	quantum/keyboard.c:607: if (process_keypress) {
      009846 EF               [12] 1100 	mov	a,r7
      009847 60 3E            [24] 1101 	jz	00112$
                                   1102 ;	quantum/keyboard.c:609: MAKE_KEYEVENT(row, col, key_pressed);
      009849 90 0B AF         [24] 1103 	mov	dptr,#_matrix_task_dummy_event_90004_529
      00984C EC               [12] 1104 	mov	a,r4
      00984D F0               [24] 1105 	movx	@dptr,a
      00984E 90 0B B0         [24] 1106 	mov	dptr,#(_matrix_task_dummy_event_90004_529 + 0x0001)
      009851 EE               [12] 1107 	mov	a,r6
      009852 F0               [24] 1108 	movx	@dptr,a
      009853 12 4B 1F         [24] 1109 	lcall	_timer_read
      009856 A9 82            [24] 1110 	mov	r1, dpl
      009858 AB 83            [24] 1111 	mov	r3, dph
      00985A 90 0B B1         [24] 1112 	mov	dptr,#(_matrix_task_dummy_event_90004_529 + 0x0002)
      00985D E9               [12] 1113 	mov	a,r1
      00985E F0               [24] 1114 	movx	@dptr,a
      00985F EB               [12] 1115 	mov	a,r3
      009860 A3               [24] 1116 	inc	dptr
      009861 F0               [24] 1117 	movx	@dptr,a
      009862 90 0B B3         [24] 1118 	mov	dptr,#(_matrix_task_dummy_event_90004_529 + 0x0004)
      009865 74 01            [12] 1119 	mov	a,#0x01
      009867 F0               [24] 1120 	movx	@dptr,a
      009868 90 0B B4         [24] 1121 	mov	dptr,#(_matrix_task_dummy_event_90004_529 + 0x0005)
      00986B EA               [12] 1122 	mov	a,r2
      00986C F0               [24] 1123 	movx	@dptr,a
                                   1124 ;	quantum/keyboard.c:610: AK820_ACTION_EXEC(dummy_event);
      00986D 90 0B AF         [24] 1125 	mov	dptr,#_matrix_task_dummy_event_90004_529
      009870 C0 07            [24] 1126 	push	ar7
      009872 C0 06            [24] 1127 	push	ar6
      009874 C0 05            [24] 1128 	push	ar5
      009876 C0 04            [24] 1129 	push	ar4
      009878 C0 02            [24] 1130 	push	ar2
      00987A 12 74 E2         [24] 1131 	lcall	_ak820_action_exec
      00987D D0 02            [24] 1132 	pop	ar2
      00987F D0 04            [24] 1133 	pop	ar4
      009881 D0 05            [24] 1134 	pop	ar5
      009883 D0 06            [24] 1135 	pop	ar6
      009885 D0 07            [24] 1136 	pop	ar7
      009887                       1137 00112$:
                                   1138 ;	quantum/keyboard.c:613: switch_events(row, col, key_pressed);
      009887 90 0B 87         [24] 1139 	mov	dptr,#_switch_events_PARM_2
      00988A EC               [12] 1140 	mov	a,r4
      00988B F0               [24] 1141 	movx	@dptr,a
      00988C 90 0B 88         [24] 1142 	mov	dptr,#_switch_events_PARM_3
      00988F EA               [12] 1143 	mov	a,r2
      009890 F0               [24] 1144 	movx	@dptr,a
      009891 8E 82            [24] 1145 	mov	dpl, r6
      009893 C0 07            [24] 1146 	push	ar7
      009895 C0 06            [24] 1147 	push	ar6
      009897 C0 05            [24] 1148 	push	ar5
      009899 C0 04            [24] 1149 	push	ar4
      00989B 12 96 F8         [24] 1150 	lcall	_switch_events
      00989E D0 04            [24] 1151 	pop	ar4
      0098A0 D0 05            [24] 1152 	pop	ar5
      0098A2 D0 06            [24] 1153 	pop	ar6
      0098A4 D0 07            [24] 1154 	pop	ar7
      0098A6                       1155 00131$:
                                   1156 ;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
      0098A6 0C               [12] 1157 	inc	r4
      0098A7 90 0B AE         [24] 1158 	mov	dptr,#_matrix_task_col_mask_30004_523
      0098AA E0               [24] 1159 	movx	a,@dptr
      0098AB 25 E0            [12] 1160 	add	a,acc
      0098AD F0               [24] 1161 	movx	@dptr,a
      0098AE 02 98 28         [24] 1162 	ljmp	00130$
      0098B1                       1163 00115$:
                                   1164 ;	quantum/keyboard.c:617: matrix_previous[row] = current_row;
      0098B1 EE               [12] 1165 	mov	a,r6
      0098B2 12 98 E2         [24] 1166 	lcall	_ak820_outline_0066
      0098B5 ED               [12] 1167 	mov	a,r5
      0098B6 F0               [24] 1168 	movx	@dptr,a
      0098B7                       1169 00116$:
                                   1170 ;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      0098B7 0E               [12] 1171 	inc	r6
      0098B8 02 97 FD         [24] 1172 	ljmp	00133$
      0098BB                       1173 00117$:
                                   1174 ;	quantum/keyboard.c:620: return matrix_changed;
      0098BB 75 82 01         [24] 1175 	mov	dpl, #0x01
                                   1176 ;	quantum/keyboard.c:621: }
      0098BE 22               [24] 1177 	ret
                                   1178 ;------------------------------------------------------------
                                   1179 ;Allocation info for local variables in function 'quantum_task'
                                   1180 ;------------------------------------------------------------
                                   1181 ;	quantum/keyboard.c:627: void quantum_task(void) {
                                   1182 ;	-----------------------------------------
                                   1183 ;	 function quantum_task
                                   1184 ;	-----------------------------------------
      0098BF                       1185 _quantum_task:
                                   1186 ;	quantum/keyboard.c:694: caps_word_task();
                                   1187 ;	quantum/keyboard.c:700: }
      0098BF 02 2E FF         [24] 1188 	ljmp	_caps_word_task
                                   1189 ;------------------------------------------------------------
                                   1190 ;Allocation info for local variables in function 'keyboard_task'
                                   1191 ;------------------------------------------------------------
                                   1192 ;activity_has_occurred Allocated with name '_keyboard_task_activity_has_occurred_10000_544'
                                   1193 ;------------------------------------------------------------
                                   1194 ;	quantum/keyboard.c:703: void keyboard_task(void) {
                                   1195 ;	-----------------------------------------
                                   1196 ;	 function keyboard_task
                                   1197 ;	-----------------------------------------
      0098C2                       1198 _keyboard_task:
                                   1199 ;	quantum/keyboard.c:705: if (matrix_task()) {
      0098C2 12 97 19         [24] 1200 	lcall	_matrix_task
      0098C5 E5 82            [12] 1201 	mov	a, dpl
      0098C7 60 03            [24] 1202 	jz	00102$
                                   1203 ;	quantum/keyboard.c:706: last_matrix_activity_trigger();
      0098C9 12 96 9C         [24] 1204 	lcall	_last_matrix_activity_trigger
                                   1205 ;	quantum/keyboard.c:707: activity_has_occurred = true;
      0098CC                       1206 00102$:
                                   1207 ;	quantum/keyboard.c:710: quantum_task();
      0098CC 12 98 BF         [24] 1208 	lcall	_quantum_task
                                   1209 ;	quantum/keyboard.c:724: rgb_matrix_task();
      0098CF 12 56 5A         [24] 1210 	lcall	_rgb_matrix_task
                                   1211 ;	quantum/keyboard.c:734: if (encoder_read()) {
      0098D2 12 95 FF         [24] 1212 	lcall	_encoder_read
      0098D5 E5 82            [12] 1213 	mov	a, dpl
      0098D7 60 03            [24] 1214 	jz	00104$
                                   1215 ;	quantum/keyboard.c:735: last_encoder_activity_trigger();
      0098D9 12 96 AF         [24] 1216 	lcall	_last_encoder_activity_trigger
                                   1217 ;	quantum/keyboard.c:736: activity_has_occurred = true;
      0098DC                       1218 00104$:
                                   1219 ;	quantum/keyboard.c:765: mousekey_task();
      0098DC 12 53 48         [24] 1220 	lcall	_mousekey_task
                                   1221 ;	quantum/keyboard.c:790: led_task();
                                   1222 ;	quantum/keyboard.c:791: }
      0098DF 02 9B C2         [24] 1223 	ljmp	_led_task
                                   1224 	.area CSEG    (CODE)
                                   1225 	.area CONST   (CODE)
                                   1226 	.area XINIT   (CODE)
      00C490                       1227 __xinit__last_input_modification_time:
      00C490 00 00 00 00           1228 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C494                       1229 __xinit__last_matrix_modification_time:
      00C494 00 00 00 00           1230 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C498                       1231 __xinit__last_encoder_modification_time:
      00C498 00 00 00 00           1232 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C49C                       1233 __xinit__last_pointing_device_modification_time:
      00C49C 00 00 00 00           1234 	.byte #0x00, #0x00, #0x00, #0x00	; 0
                                   1235 	.area CABS    (ABS,CODE)
                                   1236 
                                   1237 ; Experimental exact instruction outlining.
                                   1238 	.globl _ak820_outline_0007
                                   1239 	.globl _ak820_outline_0056
                                   1240 	.globl _ak820_outline_0058
                                   1241 	.globl _ak820_outline_0059
                                   1242 	.globl _ak820_outline_0066
                                   1243 	.globl _ak820_outline_0070
                                   1244 	.globl _ak820_outline_0130
                                   1245 	.globl _ak820_outline_0147
                                   1246 
                                   1247 	.area CSEG (CODE)
                                   1248 ; function ak820_outline_0066
      0098E2                       1249 _ak820_outline_0066:
      0098E2 24 94            [12] 1250 	add	a,#_matrix_task_matrix_previous_10001_510
      0098E4 F5 82            [12] 1251 	mov	dpl,a
      0098E6 E4               [12] 1252 	clr	a
      0098E7 34 0B            [12] 1253 	addc	a,#(_matrix_task_matrix_previous_10001_510>>8)
      0098E9 F5 83            [12] 1254 	mov	dph,a
      0098EB 22               [24] 1255 	ret
