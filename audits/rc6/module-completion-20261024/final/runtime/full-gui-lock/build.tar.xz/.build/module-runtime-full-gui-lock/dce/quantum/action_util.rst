                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_gui_process
                                    269 	.globl _ak820_macro_change
                                    270 	.globl _add_owned_mods
                                    271 	.globl _del_owned_mods
                                    272 	.globl _add_owned_weak_mods
                                    273 	.globl _del_owned_weak_mods
                                    274 	.globl _clear_owned_mods
                                    275 	.globl _clear_owned_keys
                                    276 	.globl _add_owned_key
                                    277 	.globl _del_owned_key
                                    278 	.globl _clear_owned_usages
                                    279 	.globl _owned_usage_key
                                    280 	.globl _send_keyboard_report
                                    281 	.globl _get_mods
                                    282 	.globl _clear_mods
                                    283 	.globl _get_weak_mods
                                    284 	.globl _add_weak_mods
                                    285 	.globl _del_weak_mods
                                    286 	.globl _clear_weak_mods
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 	.area	OSEG    (OVR,DATA)
      000054                        553 _change_owned_sloc1_1_0:
      000054                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      00001E                        568 _gui_disabled:
      00001E                        569 	.ds 1
      00001F                        570 _ak820_gui_process_sloc0_1_0:
      00001F                        571 	.ds 1
      000020                        572 _ak820_macro_change_sloc0_1_0:
      000020                        573 	.ds 1
      000021                        574 _change_owned_sloc0_1_0:
      000021                        575 	.ds 1
      000022                        576 _owned_usage_key_sloc0_1_0:
      000022                        577 	.ds 1
                                    578 ;--------------------------------------------------------
                                    579 ; paged external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area PSEG    (PAG,XDATA)
                                    582 ;--------------------------------------------------------
                                    583 ; uninitialized external ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area XSEG    (XDATA)
      000968                        586 _ak820_gui_process_PARM_2:
      000968                        587 	.ds 1
      000969                        588 _ak820_gui_process_code_10000_294:
      000969                        589 	.ds 2
      00096B                        590 _owned_mod_refs:
      00096B                        591 	.ds 8
      000973                        592 _owned_weak_refs:
      000973                        593 	.ds 8
      00097B                        594 _owned_mods:
      00097B                        595 	.ds 1
      00097C                        596 _owned_weak_mods:
      00097C                        597 	.ds 1
      00097D                        598 _macro_mods:
      00097D                        599 	.ds 2
      00097F                        600 _ak820_macro_primitive::
      00097F                        601 	.ds 1
      000980                        602 _ak820_macro_cancelled::
      000980                        603 	.ds 1
      000981                        604 _ak820_macro_change_PARM_2:
      000981                        605 	.ds 1
      000982                        606 _ak820_macro_change_PARM_3:
      000982                        607 	.ds 1
      000983                        608 _ak820_macro_change_bits_10000_299:
      000983                        609 	.ds 2
      000985                        610 _change_owned_PARM_2:
      000985                        611 	.ds 1
      000986                        612 _change_owned_mods_10000_304:
      000986                        613 	.ds 1
      000987                        614 _change_owned_result_10001_308:
      000987                        615 	.ds 1
      000988                        616 _change_owned_bit_20001_309:
      000988                        617 	.ds 1
      000989                        618 _add_owned_mods_mods_10000_317:
      000989                        619 	.ds 1
      00098A                        620 _del_owned_mods_mods_10000_319:
      00098A                        621 	.ds 1
      00098B                        622 _add_owned_weak_mods_mods_10000_321:
      00098B                        623 	.ds 1
      00098C                        624 _del_owned_weak_mods_mods_10000_323:
      00098C                        625 	.ds 1
      00098D                        626 _key_refs:
      00098D                        627 	.ds 165
      000A32                        628 _distinct_keys:
      000A32                        629 	.ds 1
      000A33                        630 _macro_keys:
      000A33                        631 	.ds 21
      000A48                        632 _add_owned_key_code_10000_332:
      000A48                        633 	.ds 1
      000A49                        634 _del_owned_key_code_10000_347:
      000A49                        635 	.ds 1
      000A4A                        636 _usage_refs:
      000A4A                        637 	.ds 30
      000A68                        638 _usage_order:
      000A68                        639 	.ds 30
      000A86                        640 _usage_lengths:
      000A86                        641 	.ds 2
      000A88                        642 _macro_usages:
      000A88                        643 	.ds 4
      000A8C                        644 _owned_usage_key_PARM_2:
      000A8C                        645 	.ds 1
      000A8D                        646 _owned_usage_key_code_10000_374:
      000A8D                        647 	.ds 1
      000A8E                        648 _owned_usage_key___200000085_20000_375:
      000A8E                        649 	.ds 2
      000A90                        650 _owned_usage_key_which_10000_375:
      000A90                        651 	.ds 1
      000A91                        652 _owned_usage_key_count_10000_375:
      000A91                        653 	.ds 1
      000A92                        654 _owned_usage_key_pos_30001_382:
      000A92                        655 	.ds 1
      000A93                        656 _owned_usage_key_key_40000_387:
      000A93                        657 	.ds 1
      000A94                        658 _send_keyboard_report_last_report_10001_395:
      000A94                        659 	.ds 32
      000AB4                        660 _send_keyboard_report_changed_10001_395:
      000AB4                        661 	.ds 1
      000AB5                        662 _add_weak_mods_mods_10000_413:
      000AB5                        663 	.ds 1
      000AB6                        664 _del_weak_mods_mods_10000_415:
      000AB6                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000D96                        674 _real_mods:
      000D96                        675 	.ds 1
      000D97                        676 _weak_mods:
      000D97                        677 	.ds 1
      000D98                        678 _actual_keyboard_report::
      000D98                        679 	.ds 32
                                    680 	.area HOME    (CODE)
                                    681 	.area GSINIT0 (CODE)
                                    682 	.area GSINIT1 (CODE)
                                    683 	.area GSINIT2 (CODE)
                                    684 	.area GSINIT3 (CODE)
                                    685 	.area GSINIT4 (CODE)
                                    686 	.area GSINIT5 (CODE)
                                    687 	.area GSINIT  (CODE)
                                    688 	.area GSFINAL (CODE)
                                    689 	.area CSEG    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; global & static initialisations
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area GSINIT  (CODE)
                                    695 	.area GSFINAL (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    708 ;------------------------------------------------------------
                                    709 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    710 ;------------------------------------------------------------
                                    711 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function ak820_gui_process
                                    722 ;	-----------------------------------------
      007A8B                        723 _ak820_gui_process:
      007A8B 12 38 43         [24]  724 	lcall	_ak820_outline_0103
      007A8E 90 09 69         [24]  725 	mov	dptr,#_ak820_gui_process_code_10000_294
      007A91 12 38 48         [24]  726 	lcall	_ak820_outline_0104
                                    727 ;	quantum/action_util.c:80: if (code < QK_MAGIC_GUI_ON || code > QK_MAGIC_TOGGLE_GUI) return true;
      007A94 90 09 69         [24]  728 	mov	dptr,#_ak820_gui_process_code_10000_294
      007A97 12 38 00         [24]  729 	lcall	_ak820_outline_0050
      007A9A C3               [12]  730 	clr	c
      007A9B EE               [12]  731 	mov	a,r6
      007A9C 94 09            [12]  732 	subb	a,#0x09
      007A9E EF               [12]  733 	mov	a,r7
      007A9F 94 70            [12]  734 	subb	a,#0x70
      007AA1 40 08            [24]  735 	jc	00101$
      007AA3 74 0B            [12]  736 	mov	a,#0x0b
      007AA5 9E               [12]  737 	subb	a,r6
      007AA6 74 70            [12]  738 	mov	a,#0x70
      007AA8 9F               [12]  739 	subb	a,r7
      007AA9 50 04            [24]  740 	jnc	00102$
                                    741 ;	free result
      007AAB                        742 00101$:
      007AAB 75 82 01         [24]  743 	mov	dpl, #0x01
      007AAE 22               [24]  744 	ret
      007AAF                        745 00102$:
                                    746 ;	quantum/action_util.c:81: if (pressed) {
      007AAF 90 09 68         [24]  747 	mov	dptr,#_ak820_gui_process_PARM_2
      007AB2 E0               [24]  748 	movx	a,@dptr
      007AB3 60 21            [24]  749 	jz	00105$
                                    750 ;	quantum/action_util.c:82: gui_disabled = code == QK_MAGIC_TOGGLE_GUI ? !gui_disabled : code == QK_MAGIC_GUI_OFF;
      007AB5 BE 0B 0D         [24]  751 	cjne	r6,#0x0b,00108$
      007AB8 BF 70 0A         [24]  752 	cjne	r7,#0x70,00108$
      007ABB A2 1E            [12]  753 	mov	c,_gui_disabled
      007ABD B3               [12]  754 	cpl	c
      007ABE 92 1F            [24]  755 	mov  _ak820_gui_process_sloc0_1_0,c
      007AC0 E4               [12]  756 	clr	a
      007AC1 33               [12]  757 	rlc	a
      007AC2 FD               [12]  758 	mov	r5,a
      007AC3 80 09            [24]  759 	sjmp	00109$
      007AC5                        760 00108$:
      007AC5 E4               [12]  761 	clr	a
      007AC6 BE 0A 04         [24]  762 	cjne	r6,#0x0a,00136$
      007AC9 BF 70 01         [24]  763 	cjne	r7,#0x70,00136$
      007ACC 04               [12]  764 	inc	a
      007ACD                        765 00136$:
      007ACD FD               [12]  766 	mov	r5,a
      007ACE                        767 00109$:
                                    768 ;	assignBit
      007ACE ED               [12]  769 	mov	a,r5
      007ACF 24 FF            [12]  770 	add	a,#0xff
      007AD1 92 1E            [24]  771 	mov	_gui_disabled,c
                                    772 ;	quantum/action_util.c:83: send_keyboard_report();
      007AD3 12 7F 52         [24]  773 	lcall	_send_keyboard_report
      007AD6                        774 00105$:
                                    775 ;	quantum/action_util.c:85: return false;
      007AD6 75 82 00         [24]  776 	mov	dpl, #0x00
                                    777 ;	quantum/action_util.c:89: }
      007AD9 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'ak820_macro_change'
                                    781 ;------------------------------------------------------------
                                    782 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    783 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    784 ;bits          Allocated with name '_ak820_macro_change_bits_10000_299'
                                    785 ;mask          Allocated with name '_ak820_macro_change_mask_10001_302'
                                    786 ;------------------------------------------------------------
                                    787 ;	quantum/action_util.c:98: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    788 ;	-----------------------------------------
                                    789 ;	 function ak820_macro_change
                                    790 ;	-----------------------------------------
      007ADA                        791 _ak820_macro_change:
      007ADA 12 38 43         [24]  792 	lcall	_ak820_outline_0103
      007ADD 90 09 83         [24]  793 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007AE0 12 38 48         [24]  794 	lcall	_ak820_outline_0104
                                    795 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      007AE3 90 09 7F         [24]  796 	mov	dptr,#_ak820_macro_primitive
      007AE6 E0               [24]  797 	movx	a,@dptr
      007AE7 70 04            [24]  798 	jnz	00102$
      007AE9 75 82 01         [24]  799 	mov	dpl, #0x01
      007AEC 22               [24]  800 	ret
      007AED                        801 00102$:
                                    802 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      007AED 90 09 81         [24]  803 	mov	dptr,#_ak820_macro_change_PARM_2
      007AF0 E0               [24]  804 	movx	a,@dptr
      007AF1 FF               [12]  805 	mov	r7,a
      007AF2 74 07            [12]  806 	mov	a,#0x07
      007AF4 5F               [12]  807 	anl	a,r7
      007AF5 12 76 30         [24]  808 	lcall	_ak820_outline_0062
      007AF8 80 02            [24]  809 	sjmp	00123$
      007AFA                        810 00122$:
      007AFA 25 E0            [12]  811 	add	a,acc
      007AFC                        812 00123$:
      007AFC D5 F0 FB         [24]  813 	djnz	b,00122$
      007AFF FE               [12]  814 	mov	r6,a
                                    815 ;	quantum/action_util.c:101: bits += index >> 3;
      007B00 EF               [12]  816 	mov	a,r7
      007B01 12 56 F5         [24]  817 	lcall	_ak820_outline_0183
      007B04 FF               [12]  818 	mov	r7,a
      007B05 90 09 83         [24]  819 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007B08 12 38 1F         [24]  820 	lcall	_ak820_outline_0059
      007B0B 90 09 83         [24]  821 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007B0E EF               [12]  822 	mov	a,r7
      007B0F 2C               [12]  823 	add	a, r4
      007B10 F0               [24]  824 	movx	@dptr,a
      007B11 E4               [12]  825 	clr	a
      007B12 3D               [12]  826 	addc	a, r5
      007B13 A3               [24]  827 	inc	dptr
      007B14 F0               [24]  828 	movx	@dptr,a
                                    829 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      007B15 90 09 83         [24]  830 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007B18 E0               [24]  831 	movx	a,@dptr
      007B19 FD               [12]  832 	mov	r5,a
      007B1A A3               [24]  833 	inc	dptr
      007B1B E0               [24]  834 	movx	a,@dptr
      007B1C FF               [12]  835 	mov	r7,a
      007B1D 12 80 6B         [24]  836 	lcall	_ak820_outline_0184
      007B20 E0               [24]  837 	movx	a,@dptr
      007B21 FC               [12]  838 	mov	r4,a
      007B22 EE               [12]  839 	mov	a,r6
      007B23 5C               [12]  840 	anl	a,r4
      007B24 B4 01 00         [24]  841 	cjne	a,#0x01,00124$
      007B27                        842 00124$:
      007B27 B3               [12]  843 	cpl	c
      007B28 92 20            [24]  844 	mov	_ak820_macro_change_sloc0_1_0,c
      007B2A 90 09 82         [24]  845 	mov	dptr,#_ak820_macro_change_PARM_3
      007B2D E0               [24]  846 	movx	a,@dptr
      007B2E FB               [12]  847 	mov	r3,a
      007B2F A2 20            [12]  848 	mov	c,_ak820_macro_change_sloc0_1_0
      007B31 E4               [12]  849 	clr	a
      007B32 33               [12]  850 	rlc	a
      007B33 B5 03 04         [24]  851 	cjne	a,ar3,00104$
      007B36 75 82 00         [24]  852 	mov	dpl, #0x00
      007B39 22               [24]  853 	ret
      007B3A                        854 00104$:
                                    855 ;	quantum/action_util.c:103: *bits ^= mask;
      007B3A EC               [12]  856 	mov	a,r4
      007B3B 62 06            [12]  857 	xrl	ar6,a
      007B3D 12 80 6B         [24]  858 	lcall	_ak820_outline_0184
      007B40 EE               [12]  859 	mov	a,r6
      007B41 F0               [24]  860 	movx	@dptr,a
                                    861 ;	quantum/action_util.c:104: return true;
      007B42 75 82 01         [24]  862 	mov	dpl, #0x01
                                    863 ;	quantum/action_util.c:105: }
      007B45 22               [24]  864 	ret
                                    865 ;------------------------------------------------------------
                                    866 ;Allocation info for local variables in function 'change_owned'
                                    867 ;------------------------------------------------------------
                                    868 ;mode          Allocated with name '_change_owned_PARM_2'
                                    869 ;mods          Allocated with name '_change_owned_mods_10000_304'
                                    870 ;kind          Allocated with name '_change_owned_kind_10000_305'
                                    871 ;pressed       Allocated with name '_change_owned_pressed_10000_305'
                                    872 ;refs          Allocated with name '_change_owned_refs_10000_305'
                                    873 ;old           Allocated with name '_change_owned_old_30000_307'
                                    874 ;result        Allocated with name '_change_owned_result_10001_308'
                                    875 ;i             Allocated with name '_change_owned_i_20001_309'
                                    876 ;bit           Allocated with name '_change_owned_bit_20001_309'
                                    877 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    878 ;------------------------------------------------------------
                                    879 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    880 ;	-----------------------------------------
                                    881 ;	 function change_owned
                                    882 ;	-----------------------------------------
      007B46                        883 _change_owned:
      007B46 E5 82            [12]  884 	mov	a,dpl
      007B48 90 09 86         [24]  885 	mov	dptr,#_change_owned_mods_10000_304
      007B4B F0               [24]  886 	movx	@dptr,a
                                    887 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      007B4C 90 09 85         [24]  888 	mov	dptr,#_change_owned_PARM_2
      007B4F E0               [24]  889 	movx	a,@dptr
      007B50 FF               [12]  890 	mov	r7,a
      007B51 C3               [12]  891 	clr	c
      007B52 13               [12]  892 	rrc	a
      007B53 FE               [12]  893 	mov	r6,a
                                    894 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      007B54 53 07 01         [24]  895 	anl	ar7,#0x01
      007B57 EF               [12]  896 	mov	a,r7
      007B58 B4 01 00         [24]  897 	cjne	a,#0x01,00205$
      007B5B                        898 00205$:
      007B5B 92 21            [24]  899 	mov  _change_owned_sloc0_1_0,c
      007B5D B3               [12]  900 	cpl	c
      007B5E E4               [12]  901 	clr	a
      007B5F 33               [12]  902 	rlc	a
      007B60 F5 54            [12]  903 	mov	_change_owned_sloc1_1_0,a
                                    904 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007B62 EE               [12]  905 	mov	a,r6
      007B63 60 06            [24]  906 	jz	00121$
      007B65 7D 73            [12]  907 	mov	r5,#_owned_weak_refs
      007B67 7F 09            [12]  908 	mov	r7,#(_owned_weak_refs >> 8)
      007B69 80 04            [24]  909 	sjmp	00122$
      007B6B                        910 00121$:
      007B6B 7D 6B            [12]  911 	mov	r5,#_owned_mod_refs
      007B6D 7F 09            [12]  912 	mov	r7,#(_owned_mod_refs >> 8)
      007B6F                        913 00122$:
                                    914 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      007B6F 90 09 7F         [24]  915 	mov	dptr,#_ak820_macro_primitive
      007B72 E0               [24]  916 	movx	a,@dptr
      007B73 60 37            [24]  917 	jz	00102$
                                    918 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      007B75 EE               [12]  919 	mov	a,r6
      007B76 24 7D            [12]  920 	add	a, #_macro_mods
      007B78 FB               [12]  921 	mov	r3,a
      007B79 E4               [12]  922 	clr	a
      007B7A 34 09            [12]  923 	addc	a, #(_macro_mods >> 8)
      007B7C FC               [12]  924 	mov	r4,a
      007B7D 12 48 5C         [24]  925 	lcall	_ak820_outline_0064
                                    926 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007B80 E5 54            [12]  927 	mov	a,_change_owned_sloc1_1_0
      007B82 60 0A            [24]  928 	jz	00123$
      007B84 90 09 86         [24]  929 	mov	dptr,#_change_owned_mods_10000_304
      007B87 E0               [24]  930 	movx	a,@dptr
      007B88 F9               [12]  931 	mov	r1,a
      007B89 EA               [12]  932 	mov	a,r2
      007B8A 42 01            [12]  933 	orl	ar1,a
      007B8C 80 07            [24]  934 	sjmp	00124$
      007B8E                        935 00123$:
      007B8E 90 09 86         [24]  936 	mov	dptr,#_change_owned_mods_10000_304
      007B91 E0               [24]  937 	movx	a,@dptr
      007B92 F4               [12]  938 	cpl	a
      007B93 5A               [12]  939 	anl	a,r2
      007B94 F9               [12]  940 	mov	r1,a
      007B95                        941 00124$:
      007B95 12 33 FC         [24]  942 	lcall	_ak820_outline_0122
      007B98 E9               [12]  943 	mov	a,r1
      007B99 F0               [24]  944 	movx	@dptr,a
                                    945 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      007B9A E5 54            [12]  946 	mov	a,_change_owned_sloc1_1_0
      007B9C 60 06            [24]  947 	jz	00125$
      007B9E 74 FF            [12]  948 	mov	a,#0xff
      007BA0 6A               [12]  949 	xrl	a,r2
      007BA1 FC               [12]  950 	mov	r4,a
      007BA2 80 02            [24]  951 	sjmp	00126$
      007BA4                        952 00125$:
      007BA4 8A 04            [24]  953 	mov	ar4,r2
      007BA6                        954 00126$:
      007BA6 90 09 86         [24]  955 	mov	dptr,#_change_owned_mods_10000_304
      007BA9 E0               [24]  956 	movx	a,@dptr
      007BAA 5C               [12]  957 	anl	a,r4
      007BAB F0               [24]  958 	movx	@dptr,a
      007BAC                        959 00102$:
                                    960 ;	quantum/action_util.c:115: uint8_t result = 0;
      007BAC 90 09 87         [24]  961 	mov	dptr,#_change_owned_result_10001_308
      007BAF E4               [12]  962 	clr	a
      007BB0 F0               [24]  963 	movx	@dptr,a
                                    964 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007BB1 90 09 88         [24]  965 	mov	dptr,#_change_owned_bit_20001_309
      007BB4 04               [12]  966 	inc	a
      007BB5 F0               [24]  967 	movx	@dptr,a
      007BB6 90 09 86         [24]  968 	mov	dptr,#_change_owned_mods_10000_304
      007BB9 E0               [24]  969 	movx	a,@dptr
      007BBA FC               [12]  970 	mov	r4,a
      007BBB 7B 00            [12]  971 	mov	r3,#0x00
      007BBD                        972 00117$:
      007BBD BB 08 00         [24]  973 	cjne	r3,#0x08,00210$
      007BC0                        974 00210$:
      007BC0 50 3F            [24]  975 	jnc	00112$
                                    976 ;	quantum/action_util.c:117: if (mods & bit) {
      007BC2 90 09 88         [24]  977 	mov	dptr,#_change_owned_bit_20001_309
      007BC5 E0               [24]  978 	movx	a,@dptr
      007BC6 5C               [12]  979 	anl	a,r4
      007BC7 60 1C            [24]  980 	jz	00109$
                                    981 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      007BC9 E5 54            [12]  982 	mov	a,_change_owned_sloc1_1_0
      007BCB 60 0C            [24]  983 	jz	00106$
      007BCD EB               [12]  984 	mov	a,r3
      007BCE 2D               [12]  985 	add	a, r5
      007BCF 12 37 D5         [24]  986 	lcall	_ak820_outline_0013
      007BD2 F8               [12]  987 	mov	r0,a
      007BD3 08               [12]  988 	inc	r0
      007BD4 12 80 1F         [24]  989 	lcall	_ak820_outline_0063
      007BD7 80 0C            [24]  990 	sjmp	00109$
      007BD9                        991 00106$:
                                    992 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      007BD9 EB               [12]  993 	mov	a,r3
      007BDA 2D               [12]  994 	add	a, r5
      007BDB 12 37 D5         [24]  995 	lcall	_ak820_outline_0013
      007BDE F8               [12]  996 	mov	r0,a
      007BDF 60 04            [24]  997 	jz	00109$
      007BE1 18               [12]  998 	dec	r0
      007BE2 12 80 1F         [24]  999 	lcall	_ak820_outline_0063
      007BE5                       1000 00109$:
                                   1001 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      007BE5 EB               [12] 1002 	mov	a,r3
      007BE6 2D               [12] 1003 	add	a, r5
      007BE7 12 37 D5         [24] 1004 	lcall	_ak820_outline_0013
      007BEA 60 0B            [24] 1005 	jz	00118$
      007BEC 90 09 88         [24] 1006 	mov	dptr,#_change_owned_bit_20001_309
      007BEF E0               [24] 1007 	movx	a,@dptr
      007BF0 FA               [12] 1008 	mov	r2,a
      007BF1 90 09 87         [24] 1009 	mov	dptr,#_change_owned_result_10001_308
      007BF4 E0               [24] 1010 	movx	a,@dptr
      007BF5 4A               [12] 1011 	orl	a,r2
      007BF6 F0               [24] 1012 	movx	@dptr,a
      007BF7                       1013 00118$:
                                   1014 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007BF7 0B               [12] 1015 	inc	r3
      007BF8 90 09 88         [24] 1016 	mov	dptr,#_change_owned_bit_20001_309
      007BFB E0               [24] 1017 	movx	a,@dptr
      007BFC 25 E0            [12] 1018 	add	a,acc
      007BFE F0               [24] 1019 	movx	@dptr,a
      007BFF 80 BC            [24] 1020 	sjmp	00117$
      007C01                       1021 00112$:
                                   1022 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      007C01 EE               [12] 1023 	mov	a,r6
      007C02 60 09            [24] 1024 	jz	00114$
      007C04 90 09 87         [24] 1025 	mov	dptr,#_change_owned_result_10001_308
      007C07 E0               [24] 1026 	movx	a,@dptr
      007C08 90 09 7C         [24] 1027 	mov	dptr,#_owned_weak_mods
      007C0B F0               [24] 1028 	movx	@dptr,a
      007C0C 22               [24] 1029 	ret
      007C0D                       1030 00114$:
                                   1031 ;	quantum/action_util.c:124: else owned_mods = result;
      007C0D 90 09 87         [24] 1032 	mov	dptr,#_change_owned_result_10001_308
      007C10 E0               [24] 1033 	movx	a,@dptr
      007C11 90 09 7B         [24] 1034 	mov	dptr,#_owned_mods
      007C14 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	quantum/action_util.c:125: }
      007C15 22               [24] 1037 	ret
                                   1038 ;------------------------------------------------------------
                                   1039 ;Allocation info for local variables in function 'add_owned_mods'
                                   1040 ;------------------------------------------------------------
                                   1041 ;mods          Allocated with name '_add_owned_mods_mods_10000_317'
                                   1042 ;------------------------------------------------------------
                                   1043 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1044 ;	-----------------------------------------
                                   1045 ;	 function add_owned_mods
                                   1046 ;	-----------------------------------------
      007C16                       1047 _add_owned_mods:
      007C16 E5 82            [12] 1048 	mov	a,dpl
      007C18 90 09 89         [24] 1049 	mov	dptr,#_add_owned_mods_mods_10000_317
      007C1B 12 80 3F         [24] 1050 	lcall	_ak820_outline_0113
      007C1E 74 01            [12] 1051 	mov	a,#0x01
      007C20 F0               [24] 1052 	movx	@dptr,a
      007C21 8F 82            [24] 1053 	mov	dpl, r7
      007C23 02 7B 46         [24] 1054 	ljmp	_change_owned
                                   1055 ;------------------------------------------------------------
                                   1056 ;Allocation info for local variables in function 'del_owned_mods'
                                   1057 ;------------------------------------------------------------
                                   1058 ;mods          Allocated with name '_del_owned_mods_mods_10000_319'
                                   1059 ;------------------------------------------------------------
                                   1060 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1061 ;	-----------------------------------------
                                   1062 ;	 function del_owned_mods
                                   1063 ;	-----------------------------------------
      007C26                       1064 _del_owned_mods:
      007C26 E5 82            [12] 1065 	mov	a,dpl
      007C28 90 09 8A         [24] 1066 	mov	dptr,#_del_owned_mods_mods_10000_319
      007C2B 12 80 3F         [24] 1067 	lcall	_ak820_outline_0113
      007C2E E4               [12] 1068 	clr	a
      007C2F F0               [24] 1069 	movx	@dptr,a
      007C30 8F 82            [24] 1070 	mov	dpl, r7
      007C32 02 7B 46         [24] 1071 	ljmp	_change_owned
                                   1072 ;------------------------------------------------------------
                                   1073 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1074 ;------------------------------------------------------------
                                   1075 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_321'
                                   1076 ;------------------------------------------------------------
                                   1077 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1078 ;	-----------------------------------------
                                   1079 ;	 function add_owned_weak_mods
                                   1080 ;	-----------------------------------------
      007C35                       1081 _add_owned_weak_mods:
      007C35 E5 82            [12] 1082 	mov	a,dpl
      007C37 90 09 8B         [24] 1083 	mov	dptr,#_add_owned_weak_mods_mods_10000_321
      007C3A 12 80 3F         [24] 1084 	lcall	_ak820_outline_0113
      007C3D 74 03            [12] 1085 	mov	a,#0x03
      007C3F F0               [24] 1086 	movx	@dptr,a
      007C40 8F 82            [24] 1087 	mov	dpl, r7
      007C42 02 7B 46         [24] 1088 	ljmp	_change_owned
                                   1089 ;------------------------------------------------------------
                                   1090 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1091 ;------------------------------------------------------------
                                   1092 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_323'
                                   1093 ;------------------------------------------------------------
                                   1094 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1095 ;	-----------------------------------------
                                   1096 ;	 function del_owned_weak_mods
                                   1097 ;	-----------------------------------------
      007C45                       1098 _del_owned_weak_mods:
      007C45 E5 82            [12] 1099 	mov	a,dpl
      007C47 90 09 8C         [24] 1100 	mov	dptr,#_del_owned_weak_mods_mods_10000_323
      007C4A 12 80 3F         [24] 1101 	lcall	_ak820_outline_0113
      007C4D 74 02            [12] 1102 	mov	a,#0x02
      007C4F F0               [24] 1103 	movx	@dptr,a
      007C50 8F 82            [24] 1104 	mov	dpl, r7
      007C52 02 7B 46         [24] 1105 	ljmp	_change_owned
                                   1106 ;------------------------------------------------------------
                                   1107 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1108 ;------------------------------------------------------------
                                   1109 ;i             Allocated with name '_clear_owned_mods_i_20000_327'
                                   1110 ;------------------------------------------------------------
                                   1111 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1112 ;	-----------------------------------------
                                   1113 ;	 function clear_owned_mods
                                   1114 ;	-----------------------------------------
      007C55                       1115 _clear_owned_mods:
                                   1116 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007C55 7F 00            [12] 1117 	mov	r7,#0x00
      007C57                       1118 00103$:
      007C57 BF 08 00         [24] 1119 	cjne	r7,#0x08,00122$
      007C5A                       1120 00122$:
      007C5A 50 1A            [24] 1121 	jnc	00101$
      007C5C EF               [12] 1122 	mov	a,r7
      007C5D 24 6B            [12] 1123 	add	a, #_owned_mod_refs
      007C5F FD               [12] 1124 	mov	r5,a
      007C60 E4               [12] 1125 	clr	a
      007C61 34 09            [12] 1126 	addc	a, #(_owned_mod_refs >> 8)
      007C63 FE               [12] 1127 	mov	r6,a
      007C64 EF               [12] 1128 	mov	a,r7
      007C65 24 73            [12] 1129 	add	a, #_owned_weak_refs
      007C67 F5 82            [12] 1130 	mov	dpl,a
      007C69 E4               [12] 1131 	clr	a
      007C6A 34 09            [12] 1132 	addc	a, #(_owned_weak_refs >> 8)
      007C6C F5 83            [12] 1133 	mov	dph,a
      007C6E E4               [12] 1134 	clr	a
      007C6F F0               [24] 1135 	movx	@dptr,a
      007C70 12 80 46         [24] 1136 	lcall	_ak820_outline_0118
      007C73 0F               [12] 1137 	inc	r7
      007C74 80 E1            [24] 1138 	sjmp	00103$
      007C76                       1139 00101$:
                                   1140 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007C76 90 09 7E         [24] 1141 	mov	dptr,#(_macro_mods + 0x0001)
      007C79 E4               [12] 1142 	clr	a
      007C7A F0               [24] 1143 	movx	@dptr,a
      007C7B 90 09 7D         [24] 1144 	mov	dptr,#_macro_mods
      007C7E F0               [24] 1145 	movx	@dptr,a
      007C7F 90 09 7C         [24] 1146 	mov	dptr,#_owned_weak_mods
      007C82 F0               [24] 1147 	movx	@dptr,a
      007C83 90 09 7B         [24] 1148 	mov	dptr,#_owned_mods
      007C86 F0               [24] 1149 	movx	@dptr,a
                                   1150 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      007C87 90 09 80         [24] 1151 	mov	dptr,#_ak820_macro_cancelled
      007C8A 04               [12] 1152 	inc	a
      007C8B F0               [24] 1153 	movx	@dptr,a
                                   1154 ;	quantum/action_util.c:134: }
      007C8C 22               [24] 1155 	ret
                                   1156 ;------------------------------------------------------------
                                   1157 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1158 ;------------------------------------------------------------
                                   1159 ;i             Allocated with name '_clear_owned_keys_i_20000_330'
                                   1160 ;i             Allocated with name '_clear_owned_keys_i_20000_331'
                                   1161 ;------------------------------------------------------------
                                   1162 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1163 ;	-----------------------------------------
                                   1164 ;	 function clear_owned_keys
                                   1165 ;	-----------------------------------------
      007C8D                       1166 _clear_owned_keys:
                                   1167 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007C8D 7F 00            [12] 1168 	mov	r7,#0x00
      007C8F                       1169 00104$:
      007C8F EF               [12] 1170 	mov	a,r7
      007C90 24 5B            [12] 1171 	add	a,#0xff - 0xa4
      007C92 40 0D            [24] 1172 	jc	00101$
                                   1173 ;	free result
      007C94 EF               [12] 1174 	mov	a,r7
      007C95 24 8D            [12] 1175 	add	a, #_key_refs
      007C97 F5 82            [12] 1176 	mov	dpl,a
      007C99 E4               [12] 1177 	clr	a
      007C9A 34 09            [12] 1178 	addc	a, #(_key_refs >> 8)
      007C9C 12 7A 7C         [24] 1179 	lcall	_ak820_outline_0158
      007C9F 80 EE            [24] 1180 	sjmp	00104$
      007CA1                       1181 00101$:
                                   1182 ;	quantum/action_util.c:142: distinct_keys = 0;
      007CA1 90 0A 32         [24] 1183 	mov	dptr,#_distinct_keys
      007CA4 E4               [12] 1184 	clr	a
      007CA5 F0               [24] 1185 	movx	@dptr,a
                                   1186 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007CA6 FF               [12] 1187 	mov	r7,a
      007CA7                       1188 00107$:
      007CA7 BF 15 00         [24] 1189 	cjne	r7,#0x15,00142$
      007CAA                       1190 00142$:
      007CAA 50 0D            [24] 1191 	jnc	00109$
      007CAC EF               [12] 1192 	mov	a,r7
      007CAD 24 33            [12] 1193 	add	a, #_macro_keys
      007CAF F5 82            [12] 1194 	mov	dpl,a
      007CB1 E4               [12] 1195 	clr	a
      007CB2 34 0A            [12] 1196 	addc	a, #(_macro_keys >> 8)
      007CB4 12 7A 7C         [24] 1197 	lcall	_ak820_outline_0158
      007CB7 80 EE            [24] 1198 	sjmp	00107$
      007CB9                       1199 00109$:
                                   1200 ;	quantum/action_util.c:144: }
      007CB9 22               [24] 1201 	ret
                                   1202 ;------------------------------------------------------------
                                   1203 ;Allocation info for local variables in function 'add_owned_key'
                                   1204 ;------------------------------------------------------------
                                   1205 ;code          Allocated with name '_add_owned_key_code_10000_332'
                                   1206 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_341'
                                   1207 ;key           Allocated with name '_add_owned_key_key_50000_342'
                                   1208 ;i             Allocated with name '_add_owned_key_i_40000_340'
                                   1209 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_344'
                                   1210 ;key           Allocated with name '_add_owned_key_key_40000_345'
                                   1211 ;------------------------------------------------------------
                                   1212 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1213 ;	-----------------------------------------
                                   1214 ;	 function add_owned_key
                                   1215 ;	-----------------------------------------
      007CBA                       1216 _add_owned_key:
      007CBA E5 82            [12] 1217 	mov	a,dpl
      007CBC 90 0A 48         [24] 1218 	mov	dptr,#_add_owned_key_code_10000_332
      007CBF 12 80 57         [24] 1219 	lcall	_ak820_outline_0130
                                   1220 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007CC2 74 01            [12] 1221 	mov	a,#0x01
      007CC4 F0               [24] 1222 	movx	@dptr,a
      007CC5 90 0A 33         [24] 1223 	mov	dptr,#_macro_keys
      007CC8 C0 07            [24] 1224 	push	ar7
      007CCA 12 7A DA         [24] 1225 	lcall	_ak820_macro_change
      007CCD E5 82            [12] 1226 	mov	a, dpl
      007CCF D0 07            [24] 1227 	pop	ar7
      007CD1 70 03            [24] 1228 	jnz	00102$
      007CD3 F5 82            [12] 1229 	mov	dpl,a
      007CD5 22               [24] 1230 	ret
      007CD6                       1231 00102$:
                                   1232 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      007CD6 12 80 11         [24] 1233 	lcall	_ak820_outline_0028
      007CD9 FC               [12] 1234 	mov	r4,a
      007CDA 04               [12] 1235 	inc	a
      007CDB 12 80 46         [24] 1236 	lcall	_ak820_outline_0118
      007CDE EC               [12] 1237 	mov	a,r4
      007CDF 60 04            [24] 1238 	jz	00104$
      007CE1 75 82 00         [24] 1239 	mov	dpl, #0x00
      007CE4 22               [24] 1240 	ret
      007CE5                       1241 00104$:
                                   1242 ;	quantum/action_util.c:148: ++distinct_keys;
      007CE5 90 0A 32         [24] 1243 	mov	dptr,#_distinct_keys
      007CE8 E0               [24] 1244 	movx	a,@dptr
      007CE9 24 01            [12] 1245 	add	a, #0x01
      007CEB F0               [24] 1246 	movx	@dptr,a
                                   1247 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007CEC 90 0D 85         [24] 1248 	mov	dptr,#_keyboard_protocol
      007CEF E0               [24] 1249 	movx	a,@dptr
      007CF0 60 11            [24] 1250 	jz	00106$
      007CF2 90 0A B7         [24] 1251 	mov	dptr,#_keymap_config
      007CF5 E0               [24] 1252 	movx	a,@dptr
      007CF6 30 E7 0A         [24] 1253 	jnb	acc.7,00106$
                                   1254 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007CF9 12 80 62         [24] 1255 	lcall	_ak820_outline_0171
      007CFC 12 6E 5C         [24] 1256 	lcall	_add_key_to_report
                                   1257 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007CFF 75 82 01         [24] 1258 	mov	dpl, #0x01
      007D02 22               [24] 1259 	ret
      007D03                       1260 00106$:
                                   1261 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007D03 90 0A 32         [24] 1262 	mov	dptr,#_distinct_keys
      007D06 E0               [24] 1263 	movx	a,@dptr
      007D07 24 F9            [12] 1264 	add	a,#0xff - 0x06
      007D09 50 17            [24] 1265 	jnc	00110$
                                   1266 ;	free result
                                   1267 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007D0B 7F 00            [12] 1268 	mov	r7,#0x00
      007D0D                       1269 00115$:
      007D0D BF 06 00         [24] 1270 	cjne	r7,#0x06,00174$
      007D10                       1271 00174$:
      007D10 50 1E            [24] 1272 	jnc	00111$
      007D12 EF               [12] 1273 	mov	a,r7
      007D13 24 9A            [12] 1274 	add	a, #(_actual_keyboard_report + 0x0002)
      007D15 F5 82            [12] 1275 	mov	dpl,a
      007D17 E4               [12] 1276 	clr	a
      007D18 34 0D            [12] 1277 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007D1A F5 83            [12] 1278 	mov	dph,a
      007D1C 74 01            [12] 1279 	mov	a,#0x01
      007D1E F0               [24] 1280 	movx	@dptr,a
      007D1F 0F               [12] 1281 	inc	r7
      007D20 80 EB            [24] 1282 	sjmp	00115$
      007D22                       1283 00110$:
                                   1284 ;	quantum/action_util.c:154: } else add_key(code);
      007D22 90 0A 48         [24] 1285 	mov	dptr,#_add_owned_key_code_10000_332
      007D25 E0               [24] 1286 	movx	a,@dptr
                                   1287 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007D26 90 07 FB         [24] 1288 	mov	dptr,#_add_key_to_report_PARM_2
      007D29 F0               [24] 1289 	movx	@dptr,a
      007D2A 90 0D 98         [24] 1290 	mov	dptr,#_actual_keyboard_report
      007D2D 12 6E 5C         [24] 1291 	lcall	_add_key_to_report
                                   1292 ;	quantum/action_util.c:154: } else add_key(code);
      007D30                       1293 00111$:
                                   1294 ;	quantum/action_util.c:155: return true;
      007D30 75 82 01         [24] 1295 	mov	dpl, #0x01
                                   1296 ;	quantum/action_util.c:156: }
      007D33 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'del_owned_key'
                                   1300 ;------------------------------------------------------------
                                   1301 ;code          Allocated with name '_del_owned_key_code_10000_347'
                                   1302 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_358'
                                   1303 ;key           Allocated with name '_del_owned_key_key_50000_359'
                                   1304 ;key           Allocated with name '_del_owned_key_key_40000_356'
                                   1305 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_364'
                                   1306 ;key           Allocated with name '_del_owned_key_key_70000_365'
                                   1307 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_367'
                                   1308 ;key           Allocated with name '_del_owned_key_key_40000_368'
                                   1309 ;------------------------------------------------------------
                                   1310 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1311 ;	-----------------------------------------
                                   1312 ;	 function del_owned_key
                                   1313 ;	-----------------------------------------
      007D34                       1314 _del_owned_key:
      007D34 E5 82            [12] 1315 	mov	a,dpl
      007D36 90 0A 49         [24] 1316 	mov	dptr,#_del_owned_key_code_10000_347
      007D39 12 80 57         [24] 1317 	lcall	_ak820_outline_0130
                                   1318 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007D3C E4               [12] 1319 	clr	a
      007D3D F0               [24] 1320 	movx	@dptr,a
      007D3E 90 0A 33         [24] 1321 	mov	dptr,#_macro_keys
      007D41 C0 07            [24] 1322 	push	ar7
      007D43 12 7A DA         [24] 1323 	lcall	_ak820_macro_change
      007D46 E5 82            [12] 1324 	mov	a, dpl
      007D48 D0 07            [24] 1325 	pop	ar7
      007D4A 70 03            [24] 1326 	jnz	00102$
      007D4C F5 82            [12] 1327 	mov	dpl,a
      007D4E 22               [24] 1328 	ret
      007D4F                       1329 00102$:
                                   1330 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      007D4F 12 80 11         [24] 1331 	lcall	_ak820_outline_0028
      007D52 FC               [12] 1332 	mov	r4,a
      007D53 60 09            [24] 1333 	jz	00103$
      007D55 1C               [12] 1334 	dec	r4
      007D56 12 38 6A         [24] 1335 	lcall	_ak820_outline_0131
      007D59 EC               [12] 1336 	mov	a,r4
      007D5A F0               [24] 1337 	movx	@dptr,a
      007D5B EC               [12] 1338 	mov	a,r4
      007D5C 60 04            [24] 1339 	jz	00104$
      007D5E                       1340 00103$:
      007D5E 75 82 00         [24] 1341 	mov	dpl, #0x00
      007D61 22               [24] 1342 	ret
      007D62                       1343 00104$:
                                   1344 ;	quantum/action_util.c:160: --distinct_keys;
      007D62 90 0A 32         [24] 1345 	mov	dptr,#_distinct_keys
      007D65 E0               [24] 1346 	movx	a,@dptr
      007D66 14               [12] 1347 	dec	a
      007D67 F0               [24] 1348 	movx	@dptr,a
                                   1349 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007D68 90 0D 85         [24] 1350 	mov	dptr,#_keyboard_protocol
      007D6B E0               [24] 1351 	movx	a,@dptr
      007D6C 60 16            [24] 1352 	jz	00107$
      007D6E 90 0A B7         [24] 1353 	mov	dptr,#_keymap_config
      007D71 E0               [24] 1354 	movx	a,@dptr
      007D72 30 E7 0F         [24] 1355 	jnb	acc.7,00107$
                                   1356 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007D75 90 07 FE         [24] 1357 	mov	dptr,#_del_key_from_report_PARM_2
      007D78 EF               [12] 1358 	mov	a,r7
      007D79 F0               [24] 1359 	movx	@dptr,a
      007D7A 90 0D 98         [24] 1360 	mov	dptr,#_actual_keyboard_report
      007D7D 12 6E 92         [24] 1361 	lcall	_del_key_from_report
                                   1362 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007D80 75 82 01         [24] 1363 	mov	dpl, #0x01
      007D83 22               [24] 1364 	ret
      007D84                       1365 00107$:
                                   1366 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007D84 90 0A 32         [24] 1367 	mov	dptr,#_distinct_keys
      007D87 E0               [24] 1368 	movx	a,@dptr
      007D88 FF               [12] 1369 	mov  r7,a
      007D89 24 F9            [12] 1370 	add	a,#0xff - 0x06
      007D8B 50 04            [24] 1371 	jnc	00110$
                                   1372 ;	free result
      007D8D 75 82 01         [24] 1373 	mov	dpl, #0x01
      007D90 22               [24] 1374 	ret
      007D91                       1375 00110$:
                                   1376 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007D91 BF 06 1F         [24] 1377 	cjne	r7,#0x06,00115$
                                   1378 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007D94 90 0D 98         [24] 1379 	mov	dptr,#_actual_keyboard_report
      007D97 12 6E C8         [24] 1380 	lcall	_clear_keys_from_report
                                   1381 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007D9A 7F 04            [12] 1382 	mov	r7,#0x04
      007D9C                       1383 00122$:
      007D9C EF               [12] 1384 	mov	a,r7
      007D9D 24 5B            [12] 1385 	add	a,#0xff - 0xa4
      007D9F 40 20            [24] 1386 	jc	00116$
                                   1387 ;	free result
      007DA1 12 80 11         [24] 1388 	lcall	_ak820_outline_0028
      007DA4 60 0A            [24] 1389 	jz	00123$
                                   1390 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007DA6 12 80 62         [24] 1391 	lcall	_ak820_outline_0171
      007DA9 C0 07            [24] 1392 	push	ar7
      007DAB 12 6E 5C         [24] 1393 	lcall	_add_key_to_report
      007DAE D0 07            [24] 1394 	pop	ar7
                                   1395 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007DB0                       1396 00123$:
      007DB0 0F               [12] 1397 	inc	r7
      007DB1 80 E9            [24] 1398 	sjmp	00122$
      007DB3                       1399 00115$:
                                   1400 ;	quantum/action_util.c:169: } else del_key(code);
      007DB3 90 0A 49         [24] 1401 	mov	dptr,#_del_owned_key_code_10000_347
      007DB6 E0               [24] 1402 	movx	a,@dptr
                                   1403 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007DB7 90 07 FE         [24] 1404 	mov	dptr,#_del_key_from_report_PARM_2
      007DBA F0               [24] 1405 	movx	@dptr,a
      007DBB 90 0D 98         [24] 1406 	mov	dptr,#_actual_keyboard_report
      007DBE 12 6E 92         [24] 1407 	lcall	_del_key_from_report
                                   1408 ;	quantum/action_util.c:169: } else del_key(code);
      007DC1                       1409 00116$:
                                   1410 ;	quantum/action_util.c:170: return true;
      007DC1 75 82 01         [24] 1411 	mov	dpl, #0x01
                                   1412 ;	quantum/action_util.c:171: }
      007DC4 22               [24] 1413 	ret
                                   1414 ;------------------------------------------------------------
                                   1415 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1416 ;------------------------------------------------------------
                                   1417 ;i             Allocated with name '_clear_owned_usages_i_20000_372'
                                   1418 ;i             Allocated with name '_clear_owned_usages_i_20000_373'
                                   1419 ;------------------------------------------------------------
                                   1420 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1421 ;	-----------------------------------------
                                   1422 ;	 function clear_owned_usages
                                   1423 ;	-----------------------------------------
      007DC5                       1424 _clear_owned_usages:
                                   1425 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007DC5 7F 00            [12] 1426 	mov	r7,#0x00
      007DC7                       1427 00104$:
      007DC7 BF 1E 00         [24] 1428 	cjne	r7,#0x1e,00141$
      007DCA                       1429 00141$:
      007DCA 50 14            [24] 1430 	jnc	00101$
      007DCC EF               [12] 1431 	mov	a,r7
      007DCD 24 4A            [12] 1432 	add	a, #_usage_refs
      007DCF FD               [12] 1433 	mov	r5,a
      007DD0 E4               [12] 1434 	clr	a
      007DD1 34 0A            [12] 1435 	addc	a, #(_usage_refs >> 8)
      007DD3 FE               [12] 1436 	mov	r6,a
      007DD4 EF               [12] 1437 	mov	a,r7
      007DD5 12 80 26         [24] 1438 	lcall	_ak820_outline_0067
      007DD8 E4               [12] 1439 	clr	a
      007DD9 F0               [24] 1440 	movx	@dptr,a
      007DDA 12 80 46         [24] 1441 	lcall	_ak820_outline_0118
      007DDD 0F               [12] 1442 	inc	r7
      007DDE 80 E7            [24] 1443 	sjmp	00104$
      007DE0                       1444 00101$:
                                   1445 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      007DE0 90 0A 87         [24] 1446 	mov	dptr,#(_usage_lengths + 0x0001)
      007DE3 E4               [12] 1447 	clr	a
      007DE4 F0               [24] 1448 	movx	@dptr,a
      007DE5 90 0A 86         [24] 1449 	mov	dptr,#_usage_lengths
      007DE8 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007DE9 FF               [12] 1452 	mov	r7,a
      007DEA                       1453 00107$:
      007DEA BF 04 00         [24] 1454 	cjne	r7,#0x04,00143$
      007DED                       1455 00143$:
      007DED 50 0D            [24] 1456 	jnc	00109$
      007DEF EF               [12] 1457 	mov	a,r7
      007DF0 24 88            [12] 1458 	add	a, #_macro_usages
      007DF2 F5 82            [12] 1459 	mov	dpl,a
      007DF4 E4               [12] 1460 	clr	a
      007DF5 34 0A            [12] 1461 	addc	a, #(_macro_usages >> 8)
      007DF7 12 7A 7C         [24] 1462 	lcall	_ak820_outline_0158
      007DFA 80 EE            [24] 1463 	sjmp	00107$
      007DFC                       1464 00109$:
                                   1465 ;	quantum/action_util.c:185: }
      007DFC 22               [24] 1466 	ret
                                   1467 ;------------------------------------------------------------
                                   1468 ;Allocation info for local variables in function 'owned_usage_key'
                                   1469 ;------------------------------------------------------------
                                   1470 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1471 ;code          Allocated with name '_owned_usage_key_code_10000_374'
                                   1472 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_375'
                                   1473 ;which         Allocated with name '_owned_usage_key_which_10000_375'
                                   1474 ;base          Allocated with name '_owned_usage_key_base_10000_375'
                                   1475 ;count         Allocated with name '_owned_usage_key_count_10000_375'
                                   1476 ;index         Allocated with name '_owned_usage_key_index_10000_375'
                                   1477 ;pos           Allocated with name '_owned_usage_key_pos_30001_382'
                                   1478 ;i             Allocated with name '_owned_usage_key_i_40001_383'
                                   1479 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_386'
                                   1480 ;key           Allocated with name '_owned_usage_key_key_40000_387'
                                   1481 ;------------------------------------------------------------
                                   1482 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1483 ;	-----------------------------------------
                                   1484 ;	 function owned_usage_key
                                   1485 ;	-----------------------------------------
      007DFD                       1486 _owned_usage_key:
      007DFD E5 82            [12] 1487 	mov	a,dpl
      007DFF 90 0A 8D         [24] 1488 	mov	dptr,#_owned_usage_key_code_10000_374
      007E02 F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      007E03 E0               [24] 1491 	movx	a,@dptr
      007E04 FF               [12] 1492 	mov	r7,a
      007E05 BF A8 00         [24] 1493 	cjne	r7,#0xa8,00244$
      007E08                       1494 00244$:
      007E08 B3               [12] 1495 	cpl	c
      007E09 92 22            [24] 1496 	mov	_owned_usage_key_sloc0_1_0,c
      007E0B E4               [12] 1497 	clr	a
      007E0C 33               [12] 1498 	rlc	a
      007E0D FF               [12] 1499 	mov	r7,a
      007E0E 90 0A 90         [24] 1500 	mov	dptr,#_owned_usage_key_which_10000_375
      007E11 F0               [24] 1501 	movx	@dptr,a
                                   1502 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      007E12 EF               [12] 1503 	mov	a,r7
      007E13 60 02            [24] 1504 	jz	00129$
      007E15 74 03            [12] 1505 	mov	a,#0x03
      007E17                       1506 00129$:
      007E17 FE               [12] 1507 	mov	r6,a
                                   1508 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      007E18 EF               [12] 1509 	mov	a,r7
      007E19 24 86            [12] 1510 	add	a, #_usage_lengths
      007E1B FD               [12] 1511 	mov	r5,a
      007E1C E4               [12] 1512 	clr	a
      007E1D 34 0A            [12] 1513 	addc	a, #(_usage_lengths >> 8)
      007E1F FF               [12] 1514 	mov	r7,a
      007E20 12 80 6B         [24] 1515 	lcall	_ak820_outline_0184
      007E23 E0               [24] 1516 	movx	a,@dptr
      007E24 FC               [12] 1517 	mov	r4,a
                                   1518 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      007E25 90 0A 8D         [24] 1519 	mov	dptr,#_owned_usage_key_code_10000_374
      007E28 E0               [24] 1520 	movx	a,@dptr
      007E29 24 5B            [12] 1521 	add	a,#0x5b
      007E2B FB               [12] 1522 	mov	r3,a
                                   1523 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007E2C 90 0A 8C         [24] 1524 	mov	dptr,#_owned_usage_key_PARM_2
      007E2F E0               [24] 1525 	movx	a,@dptr
      007E30 FA               [12] 1526 	mov	r2,a
      007E31 90 09 81         [24] 1527 	mov	dptr,#_ak820_macro_change_PARM_2
      007E34 EB               [12] 1528 	mov	a,r3
      007E35 F0               [24] 1529 	movx	@dptr,a
      007E36 90 09 82         [24] 1530 	mov	dptr,#_ak820_macro_change_PARM_3
      007E39 EA               [12] 1531 	mov	a,r2
      007E3A F0               [24] 1532 	movx	@dptr,a
      007E3B 90 0A 88         [24] 1533 	mov	dptr,#_macro_usages
      007E3E C0 07            [24] 1534 	push	ar7
      007E40 C0 06            [24] 1535 	push	ar6
      007E42 C0 05            [24] 1536 	push	ar5
      007E44 C0 04            [24] 1537 	push	ar4
      007E46 C0 03            [24] 1538 	push	ar3
      007E48 C0 02            [24] 1539 	push	ar2
      007E4A 12 7A DA         [24] 1540 	lcall	_ak820_macro_change
      007E4D E5 82            [12] 1541 	mov	a, dpl
      007E4F D0 02            [24] 1542 	pop	ar2
      007E51 D0 03            [24] 1543 	pop	ar3
      007E53 D0 04            [24] 1544 	pop	ar4
      007E55 D0 05            [24] 1545 	pop	ar5
      007E57 D0 06            [24] 1546 	pop	ar6
      007E59 D0 07            [24] 1547 	pop	ar7
      007E5B 70 01            [24] 1548 	jnz	00102$
      007E5D 22               [24] 1549 	ret
      007E5E                       1550 00102$:
                                   1551 ;	quantum/action_util.c:192: if (pressed) {
      007E5E EA               [12] 1552 	mov	a,r2
      007E5F 60 1B            [24] 1553 	jz	00115$
                                   1554 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      007E61 12 80 30         [24] 1555 	lcall	_ak820_outline_0073
      007E64 04               [12] 1556 	inc	a
      007E65 12 6B DF         [24] 1557 	lcall	_ak820_outline_0136
      007E68 E8               [12] 1558 	mov	a,r0
      007E69 60 01            [24] 1559 	jz	00104$
      007E6B 22               [24] 1560 	ret
      007E6C                       1561 00104$:
                                   1562 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      007E6C 90 0A 91         [24] 1563 	mov	dptr,#_owned_usage_key_count_10000_375
      007E6F EC               [12] 1564 	mov	a,r4
      007E70 04               [12] 1565 	inc	a
      007E71 F0               [24] 1566 	movx	@dptr,a
      007E72 EC               [12] 1567 	mov	a,r4
      007E73 2E               [12] 1568 	add	a, r6
      007E74 12 80 26         [24] 1569 	lcall	_ak820_outline_0067
      007E77 EB               [12] 1570 	mov	a,r3
      007E78 F0               [24] 1571 	movx	@dptr,a
      007E79 02 7E DD         [24] 1572 	ljmp	00116$
      007E7C                       1573 00115$:
                                   1574 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      007E7C 12 80 30         [24] 1575 	lcall	_ak820_outline_0073
      007E7F 60 07            [24] 1576 	jz	00105$
      007E81 18               [12] 1577 	dec	r0
      007E82 12 80 1F         [24] 1578 	lcall	_ak820_outline_0063
      007E85 E8               [12] 1579 	mov	a,r0
      007E86 60 01            [24] 1580 	jz	00106$
      007E88                       1581 00105$:
      007E88 22               [24] 1582 	ret
      007E89                       1583 00106$:
                                   1584 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      007E89 7A 00            [12] 1585 	mov	r2,#0x00
      007E8B                       1586 00108$:
      007E8B EA               [12] 1587 	mov	a,r2
      007E8C 2E               [12] 1588 	add	a, r6
      007E8D 12 80 26         [24] 1589 	lcall	_ak820_outline_0067
      007E90 E0               [24] 1590 	movx	a,@dptr
      007E91 B5 03 02         [24] 1591 	cjne	a,ar3,00251$
      007E94 80 03            [24] 1592 	sjmp	00167$
      007E96                       1593 00251$:
      007E96 0A               [12] 1594 	inc	r2
      007E97 80 F2            [24] 1595 	sjmp	00108$
      007E99                       1596 00167$:
      007E99 90 0A 92         [24] 1597 	mov	dptr,#_owned_usage_key_pos_30001_382
      007E9C EA               [12] 1598 	mov	a,r2
      007E9D F0               [24] 1599 	movx	@dptr,a
                                   1600 ;	quantum/action_util.c:199: --count;
      007E9E 1C               [12] 1601 	dec	r4
      007E9F 90 0A 91         [24] 1602 	mov	dptr,#_owned_usage_key_count_10000_375
      007EA2 EC               [12] 1603 	mov	a,r4
      007EA3 F0               [24] 1604 	movx	@dptr,a
                                   1605 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007EA4 8A 03            [24] 1606 	mov	ar3,r2
      007EA6                       1607 00125$:
      007EA6 C3               [12] 1608 	clr	c
      007EA7 EB               [12] 1609 	mov	a,r3
      007EA8 9C               [12] 1610 	subb	a,r4
      007EA9 50 23            [24] 1611 	jnc	00111$
      007EAB C0 05            [24] 1612 	push	ar5
      007EAD C0 07            [24] 1613 	push	ar7
      007EAF EB               [12] 1614 	mov	a,r3
      007EB0 2E               [12] 1615 	add	a, r6
      007EB1 FA               [12] 1616 	mov	r2,a
      007EB2 24 68            [12] 1617 	add	a, #_usage_order
      007EB4 F8               [12] 1618 	mov	r0,a
      007EB5 E4               [12] 1619 	clr	a
      007EB6 34 0A            [12] 1620 	addc	a, #(_usage_order >> 8)
      007EB8 F9               [12] 1621 	mov	r1,a
      007EB9 0A               [12] 1622 	inc	r2
      007EBA EA               [12] 1623 	mov	a,r2
      007EBB 33               [12] 1624 	rlc	a
      007EBC 95 E0            [12] 1625 	subb	a,acc
      007EBE FF               [12] 1626 	mov	r7,a
      007EBF EA               [12] 1627 	mov	a,r2
      007EC0 12 80 4C         [24] 1628 	lcall	_ak820_outline_0124
      007EC3 12 38 75         [24] 1629 	lcall	_ak820_outline_0152
      007EC6 F0               [24] 1630 	movx	@dptr,a
      007EC7 0B               [12] 1631 	inc	r3
      007EC8 D0 07            [24] 1632 	pop	ar7
      007ECA D0 05            [24] 1633 	pop	ar5
      007ECC 80 D8            [24] 1634 	sjmp	00125$
      007ECE                       1635 00111$:
                                   1636 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      007ECE 12 80 6B         [24] 1637 	lcall	_ak820_outline_0184
      007ED1 EC               [12] 1638 	mov	a,r4
      007ED2 F0               [24] 1639 	movx	@dptr,a
                                   1640 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      007ED3 90 0A 92         [24] 1641 	mov	dptr,#_owned_usage_key_pos_30001_382
      007ED6 E0               [24] 1642 	movx	a,@dptr
      007ED7 B5 04 02         [24] 1643 	cjne	a,ar4,00253$
      007EDA 80 01            [24] 1644 	sjmp	00116$
      007EDC                       1645 00253$:
      007EDC 22               [24] 1646 	ret
      007EDD                       1647 00116$:
                                   1648 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      007EDD 90 0A 91         [24] 1649 	mov	dptr,#_owned_usage_key_count_10000_375
      007EE0 E0               [24] 1650 	movx	a,@dptr
      007EE1 FC               [12] 1651 	mov	r4,a
      007EE2 12 80 6B         [24] 1652 	lcall	_ak820_outline_0184
      007EE5 F0               [24] 1653 	movx	@dptr,a
                                   1654 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007EE6 EC               [12] 1655 	mov	a,r4
      007EE7 60 15            [24] 1656 	jz	00131$
      007EE9 EC               [12] 1657 	mov	a,r4
      007EEA 2E               [12] 1658 	add	a, r6
      007EEB FE               [12] 1659 	mov	r6,a
      007EEC 1E               [12] 1660 	dec	r6
      007EED EE               [12] 1661 	mov	a,r6
      007EEE 33               [12] 1662 	rlc	a
      007EEF 95 E0            [12] 1663 	subb	a,acc
      007EF1 FF               [12] 1664 	mov	r7,a
      007EF2 EE               [12] 1665 	mov	a,r6
      007EF3 12 80 4C         [24] 1666 	lcall	_ak820_outline_0124
      007EF6 24 A5            [12] 1667 	add	a,#0xa5
      007EF8 FE               [12] 1668 	mov	r6,a
      007EF9 33               [12] 1669 	rlc	a
      007EFA 95 E0            [12] 1670 	subb	a,acc
      007EFC 80 02            [24] 1671 	sjmp	00132$
      007EFE                       1672 00131$:
      007EFE 7E 00            [12] 1673 	mov	r6,#0x00
      007F00                       1674 00132$:
      007F00 90 0A 8D         [24] 1675 	mov	dptr,#_owned_usage_key_code_10000_374
      007F03 EE               [12] 1676 	mov	a,r6
      007F04 F0               [24] 1677 	movx	@dptr,a
                                   1678 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007F05 90 0A 90         [24] 1679 	mov	dptr,#_owned_usage_key_which_10000_375
      007F08 E0               [24] 1680 	movx	a,@dptr
      007F09 60 18            [24] 1681 	jz	00118$
      007F0B EE               [12] 1682 	mov	a,r6
      007F0C 60 0B            [24] 1683 	jz	00133$
      007F0E 8E 82            [24] 1684 	mov	dpl, r6
      007F10 12 6D 18         [24] 1685 	lcall	_KEYCODE2CONSUMER
      007F13 AD 82            [24] 1686 	mov	r5, dpl
      007F15 AF 83            [24] 1687 	mov	r7, dph
      007F17 80 04            [24] 1688 	sjmp	00134$
      007F19                       1689 00133$:
      007F19 7D 00            [12] 1690 	mov	r5,#0x00
      007F1B 7F 00            [12] 1691 	mov	r7,#0x00
      007F1D                       1692 00134$:
      007F1D 12 80 6B         [24] 1693 	lcall	_ak820_outline_0184
      007F20 02 6C D2         [24] 1694 	ljmp	_host_consumer_send
      007F23                       1695 00118$:
                                   1696 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007F23 EE               [12] 1697 	mov	a,r6
      007F24 60 22            [24] 1698 	jz	00135$
                                   1699 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007F26 BE A5 00         [24] 1700 	cjne	r6,#0xa5,00258$
      007F29                       1701 00258$:
      007F29 40 05            [24] 1702 	jc	00121$
      007F2B EE               [12] 1703 	mov	a,r6
      007F2C 24 58            [12] 1704 	add	a,#0xff - 0xa7
      007F2E 50 08            [24] 1705 	jnc	00122$
                                   1706 ;	free result
      007F30                       1707 00121$:
      007F30 90 0A 8E         [24] 1708 	mov	dptr,#_owned_usage_key___200000085_20000_375
      007F33 12 4E FB         [24] 1709 	lcall	_ak820_outline_0178
      007F36 80 09            [24] 1710 	sjmp	00123$
      007F38                       1711 00122$:
                                   1712 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007F38 74 DC            [12] 1713 	mov	a,#0xdc
      007F3A 2E               [12] 1714 	add	a, r6
      007F3B 90 0A 8E         [24] 1715 	mov	dptr,#_owned_usage_key___200000085_20000_375
      007F3E 12 38 65         [24] 1716 	lcall	_ak820_outline_0123
                                   1717 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007F41                       1718 00123$:
      007F41 90 0A 8E         [24] 1719 	mov	dptr,#_owned_usage_key___200000085_20000_375
      007F44 E0               [24] 1720 	movx	a,@dptr
      007F45 FF               [12] 1721 	mov	r7,a
      007F46 80 02            [24] 1722 	sjmp	00136$
      007F48                       1723 00135$:
      007F48 7F 00            [12] 1724 	mov	r7,#0x00
      007F4A                       1725 00136$:
      007F4A 7E 00            [12] 1726 	mov	r6,#0x00
      007F4C 12 43 46         [24] 1727 	lcall	_ak820_outline_0153
                                   1728 ;	quantum/action_util.c:208: }
      007F4F 02 6C A2         [24] 1729 	ljmp	_host_system_send
                                   1730 ;------------------------------------------------------------
                                   1731 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1732 ;------------------------------------------------------------
                                   1733 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_395'
                                   1734 ;changed       Allocated with name '_send_keyboard_report_changed_10001_395'
                                   1735 ;dest          Allocated with name '_send_keyboard_report_dest_10001_395'
                                   1736 ;src           Allocated with name '_send_keyboard_report_src_10001_395'
                                   1737 ;i             Allocated with name '_send_keyboard_report_i_20001_396'
                                   1738 ;------------------------------------------------------------
                                   1739 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1740 ;	-----------------------------------------
                                   1741 ;	 function send_keyboard_report
                                   1742 ;	-----------------------------------------
      007F52                       1743 _send_keyboard_report:
                                   1744 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      007F52 90 0D 96         [24] 1745 	mov	dptr,#_real_mods
      007F55 E0               [24] 1746 	movx	a,@dptr
      007F56 FF               [12] 1747 	mov	r7,a
      007F57 90 0D 98         [24] 1748 	mov	dptr,#_actual_keyboard_report
      007F5A F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      007F5B 90 0D 97         [24] 1751 	mov	dptr,#_weak_mods
      007F5E E0               [24] 1752 	movx	a,@dptr
      007F5F 42 07            [12] 1753 	orl	ar7,a
      007F61 90 0D 98         [24] 1754 	mov	dptr,#_actual_keyboard_report
      007F64 EF               [12] 1755 	mov	a,r7
      007F65 F0               [24] 1756 	movx	@dptr,a
                                   1757 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      007F66 90 09 7C         [24] 1758 	mov	dptr,#_owned_weak_mods
      007F69 E0               [24] 1759 	movx	a,@dptr
      007F6A FE               [12] 1760 	mov	r6,a
      007F6B 90 09 7B         [24] 1761 	mov	dptr,#_owned_mods
      007F6E E0               [24] 1762 	movx	a,@dptr
      007F6F 4E               [12] 1763 	orl	a,r6
      007F70 42 07            [12] 1764 	orl	ar7,a
      007F72 90 0D 98         [24] 1765 	mov	dptr,#_actual_keyboard_report
      007F75 EF               [12] 1766 	mov	a,r7
      007F76 F0               [24] 1767 	movx	@dptr,a
                                   1768 ;	quantum/action_util.c:475: if (gui_disabled) keyboard_report->mods &= ~(MOD_BIT(KC_LGUI) | MOD_BIT(KC_RGUI));
      007F77 30 1E 07         [24] 1769 	jnb	_gui_disabled,00102$
      007F7A 90 0D 98         [24] 1770 	mov	dptr,#_actual_keyboard_report
      007F7D E0               [24] 1771 	movx	a,@dptr
      007F7E 54 77            [12] 1772 	anl	a,#0x77
      007F80 F0               [24] 1773 	movx	@dptr,a
      007F81                       1774 00102$:
                                   1775 ;	quantum/action_util.c:515: bool changed = false;
      007F81 90 0A B4         [24] 1776 	mov	dptr,#_send_keyboard_report_changed_10001_395
      007F84 E4               [12] 1777 	clr	a
      007F85 F0               [24] 1778 	movx	@dptr,a
                                   1779 ;	quantum/action_util.c:517: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1780 ;	quantum/action_util.c:518: const uint8_t __xdata *src = (const uint8_t __xdata *)AK820_REPORT_OUT;
                                   1781 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007F86 FF               [12] 1782 	mov	r7,a
      007F87                       1783 00109$:
      007F87 BF 20 00         [24] 1784 	cjne	r7,#0x20,00150$
      007F8A                       1785 00150$:
      007F8A 50 2A            [24] 1786 	jnc	00105$
                                   1787 ;	quantum/action_util.c:524: if (dest[i] != src[i]) {
      007F8C EF               [12] 1788 	mov	a,r7
      007F8D 24 94            [12] 1789 	add	a, #_send_keyboard_report_last_report_10001_395
      007F8F FD               [12] 1790 	mov	r5,a
      007F90 E4               [12] 1791 	clr	a
      007F91 34 0A            [12] 1792 	addc	a, #(_send_keyboard_report_last_report_10001_395 >> 8)
      007F93 12 48 4E         [24] 1793 	lcall	_ak820_outline_0056
      007F96 EF               [12] 1794 	mov	a,r7
      007F97 24 98            [12] 1795 	add	a, #_actual_keyboard_report
      007F99 F5 82            [12] 1796 	mov	dpl,a
      007F9B E4               [12] 1797 	clr	a
      007F9C 34 0D            [12] 1798 	addc	a, #(_actual_keyboard_report >> 8)
      007F9E F5 83            [12] 1799 	mov	dph,a
      007FA0 E0               [24] 1800 	movx	a,@dptr
      007FA1 FB               [12] 1801 	mov	r3,a
      007FA2 EC               [12] 1802 	mov	a,r4
      007FA3 B5 03 02         [24] 1803 	cjne	a,ar3,00152$
      007FA6 80 0B            [24] 1804 	sjmp	00110$
      007FA8                       1805 00152$:
                                   1806 ;	quantum/action_util.c:525: dest[i] = src[i];
      007FA8 12 38 6A         [24] 1807 	lcall	_ak820_outline_0131
      007FAB EB               [12] 1808 	mov	a,r3
      007FAC F0               [24] 1809 	movx	@dptr,a
                                   1810 ;	quantum/action_util.c:526: changed = true;
      007FAD 90 0A B4         [24] 1811 	mov	dptr,#_send_keyboard_report_changed_10001_395
      007FB0 74 01            [12] 1812 	mov	a,#0x01
      007FB2 F0               [24] 1813 	movx	@dptr,a
      007FB3                       1814 00110$:
                                   1815 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007FB3 0F               [12] 1816 	inc	r7
      007FB4 80 D1            [24] 1817 	sjmp	00109$
      007FB6                       1818 00105$:
                                   1819 ;	quantum/action_util.c:529: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      007FB6 90 0A B4         [24] 1820 	mov	dptr,#_send_keyboard_report_changed_10001_395
      007FB9 E0               [24] 1821 	movx	a,@dptr
      007FBA 60 09            [24] 1822 	jz	00111$
      007FBC 90 0D 98         [24] 1823 	mov	dptr,#_actual_keyboard_report
      007FBF 75 F0 00         [24] 1824 	mov	b, #0x00
                                   1825 ;	quantum/action_util.c:538: }
      007FC2 02 6C 17         [24] 1826 	ljmp	_host_keyboard_send
      007FC5                       1827 00111$:
      007FC5 22               [24] 1828 	ret
                                   1829 ;------------------------------------------------------------
                                   1830 ;Allocation info for local variables in function 'get_mods'
                                   1831 ;------------------------------------------------------------
                                   1832 ;	quantum/action_util.c:544: uint8_t get_mods(void) {
                                   1833 ;	-----------------------------------------
                                   1834 ;	 function get_mods
                                   1835 ;	-----------------------------------------
      007FC6                       1836 _get_mods:
      007FC6 C0 07            [24] 1837 	push	ar7
                                   1838 ;	quantum/action_util.c:549: ;
      007FC8 90 09 7B         [24] 1839 	mov	dptr,#_owned_mods
      007FCB E0               [24] 1840 	movx	a,@dptr
      007FCC FF               [12] 1841 	mov	r7,a
      007FCD 90 0D 96         [24] 1842 	mov	dptr,#_real_mods
      007FD0 12 7A 76         [24] 1843 	lcall	_ak820_outline_0138
                                   1844 ;	quantum/action_util.c:550: }
      007FD3 D0 07            [24] 1845 	pop	ar7
      007FD5 22               [24] 1846 	ret
                                   1847 ;------------------------------------------------------------
                                   1848 ;Allocation info for local variables in function 'add_mods'
                                   1849 ;------------------------------------------------------------
                                   1850 ;mods          Allocated with name '_add_mods_mods_10000_403'
                                   1851 ;------------------------------------------------------------
                                   1852 ;	quantum/action_util.c:555: void add_mods(uint8_t mods) {
                                   1853 ;	-----------------------------------------
                                   1854 ;	 function clear_mods
                                   1855 ;	-----------------------------------------
      007FD6                       1856 _clear_mods:
                                   1857 ;	quantum/action_util.c:577: real_mods = 0;
      007FD6 90 0D 96         [24] 1858 	mov	dptr,#_real_mods
      007FD9 E4               [12] 1859 	clr	a
      007FDA F0               [24] 1860 	movx	@dptr,a
                                   1861 ;	quantum/action_util.c:578: }
      007FDB 22               [24] 1862 	ret
                                   1863 ;------------------------------------------------------------
                                   1864 ;Allocation info for local variables in function 'get_weak_mods'
                                   1865 ;------------------------------------------------------------
                                   1866 ;	quantum/action_util.c:584: uint8_t get_weak_mods(void) {
                                   1867 ;	-----------------------------------------
                                   1868 ;	 function get_weak_mods
                                   1869 ;	-----------------------------------------
      007FDC                       1870 _get_weak_mods:
      007FDC C0 07            [24] 1871 	push	ar7
                                   1872 ;	quantum/action_util.c:589: ;
      007FDE 90 09 7C         [24] 1873 	mov	dptr,#_owned_weak_mods
      007FE1 E0               [24] 1874 	movx	a,@dptr
      007FE2 FF               [12] 1875 	mov	r7,a
      007FE3 90 0D 97         [24] 1876 	mov	dptr,#_weak_mods
      007FE6 12 7A 76         [24] 1877 	lcall	_ak820_outline_0138
                                   1878 ;	quantum/action_util.c:590: }
      007FE9 D0 07            [24] 1879 	pop	ar7
      007FEB 22               [24] 1880 	ret
                                   1881 ;------------------------------------------------------------
                                   1882 ;Allocation info for local variables in function 'add_weak_mods'
                                   1883 ;------------------------------------------------------------
                                   1884 ;mods          Allocated with name '_add_weak_mods_mods_10000_413'
                                   1885 ;------------------------------------------------------------
                                   1886 ;	quantum/action_util.c:595: void add_weak_mods(uint8_t mods) {
                                   1887 ;	-----------------------------------------
                                   1888 ;	 function add_weak_mods
                                   1889 ;	-----------------------------------------
      007FEC                       1890 _add_weak_mods:
      007FEC E5 82            [12] 1891 	mov	a,dpl
      007FEE 90 0A B5         [24] 1892 	mov	dptr,#_add_weak_mods_mods_10000_413
      007FF1 F0               [24] 1893 	movx	@dptr,a
                                   1894 ;	quantum/action_util.c:596: weak_mods |= mods;
      007FF2 E0               [24] 1895 	movx	a,@dptr
      007FF3 FF               [12] 1896 	mov	r7,a
      007FF4 90 0D 97         [24] 1897 	mov	dptr,#_weak_mods
      007FF7 E0               [24] 1898 	movx	a,@dptr
      007FF8 4F               [12] 1899 	orl	a,r7
      007FF9 F0               [24] 1900 	movx	@dptr,a
                                   1901 ;	quantum/action_util.c:597: }
      007FFA 22               [24] 1902 	ret
                                   1903 ;------------------------------------------------------------
                                   1904 ;Allocation info for local variables in function 'del_weak_mods'
                                   1905 ;------------------------------------------------------------
                                   1906 ;mods          Allocated with name '_del_weak_mods_mods_10000_415'
                                   1907 ;------------------------------------------------------------
                                   1908 ;	quantum/action_util.c:602: void del_weak_mods(uint8_t mods) {
                                   1909 ;	-----------------------------------------
                                   1910 ;	 function del_weak_mods
                                   1911 ;	-----------------------------------------
      007FFB                       1912 _del_weak_mods:
      007FFB E5 82            [12] 1913 	mov	a,dpl
      007FFD 90 0A B6         [24] 1914 	mov	dptr,#_del_weak_mods_mods_10000_415
      008000 F0               [24] 1915 	movx	@dptr,a
                                   1916 ;	quantum/action_util.c:603: weak_mods &= ~mods;
      008001 E0               [24] 1917 	movx	a,@dptr
      008002 F4               [12] 1918 	cpl	a
      008003 FF               [12] 1919 	mov	r7,a
      008004 90 0D 97         [24] 1920 	mov	dptr,#_weak_mods
      008007 E0               [24] 1921 	movx	a,@dptr
      008008 5F               [12] 1922 	anl	a,r7
      008009 F0               [24] 1923 	movx	@dptr,a
                                   1924 ;	quantum/action_util.c:604: }
      00800A 22               [24] 1925 	ret
                                   1926 ;------------------------------------------------------------
                                   1927 ;Allocation info for local variables in function 'set_weak_mods'
                                   1928 ;------------------------------------------------------------
                                   1929 ;mods          Allocated with name '_set_weak_mods_mods_10000_417'
                                   1930 ;------------------------------------------------------------
                                   1931 ;	quantum/action_util.c:609: void set_weak_mods(uint8_t mods) {
                                   1932 ;	-----------------------------------------
                                   1933 ;	 function clear_weak_mods
                                   1934 ;	-----------------------------------------
      00800B                       1935 _clear_weak_mods:
                                   1936 ;	quantum/action_util.c:617: weak_mods = 0;
      00800B 90 0D 97         [24] 1937 	mov	dptr,#_weak_mods
      00800E E4               [12] 1938 	clr	a
      00800F F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	quantum/action_util.c:618: }
      008010 22               [24] 1941 	ret
                                   1942 ;------------------------------------------------------------
                                   1943 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1944 ;------------------------------------------------------------
                                   1945 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_421'
                                   1946 ;------------------------------------------------------------
                                   1947 ;	quantum/action_util.c:700: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1948 ;	-----------------------------------------
                                   1949 	.area CSEG    (CODE)
                                   1950 	.area CONST   (CODE)
                                   1951 	.area XINIT   (CODE)
      00BF3E                       1952 __xinit__real_mods:
      00BF3E 00                    1953 	.db #0x00	; 0
      00BF3F                       1954 __xinit__weak_mods:
      00BF3F 00                    1955 	.db #0x00	; 0
      00BF40                       1956 __xinit__actual_keyboard_report:
      00BF40 00                    1957 	.db #0x00	; 0
      00BF41 00                    1958 	.db #0x00	; 0
      00BF42 00                    1959 	.db #0x00	; 0
      00BF43 00                    1960 	.db #0x00	; 0
      00BF44 00                    1961 	.db #0x00	; 0
      00BF45 00                    1962 	.db #0x00	; 0
      00BF46 00                    1963 	.db #0x00	; 0
      00BF47 00                    1964 	.db #0x00	; 0
      00BF48 00                    1965 	.db 0x00
      00BF49 00                    1966 	.db 0x00
      00BF4A 00                    1967 	.db 0x00
      00BF4B 00                    1968 	.db 0x00
      00BF4C 00                    1969 	.db 0x00
      00BF4D 00                    1970 	.db 0x00
      00BF4E 00                    1971 	.db 0x00
      00BF4F 00                    1972 	.db 0x00
      00BF50 00                    1973 	.db 0x00
      00BF51 00                    1974 	.db 0x00
      00BF52 00                    1975 	.db 0x00
      00BF53 00                    1976 	.db 0x00
      00BF54 00                    1977 	.db 0x00
      00BF55 00                    1978 	.db 0x00
      00BF56 00                    1979 	.db 0x00
      00BF57 00                    1980 	.db 0x00
      00BF58 00                    1981 	.db 0x00
      00BF59 00                    1982 	.db 0x00
      00BF5A 00                    1983 	.db 0x00
      00BF5B 00                    1984 	.db 0x00
      00BF5C 00                    1985 	.db 0x00
      00BF5D 00                    1986 	.db 0x00
      00BF5E 00                    1987 	.db 0x00
      00BF5F 00                    1988 	.db 0x00
                                   1989 	.area CABS    (ABS,CODE)
                                   1990 
                                   1991 ; Experimental exact instruction outlining.
                                   1992 	.globl _ak820_outline_0013
                                   1993 	.globl _ak820_outline_0028
                                   1994 	.globl _ak820_outline_0050
                                   1995 	.globl _ak820_outline_0056
                                   1996 	.globl _ak820_outline_0059
                                   1997 	.globl _ak820_outline_0062
                                   1998 	.globl _ak820_outline_0063
                                   1999 	.globl _ak820_outline_0064
                                   2000 	.globl _ak820_outline_0067
                                   2001 	.globl _ak820_outline_0073
                                   2002 	.globl _ak820_outline_0103
                                   2003 	.globl _ak820_outline_0104
                                   2004 	.globl _ak820_outline_0113
                                   2005 	.globl _ak820_outline_0118
                                   2006 	.globl _ak820_outline_0122
                                   2007 	.globl _ak820_outline_0123
                                   2008 	.globl _ak820_outline_0124
                                   2009 	.globl _ak820_outline_0130
                                   2010 	.globl _ak820_outline_0131
                                   2011 	.globl _ak820_outline_0136
                                   2012 	.globl _ak820_outline_0138
                                   2013 	.globl _ak820_outline_0152
                                   2014 	.globl _ak820_outline_0153
                                   2015 	.globl _ak820_outline_0158
                                   2016 	.globl _ak820_outline_0171
                                   2017 	.globl _ak820_outline_0178
                                   2018 	.globl _ak820_outline_0183
                                   2019 	.globl _ak820_outline_0184
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0028
      008011                       2023 _ak820_outline_0028:
      008011 EF               [12] 2024 	mov	a,r7
      008012 24 8D            [12] 2025 	add	a,#_key_refs
      008014 FD               [12] 2026 	mov	r5,a
      008015 E4               [12] 2027 	clr	a
      008016 34 09            [12] 2028 	addc	a,#(_key_refs>>8)
      008018 FE               [12] 2029 	mov	r6,a
      008019 8D 82            [24] 2030 	mov	dpl,r5
      00801B 8E 83            [24] 2031 	mov	dph,r6
      00801D E0               [24] 2032 	movx	a,@dptr
      00801E 22               [24] 2033 	ret
                                   2034 
                                   2035 	.area CSEG (CODE)
                                   2036 ; function ak820_outline_0063
      00801F                       2037 _ak820_outline_0063:
      00801F 89 82            [24] 2038 	mov	dpl,r1
      008021 8A 83            [24] 2039 	mov	dph,r2
      008023 E8               [12] 2040 	mov	a,r0
      008024 F0               [24] 2041 	movx	@dptr,a
      008025 22               [24] 2042 	ret
                                   2043 
                                   2044 	.area CSEG (CODE)
                                   2045 ; function ak820_outline_0067
      008026                       2046 _ak820_outline_0067:
      008026 24 68            [12] 2047 	add	a,#_usage_order
      008028 F5 82            [12] 2048 	mov	dpl,a
      00802A E4               [12] 2049 	clr	a
      00802B 34 0A            [12] 2050 	addc	a,#(_usage_order>>8)
      00802D F5 83            [12] 2051 	mov	dph,a
      00802F 22               [24] 2052 	ret
                                   2053 
                                   2054 	.area CSEG (CODE)
                                   2055 ; function ak820_outline_0073
      008030                       2056 _ak820_outline_0073:
      008030 EB               [12] 2057 	mov	a,r3
      008031 24 4A            [12] 2058 	add	a,#_usage_refs
      008033 F9               [12] 2059 	mov	r1,a
      008034 E4               [12] 2060 	clr	a
      008035 34 0A            [12] 2061 	addc	a,#(_usage_refs>>8)
      008037 FA               [12] 2062 	mov	r2,a
      008038 89 82            [24] 2063 	mov	dpl,r1
      00803A 8A 83            [24] 2064 	mov	dph,r2
      00803C E0               [24] 2065 	movx	a,@dptr
      00803D F8               [12] 2066 	mov	r0,a
      00803E 22               [24] 2067 	ret
                                   2068 
                                   2069 	.area CSEG (CODE)
                                   2070 ; function ak820_outline_0113
      00803F                       2071 _ak820_outline_0113:
      00803F F0               [24] 2072 	movx	@dptr,a
      008040 E0               [24] 2073 	movx	a,@dptr
      008041 FF               [12] 2074 	mov	r7,a
      008042 90 09 85         [24] 2075 	mov	dptr,#_change_owned_PARM_2
      008045 22               [24] 2076 	ret
                                   2077 
                                   2078 	.area CSEG (CODE)
                                   2079 ; function ak820_outline_0118
      008046                       2080 _ak820_outline_0118:
      008046 8D 82            [24] 2081 	mov	dpl,r5
      008048 8E 83            [24] 2082 	mov	dph,r6
      00804A F0               [24] 2083 	movx	@dptr,a
      00804B 22               [24] 2084 	ret
                                   2085 
                                   2086 	.area CSEG (CODE)
                                   2087 ; function ak820_outline_0124
      00804C                       2088 _ak820_outline_0124:
      00804C 24 68            [12] 2089 	add	a,#_usage_order
      00804E F5 82            [12] 2090 	mov	dpl,a
      008050 EF               [12] 2091 	mov	a,r7
      008051 34 0A            [12] 2092 	addc	a,#(_usage_order>>8)
      008053 F5 83            [12] 2093 	mov	dph,a
      008055 E0               [24] 2094 	movx	a,@dptr
      008056 22               [24] 2095 	ret
                                   2096 
                                   2097 	.area CSEG (CODE)
                                   2098 ; function ak820_outline_0130
      008057                       2099 _ak820_outline_0130:
      008057 F0               [24] 2100 	movx	@dptr,a
      008058 E0               [24] 2101 	movx	a,@dptr
      008059 FF               [12] 2102 	mov	r7,a
      00805A 90 09 81         [24] 2103 	mov	dptr,#_ak820_macro_change_PARM_2
      00805D F0               [24] 2104 	movx	@dptr,a
      00805E 90 09 82         [24] 2105 	mov	dptr,#_ak820_macro_change_PARM_3
      008061 22               [24] 2106 	ret
                                   2107 
                                   2108 	.area CSEG (CODE)
                                   2109 ; function ak820_outline_0171
      008062                       2110 _ak820_outline_0171:
      008062 90 07 FB         [24] 2111 	mov	dptr,#_add_key_to_report_PARM_2
      008065 EF               [12] 2112 	mov	a,r7
      008066 F0               [24] 2113 	movx	@dptr,a
      008067 90 0D 98         [24] 2114 	mov	dptr,#_actual_keyboard_report
      00806A 22               [24] 2115 	ret
                                   2116 
                                   2117 	.area CSEG (CODE)
                                   2118 ; function ak820_outline_0184
      00806B                       2119 _ak820_outline_0184:
      00806B 8D 82            [24] 2120 	mov	dpl,r5
      00806D 8F 83            [24] 2121 	mov	dph,r7
      00806F 22               [24] 2122 	ret
