                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000042                        541 _vial_handle_cmd_sloc0_1_0:
      000042                        542 	.ds 2
      000044                        543 _vial_handle_cmd_sloc1_1_0:
      000044                        544 	.ds 2
      000046                        545 _vial_handle_cmd_sloc2_1_0:
      000046                        546 	.ds 2
      000048                        547 _vial_handle_cmd_sloc3_1_0:
      000048                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C29                        573 _vial_unlock_timer:
      000C29                        574 	.ds 4
      000C2D                        575 _vial_unlock_holding:
      000C2D                        576 	.ds 1
      000C2E                        577 _vial_keycode_firewall_in_10000_610:
      000C2E                        578 	.ds 2
      000C30                        579 _vial_fill_packet_PARM_2:
      000C30                        580 	.ds 1
      000C31                        581 _vial_fill_packet_msg_10000_613:
      000C31                        582 	.ds 2
      000C33                        583 _vial_handle_cmd_PARM_2:
      000C33                        584 	.ds 1
      000C34                        585 _vial_handle_cmd_data_10000_618:
      000C34                        586 	.ds 3
      000C37                        587 _vial_handle_cmd_entry_70000_646:
      000C37                        588 	.ds 10
      000C41                        589 _vial_handle_cmd_entry_70000_647:
      000C41                        590 	.ds 10
      000C4B                        591 _g_vial_magic_keycode_override::
      000C4B                        592 	.ds 2
      000C4D                        593 _vial_keycode_down_keycode_10000_649:
      000C4D                        594 	.ds 2
      000C4F                        595 _vial_keycode_down_dummy_event_30000_656:
      000C4F                        596 	.ds 6
      000C55                        597 _vial_keycode_up_keycode_10000_657:
      000C55                        598 	.ds 2
      000C57                        599 _vial_keycode_up_dummy_event_30000_664:
      000C57                        600 	.ds 6
      000C5D                        601 _vial_keycode_tap_keycode_10000_665:
      000C5D                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000DF3                        611 _vial_unlocked::
      000DF3                        612 	.ds 1
      000DF4                        613 _vial_unlock_in_progress::
      000DF4                        614 	.ds 1
      000DF5                        615 _vial_unlock_counter:
      000DF5                        616 	.ds 1
      000DF6                        617 _vial_unlock_combo_rows:
      000DF6                        618 	.ds 2
      000DF8                        619 _vial_unlock_combo_cols:
      000DF8                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00AAF5                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00AAF5 90 0D F4         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00AAF8 E0               [24]  667 	movx	a,@dptr
      00AAF9 70 01            [24]  668 	jnz	00131$
      00AAFB 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AAFC                        671 00131$:
      00AAFC 7F 00            [12]  672 	mov	r7,#0x00
      00AAFE                        673 00115$:
      00AAFE BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00AB01                        675 00184$:
      00AB01 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00AB03 EF               [12]  678 	mov	a,r7
      00AB04 12 B0 BA         [24]  679 	lcall	_ak820_outline_0126
      00AB07 FE               [12]  680 	mov	r6,a
      00AB08 EF               [12]  681 	mov	a,r7
      00AB09 12 B0 AF         [24]  682 	lcall	_ak820_outline_0125
      00AB0C 90 07 5B         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00AB0F F0               [24]  684 	movx	@dptr,a
      00AB10 8E 82            [24]  685 	mov	dpl, r6
      00AB12 C0 07            [24]  686 	push	ar7
      00AB14 12 58 EE         [24]  687 	lcall	_matrix_is_on
      00AB17 E5 82            [12]  688 	mov	a, dpl
      00AB19 D0 07            [24]  689 	pop	ar7
      00AB1B 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00AB1D 90 0C 2D         [24]  692 	mov	dptr,#_vial_unlock_holding
      00AB20 E4               [12]  693 	clr	a
      00AB21 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AB22 90 0D F5         [24]  696 	mov	dptr,#_vial_unlock_counter
      00AB25 74 1E            [12]  697 	mov	a,#0x1e
      00AB27 F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00AB28 22               [24]  700 	ret
      00AB29                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AB29 0F               [12]  703 	inc	r7
      00AB2A 80 D2            [24]  704 	sjmp	00115$
      00AB2C                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00AB2C 90 0C 2D         [24]  707 	mov	dptr,#_vial_unlock_holding
      00AB2F E0               [24]  708 	movx	a,@dptr
      00AB30 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00AB32 90 0C 2D         [24]  711 	mov	dptr,#_vial_unlock_holding
      00AB35 74 01            [12]  712 	mov	a,#0x01
      00AB37 F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00AB38 12 48 C4         [24]  715 	lcall	_timer_read32
      00AB3B 12 4E D3         [24]  716 	lcall	_ak820_outline_0055
      00AB3E 90 0C 29         [24]  717 	mov	dptr,#_vial_unlock_timer
      00AB41 12 8F 79         [24]  718 	lcall	_ak820_outline_0007
      00AB44                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00AB44 90 0C 29         [24]  721 	mov	dptr,#_vial_unlock_timer
      00AB47 12 4E C2         [24]  722 	lcall	_ak820_outline_0053
      00AB4A 12 49 1D         [24]  723 	lcall	_timer_elapsed32
      00AB4D 12 4E D3         [24]  724 	lcall	_ak820_outline_0055
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00AB50 7B 1E            [12]  726 	mov	r3,#0x1e
      00AB52                        727 00109$:
      00AB52 EB               [12]  728 	mov	a,r3
      00AB53 60 22            [24]  729 	jz	00111$
      00AB55 C3               [12]  730 	clr	c
      00AB56 EC               [12]  731 	mov	a,r4
      00AB57 94 64            [12]  732 	subb	a,#0x64
      00AB59 ED               [12]  733 	mov	a,r5
      00AB5A 94 00            [12]  734 	subb	a,#0x00
      00AB5C EE               [12]  735 	mov	a,r6
      00AB5D 94 00            [12]  736 	subb	a,#0x00
      00AB5F EF               [12]  737 	mov	a,r7
      00AB60 94 00            [12]  738 	subb	a,#0x00
      00AB62 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00AB64 EC               [12]  741 	mov	a,r4
      00AB65 24 9C            [12]  742 	add	a,#0x9c
      00AB67 FC               [12]  743 	mov	r4,a
      00AB68 ED               [12]  744 	mov	a,r5
      00AB69 34 FF            [12]  745 	addc	a,#0xff
      00AB6B FD               [12]  746 	mov	r5,a
      00AB6C EE               [12]  747 	mov	a,r6
      00AB6D 34 FF            [12]  748 	addc	a,#0xff
      00AB6F FE               [12]  749 	mov	r6,a
      00AB70 EF               [12]  750 	mov	a,r7
      00AB71 34 FF            [12]  751 	addc	a,#0xff
      00AB73 FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00AB74 1B               [12]  754 	dec	r3
      00AB75 80 DB            [24]  755 	sjmp	00109$
      00AB77                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00AB77 90 0D F5         [24]  758 	mov	dptr,#_vial_unlock_counter
      00AB7A EB               [12]  759 	mov	a,r3
      00AB7B F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00AB7C EB               [12]  762 	mov	a,r3
      00AB7D 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00AB7F 90 0D F4         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00AB82 E4               [12]  766 	clr	a
      00AB83 F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00AB84 90 0D F3         [24]  769 	mov	dptr,#_vial_unlocked
      00AB87 04               [12]  770 	inc	a
      00AB88 F0               [24]  771 	movx	@dptr,a
      00AB89                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00AB89 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:117: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00AB8A                        782 _vial_init:
                                    783 ;	quantum/vial.c:125: reload_combo();
                                    784 ;	quantum/vial.c:130: }
      00AB8A 02 35 37         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_610'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00AB8D                        795 _vial_keycode_firewall:
      00AB8D 12 38 43         [24]  796 	lcall	_ak820_outline_0103
      00AB90 90 0C 2E         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_610
      00AB93 12 38 48         [24]  798 	lcall	_ak820_outline_0104
                                    799 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00AB96 90 0C 2E         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_610
      00AB99 12 37 CB         [24]  801 	lcall	_ak820_outline_0010
      00AB9C BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00AB9F BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00ABA2 90 0D F3         [24]  804 	mov	dptr,#_vial_unlocked
      00ABA5 E0               [24]  805 	movx	a,@dptr
      00ABA6 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:134: return 0;
      00ABA8 90 00 00         [24]  808 	mov	dptr,#0x0000
      00ABAB 22               [24]  809 	ret
      00ABAC                        810 00102$:
                                    811 ;	quantum/vial.c:135: return in;
      00ABAC 12 43 20         [24]  812 	lcall	_ak820_outline_0116
                                    813 ;	quantum/vial.c:136: }
      00ABAF 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_613'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_615'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00ABB0                        826 _vial_fill_packet:
      00ABB0 12 38 43         [24]  827 	lcall	_ak820_outline_0103
      00ABB3 90 0C 31         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_613
      00ABB6 12 38 48         [24]  829 	lcall	_ak820_outline_0104
                                    830 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00ABB9 90 0C 31         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_613
      00ABBC 12 38 00         [24]  832 	lcall	_ak820_outline_0050
      00ABBF 90 0C 30         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00ABC2 E0               [24]  834 	movx	a,@dptr
      00ABC3 FD               [12]  835 	mov	r5,a
      00ABC4 7C 00            [12]  836 	mov	r4,#0x00
      00ABC6                        837 00103$:
      00ABC6 BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00ABC9                        839 00122$:
      00ABC9 50 09            [24]  840 	jnc	00105$
      00ABCB EC               [12]  841 	mov	a,r4
      00ABCC 12 37 F0         [24]  842 	lcall	_ak820_outline_0030
      00ABCF ED               [12]  843 	mov	a,r5
      00ABD0 F0               [24]  844 	movx	@dptr,a
      00ABD1 0C               [12]  845 	inc	r4
      00ABD2 80 F2            [24]  846 	sjmp	00103$
      00ABD4                        847 00105$:
                                    848 ;	quantum/vial.c:141: }
      00ABD4 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00ABD5                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:174: repeat_key_cancel();
      00ABD5 12 9F CC         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:176: clear_keyboard();
                                    861 ;	quantum/vial.c:177: }
      00ABD8 02 75 CD         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_618'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_619'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_624'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_625'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_628'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_630'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_630'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_630'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_631'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_632'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_632'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_632'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_635'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_647'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_647'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00ABDB                        893 _vial_handle_cmd:
      00ABDB 12 42 DE         [24]  894 	lcall	_ak820_outline_0036
      00ABDE 90 0C 34         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_618
      00ABE1 12 37 DF         [24]  896 	lcall	_ak820_outline_0015
                                    897 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00ABE4 90 0C 34         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_618
      00ABE7 12 38 00         [24]  899 	lcall	_ak820_outline_0050
                                    900 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00ABEA 90 0C 33         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00ABED E0               [24]  902 	movx	a,@dptr
      00ABEE FD               [12]  903 	mov	r5,a
      00ABEF BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00ABF2 80 01            [24]  905 	sjmp	00102$
      00ABF4                        906 00258$:
                                    907 ;	quantum/vial.c:190: return;
      00ABF4 22               [24]  908 	ret
      00ABF5                        909 00102$:
                                    910 ;	quantum/vial.c:193: switch (msg[1]) {
      00ABF5 74 01            [12]  911 	mov	a,#0x01
      00ABF7 12 47 FD         [24]  912 	lcall	_ak820_outline_0011
      00ABFA FB               [12]  913 	mov  r3,a
      00ABFB 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00ABFD 50 01            [24]  915 	jnc	00259$
      00ABFF 22               [24]  916 	ret
      00AC00                        917 00259$:
                                    918 ;	free result
      00AC00 EB               [12]  919 	mov	a,r3
      00AC01 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00AC03 83               [24]  921 	movc	a,@a+pc
      00AC04 F5 82            [12]  922 	mov	dpl,a
      00AC06 EB               [12]  923 	mov	a,r3
      00AC07 24 12            [12]  924 	add	a,#(00261$-3-.)
      00AC09 83               [24]  925 	movc	a,@a+pc
      00AC0A F5 83            [12]  926 	mov	dph,a
      00AC0C E4               [12]  927 	clr	a
      00AC0D 73               [24]  928 	jmp	@a+dptr
      00AC0E                        929 00260$:
      00AC0E 2A                     930 	.db	00103$
      00AC0F 72                     931 	.db	00105$
      00AC10 86                     932 	.db	00106$
      00AC11 12                     933 	.db	00112$
      00AC12 98                     934 	.db	00113$
      00AC13 E3                     935 	.db	00114$
      00AC14 52                     936 	.db	00116$
      00AC15 6D                     937 	.db	00119$
      00AC16 8D                     938 	.db	00120$
      00AC17 9B                     939 	.db	00121$
      00AC18 9B                     940 	.db	00139$
      00AC19 9B                     941 	.db	00139$
      00AC1A 9B                     942 	.db	00139$
      00AC1B A6                     943 	.db	00122$
      00AC1C                        944 00261$:
      00AC1C AC                     945 	.db	00103$>>8
      00AC1D AC                     946 	.db	00105$>>8
      00AC1E AC                     947 	.db	00106$>>8
      00AC1F AD                     948 	.db	00112$>>8
      00AC20 AD                     949 	.db	00113$>>8
      00AC21 AD                     950 	.db	00114$>>8
      00AC22 AE                     951 	.db	00116$>>8
      00AC23 AE                     952 	.db	00119$>>8
      00AC24 AE                     953 	.db	00120$>>8
      00AC25 AE                     954 	.db	00121$>>8
      00AC26 AF                     955 	.db	00139$>>8
      00AC27 AF                     956 	.db	00139$>>8
      00AC28 AF                     957 	.db	00139$>>8
      00AC29 AE                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00AC2A                        960 00103$:
                                    961 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00AC2A 90 0C 30         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00AC2D E4               [12]  963 	clr	a
      00AC2E 12 43 02         [24]  964 	lcall	_ak820_outline_0060
      00AC31 C0 07            [24]  965 	push	ar7
      00AC33 C0 06            [24]  966 	push	ar6
      00AC35 12 AB B0         [24]  967 	lcall	_vial_fill_packet
      00AC38 D0 06            [24]  968 	pop	ar6
      00AC3A D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00AC3C 12 43 20         [24]  971 	lcall	_ak820_outline_0116
      00AC3F 74 06            [12]  972 	mov	a,#0x06
      00AC41 12 43 02         [24]  973 	lcall	_ak820_outline_0060
                                    974 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00AC44 A3               [24]  975 	inc	dptr
      00AC45 E4               [12]  976 	clr	a
      00AC46 12 42 D6         [24]  977 	lcall	_ak820_outline_0029
                                    978 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00AC49 12 42 D6         [24]  979 	lcall	_ak820_outline_0029
                                    980 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00AC4C A3               [24]  981 	inc	dptr
      00AC4D F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00AC4E FB               [12]  984 	mov	r3,a
      00AC4F                        985 00131$:
      00AC4F BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00AC52                        987 00262$:
      00AC52 50 15            [24]  988 	jnc	00104$
      00AC54 8B 02            [24]  989 	mov	ar2,r3
      00AC56 74 04            [12]  990 	mov	a,#0x04
      00AC58 2A               [12]  991 	add	a, r2
      00AC59 2E               [12]  992 	add	a, r6
      00AC5A F9               [12]  993 	mov	r1,a
      00AC5B E4               [12]  994 	clr	a
      00AC5C 3F               [12]  995 	addc	a,r7
      00AC5D FA               [12]  996 	mov	r2,a
      00AC5E EB               [12]  997 	mov	a,r3
      00AC5F 90 BD 65         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_623
      00AC62 93               [24]  999 	movc	a,@a+dptr
      00AC63 12 6B DF         [24] 1000 	lcall	_ak820_outline_0136
      00AC66 0B               [12] 1001 	inc	r3
      00AC67 80 E6            [24] 1002 	sjmp	00131$
      00AC69                       1003 00104$:
                                   1004 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00AC69 74 0C            [12] 1005 	mov	a,#0x0c
      00AC6B 12 37 F0         [24] 1006 	lcall	_ak820_outline_0030
      00AC6E 74 01            [12] 1007 	mov	a,#0x01
      00AC70 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:207: break;
      00AC71 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:210: case vial_get_size: {
      00AC72                       1012 00105$:
                                   1013 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00AC72 12 43 20         [24] 1014 	lcall	_ak820_outline_0116
      00AC75 74 7C            [12] 1015 	mov	a,#0x7c
      00AC77 12 38 31         [24] 1016 	lcall	_ak820_outline_0095
                                   1017 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00AC7A 74 01            [12] 1018 	mov	a,#0x01
      00AC7C 12 42 D6         [24] 1019 	lcall	_ak820_outline_0029
                                   1020 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00AC7F E4               [12] 1021 	clr	a
      00AC80 12 42 D6         [24] 1022 	lcall	_ak820_outline_0029
                                   1023 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00AC83 A3               [24] 1024 	inc	dptr
      00AC84 F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	quantum/vial.c:216: break;
      00AC85 22               [24] 1027 	ret
                                   1028 ;	quantum/vial.c:219: case vial_get_def: {
      00AC86                       1029 00106$:
                                   1030 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00AC86 12 AA B9         [24] 1031 	lcall	_ak820_outline_0019
      00AC89 E0               [24] 1032 	movx	a,@dptr
      00AC8A FB               [12] 1033 	mov	r3,a
      00AC8B 12 42 CC         [24] 1034 	lcall	_ak820_outline_0009
      00AC8E E0               [24] 1035 	movx	a,@dptr
      00AC8F 4B               [12] 1036 	orl	a,r3
      00AC90 60 01            [24] 1037 	jz	00108$
      00AC92 22               [24] 1038 	ret
      00AC93                       1039 00108$:
                                   1040 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00AC93 12 37 F8         [24] 1041 	lcall	_ak820_outline_0033
      00AC96 FB               [12] 1042 	mov	r3,a
      00AC97 7A 00            [12] 1043 	mov	r2,#0x00
      00AC99 12 AA B0         [24] 1044 	lcall	_ak820_outline_0014
      00AC9C F9               [12] 1045 	mov	r1,a
      00AC9D E4               [12] 1046 	clr	a
      00AC9E 42 03            [12] 1047 	orl	ar3,a
      00ACA0 E9               [12] 1048 	mov	a,r1
      00ACA1 42 02            [12] 1049 	orl	ar2,a
                                   1050 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00ACA3 C3               [12] 1051 	clr	c
      00ACA4 EB               [12] 1052 	mov	a,r3
      00ACA5 94 0C            [12] 1053 	subb	a,#0x0c
      00ACA7 EA               [12] 1054 	mov	a,r2
      00ACA8 94 00            [12] 1055 	subb	a,#0x00
      00ACAA 40 01            [24] 1056 	jc	00110$
      00ACAC 22               [24] 1057 	ret
      00ACAD                       1058 00110$:
                                   1059 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00ACAD EA               [12] 1060 	mov	a,r2
      00ACAE C4               [12] 1061 	swap	a
      00ACAF 23               [12] 1062 	rl	a
      00ACB0 54 E0            [12] 1063 	anl	a,#0xe0
      00ACB2 CB               [12] 1064 	xch	a,r3
      00ACB3 C4               [12] 1065 	swap	a
      00ACB4 23               [12] 1066 	rl	a
      00ACB5 CB               [12] 1067 	xch	a,r3
      00ACB6 6B               [12] 1068 	xrl	a,r3
      00ACB7 CB               [12] 1069 	xch	a,r3
      00ACB8 54 E0            [12] 1070 	anl	a,#0xe0
      00ACBA CB               [12] 1071 	xch	a,r3
      00ACBB 6B               [12] 1072 	xrl	a,r3
      00ACBC FA               [12] 1073 	mov	r2,a
      00ACBD 8B 42            [24] 1074 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00ACBF 8A 43            [24] 1075 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1076 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00ACC1 74 7C            [12] 1077 	mov	a,#0x7c
      00ACC3 C3               [12] 1078 	clr	c
      00ACC4 95 42            [12] 1079 	subb	a,_vial_handle_cmd_sloc0_1_0
      00ACC6 F8               [12] 1080 	mov	r0,a
      00ACC7 74 01            [12] 1081 	mov	a,#0x01
      00ACC9 95 43            [12] 1082 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00ACCB F9               [12] 1083 	mov	r1,a
                                   1084 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00ACCC C3               [12] 1085 	clr	c
      00ACCD E8               [12] 1086 	mov	a,r0
      00ACCE 94 20            [12] 1087 	subb	a,#0x20
      00ACD0 E9               [12] 1088 	mov	a,r1
      00ACD1 94 00            [12] 1089 	subb	a,#0x00
      00ACD3 40 02            [24] 1090 	jc	00142$
      00ACD5 78 20            [12] 1091 	mov	r0,#0x20
      00ACD7                       1092 00142$:
                                   1093 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00ACD7 79 00            [12] 1094 	mov	r1,#0x00
      00ACD9                       1095 00134$:
      00ACD9 C3               [12] 1096 	clr	c
      00ACDA E9               [12] 1097 	mov	a,r1
      00ACDB 98               [12] 1098 	subb	a,r0
      00ACDC 40 01            [24] 1099 	jc	00267$
      00ACDE 22               [24] 1100 	ret
      00ACDF                       1101 00267$:
      00ACDF C0 00            [24] 1102 	push	ar0
      00ACE1 E9               [12] 1103 	mov	a,r1
      00ACE2 2E               [12] 1104 	add	a, r6
      00ACE3 F5 44            [12] 1105 	mov	_vial_handle_cmd_sloc1_1_0,a
      00ACE5 E4               [12] 1106 	clr	a
      00ACE6 3F               [12] 1107 	addc	a, r7
      00ACE7 F5 45            [12] 1108 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00ACE9 89 46            [24] 1109 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00ACEB 75 47 00         [24] 1110 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00ACEE A8 42            [24] 1111 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00ACF0 AB 43            [24] 1112 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00ACF2 E5 46            [12] 1113 	mov	a,_vial_handle_cmd_sloc2_1_0
      00ACF4 28               [12] 1114 	add	a, r0
      00ACF5 F8               [12] 1115 	mov	r0,a
      00ACF6 E5 47            [12] 1116 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00ACF8 3B               [12] 1117 	addc	a, r3
      00ACF9 FB               [12] 1118 	mov	r3,a
      00ACFA E8               [12] 1119 	mov	a,r0
      00ACFB 24 E9            [12] 1120 	add	a, #_keyboard_definition
      00ACFD F5 82            [12] 1121 	mov	dpl,a
      00ACFF EB               [12] 1122 	mov	a,r3
      00AD00 34 BB            [12] 1123 	addc	a, #(_keyboard_definition >> 8)
      00AD02 F5 83            [12] 1124 	mov	dph,a
      00AD04 E4               [12] 1125 	clr	a
      00AD05 93               [24] 1126 	movc	a,@a+dptr
      00AD06 85 44 82         [24] 1127 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AD09 85 45 83         [24] 1128 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AD0C F0               [24] 1129 	movx	@dptr,a
      00AD0D 09               [12] 1130 	inc	r1
      00AD0E D0 00            [24] 1131 	pop	ar0
                                   1132 ;	quantum/vial.c:246: case vial_get_encoder: {
      00AD10 80 C7            [24] 1133 	sjmp	00134$
      00AD12                       1134 00112$:
                                   1135 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00AD12 74 02            [12] 1136 	mov	a,#0x02
      00AD14 12 48 3B         [24] 1137 	lcall	_ak820_outline_0045
      00AD17 F5 46            [12] 1138 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1139 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00AD19 74 03            [12] 1140 	mov	a,#0x03
      00AD1B 2E               [12] 1141 	add	a, r6
      00AD1C F5 44            [12] 1142 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AD1E E4               [12] 1143 	clr	a
      00AD1F 3F               [12] 1144 	addc	a, r7
      00AD20 F5 45            [12] 1145 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00AD22 85 44 82         [24] 1146 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AD25 85 45 83         [24] 1147 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AD28 E0               [24] 1148 	movx	a,@dptr
                                   1149 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00AD29 F5 42            [12] 1150 	mov	_vial_handle_cmd_sloc0_1_0,a
      00AD2B 90 0A DE         [24] 1151 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00AD2E F0               [24] 1152 	movx	@dptr,a
      00AD2F 90 0A DF         [24] 1153 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AD32 E4               [12] 1154 	clr	a
      00AD33 F0               [24] 1155 	movx	@dptr,a
      00AD34 85 46 82         [24] 1156 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AD37 C0 07            [24] 1157 	push	ar7
      00AD39 C0 06            [24] 1158 	push	ar6
      00AD3B C0 05            [24] 1159 	push	ar5
      00AD3D C0 04            [24] 1160 	push	ar4
      00AD3F C0 03            [24] 1161 	push	ar3
      00AD41 C0 02            [24] 1162 	push	ar2
      00AD43 12 83 FC         [24] 1163 	lcall	_dynamic_keymap_get_encoder
      00AD46 85 82 48         [24] 1164 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AD49 85 83 49         [24] 1165 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AD4C D0 02            [24] 1166 	pop	ar2
      00AD4E D0 03            [24] 1167 	pop	ar3
      00AD50 D0 04            [24] 1168 	pop	ar4
      00AD52 D0 05            [24] 1169 	pop	ar5
      00AD54 D0 06            [24] 1170 	pop	ar6
      00AD56 D0 07            [24] 1171 	pop	ar7
                                   1172 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00AD58 A9 49            [24] 1173 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AD5A 12 43 20         [24] 1174 	lcall	_ak820_outline_0116
      00AD5D E9               [12] 1175 	mov	a,r1
      00AD5E F0               [24] 1176 	movx	@dptr,a
                                   1177 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00AD5F A8 48            [24] 1178 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AD61 12 38 60         [24] 1179 	lcall	_ak820_outline_0121
      00AD64 E8               [12] 1180 	mov	a,r0
      00AD65 F0               [24] 1181 	movx	@dptr,a
                                   1182 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00AD66 90 0A DE         [24] 1183 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00AD69 E5 42            [12] 1184 	mov	a,_vial_handle_cmd_sloc0_1_0
      00AD6B F0               [24] 1185 	movx	@dptr,a
      00AD6C 90 0A DF         [24] 1186 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AD6F 74 01            [12] 1187 	mov	a,#0x01
      00AD71 F0               [24] 1188 	movx	@dptr,a
      00AD72 85 46 82         [24] 1189 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AD75 C0 03            [24] 1190 	push	ar3
      00AD77 C0 02            [24] 1191 	push	ar2
      00AD79 12 83 FC         [24] 1192 	lcall	_dynamic_keymap_get_encoder
      00AD7C 85 82 48         [24] 1193 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AD7F 85 83 49         [24] 1194 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AD82 D0 02            [24] 1195 	pop	ar2
      00AD84 D0 03            [24] 1196 	pop	ar3
                                   1197 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00AD86 A9 49            [24] 1198 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AD88 12 43 3C         [24] 1199 	lcall	_ak820_outline_0140
      00AD8B E9               [12] 1200 	mov	a,r1
      00AD8C F0               [24] 1201 	movx	@dptr,a
                                   1202 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00AD8D A8 48            [24] 1203 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AD8F 85 44 82         [24] 1204 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AD92 85 45 83         [24] 1205 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AD95 E8               [12] 1206 	mov	a,r0
      00AD96 F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	quantum/vial.c:255: break;
      00AD97 22               [24] 1209 	ret
                                   1210 ;	quantum/vial.c:257: case vial_set_encoder: {
      00AD98                       1211 00113$:
                                   1212 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00AD98 12 37 F8         [24] 1213 	lcall	_ak820_outline_0033
      00AD9B F5 44            [12] 1214 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AD9D 12 AA B0         [24] 1215 	lcall	_ak820_outline_0014
      00ADA0 F5 46            [12] 1216 	mov	_vial_handle_cmd_sloc2_1_0,a
      00ADA2 12 AA B9         [24] 1217 	lcall	_ak820_outline_0019
      00ADA5 E0               [24] 1218 	movx	a,@dptr
                                   1219 ;	assignBit
      00ADA6 24 FF            [12] 1220 	add	a,#0xff
      00ADA8 E4               [12] 1221 	clr	a
      00ADA9 33               [12] 1222 	rlc	a
      00ADAA F5 48            [12] 1223 	mov	_vial_handle_cmd_sloc3_1_0,a
      00ADAC 12 42 CC         [24] 1224 	lcall	_ak820_outline_0009
      00ADAF E0               [24] 1225 	movx	a,@dptr
      00ADB0 F9               [12] 1226 	mov	r1,a
      00ADB1 78 00            [12] 1227 	mov	r0,#0x00
      00ADB3 74 06            [12] 1228 	mov	a,#0x06
      00ADB5 12 37 E7         [24] 1229 	lcall	_ak820_outline_0016
      00ADB8 7B 00            [12] 1230 	mov	r3,#0x00
      00ADBA 42 00            [12] 1231 	orl	ar0,a
      00ADBC EB               [12] 1232 	mov	a,r3
      00ADBD 42 01            [12] 1233 	orl	ar1,a
      00ADBF 12 38 75         [24] 1234 	lcall	_ak820_outline_0152
      00ADC2 12 AB 8D         [24] 1235 	lcall	_vial_keycode_firewall
      00ADC5 AA 82            [24] 1236 	mov	r2, dpl
      00ADC7 AB 83            [24] 1237 	mov	r3, dph
      00ADC9 90 0A E1         [24] 1238 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00ADCC E5 46            [12] 1239 	mov	a,_vial_handle_cmd_sloc2_1_0
      00ADCE F0               [24] 1240 	movx	@dptr,a
      00ADCF 90 0A E2         [24] 1241 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00ADD2 E5 48            [12] 1242 	mov	a,_vial_handle_cmd_sloc3_1_0
      00ADD4 F0               [24] 1243 	movx	@dptr,a
      00ADD5 90 0A E3         [24] 1244 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00ADD8 EA               [12] 1245 	mov	a,r2
      00ADD9 F0               [24] 1246 	movx	@dptr,a
      00ADDA EB               [12] 1247 	mov	a,r3
      00ADDB A3               [24] 1248 	inc	dptr
      00ADDC F0               [24] 1249 	movx	@dptr,a
      00ADDD 85 44 82         [24] 1250 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1251 ;	quantum/vial.c:259: break;
      00ADE0 02 84 64         [24] 1252 	ljmp	_dynamic_keymap_set_encoder
                                   1253 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00ADE3                       1254 00114$:
                                   1255 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00ADE3 90 0C 30         [24] 1256 	mov	dptr,#_vial_fill_packet_PARM_2
      00ADE6 74 FF            [12] 1257 	mov	a,#0xff
      00ADE8 12 43 02         [24] 1258 	lcall	_ak820_outline_0060
      00ADEB C0 07            [24] 1259 	push	ar7
      00ADED C0 06            [24] 1260 	push	ar6
      00ADEF 12 AB B0         [24] 1261 	lcall	_vial_fill_packet
      00ADF2 D0 06            [24] 1262 	pop	ar6
      00ADF4 D0 07            [24] 1263 	pop	ar7
                                   1264 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00ADF6 90 0D F3         [24] 1265 	mov	dptr,#_vial_unlocked
      00ADF9 E0               [24] 1266 	movx	a,@dptr
      00ADFA 12 43 20         [24] 1267 	lcall	_ak820_outline_0116
      00ADFD F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00ADFE 74 01            [12] 1270 	mov	a,#0x01
      00AE00 2E               [12] 1271 	add	a, r6
      00AE01 FA               [12] 1272 	mov	r2,a
      00AE02 E4               [12] 1273 	clr	a
      00AE03 3F               [12] 1274 	addc	a, r7
      00AE04 FB               [12] 1275 	mov	r3,a
      00AE05 90 0D F4         [24] 1276 	mov	dptr,#_vial_unlock_in_progress
      00AE08 E0               [24] 1277 	movx	a,@dptr
      00AE09 12 43 3C         [24] 1278 	lcall	_ak820_outline_0140
      00AE0C F0               [24] 1279 	movx	@dptr,a
                                   1280 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AE0D 7B 00            [12] 1281 	mov	r3,#0x00
      00AE0F                       1282 00137$:
      00AE0F BB 02 00         [24] 1283 	cjne	r3,#0x02,00268$
      00AE12                       1284 00268$:
      00AE12 40 01            [24] 1285 	jc	00269$
      00AE14 22               [24] 1286 	ret
      00AE15                       1287 00269$:
                                   1288 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00AE15 8B 01            [24] 1289 	mov	ar1,r3
      00AE17 7A 00            [12] 1290 	mov	r2,#0x00
      00AE19 E9               [12] 1291 	mov	a,r1
      00AE1A 29               [12] 1292 	add	a,r1
      00AE1B F5 48            [12] 1293 	mov	_vial_handle_cmd_sloc3_1_0,a
      00AE1D EA               [12] 1294 	mov	a,r2
      00AE1E 33               [12] 1295 	rlc	a
      00AE1F F5 49            [12] 1296 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00AE21 74 02            [12] 1297 	mov	a,#0x02
      00AE23 25 48            [12] 1298 	add	a, _vial_handle_cmd_sloc3_1_0
      00AE25 F8               [12] 1299 	mov	r0,a
      00AE26 E4               [12] 1300 	clr	a
      00AE27 35 49            [12] 1301 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00AE29 FA               [12] 1302 	mov	r2,a
      00AE2A E8               [12] 1303 	mov	a,r0
      00AE2B 2E               [12] 1304 	add	a, r6
      00AE2C F8               [12] 1305 	mov	r0,a
      00AE2D EA               [12] 1306 	mov	a,r2
      00AE2E 3F               [12] 1307 	addc	a, r7
      00AE2F FA               [12] 1308 	mov	r2,a
      00AE30 EB               [12] 1309 	mov	a,r3
      00AE31 12 B0 BA         [24] 1310 	lcall	_ak820_outline_0126
      00AE34 88 82            [24] 1311 	mov	dpl,r0
      00AE36 8A 83            [24] 1312 	mov	dph,r2
      00AE38 F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00AE39 74 03            [12] 1315 	mov	a,#0x03
      00AE3B 25 48            [12] 1316 	add	a, _vial_handle_cmd_sloc3_1_0
      00AE3D F9               [12] 1317 	mov	r1,a
      00AE3E E4               [12] 1318 	clr	a
      00AE3F 35 49            [12] 1319 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00AE41 FA               [12] 1320 	mov	r2,a
      00AE42 E9               [12] 1321 	mov	a,r1
      00AE43 2E               [12] 1322 	add	a, r6
      00AE44 F9               [12] 1323 	mov	r1,a
      00AE45 EA               [12] 1324 	mov	a,r2
      00AE46 3F               [12] 1325 	addc	a, r7
      00AE47 FA               [12] 1326 	mov	r2,a
      00AE48 EB               [12] 1327 	mov	a,r3
      00AE49 12 B0 AF         [24] 1328 	lcall	_ak820_outline_0125
      00AE4C 12 6B DF         [24] 1329 	lcall	_ak820_outline_0136
                                   1330 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AE4F 0B               [12] 1331 	inc	r3
                                   1332 ;	quantum/vial.c:278: case vial_unlock_start: {
      00AE50 80 BD            [24] 1333 	sjmp	00137$
      00AE52                       1334 00116$:
                                   1335 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00AE52 90 0D F4         [24] 1336 	mov	dptr,#_vial_unlock_in_progress
      00AE55 E0               [24] 1337 	movx	a,@dptr
      00AE56 70 03            [24] 1338 	jnz	00118$
      00AE58 12 AB D5         [24] 1339 	lcall	_vial_release_held_state
      00AE5B                       1340 00118$:
                                   1341 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00AE5B 90 0D F4         [24] 1342 	mov	dptr,#_vial_unlock_in_progress
      00AE5E 74 01            [12] 1343 	mov	a,#0x01
      00AE60 F0               [24] 1344 	movx	@dptr,a
                                   1345 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AE61 90 0D F5         [24] 1346 	mov	dptr,#_vial_unlock_counter
      00AE64 74 1E            [12] 1347 	mov	a,#0x1e
      00AE66 F0               [24] 1348 	movx	@dptr,a
                                   1349 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00AE67 90 0C 2D         [24] 1350 	mov	dptr,#_vial_unlock_holding
      00AE6A E4               [12] 1351 	clr	a
      00AE6B F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/vial.c:287: break;
      00AE6C 22               [24] 1354 	ret
                                   1355 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00AE6D                       1356 00119$:
                                   1357 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00AE6D 90 0D F3         [24] 1358 	mov	dptr,#_vial_unlocked
      00AE70 E0               [24] 1359 	movx	a,@dptr
      00AE71 12 43 20         [24] 1360 	lcall	_ak820_outline_0116
      00AE74 F0               [24] 1361 	movx	@dptr,a
                                   1362 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00AE75 90 0D F4         [24] 1363 	mov	dptr,#_vial_unlock_in_progress
      00AE78 E0               [24] 1364 	movx	a,@dptr
      00AE79 12 38 60         [24] 1365 	lcall	_ak820_outline_0121
      00AE7C F0               [24] 1366 	movx	@dptr,a
                                   1367 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00AE7D 74 02            [12] 1368 	mov	a,#0x02
      00AE7F 2E               [12] 1369 	add	a, r6
      00AE80 FA               [12] 1370 	mov	r2,a
      00AE81 E4               [12] 1371 	clr	a
      00AE82 3F               [12] 1372 	addc	a, r7
      00AE83 FB               [12] 1373 	mov	r3,a
      00AE84 90 0D F5         [24] 1374 	mov	dptr,#_vial_unlock_counter
      00AE87 E0               [24] 1375 	movx	a,@dptr
      00AE88 12 43 3C         [24] 1376 	lcall	_ak820_outline_0140
      00AE8B F0               [24] 1377 	movx	@dptr,a
                                   1378 ;	quantum/vial.c:293: break;
      00AE8C 22               [24] 1379 	ret
                                   1380 ;	quantum/vial.c:295: case vial_lock: {
      00AE8D                       1381 00120$:
                                   1382 ;	quantum/vial.c:297: vial_unlocked = 0;
      00AE8D 90 0D F3         [24] 1383 	mov	dptr,#_vial_unlocked
      00AE90 E4               [12] 1384 	clr	a
      00AE91 F0               [24] 1385 	movx	@dptr,a
                                   1386 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00AE92 90 0D F4         [24] 1387 	mov	dptr,#_vial_unlock_in_progress
      00AE95 F0               [24] 1388 	movx	@dptr,a
                                   1389 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00AE96 90 0C 2D         [24] 1390 	mov	dptr,#_vial_unlock_holding
      00AE99 F0               [24] 1391 	movx	@dptr,a
                                   1392 ;	quantum/vial.c:301: break;
      00AE9A 22               [24] 1393 	ret
                                   1394 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00AE9B                       1395 00121$:
                                   1396 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00AE9B 90 0C 30         [24] 1397 	mov	dptr,#_vial_fill_packet_PARM_2
      00AE9E 74 FF            [12] 1398 	mov	a,#0xff
      00AEA0 12 43 02         [24] 1399 	lcall	_ak820_outline_0060
                                   1400 ;	quantum/vial.c:314: break;
      00AEA3 02 AB B0         [24] 1401 	ljmp	_vial_fill_packet
                                   1402 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00AEA6                       1403 00122$:
                                   1404 ;	quantum/vial.c:347: switch (msg[2]) {
      00AEA6 12 37 F8         [24] 1405 	lcall	_ak820_outline_0033
      00AEA9 FB               [12] 1406 	mov	r3,a
      00AEAA 60 0C            [24] 1407 	jz	00123$
      00AEAC BB 03 02         [24] 1408 	cjne	r3,#0x03,00272$
      00AEAF 80 31            [24] 1409 	sjmp	00124$
      00AEB1                       1410 00272$:
      00AEB1 BB 04 03         [24] 1411 	cjne	r3,#0x04,00273$
      00AEB4 02 AF 40         [24] 1412 	ljmp	00125$
      00AEB7                       1413 00273$:
      00AEB7 22               [24] 1414 	ret
                                   1415 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00AEB8                       1416 00123$:
                                   1417 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00AEB8 90 0C 30         [24] 1418 	mov	dptr,#_vial_fill_packet_PARM_2
      00AEBB E4               [12] 1419 	clr	a
      00AEBC 12 43 02         [24] 1420 	lcall	_ak820_outline_0060
      00AEBF C0 07            [24] 1421 	push	ar7
      00AEC1 C0 06            [24] 1422 	push	ar6
      00AEC3 12 AB B0         [24] 1423 	lcall	_vial_fill_packet
      00AEC6 D0 06            [24] 1424 	pop	ar6
      00AEC8 D0 07            [24] 1425 	pop	ar7
                                   1426 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00AECA 12 43 20         [24] 1427 	lcall	_ak820_outline_0116
      00AECD E4               [12] 1428 	clr	a
      00AECE 12 43 02         [24] 1429 	lcall	_ak820_outline_0060
                                   1430 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00AED1 A3               [24] 1431 	inc	dptr
      00AED2 74 08            [12] 1432 	mov	a,#0x08
      00AED4 12 42 D6         [24] 1433 	lcall	_ak820_outline_0029
                                   1434 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00AED7 E4               [12] 1435 	clr	a
      00AED8 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00AED9 74 1F            [12] 1438 	mov	a,#0x1f
      00AEDB 12 37 F0         [24] 1439 	lcall	_ak820_outline_0030
      00AEDE 74 01            [12] 1440 	mov	a,#0x01
      00AEE0 F0               [24] 1441 	movx	@dptr,a
                                   1442 ;	quantum/vial.c:356: break;
      00AEE1 22               [24] 1443 	ret
                                   1444 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00AEE2                       1445 00124$:
                                   1446 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00AEE2 12 AA B0         [24] 1447 	lcall	_ak820_outline_0014
      00AEE5 FB               [12] 1448 	mov	r3,a
                                   1449 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00AEE6 90 0C 37         [24] 1450 	mov	dptr,#_vial_handle_cmd_entry_70000_646
      00AEE9 12 4E FB         [24] 1451 	lcall	_ak820_outline_0178
      00AEEC 90 0C 39         [24] 1452 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0002)
      00AEEF F0               [24] 1453 	movx	@dptr,a
      00AEF0 A3               [24] 1454 	inc	dptr
      00AEF1 F0               [24] 1455 	movx	@dptr,a
      00AEF2 90 0C 3B         [24] 1456 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0004)
      00AEF5 F0               [24] 1457 	movx	@dptr,a
      00AEF6 A3               [24] 1458 	inc	dptr
      00AEF7 F0               [24] 1459 	movx	@dptr,a
      00AEF8 90 0C 3D         [24] 1460 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0006)
      00AEFB F0               [24] 1461 	movx	@dptr,a
      00AEFC A3               [24] 1462 	inc	dptr
      00AEFD F0               [24] 1463 	movx	@dptr,a
      00AEFE 90 0C 3F         [24] 1464 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00AF01 F0               [24] 1465 	movx	@dptr,a
      00AF02 A3               [24] 1466 	inc	dptr
      00AF03 F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00AF04 90 0A E6         [24] 1469 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00AF07 74 37            [12] 1470 	mov	a,#_vial_handle_cmd_entry_70000_646
      00AF09 F0               [24] 1471 	movx	@dptr,a
      00AF0A 74 0C            [12] 1472 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00AF0C 12 38 54         [24] 1473 	lcall	_ak820_outline_0117
      00AF0F 8B 82            [24] 1474 	mov	dpl, r3
      00AF11 C0 07            [24] 1475 	push	ar7
      00AF13 C0 06            [24] 1476 	push	ar6
      00AF15 C0 05            [24] 1477 	push	ar5
      00AF17 C0 04            [24] 1478 	push	ar4
      00AF19 12 84 D1         [24] 1479 	lcall	_dynamic_keymap_get_combo
      00AF1C AA 82            [24] 1480 	mov	r2, dpl
      00AF1E D0 04            [24] 1481 	pop	ar4
      00AF20 D0 05            [24] 1482 	pop	ar5
      00AF22 D0 06            [24] 1483 	pop	ar6
      00AF24 D0 07            [24] 1484 	pop	ar7
      00AF26 12 43 20         [24] 1485 	lcall	_ak820_outline_0116
      00AF29 EA               [12] 1486 	mov	a,r2
      00AF2A F0               [24] 1487 	movx	@dptr,a
                                   1488 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00AF2B 7B 00            [12] 1489 	mov	r3,#0x00
      00AF2D 90 0D 73         [24] 1490 	mov	dptr,#___memcpy_PARM_2
      00AF30 74 37            [12] 1491 	mov	a,#_vial_handle_cmd_entry_70000_646
      00AF32 F0               [24] 1492 	movx	@dptr,a
      00AF33 74 0C            [12] 1493 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00AF35 12 B0 A0         [24] 1494 	lcall	_ak820_outline_0072
      00AF38 12 38 60         [24] 1495 	lcall	_ak820_outline_0121
      00AF3B 8B F0            [24] 1496 	mov	b, r3
                                   1497 ;	quantum/vial.c:387: break;
      00AF3D 02 B6 6B         [24] 1498 	ljmp	___memcpy
                                   1499 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00AF40                       1500 00125$:
                                   1501 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00AF40 12 AA B0         [24] 1502 	lcall	_ak820_outline_0014
      00AF43 FD               [12] 1503 	mov	r5,a
                                   1504 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00AF44 74 04            [12] 1505 	mov	a,#0x04
      00AF46 2E               [12] 1506 	add	a, r6
      00AF47 FB               [12] 1507 	mov	r3,a
      00AF48 E4               [12] 1508 	clr	a
      00AF49 3F               [12] 1509 	addc	a, r7
      00AF4A FC               [12] 1510 	mov	r4,a
      00AF4B 90 0D 73         [24] 1511 	mov	dptr,#___memcpy_PARM_2
      00AF4E EB               [12] 1512 	mov	a,r3
      00AF4F F0               [24] 1513 	movx	@dptr,a
      00AF50 EC               [12] 1514 	mov	a,r4
      00AF51 12 B0 A0         [24] 1515 	lcall	_ak820_outline_0072
      00AF54 90 0C 41         [24] 1516 	mov	dptr,#_vial_handle_cmd_entry_70000_647
      00AF57 F5 F0            [12] 1517 	mov	b,a
      00AF59 C0 07            [24] 1518 	push	ar7
      00AF5B C0 06            [24] 1519 	push	ar6
      00AF5D C0 05            [24] 1520 	push	ar5
      00AF5F 12 B6 6B         [24] 1521 	lcall	___memcpy
                                   1522 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00AF62 90 0C 49         [24] 1523 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00AF65 12 38 5A         [24] 1524 	lcall	_ak820_outline_0120
      00AF68 12 33 FC         [24] 1525 	lcall	_ak820_outline_0122
      00AF6B 12 AB 8D         [24] 1526 	lcall	_vial_keycode_firewall
      00AF6E AB 82            [24] 1527 	mov	r3, dpl
      00AF70 AC 83            [24] 1528 	mov	r4, dph
      00AF72 D0 05            [24] 1529 	pop	ar5
      00AF74 90 0C 49         [24] 1530 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00AF77 12 38 2B         [24] 1531 	lcall	_ak820_outline_0075
                                   1532 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00AF7A 90 0A EA         [24] 1533 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00AF7D 74 41            [12] 1534 	mov	a,#_vial_handle_cmd_entry_70000_647
      00AF7F F0               [24] 1535 	movx	@dptr,a
      00AF80 74 0C            [12] 1536 	mov	a,#(_vial_handle_cmd_entry_70000_647 >> 8)
      00AF82 12 38 54         [24] 1537 	lcall	_ak820_outline_0117
      00AF85 8D 82            [24] 1538 	mov	dpl, r5
      00AF87 12 85 78         [24] 1539 	lcall	_dynamic_keymap_set_combo
      00AF8A AC 82            [24] 1540 	mov	r4, dpl
      00AF8C D0 06            [24] 1541 	pop	ar6
      00AF8E D0 07            [24] 1542 	pop	ar7
      00AF90 12 43 20         [24] 1543 	lcall	_ak820_outline_0116
      00AF93 EC               [12] 1544 	mov	a,r4
      00AF94 F0               [24] 1545 	movx	@dptr,a
                                   1546 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00AF95 EC               [12] 1547 	mov	a,r4
      00AF96 70 03            [24] 1548 	jnz	00139$
                                   1549 ;	quantum/vial.c:423: }
                                   1550 ;	quantum/vial.c:424: }
      00AF98 02 35 37         [24] 1551 	ljmp	_ak820_combo_reload
      00AF9B                       1552 00139$:
      00AF9B 22               [24] 1553 	ret
                                   1554 ;------------------------------------------------------------
                                   1555 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1556 ;------------------------------------------------------------
                                   1557 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_649'
                                   1558 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_656'
                                   1559 ;------------------------------------------------------------
                                   1560 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1561 ;	-----------------------------------------
                                   1562 ;	 function vial_keycode_down
                                   1563 ;	-----------------------------------------
      00AF9C                       1564 _vial_keycode_down:
      00AF9C 12 38 43         [24] 1565 	lcall	_ak820_outline_0103
      00AF9F 90 0C 4D         [24] 1566 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00AFA2 12 38 48         [24] 1567 	lcall	_ak820_outline_0104
                                   1568 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00AFA5 90 0C 4D         [24] 1569 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00AFA8 12 37 CB         [24] 1570 	lcall	_ak820_outline_0010
      00AFAB 74 E0            [12] 1571 	mov	a,#0x100 - 0x20
      00AFAD 2D               [12] 1572 	add	a,r5
      00AFAE 50 19            [24] 1573 	jnc	00104$
      00AFB0 C3               [12] 1574 	clr	c
      00AFB1 74 FF            [12] 1575 	mov	a,#0xff
      00AFB3 9C               [12] 1576 	subb	a,r4
      00AFB4 74 4F            [12] 1577 	mov	a,#0x4f
      00AFB6 9D               [12] 1578 	subb	a,r5
      00AFB7 40 10            [24] 1579 	jc	00104$
                                   1580 ;	free result
                                   1581 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00AFB9 90 0C 4D         [24] 1582 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00AFBC EE               [12] 1583 	mov	a,r6
      00AFBD 12 38 65         [24] 1584 	lcall	_ak820_outline_0123
                                   1585 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00AFC0 90 0C 4D         [24] 1586 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00AFC3 E0               [24] 1587 	movx	a,@dptr
      00AFC4 24 FE            [12] 1588 	add	a,#0xff - 0x01
      00AFC6 40 01            [24] 1589 	jc	00104$
                                   1590 ;	free result
      00AFC8 22               [24] 1591 	ret
      00AFC9                       1592 00104$:
                                   1593 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00AFC9 90 0C 4D         [24] 1594 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00AFCC 12 B0 87         [24] 1595 	lcall	_ak820_outline_0022
                                   1596 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00AFCF 40 06            [24] 1597 	jc	00107$
                                   1598 ;	free result
                                   1599 ;	quantum/vial.c:440: register_code16(keycode);
      00AFD1 12 43 20         [24] 1600 	lcall	_ak820_outline_0116
      00AFD4 02 9C 85         [24] 1601 	ljmp	_register_code16
      00AFD7                       1602 00107$:
                                   1603 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00AFD7 90 0C 53         [24] 1604 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0004)
      00AFDA 74 01            [12] 1605 	mov	a,#0x01
      00AFDC F0               [24] 1606 	movx	@dptr,a
      00AFDD 90 0C 50         [24] 1607 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0001)
      00AFE0 74 F0            [12] 1608 	mov	a,#0xf0
      00AFE2 F0               [24] 1609 	movx	@dptr,a
      00AFE3 90 0C 4F         [24] 1610 	mov	dptr,#_vial_keycode_down_dummy_event_30000_656
      00AFE6 F0               [24] 1611 	movx	@dptr,a
      00AFE7 90 0C 54         [24] 1612 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0005)
      00AFEA 74 01            [12] 1613 	mov	a,#0x01
      00AFEC F0               [24] 1614 	movx	@dptr,a
      00AFED 12 48 F5         [24] 1615 	lcall	_timer_read
      00AFF0 12 43 2B         [24] 1616 	lcall	_ak820_outline_0132
      00AFF3 43 06 01         [24] 1617 	orl	ar6,#0x01
      00AFF6 90 0C 51         [24] 1618 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0002)
      00AFF9 12 48 56         [24] 1619 	lcall	_ak820_outline_0058
                                   1620 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00AFFC 90 0C 4F         [24] 1621 	mov	dptr,#_vial_keycode_down_dummy_event_30000_656
                                   1622 ;	quantum/vial.c:448: }
      00AFFF 02 70 0C         [24] 1623 	ljmp	_ak820_action_exec
                                   1624 ;------------------------------------------------------------
                                   1625 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1626 ;------------------------------------------------------------
                                   1627 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_657'
                                   1628 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_664'
                                   1629 ;------------------------------------------------------------
                                   1630 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1631 ;	-----------------------------------------
                                   1632 ;	 function vial_keycode_up
                                   1633 ;	-----------------------------------------
      00B002                       1634 _vial_keycode_up:
      00B002 12 38 43         [24] 1635 	lcall	_ak820_outline_0103
      00B005 90 0C 55         [24] 1636 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B008 12 38 48         [24] 1637 	lcall	_ak820_outline_0104
                                   1638 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B00B 90 0C 55         [24] 1639 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B00E 12 37 CB         [24] 1640 	lcall	_ak820_outline_0010
      00B011 74 E0            [12] 1641 	mov	a,#0x100 - 0x20
      00B013 2D               [12] 1642 	add	a,r5
      00B014 50 19            [24] 1643 	jnc	00104$
      00B016 C3               [12] 1644 	clr	c
      00B017 74 FF            [12] 1645 	mov	a,#0xff
      00B019 9C               [12] 1646 	subb	a,r4
      00B01A 74 4F            [12] 1647 	mov	a,#0x4f
      00B01C 9D               [12] 1648 	subb	a,r5
      00B01D 40 10            [24] 1649 	jc	00104$
                                   1650 ;	free result
                                   1651 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B01F 90 0C 55         [24] 1652 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B022 EE               [12] 1653 	mov	a,r6
      00B023 12 38 65         [24] 1654 	lcall	_ak820_outline_0123
                                   1655 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B026 90 0C 55         [24] 1656 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B029 E0               [24] 1657 	movx	a,@dptr
      00B02A 24 FE            [12] 1658 	add	a,#0xff - 0x01
      00B02C 40 01            [24] 1659 	jc	00104$
                                   1660 ;	free result
      00B02E 22               [24] 1661 	ret
      00B02F                       1662 00104$:
                                   1663 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B02F 90 0C 55         [24] 1664 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B032 12 B0 87         [24] 1665 	lcall	_ak820_outline_0022
                                   1666 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B035 40 06            [24] 1667 	jc	00107$
                                   1668 ;	free result
                                   1669 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B037 12 43 20         [24] 1670 	lcall	_ak820_outline_0116
      00B03A 02 9C CA         [24] 1671 	ljmp	_unregister_code16
      00B03D                       1672 00107$:
                                   1673 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B03D 90 0C 5B         [24] 1674 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0004)
      00B040 74 01            [12] 1675 	mov	a,#0x01
      00B042 F0               [24] 1676 	movx	@dptr,a
      00B043 90 0C 58         [24] 1677 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0001)
      00B046 74 F0            [12] 1678 	mov	a,#0xf0
      00B048 F0               [24] 1679 	movx	@dptr,a
      00B049 90 0C 57         [24] 1680 	mov	dptr,#_vial_keycode_up_dummy_event_30000_664
      00B04C F0               [24] 1681 	movx	@dptr,a
      00B04D 90 0C 5C         [24] 1682 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0005)
      00B050 E4               [12] 1683 	clr	a
      00B051 F0               [24] 1684 	movx	@dptr,a
      00B052 12 48 F5         [24] 1685 	lcall	_timer_read
      00B055 12 43 2B         [24] 1686 	lcall	_ak820_outline_0132
      00B058 43 06 01         [24] 1687 	orl	ar6,#0x01
      00B05B 90 0C 59         [24] 1688 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0002)
      00B05E 12 48 56         [24] 1689 	lcall	_ak820_outline_0058
                                   1690 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B061 90 0C 57         [24] 1691 	mov	dptr,#_vial_keycode_up_dummy_event_30000_664
                                   1692 ;	quantum/vial.c:470: }
      00B064 02 70 0C         [24] 1693 	ljmp	_ak820_action_exec
                                   1694 ;------------------------------------------------------------
                                   1695 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1696 ;------------------------------------------------------------
                                   1697 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_665'
                                   1698 ;i             Allocated with name '_vial_keycode_tap_i_30000_668'
                                   1699 ;------------------------------------------------------------
                                   1700 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1701 ;	-----------------------------------------
                                   1702 ;	 function vial_keycode_tap
                                   1703 ;	-----------------------------------------
      00B067                       1704 _vial_keycode_tap:
      00B067 12 38 43         [24] 1705 	lcall	_ak820_outline_0103
      00B06A 90 0C 5D         [24] 1706 	mov	dptr,#_vial_keycode_tap_keycode_10000_665
      00B06D 12 38 48         [24] 1707 	lcall	_ak820_outline_0104
                                   1708 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B070 90 0C 5D         [24] 1709 	mov	dptr,#_vial_keycode_tap_keycode_10000_665
      00B073 12 37 A0         [24] 1710 	lcall	_ak820_outline_0004
      00B076 C0 07            [24] 1711 	push	ar7
      00B078 C0 06            [24] 1712 	push	ar6
      00B07A 12 AF 9C         [24] 1713 	lcall	_vial_keycode_down
      00B07D D0 06            [24] 1714 	pop	ar6
      00B07F D0 07            [24] 1715 	pop	ar7
                                   1716 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B081 12 43 20         [24] 1717 	lcall	_ak820_outline_0116
                                   1718 ;	quantum/vial.c:476: }
      00B084 02 B0 02         [24] 1719 	ljmp	_vial_keycode_up
                                   1720 ;------------------------------------------------------------
                                   1721 ;Allocation info for local variables in function 'process_record_vial'
                                   1722 ;------------------------------------------------------------
                                   1723 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1724 ;keycode       Allocated with name '_process_record_vial_keycode_10000_670'
                                   1725 ;------------------------------------------------------------
                                   1726 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1727 ;	-----------------------------------------
                                   1728 	.area CSEG    (CODE)
                                   1729 	.area CONST   (CODE)
                                   1730 	.area CONST   (CODE)
      00BBE9                       1731 _keyboard_definition:
      00BBE9 FD                    1732 	.db #0xfd	; 253
      00BBEA 37                    1733 	.db #0x37	; 55	'7'
      00BBEB 7A                    1734 	.db #0x7a	; 122	'z'
      00BBEC 58                    1735 	.db #0x58	; 88	'X'
      00BBED 5A                    1736 	.db #0x5a	; 90	'Z'
      00BBEE 00                    1737 	.db #0x00	; 0
      00BBEF 00                    1738 	.db #0x00	; 0
      00BBF0 04                    1739 	.db #0x04	; 4
      00BBF1 E6                    1740 	.db #0xe6	; 230
      00BBF2 D6                    1741 	.db #0xd6	; 214
      00BBF3 B4                    1742 	.db #0xb4	; 180
      00BBF4 46                    1743 	.db #0x46	; 70	'F'
      00BBF5 02                    1744 	.db #0x02	; 2
      00BBF6 00                    1745 	.db #0x00	; 0
      00BBF7 21                    1746 	.db #0x21	; 33
      00BBF8 01                    1747 	.db #0x01	; 1
      00BBF9 00                    1748 	.db #0x00	; 0
      00BBFA 00                    1749 	.db #0x00	; 0
      00BBFB 00                    1750 	.db #0x00	; 0
      00BBFC 00                    1751 	.db #0x00	; 0
      00BBFD 37                    1752 	.db #0x37	; 55	'7'
      00BBFE 27                    1753 	.db #0x27	; 39
      00BBFF 97                    1754 	.db #0x97	; 151
      00BC00 D6                    1755 	.db #0xd6	; 214
      00BC01 E0                    1756 	.db #0xe0	; 224
      00BC02 03                    1757 	.db #0x03	; 3
      00BC03 CB                    1758 	.db #0xcb	; 203
      00BC04 01                    1759 	.db #0x01	; 1
      00BC05 3C                    1760 	.db #0x3c	; 60
      00BC06 00                    1761 	.db #0x00	; 0
      00BC07 00                    1762 	.db #0x00	; 0
      00BC08 3D                    1763 	.db #0x3d	; 61
      00BC09 88                    1764 	.db #0x88	; 136
      00BC0A CD                    1765 	.db #0xcd	; 205
      00BC0B A5                    1766 	.db #0xa5	; 165
      00BC0C AA                    1767 	.db #0xaa	; 170
      00BC0D E5                    1768 	.db #0xe5	; 229
      00BC0E A8                    1769 	.db #0xa8	; 168
      00BC0F 76                    1770 	.db #0x76	; 118	'v'
      00BC10 F6                    1771 	.db #0xf6	; 246
      00BC11 43                    1772 	.db #0x43	; 67	'C'
      00BC12 0E                    1773 	.db #0x0e	; 14
      00BC13 D2                    1774 	.db #0xd2	; 210
      00BC14 90                    1775 	.db #0x90	; 144
      00BC15 7D                    1776 	.db #0x7d	; 125
      00BC16 94                    1777 	.db #0x94	; 148
      00BC17 79                    1778 	.db #0x79	; 121	'y'
      00BC18 78                    1779 	.db #0x78	; 120	'x'
      00BC19 EF                    1780 	.db #0xef	; 239
      00BC1A 49                    1781 	.db #0x49	; 73	'I'
      00BC1B 3E                    1782 	.db #0x3e	; 62
      00BC1C EF                    1783 	.db #0xef	; 239
      00BC1D FD                    1784 	.db #0xfd	; 253
      00BC1E 8F                    1785 	.db #0x8f	; 143
      00BC1F EF                    1786 	.db #0xef	; 239
      00BC20 00                    1787 	.db #0x00	; 0
      00BC21 C6                    1788 	.db #0xc6	; 198
      00BC22 D1                    1789 	.db #0xd1	; 209
      00BC23 DB                    1790 	.db #0xdb	; 219
      00BC24 FB                    1791 	.db #0xfb	; 251
      00BC25 EB                    1792 	.db #0xeb	; 235
      00BC26 DE                    1793 	.db #0xde	; 222
      00BC27 66                    1794 	.db #0x66	; 102	'f'
      00BC28 63                    1795 	.db #0x63	; 99	'c'
      00BC29 0C                    1796 	.db #0x0c	; 12
      00BC2A 92                    1797 	.db #0x92	; 146
      00BC2B 7B                    1798 	.db #0x7b	; 123
      00BC2C F9                    1799 	.db #0xf9	; 249
      00BC2D D4                    1800 	.db #0xd4	; 212
      00BC2E 7A                    1801 	.db #0x7a	; 122	'z'
      00BC2F 4F                    1802 	.db #0x4f	; 79	'O'
      00BC30 83                    1803 	.db #0x83	; 131
      00BC31 4B                    1804 	.db #0x4b	; 75	'K'
      00BC32 86                    1805 	.db #0x86	; 134
      00BC33 0E                    1806 	.db #0x0e	; 14
      00BC34 6A                    1807 	.db #0x6a	; 106	'j'
      00BC35 F2                    1808 	.db #0xf2	; 242
      00BC36 22                    1809 	.db #0x22	; 34
      00BC37 22                    1810 	.db #0x22	; 34
      00BC38 0B                    1811 	.db #0x0b	; 11
      00BC39 03                    1812 	.db #0x03	; 3
      00BC3A BA                    1813 	.db #0xba	; 186
      00BC3B 67                    1814 	.db #0x67	; 103	'g'
      00BC3C 9B                    1815 	.db #0x9b	; 155
      00BC3D 7A                    1816 	.db #0x7a	; 122	'z'
      00BC3E E1                    1817 	.db #0xe1	; 225
      00BC3F BC                    1818 	.db #0xbc	; 188
      00BC40 37                    1819 	.db #0x37	; 55	'7'
      00BC41 26                    1820 	.db #0x26	; 38
      00BC42 46                    1821 	.db #0x46	; 70	'F'
      00BC43 78                    1822 	.db #0x78	; 120	'x'
      00BC44 05                    1823 	.db #0x05	; 5
      00BC45 0D                    1824 	.db #0x0d	; 13
      00BC46 95                    1825 	.db #0x95	; 149
      00BC47 02                    1826 	.db #0x02	; 2
      00BC48 E4                    1827 	.db #0xe4	; 228
      00BC49 18                    1828 	.db #0x18	; 24
      00BC4A CA                    1829 	.db #0xca	; 202
      00BC4B 33                    1830 	.db #0x33	; 51	'3'
      00BC4C EA                    1831 	.db #0xea	; 234
      00BC4D 24                    1832 	.db #0x24	; 36
      00BC4E C8                    1833 	.db #0xc8	; 200
      00BC4F 81                    1834 	.db #0x81	; 129
      00BC50 4E                    1835 	.db #0x4e	; 78	'N'
      00BC51 47                    1836 	.db #0x47	; 71	'G'
      00BC52 A8                    1837 	.db #0xa8	; 168
      00BC53 44                    1838 	.db #0x44	; 68	'D'
      00BC54 DD                    1839 	.db #0xdd	; 221
      00BC55 91                    1840 	.db #0x91	; 145
      00BC56 6D                    1841 	.db #0x6d	; 109	'm'
      00BC57 69                    1842 	.db #0x69	; 105	'i'
      00BC58 DB                    1843 	.db #0xdb	; 219
      00BC59 4F                    1844 	.db #0x4f	; 79	'O'
      00BC5A 3A                    1845 	.db #0x3a	; 58
      00BC5B 43                    1846 	.db #0x43	; 67	'C'
      00BC5C 9D                    1847 	.db #0x9d	; 157
      00BC5D 26                    1848 	.db #0x26	; 38
      00BC5E 49                    1849 	.db #0x49	; 73	'I'
      00BC5F 4C                    1850 	.db #0x4c	; 76	'L'
      00BC60 EF                    1851 	.db #0xef	; 239
      00BC61 2B                    1852 	.db #0x2b	; 43
      00BC62 D8                    1853 	.db #0xd8	; 216
      00BC63 55                    1854 	.db #0x55	; 85	'U'
      00BC64 95                    1855 	.db #0x95	; 149
      00BC65 70                    1856 	.db #0x70	; 112	'p'
      00BC66 B1                    1857 	.db #0xb1	; 177
      00BC67 CC                    1858 	.db #0xcc	; 204
      00BC68 CF                    1859 	.db #0xcf	; 207
      00BC69 13                    1860 	.db #0x13	; 19
      00BC6A 32                    1861 	.db #0x32	; 50	'2'
      00BC6B 6A                    1862 	.db #0x6a	; 106	'j'
      00BC6C A1                    1863 	.db #0xa1	; 161
      00BC6D FF                    1864 	.db #0xff	; 255
      00BC6E 99                    1865 	.db #0x99	; 153
      00BC6F 61                    1866 	.db #0x61	; 97	'a'
      00BC70 95                    1867 	.db #0x95	; 149
      00BC71 B1                    1868 	.db #0xb1	; 177
      00BC72 89                    1869 	.db #0x89	; 137
      00BC73 9B                    1870 	.db #0x9b	; 155
      00BC74 11                    1871 	.db #0x11	; 17
      00BC75 D9                    1872 	.db #0xd9	; 217
      00BC76 35                    1873 	.db #0x35	; 53	'5'
      00BC77 78                    1874 	.db #0x78	; 120	'x'
      00BC78 ED                    1875 	.db #0xed	; 237
      00BC79 CD                    1876 	.db #0xcd	; 205
      00BC7A 94                    1877 	.db #0x94	; 148
      00BC7B 6E                    1878 	.db #0x6e	; 110	'n'
      00BC7C 60                    1879 	.db #0x60	; 96
      00BC7D 8E                    1880 	.db #0x8e	; 142
      00BC7E 63                    1881 	.db #0x63	; 99	'c'
      00BC7F 8B                    1882 	.db #0x8b	; 139
      00BC80 FF                    1883 	.db #0xff	; 255
      00BC81 4E                    1884 	.db #0x4e	; 78	'N'
      00BC82 20                    1885 	.db #0x20	; 32
      00BC83 7A                    1886 	.db #0x7a	; 122	'z'
      00BC84 B5                    1887 	.db #0xb5	; 181
      00BC85 87                    1888 	.db #0x87	; 135
      00BC86 C2                    1889 	.db #0xc2	; 194
      00BC87 35                    1890 	.db #0x35	; 53	'5'
      00BC88 A4                    1891 	.db #0xa4	; 164
      00BC89 6D                    1892 	.db #0x6d	; 109	'm'
      00BC8A 18                    1893 	.db #0x18	; 24
      00BC8B C1                    1894 	.db #0xc1	; 193
      00BC8C A3                    1895 	.db #0xa3	; 163
      00BC8D DB                    1896 	.db #0xdb	; 219
      00BC8E 53                    1897 	.db #0x53	; 83	'S'
      00BC8F 1D                    1898 	.db #0x1d	; 29
      00BC90 EC                    1899 	.db #0xec	; 236
      00BC91 F0                    1900 	.db #0xf0	; 240
      00BC92 BF                    1901 	.db #0xbf	; 191
      00BC93 4A                    1902 	.db #0x4a	; 74	'J'
      00BC94 4C                    1903 	.db #0x4c	; 76	'L'
      00BC95 4A                    1904 	.db #0x4a	; 74	'J'
      00BC96 C4                    1905 	.db #0xc4	; 196
      00BC97 AA                    1906 	.db #0xaa	; 170
      00BC98 37                    1907 	.db #0x37	; 55	'7'
      00BC99 19                    1908 	.db #0x19	; 25
      00BC9A 34                    1909 	.db #0x34	; 52	'4'
      00BC9B 3F                    1910 	.db #0x3f	; 63
      00BC9C A1                    1911 	.db #0xa1	; 161
      00BC9D D3                    1912 	.db #0xd3	; 211
      00BC9E 1A                    1913 	.db #0x1a	; 26
      00BC9F 5C                    1914 	.db #0x5c	; 92
      00BCA0 03                    1915 	.db #0x03	; 3
      00BCA1 4D                    1916 	.db #0x4d	; 77	'M'
      00BCA2 BC                    1917 	.db #0xbc	; 188
      00BCA3 10                    1918 	.db #0x10	; 16
      00BCA4 2E                    1919 	.db #0x2e	; 46
      00BCA5 80                    1920 	.db #0x80	; 128
      00BCA6 F7                    1921 	.db #0xf7	; 247
      00BCA7 D6                    1922 	.db #0xd6	; 214
      00BCA8 82                    1923 	.db #0x82	; 130
      00BCA9 24                    1924 	.db #0x24	; 36
      00BCAA 4C                    1925 	.db #0x4c	; 76	'L'
      00BCAB 87                    1926 	.db #0x87	; 135
      00BCAC B9                    1927 	.db #0xb9	; 185
      00BCAD F8                    1928 	.db #0xf8	; 248
      00BCAE BE                    1929 	.db #0xbe	; 190
      00BCAF 67                    1930 	.db #0x67	; 103	'g'
      00BCB0 96                    1931 	.db #0x96	; 150
      00BCB1 89                    1932 	.db #0x89	; 137
      00BCB2 30                    1933 	.db #0x30	; 48	'0'
      00BCB3 C8                    1934 	.db #0xc8	; 200
      00BCB4 8D                    1935 	.db #0x8d	; 141
      00BCB5 2C                    1936 	.db #0x2c	; 44
      00BCB6 F5                    1937 	.db #0xf5	; 245
      00BCB7 06                    1938 	.db #0x06	; 6
      00BCB8 05                    1939 	.db #0x05	; 5
      00BCB9 7C                    1940 	.db #0x7c	; 124
      00BCBA 48                    1941 	.db #0x48	; 72	'H'
      00BCBB 1B                    1942 	.db #0x1b	; 27
      00BCBC 76                    1943 	.db #0x76	; 118	'v'
      00BCBD AA                    1944 	.db #0xaa	; 170
      00BCBE 3D                    1945 	.db #0x3d	; 61
      00BCBF 28                    1946 	.db #0x28	; 40
      00BCC0 FC                    1947 	.db #0xfc	; 252
      00BCC1 80                    1948 	.db #0x80	; 128
      00BCC2 75                    1949 	.db #0x75	; 117	'u'
      00BCC3 EB                    1950 	.db #0xeb	; 235
      00BCC4 78                    1951 	.db #0x78	; 120	'x'
      00BCC5 D0                    1952 	.db #0xd0	; 208
      00BCC6 8A                    1953 	.db #0x8a	; 138
      00BCC7 8F                    1954 	.db #0x8f	; 143
      00BCC8 27                    1955 	.db #0x27	; 39
      00BCC9 F7                    1956 	.db #0xf7	; 247
      00BCCA F2                    1957 	.db #0xf2	; 242
      00BCCB EB                    1958 	.db #0xeb	; 235
      00BCCC 58                    1959 	.db #0x58	; 88	'X'
      00BCCD 37                    1960 	.db #0x37	; 55	'7'
      00BCCE 3C                    1961 	.db #0x3c	; 60
      00BCCF 2B                    1962 	.db #0x2b	; 43
      00BCD0 6F                    1963 	.db #0x6f	; 111	'o'
      00BCD1 0E                    1964 	.db #0x0e	; 14
      00BCD2 C7                    1965 	.db #0xc7	; 199
      00BCD3 E2                    1966 	.db #0xe2	; 226
      00BCD4 A0                    1967 	.db #0xa0	; 160
      00BCD5 97                    1968 	.db #0x97	; 151
      00BCD6 EE                    1969 	.db #0xee	; 238
      00BCD7 FD                    1970 	.db #0xfd	; 253
      00BCD8 9F                    1971 	.db #0x9f	; 159
      00BCD9 45                    1972 	.db #0x45	; 69	'E'
      00BCDA 17                    1973 	.db #0x17	; 23
      00BCDB 94                    1974 	.db #0x94	; 148
      00BCDC E6                    1975 	.db #0xe6	; 230
      00BCDD E7                    1976 	.db #0xe7	; 231
      00BCDE FA                    1977 	.db #0xfa	; 250
      00BCDF 4C                    1978 	.db #0x4c	; 76	'L'
      00BCE0 7A                    1979 	.db #0x7a	; 122	'z'
      00BCE1 D6                    1980 	.db #0xd6	; 214
      00BCE2 7A                    1981 	.db #0x7a	; 122	'z'
      00BCE3 7B                    1982 	.db #0x7b	; 123
      00BCE4 ED                    1983 	.db #0xed	; 237
      00BCE5 10                    1984 	.db #0x10	; 16
      00BCE6 C5                    1985 	.db #0xc5	; 197
      00BCE7 BC                    1986 	.db #0xbc	; 188
      00BCE8 E3                    1987 	.db #0xe3	; 227
      00BCE9 A9                    1988 	.db #0xa9	; 169
      00BCEA 1F                    1989 	.db #0x1f	; 31
      00BCEB CF                    1990 	.db #0xcf	; 207
      00BCEC C4                    1991 	.db #0xc4	; 196
      00BCED 9D                    1992 	.db #0x9d	; 157
      00BCEE DC                    1993 	.db #0xdc	; 220
      00BCEF 45                    1994 	.db #0x45	; 69	'E'
      00BCF0 2A                    1995 	.db #0x2a	; 42
      00BCF1 69                    1996 	.db #0x69	; 105	'i'
      00BCF2 57                    1997 	.db #0x57	; 87	'W'
      00BCF3 8F                    1998 	.db #0x8f	; 143
      00BCF4 EC                    1999 	.db #0xec	; 236
      00BCF5 85                    2000 	.db #0x85	; 133
      00BCF6 6C                    2001 	.db #0x6c	; 108	'l'
      00BCF7 43                    2002 	.db #0x43	; 67	'C'
      00BCF8 1C                    2003 	.db #0x1c	; 28
      00BCF9 BA                    2004 	.db #0xba	; 186
      00BCFA 89                    2005 	.db #0x89	; 137
      00BCFB 68                    2006 	.db #0x68	; 104	'h'
      00BCFC 4A                    2007 	.db #0x4a	; 74	'J'
      00BCFD 1C                    2008 	.db #0x1c	; 28
      00BCFE 91                    2009 	.db #0x91	; 145
      00BCFF 3F                    2010 	.db #0x3f	; 63
      00BD00 D1                    2011 	.db #0xd1	; 209
      00BD01 B3                    2012 	.db #0xb3	; 179
      00BD02 96                    2013 	.db #0x96	; 150
      00BD03 1D                    2014 	.db #0x1d	; 29
      00BD04 7C                    2015 	.db #0x7c	; 124
      00BD05 14                    2016 	.db #0x14	; 20
      00BD06 77                    2017 	.db #0x77	; 119	'w'
      00BD07 9C                    2018 	.db #0x9c	; 156
      00BD08 74                    2019 	.db #0x74	; 116	't'
      00BD09 36                    2020 	.db #0x36	; 54	'6'
      00BD0A FF                    2021 	.db #0xff	; 255
      00BD0B 2C                    2022 	.db #0x2c	; 44
      00BD0C 66                    2023 	.db #0x66	; 102	'f'
      00BD0D AF                    2024 	.db #0xaf	; 175
      00BD0E 0F                    2025 	.db #0x0f	; 15
      00BD0F 3C                    2026 	.db #0x3c	; 60
      00BD10 A2                    2027 	.db #0xa2	; 162
      00BD11 23                    2028 	.db #0x23	; 35
      00BD12 85                    2029 	.db #0x85	; 133
      00BD13 05                    2030 	.db #0x05	; 5
      00BD14 87                    2031 	.db #0x87	; 135
      00BD15 DA                    2032 	.db #0xda	; 218
      00BD16 61                    2033 	.db #0x61	; 97	'a'
      00BD17 5E                    2034 	.db #0x5e	; 94
      00BD18 42                    2035 	.db #0x42	; 66	'B'
      00BD19 54                    2036 	.db #0x54	; 84	'T'
      00BD1A 60                    2037 	.db #0x60	; 96
      00BD1B 23                    2038 	.db #0x23	; 35
      00BD1C CA                    2039 	.db #0xca	; 202
      00BD1D BC                    2040 	.db #0xbc	; 188
      00BD1E B3                    2041 	.db #0xb3	; 179
      00BD1F 18                    2042 	.db #0x18	; 24
      00BD20 1D                    2043 	.db #0x1d	; 29
      00BD21 F8                    2044 	.db #0xf8	; 248
      00BD22 0A                    2045 	.db #0x0a	; 10
      00BD23 55                    2046 	.db #0x55	; 85	'U'
      00BD24 CD                    2047 	.db #0xcd	; 205
      00BD25 A3                    2048 	.db #0xa3	; 163
      00BD26 DE                    2049 	.db #0xde	; 222
      00BD27 FF                    2050 	.db #0xff	; 255
      00BD28 B2                    2051 	.db #0xb2	; 178
      00BD29 2A                    2052 	.db #0x2a	; 42
      00BD2A 35                    2053 	.db #0x35	; 53	'5'
      00BD2B 00                    2054 	.db #0x00	; 0
      00BD2C D6                    2055 	.db #0xd6	; 214
      00BD2D 7B                    2056 	.db #0x7b	; 123
      00BD2E E8                    2057 	.db #0xe8	; 232
      00BD2F F2                    2058 	.db #0xf2	; 242
      00BD30 1A                    2059 	.db #0x1a	; 26
      00BD31 BC                    2060 	.db #0xbc	; 188
      00BD32 F5                    2061 	.db #0xf5	; 245
      00BD33 7E                    2062 	.db #0x7e	; 126
      00BD34 48                    2063 	.db #0x48	; 72	'H'
      00BD35 72                    2064 	.db #0x72	; 114	'r'
      00BD36 E0                    2065 	.db #0xe0	; 224
      00BD37 E4                    2066 	.db #0xe4	; 228
      00BD38 E0                    2067 	.db #0xe0	; 224
      00BD39 27                    2068 	.db #0x27	; 39
      00BD3A 87                    2069 	.db #0x87	; 135
      00BD3B 9A                    2070 	.db #0x9a	; 154
      00BD3C 51                    2071 	.db #0x51	; 81	'Q'
      00BD3D D4                    2072 	.db #0xd4	; 212
      00BD3E DD                    2073 	.db #0xdd	; 221
      00BD3F C3                    2074 	.db #0xc3	; 195
      00BD40 AA                    2075 	.db #0xaa	; 170
      00BD41 49                    2076 	.db #0x49	; 73	'I'
      00BD42 5A                    2077 	.db #0x5a	; 90	'Z'
      00BD43 2A                    2078 	.db #0x2a	; 42
      00BD44 00                    2079 	.db #0x00	; 0
      00BD45 A0                    2080 	.db #0xa0	; 160
      00BD46 8C                    2081 	.db #0x8c	; 140
      00BD47 FF                    2082 	.db #0xff	; 255
      00BD48 74                    2083 	.db #0x74	; 116	't'
      00BD49 BF                    2084 	.db #0xbf	; 191
      00BD4A EC                    2085 	.db #0xec	; 236
      00BD4B 1D                    2086 	.db #0x1d	; 29
      00BD4C F1                    2087 	.db #0xf1	; 241
      00BD4D 00                    2088 	.db #0x00	; 0
      00BD4E 01                    2089 	.db #0x01	; 1
      00BD4F D8                    2090 	.db #0xd8	; 216
      00BD50 02                    2091 	.db #0x02	; 2
      00BD51 CC                    2092 	.db #0xcc	; 204
      00BD52 07                    2093 	.db #0x07	; 7
      00BD53 00                    2094 	.db #0x00	; 0
      00BD54 00                    2095 	.db #0x00	; 0
      00BD55 C4                    2096 	.db #0xc4	; 196
      00BD56 5E                    2097 	.db #0x5e	; 94
      00BD57 2C                    2098 	.db #0x2c	; 44
      00BD58 7E                    2099 	.db #0x7e	; 126
      00BD59 B1                    2100 	.db #0xb1	; 177
      00BD5A C4                    2101 	.db #0xc4	; 196
      00BD5B 67                    2102 	.db #0x67	; 103	'g'
      00BD5C FB                    2103 	.db #0xfb	; 251
      00BD5D 02                    2104 	.db #0x02	; 2
      00BD5E 00                    2105 	.db #0x00	; 0
      00BD5F 00                    2106 	.db #0x00	; 0
      00BD60 00                    2107 	.db #0x00	; 0
      00BD61 00                    2108 	.db #0x00	; 0
      00BD62 04                    2109 	.db #0x04	; 4
      00BD63 59                    2110 	.db #0x59	; 89	'Y'
      00BD64 5A                    2111 	.db #0x5a	; 90	'Z'
                                   2112 	.area CSEG    (CODE)
                                   2113 	.area CONST   (CODE)
      00BD65                       2114 _vial_handle_cmd_keyboard_uid_40000_623:
      00BD65 04                    2115 	.db #0x04	; 4
      00BD66 70                    2116 	.db #0x70	; 112	'p'
      00BD67 FF                    2117 	.db #0xff	; 255
      00BD68 90                    2118 	.db #0x90	; 144
      00BD69 01                    2119 	.db #0x01	; 1
      00BD6A B9                    2120 	.db #0xb9	; 185
      00BD6B 15                    2121 	.db #0x15	; 21
      00BD6C D3                    2122 	.db #0xd3	; 211
                                   2123 	.area CSEG    (CODE)
                                   2124 	.area XINIT   (CODE)
      00BF9B                       2125 __xinit__vial_unlocked:
      00BF9B 00                    2126 	.db #0x00	;  0
      00BF9C                       2127 __xinit__vial_unlock_in_progress:
      00BF9C 00                    2128 	.db #0x00	;  0
      00BF9D                       2129 __xinit__vial_unlock_counter:
      00BF9D 00                    2130 	.db #0x00	; 0
      00BF9E                       2131 __xinit__vial_unlock_combo_rows:
      00BF9E 00                    2132 	.db #0x00	; 0
      00BF9F 00                    2133 	.db #0x00	; 0
      00BFA0                       2134 __xinit__vial_unlock_combo_cols:
      00BFA0 00                    2135 	.db #0x00	; 0
      00BFA1 05                    2136 	.db #0x05	; 5
                                   2137 	.area CABS    (ABS,CODE)
                                   2138 
                                   2139 ; Experimental exact instruction outlining.
                                   2140 	.globl _ak820_outline_0004
                                   2141 	.globl _ak820_outline_0007
                                   2142 	.globl _ak820_outline_0009
                                   2143 	.globl _ak820_outline_0010
                                   2144 	.globl _ak820_outline_0011
                                   2145 	.globl _ak820_outline_0014
                                   2146 	.globl _ak820_outline_0015
                                   2147 	.globl _ak820_outline_0016
                                   2148 	.globl _ak820_outline_0019
                                   2149 	.globl _ak820_outline_0022
                                   2150 	.globl _ak820_outline_0029
                                   2151 	.globl _ak820_outline_0030
                                   2152 	.globl _ak820_outline_0033
                                   2153 	.globl _ak820_outline_0036
                                   2154 	.globl _ak820_outline_0045
                                   2155 	.globl _ak820_outline_0050
                                   2156 	.globl _ak820_outline_0053
                                   2157 	.globl _ak820_outline_0055
                                   2158 	.globl _ak820_outline_0058
                                   2159 	.globl _ak820_outline_0060
                                   2160 	.globl _ak820_outline_0072
                                   2161 	.globl _ak820_outline_0075
                                   2162 	.globl _ak820_outline_0095
                                   2163 	.globl _ak820_outline_0103
                                   2164 	.globl _ak820_outline_0104
                                   2165 	.globl _ak820_outline_0116
                                   2166 	.globl _ak820_outline_0117
                                   2167 	.globl _ak820_outline_0120
                                   2168 	.globl _ak820_outline_0121
                                   2169 	.globl _ak820_outline_0122
                                   2170 	.globl _ak820_outline_0123
                                   2171 	.globl _ak820_outline_0125
                                   2172 	.globl _ak820_outline_0126
                                   2173 	.globl _ak820_outline_0132
                                   2174 	.globl _ak820_outline_0136
                                   2175 	.globl _ak820_outline_0140
                                   2176 	.globl _ak820_outline_0152
                                   2177 	.globl _ak820_outline_0178
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0022
      00B087                       2181 _ak820_outline_0022:
      00B087 E0               [24] 2182 	movx	a,@dptr
      00B088 FE               [12] 2183 	mov	r6,a
      00B089 A3               [24] 2184 	inc	dptr
      00B08A E0               [24] 2185 	movx	a,@dptr
      00B08B FF               [12] 2186 	mov	r7,a
      00B08C 90 0C 4B         [24] 2187 	mov	dptr,#_g_vial_magic_keycode_override
      00B08F EE               [12] 2188 	mov	a,r6
      00B090 F0               [24] 2189 	movx	@dptr,a
      00B091 EF               [12] 2190 	mov	a,r7
      00B092 A3               [24] 2191 	inc	dptr
      00B093 F0               [24] 2192 	movx	@dptr,a
      00B094 8E 04            [24] 2193 	mov	ar4,r6
      00B096 8F 05            [24] 2194 	mov	ar5,r7
      00B098 C3               [12] 2195 	clr	c
      00B099 74 FF            [12] 2196 	mov	a,#0xff
      00B09B 9C               [12] 2197 	subb	a,r4
      00B09C 74 1F            [12] 2198 	mov	a,#0x1f
      00B09E 9D               [12] 2199 	subb	a,r5
      00B09F 22               [24] 2200 	ret
                                   2201 
                                   2202 	.area CSEG (CODE)
                                   2203 ; function ak820_outline_0072
      00B0A0                       2204 _ak820_outline_0072:
      00B0A0 A3               [24] 2205 	inc	dptr
      00B0A1 F0               [24] 2206 	movx	@dptr,a
      00B0A2 E4               [12] 2207 	clr	a
      00B0A3 A3               [24] 2208 	inc	dptr
      00B0A4 F0               [24] 2209 	movx	@dptr,a
      00B0A5 90 0D 76         [24] 2210 	mov	dptr,#___memcpy_PARM_3
      00B0A8 74 0A            [12] 2211 	mov	a,#0x0a
      00B0AA F0               [24] 2212 	movx	@dptr,a
      00B0AB E4               [12] 2213 	clr	a
      00B0AC A3               [24] 2214 	inc	dptr
      00B0AD F0               [24] 2215 	movx	@dptr,a
      00B0AE 22               [24] 2216 	ret
                                   2217 
                                   2218 	.area CSEG (CODE)
                                   2219 ; function ak820_outline_0125
      00B0AF                       2220 _ak820_outline_0125:
      00B0AF 24 F8            [12] 2221 	add	a,#_vial_unlock_combo_cols
      00B0B1 F5 82            [12] 2222 	mov	dpl,a
      00B0B3 E4               [12] 2223 	clr	a
      00B0B4 34 0D            [12] 2224 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B0B6 F5 83            [12] 2225 	mov	dph,a
      00B0B8 E0               [24] 2226 	movx	a,@dptr
      00B0B9 22               [24] 2227 	ret
                                   2228 
                                   2229 	.area CSEG (CODE)
                                   2230 ; function ak820_outline_0126
      00B0BA                       2231 _ak820_outline_0126:
      00B0BA 24 F6            [12] 2232 	add	a,#_vial_unlock_combo_rows
      00B0BC F5 82            [12] 2233 	mov	dpl,a
      00B0BE E4               [12] 2234 	clr	a
      00B0BF 34 0D            [12] 2235 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B0C1 F5 83            [12] 2236 	mov	dph,a
      00B0C3 E0               [24] 2237 	movx	a,@dptr
      00B0C4 22               [24] 2238 	ret
