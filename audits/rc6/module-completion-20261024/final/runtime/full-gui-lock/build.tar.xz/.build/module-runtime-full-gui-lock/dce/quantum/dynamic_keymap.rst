                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000024                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000024                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000AD1                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AD1                        628 	.ds 1
      000AD2                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AD2                        630 	.ds 1
      000AD3                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_365:
      000AD3                        632 	.ds 1
      000AD4                        633 _dynamic_keymap_get_keycode_PARM_2:
      000AD4                        634 	.ds 1
      000AD5                        635 _dynamic_keymap_get_keycode_PARM_3:
      000AD5                        636 	.ds 1
      000AD6                        637 _dynamic_keymap_get_keycode_layer_10000_367:
      000AD6                        638 	.ds 1
      000AD7                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AD7                        640 	.ds 1
      000AD8                        641 _dynamic_keymap_set_keycode_PARM_3:
      000AD8                        642 	.ds 1
      000AD9                        643 _dynamic_keymap_set_keycode_PARM_4:
      000AD9                        644 	.ds 2
      000ADB                        645 _dynamic_keymap_set_keycode_layer_10000_371:
      000ADB                        646 	.ds 1
      000ADC                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000ADC                        648 	.ds 1
      000ADD                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_375:
      000ADD                        650 	.ds 1
      000ADE                        651 _dynamic_keymap_get_encoder_PARM_2:
      000ADE                        652 	.ds 1
      000ADF                        653 _dynamic_keymap_get_encoder_PARM_3:
      000ADF                        654 	.ds 1
      000AE0                        655 _dynamic_keymap_get_encoder_layer_10000_377:
      000AE0                        656 	.ds 1
      000AE1                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AE1                        658 	.ds 1
      000AE2                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AE2                        660 	.ds 1
      000AE3                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AE3                        662 	.ds 2
      000AE5                        663 _dynamic_keymap_set_encoder_layer_10000_381:
      000AE5                        664 	.ds 1
      000AE6                        665 _dynamic_keymap_get_combo_PARM_2:
      000AE6                        666 	.ds 3
      000AE9                        667 _dynamic_keymap_get_combo_index_10000_385:
      000AE9                        668 	.ds 1
      000AEA                        669 _dynamic_keymap_set_combo_PARM_2:
      000AEA                        670 	.ds 3
      000AED                        671 _dynamic_keymap_set_combo_index_10000_391:
      000AED                        672 	.ds 1
      000AEE                        673 _dynamic_keymap_set_combo_stored_10002_396:
      000AEE                        674 	.ds 10
      000AF8                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_399:
      000AF8                        676 	.ds 1
      000AF9                        677 _dynamic_keymap_reset_combo_10001_408:
      000AF9                        678 	.ds 10
      000B03                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B03                        680 	.ds 2
      000B05                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B05                        682 	.ds 2
      000B07                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B07                        684 	.ds 2
      000B09                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B09                        686 	.ds 3
      000B0C                        687 _ak820_dynamic_read_buffer_base_10000_410:
      000B0C                        688 	.ds 2
      000B0E                        689 _ak820_dynamic_read_buffer_available_10000_411:
      000B0E                        690 	.ds 1
      000B0F                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B0F                        692 	.ds 2
      000B11                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B11                        694 	.ds 3
      000B14                        695 _dynamic_keymap_get_buffer_offset_10000_417:
      000B14                        696 	.ds 2
      000B16                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B16                        698 	.ds 2
      000B18                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B18                        700 	.ds 3
      000B1B                        701 _dynamic_keymap_set_buffer_offset_10000_419:
      000B1B                        702 	.ds 2
      000B1D                        703 _dynamic_keymap_set_buffer_chk_offset_30001_426:
      000B1D                        704 	.ds 1
      000B1E                        705 _dynamic_keymap_set_buffer_chk_sz_30001_426:
      000B1E                        706 	.ds 1
      000B1F                        707 _dynamic_keymap_set_buffer_i_40001_433:
      000B1F                        708 	.ds 1
      000B20                        709 _keycode_at_keymap_location_PARM_2:
      000B20                        710 	.ds 1
      000B21                        711 _keycode_at_keymap_location_PARM_3:
      000B21                        712 	.ds 1
      000B22                        713 _keycode_at_keymap_location_layer_num_10000_437:
      000B22                        714 	.ds 1
      000B23                        715 _keycode_at_encodermap_location_PARM_2:
      000B23                        716 	.ds 1
      000B24                        717 _keycode_at_encodermap_location_PARM_3:
      000B24                        718 	.ds 1
      000B25                        719 _keycode_at_encodermap_location_layer_num_10000_441:
      000B25                        720 	.ds 1
      000B26                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B26                        722 	.ds 2
      000B28                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B28                        724 	.ds 3
      000B2B                        725 _dynamic_keymap_macro_get_buffer_offset_10000_449:
      000B2B                        726 	.ds 2
      000B2D                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B2D                        728 	.ds 2
      000B2F                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B2F                        730 	.ds 3
      000B32                        731 _dynamic_keymap_macro_set_buffer_offset_10000_451:
      000B32                        732 	.ds 2
      000B34                        733 _decode_keycode_kc_10000_455:
      000B34                        734 	.ds 2
      000B36                        735 _dynamic_keymap_macro_send_id_10000_458:
      000B36                        736 	.ds 1
      000B37                        737 _dynamic_keymap_macro_send_sending_10000_459:
      000B37                        738 	.ds 1
      000B38                        739 _dynamic_keymap_macro_send_p_10001_464:
      000B38                        740 	.ds 2
      000B3A                        741 _dynamic_keymap_macro_send_data_10003_471:
      000B3A                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008300                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008300 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      008303 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_365'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008304                        810 _dynamic_keymap_key_to_eeprom_address:
      008304 E5 82            [12]  811 	mov	a,dpl
      008306 90 0A D3         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_365
      008309 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      00830A E0               [24]  815 	movx	a,@dptr
      00830B FF               [12]  816 	mov	r7,a
      00830C 7E 00            [12]  817 	mov	r6,#0x00
      00830E 74 40            [12]  818 	mov	a,#0x40
      008310 12 43 30         [24]  819 	lcall	_ak820_outline_0134
      008313 7D 00            [12]  820 	mov	r5,#0x00
      008315 90 0A D1         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008318 E0               [24]  822 	movx	a,@dptr
      008319 75 F0 10         [24]  823 	mov	b,#0x10
      00831C A4               [48]  824 	mul	ab
      00831D 2E               [12]  825 	add	a, r6
      00831E FE               [12]  826 	mov	r6,a
      00831F EF               [12]  827 	mov	a,r7
      008320 35 F0            [12]  828 	addc	a, b
      008322 FF               [12]  829 	mov	r7,a
      008323 90 0A D2         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008326 E0               [24]  831 	movx	a,@dptr
      008327 7C 00            [12]  832 	mov	r4,#0x00
      008329 25 E0            [12]  833 	add	a,acc
      00832B FB               [12]  834 	mov	r3,a
      00832C EC               [12]  835 	mov	a,r4
      00832D 33               [12]  836 	rlc	a
      00832E FC               [12]  837 	mov	r4,a
      00832F EB               [12]  838 	mov	a,r3
      008330 2E               [12]  839 	add	a, r6
      008331 FE               [12]  840 	mov	r6,a
      008332 EC               [12]  841 	mov	a,r4
      008333 3F               [12]  842 	addc	a, r7
      008334 FF               [12]  843 	mov	r7,a
      008335 12 43 20         [24]  844 	lcall	_ak820_outline_0116
      008338 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      00833A 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_367'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_370'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_370'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      00833B                        861 _dynamic_keymap_get_keycode:
      00833B E5 82            [12]  862 	mov	a,dpl
      00833D 90 0A D6         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_367
      008340 F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008341 E0               [24]  866 	movx	a,@dptr
      008342 FF               [12]  867 	mov	r7,a
      008343 BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      008346                        869 00121$:
      008346 50 14            [24]  870 	jnc	00101$
      008348 90 0A D4         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00834B E0               [24]  872 	movx	a,@dptr
      00834C FE               [12]  873 	mov	r6,a
      00834D BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      008350                        875 00123$:
      008350 50 0A            [24]  876 	jnc	00101$
      008352 90 0A D5         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008355 E0               [24]  878 	movx	a,@dptr
      008356 FD               [12]  879 	mov	r5,a
      008357 BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      00835A                        881 00125$:
      00835A 40 04            [24]  882 	jc	00102$
      00835C                        883 00101$:
      00835C 90 00 00         [24]  884 	mov	dptr,#0x0000
      00835F 22               [24]  885 	ret
      008360                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008360 12 8D B2         [24]  888 	lcall	_ak820_outline_0094
      008363 12 83 04         [24]  889 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008366 12 8D BF         [24]  891 	lcall	_ak820_outline_0112
      008369 12 40 3F         [24]  892 	lcall	_eeprom_read_byte
      00836C AB 82            [24]  893 	mov	r3,dpl
      00836E 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008370 0D               [12]  896 	inc	r5
      008371 BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      008374 0E               [12]  898 	inc	r6
      008375                        899 00127$:
      008375 12 4E B2         [24]  900 	lcall	_ak820_outline_0043
      008378 12 40 3F         [24]  901 	lcall	_eeprom_read_byte
      00837B AF 82            [24]  902 	mov	r7, dpl
      00837D 7E 00            [12]  903 	mov	r6,#0x00
      00837F EF               [12]  904 	mov	a,r7
      008380 42 04            [12]  905 	orl	ar4,a
      008382 EE               [12]  906 	mov	a,r6
      008383 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      008385 12 43 5C         [24]  909 	lcall	_ak820_outline_0180
                                    910 ;	quantum/dynamic_keymap.c:215: }
      008388 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_371'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_374'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      008389                        925 _dynamic_keymap_set_keycode:
      008389 E5 82            [12]  926 	mov	a,dpl
      00838B 90 0A DB         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_371
      00838E F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      00838F E0               [24]  930 	movx	a,@dptr
      008390 FF               [12]  931 	mov	r7,a
      008391 BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      008394                        933 00121$:
      008394 50 14            [24]  934 	jnc	00101$
      008396 90 0A D7         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008399 E0               [24]  936 	movx	a,@dptr
      00839A FE               [12]  937 	mov	r6,a
      00839B BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      00839E                        939 00123$:
      00839E 50 0A            [24]  940 	jnc	00101$
      0083A0 90 0A D8         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0083A3 E0               [24]  942 	movx	a,@dptr
      0083A4 FD               [12]  943 	mov	r5,a
      0083A5 BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      0083A8                        945 00125$:
      0083A8 40 01            [24]  946 	jc	00102$
      0083AA                        947 00101$:
      0083AA 22               [24]  948 	ret
      0083AB                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0083AB 12 8D B2         [24]  951 	lcall	_ak820_outline_0094
      0083AE 12 83 04         [24]  952 	lcall	_dynamic_keymap_key_to_eeprom_address
      0083B1 12 8D BF         [24]  953 	lcall	_ak820_outline_0112
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0083B4 90 0A D9         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0083B7 E0               [24]  956 	movx	a,@dptr
      0083B8 FB               [12]  957 	mov	r3,a
      0083B9 A3               [24]  958 	inc	dptr
      0083BA E0               [24]  959 	movx	a,@dptr
      0083BB 90 06 97         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      0083BE F0               [24]  961 	movx	@dptr,a
      0083BF 12 4E B2         [24]  962 	lcall	_ak820_outline_0043
      0083C2 12 4D 9C         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0083C5 0D               [12]  965 	inc	r5
      0083C6 BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      0083C9 0E               [12]  967 	inc	r6
      0083CA                        968 00127$:
      0083CA 90 06 97         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      0083CD EB               [12]  970 	mov	a,r3
      0083CE F0               [24]  971 	movx	@dptr,a
      0083CF 12 4E B2         [24]  972 	lcall	_ak820_outline_0043
                                    973 ;	quantum/dynamic_keymap.c:223: }
      0083D2 02 4D 9C         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      0083D5                        985 _dynamic_keymap_encoder_to_eeprom_address:
      0083D5 E5 82            [12]  986 	mov	a,dpl
      0083D7 90 0A DD         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375
      0083DA F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0083DB E0               [24]  990 	movx	a,@dptr
      0083DC 75 F0 04         [24]  991 	mov	b,#0x04
      0083DF A4               [48]  992 	mul	ab
      0083E0 24 40            [12]  993 	add	a, #0x40
      0083E2 FD               [12]  994 	mov	r5,a
      0083E3 74 06            [12]  995 	mov	a,#0x06
      0083E5 35 F0            [12]  996 	addc	a, b
      0083E7 FE               [12]  997 	mov	r6,a
      0083E8 7F 00            [12]  998 	mov	r7,#0x00
      0083EA 90 0A DC         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0083ED E0               [24] 1000 	movx	a,@dptr
      0083EE 75 F0 04         [24] 1001 	mov	b,#0x04
      0083F1 A4               [48] 1002 	mul	ab
      0083F2 2D               [12] 1003 	add	a, r5
      0083F3 FD               [12] 1004 	mov	r5,a
      0083F4 EE               [12] 1005 	mov	a,r6
      0083F5 35 F0            [12] 1006 	addc	a, b
      0083F7 FE               [12] 1007 	mov	r6,a
      0083F8 12 4E B2         [24] 1008 	lcall	_ak820_outline_0043
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      0083FB 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_377'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_380'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_380'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      0083FC                       1024 _dynamic_keymap_get_encoder:
      0083FC E5 82            [12] 1025 	mov	a,dpl
      0083FE 90 0A E0         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_377
      008401 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008402 E0               [24] 1029 	movx	a,@dptr
      008403 FF               [12] 1030 	mov	r7,a
      008404 BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      008407                       1032 00131$:
      008407 50 0A            [24] 1033 	jnc	00101$
      008409 90 0A DE         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00840C E0               [24] 1035 	movx	a,@dptr
      00840D FE               [12] 1036 	mov	r6,a
      00840E BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      008411                       1038 00133$:
      008411 40 04            [24] 1039 	jc	00102$
      008413                       1040 00101$:
      008413 90 00 00         [24] 1041 	mov	dptr,#0x0000
      008416 22               [24] 1042 	ret
      008417                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008417 90 0A DC         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00841A E4               [12] 1046 	clr	a
      00841B F0               [24] 1047 	movx	@dptr,a
      00841C 8F 82            [24] 1048 	mov	dpl, r7
      00841E 12 83 D5         [24] 1049 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008421 12 8D BF         [24] 1050 	lcall	_ak820_outline_0112
                                   1051 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008424 90 0A DF         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008427 E0               [24] 1053 	movx	a,@dptr
      008428 FC               [12] 1054 	mov	r4,a
      008429 E0               [24] 1055 	movx	a,@dptr
      00842A 60 04            [24] 1056 	jz	00106$
      00842C 7B 00            [12] 1057 	mov	r3,#0x00
      00842E 80 02            [24] 1058 	sjmp	00107$
      008430                       1059 00106$:
      008430 7B 02            [12] 1060 	mov	r3,#0x02
      008432                       1061 00107$:
      008432 EB               [12] 1062 	mov	a,r3
      008433 12 8D 90         [24] 1063 	lcall	_ak820_outline_0024
      008436 12 40 3F         [24] 1064 	lcall	_eeprom_read_byte
      008439 AA 82            [24] 1065 	mov	r2,dpl
      00843B 7B 00            [12] 1066 	mov	r3,#0x00
                                   1067 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      00843D EC               [12] 1068 	mov	a,r4
      00843E 60 04            [24] 1069 	jz	00108$
      008440 7C 00            [12] 1070 	mov	r4,#0x00
      008442 80 02            [24] 1071 	sjmp	00109$
      008444                       1072 00108$:
      008444 7C 02            [12] 1073 	mov	r4,#0x02
      008446                       1074 00109$:
      008446 EC               [12] 1075 	mov	a,r4
      008447 12 38 7A         [24] 1076 	lcall	_ak820_outline_0155
      00844A 0D               [12] 1077 	inc	r5
      00844B BD 00 01         [24] 1078 	cjne	r5,#0x00,00137$
      00844E 0E               [12] 1079 	inc	r6
      00844F                       1080 00137$:
      00844F 12 4E B2         [24] 1081 	lcall	_ak820_outline_0043
      008452 12 40 3F         [24] 1082 	lcall	_eeprom_read_byte
      008455 AF 82            [24] 1083 	mov	r7, dpl
      008457 7E 00            [12] 1084 	mov	r6,#0x00
      008459 EF               [12] 1085 	mov	a,r7
      00845A 42 03            [12] 1086 	orl	ar3,a
      00845C EE               [12] 1087 	mov	a,r6
      00845D 42 02            [12] 1088 	orl	ar2,a
                                   1089 ;	quantum/dynamic_keymap.c:236: return keycode;
      00845F 8B 82            [24] 1090 	mov	dpl, r3
      008461 8A 83            [24] 1091 	mov	dph, r2
                                   1092 ;	quantum/dynamic_keymap.c:237: }
      008463 22               [24] 1093 	ret
                                   1094 ;------------------------------------------------------------
                                   1095 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1096 ;------------------------------------------------------------
                                   1097 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1098 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1099 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1100 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1101 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_381'
                                   1102 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_384'
                                   1103 ;------------------------------------------------------------
                                   1104 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1105 ;	-----------------------------------------
                                   1106 ;	 function dynamic_keymap_set_encoder
                                   1107 ;	-----------------------------------------
      008464                       1108 _dynamic_keymap_set_encoder:
      008464 E5 82            [12] 1109 	mov	a,dpl
      008466 90 0A E5         [24] 1110 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_381
      008469 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      00846A E0               [24] 1113 	movx	a,@dptr
      00846B FF               [12] 1114 	mov	r7,a
      00846C BF 06 00         [24] 1115 	cjne	r7,#0x06,00131$
      00846F                       1116 00131$:
      00846F 50 0A            [24] 1117 	jnc	00101$
      008471 90 0A E1         [24] 1118 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008474 E0               [24] 1119 	movx	a,@dptr
      008475 FE               [12] 1120 	mov	r6,a
      008476 BE 01 00         [24] 1121 	cjne	r6,#0x01,00133$
      008479                       1122 00133$:
      008479 40 01            [24] 1123 	jc	00102$
      00847B                       1124 00101$:
      00847B 22               [24] 1125 	ret
      00847C                       1126 00102$:
                                   1127 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00847C 90 0A DC         [24] 1128 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00847F E4               [12] 1129 	clr	a
      008480 F0               [24] 1130 	movx	@dptr,a
      008481 8F 82            [24] 1131 	mov	dpl, r7
      008483 12 83 D5         [24] 1132 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008486 12 8D BF         [24] 1133 	lcall	_ak820_outline_0112
                                   1134 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008489 90 0A E2         [24] 1135 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00848C E0               [24] 1136 	movx	a,@dptr
      00848D FC               [12] 1137 	mov	r4,a
      00848E E0               [24] 1138 	movx	a,@dptr
      00848F 60 04            [24] 1139 	jz	00106$
      008491 7B 00            [12] 1140 	mov	r3,#0x00
      008493 80 02            [24] 1141 	sjmp	00107$
      008495                       1142 00106$:
      008495 7B 02            [12] 1143 	mov	r3,#0x02
      008497                       1144 00107$:
      008497 EB               [12] 1145 	mov	a,r3
      008498 12 8D D1         [24] 1146 	lcall	_ak820_outline_0133
      00849B 8F 03            [24] 1147 	mov	ar3,r7
      00849D 90 0A E3         [24] 1148 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0084A0 E0               [24] 1149 	movx	a,@dptr
      0084A1 F5 29            [12] 1150 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      0084A3 A3               [24] 1151 	inc	dptr
      0084A4 E0               [24] 1152 	movx	a,@dptr
      0084A5 F5 2A            [12] 1153 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      0084A7 90 06 97         [24] 1154 	mov	dptr,#_eeprom_update_byte_PARM_2
      0084AA F0               [24] 1155 	movx	@dptr,a
      0084AB 12 43 57         [24] 1156 	lcall	_ak820_outline_0179
      0084AE 8B F0            [24] 1157 	mov	b, r3
      0084B0 12 4D 9C         [24] 1158 	lcall	_eeprom_update_byte
                                   1159 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0084B3 EC               [12] 1160 	mov	a,r4
      0084B4 60 04            [24] 1161 	jz	00108$
      0084B6 7C 00            [12] 1162 	mov	r4,#0x00
      0084B8 80 02            [24] 1163 	sjmp	00109$
      0084BA                       1164 00108$:
      0084BA 7C 02            [12] 1165 	mov	r4,#0x02
      0084BC                       1166 00109$:
      0084BC EC               [12] 1167 	mov	a,r4
      0084BD 12 38 7A         [24] 1168 	lcall	_ak820_outline_0155
      0084C0 0D               [12] 1169 	inc	r5
      0084C1 BD 00 01         [24] 1170 	cjne	r5,#0x00,00137$
      0084C4 0E               [12] 1171 	inc	r6
      0084C5                       1172 00137$:
      0084C5 90 06 97         [24] 1173 	mov	dptr,#_eeprom_update_byte_PARM_2
      0084C8 E5 29            [12] 1174 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      0084CA F0               [24] 1175 	movx	@dptr,a
      0084CB 12 4E B2         [24] 1176 	lcall	_ak820_outline_0043
                                   1177 ;	quantum/dynamic_keymap.c:245: }
      0084CE 02 4D 9C         [24] 1178 	ljmp	_eeprom_update_byte
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1183 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1184 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_385'
                                   1185 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_386'
                                   1186 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_388'
                                   1187 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_389'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function dynamic_keymap_get_combo
                                   1192 ;	-----------------------------------------
      0084D1                       1193 _dynamic_keymap_get_combo:
      0084D1 E5 82            [12] 1194 	mov	a,dpl
      0084D3 90 0A E9         [24] 1195 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      0084D6 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0084D7 90 0A E6         [24] 1198 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      0084DA 12 38 00         [24] 1199 	lcall	_ak820_outline_0050
                                   1200 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      0084DD 90 0A E9         [24] 1201 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      0084E0 E0               [24] 1202 	movx	a,@dptr
      0084E1 FD               [12] 1203 	mov	r5,a
      0084E2 BD 08 00         [24] 1204 	cjne	r5,#0x08,00132$
      0084E5                       1205 00132$:
      0084E5 40 04            [24] 1206 	jc	00102$
                                   1207 ;	quantum/dynamic_keymap.c:315: return -1;
      0084E7 90 FF FF         [24] 1208 	mov	dptr,#0xffff
      0084EA 22               [24] 1209 	ret
      0084EB                       1210 00102$:
                                   1211 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0084EB 12 8D 9E         [24] 1212 	lcall	_ak820_outline_0077
                                   1213 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      0084EE 8E 02            [24] 1214 	mov	ar2,r6
      0084F0 8F 03            [24] 1215 	mov	ar3,r7
      0084F2 90 05 81         [24] 1216 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0084F5 12 38 25         [24] 1217 	lcall	_ak820_outline_0070
      0084F8 E4               [12] 1218 	clr	a
      0084F9 A3               [24] 1219 	inc	dptr
      0084FA F0               [24] 1220 	movx	@dptr,a
      0084FB 90 05 84         [24] 1221 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0084FE 74 0A            [12] 1222 	mov	a,#0x0a
      008500 12 38 65         [24] 1223 	lcall	_ak820_outline_0123
      008503 12 43 3C         [24] 1224 	lcall	_ak820_outline_0140
      008506 C0 07            [24] 1225 	push	ar7
      008508 C0 06            [24] 1226 	push	ar6
      00850A 12 40 7A         [24] 1227 	lcall	_ak820_eeprom_read_block_xdata
      00850D D0 06            [24] 1228 	pop	ar6
      00850F D0 07            [24] 1229 	pop	ar7
                                   1230 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008511 74 04            [12] 1231 	mov	a,#0x04
      008513 12 47 FD         [24] 1232 	lcall	_ak820_outline_0011
      008516 FA               [12] 1233 	mov	r2,a
      008517 A3               [24] 1234 	inc	dptr
      008518 E0               [24] 1235 	movx	a,@dptr
      008519 FB               [12] 1236 	mov	r3,a
      00851A BA 20 14         [24] 1237 	cjne	r2,#0x20,00108$
      00851D BB 08 11         [24] 1238 	cjne	r3,#0x08,00108$
      008520 74 06            [12] 1239 	mov	a,#0x06
      008522 12 37 E7         [24] 1240 	lcall	_ak820_outline_0016
      008525 FA               [12] 1241 	mov	r2,a
      008526 A3               [24] 1242 	inc	dptr
      008527 E0               [24] 1243 	movx	a,@dptr
      008528 FB               [12] 1244 	mov	r3,a
      008529 BA 01 05         [24] 1245 	cjne	r2,#0x01,00136$
      00852C BB 00 02         [24] 1246 	cjne	r3,#0x00,00136$
      00852F 80 05            [24] 1247 	sjmp	00109$
      008531                       1248 00136$:
      008531                       1249 00108$:
      008531 75 2B 00         [24] 1250 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008534 80 03            [24] 1251 	sjmp	00110$
      008536                       1252 00109$:
      008536 75 2B 01         [24] 1253 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008539                       1254 00110$:
                                   1255 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008539 74 06            [12] 1256 	mov	a,#0x06
      00853B 12 37 F0         [24] 1257 	lcall	_ak820_outline_0030
      00853E E4               [12] 1258 	clr	a
      00853F F0               [24] 1259 	movx	@dptr,a
      008540 A3               [24] 1260 	inc	dptr
      008541 12 38 31         [24] 1261 	lcall	_ak820_outline_0095
      008544 F0               [24] 1262 	movx	@dptr,a
      008545 A3               [24] 1263 	inc	dptr
      008546 F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008547 E5 2B            [12] 1266 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008549 60 12            [24] 1267 	jz	00103$
      00854B 12 43 20         [24] 1268 	lcall	_ak820_outline_0116
      00854E C0 07            [24] 1269 	push	ar7
      008550 C0 06            [24] 1270 	push	ar6
      008552 12 34 68         [24] 1271 	lcall	_ak820_combo_valid
      008555 E5 82            [12] 1272 	mov	a, dpl
      008557 D0 06            [24] 1273 	pop	ar6
      008559 D0 07            [24] 1274 	pop	ar7
      00855B 70 17            [24] 1275 	jnz	00104$
      00855D                       1276 00103$:
      00855D 7D 00            [12] 1277 	mov	r5,#0x00
      00855F 90 0D 7B         [24] 1278 	mov	dptr,#_memset_PARM_2
      008562 E4               [12] 1279 	clr	a
      008563 F0               [24] 1280 	movx	@dptr,a
      008564 90 0D 7C         [24] 1281 	mov	dptr,#_memset_PARM_3
      008567 74 0A            [12] 1282 	mov	a,#0x0a
      008569 F0               [24] 1283 	movx	@dptr,a
      00856A E4               [12] 1284 	clr	a
      00856B A3               [24] 1285 	inc	dptr
      00856C 12 43 02         [24] 1286 	lcall	_ak820_outline_0060
      00856F 8D F0            [24] 1287 	mov	b, r5
      008571 12 B6 E1         [24] 1288 	lcall	_memset
      008574                       1289 00104$:
                                   1290 ;	quantum/dynamic_keymap.c:329: return 0;
      008574 90 00 00         [24] 1291 	mov	dptr,#0x0000
                                   1292 ;	quantum/dynamic_keymap.c:330: }
      008577 22               [24] 1293 	ret
                                   1294 ;------------------------------------------------------------
                                   1295 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1296 ;------------------------------------------------------------
                                   1297 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1298 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_391'
                                   1299 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_392'
                                   1300 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_395'
                                   1301 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_396'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1304 ;	-----------------------------------------
                                   1305 ;	 function dynamic_keymap_set_combo
                                   1306 ;	-----------------------------------------
      008578                       1307 _dynamic_keymap_set_combo:
      008578 E5 82            [12] 1308 	mov	a,dpl
      00857A 90 0A ED         [24] 1309 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      00857D F0               [24] 1310 	movx	@dptr,a
                                   1311 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      00857E 90 0A EA         [24] 1312 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008581 12 37 A0         [24] 1313 	lcall	_ak820_outline_0004
                                   1314 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008584 C0 07            [24] 1315 	push	ar7
      008586 C0 06            [24] 1316 	push	ar6
      008588 12 34 68         [24] 1317 	lcall	_ak820_combo_valid
      00858B E5 82            [12] 1318 	mov	a, dpl
      00858D D0 06            [24] 1319 	pop	ar6
      00858F D0 07            [24] 1320 	pop	ar7
      008591 60 07            [24] 1321 	jz	00101$
      008593 12 3D E5         [24] 1322 	lcall	_ak820_nvm_ok
      008596 E5 82            [12] 1323 	mov	a, dpl
      008598 70 04            [24] 1324 	jnz	00102$
      00859A                       1325 00101$:
      00859A 90 FF FF         [24] 1326 	mov	dptr,#0xffff
      00859D 22               [24] 1327 	ret
      00859E                       1328 00102$:
                                   1329 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      00859E 90 0A ED         [24] 1330 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      0085A1 E0               [24] 1331 	movx	a,@dptr
      0085A2 FD               [12] 1332 	mov	r5,a
      0085A3 BD 08 00         [24] 1333 	cjne	r5,#0x08,00133$
      0085A6                       1334 00133$:
      0085A6 40 04            [24] 1335 	jc	00105$
                                   1336 ;	quantum/dynamic_keymap.c:342: return -1;
      0085A8 90 FF FF         [24] 1337 	mov	dptr,#0xffff
      0085AB 22               [24] 1338 	ret
      0085AC                       1339 00105$:
                                   1340 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0085AC 12 8D 9E         [24] 1341 	lcall	_ak820_outline_0077
                                   1342 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      0085AF C0 07            [24] 1343 	push	ar7
      0085B1 C0 06            [24] 1344 	push	ar6
      0085B3 C0 05            [24] 1345 	push	ar5
      0085B5 C0 04            [24] 1346 	push	ar4
      0085B7 12 75 CD         [24] 1347 	lcall	_clear_keyboard
      0085BA D0 04            [24] 1348 	pop	ar4
      0085BC D0 05            [24] 1349 	pop	ar5
      0085BE D0 06            [24] 1350 	pop	ar6
      0085C0 D0 07            [24] 1351 	pop	ar7
                                   1352 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      0085C2 90 0D 73         [24] 1353 	mov	dptr,#___memcpy_PARM_2
      0085C5 12 48 56         [24] 1354 	lcall	_ak820_outline_0058
      0085C8 E4               [12] 1355 	clr	a
      0085C9 A3               [24] 1356 	inc	dptr
      0085CA F0               [24] 1357 	movx	@dptr,a
      0085CB 90 0D 76         [24] 1358 	mov	dptr,#___memcpy_PARM_3
      0085CE 74 0A            [12] 1359 	mov	a,#0x0a
      0085D0 12 38 65         [24] 1360 	lcall	_ak820_outline_0123
      0085D3 90 0A EE         [24] 1361 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      0085D6 F5 F0            [12] 1362 	mov	b,a
      0085D8 C0 05            [24] 1363 	push	ar5
      0085DA C0 04            [24] 1364 	push	ar4
      0085DC 12 B6 6B         [24] 1365 	lcall	___memcpy
      0085DF D0 04            [24] 1366 	pop	ar4
      0085E1 D0 05            [24] 1367 	pop	ar5
                                   1368 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      0085E3 90 0A F2         [24] 1369 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0004)
      0085E6 74 20            [12] 1370 	mov	a,#0x20
      0085E8 F0               [24] 1371 	movx	@dptr,a
      0085E9 74 08            [12] 1372 	mov	a,#0x08
      0085EB A3               [24] 1373 	inc	dptr
      0085EC F0               [24] 1374 	movx	@dptr,a
                                   1375 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      0085ED 90 0A F4         [24] 1376 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0006)
      0085F0 74 01            [12] 1377 	mov	a,#0x01
      0085F2 12 38 65         [24] 1378 	lcall	_ak820_outline_0123
                                   1379 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      0085F5 90 05 8A         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0085F8 12 38 25         [24] 1381 	lcall	_ak820_outline_0070
      0085FB E4               [12] 1382 	clr	a
      0085FC A3               [24] 1383 	inc	dptr
      0085FD F0               [24] 1384 	movx	@dptr,a
      0085FE 90 05 8D         [24] 1385 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008601 74 0A            [12] 1386 	mov	a,#0x0a
      008603 12 38 65         [24] 1387 	lcall	_ak820_outline_0123
      008606 90 0A EE         [24] 1388 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008609 12 41 06         [24] 1389 	lcall	_ak820_eeprom_write_block_xdata
                                   1390 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      00860C 12 3D F4         [24] 1391 	lcall	_ak820_nvm_flush
                                   1392 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      00860F 12 3D E5         [24] 1393 	lcall	_ak820_nvm_ok
      008612 E5 82            [12] 1394 	mov	a, dpl
      008614 70 04            [24] 1395 	jnz	00107$
      008616 90 FF FF         [24] 1396 	mov	dptr,#0xffff
      008619 22               [24] 1397 	ret
      00861A                       1398 00107$:
                                   1399 ;	quantum/dynamic_keymap.c:360: return 0;
      00861A 90 00 00         [24] 1400 	mov	dptr,#0x0000
                                   1401 ;	quantum/dynamic_keymap.c:361: }
      00861D 22               [24] 1402 	ret
                                   1403 ;------------------------------------------------------------
                                   1404 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1405 ;------------------------------------------------------------
                                   1406 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_399'
                                   1407 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_400'
                                   1408 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_402'
                                   1409 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_404'
                                   1410 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_406'
                                   1411 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_408'
                                   1412 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_409'
                                   1413 ;------------------------------------------------------------
                                   1414 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1415 ;	-----------------------------------------
                                   1416 ;	 function dynamic_keymap_reset
                                   1417 ;	-----------------------------------------
      00861E                       1418 _dynamic_keymap_reset:
                                   1419 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      00861E 90 0D F3         [24] 1420 	mov	dptr,#_vial_unlocked
      008621 E0               [24] 1421 	movx	a,@dptr
      008622 90 0A F8         [24] 1422 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008625 F0               [24] 1423 	movx	@dptr,a
                                   1424 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008626 90 0D F3         [24] 1425 	mov	dptr,#_vial_unlocked
      008629 74 01            [12] 1426 	mov	a,#0x01
      00862B F0               [24] 1427 	movx	@dptr,a
                                   1428 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      00862C 7F 00            [12] 1429 	mov	r7,#0x00
      00862E                       1430 00116$:
      00862E BF 06 00         [24] 1431 	cjne	r7,#0x06,00198$
      008631                       1432 00198$:
      008631 40 03            [24] 1433 	jc	00199$
      008633 02 86 E1         [24] 1434 	ljmp	00104$
      008636                       1435 00199$:
                                   1436 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008636 7E 00            [12] 1437 	mov	r6,#0x00
      008638                       1438 00110$:
      008638 BE 10 00         [24] 1439 	cjne	r6,#0x10,00200$
      00863B                       1440 00200$:
      00863B 50 4D            [24] 1441 	jnc	00102$
                                   1442 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      00863D 7D 00            [12] 1443 	mov	r5,#0x00
      00863F                       1444 00107$:
      00863F BD 08 00         [24] 1445 	cjne	r5,#0x08,00202$
      008642                       1446 00202$:
      008642 50 43            [24] 1447 	jnc	00111$
                                   1448 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008644 90 0B 94         [24] 1449 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008647 EE               [12] 1450 	mov	a,r6
      008648 F0               [24] 1451 	movx	@dptr,a
      008649 90 0B 95         [24] 1452 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      00864C ED               [12] 1453 	mov	a,r5
      00864D F0               [24] 1454 	movx	@dptr,a
      00864E 8F 82            [24] 1455 	mov	dpl, r7
      008650 C0 07            [24] 1456 	push	ar7
      008652 C0 06            [24] 1457 	push	ar6
      008654 C0 05            [24] 1458 	push	ar5
      008656 12 95 E7         [24] 1459 	lcall	_keycode_at_keymap_location_raw
      008659 AB 82            [24] 1460 	mov	r3, dpl
      00865B AC 83            [24] 1461 	mov	r4, dph
      00865D D0 05            [24] 1462 	pop	ar5
      00865F D0 06            [24] 1463 	pop	ar6
      008661 D0 07            [24] 1464 	pop	ar7
      008663 90 0A D7         [24] 1465 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008666 EE               [12] 1466 	mov	a,r6
      008667 F0               [24] 1467 	movx	@dptr,a
      008668 90 0A D8         [24] 1468 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00866B ED               [12] 1469 	mov	a,r5
      00866C F0               [24] 1470 	movx	@dptr,a
      00866D 90 0A D9         [24] 1471 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008670 12 38 2B         [24] 1472 	lcall	_ak820_outline_0075
      008673 8F 82            [24] 1473 	mov	dpl, r7
      008675 C0 07            [24] 1474 	push	ar7
      008677 C0 06            [24] 1475 	push	ar6
      008679 C0 05            [24] 1476 	push	ar5
      00867B 12 83 89         [24] 1477 	lcall	_dynamic_keymap_set_keycode
      00867E D0 05            [24] 1478 	pop	ar5
      008680 D0 06            [24] 1479 	pop	ar6
      008682 D0 07            [24] 1480 	pop	ar7
                                   1481 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008684 0D               [12] 1482 	inc	r5
      008685 80 B8            [24] 1483 	sjmp	00107$
      008687                       1484 00111$:
                                   1485 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008687 0E               [12] 1486 	inc	r6
      008688 80 AE            [24] 1487 	sjmp	00110$
      00868A                       1488 00102$:
                                   1489 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      00868A 7E 00            [12] 1490 	mov	r6,#0x00
      00868C                       1491 00113$:
      00868C BE 01 00         [24] 1492 	cjne	r6,#0x01,00204$
      00868F                       1493 00204$:
      00868F 50 4C            [24] 1494 	jnc	00117$
                                   1495 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008691 12 8D ED         [24] 1496 	lcall	_ak820_outline_0174
      008694 04               [12] 1497 	inc	a
      008695 F0               [24] 1498 	movx	@dptr,a
      008696 8F 82            [24] 1499 	mov	dpl, r7
      008698 C0 07            [24] 1500 	push	ar7
      00869A 12 96 2C         [24] 1501 	lcall	_keycode_at_encodermap_location_raw
      00869D 12 43 41         [24] 1502 	lcall	_ak820_outline_0145
      0086A0 D0 07            [24] 1503 	pop	ar7
      0086A2 12 8D E4         [24] 1504 	lcall	_ak820_outline_0173
      0086A5 04               [12] 1505 	inc	a
      0086A6 F0               [24] 1506 	movx	@dptr,a
      0086A7 90 0A E3         [24] 1507 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0086AA 12 38 25         [24] 1508 	lcall	_ak820_outline_0070
      0086AD 8F 82            [24] 1509 	mov	dpl, r7
      0086AF C0 07            [24] 1510 	push	ar7
      0086B1 12 84 64         [24] 1511 	lcall	_dynamic_keymap_set_encoder
      0086B4 D0 07            [24] 1512 	pop	ar7
                                   1513 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      0086B6 12 8D ED         [24] 1514 	lcall	_ak820_outline_0174
      0086B9 F0               [24] 1515 	movx	@dptr,a
      0086BA 8F 82            [24] 1516 	mov	dpl, r7
      0086BC C0 07            [24] 1517 	push	ar7
      0086BE 12 96 2C         [24] 1518 	lcall	_keycode_at_encodermap_location_raw
      0086C1 12 43 41         [24] 1519 	lcall	_ak820_outline_0145
      0086C4 D0 07            [24] 1520 	pop	ar7
      0086C6 12 8D E4         [24] 1521 	lcall	_ak820_outline_0173
      0086C9 F0               [24] 1522 	movx	@dptr,a
      0086CA 90 0A E3         [24] 1523 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0086CD 12 38 25         [24] 1524 	lcall	_ak820_outline_0070
      0086D0 8F 82            [24] 1525 	mov	dpl, r7
      0086D2 C0 07            [24] 1526 	push	ar7
      0086D4 12 84 64         [24] 1527 	lcall	_dynamic_keymap_set_encoder
      0086D7 D0 07            [24] 1528 	pop	ar7
                                   1529 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0086D9 7E 01            [12] 1530 	mov	r6,#0x01
      0086DB 80 AF            [24] 1531 	sjmp	00113$
      0086DD                       1532 00117$:
                                   1533 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0086DD 0F               [12] 1534 	inc	r7
      0086DE 02 86 2E         [24] 1535 	ljmp	00116$
      0086E1                       1536 00104$:
                                   1537 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      0086E1 90 0A F9         [24] 1538 	mov	dptr,#_dynamic_keymap_reset_combo_10001_408
      0086E4 12 4E FB         [24] 1539 	lcall	_ak820_outline_0178
      0086E7 90 0A FB         [24] 1540 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0002)
      0086EA F0               [24] 1541 	movx	@dptr,a
      0086EB A3               [24] 1542 	inc	dptr
      0086EC F0               [24] 1543 	movx	@dptr,a
      0086ED 90 0A FD         [24] 1544 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0004)
      0086F0 F0               [24] 1545 	movx	@dptr,a
      0086F1 A3               [24] 1546 	inc	dptr
      0086F2 F0               [24] 1547 	movx	@dptr,a
      0086F3 90 0A FF         [24] 1548 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0006)
      0086F6 F0               [24] 1549 	movx	@dptr,a
      0086F7 A3               [24] 1550 	inc	dptr
      0086F8 F0               [24] 1551 	movx	@dptr,a
      0086F9 90 0B 01         [24] 1552 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0008)
      0086FC F0               [24] 1553 	movx	@dptr,a
      0086FD A3               [24] 1554 	inc	dptr
      0086FE F0               [24] 1555 	movx	@dptr,a
                                   1556 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0086FF FF               [12] 1557 	mov	r7,a
      008700                       1558 00119$:
      008700 BF 08 00         [24] 1559 	cjne	r7,#0x08,00206$
      008703                       1560 00206$:
      008703 50 17            [24] 1561 	jnc	00105$
                                   1562 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008705 90 0A EA         [24] 1563 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008708 74 F9            [12] 1564 	mov	a,#_dynamic_keymap_reset_combo_10001_408
      00870A F0               [24] 1565 	movx	@dptr,a
      00870B 74 0A            [12] 1566 	mov	a,#(_dynamic_keymap_reset_combo_10001_408 >> 8)
      00870D 12 38 54         [24] 1567 	lcall	_ak820_outline_0117
      008710 8F 82            [24] 1568 	mov	dpl, r7
      008712 C0 07            [24] 1569 	push	ar7
      008714 12 85 78         [24] 1570 	lcall	_dynamic_keymap_set_combo
      008717 D0 07            [24] 1571 	pop	ar7
                                   1572 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008719 0F               [12] 1573 	inc	r7
      00871A 80 E4            [24] 1574 	sjmp	00119$
      00871C                       1575 00105$:
                                   1576 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      00871C 90 0A F8         [24] 1577 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      00871F E0               [24] 1578 	movx	a,@dptr
      008720 90 0D F3         [24] 1579 	mov	dptr,#_vial_unlocked
      008723 F0               [24] 1580 	movx	@dptr,a
                                   1581 ;	quantum/dynamic_keymap.c:468: }
      008724 22               [24] 1582 	ret
                                   1583 ;------------------------------------------------------------
                                   1584 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1585 ;------------------------------------------------------------
                                   1586 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1587 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1588 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1589 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1590 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1591 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_410'
                                   1592 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_411'
                                   1593 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_411'
                                   1594 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_414'
                                   1595 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_416'
                                   1596 ;------------------------------------------------------------
                                   1597 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1598 ;	-----------------------------------------
                                   1599 ;	 function ak820_dynamic_read_buffer
                                   1600 ;	-----------------------------------------
      008725                       1601 _ak820_dynamic_read_buffer:
      008725 12 38 43         [24] 1602 	lcall	_ak820_outline_0103
      008728 90 0B 0C         [24] 1603 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      00872B 12 38 48         [24] 1604 	lcall	_ak820_outline_0104
                                   1605 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      00872E 90 0B 09         [24] 1606 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008731 12 38 00         [24] 1607 	lcall	_ak820_outline_0050
                                   1608 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008734 90 0B 0E         [24] 1609 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008737 E4               [12] 1610 	clr	a
      008738 F0               [24] 1611 	movx	@dptr,a
                                   1612 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008739 90 0B 07         [24] 1613 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      00873C 12 38 1F         [24] 1614 	lcall	_ak820_outline_0059
      00873F 8C 02            [24] 1615 	mov	ar2,r4
      008741 8D 03            [24] 1616 	mov	ar3,r5
      008743 C3               [12] 1617 	clr	c
      008744 74 1C            [12] 1618 	mov	a,#0x1c
      008746 9A               [12] 1619 	subb	a,r2
      008747 E4               [12] 1620 	clr	a
      008748 9B               [12] 1621 	subb	a,r3
      008749 50 01            [24] 1622 	jnc	00102$
                                   1623 ;	free result
      00874B 22               [24] 1624 	ret
      00874C                       1625 00102$:
                                   1626 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      00874C 90 0B 05         [24] 1627 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      00874F 12 43 25         [24] 1628 	lcall	_ak820_outline_0119
      008752 90 0B 03         [24] 1629 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008755 12 38 3D         [24] 1630 	lcall	_ak820_outline_0099
      008758 C3               [12] 1631 	clr	c
      008759 EA               [12] 1632 	mov	a,r2
      00875A 98               [12] 1633 	subb	a,r0
      00875B EB               [12] 1634 	mov	a,r3
      00875C 99               [12] 1635 	subb	a,r1
      00875D 50 17            [24] 1636 	jnc	00104$
                                   1637 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      00875F E8               [12] 1638 	mov	a,r0
      008760 C3               [12] 1639 	clr	c
      008761 9A               [12] 1640 	subb	a,r2
      008762 F8               [12] 1641 	mov	r0,a
      008763 E9               [12] 1642 	mov	a,r1
      008764 9B               [12] 1643 	subb	a,r3
      008765 F9               [12] 1644 	mov	r1,a
                                   1645 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008766 C3               [12] 1646 	clr	c
      008767 E8               [12] 1647 	mov	a,r0
      008768 9C               [12] 1648 	subb	a,r4
      008769 E9               [12] 1649 	mov	a,r1
      00876A 9D               [12] 1650 	subb	a,r5
      00876B 40 04            [24] 1651 	jc	00114$
      00876D 8C 00            [24] 1652 	mov	ar0,r4
      00876F 8D 01            [24] 1653 	mov	ar1,r5
      008771                       1654 00114$:
      008771 90 0B 0E         [24] 1655 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008774 E8               [12] 1656 	mov	a,r0
      008775 F0               [24] 1657 	movx	@dptr,a
      008776                       1658 00104$:
                                   1659 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008776 90 0B 0E         [24] 1660 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008779 E0               [24] 1661 	movx	a,@dptr
      00877A F5 2C            [12] 1662 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      00877C E0               [24] 1663 	movx	a,@dptr
      00877D 60 42            [24] 1664 	jz	00106$
      00877F C0 04            [24] 1665 	push	ar4
      008781 C0 05            [24] 1666 	push	ar5
      008783 8E 00            [24] 1667 	mov	ar0,r6
      008785 8F 05            [24] 1668 	mov	ar5,r7
      008787 90 0B 0C         [24] 1669 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      00878A E0               [24] 1670 	movx	a,@dptr
      00878B F9               [12] 1671 	mov	r1,a
      00878C A3               [24] 1672 	inc	dptr
      00878D E0               [24] 1673 	movx	a,@dptr
      00878E FC               [12] 1674 	mov	r4,a
      00878F EA               [12] 1675 	mov	a,r2
      008790 29               [12] 1676 	add	a, r1
      008791 FA               [12] 1677 	mov	r2,a
      008792 EB               [12] 1678 	mov	a,r3
      008793 3C               [12] 1679 	addc	a, r4
      008794 FB               [12] 1680 	mov	r3,a
      008795 90 05 81         [24] 1681 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008798 EA               [12] 1682 	mov	a,r2
      008799 F0               [24] 1683 	movx	@dptr,a
      00879A EB               [12] 1684 	mov	a,r3
      00879B 12 38 54         [24] 1685 	lcall	_ak820_outline_0117
      00879E 90 05 84         [24] 1686 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0087A1 E5 2C            [12] 1687 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      0087A3 12 38 65         [24] 1688 	lcall	_ak820_outline_0123
      0087A6 88 82            [24] 1689 	mov	dpl, r0
      0087A8 8D 83            [24] 1690 	mov	dph, r5
      0087AA C0 07            [24] 1691 	push	ar7
      0087AC C0 06            [24] 1692 	push	ar6
      0087AE C0 05            [24] 1693 	push	ar5
      0087B0 C0 04            [24] 1694 	push	ar4
      0087B2 12 40 7A         [24] 1695 	lcall	_ak820_eeprom_read_block_xdata
      0087B5 D0 04            [24] 1696 	pop	ar4
      0087B7 D0 05            [24] 1697 	pop	ar5
      0087B9 D0 06            [24] 1698 	pop	ar6
      0087BB D0 07            [24] 1699 	pop	ar7
                                   1700 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0087BD D0 05            [24] 1701 	pop	ar5
      0087BF D0 04            [24] 1702 	pop	ar4
                                   1703 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0087C1                       1704 00106$:
                                   1705 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0087C1 90 0B 0E         [24] 1706 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      0087C4 E0               [24] 1707 	movx	a,@dptr
      0087C5 FB               [12] 1708 	mov	r3,a
      0087C6                       1709 00109$:
      0087C6 8B 01            [24] 1710 	mov	ar1,r3
      0087C8 7A 00            [12] 1711 	mov	r2,#0x00
      0087CA C3               [12] 1712 	clr	c
      0087CB E9               [12] 1713 	mov	a,r1
      0087CC 9C               [12] 1714 	subb	a,r4
      0087CD EA               [12] 1715 	mov	a,r2
      0087CE 9D               [12] 1716 	subb	a,r5
      0087CF 50 09            [24] 1717 	jnc	00111$
      0087D1 EB               [12] 1718 	mov	a,r3
      0087D2 12 37 F0         [24] 1719 	lcall	_ak820_outline_0030
      0087D5 E4               [12] 1720 	clr	a
      0087D6 F0               [24] 1721 	movx	@dptr,a
      0087D7 0B               [12] 1722 	inc	r3
      0087D8 80 EC            [24] 1723 	sjmp	00109$
      0087DA                       1724 00111$:
                                   1725 ;	quantum/dynamic_keymap.c:483: }
      0087DA 22               [24] 1726 	ret
                                   1727 ;------------------------------------------------------------
                                   1728 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1729 ;------------------------------------------------------------
                                   1730 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1731 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1732 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_417'
                                   1733 ;------------------------------------------------------------
                                   1734 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1735 ;	-----------------------------------------
                                   1736 ;	 function dynamic_keymap_get_buffer
                                   1737 ;	-----------------------------------------
      0087DB                       1738 _dynamic_keymap_get_buffer:
      0087DB 12 38 43         [24] 1739 	lcall	_ak820_outline_0103
      0087DE 90 0B 14         [24] 1740 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      0087E1 12 38 48         [24] 1741 	lcall	_ak820_outline_0104
                                   1742 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      0087E4 90 0B 14         [24] 1743 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      0087E7 12 38 00         [24] 1744 	lcall	_ak820_outline_0050
      0087EA 90 0B 0F         [24] 1745 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      0087ED 12 38 1F         [24] 1746 	lcall	_ak820_outline_0059
      0087F0 90 0B 11         [24] 1747 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      0087F3 12 4E DB         [24] 1748 	lcall	_ak820_outline_0086
      0087F6 90 0B 03         [24] 1749 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0087F9 E4               [12] 1750 	clr	a
      0087FA F0               [24] 1751 	movx	@dptr,a
      0087FB 74 06            [12] 1752 	mov	a,#0x06
      0087FD A3               [24] 1753 	inc	dptr
      0087FE F0               [24] 1754 	movx	@dptr,a
      0087FF 90 0B 05         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008802 12 48 56         [24] 1756 	lcall	_ak820_outline_0058
      008805 90 0B 07         [24] 1757 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008808 12 38 25         [24] 1758 	lcall	_ak820_outline_0070
      00880B 90 0B 09         [24] 1759 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      00880E E9               [12] 1760 	mov	a,r1
      00880F 12 4E F4         [24] 1761 	lcall	_ak820_outline_0151
      008812 F0               [24] 1762 	movx	@dptr,a
      008813 90 00 40         [24] 1763 	mov	dptr,#0x0040
                                   1764 ;	quantum/dynamic_keymap.c:511: }
      008816 02 87 25         [24] 1765 	ljmp	_ak820_dynamic_read_buffer
                                   1766 ;------------------------------------------------------------
                                   1767 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1768 ;------------------------------------------------------------
                                   1769 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1770 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1771 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1772 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1773 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1774 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_419'
                                   1775 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_420'
                                   1776 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_420'
                                   1777 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_420'
                                   1778 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_423'
                                   1779 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_426'
                                   1780 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_426'
                                   1781 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_428'
                                   1782 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_431'
                                   1783 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_433'
                                   1784 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_434'
                                   1785 ;------------------------------------------------------------
                                   1786 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1787 ;	-----------------------------------------
                                   1788 ;	 function dynamic_keymap_set_buffer
                                   1789 ;	-----------------------------------------
      008819                       1790 _dynamic_keymap_set_buffer:
      008819 12 38 43         [24] 1791 	lcall	_ak820_outline_0103
      00881C 90 0B 1B         [24] 1792 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      00881F 12 38 48         [24] 1793 	lcall	_ak820_outline_0104
                                   1794 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008822 90 0B 1B         [24] 1795 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008825 12 37 CB         [24] 1796 	lcall	_ak820_outline_0010
      008828 74 40            [12] 1797 	mov	a,#0x40
      00882A 2C               [12] 1798 	add	a, r4
      00882B FA               [12] 1799 	mov	r2,a
      00882C E4               [12] 1800 	clr	a
      00882D 3D               [12] 1801 	addc	a, r5
      00882E FB               [12] 1802 	mov	r3,a
                                   1803 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      00882F 90 0B 18         [24] 1804 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008832 12 38 3D         [24] 1805 	lcall	_ak820_outline_0099
                                   1806 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008835 90 0B 16         [24] 1807 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008838 E0               [24] 1808 	movx	a,@dptr
      008839 F5 2D            [12] 1809 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      00883B A3               [24] 1810 	inc	dptr
      00883C E0               [24] 1811 	movx	a,@dptr
      00883D F5 2E            [12] 1812 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      00883F E5 2D            [12] 1813 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008841 45 2E            [12] 1814 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008843 70 01            [24] 1815 	jnz	00102$
      008845 22               [24] 1816 	ret
      008846                       1817 00102$:
                                   1818 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008846 85 2D 2F         [24] 1819 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008849 85 2E 30         [24] 1820 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00884C C3               [12] 1821 	clr	c
      00884D 74 1C            [12] 1822 	mov	a,#0x1c
      00884F 95 2F            [12] 1823 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008851 E4               [12] 1824 	clr	a
      008852 95 30            [12] 1825 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008854 50 01            [24] 1826 	jnc	00104$
                                   1827 ;	free result
      008856 22               [24] 1828 	ret
      008857                       1829 00104$:
                                   1830 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008857 85 2D 31         [24] 1831 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1832 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      00885A 74 FA            [12] 1833 	mov	a,#0x100 - 0x06
      00885C 2F               [12] 1834 	add	a,r7
      00885D 40 11            [24] 1835 	jc	00105$
      00885F E4               [12] 1836 	clr	a
      008860 C3               [12] 1837 	clr	c
      008861 9E               [12] 1838 	subb	a,r6
      008862 FE               [12] 1839 	mov	r6,a
      008863 74 06            [12] 1840 	mov	a,#0x06
      008865 9F               [12] 1841 	subb	a,r7
      008866 FF               [12] 1842 	mov	r7,a
      008867 C3               [12] 1843 	clr	c
      008868 EE               [12] 1844 	mov	a,r6
      008869 95 2D            [12] 1845 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      00886B EF               [12] 1846 	mov	a,r7
      00886C 95 2E            [12] 1847 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00886E 50 01            [24] 1848 	jnc	00106$
      008870                       1849 00105$:
                                   1850 ;	quantum/dynamic_keymap.c:529: return;
      008870 22               [24] 1851 	ret
      008871                       1852 00106$:
                                   1853 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008871 90 0D F3         [24] 1854 	mov	dptr,#_vial_unlocked
      008874 E0               [24] 1855 	movx	a,@dptr
      008875 60 03            [24] 1856 	jz	00207$
      008877 02 89 85         [24] 1857 	ljmp	00120$
      00887A                       1858 00207$:
                                   1859 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      00887A 90 0B 1D         [24] 1860 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      00887D E4               [12] 1861 	clr	a
      00887E F0               [24] 1862 	movx	@dptr,a
                                   1863 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      00887F 90 0B 1E         [24] 1864 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008882 E5 31            [12] 1865 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008884 F0               [24] 1866 	movx	@dptr,a
                                   1867 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008885 EC               [12] 1868 	mov	a,r4
      008886 30 E0 33         [24] 1869 	jnb	acc.0,00111$
                                   1870 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008889 EA               [12] 1871 	mov	a,r2
      00888A 24 FF            [12] 1872 	add	a,#0xff
      00888C FE               [12] 1873 	mov	r6,a
      00888D EB               [12] 1874 	mov	a,r3
      00888E 34 FF            [12] 1875 	addc	a,#0xff
      008890 FF               [12] 1876 	mov	r7,a
      008891 7D 00            [12] 1877 	mov	r5,#0x00
      008893 12 43 20         [24] 1878 	lcall	_ak820_outline_0116
      008896 8D F0            [24] 1879 	mov	b, r5
      008898 12 40 3F         [24] 1880 	lcall	_eeprom_read_byte
      00889B AE 82            [24] 1881 	mov	r6,dpl
      00889D 7F 00            [12] 1882 	mov	r7,#0x00
      00889F 12 38 75         [24] 1883 	lcall	_ak820_outline_0152
      0088A2 E0               [24] 1884 	movx	a,@dptr
      0088A3 7C 00            [12] 1885 	mov	r4,#0x00
      0088A5 42 07            [12] 1886 	orl	ar7,a
      0088A7 EC               [12] 1887 	mov	a,r4
      0088A8 42 06            [12] 1888 	orl	ar6,a
                                   1889 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      0088AA BF 00 09         [24] 1890 	cjne	r7,#0x00,00109$
      0088AD BE 7C 06         [24] 1891 	cjne	r6,#0x7c,00109$
                                   1892 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      0088B0 12 38 75         [24] 1893 	lcall	_ak820_outline_0152
      0088B3 74 FF            [12] 1894 	mov	a,#0xff
      0088B5 F0               [24] 1895 	movx	@dptr,a
      0088B6                       1896 00109$:
                                   1897 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      0088B6 90 0B 1D         [24] 1898 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      0088B9 74 01            [12] 1899 	mov	a,#0x01
      0088BB F0               [24] 1900 	movx	@dptr,a
      0088BC                       1901 00111$:
                                   1902 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      0088BC 90 0B 1B         [24] 1903 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      0088BF 12 38 00         [24] 1904 	lcall	_ak820_outline_0050
      0088C2 E5 2D            [12] 1905 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0088C4 2E               [12] 1906 	add	a, r6
      0088C5 FE               [12] 1907 	mov	r6,a
      0088C6 E5 2E            [12] 1908 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0088C8 3F               [12] 1909 	addc	a, r7
      0088C9 EE               [12] 1910 	mov	a,r6
      0088CA 30 E0 5A         [24] 1911 	jnb	acc.0,00115$
                                   1912 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      0088CD AE 31            [24] 1913 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      0088CF 7F 00            [12] 1914 	mov	r7,#0x00
      0088D1 EE               [12] 1915 	mov	a,r6
      0088D2 24 FF            [12] 1916 	add	a,#0xff
      0088D4 FC               [12] 1917 	mov	r4,a
      0088D5 EF               [12] 1918 	mov	a,r7
      0088D6 34 FF            [12] 1919 	addc	a,#0xff
      0088D8 FD               [12] 1920 	mov	r5,a
      0088D9 EC               [12] 1921 	mov	a,r4
      0088DA 28               [12] 1922 	add	a, r0
      0088DB F5 82            [12] 1923 	mov	dpl,a
      0088DD ED               [12] 1924 	mov	a,r5
      0088DE 39               [12] 1925 	addc	a, r1
      0088DF F5 83            [12] 1926 	mov	dph,a
      0088E1 E0               [24] 1927 	movx	a,@dptr
      0088E2 FC               [12] 1928 	mov	r4,a
      0088E3 7D 00            [12] 1929 	mov	r5,#0x00
      0088E5 E5 31            [12] 1930 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0088E7 2A               [12] 1931 	add	a, r2
      0088E8 FA               [12] 1932 	mov	r2,a
      0088E9 E4               [12] 1933 	clr	a
      0088EA 3B               [12] 1934 	addc	a, r3
      0088EB FB               [12] 1935 	mov	r3,a
      0088EC C0 00            [24] 1936 	push	ar0
      0088EE C0 01            [24] 1937 	push	ar1
      0088F0 8B 01            [24] 1938 	mov	ar1,r3
      0088F2 7B 00            [12] 1939 	mov	r3,#0x00
      0088F4 8A 82            [24] 1940 	mov	dpl, r2
      0088F6 89 83            [24] 1941 	mov	dph, r1
      0088F8 8B F0            [24] 1942 	mov	b, r3
      0088FA 12 40 3F         [24] 1943 	lcall	_eeprom_read_byte
      0088FD AB 82            [24] 1944 	mov	r3, dpl
      0088FF 7A 00            [12] 1945 	mov	r2,#0x00
      008901 EB               [12] 1946 	mov	a,r3
      008902 12 43 36         [24] 1947 	lcall	_ak820_outline_0139
                                   1948 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008905 BD 00 05         [24] 1949 	cjne	r5,#0x00,00212$
      008908 BC 7C 02         [24] 1950 	cjne	r4,#0x7c,00212$
      00890B 80 06            [24] 1951 	sjmp	00213$
      00890D                       1952 00212$:
      00890D D0 01            [24] 1953 	pop	ar1
      00890F D0 00            [24] 1954 	pop	ar0
      008911 80 0D            [24] 1955 	sjmp	00113$
      008913                       1956 00213$:
      008913 D0 01            [24] 1957 	pop	ar1
      008915 D0 00            [24] 1958 	pop	ar0
                                   1959 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008917 1E               [12] 1960 	dec	r6
      008918 BE FF 01         [24] 1961 	cjne	r6,#0xff,00214$
      00891B 1F               [12] 1962 	dec	r7
      00891C                       1963 00214$:
      00891C EE               [12] 1964 	mov	a,r6
      00891D 12 8D C6         [24] 1965 	lcall	_ak820_outline_0127
      008920                       1966 00113$:
                                   1967 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008920 E5 31            [12] 1968 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008922 14               [12] 1969 	dec	a
      008923 90 0B 1E         [24] 1970 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008926 F0               [24] 1971 	movx	@dptr,a
      008927                       1972 00115$:
                                   1973 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008927 90 0B 1D         [24] 1974 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      00892A E0               [24] 1975 	movx	a,@dptr
      00892B 90 0B 1F         [24] 1976 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      00892E F0               [24] 1977 	movx	@dptr,a
      00892F                       1978 00122$:
      00892F 90 0B 1F         [24] 1979 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008932 E0               [24] 1980 	movx	a,@dptr
      008933 FF               [12] 1981 	mov	r7,a
      008934 90 0B 1E         [24] 1982 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008937 E0               [24] 1983 	movx	a,@dptr
      008938 FE               [12] 1984 	mov	r6,a
      008939 C3               [12] 1985 	clr	c
      00893A EF               [12] 1986 	mov	a,r7
      00893B 9E               [12] 1987 	subb	a,r6
      00893C 50 47            [24] 1988 	jnc	00120$
                                   1989 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      00893E EF               [12] 1990 	mov	a,r7
      00893F 28               [12] 1991 	add	a, r0
      008940 FD               [12] 1992 	mov	r5,a
      008941 E4               [12] 1993 	clr	a
      008942 39               [12] 1994 	addc	a, r1
      008943 12 48 4E         [24] 1995 	lcall	_ak820_outline_0056
      008946 7B 00            [12] 1996 	mov	r3,#0x00
      008948 8C 2E            [24] 1997 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      00894A 8B 2D            [24] 1998 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      00894C 8F 02            [24] 1999 	mov	ar2,r7
      00894E 7F 00            [12] 2000 	mov	r7,#0x00
      008950 74 01            [12] 2001 	mov	a,#0x01
      008952 2A               [12] 2002 	add	a, r2
      008953 FB               [12] 2003 	mov	r3,a
      008954 E4               [12] 2004 	clr	a
      008955 3F               [12] 2005 	addc	a, r7
      008956 FC               [12] 2006 	mov	r4,a
      008957 EB               [12] 2007 	mov	a,r3
      008958 28               [12] 2008 	add	a, r0
      008959 F5 82            [12] 2009 	mov	dpl,a
      00895B EC               [12] 2010 	mov	a,r4
      00895C 39               [12] 2011 	addc	a, r1
      00895D F5 83            [12] 2012 	mov	dph,a
      00895F E0               [24] 2013 	movx	a,@dptr
      008960 FC               [12] 2014 	mov	r4,a
      008961 7B 00            [12] 2015 	mov	r3,#0x00
      008963 E5 2E            [12] 2016 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008965 42 03            [12] 2017 	orl	ar3,a
                                   2018 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008967 BC 00 12         [24] 2019 	cjne	r4,#0x00,00123$
      00896A BB 7C 0F         [24] 2020 	cjne	r3,#0x7c,00123$
                                   2021 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      00896D 12 38 6A         [24] 2022 	lcall	_ak820_outline_0131
      008970 74 FF            [12] 2023 	mov	a,#0xff
      008972 F0               [24] 2024 	movx	@dptr,a
                                   2025 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008973 0A               [12] 2026 	inc	r2
      008974 BA 00 01         [24] 2027 	cjne	r2,#0x00,00218$
      008977 0F               [12] 2028 	inc	r7
      008978                       2029 00218$:
      008978 EA               [12] 2030 	mov	a,r2
      008979 12 8D C6         [24] 2031 	lcall	_ak820_outline_0127
      00897C                       2032 00123$:
                                   2033 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      00897C 90 0B 1F         [24] 2034 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      00897F E0               [24] 2035 	movx	a,@dptr
      008980 24 02            [12] 2036 	add	a,#0x02
      008982 F0               [24] 2037 	movx	@dptr,a
      008983 80 AA            [24] 2038 	sjmp	00122$
      008985                       2039 00120$:
                                   2040 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008985 90 0B 1B         [24] 2041 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008988 12 38 00         [24] 2042 	lcall	_ak820_outline_0050
      00898B 74 40            [12] 2043 	mov	a,#0x40
      00898D 12 43 30         [24] 2044 	lcall	_ak820_outline_0134
      008990 90 05 8A         [24] 2045 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008993 12 48 56         [24] 2046 	lcall	_ak820_outline_0058
      008996 E4               [12] 2047 	clr	a
      008997 A3               [24] 2048 	inc	dptr
      008998 F0               [24] 2049 	movx	@dptr,a
      008999 90 05 8D         [24] 2050 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00899C E5 2F            [12] 2051 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      00899E F0               [24] 2052 	movx	@dptr,a
      00899F E5 30            [12] 2053 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      0089A1 A3               [24] 2054 	inc	dptr
      0089A2 F0               [24] 2055 	movx	@dptr,a
      0089A3 12 38 75         [24] 2056 	lcall	_ak820_outline_0152
                                   2057 ;	quantum/dynamic_keymap.c:584: }
      0089A6 02 41 06         [24] 2058 	ljmp	_ak820_eeprom_write_block_xdata
                                   2059 ;------------------------------------------------------------
                                   2060 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2061 ;------------------------------------------------------------
                                   2062 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2063 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2064 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_437'
                                   2065 ;------------------------------------------------------------
                                   2066 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2067 ;	-----------------------------------------
                                   2068 ;	 function keycode_at_keymap_location
                                   2069 ;	-----------------------------------------
      0089A9                       2070 _keycode_at_keymap_location:
      0089A9 E5 82            [12] 2071 	mov	a,dpl
      0089AB 90 0B 22         [24] 2072 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_437
      0089AE F0               [24] 2073 	movx	@dptr,a
                                   2074 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      0089AF E0               [24] 2075 	movx	a,@dptr
      0089B0 FF               [12] 2076 	mov	r7,a
      0089B1 BF 06 00         [24] 2077 	cjne	r7,#0x06,00128$
      0089B4                       2078 00128$:
      0089B4 50 23            [24] 2079 	jnc	00102$
      0089B6 90 0B 20         [24] 2080 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      0089B9 E0               [24] 2081 	movx	a,@dptr
      0089BA FE               [12] 2082 	mov	r6,a
      0089BB BE 10 00         [24] 2083 	cjne	r6,#0x10,00130$
      0089BE                       2084 00130$:
      0089BE 50 19            [24] 2085 	jnc	00102$
      0089C0 90 0B 21         [24] 2086 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      0089C3 E0               [24] 2087 	movx	a,@dptr
      0089C4 FD               [12] 2088 	mov	r5,a
      0089C5 BD 08 00         [24] 2089 	cjne	r5,#0x08,00132$
      0089C8                       2090 00132$:
      0089C8 50 0F            [24] 2091 	jnc	00102$
                                   2092 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      0089CA 90 0A D4         [24] 2093 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0089CD EE               [12] 2094 	mov	a,r6
      0089CE F0               [24] 2095 	movx	@dptr,a
      0089CF 90 0A D5         [24] 2096 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0089D2 ED               [12] 2097 	mov	a,r5
      0089D3 F0               [24] 2098 	movx	@dptr,a
      0089D4 8F 82            [24] 2099 	mov	dpl, r7
      0089D6 02 83 3B         [24] 2100 	ljmp	_dynamic_keymap_get_keycode
      0089D9                       2101 00102$:
                                   2102 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      0089D9 90 00 00         [24] 2103 	mov	dptr,#0x0000
                                   2104 ;	quantum/dynamic_keymap.c:591: }
      0089DC 22               [24] 2105 	ret
                                   2106 ;------------------------------------------------------------
                                   2107 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2108 ;------------------------------------------------------------
                                   2109 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2110 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2111 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_441'
                                   2112 ;------------------------------------------------------------
                                   2113 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2114 ;	-----------------------------------------
                                   2115 ;	 function keycode_at_encodermap_location
                                   2116 ;	-----------------------------------------
      0089DD                       2117 _keycode_at_encodermap_location:
      0089DD E5 82            [12] 2118 	mov	a,dpl
      0089DF 90 0B 25         [24] 2119 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_441
      0089E2 F0               [24] 2120 	movx	@dptr,a
                                   2121 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      0089E3 E0               [24] 2122 	movx	a,@dptr
      0089E4 FF               [12] 2123 	mov	r7,a
      0089E5 BF 06 00         [24] 2124 	cjne	r7,#0x06,00120$
      0089E8                       2125 00120$:
      0089E8 50 1E            [24] 2126 	jnc	00102$
      0089EA 90 0B 23         [24] 2127 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      0089ED E0               [24] 2128 	movx	a,@dptr
      0089EE FE               [12] 2129 	mov	r6,a
      0089EF BE 01 00         [24] 2130 	cjne	r6,#0x01,00122$
      0089F2                       2131 00122$:
      0089F2 50 14            [24] 2132 	jnc	00102$
                                   2133 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      0089F4 90 0B 24         [24] 2134 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      0089F7 E0               [24] 2135 	movx	a,@dptr
      0089F8 FE               [12] 2136 	mov	r6,a
      0089F9 90 0A DE         [24] 2137 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0089FC E4               [12] 2138 	clr	a
      0089FD F0               [24] 2139 	movx	@dptr,a
      0089FE 90 0A DF         [24] 2140 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008A01 EE               [12] 2141 	mov	a,r6
      008A02 F0               [24] 2142 	movx	@dptr,a
      008A03 8F 82            [24] 2143 	mov	dpl, r7
      008A05 02 83 FC         [24] 2144 	ljmp	_dynamic_keymap_get_encoder
      008A08                       2145 00102$:
                                   2146 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008A08 90 00 00         [24] 2147 	mov	dptr,#0x0000
                                   2148 ;	quantum/dynamic_keymap.c:599: }
      008A0B 22               [24] 2149 	ret
                                   2150 ;------------------------------------------------------------
                                   2151 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2152 ;------------------------------------------------------------
                                   2153 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2154 ;	-----------------------------------------
                                   2155 ;	 function dynamic_keymap_macro_get_count
                                   2156 ;	-----------------------------------------
      008A0C                       2157 _dynamic_keymap_macro_get_count:
                                   2158 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008A0C 75 82 10         [24] 2159 	mov	dpl, #0x10
                                   2160 ;	quantum/dynamic_keymap.c:604: }
      008A0F 22               [24] 2161 	ret
                                   2162 ;------------------------------------------------------------
                                   2163 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2164 ;------------------------------------------------------------
                                   2165 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2166 ;	-----------------------------------------
                                   2167 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2168 ;	-----------------------------------------
      008A10                       2169 _dynamic_keymap_macro_get_buffer_size:
                                   2170 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008A10 90 20 00         [24] 2171 	mov	dptr,#0x2000
                                   2172 ;	quantum/dynamic_keymap.c:608: }
      008A13 22               [24] 2173 	ret
                                   2174 ;------------------------------------------------------------
                                   2175 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2176 ;------------------------------------------------------------
                                   2177 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2178 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2179 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2180 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_449'
                                   2181 ;------------------------------------------------------------
                                   2182 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2183 ;	-----------------------------------------
                                   2184 ;	 function dynamic_keymap_macro_get_buffer
                                   2185 ;	-----------------------------------------
      008A14                       2186 _dynamic_keymap_macro_get_buffer:
      008A14 12 38 43         [24] 2187 	lcall	_ak820_outline_0103
      008A17 90 0B 2B         [24] 2188 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008A1A 12 38 48         [24] 2189 	lcall	_ak820_outline_0104
                                   2190 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008A1D 12 2B 2B         [24] 2191 	lcall	_ak820_macro_length
      008A20 12 43 2B         [24] 2192 	lcall	_ak820_outline_0132
      008A23 90 0B 2B         [24] 2193 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008A26 12 38 1F         [24] 2194 	lcall	_ak820_outline_0059
      008A29 90 0B 26         [24] 2195 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008A2C E0               [24] 2196 	movx	a,@dptr
      008A2D F5 32            [12] 2197 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008A2F A3               [24] 2198 	inc	dptr
      008A30 E0               [24] 2199 	movx	a,@dptr
      008A31 F5 33            [12] 2200 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008A33 90 0B 28         [24] 2201 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008A36 12 38 3D         [24] 2202 	lcall	_ak820_outline_0099
      008A39 A3               [24] 2203 	inc	dptr
      008A3A E0               [24] 2204 	movx	a,@dptr
      008A3B FB               [12] 2205 	mov	r3,a
      008A3C 90 0B 03         [24] 2206 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008A3F 12 48 56         [24] 2207 	lcall	_ak820_outline_0058
      008A42 90 0B 05         [24] 2208 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008A45 12 38 25         [24] 2209 	lcall	_ak820_outline_0070
      008A48 90 0B 07         [24] 2210 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008A4B E5 32            [12] 2211 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008A4D F0               [24] 2212 	movx	@dptr,a
      008A4E E5 33            [12] 2213 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008A50 A3               [24] 2214 	inc	dptr
      008A51 F0               [24] 2215 	movx	@dptr,a
      008A52 90 0B 09         [24] 2216 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008A55 E8               [12] 2217 	mov	a,r0
      008A56 F0               [24] 2218 	movx	@dptr,a
      008A57 E9               [12] 2219 	mov	a,r1
      008A58 A3               [24] 2220 	inc	dptr
      008A59 F0               [24] 2221 	movx	@dptr,a
      008A5A EB               [12] 2222 	mov	a,r3
      008A5B A3               [24] 2223 	inc	dptr
      008A5C F0               [24] 2224 	movx	@dptr,a
      008A5D 90 08 00         [24] 2225 	mov	dptr,#0x0800
                                   2226 ;	quantum/dynamic_keymap.c:635: }
      008A60 02 87 25         [24] 2227 	ljmp	_ak820_dynamic_read_buffer
                                   2228 ;------------------------------------------------------------
                                   2229 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2230 ;------------------------------------------------------------
                                   2231 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2232 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2233 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_451'
                                   2234 ;------------------------------------------------------------
                                   2235 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2236 ;	-----------------------------------------
                                   2237 ;	 function dynamic_keymap_macro_set_buffer
                                   2238 ;	-----------------------------------------
      008A63                       2239 _dynamic_keymap_macro_set_buffer:
      008A63 12 38 43         [24] 2240 	lcall	_ak820_outline_0103
      008A66 90 0B 32         [24] 2241 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008A69 12 38 48         [24] 2242 	lcall	_ak820_outline_0104
                                   2243 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      008A6C 90 0B 32         [24] 2244 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008A6F 12 38 00         [24] 2245 	lcall	_ak820_outline_0050
      008A72 90 0B 2D         [24] 2246 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008A75 12 38 1F         [24] 2247 	lcall	_ak820_outline_0059
      008A78 90 0B 2F         [24] 2248 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008A7B 12 4E DB         [24] 2249 	lcall	_ak820_outline_0086
      008A7E 90 05 10         [24] 2250 	mov	dptr,#_ak820_macro_write_PARM_2
      008A81 12 38 25         [24] 2251 	lcall	_ak820_outline_0070
      008A84 90 05 12         [24] 2252 	mov	dptr,#_ak820_macro_write_PARM_3
      008A87 E9               [12] 2253 	mov	a,r1
      008A88 12 4E F4         [24] 2254 	lcall	_ak820_outline_0151
      008A8B 12 43 02         [24] 2255 	lcall	_ak820_outline_0060
                                   2256 ;	quantum/dynamic_keymap.c:640: }
      008A8E 02 2B 45         [24] 2257 	ljmp	_ak820_macro_write
                                   2258 ;------------------------------------------------------------
                                   2259 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2260 ;------------------------------------------------------------
                                   2261 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2262 ;	-----------------------------------------
                                   2263 ;	 function dynamic_keymap_macro_reset
                                   2264 ;	-----------------------------------------
      008A91                       2265 _dynamic_keymap_macro_reset:
                                   2266 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2267 ;	quantum/dynamic_keymap.c:666: }
      008A91 02 2E 64         [24] 2268 	ljmp	_ak820_macro_reset
                                   2269 ;------------------------------------------------------------
                                   2270 ;Allocation info for local variables in function 'decode_keycode'
                                   2271 ;------------------------------------------------------------
                                   2272 ;kc            Allocated with name '_decode_keycode_kc_10000_455'
                                   2273 ;------------------------------------------------------------
                                   2274 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2275 ;	-----------------------------------------
                                   2276 ;	 function decode_keycode
                                   2277 ;	-----------------------------------------
      008A94                       2278 _decode_keycode:
      008A94 12 38 43         [24] 2279 	lcall	_ak820_outline_0103
      008A97 90 0B 34         [24] 2280 	mov	dptr,#_decode_keycode_kc_10000_455
      008A9A 12 38 48         [24] 2281 	lcall	_ak820_outline_0104
                                   2282 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      008A9D 90 0B 34         [24] 2283 	mov	dptr,#_decode_keycode_kc_10000_455
      008AA0 12 37 CB         [24] 2284 	lcall	_ak820_outline_0010
      008AA3 C3               [12] 2285 	clr	c
      008AA4 E4               [12] 2286 	clr	a
      008AA5 9C               [12] 2287 	subb	a,r4
      008AA6 74 FF            [12] 2288 	mov	a,#0xff
      008AA8 9D               [12] 2289 	subb	a,r5
      008AA9 50 08            [24] 2290 	jnc	00102$
                                   2291 ;	free result
                                   2292 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      008AAB 8C 05            [24] 2293 	mov	ar5,r4
      008AAD 7C 00            [12] 2294 	mov	r4,#0x00
      008AAF 12 38 60         [24] 2295 	lcall	_ak820_outline_0121
      008AB2 22               [24] 2296 	ret
      008AB3                       2297 00102$:
                                   2298 ;	quantum/dynamic_keymap.c:672: return kc;
      008AB3 12 43 20         [24] 2299 	lcall	_ak820_outline_0116
                                   2300 ;	quantum/dynamic_keymap.c:673: }
      008AB6 22               [24] 2301 	ret
                                   2302 ;------------------------------------------------------------
                                   2303 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2304 ;------------------------------------------------------------
                                   2305 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_458'
                                   2306 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_459'
                                   2307 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_464'
                                   2308 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_465'
                                   2309 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_471'
                                   2310 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_489'
                                   2311 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_493'
                                   2312 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_493'
                                   2313 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_495'
                                   2314 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_497'
                                   2315 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_501'
                                   2316 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_503'
                                   2317 ;------------------------------------------------------------
                                   2318 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2319 ;	-----------------------------------------
                                   2320 ;	 function dynamic_keymap_macro_send
                                   2321 ;	-----------------------------------------
      008AB7                       2322 _dynamic_keymap_macro_send:
      008AB7 E5 82            [12] 2323 	mov	a,dpl
      008AB9 90 0B 36         [24] 2324 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008ABC F0               [24] 2325 	movx	@dptr,a
                                   2326 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      008ABD 90 0B 37         [24] 2327 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008AC0 E0               [24] 2328 	movx	a,@dptr
      008AC1 60 01            [24] 2329 	jz	00102$
      008AC3 22               [24] 2330 	ret
      008AC4                       2331 00102$:
                                   2332 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008AC4 90 0B 36         [24] 2333 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008AC7 E0               [24] 2334 	movx	a,@dptr
      008AC8 FF               [12] 2335 	mov	r7,a
      008AC9 BF 10 00         [24] 2336 	cjne	r7,#0x10,00422$
      008ACC                       2337 00422$:
      008ACC 40 01            [24] 2338 	jc	00104$
                                   2339 ;	quantum/dynamic_keymap.c:683: return;
      008ACE 22               [24] 2340 	ret
      008ACF                       2341 00104$:
                                   2342 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      008ACF C0 07            [24] 2343 	push	ar7
      008AD1 12 2A F2         [24] 2344 	lcall	_ak820_macro_ready
      008AD4 E5 82            [12] 2345 	mov	a, dpl
      008AD6 D0 07            [24] 2346 	pop	ar7
      008AD8 70 01            [24] 2347 	jnz	00106$
      008ADA 22               [24] 2348 	ret
      008ADB                       2349 00106$:
                                   2350 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008ADB 90 0B 38         [24] 2351 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008ADE E4               [12] 2352 	clr	a
      008ADF F0               [24] 2353 	movx	@dptr,a
      008AE0 74 08            [12] 2354 	mov	a,#0x08
      008AE2 A3               [24] 2355 	inc	dptr
      008AE3 F0               [24] 2356 	movx	@dptr,a
                                   2357 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008AE4 C0 07            [24] 2358 	push	ar7
      008AE6 12 2B 2B         [24] 2359 	lcall	_ak820_macro_length
      008AE9 AD 82            [24] 2360 	mov	r5, dpl
      008AEB AE 83            [24] 2361 	mov	r6, dph
      008AED D0 07            [24] 2362 	pop	ar7
      008AEF 74 08            [12] 2363 	mov	a,#0x08
      008AF1 2E               [12] 2364 	add	a, r6
      008AF2 FE               [12] 2365 	mov	r6,a
                                   2366 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      008AF3 7B 00            [12] 2367 	mov	r3,#0x00
      008AF5 7C 08            [12] 2368 	mov	r4,#0x08
      008AF7                       2369 00111$:
      008AF7 EF               [12] 2370 	mov	a,r7
      008AF8 60 31            [24] 2371 	jz	00113$
                                   2372 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008AFA EB               [12] 2373 	mov	a,r3
      008AFB B5 05 05         [24] 2374 	cjne	a,ar5,00108$
      008AFE EC               [12] 2375 	mov	a,r4
      008AFF B5 06 01         [24] 2376 	cjne	a,ar6,00108$
                                   2377 ;	quantum/dynamic_keymap.c:717: return;
      008B02 22               [24] 2378 	ret
      008B03                       2379 00108$:
                                   2380 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008B03 8B 01            [24] 2381 	mov	ar1,r3
      008B05 8C 02            [24] 2382 	mov	ar2,r4
      008B07 8A 00            [24] 2383 	mov	ar0,r2
      008B09 7A 00            [12] 2384 	mov	r2,#0x00
      008B0B 89 82            [24] 2385 	mov	dpl, r1
      008B0D 88 83            [24] 2386 	mov	dph, r0
      008B0F 8A F0            [24] 2387 	mov	b, r2
      008B11 12 40 3F         [24] 2388 	lcall	_eeprom_read_byte
      008B14 E5 82            [12] 2389 	mov	a, dpl
      008B16 70 06            [24] 2390 	jnz	00110$
                                   2391 ;	quantum/dynamic_keymap.c:720: --id;
      008B18 1F               [12] 2392 	dec	r7
      008B19 90 0B 36         [24] 2393 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008B1C EF               [12] 2394 	mov	a,r7
      008B1D F0               [24] 2395 	movx	@dptr,a
      008B1E                       2396 00110$:
                                   2397 ;	quantum/dynamic_keymap.c:722: ++p;
      008B1E 0B               [12] 2398 	inc	r3
      008B1F BB 00 01         [24] 2399 	cjne	r3,#0x00,00429$
      008B22 0C               [12] 2400 	inc	r4
      008B23                       2401 00429$:
      008B23 90 0B 38         [24] 2402 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008B26 12 38 2B         [24] 2403 	lcall	_ak820_outline_0075
      008B29 80 CC            [24] 2404 	sjmp	00111$
      008B2B                       2405 00113$:
                                   2406 ;	quantum/dynamic_keymap.c:728: sending = true;
      008B2B 90 0B 37         [24] 2407 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008B2E 74 01            [12] 2408 	mov	a,#0x01
      008B30 F0               [24] 2409 	movx	@dptr,a
                                   2410 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      008B31 12 8D DE         [24] 2411 	lcall	_ak820_outline_0160
      008B34 90 09 80         [24] 2412 	mov	dptr,#_ak820_macro_cancelled
      008B37 F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      008B38 90 0B 3A         [24] 2415 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008B3B F0               [24] 2416 	movx	@dptr,a
      008B3C 90 0B 3B         [24] 2417 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008B3F F0               [24] 2418 	movx	@dptr,a
      008B40 90 0B 3C         [24] 2419 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008B43 F0               [24] 2420 	movx	@dptr,a
      008B44 90 0B 3D         [24] 2421 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008B47 F0               [24] 2422 	movx	@dptr,a
                                   2423 ;	quantum/dynamic_keymap.c:738: while (p < end
      008B48                       2424 00167$:
                                   2425 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      008B48 90 0B 38         [24] 2426 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008B4B E0               [24] 2427 	movx	a,@dptr
      008B4C FC               [12] 2428 	mov	r4,a
      008B4D A3               [24] 2429 	inc	dptr
      008B4E E0               [24] 2430 	movx	a,@dptr
      008B4F FF               [12] 2431 	mov	r7,a
      008B50 C3               [12] 2432 	clr	c
      008B51 EC               [12] 2433 	mov	a,r4
      008B52 9D               [12] 2434 	subb	a,r5
      008B53 EF               [12] 2435 	mov	a,r7
      008B54 9E               [12] 2436 	subb	a,r6
      008B55 40 03            [24] 2437 	jc	00430$
      008B57 02 8D 6C         [24] 2438 	ljmp	00169$
      008B5A                       2439 00430$:
      008B5A 90 09 80         [24] 2440 	mov	dptr,#_ak820_macro_cancelled
      008B5D E0               [24] 2441 	movx	a,@dptr
      008B5E 60 03            [24] 2442 	jz	00431$
      008B60 02 8D 6C         [24] 2443 	ljmp	00169$
      008B63                       2444 00431$:
                                   2445 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008B63 8C 02            [24] 2446 	mov	ar2,r4
      008B65 8F 03            [24] 2447 	mov	ar3,r7
      008B67 90 0B 38         [24] 2448 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008B6A 74 01            [12] 2449 	mov	a,#0x01
      008B6C 2C               [12] 2450 	add	a, r4
      008B6D F0               [24] 2451 	movx	@dptr,a
      008B6E E4               [12] 2452 	clr	a
      008B6F 3F               [12] 2453 	addc	a, r7
      008B70 A3               [24] 2454 	inc	dptr
      008B71 F0               [24] 2455 	movx	@dptr,a
      008B72 7F 00            [12] 2456 	mov	r7,#0x00
      008B74 12 43 3C         [24] 2457 	lcall	_ak820_outline_0140
      008B77 8F F0            [24] 2458 	mov	b, r7
      008B79 12 40 3F         [24] 2459 	lcall	_eeprom_read_byte
      008B7C AF 82            [24] 2460 	mov	r7, dpl
      008B7E 90 0B 3A         [24] 2461 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008B81 EF               [12] 2462 	mov	a,r7
      008B82 F0               [24] 2463 	movx	@dptr,a
                                   2464 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      008B83 90 0B 3B         [24] 2465 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008B86 E4               [12] 2466 	clr	a
      008B87 F0               [24] 2467 	movx	@dptr,a
                                   2468 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      008B88 90 0B 3A         [24] 2469 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008B8B E0               [24] 2470 	movx	a,@dptr
      008B8C 70 03            [24] 2471 	jnz	00432$
      008B8E 02 8D 6C         [24] 2472 	ljmp	00169$
      008B91                       2473 00432$:
                                   2474 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      008B91 90 0B 3A         [24] 2475 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008B94 E0               [24] 2476 	movx	a,@dptr
      008B95 FF               [12] 2477 	mov	r7,a
      008B96 BF 01 02         [24] 2478 	cjne	r7,#0x01,00433$
      008B99 80 03            [24] 2479 	sjmp	00434$
      008B9B                       2480 00433$:
      008B9B 02 8D 4E         [24] 2481 	ljmp	00164$
      008B9E                       2482 00434$:
                                   2483 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008B9E 12 8D 74         [24] 2484 	lcall	_ak820_outline_0000
      008BA1 12 40 3F         [24] 2485 	lcall	_eeprom_read_byte
      008BA4 AF 82            [24] 2486 	mov	r7, dpl
      008BA6 90 0B 3B         [24] 2487 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008BA9 EF               [12] 2488 	mov	a,r7
      008BAA F0               [24] 2489 	movx	@dptr,a
                                   2490 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      008BAB EF               [12] 2491 	mov	a,r7
      008BAC 70 03            [24] 2492 	jnz	00435$
      008BAE 02 8D 6C         [24] 2493 	ljmp	00169$
      008BB1                       2494 00435$:
                                   2495 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008BB1 12 8D AC         [24] 2496 	lcall	_ak820_outline_0088
      008BB4 BF 01 02         [24] 2497 	cjne	r7,#0x01,00436$
      008BB7 80 13            [24] 2498 	sjmp	00151$
      008BB9                       2499 00436$:
      008BB9 12 8D AC         [24] 2500 	lcall	_ak820_outline_0088
      008BBC BF 02 02         [24] 2501 	cjne	r7,#0x02,00437$
      008BBF 80 0B            [24] 2502 	sjmp	00151$
      008BC1                       2503 00437$:
      008BC1 12 8D AC         [24] 2504 	lcall	_ak820_outline_0088
      008BC4 BF 03 02         [24] 2505 	cjne	r7,#0x03,00438$
      008BC7 80 03            [24] 2506 	sjmp	00439$
      008BC9                       2507 00438$:
      008BC9 02 8C 2D         [24] 2508 	ljmp	00152$
      008BCC                       2509 00439$:
      008BCC                       2510 00151$:
                                   2511 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008BCC 12 8D 74         [24] 2512 	lcall	_ak820_outline_0000
      008BCF 12 40 3F         [24] 2513 	lcall	_eeprom_read_byte
      008BD2 12 8D F6         [24] 2514 	lcall	_ak820_outline_0177
                                   2515 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      008BD5 70 03            [24] 2516 	jnz	00440$
      008BD7 02 8B 48         [24] 2517 	ljmp	00167$
      008BDA                       2518 00440$:
                                   2519 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008BDA 12 8D AC         [24] 2520 	lcall	_ak820_outline_0088
      008BDD BF 01 03         [24] 2521 	cjne	r7,#0x01,00441$
      008BE0 D3               [12] 2522 	setb	c
      008BE1 80 01            [24] 2523 	sjmp	00442$
      008BE3                       2524 00441$:
      008BE3 C3               [12] 2525 	clr	c
      008BE4                       2526 00442$:
      008BE4 92 24            [24] 2527 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008BE6 90 09 7F         [24] 2528 	mov	dptr,#_ak820_macro_primitive
      008BE9 B3               [12] 2529 	cpl	c
      008BEA E4               [12] 2530 	clr	a
      008BEB 33               [12] 2531 	rlc	a
      008BEC F0               [24] 2532 	movx	@dptr,a
                                   2533 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008BED 12 8D AC         [24] 2534 	lcall	_ak820_outline_0088
      008BF0 BF 01 10         [24] 2535 	cjne	r7,#0x01,00122$
      008BF3 12 8D D7         [24] 2536 	lcall	_ak820_outline_0147
      008BF6 C0 06            [24] 2537 	push	ar6
      008BF8 C0 05            [24] 2538 	push	ar5
      008BFA 12 75 60         [24] 2539 	lcall	_tap_code
      008BFD D0 05            [24] 2540 	pop	ar5
      008BFF D0 06            [24] 2541 	pop	ar6
      008C01 80 24            [24] 2542 	sjmp	00123$
      008C03                       2543 00122$:
                                   2544 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008C03 12 8D AC         [24] 2545 	lcall	_ak820_outline_0088
      008C06 BF 02 10         [24] 2546 	cjne	r7,#0x02,00119$
      008C09 12 8D D7         [24] 2547 	lcall	_ak820_outline_0147
      008C0C C0 06            [24] 2548 	push	ar6
      008C0E C0 05            [24] 2549 	push	ar5
      008C10 12 74 5A         [24] 2550 	lcall	_register_code
      008C13 D0 05            [24] 2551 	pop	ar5
      008C15 D0 06            [24] 2552 	pop	ar6
      008C17 80 0E            [24] 2553 	sjmp	00123$
      008C19                       2554 00119$:
                                   2555 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      008C19 12 8D D7         [24] 2556 	lcall	_ak820_outline_0147
      008C1C C0 06            [24] 2557 	push	ar6
      008C1E C0 05            [24] 2558 	push	ar5
      008C20 12 74 C7         [24] 2559 	lcall	_unregister_code
      008C23 D0 05            [24] 2560 	pop	ar5
      008C25 D0 06            [24] 2561 	pop	ar6
      008C27                       2562 00123$:
                                   2563 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      008C27 12 8D DE         [24] 2564 	lcall	_ak820_outline_0160
      008C2A 02 8B 48         [24] 2565 	ljmp	00167$
      008C2D                       2566 00152$:
                                   2567 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008C2D 12 8D AC         [24] 2568 	lcall	_ak820_outline_0088
      008C30 BF 05 02         [24] 2569 	cjne	r7,#0x05,00447$
      008C33 80 13            [24] 2570 	sjmp	00146$
      008C35                       2571 00447$:
      008C35 12 8D AC         [24] 2572 	lcall	_ak820_outline_0088
      008C38 BF 06 02         [24] 2573 	cjne	r7,#0x06,00448$
      008C3B 80 0B            [24] 2574 	sjmp	00146$
      008C3D                       2575 00448$:
      008C3D 12 8D AC         [24] 2576 	lcall	_ak820_outline_0088
      008C40 BF 07 02         [24] 2577 	cjne	r7,#0x07,00449$
      008C43 80 03            [24] 2578 	sjmp	00450$
      008C45                       2579 00449$:
      008C45 02 8C EE         [24] 2580 	ljmp	00147$
      008C48                       2581 00450$:
      008C48                       2582 00146$:
                                   2583 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008C48 12 8D 74         [24] 2584 	lcall	_ak820_outline_0000
      008C4B 12 40 3F         [24] 2585 	lcall	_eeprom_read_byte
      008C4E 12 8D F6         [24] 2586 	lcall	_ak820_outline_0177
                                   2587 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      008C51 70 03            [24] 2588 	jnz	00451$
      008C53 02 8B 48         [24] 2589 	ljmp	00167$
      008C56                       2590 00451$:
                                   2591 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008C56 12 8D 74         [24] 2592 	lcall	_ak820_outline_0000
      008C59 12 40 3F         [24] 2593 	lcall	_eeprom_read_byte
      008C5C AF 82            [24] 2594 	mov	r7, dpl
      008C5E 90 0B 3D         [24] 2595 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008C61 EF               [12] 2596 	mov	a,r7
      008C62 F0               [24] 2597 	movx	@dptr,a
                                   2598 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      008C63 EF               [12] 2599 	mov	a,r7
      008C64 70 03            [24] 2600 	jnz	00452$
      008C66 02 8B 48         [24] 2601 	ljmp	00167$
      008C69                       2602 00452$:
                                   2603 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008C69 90 0B 3C         [24] 2604 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008C6C E0               [24] 2605 	movx	a,@dptr
      008C6D FF               [12] 2606 	mov	r7,a
      008C6E 90 0B 3D         [24] 2607 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008C71 E0               [24] 2608 	movx	a,@dptr
      008C72 FB               [12] 2609 	mov	r3,a
      008C73 E4               [12] 2610 	clr	a
      008C74 FC               [12] 2611 	mov	r4,a
      008C75 FA               [12] 2612 	mov	r2,a
      008C76 EF               [12] 2613 	mov	a,r7
      008C77 42 04            [12] 2614 	orl	ar4,a
      008C79 EA               [12] 2615 	mov	a,r2
      008C7A 42 03            [12] 2616 	orl	ar3,a
                                   2617 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      008C7C 12 43 5C         [24] 2618 	lcall	_ak820_outline_0180
      008C7F C0 06            [24] 2619 	push	ar6
      008C81 C0 05            [24] 2620 	push	ar5
      008C83 12 8A 94         [24] 2621 	lcall	_decode_keycode
      008C86 AC 82            [24] 2622 	mov	r4, dpl
      008C88 AF 83            [24] 2623 	mov	r7, dph
      008C8A D0 05            [24] 2624 	pop	ar5
      008C8C D0 06            [24] 2625 	pop	ar6
                                   2626 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008C8E 90 0B 3B         [24] 2627 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008C91 E0               [24] 2628 	movx	a,@dptr
      008C92 FB               [12] 2629 	mov	r3,a
      008C93 BB 05 03         [24] 2630 	cjne	r3,#0x05,00453$
      008C96 D3               [12] 2631 	setb	c
      008C97 80 01            [24] 2632 	sjmp	00454$
      008C99                       2633 00453$:
      008C99 C3               [12] 2634 	clr	c
      008C9A                       2635 00454$:
      008C9A 92 24            [24] 2636 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008C9C 90 09 7F         [24] 2637 	mov	dptr,#_ak820_macro_primitive
      008C9F B3               [12] 2638 	cpl	c
      008CA0 E4               [12] 2639 	clr	a
      008CA1 33               [12] 2640 	rlc	a
      008CA2 F0               [24] 2641 	movx	@dptr,a
                                   2642 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      008CA3 90 0B 3B         [24] 2643 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008CA6 E0               [24] 2644 	movx	a,@dptr
      008CA7 FB               [12] 2645 	mov	r3,a
      008CA8 BB 05 02         [24] 2646 	cjne	r3,#0x05,00455$
      008CAB 80 0A            [24] 2647 	sjmp	00126$
      008CAD                       2648 00455$:
      008CAD BB 06 02         [24] 2649 	cjne	r3,#0x06,00456$
      008CB0 80 16            [24] 2650 	sjmp	00127$
      008CB2                       2651 00456$:
                                   2652 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      008CB2 BB 07 33         [24] 2653 	cjne	r3,#0x07,00129$
      008CB5 80 22            [24] 2654 	sjmp	00128$
      008CB7                       2655 00126$:
                                   2656 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      008CB7 8C 82            [24] 2657 	mov	dpl, r4
      008CB9 8F 83            [24] 2658 	mov	dph, r7
      008CBB C0 06            [24] 2659 	push	ar6
      008CBD C0 05            [24] 2660 	push	ar5
      008CBF 12 B0 67         [24] 2661 	lcall	_vial_keycode_tap
      008CC2 D0 05            [24] 2662 	pop	ar5
      008CC4 D0 06            [24] 2663 	pop	ar6
                                   2664 ;	quantum/dynamic_keymap.c:795: break;
                                   2665 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      008CC6 80 20            [24] 2666 	sjmp	00129$
      008CC8                       2667 00127$:
                                   2668 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      008CC8 8C 82            [24] 2669 	mov	dpl, r4
      008CCA 8F 83            [24] 2670 	mov	dph, r7
      008CCC C0 06            [24] 2671 	push	ar6
      008CCE C0 05            [24] 2672 	push	ar5
      008CD0 12 AF 9C         [24] 2673 	lcall	_vial_keycode_down
      008CD3 D0 05            [24] 2674 	pop	ar5
      008CD5 D0 06            [24] 2675 	pop	ar6
                                   2676 ;	quantum/dynamic_keymap.c:798: break;
                                   2677 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      008CD7 80 0F            [24] 2678 	sjmp	00129$
      008CD9                       2679 00128$:
                                   2680 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      008CD9 8C 82            [24] 2681 	mov	dpl, r4
      008CDB 8F 83            [24] 2682 	mov	dph, r7
      008CDD C0 06            [24] 2683 	push	ar6
      008CDF C0 05            [24] 2684 	push	ar5
      008CE1 12 B0 02         [24] 2685 	lcall	_vial_keycode_up
      008CE4 D0 05            [24] 2686 	pop	ar5
      008CE6 D0 06            [24] 2687 	pop	ar6
                                   2688 ;	quantum/dynamic_keymap.c:802: }
      008CE8                       2689 00129$:
                                   2690 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      008CE8 12 8D DE         [24] 2691 	lcall	_ak820_outline_0160
      008CEB 02 8B 48         [24] 2692 	ljmp	00167$
      008CEE                       2693 00147$:
                                   2694 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      008CEE 12 8D AC         [24] 2695 	lcall	_ak820_outline_0088
      008CF1 BF 04 02         [24] 2696 	cjne	r7,#0x04,00458$
      008CF4 80 03            [24] 2697 	sjmp	00459$
      008CF6                       2698 00458$:
      008CF6 02 8B 48         [24] 2699 	ljmp	00167$
      008CF9                       2700 00459$:
                                   2701 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008CF9 12 8D 74         [24] 2702 	lcall	_ak820_outline_0000
      008CFC 12 40 3F         [24] 2703 	lcall	_eeprom_read_byte
      008CFF AF 82            [24] 2704 	mov	r7, dpl
                                   2705 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008D01 90 0B 38         [24] 2706 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008D04 12 38 5A         [24] 2707 	lcall	_ak820_outline_0120
      008D07 90 0B 38         [24] 2708 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008D0A 74 01            [12] 2709 	mov	a,#0x01
      008D0C 2B               [12] 2710 	add	a, r3
      008D0D F0               [24] 2711 	movx	@dptr,a
      008D0E E4               [12] 2712 	clr	a
      008D0F 3C               [12] 2713 	addc	a, r4
      008D10 A3               [24] 2714 	inc	dptr
      008D11 F0               [24] 2715 	movx	@dptr,a
      008D12 7A 00            [12] 2716 	mov	r2,#0x00
      008D14 12 33 FC         [24] 2717 	lcall	_ak820_outline_0122
      008D17 8A F0            [24] 2718 	mov	b, r2
      008D19 12 40 3F         [24] 2719 	lcall	_eeprom_read_byte
      008D1C AC 82            [24] 2720 	mov	r4, dpl
                                   2721 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      008D1E EF               [12] 2722 	mov	a,r7
      008D1F 60 4B            [24] 2723 	jz	00169$
      008D21 EC               [12] 2724 	mov	a,r4
      008D22 60 48            [24] 2725 	jz	00169$
                                   2726 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008D24 1F               [12] 2727 	dec	r7
      008D25 1C               [12] 2728 	dec	r4
      008D26 EC               [12] 2729 	mov	a,r4
      008D27 75 F0 FF         [24] 2730 	mov	b,#0xff
      008D2A A4               [48] 2731 	mul	ab
      008D2B FC               [12] 2732 	mov	r4,a
      008D2C AB F0            [24] 2733 	mov	r3,b
      008D2E 7A 00            [12] 2734 	mov	r2,#0x00
      008D30 EC               [12] 2735 	mov	a,r4
      008D31 2F               [12] 2736 	add	a, r7
      008D32 FC               [12] 2737 	mov	r4,a
      008D33 EB               [12] 2738 	mov	a,r3
      008D34 3A               [12] 2739 	addc	a, r2
      008D35 FB               [12] 2740 	mov	r3,a
                                   2741 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      008D36                       2742 00141$:
      008D36 8C 02            [24] 2743 	mov	ar2,r4
      008D38 8B 07            [24] 2744 	mov	ar7,r3
      008D3A 1C               [12] 2745 	dec	r4
      008D3B BC FF 01         [24] 2746 	cjne	r4,#0xff,00462$
      008D3E 1B               [12] 2747 	dec	r3
      008D3F                       2748 00462$:
      008D3F EA               [12] 2749 	mov	a,r2
      008D40 4F               [12] 2750 	orl	a,r7
      008D41 70 03            [24] 2751 	jnz	00463$
      008D43 02 8B 48         [24] 2752 	ljmp	00167$
      008D46                       2753 00463$:
      008D46 90 00 01         [24] 2754 	mov	dptr,#0x0001
      008D49 12 58 7C         [24] 2755 	lcall	_mDelaymS
      008D4C 80 E8            [24] 2756 	sjmp	00141$
      008D4E                       2757 00164$:
                                   2758 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      008D4E 90 0B 3A         [24] 2759 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008D51 E0               [24] 2760 	movx	a,@dptr
      008D52 FF               [12] 2761 	mov	r7,a
      008D53 BF 80 00         [24] 2762 	cjne	r7,#0x80,00464$
      008D56                       2763 00464$:
      008D56 50 14            [24] 2764 	jnc	00169$
                                   2765 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      008D58 90 0B 3A         [24] 2766 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008D5B E0               [24] 2767 	movx	a,@dptr
      008D5C F5 82            [12] 2768 	mov	dpl,a
      008D5E C0 06            [24] 2769 	push	ar6
      008D60 C0 05            [24] 2770 	push	ar5
      008D62 12 A3 04         [24] 2771 	lcall	_send_char
      008D65 D0 05            [24] 2772 	pop	ar5
      008D67 D0 06            [24] 2773 	pop	ar6
                                   2774 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008D69 02 8B 48         [24] 2775 	ljmp	00167$
      008D6C                       2776 00169$:
                                   2777 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      008D6C 12 8D DE         [24] 2778 	lcall	_ak820_outline_0160
                                   2779 ;	quantum/dynamic_keymap.c:837: sending = false;
      008D6F 90 0B 37         [24] 2780 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008D72 F0               [24] 2781 	movx	@dptr,a
                                   2782 ;	quantum/dynamic_keymap.c:839: }
      008D73 22               [24] 2783 	ret
                                   2784 	.area CSEG    (CODE)
                                   2785 	.area CONST   (CODE)
                                   2786 	.area XINIT   (CODE)
                                   2787 	.area CABS    (ABS,CODE)
                                   2788 
                                   2789 ; Experimental exact instruction outlining.
                                   2790 	.globl _ak820_outline_0000
                                   2791 	.globl _ak820_outline_0004
                                   2792 	.globl _ak820_outline_0010
                                   2793 	.globl _ak820_outline_0011
                                   2794 	.globl _ak820_outline_0016
                                   2795 	.globl _ak820_outline_0024
                                   2796 	.globl _ak820_outline_0030
                                   2797 	.globl _ak820_outline_0043
                                   2798 	.globl _ak820_outline_0050
                                   2799 	.globl _ak820_outline_0056
                                   2800 	.globl _ak820_outline_0058
                                   2801 	.globl _ak820_outline_0059
                                   2802 	.globl _ak820_outline_0060
                                   2803 	.globl _ak820_outline_0070
                                   2804 	.globl _ak820_outline_0075
                                   2805 	.globl _ak820_outline_0077
                                   2806 	.globl _ak820_outline_0086
                                   2807 	.globl _ak820_outline_0088
                                   2808 	.globl _ak820_outline_0094
                                   2809 	.globl _ak820_outline_0095
                                   2810 	.globl _ak820_outline_0099
                                   2811 	.globl _ak820_outline_0103
                                   2812 	.globl _ak820_outline_0104
                                   2813 	.globl _ak820_outline_0112
                                   2814 	.globl _ak820_outline_0116
                                   2815 	.globl _ak820_outline_0117
                                   2816 	.globl _ak820_outline_0119
                                   2817 	.globl _ak820_outline_0120
                                   2818 	.globl _ak820_outline_0121
                                   2819 	.globl _ak820_outline_0122
                                   2820 	.globl _ak820_outline_0123
                                   2821 	.globl _ak820_outline_0127
                                   2822 	.globl _ak820_outline_0131
                                   2823 	.globl _ak820_outline_0132
                                   2824 	.globl _ak820_outline_0133
                                   2825 	.globl _ak820_outline_0134
                                   2826 	.globl _ak820_outline_0139
                                   2827 	.globl _ak820_outline_0140
                                   2828 	.globl _ak820_outline_0145
                                   2829 	.globl _ak820_outline_0147
                                   2830 	.globl _ak820_outline_0151
                                   2831 	.globl _ak820_outline_0152
                                   2832 	.globl _ak820_outline_0155
                                   2833 	.globl _ak820_outline_0160
                                   2834 	.globl _ak820_outline_0173
                                   2835 	.globl _ak820_outline_0174
                                   2836 	.globl _ak820_outline_0177
                                   2837 	.globl _ak820_outline_0178
                                   2838 	.globl _ak820_outline_0179
                                   2839 	.globl _ak820_outline_0180
                                   2840 
                                   2841 	.area CSEG (CODE)
                                   2842 ; function ak820_outline_0000
      008D74                       2843 _ak820_outline_0000:
      008D74 90 0B 38         [24] 2844 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008D77 E0               [24] 2845 	movx	a,@dptr
      008D78 FC               [12] 2846 	mov	r4,a
      008D79 A3               [24] 2847 	inc	dptr
      008D7A E0               [24] 2848 	movx	a,@dptr
      008D7B FF               [12] 2849 	mov	r7,a
      008D7C 90 0B 38         [24] 2850 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008D7F 74 01            [12] 2851 	mov	a,#0x01
      008D81 2C               [12] 2852 	add	a,r4
      008D82 F0               [24] 2853 	movx	@dptr,a
      008D83 E4               [12] 2854 	clr	a
      008D84 3F               [12] 2855 	addc	a,r7
      008D85 A3               [24] 2856 	inc	dptr
      008D86 F0               [24] 2857 	movx	@dptr,a
      008D87 7B 00            [12] 2858 	mov	r3,#0x00
      008D89 8C 82            [24] 2859 	mov	dpl,r4
      008D8B 8F 83            [24] 2860 	mov	dph,r7
      008D8D 8B F0            [24] 2861 	mov	b,r3
      008D8F 22               [24] 2862 	ret
                                   2863 
                                   2864 	.area CSEG (CODE)
                                   2865 ; function ak820_outline_0024
      008D90                       2866 _ak820_outline_0024:
      008D90 2D               [12] 2867 	add	a,r5
      008D91 F9               [12] 2868 	mov	r1,a
      008D92 E4               [12] 2869 	clr	a
      008D93 3E               [12] 2870 	addc	a,r6
      008D94 FA               [12] 2871 	mov	r2,a
      008D95 8F 03            [24] 2872 	mov	ar3,r7
      008D97 89 82            [24] 2873 	mov	dpl,r1
      008D99 8A 83            [24] 2874 	mov	dph,r2
      008D9B 8B F0            [24] 2875 	mov	b,r3
      008D9D 22               [24] 2876 	ret
                                   2877 
                                   2878 	.area CSEG (CODE)
                                   2879 ; function ak820_outline_0077
      008D9E                       2880 _ak820_outline_0077:
      008D9E ED               [12] 2881 	mov	a,r5
      008D9F 75 F0 0A         [24] 2882 	mov	b,#0x0a
      008DA2 A4               [48] 2883 	mul	ab
      008DA3 24 58            [12] 2884 	add	a,#0x58
      008DA5 FC               [12] 2885 	mov	r4,a
      008DA6 74 06            [12] 2886 	mov	a,#0x06
      008DA8 35 F0            [12] 2887 	addc	a,b
      008DAA FD               [12] 2888 	mov	r5,a
      008DAB 22               [24] 2889 	ret
                                   2890 
                                   2891 	.area CSEG (CODE)
                                   2892 ; function ak820_outline_0088
      008DAC                       2893 _ak820_outline_0088:
      008DAC 90 0B 3B         [24] 2894 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0001)
      008DAF E0               [24] 2895 	movx	a,@dptr
      008DB0 FF               [12] 2896 	mov	r7,a
      008DB1 22               [24] 2897 	ret
                                   2898 
                                   2899 	.area CSEG (CODE)
                                   2900 ; function ak820_outline_0094
      008DB2                       2901 _ak820_outline_0094:
      008DB2 90 0A D1         [24] 2902 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008DB5 EE               [12] 2903 	mov	a,r6
      008DB6 F0               [24] 2904 	movx	@dptr,a
      008DB7 90 0A D2         [24] 2905 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008DBA ED               [12] 2906 	mov	a,r5
      008DBB F0               [24] 2907 	movx	@dptr,a
      008DBC 8F 82            [24] 2908 	mov	dpl,r7
      008DBE 22               [24] 2909 	ret
                                   2910 
                                   2911 	.area CSEG (CODE)
                                   2912 ; function ak820_outline_0112
      008DBF                       2913 _ak820_outline_0112:
      008DBF AD 82            [24] 2914 	mov	r5,dpl
      008DC1 AE 83            [24] 2915 	mov	r6,dph
      008DC3 AF F0            [24] 2916 	mov	r7,b
      008DC5 22               [24] 2917 	ret
                                   2918 
                                   2919 	.area CSEG (CODE)
                                   2920 ; function ak820_outline_0127
      008DC6                       2921 _ak820_outline_0127:
      008DC6 28               [12] 2922 	add	a,r0
      008DC7 F5 82            [12] 2923 	mov	dpl,a
      008DC9 EF               [12] 2924 	mov	a,r7
      008DCA 39               [12] 2925 	addc	a,r1
      008DCB F5 83            [12] 2926 	mov	dph,a
      008DCD 74 FF            [12] 2927 	mov	a,#0xff
      008DCF F0               [24] 2928 	movx	@dptr,a
      008DD0 22               [24] 2929 	ret
                                   2930 
                                   2931 	.area CSEG (CODE)
                                   2932 ; function ak820_outline_0133
      008DD1                       2933 _ak820_outline_0133:
      008DD1 2D               [12] 2934 	add	a,r5
      008DD2 F9               [12] 2935 	mov	r1,a
      008DD3 E4               [12] 2936 	clr	a
      008DD4 3E               [12] 2937 	addc	a,r6
      008DD5 FA               [12] 2938 	mov	r2,a
      008DD6 22               [24] 2939 	ret
                                   2940 
                                   2941 	.area CSEG (CODE)
                                   2942 ; function ak820_outline_0147
      008DD7                       2943 _ak820_outline_0147:
      008DD7 90 0B 3C         [24] 2944 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      008DDA E0               [24] 2945 	movx	a,@dptr
      008DDB F5 82            [12] 2946 	mov	dpl,a
      008DDD 22               [24] 2947 	ret
                                   2948 
                                   2949 	.area CSEG (CODE)
                                   2950 ; function ak820_outline_0160
      008DDE                       2951 _ak820_outline_0160:
      008DDE 90 09 7F         [24] 2952 	mov	dptr,#_ak820_macro_primitive
      008DE1 E4               [12] 2953 	clr	a
      008DE2 F0               [24] 2954 	movx	@dptr,a
      008DE3 22               [24] 2955 	ret
                                   2956 
                                   2957 	.area CSEG (CODE)
                                   2958 ; function ak820_outline_0173
      008DE4                       2959 _ak820_outline_0173:
      008DE4 90 0A E1         [24] 2960 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008DE7 E4               [12] 2961 	clr	a
      008DE8 F0               [24] 2962 	movx	@dptr,a
      008DE9 90 0A E2         [24] 2963 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008DEC 22               [24] 2964 	ret
                                   2965 
                                   2966 	.area CSEG (CODE)
                                   2967 ; function ak820_outline_0174
      008DED                       2968 _ak820_outline_0174:
      008DED 90 0B 97         [24] 2969 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      008DF0 E4               [12] 2970 	clr	a
      008DF1 F0               [24] 2971 	movx	@dptr,a
      008DF2 90 0B 98         [24] 2972 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      008DF5 22               [24] 2973 	ret
                                   2974 
                                   2975 	.area CSEG (CODE)
                                   2976 ; function ak820_outline_0177
      008DF6                       2977 _ak820_outline_0177:
      008DF6 AF 82            [24] 2978 	mov	r7,dpl
      008DF8 90 0B 3C         [24] 2979 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      008DFB EF               [12] 2980 	mov	a,r7
      008DFC F0               [24] 2981 	movx	@dptr,a
      008DFD EF               [12] 2982 	mov	a,r7
      008DFE 22               [24] 2983 	ret
