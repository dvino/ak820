                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _process_record_quantum
                                     53 	.globl _action_for_keycode
                                     54 	.globl _mDelaymS
                                     55 	.globl _host_consumer_send
                                     56 	.globl _host_system_send
                                     57 	.globl _host_keyboard_leds
                                     58 	.globl _led_set
                                     59 	.globl _clear_keys_from_report
                                     60 	.globl ___memcpy
                                     61 	.globl _ADC_START
                                     62 	.globl _S0_R_FIFO
                                     63 	.globl _S0_T_FIFO
                                     64 	.globl _S0_FREE
                                     65 	.globl _S0_IF_BYTE
                                     66 	.globl _S0_IF_FIRST
                                     67 	.globl _S0_IF_OV
                                     68 	.globl _S0_FST_ACT
                                     69 	.globl _CP_RL2
                                     70 	.globl _C_T2
                                     71 	.globl _TR2
                                     72 	.globl _EXEN2
                                     73 	.globl _TCLK
                                     74 	.globl _RCLK
                                     75 	.globl _EXF2
                                     76 	.globl _CAP1F
                                     77 	.globl _TF2
                                     78 	.globl _RI
                                     79 	.globl _TI
                                     80 	.globl _RB8
                                     81 	.globl _TB8
                                     82 	.globl _REN
                                     83 	.globl _SM2
                                     84 	.globl _SM1
                                     85 	.globl _SM0
                                     86 	.globl _IT0
                                     87 	.globl _IE0
                                     88 	.globl _IT1
                                     89 	.globl _IE1
                                     90 	.globl _TR0
                                     91 	.globl _TF0
                                     92 	.globl _TR1
                                     93 	.globl _TF1
                                     94 	.globl _P4_0
                                     95 	.globl _P4_1
                                     96 	.globl _P4_2
                                     97 	.globl _P4_3
                                     98 	.globl _P4_4
                                     99 	.globl _P4_5
                                    100 	.globl _P4_6
                                    101 	.globl _RXD
                                    102 	.globl _TXD
                                    103 	.globl _INT0
                                    104 	.globl _INT1
                                    105 	.globl _T0
                                    106 	.globl _T1
                                    107 	.globl _MOSI1
                                    108 	.globl _MISO1
                                    109 	.globl _SCK1
                                    110 	.globl _P3_0
                                    111 	.globl _P3_1
                                    112 	.globl _P3_2
                                    113 	.globl _P3_3
                                    114 	.globl _P3_4
                                    115 	.globl _P3_5
                                    116 	.globl _P3_6
                                    117 	.globl _P3_7
                                    118 	.globl _CAP1_
                                    119 	.globl _T2_
                                    120 	.globl _CAP2_
                                    121 	.globl _T2EX_
                                    122 	.globl _RXD1
                                    123 	.globl _TXD1
                                    124 	.globl _P2_0
                                    125 	.globl _P2_1
                                    126 	.globl _P2_2
                                    127 	.globl _P2_3
                                    128 	.globl _P2_4
                                    129 	.globl _P2_5
                                    130 	.globl _P2_6
                                    131 	.globl _P2_7
                                    132 	.globl _AIN0
                                    133 	.globl _AIN1
                                    134 	.globl _AIN2
                                    135 	.globl _AIN3
                                    136 	.globl _AIN4
                                    137 	.globl _AIN5
                                    138 	.globl _AIN6
                                    139 	.globl _AIN7
                                    140 	.globl _CAP1
                                    141 	.globl _T2
                                    142 	.globl _CAP2
                                    143 	.globl _T2EX
                                    144 	.globl _INT0_
                                    145 	.globl _SCS
                                    146 	.globl _MOSI
                                    147 	.globl _MISO
                                    148 	.globl _SCK
                                    149 	.globl _RXD1_
                                    150 	.globl _TXD1_
                                    151 	.globl _P1_0
                                    152 	.globl _P1_1
                                    153 	.globl _P1_2
                                    154 	.globl _P1_3
                                    155 	.globl _P1_4
                                    156 	.globl _P1_5
                                    157 	.globl _P1_6
                                    158 	.globl _P1_7
                                    159 	.globl _AIN8
                                    160 	.globl _AIN9
                                    161 	.globl _AIN10
                                    162 	.globl _AIN11
                                    163 	.globl _AIN12
                                    164 	.globl _AIN13
                                    165 	.globl _RXD_
                                    166 	.globl _TXD_
                                    167 	.globl _SCL0
                                    168 	.globl _SDA0
                                    169 	.globl _P0_0
                                    170 	.globl _P0_1
                                    171 	.globl _P0_2
                                    172 	.globl _P0_3
                                    173 	.globl _P0_4
                                    174 	.globl _P0_5
                                    175 	.globl _P0_6
                                    176 	.globl _P0_7
                                    177 	.globl _IE_SPI0
                                    178 	.globl _IE_USB
                                    179 	.globl _IE_ADC
                                    180 	.globl _IE_UART1
                                    181 	.globl _IE_PWM_I2C
                                    182 	.globl _IE_GPIO
                                    183 	.globl _IE_WDOG
                                    184 	.globl _PX0
                                    185 	.globl _PT0
                                    186 	.globl _PX1
                                    187 	.globl _PT1
                                    188 	.globl _PS
                                    189 	.globl _PT2
                                    190 	.globl _PL_FLAG
                                    191 	.globl _PH_FLAG
                                    192 	.globl _EX0
                                    193 	.globl _ET0
                                    194 	.globl _EX1
                                    195 	.globl _ET1
                                    196 	.globl _ES
                                    197 	.globl _ET2
                                    198 	.globl _E_DIS
                                    199 	.globl _EA
                                    200 	.globl _P
                                    201 	.globl _F1
                                    202 	.globl _OV
                                    203 	.globl _RS0
                                    204 	.globl _RS1
                                    205 	.globl _F0
                                    206 	.globl _AC
                                    207 	.globl _CY
                                    208 	.globl _I2CS_INT_ST
                                    209 	.globl _I2CX_INT
                                    210 	.globl _LED_STATUS
                                    211 	.globl _LED_DMA_H
                                    212 	.globl _LED_DMA_L
                                    213 	.globl _LED_DMA
                                    214 	.globl _LED_PWM_OE
                                    215 	.globl _LED_COMMON
                                    216 	.globl _ADC_CHAN
                                    217 	.globl _ADC_DAT_H
                                    218 	.globl _ADC_DAT_L
                                    219 	.globl _ADC_DAT
                                    220 	.globl _ADC_CTRL
                                    221 	.globl _SPI1_CK_SE
                                    222 	.globl _SPI1_CTRL
                                    223 	.globl _SPI1_DATA
                                    224 	.globl _SPI1_STAT
                                    225 	.globl _SIF1
                                    226 	.globl _SBAUD1
                                    227 	.globl _SBUF1
                                    228 	.globl _SCON1
                                    229 	.globl _SPI0_SETUP
                                    230 	.globl _SPI0_CK_SE
                                    231 	.globl _SPI0_CTRL
                                    232 	.globl _SPI0_DATA
                                    233 	.globl _SPI0_STAT
                                    234 	.globl _T2CAP1H
                                    235 	.globl _T2CAP1L
                                    236 	.globl _T2CAP1
                                    237 	.globl _TH2
                                    238 	.globl _TL2
                                    239 	.globl _T2COUNT
                                    240 	.globl _RCAP2H
                                    241 	.globl _RCAP2L
                                    242 	.globl _RCAP2
                                    243 	.globl _T2MOD
                                    244 	.globl _T2CON
                                    245 	.globl _SBUF
                                    246 	.globl _SCON
                                    247 	.globl _TH1
                                    248 	.globl _TH0
                                    249 	.globl _TL1
                                    250 	.globl _TL0
                                    251 	.globl _TMOD
                                    252 	.globl _TCON
                                    253 	.globl _XBUS_AUX
                                    254 	.globl _P7
                                    255 	.globl _P6_DIR
                                    256 	.globl _P6_OUT_PU
                                    257 	.globl _P6_IN
                                    258 	.globl _P5_DIR
                                    259 	.globl _P5_OUT_PU
                                    260 	.globl _P5_IN
                                    261 	.globl _P4_LED_KEY
                                    262 	.globl _P4_DIR_PU
                                    263 	.globl _P4_MOD_OC
                                    264 	.globl _P4
                                    265 	.globl _P3_DIR_PU
                                    266 	.globl _P3_MOD_OC
                                    267 	.globl _P3
                                    268 	.globl _P2_DIR_PU
                                    269 	.globl _P2_MOD_OC
                                    270 	.globl _P2
                                    271 	.globl _P1_DIR_PU
                                    272 	.globl _P1_MOD_OC
                                    273 	.globl _P1
                                    274 	.globl _P0_DIR_PU
                                    275 	.globl _P0_MOD_OC
                                    276 	.globl _P0
                                    277 	.globl _ROM_CTRL
                                    278 	.globl _ROM_DATA_HH
                                    279 	.globl _ROM_DATA_HL
                                    280 	.globl _ROM_DATA_HI
                                    281 	.globl _ROM_ADDR_H
                                    282 	.globl _ROM_ADDR_L
                                    283 	.globl _ROM_ADDR
                                    284 	.globl _GPIO_IE
                                    285 	.globl _IP_EX
                                    286 	.globl _IE_EX
                                    287 	.globl _IP
                                    288 	.globl _IE
                                    289 	.globl _WDOG_COUNT
                                    290 	.globl _RESET_KEEP
                                    291 	.globl _WAKE_CTRL
                                    292 	.globl _CLOCK_CFG
                                    293 	.globl _POWER_CFG
                                    294 	.globl _PCON
                                    295 	.globl _GLOBAL_CFG
                                    296 	.globl _SAFE_MOD
                                    297 	.globl _DPH
                                    298 	.globl _DPL
                                    299 	.globl _SP
                                    300 	.globl _A_INV
                                    301 	.globl _B
                                    302 	.globl _ACC
                                    303 	.globl _PSW
                                    304 	.globl _disable_action_cache
                                    305 	.globl _tap_code_delay_PARM_2
                                    306 	.globl _process_action_PARM_2
                                    307 	.globl _action_exec_PARM_1
                                    308 	.globl _tp_buttons
                                    309 	.globl _action_exec
                                    310 	.globl _ak820_action_exec
                                    311 	.globl _process_record
                                    312 	.globl _process_record_handler
                                    313 	.globl _process_action
                                    314 	.globl _register_code
                                    315 	.globl _unregister_code
                                    316 	.globl _tap_code_delay
                                    317 	.globl _tap_code
                                    318 	.globl _register_mods
                                    319 	.globl _unregister_mods
                                    320 	.globl _register_weak_mods
                                    321 	.globl _unregister_weak_mods
                                    322 	.globl _clear_keyboard
                                    323 	.globl _clear_keyboard_but_mods
                                    324 	.globl _clear_keyboard_but_mods_and_keys
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000027                        587 _process_action_sloc0_1_0:
      000027                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; overlayable items in internal ram
                                    591 ;--------------------------------------------------------
                                    592 ;--------------------------------------------------------
                                    593 ; indirectly addressable internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area ISEG    (DATA)
                                    596 ;--------------------------------------------------------
                                    597 ; absolute internal ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area IABS    (ABS,DATA)
                                    600 	.area IABS    (ABS,DATA)
                                    601 ;--------------------------------------------------------
                                    602 ; bit data
                                    603 ;--------------------------------------------------------
                                    604 	.area BSEG    (BIT)
      00001D                        605 _process_action_sloc1_1_0:
      00001D                        606 	.ds 1
                                    607 ;--------------------------------------------------------
                                    608 ; paged external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area PSEG    (PAG,XDATA)
                                    611 ;--------------------------------------------------------
                                    612 ; uninitialized external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area XSEG    (XDATA)
      00080A                        615 _tp_buttons::
      00080A                        616 	.ds 2
      00080C                        617 _action_exec_PARM_1:
      00080C                        618 	.ds 6
      000812                        619 _action_exec_record_10001_625:
      000812                        620 	.ds 9
      00081B                        621 _ak820_action_exec_event_10000_629:
      00081B                        622 	.ds 2
      00081D                        623 _ak820_action_exec_snapshot_10000_630:
      00081D                        624 	.ds 6
      000823                        625 _process_record_record_argument_10000_633:
      000823                        626 	.ds 2
      000825                        627 _process_record_handler_record_argument_10000_641:
      000825                        628 	.ds 2
      000827                        629 _process_record_handler_action_10000_642:
      000827                        630 	.ds 2
      000829                        631 _process_action_PARM_2:
      000829                        632 	.ds 2
      00082B                        633 _process_action_record_argument_10000_653:
      00082B                        634 	.ds 2
      00082D                        635 _process_action_on_40000_676:
      00082D                        636 	.ds 1
      00082E                        637 _register_code_code_10000_710:
      00082E                        638 	.ds 1
      00082F                        639 _unregister_code_code_10000_724:
      00082F                        640 	.ds 1
      000830                        641 _tap_code_delay_PARM_2:
      000830                        642 	.ds 2
      000832                        643 _tap_code_delay_code_10000_737:
      000832                        644 	.ds 1
      000833                        645 _tap_code_code_10000_744:
      000833                        646 	.ds 1
      000834                        647 _register_mods_mods_10000_746:
      000834                        648 	.ds 1
      000835                        649 _unregister_mods_mods_10000_750:
      000835                        650 	.ds 1
      000836                        651 _register_weak_mods_mods_10000_754:
      000836                        652 	.ds 1
      000837                        653 _unregister_weak_mods_mods_10000_758:
      000837                        654 	.ds 1
                                    655 ;--------------------------------------------------------
                                    656 ; absolute external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XABS    (ABS,XDATA)
                                    659 ;--------------------------------------------------------
                                    660 ; initialized external ram data
                                    661 ;--------------------------------------------------------
                                    662 	.area XISEG   (XDATA)
      000D93                        663 _disable_action_cache::
      000D93                        664 	.ds 1
                                    665 	.area HOME    (CODE)
                                    666 	.area GSINIT0 (CODE)
                                    667 	.area GSINIT1 (CODE)
                                    668 	.area GSINIT2 (CODE)
                                    669 	.area GSINIT3 (CODE)
                                    670 	.area GSINIT4 (CODE)
                                    671 	.area GSINIT5 (CODE)
                                    672 	.area GSINIT  (CODE)
                                    673 	.area GSFINAL (CODE)
                                    674 	.area CSEG    (CODE)
                                    675 ;--------------------------------------------------------
                                    676 ; global & static initialisations
                                    677 ;--------------------------------------------------------
                                    678 	.area HOME    (CODE)
                                    679 	.area GSINIT  (CODE)
                                    680 	.area GSFINAL (CODE)
                                    681 	.area GSINIT  (CODE)
                                    682 ;--------------------------------------------------------
                                    683 ; Home
                                    684 ;--------------------------------------------------------
                                    685 	.area HOME    (CODE)
                                    686 	.area HOME    (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; code
                                    689 ;--------------------------------------------------------
                                    690 	.area CSEG    (CODE)
                                    691 ;------------------------------------------------------------
                                    692 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    693 ;------------------------------------------------------------
                                    694 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    695 ;------------------------------------------------------------
                                    696 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    697 ;	-----------------------------------------
                           000007   698 	ar7 = 0x07
                           000006   699 	ar6 = 0x06
                           000005   700 	ar5 = 0x05
                           000004   701 	ar4 = 0x04
                           000003   702 	ar3 = 0x03
                           000002   703 	ar2 = 0x02
                           000001   704 	ar1 = 0x01
                           000000   705 	ar0 = 0x00
                                    706 ;	 function action_exec
                                    707 ;	-----------------------------------------
      006FAA                        708 _action_exec:
                                    709 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      006FAA 90 08 0E         [24]  710 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      006FAD 12 37 A0         [24]  711 	lcall	_ak820_outline_0004
      006FB0 12 35 B8         [24]  712 	lcall	_ak820_combo_tick
                                    713 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      006FB3 90 08 0C         [24]  714 	mov	dptr,#_action_exec_PARM_1
      006FB6 12 44 25         [24]  715 	lcall	_ak820_tapping_before
      006FB9 E5 82            [12]  716 	mov	a, dpl
      006FBB 70 01            [24]  717 	jnz	00102$
      006FBD 22               [24]  718 	ret
      006FBE                        719 00102$:
                                    720 ;	quantum/action.c:126: if (event.pressed) {
      006FBE 90 08 11         [24]  721 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      006FC1 E0               [24]  722 	movx	a,@dptr
      006FC2 60 03            [24]  723 	jz	00104$
                                    724 ;	quantum/action.c:128: clear_weak_mods();
      006FC4 12 80 0B         [24]  725 	lcall	_clear_weak_mods
      006FC7                        726 00104$:
                                    727 ;	quantum/action.c:140: record.event = event;
      006FC7 90 0D 73         [24]  728 	mov	dptr,#___memcpy_PARM_2
      006FCA 74 0C            [12]  729 	mov	a,#_action_exec_PARM_1
      006FCC F0               [24]  730 	movx	@dptr,a
      006FCD 74 08            [12]  731 	mov	a,#(_action_exec_PARM_1 >> 8)
      006FCF 12 76 27         [24]  732 	lcall	_ak820_outline_0049
      006FD2 12 76 47         [24]  733 	lcall	_ak820_outline_0107
      006FD5 90 08 12         [24]  734 	mov	dptr,#_action_exec_record_10001_625
      006FD8 F5 F0            [12]  735 	mov	b,a
      006FDA 12 B6 6B         [24]  736 	lcall	___memcpy
                                    737 ;	quantum/action.c:142: record.tap.count = 0;
      006FDD 90 08 18         [24]  738 	mov	dptr,#(_action_exec_record_10001_625 + 0x0006)
      006FE0 E0               [24]  739 	movx	a,@dptr
      006FE1 54 0F            [12]  740 	anl	a,#0x0f
      006FE3 F0               [24]  741 	movx	@dptr,a
                                    742 ;	quantum/action.c:147: record.keycode = 0;
      006FE4 90 08 19         [24]  743 	mov	dptr,#(_action_exec_record_10001_625 + 0x0007)
      006FE7 12 4E FB         [24]  744 	lcall	_ak820_outline_0178
                                    745 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      006FEA 90 08 16         [24]  746 	mov	dptr,#(_action_exec_record_10001_625 + 0x0004)
      006FED E0               [24]  747 	movx	a,@dptr
      006FEE 60 0A            [24]  748 	jz	00107$
      006FF0 90 08 12         [24]  749 	mov	dptr,#_action_exec_record_10001_625
      006FF3 12 9D 72         [24]  750 	lcall	_pre_process_record_quantum
      006FF6 E5 82            [12]  751 	mov	a, dpl
      006FF8 60 11            [24]  752 	jz	00110$
      006FFA                        753 00107$:
                                    754 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      006FFA 90 08 12         [24]  755 	mov	dptr,#_action_exec_record_10001_625
      006FFD 12 45 09         [24]  756 	lcall	_ak820_tapping_process
      007000 E5 82            [12]  757 	mov	a, dpl
      007002 70 01            [24]  758 	jnz	00106$
      007004 22               [24]  759 	ret
      007005                        760 00106$:
                                    761 ;	quantum/action.c:185: process_record(&record);
      007005 90 08 12         [24]  762 	mov	dptr,#_action_exec_record_10001_625
                                    763 ;	quantum/action.c:200: }
      007008 02 70 49         [24]  764 	ljmp	_process_record
      00700B                        765 00110$:
      00700B 22               [24]  766 	ret
                                    767 ;------------------------------------------------------------
                                    768 ;Allocation info for local variables in function 'ak820_action_exec'
                                    769 ;------------------------------------------------------------
                                    770 ;event         Allocated with name '_ak820_action_exec_event_10000_629'
                                    771 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_630'
                                    772 ;------------------------------------------------------------
                                    773 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    774 ;	-----------------------------------------
                                    775 ;	 function ak820_action_exec
                                    776 ;	-----------------------------------------
      00700C                        777 _ak820_action_exec:
      00700C 12 38 43         [24]  778 	lcall	_ak820_outline_0103
      00700F 90 08 1B         [24]  779 	mov	dptr,#_ak820_action_exec_event_10000_629
      007012 12 38 48         [24]  780 	lcall	_ak820_outline_0104
                                    781 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007015 90 08 1B         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_629
      007018 12 38 17         [24]  783 	lcall	_ak820_outline_0057
      00701B 90 0D 73         [24]  784 	mov	dptr,#___memcpy_PARM_2
      00701E ED               [12]  785 	mov	a,r5
      00701F 12 37 DF         [24]  786 	lcall	_ak820_outline_0015
      007022 90 0D 76         [24]  787 	mov	dptr,#___memcpy_PARM_3
      007025 12 76 47         [24]  788 	lcall	_ak820_outline_0107
      007028 90 08 1D         [24]  789 	mov	dptr,#_ak820_action_exec_snapshot_10000_630
      00702B F5 F0            [12]  790 	mov	b,a
      00702D 12 B6 6B         [24]  791 	lcall	___memcpy
                                    792 ;	quantum/action.c:207: action_exec(snapshot);
      007030 90 0D 73         [24]  793 	mov	dptr,#___memcpy_PARM_2
      007033 74 1D            [12]  794 	mov	a,#_ak820_action_exec_snapshot_10000_630
      007035 F0               [24]  795 	movx	@dptr,a
      007036 74 08            [12]  796 	mov	a,#(_ak820_action_exec_snapshot_10000_630 >> 8)
      007038 12 76 27         [24]  797 	lcall	_ak820_outline_0049
      00703B 12 76 47         [24]  798 	lcall	_ak820_outline_0107
      00703E 90 08 0C         [24]  799 	mov	dptr,#_action_exec_PARM_1
      007041 F5 F0            [12]  800 	mov	b,a
      007043 12 B6 6B         [24]  801 	lcall	___memcpy
                                    802 ;	quantum/action.c:208: }
      007046 02 6F AA         [24]  803 	ljmp	_action_exec
                                    804 ;------------------------------------------------------------
                                    805 ;Allocation info for local variables in function 'process_record_nocache'
                                    806 ;------------------------------------------------------------
                                    807 ;record        Allocated with name '_process_record_nocache_record_10000_631'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function process_record
                                    812 ;	-----------------------------------------
      007049                        813 _process_record:
      007049 12 38 43         [24]  814 	lcall	_ak820_outline_0103
      00704C 90 08 23         [24]  815 	mov	dptr,#_process_record_record_argument_10000_633
      00704F 12 38 48         [24]  816 	lcall	_ak820_outline_0104
                                    817 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007052 90 08 23         [24]  818 	mov	dptr,#_process_record_record_argument_10000_633
      007055 12 38 00         [24]  819 	lcall	_ak820_outline_0050
                                    820 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      007058 74 04            [12]  821 	mov	a,#0x04
      00705A 12 47 FD         [24]  822 	lcall	_ak820_outline_0011
      00705D 70 01            [24]  823 	jnz	00102$
                                    824 ;	quantum/action.c:354: return;
      00705F 22               [24]  825 	ret
      007060                        826 00102$:
                                    827 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007060 8E 04            [24]  828 	mov	ar4,r6
      007062 8F 05            [24]  829 	mov	ar5,r7
      007064 90 0D 73         [24]  830 	mov	dptr,#___memcpy_PARM_2
      007067 EC               [12]  831 	mov	a,r4
      007068 F0               [24]  832 	movx	@dptr,a
      007069 ED               [12]  833 	mov	a,r5
      00706A 12 76 27         [24]  834 	lcall	_ak820_outline_0049
      00706D 12 4E ED         [24]  835 	lcall	_ak820_outline_0106
      007070 90 06 20         [24]  836 	mov	dptr,#_ak820_tapping_source_PARM_1
      007073 F5 F0            [12]  837 	mov	b,a
      007075 C0 07            [24]  838 	push	ar7
      007077 C0 06            [24]  839 	push	ar6
      007079 12 B6 6B         [24]  840 	lcall	___memcpy
      00707C 12 43 61         [24]  841 	lcall	_ak820_tapping_source
      00707F AD 82            [24]  842 	mov	r5, dpl
      007081 D0 06            [24]  843 	pop	ar6
      007083 D0 07            [24]  844 	pop	ar7
                                    845 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      007085 12 42 CC         [24]  846 	lcall	_ak820_outline_0009
      007088 E0               [24]  847 	movx	a,@dptr
      007089 FC               [12]  848 	mov	r4,a
                                    849 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      00708A 74 07            [12]  850 	mov	a,#0x07
      00708C 2E               [12]  851 	add	a, r6
      00708D FA               [12]  852 	mov	r2,a
      00708E E4               [12]  853 	clr	a
      00708F 3F               [12]  854 	addc	a, r7
      007090 FB               [12]  855 	mov	r3,a
      007091 90 0B D5         [24]  856 	mov	dptr,#_get_record_keycode_PARM_2
      007094 12 48 46         [24]  857 	lcall	_ak820_outline_0054
      007097 C0 07            [24]  858 	push	ar7
      007099 C0 06            [24]  859 	push	ar6
      00709B C0 05            [24]  860 	push	ar5
      00709D C0 04            [24]  861 	push	ar4
      00709F C0 03            [24]  862 	push	ar3
      0070A1 C0 02            [24]  863 	push	ar2
      0070A3 12 9D 34         [24]  864 	lcall	_get_record_keycode
      0070A6 A8 82            [24]  865 	mov	r0, dpl
      0070A8 A9 83            [24]  866 	mov	r1, dph
      0070AA D0 02            [24]  867 	pop	ar2
      0070AC D0 03            [24]  868 	pop	ar3
      0070AE D0 04            [24]  869 	pop	ar4
      0070B0 D0 05            [24]  870 	pop	ar5
      0070B2 D0 06            [24]  871 	pop	ar6
      0070B4 D0 07            [24]  872 	pop	ar7
      0070B6 12 43 3C         [24]  873 	lcall	_ak820_outline_0140
      0070B9 E8               [12]  874 	mov	a,r0
      0070BA F0               [24]  875 	movx	@dptr,a
      0070BB E9               [12]  876 	mov	a,r1
      0070BC A3               [24]  877 	inc	dptr
      0070BD F0               [24]  878 	movx	@dptr,a
                                    879 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0070BE 74 07            [12]  880 	mov	a,#0x07
      0070C0 12 37 E7         [24]  881 	lcall	_ak820_outline_0016
      0070C3 FA               [12]  882 	mov	r2,a
      0070C4 A3               [24]  883 	inc	dptr
      0070C5 E0               [24]  884 	movx	a,@dptr
      0070C6 FB               [12]  885 	mov	r3,a
      0070C7 90 06 30         [24]  886 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0070CA ED               [12]  887 	mov	a,r5
      0070CB F0               [24]  888 	movx	@dptr,a
      0070CC 90 06 31         [24]  889 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0070CF EC               [12]  890 	mov	a,r4
      0070D0 F0               [24]  891 	movx	@dptr,a
      0070D1 12 43 3C         [24]  892 	lcall	_ak820_outline_0140
      0070D4 C0 07            [24]  893 	push	ar7
      0070D6 C0 06            [24]  894 	push	ar6
      0070D8 C0 05            [24]  895 	push	ar5
      0070DA C0 04            [24]  896 	push	ar4
      0070DC 12 46 B0         [24]  897 	lcall	_ak820_oneshot_process
      0070DF E5 82            [12]  898 	mov	a, dpl
      0070E1 D0 04            [24]  899 	pop	ar4
      0070E3 D0 05            [24]  900 	pop	ar5
      0070E5 D0 06            [24]  901 	pop	ar6
      0070E7 D0 07            [24]  902 	pop	ar7
      0070E9 70 01            [24]  903 	jnz	00104$
      0070EB 22               [24]  904 	ret
      0070EC                        905 00104$:
                                    906 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      0070EC 12 43 20         [24]  907 	lcall	_ak820_outline_0116
      0070EF C0 07            [24]  908 	push	ar7
      0070F1 C0 06            [24]  909 	push	ar6
      0070F3 C0 05            [24]  910 	push	ar5
      0070F5 C0 04            [24]  911 	push	ar4
      0070F7 12 9D B4         [24]  912 	lcall	_process_record_quantum
      0070FA E5 82            [12]  913 	mov	a, dpl
      0070FC D0 04            [24]  914 	pop	ar4
      0070FE D0 05            [24]  915 	pop	ar5
      007100 D0 06            [24]  916 	pop	ar6
      007102 D0 07            [24]  917 	pop	ar7
      007104 70 0A            [24]  918 	jnz	00106$
                                    919 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007106 90 05 98         [24]  920 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007109 EC               [12]  921 	mov	a,r4
      00710A F0               [24]  922 	movx	@dptr,a
      00710B 8D 82            [24]  923 	mov	dpl, r5
                                    924 ;	quantum/action.c:376: return;
      00710D 02 2E BB         [24]  925 	ljmp	_ak820_oneshot_post
      007110                        926 00106$:
                                    927 ;	quantum/action.c:382: process_record_handler(record);
      007110 12 43 20         [24]  928 	lcall	_ak820_outline_0116
      007113 C0 05            [24]  929 	push	ar5
      007115 C0 04            [24]  930 	push	ar4
      007117 12 71 28         [24]  931 	lcall	_process_record_handler
      00711A D0 04            [24]  932 	pop	ar4
      00711C D0 05            [24]  933 	pop	ar5
                                    934 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00711E 90 05 98         [24]  935 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007121 EC               [12]  936 	mov	a,r4
      007122 F0               [24]  937 	movx	@dptr,a
      007123 8D 82            [24]  938 	mov	dpl, r5
                                    939 ;	quantum/action.c:392: }
      007125 02 2E BB         [24]  940 	ljmp	_ak820_oneshot_post
                                    941 ;------------------------------------------------------------
                                    942 ;Allocation info for local variables in function 'process_record_handler'
                                    943 ;------------------------------------------------------------
                                    944 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_641'
                                    945 ;record        Allocated with name '_process_record_handler_record_10000_642'
                                    946 ;action        Allocated with name '_process_record_handler_action_10000_642'
                                    947 ;------------------------------------------------------------
                                    948 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    949 ;	-----------------------------------------
                                    950 ;	 function process_record_handler
                                    951 ;	-----------------------------------------
      007128                        952 _process_record_handler:
      007128 12 38 43         [24]  953 	lcall	_ak820_outline_0103
      00712B 90 08 25         [24]  954 	mov	dptr,#_process_record_handler_record_argument_10000_641
      00712E 12 38 48         [24]  955 	lcall	_ak820_outline_0104
                                    956 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007131 90 08 25         [24]  957 	mov	dptr,#_process_record_handler_record_argument_10000_641
      007134 12 37 B7         [24]  958 	lcall	_ak820_outline_0008
                                    959 ;	quantum/action.c:405: if (record->keycode) {
      007137 4C               [12]  960 	orl	a,r4
      007138 60 19            [24]  961 	jz	00102$
                                    962 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      00713A 12 38 60         [24]  963 	lcall	_ak820_outline_0121
      00713D C0 07            [24]  964 	push	ar7
      00713F C0 06            [24]  965 	push	ar6
      007141 12 94 04         [24]  966 	lcall	_action_for_keycode
      007144 12 43 41         [24]  967 	lcall	_ak820_outline_0145
      007147 D0 06            [24]  968 	pop	ar6
      007149 D0 07            [24]  969 	pop	ar7
      00714B 90 08 27         [24]  970 	mov	dptr,#_process_record_handler_action_10000_642
      00714E 12 38 25         [24]  971 	lcall	_ak820_outline_0070
      007151 80 2B            [24]  972 	sjmp	00104$
      007153                        973 00102$:
                                    974 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007153 12 76 0F         [24]  975 	lcall	_ak820_outline_0018
      007156 7A 00            [12]  976 	mov	r2,#0x00
      007158 12 43 36         [24]  977 	lcall	_ak820_outline_0139
      00715B 12 42 CC         [24]  978 	lcall	_ak820_outline_0009
      00715E E0               [24]  979 	movx	a,@dptr
      00715F 90 09 62         [24]  980 	mov	dptr,#_ak820_resolve_key_PARM_2
      007162 F0               [24]  981 	movx	@dptr,a
      007163 8D 82            [24]  982 	mov	dpl, r5
      007165 8C 83            [24]  983 	mov	dph, r4
      007167 C0 07            [24]  984 	push	ar7
      007169 C0 06            [24]  985 	push	ar6
      00716B 12 79 AC         [24]  986 	lcall	_ak820_resolve_key
      00716E 12 94 04         [24]  987 	lcall	_action_for_keycode
      007171 12 43 41         [24]  988 	lcall	_ak820_outline_0145
      007174 D0 06            [24]  989 	pop	ar6
      007176 D0 07            [24]  990 	pop	ar7
      007178 90 08 27         [24]  991 	mov	dptr,#_process_record_handler_action_10000_642
      00717B 12 38 25         [24]  992 	lcall	_ak820_outline_0070
                                    993 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      00717E                        994 00104$:
                                    995 ;	quantum/action.c:429: process_action(record, action);
      00717E 90 0D 73         [24]  996 	mov	dptr,#___memcpy_PARM_2
      007181 74 27            [12]  997 	mov	a,#_process_record_handler_action_10000_642
      007183 F0               [24]  998 	movx	@dptr,a
      007184 74 08            [12]  999 	mov	a,#(_process_record_handler_action_10000_642 >> 8)
      007186 12 76 27         [24] 1000 	lcall	_ak820_outline_0049
      007189 12 4E ED         [24] 1001 	lcall	_ak820_outline_0106
      00718C 90 08 29         [24] 1002 	mov	dptr,#_process_action_PARM_2
      00718F F5 F0            [12] 1003 	mov	b,a
      007191 C0 07            [24] 1004 	push	ar7
      007193 C0 06            [24] 1005 	push	ar6
      007195 12 B6 6B         [24] 1006 	lcall	___memcpy
      007198 D0 06            [24] 1007 	pop	ar6
      00719A D0 07            [24] 1008 	pop	ar7
      00719C 12 43 20         [24] 1009 	lcall	_ak820_outline_0116
                                   1010 ;	quantum/action.c:430: }
      00719F 02 71 A2         [24] 1011 	ljmp	_process_action
                                   1012 ;------------------------------------------------------------
                                   1013 ;Allocation info for local variables in function 'register_mouse'
                                   1014 ;------------------------------------------------------------
                                   1015 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1016 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_650'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function process_action
                                   1021 ;	-----------------------------------------
      0071A2                       1022 _process_action:
      0071A2 12 38 43         [24] 1023 	lcall	_ak820_outline_0103
      0071A5 90 08 2B         [24] 1024 	mov	dptr,#_process_action_record_argument_10000_653
      0071A8 12 38 48         [24] 1025 	lcall	_ak820_outline_0104
                                   1026 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0071AB 90 08 2B         [24] 1027 	mov	dptr,#_process_action_record_argument_10000_653
      0071AE 12 37 A0         [24] 1028 	lcall	_ak820_outline_0004
                                   1029 ;	quantum/action.c:501: pressed = record->event.pressed;
      0071B1 A3               [24] 1030 	inc	dptr
      0071B2 A3               [24] 1031 	inc	dptr
      0071B3 A3               [24] 1032 	inc	dptr
      0071B4 A3               [24] 1033 	inc	dptr
      0071B5 A3               [24] 1034 	inc	dptr
      0071B6 E0               [24] 1035 	movx	a,@dptr
      0071B7 F5 27            [12] 1036 	mov	_process_action_sloc0_1_0,a
                                   1037 ;	quantum/action.c:525: switch (action.kind.id) {
      0071B9 90 08 2A         [24] 1038 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0071BC E0               [24] 1039 	movx	a,@dptr
      0071BD C4               [12] 1040 	swap	a
      0071BE 54 0F            [12] 1041 	anl	a,#0x0f
      0071C0 FD               [12] 1042 	mov  r5,a
      0071C1 24 F4            [12] 1043 	add	a,#0xff - 0x0b
      0071C3 50 03            [24] 1044 	jnc	00434$
      0071C5 02 74 43         [24] 1045 	ljmp	00181$
      0071C8                       1046 00434$:
                                   1047 ;	free result
      0071C8 ED               [12] 1048 	mov	a,r5
      0071C9 24 0A            [12] 1049 	add	a,#(00435$-3-.)
      0071CB 83               [24] 1050 	movc	a,@a+pc
      0071CC F5 82            [12] 1051 	mov	dpl,a
      0071CE ED               [12] 1052 	mov	a,r5
      0071CF 24 10            [12] 1053 	add	a,#(00436$-3-.)
      0071D1 83               [24] 1054 	movc	a,@a+pc
      0071D2 F5 83            [12] 1055 	mov	dph,a
      0071D4 E4               [12] 1056 	clr	a
      0071D5 73               [24] 1057 	jmp	@a+dptr
      0071D6                       1058 00435$:
      0071D6 EE                    1059 	.db	00102$
      0071D7 EE                    1060 	.db	00102$
      0071D8 43                    1061 	.db	00181$
      0071D9 43                    1062 	.db	00181$
      0071DA 78                    1063 	.db	00123$
      0071DB 43                    1064 	.db	00181$
      0071DC 43                    1065 	.db	00181$
      0071DD 43                    1066 	.db	00181$
      0071DE D8                    1067 	.db	00131$
      0071DF AA                    1068 	.db	00147$
      0071E0 D0                    1069 	.db	00152$
      0071E1 D0                    1070 	.db	00152$
      0071E2                       1071 00436$:
      0071E2 71                    1072 	.db	00102$>>8
      0071E3 71                    1073 	.db	00102$>>8
      0071E4 74                    1074 	.db	00181$>>8
      0071E5 74                    1075 	.db	00181$>>8
      0071E6 72                    1076 	.db	00123$>>8
      0071E7 74                    1077 	.db	00181$>>8
      0071E8 74                    1078 	.db	00181$>>8
      0071E9 74                    1079 	.db	00181$>>8
      0071EA 72                    1080 	.db	00131$>>8
      0071EB 73                    1081 	.db	00147$>>8
      0071EC 73                    1082 	.db	00152$>>8
      0071ED 73                    1083 	.db	00152$>>8
                                   1084 ;	quantum/action.c:528: case ACT_RMODS: {
      0071EE                       1085 00102$:
                                   1086 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0071EE 90 08 2A         [24] 1087 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0071F1 E0               [24] 1088 	movx	a,@dptr
      0071F2 54 F0            [12] 1089 	anl	a,#0xf0
      0071F4 70 06            [24] 1090 	jnz	00194$
      0071F6 12 76 4E         [24] 1091 	lcall	_ak820_outline_0109
      0071F9 FD               [12] 1092 	mov	r5,a
      0071FA 80 07            [24] 1093 	sjmp	00195$
      0071FC                       1094 00194$:
      0071FC 12 76 4E         [24] 1095 	lcall	_ak820_outline_0109
      0071FF C4               [12] 1096 	swap	a
      007200 54 F0            [12] 1097 	anl	a,#0xf0
      007202 FD               [12] 1098 	mov	r5,a
      007203                       1099 00195$:
                                   1100 ;	quantum/action.c:531: if (pressed) {
      007203 E5 27            [12] 1101 	mov	a,_process_action_sloc0_1_0
      007205 60 35            [24] 1102 	jz	00119$
                                   1103 ;	quantum/action.c:532: if (mods) {
      007207 ED               [12] 1104 	mov	a,r5
      007208 60 29            [24] 1105 	jz	00110$
                                   1106 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00720A 12 76 60         [24] 1107 	lcall	_ak820_outline_0154
      00720D FC               [12] 1108 	mov	r4,a
      00720E BC E0 00         [24] 1109 	cjne	r4,#0xe0,00440$
      007211                       1110 00440$:
      007211 40 07            [24] 1111 	jc	00108$
      007213 12 76 60         [24] 1112 	lcall	_ak820_outline_0154
      007216 24 18            [12] 1113 	add	a,#0xff - 0xe7
      007218 50 0A            [24] 1114 	jnc	00104$
                                   1115 ;	free result
      00721A                       1116 00108$:
      00721A 7B 29            [12] 1117 	mov	r3,#_process_action_PARM_2
      00721C 7C 08            [12] 1118 	mov	r4,#(_process_action_PARM_2 >> 8)
      00721E 12 33 FC         [24] 1119 	lcall	_ak820_outline_0122
      007221 E0               [24] 1120 	movx	a,@dptr
      007222 70 07            [24] 1121 	jnz	00105$
      007224                       1122 00104$:
                                   1123 ;	quantum/action.c:537: add_owned_mods(mods);
      007224 8D 82            [24] 1124 	mov	dpl, r5
      007226 12 7C 16         [24] 1125 	lcall	_add_owned_mods
      007229 80 05            [24] 1126 	sjmp	00106$
      00722B                       1127 00105$:
                                   1128 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      00722B 8D 82            [24] 1129 	mov	dpl, r5
      00722D 12 7C 35         [24] 1130 	lcall	_add_owned_weak_mods
      007230                       1131 00106$:
                                   1132 ;	quantum/action.c:541: send_keyboard_report();
      007230 12 7F 52         [24] 1133 	lcall	_send_keyboard_report
      007233                       1134 00110$:
                                   1135 ;	quantum/action.c:543: register_code(action.key.code);
      007233 12 76 37         [24] 1136 	lcall	_ak820_outline_0074
      007236 12 74 5A         [24] 1137 	lcall	_register_code
      007239 02 74 43         [24] 1138 	ljmp	00181$
      00723C                       1139 00119$:
                                   1140 ;	quantum/action.c:545: unregister_code(action.key.code);
      00723C 12 76 37         [24] 1141 	lcall	_ak820_outline_0074
      00723F C0 05            [24] 1142 	push	ar5
      007241 12 74 C7         [24] 1143 	lcall	_unregister_code
      007244 D0 05            [24] 1144 	pop	ar5
                                   1145 ;	quantum/action.c:546: if (mods) {
      007246 ED               [12] 1146 	mov	a,r5
      007247 70 03            [24] 1147 	jnz	00444$
      007249 02 74 43         [24] 1148 	ljmp	00181$
      00724C                       1149 00444$:
                                   1150 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00724C 12 76 60         [24] 1151 	lcall	_ak820_outline_0154
      00724F FC               [12] 1152 	mov	r4,a
      007250 BC E0 00         [24] 1153 	cjne	r4,#0xe0,00445$
      007253                       1154 00445$:
      007253 40 07            [24] 1155 	jc	00115$
      007255 12 76 60         [24] 1156 	lcall	_ak820_outline_0154
      007258 24 18            [12] 1157 	add	a,#0xff - 0xe7
      00725A 50 0A            [24] 1158 	jnc	00111$
                                   1159 ;	free result
      00725C                       1160 00115$:
      00725C 7B 29            [12] 1161 	mov	r3,#_process_action_PARM_2
      00725E 7C 08            [12] 1162 	mov	r4,#(_process_action_PARM_2 >> 8)
      007260 12 33 FC         [24] 1163 	lcall	_ak820_outline_0122
      007263 E0               [24] 1164 	movx	a,@dptr
      007264 70 07            [24] 1165 	jnz	00112$
      007266                       1166 00111$:
                                   1167 ;	quantum/action.c:548: del_owned_mods(mods);
      007266 8D 82            [24] 1168 	mov	dpl, r5
      007268 12 7C 26         [24] 1169 	lcall	_del_owned_mods
      00726B 80 05            [24] 1170 	sjmp	00113$
      00726D                       1171 00112$:
                                   1172 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      00726D 8D 82            [24] 1173 	mov	dpl, r5
      00726F 12 7C 45         [24] 1174 	lcall	_del_owned_weak_mods
      007272                       1175 00113$:
                                   1176 ;	quantum/action.c:552: send_keyboard_report();
      007272 12 7F 52         [24] 1177 	lcall	_send_keyboard_report
                                   1178 ;	quantum/action.c:555: } break;
      007275 02 74 43         [24] 1179 	ljmp	00181$
                                   1180 ;	quantum/action.c:632: case ACT_USAGE:
      007278                       1181 00123$:
                                   1182 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007278 74 07            [12] 1183 	mov	a,#0x07
      00727A 12 37 F0         [24] 1184 	lcall	_ak820_outline_0030
      00727D 12 37 CB         [24] 1185 	lcall	_ak820_outline_0010
      007280 C3               [12] 1186 	clr	c
      007281 EC               [12] 1187 	mov	a,r4
      007282 94 A5            [12] 1188 	subb	a,#0xa5
      007284 ED               [12] 1189 	mov	a,r5
      007285 94 00            [12] 1190 	subb	a,#0x00
      007287 40 15            [24] 1191 	jc	00125$
      007289 74 C2            [12] 1192 	mov	a,#0xc2
      00728B 9C               [12] 1193 	subb	a,r4
      00728C E4               [12] 1194 	clr	a
      00728D 9D               [12] 1195 	subb	a,r5
      00728E 40 0E            [24] 1196 	jc	00125$
                                   1197 ;	free result
                                   1198 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      007290 90 0A 8C         [24] 1199 	mov	dptr,#_owned_usage_key_PARM_2
      007293 E5 27            [12] 1200 	mov	a,_process_action_sloc0_1_0
      007295 F0               [24] 1201 	movx	@dptr,a
      007296 8E 82            [24] 1202 	mov	dpl, r6
      007298 12 7D FD         [24] 1203 	lcall	_owned_usage_key
                                   1204 ;	quantum/action.c:640: break;
      00729B 02 74 43         [24] 1205 	ljmp	00181$
      00729E                       1206 00125$:
                                   1207 ;	quantum/action.c:643: switch (action.usage.page) {
      00729E 12 76 3E         [24] 1208 	lcall	_ak820_outline_0084
      0072A1 FF               [12] 1209 	mov	r7,a
      0072A2 60 08            [24] 1210 	jz	00127$
      0072A4 BF 01 02         [24] 1211 	cjne	r7,#0x01,00452$
      0072A7 80 19            [24] 1212 	sjmp	00128$
      0072A9                       1213 00452$:
      0072A9 02 74 43         [24] 1214 	ljmp	00181$
                                   1215 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0072AC                       1216 00127$:
                                   1217 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0072AC E5 27            [12] 1218 	mov	a,_process_action_sloc0_1_0
      0072AE 60 05            [24] 1219 	jz	00196$
      0072B0 12 76 55         [24] 1220 	lcall	_ak820_outline_0129
      0072B3 80 04            [24] 1221 	sjmp	00197$
      0072B5                       1222 00196$:
      0072B5 7E 00            [12] 1223 	mov	r6,#0x00
      0072B7 7F 00            [12] 1224 	mov	r7,#0x00
      0072B9                       1225 00197$:
      0072B9 12 43 20         [24] 1226 	lcall	_ak820_outline_0116
      0072BC 12 6C A2         [24] 1227 	lcall	_host_system_send
                                   1228 ;	quantum/action.c:646: break;
      0072BF 02 74 43         [24] 1229 	ljmp	00181$
                                   1230 ;	quantum/action.c:647: case PAGE_CONSUMER:
      0072C2                       1231 00128$:
                                   1232 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      0072C2 E5 27            [12] 1233 	mov	a,_process_action_sloc0_1_0
      0072C4 60 05            [24] 1234 	jz	00198$
      0072C6 12 76 55         [24] 1235 	lcall	_ak820_outline_0129
      0072C9 80 04            [24] 1236 	sjmp	00199$
      0072CB                       1237 00198$:
      0072CB 7E 00            [12] 1238 	mov	r6,#0x00
      0072CD 7F 00            [12] 1239 	mov	r7,#0x00
      0072CF                       1240 00199$:
      0072CF 12 43 20         [24] 1241 	lcall	_ak820_outline_0116
      0072D2 12 6C D2         [24] 1242 	lcall	_host_consumer_send
                                   1243 ;	quantum/action.c:651: break;
      0072D5 02 74 43         [24] 1244 	ljmp	00181$
                                   1245 ;	quantum/action.c:658: case ACT_LAYER: {
      0072D8                       1246 00131$:
                                   1247 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      0072D8 90 08 2A         [24] 1248 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0072DB E0               [24] 1249 	movx	a,@dptr
      0072DC 54 03            [12] 1250 	anl	a,#0x03
      0072DE 90 08 2D         [24] 1251 	mov	dptr,#_process_action_on_40000_676
      0072E1 F0               [24] 1252 	movx	@dptr,a
                                   1253 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0072E2 E0               [24] 1254 	movx	a,@dptr
      0072E3 FF               [12] 1255 	mov	r7,a
      0072E4 60 11            [24] 1256 	jz	00200$
      0072E6 E5 27            [12] 1257 	mov	a,_process_action_sloc0_1_0
      0072E8 60 07            [24] 1258 	jz	00202$
      0072EA 8F 06            [24] 1259 	mov	ar6,r7
      0072EC 53 06 01         [24] 1260 	anl	ar6,#0x01
      0072EF 80 10            [24] 1261 	sjmp	00201$
      0072F1                       1262 00202$:
      0072F1 74 02            [12] 1263 	mov	a,#0x02
      0072F3 5F               [12] 1264 	anl	a,r7
      0072F4 FE               [12] 1265 	mov	r6,a
      0072F5 80 0A            [24] 1266 	sjmp	00201$
      0072F7                       1267 00200$:
      0072F7 E5 27            [12] 1268 	mov	a,_process_action_sloc0_1_0
      0072F9 B4 01 00         [24] 1269 	cjne	a,#0x01,00457$
      0072FC                       1270 00457$:
      0072FC 92 1D            [24] 1271 	mov  _process_action_sloc1_1_0,c
      0072FE E4               [12] 1272 	clr	a
      0072FF 33               [12] 1273 	rlc	a
      007300 FE               [12] 1274 	mov	r6,a
      007301                       1275 00201$:
      007301 EE               [12] 1276 	mov	a,r6
      007302 70 03            [24] 1277 	jnz	00458$
      007304 02 74 43         [24] 1278 	ljmp	00181$
      007307                       1279 00458$:
                                   1280 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007307 12 76 60         [24] 1281 	lcall	_ak820_outline_0154
      00730A C4               [12] 1282 	swap	a
      00730B 03               [12] 1283 	rr	a
      00730C 54 07            [12] 1284 	anl	a,#0x07
      00730E 25 E0            [12] 1285 	add	a,acc
      007310 25 E0            [12] 1286 	add	a,acc
      007312 FF               [12] 1287 	mov	r7,a
                                   1288 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007313 12 76 60         [24] 1289 	lcall	_ak820_outline_0154
      007316 54 0F            [12] 1290 	anl	a,#0x0f
      007318 FE               [12] 1291 	mov	r6,a
      007319 8F F0            [24] 1292 	mov	b,r7
      00731B 05 F0            [12] 1293 	inc	b
      00731D EE               [12] 1294 	mov	a,r6
      00731E 80 02            [24] 1295 	sjmp	00460$
      007320                       1296 00459$:
      007320 25 E0            [12] 1297 	add	a,acc
      007322                       1298 00460$:
      007322 D5 F0 FB         [24] 1299 	djnz	b,00459$
      007325 FE               [12] 1300 	mov	r6,a
                                   1301 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007326 12 76 60         [24] 1302 	lcall	_ak820_outline_0154
      007329 30 E4 11         [24] 1303 	jnb	acc.4,00204$
      00732C 8F F0            [24] 1304 	mov	b,r7
      00732E 05 F0            [12] 1305 	inc	b
      007330 74 0F            [12] 1306 	mov	a,#0x0f
      007332 80 02            [24] 1307 	sjmp	00463$
      007334                       1308 00462$:
      007334 25 E0            [12] 1309 	add	a,acc
      007336                       1310 00463$:
      007336 D5 F0 FB         [24] 1311 	djnz	b,00462$
      007339 F4               [12] 1312 	cpl	a
      00733A FF               [12] 1313 	mov	r7,a
      00733B 80 02            [24] 1314 	sjmp	00205$
      00733D                       1315 00204$:
      00733D 7F 00            [12] 1316 	mov	r7,#0x00
      00733F                       1317 00205$:
                                   1318 ;	quantum/action.c:666: bits |= mask;
      00733F EE               [12] 1319 	mov	a,r6
      007340 42 07            [12] 1320 	orl	ar7,a
                                   1321 ;	quantum/action.c:667: if (!on) {
      007342 90 08 2D         [24] 1322 	mov	dptr,#_process_action_on_40000_676
      007345 E0               [24] 1323 	movx	a,@dptr
      007346 70 31            [24] 1324 	jnz	00143$
                                   1325 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      007348 12 76 3E         [24] 1326 	lcall	_ak820_outline_0084
      00734B FE               [12] 1327 	mov	r6,a
      00734C 2E               [12] 1328 	add	a,r6
                                   1329 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      00734D 90 73 51         [24] 1330 	mov	dptr,#00465$
      007350 73               [24] 1331 	jmp	@a+dptr
      007351                       1332 00465$:
      007351 80 06            [24] 1333 	sjmp	00132$
      007353 80 0C            [24] 1334 	sjmp	00133$
      007355 80 12            [24] 1335 	sjmp	00134$
      007357 80 18            [24] 1336 	sjmp	00135$
      007359                       1337 00132$:
      007359 8F 82            [24] 1338 	mov	dpl, r7
      00735B 12 76 BB         [24] 1339 	lcall	_default_layer_and
      00735E 02 74 43         [24] 1340 	ljmp	00181$
                                   1341 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      007361                       1342 00133$:
      007361 8F 82            [24] 1343 	mov	dpl, r7
      007363 12 76 AA         [24] 1344 	lcall	_default_layer_or
      007366 02 74 43         [24] 1345 	ljmp	00181$
                                   1346 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      007369                       1347 00134$:
      007369 8F 82            [24] 1348 	mov	dpl, r7
      00736B 12 76 D1         [24] 1349 	lcall	_default_layer_xor
      00736E 02 74 43         [24] 1350 	ljmp	00181$
                                   1351 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      007371                       1352 00135$:
      007371 8F 82            [24] 1353 	mov	dpl, r7
      007373 12 76 9F         [24] 1354 	lcall	_default_layer_set
                                   1355 ;	quantum/action.c:673: }
      007376 02 74 43         [24] 1356 	ljmp	00181$
      007379                       1357 00143$:
                                   1358 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      007379 12 76 3E         [24] 1359 	lcall	_ak820_outline_0084
      00737C FE               [12] 1360 	mov	r6,a
      00737D 2E               [12] 1361 	add	a,r6
                                   1362 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      00737E 90 73 82         [24] 1363 	mov	dptr,#00466$
      007381 73               [24] 1364 	jmp	@a+dptr
      007382                       1365 00466$:
      007382 80 06            [24] 1366 	sjmp	00137$
      007384 80 0C            [24] 1367 	sjmp	00138$
      007386 80 12            [24] 1368 	sjmp	00139$
      007388 80 18            [24] 1369 	sjmp	00140$
      00738A                       1370 00137$:
      00738A 8F 82            [24] 1371 	mov	dpl, r7
      00738C 12 78 54         [24] 1372 	lcall	_layer_and
      00738F 02 74 43         [24] 1373 	ljmp	00181$
                                   1374 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      007392                       1375 00138$:
      007392 8F 82            [24] 1376 	mov	dpl, r7
      007394 12 78 43         [24] 1377 	lcall	_layer_or
      007397 02 74 43         [24] 1378 	ljmp	00181$
                                   1379 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      00739A                       1380 00139$:
      00739A 8F 82            [24] 1381 	mov	dpl, r7
      00739C 12 78 6A         [24] 1382 	lcall	_layer_xor
      00739F 02 74 43         [24] 1383 	ljmp	00181$
                                   1384 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      0073A2                       1385 00140$:
      0073A2 8F 82            [24] 1386 	mov	dpl, r7
      0073A4 12 77 E0         [24] 1387 	lcall	_layer_state_set
                                   1388 ;	quantum/action.c:683: break;
      0073A7 02 74 43         [24] 1389 	ljmp	00181$
                                   1390 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      0073AA                       1391 00147$:
                                   1392 ;	quantum/action.c:686: if (pressed) {
      0073AA E5 27            [12] 1393 	mov	a,_process_action_sloc0_1_0
      0073AC 60 11            [24] 1394 	jz	00149$
                                   1395 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      0073AE 12 76 4E         [24] 1396 	lcall	_ak820_outline_0109
      0073B1 F5 82            [12] 1397 	mov	dpl,a
      0073B3 12 77 41         [24] 1398 	lcall	_layer_hold_on
                                   1399 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      0073B6 12 76 37         [24] 1400 	lcall	_ak820_outline_0074
      0073B9 12 75 7D         [24] 1401 	lcall	_register_mods
      0073BC 02 74 43         [24] 1402 	ljmp	00181$
      0073BF                       1403 00149$:
                                   1404 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      0073BF 12 76 37         [24] 1405 	lcall	_ak820_outline_0074
      0073C2 12 75 91         [24] 1406 	lcall	_unregister_mods
                                   1407 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      0073C5 12 76 4E         [24] 1408 	lcall	_ak820_outline_0109
      0073C8 F5 82            [12] 1409 	mov	dpl,a
      0073CA 12 77 79         [24] 1410 	lcall	_layer_hold_off
                                   1411 ;	quantum/action.c:693: break;
      0073CD 02 74 43         [24] 1412 	ljmp	00181$
                                   1413 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      0073D0                       1414 00152$:
                                   1415 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      0073D0 12 76 60         [24] 1416 	lcall	_ak820_outline_0154
      0073D3 FF               [12] 1417 	mov	r7,a
      0073D4 BF F1 02         [24] 1418 	cjne	r7,#0xf1,00468$
      0073D7 80 0A            [24] 1419 	sjmp	00154$
      0073D9                       1420 00468$:
      0073D9 BF F2 02         [24] 1421 	cjne	r7,#0xf2,00469$
      0073DC 80 19            [24] 1422 	sjmp	00155$
      0073DE                       1423 00469$:
                                   1424 ;	quantum/action.c:712: momentary_layer_action:
      0073DE BF F3 3B         [24] 1425 	cjne	r7,#0xf3,00160$
      0073E1 80 28            [24] 1426 	sjmp	00156$
      0073E3                       1427 00154$:
                                   1428 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0073E3 E5 27            [12] 1429 	mov	a,_process_action_sloc0_1_0
      0073E5 60 08            [24] 1430 	jz	00206$
      0073E7 12 76 1E         [24] 1431 	lcall	_ak820_outline_0038
      0073EA 12 77 41         [24] 1432 	lcall	_layer_hold_on
      0073ED 80 54            [24] 1433 	sjmp	00181$
      0073EF                       1434 00206$:
      0073EF 12 76 1E         [24] 1435 	lcall	_ak820_outline_0038
      0073F2 12 77 79         [24] 1436 	lcall	_layer_hold_off
                                   1437 ;	quantum/action.c:714: break;
                                   1438 ;	quantum/action.c:715: case OP_OFF_ON:
      0073F5 80 4C            [24] 1439 	sjmp	00181$
      0073F7                       1440 00155$:
                                   1441 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0073F7 E5 27            [12] 1442 	mov	a,_process_action_sloc0_1_0
      0073F9 60 08            [24] 1443 	jz	00208$
      0073FB 12 76 1E         [24] 1444 	lcall	_ak820_outline_0038
      0073FE 12 78 25         [24] 1445 	lcall	_layer_off
      007401 80 40            [24] 1446 	sjmp	00181$
      007403                       1447 00208$:
      007403 12 76 1E         [24] 1448 	lcall	_ak820_outline_0038
      007406 12 78 0A         [24] 1449 	lcall	_layer_on
                                   1450 ;	quantum/action.c:717: break;
                                   1451 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007409 80 38            [24] 1452 	sjmp	00181$
      00740B                       1453 00156$:
                                   1454 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00740B E5 27            [12] 1455 	mov	a,_process_action_sloc0_1_0
      00740D 60 08            [24] 1456 	jz	00210$
      00740F 12 76 1E         [24] 1457 	lcall	_ak820_outline_0038
      007412 12 77 F4         [24] 1458 	lcall	_layer_move
      007415 80 2C            [24] 1459 	sjmp	00181$
      007417                       1460 00210$:
      007417 12 77 EE         [24] 1461 	lcall	_layer_clear
                                   1462 ;	quantum/action.c:720: break;
                                   1463 ;	quantum/action.c:766: default:
      00741A 80 27            [24] 1464 	sjmp	00181$
      00741C                       1465 00160$:
                                   1466 ;	quantum/action.c:773: if (pressed) {
      00741C E5 27            [12] 1467 	mov	a,_process_action_sloc0_1_0
      00741E 60 08            [24] 1468 	jz	00163$
                                   1469 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007420 12 76 37         [24] 1470 	lcall	_ak820_outline_0074
      007423 12 74 5A         [24] 1471 	lcall	_register_code
                                   1472 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007426 80 1B            [24] 1473 	sjmp	00181$
      007428                       1474 00163$:
                                   1475 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007428 12 76 60         [24] 1476 	lcall	_ak820_outline_0154
      00742B FF               [12] 1477 	mov	r7,a
      00742C BF 39 0E         [24] 1478 	cjne	r7,#0x39,00175$
                                   1479 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      00742F 7F 50            [12] 1480 	mov	r7,#0x50
      007431                       1481 00187$:
      007431 EF               [12] 1482 	mov	a,r7
      007432 60 09            [24] 1483 	jz	00175$
      007434 90 00 01         [24] 1484 	mov	dptr,#0x0001
      007437 12 58 7C         [24] 1485 	lcall	_mDelaymS
      00743A 1F               [12] 1486 	dec	r7
                                   1487 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      00743B 80 F4            [24] 1488 	sjmp	00187$
      00743D                       1489 00175$:
                                   1490 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      00743D 12 76 37         [24] 1491 	lcall	_ak820_outline_0074
      007440 12 74 C7         [24] 1492 	lcall	_unregister_code
                                   1493 ;	quantum/action.c:866: }
      007443                       1494 00181$:
                                   1495 ;	quantum/action.c:887: switch (action.kind.id) {
      007443 90 08 2A         [24] 1496 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007446 E0               [24] 1497 	movx	a,@dptr
      007447 C4               [12] 1498 	swap	a
      007448 54 0F            [12] 1499 	anl	a,#0x0f
      00744A FF               [12] 1500 	mov	r7,a
      00744B BF 08 02         [24] 1501 	cjne	r7,#0x08,00478$
      00744E 80 03            [24] 1502 	sjmp	00183$
      007450                       1503 00478$:
      007450 BF 09 06         [24] 1504 	cjne	r7,#0x09,00192$
                                   1505 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007453                       1506 00183$:
                                   1507 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007453 12 6C 07         [24] 1508 	lcall	_host_keyboard_leds
                                   1509 ;	quantum/action.c:898: }
                                   1510 ;	quantum/action.c:951: }
      007456 02 96 B9         [24] 1511 	ljmp	_led_set
      007459                       1512 00192$:
      007459 22               [24] 1513 	ret
                                   1514 ;------------------------------------------------------------
                                   1515 ;Allocation info for local variables in function 'register_code'
                                   1516 ;------------------------------------------------------------
                                   1517 ;code          Allocated with name '_register_code_code_10000_710'
                                   1518 ;------------------------------------------------------------
                                   1519 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1520 ;	-----------------------------------------
                                   1521 ;	 function register_code
                                   1522 ;	-----------------------------------------
      00745A                       1523 _register_code:
      00745A E5 82            [12] 1524 	mov	a,dpl
      00745C 90 08 2E         [24] 1525 	mov	dptr,#_register_code_code_10000_710
      00745F F0               [24] 1526 	movx	@dptr,a
                                   1527 ;	quantum/action.c:958: if (code == KC_NO) {
      007460 E0               [24] 1528 	movx	a,@dptr
      007461 FF               [12] 1529 	mov	r7,a
      007462 70 01            [24] 1530 	jnz	00123$
                                   1531 ;	quantum/action.c:959: return;
      007464 22               [24] 1532 	ret
      007465                       1533 00123$:
                                   1534 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007465 BF 04 00         [24] 1535 	cjne	r7,#0x04,00186$
      007468                       1536 00186$:
      007468 40 12            [24] 1537 	jc	00119$
      00746A EF               [12] 1538 	mov	a,r7
      00746B 24 5B            [12] 1539 	add	a,#0xff - 0xa4
      00746D 40 0D            [24] 1540 	jc	00119$
                                   1541 ;	free result
                                   1542 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      00746F 8F 82            [24] 1543 	mov	dpl, r7
      007471 12 7C BA         [24] 1544 	lcall	_add_owned_key
      007474 E5 82            [12] 1545 	mov	a, dpl
      007476 70 01            [24] 1546 	jnz	00104$
      007478 22               [24] 1547 	ret
      007479                       1548 00104$:
                                   1549 ;	quantum/action.c:1013: send_keyboard_report();
      007479 02 7F 52         [24] 1550 	ljmp	_send_keyboard_report
      00747C                       1551 00119$:
                                   1552 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      00747C 12 76 65         [24] 1553 	lcall	_ak820_outline_0162
      00747F BF E0 00         [24] 1554 	cjne	r7,#0xe0,00190$
      007482                       1555 00190$:
      007482 40 1A            [24] 1556 	jc	00115$
      007484 EF               [12] 1557 	mov	a,r7
      007485 24 18            [12] 1558 	add	a,#0xff - 0xe7
      007487 40 15            [24] 1559 	jc	00115$
                                   1560 ;	free result
                                   1561 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      007489 74 07            [12] 1562 	mov	a,#0x07
      00748B 5F               [12] 1563 	anl	a,r7
      00748C 12 76 30         [24] 1564 	lcall	_ak820_outline_0062
      00748F 80 02            [24] 1565 	sjmp	00194$
      007491                       1566 00193$:
      007491 25 E0            [12] 1567 	add	a,acc
      007493                       1568 00194$:
      007493 D5 F0 FB         [24] 1569 	djnz	b,00193$
      007496 F5 82            [12] 1570 	mov	dpl,a
      007498 12 7C 16         [24] 1571 	lcall	_add_owned_mods
                                   1572 ;	quantum/action.c:1016: send_keyboard_report();
      00749B 02 7F 52         [24] 1573 	ljmp	_send_keyboard_report
      00749E                       1574 00115$:
                                   1575 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00749E 12 76 65         [24] 1576 	lcall	_ak820_outline_0162
      0074A1 BF A5 00         [24] 1577 	cjne	r7,#0xa5,00195$
      0074A4                       1578 00195$:
      0074A4 40 05            [24] 1579 	jc	00113$
      0074A6 EF               [12] 1580 	mov	a,r7
      0074A7 24 58            [12] 1581 	add	a,#0xff - 0xa7
      0074A9 50 0D            [24] 1582 	jnc	00108$
                                   1583 ;	free result
      0074AB                       1584 00113$:
      0074AB 12 76 65         [24] 1585 	lcall	_ak820_outline_0162
      0074AE BF A8 00         [24] 1586 	cjne	r7,#0xa8,00198$
      0074B1                       1587 00198$:
      0074B1 40 13            [24] 1588 	jc	00125$
      0074B3 EF               [12] 1589 	mov	a,r7
      0074B4 24 3D            [12] 1590 	add	a,#0xff - 0xc2
      0074B6 40 0E            [24] 1591 	jc	00125$
                                   1592 ;	free result
      0074B8                       1593 00108$:
                                   1594 ;	quantum/action.c:1021: owned_usage_key(code, true);
      0074B8 12 76 65         [24] 1595 	lcall	_ak820_outline_0162
      0074BB 90 0A 8C         [24] 1596 	mov	dptr,#_owned_usage_key_PARM_2
      0074BE 74 01            [12] 1597 	mov	a,#0x01
      0074C0 F0               [24] 1598 	movx	@dptr,a
      0074C1 8F 82            [24] 1599 	mov	dpl, r7
                                   1600 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1601 ;	quantum/action.c:1031: }
      0074C3 02 7D FD         [24] 1602 	ljmp	_owned_usage_key
      0074C6                       1603 00125$:
      0074C6 22               [24] 1604 	ret
                                   1605 ;------------------------------------------------------------
                                   1606 ;Allocation info for local variables in function 'unregister_code'
                                   1607 ;------------------------------------------------------------
                                   1608 ;code          Allocated with name '_unregister_code_code_10000_724'
                                   1609 ;------------------------------------------------------------
                                   1610 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1611 ;	-----------------------------------------
                                   1612 ;	 function unregister_code
                                   1613 ;	-----------------------------------------
      0074C7                       1614 _unregister_code:
      0074C7 E5 82            [12] 1615 	mov	a,dpl
      0074C9 90 08 2F         [24] 1616 	mov	dptr,#_unregister_code_code_10000_724
      0074CC F0               [24] 1617 	movx	@dptr,a
                                   1618 ;	quantum/action.c:1038: if (code == KC_NO) {
      0074CD E0               [24] 1619 	movx	a,@dptr
      0074CE FF               [12] 1620 	mov	r7,a
      0074CF 70 01            [24] 1621 	jnz	00121$
                                   1622 ;	quantum/action.c:1039: return;
      0074D1 22               [24] 1623 	ret
      0074D2                       1624 00121$:
                                   1625 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      0074D2 BF 04 00         [24] 1626 	cjne	r7,#0x04,00184$
      0074D5                       1627 00184$:
      0074D5 40 12            [24] 1628 	jc	00117$
      0074D7 EF               [12] 1629 	mov	a,r7
      0074D8 24 5B            [12] 1630 	add	a,#0xff - 0xa4
      0074DA 40 0D            [24] 1631 	jc	00117$
                                   1632 ;	free result
                                   1633 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      0074DC 8F 82            [24] 1634 	mov	dpl, r7
      0074DE 12 7D 34         [24] 1635 	lcall	_del_owned_key
      0074E1 E5 82            [12] 1636 	mov	a, dpl
      0074E3 70 01            [24] 1637 	jnz	00102$
      0074E5 22               [24] 1638 	ret
      0074E6                       1639 00102$:
                                   1640 ;	quantum/action.c:1080: send_keyboard_report();
      0074E6 02 7F 52         [24] 1641 	ljmp	_send_keyboard_report
      0074E9                       1642 00117$:
                                   1643 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      0074E9 12 76 6B         [24] 1644 	lcall	_ak820_outline_0163
      0074EC BF E0 00         [24] 1645 	cjne	r7,#0xe0,00188$
      0074EF                       1646 00188$:
      0074EF 40 1A            [24] 1647 	jc	00113$
      0074F1 EF               [12] 1648 	mov	a,r7
      0074F2 24 18            [12] 1649 	add	a,#0xff - 0xe7
      0074F4 40 15            [24] 1650 	jc	00113$
                                   1651 ;	free result
                                   1652 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      0074F6 74 07            [12] 1653 	mov	a,#0x07
      0074F8 5F               [12] 1654 	anl	a,r7
      0074F9 12 76 30         [24] 1655 	lcall	_ak820_outline_0062
      0074FC 80 02            [24] 1656 	sjmp	00192$
      0074FE                       1657 00191$:
      0074FE 25 E0            [12] 1658 	add	a,acc
      007500                       1659 00192$:
      007500 D5 F0 FB         [24] 1660 	djnz	b,00191$
      007503 F5 82            [12] 1661 	mov	dpl,a
      007505 12 7C 26         [24] 1662 	lcall	_del_owned_mods
                                   1663 ;	quantum/action.c:1083: send_keyboard_report();
      007508 02 7F 52         [24] 1664 	ljmp	_send_keyboard_report
      00750B                       1665 00113$:
                                   1666 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00750B 12 76 6B         [24] 1667 	lcall	_ak820_outline_0163
      00750E BF A5 00         [24] 1668 	cjne	r7,#0xa5,00193$
      007511                       1669 00193$:
      007511 40 05            [24] 1670 	jc	00111$
      007513 EF               [12] 1671 	mov	a,r7
      007514 24 58            [12] 1672 	add	a,#0xff - 0xa7
      007516 50 0D            [24] 1673 	jnc	00106$
                                   1674 ;	free result
      007518                       1675 00111$:
      007518 12 76 6B         [24] 1676 	lcall	_ak820_outline_0163
      00751B BF A8 00         [24] 1677 	cjne	r7,#0xa8,00196$
      00751E                       1678 00196$:
      00751E 40 12            [24] 1679 	jc	00123$
      007520 EF               [12] 1680 	mov	a,r7
      007521 24 3D            [12] 1681 	add	a,#0xff - 0xc2
      007523 40 0D            [24] 1682 	jc	00123$
                                   1683 ;	free result
      007525                       1684 00106$:
                                   1685 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007525 12 76 6B         [24] 1686 	lcall	_ak820_outline_0163
      007528 90 0A 8C         [24] 1687 	mov	dptr,#_owned_usage_key_PARM_2
      00752B E4               [12] 1688 	clr	a
      00752C F0               [24] 1689 	movx	@dptr,a
      00752D 8F 82            [24] 1690 	mov	dpl, r7
                                   1691 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1692 ;	quantum/action.c:1098: }
      00752F 02 7D FD         [24] 1693 	ljmp	_owned_usage_key
      007532                       1694 00123$:
      007532 22               [24] 1695 	ret
                                   1696 ;------------------------------------------------------------
                                   1697 ;Allocation info for local variables in function 'tap_code_delay'
                                   1698 ;------------------------------------------------------------
                                   1699 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1700 ;code          Allocated with name '_tap_code_delay_code_10000_737'
                                   1701 ;i             Allocated with name '_tap_code_delay_i_20000_739'
                                   1702 ;i             Allocated with name '_tap_code_delay_i_50000_742'
                                   1703 ;------------------------------------------------------------
                                   1704 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1705 ;	-----------------------------------------
                                   1706 ;	 function tap_code_delay
                                   1707 ;	-----------------------------------------
      007533                       1708 _tap_code_delay:
      007533 E5 82            [12] 1709 	mov	a,dpl
      007535 90 08 32         [24] 1710 	mov	dptr,#_tap_code_delay_code_10000_737
      007538 F0               [24] 1711 	movx	@dptr,a
                                   1712 ;	quantum/action.c:1106: register_code(code);
      007539 E0               [24] 1713 	movx	a,@dptr
      00753A FF               [12] 1714 	mov	r7,a
      00753B F5 82            [12] 1715 	mov	dpl,a
      00753D C0 07            [24] 1716 	push	ar7
      00753F 12 74 5A         [24] 1717 	lcall	_register_code
      007542 D0 07            [24] 1718 	pop	ar7
                                   1719 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007544 90 08 30         [24] 1720 	mov	dptr,#_tap_code_delay_PARM_2
      007547 12 43 0E         [24] 1721 	lcall	_ak820_outline_0096
      00754A                       1722 00110$:
      00754A ED               [12] 1723 	mov	a,r5
      00754B 4E               [12] 1724 	orl	a,r6
      00754C 60 0D            [24] 1725 	jz	00105$
                                   1726 ;	quantum/action.c:1108: wait_ms(1);
      00754E 90 00 01         [24] 1727 	mov	dptr,#0x0001
      007551 12 58 7C         [24] 1728 	lcall	_mDelaymS
                                   1729 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007554 1D               [12] 1730 	dec	r5
      007555 BD FF 01         [24] 1731 	cjne	r5,#0xff,00141$
      007558 1E               [12] 1732 	dec	r6
      007559                       1733 00141$:
      007559 80 EF            [24] 1734 	sjmp	00110$
      00755B                       1735 00105$:
                                   1736 ;	quantum/action.c:1110: unregister_code(code);
      00755B 8F 82            [24] 1737 	mov	dpl, r7
                                   1738 ;	quantum/action.c:1111: }
      00755D 02 74 C7         [24] 1739 	ljmp	_unregister_code
                                   1740 ;------------------------------------------------------------
                                   1741 ;Allocation info for local variables in function 'tap_code'
                                   1742 ;------------------------------------------------------------
                                   1743 ;code          Allocated with name '_tap_code_code_10000_744'
                                   1744 ;------------------------------------------------------------
                                   1745 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1746 ;	-----------------------------------------
                                   1747 ;	 function tap_code
                                   1748 ;	-----------------------------------------
      007560                       1749 _tap_code:
      007560 E5 82            [12] 1750 	mov	a,dpl
      007562 90 08 33         [24] 1751 	mov	dptr,#_tap_code_code_10000_744
      007565 F0               [24] 1752 	movx	@dptr,a
                                   1753 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007566 E0               [24] 1754 	movx	a,@dptr
      007567 FF               [12] 1755 	mov	r7,a
      007568 BF 39 04         [24] 1756 	cjne	r7,#0x39,00103$
      00756B 7E 50            [12] 1757 	mov	r6,#0x50
      00756D 80 02            [24] 1758 	sjmp	00104$
      00756F                       1759 00103$:
      00756F 7E 00            [12] 1760 	mov	r6,#0x00
      007571                       1761 00104$:
      007571 90 08 30         [24] 1762 	mov	dptr,#_tap_code_delay_PARM_2
      007574 EE               [12] 1763 	mov	a,r6
      007575 12 38 65         [24] 1764 	lcall	_ak820_outline_0123
      007578 8F 82            [24] 1765 	mov	dpl, r7
                                   1766 ;	quantum/action.c:1119: }
      00757A 02 75 33         [24] 1767 	ljmp	_tap_code_delay
                                   1768 ;------------------------------------------------------------
                                   1769 ;Allocation info for local variables in function 'register_mods'
                                   1770 ;------------------------------------------------------------
                                   1771 ;mods          Allocated with name '_register_mods_mods_10000_746'
                                   1772 ;------------------------------------------------------------
                                   1773 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1774 ;	-----------------------------------------
                                   1775 ;	 function register_mods
                                   1776 ;	-----------------------------------------
      00757D                       1777 _register_mods:
      00757D E5 82            [12] 1778 	mov	a,dpl
      00757F 90 08 34         [24] 1779 	mov	dptr,#_register_mods_mods_10000_746
      007582 F0               [24] 1780 	movx	@dptr,a
                                   1781 ;	quantum/action.c:1126: if (mods) {
      007583 E0               [24] 1782 	movx	a,@dptr
      007584 FF               [12] 1783 	mov	r7,a
      007585 E0               [24] 1784 	movx	a,@dptr
      007586 60 08            [24] 1785 	jz	00103$
                                   1786 ;	quantum/action.c:1127: add_owned_mods(mods);
      007588 8F 82            [24] 1787 	mov	dpl, r7
      00758A 12 7C 16         [24] 1788 	lcall	_add_owned_mods
                                   1789 ;	quantum/action.c:1128: send_keyboard_report();
                                   1790 ;	quantum/action.c:1130: }
      00758D 02 7F 52         [24] 1791 	ljmp	_send_keyboard_report
      007590                       1792 00103$:
      007590 22               [24] 1793 	ret
                                   1794 ;------------------------------------------------------------
                                   1795 ;Allocation info for local variables in function 'unregister_mods'
                                   1796 ;------------------------------------------------------------
                                   1797 ;mods          Allocated with name '_unregister_mods_mods_10000_750'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function unregister_mods
                                   1802 ;	-----------------------------------------
      007591                       1803 _unregister_mods:
      007591 E5 82            [12] 1804 	mov	a,dpl
      007593 90 08 35         [24] 1805 	mov	dptr,#_unregister_mods_mods_10000_750
      007596 F0               [24] 1806 	movx	@dptr,a
                                   1807 ;	quantum/action.c:1137: if (mods) {
      007597 E0               [24] 1808 	movx	a,@dptr
      007598 FF               [12] 1809 	mov	r7,a
      007599 E0               [24] 1810 	movx	a,@dptr
      00759A 60 08            [24] 1811 	jz	00103$
                                   1812 ;	quantum/action.c:1138: del_owned_mods(mods);
      00759C 8F 82            [24] 1813 	mov	dpl, r7
      00759E 12 7C 26         [24] 1814 	lcall	_del_owned_mods
                                   1815 ;	quantum/action.c:1139: send_keyboard_report();
                                   1816 ;	quantum/action.c:1141: }
      0075A1 02 7F 52         [24] 1817 	ljmp	_send_keyboard_report
      0075A4                       1818 00103$:
      0075A4 22               [24] 1819 	ret
                                   1820 ;------------------------------------------------------------
                                   1821 ;Allocation info for local variables in function 'register_weak_mods'
                                   1822 ;------------------------------------------------------------
                                   1823 ;mods          Allocated with name '_register_weak_mods_mods_10000_754'
                                   1824 ;------------------------------------------------------------
                                   1825 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1826 ;	-----------------------------------------
                                   1827 ;	 function register_weak_mods
                                   1828 ;	-----------------------------------------
      0075A5                       1829 _register_weak_mods:
      0075A5 E5 82            [12] 1830 	mov	a,dpl
      0075A7 90 08 36         [24] 1831 	mov	dptr,#_register_weak_mods_mods_10000_754
      0075AA F0               [24] 1832 	movx	@dptr,a
                                   1833 ;	quantum/action.c:1148: if (mods) {
      0075AB E0               [24] 1834 	movx	a,@dptr
      0075AC FF               [12] 1835 	mov	r7,a
      0075AD E0               [24] 1836 	movx	a,@dptr
      0075AE 60 08            [24] 1837 	jz	00103$
                                   1838 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      0075B0 8F 82            [24] 1839 	mov	dpl, r7
      0075B2 12 7C 35         [24] 1840 	lcall	_add_owned_weak_mods
                                   1841 ;	quantum/action.c:1150: send_keyboard_report();
                                   1842 ;	quantum/action.c:1152: }
      0075B5 02 7F 52         [24] 1843 	ljmp	_send_keyboard_report
      0075B8                       1844 00103$:
      0075B8 22               [24] 1845 	ret
                                   1846 ;------------------------------------------------------------
                                   1847 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1848 ;------------------------------------------------------------
                                   1849 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_758'
                                   1850 ;------------------------------------------------------------
                                   1851 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1852 ;	-----------------------------------------
                                   1853 ;	 function unregister_weak_mods
                                   1854 ;	-----------------------------------------
      0075B9                       1855 _unregister_weak_mods:
      0075B9 E5 82            [12] 1856 	mov	a,dpl
      0075BB 90 08 37         [24] 1857 	mov	dptr,#_unregister_weak_mods_mods_10000_758
      0075BE F0               [24] 1858 	movx	@dptr,a
                                   1859 ;	quantum/action.c:1159: if (mods) {
      0075BF E0               [24] 1860 	movx	a,@dptr
      0075C0 FF               [12] 1861 	mov	r7,a
      0075C1 E0               [24] 1862 	movx	a,@dptr
      0075C2 60 08            [24] 1863 	jz	00103$
                                   1864 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      0075C4 8F 82            [24] 1865 	mov	dpl, r7
      0075C6 12 7C 45         [24] 1866 	lcall	_del_owned_weak_mods
                                   1867 ;	quantum/action.c:1161: send_keyboard_report();
                                   1868 ;	quantum/action.c:1163: }
      0075C9 02 7F 52         [24] 1869 	ljmp	_send_keyboard_report
      0075CC                       1870 00103$:
      0075CC 22               [24] 1871 	ret
                                   1872 ;------------------------------------------------------------
                                   1873 ;Allocation info for local variables in function 'clear_keyboard'
                                   1874 ;------------------------------------------------------------
                                   1875 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1876 ;	-----------------------------------------
                                   1877 ;	 function clear_keyboard
                                   1878 ;	-----------------------------------------
      0075CD                       1879 _clear_keyboard:
                                   1880 ;	quantum/action.c:1170: clear_mods();
      0075CD 12 7F D6         [24] 1881 	lcall	_clear_mods
                                   1882 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1883 ;	quantum/action.c:1172: }
      0075D0 02 75 D3         [24] 1884 	ljmp	_clear_keyboard_but_mods
                                   1885 ;------------------------------------------------------------
                                   1886 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1887 ;------------------------------------------------------------
                                   1888 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1889 ;	-----------------------------------------
                                   1890 ;	 function clear_keyboard_but_mods
                                   1891 ;	-----------------------------------------
      0075D3                       1892 _clear_keyboard_but_mods:
                                   1893 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0075D3 90 0D 98         [24] 1894 	mov	dptr,#_actual_keyboard_report
      0075D6 12 6E C8         [24] 1895 	lcall	_clear_keys_from_report
                                   1896 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1897 ;	quantum/action.c:1181: }
      0075D9 02 75 DC         [24] 1898 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1899 ;------------------------------------------------------------
                                   1900 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1901 ;------------------------------------------------------------
                                   1902 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1903 ;	-----------------------------------------
                                   1904 ;	 function clear_keyboard_but_mods_and_keys
                                   1905 ;	-----------------------------------------
      0075DC                       1906 _clear_keyboard_but_mods_and_keys:
                                   1907 ;	quantum/action.c:1189: ak820_tapping_cancel();
      0075DC 12 46 88         [24] 1908 	lcall	_ak820_tapping_cancel
                                   1909 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      0075DF 12 2E F0         [24] 1910 	lcall	_ak820_oneshot_cancel
                                   1911 ;	quantum/action.c:1209: ak820_combo_cancel();
      0075E2 12 35 27         [24] 1912 	lcall	_ak820_combo_cancel
                                   1913 ;	quantum/action.c:1212: repeat_key_cancel();
      0075E5 12 9F CC         [24] 1914 	lcall	_repeat_key_cancel
                                   1915 ;	quantum/action.c:1214: clear_owned_mods();
      0075E8 12 7C 55         [24] 1916 	lcall	_clear_owned_mods
                                   1917 ;	quantum/action.c:1215: clear_owned_keys();
      0075EB 12 7C 8D         [24] 1918 	lcall	_clear_owned_keys
                                   1919 ;	quantum/action.c:1216: clear_owned_usages();
      0075EE 12 7D C5         [24] 1920 	lcall	_clear_owned_usages
                                   1921 ;	quantum/action.c:1217: layer_hold_clear();
      0075F1 12 77 B1         [24] 1922 	lcall	_layer_hold_clear
                                   1923 ;	quantum/action.c:1219: clear_macro_tri_layer();
      0075F4 12 9B 48         [24] 1924 	lcall	_clear_macro_tri_layer
                                   1925 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0075F7 90 0D 98         [24] 1926 	mov	dptr,#_actual_keyboard_report
      0075FA 12 6E C8         [24] 1927 	lcall	_clear_keys_from_report
                                   1928 ;	quantum/action.c:1224: host_system_send(0);
      0075FD 90 00 00         [24] 1929 	mov	dptr,#0x0000
      007600 12 6C A2         [24] 1930 	lcall	_host_system_send
                                   1931 ;	quantum/action.c:1225: host_consumer_send(0);
      007603 90 00 00         [24] 1932 	mov	dptr,#0x0000
      007606 12 6C D2         [24] 1933 	lcall	_host_consumer_send
                                   1934 ;	quantum/action.c:1227: clear_weak_mods();
      007609 12 80 0B         [24] 1935 	lcall	_clear_weak_mods
                                   1936 ;	quantum/action.c:1228: send_keyboard_report();
                                   1937 ;	quantum/action.c:1236: }
      00760C 02 7F 52         [24] 1938 	ljmp	_send_keyboard_report
                                   1939 ;------------------------------------------------------------
                                   1940 ;Allocation info for local variables in function 'is_tap_record'
                                   1941 ;------------------------------------------------------------
                                   1942 ;record        Allocated with name '_is_tap_record_record_10000_774'
                                   1943 ;action        Allocated with name '_is_tap_record_action_10001_778'
                                   1944 ;------------------------------------------------------------
                                   1945 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1946 ;	-----------------------------------------
                                   1947 	.area CSEG    (CODE)
                                   1948 	.area CONST   (CODE)
                                   1949 	.area XINIT   (CODE)
      00BF3B                       1950 __xinit__disable_action_cache:
      00BF3B 00                    1951 	.db #0x00	;  0
                                   1952 	.area CABS    (ABS,CODE)
                                   1953 
                                   1954 ; Experimental exact instruction outlining.
                                   1955 	.globl _ak820_outline_0004
                                   1956 	.globl _ak820_outline_0008
                                   1957 	.globl _ak820_outline_0009
                                   1958 	.globl _ak820_outline_0010
                                   1959 	.globl _ak820_outline_0011
                                   1960 	.globl _ak820_outline_0015
                                   1961 	.globl _ak820_outline_0016
                                   1962 	.globl _ak820_outline_0018
                                   1963 	.globl _ak820_outline_0030
                                   1964 	.globl _ak820_outline_0038
                                   1965 	.globl _ak820_outline_0049
                                   1966 	.globl _ak820_outline_0050
                                   1967 	.globl _ak820_outline_0054
                                   1968 	.globl _ak820_outline_0057
                                   1969 	.globl _ak820_outline_0062
                                   1970 	.globl _ak820_outline_0070
                                   1971 	.globl _ak820_outline_0074
                                   1972 	.globl _ak820_outline_0084
                                   1973 	.globl _ak820_outline_0096
                                   1974 	.globl _ak820_outline_0103
                                   1975 	.globl _ak820_outline_0104
                                   1976 	.globl _ak820_outline_0106
                                   1977 	.globl _ak820_outline_0107
                                   1978 	.globl _ak820_outline_0109
                                   1979 	.globl _ak820_outline_0116
                                   1980 	.globl _ak820_outline_0121
                                   1981 	.globl _ak820_outline_0122
                                   1982 	.globl _ak820_outline_0123
                                   1983 	.globl _ak820_outline_0129
                                   1984 	.globl _ak820_outline_0139
                                   1985 	.globl _ak820_outline_0140
                                   1986 	.globl _ak820_outline_0145
                                   1987 	.globl _ak820_outline_0154
                                   1988 	.globl _ak820_outline_0162
                                   1989 	.globl _ak820_outline_0163
                                   1990 	.globl _ak820_outline_0178
                                   1991 
                                   1992 	.area CSEG (CODE)
                                   1993 ; function ak820_outline_0018
      00760F                       1994 _ak820_outline_0018:
      00760F 8E 82            [24] 1995 	mov	dpl,r6
      007611 8F 83            [24] 1996 	mov	dph,r7
      007613 A3               [24] 1997 	inc	dptr
      007614 E0               [24] 1998 	movx	a,@dptr
      007615 FC               [12] 1999 	mov	r4,a
      007616 7D 00            [12] 2000 	mov	r5,#0x00
      007618 8E 82            [24] 2001 	mov	dpl,r6
      00761A 8F 83            [24] 2002 	mov	dph,r7
      00761C E0               [24] 2003 	movx	a,@dptr
      00761D 22               [24] 2004 	ret
                                   2005 
                                   2006 	.area CSEG (CODE)
                                   2007 ; function ak820_outline_0038
      00761E                       2008 _ak820_outline_0038:
      00761E 90 08 2A         [24] 2009 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007621 E0               [24] 2010 	movx	a,@dptr
      007622 54 1F            [12] 2011 	anl	a,#0x1f
      007624 F5 82            [12] 2012 	mov	dpl,a
      007626 22               [24] 2013 	ret
                                   2014 
                                   2015 	.area CSEG (CODE)
                                   2016 ; function ak820_outline_0049
      007627                       2017 _ak820_outline_0049:
      007627 A3               [24] 2018 	inc	dptr
      007628 F0               [24] 2019 	movx	@dptr,a
      007629 E4               [12] 2020 	clr	a
      00762A A3               [24] 2021 	inc	dptr
      00762B F0               [24] 2022 	movx	@dptr,a
      00762C 90 0D 76         [24] 2023 	mov	dptr,#___memcpy_PARM_3
      00762F 22               [24] 2024 	ret
                                   2025 
                                   2026 	.area CSEG (CODE)
                                   2027 ; function ak820_outline_0062
      007630                       2028 _ak820_outline_0062:
      007630 F5 F0            [12] 2029 	mov	b,a
      007632 05 F0            [12] 2030 	inc	b
      007634 74 01            [12] 2031 	mov	a,#0x01
      007636 22               [24] 2032 	ret
                                   2033 
                                   2034 	.area CSEG (CODE)
                                   2035 ; function ak820_outline_0074
      007637                       2036 _ak820_outline_0074:
      007637 90 08 29         [24] 2037 	mov	dptr,#_process_action_PARM_2
      00763A E0               [24] 2038 	movx	a,@dptr
      00763B F5 82            [12] 2039 	mov	dpl,a
      00763D 22               [24] 2040 	ret
                                   2041 
                                   2042 	.area CSEG (CODE)
                                   2043 ; function ak820_outline_0084
      00763E                       2044 _ak820_outline_0084:
      00763E 90 08 2A         [24] 2045 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007641 E0               [24] 2046 	movx	a,@dptr
      007642 03               [12] 2047 	rr	a
      007643 03               [12] 2048 	rr	a
      007644 54 03            [12] 2049 	anl	a,#0x03
      007646 22               [24] 2050 	ret
                                   2051 
                                   2052 	.area CSEG (CODE)
                                   2053 ; function ak820_outline_0107
      007647                       2054 _ak820_outline_0107:
      007647 74 06            [12] 2055 	mov	a,#0x06
      007649 F0               [24] 2056 	movx	@dptr,a
      00764A E4               [12] 2057 	clr	a
      00764B A3               [24] 2058 	inc	dptr
      00764C F0               [24] 2059 	movx	@dptr,a
      00764D 22               [24] 2060 	ret
                                   2061 
                                   2062 	.area CSEG (CODE)
                                   2063 ; function ak820_outline_0109
      00764E                       2064 _ak820_outline_0109:
      00764E 90 08 2A         [24] 2065 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007651 E0               [24] 2066 	movx	a,@dptr
      007652 54 0F            [12] 2067 	anl	a,#0x0f
      007654 22               [24] 2068 	ret
                                   2069 
                                   2070 	.area CSEG (CODE)
                                   2071 ; function ak820_outline_0129
      007655                       2072 _ak820_outline_0129:
      007655 90 08 29         [24] 2073 	mov	dptr,#_process_action_PARM_2
      007658 E0               [24] 2074 	movx	a,@dptr
      007659 FE               [12] 2075 	mov	r6,a
      00765A A3               [24] 2076 	inc	dptr
      00765B E0               [24] 2077 	movx	a,@dptr
      00765C 54 03            [12] 2078 	anl	a,#0x03
      00765E FF               [12] 2079 	mov	r7,a
      00765F 22               [24] 2080 	ret
                                   2081 
                                   2082 	.area CSEG (CODE)
                                   2083 ; function ak820_outline_0154
      007660                       2084 _ak820_outline_0154:
      007660 90 08 29         [24] 2085 	mov	dptr,#_process_action_PARM_2
      007663 E0               [24] 2086 	movx	a,@dptr
      007664 22               [24] 2087 	ret
                                   2088 
                                   2089 	.area CSEG (CODE)
                                   2090 ; function ak820_outline_0162
      007665                       2091 _ak820_outline_0162:
      007665 90 08 2E         [24] 2092 	mov	dptr,#_register_code_code_10000_710
      007668 E0               [24] 2093 	movx	a,@dptr
      007669 FF               [12] 2094 	mov	r7,a
      00766A 22               [24] 2095 	ret
                                   2096 
                                   2097 	.area CSEG (CODE)
                                   2098 ; function ak820_outline_0163
      00766B                       2099 _ak820_outline_0163:
      00766B 90 08 2F         [24] 2100 	mov	dptr,#_unregister_code_code_10000_724
      00766E E0               [24] 2101 	movx	a,@dptr
      00766F FF               [12] 2102 	mov	r7,a
      007670 22               [24] 2103 	ret
