                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00067B                         85 _eeprom_read_word_addr_10000_91:
      00067B                         86 	.ds 3
      00067E                         87 _eeprom_read_word_ret_10000_92:
      00067E                         88 	.ds 2
      000680                         89 _eeprom_read_dword_addr_10000_93:
      000680                         90 	.ds 3
      000683                         91 _eeprom_read_dword_ret_10000_94:
      000683                         92 	.ds 4
      000687                         93 _eeprom_write_byte_PARM_2:
      000687                         94 	.ds 1
      000688                         95 _eeprom_write_byte_addr_10000_95:
      000688                         96 	.ds 3
      00068B                         97 _eeprom_write_word_PARM_2:
      00068B                         98 	.ds 2
      00068D                         99 _eeprom_write_word_addr_10000_97:
      00068D                        100 	.ds 3
      000690                        101 _eeprom_write_dword_PARM_2:
      000690                        102 	.ds 4
      000694                        103 _eeprom_write_dword_addr_10000_99:
      000694                        104 	.ds 3
      000697                        105 _eeprom_update_byte_PARM_2:
      000697                        106 	.ds 1
      000698                        107 _eeprom_update_byte_addr_10000_107:
      000698                        108 	.ds 3
      00069B                        109 _eeprom_update_word_PARM_2:
      00069B                        110 	.ds 2
      00069D                        111 _eeprom_update_word_addr_10000_111:
      00069D                        112 	.ds 3
      0006A0                        113 _eeprom_update_dword_PARM_2:
      0006A0                        114 	.ds 4
      0006A4                        115 _eeprom_update_dword_addr_10000_115:
      0006A4                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004CF0                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004CF0 12 42 DE         [24]  170 	lcall	_ak820_outline_0036
      004CF3 90 06 7B         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004CF6 12 37 DF         [24]  172 	lcall	_ak820_outline_0015
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004CF9 90 06 7E         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004CFC 12 4E FB         [24]  175 	lcall	_ak820_outline_0178
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004CFF 90 06 7B         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004D02 12 4E A9         [24]  178 	lcall	_ak820_outline_0020
      004D05 90 05 81         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004D08 ED               [12]  180 	mov	a,r5
      004D09 12 37 DF         [24]  181 	lcall	_ak820_outline_0015
      004D0C 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004D0F 12 4E ED         [24]  183 	lcall	_ak820_outline_0106
      004D12 90 06 7E         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D15 12 40 7A         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004D18 90 06 7E         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D1B 12 4E E4         [24]  188 	lcall	_ak820_outline_0087
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004D1E 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004D1F                        201 _eeprom_read_dword:
      004D1F 12 42 DE         [24]  202 	lcall	_ak820_outline_0036
      004D22 90 06 80         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004D25 12 37 DF         [24]  204 	lcall	_ak820_outline_0015
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004D28 90 06 83         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D2B 12 4E B9         [24]  207 	lcall	_ak820_outline_0048
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004D2E 90 06 80         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004D31 12 4E A9         [24]  210 	lcall	_ak820_outline_0020
      004D34 90 05 81         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004D37 ED               [12]  212 	mov	a,r5
      004D38 12 37 DF         [24]  213 	lcall	_ak820_outline_0015
      004D3B 90 05 84         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004D3E 74 04            [12]  215 	mov	a,#0x04
      004D40 12 38 65         [24]  216 	lcall	_ak820_outline_0123
      004D43 90 06 83         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D46 12 40 7A         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004D49 90 06 83         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D4C 12 4E C2         [24]  221 	lcall	_ak820_outline_0053
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004D4F 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004D50                        234 _eeprom_write_byte:
      004D50 12 42 DE         [24]  235 	lcall	_ak820_outline_0036
      004D53 90 06 88         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004D56 12 37 DF         [24]  237 	lcall	_ak820_outline_0015
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004D59 90 06 88         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004D5C 12 4E 83         [24]  240 	lcall	_ak820_outline_0002
      004D5F 74 01            [12]  241 	mov	a,#0x01
      004D61 12 38 65         [24]  242 	lcall	_ak820_outline_0123
      004D64 90 06 87         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004D67 02 41 06         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004D6A                        256 _eeprom_write_word:
      004D6A 12 42 DE         [24]  257 	lcall	_ak820_outline_0036
      004D6D 90 06 8D         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004D70 12 37 DF         [24]  259 	lcall	_ak820_outline_0015
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004D73 90 06 8D         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004D76 12 4E 83         [24]  262 	lcall	_ak820_outline_0002
      004D79 12 4E ED         [24]  263 	lcall	_ak820_outline_0106
      004D7C 90 06 8B         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004D7F 02 41 06         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004D82                        277 _eeprom_write_dword:
      004D82 12 42 DE         [24]  278 	lcall	_ak820_outline_0036
      004D85 90 06 94         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004D88 12 37 DF         [24]  280 	lcall	_ak820_outline_0015
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004D8B 90 06 94         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004D8E 12 4E 83         [24]  283 	lcall	_ak820_outline_0002
      004D91 74 04            [12]  284 	mov	a,#0x04
      004D93 12 38 65         [24]  285 	lcall	_ak820_outline_0123
      004D96 90 06 90         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004D99 02 41 06         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004D9C                        307 _eeprom_update_byte:
      004D9C C0 07            [24]  308 	push	ar7
      004D9E C0 06            [24]  309 	push	ar6
      004DA0 C0 05            [24]  310 	push	ar5
      004DA2 C0 04            [24]  311 	push	ar4
      004DA4 12 42 DE         [24]  312 	lcall	_ak820_outline_0036
      004DA7 90 06 98         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004DAA 12 37 DF         [24]  314 	lcall	_ak820_outline_0015
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004DAD 90 06 98         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004DB0 12 4E 9A         [24]  317 	lcall	_ak820_outline_0003
      004DB3 12 40 3F         [24]  318 	lcall	_eeprom_read_byte
      004DB6 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004DB8 90 06 97         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004DBB E0               [24]  322 	movx	a,@dptr
      004DBC FE               [12]  323 	mov	r6,a
      004DBD EF               [12]  324 	mov	a,r7
      004DBE B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004DC1 80 35            [24]  326 	sjmp	00103$
      004DC3                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004DC3 90 06 98         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004DC6 12 38 1F         [24]  330 	lcall	_ak820_outline_0059
      004DC9 A3               [24]  331 	inc	dptr
      004DCA E0               [24]  332 	movx	a,@dptr
      004DCB FF               [12]  333 	mov	r7,a
      004DCC 90 06 87         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004DCF EE               [12]  335 	mov	a,r6
      004DD0 12 38 31         [24]  336 	lcall	_ak820_outline_0095
      004DD3 8F F0            [24]  337 	mov	b, r7
      004DD5 C0 07            [24]  338 	push	ar7
      004DD7 C0 06            [24]  339 	push	ar6
      004DD9 C0 05            [24]  340 	push	ar5
      004DDB C0 04            [24]  341 	push	ar4
      004DDD C0 03            [24]  342 	push	ar3
      004DDF C0 02            [24]  343 	push	ar2
      004DE1 C0 01            [24]  344 	push	ar1
      004DE3 C0 00            [24]  345 	push	ar0
      004DE5 12 4D 50         [24]  346 	lcall	_eeprom_write_byte
      004DE8 D0 00            [24]  347 	pop	ar0
      004DEA D0 01            [24]  348 	pop	ar1
      004DEC D0 02            [24]  349 	pop	ar2
      004DEE D0 03            [24]  350 	pop	ar3
      004DF0 D0 04            [24]  351 	pop	ar4
      004DF2 D0 05            [24]  352 	pop	ar5
      004DF4 D0 06            [24]  353 	pop	ar6
      004DF6 D0 07            [24]  354 	pop	ar7
      004DF8                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      004DF8 D0 04            [24]  357 	pop	ar4
      004DFA D0 05            [24]  358 	pop	ar5
      004DFC D0 06            [24]  359 	pop	ar6
      004DFE D0 07            [24]  360 	pop	ar7
      004E00 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      004E01                        373 _eeprom_update_word:
      004E01 12 42 DE         [24]  374 	lcall	_ak820_outline_0036
      004E04 90 06 9D         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E07 12 37 DF         [24]  376 	lcall	_ak820_outline_0015
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004E0A 90 06 9D         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E0D 12 4E 9A         [24]  379 	lcall	_ak820_outline_0003
      004E10 12 4C F0         [24]  380 	lcall	_eeprom_read_word
      004E13 12 43 2B         [24]  381 	lcall	_ak820_outline_0132
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004E16 90 06 9B         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      004E19 12 38 1F         [24]  384 	lcall	_ak820_outline_0059
      004E1C EE               [12]  385 	mov	a,r6
      004E1D B5 04 05         [24]  386 	cjne	a,ar4,00112$
      004E20 EF               [12]  387 	mov	a,r7
      004E21 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      004E24 22               [24]  389 	ret
      004E25                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004E25 90 06 9D         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E28 E0               [24]  393 	movx	a,@dptr
      004E29 FB               [12]  394 	mov	r3,a
      004E2A A3               [24]  395 	inc	dptr
      004E2B 12 38 00         [24]  396 	lcall	_ak820_outline_0050
      004E2E 90 06 8B         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      004E31 12 38 25         [24]  398 	lcall	_ak820_outline_0070
      004E34 8B 82            [24]  399 	mov	dpl, r3
      004E36 8E 83            [24]  400 	mov	dph, r6
      004E38 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      004E3A 02 4D 6A         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      004E3D                        415 _eeprom_update_dword:
      004E3D 12 42 DE         [24]  416 	lcall	_ak820_outline_0036
      004E40 90 06 A4         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E43 12 37 DF         [24]  418 	lcall	_ak820_outline_0015
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004E46 90 06 A4         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E49 12 4E 9A         [24]  421 	lcall	_ak820_outline_0003
      004E4C 12 4D 1F         [24]  422 	lcall	_eeprom_read_dword
      004E4F 12 4E D3         [24]  423 	lcall	_ak820_outline_0055
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004E52 90 06 A0         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      004E55 E0               [24]  426 	movx	a,@dptr
      004E56 F8               [12]  427 	mov	r0,a
      004E57 A3               [24]  428 	inc	dptr
      004E58 12 4E DB         [24]  429 	lcall	_ak820_outline_0086
      004E5B EC               [12]  430 	mov	a,r4
      004E5C B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      004E5F ED               [12]  432 	mov	a,r5
      004E60 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      004E63 EE               [12]  434 	mov	a,r6
      004E64 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      004E67 EF               [12]  436 	mov	a,r7
      004E68 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      004E6B 22               [24]  438 	ret
      004E6C                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004E6C 90 06 A4         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E6F 12 4E A9         [24]  442 	lcall	_ak820_outline_0020
      004E72 90 06 90         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      004E75 E8               [12]  444 	mov	a,r0
      004E76 F0               [24]  445 	movx	@dptr,a
      004E77 E9               [12]  446 	mov	a,r1
      004E78 A3               [24]  447 	inc	dptr
      004E79 12 4E F4         [24]  448 	lcall	_ak820_outline_0151
      004E7C F0               [24]  449 	movx	@dptr,a
      004E7D 12 4E B2         [24]  450 	lcall	_ak820_outline_0043
                                    451 ;	drivers/eeprom/eeprom_driver.c:101: }
      004E80 02 4D 82         [24]  452 	ljmp	_eeprom_write_dword
                                    453 	.area CSEG    (CODE)
                                    454 	.area CONST   (CODE)
                                    455 	.area XINIT   (CODE)
                                    456 	.area CABS    (ABS,CODE)
                                    457 
                                    458 ; Experimental exact instruction outlining.
                                    459 	.globl _ak820_outline_0002
                                    460 	.globl _ak820_outline_0003
                                    461 	.globl _ak820_outline_0015
                                    462 	.globl _ak820_outline_0020
                                    463 	.globl _ak820_outline_0036
                                    464 	.globl _ak820_outline_0043
                                    465 	.globl _ak820_outline_0048
                                    466 	.globl _ak820_outline_0050
                                    467 	.globl _ak820_outline_0053
                                    468 	.globl _ak820_outline_0055
                                    469 	.globl _ak820_outline_0059
                                    470 	.globl _ak820_outline_0070
                                    471 	.globl _ak820_outline_0086
                                    472 	.globl _ak820_outline_0087
                                    473 	.globl _ak820_outline_0095
                                    474 	.globl _ak820_outline_0106
                                    475 	.globl _ak820_outline_0123
                                    476 	.globl _ak820_outline_0132
                                    477 	.globl _ak820_outline_0151
                                    478 	.globl _ak820_outline_0178
                                    479 
                                    480 	.area CSEG (CODE)
                                    481 ; function ak820_outline_0002
      004E83                        482 _ak820_outline_0002:
      004E83 E0               [24]  483 	movx	a,@dptr
      004E84 FD               [12]  484 	mov	r5,a
      004E85 A3               [24]  485 	inc	dptr
      004E86 E0               [24]  486 	movx	a,@dptr
      004E87 FE               [12]  487 	mov	r6,a
      004E88 A3               [24]  488 	inc	dptr
      004E89 E0               [24]  489 	movx	a,@dptr
      004E8A FF               [12]  490 	mov	r7,a
      004E8B 90 05 8A         [24]  491 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004E8E ED               [12]  492 	mov	a,r5
      004E8F F0               [24]  493 	movx	@dptr,a
      004E90 EE               [12]  494 	mov	a,r6
      004E91 A3               [24]  495 	inc	dptr
      004E92 F0               [24]  496 	movx	@dptr,a
      004E93 EF               [12]  497 	mov	a,r7
      004E94 A3               [24]  498 	inc	dptr
      004E95 F0               [24]  499 	movx	@dptr,a
      004E96 90 05 8D         [24]  500 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004E99 22               [24]  501 	ret
                                    502 
                                    503 	.area CSEG (CODE)
                                    504 ; function ak820_outline_0003
      004E9A                        505 _ak820_outline_0003:
      004E9A E0               [24]  506 	movx	a,@dptr
      004E9B FD               [12]  507 	mov	r5,a
      004E9C A3               [24]  508 	inc	dptr
      004E9D E0               [24]  509 	movx	a,@dptr
      004E9E FE               [12]  510 	mov	r6,a
      004E9F A3               [24]  511 	inc	dptr
      004EA0 E0               [24]  512 	movx	a,@dptr
      004EA1 FF               [12]  513 	mov	r7,a
      004EA2 8D 82            [24]  514 	mov	dpl,r5
      004EA4 8E 83            [24]  515 	mov	dph,r6
      004EA6 8F F0            [24]  516 	mov	b,r7
      004EA8 22               [24]  517 	ret
                                    518 
                                    519 	.area CSEG (CODE)
                                    520 ; function ak820_outline_0020
      004EA9                        521 _ak820_outline_0020:
      004EA9 E0               [24]  522 	movx	a,@dptr
      004EAA FD               [12]  523 	mov	r5,a
      004EAB A3               [24]  524 	inc	dptr
      004EAC E0               [24]  525 	movx	a,@dptr
      004EAD FE               [12]  526 	mov	r6,a
      004EAE A3               [24]  527 	inc	dptr
      004EAF E0               [24]  528 	movx	a,@dptr
      004EB0 FF               [12]  529 	mov	r7,a
      004EB1 22               [24]  530 	ret
                                    531 
                                    532 	.area CSEG (CODE)
                                    533 ; function ak820_outline_0043
      004EB2                        534 _ak820_outline_0043:
      004EB2 8D 82            [24]  535 	mov	dpl,r5
      004EB4 8E 83            [24]  536 	mov	dph,r6
      004EB6 8F F0            [24]  537 	mov	b,r7
      004EB8 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0048
      004EB9                        542 _ak820_outline_0048:
      004EB9 E4               [12]  543 	clr	a
      004EBA F0               [24]  544 	movx	@dptr,a
      004EBB A3               [24]  545 	inc	dptr
      004EBC F0               [24]  546 	movx	@dptr,a
      004EBD A3               [24]  547 	inc	dptr
      004EBE F0               [24]  548 	movx	@dptr,a
      004EBF A3               [24]  549 	inc	dptr
      004EC0 F0               [24]  550 	movx	@dptr,a
      004EC1 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0053
      004EC2                        555 _ak820_outline_0053:
      004EC2 E0               [24]  556 	movx	a,@dptr
      004EC3 FC               [12]  557 	mov	r4,a
      004EC4 A3               [24]  558 	inc	dptr
      004EC5 E0               [24]  559 	movx	a,@dptr
      004EC6 FD               [12]  560 	mov	r5,a
      004EC7 A3               [24]  561 	inc	dptr
      004EC8 E0               [24]  562 	movx	a,@dptr
      004EC9 FE               [12]  563 	mov	r6,a
      004ECA A3               [24]  564 	inc	dptr
      004ECB E0               [24]  565 	movx	a,@dptr
      004ECC 8C 82            [24]  566 	mov	dpl,r4
      004ECE 8D 83            [24]  567 	mov	dph,r5
      004ED0 8E F0            [24]  568 	mov	b,r6
      004ED2 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0055
      004ED3                        573 _ak820_outline_0055:
      004ED3 AC 82            [24]  574 	mov	r4,dpl
      004ED5 AD 83            [24]  575 	mov	r5,dph
      004ED7 AE F0            [24]  576 	mov	r6,b
      004ED9 FF               [12]  577 	mov	r7,a
      004EDA 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0086
      004EDB                        582 _ak820_outline_0086:
      004EDB E0               [24]  583 	movx	a,@dptr
      004EDC F9               [12]  584 	mov	r1,a
      004EDD A3               [24]  585 	inc	dptr
      004EDE E0               [24]  586 	movx	a,@dptr
      004EDF FA               [12]  587 	mov	r2,a
      004EE0 A3               [24]  588 	inc	dptr
      004EE1 E0               [24]  589 	movx	a,@dptr
      004EE2 FB               [12]  590 	mov	r3,a
      004EE3 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0087
      004EE4                        595 _ak820_outline_0087:
      004EE4 E0               [24]  596 	movx	a,@dptr
      004EE5 FE               [12]  597 	mov	r6,a
      004EE6 A3               [24]  598 	inc	dptr
      004EE7 E0               [24]  599 	movx	a,@dptr
      004EE8 8E 82            [24]  600 	mov	dpl,r6
      004EEA F5 83            [12]  601 	mov	dph,a
      004EEC 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0106
      004EED                        606 _ak820_outline_0106:
      004EED 74 02            [12]  607 	mov	a,#0x02
      004EEF F0               [24]  608 	movx	@dptr,a
      004EF0 E4               [12]  609 	clr	a
      004EF1 A3               [24]  610 	inc	dptr
      004EF2 F0               [24]  611 	movx	@dptr,a
      004EF3 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0151
      004EF4                        616 _ak820_outline_0151:
      004EF4 F0               [24]  617 	movx	@dptr,a
      004EF5 EA               [12]  618 	mov	a,r2
      004EF6 A3               [24]  619 	inc	dptr
      004EF7 F0               [24]  620 	movx	@dptr,a
      004EF8 EB               [12]  621 	mov	a,r3
      004EF9 A3               [24]  622 	inc	dptr
      004EFA 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0178
      004EFB                        627 _ak820_outline_0178:
      004EFB E4               [12]  628 	clr	a
      004EFC F0               [24]  629 	movx	@dptr,a
      004EFD A3               [24]  630 	inc	dptr
      004EFE F0               [24]  631 	movx	@dptr,a
      004EFF 22               [24]  632 	ret
