                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         53 bits:
      000025                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000519                        109 _page_data:
      000519                        110 	.ds 64
      000559                        111 _cached_page:
      000559                        112 	.ds 1
      00055A                        113 _batch_depth:
      00055A                        114 	.ds 1
      00055B                        115 _first_failure_stage:
      00055B                        116 	.ds 1
      00055C                        117 _nvm_fail_stage_10000_20:
      00055C                        118 	.ds 1
      00055D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055D                        120 	.ds 2
      00055F                        121 _crc_byte_PARM_2:
      00055F                        122 	.ds 1
      000560                        123 _crc_byte_crc_10000_25:
      000560                        124 	.ds 2
      000562                        125 _page_crc_crc_10000_30:
      000562                        126 	.ds 2
      000564                        127 _write_page_address_10000_32:
      000564                        128 	.ds 2
      000566                        129 _journal_header_valid_header_10000_39:
      000566                        130 	.ds 2
      000568                        131 _recover_journal_header_10000_46:
      000568                        132 	.ds 9
      000571                        133 _ak820_nvm_flush_header_10000_62:
      000571                        134 	.ds 9
      00057A                        135 _ak820_nvm_flush_stage_10000_62:
      00057A                        136 	.ds 1
      00057B                        137 _load_page_page_10000_87:
      00057B                        138 	.ds 1
      00057C                        139 _read_offset_offset_10000_93:
      00057C                        140 	.ds 2
      00057E                        141 _eeprom_read_byte_addr_10000_97:
      00057E                        142 	.ds 3
      000581                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000584                        146 	.ds 2
      000586                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000586                        148 	.ds 2
      000588                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000588                        150 	.ds 2
      00058A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058A                        152 	.ds 3
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058D                        154 	.ds 2
      00058F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058F                        156 	.ds 2
      000591                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000591                        158 	.ds 3
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000594                        160 	.ds 2
      000596                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000596                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003BB2                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003BB2 E5 82            [12]  215 	mov	a,dpl
      003BB4 90 05 5C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003BB7 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003BB8 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003BBB 90 05 5C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003BBE E0               [24]  221 	movx	a,@dptr
      003BBF 90 05 5B         [24]  222 	mov	dptr,#_first_failure_stage
      003BC2 F0               [24]  223 	movx	@dptr,a
      003BC3                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003BC3 D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003BC5 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003BC6                        239 _ak820_nvm_diagnostic:
      003BC6 12 38 44         [24]  240 	lcall	_ak820_outline_0103
      003BC9 90 05 5D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BCC 12 38 49         [24]  242 	lcall	_ak820_outline_0104
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003BCF 90 05 5D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BD2 12 38 01         [24]  245 	lcall	_ak820_outline_0051
      003BD5 A2 09            [12]  246 	mov	c,_storage_failed
      003BD7 E4               [12]  247 	clr	a
      003BD8 33               [12]  248 	rlc	a
      003BD9 12 43 89         [24]  249 	lcall	_ak820_outline_0116
      003BDC 12 43 64         [24]  250 	lcall	_ak820_outline_0061
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003BDF A3               [24]  252 	inc	dptr
      003BE0 A2 07            [12]  253 	mov	c,_page_valid
      003BE2 E4               [12]  254 	clr	a
      003BE3 33               [12]  255 	rlc	a
      003BE4 12 43 38         [24]  256 	lcall	_ak820_outline_0030
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003BE7 A2 08            [12]  258 	mov	c,_page_dirty
      003BE9 E4               [12]  259 	clr	a
      003BEA 33               [12]  260 	rlc	a
      003BEB F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003BEC 74 03            [12]  263 	mov	a,#0x03
      003BEE 12 43 B4         [24]  264 	lcall	_ak820_outline_0156
      003BF1 90 05 5A         [24]  265 	mov	dptr,#_batch_depth
      003BF4 E0               [24]  266 	movx	a,@dptr
      003BF5 12 38 55         [24]  267 	lcall	_ak820_outline_0117
      003BF8 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003BF9 74 04            [12]  270 	mov	a,#0x04
      003BFB 12 43 B4         [24]  271 	lcall	_ak820_outline_0156
      003BFE 90 05 59         [24]  272 	mov	dptr,#_cached_page
      003C01 E0               [24]  273 	movx	a,@dptr
      003C02 12 38 55         [24]  274 	lcall	_ak820_outline_0117
      003C05 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003C06 12 43 2E         [24]  277 	lcall	_ak820_outline_0011
      003C09 E4               [12]  278 	clr	a
      003C0A F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003C0B 74 06            [12]  281 	mov	a,#0x06
      003C0D 12 43 99         [24]  282 	lcall	_ak820_outline_0134
      003C10 90 05 5B         [24]  283 	mov	dptr,#_first_failure_stage
      003C13 E0               [24]  284 	movx	a,@dptr
      003C14 12 43 89         [24]  285 	lcall	_ak820_outline_0116
      003C17 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003C18 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003C19                        300 _crc_byte:
      003C19 12 38 44         [24]  301 	lcall	_ak820_outline_0103
      003C1C 90 05 60         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003C1F 12 38 49         [24]  303 	lcall	_ak820_outline_0104
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003C22 90 05 5F         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003C25 E0               [24]  306 	movx	a,@dptr
      003C26 FF               [12]  307 	mov	r7,a
      003C27 7E 00            [12]  308 	mov	r6,#0x00
      003C29 90 05 60         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003C2C E0               [24]  310 	movx	a,@dptr
      003C2D 6E               [12]  311 	xrl	a,r6
      003C2E F0               [24]  312 	movx	@dptr,a
      003C2F A3               [24]  313 	inc	dptr
      003C30 E0               [24]  314 	movx	a,@dptr
      003C31 6F               [12]  315 	xrl	a,r7
      003C32 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C33 7F 00            [12]  318 	mov	r7,#0x00
      003C35                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C35 90 05 60         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003C38 12 43 77         [24]  322 	lcall	_ak820_outline_0093
      003C3B 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003C3E ED               [12]  324 	mov	a,r5
      003C3F 2D               [12]  325 	add	a,r5
      003C40 FB               [12]  326 	mov	r3,a
      003C41 EE               [12]  327 	mov	a,r6
      003C42 33               [12]  328 	rlc	a
      003C43 FC               [12]  329 	mov	r4,a
      003C44 63 03 21         [24]  330 	xrl	ar3,#0x21
      003C47 63 04 10         [24]  331 	xrl	ar4,#0x10
      003C4A 80 06            [24]  332 	sjmp	00107$
      003C4C                        333 00106$:
      003C4C ED               [12]  334 	mov	a,r5
      003C4D 2D               [12]  335 	add	a,r5
      003C4E FB               [12]  336 	mov	r3,a
      003C4F EE               [12]  337 	mov	a,r6
      003C50 33               [12]  338 	rlc	a
      003C51 FC               [12]  339 	mov	r4,a
      003C52                        340 00107$:
      003C52 90 05 60         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003C55 12 38 2C         [24]  342 	lcall	_ak820_outline_0077
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C58 0F               [12]  344 	inc	r7
      003C59 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C5C 12 33 FC         [24]  347 	lcall	_ak820_outline_0122
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C5F 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003C60                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C60 90 05 62         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003C63 74 FF            [12]  363 	mov	a,#0xff
      003C65 F0               [24]  364 	movx	@dptr,a
      003C66 A3               [24]  365 	inc	dptr
      003C67 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C68 7F 00            [12]  368 	mov	r7,#0x00
      003C6A                        369 00102$:
      003C6A 90 05 62         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003C6D 12 43 77         [24]  371 	lcall	_ak820_outline_0093
      003C70 12 43 7D         [24]  372 	lcall	_ak820_outline_0101
      003C73 90 05 5F         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003C76 F0               [24]  374 	movx	@dptr,a
      003C77 12 38 65         [24]  375 	lcall	_ak820_outline_0132
      003C7A C0 07            [24]  376 	push	ar7
      003C7C 12 3C 19         [24]  377 	lcall	_crc_byte
      003C7F AD 82            [24]  378 	mov	r5, dpl
      003C81 AE 83            [24]  379 	mov	r6, dph
      003C83 D0 07            [24]  380 	pop	ar7
      003C85 90 05 62         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003C88 12 43 BA         [24]  382 	lcall	_ak820_outline_0157
      003C8B 0F               [12]  383 	inc	r7
      003C8C BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C8F 12 38 65         [24]  386 	lcall	_ak820_outline_0132
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C92 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003C93                        399 _write_page:
      003C93 12 38 44         [24]  400 	lcall	_ak820_outline_0103
      003C96 90 05 64         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003C99 12 38 49         [24]  402 	lcall	_ak820_outline_0104
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C9C 90 05 64         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003C9F 12 37 A1         [24]  405 	lcall	_ak820_outline_0004
      003CA2 C0 07            [24]  406 	push	ar7
      003CA4 C0 06            [24]  407 	push	ar6
      003CA6 12 39 C1         [24]  408 	lcall	_ak820_flash_erase
      003CA9 E5 82            [12]  409 	mov	a, dpl
      003CAB D0 06            [24]  410 	pop	ar6
      003CAD D0 07            [24]  411 	pop	ar7
      003CAF 70 03            [24]  412 	jnz	00102$
      003CB1 F5 82            [12]  413 	mov	dpl,a
      003CB3 22               [24]  414 	ret
      003CB4                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003CB4 90 04 F5         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003CB7 74 19            [12]  418 	mov	a,#_page_data
      003CB9 F0               [24]  419 	movx	@dptr,a
      003CBA 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003CBC A3               [24]  421 	inc	dptr
      003CBD 12 43 64         [24]  422 	lcall	_ak820_outline_0061
      003CC0 12 3A D5         [24]  423 	lcall	_ak820_flash_program_page
      003CC3 E5 82            [12]  424 	mov	a, dpl
      003CC5 70 03            [24]  425 	jnz	00120$
      003CC7 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CC9 22               [24]  428 	ret
      003CCA                        429 00120$:
      003CCA 7F 00            [12]  430 	mov	r7,#0x00
      003CCC                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003CCC 8F 05            [24]  433 	mov	ar5,r7
      003CCE 7E 00            [12]  434 	mov	r6,#0x00
      003CD0 90 05 64         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003CD3 12 38 5A         [24]  436 	lcall	_ak820_outline_0121
      003CD6 ED               [12]  437 	mov	a,r5
      003CD7 2B               [12]  438 	add	a, r3
      003CD8 FB               [12]  439 	mov	r3,a
      003CD9 EE               [12]  440 	mov	a,r6
      003CDA 3C               [12]  441 	addc	a, r4
      003CDB FC               [12]  442 	mov	r4,a
      003CDC 12 33 FC         [24]  443 	lcall	_ak820_outline_0122
      003CDF 12 38 B4         [24]  444 	lcall	_ak820_flash_read
      003CE2 AE 82            [24]  445 	mov	r6, dpl
      003CE4 12 43 7D         [24]  446 	lcall	_ak820_outline_0101
      003CE7 FD               [12]  447 	mov	r5,a
      003CE8 EE               [12]  448 	mov	a,r6
      003CE9 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003CEC 80 04            [24]  450 	sjmp	00109$
      003CEE                        451 00149$:
      003CEE 75 82 00         [24]  452 	mov	dpl, #0x00
      003CF1 22               [24]  453 	ret
      003CF2                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CF2 0F               [12]  456 	inc	r7
      003CF3 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003CF6 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003CF9 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003CFA                        472 _journal_header_valid:
      003CFA 12 38 44         [24]  473 	lcall	_ak820_outline_0103
      003CFD 90 05 66         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003D00 12 38 49         [24]  475 	lcall	_ak820_outline_0104
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003D03 90 05 66         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003D06 12 37 A1         [24]  478 	lcall	_ak820_outline_0004
      003D09 E0               [24]  479 	movx	a,@dptr
      003D0A FD               [12]  480 	mov	r5,a
      003D0B BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003D0E 80 04            [24]  482 	sjmp	00116$
      003D10                        483 00138$:
      003D10 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D13 22               [24]  486 	ret
      003D14                        487 00116$:
      003D14 7D 01            [12]  488 	mov	r5,#0x01
      003D16                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003D16 ED               [12]  491 	mov	a,r5
      003D17 12 37 E8         [24]  492 	lcall	_ak820_outline_0017
      003D1A FC               [12]  493 	mov	r4,a
      003D1B 8D 02            [24]  494 	mov	ar2,r5
      003D1D 7B 00            [12]  495 	mov	r3,#0x00
      003D1F 74 04            [12]  496 	mov	a,#0x04
      003D21 2A               [12]  497 	add	a, r2
      003D22 FA               [12]  498 	mov	r2,a
      003D23 E4               [12]  499 	clr	a
      003D24 3B               [12]  500 	addc	a, r3
      003D25 FB               [12]  501 	mov	r3,a
      003D26 EA               [12]  502 	mov	a,r2
      003D27 2E               [12]  503 	add	a, r6
      003D28 F5 82            [12]  504 	mov	dpl,a
      003D2A EB               [12]  505 	mov	a,r3
      003D2B 3F               [12]  506 	addc	a, r7
      003D2C F5 83            [12]  507 	mov	dph,a
      003D2E E0               [24]  508 	movx	a,@dptr
      003D2F 62 04            [12]  509 	xrl	ar4,a
      003D31 BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      003D34 80 04            [24]  511 	sjmp	00107$
      003D36                        512 00139$:
      003D36 75 82 00         [24]  513 	mov	dpl, #0x00
      003D39 22               [24]  514 	ret
      003D3A                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D3A 0D               [12]  517 	inc	r5
      003D3B BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D3E 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D41 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      003D42                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D42 7F 00            [12]  537 	mov	r7,#0x00
      003D44                        538 00115$:
      003D44 EF               [12]  539 	mov	a,r7
      003D45 24 68            [12]  540 	add	a, #_recover_journal_header_10000_46
      003D47 FD               [12]  541 	mov	r5,a
      003D48 E4               [12]  542 	clr	a
      003D49 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D4B FE               [12]  544 	mov	r6,a
      003D4C 8F 04            [24]  545 	mov	ar4,r7
      003D4E 7B 00            [12]  546 	mov	r3,#0x00
      003D50 74 40            [12]  547 	mov	a,#0x40
      003D52 2C               [12]  548 	add	a, r4
      003D53 FC               [12]  549 	mov	r4,a
      003D54 74 EF            [12]  550 	mov	a,#0xef
      003D56 3B               [12]  551 	addc	a, r3
      003D57 FB               [12]  552 	mov	r3,a
      003D58 12 43 C5         [24]  553 	lcall	_ak820_outline_0180
      003D5B 12 38 B4         [24]  554 	lcall	_ak820_flash_read
      003D5E AC 82            [24]  555 	mov	r4, dpl
      003D60 12 43 6A         [24]  556 	lcall	_ak820_outline_0065
      003D63 0F               [12]  557 	inc	r7
      003D64 BF 09 DD         [24]  558 	cjne	r7,#0x09,00115$
                                    559 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D67 90 05 68         [24]  560 	mov	dptr,#_recover_journal_header_10000_46
      003D6A 12 3C FA         [24]  561 	lcall	_journal_header_valid
      003D6D E5 82            [12]  562 	mov	a, dpl
      003D6F 70 01            [24]  563 	jnz	00103$
      003D71 22               [24]  564 	ret
      003D72                        565 00103$:
                                    566 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D72 90 05 69         [24]  567 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D75 E0               [24]  568 	movx	a,@dptr
      003D76 FF               [12]  569 	mov	r7,a
      003D77 7E 00            [12]  570 	mov	r6,#0x00
      003D79 90 05 6A         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D7C E0               [24]  572 	movx	a,@dptr
      003D7D FC               [12]  573 	mov	r4,a
      003D7E E4               [12]  574 	clr	a
      003D7F 42 07            [12]  575 	orl	ar7,a
      003D81 EC               [12]  576 	mov	a,r4
      003D82 42 06            [12]  577 	orl	ar6,a
                                    578 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D84 90 05 6B         [24]  579 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D87 E0               [24]  580 	movx	a,@dptr
      003D88 FD               [12]  581 	mov	r5,a
      003D89 7C 00            [12]  582 	mov	r4,#0x00
      003D8B 90 05 6C         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D8E E0               [24]  584 	movx	a,@dptr
      003D8F FA               [12]  585 	mov	r2,a
      003D90 E4               [12]  586 	clr	a
      003D91 12 43 9F         [24]  587 	lcall	_ak820_outline_0139
                                    588 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D94 C3               [12]  589 	clr	c
      003D95 EF               [12]  590 	mov	a,r7
      003D96 94 A0            [12]  591 	subb	a,#0xa0
      003D98 EE               [12]  592 	mov	a,r6
      003D99 94 00            [12]  593 	subb	a,#0x00
      003D9B 40 06            [24]  594 	jc	00134$
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D9D 75 82 01         [24]  596 	mov	dpl, #0x01
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003DA0 02 3B B2         [24]  598 	ljmp	_nvm_fail
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003DA3                        600 00134$:
      003DA3 7B 00            [12]  601 	mov	r3,#0x00
      003DA5                        602 00117$:
      003DA5 C0 05            [24]  603 	push	ar5
      003DA7 C0 04            [24]  604 	push	ar4
      003DA9 EB               [12]  605 	mov	a,r3
      003DAA 24 19            [12]  606 	add	a, #_page_data
      003DAC F9               [12]  607 	mov	r1,a
      003DAD E4               [12]  608 	clr	a
      003DAE 34 05            [12]  609 	addc	a, #(_page_data >> 8)
      003DB0 FA               [12]  610 	mov	r2,a
      003DB1 8B 00            [24]  611 	mov	ar0,r3
      003DB3 7D 00            [12]  612 	mov	r5,#0x00
      003DB5 74 EF            [12]  613 	mov	a,#0xef
      003DB7 2D               [12]  614 	add	a, r5
      003DB8 FD               [12]  615 	mov	r5,a
      003DB9 88 82            [24]  616 	mov	dpl, r0
      003DBB 8D 83            [24]  617 	mov	dph, r5
      003DBD 12 38 B4         [24]  618 	lcall	_ak820_flash_read
      003DC0 AD 82            [24]  619 	mov	r5, dpl
      003DC2 12 43 C0         [24]  620 	lcall	_ak820_outline_0179
      003DC5 ED               [12]  621 	mov	a,r5
      003DC6 F0               [24]  622 	movx	@dptr,a
      003DC7 0B               [12]  623 	inc	r3
      003DC8 BB 40 02         [24]  624 	cjne	r3,#0x40,00190$
      003DCB 80 06            [24]  625 	sjmp	00191$
      003DCD                        626 00190$:
      003DCD D0 04            [24]  627 	pop	ar4
      003DCF D0 05            [24]  628 	pop	ar5
      003DD1 80 D2            [24]  629 	sjmp	00117$
      003DD3                        630 00191$:
      003DD3 D0 04            [24]  631 	pop	ar4
      003DD5 D0 05            [24]  632 	pop	ar5
                                    633 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003DD7 C0 07            [24]  634 	push	ar7
      003DD9 C0 06            [24]  635 	push	ar6
      003DDB C0 05            [24]  636 	push	ar5
      003DDD C0 04            [24]  637 	push	ar4
      003DDF 12 3C 60         [24]  638 	lcall	_page_crc
      003DE2 AA 82            [24]  639 	mov	r2, dpl
      003DE4 AB 83            [24]  640 	mov	r3, dph
      003DE6 D0 04            [24]  641 	pop	ar4
      003DE8 D0 05            [24]  642 	pop	ar5
      003DEA D0 06            [24]  643 	pop	ar6
      003DEC D0 07            [24]  644 	pop	ar7
      003DEE EA               [12]  645 	mov	a,r2
      003DEF B5 05 06         [24]  646 	cjne	a,ar5,00192$
      003DF2 EB               [12]  647 	mov	a,r3
      003DF3 B5 04 02         [24]  648 	cjne	a,ar4,00192$
      003DF6 80 06            [24]  649 	sjmp	00113$
      003DF8                        650 00192$:
      003DF8 75 82 02         [24]  651 	mov	dpl, #0x02
      003DFB 02 3B B2         [24]  652 	ljmp	_nvm_fail
      003DFE                        653 00113$:
                                    654 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003DFE EE               [12]  655 	mov	a,r6
      003DFF 54 03            [12]  656 	anl	a,#0x03
      003E01 A2 E0            [12]  657 	mov	c,acc.0
      003E03 CF               [12]  658 	xch	a,r7
      003E04 13               [12]  659 	rrc	a
      003E05 CF               [12]  660 	xch	a,r7
      003E06 13               [12]  661 	rrc	a
      003E07 A2 E0            [12]  662 	mov	c,acc.0
      003E09 CF               [12]  663 	xch	a,r7
      003E0A 13               [12]  664 	rrc	a
      003E0B CF               [12]  665 	xch	a,r7
      003E0C 13               [12]  666 	rrc	a
      003E0D CF               [12]  667 	xch	a,r7
      003E0E 24 C7            [12]  668 	add	a,#0xc7
      003E10 FE               [12]  669 	mov	r6,a
      003E11 12 43 AF         [24]  670 	lcall	_ak820_outline_0153
      003E14 12 3C 93         [24]  671 	lcall	_write_page
      003E17 E5 82            [12]  672 	mov	a, dpl
      003E19 70 06            [24]  673 	jnz	00110$
      003E1B 75 82 03         [24]  674 	mov	dpl, #0x03
      003E1E 02 3B B2         [24]  675 	ljmp	_nvm_fail
      003E21                        676 00110$:
                                    677 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003E21 90 EF 40         [24]  678 	mov	dptr,#0xef40
      003E24 12 39 C1         [24]  679 	lcall	_ak820_flash_erase
      003E27 E5 82            [12]  680 	mov	a, dpl
      003E29 70 06            [24]  681 	jnz	00119$
      003E2B 75 82 04         [24]  682 	mov	dpl, #0x04
                                    683 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003E2E 02 3B B2         [24]  684 	ljmp	_nvm_fail
      003E31                        685 00119$:
      003E31 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    689 ;------------------------------------------------------------
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    691 ;	-----------------------------------------
                                    692 ;	 function eeprom_driver_init
                                    693 ;	-----------------------------------------
      003E32                        694 _eeprom_driver_init:
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    696 ;	assignBit
      003E32 C2 09            [12]  697 	clr	_storage_failed
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E34 90 05 5B         [24]  699 	mov	dptr,#_first_failure_stage
      003E37 E4               [12]  700 	clr	a
      003E38 F0               [24]  701 	movx	@dptr,a
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    703 ;	assignBit
      003E39 C2 08            [12]  704 	clr	_page_dirty
                                    705 ;	assignBit
      003E3B C2 07            [12]  706 	clr	_page_valid
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E3D 90 05 5A         [24]  708 	mov	dptr,#_batch_depth
      003E40 E4               [12]  709 	clr	a
      003E41 F0               [24]  710 	movx	@dptr,a
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E42 12 3D 42         [24]  712 	lcall	_recover_journal
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E45 02 2A 6B         [24]  715 	ljmp	_ak820_macro_init
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_nvm_ok
                                    722 ;	-----------------------------------------
      003E48                        723 _ak820_nvm_ok:
      003E48 A2 09            [12]  724 	mov	c,_storage_failed
      003E4A B3               [12]  725 	cpl	c
      003E4B 92 0A            [24]  726 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E4D 12 38 81         [24]  727 	lcall	_ak820_outline_0167
      003E50 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    731 ;------------------------------------------------------------
                                    732 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    733 ;	-----------------------------------------
                                    734 ;	 function ak820_nvm_schema_fault
                                    735 ;	-----------------------------------------
      003E51                        736 _ak820_nvm_schema_fault:
      003E51 75 82 10         [24]  737 	mov	dpl, #0x10
      003E54 02 3B B2         [24]  738 	ljmp	_nvm_fail
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    741 ;------------------------------------------------------------
                                    742 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    743 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    744 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    745 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_flush
                                    750 ;	-----------------------------------------
      003E57                        751 _ak820_nvm_flush:
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E57 30 08 03         [24]  753 	jnb	_page_dirty,00101$
      003E5A 30 09 01         [24]  754 	jnb	_storage_failed,00102$
      003E5D                        755 00101$:
      003E5D 22               [24]  756 	ret
      003E5E                        757 00102$:
                                    758 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E5E 12 3C 60         [24]  759 	lcall	_page_crc
      003E61 12 43 94         [24]  760 	lcall	_ak820_outline_0131
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E64 90 05 71         [24]  762 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E67 74 A5            [12]  763 	mov	a,#0xa5
      003E69 F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E6A 90 05 59         [24]  766 	mov	dptr,#_cached_page
      003E6D E0               [24]  767 	movx	a,@dptr
      003E6E 90 05 72         [24]  768 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E71 F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E72 90 05 73         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E75 E4               [12]  772 	clr	a
      003E76 F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E77 8E 05            [24]  775 	mov	ar5,r6
      003E79 90 05 74         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E7C ED               [12]  777 	mov	a,r5
      003E7D F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E7E 8F 06            [24]  780 	mov	ar6,r7
      003E80 90 05 75         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E83 EE               [12]  782 	mov	a,r6
      003E84 F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E85 7F 01            [12]  785 	mov	r7,#0x01
      003E87                        786 00128$:
      003E87 8F 06            [24]  787 	mov	ar6,r7
      003E89 EE               [12]  788 	mov	a,r6
      003E8A 24 04            [12]  789 	add	a,#0x04
      003E8C FE               [12]  790 	mov	r6,a
      003E8D 33               [12]  791 	rlc	a
      003E8E 95 E0            [12]  792 	subb	a,acc
      003E90 FD               [12]  793 	mov	r5,a
      003E91 EE               [12]  794 	mov	a,r6
      003E92 24 71            [12]  795 	add	a, #_ak820_nvm_flush_header_10000_62
      003E94 FE               [12]  796 	mov	r6,a
      003E95 ED               [12]  797 	mov	a,r5
      003E96 34 05            [12]  798 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E98 FD               [12]  799 	mov	r5,a
      003E99 12 43 47         [24]  800 	lcall	_ak820_outline_0041
      003E9C FC               [12]  801 	mov	r4,a
      003E9D 63 04 FF         [24]  802 	xrl	ar4,#0xff
      003EA0 8E 82            [24]  803 	mov	dpl,r6
      003EA2 8D 83            [24]  804 	mov	dph,r5
      003EA4 EC               [12]  805 	mov	a,r4
      003EA5 F0               [24]  806 	movx	@dptr,a
      003EA6 0F               [12]  807 	inc	r7
      003EA7 BF 05 DD         [24]  808 	cjne	r7,#0x05,00128$
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003EAA 90 05 7A         [24]  810 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EAD 74 05            [12]  811 	mov	a,#0x05
      003EAF F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003EB0 90 EF 40         [24]  814 	mov	dptr,#0xef40
      003EB3 12 39 C1         [24]  815 	lcall	_ak820_flash_erase
      003EB6 E5 82            [12]  816 	mov	a, dpl
      003EB8 70 03            [24]  817 	jnz	00269$
      003EBA 02 3F A0         [24]  818 	ljmp	00127$
      003EBD                        819 00269$:
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003EBD 90 05 7A         [24]  821 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EC0 74 06            [12]  822 	mov	a,#0x06
      003EC2 F0               [24]  823 	movx	@dptr,a
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EC3 7F 00            [12]  825 	mov	r7,#0x00
      003EC5                        826 00130$:
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003EC5 12 43 53         [24]  828 	lcall	_ak820_outline_0052
      003EC8 12 38 B4         [24]  829 	lcall	_ak820_flash_read
      003ECB E5 82            [12]  830 	mov	a, dpl
      003ECD 60 03            [24]  831 	jz	00270$
      003ECF 02 3F A0         [24]  832 	ljmp	00127$
      003ED2                        833 00270$:
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003ED2 0F               [12]  835 	inc	r7
      003ED3 BF 40 EF         [24]  836 	cjne	r7,#0x40,00130$
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003ED6 90 05 7A         [24]  838 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003ED9 74 07            [12]  839 	mov	a,#0x07
      003EDB F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003EDC 90 EF 00         [24]  842 	mov	dptr,#0xef00
      003EDF 12 3C 93         [24]  843 	lcall	_write_page
      003EE2 E5 82            [12]  844 	mov	a, dpl
      003EE4 70 03            [24]  845 	jnz	00273$
      003EE6 02 3F A0         [24]  846 	ljmp	00127$
      003EE9                        847 00273$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003EE9 90 05 7A         [24]  849 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EEC 74 08            [12]  850 	mov	a,#0x08
      003EEE F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EEF 7F 01            [12]  853 	mov	r7,#0x01
      003EF1                        854 00132$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003EF1 12 43 47         [24]  856 	lcall	_ak820_outline_0041
      003EF4 FE               [12]  857 	mov	r6,a
      003EF5 60 22            [24]  858 	jz	00133$
      003EF7 8F 05            [24]  859 	mov	ar5,r7
      003EF9 7C 00            [12]  860 	mov	r4,#0x00
      003EFB 74 40            [12]  861 	mov	a,#0x40
      003EFD 2D               [12]  862 	add	a, r5
      003EFE FD               [12]  863 	mov	r5,a
      003EFF 74 EF            [12]  864 	mov	a,#0xef
      003F01 3C               [12]  865 	addc	a, r4
      003F02 FC               [12]  866 	mov	r4,a
      003F03 90 04 F2         [24]  867 	mov	dptr,#_ak820_flash_program_PARM_2
      003F06 EE               [12]  868 	mov	a,r6
      003F07 F0               [24]  869 	movx	@dptr,a
      003F08 12 43 CA         [24]  870 	lcall	_ak820_outline_0184
      003F0B C0 07            [24]  871 	push	ar7
      003F0D 12 3A 21         [24]  872 	lcall	_ak820_flash_program
      003F10 E5 82            [12]  873 	mov	a, dpl
      003F12 D0 07            [24]  874 	pop	ar7
      003F14 70 03            [24]  875 	jnz	00275$
      003F16 02 3F A0         [24]  876 	ljmp	00127$
      003F19                        877 00275$:
      003F19                        878 00133$:
                                    879 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003F19 0F               [12]  880 	inc	r7
      003F1A BF 09 D4         [24]  881 	cjne	r7,#0x09,00132$
                                    882 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003F1D 90 05 7A         [24]  883 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F20 74 09            [12]  884 	mov	a,#0x09
      003F22 F0               [24]  885 	movx	@dptr,a
                                    886 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F23 7F 01            [12]  887 	mov	r7,#0x01
      003F25                        888 00134$:
                                    889 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003F25 12 43 53         [24]  890 	lcall	_ak820_outline_0052
      003F28 12 38 B4         [24]  891 	lcall	_ak820_flash_read
      003F2B AE 82            [24]  892 	mov	r6, dpl
      003F2D 12 43 47         [24]  893 	lcall	_ak820_outline_0041
      003F30 FD               [12]  894 	mov	r5,a
      003F31 EE               [12]  895 	mov	a,r6
      003F32 B5 05 6B         [24]  896 	cjne	a,ar5,00127$
                                    897 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F35 0F               [12]  898 	inc	r7
      003F36 BF 09 EC         [24]  899 	cjne	r7,#0x09,00134$
                                    900 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F39 90 05 7A         [24]  901 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F3C 74 0A            [12]  902 	mov	a,#0x0a
      003F3E F0               [24]  903 	movx	@dptr,a
                                    904 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F3F 90 05 71         [24]  905 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F42 E0               [24]  906 	movx	a,@dptr
      003F43 90 04 F2         [24]  907 	mov	dptr,#_ak820_flash_program_PARM_2
      003F46 F0               [24]  908 	movx	@dptr,a
      003F47 90 EF 40         [24]  909 	mov	dptr,#0xef40
      003F4A 12 3A 21         [24]  910 	lcall	_ak820_flash_program
      003F4D E5 82            [12]  911 	mov	a, dpl
      003F4F 60 4F            [24]  912 	jz	00127$
                                    913 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F51 90 05 7A         [24]  914 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F54 74 0B            [12]  915 	mov	a,#0x0b
      003F56 F0               [24]  916 	movx	@dptr,a
                                    917 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F57 90 EF 40         [24]  918 	mov	dptr,#0xef40
      003F5A 12 38 B4         [24]  919 	lcall	_ak820_flash_read
      003F5D AF 82            [24]  920 	mov	r7, dpl
      003F5F 90 05 71         [24]  921 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F62 E0               [24]  922 	movx	a,@dptr
      003F63 FE               [12]  923 	mov	r6,a
      003F64 EF               [12]  924 	mov	a,r7
      003F65 B5 06 38         [24]  925 	cjne	a,ar6,00127$
                                    926 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F68 90 05 7A         [24]  927 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F6B 74 0C            [12]  928 	mov	a,#0x0c
      003F6D F0               [24]  929 	movx	@dptr,a
                                    930 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F6E 90 05 59         [24]  931 	mov	dptr,#_cached_page
      003F71 E0               [24]  932 	movx	a,@dptr
      003F72 FE               [12]  933 	mov	r6,a
      003F73 E4               [12]  934 	clr	a
      003F74 C3               [12]  935 	clr	c
      003F75 CE               [12]  936 	xch	a,r6
      003F76 13               [12]  937 	rrc	a
      003F77 CE               [12]  938 	xch	a,r6
      003F78 13               [12]  939 	rrc	a
      003F79 A2 E0            [12]  940 	mov	c,acc.0
      003F7B CE               [12]  941 	xch	a,r6
      003F7C 13               [12]  942 	rrc	a
      003F7D CE               [12]  943 	xch	a,r6
      003F7E 13               [12]  944 	rrc	a
      003F7F CE               [12]  945 	xch	a,r6
      003F80 24 C7            [12]  946 	add	a,#0xc7
      003F82 FF               [12]  947 	mov	r7,a
      003F83 12 43 89         [24]  948 	lcall	_ak820_outline_0116
      003F86 12 3C 93         [24]  949 	lcall	_write_page
      003F89 E5 82            [12]  950 	mov	a, dpl
      003F8B 60 13            [24]  951 	jz	00127$
                                    952 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F8D 90 05 7A         [24]  953 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F90 74 0D            [12]  954 	mov	a,#0x0d
      003F92 F0               [24]  955 	movx	@dptr,a
                                    956 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F93 90 EF 40         [24]  957 	mov	dptr,#0xef40
      003F96 12 39 C1         [24]  958 	lcall	_ak820_flash_erase
      003F99 E5 82            [12]  959 	mov	a, dpl
      003F9B 60 03            [24]  960 	jz	00127$
                                    961 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    962 ;	assignBit
      003F9D C2 08            [12]  963 	clr	_page_dirty
                                    964 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F9F 22               [24]  966 	ret
      003FA0                        967 00127$:
                                    968 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003FA0 90 05 7A         [24]  969 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FA3 E0               [24]  970 	movx	a,@dptr
      003FA4 F5 82            [12]  971 	mov	dpl,a
                                    972 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003FA6 02 3B B2         [24]  973 	ljmp	_nvm_fail
                                    974 ;------------------------------------------------------------
                                    975 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    976 ;------------------------------------------------------------
                                    977 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    978 ;	-----------------------------------------
                                    979 ;	 function ak820_nvm_begin
                                    980 ;	-----------------------------------------
      003FA9                        981 _ak820_nvm_begin:
                                    982 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003FA9 90 05 5A         [24]  983 	mov	dptr,#_batch_depth
      003FAC E0               [24]  984 	movx	a,@dptr
      003FAD FF               [12]  985 	mov	r7,a
      003FAE BF FF 06         [24]  986 	cjne	r7,#0xff,00102$
      003FB1 75 82 0F         [24]  987 	mov	dpl, #0x0f
      003FB4 02 3B B2         [24]  988 	ljmp	_nvm_fail
      003FB7                        989 00102$:
                                    990 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003FB7 90 05 5A         [24]  991 	mov	dptr,#_batch_depth
      003FBA EF               [12]  992 	mov	a,r7
      003FBB 04               [12]  993 	inc	a
      003FBC F0               [24]  994 	movx	@dptr,a
                                    995 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003FBD 22               [24]  996 	ret
                                    997 ;------------------------------------------------------------
                                    998 ;Allocation info for local variables in function 'ak820_nvm_end'
                                    999 ;------------------------------------------------------------
                                   1000 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1001 ;	-----------------------------------------
                                   1002 ;	 function ak820_nvm_end
                                   1003 ;	-----------------------------------------
      003FBE                       1004 _ak820_nvm_end:
                                   1005 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003FBE 90 05 5A         [24] 1006 	mov	dptr,#_batch_depth
      003FC1 E0               [24] 1007 	movx	a,@dptr
      003FC2 FF               [12] 1008 	mov	r7,a
      003FC3 E0               [24] 1009 	movx	a,@dptr
      003FC4 60 06            [24] 1010 	jz	00102$
      003FC6 EF               [12] 1011 	mov	a,r7
      003FC7 14               [12] 1012 	dec	a
      003FC8 90 05 5A         [24] 1013 	mov	dptr,#_batch_depth
      003FCB F0               [24] 1014 	movx	@dptr,a
      003FCC                       1015 00102$:
                                   1016 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003FCC 90 05 5A         [24] 1017 	mov	dptr,#_batch_depth
      003FCF E0               [24] 1018 	movx	a,@dptr
      003FD0 70 03            [24] 1019 	jnz	00105$
                                   1020 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003FD2 02 3E 57         [24] 1021 	ljmp	_ak820_nvm_flush
      003FD5                       1022 00105$:
      003FD5 22               [24] 1023 	ret
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'load_page'
                                   1026 ;------------------------------------------------------------
                                   1027 ;page          Allocated with name '_load_page_page_10000_87'
                                   1028 ;i             Allocated with name '_load_page_i_10000_88'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function load_page
                                   1033 ;	-----------------------------------------
      003FD6                       1034 _load_page:
      003FD6 E5 82            [12] 1035 	mov	a,dpl
      003FD8 90 05 7B         [24] 1036 	mov	dptr,#_load_page_page_10000_87
      003FDB F0               [24] 1037 	movx	@dptr,a
                                   1038 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003FDC 30 07 17         [24] 1039 	jnb	_page_valid,00102$
      003FDF 90 05 59         [24] 1040 	mov	dptr,#_cached_page
      003FE2 E0               [24] 1041 	movx	a,@dptr
      003FE3 FF               [12] 1042 	mov	r7,a
      003FE4 90 05 7B         [24] 1043 	mov	dptr,#_load_page_page_10000_87
      003FE7 E0               [24] 1044 	movx	a,@dptr
      003FE8 FE               [12] 1045 	mov	r6,a
      003FE9 EF               [12] 1046 	mov	a,r7
      003FEA B5 06 09         [24] 1047 	cjne	a,ar6,00102$
      003FED A2 09            [12] 1048 	mov	c,_storage_failed
      003FEF B3               [12] 1049 	cpl	c
      003FF0 92 0B            [24] 1050 	mov  _load_page_sloc0_1_0,c
      003FF2 12 38 81         [24] 1051 	lcall	_ak820_outline_0167
      003FF5 22               [24] 1052 	ret
      003FF6                       1053 00102$:
                                   1054 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003FF6 12 3E 57         [24] 1055 	lcall	_ak820_nvm_flush
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003FF9 30 09 04         [24] 1057 	jnb	_storage_failed,00119$
      003FFC 75 82 00         [24] 1058 	mov	dpl, #0x00
                                   1059 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FFF 22               [24] 1060 	ret
      004000                       1061 00119$:
      004000 7F 00            [12] 1062 	mov	r7,#0x00
      004002                       1063 00107$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004002 EF               [12] 1065 	mov	a,r7
      004003 24 19            [12] 1066 	add	a, #_page_data
      004005 FD               [12] 1067 	mov	r5,a
      004006 E4               [12] 1068 	clr	a
      004007 34 05            [12] 1069 	addc	a, #(_page_data >> 8)
      004009 FE               [12] 1070 	mov	r6,a
      00400A 90 05 7B         [24] 1071 	mov	dptr,#_load_page_page_10000_87
      00400D E0               [24] 1072 	movx	a,@dptr
      00400E FC               [12] 1073 	mov	r4,a
      00400F FA               [12] 1074 	mov	r2,a
      004010 E4               [12] 1075 	clr	a
      004011 C3               [12] 1076 	clr	c
      004012 CA               [12] 1077 	xch	a,r2
      004013 13               [12] 1078 	rrc	a
      004014 CA               [12] 1079 	xch	a,r2
      004015 13               [12] 1080 	rrc	a
      004016 A2 E0            [12] 1081 	mov	c,acc.0
      004018 CA               [12] 1082 	xch	a,r2
      004019 13               [12] 1083 	rrc	a
      00401A CA               [12] 1084 	xch	a,r2
      00401B 13               [12] 1085 	rrc	a
      00401C CA               [12] 1086 	xch	a,r2
      00401D 24 C7            [12] 1087 	add	a,#0xc7
      00401F FB               [12] 1088 	mov	r3,a
      004020 8F 01            [24] 1089 	mov	ar1,r7
      004022 89 00            [24] 1090 	mov	ar0,r1
      004024 79 00            [12] 1091 	mov	r1,#0x00
      004026 E8               [12] 1092 	mov	a,r0
      004027 2A               [12] 1093 	add	a, r2
      004028 FA               [12] 1094 	mov	r2,a
      004029 E9               [12] 1095 	mov	a,r1
      00402A 3B               [12] 1096 	addc	a, r3
      00402B FB               [12] 1097 	mov	r3,a
      00402C 12 43 A5         [24] 1098 	lcall	_ak820_outline_0140
      00402F 12 38 B4         [24] 1099 	lcall	_ak820_flash_read
      004032 AB 82            [24] 1100 	mov	r3, dpl
      004034 12 38 65         [24] 1101 	lcall	_ak820_outline_0132
      004037 EB               [12] 1102 	mov	a,r3
      004038 F0               [24] 1103 	movx	@dptr,a
                                   1104 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004039 0F               [12] 1105 	inc	r7
      00403A BF 40 C5         [24] 1106 	cjne	r7,#0x40,00107$
                                   1107 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00403D 90 05 59         [24] 1108 	mov	dptr,#_cached_page
      004040 EC               [12] 1109 	mov	a,r4
      004041 F0               [24] 1110 	movx	@dptr,a
                                   1111 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1112 ;	assignBit
      004042 D2 07            [12] 1113 	setb	_page_valid
                                   1114 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004044 75 82 01         [24] 1115 	mov	dpl, #0x01
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004047 22               [24] 1117 	ret
                                   1118 ;------------------------------------------------------------
                                   1119 ;Allocation info for local variables in function 'read_offset'
                                   1120 ;------------------------------------------------------------
                                   1121 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1122 ;------------------------------------------------------------
                                   1123 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1124 ;	-----------------------------------------
                                   1125 ;	 function read_offset
                                   1126 ;	-----------------------------------------
      004048                       1127 _read_offset:
      004048 12 38 44         [24] 1128 	lcall	_ak820_outline_0103
      00404B 90 05 7C         [24] 1129 	mov	dptr,#_read_offset_offset_10000_93
      00404E 12 38 49         [24] 1130 	lcall	_ak820_outline_0104
                                   1131 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004051 90 05 7C         [24] 1132 	mov	dptr,#_read_offset_offset_10000_93
      004054 12 38 01         [24] 1133 	lcall	_ak820_outline_0051
      004057 C3               [12] 1134 	clr	c
      004058 94 28            [12] 1135 	subb	a,#0x28
      00405A 40 04            [24] 1136 	jc	00102$
      00405C 75 82 00         [24] 1137 	mov	dpl, #0x00
      00405F 22               [24] 1138 	ret
      004060                       1139 00102$:
                                   1140 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004060 30 07 34         [24] 1141 	jnb	_page_valid,00104$
      004063 8E 04            [24] 1142 	mov	ar4,r6
      004065 EF               [12] 1143 	mov	a,r7
      004066 A2 E7            [12] 1144 	mov	c,acc.7
      004068 CC               [12] 1145 	xch	a,r4
      004069 33               [12] 1146 	rlc	a
      00406A CC               [12] 1147 	xch	a,r4
      00406B 33               [12] 1148 	rlc	a
      00406C A2 E7            [12] 1149 	mov	c,acc.7
      00406E CC               [12] 1150 	xch	a,r4
      00406F 33               [12] 1151 	rlc	a
      004070 CC               [12] 1152 	xch	a,r4
      004071 33               [12] 1153 	rlc	a
      004072 CC               [12] 1154 	xch	a,r4
      004073 54 03            [12] 1155 	anl	a,#0x03
      004075 FD               [12] 1156 	mov	r5,a
      004076 90 05 59         [24] 1157 	mov	dptr,#_cached_page
      004079 E0               [24] 1158 	movx	a,@dptr
      00407A FA               [12] 1159 	mov	r2,a
      00407B 7B 00            [12] 1160 	mov	r3,#0x00
      00407D EC               [12] 1161 	mov	a,r4
      00407E B5 02 16         [24] 1162 	cjne	a,ar2,00104$
      004081 ED               [12] 1163 	mov	a,r5
      004082 B5 03 12         [24] 1164 	cjne	a,ar3,00104$
                                   1165 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004085 74 3F            [12] 1166 	mov	a,#0x3f
      004087 5E               [12] 1167 	anl	a,r6
      004088 7D 00            [12] 1168 	mov	r5,#0x00
      00408A 24 19            [12] 1169 	add	a, #_page_data
      00408C F5 82            [12] 1170 	mov	dpl,a
      00408E ED               [12] 1171 	mov	a,r5
      00408F 34 05            [12] 1172 	addc	a, #(_page_data >> 8)
      004091 F5 83            [12] 1173 	mov	dph,a
      004093 E0               [24] 1174 	movx	a,@dptr
      004094 F5 82            [12] 1175 	mov	dpl,a
      004096 22               [24] 1176 	ret
      004097                       1177 00104$:
                                   1178 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004097 74 C7            [12] 1179 	mov	a,#0xc7
      004099 2F               [12] 1180 	add	a, r7
      00409A FF               [12] 1181 	mov	r7,a
      00409B 12 43 89         [24] 1182 	lcall	_ak820_outline_0116
                                   1183 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      00409E 02 38 B4         [24] 1184 	ljmp	_ak820_flash_read
                                   1185 ;------------------------------------------------------------
                                   1186 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1187 ;------------------------------------------------------------
                                   1188 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function eeprom_read_byte
                                   1193 ;	-----------------------------------------
      0040A1                       1194 _eeprom_read_byte:
      0040A1 C0 07            [24] 1195 	push	ar7
      0040A3 C0 06            [24] 1196 	push	ar6
      0040A5 12 43 40         [24] 1197 	lcall	_ak820_outline_0037
      0040A8 90 05 7E         [24] 1198 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040AB 12 37 E0         [24] 1199 	lcall	_ak820_outline_0016
                                   1200 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0040AE 90 05 7E         [24] 1201 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040B1 12 37 A1         [24] 1202 	lcall	_ak820_outline_0004
      0040B4 C0 06            [24] 1203 	push	ar6
      0040B6 C0 05            [24] 1204 	push	ar5
      0040B8 C0 04            [24] 1205 	push	ar4
      0040BA C0 03            [24] 1206 	push	ar3
      0040BC C0 02            [24] 1207 	push	ar2
      0040BE C0 01            [24] 1208 	push	ar1
      0040C0 C0 00            [24] 1209 	push	ar0
      0040C2 12 40 48         [24] 1210 	lcall	_read_offset
      0040C5 AF 82            [24] 1211 	mov	r7, dpl
      0040C7 D0 00            [24] 1212 	pop	ar0
      0040C9 D0 01            [24] 1213 	pop	ar1
      0040CB D0 02            [24] 1214 	pop	ar2
      0040CD D0 03            [24] 1215 	pop	ar3
      0040CF D0 04            [24] 1216 	pop	ar4
      0040D1 D0 05            [24] 1217 	pop	ar5
      0040D3 D0 06            [24] 1218 	pop	ar6
      0040D5 8F 82            [24] 1219 	mov	dpl, r7
                                   1220 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0040D7 D0 06            [24] 1221 	pop	ar6
      0040D9 D0 07            [24] 1222 	pop	ar7
      0040DB 22               [24] 1223 	ret
                                   1224 ;------------------------------------------------------------
                                   1225 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1226 ;------------------------------------------------------------
                                   1227 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1228 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1229 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1230 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1231 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1232 ;------------------------------------------------------------
                                   1233 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1234 ;	-----------------------------------------
                                   1235 ;	 function ak820_eeprom_read_block_xdata
                                   1236 ;	-----------------------------------------
      0040DC                       1237 _ak820_eeprom_read_block_xdata:
      0040DC 12 38 44         [24] 1238 	lcall	_ak820_outline_0103
      0040DF 90 05 86         [24] 1239 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040E2 12 38 49         [24] 1240 	lcall	_ak820_outline_0104
                                   1241 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040E5 90 05 81         [24] 1242 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0040E8 12 38 01         [24] 1243 	lcall	_ak820_outline_0051
                                   1244 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0040EB 90 05 86         [24] 1245 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040EE 12 38 20         [24] 1246 	lcall	_ak820_outline_0060
      0040F1 90 05 88         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040F4 12 38 26         [24] 1248 	lcall	_ak820_outline_0071
                                   1249 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0040F7 90 05 84         [24] 1250 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0040FA 12 38 20         [24] 1251 	lcall	_ak820_outline_0060
      0040FD                       1252 00103$:
      0040FD 8C 02            [24] 1253 	mov	ar2,r4
      0040FF 8D 03            [24] 1254 	mov	ar3,r5
      004101 1C               [12] 1255 	dec	r4
      004102 BC FF 01         [24] 1256 	cjne	r4,#0xff,00130$
      004105 1D               [12] 1257 	dec	r5
      004106                       1258 00130$:
      004106 EA               [12] 1259 	mov	a,r2
      004107 4B               [12] 1260 	orl	a,r3
      004108 60 5D            [24] 1261 	jz	00106$
                                   1262 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00410A 8E 02            [24] 1263 	mov	ar2,r6
      00410C 8F 03            [24] 1264 	mov	ar3,r7
      00410E 74 D8            [12] 1265 	mov	a,#0x100 - 0x28
      004110 2B               [12] 1266 	add	a,r3
      004111 50 17            [24] 1267 	jnc	00102$
      004113 90 05 88         [24] 1268 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004116 12 43 8E         [24] 1269 	lcall	_ak820_outline_0120
      004119 12 43 A5         [24] 1270 	lcall	_ak820_outline_0140
      00411C E4               [12] 1271 	clr	a
      00411D F0               [24] 1272 	movx	@dptr,a
      00411E 90 05 88         [24] 1273 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004121 04               [12] 1274 	inc	a
      004122 2A               [12] 1275 	add	a, r2
      004123 F0               [24] 1276 	movx	@dptr,a
      004124 E4               [12] 1277 	clr	a
      004125 3B               [12] 1278 	addc	a, r3
      004126 A3               [24] 1279 	inc	dptr
      004127 F0               [24] 1280 	movx	@dptr,a
      004128 80 D3            [24] 1281 	sjmp	00103$
      00412A                       1282 00102$:
                                   1283 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      00412A 90 05 88         [24] 1284 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00412D 12 43 8E         [24] 1285 	lcall	_ak820_outline_0120
      004130 12 43 89         [24] 1286 	lcall	_ak820_outline_0116
      004133 C0 07            [24] 1287 	push	ar7
      004135 C0 06            [24] 1288 	push	ar6
      004137 C0 05            [24] 1289 	push	ar5
      004139 C0 04            [24] 1290 	push	ar4
      00413B C0 03            [24] 1291 	push	ar3
      00413D C0 02            [24] 1292 	push	ar2
      00413F 12 40 48         [24] 1293 	lcall	_read_offset
      004142 A9 82            [24] 1294 	mov	r1, dpl
      004144 D0 02            [24] 1295 	pop	ar2
      004146 D0 03            [24] 1296 	pop	ar3
      004148 D0 04            [24] 1297 	pop	ar4
      00414A D0 05            [24] 1298 	pop	ar5
      00414C D0 06            [24] 1299 	pop	ar6
      00414E D0 07            [24] 1300 	pop	ar7
      004150 12 43 A5         [24] 1301 	lcall	_ak820_outline_0140
      004153 E9               [12] 1302 	mov	a,r1
      004154 F0               [24] 1303 	movx	@dptr,a
      004155 90 05 88         [24] 1304 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004158 74 01            [12] 1305 	mov	a,#0x01
      00415A 2A               [12] 1306 	add	a, r2
      00415B F0               [24] 1307 	movx	@dptr,a
      00415C E4               [12] 1308 	clr	a
      00415D 3B               [12] 1309 	addc	a, r3
      00415E A3               [24] 1310 	inc	dptr
      00415F F0               [24] 1311 	movx	@dptr,a
                                   1312 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004160 0E               [12] 1313 	inc	r6
      004161 BE 00 99         [24] 1314 	cjne	r6,#0x00,00103$
      004164 0F               [12] 1315 	inc	r7
      004165 80 96            [24] 1316 	sjmp	00103$
      004167                       1317 00106$:
                                   1318 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004167 22               [24] 1319 	ret
                                   1320 ;------------------------------------------------------------
                                   1321 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1322 ;------------------------------------------------------------
                                   1323 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1324 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1325 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1326 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1327 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1328 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1329 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1330 ;------------------------------------------------------------
                                   1331 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1332 ;	-----------------------------------------
                                   1333 ;	 function ak820_eeprom_write_block_xdata
                                   1334 ;	-----------------------------------------
      004168                       1335 _ak820_eeprom_write_block_xdata:
      004168 12 38 44         [24] 1336 	lcall	_ak820_outline_0103
      00416B 90 05 8F         [24] 1337 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00416E 12 38 49         [24] 1338 	lcall	_ak820_outline_0104
                                   1339 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004171 90 05 8A         [24] 1340 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004174 12 38 01         [24] 1341 	lcall	_ak820_outline_0051
                                   1342 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004177 90 05 8F         [24] 1343 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00417A 12 38 20         [24] 1344 	lcall	_ak820_outline_0060
                                   1345 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00417D 8E 02            [24] 1346 	mov	ar2,r6
      00417F 8F 03            [24] 1347 	mov	ar3,r7
      004181 C3               [12] 1348 	clr	c
      004182 E4               [12] 1349 	clr	a
      004183 9A               [12] 1350 	subb	a,r2
      004184 74 28            [12] 1351 	mov	a,#0x28
      004186 9B               [12] 1352 	subb	a,r3
      004187 40 15            [24] 1353 	jc	00101$
                                   1354 ;	free result
      004189 E4               [12] 1355 	clr	a
      00418A C3               [12] 1356 	clr	c
      00418B 9E               [12] 1357 	subb	a,r6
      00418C FA               [12] 1358 	mov	r2,a
      00418D 74 28            [12] 1359 	mov	a,#0x28
      00418F 9F               [12] 1360 	subb	a,r7
      004190 FB               [12] 1361 	mov	r3,a
      004191 90 05 8D         [24] 1362 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004194 12 38 3E         [24] 1363 	lcall	_ak820_outline_0100
      004197 C3               [12] 1364 	clr	c
      004198 EA               [12] 1365 	mov	a,r2
      004199 98               [12] 1366 	subb	a,r0
      00419A EB               [12] 1367 	mov	a,r3
      00419B 99               [12] 1368 	subb	a,r1
      00419C 50 06            [24] 1369 	jnc	00125$
                                   1370 ;	free result
      00419E                       1371 00101$:
                                   1372 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      00419E 75 82 0E         [24] 1373 	mov	dpl, #0x0e
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0041A1 02 3B B2         [24] 1375 	ljmp	_nvm_fail
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0041A4                       1377 00125$:
      0041A4 90 05 8D         [24] 1378 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0041A7 12 43 8E         [24] 1379 	lcall	_ak820_outline_0120
      0041AA                       1380 00108$:
      0041AA 8A 00            [24] 1381 	mov	ar0,r2
      0041AC 8B 01            [24] 1382 	mov	ar1,r3
      0041AE 1A               [12] 1383 	dec	r2
      0041AF BA FF 01         [24] 1384 	cjne	r2,#0xff,00159$
      0041B2 1B               [12] 1385 	dec	r3
      0041B3                       1386 00159$:
      0041B3 E8               [12] 1387 	mov	a,r0
      0041B4 49               [12] 1388 	orl	a,r1
      0041B5 70 03            [24] 1389 	jnz	00160$
      0041B7 02 42 41         [24] 1390 	ljmp	00110$
      0041BA                       1391 00160$:
                                   1392 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0041BA C0 02            [24] 1393 	push	ar2
      0041BC C0 03            [24] 1394 	push	ar3
      0041BE 12 43 71         [24] 1395 	lcall	_ak820_outline_0092
      0041C1 F9               [12] 1396 	mov	r1,a
      0041C2 A3               [24] 1397 	inc	dptr
      0041C3 12 43 AA         [24] 1398 	lcall	_ak820_outline_0145
                                   1399 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0041C6 8E 0C            [24] 1400 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0041C8 8F 0D            [24] 1401 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0041CA A8 0C            [24] 1402 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041CC E5 0D            [12] 1403 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041CE A2 E7            [12] 1404 	mov	c,acc.7
      0041D0 C8               [12] 1405 	xch	a,r0
      0041D1 33               [12] 1406 	rlc	a
      0041D2 C8               [12] 1407 	xch	a,r0
      0041D3 33               [12] 1408 	rlc	a
      0041D4 A2 E7            [12] 1409 	mov	c,acc.7
      0041D6 C8               [12] 1410 	xch	a,r0
      0041D7 33               [12] 1411 	rlc	a
      0041D8 C8               [12] 1412 	xch	a,r0
      0041D9 33               [12] 1413 	rlc	a
      0041DA C8               [12] 1414 	xch	a,r0
      0041DB 54 03            [12] 1415 	anl	a,#0x03
      0041DD FB               [12] 1416 	mov	r3,a
      0041DE 88 82            [24] 1417 	mov	dpl, r0
      0041E0 C0 07            [24] 1418 	push	ar7
      0041E2 C0 06            [24] 1419 	push	ar6
      0041E4 C0 05            [24] 1420 	push	ar5
      0041E6 C0 04            [24] 1421 	push	ar4
      0041E8 C0 03            [24] 1422 	push	ar3
      0041EA C0 02            [24] 1423 	push	ar2
      0041EC C0 01            [24] 1424 	push	ar1
      0041EE 12 3F D6         [24] 1425 	lcall	_load_page
      0041F1 E5 82            [12] 1426 	mov	a, dpl
      0041F3 D0 01            [24] 1427 	pop	ar1
      0041F5 D0 02            [24] 1428 	pop	ar2
      0041F7 D0 03            [24] 1429 	pop	ar3
      0041F9 D0 04            [24] 1430 	pop	ar4
      0041FB D0 05            [24] 1431 	pop	ar5
      0041FD D0 06            [24] 1432 	pop	ar6
      0041FF D0 07            [24] 1433 	pop	ar7
      004201 D0 03            [24] 1434 	pop	ar3
      004203 D0 02            [24] 1435 	pop	ar2
      004205 70 01            [24] 1436 	jnz	00105$
      004207 22               [24] 1437 	ret
      004208                       1438 00105$:
                                   1439 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004208 C0 06            [24] 1440 	push	ar6
      00420A C0 07            [24] 1441 	push	ar7
      00420C 74 3F            [12] 1442 	mov	a,#0x3f
      00420E 55 0C            [12] 1443 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004210 7F 00            [12] 1444 	mov	r7,#0x00
      004212 24 19            [12] 1445 	add	a, #_page_data
      004214 F5 0C            [12] 1446 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004216 EF               [12] 1447 	mov	a,r7
      004217 34 05            [12] 1448 	addc	a, #(_page_data >> 8)
      004219 F5 0D            [12] 1449 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      00421B 85 0C 82         [24] 1450 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00421E 85 0D 83         [24] 1451 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004221 E0               [24] 1452 	movx	a,@dptr
      004222 B5 01 06         [24] 1453 	cjne	a,ar1,00162$
      004225 D0 07            [24] 1454 	pop	ar7
      004227 D0 06            [24] 1455 	pop	ar6
      004229 80 0E            [24] 1456 	sjmp	00107$
      00422B                       1457 00162$:
      00422B D0 07            [24] 1458 	pop	ar7
      00422D D0 06            [24] 1459 	pop	ar6
                                   1460 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00422F 85 0C 82         [24] 1461 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004232 85 0D 83         [24] 1462 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004235 E9               [12] 1463 	mov	a,r1
      004236 F0               [24] 1464 	movx	@dptr,a
                                   1465 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1466 ;	assignBit
      004237 D2 08            [12] 1467 	setb	_page_dirty
      004239                       1468 00107$:
                                   1469 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004239 0E               [12] 1470 	inc	r6
      00423A BE 00 01         [24] 1471 	cjne	r6,#0x00,00163$
      00423D 0F               [12] 1472 	inc	r7
      00423E                       1473 00163$:
      00423E 02 41 AA         [24] 1474 	ljmp	00108$
      004241                       1475 00110$:
                                   1476 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004241 90 05 5A         [24] 1477 	mov	dptr,#_batch_depth
      004244 E0               [24] 1478 	movx	a,@dptr
      004245 70 03            [24] 1479 	jnz	00113$
                                   1480 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004247 02 3E 57         [24] 1481 	ljmp	_ak820_nvm_flush
      00424A                       1482 00113$:
      00424A 22               [24] 1483 	ret
                                   1484 ;------------------------------------------------------------
                                   1485 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1486 ;------------------------------------------------------------
                                   1487 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1488 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1489 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1490 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1491 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1492 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1493 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1494 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1495 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1496 ;------------------------------------------------------------
                                   1497 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1498 ;	-----------------------------------------
                                   1499 ;	 function ak820_eeprom_update_block_xdata
                                   1500 ;	-----------------------------------------
      00424B                       1501 _ak820_eeprom_update_block_xdata:
      00424B 12 38 44         [24] 1502 	lcall	_ak820_outline_0103
      00424E 90 05 96         [24] 1503 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004251 12 38 49         [24] 1504 	lcall	_ak820_outline_0104
                                   1505 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004254 90 05 96         [24] 1506 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004257 12 38 01         [24] 1507 	lcall	_ak820_outline_0051
                                   1508 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00425A 90 05 91         [24] 1509 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00425D E0               [24] 1510 	movx	a,@dptr
      00425E F5 12            [12] 1511 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004260 A3               [24] 1512 	inc	dptr
      004261 E0               [24] 1513 	movx	a,@dptr
      004262 F5 13            [12] 1514 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004264 A3               [24] 1515 	inc	dptr
      004265 E0               [24] 1516 	movx	a,@dptr
      004266 F5 14            [12] 1517 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004268 A9 12            [24] 1518 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00426A AA 13            [24] 1519 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1520 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00426C E4               [12] 1521 	clr	a
      00426D F5 0E            [12] 1522 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      00426F F5 0F            [12] 1523 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004271                       1524 00105$:
      004271 90 05 94         [24] 1525 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004274 E0               [24] 1526 	movx	a,@dptr
      004275 F5 10            [12] 1527 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004277 A3               [24] 1528 	inc	dptr
      004278 E0               [24] 1529 	movx	a,@dptr
      004279 F5 11            [12] 1530 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      00427B C3               [12] 1531 	clr	c
      00427C E5 0E            [12] 1532 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00427E 95 10            [12] 1533 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004280 E5 0F            [12] 1534 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004282 95 11            [12] 1535 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004284 50 68            [24] 1536 	jnc	00107$
                                   1537 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004286 89 00            [24] 1538 	mov	ar0,r1
      004288 8A 05            [24] 1539 	mov	ar5,r2
      00428A E5 0E            [12] 1540 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00428C 28               [12] 1541 	add	a, r0
      00428D F8               [12] 1542 	mov	r0,a
      00428E E5 0F            [12] 1543 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004290 3D               [12] 1544 	addc	a, r5
      004291 FD               [12] 1545 	mov	r5,a
      004292 88 82            [24] 1546 	mov	dpl, r0
      004294 8D 83            [24] 1547 	mov	dph, r5
      004296 C0 07            [24] 1548 	push	ar7
      004298 C0 06            [24] 1549 	push	ar6
      00429A C0 02            [24] 1550 	push	ar2
      00429C C0 01            [24] 1551 	push	ar1
      00429E 12 40 48         [24] 1552 	lcall	_read_offset
      0042A1 AD 82            [24] 1553 	mov	r5, dpl
      0042A3 D0 01            [24] 1554 	pop	ar1
      0042A5 D0 02            [24] 1555 	pop	ar2
      0042A7 D0 06            [24] 1556 	pop	ar6
      0042A9 D0 07            [24] 1557 	pop	ar7
      0042AB E5 0E            [12] 1558 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042AD 2E               [12] 1559 	add	a, r6
      0042AE F5 82            [12] 1560 	mov	dpl,a
      0042B0 E5 0F            [12] 1561 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042B2 3F               [12] 1562 	addc	a, r7
      0042B3 F5 83            [12] 1563 	mov	dph,a
      0042B5 E0               [24] 1564 	movx	a,@dptr
      0042B6 FC               [12] 1565 	mov	r4,a
      0042B7 ED               [12] 1566 	mov	a,r5
      0042B8 B5 04 02         [24] 1567 	cjne	a,ar4,00131$
      0042BB 80 27            [24] 1568 	sjmp	00106$
      0042BD                       1569 00131$:
                                   1570 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      0042BD 90 05 96         [24] 1571 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0042C0 E0               [24] 1572 	movx	a,@dptr
      0042C1 F8               [12] 1573 	mov	r0,a
      0042C2 A3               [24] 1574 	inc	dptr
      0042C3 E0               [24] 1575 	movx	a,@dptr
      0042C4 FD               [12] 1576 	mov	r5,a
      0042C5 90 05 8A         [24] 1577 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0042C8 E5 12            [12] 1578 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0042CA F0               [24] 1579 	movx	@dptr,a
      0042CB E5 13            [12] 1580 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0042CD A3               [24] 1581 	inc	dptr
      0042CE F0               [24] 1582 	movx	@dptr,a
      0042CF E5 14            [12] 1583 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0042D1 A3               [24] 1584 	inc	dptr
      0042D2 F0               [24] 1585 	movx	@dptr,a
      0042D3 90 05 8D         [24] 1586 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0042D6 E5 10            [12] 1587 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042D8 F0               [24] 1588 	movx	@dptr,a
      0042D9 E5 11            [12] 1589 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042DB A3               [24] 1590 	inc	dptr
      0042DC F0               [24] 1591 	movx	@dptr,a
      0042DD 88 82            [24] 1592 	mov	dpl, r0
      0042DF 8D 83            [24] 1593 	mov	dph, r5
                                   1594 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0042E1 02 41 68         [24] 1595 	ljmp	_ak820_eeprom_write_block_xdata
      0042E4                       1596 00106$:
                                   1597 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042E4 05 0E            [12] 1598 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042E6 E4               [12] 1599 	clr	a
      0042E7 B5 0E 87         [24] 1600 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0042EA 05 0F            [12] 1601 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042EC 80 83            [24] 1602 	sjmp	00105$
      0042EE                       1603 00107$:
                                   1604 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0042EE 22               [24] 1605 	ret
                                   1606 ;------------------------------------------------------------
                                   1607 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1608 ;------------------------------------------------------------
                                   1609 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1610 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1611 ;------------------------------------------------------------
                                   1612 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1613 ;	-----------------------------------------
                                   1614 ;	 function eeprom_driver_erase
                                   1615 ;	-----------------------------------------
      0042EF                       1616 _eeprom_driver_erase:
                                   1617 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0042EF 12 3E 57         [24] 1618 	lcall	_ak820_nvm_flush
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042F2 7F 00            [12] 1620 	mov	r7,#0x00
      0042F4                       1621 00111$:
      0042F4 BF A0 01         [24] 1622 	cjne	r7,#0xa0,00165$
      0042F7 22               [24] 1623 	ret
      0042F8                       1624 00165$:
      0042F8 20 09 32         [24] 1625 	jb	_storage_failed,00113$
                                   1626 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0042FB 8F 82            [24] 1627 	mov	dpl, r7
      0042FD C0 07            [24] 1628 	push	ar7
      0042FF 12 3F D6         [24] 1629 	lcall	_load_page
      004302 E5 82            [12] 1630 	mov	a, dpl
      004304 D0 07            [24] 1631 	pop	ar7
      004306 70 01            [24] 1632 	jnz	00126$
                                   1633 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004308 22               [24] 1634 	ret
      004309                       1635 00126$:
      004309 7E 00            [12] 1636 	mov	r6,#0x00
      00430B                       1637 00107$:
                                   1638 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      00430B EE               [12] 1639 	mov	a,r6
      00430C 24 19            [12] 1640 	add	a, #_page_data
      00430E FC               [12] 1641 	mov	r4,a
      00430F E4               [12] 1642 	clr	a
      004310 34 05            [12] 1643 	addc	a, #(_page_data >> 8)
      004312 FD               [12] 1644 	mov	r5,a
      004313 12 43 71         [24] 1645 	lcall	_ak820_outline_0092
      004316 60 07            [24] 1646 	jz	00108$
      004318 12 38 55         [24] 1647 	lcall	_ak820_outline_0117
      00431B E4               [12] 1648 	clr	a
      00431C F0               [24] 1649 	movx	@dptr,a
                                   1650 ;	assignBit
      00431D D2 08            [12] 1651 	setb	_page_dirty
      00431F                       1652 00108$:
                                   1653 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00431F 0E               [12] 1654 	inc	r6
      004320 BE 40 E8         [24] 1655 	cjne	r6,#0x40,00107$
                                   1656 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004323 C0 07            [24] 1657 	push	ar7
      004325 12 3E 57         [24] 1658 	lcall	_ak820_nvm_flush
      004328 D0 07            [24] 1659 	pop	ar7
                                   1660 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00432A 0F               [12] 1661 	inc	r7
      00432B 80 C7            [24] 1662 	sjmp	00111$
      00432D                       1663 00113$:
                                   1664 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      00432D 22               [24] 1665 	ret
                                   1666 	.area CSEG    (CODE)
                                   1667 	.area CONST   (CODE)
                                   1668 	.area XINIT   (CODE)
                                   1669 	.area CABS    (ABS,CODE)
                                   1670 
                                   1671 ; Experimental exact instruction outlining.
                                   1672 	.globl _ak820_outline_0004
                                   1673 	.globl _ak820_outline_0011
                                   1674 	.globl _ak820_outline_0016
                                   1675 	.globl _ak820_outline_0017
                                   1676 	.globl _ak820_outline_0030
                                   1677 	.globl _ak820_outline_0037
                                   1678 	.globl _ak820_outline_0041
                                   1679 	.globl _ak820_outline_0051
                                   1680 	.globl _ak820_outline_0052
                                   1681 	.globl _ak820_outline_0060
                                   1682 	.globl _ak820_outline_0061
                                   1683 	.globl _ak820_outline_0065
                                   1684 	.globl _ak820_outline_0071
                                   1685 	.globl _ak820_outline_0077
                                   1686 	.globl _ak820_outline_0092
                                   1687 	.globl _ak820_outline_0093
                                   1688 	.globl _ak820_outline_0100
                                   1689 	.globl _ak820_outline_0101
                                   1690 	.globl _ak820_outline_0103
                                   1691 	.globl _ak820_outline_0104
                                   1692 	.globl _ak820_outline_0116
                                   1693 	.globl _ak820_outline_0117
                                   1694 	.globl _ak820_outline_0120
                                   1695 	.globl _ak820_outline_0121
                                   1696 	.globl _ak820_outline_0122
                                   1697 	.globl _ak820_outline_0131
                                   1698 	.globl _ak820_outline_0132
                                   1699 	.globl _ak820_outline_0134
                                   1700 	.globl _ak820_outline_0139
                                   1701 	.globl _ak820_outline_0140
                                   1702 	.globl _ak820_outline_0145
                                   1703 	.globl _ak820_outline_0153
                                   1704 	.globl _ak820_outline_0156
                                   1705 	.globl _ak820_outline_0157
                                   1706 	.globl _ak820_outline_0167
                                   1707 	.globl _ak820_outline_0179
                                   1708 	.globl _ak820_outline_0180
                                   1709 	.globl _ak820_outline_0184
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0011
      00432E                       1713 _ak820_outline_0011:
      00432E 8E 82            [24] 1714 	mov	dpl,r6
      004330 8F 83            [24] 1715 	mov	dph,r7
      004332 A3               [24] 1716 	inc	dptr
      004333 A3               [24] 1717 	inc	dptr
      004334 A3               [24] 1718 	inc	dptr
      004335 A3               [24] 1719 	inc	dptr
      004336 A3               [24] 1720 	inc	dptr
      004337 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0030
      004338                       1725 _ak820_outline_0030:
      004338 F0               [24] 1726 	movx	@dptr,a
      004339 8E 82            [24] 1727 	mov	dpl,r6
      00433B 8F 83            [24] 1728 	mov	dph,r7
      00433D A3               [24] 1729 	inc	dptr
      00433E A3               [24] 1730 	inc	dptr
      00433F 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0037
      004340                       1735 _ak820_outline_0037:
      004340 AF F0            [24] 1736 	mov	r7,b
      004342 AE 83            [24] 1737 	mov	r6,dph
      004344 E5 82            [12] 1738 	mov	a,dpl
      004346 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0041
      004347                       1743 _ak820_outline_0041:
      004347 EF               [12] 1744 	mov	a,r7
      004348 24 71            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      00434A F5 82            [12] 1746 	mov	dpl,a
      00434C E4               [12] 1747 	clr	a
      00434D 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00434F F5 83            [12] 1749 	mov	dph,a
      004351 E0               [24] 1750 	movx	a,@dptr
      004352 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0052
      004353                       1755 _ak820_outline_0052:
      004353 8F 06            [24] 1756 	mov	ar6,r7
      004355 7D 00            [12] 1757 	mov	r5,#0x00
      004357 74 40            [12] 1758 	mov	a,#0x40
      004359 2E               [12] 1759 	add	a,r6
      00435A FE               [12] 1760 	mov	r6,a
      00435B 74 EF            [12] 1761 	mov	a,#0xef
      00435D 3D               [12] 1762 	addc	a,r5
      00435E FD               [12] 1763 	mov	r5,a
      00435F 8E 82            [24] 1764 	mov	dpl,r6
      004361 8D 83            [24] 1765 	mov	dph,r5
      004363 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0061
      004364                       1770 _ak820_outline_0061:
      004364 F0               [24] 1771 	movx	@dptr,a
      004365 8E 82            [24] 1772 	mov	dpl,r6
      004367 8F 83            [24] 1773 	mov	dph,r7
      004369 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0065
      00436A                       1778 _ak820_outline_0065:
      00436A 8D 82            [24] 1779 	mov	dpl,r5
      00436C 8E 83            [24] 1780 	mov	dph,r6
      00436E EC               [12] 1781 	mov	a,r4
      00436F F0               [24] 1782 	movx	@dptr,a
      004370 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0092
      004371                       1787 _ak820_outline_0092:
      004371 8C 82            [24] 1788 	mov	dpl,r4
      004373 8D 83            [24] 1789 	mov	dph,r5
      004375 E0               [24] 1790 	movx	a,@dptr
      004376 22               [24] 1791 	ret
                                   1792 
                                   1793 	.area CSEG (CODE)
                                   1794 ; function ak820_outline_0093
      004377                       1795 _ak820_outline_0093:
      004377 E0               [24] 1796 	movx	a,@dptr
      004378 FD               [12] 1797 	mov	r5,a
      004379 A3               [24] 1798 	inc	dptr
      00437A E0               [24] 1799 	movx	a,@dptr
      00437B FE               [12] 1800 	mov	r6,a
      00437C 22               [24] 1801 	ret
                                   1802 
                                   1803 	.area CSEG (CODE)
                                   1804 ; function ak820_outline_0101
      00437D                       1805 _ak820_outline_0101:
      00437D EF               [12] 1806 	mov	a,r7
      00437E 24 19            [12] 1807 	add	a,#_page_data
      004380 F5 82            [12] 1808 	mov	dpl,a
      004382 E4               [12] 1809 	clr	a
      004383 34 05            [12] 1810 	addc	a,#(_page_data>>8)
      004385 F5 83            [12] 1811 	mov	dph,a
      004387 E0               [24] 1812 	movx	a,@dptr
      004388 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0116
      004389                       1817 _ak820_outline_0116:
      004389 8E 82            [24] 1818 	mov	dpl,r6
      00438B 8F 83            [24] 1819 	mov	dph,r7
      00438D 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0120
      00438E                       1824 _ak820_outline_0120:
      00438E E0               [24] 1825 	movx	a,@dptr
      00438F FA               [12] 1826 	mov	r2,a
      004390 A3               [24] 1827 	inc	dptr
      004391 E0               [24] 1828 	movx	a,@dptr
      004392 FB               [12] 1829 	mov	r3,a
      004393 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0131
      004394                       1834 _ak820_outline_0131:
      004394 AE 82            [24] 1835 	mov	r6,dpl
      004396 AF 83            [24] 1836 	mov	r7,dph
      004398 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0134
      004399                       1841 _ak820_outline_0134:
      004399 2E               [12] 1842 	add	a,r6
      00439A FE               [12] 1843 	mov	r6,a
      00439B E4               [12] 1844 	clr	a
      00439C 3F               [12] 1845 	addc	a,r7
      00439D FF               [12] 1846 	mov	r7,a
      00439E 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0139
      00439F                       1851 _ak820_outline_0139:
      00439F 42 05            [12] 1852 	orl	ar5,a
      0043A1 EA               [12] 1853 	mov	a,r2
      0043A2 42 04            [12] 1854 	orl	ar4,a
      0043A4 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0140
      0043A5                       1859 _ak820_outline_0140:
      0043A5 8A 82            [24] 1860 	mov	dpl,r2
      0043A7 8B 83            [24] 1861 	mov	dph,r3
      0043A9 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0145
      0043AA                       1866 _ak820_outline_0145:
      0043AA AC 82            [24] 1867 	mov	r4,dpl
      0043AC AD 83            [24] 1868 	mov	r5,dph
      0043AE 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0153
      0043AF                       1873 _ak820_outline_0153:
      0043AF 8F 82            [24] 1874 	mov	dpl,r7
      0043B1 8E 83            [24] 1875 	mov	dph,r6
      0043B3 22               [24] 1876 	ret
                                   1877 
                                   1878 	.area CSEG (CODE)
                                   1879 ; function ak820_outline_0156
      0043B4                       1880 _ak820_outline_0156:
      0043B4 2E               [12] 1881 	add	a,r6
      0043B5 FC               [12] 1882 	mov	r4,a
      0043B6 E4               [12] 1883 	clr	a
      0043B7 3F               [12] 1884 	addc	a,r7
      0043B8 FD               [12] 1885 	mov	r5,a
      0043B9 22               [24] 1886 	ret
                                   1887 
                                   1888 	.area CSEG (CODE)
                                   1889 ; function ak820_outline_0157
      0043BA                       1890 _ak820_outline_0157:
      0043BA ED               [12] 1891 	mov	a,r5
      0043BB F0               [24] 1892 	movx	@dptr,a
      0043BC EE               [12] 1893 	mov	a,r6
      0043BD A3               [24] 1894 	inc	dptr
      0043BE F0               [24] 1895 	movx	@dptr,a
      0043BF 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0179
      0043C0                       1900 _ak820_outline_0179:
      0043C0 89 82            [24] 1901 	mov	dpl,r1
      0043C2 8A 83            [24] 1902 	mov	dph,r2
      0043C4 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0180
      0043C5                       1907 _ak820_outline_0180:
      0043C5 8C 82            [24] 1908 	mov	dpl,r4
      0043C7 8B 83            [24] 1909 	mov	dph,r3
      0043C9 22               [24] 1910 	ret
                                   1911 
                                   1912 	.area CSEG (CODE)
                                   1913 ; function ak820_outline_0184
      0043CA                       1914 _ak820_outline_0184:
      0043CA 8D 82            [24] 1915 	mov	dpl,r5
      0043CC 8C 83            [24] 1916 	mov	dph,r4
      0043CE 22               [24] 1917 	ret
