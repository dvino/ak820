                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000028                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000028                        588 	.ds 2
      00002A                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002A                        590 	.ds 1
      00002B                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002B                        592 	.ds 1
      00002C                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002C                        594 	.ds 2
      00002E                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002E                        596 	.ds 2
      000030                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000030                        598 	.ds 1
      000031                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000031                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000022                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000022                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000AD7                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AD7                        628 	.ds 1
      000AD8                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AD8                        630 	.ds 1
      000AD9                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_364:
      000AD9                        632 	.ds 1
      000ADA                        633 _dynamic_keymap_get_keycode_PARM_2:
      000ADA                        634 	.ds 1
      000ADB                        635 _dynamic_keymap_get_keycode_PARM_3:
      000ADB                        636 	.ds 1
      000ADC                        637 _dynamic_keymap_get_keycode_layer_10000_366:
      000ADC                        638 	.ds 1
      000ADD                        639 _dynamic_keymap_set_keycode_PARM_2:
      000ADD                        640 	.ds 1
      000ADE                        641 _dynamic_keymap_set_keycode_PARM_3:
      000ADE                        642 	.ds 1
      000ADF                        643 _dynamic_keymap_set_keycode_PARM_4:
      000ADF                        644 	.ds 2
      000AE1                        645 _dynamic_keymap_set_keycode_layer_10000_370:
      000AE1                        646 	.ds 1
      000AE2                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000AE2                        648 	.ds 1
      000AE3                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_374:
      000AE3                        650 	.ds 1
      000AE4                        651 _dynamic_keymap_get_encoder_PARM_2:
      000AE4                        652 	.ds 1
      000AE5                        653 _dynamic_keymap_get_encoder_PARM_3:
      000AE5                        654 	.ds 1
      000AE6                        655 _dynamic_keymap_get_encoder_layer_10000_376:
      000AE6                        656 	.ds 1
      000AE7                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AE7                        658 	.ds 1
      000AE8                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AE8                        660 	.ds 1
      000AE9                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AE9                        662 	.ds 2
      000AEB                        663 _dynamic_keymap_set_encoder_layer_10000_380:
      000AEB                        664 	.ds 1
      000AEC                        665 _dynamic_keymap_get_combo_PARM_2:
      000AEC                        666 	.ds 3
      000AEF                        667 _dynamic_keymap_get_combo_index_10000_384:
      000AEF                        668 	.ds 1
      000AF0                        669 _dynamic_keymap_set_combo_PARM_2:
      000AF0                        670 	.ds 3
      000AF3                        671 _dynamic_keymap_set_combo_index_10000_390:
      000AF3                        672 	.ds 1
      000AF4                        673 _dynamic_keymap_set_combo_stored_10002_395:
      000AF4                        674 	.ds 10
      000AFE                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_398:
      000AFE                        676 	.ds 1
      000AFF                        677 _dynamic_keymap_reset_combo_10001_407:
      000AFF                        678 	.ds 10
      000B09                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B09                        680 	.ds 2
      000B0B                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B0B                        682 	.ds 2
      000B0D                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B0D                        684 	.ds 2
      000B0F                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B0F                        686 	.ds 3
      000B12                        687 _ak820_dynamic_read_buffer_base_10000_409:
      000B12                        688 	.ds 2
      000B14                        689 _ak820_dynamic_read_buffer_available_10000_410:
      000B14                        690 	.ds 1
      000B15                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B15                        692 	.ds 2
      000B17                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B17                        694 	.ds 3
      000B1A                        695 _dynamic_keymap_get_buffer_offset_10000_416:
      000B1A                        696 	.ds 2
      000B1C                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B1C                        698 	.ds 2
      000B1E                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B1E                        700 	.ds 3
      000B21                        701 _dynamic_keymap_set_buffer_offset_10000_418:
      000B21                        702 	.ds 2
      000B23                        703 _dynamic_keymap_set_buffer_chk_offset_30001_425:
      000B23                        704 	.ds 1
      000B24                        705 _dynamic_keymap_set_buffer_chk_sz_30001_425:
      000B24                        706 	.ds 1
      000B25                        707 _dynamic_keymap_set_buffer_i_40001_432:
      000B25                        708 	.ds 1
      000B26                        709 _keycode_at_keymap_location_PARM_2:
      000B26                        710 	.ds 1
      000B27                        711 _keycode_at_keymap_location_PARM_3:
      000B27                        712 	.ds 1
      000B28                        713 _keycode_at_keymap_location_layer_num_10000_436:
      000B28                        714 	.ds 1
      000B29                        715 _keycode_at_encodermap_location_PARM_2:
      000B29                        716 	.ds 1
      000B2A                        717 _keycode_at_encodermap_location_PARM_3:
      000B2A                        718 	.ds 1
      000B2B                        719 _keycode_at_encodermap_location_layer_num_10000_440:
      000B2B                        720 	.ds 1
      000B2C                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B2C                        722 	.ds 2
      000B2E                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B2E                        724 	.ds 3
      000B31                        725 _dynamic_keymap_macro_get_buffer_offset_10000_448:
      000B31                        726 	.ds 2
      000B33                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B33                        728 	.ds 2
      000B35                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B35                        730 	.ds 3
      000B38                        731 _dynamic_keymap_macro_set_buffer_offset_10000_450:
      000B38                        732 	.ds 2
      000B3A                        733 _decode_keycode_kc_10000_454:
      000B3A                        734 	.ds 2
      000B3C                        735 _dynamic_keymap_macro_send_id_10000_457:
      000B3C                        736 	.ds 1
      000B3D                        737 _dynamic_keymap_macro_send_sending_10000_458:
      000B3D                        738 	.ds 1
      000B3E                        739 _dynamic_keymap_macro_send_p_10001_463:
      000B3E                        740 	.ds 2
      000B40                        741 _dynamic_keymap_macro_send_data_10003_470:
      000B40                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      00849F                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      00849F 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      0084A2 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_364'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      0084A3                        810 _dynamic_keymap_key_to_eeprom_address:
      0084A3 E5 82            [12]  811 	mov	a,dpl
      0084A5 90 0A D9         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_364
      0084A8 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      0084A9 E0               [24]  815 	movx	a,@dptr
      0084AA FF               [12]  816 	mov	r7,a
      0084AB 7E 00            [12]  817 	mov	r6,#0x00
      0084AD 74 40            [12]  818 	mov	a,#0x40
      0084AF 12 43 99         [24]  819 	lcall	_ak820_outline_0134
      0084B2 7D 00            [12]  820 	mov	r5,#0x00
      0084B4 90 0A D7         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0084B7 E0               [24]  822 	movx	a,@dptr
      0084B8 75 F0 10         [24]  823 	mov	b,#0x10
      0084BB A4               [48]  824 	mul	ab
      0084BC 2E               [12]  825 	add	a, r6
      0084BD FE               [12]  826 	mov	r6,a
      0084BE EF               [12]  827 	mov	a,r7
      0084BF 35 F0            [12]  828 	addc	a, b
      0084C1 FF               [12]  829 	mov	r7,a
      0084C2 90 0A D8         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0084C5 E0               [24]  831 	movx	a,@dptr
      0084C6 7C 00            [12]  832 	mov	r4,#0x00
      0084C8 25 E0            [12]  833 	add	a,acc
      0084CA FB               [12]  834 	mov	r3,a
      0084CB EC               [12]  835 	mov	a,r4
      0084CC 33               [12]  836 	rlc	a
      0084CD FC               [12]  837 	mov	r4,a
      0084CE EB               [12]  838 	mov	a,r3
      0084CF 2E               [12]  839 	add	a, r6
      0084D0 FE               [12]  840 	mov	r6,a
      0084D1 EC               [12]  841 	mov	a,r4
      0084D2 3F               [12]  842 	addc	a, r7
      0084D3 FF               [12]  843 	mov	r7,a
      0084D4 12 43 89         [24]  844 	lcall	_ak820_outline_0116
      0084D7 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      0084D9 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_366'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_369'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_369'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      0084DA                        861 _dynamic_keymap_get_keycode:
      0084DA E5 82            [12]  862 	mov	a,dpl
      0084DC 90 0A DC         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_366
      0084DF F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0084E0 E0               [24]  866 	movx	a,@dptr
      0084E1 FF               [12]  867 	mov	r7,a
      0084E2 BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      0084E5                        869 00121$:
      0084E5 50 14            [24]  870 	jnc	00101$
      0084E7 90 0A DA         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0084EA E0               [24]  872 	movx	a,@dptr
      0084EB FE               [12]  873 	mov	r6,a
      0084EC BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      0084EF                        875 00123$:
      0084EF 50 0A            [24]  876 	jnc	00101$
      0084F1 90 0A DB         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0084F4 E0               [24]  878 	movx	a,@dptr
      0084F5 FD               [12]  879 	mov	r5,a
      0084F6 BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      0084F9                        881 00125$:
      0084F9 40 04            [24]  882 	jc	00102$
      0084FB                        883 00101$:
      0084FB 90 00 00         [24]  884 	mov	dptr,#0x0000
      0084FE 22               [24]  885 	ret
      0084FF                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0084FF 12 8F 52         [24]  888 	lcall	_ak820_outline_0096
      008502 12 84 A3         [24]  889 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008505 12 8F 5F         [24]  891 	lcall	_ak820_outline_0112
      008508 12 40 A1         [24]  892 	lcall	_eeprom_read_byte
      00850B AB 82            [24]  893 	mov	r3,dpl
      00850D 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      00850F 0D               [12]  896 	inc	r5
      008510 BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      008513 0E               [12]  898 	inc	r6
      008514                        899 00127$:
      008514 12 4F C5         [24]  900 	lcall	_ak820_outline_0044
      008517 12 40 A1         [24]  901 	lcall	_eeprom_read_byte
      00851A AF 82            [24]  902 	mov	r7, dpl
      00851C 7E 00            [12]  903 	mov	r6,#0x00
      00851E EF               [12]  904 	mov	a,r7
      00851F 42 04            [12]  905 	orl	ar4,a
      008521 EE               [12]  906 	mov	a,r6
      008522 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      008524 12 43 C5         [24]  909 	lcall	_ak820_outline_0180
                                    910 ;	quantum/dynamic_keymap.c:215: }
      008527 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_370'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_373'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      008528                        925 _dynamic_keymap_set_keycode:
      008528 E5 82            [12]  926 	mov	a,dpl
      00852A 90 0A E1         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_370
      00852D F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      00852E E0               [24]  930 	movx	a,@dptr
      00852F FF               [12]  931 	mov	r7,a
      008530 BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      008533                        933 00121$:
      008533 50 14            [24]  934 	jnc	00101$
      008535 90 0A DD         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008538 E0               [24]  936 	movx	a,@dptr
      008539 FE               [12]  937 	mov	r6,a
      00853A BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      00853D                        939 00123$:
      00853D 50 0A            [24]  940 	jnc	00101$
      00853F 90 0A DE         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008542 E0               [24]  942 	movx	a,@dptr
      008543 FD               [12]  943 	mov	r5,a
      008544 BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      008547                        945 00125$:
      008547 40 01            [24]  946 	jc	00102$
      008549                        947 00101$:
      008549 22               [24]  948 	ret
      00854A                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00854A 12 8F 52         [24]  951 	lcall	_ak820_outline_0096
      00854D 12 84 A3         [24]  952 	lcall	_dynamic_keymap_key_to_eeprom_address
      008550 12 8F 5F         [24]  953 	lcall	_ak820_outline_0112
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008553 90 0A DF         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008556 E0               [24]  956 	movx	a,@dptr
      008557 FB               [12]  957 	mov	r3,a
      008558 A3               [24]  958 	inc	dptr
      008559 E0               [24]  959 	movx	a,@dptr
      00855A 90 06 9F         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      00855D F0               [24]  961 	movx	@dptr,a
      00855E 12 4F C5         [24]  962 	lcall	_ak820_outline_0044
      008561 12 4E AE         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008564 0D               [12]  965 	inc	r5
      008565 BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      008568 0E               [12]  967 	inc	r6
      008569                        968 00127$:
      008569 90 06 9F         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      00856C EB               [12]  970 	mov	a,r3
      00856D F0               [24]  971 	movx	@dptr,a
      00856E 12 4F C5         [24]  972 	lcall	_ak820_outline_0044
                                    973 ;	quantum/dynamic_keymap.c:223: }
      008571 02 4E AE         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      008574                        985 _dynamic_keymap_encoder_to_eeprom_address:
      008574 E5 82            [12]  986 	mov	a,dpl
      008576 90 0A E3         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374
      008579 F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      00857A E0               [24]  990 	movx	a,@dptr
      00857B 75 F0 04         [24]  991 	mov	b,#0x04
      00857E A4               [48]  992 	mul	ab
      00857F 24 40            [12]  993 	add	a, #0x40
      008581 FD               [12]  994 	mov	r5,a
      008582 74 06            [12]  995 	mov	a,#0x06
      008584 35 F0            [12]  996 	addc	a, b
      008586 FE               [12]  997 	mov	r6,a
      008587 7F 00            [12]  998 	mov	r7,#0x00
      008589 90 0A E2         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00858C E0               [24] 1000 	movx	a,@dptr
      00858D 75 F0 04         [24] 1001 	mov	b,#0x04
      008590 A4               [48] 1002 	mul	ab
      008591 2D               [12] 1003 	add	a, r5
      008592 FD               [12] 1004 	mov	r5,a
      008593 EE               [12] 1005 	mov	a,r6
      008594 35 F0            [12] 1006 	addc	a, b
      008596 FE               [12] 1007 	mov	r6,a
      008597 12 4F C5         [24] 1008 	lcall	_ak820_outline_0044
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      00859A 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_376'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_379'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_379'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      00859B                       1024 _dynamic_keymap_get_encoder:
      00859B E5 82            [12] 1025 	mov	a,dpl
      00859D 90 0A E6         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_376
      0085A0 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      0085A1 E0               [24] 1029 	movx	a,@dptr
      0085A2 FF               [12] 1030 	mov	r7,a
      0085A3 BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      0085A6                       1032 00131$:
      0085A6 50 0A            [24] 1033 	jnc	00101$
      0085A8 90 0A E4         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0085AB E0               [24] 1035 	movx	a,@dptr
      0085AC FE               [12] 1036 	mov	r6,a
      0085AD BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      0085B0                       1038 00133$:
      0085B0 40 04            [24] 1039 	jc	00102$
      0085B2                       1040 00101$:
      0085B2 90 00 00         [24] 1041 	mov	dptr,#0x0000
      0085B5 22               [24] 1042 	ret
      0085B6                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0085B6 90 0A E2         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0085B9 E4               [12] 1046 	clr	a
      0085BA F0               [24] 1047 	movx	@dptr,a
      0085BB 8F 82            [24] 1048 	mov	dpl, r7
      0085BD 12 85 74         [24] 1049 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0085C0 12 8F 5F         [24] 1050 	lcall	_ak820_outline_0112
                                   1051 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      0085C3 90 0A E5         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0085C6 E0               [24] 1053 	movx	a,@dptr
      0085C7 FC               [12] 1054 	mov	r4,a
      0085C8 E0               [24] 1055 	movx	a,@dptr
      0085C9 60 04            [24] 1056 	jz	00106$
      0085CB 7B 00            [12] 1057 	mov	r3,#0x00
      0085CD 80 02            [24] 1058 	sjmp	00107$
      0085CF                       1059 00106$:
      0085CF 7B 02            [12] 1060 	mov	r3,#0x02
      0085D1                       1061 00107$:
      0085D1 EB               [12] 1062 	mov	a,r3
      0085D2 12 8F 30         [24] 1063 	lcall	_ak820_outline_0025
      0085D5 12 40 A1         [24] 1064 	lcall	_eeprom_read_byte
      0085D8 AA 82            [24] 1065 	mov	r2,dpl
      0085DA 7B 00            [12] 1066 	mov	r3,#0x00
                                   1067 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0085DC EC               [12] 1068 	mov	a,r4
      0085DD 60 04            [24] 1069 	jz	00108$
      0085DF 7C 00            [12] 1070 	mov	r4,#0x00
      0085E1 80 02            [24] 1071 	sjmp	00109$
      0085E3                       1072 00108$:
      0085E3 7C 02            [12] 1073 	mov	r4,#0x02
      0085E5                       1074 00109$:
      0085E5 EC               [12] 1075 	mov	a,r4
      0085E6 12 38 75         [24] 1076 	lcall	_ak820_outline_0155
      0085E9 0D               [12] 1077 	inc	r5
      0085EA BD 00 01         [24] 1078 	cjne	r5,#0x00,00137$
      0085ED 0E               [12] 1079 	inc	r6
      0085EE                       1080 00137$:
      0085EE 12 4F C5         [24] 1081 	lcall	_ak820_outline_0044
      0085F1 12 40 A1         [24] 1082 	lcall	_eeprom_read_byte
      0085F4 AF 82            [24] 1083 	mov	r7, dpl
      0085F6 7E 00            [12] 1084 	mov	r6,#0x00
      0085F8 EF               [12] 1085 	mov	a,r7
      0085F9 42 03            [12] 1086 	orl	ar3,a
      0085FB EE               [12] 1087 	mov	a,r6
      0085FC 42 02            [12] 1088 	orl	ar2,a
                                   1089 ;	quantum/dynamic_keymap.c:236: return keycode;
      0085FE 8B 82            [24] 1090 	mov	dpl, r3
      008600 8A 83            [24] 1091 	mov	dph, r2
                                   1092 ;	quantum/dynamic_keymap.c:237: }
      008602 22               [24] 1093 	ret
                                   1094 ;------------------------------------------------------------
                                   1095 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1096 ;------------------------------------------------------------
                                   1097 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1098 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1099 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1100 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1101 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_380'
                                   1102 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_383'
                                   1103 ;------------------------------------------------------------
                                   1104 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1105 ;	-----------------------------------------
                                   1106 ;	 function dynamic_keymap_set_encoder
                                   1107 ;	-----------------------------------------
      008603                       1108 _dynamic_keymap_set_encoder:
      008603 E5 82            [12] 1109 	mov	a,dpl
      008605 90 0A EB         [24] 1110 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_380
      008608 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008609 E0               [24] 1113 	movx	a,@dptr
      00860A FF               [12] 1114 	mov	r7,a
      00860B BF 06 00         [24] 1115 	cjne	r7,#0x06,00131$
      00860E                       1116 00131$:
      00860E 50 0A            [24] 1117 	jnc	00101$
      008610 90 0A E7         [24] 1118 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008613 E0               [24] 1119 	movx	a,@dptr
      008614 FE               [12] 1120 	mov	r6,a
      008615 BE 01 00         [24] 1121 	cjne	r6,#0x01,00133$
      008618                       1122 00133$:
      008618 40 01            [24] 1123 	jc	00102$
      00861A                       1124 00101$:
      00861A 22               [24] 1125 	ret
      00861B                       1126 00102$:
                                   1127 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00861B 90 0A E2         [24] 1128 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00861E E4               [12] 1129 	clr	a
      00861F F0               [24] 1130 	movx	@dptr,a
      008620 8F 82            [24] 1131 	mov	dpl, r7
      008622 12 85 74         [24] 1132 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008625 12 8F 5F         [24] 1133 	lcall	_ak820_outline_0112
                                   1134 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008628 90 0A E8         [24] 1135 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00862B E0               [24] 1136 	movx	a,@dptr
      00862C FC               [12] 1137 	mov	r4,a
      00862D E0               [24] 1138 	movx	a,@dptr
      00862E 60 04            [24] 1139 	jz	00106$
      008630 7B 00            [12] 1140 	mov	r3,#0x00
      008632 80 02            [24] 1141 	sjmp	00107$
      008634                       1142 00106$:
      008634 7B 02            [12] 1143 	mov	r3,#0x02
      008636                       1144 00107$:
      008636 EB               [12] 1145 	mov	a,r3
      008637 12 8F 71         [24] 1146 	lcall	_ak820_outline_0133
      00863A 8F 03            [24] 1147 	mov	ar3,r7
      00863C 90 0A E9         [24] 1148 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00863F E0               [24] 1149 	movx	a,@dptr
      008640 F5 28            [12] 1150 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008642 A3               [24] 1151 	inc	dptr
      008643 E0               [24] 1152 	movx	a,@dptr
      008644 F5 29            [12] 1153 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008646 90 06 9F         [24] 1154 	mov	dptr,#_eeprom_update_byte_PARM_2
      008649 F0               [24] 1155 	movx	@dptr,a
      00864A 12 43 C0         [24] 1156 	lcall	_ak820_outline_0179
      00864D 8B F0            [24] 1157 	mov	b, r3
      00864F 12 4E AE         [24] 1158 	lcall	_eeprom_update_byte
                                   1159 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008652 EC               [12] 1160 	mov	a,r4
      008653 60 04            [24] 1161 	jz	00108$
      008655 7C 00            [12] 1162 	mov	r4,#0x00
      008657 80 02            [24] 1163 	sjmp	00109$
      008659                       1164 00108$:
      008659 7C 02            [12] 1165 	mov	r4,#0x02
      00865B                       1166 00109$:
      00865B EC               [12] 1167 	mov	a,r4
      00865C 12 38 75         [24] 1168 	lcall	_ak820_outline_0155
      00865F 0D               [12] 1169 	inc	r5
      008660 BD 00 01         [24] 1170 	cjne	r5,#0x00,00137$
      008663 0E               [12] 1171 	inc	r6
      008664                       1172 00137$:
      008664 90 06 9F         [24] 1173 	mov	dptr,#_eeprom_update_byte_PARM_2
      008667 E5 28            [12] 1174 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008669 F0               [24] 1175 	movx	@dptr,a
      00866A 12 4F C5         [24] 1176 	lcall	_ak820_outline_0044
                                   1177 ;	quantum/dynamic_keymap.c:245: }
      00866D 02 4E AE         [24] 1178 	ljmp	_eeprom_update_byte
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1183 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1184 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_384'
                                   1185 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_385'
                                   1186 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_387'
                                   1187 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_388'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function dynamic_keymap_get_combo
                                   1192 ;	-----------------------------------------
      008670                       1193 _dynamic_keymap_get_combo:
      008670 E5 82            [12] 1194 	mov	a,dpl
      008672 90 0A EF         [24] 1195 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      008675 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008676 90 0A EC         [24] 1198 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008679 12 38 01         [24] 1199 	lcall	_ak820_outline_0051
                                   1200 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      00867C 90 0A EF         [24] 1201 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      00867F E0               [24] 1202 	movx	a,@dptr
      008680 FD               [12] 1203 	mov	r5,a
      008681 BD 08 00         [24] 1204 	cjne	r5,#0x08,00132$
      008684                       1205 00132$:
      008684 40 04            [24] 1206 	jc	00102$
                                   1207 ;	quantum/dynamic_keymap.c:315: return -1;
      008686 90 FF FF         [24] 1208 	mov	dptr,#0xffff
      008689 22               [24] 1209 	ret
      00868A                       1210 00102$:
                                   1211 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00868A 12 8F 3E         [24] 1212 	lcall	_ak820_outline_0079
                                   1213 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      00868D 8E 02            [24] 1214 	mov	ar2,r6
      00868F 8F 03            [24] 1215 	mov	ar3,r7
      008691 90 05 81         [24] 1216 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008694 12 38 26         [24] 1217 	lcall	_ak820_outline_0071
      008697 E4               [12] 1218 	clr	a
      008698 A3               [24] 1219 	inc	dptr
      008699 F0               [24] 1220 	movx	@dptr,a
      00869A 90 05 84         [24] 1221 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00869D 74 0A            [12] 1222 	mov	a,#0x0a
      00869F 12 38 60         [24] 1223 	lcall	_ak820_outline_0123
      0086A2 12 43 A5         [24] 1224 	lcall	_ak820_outline_0140
      0086A5 C0 07            [24] 1225 	push	ar7
      0086A7 C0 06            [24] 1226 	push	ar6
      0086A9 12 40 DC         [24] 1227 	lcall	_ak820_eeprom_read_block_xdata
      0086AC D0 06            [24] 1228 	pop	ar6
      0086AE D0 07            [24] 1229 	pop	ar7
                                   1230 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      0086B0 74 04            [12] 1231 	mov	a,#0x04
      0086B2 12 49 15         [24] 1232 	lcall	_ak820_outline_0012
      0086B5 FA               [12] 1233 	mov	r2,a
      0086B6 A3               [24] 1234 	inc	dptr
      0086B7 E0               [24] 1235 	movx	a,@dptr
      0086B8 FB               [12] 1236 	mov	r3,a
      0086B9 BA 20 14         [24] 1237 	cjne	r2,#0x20,00108$
      0086BC BB 08 11         [24] 1238 	cjne	r3,#0x08,00108$
      0086BF 74 06            [12] 1239 	mov	a,#0x06
      0086C1 12 37 E8         [24] 1240 	lcall	_ak820_outline_0017
      0086C4 FA               [12] 1241 	mov	r2,a
      0086C5 A3               [24] 1242 	inc	dptr
      0086C6 E0               [24] 1243 	movx	a,@dptr
      0086C7 FB               [12] 1244 	mov	r3,a
      0086C8 BA 01 05         [24] 1245 	cjne	r2,#0x01,00136$
      0086CB BB 00 02         [24] 1246 	cjne	r3,#0x00,00136$
      0086CE 80 05            [24] 1247 	sjmp	00109$
      0086D0                       1248 00136$:
      0086D0                       1249 00108$:
      0086D0 75 2A 00         [24] 1250 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      0086D3 80 03            [24] 1251 	sjmp	00110$
      0086D5                       1252 00109$:
      0086D5 75 2A 01         [24] 1253 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      0086D8                       1254 00110$:
                                   1255 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      0086D8 74 06            [12] 1256 	mov	a,#0x06
      0086DA 12 37 F1         [24] 1257 	lcall	_ak820_outline_0031
      0086DD 12 50 0E         [24] 1258 	lcall	_ak820_outline_0166
      0086E0 12 38 55         [24] 1259 	lcall	_ak820_outline_0117
      0086E3 F0               [24] 1260 	movx	@dptr,a
      0086E4 A3               [24] 1261 	inc	dptr
      0086E5 F0               [24] 1262 	movx	@dptr,a
                                   1263 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      0086E6 E5 2A            [12] 1264 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      0086E8 60 12            [24] 1265 	jz	00103$
      0086EA 12 43 89         [24] 1266 	lcall	_ak820_outline_0116
      0086ED C0 07            [24] 1267 	push	ar7
      0086EF C0 06            [24] 1268 	push	ar6
      0086F1 12 34 68         [24] 1269 	lcall	_ak820_combo_valid
      0086F4 E5 82            [12] 1270 	mov	a, dpl
      0086F6 D0 06            [24] 1271 	pop	ar6
      0086F8 D0 07            [24] 1272 	pop	ar7
      0086FA 70 17            [24] 1273 	jnz	00104$
      0086FC                       1274 00103$:
      0086FC 7D 00            [12] 1275 	mov	r5,#0x00
      0086FE 90 0D 81         [24] 1276 	mov	dptr,#_memset_PARM_2
      008701 E4               [12] 1277 	clr	a
      008702 F0               [24] 1278 	movx	@dptr,a
      008703 90 0D 82         [24] 1279 	mov	dptr,#_memset_PARM_3
      008706 74 0A            [12] 1280 	mov	a,#0x0a
      008708 F0               [24] 1281 	movx	@dptr,a
      008709 E4               [12] 1282 	clr	a
      00870A A3               [24] 1283 	inc	dptr
      00870B 12 43 64         [24] 1284 	lcall	_ak820_outline_0061
      00870E 8D F0            [24] 1285 	mov	b, r5
      008710 12 B8 56         [24] 1286 	lcall	_memset
      008713                       1287 00104$:
                                   1288 ;	quantum/dynamic_keymap.c:329: return 0;
      008713 90 00 00         [24] 1289 	mov	dptr,#0x0000
                                   1290 ;	quantum/dynamic_keymap.c:330: }
      008716 22               [24] 1291 	ret
                                   1292 ;------------------------------------------------------------
                                   1293 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1294 ;------------------------------------------------------------
                                   1295 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1296 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_390'
                                   1297 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_391'
                                   1298 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_394'
                                   1299 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_395'
                                   1300 ;------------------------------------------------------------
                                   1301 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1302 ;	-----------------------------------------
                                   1303 ;	 function dynamic_keymap_set_combo
                                   1304 ;	-----------------------------------------
      008717                       1305 _dynamic_keymap_set_combo:
      008717 E5 82            [12] 1306 	mov	a,dpl
      008719 90 0A F3         [24] 1307 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      00871C F0               [24] 1308 	movx	@dptr,a
                                   1309 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      00871D 90 0A F0         [24] 1310 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008720 12 37 A1         [24] 1311 	lcall	_ak820_outline_0004
                                   1312 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008723 C0 07            [24] 1313 	push	ar7
      008725 C0 06            [24] 1314 	push	ar6
      008727 12 34 68         [24] 1315 	lcall	_ak820_combo_valid
      00872A E5 82            [12] 1316 	mov	a, dpl
      00872C D0 06            [24] 1317 	pop	ar6
      00872E D0 07            [24] 1318 	pop	ar7
      008730 60 07            [24] 1319 	jz	00101$
      008732 12 3E 48         [24] 1320 	lcall	_ak820_nvm_ok
      008735 E5 82            [12] 1321 	mov	a, dpl
      008737 70 04            [24] 1322 	jnz	00102$
      008739                       1323 00101$:
      008739 90 FF FF         [24] 1324 	mov	dptr,#0xffff
      00873C 22               [24] 1325 	ret
      00873D                       1326 00102$:
                                   1327 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      00873D 90 0A F3         [24] 1328 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      008740 E0               [24] 1329 	movx	a,@dptr
      008741 FD               [12] 1330 	mov	r5,a
      008742 BD 08 00         [24] 1331 	cjne	r5,#0x08,00133$
      008745                       1332 00133$:
      008745 40 04            [24] 1333 	jc	00105$
                                   1334 ;	quantum/dynamic_keymap.c:342: return -1;
      008747 90 FF FF         [24] 1335 	mov	dptr,#0xffff
      00874A 22               [24] 1336 	ret
      00874B                       1337 00105$:
                                   1338 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00874B 12 8F 3E         [24] 1339 	lcall	_ak820_outline_0079
                                   1340 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      00874E C0 07            [24] 1341 	push	ar7
      008750 C0 06            [24] 1342 	push	ar6
      008752 C0 05            [24] 1343 	push	ar5
      008754 C0 04            [24] 1344 	push	ar4
      008756 12 77 C7         [24] 1345 	lcall	_clear_keyboard
      008759 D0 04            [24] 1346 	pop	ar4
      00875B D0 05            [24] 1347 	pop	ar5
      00875D D0 06            [24] 1348 	pop	ar6
      00875F D0 07            [24] 1349 	pop	ar7
                                   1350 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008761 90 0D 79         [24] 1351 	mov	dptr,#___memcpy_PARM_2
      008764 12 49 6F         [24] 1352 	lcall	_ak820_outline_0059
      008767 E4               [12] 1353 	clr	a
      008768 A3               [24] 1354 	inc	dptr
      008769 F0               [24] 1355 	movx	@dptr,a
      00876A 90 0D 7C         [24] 1356 	mov	dptr,#___memcpy_PARM_3
      00876D 74 0A            [12] 1357 	mov	a,#0x0a
      00876F 12 38 60         [24] 1358 	lcall	_ak820_outline_0123
      008772 90 0A F4         [24] 1359 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008775 F5 F0            [12] 1360 	mov	b,a
      008777 C0 05            [24] 1361 	push	ar5
      008779 C0 04            [24] 1362 	push	ar4
      00877B 12 B7 E0         [24] 1363 	lcall	___memcpy
      00877E D0 04            [24] 1364 	pop	ar4
      008780 D0 05            [24] 1365 	pop	ar5
                                   1366 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008782 90 0A F8         [24] 1367 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0004)
      008785 74 20            [12] 1368 	mov	a,#0x20
      008787 F0               [24] 1369 	movx	@dptr,a
      008788 74 08            [12] 1370 	mov	a,#0x08
      00878A A3               [24] 1371 	inc	dptr
      00878B F0               [24] 1372 	movx	@dptr,a
                                   1373 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      00878C 90 0A FA         [24] 1374 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0006)
      00878F 74 01            [12] 1375 	mov	a,#0x01
      008791 12 38 60         [24] 1376 	lcall	_ak820_outline_0123
                                   1377 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008794 90 05 8A         [24] 1378 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008797 12 38 26         [24] 1379 	lcall	_ak820_outline_0071
      00879A E4               [12] 1380 	clr	a
      00879B A3               [24] 1381 	inc	dptr
      00879C F0               [24] 1382 	movx	@dptr,a
      00879D 90 05 8D         [24] 1383 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0087A0 74 0A            [12] 1384 	mov	a,#0x0a
      0087A2 12 38 60         [24] 1385 	lcall	_ak820_outline_0123
      0087A5 90 0A F4         [24] 1386 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      0087A8 12 41 68         [24] 1387 	lcall	_ak820_eeprom_write_block_xdata
                                   1388 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      0087AB 12 3E 57         [24] 1389 	lcall	_ak820_nvm_flush
                                   1390 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      0087AE 12 3E 48         [24] 1391 	lcall	_ak820_nvm_ok
      0087B1 E5 82            [12] 1392 	mov	a, dpl
      0087B3 70 04            [24] 1393 	jnz	00107$
      0087B5 90 FF FF         [24] 1394 	mov	dptr,#0xffff
      0087B8 22               [24] 1395 	ret
      0087B9                       1396 00107$:
                                   1397 ;	quantum/dynamic_keymap.c:360: return 0;
      0087B9 90 00 00         [24] 1398 	mov	dptr,#0x0000
                                   1399 ;	quantum/dynamic_keymap.c:361: }
      0087BC 22               [24] 1400 	ret
                                   1401 ;------------------------------------------------------------
                                   1402 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1403 ;------------------------------------------------------------
                                   1404 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_398'
                                   1405 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_399'
                                   1406 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_401'
                                   1407 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_403'
                                   1408 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_405'
                                   1409 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_407'
                                   1410 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_408'
                                   1411 ;------------------------------------------------------------
                                   1412 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1413 ;	-----------------------------------------
                                   1414 ;	 function dynamic_keymap_reset
                                   1415 ;	-----------------------------------------
      0087BD                       1416 _dynamic_keymap_reset:
                                   1417 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      0087BD 90 0D F9         [24] 1418 	mov	dptr,#_vial_unlocked
      0087C0 E0               [24] 1419 	movx	a,@dptr
      0087C1 90 0A FE         [24] 1420 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      0087C4 F0               [24] 1421 	movx	@dptr,a
                                   1422 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      0087C5 90 0D F9         [24] 1423 	mov	dptr,#_vial_unlocked
      0087C8 74 01            [12] 1424 	mov	a,#0x01
      0087CA F0               [24] 1425 	movx	@dptr,a
                                   1426 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0087CB 7F 00            [12] 1427 	mov	r7,#0x00
      0087CD                       1428 00116$:
      0087CD BF 06 00         [24] 1429 	cjne	r7,#0x06,00198$
      0087D0                       1430 00198$:
      0087D0 40 03            [24] 1431 	jc	00199$
      0087D2 02 88 80         [24] 1432 	ljmp	00104$
      0087D5                       1433 00199$:
                                   1434 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0087D5 7E 00            [12] 1435 	mov	r6,#0x00
      0087D7                       1436 00110$:
      0087D7 BE 10 00         [24] 1437 	cjne	r6,#0x10,00200$
      0087DA                       1438 00200$:
      0087DA 50 4D            [24] 1439 	jnc	00102$
                                   1440 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0087DC 7D 00            [12] 1441 	mov	r5,#0x00
      0087DE                       1442 00107$:
      0087DE BD 08 00         [24] 1443 	cjne	r5,#0x08,00202$
      0087E1                       1444 00202$:
      0087E1 50 43            [24] 1445 	jnc	00111$
                                   1446 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      0087E3 90 0B 9A         [24] 1447 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      0087E6 EE               [12] 1448 	mov	a,r6
      0087E7 F0               [24] 1449 	movx	@dptr,a
      0087E8 90 0B 9B         [24] 1450 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      0087EB ED               [12] 1451 	mov	a,r5
      0087EC F0               [24] 1452 	movx	@dptr,a
      0087ED 8F 82            [24] 1453 	mov	dpl, r7
      0087EF C0 07            [24] 1454 	push	ar7
      0087F1 C0 06            [24] 1455 	push	ar6
      0087F3 C0 05            [24] 1456 	push	ar5
      0087F5 12 97 84         [24] 1457 	lcall	_keycode_at_keymap_location_raw
      0087F8 AB 82            [24] 1458 	mov	r3, dpl
      0087FA AC 83            [24] 1459 	mov	r4, dph
      0087FC D0 05            [24] 1460 	pop	ar5
      0087FE D0 06            [24] 1461 	pop	ar6
      008800 D0 07            [24] 1462 	pop	ar7
      008802 90 0A DD         [24] 1463 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008805 EE               [12] 1464 	mov	a,r6
      008806 F0               [24] 1465 	movx	@dptr,a
      008807 90 0A DE         [24] 1466 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00880A ED               [12] 1467 	mov	a,r5
      00880B F0               [24] 1468 	movx	@dptr,a
      00880C 90 0A DF         [24] 1469 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00880F 12 38 2C         [24] 1470 	lcall	_ak820_outline_0077
      008812 8F 82            [24] 1471 	mov	dpl, r7
      008814 C0 07            [24] 1472 	push	ar7
      008816 C0 06            [24] 1473 	push	ar6
      008818 C0 05            [24] 1474 	push	ar5
      00881A 12 85 28         [24] 1475 	lcall	_dynamic_keymap_set_keycode
      00881D D0 05            [24] 1476 	pop	ar5
      00881F D0 06            [24] 1477 	pop	ar6
      008821 D0 07            [24] 1478 	pop	ar7
                                   1479 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008823 0D               [12] 1480 	inc	r5
      008824 80 B8            [24] 1481 	sjmp	00107$
      008826                       1482 00111$:
                                   1483 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008826 0E               [12] 1484 	inc	r6
      008827 80 AE            [24] 1485 	sjmp	00110$
      008829                       1486 00102$:
                                   1487 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008829 7E 00            [12] 1488 	mov	r6,#0x00
      00882B                       1489 00113$:
      00882B BE 01 00         [24] 1490 	cjne	r6,#0x01,00204$
      00882E                       1491 00204$:
      00882E 50 4C            [24] 1492 	jnc	00117$
                                   1493 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008830 12 8F 8D         [24] 1494 	lcall	_ak820_outline_0175
      008833 04               [12] 1495 	inc	a
      008834 F0               [24] 1496 	movx	@dptr,a
      008835 8F 82            [24] 1497 	mov	dpl, r7
      008837 C0 07            [24] 1498 	push	ar7
      008839 12 97 C9         [24] 1499 	lcall	_keycode_at_encodermap_location_raw
      00883C 12 43 AA         [24] 1500 	lcall	_ak820_outline_0145
      00883F D0 07            [24] 1501 	pop	ar7
      008841 12 8F 84         [24] 1502 	lcall	_ak820_outline_0174
      008844 04               [12] 1503 	inc	a
      008845 F0               [24] 1504 	movx	@dptr,a
      008846 90 0A E9         [24] 1505 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008849 12 38 26         [24] 1506 	lcall	_ak820_outline_0071
      00884C 8F 82            [24] 1507 	mov	dpl, r7
      00884E C0 07            [24] 1508 	push	ar7
      008850 12 86 03         [24] 1509 	lcall	_dynamic_keymap_set_encoder
      008853 D0 07            [24] 1510 	pop	ar7
                                   1511 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008855 12 8F 8D         [24] 1512 	lcall	_ak820_outline_0175
      008858 F0               [24] 1513 	movx	@dptr,a
      008859 8F 82            [24] 1514 	mov	dpl, r7
      00885B C0 07            [24] 1515 	push	ar7
      00885D 12 97 C9         [24] 1516 	lcall	_keycode_at_encodermap_location_raw
      008860 12 43 AA         [24] 1517 	lcall	_ak820_outline_0145
      008863 D0 07            [24] 1518 	pop	ar7
      008865 12 8F 84         [24] 1519 	lcall	_ak820_outline_0174
      008868 F0               [24] 1520 	movx	@dptr,a
      008869 90 0A E9         [24] 1521 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00886C 12 38 26         [24] 1522 	lcall	_ak820_outline_0071
      00886F 8F 82            [24] 1523 	mov	dpl, r7
      008871 C0 07            [24] 1524 	push	ar7
      008873 12 86 03         [24] 1525 	lcall	_dynamic_keymap_set_encoder
      008876 D0 07            [24] 1526 	pop	ar7
                                   1527 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008878 7E 01            [12] 1528 	mov	r6,#0x01
      00887A 80 AF            [24] 1529 	sjmp	00113$
      00887C                       1530 00117$:
                                   1531 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      00887C 0F               [12] 1532 	inc	r7
      00887D 02 87 CD         [24] 1533 	ljmp	00116$
      008880                       1534 00104$:
                                   1535 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008880 90 0A FF         [24] 1536 	mov	dptr,#_dynamic_keymap_reset_combo_10001_407
      008883 12 50 0E         [24] 1537 	lcall	_ak820_outline_0166
      008886 90 0B 01         [24] 1538 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0002)
      008889 F0               [24] 1539 	movx	@dptr,a
      00888A A3               [24] 1540 	inc	dptr
      00888B F0               [24] 1541 	movx	@dptr,a
      00888C 90 0B 03         [24] 1542 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0004)
      00888F F0               [24] 1543 	movx	@dptr,a
      008890 A3               [24] 1544 	inc	dptr
      008891 F0               [24] 1545 	movx	@dptr,a
      008892 90 0B 05         [24] 1546 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0006)
      008895 F0               [24] 1547 	movx	@dptr,a
      008896 A3               [24] 1548 	inc	dptr
      008897 F0               [24] 1549 	movx	@dptr,a
      008898 90 0B 07         [24] 1550 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0008)
      00889B F0               [24] 1551 	movx	@dptr,a
      00889C A3               [24] 1552 	inc	dptr
      00889D F0               [24] 1553 	movx	@dptr,a
                                   1554 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      00889E FF               [12] 1555 	mov	r7,a
      00889F                       1556 00119$:
      00889F BF 08 00         [24] 1557 	cjne	r7,#0x08,00206$
      0088A2                       1558 00206$:
      0088A2 50 17            [24] 1559 	jnc	00105$
                                   1560 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      0088A4 90 0A F0         [24] 1561 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0088A7 74 FF            [12] 1562 	mov	a,#_dynamic_keymap_reset_combo_10001_407
      0088A9 F0               [24] 1563 	movx	@dptr,a
      0088AA 74 0A            [12] 1564 	mov	a,#(_dynamic_keymap_reset_combo_10001_407 >> 8)
      0088AC 12 38 32         [24] 1565 	lcall	_ak820_outline_0097
      0088AF 8F 82            [24] 1566 	mov	dpl, r7
      0088B1 C0 07            [24] 1567 	push	ar7
      0088B3 12 87 17         [24] 1568 	lcall	_dynamic_keymap_set_combo
      0088B6 D0 07            [24] 1569 	pop	ar7
                                   1570 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0088B8 0F               [12] 1571 	inc	r7
      0088B9 80 E4            [24] 1572 	sjmp	00119$
      0088BB                       1573 00105$:
                                   1574 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      0088BB 90 0A FE         [24] 1575 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      0088BE E0               [24] 1576 	movx	a,@dptr
      0088BF 90 0D F9         [24] 1577 	mov	dptr,#_vial_unlocked
      0088C2 F0               [24] 1578 	movx	@dptr,a
                                   1579 ;	quantum/dynamic_keymap.c:468: }
      0088C3 22               [24] 1580 	ret
                                   1581 ;------------------------------------------------------------
                                   1582 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1583 ;------------------------------------------------------------
                                   1584 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1585 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1586 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1587 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1588 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1589 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_409'
                                   1590 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_410'
                                   1591 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_410'
                                   1592 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_413'
                                   1593 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_415'
                                   1594 ;------------------------------------------------------------
                                   1595 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1596 ;	-----------------------------------------
                                   1597 ;	 function ak820_dynamic_read_buffer
                                   1598 ;	-----------------------------------------
      0088C4                       1599 _ak820_dynamic_read_buffer:
      0088C4 12 38 44         [24] 1600 	lcall	_ak820_outline_0103
      0088C7 90 0B 12         [24] 1601 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      0088CA 12 38 49         [24] 1602 	lcall	_ak820_outline_0104
                                   1603 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0088CD 90 0B 0F         [24] 1604 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0088D0 12 38 01         [24] 1605 	lcall	_ak820_outline_0051
                                   1606 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      0088D3 90 0B 14         [24] 1607 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      0088D6 E4               [12] 1608 	clr	a
      0088D7 F0               [24] 1609 	movx	@dptr,a
                                   1610 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      0088D8 90 0B 0D         [24] 1611 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0088DB 12 38 20         [24] 1612 	lcall	_ak820_outline_0060
      0088DE 8C 02            [24] 1613 	mov	ar2,r4
      0088E0 8D 03            [24] 1614 	mov	ar3,r5
      0088E2 C3               [12] 1615 	clr	c
      0088E3 74 1C            [12] 1616 	mov	a,#0x1c
      0088E5 9A               [12] 1617 	subb	a,r2
      0088E6 E4               [12] 1618 	clr	a
      0088E7 9B               [12] 1619 	subb	a,r3
      0088E8 50 01            [24] 1620 	jnc	00102$
                                   1621 ;	free result
      0088EA 22               [24] 1622 	ret
      0088EB                       1623 00102$:
                                   1624 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      0088EB 90 0B 0B         [24] 1625 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0088EE 12 43 8E         [24] 1626 	lcall	_ak820_outline_0120
      0088F1 90 0B 09         [24] 1627 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0088F4 12 38 3E         [24] 1628 	lcall	_ak820_outline_0100
      0088F7 C3               [12] 1629 	clr	c
      0088F8 EA               [12] 1630 	mov	a,r2
      0088F9 98               [12] 1631 	subb	a,r0
      0088FA EB               [12] 1632 	mov	a,r3
      0088FB 99               [12] 1633 	subb	a,r1
      0088FC 50 17            [24] 1634 	jnc	00104$
                                   1635 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      0088FE E8               [12] 1636 	mov	a,r0
      0088FF C3               [12] 1637 	clr	c
      008900 9A               [12] 1638 	subb	a,r2
      008901 F8               [12] 1639 	mov	r0,a
      008902 E9               [12] 1640 	mov	a,r1
      008903 9B               [12] 1641 	subb	a,r3
      008904 F9               [12] 1642 	mov	r1,a
                                   1643 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008905 C3               [12] 1644 	clr	c
      008906 E8               [12] 1645 	mov	a,r0
      008907 9C               [12] 1646 	subb	a,r4
      008908 E9               [12] 1647 	mov	a,r1
      008909 9D               [12] 1648 	subb	a,r5
      00890A 40 04            [24] 1649 	jc	00114$
      00890C 8C 00            [24] 1650 	mov	ar0,r4
      00890E 8D 01            [24] 1651 	mov	ar1,r5
      008910                       1652 00114$:
      008910 90 0B 14         [24] 1653 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008913 E8               [12] 1654 	mov	a,r0
      008914 F0               [24] 1655 	movx	@dptr,a
      008915                       1656 00104$:
                                   1657 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008915 90 0B 14         [24] 1658 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008918 E0               [24] 1659 	movx	a,@dptr
      008919 F5 2B            [12] 1660 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      00891B E0               [24] 1661 	movx	a,@dptr
      00891C 60 42            [24] 1662 	jz	00106$
      00891E C0 04            [24] 1663 	push	ar4
      008920 C0 05            [24] 1664 	push	ar5
      008922 8E 00            [24] 1665 	mov	ar0,r6
      008924 8F 05            [24] 1666 	mov	ar5,r7
      008926 90 0B 12         [24] 1667 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      008929 E0               [24] 1668 	movx	a,@dptr
      00892A F9               [12] 1669 	mov	r1,a
      00892B A3               [24] 1670 	inc	dptr
      00892C E0               [24] 1671 	movx	a,@dptr
      00892D FC               [12] 1672 	mov	r4,a
      00892E EA               [12] 1673 	mov	a,r2
      00892F 29               [12] 1674 	add	a, r1
      008930 FA               [12] 1675 	mov	r2,a
      008931 EB               [12] 1676 	mov	a,r3
      008932 3C               [12] 1677 	addc	a, r4
      008933 FB               [12] 1678 	mov	r3,a
      008934 90 05 81         [24] 1679 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008937 EA               [12] 1680 	mov	a,r2
      008938 F0               [24] 1681 	movx	@dptr,a
      008939 EB               [12] 1682 	mov	a,r3
      00893A 12 38 32         [24] 1683 	lcall	_ak820_outline_0097
      00893D 90 05 84         [24] 1684 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008940 E5 2B            [12] 1685 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008942 12 38 60         [24] 1686 	lcall	_ak820_outline_0123
      008945 88 82            [24] 1687 	mov	dpl, r0
      008947 8D 83            [24] 1688 	mov	dph, r5
      008949 C0 07            [24] 1689 	push	ar7
      00894B C0 06            [24] 1690 	push	ar6
      00894D C0 05            [24] 1691 	push	ar5
      00894F C0 04            [24] 1692 	push	ar4
      008951 12 40 DC         [24] 1693 	lcall	_ak820_eeprom_read_block_xdata
      008954 D0 04            [24] 1694 	pop	ar4
      008956 D0 05            [24] 1695 	pop	ar5
      008958 D0 06            [24] 1696 	pop	ar6
      00895A D0 07            [24] 1697 	pop	ar7
                                   1698 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      00895C D0 05            [24] 1699 	pop	ar5
      00895E D0 04            [24] 1700 	pop	ar4
                                   1701 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008960                       1702 00106$:
                                   1703 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008960 90 0B 14         [24] 1704 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008963 E0               [24] 1705 	movx	a,@dptr
      008964 FB               [12] 1706 	mov	r3,a
      008965                       1707 00109$:
      008965 8B 01            [24] 1708 	mov	ar1,r3
      008967 7A 00            [12] 1709 	mov	r2,#0x00
      008969 C3               [12] 1710 	clr	c
      00896A E9               [12] 1711 	mov	a,r1
      00896B 9C               [12] 1712 	subb	a,r4
      00896C EA               [12] 1713 	mov	a,r2
      00896D 9D               [12] 1714 	subb	a,r5
      00896E 50 09            [24] 1715 	jnc	00111$
      008970 EB               [12] 1716 	mov	a,r3
      008971 12 37 F1         [24] 1717 	lcall	_ak820_outline_0031
      008974 E4               [12] 1718 	clr	a
      008975 F0               [24] 1719 	movx	@dptr,a
      008976 0B               [12] 1720 	inc	r3
      008977 80 EC            [24] 1721 	sjmp	00109$
      008979                       1722 00111$:
                                   1723 ;	quantum/dynamic_keymap.c:483: }
      008979 22               [24] 1724 	ret
                                   1725 ;------------------------------------------------------------
                                   1726 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1727 ;------------------------------------------------------------
                                   1728 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1729 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1730 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_416'
                                   1731 ;------------------------------------------------------------
                                   1732 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1733 ;	-----------------------------------------
                                   1734 ;	 function dynamic_keymap_get_buffer
                                   1735 ;	-----------------------------------------
      00897A                       1736 _dynamic_keymap_get_buffer:
      00897A 12 38 44         [24] 1737 	lcall	_ak820_outline_0103
      00897D 90 0B 1A         [24] 1738 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008980 12 38 49         [24] 1739 	lcall	_ak820_outline_0104
                                   1740 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008983 90 0B 1A         [24] 1741 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008986 12 38 01         [24] 1742 	lcall	_ak820_outline_0051
      008989 90 0B 15         [24] 1743 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00898C 12 38 20         [24] 1744 	lcall	_ak820_outline_0060
      00898F 90 0B 17         [24] 1745 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008992 12 4F EE         [24] 1746 	lcall	_ak820_outline_0088
      008995 90 0B 09         [24] 1747 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008998 E4               [12] 1748 	clr	a
      008999 F0               [24] 1749 	movx	@dptr,a
      00899A 74 06            [12] 1750 	mov	a,#0x06
      00899C A3               [24] 1751 	inc	dptr
      00899D F0               [24] 1752 	movx	@dptr,a
      00899E 90 0B 0B         [24] 1753 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0089A1 12 49 6F         [24] 1754 	lcall	_ak820_outline_0059
      0089A4 90 0B 0D         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0089A7 12 38 26         [24] 1756 	lcall	_ak820_outline_0071
      0089AA 90 0B 0F         [24] 1757 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0089AD E9               [12] 1758 	mov	a,r1
      0089AE 12 50 07         [24] 1759 	lcall	_ak820_outline_0151
      0089B1 F0               [24] 1760 	movx	@dptr,a
      0089B2 90 00 40         [24] 1761 	mov	dptr,#0x0040
                                   1762 ;	quantum/dynamic_keymap.c:511: }
      0089B5 02 88 C4         [24] 1763 	ljmp	_ak820_dynamic_read_buffer
                                   1764 ;------------------------------------------------------------
                                   1765 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1766 ;------------------------------------------------------------
                                   1767 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1768 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1769 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1770 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1771 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1772 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_418'
                                   1773 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_419'
                                   1774 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_419'
                                   1775 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_419'
                                   1776 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_422'
                                   1777 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_425'
                                   1778 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_425'
                                   1779 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_427'
                                   1780 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_430'
                                   1781 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_432'
                                   1782 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_433'
                                   1783 ;------------------------------------------------------------
                                   1784 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1785 ;	-----------------------------------------
                                   1786 ;	 function dynamic_keymap_set_buffer
                                   1787 ;	-----------------------------------------
      0089B8                       1788 _dynamic_keymap_set_buffer:
      0089B8 12 38 44         [24] 1789 	lcall	_ak820_outline_0103
      0089BB 90 0B 21         [24] 1790 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      0089BE 12 38 49         [24] 1791 	lcall	_ak820_outline_0104
                                   1792 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      0089C1 90 0B 21         [24] 1793 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      0089C4 12 37 CC         [24] 1794 	lcall	_ak820_outline_0010
      0089C7 74 40            [12] 1795 	mov	a,#0x40
      0089C9 2C               [12] 1796 	add	a, r4
      0089CA FA               [12] 1797 	mov	r2,a
      0089CB E4               [12] 1798 	clr	a
      0089CC 3D               [12] 1799 	addc	a, r5
      0089CD FB               [12] 1800 	mov	r3,a
                                   1801 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0089CE 90 0B 1E         [24] 1802 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      0089D1 12 38 3E         [24] 1803 	lcall	_ak820_outline_0100
                                   1804 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      0089D4 90 0B 1C         [24] 1805 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      0089D7 E0               [24] 1806 	movx	a,@dptr
      0089D8 F5 2C            [12] 1807 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      0089DA A3               [24] 1808 	inc	dptr
      0089DB E0               [24] 1809 	movx	a,@dptr
      0089DC F5 2D            [12] 1810 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      0089DE E5 2C            [12] 1811 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0089E0 45 2D            [12] 1812 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0089E2 70 01            [24] 1813 	jnz	00102$
      0089E4 22               [24] 1814 	ret
      0089E5                       1815 00102$:
                                   1816 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      0089E5 85 2C 2E         [24] 1817 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      0089E8 85 2D 2F         [24] 1818 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0089EB C3               [12] 1819 	clr	c
      0089EC 74 1C            [12] 1820 	mov	a,#0x1c
      0089EE 95 2E            [12] 1821 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      0089F0 E4               [12] 1822 	clr	a
      0089F1 95 2F            [12] 1823 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      0089F3 50 01            [24] 1824 	jnc	00104$
                                   1825 ;	free result
      0089F5 22               [24] 1826 	ret
      0089F6                       1827 00104$:
                                   1828 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      0089F6 85 2C 30         [24] 1829 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1830 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      0089F9 74 FA            [12] 1831 	mov	a,#0x100 - 0x06
      0089FB 2F               [12] 1832 	add	a,r7
      0089FC 40 11            [24] 1833 	jc	00105$
      0089FE E4               [12] 1834 	clr	a
      0089FF C3               [12] 1835 	clr	c
      008A00 9E               [12] 1836 	subb	a,r6
      008A01 FE               [12] 1837 	mov	r6,a
      008A02 74 06            [12] 1838 	mov	a,#0x06
      008A04 9F               [12] 1839 	subb	a,r7
      008A05 FF               [12] 1840 	mov	r7,a
      008A06 C3               [12] 1841 	clr	c
      008A07 EE               [12] 1842 	mov	a,r6
      008A08 95 2C            [12] 1843 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008A0A EF               [12] 1844 	mov	a,r7
      008A0B 95 2D            [12] 1845 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008A0D 50 01            [24] 1846 	jnc	00106$
      008A0F                       1847 00105$:
                                   1848 ;	quantum/dynamic_keymap.c:529: return;
      008A0F 22               [24] 1849 	ret
      008A10                       1850 00106$:
                                   1851 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008A10 90 0D F9         [24] 1852 	mov	dptr,#_vial_unlocked
      008A13 E0               [24] 1853 	movx	a,@dptr
      008A14 60 03            [24] 1854 	jz	00207$
      008A16 02 8B 25         [24] 1855 	ljmp	00120$
      008A19                       1856 00207$:
                                   1857 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008A19 90 0B 23         [24] 1858 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008A1C E4               [12] 1859 	clr	a
      008A1D F0               [24] 1860 	movx	@dptr,a
                                   1861 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008A1E 90 0B 24         [24] 1862 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008A21 E5 30            [12] 1863 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008A23 F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008A24 EC               [12] 1866 	mov	a,r4
      008A25 30 E0 33         [24] 1867 	jnb	acc.0,00111$
                                   1868 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008A28 EA               [12] 1869 	mov	a,r2
      008A29 24 FF            [12] 1870 	add	a,#0xff
      008A2B FE               [12] 1871 	mov	r6,a
      008A2C EB               [12] 1872 	mov	a,r3
      008A2D 34 FF            [12] 1873 	addc	a,#0xff
      008A2F FF               [12] 1874 	mov	r7,a
      008A30 7D 00            [12] 1875 	mov	r5,#0x00
      008A32 12 43 89         [24] 1876 	lcall	_ak820_outline_0116
      008A35 8D F0            [24] 1877 	mov	b, r5
      008A37 12 40 A1         [24] 1878 	lcall	_eeprom_read_byte
      008A3A AE 82            [24] 1879 	mov	r6,dpl
      008A3C 7F 00            [12] 1880 	mov	r7,#0x00
      008A3E 12 38 70         [24] 1881 	lcall	_ak820_outline_0152
      008A41 E0               [24] 1882 	movx	a,@dptr
      008A42 7C 00            [12] 1883 	mov	r4,#0x00
      008A44 42 07            [12] 1884 	orl	ar7,a
      008A46 EC               [12] 1885 	mov	a,r4
      008A47 42 06            [12] 1886 	orl	ar6,a
                                   1887 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008A49 BF 00 09         [24] 1888 	cjne	r7,#0x00,00109$
      008A4C BE 7C 06         [24] 1889 	cjne	r6,#0x7c,00109$
                                   1890 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008A4F 12 38 70         [24] 1891 	lcall	_ak820_outline_0152
      008A52 74 FF            [12] 1892 	mov	a,#0xff
      008A54 F0               [24] 1893 	movx	@dptr,a
      008A55                       1894 00109$:
                                   1895 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008A55 90 0B 23         [24] 1896 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008A58 74 01            [12] 1897 	mov	a,#0x01
      008A5A F0               [24] 1898 	movx	@dptr,a
      008A5B                       1899 00111$:
                                   1900 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008A5B 90 0B 21         [24] 1901 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008A5E 12 38 01         [24] 1902 	lcall	_ak820_outline_0051
      008A61 E5 2C            [12] 1903 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008A63 2E               [12] 1904 	add	a, r6
      008A64 FE               [12] 1905 	mov	r6,a
      008A65 E5 2D            [12] 1906 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008A67 3F               [12] 1907 	addc	a, r7
      008A68 EE               [12] 1908 	mov	a,r6
      008A69 30 E0 5A         [24] 1909 	jnb	acc.0,00115$
                                   1910 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008A6C AE 30            [24] 1911 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008A6E 7F 00            [12] 1912 	mov	r7,#0x00
      008A70 EE               [12] 1913 	mov	a,r6
      008A71 24 FF            [12] 1914 	add	a,#0xff
      008A73 FC               [12] 1915 	mov	r4,a
      008A74 EF               [12] 1916 	mov	a,r7
      008A75 34 FF            [12] 1917 	addc	a,#0xff
      008A77 FD               [12] 1918 	mov	r5,a
      008A78 EC               [12] 1919 	mov	a,r4
      008A79 28               [12] 1920 	add	a, r0
      008A7A F5 82            [12] 1921 	mov	dpl,a
      008A7C ED               [12] 1922 	mov	a,r5
      008A7D 39               [12] 1923 	addc	a, r1
      008A7E F5 83            [12] 1924 	mov	dph,a
      008A80 E0               [24] 1925 	movx	a,@dptr
      008A81 FC               [12] 1926 	mov	r4,a
      008A82 7D 00            [12] 1927 	mov	r5,#0x00
      008A84 E5 30            [12] 1928 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008A86 2A               [12] 1929 	add	a, r2
      008A87 FA               [12] 1930 	mov	r2,a
      008A88 E4               [12] 1931 	clr	a
      008A89 3B               [12] 1932 	addc	a, r3
      008A8A FB               [12] 1933 	mov	r3,a
      008A8B C0 00            [24] 1934 	push	ar0
      008A8D C0 01            [24] 1935 	push	ar1
      008A8F 8B 01            [24] 1936 	mov	ar1,r3
      008A91 7B 00            [12] 1937 	mov	r3,#0x00
      008A93 8A 82            [24] 1938 	mov	dpl, r2
      008A95 89 83            [24] 1939 	mov	dph, r1
      008A97 8B F0            [24] 1940 	mov	b, r3
      008A99 12 40 A1         [24] 1941 	lcall	_eeprom_read_byte
      008A9C AB 82            [24] 1942 	mov	r3, dpl
      008A9E 7A 00            [12] 1943 	mov	r2,#0x00
      008AA0 EB               [12] 1944 	mov	a,r3
      008AA1 12 43 9F         [24] 1945 	lcall	_ak820_outline_0139
                                   1946 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008AA4 BD 00 05         [24] 1947 	cjne	r5,#0x00,00212$
      008AA7 BC 7C 02         [24] 1948 	cjne	r4,#0x7c,00212$
      008AAA 80 06            [24] 1949 	sjmp	00213$
      008AAC                       1950 00212$:
      008AAC D0 01            [24] 1951 	pop	ar1
      008AAE D0 00            [24] 1952 	pop	ar0
      008AB0 80 0D            [24] 1953 	sjmp	00113$
      008AB2                       1954 00213$:
      008AB2 D0 01            [24] 1955 	pop	ar1
      008AB4 D0 00            [24] 1956 	pop	ar0
                                   1957 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008AB6 1E               [12] 1958 	dec	r6
      008AB7 BE FF 01         [24] 1959 	cjne	r6,#0xff,00214$
      008ABA 1F               [12] 1960 	dec	r7
      008ABB                       1961 00214$:
      008ABB EE               [12] 1962 	mov	a,r6
      008ABC 12 8F 66         [24] 1963 	lcall	_ak820_outline_0127
      008ABF                       1964 00113$:
                                   1965 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008ABF E5 30            [12] 1966 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008AC1 14               [12] 1967 	dec	a
      008AC2 90 0B 24         [24] 1968 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008AC5 F0               [24] 1969 	movx	@dptr,a
      008AC6                       1970 00115$:
                                   1971 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008AC6 90 0B 23         [24] 1972 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008AC9 E0               [24] 1973 	movx	a,@dptr
      008ACA 90 0B 25         [24] 1974 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008ACD F0               [24] 1975 	movx	@dptr,a
      008ACE                       1976 00122$:
      008ACE 90 0B 25         [24] 1977 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008AD1 E0               [24] 1978 	movx	a,@dptr
      008AD2 FF               [12] 1979 	mov	r7,a
      008AD3 90 0B 24         [24] 1980 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008AD6 E0               [24] 1981 	movx	a,@dptr
      008AD7 FE               [12] 1982 	mov	r6,a
      008AD8 C3               [12] 1983 	clr	c
      008AD9 EF               [12] 1984 	mov	a,r7
      008ADA 9E               [12] 1985 	subb	a,r6
      008ADB 50 48            [24] 1986 	jnc	00120$
                                   1987 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008ADD EF               [12] 1988 	mov	a,r7
      008ADE 28               [12] 1989 	add	a, r0
      008ADF FD               [12] 1990 	mov	r5,a
      008AE0 E4               [12] 1991 	clr	a
      008AE1 39               [12] 1992 	addc	a, r1
      008AE2 FE               [12] 1993 	mov	r6,a
      008AE3 12 49 75         [24] 1994 	lcall	_ak820_outline_0075
      008AE6 7B 00            [12] 1995 	mov	r3,#0x00
      008AE8 8C 2D            [24] 1996 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008AEA 8B 2C            [24] 1997 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008AEC 8F 02            [24] 1998 	mov	ar2,r7
      008AEE 7F 00            [12] 1999 	mov	r7,#0x00
      008AF0 74 01            [12] 2000 	mov	a,#0x01
      008AF2 2A               [12] 2001 	add	a, r2
      008AF3 FB               [12] 2002 	mov	r3,a
      008AF4 E4               [12] 2003 	clr	a
      008AF5 3F               [12] 2004 	addc	a, r7
      008AF6 FC               [12] 2005 	mov	r4,a
      008AF7 EB               [12] 2006 	mov	a,r3
      008AF8 28               [12] 2007 	add	a, r0
      008AF9 F5 82            [12] 2008 	mov	dpl,a
      008AFB EC               [12] 2009 	mov	a,r4
      008AFC 39               [12] 2010 	addc	a, r1
      008AFD F5 83            [12] 2011 	mov	dph,a
      008AFF E0               [24] 2012 	movx	a,@dptr
      008B00 FC               [12] 2013 	mov	r4,a
      008B01 7B 00            [12] 2014 	mov	r3,#0x00
      008B03 E5 2D            [12] 2015 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008B05 42 03            [12] 2016 	orl	ar3,a
                                   2017 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008B07 BC 00 12         [24] 2018 	cjne	r4,#0x00,00123$
      008B0A BB 7C 0F         [24] 2019 	cjne	r3,#0x7c,00123$
                                   2020 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008B0D 12 38 65         [24] 2021 	lcall	_ak820_outline_0132
      008B10 74 FF            [12] 2022 	mov	a,#0xff
      008B12 F0               [24] 2023 	movx	@dptr,a
                                   2024 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008B13 0A               [12] 2025 	inc	r2
      008B14 BA 00 01         [24] 2026 	cjne	r2,#0x00,00218$
      008B17 0F               [12] 2027 	inc	r7
      008B18                       2028 00218$:
      008B18 EA               [12] 2029 	mov	a,r2
      008B19 12 8F 66         [24] 2030 	lcall	_ak820_outline_0127
      008B1C                       2031 00123$:
                                   2032 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008B1C 90 0B 25         [24] 2033 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008B1F E0               [24] 2034 	movx	a,@dptr
      008B20 24 02            [12] 2035 	add	a,#0x02
      008B22 F0               [24] 2036 	movx	@dptr,a
      008B23 80 A9            [24] 2037 	sjmp	00122$
      008B25                       2038 00120$:
                                   2039 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008B25 90 0B 21         [24] 2040 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008B28 12 38 01         [24] 2041 	lcall	_ak820_outline_0051
      008B2B 74 40            [12] 2042 	mov	a,#0x40
      008B2D 12 43 99         [24] 2043 	lcall	_ak820_outline_0134
      008B30 90 05 8A         [24] 2044 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008B33 12 49 6F         [24] 2045 	lcall	_ak820_outline_0059
      008B36 E4               [12] 2046 	clr	a
      008B37 A3               [24] 2047 	inc	dptr
      008B38 F0               [24] 2048 	movx	@dptr,a
      008B39 90 05 8D         [24] 2049 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008B3C E5 2E            [12] 2050 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008B3E F0               [24] 2051 	movx	@dptr,a
      008B3F E5 2F            [12] 2052 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008B41 A3               [24] 2053 	inc	dptr
      008B42 F0               [24] 2054 	movx	@dptr,a
      008B43 12 38 70         [24] 2055 	lcall	_ak820_outline_0152
                                   2056 ;	quantum/dynamic_keymap.c:584: }
      008B46 02 41 68         [24] 2057 	ljmp	_ak820_eeprom_write_block_xdata
                                   2058 ;------------------------------------------------------------
                                   2059 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2060 ;------------------------------------------------------------
                                   2061 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2062 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2063 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_436'
                                   2064 ;------------------------------------------------------------
                                   2065 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2066 ;	-----------------------------------------
                                   2067 ;	 function keycode_at_keymap_location
                                   2068 ;	-----------------------------------------
      008B49                       2069 _keycode_at_keymap_location:
      008B49 E5 82            [12] 2070 	mov	a,dpl
      008B4B 90 0B 28         [24] 2071 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_436
      008B4E F0               [24] 2072 	movx	@dptr,a
                                   2073 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008B4F E0               [24] 2074 	movx	a,@dptr
      008B50 FF               [12] 2075 	mov	r7,a
      008B51 BF 06 00         [24] 2076 	cjne	r7,#0x06,00128$
      008B54                       2077 00128$:
      008B54 50 23            [24] 2078 	jnc	00102$
      008B56 90 0B 26         [24] 2079 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008B59 E0               [24] 2080 	movx	a,@dptr
      008B5A FE               [12] 2081 	mov	r6,a
      008B5B BE 10 00         [24] 2082 	cjne	r6,#0x10,00130$
      008B5E                       2083 00130$:
      008B5E 50 19            [24] 2084 	jnc	00102$
      008B60 90 0B 27         [24] 2085 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008B63 E0               [24] 2086 	movx	a,@dptr
      008B64 FD               [12] 2087 	mov	r5,a
      008B65 BD 08 00         [24] 2088 	cjne	r5,#0x08,00132$
      008B68                       2089 00132$:
      008B68 50 0F            [24] 2090 	jnc	00102$
                                   2091 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008B6A 90 0A DA         [24] 2092 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008B6D EE               [12] 2093 	mov	a,r6
      008B6E F0               [24] 2094 	movx	@dptr,a
      008B6F 90 0A DB         [24] 2095 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008B72 ED               [12] 2096 	mov	a,r5
      008B73 F0               [24] 2097 	movx	@dptr,a
      008B74 8F 82            [24] 2098 	mov	dpl, r7
      008B76 02 84 DA         [24] 2099 	ljmp	_dynamic_keymap_get_keycode
      008B79                       2100 00102$:
                                   2101 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008B79 90 00 00         [24] 2102 	mov	dptr,#0x0000
                                   2103 ;	quantum/dynamic_keymap.c:591: }
      008B7C 22               [24] 2104 	ret
                                   2105 ;------------------------------------------------------------
                                   2106 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2107 ;------------------------------------------------------------
                                   2108 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2109 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2110 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_440'
                                   2111 ;------------------------------------------------------------
                                   2112 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2113 ;	-----------------------------------------
                                   2114 ;	 function keycode_at_encodermap_location
                                   2115 ;	-----------------------------------------
      008B7D                       2116 _keycode_at_encodermap_location:
      008B7D E5 82            [12] 2117 	mov	a,dpl
      008B7F 90 0B 2B         [24] 2118 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_440
      008B82 F0               [24] 2119 	movx	@dptr,a
                                   2120 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008B83 E0               [24] 2121 	movx	a,@dptr
      008B84 FF               [12] 2122 	mov	r7,a
      008B85 BF 06 00         [24] 2123 	cjne	r7,#0x06,00120$
      008B88                       2124 00120$:
      008B88 50 1E            [24] 2125 	jnc	00102$
      008B8A 90 0B 29         [24] 2126 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008B8D E0               [24] 2127 	movx	a,@dptr
      008B8E FE               [12] 2128 	mov	r6,a
      008B8F BE 01 00         [24] 2129 	cjne	r6,#0x01,00122$
      008B92                       2130 00122$:
      008B92 50 14            [24] 2131 	jnc	00102$
                                   2132 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008B94 90 0B 2A         [24] 2133 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008B97 E0               [24] 2134 	movx	a,@dptr
      008B98 FE               [12] 2135 	mov	r6,a
      008B99 90 0A E4         [24] 2136 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008B9C E4               [12] 2137 	clr	a
      008B9D F0               [24] 2138 	movx	@dptr,a
      008B9E 90 0A E5         [24] 2139 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008BA1 EE               [12] 2140 	mov	a,r6
      008BA2 F0               [24] 2141 	movx	@dptr,a
      008BA3 8F 82            [24] 2142 	mov	dpl, r7
      008BA5 02 85 9B         [24] 2143 	ljmp	_dynamic_keymap_get_encoder
      008BA8                       2144 00102$:
                                   2145 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008BA8 90 00 00         [24] 2146 	mov	dptr,#0x0000
                                   2147 ;	quantum/dynamic_keymap.c:599: }
      008BAB 22               [24] 2148 	ret
                                   2149 ;------------------------------------------------------------
                                   2150 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2151 ;------------------------------------------------------------
                                   2152 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2153 ;	-----------------------------------------
                                   2154 ;	 function dynamic_keymap_macro_get_count
                                   2155 ;	-----------------------------------------
      008BAC                       2156 _dynamic_keymap_macro_get_count:
                                   2157 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008BAC 75 82 10         [24] 2158 	mov	dpl, #0x10
                                   2159 ;	quantum/dynamic_keymap.c:604: }
      008BAF 22               [24] 2160 	ret
                                   2161 ;------------------------------------------------------------
                                   2162 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2163 ;------------------------------------------------------------
                                   2164 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2165 ;	-----------------------------------------
                                   2166 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2167 ;	-----------------------------------------
      008BB0                       2168 _dynamic_keymap_macro_get_buffer_size:
                                   2169 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008BB0 90 20 00         [24] 2170 	mov	dptr,#0x2000
                                   2171 ;	quantum/dynamic_keymap.c:608: }
      008BB3 22               [24] 2172 	ret
                                   2173 ;------------------------------------------------------------
                                   2174 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2175 ;------------------------------------------------------------
                                   2176 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2177 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2178 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2179 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_448'
                                   2180 ;------------------------------------------------------------
                                   2181 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2182 ;	-----------------------------------------
                                   2183 ;	 function dynamic_keymap_macro_get_buffer
                                   2184 ;	-----------------------------------------
      008BB4                       2185 _dynamic_keymap_macro_get_buffer:
      008BB4 12 38 44         [24] 2186 	lcall	_ak820_outline_0103
      008BB7 90 0B 31         [24] 2187 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      008BBA 12 38 49         [24] 2188 	lcall	_ak820_outline_0104
                                   2189 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008BBD 12 2A DF         [24] 2190 	lcall	_ak820_macro_length
      008BC0 12 43 94         [24] 2191 	lcall	_ak820_outline_0131
      008BC3 90 0B 31         [24] 2192 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      008BC6 12 38 20         [24] 2193 	lcall	_ak820_outline_0060
      008BC9 90 0B 2C         [24] 2194 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008BCC E0               [24] 2195 	movx	a,@dptr
      008BCD F5 31            [12] 2196 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008BCF A3               [24] 2197 	inc	dptr
      008BD0 E0               [24] 2198 	movx	a,@dptr
      008BD1 F5 32            [12] 2199 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008BD3 90 0B 2E         [24] 2200 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008BD6 12 38 3E         [24] 2201 	lcall	_ak820_outline_0100
      008BD9 A3               [24] 2202 	inc	dptr
      008BDA E0               [24] 2203 	movx	a,@dptr
      008BDB FB               [12] 2204 	mov	r3,a
      008BDC 90 0B 09         [24] 2205 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008BDF 12 49 6F         [24] 2206 	lcall	_ak820_outline_0059
      008BE2 90 0B 0B         [24] 2207 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008BE5 12 38 26         [24] 2208 	lcall	_ak820_outline_0071
      008BE8 90 0B 0D         [24] 2209 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008BEB E5 31            [12] 2210 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008BED F0               [24] 2211 	movx	@dptr,a
      008BEE E5 32            [12] 2212 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008BF0 A3               [24] 2213 	inc	dptr
      008BF1 F0               [24] 2214 	movx	@dptr,a
      008BF2 90 0B 0F         [24] 2215 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008BF5 E8               [12] 2216 	mov	a,r0
      008BF6 F0               [24] 2217 	movx	@dptr,a
      008BF7 E9               [12] 2218 	mov	a,r1
      008BF8 A3               [24] 2219 	inc	dptr
      008BF9 F0               [24] 2220 	movx	@dptr,a
      008BFA EB               [12] 2221 	mov	a,r3
      008BFB A3               [24] 2222 	inc	dptr
      008BFC F0               [24] 2223 	movx	@dptr,a
      008BFD 90 08 00         [24] 2224 	mov	dptr,#0x0800
                                   2225 ;	quantum/dynamic_keymap.c:635: }
      008C00 02 88 C4         [24] 2226 	ljmp	_ak820_dynamic_read_buffer
                                   2227 ;------------------------------------------------------------
                                   2228 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2229 ;------------------------------------------------------------
                                   2230 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2231 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2232 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_450'
                                   2233 ;------------------------------------------------------------
                                   2234 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2235 ;	-----------------------------------------
                                   2236 ;	 function dynamic_keymap_macro_set_buffer
                                   2237 ;	-----------------------------------------
      008C03                       2238 _dynamic_keymap_macro_set_buffer:
      008C03 12 38 44         [24] 2239 	lcall	_ak820_outline_0103
      008C06 90 0B 38         [24] 2240 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      008C09 12 38 49         [24] 2241 	lcall	_ak820_outline_0104
                                   2242 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      008C0C 90 0B 38         [24] 2243 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      008C0F 12 38 01         [24] 2244 	lcall	_ak820_outline_0051
      008C12 90 0B 33         [24] 2245 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008C15 12 38 20         [24] 2246 	lcall	_ak820_outline_0060
      008C18 90 0B 35         [24] 2247 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008C1B 12 4F EE         [24] 2248 	lcall	_ak820_outline_0088
      008C1E 90 05 10         [24] 2249 	mov	dptr,#_ak820_macro_write_PARM_2
      008C21 12 38 26         [24] 2250 	lcall	_ak820_outline_0071
      008C24 90 05 12         [24] 2251 	mov	dptr,#_ak820_macro_write_PARM_3
      008C27 E9               [12] 2252 	mov	a,r1
      008C28 12 50 07         [24] 2253 	lcall	_ak820_outline_0151
      008C2B 12 43 64         [24] 2254 	lcall	_ak820_outline_0061
                                   2255 ;	quantum/dynamic_keymap.c:640: }
      008C2E 02 2A F9         [24] 2256 	ljmp	_ak820_macro_write
                                   2257 ;------------------------------------------------------------
                                   2258 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2259 ;------------------------------------------------------------
                                   2260 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2261 ;	-----------------------------------------
                                   2262 ;	 function dynamic_keymap_macro_reset
                                   2263 ;	-----------------------------------------
      008C31                       2264 _dynamic_keymap_macro_reset:
                                   2265 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2266 ;	quantum/dynamic_keymap.c:666: }
      008C31 02 2E 18         [24] 2267 	ljmp	_ak820_macro_reset
                                   2268 ;------------------------------------------------------------
                                   2269 ;Allocation info for local variables in function 'decode_keycode'
                                   2270 ;------------------------------------------------------------
                                   2271 ;kc            Allocated with name '_decode_keycode_kc_10000_454'
                                   2272 ;------------------------------------------------------------
                                   2273 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2274 ;	-----------------------------------------
                                   2275 ;	 function decode_keycode
                                   2276 ;	-----------------------------------------
      008C34                       2277 _decode_keycode:
      008C34 12 38 44         [24] 2278 	lcall	_ak820_outline_0103
      008C37 90 0B 3A         [24] 2279 	mov	dptr,#_decode_keycode_kc_10000_454
      008C3A 12 38 49         [24] 2280 	lcall	_ak820_outline_0104
                                   2281 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      008C3D 90 0B 3A         [24] 2282 	mov	dptr,#_decode_keycode_kc_10000_454
      008C40 12 37 CC         [24] 2283 	lcall	_ak820_outline_0010
      008C43 C3               [12] 2284 	clr	c
      008C44 E4               [12] 2285 	clr	a
      008C45 9C               [12] 2286 	subb	a,r4
      008C46 74 FF            [12] 2287 	mov	a,#0xff
      008C48 9D               [12] 2288 	subb	a,r5
      008C49 50 08            [24] 2289 	jnc	00102$
                                   2290 ;	free result
                                   2291 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      008C4B 8C 05            [24] 2292 	mov	ar5,r4
      008C4D 7C 00            [12] 2293 	mov	r4,#0x00
      008C4F 12 38 55         [24] 2294 	lcall	_ak820_outline_0117
      008C52 22               [24] 2295 	ret
      008C53                       2296 00102$:
                                   2297 ;	quantum/dynamic_keymap.c:672: return kc;
      008C53 12 43 89         [24] 2298 	lcall	_ak820_outline_0116
                                   2299 ;	quantum/dynamic_keymap.c:673: }
      008C56 22               [24] 2300 	ret
                                   2301 ;------------------------------------------------------------
                                   2302 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2303 ;------------------------------------------------------------
                                   2304 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_457'
                                   2305 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_458'
                                   2306 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_463'
                                   2307 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_464'
                                   2308 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_470'
                                   2309 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_488'
                                   2310 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_492'
                                   2311 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_492'
                                   2312 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_494'
                                   2313 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_496'
                                   2314 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_500'
                                   2315 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_502'
                                   2316 ;------------------------------------------------------------
                                   2317 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2318 ;	-----------------------------------------
                                   2319 ;	 function dynamic_keymap_macro_send
                                   2320 ;	-----------------------------------------
      008C57                       2321 _dynamic_keymap_macro_send:
      008C57 E5 82            [12] 2322 	mov	a,dpl
      008C59 90 0B 3C         [24] 2323 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008C5C F0               [24] 2324 	movx	@dptr,a
                                   2325 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      008C5D 90 0B 3D         [24] 2326 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008C60 E0               [24] 2327 	movx	a,@dptr
      008C61 60 01            [24] 2328 	jz	00102$
      008C63 22               [24] 2329 	ret
      008C64                       2330 00102$:
                                   2331 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008C64 90 0B 3C         [24] 2332 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008C67 E0               [24] 2333 	movx	a,@dptr
      008C68 FF               [12] 2334 	mov	r7,a
      008C69 BF 10 00         [24] 2335 	cjne	r7,#0x10,00422$
      008C6C                       2336 00422$:
      008C6C 40 01            [24] 2337 	jc	00104$
                                   2338 ;	quantum/dynamic_keymap.c:683: return;
      008C6E 22               [24] 2339 	ret
      008C6F                       2340 00104$:
                                   2341 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      008C6F C0 07            [24] 2342 	push	ar7
      008C71 12 2A A6         [24] 2343 	lcall	_ak820_macro_ready
      008C74 E5 82            [12] 2344 	mov	a, dpl
      008C76 D0 07            [24] 2345 	pop	ar7
      008C78 70 01            [24] 2346 	jnz	00106$
      008C7A 22               [24] 2347 	ret
      008C7B                       2348 00106$:
                                   2349 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008C7B 90 0B 3E         [24] 2350 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008C7E E4               [12] 2351 	clr	a
      008C7F F0               [24] 2352 	movx	@dptr,a
      008C80 74 08            [12] 2353 	mov	a,#0x08
      008C82 A3               [24] 2354 	inc	dptr
      008C83 F0               [24] 2355 	movx	@dptr,a
                                   2356 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008C84 C0 07            [24] 2357 	push	ar7
      008C86 12 2A DF         [24] 2358 	lcall	_ak820_macro_length
      008C89 AD 82            [24] 2359 	mov	r5, dpl
      008C8B AE 83            [24] 2360 	mov	r6, dph
      008C8D D0 07            [24] 2361 	pop	ar7
      008C8F 74 08            [12] 2362 	mov	a,#0x08
      008C91 2E               [12] 2363 	add	a, r6
      008C92 FE               [12] 2364 	mov	r6,a
                                   2365 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      008C93 7B 00            [12] 2366 	mov	r3,#0x00
      008C95 7C 08            [12] 2367 	mov	r4,#0x08
      008C97                       2368 00111$:
      008C97 EF               [12] 2369 	mov	a,r7
      008C98 60 31            [24] 2370 	jz	00113$
                                   2371 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008C9A EB               [12] 2372 	mov	a,r3
      008C9B B5 05 05         [24] 2373 	cjne	a,ar5,00108$
      008C9E EC               [12] 2374 	mov	a,r4
      008C9F B5 06 01         [24] 2375 	cjne	a,ar6,00108$
                                   2376 ;	quantum/dynamic_keymap.c:717: return;
      008CA2 22               [24] 2377 	ret
      008CA3                       2378 00108$:
                                   2379 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008CA3 8B 01            [24] 2380 	mov	ar1,r3
      008CA5 8C 02            [24] 2381 	mov	ar2,r4
      008CA7 8A 00            [24] 2382 	mov	ar0,r2
      008CA9 7A 00            [12] 2383 	mov	r2,#0x00
      008CAB 89 82            [24] 2384 	mov	dpl, r1
      008CAD 88 83            [24] 2385 	mov	dph, r0
      008CAF 8A F0            [24] 2386 	mov	b, r2
      008CB1 12 40 A1         [24] 2387 	lcall	_eeprom_read_byte
      008CB4 E5 82            [12] 2388 	mov	a, dpl
      008CB6 70 06            [24] 2389 	jnz	00110$
                                   2390 ;	quantum/dynamic_keymap.c:720: --id;
      008CB8 1F               [12] 2391 	dec	r7
      008CB9 90 0B 3C         [24] 2392 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008CBC EF               [12] 2393 	mov	a,r7
      008CBD F0               [24] 2394 	movx	@dptr,a
      008CBE                       2395 00110$:
                                   2396 ;	quantum/dynamic_keymap.c:722: ++p;
      008CBE 0B               [12] 2397 	inc	r3
      008CBF BB 00 01         [24] 2398 	cjne	r3,#0x00,00429$
      008CC2 0C               [12] 2399 	inc	r4
      008CC3                       2400 00429$:
      008CC3 90 0B 3E         [24] 2401 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008CC6 12 38 2C         [24] 2402 	lcall	_ak820_outline_0077
      008CC9 80 CC            [24] 2403 	sjmp	00111$
      008CCB                       2404 00113$:
                                   2405 ;	quantum/dynamic_keymap.c:728: sending = true;
      008CCB 90 0B 3D         [24] 2406 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008CCE 74 01            [12] 2407 	mov	a,#0x01
      008CD0 F0               [24] 2408 	movx	@dptr,a
                                   2409 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      008CD1 12 8F 7E         [24] 2410 	lcall	_ak820_outline_0160
      008CD4 90 09 86         [24] 2411 	mov	dptr,#_ak820_macro_cancelled
      008CD7 F0               [24] 2412 	movx	@dptr,a
                                   2413 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      008CD8 90 0B 40         [24] 2414 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008CDB F0               [24] 2415 	movx	@dptr,a
      008CDC 90 0B 41         [24] 2416 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008CDF F0               [24] 2417 	movx	@dptr,a
      008CE0 90 0B 42         [24] 2418 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008CE3 F0               [24] 2419 	movx	@dptr,a
      008CE4 90 0B 43         [24] 2420 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008CE7 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	quantum/dynamic_keymap.c:738: while (p < end
      008CE8                       2423 00167$:
                                   2424 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      008CE8 90 0B 3E         [24] 2425 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008CEB E0               [24] 2426 	movx	a,@dptr
      008CEC FC               [12] 2427 	mov	r4,a
      008CED A3               [24] 2428 	inc	dptr
      008CEE E0               [24] 2429 	movx	a,@dptr
      008CEF FF               [12] 2430 	mov	r7,a
      008CF0 C3               [12] 2431 	clr	c
      008CF1 EC               [12] 2432 	mov	a,r4
      008CF2 9D               [12] 2433 	subb	a,r5
      008CF3 EF               [12] 2434 	mov	a,r7
      008CF4 9E               [12] 2435 	subb	a,r6
      008CF5 40 03            [24] 2436 	jc	00430$
      008CF7 02 8F 0C         [24] 2437 	ljmp	00169$
      008CFA                       2438 00430$:
      008CFA 90 09 86         [24] 2439 	mov	dptr,#_ak820_macro_cancelled
      008CFD E0               [24] 2440 	movx	a,@dptr
      008CFE 60 03            [24] 2441 	jz	00431$
      008D00 02 8F 0C         [24] 2442 	ljmp	00169$
      008D03                       2443 00431$:
                                   2444 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008D03 8C 02            [24] 2445 	mov	ar2,r4
      008D05 8F 03            [24] 2446 	mov	ar3,r7
      008D07 90 0B 3E         [24] 2447 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008D0A 74 01            [12] 2448 	mov	a,#0x01
      008D0C 2C               [12] 2449 	add	a, r4
      008D0D F0               [24] 2450 	movx	@dptr,a
      008D0E E4               [12] 2451 	clr	a
      008D0F 3F               [12] 2452 	addc	a, r7
      008D10 A3               [24] 2453 	inc	dptr
      008D11 F0               [24] 2454 	movx	@dptr,a
      008D12 7F 00            [12] 2455 	mov	r7,#0x00
      008D14 12 43 A5         [24] 2456 	lcall	_ak820_outline_0140
      008D17 8F F0            [24] 2457 	mov	b, r7
      008D19 12 40 A1         [24] 2458 	lcall	_eeprom_read_byte
      008D1C AF 82            [24] 2459 	mov	r7, dpl
      008D1E 90 0B 40         [24] 2460 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008D21 EF               [12] 2461 	mov	a,r7
      008D22 F0               [24] 2462 	movx	@dptr,a
                                   2463 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      008D23 90 0B 41         [24] 2464 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008D26 E4               [12] 2465 	clr	a
      008D27 F0               [24] 2466 	movx	@dptr,a
                                   2467 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      008D28 90 0B 40         [24] 2468 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008D2B E0               [24] 2469 	movx	a,@dptr
      008D2C 70 03            [24] 2470 	jnz	00432$
      008D2E 02 8F 0C         [24] 2471 	ljmp	00169$
      008D31                       2472 00432$:
                                   2473 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      008D31 90 0B 40         [24] 2474 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008D34 E0               [24] 2475 	movx	a,@dptr
      008D35 FF               [12] 2476 	mov	r7,a
      008D36 BF 01 02         [24] 2477 	cjne	r7,#0x01,00433$
      008D39 80 03            [24] 2478 	sjmp	00434$
      008D3B                       2479 00433$:
      008D3B 02 8E EE         [24] 2480 	ljmp	00164$
      008D3E                       2481 00434$:
                                   2482 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008D3E 12 8F 14         [24] 2483 	lcall	_ak820_outline_0000
      008D41 12 40 A1         [24] 2484 	lcall	_eeprom_read_byte
      008D44 AF 82            [24] 2485 	mov	r7, dpl
      008D46 90 0B 41         [24] 2486 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008D49 EF               [12] 2487 	mov	a,r7
      008D4A F0               [24] 2488 	movx	@dptr,a
                                   2489 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      008D4B EF               [12] 2490 	mov	a,r7
      008D4C 70 03            [24] 2491 	jnz	00435$
      008D4E 02 8F 0C         [24] 2492 	ljmp	00169$
      008D51                       2493 00435$:
                                   2494 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008D51 12 8F 4C         [24] 2495 	lcall	_ak820_outline_0090
      008D54 BF 01 02         [24] 2496 	cjne	r7,#0x01,00436$
      008D57 80 13            [24] 2497 	sjmp	00151$
      008D59                       2498 00436$:
      008D59 12 8F 4C         [24] 2499 	lcall	_ak820_outline_0090
      008D5C BF 02 02         [24] 2500 	cjne	r7,#0x02,00437$
      008D5F 80 0B            [24] 2501 	sjmp	00151$
      008D61                       2502 00437$:
      008D61 12 8F 4C         [24] 2503 	lcall	_ak820_outline_0090
      008D64 BF 03 02         [24] 2504 	cjne	r7,#0x03,00438$
      008D67 80 03            [24] 2505 	sjmp	00439$
      008D69                       2506 00438$:
      008D69 02 8D CD         [24] 2507 	ljmp	00152$
      008D6C                       2508 00439$:
      008D6C                       2509 00151$:
                                   2510 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008D6C 12 8F 14         [24] 2511 	lcall	_ak820_outline_0000
      008D6F 12 40 A1         [24] 2512 	lcall	_eeprom_read_byte
      008D72 12 8F 96         [24] 2513 	lcall	_ak820_outline_0178
                                   2514 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      008D75 70 03            [24] 2515 	jnz	00440$
      008D77 02 8C E8         [24] 2516 	ljmp	00167$
      008D7A                       2517 00440$:
                                   2518 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008D7A 12 8F 4C         [24] 2519 	lcall	_ak820_outline_0090
      008D7D BF 01 03         [24] 2520 	cjne	r7,#0x01,00441$
      008D80 D3               [12] 2521 	setb	c
      008D81 80 01            [24] 2522 	sjmp	00442$
      008D83                       2523 00441$:
      008D83 C3               [12] 2524 	clr	c
      008D84                       2525 00442$:
      008D84 92 22            [24] 2526 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008D86 90 09 85         [24] 2527 	mov	dptr,#_ak820_macro_primitive
      008D89 B3               [12] 2528 	cpl	c
      008D8A E4               [12] 2529 	clr	a
      008D8B 33               [12] 2530 	rlc	a
      008D8C F0               [24] 2531 	movx	@dptr,a
                                   2532 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008D8D 12 8F 4C         [24] 2533 	lcall	_ak820_outline_0090
      008D90 BF 01 10         [24] 2534 	cjne	r7,#0x01,00122$
      008D93 12 8F 77         [24] 2535 	lcall	_ak820_outline_0147
      008D96 C0 06            [24] 2536 	push	ar6
      008D98 C0 05            [24] 2537 	push	ar5
      008D9A 12 77 5A         [24] 2538 	lcall	_tap_code
      008D9D D0 05            [24] 2539 	pop	ar5
      008D9F D0 06            [24] 2540 	pop	ar6
      008DA1 80 24            [24] 2541 	sjmp	00123$
      008DA3                       2542 00122$:
                                   2543 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008DA3 12 8F 4C         [24] 2544 	lcall	_ak820_outline_0090
      008DA6 BF 02 10         [24] 2545 	cjne	r7,#0x02,00119$
      008DA9 12 8F 77         [24] 2546 	lcall	_ak820_outline_0147
      008DAC C0 06            [24] 2547 	push	ar6
      008DAE C0 05            [24] 2548 	push	ar5
      008DB0 12 76 54         [24] 2549 	lcall	_register_code
      008DB3 D0 05            [24] 2550 	pop	ar5
      008DB5 D0 06            [24] 2551 	pop	ar6
      008DB7 80 0E            [24] 2552 	sjmp	00123$
      008DB9                       2553 00119$:
                                   2554 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      008DB9 12 8F 77         [24] 2555 	lcall	_ak820_outline_0147
      008DBC C0 06            [24] 2556 	push	ar6
      008DBE C0 05            [24] 2557 	push	ar5
      008DC0 12 76 C1         [24] 2558 	lcall	_unregister_code
      008DC3 D0 05            [24] 2559 	pop	ar5
      008DC5 D0 06            [24] 2560 	pop	ar6
      008DC7                       2561 00123$:
                                   2562 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      008DC7 12 8F 7E         [24] 2563 	lcall	_ak820_outline_0160
      008DCA 02 8C E8         [24] 2564 	ljmp	00167$
      008DCD                       2565 00152$:
                                   2566 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008DCD 12 8F 4C         [24] 2567 	lcall	_ak820_outline_0090
      008DD0 BF 05 02         [24] 2568 	cjne	r7,#0x05,00447$
      008DD3 80 13            [24] 2569 	sjmp	00146$
      008DD5                       2570 00447$:
      008DD5 12 8F 4C         [24] 2571 	lcall	_ak820_outline_0090
      008DD8 BF 06 02         [24] 2572 	cjne	r7,#0x06,00448$
      008DDB 80 0B            [24] 2573 	sjmp	00146$
      008DDD                       2574 00448$:
      008DDD 12 8F 4C         [24] 2575 	lcall	_ak820_outline_0090
      008DE0 BF 07 02         [24] 2576 	cjne	r7,#0x07,00449$
      008DE3 80 03            [24] 2577 	sjmp	00450$
      008DE5                       2578 00449$:
      008DE5 02 8E 8E         [24] 2579 	ljmp	00147$
      008DE8                       2580 00450$:
      008DE8                       2581 00146$:
                                   2582 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008DE8 12 8F 14         [24] 2583 	lcall	_ak820_outline_0000
      008DEB 12 40 A1         [24] 2584 	lcall	_eeprom_read_byte
      008DEE 12 8F 96         [24] 2585 	lcall	_ak820_outline_0178
                                   2586 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      008DF1 70 03            [24] 2587 	jnz	00451$
      008DF3 02 8C E8         [24] 2588 	ljmp	00167$
      008DF6                       2589 00451$:
                                   2590 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008DF6 12 8F 14         [24] 2591 	lcall	_ak820_outline_0000
      008DF9 12 40 A1         [24] 2592 	lcall	_eeprom_read_byte
      008DFC AF 82            [24] 2593 	mov	r7, dpl
      008DFE 90 0B 43         [24] 2594 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008E01 EF               [12] 2595 	mov	a,r7
      008E02 F0               [24] 2596 	movx	@dptr,a
                                   2597 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      008E03 EF               [12] 2598 	mov	a,r7
      008E04 70 03            [24] 2599 	jnz	00452$
      008E06 02 8C E8         [24] 2600 	ljmp	00167$
      008E09                       2601 00452$:
                                   2602 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008E09 90 0B 42         [24] 2603 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008E0C E0               [24] 2604 	movx	a,@dptr
      008E0D FF               [12] 2605 	mov	r7,a
      008E0E 90 0B 43         [24] 2606 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008E11 E0               [24] 2607 	movx	a,@dptr
      008E12 FB               [12] 2608 	mov	r3,a
      008E13 E4               [12] 2609 	clr	a
      008E14 FC               [12] 2610 	mov	r4,a
      008E15 FA               [12] 2611 	mov	r2,a
      008E16 EF               [12] 2612 	mov	a,r7
      008E17 42 04            [12] 2613 	orl	ar4,a
      008E19 EA               [12] 2614 	mov	a,r2
      008E1A 42 03            [12] 2615 	orl	ar3,a
                                   2616 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      008E1C 12 43 C5         [24] 2617 	lcall	_ak820_outline_0180
      008E1F C0 06            [24] 2618 	push	ar6
      008E21 C0 05            [24] 2619 	push	ar5
      008E23 12 8C 34         [24] 2620 	lcall	_decode_keycode
      008E26 AC 82            [24] 2621 	mov	r4, dpl
      008E28 AF 83            [24] 2622 	mov	r7, dph
      008E2A D0 05            [24] 2623 	pop	ar5
      008E2C D0 06            [24] 2624 	pop	ar6
                                   2625 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008E2E 90 0B 41         [24] 2626 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008E31 E0               [24] 2627 	movx	a,@dptr
      008E32 FB               [12] 2628 	mov	r3,a
      008E33 BB 05 03         [24] 2629 	cjne	r3,#0x05,00453$
      008E36 D3               [12] 2630 	setb	c
      008E37 80 01            [24] 2631 	sjmp	00454$
      008E39                       2632 00453$:
      008E39 C3               [12] 2633 	clr	c
      008E3A                       2634 00454$:
      008E3A 92 22            [24] 2635 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008E3C 90 09 85         [24] 2636 	mov	dptr,#_ak820_macro_primitive
      008E3F B3               [12] 2637 	cpl	c
      008E40 E4               [12] 2638 	clr	a
      008E41 33               [12] 2639 	rlc	a
      008E42 F0               [24] 2640 	movx	@dptr,a
                                   2641 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      008E43 90 0B 41         [24] 2642 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008E46 E0               [24] 2643 	movx	a,@dptr
      008E47 FB               [12] 2644 	mov	r3,a
      008E48 BB 05 02         [24] 2645 	cjne	r3,#0x05,00455$
      008E4B 80 0A            [24] 2646 	sjmp	00126$
      008E4D                       2647 00455$:
      008E4D BB 06 02         [24] 2648 	cjne	r3,#0x06,00456$
      008E50 80 16            [24] 2649 	sjmp	00127$
      008E52                       2650 00456$:
                                   2651 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      008E52 BB 07 33         [24] 2652 	cjne	r3,#0x07,00129$
      008E55 80 22            [24] 2653 	sjmp	00128$
      008E57                       2654 00126$:
                                   2655 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      008E57 8C 82            [24] 2656 	mov	dpl, r4
      008E59 8F 83            [24] 2657 	mov	dph, r7
      008E5B C0 06            [24] 2658 	push	ar6
      008E5D C0 05            [24] 2659 	push	ar5
      008E5F 12 B1 DD         [24] 2660 	lcall	_vial_keycode_tap
      008E62 D0 05            [24] 2661 	pop	ar5
      008E64 D0 06            [24] 2662 	pop	ar6
                                   2663 ;	quantum/dynamic_keymap.c:795: break;
                                   2664 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      008E66 80 20            [24] 2665 	sjmp	00129$
      008E68                       2666 00127$:
                                   2667 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      008E68 8C 82            [24] 2668 	mov	dpl, r4
      008E6A 8F 83            [24] 2669 	mov	dph, r7
      008E6C C0 06            [24] 2670 	push	ar6
      008E6E C0 05            [24] 2671 	push	ar5
      008E70 12 B1 12         [24] 2672 	lcall	_vial_keycode_down
      008E73 D0 05            [24] 2673 	pop	ar5
      008E75 D0 06            [24] 2674 	pop	ar6
                                   2675 ;	quantum/dynamic_keymap.c:798: break;
                                   2676 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      008E77 80 0F            [24] 2677 	sjmp	00129$
      008E79                       2678 00128$:
                                   2679 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      008E79 8C 82            [24] 2680 	mov	dpl, r4
      008E7B 8F 83            [24] 2681 	mov	dph, r7
      008E7D C0 06            [24] 2682 	push	ar6
      008E7F C0 05            [24] 2683 	push	ar5
      008E81 12 B1 78         [24] 2684 	lcall	_vial_keycode_up
      008E84 D0 05            [24] 2685 	pop	ar5
      008E86 D0 06            [24] 2686 	pop	ar6
                                   2687 ;	quantum/dynamic_keymap.c:802: }
      008E88                       2688 00129$:
                                   2689 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      008E88 12 8F 7E         [24] 2690 	lcall	_ak820_outline_0160
      008E8B 02 8C E8         [24] 2691 	ljmp	00167$
      008E8E                       2692 00147$:
                                   2693 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      008E8E 12 8F 4C         [24] 2694 	lcall	_ak820_outline_0090
      008E91 BF 04 02         [24] 2695 	cjne	r7,#0x04,00458$
      008E94 80 03            [24] 2696 	sjmp	00459$
      008E96                       2697 00458$:
      008E96 02 8C E8         [24] 2698 	ljmp	00167$
      008E99                       2699 00459$:
                                   2700 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E99 12 8F 14         [24] 2701 	lcall	_ak820_outline_0000
      008E9C 12 40 A1         [24] 2702 	lcall	_eeprom_read_byte
      008E9F AF 82            [24] 2703 	mov	r7, dpl
                                   2704 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008EA1 90 0B 3E         [24] 2705 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008EA4 12 38 5A         [24] 2706 	lcall	_ak820_outline_0121
      008EA7 90 0B 3E         [24] 2707 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008EAA 74 01            [12] 2708 	mov	a,#0x01
      008EAC 2B               [12] 2709 	add	a, r3
      008EAD F0               [24] 2710 	movx	@dptr,a
      008EAE E4               [12] 2711 	clr	a
      008EAF 3C               [12] 2712 	addc	a, r4
      008EB0 A3               [24] 2713 	inc	dptr
      008EB1 F0               [24] 2714 	movx	@dptr,a
      008EB2 7A 00            [12] 2715 	mov	r2,#0x00
      008EB4 12 33 FC         [24] 2716 	lcall	_ak820_outline_0122
      008EB7 8A F0            [24] 2717 	mov	b, r2
      008EB9 12 40 A1         [24] 2718 	lcall	_eeprom_read_byte
      008EBC AC 82            [24] 2719 	mov	r4, dpl
                                   2720 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      008EBE EF               [12] 2721 	mov	a,r7
      008EBF 60 4B            [24] 2722 	jz	00169$
      008EC1 EC               [12] 2723 	mov	a,r4
      008EC2 60 48            [24] 2724 	jz	00169$
                                   2725 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008EC4 1F               [12] 2726 	dec	r7
      008EC5 1C               [12] 2727 	dec	r4
      008EC6 EC               [12] 2728 	mov	a,r4
      008EC7 75 F0 FF         [24] 2729 	mov	b,#0xff
      008ECA A4               [48] 2730 	mul	ab
      008ECB FC               [12] 2731 	mov	r4,a
      008ECC AB F0            [24] 2732 	mov	r3,b
      008ECE 7A 00            [12] 2733 	mov	r2,#0x00
      008ED0 EC               [12] 2734 	mov	a,r4
      008ED1 2F               [12] 2735 	add	a, r7
      008ED2 FC               [12] 2736 	mov	r4,a
      008ED3 EB               [12] 2737 	mov	a,r3
      008ED4 3A               [12] 2738 	addc	a, r2
      008ED5 FB               [12] 2739 	mov	r3,a
                                   2740 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      008ED6                       2741 00141$:
      008ED6 8C 02            [24] 2742 	mov	ar2,r4
      008ED8 8B 07            [24] 2743 	mov	ar7,r3
      008EDA 1C               [12] 2744 	dec	r4
      008EDB BC FF 01         [24] 2745 	cjne	r4,#0xff,00462$
      008EDE 1B               [12] 2746 	dec	r3
      008EDF                       2747 00462$:
      008EDF EA               [12] 2748 	mov	a,r2
      008EE0 4F               [12] 2749 	orl	a,r7
      008EE1 70 03            [24] 2750 	jnz	00463$
      008EE3 02 8C E8         [24] 2751 	ljmp	00167$
      008EE6                       2752 00463$:
      008EE6 90 00 01         [24] 2753 	mov	dptr,#0x0001
      008EE9 12 59 90         [24] 2754 	lcall	_mDelaymS
      008EEC 80 E8            [24] 2755 	sjmp	00141$
      008EEE                       2756 00164$:
                                   2757 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      008EEE 90 0B 40         [24] 2758 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008EF1 E0               [24] 2759 	movx	a,@dptr
      008EF2 FF               [12] 2760 	mov	r7,a
      008EF3 BF 80 00         [24] 2761 	cjne	r7,#0x80,00464$
      008EF6                       2762 00464$:
      008EF6 50 14            [24] 2763 	jnc	00169$
                                   2764 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      008EF8 90 0B 40         [24] 2765 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008EFB E0               [24] 2766 	movx	a,@dptr
      008EFC F5 82            [12] 2767 	mov	dpl,a
      008EFE C0 06            [24] 2768 	push	ar6
      008F00 C0 05            [24] 2769 	push	ar5
      008F02 12 A4 79         [24] 2770 	lcall	_send_char
      008F05 D0 05            [24] 2771 	pop	ar5
      008F07 D0 06            [24] 2772 	pop	ar6
                                   2773 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008F09 02 8C E8         [24] 2774 	ljmp	00167$
      008F0C                       2775 00169$:
                                   2776 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      008F0C 12 8F 7E         [24] 2777 	lcall	_ak820_outline_0160
                                   2778 ;	quantum/dynamic_keymap.c:837: sending = false;
      008F0F 90 0B 3D         [24] 2779 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008F12 F0               [24] 2780 	movx	@dptr,a
                                   2781 ;	quantum/dynamic_keymap.c:839: }
      008F13 22               [24] 2782 	ret
                                   2783 	.area CSEG    (CODE)
                                   2784 	.area CONST   (CODE)
                                   2785 	.area XINIT   (CODE)
                                   2786 	.area CABS    (ABS,CODE)
                                   2787 
                                   2788 ; Experimental exact instruction outlining.
                                   2789 	.globl _ak820_outline_0000
                                   2790 	.globl _ak820_outline_0004
                                   2791 	.globl _ak820_outline_0010
                                   2792 	.globl _ak820_outline_0012
                                   2793 	.globl _ak820_outline_0017
                                   2794 	.globl _ak820_outline_0025
                                   2795 	.globl _ak820_outline_0031
                                   2796 	.globl _ak820_outline_0044
                                   2797 	.globl _ak820_outline_0051
                                   2798 	.globl _ak820_outline_0059
                                   2799 	.globl _ak820_outline_0060
                                   2800 	.globl _ak820_outline_0061
                                   2801 	.globl _ak820_outline_0071
                                   2802 	.globl _ak820_outline_0075
                                   2803 	.globl _ak820_outline_0077
                                   2804 	.globl _ak820_outline_0079
                                   2805 	.globl _ak820_outline_0088
                                   2806 	.globl _ak820_outline_0090
                                   2807 	.globl _ak820_outline_0096
                                   2808 	.globl _ak820_outline_0097
                                   2809 	.globl _ak820_outline_0100
                                   2810 	.globl _ak820_outline_0103
                                   2811 	.globl _ak820_outline_0104
                                   2812 	.globl _ak820_outline_0112
                                   2813 	.globl _ak820_outline_0116
                                   2814 	.globl _ak820_outline_0117
                                   2815 	.globl _ak820_outline_0120
                                   2816 	.globl _ak820_outline_0121
                                   2817 	.globl _ak820_outline_0122
                                   2818 	.globl _ak820_outline_0123
                                   2819 	.globl _ak820_outline_0127
                                   2820 	.globl _ak820_outline_0131
                                   2821 	.globl _ak820_outline_0132
                                   2822 	.globl _ak820_outline_0133
                                   2823 	.globl _ak820_outline_0134
                                   2824 	.globl _ak820_outline_0139
                                   2825 	.globl _ak820_outline_0140
                                   2826 	.globl _ak820_outline_0145
                                   2827 	.globl _ak820_outline_0147
                                   2828 	.globl _ak820_outline_0151
                                   2829 	.globl _ak820_outline_0152
                                   2830 	.globl _ak820_outline_0155
                                   2831 	.globl _ak820_outline_0160
                                   2832 	.globl _ak820_outline_0166
                                   2833 	.globl _ak820_outline_0174
                                   2834 	.globl _ak820_outline_0175
                                   2835 	.globl _ak820_outline_0178
                                   2836 	.globl _ak820_outline_0179
                                   2837 	.globl _ak820_outline_0180
                                   2838 
                                   2839 	.area CSEG (CODE)
                                   2840 ; function ak820_outline_0000
      008F14                       2841 _ak820_outline_0000:
      008F14 90 0B 3E         [24] 2842 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008F17 E0               [24] 2843 	movx	a,@dptr
      008F18 FC               [12] 2844 	mov	r4,a
      008F19 A3               [24] 2845 	inc	dptr
      008F1A E0               [24] 2846 	movx	a,@dptr
      008F1B FF               [12] 2847 	mov	r7,a
      008F1C 90 0B 3E         [24] 2848 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008F1F 74 01            [12] 2849 	mov	a,#0x01
      008F21 2C               [12] 2850 	add	a,r4
      008F22 F0               [24] 2851 	movx	@dptr,a
      008F23 E4               [12] 2852 	clr	a
      008F24 3F               [12] 2853 	addc	a,r7
      008F25 A3               [24] 2854 	inc	dptr
      008F26 F0               [24] 2855 	movx	@dptr,a
      008F27 7B 00            [12] 2856 	mov	r3,#0x00
      008F29 8C 82            [24] 2857 	mov	dpl,r4
      008F2B 8F 83            [24] 2858 	mov	dph,r7
      008F2D 8B F0            [24] 2859 	mov	b,r3
      008F2F 22               [24] 2860 	ret
                                   2861 
                                   2862 	.area CSEG (CODE)
                                   2863 ; function ak820_outline_0025
      008F30                       2864 _ak820_outline_0025:
      008F30 2D               [12] 2865 	add	a,r5
      008F31 F9               [12] 2866 	mov	r1,a
      008F32 E4               [12] 2867 	clr	a
      008F33 3E               [12] 2868 	addc	a,r6
      008F34 FA               [12] 2869 	mov	r2,a
      008F35 8F 03            [24] 2870 	mov	ar3,r7
      008F37 89 82            [24] 2871 	mov	dpl,r1
      008F39 8A 83            [24] 2872 	mov	dph,r2
      008F3B 8B F0            [24] 2873 	mov	b,r3
      008F3D 22               [24] 2874 	ret
                                   2875 
                                   2876 	.area CSEG (CODE)
                                   2877 ; function ak820_outline_0079
      008F3E                       2878 _ak820_outline_0079:
      008F3E ED               [12] 2879 	mov	a,r5
      008F3F 75 F0 0A         [24] 2880 	mov	b,#0x0a
      008F42 A4               [48] 2881 	mul	ab
      008F43 24 58            [12] 2882 	add	a,#0x58
      008F45 FC               [12] 2883 	mov	r4,a
      008F46 74 06            [12] 2884 	mov	a,#0x06
      008F48 35 F0            [12] 2885 	addc	a,b
      008F4A FD               [12] 2886 	mov	r5,a
      008F4B 22               [24] 2887 	ret
                                   2888 
                                   2889 	.area CSEG (CODE)
                                   2890 ; function ak820_outline_0090
      008F4C                       2891 _ak820_outline_0090:
      008F4C 90 0B 41         [24] 2892 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0001)
      008F4F E0               [24] 2893 	movx	a,@dptr
      008F50 FF               [12] 2894 	mov	r7,a
      008F51 22               [24] 2895 	ret
                                   2896 
                                   2897 	.area CSEG (CODE)
                                   2898 ; function ak820_outline_0096
      008F52                       2899 _ak820_outline_0096:
      008F52 90 0A D7         [24] 2900 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008F55 EE               [12] 2901 	mov	a,r6
      008F56 F0               [24] 2902 	movx	@dptr,a
      008F57 90 0A D8         [24] 2903 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008F5A ED               [12] 2904 	mov	a,r5
      008F5B F0               [24] 2905 	movx	@dptr,a
      008F5C 8F 82            [24] 2906 	mov	dpl,r7
      008F5E 22               [24] 2907 	ret
                                   2908 
                                   2909 	.area CSEG (CODE)
                                   2910 ; function ak820_outline_0112
      008F5F                       2911 _ak820_outline_0112:
      008F5F AD 82            [24] 2912 	mov	r5,dpl
      008F61 AE 83            [24] 2913 	mov	r6,dph
      008F63 AF F0            [24] 2914 	mov	r7,b
      008F65 22               [24] 2915 	ret
                                   2916 
                                   2917 	.area CSEG (CODE)
                                   2918 ; function ak820_outline_0127
      008F66                       2919 _ak820_outline_0127:
      008F66 28               [12] 2920 	add	a,r0
      008F67 F5 82            [12] 2921 	mov	dpl,a
      008F69 EF               [12] 2922 	mov	a,r7
      008F6A 39               [12] 2923 	addc	a,r1
      008F6B F5 83            [12] 2924 	mov	dph,a
      008F6D 74 FF            [12] 2925 	mov	a,#0xff
      008F6F F0               [24] 2926 	movx	@dptr,a
      008F70 22               [24] 2927 	ret
                                   2928 
                                   2929 	.area CSEG (CODE)
                                   2930 ; function ak820_outline_0133
      008F71                       2931 _ak820_outline_0133:
      008F71 2D               [12] 2932 	add	a,r5
      008F72 F9               [12] 2933 	mov	r1,a
      008F73 E4               [12] 2934 	clr	a
      008F74 3E               [12] 2935 	addc	a,r6
      008F75 FA               [12] 2936 	mov	r2,a
      008F76 22               [24] 2937 	ret
                                   2938 
                                   2939 	.area CSEG (CODE)
                                   2940 ; function ak820_outline_0147
      008F77                       2941 _ak820_outline_0147:
      008F77 90 0B 42         [24] 2942 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008F7A E0               [24] 2943 	movx	a,@dptr
      008F7B F5 82            [12] 2944 	mov	dpl,a
      008F7D 22               [24] 2945 	ret
                                   2946 
                                   2947 	.area CSEG (CODE)
                                   2948 ; function ak820_outline_0160
      008F7E                       2949 _ak820_outline_0160:
      008F7E 90 09 85         [24] 2950 	mov	dptr,#_ak820_macro_primitive
      008F81 E4               [12] 2951 	clr	a
      008F82 F0               [24] 2952 	movx	@dptr,a
      008F83 22               [24] 2953 	ret
                                   2954 
                                   2955 	.area CSEG (CODE)
                                   2956 ; function ak820_outline_0174
      008F84                       2957 _ak820_outline_0174:
      008F84 90 0A E7         [24] 2958 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008F87 E4               [12] 2959 	clr	a
      008F88 F0               [24] 2960 	movx	@dptr,a
      008F89 90 0A E8         [24] 2961 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008F8C 22               [24] 2962 	ret
                                   2963 
                                   2964 	.area CSEG (CODE)
                                   2965 ; function ak820_outline_0175
      008F8D                       2966 _ak820_outline_0175:
      008F8D 90 0B 9D         [24] 2967 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      008F90 E4               [12] 2968 	clr	a
      008F91 F0               [24] 2969 	movx	@dptr,a
      008F92 90 0B 9E         [24] 2970 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      008F95 22               [24] 2971 	ret
                                   2972 
                                   2973 	.area CSEG (CODE)
                                   2974 ; function ak820_outline_0178
      008F96                       2975 _ak820_outline_0178:
      008F96 AF 82            [24] 2976 	mov	r7,dpl
      008F98 90 0B 42         [24] 2977 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008F9B EF               [12] 2978 	mov	a,r7
      008F9C F0               [24] 2979 	movx	@dptr,a
      008F9D EF               [12] 2980 	mov	a,r7
      008F9E 22               [24] 2981 	ret
