                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         47 bits:
      000025                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000683                         85 _eeprom_read_word_addr_10000_91:
      000683                         86 	.ds 3
      000686                         87 _eeprom_read_word_ret_10000_92:
      000686                         88 	.ds 2
      000688                         89 _eeprom_read_dword_addr_10000_93:
      000688                         90 	.ds 3
      00068B                         91 _eeprom_read_dword_ret_10000_94:
      00068B                         92 	.ds 4
      00068F                         93 _eeprom_write_byte_PARM_2:
      00068F                         94 	.ds 1
      000690                         95 _eeprom_write_byte_addr_10000_95:
      000690                         96 	.ds 3
      000693                         97 _eeprom_write_word_PARM_2:
      000693                         98 	.ds 2
      000695                         99 _eeprom_write_word_addr_10000_97:
      000695                        100 	.ds 3
      000698                        101 _eeprom_write_dword_PARM_2:
      000698                        102 	.ds 4
      00069C                        103 _eeprom_write_dword_addr_10000_99:
      00069C                        104 	.ds 3
      00069F                        105 _eeprom_update_byte_PARM_2:
      00069F                        106 	.ds 1
      0006A0                        107 _eeprom_update_byte_addr_10000_107:
      0006A0                        108 	.ds 3
      0006A3                        109 _eeprom_update_word_PARM_2:
      0006A3                        110 	.ds 2
      0006A5                        111 _eeprom_update_word_addr_10000_111:
      0006A5                        112 	.ds 3
      0006A8                        113 _eeprom_update_dword_PARM_2:
      0006A8                        114 	.ds 4
      0006AC                        115 _eeprom_update_dword_addr_10000_115:
      0006AC                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004E02                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004E02 12 43 40         [24]  170 	lcall	_ak820_outline_0037
      004E05 90 06 83         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004E08 12 37 E0         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004E0B 90 06 86         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E0E 12 50 0E         [24]  175 	lcall	_ak820_outline_0166
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004E11 90 06 83         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004E14 12 4F BC         [24]  178 	lcall	_ak820_outline_0022
      004E17 90 05 81         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004E1A ED               [12]  180 	mov	a,r5
      004E1B 12 37 E0         [24]  181 	lcall	_ak820_outline_0016
      004E1E 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004E21 12 50 00         [24]  183 	lcall	_ak820_outline_0106
      004E24 90 06 86         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E27 12 40 DC         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004E2A 90 06 86         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E2D 12 4F F7         [24]  188 	lcall	_ak820_outline_0089
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004E30 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004E31                        201 _eeprom_read_dword:
      004E31 12 43 40         [24]  202 	lcall	_ak820_outline_0037
      004E34 90 06 88         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004E37 12 37 E0         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004E3A 90 06 8B         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004E3D 12 4F CC         [24]  207 	lcall	_ak820_outline_0049
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004E40 90 06 88         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004E43 12 4F BC         [24]  210 	lcall	_ak820_outline_0022
      004E46 90 05 81         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004E49 ED               [12]  212 	mov	a,r5
      004E4A 12 37 E0         [24]  213 	lcall	_ak820_outline_0016
      004E4D 90 05 84         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004E50 74 04            [12]  215 	mov	a,#0x04
      004E52 12 38 60         [24]  216 	lcall	_ak820_outline_0123
      004E55 90 06 8B         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004E58 12 40 DC         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004E5B 90 06 8B         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004E5E 12 4F D5         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004E61 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004E62                        234 _eeprom_write_byte:
      004E62 12 43 40         [24]  235 	lcall	_ak820_outline_0037
      004E65 90 06 90         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004E68 12 37 E0         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004E6B 90 06 90         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004E6E 12 4F 96         [24]  240 	lcall	_ak820_outline_0002
      004E71 74 01            [12]  241 	mov	a,#0x01
      004E73 12 38 60         [24]  242 	lcall	_ak820_outline_0123
      004E76 90 06 8F         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004E79 02 41 68         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004E7C                        256 _eeprom_write_word:
      004E7C 12 43 40         [24]  257 	lcall	_ak820_outline_0037
      004E7F 90 06 95         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004E82 12 37 E0         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004E85 90 06 95         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004E88 12 4F 96         [24]  262 	lcall	_ak820_outline_0002
      004E8B 12 50 00         [24]  263 	lcall	_ak820_outline_0106
      004E8E 90 06 93         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004E91 02 41 68         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004E94                        277 _eeprom_write_dword:
      004E94 12 43 40         [24]  278 	lcall	_ak820_outline_0037
      004E97 90 06 9C         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004E9A 12 37 E0         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004E9D 90 06 9C         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004EA0 12 4F 96         [24]  283 	lcall	_ak820_outline_0002
      004EA3 74 04            [12]  284 	mov	a,#0x04
      004EA5 12 38 60         [24]  285 	lcall	_ak820_outline_0123
      004EA8 90 06 98         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004EAB 02 41 68         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004EAE                        307 _eeprom_update_byte:
      004EAE C0 07            [24]  308 	push	ar7
      004EB0 C0 06            [24]  309 	push	ar6
      004EB2 C0 05            [24]  310 	push	ar5
      004EB4 C0 04            [24]  311 	push	ar4
      004EB6 12 43 40         [24]  312 	lcall	_ak820_outline_0037
      004EB9 90 06 A0         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004EBC 12 37 E0         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004EBF 90 06 A0         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004EC2 12 4F AD         [24]  317 	lcall	_ak820_outline_0003
      004EC5 12 40 A1         [24]  318 	lcall	_eeprom_read_byte
      004EC8 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004ECA 90 06 9F         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004ECD E0               [24]  322 	movx	a,@dptr
      004ECE FE               [12]  323 	mov	r6,a
      004ECF EF               [12]  324 	mov	a,r7
      004ED0 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004ED3 80 36            [24]  326 	sjmp	00103$
      004ED5                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004ED5 90 06 A0         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004ED8 12 38 20         [24]  330 	lcall	_ak820_outline_0060
      004EDB A3               [24]  331 	inc	dptr
      004EDC E0               [24]  332 	movx	a,@dptr
      004EDD FF               [12]  333 	mov	r7,a
      004EDE 90 06 8F         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004EE1 EE               [12]  335 	mov	a,r6
      004EE2 F0               [24]  336 	movx	@dptr,a
      004EE3 12 38 55         [24]  337 	lcall	_ak820_outline_0117
      004EE6 8F F0            [24]  338 	mov	b, r7
      004EE8 C0 07            [24]  339 	push	ar7
      004EEA C0 06            [24]  340 	push	ar6
      004EEC C0 05            [24]  341 	push	ar5
      004EEE C0 04            [24]  342 	push	ar4
      004EF0 C0 03            [24]  343 	push	ar3
      004EF2 C0 02            [24]  344 	push	ar2
      004EF4 C0 01            [24]  345 	push	ar1
      004EF6 C0 00            [24]  346 	push	ar0
      004EF8 12 4E 62         [24]  347 	lcall	_eeprom_write_byte
      004EFB D0 00            [24]  348 	pop	ar0
      004EFD D0 01            [24]  349 	pop	ar1
      004EFF D0 02            [24]  350 	pop	ar2
      004F01 D0 03            [24]  351 	pop	ar3
      004F03 D0 04            [24]  352 	pop	ar4
      004F05 D0 05            [24]  353 	pop	ar5
      004F07 D0 06            [24]  354 	pop	ar6
      004F09 D0 07            [24]  355 	pop	ar7
      004F0B                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      004F0B D0 04            [24]  358 	pop	ar4
      004F0D D0 05            [24]  359 	pop	ar5
      004F0F D0 06            [24]  360 	pop	ar6
      004F11 D0 07            [24]  361 	pop	ar7
      004F13 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      004F14                        374 _eeprom_update_word:
      004F14 12 43 40         [24]  375 	lcall	_ak820_outline_0037
      004F17 90 06 A5         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F1A 12 37 E0         [24]  377 	lcall	_ak820_outline_0016
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004F1D 90 06 A5         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F20 12 4F AD         [24]  380 	lcall	_ak820_outline_0003
      004F23 12 4E 02         [24]  381 	lcall	_eeprom_read_word
      004F26 12 43 94         [24]  382 	lcall	_ak820_outline_0131
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004F29 90 06 A3         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      004F2C 12 38 20         [24]  385 	lcall	_ak820_outline_0060
      004F2F EE               [12]  386 	mov	a,r6
      004F30 B5 04 05         [24]  387 	cjne	a,ar4,00112$
      004F33 EF               [12]  388 	mov	a,r7
      004F34 B5 05 01         [24]  389 	cjne	a,ar5,00112$
      004F37 22               [24]  390 	ret
      004F38                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004F38 90 06 A5         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F3B E0               [24]  394 	movx	a,@dptr
      004F3C FB               [12]  395 	mov	r3,a
      004F3D A3               [24]  396 	inc	dptr
      004F3E 12 38 01         [24]  397 	lcall	_ak820_outline_0051
      004F41 90 06 93         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      004F44 12 38 26         [24]  399 	lcall	_ak820_outline_0071
      004F47 8B 82            [24]  400 	mov	dpl, r3
      004F49 8E 83            [24]  401 	mov	dph, r6
      004F4B 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      004F4D 02 4E 7C         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      004F50                        416 _eeprom_update_dword:
      004F50 12 43 40         [24]  417 	lcall	_ak820_outline_0037
      004F53 90 06 AC         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004F56 12 37 E0         [24]  419 	lcall	_ak820_outline_0016
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004F59 90 06 AC         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004F5C 12 4F AD         [24]  422 	lcall	_ak820_outline_0003
      004F5F 12 4E 31         [24]  423 	lcall	_eeprom_read_dword
      004F62 12 4F E6         [24]  424 	lcall	_ak820_outline_0057
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004F65 90 06 A8         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      004F68 E0               [24]  427 	movx	a,@dptr
      004F69 F8               [12]  428 	mov	r0,a
      004F6A A3               [24]  429 	inc	dptr
      004F6B 12 4F EE         [24]  430 	lcall	_ak820_outline_0088
      004F6E EC               [12]  431 	mov	a,r4
      004F6F B5 00 0D         [24]  432 	cjne	a,ar0,00112$
      004F72 ED               [12]  433 	mov	a,r5
      004F73 B5 01 09         [24]  434 	cjne	a,ar1,00112$
      004F76 EE               [12]  435 	mov	a,r6
      004F77 B5 02 05         [24]  436 	cjne	a,ar2,00112$
      004F7A EF               [12]  437 	mov	a,r7
      004F7B B5 03 01         [24]  438 	cjne	a,ar3,00112$
      004F7E 22               [24]  439 	ret
      004F7F                        440 00112$:
                                    441 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004F7F 90 06 AC         [24]  442 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004F82 12 4F BC         [24]  443 	lcall	_ak820_outline_0022
      004F85 90 06 98         [24]  444 	mov	dptr,#_eeprom_write_dword_PARM_2
      004F88 E8               [12]  445 	mov	a,r0
      004F89 F0               [24]  446 	movx	@dptr,a
      004F8A E9               [12]  447 	mov	a,r1
      004F8B A3               [24]  448 	inc	dptr
      004F8C 12 50 07         [24]  449 	lcall	_ak820_outline_0151
      004F8F F0               [24]  450 	movx	@dptr,a
      004F90 12 4F C5         [24]  451 	lcall	_ak820_outline_0044
                                    452 ;	drivers/eeprom/eeprom_driver.c:101: }
      004F93 02 4E 94         [24]  453 	ljmp	_eeprom_write_dword
                                    454 	.area CSEG    (CODE)
                                    455 	.area CONST   (CODE)
                                    456 	.area XINIT   (CODE)
                                    457 	.area CABS    (ABS,CODE)
                                    458 
                                    459 ; Experimental exact instruction outlining.
                                    460 	.globl _ak820_outline_0002
                                    461 	.globl _ak820_outline_0003
                                    462 	.globl _ak820_outline_0016
                                    463 	.globl _ak820_outline_0022
                                    464 	.globl _ak820_outline_0037
                                    465 	.globl _ak820_outline_0044
                                    466 	.globl _ak820_outline_0049
                                    467 	.globl _ak820_outline_0051
                                    468 	.globl _ak820_outline_0054
                                    469 	.globl _ak820_outline_0057
                                    470 	.globl _ak820_outline_0060
                                    471 	.globl _ak820_outline_0071
                                    472 	.globl _ak820_outline_0088
                                    473 	.globl _ak820_outline_0089
                                    474 	.globl _ak820_outline_0106
                                    475 	.globl _ak820_outline_0117
                                    476 	.globl _ak820_outline_0123
                                    477 	.globl _ak820_outline_0131
                                    478 	.globl _ak820_outline_0151
                                    479 	.globl _ak820_outline_0166
                                    480 
                                    481 	.area CSEG (CODE)
                                    482 ; function ak820_outline_0002
      004F96                        483 _ak820_outline_0002:
      004F96 E0               [24]  484 	movx	a,@dptr
      004F97 FD               [12]  485 	mov	r5,a
      004F98 A3               [24]  486 	inc	dptr
      004F99 E0               [24]  487 	movx	a,@dptr
      004F9A FE               [12]  488 	mov	r6,a
      004F9B A3               [24]  489 	inc	dptr
      004F9C E0               [24]  490 	movx	a,@dptr
      004F9D FF               [12]  491 	mov	r7,a
      004F9E 90 05 8A         [24]  492 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004FA1 ED               [12]  493 	mov	a,r5
      004FA2 F0               [24]  494 	movx	@dptr,a
      004FA3 EE               [12]  495 	mov	a,r6
      004FA4 A3               [24]  496 	inc	dptr
      004FA5 F0               [24]  497 	movx	@dptr,a
      004FA6 EF               [12]  498 	mov	a,r7
      004FA7 A3               [24]  499 	inc	dptr
      004FA8 F0               [24]  500 	movx	@dptr,a
      004FA9 90 05 8D         [24]  501 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004FAC 22               [24]  502 	ret
                                    503 
                                    504 	.area CSEG (CODE)
                                    505 ; function ak820_outline_0003
      004FAD                        506 _ak820_outline_0003:
      004FAD E0               [24]  507 	movx	a,@dptr
      004FAE FD               [12]  508 	mov	r5,a
      004FAF A3               [24]  509 	inc	dptr
      004FB0 E0               [24]  510 	movx	a,@dptr
      004FB1 FE               [12]  511 	mov	r6,a
      004FB2 A3               [24]  512 	inc	dptr
      004FB3 E0               [24]  513 	movx	a,@dptr
      004FB4 FF               [12]  514 	mov	r7,a
      004FB5 8D 82            [24]  515 	mov	dpl,r5
      004FB7 8E 83            [24]  516 	mov	dph,r6
      004FB9 8F F0            [24]  517 	mov	b,r7
      004FBB 22               [24]  518 	ret
                                    519 
                                    520 	.area CSEG (CODE)
                                    521 ; function ak820_outline_0022
      004FBC                        522 _ak820_outline_0022:
      004FBC E0               [24]  523 	movx	a,@dptr
      004FBD FD               [12]  524 	mov	r5,a
      004FBE A3               [24]  525 	inc	dptr
      004FBF E0               [24]  526 	movx	a,@dptr
      004FC0 FE               [12]  527 	mov	r6,a
      004FC1 A3               [24]  528 	inc	dptr
      004FC2 E0               [24]  529 	movx	a,@dptr
      004FC3 FF               [12]  530 	mov	r7,a
      004FC4 22               [24]  531 	ret
                                    532 
                                    533 	.area CSEG (CODE)
                                    534 ; function ak820_outline_0044
      004FC5                        535 _ak820_outline_0044:
      004FC5 8D 82            [24]  536 	mov	dpl,r5
      004FC7 8E 83            [24]  537 	mov	dph,r6
      004FC9 8F F0            [24]  538 	mov	b,r7
      004FCB 22               [24]  539 	ret
                                    540 
                                    541 	.area CSEG (CODE)
                                    542 ; function ak820_outline_0049
      004FCC                        543 _ak820_outline_0049:
      004FCC E4               [12]  544 	clr	a
      004FCD F0               [24]  545 	movx	@dptr,a
      004FCE A3               [24]  546 	inc	dptr
      004FCF F0               [24]  547 	movx	@dptr,a
      004FD0 A3               [24]  548 	inc	dptr
      004FD1 F0               [24]  549 	movx	@dptr,a
      004FD2 A3               [24]  550 	inc	dptr
      004FD3 F0               [24]  551 	movx	@dptr,a
      004FD4 22               [24]  552 	ret
                                    553 
                                    554 	.area CSEG (CODE)
                                    555 ; function ak820_outline_0054
      004FD5                        556 _ak820_outline_0054:
      004FD5 E0               [24]  557 	movx	a,@dptr
      004FD6 FC               [12]  558 	mov	r4,a
      004FD7 A3               [24]  559 	inc	dptr
      004FD8 E0               [24]  560 	movx	a,@dptr
      004FD9 FD               [12]  561 	mov	r5,a
      004FDA A3               [24]  562 	inc	dptr
      004FDB E0               [24]  563 	movx	a,@dptr
      004FDC FE               [12]  564 	mov	r6,a
      004FDD A3               [24]  565 	inc	dptr
      004FDE E0               [24]  566 	movx	a,@dptr
      004FDF 8C 82            [24]  567 	mov	dpl,r4
      004FE1 8D 83            [24]  568 	mov	dph,r5
      004FE3 8E F0            [24]  569 	mov	b,r6
      004FE5 22               [24]  570 	ret
                                    571 
                                    572 	.area CSEG (CODE)
                                    573 ; function ak820_outline_0057
      004FE6                        574 _ak820_outline_0057:
      004FE6 AC 82            [24]  575 	mov	r4,dpl
      004FE8 AD 83            [24]  576 	mov	r5,dph
      004FEA AE F0            [24]  577 	mov	r6,b
      004FEC FF               [12]  578 	mov	r7,a
      004FED 22               [24]  579 	ret
                                    580 
                                    581 	.area CSEG (CODE)
                                    582 ; function ak820_outline_0088
      004FEE                        583 _ak820_outline_0088:
      004FEE E0               [24]  584 	movx	a,@dptr
      004FEF F9               [12]  585 	mov	r1,a
      004FF0 A3               [24]  586 	inc	dptr
      004FF1 E0               [24]  587 	movx	a,@dptr
      004FF2 FA               [12]  588 	mov	r2,a
      004FF3 A3               [24]  589 	inc	dptr
      004FF4 E0               [24]  590 	movx	a,@dptr
      004FF5 FB               [12]  591 	mov	r3,a
      004FF6 22               [24]  592 	ret
                                    593 
                                    594 	.area CSEG (CODE)
                                    595 ; function ak820_outline_0089
      004FF7                        596 _ak820_outline_0089:
      004FF7 E0               [24]  597 	movx	a,@dptr
      004FF8 FE               [12]  598 	mov	r6,a
      004FF9 A3               [24]  599 	inc	dptr
      004FFA E0               [24]  600 	movx	a,@dptr
      004FFB 8E 82            [24]  601 	mov	dpl,r6
      004FFD F5 83            [12]  602 	mov	dph,a
      004FFF 22               [24]  603 	ret
                                    604 
                                    605 	.area CSEG (CODE)
                                    606 ; function ak820_outline_0106
      005000                        607 _ak820_outline_0106:
      005000 74 02            [12]  608 	mov	a,#0x02
      005002 F0               [24]  609 	movx	@dptr,a
      005003 E4               [12]  610 	clr	a
      005004 A3               [24]  611 	inc	dptr
      005005 F0               [24]  612 	movx	@dptr,a
      005006 22               [24]  613 	ret
                                    614 
                                    615 	.area CSEG (CODE)
                                    616 ; function ak820_outline_0151
      005007                        617 _ak820_outline_0151:
      005007 F0               [24]  618 	movx	@dptr,a
      005008 EA               [12]  619 	mov	a,r2
      005009 A3               [24]  620 	inc	dptr
      00500A F0               [24]  621 	movx	@dptr,a
      00500B EB               [12]  622 	mov	a,r3
      00500C A3               [24]  623 	inc	dptr
      00500D 22               [24]  624 	ret
                                    625 
                                    626 	.area CSEG (CODE)
                                    627 ; function ak820_outline_0166
      00500E                        628 _ak820_outline_0166:
      00500E E4               [12]  629 	clr	a
      00500F F0               [24]  630 	movx	@dptr,a
      005010 A3               [24]  631 	inc	dptr
      005011 F0               [24]  632 	movx	@dptr,a
      005012 22               [24]  633 	ret
