                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000053                        551 _change_owned_sloc1_1_0:
      000053                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      00001E                        566 _ak820_macro_change_sloc0_1_0:
      00001E                        567 	.ds 1
      00001F                        568 _change_owned_sloc0_1_0:
      00001F                        569 	.ds 1
      000020                        570 _owned_usage_key_sloc0_1_0:
      000020                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000971                        580 _owned_mod_refs:
      000971                        581 	.ds 8
      000979                        582 _owned_weak_refs:
      000979                        583 	.ds 8
      000981                        584 _owned_mods:
      000981                        585 	.ds 1
      000982                        586 _owned_weak_mods:
      000982                        587 	.ds 1
      000983                        588 _macro_mods:
      000983                        589 	.ds 2
      000985                        590 _ak820_macro_primitive::
      000985                        591 	.ds 1
      000986                        592 _ak820_macro_cancelled::
      000986                        593 	.ds 1
      000987                        594 _ak820_macro_change_PARM_2:
      000987                        595 	.ds 1
      000988                        596 _ak820_macro_change_PARM_3:
      000988                        597 	.ds 1
      000989                        598 _ak820_macro_change_bits_10000_293:
      000989                        599 	.ds 2
      00098B                        600 _change_owned_PARM_2:
      00098B                        601 	.ds 1
      00098C                        602 _change_owned_mods_10000_298:
      00098C                        603 	.ds 1
      00098D                        604 _change_owned_result_10001_302:
      00098D                        605 	.ds 1
      00098E                        606 _change_owned_bit_20001_303:
      00098E                        607 	.ds 1
      00098F                        608 _add_owned_mods_mods_10000_311:
      00098F                        609 	.ds 1
      000990                        610 _del_owned_mods_mods_10000_313:
      000990                        611 	.ds 1
      000991                        612 _add_owned_weak_mods_mods_10000_315:
      000991                        613 	.ds 1
      000992                        614 _del_owned_weak_mods_mods_10000_317:
      000992                        615 	.ds 1
      000993                        616 _key_refs:
      000993                        617 	.ds 165
      000A38                        618 _distinct_keys:
      000A38                        619 	.ds 1
      000A39                        620 _macro_keys:
      000A39                        621 	.ds 21
      000A4E                        622 _add_owned_key_code_10000_326:
      000A4E                        623 	.ds 1
      000A4F                        624 _del_owned_key_code_10000_341:
      000A4F                        625 	.ds 1
      000A50                        626 _usage_refs:
      000A50                        627 	.ds 30
      000A6E                        628 _usage_order:
      000A6E                        629 	.ds 30
      000A8C                        630 _usage_lengths:
      000A8C                        631 	.ds 2
      000A8E                        632 _macro_usages:
      000A8E                        633 	.ds 4
      000A92                        634 _owned_usage_key_PARM_2:
      000A92                        635 	.ds 1
      000A93                        636 _owned_usage_key_code_10000_368:
      000A93                        637 	.ds 1
      000A94                        638 _owned_usage_key___200000085_20000_369:
      000A94                        639 	.ds 2
      000A96                        640 _owned_usage_key_which_10000_369:
      000A96                        641 	.ds 1
      000A97                        642 _owned_usage_key_count_10000_369:
      000A97                        643 	.ds 1
      000A98                        644 _owned_usage_key_pos_30001_376:
      000A98                        645 	.ds 1
      000A99                        646 _owned_usage_key_key_40000_381:
      000A99                        647 	.ds 1
      000A9A                        648 _send_keyboard_report_last_report_10001_388:
      000A9A                        649 	.ds 32
      000ABA                        650 _send_keyboard_report_changed_10001_388:
      000ABA                        651 	.ds 1
      000ABB                        652 _add_weak_mods_mods_10000_406:
      000ABB                        653 	.ds 1
      000ABC                        654 _del_weak_mods_mods_10000_408:
      000ABC                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000D9C                        664 _real_mods:
      000D9C                        665 	.ds 1
      000D9D                        666 _weak_mods:
      000D9D                        667 	.ds 1
      000D9E                        668 _actual_keyboard_report::
      000D9E                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007C85                        713 _ak820_macro_change:
      007C85 12 38 44         [24]  714 	lcall	_ak820_outline_0103
      007C88 90 09 89         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007C8B 12 38 49         [24]  716 	lcall	_ak820_outline_0104
                                    717 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      007C8E 90 09 85         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007C91 E0               [24]  719 	movx	a,@dptr
      007C92 70 04            [24]  720 	jnz	00102$
      007C94 75 82 01         [24]  721 	mov	dpl, #0x01
      007C97 22               [24]  722 	ret
      007C98                        723 00102$:
                                    724 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      007C98 90 09 87         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      007C9B E0               [24]  726 	movx	a,@dptr
      007C9C FF               [12]  727 	mov	r7,a
      007C9D 74 07            [12]  728 	mov	a,#0x07
      007C9F 5F               [12]  729 	anl	a,r7
      007CA0 12 78 2A         [24]  730 	lcall	_ak820_outline_0063
      007CA3 80 02            [24]  731 	sjmp	00123$
      007CA5                        732 00122$:
      007CA5 25 E0            [12]  733 	add	a,acc
      007CA7                        734 00123$:
      007CA7 D5 F0 FB         [24]  735 	djnz	b,00122$
      007CAA FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:101: bits += index >> 3;
      007CAB EF               [12]  738 	mov	a,r7
      007CAC 12 58 09         [24]  739 	lcall	_ak820_outline_0183
      007CAF FF               [12]  740 	mov	r7,a
      007CB0 90 09 89         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007CB3 12 38 20         [24]  742 	lcall	_ak820_outline_0060
      007CB6 90 09 89         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007CB9 EF               [12]  744 	mov	a,r7
      007CBA 2C               [12]  745 	add	a, r4
      007CBB F0               [24]  746 	movx	@dptr,a
      007CBC E4               [12]  747 	clr	a
      007CBD 3D               [12]  748 	addc	a, r5
      007CBE A3               [24]  749 	inc	dptr
      007CBF F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      007CC0 90 09 89         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007CC3 E0               [24]  753 	movx	a,@dptr
      007CC4 FD               [12]  754 	mov	r5,a
      007CC5 A3               [24]  755 	inc	dptr
      007CC6 E0               [24]  756 	movx	a,@dptr
      007CC7 FF               [12]  757 	mov	r7,a
      007CC8 12 82 0A         [24]  758 	lcall	_ak820_outline_0185
      007CCB E0               [24]  759 	movx	a,@dptr
      007CCC FC               [12]  760 	mov	r4,a
      007CCD EE               [12]  761 	mov	a,r6
      007CCE 5C               [12]  762 	anl	a,r4
      007CCF B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      007CD2                        764 00124$:
      007CD2 B3               [12]  765 	cpl	c
      007CD3 92 1E            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      007CD5 90 09 88         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      007CD8 E0               [24]  768 	movx	a,@dptr
      007CD9 FB               [12]  769 	mov	r3,a
      007CDA A2 1E            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      007CDC E4               [12]  771 	clr	a
      007CDD 33               [12]  772 	rlc	a
      007CDE B5 03 04         [24]  773 	cjne	a,ar3,00104$
      007CE1 75 82 00         [24]  774 	mov	dpl, #0x00
      007CE4 22               [24]  775 	ret
      007CE5                        776 00104$:
                                    777 ;	quantum/action_util.c:103: *bits ^= mask;
      007CE5 EC               [12]  778 	mov	a,r4
      007CE6 62 06            [12]  779 	xrl	ar6,a
      007CE8 12 82 0A         [24]  780 	lcall	_ak820_outline_0185
      007CEB EE               [12]  781 	mov	a,r6
      007CEC F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:104: return true;
      007CED 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:105: }
      007CF0 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      007CF1                        805 _change_owned:
      007CF1 E5 82            [12]  806 	mov	a,dpl
      007CF3 90 09 8C         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      007CF6 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      007CF7 90 09 8B         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007CFA E0               [24]  811 	movx	a,@dptr
      007CFB FF               [12]  812 	mov	r7,a
      007CFC C3               [12]  813 	clr	c
      007CFD 13               [12]  814 	rrc	a
      007CFE FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      007CFF 53 07 01         [24]  817 	anl	ar7,#0x01
      007D02 EF               [12]  818 	mov	a,r7
      007D03 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007D06                        820 00205$:
      007D06 92 1F            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007D08 B3               [12]  822 	cpl	c
      007D09 E4               [12]  823 	clr	a
      007D0A 33               [12]  824 	rlc	a
      007D0B F5 53            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007D0D EE               [12]  827 	mov	a,r6
      007D0E 60 06            [24]  828 	jz	00121$
      007D10 7D 79            [12]  829 	mov	r5,#_owned_weak_refs
      007D12 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      007D14 80 04            [24]  831 	sjmp	00122$
      007D16                        832 00121$:
      007D16 7D 71            [12]  833 	mov	r5,#_owned_mod_refs
      007D18 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007D1A                        835 00122$:
                                    836 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      007D1A 90 09 85         [24]  837 	mov	dptr,#_ak820_macro_primitive
      007D1D E0               [24]  838 	movx	a,@dptr
      007D1E 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      007D20 EE               [12]  841 	mov	a,r6
      007D21 24 83            [12]  842 	add	a, #_macro_mods
      007D23 FB               [12]  843 	mov	r3,a
      007D24 E4               [12]  844 	clr	a
      007D25 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007D27 12 49 67         [24]  846 	lcall	_ak820_outline_0056
                                    847 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007D2A E5 53            [12]  848 	mov	a,_change_owned_sloc1_1_0
      007D2C 60 0A            [24]  849 	jz	00123$
      007D2E 90 09 8C         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      007D31 E0               [24]  851 	movx	a,@dptr
      007D32 F9               [12]  852 	mov	r1,a
      007D33 EA               [12]  853 	mov	a,r2
      007D34 42 01            [12]  854 	orl	ar1,a
      007D36 80 07            [24]  855 	sjmp	00124$
      007D38                        856 00123$:
      007D38 90 09 8C         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      007D3B E0               [24]  858 	movx	a,@dptr
      007D3C F4               [12]  859 	cpl	a
      007D3D 5A               [12]  860 	anl	a,r2
      007D3E F9               [12]  861 	mov	r1,a
      007D3F                        862 00124$:
      007D3F 12 33 FC         [24]  863 	lcall	_ak820_outline_0122
      007D42 E9               [12]  864 	mov	a,r1
      007D43 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      007D44 E5 53            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007D46 60 06            [24]  868 	jz	00125$
      007D48 74 FF            [12]  869 	mov	a,#0xff
      007D4A 6A               [12]  870 	xrl	a,r2
      007D4B FC               [12]  871 	mov	r4,a
      007D4C 80 02            [24]  872 	sjmp	00126$
      007D4E                        873 00125$:
      007D4E 8A 04            [24]  874 	mov	ar4,r2
      007D50                        875 00126$:
      007D50 90 09 8C         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      007D53 E0               [24]  877 	movx	a,@dptr
      007D54 5C               [12]  878 	anl	a,r4
      007D55 F0               [24]  879 	movx	@dptr,a
      007D56                        880 00102$:
                                    881 ;	quantum/action_util.c:115: uint8_t result = 0;
      007D56 90 09 8D         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      007D59 E4               [12]  883 	clr	a
      007D5A F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007D5B 90 09 8E         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      007D5E 04               [12]  887 	inc	a
      007D5F F0               [24]  888 	movx	@dptr,a
      007D60 90 09 8C         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      007D63 E0               [24]  890 	movx	a,@dptr
      007D64 FC               [12]  891 	mov	r4,a
      007D65 7B 00            [12]  892 	mov	r3,#0x00
      007D67                        893 00117$:
      007D67 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      007D6A                        895 00210$:
      007D6A 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:117: if (mods & bit) {
      007D6C 90 09 8E         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      007D6F E0               [24]  899 	movx	a,@dptr
      007D70 5C               [12]  900 	anl	a,r4
      007D71 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      007D73 E5 53            [12]  903 	mov	a,_change_owned_sloc1_1_0
      007D75 60 0C            [24]  904 	jz	00106$
      007D77 EB               [12]  905 	mov	a,r3
      007D78 2D               [12]  906 	add	a, r5
      007D79 12 37 D6         [24]  907 	lcall	_ak820_outline_0014
      007D7C F8               [12]  908 	mov	r0,a
      007D7D 08               [12]  909 	inc	r0
      007D7E 12 81 BE         [24]  910 	lcall	_ak820_outline_0064
      007D81 80 0C            [24]  911 	sjmp	00109$
      007D83                        912 00106$:
                                    913 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      007D83 EB               [12]  914 	mov	a,r3
      007D84 2D               [12]  915 	add	a, r5
      007D85 12 37 D6         [24]  916 	lcall	_ak820_outline_0014
      007D88 F8               [12]  917 	mov	r0,a
      007D89 60 04            [24]  918 	jz	00109$
      007D8B 18               [12]  919 	dec	r0
      007D8C 12 81 BE         [24]  920 	lcall	_ak820_outline_0064
      007D8F                        921 00109$:
                                    922 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      007D8F EB               [12]  923 	mov	a,r3
      007D90 2D               [12]  924 	add	a, r5
      007D91 12 37 D6         [24]  925 	lcall	_ak820_outline_0014
      007D94 60 0B            [24]  926 	jz	00118$
      007D96 90 09 8E         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      007D99 E0               [24]  928 	movx	a,@dptr
      007D9A FA               [12]  929 	mov	r2,a
      007D9B 90 09 8D         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      007D9E E0               [24]  931 	movx	a,@dptr
      007D9F 4A               [12]  932 	orl	a,r2
      007DA0 F0               [24]  933 	movx	@dptr,a
      007DA1                        934 00118$:
                                    935 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007DA1 0B               [12]  936 	inc	r3
      007DA2 90 09 8E         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      007DA5 E0               [24]  938 	movx	a,@dptr
      007DA6 25 E0            [12]  939 	add	a,acc
      007DA8 F0               [24]  940 	movx	@dptr,a
      007DA9 80 BC            [24]  941 	sjmp	00117$
      007DAB                        942 00112$:
                                    943 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      007DAB EE               [12]  944 	mov	a,r6
      007DAC 60 09            [24]  945 	jz	00114$
      007DAE 90 09 8D         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      007DB1 E0               [24]  947 	movx	a,@dptr
      007DB2 90 09 82         [24]  948 	mov	dptr,#_owned_weak_mods
      007DB5 F0               [24]  949 	movx	@dptr,a
      007DB6 22               [24]  950 	ret
      007DB7                        951 00114$:
                                    952 ;	quantum/action_util.c:124: else owned_mods = result;
      007DB7 90 09 8D         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      007DBA E0               [24]  954 	movx	a,@dptr
      007DBB 90 09 81         [24]  955 	mov	dptr,#_owned_mods
      007DBE F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:125: }
      007DBF 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      007DC0                        968 _add_owned_mods:
      007DC0 E5 82            [12]  969 	mov	a,dpl
      007DC2 90 09 8F         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      007DC5 12 81 DE         [24]  971 	lcall	_ak820_outline_0113
      007DC8 74 01            [12]  972 	mov	a,#0x01
      007DCA F0               [24]  973 	movx	@dptr,a
      007DCB 8F 82            [24]  974 	mov	dpl, r7
      007DCD 02 7C F1         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      007DD0                        985 _del_owned_mods:
      007DD0 E5 82            [12]  986 	mov	a,dpl
      007DD2 90 09 90         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      007DD5 12 81 DE         [24]  988 	lcall	_ak820_outline_0113
      007DD8 E4               [12]  989 	clr	a
      007DD9 F0               [24]  990 	movx	@dptr,a
      007DDA 8F 82            [24]  991 	mov	dpl, r7
      007DDC 02 7C F1         [24]  992 	ljmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      007DDF                       1002 _add_owned_weak_mods:
      007DDF E5 82            [12] 1003 	mov	a,dpl
      007DE1 90 09 91         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      007DE4 12 81 DE         [24] 1005 	lcall	_ak820_outline_0113
      007DE7 74 03            [12] 1006 	mov	a,#0x03
      007DE9 F0               [24] 1007 	movx	@dptr,a
      007DEA 8F 82            [24] 1008 	mov	dpl, r7
      007DEC 02 7C F1         [24] 1009 	ljmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      007DEF                       1019 _del_owned_weak_mods:
      007DEF E5 82            [12] 1020 	mov	a,dpl
      007DF1 90 09 92         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      007DF4 12 81 DE         [24] 1022 	lcall	_ak820_outline_0113
      007DF7 74 02            [12] 1023 	mov	a,#0x02
      007DF9 F0               [24] 1024 	movx	@dptr,a
      007DFA 8F 82            [24] 1025 	mov	dpl, r7
      007DFC 02 7C F1         [24] 1026 	ljmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      007DFF                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007DFF 7F 00            [12] 1038 	mov	r7,#0x00
      007E01                       1039 00103$:
      007E01 BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      007E04                       1041 00122$:
      007E04 50 1A            [24] 1042 	jnc	00101$
      007E06 EF               [12] 1043 	mov	a,r7
      007E07 24 71            [12] 1044 	add	a, #_owned_mod_refs
      007E09 FD               [12] 1045 	mov	r5,a
      007E0A E4               [12] 1046 	clr	a
      007E0B 34 09            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      007E0D FE               [12] 1048 	mov	r6,a
      007E0E EF               [12] 1049 	mov	a,r7
      007E0F 24 79            [12] 1050 	add	a, #_owned_weak_refs
      007E11 F5 82            [12] 1051 	mov	dpl,a
      007E13 E4               [12] 1052 	clr	a
      007E14 34 09            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      007E16 F5 83            [12] 1054 	mov	dph,a
      007E18 E4               [12] 1055 	clr	a
      007E19 F0               [24] 1056 	movx	@dptr,a
      007E1A 12 81 E5         [24] 1057 	lcall	_ak820_outline_0119
      007E1D 0F               [12] 1058 	inc	r7
      007E1E 80 E1            [24] 1059 	sjmp	00103$
      007E20                       1060 00101$:
                                   1061 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007E20 90 09 84         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      007E23 E4               [12] 1063 	clr	a
      007E24 F0               [24] 1064 	movx	@dptr,a
      007E25 90 09 83         [24] 1065 	mov	dptr,#_macro_mods
      007E28 F0               [24] 1066 	movx	@dptr,a
      007E29 90 09 82         [24] 1067 	mov	dptr,#_owned_weak_mods
      007E2C F0               [24] 1068 	movx	@dptr,a
      007E2D 90 09 81         [24] 1069 	mov	dptr,#_owned_mods
      007E30 F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      007E31 90 09 86         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      007E34 04               [12] 1073 	inc	a
      007E35 F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:134: }
      007E36 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      007E37                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007E37 7F 00            [12] 1089 	mov	r7,#0x00
      007E39                       1090 00104$:
      007E39 EF               [12] 1091 	mov	a,r7
      007E3A 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      007E3C 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      007E3E EF               [12] 1095 	mov	a,r7
      007E3F 24 93            [12] 1096 	add	a, #_key_refs
      007E41 F5 82            [12] 1097 	mov	dpl,a
      007E43 E4               [12] 1098 	clr	a
      007E44 34 09            [12] 1099 	addc	a, #(_key_refs >> 8)
      007E46 12 7C 76         [24] 1100 	lcall	_ak820_outline_0158
      007E49 80 EE            [24] 1101 	sjmp	00104$
      007E4B                       1102 00101$:
                                   1103 ;	quantum/action_util.c:142: distinct_keys = 0;
      007E4B 90 0A 38         [24] 1104 	mov	dptr,#_distinct_keys
      007E4E E4               [12] 1105 	clr	a
      007E4F F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007E50 FF               [12] 1108 	mov	r7,a
      007E51                       1109 00107$:
      007E51 BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      007E54                       1111 00142$:
      007E54 50 0D            [24] 1112 	jnc	00109$
      007E56 EF               [12] 1113 	mov	a,r7
      007E57 24 39            [12] 1114 	add	a, #_macro_keys
      007E59 F5 82            [12] 1115 	mov	dpl,a
      007E5B E4               [12] 1116 	clr	a
      007E5C 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      007E5E 12 7C 76         [24] 1118 	lcall	_ak820_outline_0158
      007E61 80 EE            [24] 1119 	sjmp	00107$
      007E63                       1120 00109$:
                                   1121 ;	quantum/action_util.c:144: }
      007E63 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      007E64                       1137 _add_owned_key:
      007E64 E5 82            [12] 1138 	mov	a,dpl
      007E66 90 0A 4E         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      007E69 12 81 F6         [24] 1140 	lcall	_ak820_outline_0130
                                   1141 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007E6C 74 01            [12] 1142 	mov	a,#0x01
      007E6E F0               [24] 1143 	movx	@dptr,a
      007E6F 90 0A 39         [24] 1144 	mov	dptr,#_macro_keys
      007E72 C0 07            [24] 1145 	push	ar7
      007E74 12 7C 85         [24] 1146 	lcall	_ak820_macro_change
      007E77 E5 82            [12] 1147 	mov	a, dpl
      007E79 D0 07            [24] 1148 	pop	ar7
      007E7B 70 03            [24] 1149 	jnz	00102$
      007E7D F5 82            [12] 1150 	mov	dpl,a
      007E7F 22               [24] 1151 	ret
      007E80                       1152 00102$:
                                   1153 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      007E80 12 81 B0         [24] 1154 	lcall	_ak820_outline_0029
      007E83 FC               [12] 1155 	mov	r4,a
      007E84 04               [12] 1156 	inc	a
      007E85 12 81 E5         [24] 1157 	lcall	_ak820_outline_0119
      007E88 EC               [12] 1158 	mov	a,r4
      007E89 60 04            [24] 1159 	jz	00104$
      007E8B 75 82 00         [24] 1160 	mov	dpl, #0x00
      007E8E 22               [24] 1161 	ret
      007E8F                       1162 00104$:
                                   1163 ;	quantum/action_util.c:148: ++distinct_keys;
      007E8F 90 0A 38         [24] 1164 	mov	dptr,#_distinct_keys
      007E92 E0               [24] 1165 	movx	a,@dptr
      007E93 24 01            [12] 1166 	add	a, #0x01
      007E95 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007E96 90 0D 8B         [24] 1169 	mov	dptr,#_keyboard_protocol
      007E99 E0               [24] 1170 	movx	a,@dptr
      007E9A 60 11            [24] 1171 	jz	00106$
      007E9C 90 0A BD         [24] 1172 	mov	dptr,#_keymap_config
      007E9F E0               [24] 1173 	movx	a,@dptr
      007EA0 30 E7 0A         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007EA3 12 82 01         [24] 1176 	lcall	_ak820_outline_0172
      007EA6 12 70 59         [24] 1177 	lcall	_add_key_to_report
                                   1178 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007EA9 75 82 01         [24] 1179 	mov	dpl, #0x01
      007EAC 22               [24] 1180 	ret
      007EAD                       1181 00106$:
                                   1182 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007EAD 90 0A 38         [24] 1183 	mov	dptr,#_distinct_keys
      007EB0 E0               [24] 1184 	movx	a,@dptr
      007EB1 24 F9            [12] 1185 	add	a,#0xff - 0x06
      007EB3 50 17            [24] 1186 	jnc	00110$
                                   1187 ;	free result
                                   1188 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007EB5 7F 00            [12] 1189 	mov	r7,#0x00
      007EB7                       1190 00115$:
      007EB7 BF 06 00         [24] 1191 	cjne	r7,#0x06,00174$
      007EBA                       1192 00174$:
      007EBA 50 1E            [24] 1193 	jnc	00111$
      007EBC EF               [12] 1194 	mov	a,r7
      007EBD 24 A0            [12] 1195 	add	a, #(_actual_keyboard_report + 0x0002)
      007EBF F5 82            [12] 1196 	mov	dpl,a
      007EC1 E4               [12] 1197 	clr	a
      007EC2 34 0D            [12] 1198 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007EC4 F5 83            [12] 1199 	mov	dph,a
      007EC6 74 01            [12] 1200 	mov	a,#0x01
      007EC8 F0               [24] 1201 	movx	@dptr,a
      007EC9 0F               [12] 1202 	inc	r7
      007ECA 80 EB            [24] 1203 	sjmp	00115$
      007ECC                       1204 00110$:
                                   1205 ;	quantum/action_util.c:154: } else add_key(code);
      007ECC 90 0A 4E         [24] 1206 	mov	dptr,#_add_owned_key_code_10000_326
      007ECF E0               [24] 1207 	movx	a,@dptr
                                   1208 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007ED0 90 08 04         [24] 1209 	mov	dptr,#_add_key_to_report_PARM_2
      007ED3 F0               [24] 1210 	movx	@dptr,a
      007ED4 90 0D 9E         [24] 1211 	mov	dptr,#_actual_keyboard_report
      007ED7 12 70 59         [24] 1212 	lcall	_add_key_to_report
                                   1213 ;	quantum/action_util.c:154: } else add_key(code);
      007EDA                       1214 00111$:
                                   1215 ;	quantum/action_util.c:155: return true;
      007EDA 75 82 01         [24] 1216 	mov	dpl, #0x01
                                   1217 ;	quantum/action_util.c:156: }
      007EDD 22               [24] 1218 	ret
                                   1219 ;------------------------------------------------------------
                                   1220 ;Allocation info for local variables in function 'del_owned_key'
                                   1221 ;------------------------------------------------------------
                                   1222 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1223 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1224 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1225 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1226 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1227 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1228 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1229 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function del_owned_key
                                   1234 ;	-----------------------------------------
      007EDE                       1235 _del_owned_key:
      007EDE E5 82            [12] 1236 	mov	a,dpl
      007EE0 90 0A 4F         [24] 1237 	mov	dptr,#_del_owned_key_code_10000_341
      007EE3 12 81 F6         [24] 1238 	lcall	_ak820_outline_0130
                                   1239 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007EE6 E4               [12] 1240 	clr	a
      007EE7 F0               [24] 1241 	movx	@dptr,a
      007EE8 90 0A 39         [24] 1242 	mov	dptr,#_macro_keys
      007EEB C0 07            [24] 1243 	push	ar7
      007EED 12 7C 85         [24] 1244 	lcall	_ak820_macro_change
      007EF0 E5 82            [12] 1245 	mov	a, dpl
      007EF2 D0 07            [24] 1246 	pop	ar7
      007EF4 70 03            [24] 1247 	jnz	00102$
      007EF6 F5 82            [12] 1248 	mov	dpl,a
      007EF8 22               [24] 1249 	ret
      007EF9                       1250 00102$:
                                   1251 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      007EF9 12 81 B0         [24] 1252 	lcall	_ak820_outline_0029
      007EFC FC               [12] 1253 	mov	r4,a
      007EFD 60 07            [24] 1254 	jz	00103$
      007EFF 1C               [12] 1255 	dec	r4
      007F00 12 43 6A         [24] 1256 	lcall	_ak820_outline_0065
      007F03 EC               [12] 1257 	mov	a,r4
      007F04 60 04            [24] 1258 	jz	00104$
      007F06                       1259 00103$:
      007F06 75 82 00         [24] 1260 	mov	dpl, #0x00
      007F09 22               [24] 1261 	ret
      007F0A                       1262 00104$:
                                   1263 ;	quantum/action_util.c:160: --distinct_keys;
      007F0A 90 0A 38         [24] 1264 	mov	dptr,#_distinct_keys
      007F0D E0               [24] 1265 	movx	a,@dptr
      007F0E 14               [12] 1266 	dec	a
      007F0F F0               [24] 1267 	movx	@dptr,a
                                   1268 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007F10 90 0D 8B         [24] 1269 	mov	dptr,#_keyboard_protocol
      007F13 E0               [24] 1270 	movx	a,@dptr
      007F14 60 16            [24] 1271 	jz	00107$
      007F16 90 0A BD         [24] 1272 	mov	dptr,#_keymap_config
      007F19 E0               [24] 1273 	movx	a,@dptr
      007F1A 30 E7 0F         [24] 1274 	jnb	acc.7,00107$
                                   1275 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007F1D 90 08 07         [24] 1276 	mov	dptr,#_del_key_from_report_PARM_2
      007F20 EF               [12] 1277 	mov	a,r7
      007F21 F0               [24] 1278 	movx	@dptr,a
      007F22 90 0D 9E         [24] 1279 	mov	dptr,#_actual_keyboard_report
      007F25 12 70 8F         [24] 1280 	lcall	_del_key_from_report
                                   1281 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007F28 75 82 01         [24] 1282 	mov	dpl, #0x01
      007F2B 22               [24] 1283 	ret
      007F2C                       1284 00107$:
                                   1285 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007F2C 90 0A 38         [24] 1286 	mov	dptr,#_distinct_keys
      007F2F E0               [24] 1287 	movx	a,@dptr
      007F30 FF               [12] 1288 	mov  r7,a
      007F31 24 F9            [12] 1289 	add	a,#0xff - 0x06
      007F33 50 04            [24] 1290 	jnc	00110$
                                   1291 ;	free result
      007F35 75 82 01         [24] 1292 	mov	dpl, #0x01
      007F38 22               [24] 1293 	ret
      007F39                       1294 00110$:
                                   1295 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007F39 BF 06 1F         [24] 1296 	cjne	r7,#0x06,00115$
                                   1297 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007F3C 90 0D 9E         [24] 1298 	mov	dptr,#_actual_keyboard_report
      007F3F 12 70 C5         [24] 1299 	lcall	_clear_keys_from_report
                                   1300 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007F42 7F 04            [12] 1301 	mov	r7,#0x04
      007F44                       1302 00122$:
      007F44 EF               [12] 1303 	mov	a,r7
      007F45 24 5B            [12] 1304 	add	a,#0xff - 0xa4
      007F47 40 20            [24] 1305 	jc	00116$
                                   1306 ;	free result
      007F49 12 81 B0         [24] 1307 	lcall	_ak820_outline_0029
      007F4C 60 0A            [24] 1308 	jz	00123$
                                   1309 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007F4E 12 82 01         [24] 1310 	lcall	_ak820_outline_0172
      007F51 C0 07            [24] 1311 	push	ar7
      007F53 12 70 59         [24] 1312 	lcall	_add_key_to_report
      007F56 D0 07            [24] 1313 	pop	ar7
                                   1314 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007F58                       1315 00123$:
      007F58 0F               [12] 1316 	inc	r7
      007F59 80 E9            [24] 1317 	sjmp	00122$
      007F5B                       1318 00115$:
                                   1319 ;	quantum/action_util.c:169: } else del_key(code);
      007F5B 90 0A 4F         [24] 1320 	mov	dptr,#_del_owned_key_code_10000_341
      007F5E E0               [24] 1321 	movx	a,@dptr
                                   1322 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007F5F 90 08 07         [24] 1323 	mov	dptr,#_del_key_from_report_PARM_2
      007F62 F0               [24] 1324 	movx	@dptr,a
      007F63 90 0D 9E         [24] 1325 	mov	dptr,#_actual_keyboard_report
      007F66 12 70 8F         [24] 1326 	lcall	_del_key_from_report
                                   1327 ;	quantum/action_util.c:169: } else del_key(code);
      007F69                       1328 00116$:
                                   1329 ;	quantum/action_util.c:170: return true;
      007F69 75 82 01         [24] 1330 	mov	dpl, #0x01
                                   1331 ;	quantum/action_util.c:171: }
      007F6C 22               [24] 1332 	ret
                                   1333 ;------------------------------------------------------------
                                   1334 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1335 ;------------------------------------------------------------
                                   1336 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1337 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1338 ;------------------------------------------------------------
                                   1339 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1340 ;	-----------------------------------------
                                   1341 ;	 function clear_owned_usages
                                   1342 ;	-----------------------------------------
      007F6D                       1343 _clear_owned_usages:
                                   1344 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007F6D 7F 00            [12] 1345 	mov	r7,#0x00
      007F6F                       1346 00104$:
      007F6F BF 1E 00         [24] 1347 	cjne	r7,#0x1e,00141$
      007F72                       1348 00141$:
      007F72 50 14            [24] 1349 	jnc	00101$
      007F74 EF               [12] 1350 	mov	a,r7
      007F75 24 50            [12] 1351 	add	a, #_usage_refs
      007F77 FD               [12] 1352 	mov	r5,a
      007F78 E4               [12] 1353 	clr	a
      007F79 34 0A            [12] 1354 	addc	a, #(_usage_refs >> 8)
      007F7B FE               [12] 1355 	mov	r6,a
      007F7C EF               [12] 1356 	mov	a,r7
      007F7D 12 81 C5         [24] 1357 	lcall	_ak820_outline_0068
      007F80 E4               [12] 1358 	clr	a
      007F81 F0               [24] 1359 	movx	@dptr,a
      007F82 12 81 E5         [24] 1360 	lcall	_ak820_outline_0119
      007F85 0F               [12] 1361 	inc	r7
      007F86 80 E7            [24] 1362 	sjmp	00104$
      007F88                       1363 00101$:
                                   1364 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      007F88 90 0A 8D         [24] 1365 	mov	dptr,#(_usage_lengths + 0x0001)
      007F8B E4               [12] 1366 	clr	a
      007F8C F0               [24] 1367 	movx	@dptr,a
      007F8D 90 0A 8C         [24] 1368 	mov	dptr,#_usage_lengths
      007F90 F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007F91 FF               [12] 1371 	mov	r7,a
      007F92                       1372 00107$:
      007F92 BF 04 00         [24] 1373 	cjne	r7,#0x04,00143$
      007F95                       1374 00143$:
      007F95 50 0D            [24] 1375 	jnc	00109$
      007F97 EF               [12] 1376 	mov	a,r7
      007F98 24 8E            [12] 1377 	add	a, #_macro_usages
      007F9A F5 82            [12] 1378 	mov	dpl,a
      007F9C E4               [12] 1379 	clr	a
      007F9D 34 0A            [12] 1380 	addc	a, #(_macro_usages >> 8)
      007F9F 12 7C 76         [24] 1381 	lcall	_ak820_outline_0158
      007FA2 80 EE            [24] 1382 	sjmp	00107$
      007FA4                       1383 00109$:
                                   1384 ;	quantum/action_util.c:185: }
      007FA4 22               [24] 1385 	ret
                                   1386 ;------------------------------------------------------------
                                   1387 ;Allocation info for local variables in function 'owned_usage_key'
                                   1388 ;------------------------------------------------------------
                                   1389 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1390 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1391 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1392 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1393 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1394 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1395 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1396 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1397 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1398 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1399 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function owned_usage_key
                                   1404 ;	-----------------------------------------
      007FA5                       1405 _owned_usage_key:
      007FA5 E5 82            [12] 1406 	mov	a,dpl
      007FA7 90 0A 93         [24] 1407 	mov	dptr,#_owned_usage_key_code_10000_368
      007FAA F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      007FAB E0               [24] 1410 	movx	a,@dptr
      007FAC FF               [12] 1411 	mov	r7,a
      007FAD BF A8 00         [24] 1412 	cjne	r7,#0xa8,00244$
      007FB0                       1413 00244$:
      007FB0 B3               [12] 1414 	cpl	c
      007FB1 92 20            [24] 1415 	mov	_owned_usage_key_sloc0_1_0,c
      007FB3 E4               [12] 1416 	clr	a
      007FB4 33               [12] 1417 	rlc	a
      007FB5 FF               [12] 1418 	mov	r7,a
      007FB6 90 0A 96         [24] 1419 	mov	dptr,#_owned_usage_key_which_10000_369
      007FB9 F0               [24] 1420 	movx	@dptr,a
                                   1421 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      007FBA EF               [12] 1422 	mov	a,r7
      007FBB 60 02            [24] 1423 	jz	00129$
      007FBD 74 03            [12] 1424 	mov	a,#0x03
      007FBF                       1425 00129$:
      007FBF FE               [12] 1426 	mov	r6,a
                                   1427 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      007FC0 EF               [12] 1428 	mov	a,r7
      007FC1 24 8C            [12] 1429 	add	a, #_usage_lengths
      007FC3 FD               [12] 1430 	mov	r5,a
      007FC4 E4               [12] 1431 	clr	a
      007FC5 34 0A            [12] 1432 	addc	a, #(_usage_lengths >> 8)
      007FC7 FF               [12] 1433 	mov	r7,a
      007FC8 12 82 0A         [24] 1434 	lcall	_ak820_outline_0185
      007FCB E0               [24] 1435 	movx	a,@dptr
      007FCC FC               [12] 1436 	mov	r4,a
                                   1437 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      007FCD 90 0A 93         [24] 1438 	mov	dptr,#_owned_usage_key_code_10000_368
      007FD0 E0               [24] 1439 	movx	a,@dptr
      007FD1 24 5B            [12] 1440 	add	a,#0x5b
      007FD3 FB               [12] 1441 	mov	r3,a
                                   1442 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007FD4 90 0A 92         [24] 1443 	mov	dptr,#_owned_usage_key_PARM_2
      007FD7 E0               [24] 1444 	movx	a,@dptr
      007FD8 FA               [12] 1445 	mov	r2,a
      007FD9 90 09 87         [24] 1446 	mov	dptr,#_ak820_macro_change_PARM_2
      007FDC EB               [12] 1447 	mov	a,r3
      007FDD F0               [24] 1448 	movx	@dptr,a
      007FDE 90 09 88         [24] 1449 	mov	dptr,#_ak820_macro_change_PARM_3
      007FE1 EA               [12] 1450 	mov	a,r2
      007FE2 F0               [24] 1451 	movx	@dptr,a
      007FE3 90 0A 8E         [24] 1452 	mov	dptr,#_macro_usages
      007FE6 C0 07            [24] 1453 	push	ar7
      007FE8 C0 06            [24] 1454 	push	ar6
      007FEA C0 05            [24] 1455 	push	ar5
      007FEC C0 04            [24] 1456 	push	ar4
      007FEE C0 03            [24] 1457 	push	ar3
      007FF0 C0 02            [24] 1458 	push	ar2
      007FF2 12 7C 85         [24] 1459 	lcall	_ak820_macro_change
      007FF5 E5 82            [12] 1460 	mov	a, dpl
      007FF7 D0 02            [24] 1461 	pop	ar2
      007FF9 D0 03            [24] 1462 	pop	ar3
      007FFB D0 04            [24] 1463 	pop	ar4
      007FFD D0 05            [24] 1464 	pop	ar5
      007FFF D0 06            [24] 1465 	pop	ar6
      008001 D0 07            [24] 1466 	pop	ar7
      008003 70 01            [24] 1467 	jnz	00102$
      008005 22               [24] 1468 	ret
      008006                       1469 00102$:
                                   1470 ;	quantum/action_util.c:192: if (pressed) {
      008006 EA               [12] 1471 	mov	a,r2
      008007 60 1B            [24] 1472 	jz	00115$
                                   1473 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      008009 12 81 CF         [24] 1474 	lcall	_ak820_outline_0074
      00800C 04               [12] 1475 	inc	a
      00800D 12 6D DE         [24] 1476 	lcall	_ak820_outline_0136
      008010 E8               [12] 1477 	mov	a,r0
      008011 60 01            [24] 1478 	jz	00104$
      008013 22               [24] 1479 	ret
      008014                       1480 00104$:
                                   1481 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      008014 90 0A 97         [24] 1482 	mov	dptr,#_owned_usage_key_count_10000_369
      008017 EC               [12] 1483 	mov	a,r4
      008018 04               [12] 1484 	inc	a
      008019 F0               [24] 1485 	movx	@dptr,a
      00801A EC               [12] 1486 	mov	a,r4
      00801B 2E               [12] 1487 	add	a, r6
      00801C 12 81 C5         [24] 1488 	lcall	_ak820_outline_0068
      00801F EB               [12] 1489 	mov	a,r3
      008020 F0               [24] 1490 	movx	@dptr,a
      008021 02 80 85         [24] 1491 	ljmp	00116$
      008024                       1492 00115$:
                                   1493 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      008024 12 81 CF         [24] 1494 	lcall	_ak820_outline_0074
      008027 60 07            [24] 1495 	jz	00105$
      008029 18               [12] 1496 	dec	r0
      00802A 12 81 BE         [24] 1497 	lcall	_ak820_outline_0064
      00802D E8               [12] 1498 	mov	a,r0
      00802E 60 01            [24] 1499 	jz	00106$
      008030                       1500 00105$:
      008030 22               [24] 1501 	ret
      008031                       1502 00106$:
                                   1503 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      008031 7A 00            [12] 1504 	mov	r2,#0x00
      008033                       1505 00108$:
      008033 EA               [12] 1506 	mov	a,r2
      008034 2E               [12] 1507 	add	a, r6
      008035 12 81 C5         [24] 1508 	lcall	_ak820_outline_0068
      008038 E0               [24] 1509 	movx	a,@dptr
      008039 B5 03 02         [24] 1510 	cjne	a,ar3,00251$
      00803C 80 03            [24] 1511 	sjmp	00167$
      00803E                       1512 00251$:
      00803E 0A               [12] 1513 	inc	r2
      00803F 80 F2            [24] 1514 	sjmp	00108$
      008041                       1515 00167$:
      008041 90 0A 98         [24] 1516 	mov	dptr,#_owned_usage_key_pos_30001_376
      008044 EA               [12] 1517 	mov	a,r2
      008045 F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	quantum/action_util.c:199: --count;
      008046 1C               [12] 1520 	dec	r4
      008047 90 0A 97         [24] 1521 	mov	dptr,#_owned_usage_key_count_10000_369
      00804A EC               [12] 1522 	mov	a,r4
      00804B F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      00804C 8A 03            [24] 1525 	mov	ar3,r2
      00804E                       1526 00125$:
      00804E C3               [12] 1527 	clr	c
      00804F EB               [12] 1528 	mov	a,r3
      008050 9C               [12] 1529 	subb	a,r4
      008051 50 23            [24] 1530 	jnc	00111$
      008053 C0 05            [24] 1531 	push	ar5
      008055 C0 07            [24] 1532 	push	ar7
      008057 EB               [12] 1533 	mov	a,r3
      008058 2E               [12] 1534 	add	a, r6
      008059 FA               [12] 1535 	mov	r2,a
      00805A 24 6E            [12] 1536 	add	a, #_usage_order
      00805C F8               [12] 1537 	mov	r0,a
      00805D E4               [12] 1538 	clr	a
      00805E 34 0A            [12] 1539 	addc	a, #(_usage_order >> 8)
      008060 F9               [12] 1540 	mov	r1,a
      008061 0A               [12] 1541 	inc	r2
      008062 EA               [12] 1542 	mov	a,r2
      008063 33               [12] 1543 	rlc	a
      008064 95 E0            [12] 1544 	subb	a,acc
      008066 FF               [12] 1545 	mov	r7,a
      008067 EA               [12] 1546 	mov	a,r2
      008068 12 81 EB         [24] 1547 	lcall	_ak820_outline_0124
      00806B 12 38 70         [24] 1548 	lcall	_ak820_outline_0152
      00806E F0               [24] 1549 	movx	@dptr,a
      00806F 0B               [12] 1550 	inc	r3
      008070 D0 07            [24] 1551 	pop	ar7
      008072 D0 05            [24] 1552 	pop	ar5
      008074 80 D8            [24] 1553 	sjmp	00125$
      008076                       1554 00111$:
                                   1555 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      008076 12 82 0A         [24] 1556 	lcall	_ak820_outline_0185
      008079 EC               [12] 1557 	mov	a,r4
      00807A F0               [24] 1558 	movx	@dptr,a
                                   1559 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      00807B 90 0A 98         [24] 1560 	mov	dptr,#_owned_usage_key_pos_30001_376
      00807E E0               [24] 1561 	movx	a,@dptr
      00807F B5 04 02         [24] 1562 	cjne	a,ar4,00253$
      008082 80 01            [24] 1563 	sjmp	00116$
      008084                       1564 00253$:
      008084 22               [24] 1565 	ret
      008085                       1566 00116$:
                                   1567 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      008085 90 0A 97         [24] 1568 	mov	dptr,#_owned_usage_key_count_10000_369
      008088 E0               [24] 1569 	movx	a,@dptr
      008089 FC               [12] 1570 	mov	r4,a
      00808A 12 82 0A         [24] 1571 	lcall	_ak820_outline_0185
      00808D F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      00808E EC               [12] 1574 	mov	a,r4
      00808F 60 15            [24] 1575 	jz	00131$
      008091 EC               [12] 1576 	mov	a,r4
      008092 2E               [12] 1577 	add	a, r6
      008093 FE               [12] 1578 	mov	r6,a
      008094 1E               [12] 1579 	dec	r6
      008095 EE               [12] 1580 	mov	a,r6
      008096 33               [12] 1581 	rlc	a
      008097 95 E0            [12] 1582 	subb	a,acc
      008099 FF               [12] 1583 	mov	r7,a
      00809A EE               [12] 1584 	mov	a,r6
      00809B 12 81 EB         [24] 1585 	lcall	_ak820_outline_0124
      00809E 24 A5            [12] 1586 	add	a,#0xa5
      0080A0 FE               [12] 1587 	mov	r6,a
      0080A1 33               [12] 1588 	rlc	a
      0080A2 95 E0            [12] 1589 	subb	a,acc
      0080A4 80 02            [24] 1590 	sjmp	00132$
      0080A6                       1591 00131$:
      0080A6 7E 00            [12] 1592 	mov	r6,#0x00
      0080A8                       1593 00132$:
      0080A8 90 0A 93         [24] 1594 	mov	dptr,#_owned_usage_key_code_10000_368
      0080AB EE               [12] 1595 	mov	a,r6
      0080AC F0               [24] 1596 	movx	@dptr,a
                                   1597 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      0080AD 90 0A 96         [24] 1598 	mov	dptr,#_owned_usage_key_which_10000_369
      0080B0 E0               [24] 1599 	movx	a,@dptr
      0080B1 60 18            [24] 1600 	jz	00118$
      0080B3 EE               [12] 1601 	mov	a,r6
      0080B4 60 0B            [24] 1602 	jz	00133$
      0080B6 8E 82            [24] 1603 	mov	dpl, r6
      0080B8 12 6F 17         [24] 1604 	lcall	_KEYCODE2CONSUMER
      0080BB AD 82            [24] 1605 	mov	r5, dpl
      0080BD AF 83            [24] 1606 	mov	r7, dph
      0080BF 80 04            [24] 1607 	sjmp	00134$
      0080C1                       1608 00133$:
      0080C1 7D 00            [12] 1609 	mov	r5,#0x00
      0080C3 7F 00            [12] 1610 	mov	r7,#0x00
      0080C5                       1611 00134$:
      0080C5 12 82 0A         [24] 1612 	lcall	_ak820_outline_0185
      0080C8 02 6E D1         [24] 1613 	ljmp	_host_consumer_send
      0080CB                       1614 00118$:
                                   1615 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      0080CB EE               [12] 1616 	mov	a,r6
      0080CC 60 22            [24] 1617 	jz	00135$
                                   1618 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      0080CE BE A5 00         [24] 1619 	cjne	r6,#0xa5,00258$
      0080D1                       1620 00258$:
      0080D1 40 05            [24] 1621 	jc	00121$
      0080D3 EE               [12] 1622 	mov	a,r6
      0080D4 24 58            [12] 1623 	add	a,#0xff - 0xa7
      0080D6 50 08            [24] 1624 	jnc	00122$
                                   1625 ;	free result
      0080D8                       1626 00121$:
      0080D8 90 0A 94         [24] 1627 	mov	dptr,#_owned_usage_key___200000085_20000_369
      0080DB 12 50 0E         [24] 1628 	lcall	_ak820_outline_0166
      0080DE 80 09            [24] 1629 	sjmp	00123$
      0080E0                       1630 00122$:
                                   1631 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      0080E0 74 DC            [12] 1632 	mov	a,#0xdc
      0080E2 2E               [12] 1633 	add	a, r6
      0080E3 90 0A 94         [24] 1634 	mov	dptr,#_owned_usage_key___200000085_20000_369
      0080E6 12 38 60         [24] 1635 	lcall	_ak820_outline_0123
                                   1636 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      0080E9                       1637 00123$:
      0080E9 90 0A 94         [24] 1638 	mov	dptr,#_owned_usage_key___200000085_20000_369
      0080EC E0               [24] 1639 	movx	a,@dptr
      0080ED FF               [12] 1640 	mov	r7,a
      0080EE 80 02            [24] 1641 	sjmp	00136$
      0080F0                       1642 00135$:
      0080F0 7F 00            [12] 1643 	mov	r7,#0x00
      0080F2                       1644 00136$:
      0080F2 7E 00            [12] 1645 	mov	r6,#0x00
      0080F4 12 43 AF         [24] 1646 	lcall	_ak820_outline_0153
                                   1647 ;	quantum/action_util.c:208: }
      0080F7 02 6E A1         [24] 1648 	ljmp	_host_system_send
                                   1649 ;------------------------------------------------------------
                                   1650 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1651 ;------------------------------------------------------------
                                   1652 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1653 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1654 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1655 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1656 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1657 ;------------------------------------------------------------
                                   1658 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1659 ;	-----------------------------------------
                                   1660 ;	 function send_keyboard_report
                                   1661 ;	-----------------------------------------
      0080FA                       1662 _send_keyboard_report:
                                   1663 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      0080FA 90 0D 9C         [24] 1664 	mov	dptr,#_real_mods
      0080FD E0               [24] 1665 	movx	a,@dptr
      0080FE FF               [12] 1666 	mov	r7,a
      0080FF 90 0D 9E         [24] 1667 	mov	dptr,#_actual_keyboard_report
      008102 F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      008103 90 0D 9D         [24] 1670 	mov	dptr,#_weak_mods
      008106 E0               [24] 1671 	movx	a,@dptr
      008107 42 07            [12] 1672 	orl	ar7,a
      008109 90 0D 9E         [24] 1673 	mov	dptr,#_actual_keyboard_report
      00810C EF               [12] 1674 	mov	a,r7
      00810D F0               [24] 1675 	movx	@dptr,a
                                   1676 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      00810E 90 09 82         [24] 1677 	mov	dptr,#_owned_weak_mods
      008111 E0               [24] 1678 	movx	a,@dptr
      008112 FE               [12] 1679 	mov	r6,a
      008113 90 09 81         [24] 1680 	mov	dptr,#_owned_mods
      008116 E0               [24] 1681 	movx	a,@dptr
      008117 4E               [12] 1682 	orl	a,r6
      008118 42 07            [12] 1683 	orl	ar7,a
      00811A 90 0D 9E         [24] 1684 	mov	dptr,#_actual_keyboard_report
      00811D EF               [12] 1685 	mov	a,r7
      00811E F0               [24] 1686 	movx	@dptr,a
                                   1687 ;	quantum/action_util.c:515: bool changed = false;
      00811F 90 0A BA         [24] 1688 	mov	dptr,#_send_keyboard_report_changed_10001_388
      008122 E4               [12] 1689 	clr	a
      008123 F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:517: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1692 ;	quantum/action_util.c:518: const uint8_t __xdata *src = (const uint8_t __xdata *)AK820_REPORT_OUT;
                                   1693 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008124 FF               [12] 1694 	mov	r7,a
      008125                       1695 00107$:
      008125 BF 20 00         [24] 1696 	cjne	r7,#0x20,00140$
      008128                       1697 00140$:
      008128 50 2B            [24] 1698 	jnc	00103$
                                   1699 ;	quantum/action_util.c:524: if (dest[i] != src[i]) {
      00812A EF               [12] 1700 	mov	a,r7
      00812B 24 9A            [12] 1701 	add	a, #_send_keyboard_report_last_report_10001_388
      00812D FD               [12] 1702 	mov	r5,a
      00812E E4               [12] 1703 	clr	a
      00812F 34 0A            [12] 1704 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      008131 FE               [12] 1705 	mov	r6,a
      008132 12 49 75         [24] 1706 	lcall	_ak820_outline_0075
      008135 EF               [12] 1707 	mov	a,r7
      008136 24 9E            [12] 1708 	add	a, #_actual_keyboard_report
      008138 F5 82            [12] 1709 	mov	dpl,a
      00813A E4               [12] 1710 	clr	a
      00813B 34 0D            [12] 1711 	addc	a, #(_actual_keyboard_report >> 8)
      00813D F5 83            [12] 1712 	mov	dph,a
      00813F E0               [24] 1713 	movx	a,@dptr
      008140 FB               [12] 1714 	mov	r3,a
      008141 EC               [12] 1715 	mov	a,r4
      008142 B5 03 02         [24] 1716 	cjne	a,ar3,00142$
      008145 80 0B            [24] 1717 	sjmp	00108$
      008147                       1718 00142$:
                                   1719 ;	quantum/action_util.c:525: dest[i] = src[i];
      008147 12 38 65         [24] 1720 	lcall	_ak820_outline_0132
      00814A EB               [12] 1721 	mov	a,r3
      00814B F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	quantum/action_util.c:526: changed = true;
      00814C 90 0A BA         [24] 1724 	mov	dptr,#_send_keyboard_report_changed_10001_388
      00814F 74 01            [12] 1725 	mov	a,#0x01
      008151 F0               [24] 1726 	movx	@dptr,a
      008152                       1727 00108$:
                                   1728 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008152 0F               [12] 1729 	inc	r7
      008153 80 D0            [24] 1730 	sjmp	00107$
      008155                       1731 00103$:
                                   1732 ;	quantum/action_util.c:529: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      008155 90 0A BA         [24] 1733 	mov	dptr,#_send_keyboard_report_changed_10001_388
      008158 E0               [24] 1734 	movx	a,@dptr
      008159 60 09            [24] 1735 	jz	00109$
      00815B 90 0D 9E         [24] 1736 	mov	dptr,#_actual_keyboard_report
      00815E 75 F0 00         [24] 1737 	mov	b, #0x00
                                   1738 ;	quantum/action_util.c:538: }
      008161 02 6E 16         [24] 1739 	ljmp	_host_keyboard_send
      008164                       1740 00109$:
      008164 22               [24] 1741 	ret
                                   1742 ;------------------------------------------------------------
                                   1743 ;Allocation info for local variables in function 'get_mods'
                                   1744 ;------------------------------------------------------------
                                   1745 ;	quantum/action_util.c:544: uint8_t get_mods(void) {
                                   1746 ;	-----------------------------------------
                                   1747 ;	 function get_mods
                                   1748 ;	-----------------------------------------
      008165                       1749 _get_mods:
      008165 C0 07            [24] 1750 	push	ar7
                                   1751 ;	quantum/action_util.c:549: ;
      008167 90 09 81         [24] 1752 	mov	dptr,#_owned_mods
      00816A E0               [24] 1753 	movx	a,@dptr
      00816B FF               [12] 1754 	mov	r7,a
      00816C 90 0D 9C         [24] 1755 	mov	dptr,#_real_mods
      00816F 12 7C 70         [24] 1756 	lcall	_ak820_outline_0138
                                   1757 ;	quantum/action_util.c:550: }
      008172 D0 07            [24] 1758 	pop	ar7
      008174 22               [24] 1759 	ret
                                   1760 ;------------------------------------------------------------
                                   1761 ;Allocation info for local variables in function 'add_mods'
                                   1762 ;------------------------------------------------------------
                                   1763 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1764 ;------------------------------------------------------------
                                   1765 ;	quantum/action_util.c:555: void add_mods(uint8_t mods) {
                                   1766 ;	-----------------------------------------
                                   1767 ;	 function clear_mods
                                   1768 ;	-----------------------------------------
      008175                       1769 _clear_mods:
                                   1770 ;	quantum/action_util.c:577: real_mods = 0;
      008175 90 0D 9C         [24] 1771 	mov	dptr,#_real_mods
      008178 E4               [12] 1772 	clr	a
      008179 F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	quantum/action_util.c:578: }
      00817A 22               [24] 1775 	ret
                                   1776 ;------------------------------------------------------------
                                   1777 ;Allocation info for local variables in function 'get_weak_mods'
                                   1778 ;------------------------------------------------------------
                                   1779 ;	quantum/action_util.c:584: uint8_t get_weak_mods(void) {
                                   1780 ;	-----------------------------------------
                                   1781 ;	 function get_weak_mods
                                   1782 ;	-----------------------------------------
      00817B                       1783 _get_weak_mods:
      00817B C0 07            [24] 1784 	push	ar7
                                   1785 ;	quantum/action_util.c:589: ;
      00817D 90 09 82         [24] 1786 	mov	dptr,#_owned_weak_mods
      008180 E0               [24] 1787 	movx	a,@dptr
      008181 FF               [12] 1788 	mov	r7,a
      008182 90 0D 9D         [24] 1789 	mov	dptr,#_weak_mods
      008185 12 7C 70         [24] 1790 	lcall	_ak820_outline_0138
                                   1791 ;	quantum/action_util.c:590: }
      008188 D0 07            [24] 1792 	pop	ar7
      00818A 22               [24] 1793 	ret
                                   1794 ;------------------------------------------------------------
                                   1795 ;Allocation info for local variables in function 'add_weak_mods'
                                   1796 ;------------------------------------------------------------
                                   1797 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action_util.c:595: void add_weak_mods(uint8_t mods) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function add_weak_mods
                                   1802 ;	-----------------------------------------
      00818B                       1803 _add_weak_mods:
      00818B E5 82            [12] 1804 	mov	a,dpl
      00818D 90 0A BB         [24] 1805 	mov	dptr,#_add_weak_mods_mods_10000_406
      008190 F0               [24] 1806 	movx	@dptr,a
                                   1807 ;	quantum/action_util.c:596: weak_mods |= mods;
      008191 E0               [24] 1808 	movx	a,@dptr
      008192 FF               [12] 1809 	mov	r7,a
      008193 90 0D 9D         [24] 1810 	mov	dptr,#_weak_mods
      008196 E0               [24] 1811 	movx	a,@dptr
      008197 4F               [12] 1812 	orl	a,r7
      008198 F0               [24] 1813 	movx	@dptr,a
                                   1814 ;	quantum/action_util.c:597: }
      008199 22               [24] 1815 	ret
                                   1816 ;------------------------------------------------------------
                                   1817 ;Allocation info for local variables in function 'del_weak_mods'
                                   1818 ;------------------------------------------------------------
                                   1819 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1820 ;------------------------------------------------------------
                                   1821 ;	quantum/action_util.c:602: void del_weak_mods(uint8_t mods) {
                                   1822 ;	-----------------------------------------
                                   1823 ;	 function del_weak_mods
                                   1824 ;	-----------------------------------------
      00819A                       1825 _del_weak_mods:
      00819A E5 82            [12] 1826 	mov	a,dpl
      00819C 90 0A BC         [24] 1827 	mov	dptr,#_del_weak_mods_mods_10000_408
      00819F F0               [24] 1828 	movx	@dptr,a
                                   1829 ;	quantum/action_util.c:603: weak_mods &= ~mods;
      0081A0 E0               [24] 1830 	movx	a,@dptr
      0081A1 F4               [12] 1831 	cpl	a
      0081A2 FF               [12] 1832 	mov	r7,a
      0081A3 90 0D 9D         [24] 1833 	mov	dptr,#_weak_mods
      0081A6 E0               [24] 1834 	movx	a,@dptr
      0081A7 5F               [12] 1835 	anl	a,r7
      0081A8 F0               [24] 1836 	movx	@dptr,a
                                   1837 ;	quantum/action_util.c:604: }
      0081A9 22               [24] 1838 	ret
                                   1839 ;------------------------------------------------------------
                                   1840 ;Allocation info for local variables in function 'set_weak_mods'
                                   1841 ;------------------------------------------------------------
                                   1842 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1843 ;------------------------------------------------------------
                                   1844 ;	quantum/action_util.c:609: void set_weak_mods(uint8_t mods) {
                                   1845 ;	-----------------------------------------
                                   1846 ;	 function clear_weak_mods
                                   1847 ;	-----------------------------------------
      0081AA                       1848 _clear_weak_mods:
                                   1849 ;	quantum/action_util.c:617: weak_mods = 0;
      0081AA 90 0D 9D         [24] 1850 	mov	dptr,#_weak_mods
      0081AD E4               [12] 1851 	clr	a
      0081AE F0               [24] 1852 	movx	@dptr,a
                                   1853 ;	quantum/action_util.c:618: }
      0081AF 22               [24] 1854 	ret
                                   1855 ;------------------------------------------------------------
                                   1856 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1857 ;------------------------------------------------------------
                                   1858 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1859 ;------------------------------------------------------------
                                   1860 ;	quantum/action_util.c:700: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1861 ;	-----------------------------------------
                                   1862 	.area CSEG    (CODE)
                                   1863 	.area CONST   (CODE)
                                   1864 	.area XINIT   (CODE)
      00C0B3                       1865 __xinit__real_mods:
      00C0B3 00                    1866 	.db #0x00	; 0
      00C0B4                       1867 __xinit__weak_mods:
      00C0B4 00                    1868 	.db #0x00	; 0
      00C0B5                       1869 __xinit__actual_keyboard_report:
      00C0B5 00                    1870 	.db #0x00	; 0
      00C0B6 00                    1871 	.db #0x00	; 0
      00C0B7 00                    1872 	.db #0x00	; 0
      00C0B8 00                    1873 	.db #0x00	; 0
      00C0B9 00                    1874 	.db #0x00	; 0
      00C0BA 00                    1875 	.db #0x00	; 0
      00C0BB 00                    1876 	.db #0x00	; 0
      00C0BC 00                    1877 	.db #0x00	; 0
      00C0BD 00                    1878 	.db 0x00
      00C0BE 00                    1879 	.db 0x00
      00C0BF 00                    1880 	.db 0x00
      00C0C0 00                    1881 	.db 0x00
      00C0C1 00                    1882 	.db 0x00
      00C0C2 00                    1883 	.db 0x00
      00C0C3 00                    1884 	.db 0x00
      00C0C4 00                    1885 	.db 0x00
      00C0C5 00                    1886 	.db 0x00
      00C0C6 00                    1887 	.db 0x00
      00C0C7 00                    1888 	.db 0x00
      00C0C8 00                    1889 	.db 0x00
      00C0C9 00                    1890 	.db 0x00
      00C0CA 00                    1891 	.db 0x00
      00C0CB 00                    1892 	.db 0x00
      00C0CC 00                    1893 	.db 0x00
      00C0CD 00                    1894 	.db 0x00
      00C0CE 00                    1895 	.db 0x00
      00C0CF 00                    1896 	.db 0x00
      00C0D0 00                    1897 	.db 0x00
      00C0D1 00                    1898 	.db 0x00
      00C0D2 00                    1899 	.db 0x00
      00C0D3 00                    1900 	.db 0x00
      00C0D4 00                    1901 	.db 0x00
                                   1902 	.area CABS    (ABS,CODE)
                                   1903 
                                   1904 ; Experimental exact instruction outlining.
                                   1905 	.globl _ak820_outline_0014
                                   1906 	.globl _ak820_outline_0029
                                   1907 	.globl _ak820_outline_0056
                                   1908 	.globl _ak820_outline_0060
                                   1909 	.globl _ak820_outline_0063
                                   1910 	.globl _ak820_outline_0064
                                   1911 	.globl _ak820_outline_0065
                                   1912 	.globl _ak820_outline_0068
                                   1913 	.globl _ak820_outline_0074
                                   1914 	.globl _ak820_outline_0075
                                   1915 	.globl _ak820_outline_0103
                                   1916 	.globl _ak820_outline_0104
                                   1917 	.globl _ak820_outline_0113
                                   1918 	.globl _ak820_outline_0119
                                   1919 	.globl _ak820_outline_0122
                                   1920 	.globl _ak820_outline_0123
                                   1921 	.globl _ak820_outline_0124
                                   1922 	.globl _ak820_outline_0130
                                   1923 	.globl _ak820_outline_0132
                                   1924 	.globl _ak820_outline_0136
                                   1925 	.globl _ak820_outline_0138
                                   1926 	.globl _ak820_outline_0152
                                   1927 	.globl _ak820_outline_0153
                                   1928 	.globl _ak820_outline_0158
                                   1929 	.globl _ak820_outline_0166
                                   1930 	.globl _ak820_outline_0172
                                   1931 	.globl _ak820_outline_0183
                                   1932 	.globl _ak820_outline_0185
                                   1933 
                                   1934 	.area CSEG (CODE)
                                   1935 ; function ak820_outline_0029
      0081B0                       1936 _ak820_outline_0029:
      0081B0 EF               [12] 1937 	mov	a,r7
      0081B1 24 93            [12] 1938 	add	a,#_key_refs
      0081B3 FD               [12] 1939 	mov	r5,a
      0081B4 E4               [12] 1940 	clr	a
      0081B5 34 09            [12] 1941 	addc	a,#(_key_refs>>8)
      0081B7 FE               [12] 1942 	mov	r6,a
      0081B8 8D 82            [24] 1943 	mov	dpl,r5
      0081BA 8E 83            [24] 1944 	mov	dph,r6
      0081BC E0               [24] 1945 	movx	a,@dptr
      0081BD 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0064
      0081BE                       1950 _ak820_outline_0064:
      0081BE 89 82            [24] 1951 	mov	dpl,r1
      0081C0 8A 83            [24] 1952 	mov	dph,r2
      0081C2 E8               [12] 1953 	mov	a,r0
      0081C3 F0               [24] 1954 	movx	@dptr,a
      0081C4 22               [24] 1955 	ret
                                   1956 
                                   1957 	.area CSEG (CODE)
                                   1958 ; function ak820_outline_0068
      0081C5                       1959 _ak820_outline_0068:
      0081C5 24 6E            [12] 1960 	add	a,#_usage_order
      0081C7 F5 82            [12] 1961 	mov	dpl,a
      0081C9 E4               [12] 1962 	clr	a
      0081CA 34 0A            [12] 1963 	addc	a,#(_usage_order>>8)
      0081CC F5 83            [12] 1964 	mov	dph,a
      0081CE 22               [24] 1965 	ret
                                   1966 
                                   1967 	.area CSEG (CODE)
                                   1968 ; function ak820_outline_0074
      0081CF                       1969 _ak820_outline_0074:
      0081CF EB               [12] 1970 	mov	a,r3
      0081D0 24 50            [12] 1971 	add	a,#_usage_refs
      0081D2 F9               [12] 1972 	mov	r1,a
      0081D3 E4               [12] 1973 	clr	a
      0081D4 34 0A            [12] 1974 	addc	a,#(_usage_refs>>8)
      0081D6 FA               [12] 1975 	mov	r2,a
      0081D7 89 82            [24] 1976 	mov	dpl,r1
      0081D9 8A 83            [24] 1977 	mov	dph,r2
      0081DB E0               [24] 1978 	movx	a,@dptr
      0081DC F8               [12] 1979 	mov	r0,a
      0081DD 22               [24] 1980 	ret
                                   1981 
                                   1982 	.area CSEG (CODE)
                                   1983 ; function ak820_outline_0113
      0081DE                       1984 _ak820_outline_0113:
      0081DE F0               [24] 1985 	movx	@dptr,a
      0081DF E0               [24] 1986 	movx	a,@dptr
      0081E0 FF               [12] 1987 	mov	r7,a
      0081E1 90 09 8B         [24] 1988 	mov	dptr,#_change_owned_PARM_2
      0081E4 22               [24] 1989 	ret
                                   1990 
                                   1991 	.area CSEG (CODE)
                                   1992 ; function ak820_outline_0119
      0081E5                       1993 _ak820_outline_0119:
      0081E5 8D 82            [24] 1994 	mov	dpl,r5
      0081E7 8E 83            [24] 1995 	mov	dph,r6
      0081E9 F0               [24] 1996 	movx	@dptr,a
      0081EA 22               [24] 1997 	ret
                                   1998 
                                   1999 	.area CSEG (CODE)
                                   2000 ; function ak820_outline_0124
      0081EB                       2001 _ak820_outline_0124:
      0081EB 24 6E            [12] 2002 	add	a,#_usage_order
      0081ED F5 82            [12] 2003 	mov	dpl,a
      0081EF EF               [12] 2004 	mov	a,r7
      0081F0 34 0A            [12] 2005 	addc	a,#(_usage_order>>8)
      0081F2 F5 83            [12] 2006 	mov	dph,a
      0081F4 E0               [24] 2007 	movx	a,@dptr
      0081F5 22               [24] 2008 	ret
                                   2009 
                                   2010 	.area CSEG (CODE)
                                   2011 ; function ak820_outline_0130
      0081F6                       2012 _ak820_outline_0130:
      0081F6 F0               [24] 2013 	movx	@dptr,a
      0081F7 E0               [24] 2014 	movx	a,@dptr
      0081F8 FF               [12] 2015 	mov	r7,a
      0081F9 90 09 87         [24] 2016 	mov	dptr,#_ak820_macro_change_PARM_2
      0081FC F0               [24] 2017 	movx	@dptr,a
      0081FD 90 09 88         [24] 2018 	mov	dptr,#_ak820_macro_change_PARM_3
      008200 22               [24] 2019 	ret
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0172
      008201                       2023 _ak820_outline_0172:
      008201 90 08 04         [24] 2024 	mov	dptr,#_add_key_to_report_PARM_2
      008204 EF               [12] 2025 	mov	a,r7
      008205 F0               [24] 2026 	movx	@dptr,a
      008206 90 0D 9E         [24] 2027 	mov	dptr,#_actual_keyboard_report
      008209 22               [24] 2028 	ret
                                   2029 
                                   2030 	.area CSEG (CODE)
                                   2031 ; function ak820_outline_0185
      00820A                       2032 _ak820_outline_0185:
      00820A 8D 82            [24] 2033 	mov	dpl,r5
      00820C 8F 83            [24] 2034 	mov	dph,r7
      00820E 22               [24] 2035 	ret
