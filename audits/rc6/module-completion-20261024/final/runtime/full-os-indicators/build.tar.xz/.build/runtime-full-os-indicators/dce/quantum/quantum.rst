                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _ak820_resolve_key
                                     24 	.globl _default_layer_set
                                     25 	.globl _clear_keyboard
                                     26 	.globl _unregister_weak_mods
                                     27 	.globl _register_weak_mods
                                     28 	.globl _unregister_mods
                                     29 	.globl _register_mods
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _eeconfig_disable
                                     33 	.globl _rgb_matrix_set_suspend_state
                                     34 	.globl _rgb_matrix_task
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _process_record_quantum_helper_PARM_2
                                    280 	.globl _get_record_keycode_PARM_2
                                    281 	.globl _register_code16
                                    282 	.globl _unregister_code16
                                    283 	.globl _reset_keyboard
                                    284 	.globl _soft_reset_keyboard
                                    285 	.globl _get_record_keycode
                                    286 	.globl _pre_process_record_quantum
                                    287 	.globl _process_record_quantum
                                    288 	.globl _process_record_quantum_helper
                                    289 	.globl _shutdown_user
                                    290 ;--------------------------------------------------------
                                    291 ; special function registers
                                    292 ;--------------------------------------------------------
                                    293 	.area RSEG    (ABS,DATA)
      000000                        294 	.org 0x0000
                           0000D0   295 _PSW	=	0x00d0
                           0000E0   296 _ACC	=	0x00e0
                           0000F0   297 _B	=	0x00f0
                           0000FD   298 _A_INV	=	0x00fd
                           000081   299 _SP	=	0x0081
                           000082   300 _DPL	=	0x0082
                           000083   301 _DPH	=	0x0083
                           0000A1   302 _SAFE_MOD	=	0x00a1
                           0000B1   303 _GLOBAL_CFG	=	0x00b1
                           000087   304 _PCON	=	0x0087
                           0000BA   305 _POWER_CFG	=	0x00ba
                           0000B9   306 _CLOCK_CFG	=	0x00b9
                           0000A9   307 _WAKE_CTRL	=	0x00a9
                           0000FE   308 _RESET_KEEP	=	0x00fe
                           0000FF   309 _WDOG_COUNT	=	0x00ff
                           0000A8   310 _IE	=	0x00a8
                           0000B8   311 _IP	=	0x00b8
                           0000E8   312 _IE_EX	=	0x00e8
                           0000E9   313 _IP_EX	=	0x00e9
                           0000B2   314 _GPIO_IE	=	0x00b2
                           008584   315 _ROM_ADDR	=	0x8584
                           000084   316 _ROM_ADDR_L	=	0x0084
                           000085   317 _ROM_ADDR_H	=	0x0085
                           008F8E   318 _ROM_DATA_HI	=	0x8f8e
                           00008E   319 _ROM_DATA_HL	=	0x008e
                           00008F   320 _ROM_DATA_HH	=	0x008f
                           000086   321 _ROM_CTRL	=	0x0086
                           000080   322 _P0	=	0x0080
                           0000C4   323 _P0_MOD_OC	=	0x00c4
                           0000C5   324 _P0_DIR_PU	=	0x00c5
                           000090   325 _P1	=	0x0090
                           000092   326 _P1_MOD_OC	=	0x0092
                           000093   327 _P1_DIR_PU	=	0x0093
                           0000A0   328 _P2	=	0x00a0
                           000094   329 _P2_MOD_OC	=	0x0094
                           000095   330 _P2_DIR_PU	=	0x0095
                           0000B0   331 _P3	=	0x00b0
                           000096   332 _P3_MOD_OC	=	0x0096
                           000097   333 _P3_DIR_PU	=	0x0097
                           0000C0   334 _P4	=	0x00c0
                           0000C2   335 _P4_MOD_OC	=	0x00c2
                           0000C3   336 _P4_DIR_PU	=	0x00c3
                           0000C1   337 _P4_LED_KEY	=	0x00c1
                           0000AA   338 _P5_IN	=	0x00aa
                           0000AB   339 _P5_OUT_PU	=	0x00ab
                           0000AC   340 _P5_DIR	=	0x00ac
                           0000AD   341 _P6_IN	=	0x00ad
                           0000AE   342 _P6_OUT_PU	=	0x00ae
                           0000AF   343 _P6_DIR	=	0x00af
                           0000F1   344 _P7	=	0x00f1
                           0000A2   345 _XBUS_AUX	=	0x00a2
                           000088   346 _TCON	=	0x0088
                           000089   347 _TMOD	=	0x0089
                           00008A   348 _TL0	=	0x008a
                           00008B   349 _TL1	=	0x008b
                           00008C   350 _TH0	=	0x008c
                           00008D   351 _TH1	=	0x008d
                           000098   352 _SCON	=	0x0098
                           000099   353 _SBUF	=	0x0099
                           0000C8   354 _T2CON	=	0x00c8
                           0000C9   355 _T2MOD	=	0x00c9
                           00CBCA   356 _RCAP2	=	0xcbca
                           0000CA   357 _RCAP2L	=	0x00ca
                           0000CB   358 _RCAP2H	=	0x00cb
                           00CDCC   359 _T2COUNT	=	0xcdcc
                           0000CC   360 _TL2	=	0x00cc
                           0000CD   361 _TH2	=	0x00cd
                           00CFCE   362 _T2CAP1	=	0xcfce
                           0000CE   363 _T2CAP1L	=	0x00ce
                           0000CF   364 _T2CAP1H	=	0x00cf
                           0000F8   365 _SPI0_STAT	=	0x00f8
                           0000F9   366 _SPI0_DATA	=	0x00f9
                           0000FA   367 _SPI0_CTRL	=	0x00fa
                           0000FB   368 _SPI0_CK_SE	=	0x00fb
                           0000FC   369 _SPI0_SETUP	=	0x00fc
                           0000BC   370 _SCON1	=	0x00bc
                           0000BD   371 _SBUF1	=	0x00bd
                           0000BE   372 _SBAUD1	=	0x00be
                           0000BF   373 _SIF1	=	0x00bf
                           0000B4   374 _SPI1_STAT	=	0x00b4
                           0000B5   375 _SPI1_DATA	=	0x00b5
                           0000B6   376 _SPI1_CTRL	=	0x00b6
                           0000B7   377 _SPI1_CK_SE	=	0x00b7
                           0000F3   378 _ADC_CTRL	=	0x00f3
                           00F5F4   379 _ADC_DAT	=	0xf5f4
                           0000F4   380 _ADC_DAT_L	=	0x00f4
                           0000F5   381 _ADC_DAT_H	=	0x00f5
                           0000F6   382 _ADC_CHAN	=	0x00f6
                           0000A6   383 _LED_COMMON	=	0x00a6
                           0000A7   384 _LED_PWM_OE	=	0x00a7
                           00C7C6   385 _LED_DMA	=	0xc7c6
                           0000C6   386 _LED_DMA_L	=	0x00c6
                           0000C7   387 _LED_DMA_H	=	0x00c7
                           0000F7   388 _LED_STATUS	=	0x00f7
                           0000B3   389 _I2CX_INT	=	0x00b3
                           0000BB   390 _I2CS_INT_ST	=	0x00bb
                                    391 ;--------------------------------------------------------
                                    392 ; special function bits
                                    393 ;--------------------------------------------------------
                                    394 	.area RSEG    (ABS,DATA)
      000000                        395 	.org 0x0000
                           0000D7   396 _CY	=	0x00d7
                           0000D6   397 _AC	=	0x00d6
                           0000D5   398 _F0	=	0x00d5
                           0000D4   399 _RS1	=	0x00d4
                           0000D3   400 _RS0	=	0x00d3
                           0000D2   401 _OV	=	0x00d2
                           0000D1   402 _F1	=	0x00d1
                           0000D0   403 _P	=	0x00d0
                           0000AF   404 _EA	=	0x00af
                           0000AE   405 _E_DIS	=	0x00ae
                           0000AD   406 _ET2	=	0x00ad
                           0000AC   407 _ES	=	0x00ac
                           0000AB   408 _ET1	=	0x00ab
                           0000AA   409 _EX1	=	0x00aa
                           0000A9   410 _ET0	=	0x00a9
                           0000A8   411 _EX0	=	0x00a8
                           0000BF   412 _PH_FLAG	=	0x00bf
                           0000BE   413 _PL_FLAG	=	0x00be
                           0000BD   414 _PT2	=	0x00bd
                           0000BC   415 _PS	=	0x00bc
                           0000BB   416 _PT1	=	0x00bb
                           0000BA   417 _PX1	=	0x00ba
                           0000B9   418 _PT0	=	0x00b9
                           0000B8   419 _PX0	=	0x00b8
                           0000EF   420 _IE_WDOG	=	0x00ef
                           0000EE   421 _IE_GPIO	=	0x00ee
                           0000ED   422 _IE_PWM_I2C	=	0x00ed
                           0000EC   423 _IE_UART1	=	0x00ec
                           0000EB   424 _IE_ADC	=	0x00eb
                           0000E9   425 _IE_USB	=	0x00e9
                           0000E8   426 _IE_SPI0	=	0x00e8
                           000087   427 _P0_7	=	0x0087
                           000086   428 _P0_6	=	0x0086
                           000085   429 _P0_5	=	0x0085
                           000084   430 _P0_4	=	0x0084
                           000083   431 _P0_3	=	0x0083
                           000082   432 _P0_2	=	0x0082
                           000081   433 _P0_1	=	0x0081
                           000080   434 _P0_0	=	0x0080
                           000081   435 _SDA0	=	0x0081
                           000080   436 _SCL0	=	0x0080
                           000083   437 _TXD_	=	0x0083
                           000082   438 _RXD_	=	0x0082
                           000085   439 _AIN13	=	0x0085
                           000084   440 _AIN12	=	0x0084
                           000083   441 _AIN11	=	0x0083
                           000082   442 _AIN10	=	0x0082
                           000081   443 _AIN9	=	0x0081
                           000080   444 _AIN8	=	0x0080
                           000097   445 _P1_7	=	0x0097
                           000096   446 _P1_6	=	0x0096
                           000095   447 _P1_5	=	0x0095
                           000094   448 _P1_4	=	0x0094
                           000093   449 _P1_3	=	0x0093
                           000092   450 _P1_2	=	0x0092
                           000091   451 _P1_1	=	0x0091
                           000090   452 _P1_0	=	0x0090
                           000097   453 _TXD1_	=	0x0097
                           000096   454 _RXD1_	=	0x0096
                           000097   455 _SCK	=	0x0097
                           000096   456 _MISO	=	0x0096
                           000095   457 _MOSI	=	0x0095
                           000094   458 _SCS	=	0x0094
                           000092   459 _INT0_	=	0x0092
                           000091   460 _T2EX	=	0x0091
                           000091   461 _CAP2	=	0x0091
                           000090   462 _T2	=	0x0090
                           000090   463 _CAP1	=	0x0090
                           000097   464 _AIN7	=	0x0097
                           000096   465 _AIN6	=	0x0096
                           000095   466 _AIN5	=	0x0095
                           000094   467 _AIN4	=	0x0094
                           000093   468 _AIN3	=	0x0093
                           000092   469 _AIN2	=	0x0092
                           000091   470 _AIN1	=	0x0091
                           000090   471 _AIN0	=	0x0090
                           0000A7   472 _P2_7	=	0x00a7
                           0000A6   473 _P2_6	=	0x00a6
                           0000A5   474 _P2_5	=	0x00a5
                           0000A4   475 _P2_4	=	0x00a4
                           0000A3   476 _P2_3	=	0x00a3
                           0000A2   477 _P2_2	=	0x00a2
                           0000A1   478 _P2_1	=	0x00a1
                           0000A0   479 _P2_0	=	0x00a0
                           0000A7   480 _TXD1	=	0x00a7
                           0000A6   481 _RXD1	=	0x00a6
                           0000A5   482 _T2EX_	=	0x00a5
                           0000A5   483 _CAP2_	=	0x00a5
                           0000A4   484 _T2_	=	0x00a4
                           0000A4   485 _CAP1_	=	0x00a4
                           0000B7   486 _P3_7	=	0x00b7
                           0000B6   487 _P3_6	=	0x00b6
                           0000B5   488 _P3_5	=	0x00b5
                           0000B4   489 _P3_4	=	0x00b4
                           0000B3   490 _P3_3	=	0x00b3
                           0000B2   491 _P3_2	=	0x00b2
                           0000B1   492 _P3_1	=	0x00b1
                           0000B0   493 _P3_0	=	0x00b0
                           0000B7   494 _SCK1	=	0x00b7
                           0000B6   495 _MISO1	=	0x00b6
                           0000B5   496 _MOSI1	=	0x00b5
                           0000B5   497 _T1	=	0x00b5
                           0000B4   498 _T0	=	0x00b4
                           0000B3   499 _INT1	=	0x00b3
                           0000B2   500 _INT0	=	0x00b2
                           0000B1   501 _TXD	=	0x00b1
                           0000B0   502 _RXD	=	0x00b0
                           0000C6   503 _P4_6	=	0x00c6
                           0000C5   504 _P4_5	=	0x00c5
                           0000C4   505 _P4_4	=	0x00c4
                           0000C3   506 _P4_3	=	0x00c3
                           0000C2   507 _P4_2	=	0x00c2
                           0000C1   508 _P4_1	=	0x00c1
                           0000C0   509 _P4_0	=	0x00c0
                           00008F   510 _TF1	=	0x008f
                           00008E   511 _TR1	=	0x008e
                           00008D   512 _TF0	=	0x008d
                           00008C   513 _TR0	=	0x008c
                           00008B   514 _IE1	=	0x008b
                           00008A   515 _IT1	=	0x008a
                           000089   516 _IE0	=	0x0089
                           000088   517 _IT0	=	0x0088
                           00009F   518 _SM0	=	0x009f
                           00009E   519 _SM1	=	0x009e
                           00009D   520 _SM2	=	0x009d
                           00009C   521 _REN	=	0x009c
                           00009B   522 _TB8	=	0x009b
                           00009A   523 _RB8	=	0x009a
                           000099   524 _TI	=	0x0099
                           000098   525 _RI	=	0x0098
                           0000CF   526 _TF2	=	0x00cf
                           0000CF   527 _CAP1F	=	0x00cf
                           0000CE   528 _EXF2	=	0x00ce
                           0000CD   529 _RCLK	=	0x00cd
                           0000CC   530 _TCLK	=	0x00cc
                           0000CB   531 _EXEN2	=	0x00cb
                           0000CA   532 _TR2	=	0x00ca
                           0000C9   533 _C_T2	=	0x00c9
                           0000C8   534 _CP_RL2	=	0x00c8
                           0000FF   535 _S0_FST_ACT	=	0x00ff
                           0000FE   536 _S0_IF_OV	=	0x00fe
                           0000FD   537 _S0_IF_FIRST	=	0x00fd
                           0000FC   538 _S0_IF_BYTE	=	0x00fc
                           0000FB   539 _S0_FREE	=	0x00fb
                           0000FA   540 _S0_T_FIFO	=	0x00fa
                           0000F8   541 _S0_R_FIFO	=	0x00f8
                           0000F7   542 _ADC_START	=	0x00f7
                                    543 ;--------------------------------------------------------
                                    544 ; overlayable register banks
                                    545 ;--------------------------------------------------------
                                    546 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        547 	.ds 8
                                    548 ;--------------------------------------------------------
                                    549 ; internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area DSEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; overlayable items in internal ram
                                    554 ;--------------------------------------------------------
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      000023                        568 _get_record_keycode_sloc0_1_0:
      000023                        569 	.ds 1
      000024                        570 _pre_process_record_quantum_sloc0_1_0:
      000024                        571 	.ds 1
      000025                        572 _process_ak820_nkro_sloc0_1_0:
      000025                        573 	.ds 1
                                    574 ;--------------------------------------------------------
                                    575 ; paged external ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area PSEG    (PAG,XDATA)
                                    578 ;--------------------------------------------------------
                                    579 ; uninitialized external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area XSEG    (XDATA)
      000BD5                        582 _extract_mod_bits_code_10000_599:
      000BD5                        583 	.ds 2
      000BD7                        584 _register_code16_code_10000_605:
      000BD7                        585 	.ds 2
      000BD9                        586 _unregister_code16_code_10000_610:
      000BD9                        587 	.ds 2
      000BDB                        588 _get_record_keycode_PARM_2:
      000BDB                        589 	.ds 1
      000BDC                        590 _get_record_keycode_record_argument_10000_648:
      000BDC                        591 	.ds 2
      000BDE                        592 _pre_process_record_quantum_record_argument_10000_654:
      000BDE                        593 	.ds 2
      000BE0                        594 _process_record_quantum_record_10000_658:
      000BE0                        595 	.ds 2
      000BE2                        596 _process_ak820_nkro_PARM_2:
      000BE2                        597 	.ds 3
      000BE5                        598 _process_ak820_nkro_keycode_10000_660:
      000BE5                        599 	.ds 2
      000BE7                        600 _process_record_quantum_helper_PARM_2:
      000BE7                        601 	.ds 2
      000BE9                        602 _process_record_quantum_helper_keycode_10000_665:
      000BE9                        603 	.ds 2
      000BEB                        604 _get_u8_str_last_num_10000_691:
      000BEB                        605 	.ds 1
      000BEC                        606 _get_u16_str_last_num_10000_695:
      000BEC                        607 	.ds 2
                                    608 ;--------------------------------------------------------
                                    609 ; absolute external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area XABS    (ABS,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; initialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XISEG   (XDATA)
                                    616 	.area HOME    (CODE)
                                    617 	.area GSINIT0 (CODE)
                                    618 	.area GSINIT1 (CODE)
                                    619 	.area GSINIT2 (CODE)
                                    620 	.area GSINIT3 (CODE)
                                    621 	.area GSINIT4 (CODE)
                                    622 	.area GSINIT5 (CODE)
                                    623 	.area GSINIT  (CODE)
                                    624 	.area GSFINAL (CODE)
                                    625 	.area CSEG    (CODE)
                                    626 ;--------------------------------------------------------
                                    627 ; global & static initialisations
                                    628 ;--------------------------------------------------------
                                    629 	.area HOME    (CODE)
                                    630 	.area GSINIT  (CODE)
                                    631 	.area GSFINAL (CODE)
                                    632 	.area GSINIT  (CODE)
                                    633 ;------------------------------------------------------------
                                    634 ;Allocation info for local variables in function 'get_u8_str'
                                    635 ;------------------------------------------------------------
                                    636 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    637 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_690'
                                    638 ;buf           Allocated with name '_get_u8_str_buf_10000_691'
                                    639 ;last_num      Allocated with name '_get_u8_str_last_num_10000_691'
                                    640 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_691'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/quantum.c:789: static uint8_t last_num = 0xFF;
      0030F3 90 0B EB         [24]  643 	mov	dptr,#_get_u8_str_last_num_10000_691
      0030F6 74 FF            [12]  644 	mov	a,#0xff
      0030F8 F0               [24]  645 	movx	@dptr,a
                                    646 ;------------------------------------------------------------
                                    647 ;Allocation info for local variables in function 'get_u16_str'
                                    648 ;------------------------------------------------------------
                                    649 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    650 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_694'
                                    651 ;buf           Allocated with name '_get_u16_str_buf_10000_695'
                                    652 ;last_num      Allocated with name '_get_u16_str_last_num_10000_695'
                                    653 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_695'
                                    654 ;------------------------------------------------------------
                                    655 ;	quantum/quantum.c:809: static uint16_t last_num = 0xFF;
      0030F9 90 0B EC         [24]  656 	mov	dptr,#_get_u16_str_last_num_10000_695
      0030FC 74 FF            [12]  657 	mov	a,#0xff
      0030FE F0               [24]  658 	movx	@dptr,a
      0030FF E4               [12]  659 	clr	a
      003100 A3               [24]  660 	inc	dptr
      003101 F0               [24]  661 	movx	@dptr,a
                                    662 ;--------------------------------------------------------
                                    663 ; Home
                                    664 ;--------------------------------------------------------
                                    665 	.area HOME    (CODE)
                                    666 	.area HOME    (CODE)
                                    667 ;--------------------------------------------------------
                                    668 ; code
                                    669 ;--------------------------------------------------------
                                    670 	.area CSEG    (CODE)
                                    671 ;------------------------------------------------------------
                                    672 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    673 ;------------------------------------------------------------
                                    674 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    675 ;------------------------------------------------------------
                                    676 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    677 ;	-----------------------------------------
                           000007   678 	ar7 = 0x07
                           000006   679 	ar6 = 0x06
                           000005   680 	ar5 = 0x05
                           000004   681 	ar4 = 0x04
                           000003   682 	ar3 = 0x03
                           000002   683 	ar2 = 0x02
                           000001   684 	ar1 = 0x01
                           000000   685 	ar0 = 0x00
                                    686 ;	 function extract_mod_bits
                                    687 ;	-----------------------------------------
      009DF4                        688 _extract_mod_bits:
      009DF4 12 38 44         [24]  689 	lcall	_ak820_outline_0103
      009DF7 90 0B D5         [24]  690 	mov	dptr,#_extract_mod_bits_code_10000_599
      009DFA 12 38 49         [24]  691 	lcall	_ak820_outline_0104
                                    692 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      009DFD 90 0B D5         [24]  693 	mov	dptr,#_extract_mod_bits_code_10000_599
      009E00 E0               [24]  694 	movx	a,@dptr
      009E01 A3               [24]  695 	inc	dptr
      009E02 E0               [24]  696 	movx	a,@dptr
                                    697 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009E03 FF               [12]  698 	mov	r7,a
      009E04 60 05            [24]  699 	jz	00101$
      009E06 EF               [12]  700 	mov	a,r7
      009E07 24 E0            [12]  701 	add	a,#0xff - 0x1f
      009E09 50 04            [24]  702 	jnc	00102$
                                    703 ;	free result
      009E0B                        704 00101$:
      009E0B 75 82 00         [24]  705 	mov	dpl, #0x00
      009E0E 22               [24]  706 	ret
      009E0F                        707 00102$:
                                    708 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009E0F EF               [12]  709 	mov	a,r7
      009E10 30 E4 07         [24]  710 	jnb	acc.4,00106$
      009E13 EF               [12]  711 	mov	a,r7
      009E14 C4               [12]  712 	swap	a
      009E15 54 F0            [12]  713 	anl	a,#0xf0
      009E17 FE               [12]  714 	mov	r6,a
      009E18 80 02            [24]  715 	sjmp	00107$
      009E1A                        716 00106$:
      009E1A 8F 06            [24]  717 	mov	ar6,r7
      009E1C                        718 00107$:
      009E1C 8E 82            [24]  719 	mov	dpl, r6
                                    720 ;	quantum/quantum.c:143: }
      009E1E 22               [24]  721 	ret
                                    722 ;------------------------------------------------------------
                                    723 ;Allocation info for local variables in function 'do_code16'
                                    724 ;------------------------------------------------------------
                                    725 ;f             Allocated with name '_do_code16_PARM_2'
                                    726 ;code          Allocated with name '_do_code16_code_10000_602'
                                    727 ;------------------------------------------------------------
                                    728 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    729 ;	-----------------------------------------
                                    730 ;	 function register_code16
                                    731 ;	-----------------------------------------
      009E1F                        732 _register_code16:
      009E1F 12 38 44         [24]  733 	lcall	_ak820_outline_0103
      009E22 90 0B D7         [24]  734 	mov	dptr,#_register_code16_code_10000_605
      009E25 12 38 49         [24]  735 	lcall	_ak820_outline_0104
                                    736 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      009E28 90 0B D7         [24]  737 	mov	dptr,#_register_code16_code_10000_605
      009E2B 12 37 A1         [24]  738 	lcall	_ak820_outline_0004
      009E2E C0 07            [24]  739 	push	ar7
      009E30 C0 06            [24]  740 	push	ar6
      009E32 12 9D F4         [24]  741 	lcall	_extract_mod_bits
      009E35 AD 82            [24]  742 	mov	r5, dpl
      009E37 D0 06            [24]  743 	pop	ar6
      009E39 D0 07            [24]  744 	pop	ar7
                                    745 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009E3B 12 9C 36         [24]  746 	lcall	_ak820_outline_0114
      009E3E 40 07            [24]  747 	jc	00105$
      009E40 74 E7            [12]  748 	mov	a,#0xe7
      009E42 9E               [12]  749 	subb	a,r6
      009E43 E4               [12]  750 	clr	a
      009E44 9F               [12]  751 	subb	a,r7
      009E45 50 08            [24]  752 	jnc	00101$
                                    753 ;	free result
      009E47                        754 00105$:
      009E47 90 0B D7         [24]  755 	mov	dptr,#_register_code16_code_10000_605
      009E4A 12 6F 0F         [24]  756 	lcall	_ak820_outline_0036
      009E4D 70 07            [24]  757 	jnz	00102$
      009E4F                        758 00101$:
                                    759 ;	quantum/quantum.c:153: register_mods(mods);
      009E4F 8D 82            [24]  760 	mov	dpl, r5
      009E51 12 77 77         [24]  761 	lcall	_register_mods
      009E54 80 05            [24]  762 	sjmp	00103$
      009E56                        763 00102$:
                                    764 ;	quantum/quantum.c:155: register_weak_mods(mods);
      009E56 8D 82            [24]  765 	mov	dpl, r5
      009E58 12 77 9F         [24]  766 	lcall	_register_weak_mods
      009E5B                        767 00103$:
                                    768 ;	quantum/quantum.c:157: register_code(code);
      009E5B 90 0B D7         [24]  769 	mov	dptr,#_register_code16_code_10000_605
      009E5E E0               [24]  770 	movx	a,@dptr
      009E5F F5 82            [12]  771 	mov	dpl,a
                                    772 ;	quantum/quantum.c:167: }
      009E61 02 76 54         [24]  773 	ljmp	_register_code
                                    774 ;------------------------------------------------------------
                                    775 ;Allocation info for local variables in function 'unregister_code16'
                                    776 ;------------------------------------------------------------
                                    777 ;code          Allocated with name '_unregister_code16_code_10000_610'
                                    778 ;mods          Allocated with name '_unregister_code16_mods_10000_611'
                                    779 ;------------------------------------------------------------
                                    780 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    781 ;	-----------------------------------------
                                    782 ;	 function unregister_code16
                                    783 ;	-----------------------------------------
      009E64                        784 _unregister_code16:
      009E64 12 38 44         [24]  785 	lcall	_ak820_outline_0103
      009E67 90 0B D9         [24]  786 	mov	dptr,#_unregister_code16_code_10000_610
      009E6A 12 38 49         [24]  787 	lcall	_ak820_outline_0104
                                    788 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      009E6D 90 0B D9         [24]  789 	mov	dptr,#_unregister_code16_code_10000_610
      009E70 12 37 A1         [24]  790 	lcall	_ak820_outline_0004
      009E73 C0 07            [24]  791 	push	ar7
      009E75 C0 06            [24]  792 	push	ar6
      009E77 12 9D F4         [24]  793 	lcall	_extract_mod_bits
      009E7A AD 82            [24]  794 	mov	r5, dpl
      009E7C D0 06            [24]  795 	pop	ar6
                                    796 ;	quantum/quantum.c:172: unregister_code(code);
      009E7E 8E 04            [24]  797 	mov	ar4,r6
      009E80 8C 82            [24]  798 	mov	dpl, r4
      009E82 C0 06            [24]  799 	push	ar6
      009E84 C0 05            [24]  800 	push	ar5
      009E86 12 76 C1         [24]  801 	lcall	_unregister_code
      009E89 D0 05            [24]  802 	pop	ar5
      009E8B D0 06            [24]  803 	pop	ar6
      009E8D D0 07            [24]  804 	pop	ar7
                                    805 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009E8F 12 9C 36         [24]  806 	lcall	_ak820_outline_0114
      009E92 40 07            [24]  807 	jc	00105$
      009E94 74 E7            [12]  808 	mov	a,#0xe7
      009E96 9E               [12]  809 	subb	a,r6
      009E97 E4               [12]  810 	clr	a
      009E98 9F               [12]  811 	subb	a,r7
      009E99 50 08            [24]  812 	jnc	00101$
                                    813 ;	free result
      009E9B                        814 00105$:
      009E9B 90 0B D9         [24]  815 	mov	dptr,#_unregister_code16_code_10000_610
      009E9E 12 6F 0F         [24]  816 	lcall	_ak820_outline_0036
      009EA1 70 05            [24]  817 	jnz	00102$
      009EA3                        818 00101$:
                                    819 ;	quantum/quantum.c:174: unregister_mods(mods);
      009EA3 8D 82            [24]  820 	mov	dpl, r5
      009EA5 02 77 8B         [24]  821 	ljmp	_unregister_mods
      009EA8                        822 00102$:
                                    823 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      009EA8 8D 82            [24]  824 	mov	dpl, r5
                                    825 ;	quantum/quantum.c:187: }
      009EAA 02 77 B3         [24]  826 	ljmp	_unregister_weak_mods
                                    827 ;------------------------------------------------------------
                                    828 ;Allocation info for local variables in function 'tap_code16_delay'
                                    829 ;------------------------------------------------------------
                                    830 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    831 ;code          Allocated with name '_tap_code16_delay_code_10000_615'
                                    832 ;i             Allocated with name '_tap_code16_delay_i_20000_617'
                                    833 ;i             Allocated with name '_tap_code16_delay_i_50000_620'
                                    834 ;------------------------------------------------------------
                                    835 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    836 ;	-----------------------------------------
                                    837 ;	 function shutdown_quantum
                                    838 ;	-----------------------------------------
      009EAD                        839 _shutdown_quantum:
                                    840 ;	quantum/quantum.c:237: clear_keyboard();
      009EAD 12 77 C7         [24]  841 	lcall	_clear_keyboard
                                    842 ;	quantum/quantum.c:252: shutdown_user();
      009EB0 12 A1 33         [24]  843 	lcall	_shutdown_user
                                    844 ;	quantum/quantum.c:253: wait_ms(250);
      009EB3 7F FA            [12]  845 	mov	r7,#0xfa
      009EB5                        846 00106$:
      009EB5 EF               [12]  847 	mov	a,r7
      009EB6 60 09            [24]  848 	jz	00108$
      009EB8 90 00 01         [24]  849 	mov	dptr,#0x0001
      009EBB 12 59 90         [24]  850 	lcall	_mDelaymS
      009EBE 1F               [12]  851 	dec	r7
      009EBF 80 F4            [24]  852 	sjmp	00106$
      009EC1                        853 00108$:
                                    854 ;	quantum/quantum.c:258: }
      009EC1 22               [24]  855 	ret
                                    856 ;------------------------------------------------------------
                                    857 ;Allocation info for local variables in function 'reset_keyboard'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function reset_keyboard
                                    862 ;	-----------------------------------------
      009EC2                        863 _reset_keyboard:
                                    864 ;	quantum/quantum.c:261: shutdown_quantum();
      009EC2 12 9E AD         [24]  865 	lcall	_shutdown_quantum
                                    866 ;	quantum/quantum.c:262: bootloader_jump();
                                    867 ;	quantum/quantum.c:263: }
      009EC5 02 34 0E         [24]  868 	ljmp	_bootloader_jump
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                    871 ;------------------------------------------------------------
                                    872 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                    873 ;	-----------------------------------------
                                    874 ;	 function soft_reset_keyboard
                                    875 ;	-----------------------------------------
      009EC8                        876 _soft_reset_keyboard:
                                    877 ;	quantum/quantum.c:266: shutdown_quantum();
      009EC8 12 9E AD         [24]  878 	lcall	_shutdown_quantum
                                    879 ;	quantum/quantum.c:267: mcu_reset();
                                    880 ;	quantum/quantum.c:268: }
      009ECB 02 34 01         [24]  881 	ljmp	_mcu_reset
                                    882 ;------------------------------------------------------------
                                    883 ;Allocation info for local variables in function 'get_record_keycode'
                                    884 ;------------------------------------------------------------
                                    885 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                    886 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_648'
                                    887 ;record        Allocated with name '_get_record_keycode_record_10000_649'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function get_record_keycode
                                    892 ;	-----------------------------------------
      009ECE                        893 _get_record_keycode:
      009ECE 12 38 44         [24]  894 	lcall	_ak820_outline_0103
      009ED1 90 0B DC         [24]  895 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009ED4 12 38 49         [24]  896 	lcall	_ak820_outline_0104
                                    897 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009ED7 90 0B DC         [24]  898 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009EDA 12 37 B8         [24]  899 	lcall	_ak820_outline_0009
                                    900 ;	quantum/quantum.c:278: if (record->keycode) {
      009EDD 4C               [12]  901 	orl	a,r4
      009EDE 60 04            [24]  902 	jz	00102$
                                    903 ;	quantum/quantum.c:279: return record->keycode;
      009EE0 12 38 55         [24]  904 	lcall	_ak820_outline_0117
      009EE3 22               [24]  905 	ret
      009EE4                        906 00102$:
                                    907 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      009EE4 12 78 09         [24]  908 	lcall	_ak820_outline_0020
      009EE7 7A 00            [12]  909 	mov	r2,#0x00
      009EE9 12 43 9F         [24]  910 	lcall	_ak820_outline_0139
      009EEC 12 37 AB         [24]  911 	lcall	_ak820_outline_0005
      009EEF 60 06            [24]  912 	jz	00105$
      009EF1 90 0B DB         [24]  913 	mov	dptr,#_get_record_keycode_PARM_2
      009EF4 E0               [24]  914 	movx	a,@dptr
      009EF5 70 04            [24]  915 	jnz	00106$
      009EF7                        916 00105$:
                                    917 ;	assignBit
      009EF7 C2 23            [12]  918 	clr	_get_record_keycode_sloc0_1_0
      009EF9 80 02            [24]  919 	sjmp	00107$
      009EFB                        920 00106$:
                                    921 ;	assignBit
      009EFB D2 23            [12]  922 	setb	_get_record_keycode_sloc0_1_0
      009EFD                        923 00107$:
      009EFD 90 09 6B         [24]  924 	mov	dptr,#_ak820_resolve_key_PARM_2
      009F00 A2 23            [12]  925 	mov	c,_get_record_keycode_sloc0_1_0
      009F02 E4               [12]  926 	clr	a
      009F03 33               [12]  927 	rlc	a
      009F04 F0               [24]  928 	movx	@dptr,a
      009F05 12 43 CA         [24]  929 	lcall	_ak820_outline_0184
                                    930 ;	quantum/quantum.c:287: }
      009F08 02 7B A6         [24]  931 	ljmp	_ak820_resolve_key
                                    932 ;------------------------------------------------------------
                                    933 ;Allocation info for local variables in function 'get_event_keycode'
                                    934 ;------------------------------------------------------------
                                    935 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                    936 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_652'
                                    937 ;------------------------------------------------------------
                                    938 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                    939 ;	-----------------------------------------
                                    940 ;	 function pre_process_record_quantum
                                    941 ;	-----------------------------------------
      009F0B                        942 _pre_process_record_quantum:
      009F0B 12 38 44         [24]  943 	lcall	_ak820_outline_0103
      009F0E 90 0B DE         [24]  944 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009F11 12 38 49         [24]  945 	lcall	_ak820_outline_0104
                                    946 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009F14 90 0B DE         [24]  947 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009F17 12 38 01         [24]  948 	lcall	_ak820_outline_0051
                                    949 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      009F1A 90 0B DB         [24]  950 	mov	dptr,#_get_record_keycode_PARM_2
      009F1D 12 49 5F         [24]  951 	lcall	_ak820_outline_0055
      009F20 C0 07            [24]  952 	push	ar7
      009F22 C0 06            [24]  953 	push	ar6
      009F24 12 9E CE         [24]  954 	lcall	_get_record_keycode
      009F27 12 43 AA         [24]  955 	lcall	_ak820_outline_0145
      009F2A D0 06            [24]  956 	pop	ar6
      009F2C D0 07            [24]  957 	pop	ar7
                                    958 ;	quantum/quantum.c:334: record->keycode = keycode;
      009F2E 74 07            [12]  959 	mov	a,#0x07
      009F30 12 37 F1         [24]  960 	lcall	_ak820_outline_0031
      009F33 EC               [12]  961 	mov	a,r4
      009F34 F0               [24]  962 	movx	@dptr,a
      009F35 ED               [12]  963 	mov	a,r5
      009F36 A3               [24]  964 	inc	dptr
      009F37 12 43 64         [24]  965 	lcall	_ak820_outline_0061
                                    966 ;	quantum/quantum.c:361: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      009F3A 12 35 EF         [24]  967 	lcall	_ak820_combo_process
      009F3D E5 82            [12]  968 	mov	a, dpl
      009F3F 70 04            [24]  969 	jnz	00104$
                                    970 ;	quantum/quantum.c:366: true;
                                    971 ;	assignBit
      009F41 C2 24            [12]  972 	clr	_pre_process_record_quantum_sloc0_1_0
      009F43 80 02            [24]  973 	sjmp	00105$
      009F45                        974 00104$:
                                    975 ;	assignBit
      009F45 D2 24            [12]  976 	setb	_pre_process_record_quantum_sloc0_1_0
      009F47                        977 00105$:
      009F47 A2 24            [12]  978 	mov	c,_pre_process_record_quantum_sloc0_1_0
      009F49 12 38 81         [24]  979 	lcall	_ak820_outline_0167
                                    980 ;	quantum/quantum.c:367: }
      009F4C 22               [24]  981 	ret
                                    982 ;------------------------------------------------------------
                                    983 ;Allocation info for local variables in function 'post_process_record_quantum'
                                    984 ;------------------------------------------------------------
                                    985 ;record        Allocated with name '_post_process_record_quantum_record_10000_656'
                                    986 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_657'
                                    987 ;------------------------------------------------------------
                                    988 ;	quantum/quantum.c:370: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                    989 ;	-----------------------------------------
                                    990 ;	 function process_record_quantum
                                    991 ;	-----------------------------------------
      009F4D                        992 _process_record_quantum:
      009F4D 12 38 44         [24]  993 	lcall	_ak820_outline_0103
      009F50 90 0B E0         [24]  994 	mov	dptr,#_process_record_quantum_record_10000_658
      009F53 12 38 49         [24]  995 	lcall	_ak820_outline_0104
                                    996 ;	quantum/quantum.c:377: uint16_t keycode = get_record_keycode(record, false);
      009F56 90 0B E0         [24]  997 	mov	dptr,#_process_record_quantum_record_10000_658
      009F59 12 38 01         [24]  998 	lcall	_ak820_outline_0051
      009F5C 90 0B DB         [24]  999 	mov	dptr,#_get_record_keycode_PARM_2
      009F5F E4               [12] 1000 	clr	a
      009F60 12 43 64         [24] 1001 	lcall	_ak820_outline_0061
      009F63 12 9E CE         [24] 1002 	lcall	_get_record_keycode
      009F66 12 43 94         [24] 1003 	lcall	_ak820_outline_0131
                                   1004 ;	quantum/quantum.c:381: return process_record_quantum_helper(keycode, record);
      009F69 90 0B E0         [24] 1005 	mov	dptr,#_process_record_quantum_record_10000_658
      009F6C 12 38 20         [24] 1006 	lcall	_ak820_outline_0060
      009F6F 90 0B E7         [24] 1007 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009F72 EC               [12] 1008 	mov	a,r4
      009F73 F0               [24] 1009 	movx	@dptr,a
      009F74 ED               [12] 1010 	mov	a,r5
      009F75 A3               [24] 1011 	inc	dptr
      009F76 12 43 64         [24] 1012 	lcall	_ak820_outline_0061
                                   1013 ;	quantum/quantum.c:382: }
      009F79 02 9F E7         [24] 1014 	ljmp	_process_record_quantum_helper
                                   1015 ;------------------------------------------------------------
                                   1016 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1017 ;------------------------------------------------------------
                                   1018 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1019 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_660'
                                   1020 ;record        Allocated with name '_process_ak820_nkro_record_10000_661'
                                   1021 ;------------------------------------------------------------
                                   1022 ;	quantum/quantum.c:399: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1023 ;	-----------------------------------------
                                   1024 ;	 function process_ak820_nkro
                                   1025 ;	-----------------------------------------
      009F7C                       1026 _process_ak820_nkro:
      009F7C 12 38 44         [24] 1027 	lcall	_ak820_outline_0103
      009F7F 90 0B E5         [24] 1028 	mov	dptr,#_process_ak820_nkro_keycode_10000_660
      009F82 12 38 49         [24] 1029 	lcall	_ak820_outline_0104
                                   1030 ;	quantum/quantum.c:401: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009F85 90 0B E2         [24] 1031 	mov	dptr,#_process_ak820_nkro_PARM_2
      009F88 12 38 01         [24] 1032 	lcall	_ak820_outline_0051
                                   1033 ;	quantum/quantum.c:405: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      009F8B 90 0B E5         [24] 1034 	mov	dptr,#_process_ak820_nkro_keycode_10000_660
      009F8E 12 38 20         [24] 1035 	lcall	_ak820_outline_0060
      009F91 C3               [12] 1036 	clr	c
      009F92 EC               [12] 1037 	mov	a,r4
      009F93 94 11            [12] 1038 	subb	a,#0x11
      009F95 ED               [12] 1039 	mov	a,r5
      009F96 94 70            [12] 1040 	subb	a,#0x70
      009F98 40 08            [24] 1041 	jc	00101$
      009F9A 74 13            [12] 1042 	mov	a,#0x13
      009F9C 9C               [12] 1043 	subb	a,r4
      009F9D 74 70            [12] 1044 	mov	a,#0x70
      009F9F 9D               [12] 1045 	subb	a,r5
      009FA0 50 04            [24] 1046 	jnc	00102$
                                   1047 ;	free result
      009FA2                       1048 00101$:
      009FA2 75 82 01         [24] 1049 	mov	dpl, #0x01
      009FA5 22               [24] 1050 	ret
      009FA6                       1051 00102$:
                                   1052 ;	quantum/quantum.c:406: if (record->event.pressed) {
      009FA6 12 37 AB         [24] 1053 	lcall	_ak820_outline_0005
      009FA9 60 38            [24] 1054 	jz	00105$
                                   1055 ;	quantum/quantum.c:407: clear_keyboard();
      009FAB C0 05            [24] 1056 	push	ar5
      009FAD C0 04            [24] 1057 	push	ar4
      009FAF 12 77 C7         [24] 1058 	lcall	_clear_keyboard
      009FB2 D0 04            [24] 1059 	pop	ar4
      009FB4 D0 05            [24] 1060 	pop	ar5
                                   1061 ;	quantum/quantum.c:408: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      009FB6 BC 13 14         [24] 1062 	cjne	r4,#0x13,00108$
      009FB9 BD 70 11         [24] 1063 	cjne	r5,#0x70,00108$
      009FBC 90 0A BD         [24] 1064 	mov	dptr,#_keymap_config
      009FBF E0               [24] 1065 	movx	a,@dptr
      009FC0 23               [12] 1066 	rl	a
      009FC1 54 01            [12] 1067 	anl	a,#0x01
      009FC3 B4 01 00         [24] 1068 	cjne	a,#0x01,00136$
      009FC6                       1069 00136$:
      009FC6 92 25            [24] 1070 	mov  _process_ak820_nkro_sloc0_1_0,c
      009FC8 E4               [12] 1071 	clr	a
      009FC9 33               [12] 1072 	rlc	a
      009FCA FF               [12] 1073 	mov	r7,a
      009FCB 80 09            [24] 1074 	sjmp	00109$
      009FCD                       1075 00108$:
      009FCD E4               [12] 1076 	clr	a
      009FCE BC 11 04         [24] 1077 	cjne	r4,#0x11,00137$
      009FD1 BD 70 01         [24] 1078 	cjne	r5,#0x70,00137$
      009FD4 04               [12] 1079 	inc	a
      009FD5                       1080 00137$:
      009FD5 FF               [12] 1081 	mov	r7,a
      009FD6                       1082 00109$:
                                   1083 ;	assignBit
      009FD6 EF               [12] 1084 	mov	a,r7
      009FD7 24 FF            [12] 1085 	add	a,#0xff
      009FD9 E4               [12] 1086 	clr	a
      009FDA 33               [12] 1087 	rlc	a
      009FDB 90 0A BD         [24] 1088 	mov	dptr,#_keymap_config
      009FDE 13               [12] 1089 	rrc	a
      009FDF E0               [24] 1090 	movx	a,@dptr
      009FE0 92 E7            [24] 1091 	mov	acc.7,c
      009FE2 F0               [24] 1092 	movx	@dptr,a
      009FE3                       1093 00105$:
                                   1094 ;	quantum/quantum.c:410: return false;
      009FE3 75 82 00         [24] 1095 	mov	dpl, #0x00
                                   1096 ;	quantum/quantum.c:411: }
      009FE6 22               [24] 1097 	ret
                                   1098 ;------------------------------------------------------------
                                   1099 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1100 ;------------------------------------------------------------
                                   1101 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1102 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_665'
                                   1103 ;record        Allocated with name '_process_record_quantum_helper_record_10000_666'
                                   1104 ;------------------------------------------------------------
                                   1105 ;	quantum/quantum.c:414: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1106 ;	-----------------------------------------
                                   1107 ;	 function process_record_quantum_helper
                                   1108 ;	-----------------------------------------
      009FE7                       1109 _process_record_quantum_helper:
      009FE7 12 38 44         [24] 1110 	lcall	_ak820_outline_0103
      009FEA 90 0B E9         [24] 1111 	mov	dptr,#_process_record_quantum_helper_keycode_10000_665
      009FED 12 38 49         [24] 1112 	lcall	_ak820_outline_0104
                                   1113 ;	quantum/quantum.c:416: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009FF0 90 0B E7         [24] 1114 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009FF3 12 38 01         [24] 1115 	lcall	_ak820_outline_0051
                                   1116 ;	quantum/quantum.c:459: process_ak820_nkro(keycode, record) &&
      009FF6 90 0B E9         [24] 1117 	mov	dptr,#_process_record_quantum_helper_keycode_10000_665
      009FF9 12 38 20         [24] 1118 	lcall	_ak820_outline_0060
      009FFC 90 0B E2         [24] 1119 	mov	dptr,#_process_ak820_nkro_PARM_2
      009FFF 12 A1 34         [24] 1120 	lcall	_ak820_outline_0006
      00A002 C0 07            [24] 1121 	push	ar7
      00A004 C0 06            [24] 1122 	push	ar6
      00A006 C0 05            [24] 1123 	push	ar5
      00A008 C0 04            [24] 1124 	push	ar4
      00A00A 12 9F 7C         [24] 1125 	lcall	_process_ak820_nkro
      00A00D E5 82            [12] 1126 	mov	a, dpl
      00A00F D0 04            [24] 1127 	pop	ar4
      00A011 D0 05            [24] 1128 	pop	ar5
      00A013 D0 06            [24] 1129 	pop	ar6
      00A015 D0 07            [24] 1130 	pop	ar7
      00A017 70 03            [24] 1131 	jnz	00196$
      00A019 02 A0 F6         [24] 1132 	ljmp	00101$
      00A01C                       1133 00196$:
                                   1134 ;	quantum/quantum.c:470: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A01C 90 0B C0         [24] 1135 	mov	dptr,#_process_last_key_PARM_2
      00A01F 12 49 6F         [24] 1136 	lcall	_ak820_outline_0059
      00A022 12 38 55         [24] 1137 	lcall	_ak820_outline_0117
      00A025 C0 07            [24] 1138 	push	ar7
      00A027 C0 06            [24] 1139 	push	ar6
      00A029 C0 05            [24] 1140 	push	ar5
      00A02B C0 04            [24] 1141 	push	ar4
      00A02D 12 9B 76         [24] 1142 	lcall	_process_last_key
      00A030 E5 82            [12] 1143 	mov	a, dpl
      00A032 D0 04            [24] 1144 	pop	ar4
      00A034 D0 05            [24] 1145 	pop	ar5
      00A036 D0 06            [24] 1146 	pop	ar6
      00A038 D0 07            [24] 1147 	pop	ar7
      00A03A 70 03            [24] 1148 	jnz	00197$
      00A03C 02 A0 F6         [24] 1149 	ljmp	00101$
      00A03F                       1150 00197$:
      00A03F 90 0B C5         [24] 1151 	mov	dptr,#_process_repeat_key_PARM_2
      00A042 12 49 6F         [24] 1152 	lcall	_ak820_outline_0059
      00A045 12 38 55         [24] 1153 	lcall	_ak820_outline_0117
      00A048 C0 07            [24] 1154 	push	ar7
      00A04A C0 06            [24] 1155 	push	ar6
      00A04C C0 05            [24] 1156 	push	ar5
      00A04E C0 04            [24] 1157 	push	ar4
      00A050 12 9B EF         [24] 1158 	lcall	_process_repeat_key
      00A053 E5 82            [12] 1159 	mov	a, dpl
      00A055 D0 04            [24] 1160 	pop	ar4
      00A057 D0 05            [24] 1161 	pop	ar5
      00A059 D0 06            [24] 1162 	pop	ar6
      00A05B D0 07            [24] 1163 	pop	ar7
      00A05D 70 03            [24] 1164 	jnz	00198$
      00A05F 02 A0 F6         [24] 1165 	ljmp	00101$
      00A062                       1166 00198$:
                                   1167 ;	quantum/quantum.c:479: process_record_via(keycode, record) &&
      00A062 90 0C 22         [24] 1168 	mov	dptr,#_process_record_via_PARM_2
      00A065 12 A1 34         [24] 1169 	lcall	_ak820_outline_0006
      00A068 C0 07            [24] 1170 	push	ar7
      00A06A C0 06            [24] 1171 	push	ar6
      00A06C C0 05            [24] 1172 	push	ar5
      00A06E C0 04            [24] 1173 	push	ar4
      00A070 12 A6 21         [24] 1174 	lcall	_process_record_via
      00A073 E5 82            [12] 1175 	mov	a, dpl
      00A075 D0 04            [24] 1176 	pop	ar4
      00A077 D0 05            [24] 1177 	pop	ar5
      00A079 D0 06            [24] 1178 	pop	ar6
      00A07B D0 07            [24] 1179 	pop	ar7
      00A07D 70 03            [24] 1180 	jnz	00199$
      00A07F 02 A0 F6         [24] 1181 	ljmp	00101$
      00A082                       1182 00199$:
                                   1183 ;	quantum/quantum.c:514: process_caps_word(keycode, record) &&
      00A082 90 0B A9         [24] 1184 	mov	dptr,#_process_caps_word_PARM_2
      00A085 12 A1 34         [24] 1185 	lcall	_ak820_outline_0006
      00A088 C0 07            [24] 1186 	push	ar7
      00A08A C0 06            [24] 1187 	push	ar6
      00A08C C0 05            [24] 1188 	push	ar5
      00A08E C0 04            [24] 1189 	push	ar4
      00A090 12 99 15         [24] 1190 	lcall	_process_caps_word
      00A093 E5 82            [12] 1191 	mov	a, dpl
      00A095 D0 04            [24] 1192 	pop	ar4
      00A097 D0 05            [24] 1193 	pop	ar5
      00A099 D0 06            [24] 1194 	pop	ar6
      00A09B D0 07            [24] 1195 	pop	ar7
      00A09D 60 57            [24] 1196 	jz	00101$
                                   1197 ;	quantum/quantum.c:544: process_grave_esc(keycode, record) &&
      00A09F 90 0B AE         [24] 1198 	mov	dptr,#_process_grave_esc_PARM_2
      00A0A2 12 A1 34         [24] 1199 	lcall	_ak820_outline_0006
      00A0A5 C0 07            [24] 1200 	push	ar7
      00A0A7 C0 06            [24] 1201 	push	ar6
      00A0A9 C0 05            [24] 1202 	push	ar5
      00A0AB C0 04            [24] 1203 	push	ar4
      00A0AD 12 9A 28         [24] 1204 	lcall	_process_grave_esc
      00A0B0 E5 82            [12] 1205 	mov	a, dpl
      00A0B2 D0 04            [24] 1206 	pop	ar4
      00A0B4 D0 05            [24] 1207 	pop	ar5
      00A0B6 D0 06            [24] 1208 	pop	ar6
      00A0B8 D0 07            [24] 1209 	pop	ar7
      00A0BA 60 3A            [24] 1210 	jz	00101$
                                   1211 ;	quantum/quantum.c:547: process_rgb(keycode, record) &&
      00A0BC 90 0B C9         [24] 1212 	mov	dptr,#_process_rgb_PARM_2
      00A0BF 12 A1 34         [24] 1213 	lcall	_ak820_outline_0006
      00A0C2 C0 07            [24] 1214 	push	ar7
      00A0C4 C0 06            [24] 1215 	push	ar6
      00A0C6 C0 05            [24] 1216 	push	ar5
      00A0C8 C0 04            [24] 1217 	push	ar4
      00A0CA 12 9C 3E         [24] 1218 	lcall	_process_rgb
      00A0CD E5 82            [12] 1219 	mov	a, dpl
      00A0CF D0 04            [24] 1220 	pop	ar4
      00A0D1 D0 05            [24] 1221 	pop	ar5
      00A0D3 D0 06            [24] 1222 	pop	ar6
      00A0D5 D0 07            [24] 1223 	pop	ar7
      00A0D7 60 1D            [24] 1224 	jz	00101$
                                   1225 ;	quantum/quantum.c:559: process_tri_layer(keycode, record) &&
      00A0D9 90 0B CF         [24] 1226 	mov	dptr,#_process_tri_layer_PARM_2
      00A0DC 12 A1 34         [24] 1227 	lcall	_ak820_outline_0006
      00A0DF C0 07            [24] 1228 	push	ar7
      00A0E1 C0 06            [24] 1229 	push	ar6
      00A0E3 C0 05            [24] 1230 	push	ar5
      00A0E5 C0 04            [24] 1231 	push	ar4
      00A0E7 12 9C EF         [24] 1232 	lcall	_process_tri_layer
      00A0EA E5 82            [12] 1233 	mov	a, dpl
      00A0EC D0 04            [24] 1234 	pop	ar4
      00A0EE D0 05            [24] 1235 	pop	ar5
      00A0F0 D0 06            [24] 1236 	pop	ar6
      00A0F2 D0 07            [24] 1237 	pop	ar7
      00A0F4 70 04            [24] 1238 	jnz	00102$
                                   1239 ;	quantum/quantum.c:561: true)) {
      00A0F6                       1240 00101$:
                                   1241 ;	quantum/quantum.c:562: return false;
      00A0F6 75 82 00         [24] 1242 	mov	dpl, #0x00
      00A0F9 22               [24] 1243 	ret
      00A0FA                       1244 00102$:
                                   1245 ;	quantum/quantum.c:565: if (record->event.pressed) {
      00A0FA 12 37 AB         [24] 1246 	lcall	_ak820_outline_0005
      00A0FD 60 30            [24] 1247 	jz	00116$
                                   1248 ;	quantum/quantum.c:566: switch (keycode) {
      00A0FF BC 00 05         [24] 1249 	cjne	r4,#0x00,00205$
      00A102 BD 7C 02         [24] 1250 	cjne	r5,#0x7c,00205$
      00A105 80 10            [24] 1251 	sjmp	00111$
      00A107                       1252 00205$:
      00A107 BC 01 05         [24] 1253 	cjne	r4,#0x01,00206$
      00A10A BD 7C 02         [24] 1254 	cjne	r5,#0x7c,00206$
      00A10D 80 0F            [24] 1255 	sjmp	00112$
      00A10F                       1256 00206$:
                                   1257 ;	quantum/quantum.c:568: case QK_BOOTLOADER:
      00A10F BC 03 1D         [24] 1258 	cjne	r4,#0x03,00116$
      00A112 BD 7C 1A         [24] 1259 	cjne	r5,#0x7c,00116$
      00A115 80 0E            [24] 1260 	sjmp	00113$
      00A117                       1261 00111$:
                                   1262 ;	quantum/quantum.c:569: reset_keyboard();
      00A117 12 9E C2         [24] 1263 	lcall	_reset_keyboard
                                   1264 ;	quantum/quantum.c:570: return false;
      00A11A 75 82 00         [24] 1265 	mov	dpl, #0x00
                                   1266 ;	quantum/quantum.c:571: case QK_REBOOT:
      00A11D 22               [24] 1267 	ret
      00A11E                       1268 00112$:
                                   1269 ;	quantum/quantum.c:572: soft_reset_keyboard();
      00A11E 12 9E C8         [24] 1270 	lcall	_soft_reset_keyboard
                                   1271 ;	quantum/quantum.c:573: return false;
      00A121 75 82 00         [24] 1272 	mov	dpl, #0x00
                                   1273 ;	quantum/quantum.c:585: case QK_CLEAR_EEPROM:
      00A124 22               [24] 1274 	ret
      00A125                       1275 00113$:
                                   1276 ;	quantum/quantum.c:592: eeconfig_disable();
      00A125 12 90 80         [24] 1277 	lcall	_eeconfig_disable
                                   1278 ;	quantum/quantum.c:593: soft_reset_keyboard();
      00A128 12 9E C8         [24] 1279 	lcall	_soft_reset_keyboard
                                   1280 ;	quantum/quantum.c:595: return false;
      00A12B 75 82 00         [24] 1281 	mov	dpl, #0x00
                                   1282 ;	quantum/quantum.c:650: }
      00A12E 22               [24] 1283 	ret
      00A12F                       1284 00116$:
                                   1285 ;	quantum/quantum.c:654: return true;
      00A12F 75 82 01         [24] 1286 	mov	dpl, #0x01
                                   1287 ;	quantum/quantum.c:658: }
      00A132 22               [24] 1288 	ret
                                   1289 ;------------------------------------------------------------
                                   1290 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1291 ;------------------------------------------------------------
                                   1292 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_673'
                                   1293 ;------------------------------------------------------------
                                   1294 ;	quantum/quantum.c:660: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1295 ;	-----------------------------------------
                                   1296 ;	 function shutdown_user
                                   1297 ;	-----------------------------------------
      00A133                       1298 _shutdown_user:
      00A133 22               [24] 1299 	ret
                                   1300 ;------------------------------------------------------------
                                   1301 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/quantum.c:676: void suspend_power_down_quantum(void) {
                                   1304 ;	-----------------------------------------
                                   1305 	.area CSEG    (CODE)
                                   1306 	.area CONST   (CODE)
                                   1307 	.area XINIT   (CODE)
                                   1308 	.area CABS    (ABS,CODE)
                                   1309 
                                   1310 ; Experimental exact instruction outlining.
                                   1311 	.globl _ak820_outline_0004
                                   1312 	.globl _ak820_outline_0005
                                   1313 	.globl _ak820_outline_0006
                                   1314 	.globl _ak820_outline_0009
                                   1315 	.globl _ak820_outline_0020
                                   1316 	.globl _ak820_outline_0031
                                   1317 	.globl _ak820_outline_0036
                                   1318 	.globl _ak820_outline_0051
                                   1319 	.globl _ak820_outline_0055
                                   1320 	.globl _ak820_outline_0059
                                   1321 	.globl _ak820_outline_0060
                                   1322 	.globl _ak820_outline_0061
                                   1323 	.globl _ak820_outline_0103
                                   1324 	.globl _ak820_outline_0104
                                   1325 	.globl _ak820_outline_0114
                                   1326 	.globl _ak820_outline_0117
                                   1327 	.globl _ak820_outline_0131
                                   1328 	.globl _ak820_outline_0139
                                   1329 	.globl _ak820_outline_0145
                                   1330 	.globl _ak820_outline_0167
                                   1331 	.globl _ak820_outline_0184
                                   1332 
                                   1333 	.area CSEG (CODE)
                                   1334 ; function ak820_outline_0006
      00A134                       1335 _ak820_outline_0006:
      00A134 EE               [12] 1336 	mov	a,r6
      00A135 F0               [24] 1337 	movx	@dptr,a
      00A136 EF               [12] 1338 	mov	a,r7
      00A137 A3               [24] 1339 	inc	dptr
      00A138 F0               [24] 1340 	movx	@dptr,a
      00A139 E4               [12] 1341 	clr	a
      00A13A A3               [24] 1342 	inc	dptr
      00A13B F0               [24] 1343 	movx	@dptr,a
      00A13C 8C 82            [24] 1344 	mov	dpl,r4
      00A13E 8D 83            [24] 1345 	mov	dph,r5
      00A140 22               [24] 1346 	ret
