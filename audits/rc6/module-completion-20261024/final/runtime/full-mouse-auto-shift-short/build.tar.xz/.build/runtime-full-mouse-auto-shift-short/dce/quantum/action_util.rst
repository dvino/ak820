                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000054                        551 _change_owned_sloc1_1_0:
      000054                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      00001F                        566 _ak820_macro_change_sloc0_1_0:
      00001F                        567 	.ds 1
      000020                        568 _change_owned_sloc0_1_0:
      000020                        569 	.ds 1
      000021                        570 _owned_usage_key_sloc0_1_0:
      000021                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000996                        580 _owned_mod_refs:
      000996                        581 	.ds 8
      00099E                        582 _owned_weak_refs:
      00099E                        583 	.ds 8
      0009A6                        584 _owned_mods:
      0009A6                        585 	.ds 1
      0009A7                        586 _owned_weak_mods:
      0009A7                        587 	.ds 1
      0009A8                        588 _macro_mods:
      0009A8                        589 	.ds 2
      0009AA                        590 _ak820_macro_primitive::
      0009AA                        591 	.ds 1
      0009AB                        592 _ak820_macro_cancelled::
      0009AB                        593 	.ds 1
      0009AC                        594 _ak820_macro_change_PARM_2:
      0009AC                        595 	.ds 1
      0009AD                        596 _ak820_macro_change_PARM_3:
      0009AD                        597 	.ds 1
      0009AE                        598 _ak820_macro_change_bits_10000_294:
      0009AE                        599 	.ds 2
      0009B0                        600 _change_owned_PARM_2:
      0009B0                        601 	.ds 1
      0009B1                        602 _change_owned_mods_10000_299:
      0009B1                        603 	.ds 1
      0009B2                        604 _change_owned_result_10001_303:
      0009B2                        605 	.ds 1
      0009B3                        606 _change_owned_bit_20001_304:
      0009B3                        607 	.ds 1
      0009B4                        608 _add_owned_mods_mods_10000_312:
      0009B4                        609 	.ds 1
      0009B5                        610 _del_owned_mods_mods_10000_314:
      0009B5                        611 	.ds 1
      0009B6                        612 _add_owned_weak_mods_mods_10000_316:
      0009B6                        613 	.ds 1
      0009B7                        614 _del_owned_weak_mods_mods_10000_318:
      0009B7                        615 	.ds 1
      0009B8                        616 _key_refs:
      0009B8                        617 	.ds 165
      000A5D                        618 _distinct_keys:
      000A5D                        619 	.ds 1
      000A5E                        620 _macro_keys:
      000A5E                        621 	.ds 21
      000A73                        622 _add_owned_key_code_10000_327:
      000A73                        623 	.ds 1
      000A74                        624 _del_owned_key_code_10000_342:
      000A74                        625 	.ds 1
      000A75                        626 _usage_refs:
      000A75                        627 	.ds 30
      000A93                        628 _usage_order:
      000A93                        629 	.ds 30
      000AB1                        630 _usage_lengths:
      000AB1                        631 	.ds 2
      000AB3                        632 _macro_usages:
      000AB3                        633 	.ds 4
      000AB7                        634 _owned_usage_key_PARM_2:
      000AB7                        635 	.ds 1
      000AB8                        636 _owned_usage_key_code_10000_369:
      000AB8                        637 	.ds 1
      000AB9                        638 _owned_usage_key___200000085_20000_370:
      000AB9                        639 	.ds 2
      000ABB                        640 _owned_usage_key_which_10000_370:
      000ABB                        641 	.ds 1
      000ABC                        642 _owned_usage_key_count_10000_370:
      000ABC                        643 	.ds 1
      000ABD                        644 _owned_usage_key_pos_30001_377:
      000ABD                        645 	.ds 1
      000ABE                        646 _owned_usage_key_key_40000_382:
      000ABE                        647 	.ds 1
      000ABF                        648 _send_keyboard_report_last_report_10001_389:
      000ABF                        649 	.ds 32
      000ADF                        650 _send_keyboard_report_changed_10001_389:
      000ADF                        651 	.ds 1
      000AE0                        652 _add_weak_mods_mods_10000_407:
      000AE0                        653 	.ds 1
      000AE1                        654 _del_weak_mods_mods_10000_409:
      000AE1                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DC2                        664 _real_mods:
      000DC2                        665 	.ds 1
      000DC3                        666 _weak_mods:
      000DC3                        667 	.ds 1
      000DC4                        668 _actual_keyboard_report::
      000DC4                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007F7E                        713 _ak820_macro_change:
      007F7E 12 3A 84         [24]  714 	lcall	_ak820_outline_0103
      007F81 90 09 AE         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_294
      007F84 12 3A 89         [24]  716 	lcall	_ak820_outline_0104
                                    717 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      007F87 90 09 AA         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007F8A E0               [24]  719 	movx	a,@dptr
      007F8B 70 04            [24]  720 	jnz	00102$
      007F8D 75 82 01         [24]  721 	mov	dpl, #0x01
      007F90 22               [24]  722 	ret
      007F91                        723 00102$:
                                    724 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      007F91 90 09 AC         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      007F94 E0               [24]  726 	movx	a,@dptr
      007F95 FF               [12]  727 	mov	r7,a
      007F96 74 07            [12]  728 	mov	a,#0x07
      007F98 5F               [12]  729 	anl	a,r7
      007F99 12 7B 3B         [24]  730 	lcall	_ak820_outline_0062
      007F9C 80 02            [24]  731 	sjmp	00123$
      007F9E                        732 00122$:
      007F9E 25 E0            [12]  733 	add	a,acc
      007FA0                        734 00123$:
      007FA0 D5 F0 FB         [24]  735 	djnz	b,00122$
      007FA3 FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:101: bits += index >> 3;
      007FA4 EF               [12]  738 	mov	a,r7
      007FA5 12 5B 8A         [24]  739 	lcall	_ak820_outline_0182
      007FA8 FF               [12]  740 	mov	r7,a
      007FA9 90 09 AE         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_294
      007FAC 12 3A 60         [24]  742 	lcall	_ak820_outline_0059
      007FAF 90 09 AE         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_294
      007FB2 EF               [12]  744 	mov	a,r7
      007FB3 2C               [12]  745 	add	a, r4
      007FB4 F0               [24]  746 	movx	@dptr,a
      007FB5 E4               [12]  747 	clr	a
      007FB6 3D               [12]  748 	addc	a, r5
      007FB7 A3               [24]  749 	inc	dptr
      007FB8 F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      007FB9 90 09 AE         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_294
      007FBC E0               [24]  753 	movx	a,@dptr
      007FBD FD               [12]  754 	mov	r5,a
      007FBE A3               [24]  755 	inc	dptr
      007FBF E0               [24]  756 	movx	a,@dptr
      007FC0 FF               [12]  757 	mov	r7,a
      007FC1 12 85 01         [24]  758 	lcall	_ak820_outline_0184
      007FC4 E0               [24]  759 	movx	a,@dptr
      007FC5 FC               [12]  760 	mov	r4,a
      007FC6 EE               [12]  761 	mov	a,r6
      007FC7 5C               [12]  762 	anl	a,r4
      007FC8 B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      007FCB                        764 00124$:
      007FCB B3               [12]  765 	cpl	c
      007FCC 92 1F            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      007FCE 90 09 AD         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      007FD1 E0               [24]  768 	movx	a,@dptr
      007FD2 FB               [12]  769 	mov	r3,a
      007FD3 A2 1F            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      007FD5 E4               [12]  771 	clr	a
      007FD6 33               [12]  772 	rlc	a
      007FD7 B5 03 04         [24]  773 	cjne	a,ar3,00104$
      007FDA 75 82 00         [24]  774 	mov	dpl, #0x00
      007FDD 22               [24]  775 	ret
      007FDE                        776 00104$:
                                    777 ;	quantum/action_util.c:103: *bits ^= mask;
      007FDE EC               [12]  778 	mov	a,r4
      007FDF 62 06            [12]  779 	xrl	ar6,a
      007FE1 12 85 01         [24]  780 	lcall	_ak820_outline_0184
      007FE4 EE               [12]  781 	mov	a,r6
      007FE5 F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:104: return true;
      007FE6 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:105: }
      007FE9 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_299'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_300'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_300'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_300'
                                    795 ;old           Allocated with name '_change_owned_old_30000_302'
                                    796 ;result        Allocated with name '_change_owned_result_10001_303'
                                    797 ;i             Allocated with name '_change_owned_i_20001_304'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_304'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      007FEA                        805 _change_owned:
      007FEA E5 82            [12]  806 	mov	a,dpl
      007FEC 90 09 B1         [24]  807 	mov	dptr,#_change_owned_mods_10000_299
      007FEF F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      007FF0 90 09 B0         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007FF3 E0               [24]  811 	movx	a,@dptr
      007FF4 FF               [12]  812 	mov	r7,a
      007FF5 C3               [12]  813 	clr	c
      007FF6 13               [12]  814 	rrc	a
      007FF7 FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      007FF8 53 07 01         [24]  817 	anl	ar7,#0x01
      007FFB EF               [12]  818 	mov	a,r7
      007FFC B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007FFF                        820 00205$:
      007FFF 92 20            [24]  821 	mov  _change_owned_sloc0_1_0,c
      008001 B3               [12]  822 	cpl	c
      008002 E4               [12]  823 	clr	a
      008003 33               [12]  824 	rlc	a
      008004 F5 54            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      008006 EE               [12]  827 	mov	a,r6
      008007 60 06            [24]  828 	jz	00121$
      008009 7D 9E            [12]  829 	mov	r5,#_owned_weak_refs
      00800B 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      00800D 80 04            [24]  831 	sjmp	00122$
      00800F                        832 00121$:
      00800F 7D 96            [12]  833 	mov	r5,#_owned_mod_refs
      008011 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      008013                        835 00122$:
                                    836 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      008013 90 09 AA         [24]  837 	mov	dptr,#_ak820_macro_primitive
      008016 E0               [24]  838 	movx	a,@dptr
      008017 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      008019 EE               [12]  841 	mov	a,r6
      00801A 24 A8            [12]  842 	add	a, #_macro_mods
      00801C FB               [12]  843 	mov	r3,a
      00801D E4               [12]  844 	clr	a
      00801E 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      008020 12 4A 71         [24]  846 	lcall	_ak820_outline_0055
                                    847 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      008023 E5 54            [12]  848 	mov	a,_change_owned_sloc1_1_0
      008025 60 0A            [24]  849 	jz	00123$
      008027 90 09 B1         [24]  850 	mov	dptr,#_change_owned_mods_10000_299
      00802A E0               [24]  851 	movx	a,@dptr
      00802B F9               [12]  852 	mov	r1,a
      00802C EA               [12]  853 	mov	a,r2
      00802D 42 01            [12]  854 	orl	ar1,a
      00802F 80 07            [24]  855 	sjmp	00124$
      008031                        856 00123$:
      008031 90 09 B1         [24]  857 	mov	dptr,#_change_owned_mods_10000_299
      008034 E0               [24]  858 	movx	a,@dptr
      008035 F4               [12]  859 	cpl	a
      008036 5A               [12]  860 	anl	a,r2
      008037 F9               [12]  861 	mov	r1,a
      008038                        862 00124$:
      008038 12 36 42         [24]  863 	lcall	_ak820_outline_0121
      00803B E9               [12]  864 	mov	a,r1
      00803C F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      00803D E5 54            [12]  867 	mov	a,_change_owned_sloc1_1_0
      00803F 60 06            [24]  868 	jz	00125$
      008041 74 FF            [12]  869 	mov	a,#0xff
      008043 6A               [12]  870 	xrl	a,r2
      008044 FC               [12]  871 	mov	r4,a
      008045 80 02            [24]  872 	sjmp	00126$
      008047                        873 00125$:
      008047 8A 04            [24]  874 	mov	ar4,r2
      008049                        875 00126$:
      008049 90 09 B1         [24]  876 	mov	dptr,#_change_owned_mods_10000_299
      00804C E0               [24]  877 	movx	a,@dptr
      00804D 5C               [12]  878 	anl	a,r4
      00804E F0               [24]  879 	movx	@dptr,a
      00804F                        880 00102$:
                                    881 ;	quantum/action_util.c:115: uint8_t result = 0;
      00804F 90 09 B2         [24]  882 	mov	dptr,#_change_owned_result_10001_303
      008052 E4               [12]  883 	clr	a
      008053 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      008054 90 09 B3         [24]  886 	mov	dptr,#_change_owned_bit_20001_304
      008057 04               [12]  887 	inc	a
      008058 F0               [24]  888 	movx	@dptr,a
      008059 90 09 B1         [24]  889 	mov	dptr,#_change_owned_mods_10000_299
      00805C E0               [24]  890 	movx	a,@dptr
      00805D FC               [12]  891 	mov	r4,a
      00805E 7B 00            [12]  892 	mov	r3,#0x00
      008060                        893 00117$:
      008060 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      008063                        895 00210$:
      008063 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:117: if (mods & bit) {
      008065 90 09 B3         [24]  898 	mov	dptr,#_change_owned_bit_20001_304
      008068 E0               [24]  899 	movx	a,@dptr
      008069 5C               [12]  900 	anl	a,r4
      00806A 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      00806C E5 54            [12]  903 	mov	a,_change_owned_sloc1_1_0
      00806E 60 0C            [24]  904 	jz	00106$
      008070 EB               [12]  905 	mov	a,r3
      008071 2D               [12]  906 	add	a, r5
      008072 12 3A 16         [24]  907 	lcall	_ak820_outline_0013
      008075 F8               [12]  908 	mov	r0,a
      008076 08               [12]  909 	inc	r0
      008077 12 84 B5         [24]  910 	lcall	_ak820_outline_0063
      00807A 80 0C            [24]  911 	sjmp	00109$
      00807C                        912 00106$:
                                    913 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      00807C EB               [12]  914 	mov	a,r3
      00807D 2D               [12]  915 	add	a, r5
      00807E 12 3A 16         [24]  916 	lcall	_ak820_outline_0013
      008081 F8               [12]  917 	mov	r0,a
      008082 60 04            [24]  918 	jz	00109$
      008084 18               [12]  919 	dec	r0
      008085 12 84 B5         [24]  920 	lcall	_ak820_outline_0063
      008088                        921 00109$:
                                    922 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      008088 EB               [12]  923 	mov	a,r3
      008089 2D               [12]  924 	add	a, r5
      00808A 12 3A 16         [24]  925 	lcall	_ak820_outline_0013
      00808D 60 0B            [24]  926 	jz	00118$
      00808F 90 09 B3         [24]  927 	mov	dptr,#_change_owned_bit_20001_304
      008092 E0               [24]  928 	movx	a,@dptr
      008093 FA               [12]  929 	mov	r2,a
      008094 90 09 B2         [24]  930 	mov	dptr,#_change_owned_result_10001_303
      008097 E0               [24]  931 	movx	a,@dptr
      008098 4A               [12]  932 	orl	a,r2
      008099 F0               [24]  933 	movx	@dptr,a
      00809A                        934 00118$:
                                    935 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      00809A 0B               [12]  936 	inc	r3
      00809B 90 09 B3         [24]  937 	mov	dptr,#_change_owned_bit_20001_304
      00809E E0               [24]  938 	movx	a,@dptr
      00809F 25 E0            [12]  939 	add	a,acc
      0080A1 F0               [24]  940 	movx	@dptr,a
      0080A2 80 BC            [24]  941 	sjmp	00117$
      0080A4                        942 00112$:
                                    943 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      0080A4 EE               [12]  944 	mov	a,r6
      0080A5 60 09            [24]  945 	jz	00114$
      0080A7 90 09 B2         [24]  946 	mov	dptr,#_change_owned_result_10001_303
      0080AA E0               [24]  947 	movx	a,@dptr
      0080AB 90 09 A7         [24]  948 	mov	dptr,#_owned_weak_mods
      0080AE F0               [24]  949 	movx	@dptr,a
      0080AF 22               [24]  950 	ret
      0080B0                        951 00114$:
                                    952 ;	quantum/action_util.c:124: else owned_mods = result;
      0080B0 90 09 B2         [24]  953 	mov	dptr,#_change_owned_result_10001_303
      0080B3 E0               [24]  954 	movx	a,@dptr
      0080B4 90 09 A6         [24]  955 	mov	dptr,#_owned_mods
      0080B7 F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:125: }
      0080B8 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_312'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      0080B9                        968 _add_owned_mods:
      0080B9 E5 82            [12]  969 	mov	a,dpl
      0080BB 90 09 B4         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_312
      0080BE 12 84 D5         [24]  971 	lcall	_ak820_outline_0113
      0080C1 74 01            [12]  972 	mov	a,#0x01
      0080C3 F0               [24]  973 	movx	@dptr,a
      0080C4 8F 82            [24]  974 	mov	dpl, r7
      0080C6 02 7F EA         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_314'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      0080C9                        985 _del_owned_mods:
      0080C9 E5 82            [12]  986 	mov	a,dpl
      0080CB 90 09 B5         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_314
      0080CE 12 84 D5         [24]  988 	lcall	_ak820_outline_0113
      0080D1 12 7B 7C         [24]  989 	lcall	_ak820_outline_0183
      0080D4 02 7F EA         [24]  990 	ljmp	_change_owned
                                    991 ;------------------------------------------------------------
                                    992 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    993 ;------------------------------------------------------------
                                    994 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_316'
                                    995 ;------------------------------------------------------------
                                    996 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    997 ;	-----------------------------------------
                                    998 ;	 function add_owned_weak_mods
                                    999 ;	-----------------------------------------
      0080D7                       1000 _add_owned_weak_mods:
      0080D7 E5 82            [12] 1001 	mov	a,dpl
      0080D9 90 09 B6         [24] 1002 	mov	dptr,#_add_owned_weak_mods_mods_10000_316
      0080DC 12 84 D5         [24] 1003 	lcall	_ak820_outline_0113
      0080DF 74 03            [12] 1004 	mov	a,#0x03
      0080E1 F0               [24] 1005 	movx	@dptr,a
      0080E2 8F 82            [24] 1006 	mov	dpl, r7
      0080E4 02 7F EA         [24] 1007 	ljmp	_change_owned
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1010 ;------------------------------------------------------------
                                   1011 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_318'
                                   1012 ;------------------------------------------------------------
                                   1013 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1014 ;	-----------------------------------------
                                   1015 ;	 function del_owned_weak_mods
                                   1016 ;	-----------------------------------------
      0080E7                       1017 _del_owned_weak_mods:
      0080E7 E5 82            [12] 1018 	mov	a,dpl
      0080E9 90 09 B7         [24] 1019 	mov	dptr,#_del_owned_weak_mods_mods_10000_318
      0080EC 12 84 D5         [24] 1020 	lcall	_ak820_outline_0113
      0080EF 74 02            [12] 1021 	mov	a,#0x02
      0080F1 F0               [24] 1022 	movx	@dptr,a
      0080F2 8F 82            [24] 1023 	mov	dpl, r7
      0080F4 02 7F EA         [24] 1024 	ljmp	_change_owned
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1027 ;------------------------------------------------------------
                                   1028 ;i             Allocated with name '_clear_owned_mods_i_20000_322'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function clear_owned_mods
                                   1033 ;	-----------------------------------------
      0080F7                       1034 _clear_owned_mods:
                                   1035 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      0080F7 7F 00            [12] 1036 	mov	r7,#0x00
      0080F9                       1037 00103$:
      0080F9 BF 08 00         [24] 1038 	cjne	r7,#0x08,00122$
      0080FC                       1039 00122$:
      0080FC 50 1A            [24] 1040 	jnc	00101$
      0080FE EF               [12] 1041 	mov	a,r7
      0080FF 24 96            [12] 1042 	add	a, #_owned_mod_refs
      008101 FD               [12] 1043 	mov	r5,a
      008102 E4               [12] 1044 	clr	a
      008103 34 09            [12] 1045 	addc	a, #(_owned_mod_refs >> 8)
      008105 FE               [12] 1046 	mov	r6,a
      008106 EF               [12] 1047 	mov	a,r7
      008107 24 9E            [12] 1048 	add	a, #_owned_weak_refs
      008109 F5 82            [12] 1049 	mov	dpl,a
      00810B E4               [12] 1050 	clr	a
      00810C 34 09            [12] 1051 	addc	a, #(_owned_weak_refs >> 8)
      00810E F5 83            [12] 1052 	mov	dph,a
      008110 E4               [12] 1053 	clr	a
      008111 F0               [24] 1054 	movx	@dptr,a
      008112 12 84 DC         [24] 1055 	lcall	_ak820_outline_0118
      008115 0F               [12] 1056 	inc	r7
      008116 80 E1            [24] 1057 	sjmp	00103$
      008118                       1058 00101$:
                                   1059 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      008118 90 09 A9         [24] 1060 	mov	dptr,#(_macro_mods + 0x0001)
      00811B E4               [12] 1061 	clr	a
      00811C F0               [24] 1062 	movx	@dptr,a
      00811D 90 09 A8         [24] 1063 	mov	dptr,#_macro_mods
      008120 F0               [24] 1064 	movx	@dptr,a
      008121 90 09 A7         [24] 1065 	mov	dptr,#_owned_weak_mods
      008124 F0               [24] 1066 	movx	@dptr,a
      008125 90 09 A6         [24] 1067 	mov	dptr,#_owned_mods
      008128 F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      008129 90 09 AB         [24] 1070 	mov	dptr,#_ak820_macro_cancelled
      00812C 04               [12] 1071 	inc	a
      00812D F0               [24] 1072 	movx	@dptr,a
                                   1073 ;	quantum/action_util.c:134: }
      00812E 22               [24] 1074 	ret
                                   1075 ;------------------------------------------------------------
                                   1076 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1077 ;------------------------------------------------------------
                                   1078 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1079 ;i             Allocated with name '_clear_owned_keys_i_20000_326'
                                   1080 ;------------------------------------------------------------
                                   1081 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1082 ;	-----------------------------------------
                                   1083 ;	 function clear_owned_keys
                                   1084 ;	-----------------------------------------
      00812F                       1085 _clear_owned_keys:
                                   1086 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      00812F 7F 00            [12] 1087 	mov	r7,#0x00
      008131                       1088 00104$:
      008131 EF               [12] 1089 	mov	a,r7
      008132 24 5B            [12] 1090 	add	a,#0xff - 0xa4
      008134 40 0D            [24] 1091 	jc	00101$
                                   1092 ;	free result
      008136 EF               [12] 1093 	mov	a,r7
      008137 24 B8            [12] 1094 	add	a, #_key_refs
      008139 F5 82            [12] 1095 	mov	dpl,a
      00813B E4               [12] 1096 	clr	a
      00813C 34 09            [12] 1097 	addc	a, #(_key_refs >> 8)
      00813E 12 7F 6F         [24] 1098 	lcall	_ak820_outline_0159
      008141 80 EE            [24] 1099 	sjmp	00104$
      008143                       1100 00101$:
                                   1101 ;	quantum/action_util.c:142: distinct_keys = 0;
      008143 90 0A 5D         [24] 1102 	mov	dptr,#_distinct_keys
      008146 E4               [12] 1103 	clr	a
      008147 F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      008148 FF               [12] 1106 	mov	r7,a
      008149                       1107 00107$:
      008149 BF 15 00         [24] 1108 	cjne	r7,#0x15,00142$
      00814C                       1109 00142$:
      00814C 50 0D            [24] 1110 	jnc	00109$
      00814E EF               [12] 1111 	mov	a,r7
      00814F 24 5E            [12] 1112 	add	a, #_macro_keys
      008151 F5 82            [12] 1113 	mov	dpl,a
      008153 E4               [12] 1114 	clr	a
      008154 34 0A            [12] 1115 	addc	a, #(_macro_keys >> 8)
      008156 12 7F 6F         [24] 1116 	lcall	_ak820_outline_0159
      008159 80 EE            [24] 1117 	sjmp	00107$
      00815B                       1118 00109$:
                                   1119 ;	quantum/action_util.c:144: }
      00815B 22               [24] 1120 	ret
                                   1121 ;------------------------------------------------------------
                                   1122 ;Allocation info for local variables in function 'add_owned_key'
                                   1123 ;------------------------------------------------------------
                                   1124 ;code          Allocated with name '_add_owned_key_code_10000_327'
                                   1125 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_336'
                                   1126 ;key           Allocated with name '_add_owned_key_key_50000_337'
                                   1127 ;i             Allocated with name '_add_owned_key_i_40000_335'
                                   1128 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_339'
                                   1129 ;key           Allocated with name '_add_owned_key_key_40000_340'
                                   1130 ;------------------------------------------------------------
                                   1131 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1132 ;	-----------------------------------------
                                   1133 ;	 function add_owned_key
                                   1134 ;	-----------------------------------------
      00815C                       1135 _add_owned_key:
      00815C E5 82            [12] 1136 	mov	a,dpl
      00815E 90 0A 73         [24] 1137 	mov	dptr,#_add_owned_key_code_10000_327
      008161 12 84 ED         [24] 1138 	lcall	_ak820_outline_0129
                                   1139 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      008164 74 01            [12] 1140 	mov	a,#0x01
      008166 F0               [24] 1141 	movx	@dptr,a
      008167 90 0A 5E         [24] 1142 	mov	dptr,#_macro_keys
      00816A C0 07            [24] 1143 	push	ar7
      00816C 12 7F 7E         [24] 1144 	lcall	_ak820_macro_change
      00816F E5 82            [12] 1145 	mov	a, dpl
      008171 D0 07            [24] 1146 	pop	ar7
      008173 70 03            [24] 1147 	jnz	00102$
      008175 F5 82            [12] 1148 	mov	dpl,a
      008177 22               [24] 1149 	ret
      008178                       1150 00102$:
                                   1151 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      008178 12 84 A7         [24] 1152 	lcall	_ak820_outline_0028
      00817B FC               [12] 1153 	mov	r4,a
      00817C 04               [12] 1154 	inc	a
      00817D 12 84 DC         [24] 1155 	lcall	_ak820_outline_0118
      008180 EC               [12] 1156 	mov	a,r4
      008181 60 04            [24] 1157 	jz	00104$
      008183 75 82 00         [24] 1158 	mov	dpl, #0x00
      008186 22               [24] 1159 	ret
      008187                       1160 00104$:
                                   1161 ;	quantum/action_util.c:148: ++distinct_keys;
      008187 90 0A 5D         [24] 1162 	mov	dptr,#_distinct_keys
      00818A E0               [24] 1163 	movx	a,@dptr
      00818B 24 01            [12] 1164 	add	a, #0x01
      00818D F0               [24] 1165 	movx	@dptr,a
                                   1166 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      00818E 90 0D B1         [24] 1167 	mov	dptr,#_keyboard_protocol
      008191 E0               [24] 1168 	movx	a,@dptr
      008192 60 11            [24] 1169 	jz	00106$
      008194 90 0A E2         [24] 1170 	mov	dptr,#_keymap_config
      008197 E0               [24] 1171 	movx	a,@dptr
      008198 30 E7 0A         [24] 1172 	jnb	acc.7,00106$
                                   1173 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00819B 12 84 F8         [24] 1174 	lcall	_ak820_outline_0171
      00819E 12 72 F4         [24] 1175 	lcall	_add_key_to_report
                                   1176 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0081A1 75 82 01         [24] 1177 	mov	dpl, #0x01
      0081A4 22               [24] 1178 	ret
      0081A5                       1179 00106$:
                                   1180 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      0081A5 90 0A 5D         [24] 1181 	mov	dptr,#_distinct_keys
      0081A8 E0               [24] 1182 	movx	a,@dptr
      0081A9 24 F9            [12] 1183 	add	a,#0xff - 0x06
      0081AB 50 17            [24] 1184 	jnc	00110$
                                   1185 ;	free result
                                   1186 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      0081AD 7F 00            [12] 1187 	mov	r7,#0x00
      0081AF                       1188 00115$:
      0081AF BF 06 00         [24] 1189 	cjne	r7,#0x06,00174$
      0081B2                       1190 00174$:
      0081B2 50 1E            [24] 1191 	jnc	00111$
      0081B4 EF               [12] 1192 	mov	a,r7
      0081B5 24 C6            [12] 1193 	add	a, #(_actual_keyboard_report + 0x0002)
      0081B7 F5 82            [12] 1194 	mov	dpl,a
      0081B9 E4               [12] 1195 	clr	a
      0081BA 34 0D            [12] 1196 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      0081BC F5 83            [12] 1197 	mov	dph,a
      0081BE 74 01            [12] 1198 	mov	a,#0x01
      0081C0 F0               [24] 1199 	movx	@dptr,a
      0081C1 0F               [12] 1200 	inc	r7
      0081C2 80 EB            [24] 1201 	sjmp	00115$
      0081C4                       1202 00110$:
                                   1203 ;	quantum/action_util.c:154: } else add_key(code);
      0081C4 90 0A 73         [24] 1204 	mov	dptr,#_add_owned_key_code_10000_327
      0081C7 E0               [24] 1205 	movx	a,@dptr
                                   1206 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0081C8 90 08 27         [24] 1207 	mov	dptr,#_add_key_to_report_PARM_2
      0081CB F0               [24] 1208 	movx	@dptr,a
      0081CC 90 0D C4         [24] 1209 	mov	dptr,#_actual_keyboard_report
      0081CF 12 72 F4         [24] 1210 	lcall	_add_key_to_report
                                   1211 ;	quantum/action_util.c:154: } else add_key(code);
      0081D2                       1212 00111$:
                                   1213 ;	quantum/action_util.c:155: return true;
      0081D2 75 82 01         [24] 1214 	mov	dpl, #0x01
                                   1215 ;	quantum/action_util.c:156: }
      0081D5 22               [24] 1216 	ret
                                   1217 ;------------------------------------------------------------
                                   1218 ;Allocation info for local variables in function 'del_owned_key'
                                   1219 ;------------------------------------------------------------
                                   1220 ;code          Allocated with name '_del_owned_key_code_10000_342'
                                   1221 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_353'
                                   1222 ;key           Allocated with name '_del_owned_key_key_50000_354'
                                   1223 ;key           Allocated with name '_del_owned_key_key_40000_351'
                                   1224 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_359'
                                   1225 ;key           Allocated with name '_del_owned_key_key_70000_360'
                                   1226 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_362'
                                   1227 ;key           Allocated with name '_del_owned_key_key_40000_363'
                                   1228 ;------------------------------------------------------------
                                   1229 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1230 ;	-----------------------------------------
                                   1231 ;	 function del_owned_key
                                   1232 ;	-----------------------------------------
      0081D6                       1233 _del_owned_key:
      0081D6 E5 82            [12] 1234 	mov	a,dpl
      0081D8 90 0A 74         [24] 1235 	mov	dptr,#_del_owned_key_code_10000_342
      0081DB 12 84 ED         [24] 1236 	lcall	_ak820_outline_0129
                                   1237 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      0081DE E4               [12] 1238 	clr	a
      0081DF F0               [24] 1239 	movx	@dptr,a
      0081E0 90 0A 5E         [24] 1240 	mov	dptr,#_macro_keys
      0081E3 C0 07            [24] 1241 	push	ar7
      0081E5 12 7F 7E         [24] 1242 	lcall	_ak820_macro_change
      0081E8 E5 82            [12] 1243 	mov	a, dpl
      0081EA D0 07            [24] 1244 	pop	ar7
      0081EC 70 03            [24] 1245 	jnz	00102$
      0081EE F5 82            [12] 1246 	mov	dpl,a
      0081F0 22               [24] 1247 	ret
      0081F1                       1248 00102$:
                                   1249 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      0081F1 12 84 A7         [24] 1250 	lcall	_ak820_outline_0028
      0081F4 FC               [12] 1251 	mov	r4,a
      0081F5 60 07            [24] 1252 	jz	00103$
      0081F7 1C               [12] 1253 	dec	r4
      0081F8 12 45 41         [24] 1254 	lcall	_ak820_outline_0064
      0081FB EC               [12] 1255 	mov	a,r4
      0081FC 60 04            [24] 1256 	jz	00104$
      0081FE                       1257 00103$:
      0081FE 75 82 00         [24] 1258 	mov	dpl, #0x00
      008201 22               [24] 1259 	ret
      008202                       1260 00104$:
                                   1261 ;	quantum/action_util.c:160: --distinct_keys;
      008202 90 0A 5D         [24] 1262 	mov	dptr,#_distinct_keys
      008205 E0               [24] 1263 	movx	a,@dptr
      008206 14               [12] 1264 	dec	a
      008207 F0               [24] 1265 	movx	@dptr,a
                                   1266 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008208 90 0D B1         [24] 1267 	mov	dptr,#_keyboard_protocol
      00820B E0               [24] 1268 	movx	a,@dptr
      00820C 60 16            [24] 1269 	jz	00107$
      00820E 90 0A E2         [24] 1270 	mov	dptr,#_keymap_config
      008211 E0               [24] 1271 	movx	a,@dptr
      008212 30 E7 0F         [24] 1272 	jnb	acc.7,00107$
                                   1273 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      008215 90 08 2A         [24] 1274 	mov	dptr,#_del_key_from_report_PARM_2
      008218 EF               [12] 1275 	mov	a,r7
      008219 F0               [24] 1276 	movx	@dptr,a
      00821A 90 0D C4         [24] 1277 	mov	dptr,#_actual_keyboard_report
      00821D 12 73 28         [24] 1278 	lcall	_del_key_from_report
                                   1279 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008220 75 82 01         [24] 1280 	mov	dpl, #0x01
      008223 22               [24] 1281 	ret
      008224                       1282 00107$:
                                   1283 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      008224 90 0A 5D         [24] 1284 	mov	dptr,#_distinct_keys
      008227 E0               [24] 1285 	movx	a,@dptr
      008228 FF               [12] 1286 	mov  r7,a
      008229 24 F9            [12] 1287 	add	a,#0xff - 0x06
      00822B 50 04            [24] 1288 	jnc	00110$
                                   1289 ;	free result
      00822D 75 82 01         [24] 1290 	mov	dpl, #0x01
      008230 22               [24] 1291 	ret
      008231                       1292 00110$:
                                   1293 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      008231 BF 06 1F         [24] 1294 	cjne	r7,#0x06,00115$
                                   1295 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      008234 90 0D C4         [24] 1296 	mov	dptr,#_actual_keyboard_report
      008237 12 73 5C         [24] 1297 	lcall	_clear_keys_from_report
                                   1298 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      00823A 7F 04            [12] 1299 	mov	r7,#0x04
      00823C                       1300 00122$:
      00823C EF               [12] 1301 	mov	a,r7
      00823D 24 5B            [12] 1302 	add	a,#0xff - 0xa4
      00823F 40 20            [24] 1303 	jc	00116$
                                   1304 ;	free result
      008241 12 84 A7         [24] 1305 	lcall	_ak820_outline_0028
      008244 60 0A            [24] 1306 	jz	00123$
                                   1307 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008246 12 84 F8         [24] 1308 	lcall	_ak820_outline_0171
      008249 C0 07            [24] 1309 	push	ar7
      00824B 12 72 F4         [24] 1310 	lcall	_add_key_to_report
      00824E D0 07            [24] 1311 	pop	ar7
                                   1312 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008250                       1313 00123$:
      008250 0F               [12] 1314 	inc	r7
      008251 80 E9            [24] 1315 	sjmp	00122$
      008253                       1316 00115$:
                                   1317 ;	quantum/action_util.c:169: } else del_key(code);
      008253 90 0A 74         [24] 1318 	mov	dptr,#_del_owned_key_code_10000_342
      008256 E0               [24] 1319 	movx	a,@dptr
                                   1320 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      008257 90 08 2A         [24] 1321 	mov	dptr,#_del_key_from_report_PARM_2
      00825A F0               [24] 1322 	movx	@dptr,a
      00825B 90 0D C4         [24] 1323 	mov	dptr,#_actual_keyboard_report
      00825E 12 73 28         [24] 1324 	lcall	_del_key_from_report
                                   1325 ;	quantum/action_util.c:169: } else del_key(code);
      008261                       1326 00116$:
                                   1327 ;	quantum/action_util.c:170: return true;
      008261 75 82 01         [24] 1328 	mov	dpl, #0x01
                                   1329 ;	quantum/action_util.c:171: }
      008264 22               [24] 1330 	ret
                                   1331 ;------------------------------------------------------------
                                   1332 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1333 ;------------------------------------------------------------
                                   1334 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1335 ;i             Allocated with name '_clear_owned_usages_i_20000_368'
                                   1336 ;------------------------------------------------------------
                                   1337 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1338 ;	-----------------------------------------
                                   1339 ;	 function clear_owned_usages
                                   1340 ;	-----------------------------------------
      008265                       1341 _clear_owned_usages:
                                   1342 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      008265 7F 00            [12] 1343 	mov	r7,#0x00
      008267                       1344 00104$:
      008267 BF 1E 00         [24] 1345 	cjne	r7,#0x1e,00141$
      00826A                       1346 00141$:
      00826A 50 14            [24] 1347 	jnc	00101$
      00826C EF               [12] 1348 	mov	a,r7
      00826D 24 75            [12] 1349 	add	a, #_usage_refs
      00826F FD               [12] 1350 	mov	r5,a
      008270 E4               [12] 1351 	clr	a
      008271 34 0A            [12] 1352 	addc	a, #(_usage_refs >> 8)
      008273 FE               [12] 1353 	mov	r6,a
      008274 EF               [12] 1354 	mov	a,r7
      008275 12 84 BC         [24] 1355 	lcall	_ak820_outline_0067
      008278 E4               [12] 1356 	clr	a
      008279 F0               [24] 1357 	movx	@dptr,a
      00827A 12 84 DC         [24] 1358 	lcall	_ak820_outline_0118
      00827D 0F               [12] 1359 	inc	r7
      00827E 80 E7            [24] 1360 	sjmp	00104$
      008280                       1361 00101$:
                                   1362 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      008280 90 0A B2         [24] 1363 	mov	dptr,#(_usage_lengths + 0x0001)
      008283 E4               [12] 1364 	clr	a
      008284 F0               [24] 1365 	movx	@dptr,a
      008285 90 0A B1         [24] 1366 	mov	dptr,#_usage_lengths
      008288 F0               [24] 1367 	movx	@dptr,a
                                   1368 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      008289 FF               [12] 1369 	mov	r7,a
      00828A                       1370 00107$:
      00828A BF 04 00         [24] 1371 	cjne	r7,#0x04,00143$
      00828D                       1372 00143$:
      00828D 50 0D            [24] 1373 	jnc	00109$
      00828F EF               [12] 1374 	mov	a,r7
      008290 24 B3            [12] 1375 	add	a, #_macro_usages
      008292 F5 82            [12] 1376 	mov	dpl,a
      008294 E4               [12] 1377 	clr	a
      008295 34 0A            [12] 1378 	addc	a, #(_macro_usages >> 8)
      008297 12 7F 6F         [24] 1379 	lcall	_ak820_outline_0159
      00829A 80 EE            [24] 1380 	sjmp	00107$
      00829C                       1381 00109$:
                                   1382 ;	quantum/action_util.c:185: }
      00829C 22               [24] 1383 	ret
                                   1384 ;------------------------------------------------------------
                                   1385 ;Allocation info for local variables in function 'owned_usage_key'
                                   1386 ;------------------------------------------------------------
                                   1387 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1388 ;code          Allocated with name '_owned_usage_key_code_10000_369'
                                   1389 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_370'
                                   1390 ;which         Allocated with name '_owned_usage_key_which_10000_370'
                                   1391 ;base          Allocated with name '_owned_usage_key_base_10000_370'
                                   1392 ;count         Allocated with name '_owned_usage_key_count_10000_370'
                                   1393 ;index         Allocated with name '_owned_usage_key_index_10000_370'
                                   1394 ;pos           Allocated with name '_owned_usage_key_pos_30001_377'
                                   1395 ;i             Allocated with name '_owned_usage_key_i_40001_378'
                                   1396 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_381'
                                   1397 ;key           Allocated with name '_owned_usage_key_key_40000_382'
                                   1398 ;------------------------------------------------------------
                                   1399 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1400 ;	-----------------------------------------
                                   1401 ;	 function owned_usage_key
                                   1402 ;	-----------------------------------------
      00829D                       1403 _owned_usage_key:
      00829D E5 82            [12] 1404 	mov	a,dpl
      00829F 90 0A B8         [24] 1405 	mov	dptr,#_owned_usage_key_code_10000_369
      0082A2 F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      0082A3 E0               [24] 1408 	movx	a,@dptr
      0082A4 FF               [12] 1409 	mov	r7,a
      0082A5 BF A8 00         [24] 1410 	cjne	r7,#0xa8,00244$
      0082A8                       1411 00244$:
      0082A8 B3               [12] 1412 	cpl	c
      0082A9 92 21            [24] 1413 	mov	_owned_usage_key_sloc0_1_0,c
      0082AB E4               [12] 1414 	clr	a
      0082AC 33               [12] 1415 	rlc	a
      0082AD FF               [12] 1416 	mov	r7,a
      0082AE 90 0A BB         [24] 1417 	mov	dptr,#_owned_usage_key_which_10000_370
      0082B1 F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      0082B2 EF               [12] 1420 	mov	a,r7
      0082B3 60 02            [24] 1421 	jz	00129$
      0082B5 74 03            [12] 1422 	mov	a,#0x03
      0082B7                       1423 00129$:
      0082B7 FE               [12] 1424 	mov	r6,a
                                   1425 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      0082B8 EF               [12] 1426 	mov	a,r7
      0082B9 24 B1            [12] 1427 	add	a, #_usage_lengths
      0082BB FD               [12] 1428 	mov	r5,a
      0082BC E4               [12] 1429 	clr	a
      0082BD 34 0A            [12] 1430 	addc	a, #(_usage_lengths >> 8)
      0082BF FF               [12] 1431 	mov	r7,a
      0082C0 12 85 01         [24] 1432 	lcall	_ak820_outline_0184
      0082C3 E0               [24] 1433 	movx	a,@dptr
      0082C4 FC               [12] 1434 	mov	r4,a
                                   1435 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      0082C5 90 0A B8         [24] 1436 	mov	dptr,#_owned_usage_key_code_10000_369
      0082C8 E0               [24] 1437 	movx	a,@dptr
      0082C9 24 5B            [12] 1438 	add	a,#0x5b
      0082CB FB               [12] 1439 	mov	r3,a
                                   1440 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      0082CC 90 0A B7         [24] 1441 	mov	dptr,#_owned_usage_key_PARM_2
      0082CF E0               [24] 1442 	movx	a,@dptr
      0082D0 FA               [12] 1443 	mov	r2,a
      0082D1 90 09 AC         [24] 1444 	mov	dptr,#_ak820_macro_change_PARM_2
      0082D4 EB               [12] 1445 	mov	a,r3
      0082D5 F0               [24] 1446 	movx	@dptr,a
      0082D6 90 09 AD         [24] 1447 	mov	dptr,#_ak820_macro_change_PARM_3
      0082D9 EA               [12] 1448 	mov	a,r2
      0082DA F0               [24] 1449 	movx	@dptr,a
      0082DB 90 0A B3         [24] 1450 	mov	dptr,#_macro_usages
      0082DE C0 07            [24] 1451 	push	ar7
      0082E0 C0 06            [24] 1452 	push	ar6
      0082E2 C0 05            [24] 1453 	push	ar5
      0082E4 C0 04            [24] 1454 	push	ar4
      0082E6 C0 03            [24] 1455 	push	ar3
      0082E8 C0 02            [24] 1456 	push	ar2
      0082EA 12 7F 7E         [24] 1457 	lcall	_ak820_macro_change
      0082ED E5 82            [12] 1458 	mov	a, dpl
      0082EF D0 02            [24] 1459 	pop	ar2
      0082F1 D0 03            [24] 1460 	pop	ar3
      0082F3 D0 04            [24] 1461 	pop	ar4
      0082F5 D0 05            [24] 1462 	pop	ar5
      0082F7 D0 06            [24] 1463 	pop	ar6
      0082F9 D0 07            [24] 1464 	pop	ar7
      0082FB 70 01            [24] 1465 	jnz	00102$
      0082FD 22               [24] 1466 	ret
      0082FE                       1467 00102$:
                                   1468 ;	quantum/action_util.c:192: if (pressed) {
      0082FE EA               [12] 1469 	mov	a,r2
      0082FF 60 1A            [24] 1470 	jz	00115$
                                   1471 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      008301 12 84 C6         [24] 1472 	lcall	_ak820_outline_0073
      008304 04               [12] 1473 	inc	a
      008305 12 70 7A         [24] 1474 	lcall	_ak820_outline_0135
      008308 E8               [12] 1475 	mov	a,r0
      008309 60 01            [24] 1476 	jz	00104$
      00830B 22               [24] 1477 	ret
      00830C                       1478 00104$:
                                   1479 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      00830C 90 0A BC         [24] 1480 	mov	dptr,#_owned_usage_key_count_10000_370
      00830F EC               [12] 1481 	mov	a,r4
      008310 04               [12] 1482 	inc	a
      008311 F0               [24] 1483 	movx	@dptr,a
      008312 EC               [12] 1484 	mov	a,r4
      008313 2E               [12] 1485 	add	a, r6
      008314 12 84 BC         [24] 1486 	lcall	_ak820_outline_0067
      008317 EB               [12] 1487 	mov	a,r3
      008318 F0               [24] 1488 	movx	@dptr,a
      008319 61 7C            [12] 1489 	ajmp	00116$
      00831B                       1490 00115$:
                                   1491 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      00831B 12 84 C6         [24] 1492 	lcall	_ak820_outline_0073
      00831E 60 07            [24] 1493 	jz	00105$
      008320 18               [12] 1494 	dec	r0
      008321 12 84 B5         [24] 1495 	lcall	_ak820_outline_0063
      008324 E8               [12] 1496 	mov	a,r0
      008325 60 01            [24] 1497 	jz	00106$
      008327                       1498 00105$:
      008327 22               [24] 1499 	ret
      008328                       1500 00106$:
                                   1501 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      008328 7A 00            [12] 1502 	mov	r2,#0x00
      00832A                       1503 00108$:
      00832A EA               [12] 1504 	mov	a,r2
      00832B 2E               [12] 1505 	add	a, r6
      00832C 12 84 BC         [24] 1506 	lcall	_ak820_outline_0067
      00832F E0               [24] 1507 	movx	a,@dptr
      008330 B5 03 02         [24] 1508 	cjne	a,ar3,00251$
      008333 80 03            [24] 1509 	sjmp	00167$
      008335                       1510 00251$:
      008335 0A               [12] 1511 	inc	r2
      008336 80 F2            [24] 1512 	sjmp	00108$
      008338                       1513 00167$:
      008338 90 0A BD         [24] 1514 	mov	dptr,#_owned_usage_key_pos_30001_377
      00833B EA               [12] 1515 	mov	a,r2
      00833C F0               [24] 1516 	movx	@dptr,a
                                   1517 ;	quantum/action_util.c:199: --count;
      00833D 1C               [12] 1518 	dec	r4
      00833E 90 0A BC         [24] 1519 	mov	dptr,#_owned_usage_key_count_10000_370
      008341 EC               [12] 1520 	mov	a,r4
      008342 F0               [24] 1521 	movx	@dptr,a
                                   1522 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      008343 8A 03            [24] 1523 	mov	ar3,r2
      008345                       1524 00125$:
      008345 C3               [12] 1525 	clr	c
      008346 EB               [12] 1526 	mov	a,r3
      008347 9C               [12] 1527 	subb	a,r4
      008348 50 23            [24] 1528 	jnc	00111$
      00834A C0 05            [24] 1529 	push	ar5
      00834C C0 07            [24] 1530 	push	ar7
      00834E EB               [12] 1531 	mov	a,r3
      00834F 2E               [12] 1532 	add	a, r6
      008350 FA               [12] 1533 	mov	r2,a
      008351 24 93            [12] 1534 	add	a, #_usage_order
      008353 F8               [12] 1535 	mov	r0,a
      008354 E4               [12] 1536 	clr	a
      008355 34 0A            [12] 1537 	addc	a, #(_usage_order >> 8)
      008357 F9               [12] 1538 	mov	r1,a
      008358 0A               [12] 1539 	inc	r2
      008359 EA               [12] 1540 	mov	a,r2
      00835A 33               [12] 1541 	rlc	a
      00835B 95 E0            [12] 1542 	subb	a,acc
      00835D FF               [12] 1543 	mov	r7,a
      00835E EA               [12] 1544 	mov	a,r2
      00835F 12 84 E2         [24] 1545 	lcall	_ak820_outline_0123
      008362 12 3A B0         [24] 1546 	lcall	_ak820_outline_0154
      008365 F0               [24] 1547 	movx	@dptr,a
      008366 0B               [12] 1548 	inc	r3
      008367 D0 07            [24] 1549 	pop	ar7
      008369 D0 05            [24] 1550 	pop	ar5
      00836B 80 D8            [24] 1551 	sjmp	00125$
      00836D                       1552 00111$:
                                   1553 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      00836D 12 85 01         [24] 1554 	lcall	_ak820_outline_0184
      008370 EC               [12] 1555 	mov	a,r4
      008371 F0               [24] 1556 	movx	@dptr,a
                                   1557 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      008372 90 0A BD         [24] 1558 	mov	dptr,#_owned_usage_key_pos_30001_377
      008375 E0               [24] 1559 	movx	a,@dptr
      008376 B5 04 02         [24] 1560 	cjne	a,ar4,00253$
      008379 80 01            [24] 1561 	sjmp	00116$
      00837B                       1562 00253$:
      00837B 22               [24] 1563 	ret
      00837C                       1564 00116$:
                                   1565 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      00837C 90 0A BC         [24] 1566 	mov	dptr,#_owned_usage_key_count_10000_370
      00837F E0               [24] 1567 	movx	a,@dptr
      008380 FC               [12] 1568 	mov	r4,a
      008381 12 85 01         [24] 1569 	lcall	_ak820_outline_0184
      008384 F0               [24] 1570 	movx	@dptr,a
                                   1571 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      008385 EC               [12] 1572 	mov	a,r4
      008386 60 15            [24] 1573 	jz	00131$
      008388 EC               [12] 1574 	mov	a,r4
      008389 2E               [12] 1575 	add	a, r6
      00838A FE               [12] 1576 	mov	r6,a
      00838B 1E               [12] 1577 	dec	r6
      00838C EE               [12] 1578 	mov	a,r6
      00838D 33               [12] 1579 	rlc	a
      00838E 95 E0            [12] 1580 	subb	a,acc
      008390 FF               [12] 1581 	mov	r7,a
      008391 EE               [12] 1582 	mov	a,r6
      008392 12 84 E2         [24] 1583 	lcall	_ak820_outline_0123
      008395 24 A5            [12] 1584 	add	a,#0xa5
      008397 FE               [12] 1585 	mov	r6,a
      008398 33               [12] 1586 	rlc	a
      008399 95 E0            [12] 1587 	subb	a,acc
      00839B 80 02            [24] 1588 	sjmp	00132$
      00839D                       1589 00131$:
      00839D 7E 00            [12] 1590 	mov	r6,#0x00
      00839F                       1591 00132$:
      00839F 90 0A B8         [24] 1592 	mov	dptr,#_owned_usage_key_code_10000_369
      0083A2 EE               [12] 1593 	mov	a,r6
      0083A3 F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      0083A4 90 0A BB         [24] 1596 	mov	dptr,#_owned_usage_key_which_10000_370
      0083A7 E0               [24] 1597 	movx	a,@dptr
      0083A8 60 18            [24] 1598 	jz	00118$
      0083AA EE               [12] 1599 	mov	a,r6
      0083AB 60 0B            [24] 1600 	jz	00133$
      0083AD 8E 82            [24] 1601 	mov	dpl, r6
      0083AF 12 71 B1         [24] 1602 	lcall	_KEYCODE2CONSUMER
      0083B2 AD 82            [24] 1603 	mov	r5, dpl
      0083B4 AF 83            [24] 1604 	mov	r7, dph
      0083B6 80 04            [24] 1605 	sjmp	00134$
      0083B8                       1606 00133$:
      0083B8 7D 00            [12] 1607 	mov	r5,#0x00
      0083BA 7F 00            [12] 1608 	mov	r7,#0x00
      0083BC                       1609 00134$:
      0083BC 12 85 01         [24] 1610 	lcall	_ak820_outline_0184
      0083BF 02 71 6C         [24] 1611 	ljmp	_host_consumer_send
      0083C2                       1612 00118$:
                                   1613 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      0083C2 EE               [12] 1614 	mov	a,r6
      0083C3 60 22            [24] 1615 	jz	00135$
                                   1616 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      0083C5 BE A5 00         [24] 1617 	cjne	r6,#0xa5,00258$
      0083C8                       1618 00258$:
      0083C8 40 05            [24] 1619 	jc	00121$
      0083CA EE               [12] 1620 	mov	a,r6
      0083CB 24 58            [12] 1621 	add	a,#0xff - 0xa7
      0083CD 50 08            [24] 1622 	jnc	00122$
                                   1623 ;	free result
      0083CF                       1624 00121$:
      0083CF 90 0A B9         [24] 1625 	mov	dptr,#_owned_usage_key___200000085_20000_370
      0083D2 12 51 43         [24] 1626 	lcall	_ak820_outline_0165
      0083D5 80 09            [24] 1627 	sjmp	00123$
      0083D7                       1628 00122$:
                                   1629 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      0083D7 74 DC            [12] 1630 	mov	a,#0xdc
      0083D9 2E               [12] 1631 	add	a, r6
      0083DA 90 0A B9         [24] 1632 	mov	dptr,#_owned_usage_key___200000085_20000_370
      0083DD 12 3A A0         [24] 1633 	lcall	_ak820_outline_0122
                                   1634 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      0083E0                       1635 00123$:
      0083E0 90 0A B9         [24] 1636 	mov	dptr,#_owned_usage_key___200000085_20000_370
      0083E3 E0               [24] 1637 	movx	a,@dptr
      0083E4 FF               [12] 1638 	mov	r7,a
      0083E5 80 02            [24] 1639 	sjmp	00136$
      0083E7                       1640 00135$:
      0083E7 7F 00            [12] 1641 	mov	r7,#0x00
      0083E9                       1642 00136$:
      0083E9 7E 00            [12] 1643 	mov	r6,#0x00
      0083EB 12 45 86         [24] 1644 	lcall	_ak820_outline_0155
                                   1645 ;	quantum/action_util.c:208: }
      0083EE 02 71 3D         [24] 1646 	ljmp	_host_system_send
                                   1647 ;------------------------------------------------------------
                                   1648 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1649 ;------------------------------------------------------------
                                   1650 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_389'
                                   1651 ;changed       Allocated with name '_send_keyboard_report_changed_10001_389'
                                   1652 ;dest          Allocated with name '_send_keyboard_report_dest_10001_389'
                                   1653 ;src           Allocated with name '_send_keyboard_report_src_10001_389'
                                   1654 ;i             Allocated with name '_send_keyboard_report_i_20001_390'
                                   1655 ;------------------------------------------------------------
                                   1656 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1657 ;	-----------------------------------------
                                   1658 ;	 function send_keyboard_report
                                   1659 ;	-----------------------------------------
      0083F1                       1660 _send_keyboard_report:
                                   1661 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      0083F1 90 0D C2         [24] 1662 	mov	dptr,#_real_mods
      0083F4 E0               [24] 1663 	movx	a,@dptr
      0083F5 FF               [12] 1664 	mov	r7,a
      0083F6 90 0D C4         [24] 1665 	mov	dptr,#_actual_keyboard_report
      0083F9 F0               [24] 1666 	movx	@dptr,a
                                   1667 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      0083FA 90 0D C3         [24] 1668 	mov	dptr,#_weak_mods
      0083FD E0               [24] 1669 	movx	a,@dptr
      0083FE 42 07            [12] 1670 	orl	ar7,a
      008400 90 0D C4         [24] 1671 	mov	dptr,#_actual_keyboard_report
      008403 EF               [12] 1672 	mov	a,r7
      008404 F0               [24] 1673 	movx	@dptr,a
                                   1674 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      008405 90 09 A7         [24] 1675 	mov	dptr,#_owned_weak_mods
      008408 E0               [24] 1676 	movx	a,@dptr
      008409 FE               [12] 1677 	mov	r6,a
      00840A 90 09 A6         [24] 1678 	mov	dptr,#_owned_mods
      00840D E0               [24] 1679 	movx	a,@dptr
      00840E 4E               [12] 1680 	orl	a,r6
      00840F 42 07            [12] 1681 	orl	ar7,a
      008411 90 0D C4         [24] 1682 	mov	dptr,#_actual_keyboard_report
      008414 EF               [12] 1683 	mov	a,r7
      008415 F0               [24] 1684 	movx	@dptr,a
                                   1685 ;	quantum/action_util.c:515: bool changed = false;
      008416 90 0A DF         [24] 1686 	mov	dptr,#_send_keyboard_report_changed_10001_389
      008419 E4               [12] 1687 	clr	a
      00841A F0               [24] 1688 	movx	@dptr,a
                                   1689 ;	quantum/action_util.c:517: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1690 ;	quantum/action_util.c:518: const uint8_t __xdata *src = (const uint8_t __xdata *)AK820_REPORT_OUT;
                                   1691 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      00841B FF               [12] 1692 	mov	r7,a
      00841C                       1693 00107$:
      00841C BF 20 00         [24] 1694 	cjne	r7,#0x20,00140$
      00841F                       1695 00140$:
      00841F 50 2B            [24] 1696 	jnc	00103$
                                   1697 ;	quantum/action_util.c:524: if (dest[i] != src[i]) {
      008421 EF               [12] 1698 	mov	a,r7
      008422 24 BF            [12] 1699 	add	a, #_send_keyboard_report_last_report_10001_389
      008424 FD               [12] 1700 	mov	r5,a
      008425 E4               [12] 1701 	clr	a
      008426 34 0A            [12] 1702 	addc	a, #(_send_keyboard_report_last_report_10001_389 >> 8)
      008428 FE               [12] 1703 	mov	r6,a
      008429 12 4A 7F         [24] 1704 	lcall	_ak820_outline_0074
      00842C EF               [12] 1705 	mov	a,r7
      00842D 24 C4            [12] 1706 	add	a, #_actual_keyboard_report
      00842F F5 82            [12] 1707 	mov	dpl,a
      008431 E4               [12] 1708 	clr	a
      008432 34 0D            [12] 1709 	addc	a, #(_actual_keyboard_report >> 8)
      008434 F5 83            [12] 1710 	mov	dph,a
      008436 E0               [24] 1711 	movx	a,@dptr
      008437 FB               [12] 1712 	mov	r3,a
      008438 EC               [12] 1713 	mov	a,r4
      008439 B5 03 02         [24] 1714 	cjne	a,ar3,00142$
      00843C 80 0B            [24] 1715 	sjmp	00108$
      00843E                       1716 00142$:
                                   1717 ;	quantum/action_util.c:525: dest[i] = src[i];
      00843E 12 3A A5         [24] 1718 	lcall	_ak820_outline_0131
      008441 EB               [12] 1719 	mov	a,r3
      008442 F0               [24] 1720 	movx	@dptr,a
                                   1721 ;	quantum/action_util.c:526: changed = true;
      008443 90 0A DF         [24] 1722 	mov	dptr,#_send_keyboard_report_changed_10001_389
      008446 74 01            [12] 1723 	mov	a,#0x01
      008448 F0               [24] 1724 	movx	@dptr,a
      008449                       1725 00108$:
                                   1726 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008449 0F               [12] 1727 	inc	r7
      00844A 80 D0            [24] 1728 	sjmp	00107$
      00844C                       1729 00103$:
                                   1730 ;	quantum/action_util.c:529: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      00844C 90 0A DF         [24] 1731 	mov	dptr,#_send_keyboard_report_changed_10001_389
      00844F E0               [24] 1732 	movx	a,@dptr
      008450 60 09            [24] 1733 	jz	00109$
      008452 90 0D C4         [24] 1734 	mov	dptr,#_actual_keyboard_report
      008455 75 F0 00         [24] 1735 	mov	b, #0x00
                                   1736 ;	quantum/action_util.c:538: }
      008458 02 70 B2         [24] 1737 	ljmp	_host_keyboard_send
      00845B                       1738 00109$:
      00845B 22               [24] 1739 	ret
                                   1740 ;------------------------------------------------------------
                                   1741 ;Allocation info for local variables in function 'get_mods'
                                   1742 ;------------------------------------------------------------
                                   1743 ;	quantum/action_util.c:544: uint8_t get_mods(void) {
                                   1744 ;	-----------------------------------------
                                   1745 ;	 function get_mods
                                   1746 ;	-----------------------------------------
      00845C                       1747 _get_mods:
      00845C C0 07            [24] 1748 	push	ar7
                                   1749 ;	quantum/action_util.c:549: ;
      00845E 90 09 A6         [24] 1750 	mov	dptr,#_owned_mods
      008461 E0               [24] 1751 	movx	a,@dptr
      008462 FF               [12] 1752 	mov	r7,a
      008463 90 0D C2         [24] 1753 	mov	dptr,#_real_mods
      008466 12 7F 69         [24] 1754 	lcall	_ak820_outline_0139
                                   1755 ;	quantum/action_util.c:550: }
      008469 D0 07            [24] 1756 	pop	ar7
      00846B 22               [24] 1757 	ret
                                   1758 ;------------------------------------------------------------
                                   1759 ;Allocation info for local variables in function 'add_mods'
                                   1760 ;------------------------------------------------------------
                                   1761 ;mods          Allocated with name '_add_mods_mods_10000_397'
                                   1762 ;------------------------------------------------------------
                                   1763 ;	quantum/action_util.c:555: void add_mods(uint8_t mods) {
                                   1764 ;	-----------------------------------------
                                   1765 ;	 function clear_mods
                                   1766 ;	-----------------------------------------
      00846C                       1767 _clear_mods:
                                   1768 ;	quantum/action_util.c:577: real_mods = 0;
      00846C 90 0D C2         [24] 1769 	mov	dptr,#_real_mods
      00846F E4               [12] 1770 	clr	a
      008470 F0               [24] 1771 	movx	@dptr,a
                                   1772 ;	quantum/action_util.c:578: }
      008471 22               [24] 1773 	ret
                                   1774 ;------------------------------------------------------------
                                   1775 ;Allocation info for local variables in function 'get_weak_mods'
                                   1776 ;------------------------------------------------------------
                                   1777 ;	quantum/action_util.c:584: uint8_t get_weak_mods(void) {
                                   1778 ;	-----------------------------------------
                                   1779 ;	 function get_weak_mods
                                   1780 ;	-----------------------------------------
      008472                       1781 _get_weak_mods:
      008472 C0 07            [24] 1782 	push	ar7
                                   1783 ;	quantum/action_util.c:589: ;
      008474 90 09 A7         [24] 1784 	mov	dptr,#_owned_weak_mods
      008477 E0               [24] 1785 	movx	a,@dptr
      008478 FF               [12] 1786 	mov	r7,a
      008479 90 0D C3         [24] 1787 	mov	dptr,#_weak_mods
      00847C 12 7F 69         [24] 1788 	lcall	_ak820_outline_0139
                                   1789 ;	quantum/action_util.c:590: }
      00847F D0 07            [24] 1790 	pop	ar7
      008481 22               [24] 1791 	ret
                                   1792 ;------------------------------------------------------------
                                   1793 ;Allocation info for local variables in function 'add_weak_mods'
                                   1794 ;------------------------------------------------------------
                                   1795 ;mods          Allocated with name '_add_weak_mods_mods_10000_407'
                                   1796 ;------------------------------------------------------------
                                   1797 ;	quantum/action_util.c:595: void add_weak_mods(uint8_t mods) {
                                   1798 ;	-----------------------------------------
                                   1799 ;	 function add_weak_mods
                                   1800 ;	-----------------------------------------
      008482                       1801 _add_weak_mods:
      008482 E5 82            [12] 1802 	mov	a,dpl
      008484 90 0A E0         [24] 1803 	mov	dptr,#_add_weak_mods_mods_10000_407
      008487 F0               [24] 1804 	movx	@dptr,a
                                   1805 ;	quantum/action_util.c:596: weak_mods |= mods;
      008488 E0               [24] 1806 	movx	a,@dptr
      008489 FF               [12] 1807 	mov	r7,a
      00848A 90 0D C3         [24] 1808 	mov	dptr,#_weak_mods
      00848D E0               [24] 1809 	movx	a,@dptr
      00848E 4F               [12] 1810 	orl	a,r7
      00848F F0               [24] 1811 	movx	@dptr,a
                                   1812 ;	quantum/action_util.c:597: }
      008490 22               [24] 1813 	ret
                                   1814 ;------------------------------------------------------------
                                   1815 ;Allocation info for local variables in function 'del_weak_mods'
                                   1816 ;------------------------------------------------------------
                                   1817 ;mods          Allocated with name '_del_weak_mods_mods_10000_409'
                                   1818 ;------------------------------------------------------------
                                   1819 ;	quantum/action_util.c:602: void del_weak_mods(uint8_t mods) {
                                   1820 ;	-----------------------------------------
                                   1821 ;	 function del_weak_mods
                                   1822 ;	-----------------------------------------
      008491                       1823 _del_weak_mods:
      008491 E5 82            [12] 1824 	mov	a,dpl
      008493 90 0A E1         [24] 1825 	mov	dptr,#_del_weak_mods_mods_10000_409
      008496 F0               [24] 1826 	movx	@dptr,a
                                   1827 ;	quantum/action_util.c:603: weak_mods &= ~mods;
      008497 E0               [24] 1828 	movx	a,@dptr
      008498 F4               [12] 1829 	cpl	a
      008499 FF               [12] 1830 	mov	r7,a
      00849A 90 0D C3         [24] 1831 	mov	dptr,#_weak_mods
      00849D E0               [24] 1832 	movx	a,@dptr
      00849E 5F               [12] 1833 	anl	a,r7
      00849F F0               [24] 1834 	movx	@dptr,a
                                   1835 ;	quantum/action_util.c:604: }
      0084A0 22               [24] 1836 	ret
                                   1837 ;------------------------------------------------------------
                                   1838 ;Allocation info for local variables in function 'set_weak_mods'
                                   1839 ;------------------------------------------------------------
                                   1840 ;mods          Allocated with name '_set_weak_mods_mods_10000_411'
                                   1841 ;------------------------------------------------------------
                                   1842 ;	quantum/action_util.c:609: void set_weak_mods(uint8_t mods) {
                                   1843 ;	-----------------------------------------
                                   1844 ;	 function clear_weak_mods
                                   1845 ;	-----------------------------------------
      0084A1                       1846 _clear_weak_mods:
                                   1847 ;	quantum/action_util.c:617: weak_mods = 0;
      0084A1 90 0D C3         [24] 1848 	mov	dptr,#_weak_mods
      0084A4 E4               [12] 1849 	clr	a
      0084A5 F0               [24] 1850 	movx	@dptr,a
                                   1851 ;	quantum/action_util.c:618: }
      0084A6 22               [24] 1852 	ret
                                   1853 ;------------------------------------------------------------
                                   1854 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1855 ;------------------------------------------------------------
                                   1856 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_415'
                                   1857 ;------------------------------------------------------------
                                   1858 ;	quantum/action_util.c:700: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1859 ;	-----------------------------------------
                                   1860 	.area CSEG    (CODE)
                                   1861 	.area CONST   (CODE)
                                   1862 	.area XINIT   (CODE)
      00C377                       1863 __xinit__real_mods:
      00C377 00                    1864 	.db #0x00	; 0
      00C378                       1865 __xinit__weak_mods:
      00C378 00                    1866 	.db #0x00	; 0
      00C379                       1867 __xinit__actual_keyboard_report:
      00C379 00                    1868 	.db #0x00	; 0
      00C37A 00                    1869 	.db #0x00	; 0
      00C37B 00                    1870 	.db #0x00	; 0
      00C37C 00                    1871 	.db #0x00	; 0
      00C37D 00                    1872 	.db #0x00	; 0
      00C37E 00                    1873 	.db #0x00	; 0
      00C37F 00                    1874 	.db #0x00	; 0
      00C380 00                    1875 	.db #0x00	; 0
      00C381 00                    1876 	.db 0x00
      00C382 00                    1877 	.db 0x00
      00C383 00                    1878 	.db 0x00
      00C384 00                    1879 	.db 0x00
      00C385 00                    1880 	.db 0x00
      00C386 00                    1881 	.db 0x00
      00C387 00                    1882 	.db 0x00
      00C388 00                    1883 	.db 0x00
      00C389 00                    1884 	.db 0x00
      00C38A 00                    1885 	.db 0x00
      00C38B 00                    1886 	.db 0x00
      00C38C 00                    1887 	.db 0x00
      00C38D 00                    1888 	.db 0x00
      00C38E 00                    1889 	.db 0x00
      00C38F 00                    1890 	.db 0x00
      00C390 00                    1891 	.db 0x00
      00C391 00                    1892 	.db 0x00
      00C392 00                    1893 	.db 0x00
      00C393 00                    1894 	.db 0x00
      00C394 00                    1895 	.db 0x00
      00C395 00                    1896 	.db 0x00
      00C396 00                    1897 	.db 0x00
      00C397 00                    1898 	.db 0x00
      00C398 00                    1899 	.db 0x00
                                   1900 	.area CABS    (ABS,CODE)
                                   1901 
                                   1902 ; Experimental exact instruction outlining.
                                   1903 	.globl _ak820_outline_0013
                                   1904 	.globl _ak820_outline_0028
                                   1905 	.globl _ak820_outline_0055
                                   1906 	.globl _ak820_outline_0059
                                   1907 	.globl _ak820_outline_0062
                                   1908 	.globl _ak820_outline_0063
                                   1909 	.globl _ak820_outline_0064
                                   1910 	.globl _ak820_outline_0067
                                   1911 	.globl _ak820_outline_0073
                                   1912 	.globl _ak820_outline_0074
                                   1913 	.globl _ak820_outline_0103
                                   1914 	.globl _ak820_outline_0104
                                   1915 	.globl _ak820_outline_0113
                                   1916 	.globl _ak820_outline_0118
                                   1917 	.globl _ak820_outline_0121
                                   1918 	.globl _ak820_outline_0122
                                   1919 	.globl _ak820_outline_0123
                                   1920 	.globl _ak820_outline_0129
                                   1921 	.globl _ak820_outline_0131
                                   1922 	.globl _ak820_outline_0135
                                   1923 	.globl _ak820_outline_0139
                                   1924 	.globl _ak820_outline_0154
                                   1925 	.globl _ak820_outline_0155
                                   1926 	.globl _ak820_outline_0159
                                   1927 	.globl _ak820_outline_0165
                                   1928 	.globl _ak820_outline_0171
                                   1929 	.globl _ak820_outline_0182
                                   1930 	.globl _ak820_outline_0183
                                   1931 	.globl _ak820_outline_0184
                                   1932 
                                   1933 	.area CSEG (CODE)
                                   1934 ; function ak820_outline_0028
      0084A7                       1935 _ak820_outline_0028:
      0084A7 EF               [12] 1936 	mov	a,r7
      0084A8 24 B8            [12] 1937 	add	a,#_key_refs
      0084AA FD               [12] 1938 	mov	r5,a
      0084AB E4               [12] 1939 	clr	a
      0084AC 34 09            [12] 1940 	addc	a,#(_key_refs>>8)
      0084AE FE               [12] 1941 	mov	r6,a
      0084AF 8D 82            [24] 1942 	mov	dpl,r5
      0084B1 8E 83            [24] 1943 	mov	dph,r6
      0084B3 E0               [24] 1944 	movx	a,@dptr
      0084B4 22               [24] 1945 	ret
                                   1946 
                                   1947 	.area CSEG (CODE)
                                   1948 ; function ak820_outline_0063
      0084B5                       1949 _ak820_outline_0063:
      0084B5 89 82            [24] 1950 	mov	dpl,r1
      0084B7 8A 83            [24] 1951 	mov	dph,r2
      0084B9 E8               [12] 1952 	mov	a,r0
      0084BA F0               [24] 1953 	movx	@dptr,a
      0084BB 22               [24] 1954 	ret
                                   1955 
                                   1956 	.area CSEG (CODE)
                                   1957 ; function ak820_outline_0067
      0084BC                       1958 _ak820_outline_0067:
      0084BC 24 93            [12] 1959 	add	a,#_usage_order
      0084BE F5 82            [12] 1960 	mov	dpl,a
      0084C0 E4               [12] 1961 	clr	a
      0084C1 34 0A            [12] 1962 	addc	a,#(_usage_order>>8)
      0084C3 F5 83            [12] 1963 	mov	dph,a
      0084C5 22               [24] 1964 	ret
                                   1965 
                                   1966 	.area CSEG (CODE)
                                   1967 ; function ak820_outline_0073
      0084C6                       1968 _ak820_outline_0073:
      0084C6 EB               [12] 1969 	mov	a,r3
      0084C7 24 75            [12] 1970 	add	a,#_usage_refs
      0084C9 F9               [12] 1971 	mov	r1,a
      0084CA E4               [12] 1972 	clr	a
      0084CB 34 0A            [12] 1973 	addc	a,#(_usage_refs>>8)
      0084CD FA               [12] 1974 	mov	r2,a
      0084CE 89 82            [24] 1975 	mov	dpl,r1
      0084D0 8A 83            [24] 1976 	mov	dph,r2
      0084D2 E0               [24] 1977 	movx	a,@dptr
      0084D3 F8               [12] 1978 	mov	r0,a
      0084D4 22               [24] 1979 	ret
                                   1980 
                                   1981 	.area CSEG (CODE)
                                   1982 ; function ak820_outline_0113
      0084D5                       1983 _ak820_outline_0113:
      0084D5 F0               [24] 1984 	movx	@dptr,a
      0084D6 E0               [24] 1985 	movx	a,@dptr
      0084D7 FF               [12] 1986 	mov	r7,a
      0084D8 90 09 B0         [24] 1987 	mov	dptr,#_change_owned_PARM_2
      0084DB 22               [24] 1988 	ret
                                   1989 
                                   1990 	.area CSEG (CODE)
                                   1991 ; function ak820_outline_0118
      0084DC                       1992 _ak820_outline_0118:
      0084DC 8D 82            [24] 1993 	mov	dpl,r5
      0084DE 8E 83            [24] 1994 	mov	dph,r6
      0084E0 F0               [24] 1995 	movx	@dptr,a
      0084E1 22               [24] 1996 	ret
                                   1997 
                                   1998 	.area CSEG (CODE)
                                   1999 ; function ak820_outline_0123
      0084E2                       2000 _ak820_outline_0123:
      0084E2 24 93            [12] 2001 	add	a,#_usage_order
      0084E4 F5 82            [12] 2002 	mov	dpl,a
      0084E6 EF               [12] 2003 	mov	a,r7
      0084E7 34 0A            [12] 2004 	addc	a,#(_usage_order>>8)
      0084E9 F5 83            [12] 2005 	mov	dph,a
      0084EB E0               [24] 2006 	movx	a,@dptr
      0084EC 22               [24] 2007 	ret
                                   2008 
                                   2009 	.area CSEG (CODE)
                                   2010 ; function ak820_outline_0129
      0084ED                       2011 _ak820_outline_0129:
      0084ED F0               [24] 2012 	movx	@dptr,a
      0084EE E0               [24] 2013 	movx	a,@dptr
      0084EF FF               [12] 2014 	mov	r7,a
      0084F0 90 09 AC         [24] 2015 	mov	dptr,#_ak820_macro_change_PARM_2
      0084F3 F0               [24] 2016 	movx	@dptr,a
      0084F4 90 09 AD         [24] 2017 	mov	dptr,#_ak820_macro_change_PARM_3
      0084F7 22               [24] 2018 	ret
                                   2019 
                                   2020 	.area CSEG (CODE)
                                   2021 ; function ak820_outline_0171
      0084F8                       2022 _ak820_outline_0171:
      0084F8 90 08 27         [24] 2023 	mov	dptr,#_add_key_to_report_PARM_2
      0084FB EF               [12] 2024 	mov	a,r7
      0084FC F0               [24] 2025 	movx	@dptr,a
      0084FD 90 0D C4         [24] 2026 	mov	dptr,#_actual_keyboard_report
      008500 22               [24] 2027 	ret
                                   2028 
                                   2029 	.area CSEG (CODE)
                                   2030 ; function ak820_outline_0184
      008501                       2031 _ak820_outline_0184:
      008501 8D 82            [24] 2032 	mov	dpl,r5
      008503 8F 83            [24] 2033 	mov	dph,r7
      008505 22               [24] 2034 	ret
