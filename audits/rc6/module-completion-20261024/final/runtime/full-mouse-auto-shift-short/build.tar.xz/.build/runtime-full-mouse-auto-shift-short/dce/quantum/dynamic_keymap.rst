                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000023                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000023                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000AFC                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AFC                        628 	.ds 1
      000AFD                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AFD                        630 	.ds 1
      000AFE                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_365:
      000AFE                        632 	.ds 1
      000AFF                        633 _dynamic_keymap_get_keycode_PARM_2:
      000AFF                        634 	.ds 1
      000B00                        635 _dynamic_keymap_get_keycode_PARM_3:
      000B00                        636 	.ds 1
      000B01                        637 _dynamic_keymap_get_keycode_layer_10000_367:
      000B01                        638 	.ds 1
      000B02                        639 _dynamic_keymap_set_keycode_PARM_2:
      000B02                        640 	.ds 1
      000B03                        641 _dynamic_keymap_set_keycode_PARM_3:
      000B03                        642 	.ds 1
      000B04                        643 _dynamic_keymap_set_keycode_PARM_4:
      000B04                        644 	.ds 2
      000B06                        645 _dynamic_keymap_set_keycode_layer_10000_371:
      000B06                        646 	.ds 1
      000B07                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B07                        648 	.ds 1
      000B08                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_375:
      000B08                        650 	.ds 1
      000B09                        651 _dynamic_keymap_get_encoder_PARM_2:
      000B09                        652 	.ds 1
      000B0A                        653 _dynamic_keymap_get_encoder_PARM_3:
      000B0A                        654 	.ds 1
      000B0B                        655 _dynamic_keymap_get_encoder_layer_10000_377:
      000B0B                        656 	.ds 1
      000B0C                        657 _dynamic_keymap_set_encoder_PARM_2:
      000B0C                        658 	.ds 1
      000B0D                        659 _dynamic_keymap_set_encoder_PARM_3:
      000B0D                        660 	.ds 1
      000B0E                        661 _dynamic_keymap_set_encoder_PARM_4:
      000B0E                        662 	.ds 2
      000B10                        663 _dynamic_keymap_set_encoder_layer_10000_381:
      000B10                        664 	.ds 1
      000B11                        665 _dynamic_keymap_get_combo_PARM_2:
      000B11                        666 	.ds 3
      000B14                        667 _dynamic_keymap_get_combo_index_10000_385:
      000B14                        668 	.ds 1
      000B15                        669 _dynamic_keymap_set_combo_PARM_2:
      000B15                        670 	.ds 3
      000B18                        671 _dynamic_keymap_set_combo_index_10000_391:
      000B18                        672 	.ds 1
      000B19                        673 _dynamic_keymap_set_combo_stored_10002_396:
      000B19                        674 	.ds 10
      000B23                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_399:
      000B23                        676 	.ds 1
      000B24                        677 _dynamic_keymap_reset_combo_10001_408:
      000B24                        678 	.ds 10
      000B2E                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B2E                        680 	.ds 2
      000B30                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B30                        682 	.ds 2
      000B32                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B32                        684 	.ds 2
      000B34                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B34                        686 	.ds 3
      000B37                        687 _ak820_dynamic_read_buffer_base_10000_410:
      000B37                        688 	.ds 2
      000B39                        689 _ak820_dynamic_read_buffer_available_10000_411:
      000B39                        690 	.ds 1
      000B3A                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B3A                        692 	.ds 2
      000B3C                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B3C                        694 	.ds 3
      000B3F                        695 _dynamic_keymap_get_buffer_offset_10000_417:
      000B3F                        696 	.ds 2
      000B41                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B41                        698 	.ds 2
      000B43                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B43                        700 	.ds 3
      000B46                        701 _dynamic_keymap_set_buffer_offset_10000_419:
      000B46                        702 	.ds 2
      000B48                        703 _dynamic_keymap_set_buffer_chk_offset_30001_426:
      000B48                        704 	.ds 1
      000B49                        705 _dynamic_keymap_set_buffer_chk_sz_30001_426:
      000B49                        706 	.ds 1
      000B4A                        707 _dynamic_keymap_set_buffer_i_40001_433:
      000B4A                        708 	.ds 1
      000B4B                        709 _keycode_at_keymap_location_PARM_2:
      000B4B                        710 	.ds 1
      000B4C                        711 _keycode_at_keymap_location_PARM_3:
      000B4C                        712 	.ds 1
      000B4D                        713 _keycode_at_keymap_location_layer_num_10000_437:
      000B4D                        714 	.ds 1
      000B4E                        715 _keycode_at_encodermap_location_PARM_2:
      000B4E                        716 	.ds 1
      000B4F                        717 _keycode_at_encodermap_location_PARM_3:
      000B4F                        718 	.ds 1
      000B50                        719 _keycode_at_encodermap_location_layer_num_10000_441:
      000B50                        720 	.ds 1
      000B51                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B51                        722 	.ds 2
      000B53                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B53                        724 	.ds 3
      000B56                        725 _dynamic_keymap_macro_get_buffer_offset_10000_449:
      000B56                        726 	.ds 2
      000B58                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B58                        728 	.ds 2
      000B5A                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B5A                        730 	.ds 3
      000B5D                        731 _dynamic_keymap_macro_set_buffer_offset_10000_451:
      000B5D                        732 	.ds 2
      000B5F                        733 _decode_keycode_kc_10000_455:
      000B5F                        734 	.ds 2
      000B61                        735 _dynamic_keymap_macro_send_id_10000_458:
      000B61                        736 	.ds 1
      000B62                        737 _dynamic_keymap_macro_send_sending_10000_459:
      000B62                        738 	.ds 1
      000B63                        739 _dynamic_keymap_macro_send_p_10001_464:
      000B63                        740 	.ds 2
      000B65                        741 _dynamic_keymap_macro_send_data_10003_471:
      000B65                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008793                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008793 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      008796 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_365'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008797                        810 _dynamic_keymap_key_to_eeprom_address:
      008797 E5 82            [12]  811 	mov	a,dpl
      008799 90 0A FE         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_365
      00879C F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      00879D E0               [24]  815 	movx	a,@dptr
      00879E FF               [12]  816 	mov	r7,a
      00879F 7E 00            [12]  817 	mov	r6,#0x00
      0087A1 74 40            [12]  818 	mov	a,#0x40
      0087A3 12 45 70         [24]  819 	lcall	_ak820_outline_0133
      0087A6 7D 00            [12]  820 	mov	r5,#0x00
      0087A8 90 0A FC         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0087AB E0               [24]  822 	movx	a,@dptr
      0087AC 75 F0 10         [24]  823 	mov	b,#0x10
      0087AF A4               [48]  824 	mul	ab
      0087B0 2E               [12]  825 	add	a, r6
      0087B1 FE               [12]  826 	mov	r6,a
      0087B2 EF               [12]  827 	mov	a,r7
      0087B3 35 F0            [12]  828 	addc	a, b
      0087B5 FF               [12]  829 	mov	r7,a
      0087B6 90 0A FD         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0087B9 E0               [24]  831 	movx	a,@dptr
      0087BA 7C 00            [12]  832 	mov	r4,#0x00
      0087BC 25 E0            [12]  833 	add	a,acc
      0087BE FB               [12]  834 	mov	r3,a
      0087BF EC               [12]  835 	mov	a,r4
      0087C0 33               [12]  836 	rlc	a
      0087C1 FC               [12]  837 	mov	r4,a
      0087C2 EB               [12]  838 	mov	a,r3
      0087C3 2E               [12]  839 	add	a, r6
      0087C4 FE               [12]  840 	mov	r6,a
      0087C5 EC               [12]  841 	mov	a,r4
      0087C6 3F               [12]  842 	addc	a, r7
      0087C7 FF               [12]  843 	mov	r7,a
      0087C8 12 45 60         [24]  844 	lcall	_ak820_outline_0116
      0087CB 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      0087CD 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_367'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_370'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_370'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      0087CE                        861 _dynamic_keymap_get_keycode:
      0087CE E5 82            [12]  862 	mov	a,dpl
      0087D0 90 0B 01         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_367
      0087D3 F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0087D4 E0               [24]  866 	movx	a,@dptr
      0087D5 FF               [12]  867 	mov	r7,a
      0087D6 BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      0087D9                        869 00121$:
      0087D9 50 14            [24]  870 	jnc	00101$
      0087DB 90 0A FF         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0087DE E0               [24]  872 	movx	a,@dptr
      0087DF FE               [12]  873 	mov	r6,a
      0087E0 BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      0087E3                        875 00123$:
      0087E3 50 0A            [24]  876 	jnc	00101$
      0087E5 90 0B 00         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0087E8 E0               [24]  878 	movx	a,@dptr
      0087E9 FD               [12]  879 	mov	r5,a
      0087EA BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      0087ED                        881 00125$:
      0087ED 40 04            [24]  882 	jc	00102$
      0087EF                        883 00101$:
      0087EF 90 00 00         [24]  884 	mov	dptr,#0x0000
      0087F2 22               [24]  885 	ret
      0087F3                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0087F3 12 92 33         [24]  888 	lcall	_ak820_outline_0095
      0087F6 12 87 97         [24]  889 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      0087F9 12 92 40         [24]  891 	lcall	_ak820_outline_0112
      0087FC 12 42 78         [24]  892 	lcall	_eeprom_read_byte
      0087FF AB 82            [24]  893 	mov	r3,dpl
      008801 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008803 0D               [12]  896 	inc	r5
      008804 BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      008807 0E               [12]  898 	inc	r6
      008808                        899 00127$:
      008808 12 50 FA         [24]  900 	lcall	_ak820_outline_0043
      00880B 12 42 78         [24]  901 	lcall	_eeprom_read_byte
      00880E AF 82            [24]  902 	mov	r7, dpl
      008810 7E 00            [12]  903 	mov	r6,#0x00
      008812 EF               [12]  904 	mov	a,r7
      008813 42 04            [12]  905 	orl	ar4,a
      008815 EE               [12]  906 	mov	a,r6
      008816 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      008818 12 45 9C         [24]  909 	lcall	_ak820_outline_0179
                                    910 ;	quantum/dynamic_keymap.c:215: }
      00881B 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_371'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_374'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      00881C                        925 _dynamic_keymap_set_keycode:
      00881C E5 82            [12]  926 	mov	a,dpl
      00881E 90 0B 06         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_371
      008821 F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008822 E0               [24]  930 	movx	a,@dptr
      008823 FF               [12]  931 	mov	r7,a
      008824 BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      008827                        933 00121$:
      008827 50 14            [24]  934 	jnc	00101$
      008829 90 0B 02         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00882C E0               [24]  936 	movx	a,@dptr
      00882D FE               [12]  937 	mov	r6,a
      00882E BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      008831                        939 00123$:
      008831 50 0A            [24]  940 	jnc	00101$
      008833 90 0B 03         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008836 E0               [24]  942 	movx	a,@dptr
      008837 FD               [12]  943 	mov	r5,a
      008838 BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      00883B                        945 00125$:
      00883B 40 01            [24]  946 	jc	00102$
      00883D                        947 00101$:
      00883D 22               [24]  948 	ret
      00883E                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00883E 12 92 33         [24]  951 	lcall	_ak820_outline_0095
      008841 12 87 97         [24]  952 	lcall	_dynamic_keymap_key_to_eeprom_address
      008844 12 92 40         [24]  953 	lcall	_ak820_outline_0112
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008847 90 0B 04         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00884A E0               [24]  956 	movx	a,@dptr
      00884B FB               [12]  957 	mov	r3,a
      00884C A3               [24]  958 	inc	dptr
      00884D E0               [24]  959 	movx	a,@dptr
      00884E 90 06 AA         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      008851 F0               [24]  961 	movx	@dptr,a
      008852 12 50 FA         [24]  962 	lcall	_ak820_outline_0043
      008855 12 4F E3         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008858 0D               [12]  965 	inc	r5
      008859 BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      00885C 0E               [12]  967 	inc	r6
      00885D                        968 00127$:
      00885D 90 06 AA         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      008860 EB               [12]  970 	mov	a,r3
      008861 F0               [24]  971 	movx	@dptr,a
      008862 12 50 FA         [24]  972 	lcall	_ak820_outline_0043
                                    973 ;	quantum/dynamic_keymap.c:223: }
      008865 02 4F E3         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      008868                        985 _dynamic_keymap_encoder_to_eeprom_address:
      008868 E5 82            [12]  986 	mov	a,dpl
      00886A 90 0B 08         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375
      00886D F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      00886E E0               [24]  990 	movx	a,@dptr
      00886F 75 F0 04         [24]  991 	mov	b,#0x04
      008872 A4               [48]  992 	mul	ab
      008873 24 40            [12]  993 	add	a, #0x40
      008875 FD               [12]  994 	mov	r5,a
      008876 74 06            [12]  995 	mov	a,#0x06
      008878 35 F0            [12]  996 	addc	a, b
      00887A FE               [12]  997 	mov	r6,a
      00887B 7F 00            [12]  998 	mov	r7,#0x00
      00887D 90 0B 07         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008880 E0               [24] 1000 	movx	a,@dptr
      008881 75 F0 04         [24] 1001 	mov	b,#0x04
      008884 A4               [48] 1002 	mul	ab
      008885 2D               [12] 1003 	add	a, r5
      008886 FD               [12] 1004 	mov	r5,a
      008887 EE               [12] 1005 	mov	a,r6
      008888 35 F0            [12] 1006 	addc	a, b
      00888A FE               [12] 1007 	mov	r6,a
      00888B 12 50 FA         [24] 1008 	lcall	_ak820_outline_0043
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      00888E 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_377'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_380'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_380'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      00888F                       1024 _dynamic_keymap_get_encoder:
      00888F E5 82            [12] 1025 	mov	a,dpl
      008891 90 0B 0B         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_377
      008894 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008895 E0               [24] 1029 	movx	a,@dptr
      008896 FF               [12] 1030 	mov	r7,a
      008897 BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      00889A                       1032 00131$:
      00889A 50 0A            [24] 1033 	jnc	00101$
      00889C 90 0B 09         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00889F E0               [24] 1035 	movx	a,@dptr
      0088A0 FE               [12] 1036 	mov	r6,a
      0088A1 BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      0088A4                       1038 00133$:
      0088A4 40 04            [24] 1039 	jc	00102$
      0088A6                       1040 00101$:
      0088A6 90 00 00         [24] 1041 	mov	dptr,#0x0000
      0088A9 22               [24] 1042 	ret
      0088AA                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0088AA 90 0B 07         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0088AD 12 7B 7C         [24] 1046 	lcall	_ak820_outline_0183
      0088B0 11 68            [12] 1047 	acall	_dynamic_keymap_encoder_to_eeprom_address
      0088B2 12 92 40         [24] 1048 	lcall	_ak820_outline_0112
                                   1049 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      0088B5 90 0B 0A         [24] 1050 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0088B8 E0               [24] 1051 	movx	a,@dptr
      0088B9 FC               [12] 1052 	mov	r4,a
      0088BA E0               [24] 1053 	movx	a,@dptr
      0088BB 60 04            [24] 1054 	jz	00106$
      0088BD 7B 00            [12] 1055 	mov	r3,#0x00
      0088BF 80 02            [24] 1056 	sjmp	00107$
      0088C1                       1057 00106$:
      0088C1 7B 02            [12] 1058 	mov	r3,#0x02
      0088C3                       1059 00107$:
      0088C3 EB               [12] 1060 	mov	a,r3
      0088C4 12 92 11         [24] 1061 	lcall	_ak820_outline_0024
      0088C7 12 42 78         [24] 1062 	lcall	_eeprom_read_byte
      0088CA AA 82            [24] 1063 	mov	r2,dpl
      0088CC 7B 00            [12] 1064 	mov	r3,#0x00
                                   1065 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0088CE EC               [12] 1066 	mov	a,r4
      0088CF 60 04            [24] 1067 	jz	00108$
      0088D1 7C 00            [12] 1068 	mov	r4,#0x00
      0088D3 80 02            [24] 1069 	sjmp	00109$
      0088D5                       1070 00108$:
      0088D5 7C 02            [12] 1071 	mov	r4,#0x02
      0088D7                       1072 00109$:
      0088D7 EC               [12] 1073 	mov	a,r4
      0088D8 12 3A B5         [24] 1074 	lcall	_ak820_outline_0156
      0088DB 0D               [12] 1075 	inc	r5
      0088DC BD 00 01         [24] 1076 	cjne	r5,#0x00,00137$
      0088DF 0E               [12] 1077 	inc	r6
      0088E0                       1078 00137$:
      0088E0 12 50 FA         [24] 1079 	lcall	_ak820_outline_0043
      0088E3 12 42 78         [24] 1080 	lcall	_eeprom_read_byte
      0088E6 AF 82            [24] 1081 	mov	r7, dpl
      0088E8 7E 00            [12] 1082 	mov	r6,#0x00
      0088EA EF               [12] 1083 	mov	a,r7
      0088EB 42 03            [12] 1084 	orl	ar3,a
      0088ED EE               [12] 1085 	mov	a,r6
      0088EE 42 02            [12] 1086 	orl	ar2,a
                                   1087 ;	quantum/dynamic_keymap.c:236: return keycode;
      0088F0 8B 82            [24] 1088 	mov	dpl, r3
      0088F2 8A 83            [24] 1089 	mov	dph, r2
                                   1090 ;	quantum/dynamic_keymap.c:237: }
      0088F4 22               [24] 1091 	ret
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1094 ;------------------------------------------------------------
                                   1095 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1096 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1097 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1098 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1099 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_381'
                                   1100 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_384'
                                   1101 ;------------------------------------------------------------
                                   1102 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1103 ;	-----------------------------------------
                                   1104 ;	 function dynamic_keymap_set_encoder
                                   1105 ;	-----------------------------------------
      0088F5                       1106 _dynamic_keymap_set_encoder:
      0088F5 E5 82            [12] 1107 	mov	a,dpl
      0088F7 90 0B 10         [24] 1108 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_381
      0088FA F0               [24] 1109 	movx	@dptr,a
                                   1110 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      0088FB E0               [24] 1111 	movx	a,@dptr
      0088FC FF               [12] 1112 	mov	r7,a
      0088FD BF 06 00         [24] 1113 	cjne	r7,#0x06,00131$
      008900                       1114 00131$:
      008900 50 0A            [24] 1115 	jnc	00101$
      008902 90 0B 0C         [24] 1116 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008905 E0               [24] 1117 	movx	a,@dptr
      008906 FE               [12] 1118 	mov	r6,a
      008907 BE 01 00         [24] 1119 	cjne	r6,#0x01,00133$
      00890A                       1120 00133$:
      00890A 40 01            [24] 1121 	jc	00102$
      00890C                       1122 00101$:
      00890C 22               [24] 1123 	ret
      00890D                       1124 00102$:
                                   1125 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00890D 90 0B 07         [24] 1126 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008910 12 7B 7C         [24] 1127 	lcall	_ak820_outline_0183
      008913 11 68            [12] 1128 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008915 12 92 40         [24] 1129 	lcall	_ak820_outline_0112
                                   1130 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008918 90 0B 0D         [24] 1131 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00891B E0               [24] 1132 	movx	a,@dptr
      00891C FC               [12] 1133 	mov	r4,a
      00891D E0               [24] 1134 	movx	a,@dptr
      00891E 60 04            [24] 1135 	jz	00106$
      008920 7B 00            [12] 1136 	mov	r3,#0x00
      008922 80 02            [24] 1137 	sjmp	00107$
      008924                       1138 00106$:
      008924 7B 02            [12] 1139 	mov	r3,#0x02
      008926                       1140 00107$:
      008926 EB               [12] 1141 	mov	a,r3
      008927 12 92 52         [24] 1142 	lcall	_ak820_outline_0132
      00892A 8F 03            [24] 1143 	mov	ar3,r7
      00892C 90 0B 0E         [24] 1144 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00892F E0               [24] 1145 	movx	a,@dptr
      008930 F5 29            [12] 1146 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008932 A3               [24] 1147 	inc	dptr
      008933 E0               [24] 1148 	movx	a,@dptr
      008934 F5 2A            [12] 1149 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008936 90 06 AA         [24] 1150 	mov	dptr,#_eeprom_update_byte_PARM_2
      008939 F0               [24] 1151 	movx	@dptr,a
      00893A 12 45 97         [24] 1152 	lcall	_ak820_outline_0178
      00893D 8B F0            [24] 1153 	mov	b, r3
      00893F 12 4F E3         [24] 1154 	lcall	_eeprom_update_byte
                                   1155 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008942 EC               [12] 1156 	mov	a,r4
      008943 60 04            [24] 1157 	jz	00108$
      008945 7C 00            [12] 1158 	mov	r4,#0x00
      008947 80 02            [24] 1159 	sjmp	00109$
      008949                       1160 00108$:
      008949 7C 02            [12] 1161 	mov	r4,#0x02
      00894B                       1162 00109$:
      00894B EC               [12] 1163 	mov	a,r4
      00894C 12 3A B5         [24] 1164 	lcall	_ak820_outline_0156
      00894F 0D               [12] 1165 	inc	r5
      008950 BD 00 01         [24] 1166 	cjne	r5,#0x00,00137$
      008953 0E               [12] 1167 	inc	r6
      008954                       1168 00137$:
      008954 90 06 AA         [24] 1169 	mov	dptr,#_eeprom_update_byte_PARM_2
      008957 E5 29            [12] 1170 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008959 F0               [24] 1171 	movx	@dptr,a
      00895A 12 50 FA         [24] 1172 	lcall	_ak820_outline_0043
                                   1173 ;	quantum/dynamic_keymap.c:245: }
      00895D 02 4F E3         [24] 1174 	ljmp	_eeprom_update_byte
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1179 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1180 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_385'
                                   1181 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_386'
                                   1182 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_388'
                                   1183 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_389'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function dynamic_keymap_get_combo
                                   1188 ;	-----------------------------------------
      008960                       1189 _dynamic_keymap_get_combo:
      008960 E5 82            [12] 1190 	mov	a,dpl
      008962 90 0B 14         [24] 1191 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008965 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008966 90 0B 11         [24] 1194 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008969 12 3A 41         [24] 1195 	lcall	_ak820_outline_0050
                                   1196 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      00896C 90 0B 14         [24] 1197 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      00896F E0               [24] 1198 	movx	a,@dptr
      008970 FD               [12] 1199 	mov	r5,a
      008971 BD 08 00         [24] 1200 	cjne	r5,#0x08,00132$
      008974                       1201 00132$:
      008974 40 04            [24] 1202 	jc	00102$
                                   1203 ;	quantum/dynamic_keymap.c:315: return -1;
      008976 90 FF FF         [24] 1204 	mov	dptr,#0xffff
      008979 22               [24] 1205 	ret
      00897A                       1206 00102$:
                                   1207 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00897A 12 92 1F         [24] 1208 	lcall	_ak820_outline_0078
                                   1209 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      00897D 8E 02            [24] 1210 	mov	ar2,r6
      00897F 8F 03            [24] 1211 	mov	ar3,r7
      008981 90 05 91         [24] 1212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008984 12 3A 66         [24] 1213 	lcall	_ak820_outline_0070
      008987 E4               [12] 1214 	clr	a
      008988 A3               [24] 1215 	inc	dptr
      008989 F0               [24] 1216 	movx	@dptr,a
      00898A 90 05 94         [24] 1217 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00898D 74 0A            [12] 1218 	mov	a,#0x0a
      00898F 12 3A A0         [24] 1219 	lcall	_ak820_outline_0122
      008992 12 45 7C         [24] 1220 	lcall	_ak820_outline_0141
      008995 C0 07            [24] 1221 	push	ar7
      008997 C0 06            [24] 1222 	push	ar6
      008999 12 42 B3         [24] 1223 	lcall	_ak820_eeprom_read_block_xdata
      00899C D0 06            [24] 1224 	pop	ar6
      00899E D0 07            [24] 1225 	pop	ar7
                                   1226 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      0089A0 74 04            [12] 1227 	mov	a,#0x04
      0089A2 12 4A 1F         [24] 1228 	lcall	_ak820_outline_0011
      0089A5 FA               [12] 1229 	mov	r2,a
      0089A6 A3               [24] 1230 	inc	dptr
      0089A7 E0               [24] 1231 	movx	a,@dptr
      0089A8 FB               [12] 1232 	mov	r3,a
      0089A9 BA 20 14         [24] 1233 	cjne	r2,#0x20,00108$
      0089AC BB 08 11         [24] 1234 	cjne	r3,#0x08,00108$
      0089AF 74 06            [12] 1235 	mov	a,#0x06
      0089B1 12 3A 28         [24] 1236 	lcall	_ak820_outline_0016
      0089B4 FA               [12] 1237 	mov	r2,a
      0089B5 A3               [24] 1238 	inc	dptr
      0089B6 E0               [24] 1239 	movx	a,@dptr
      0089B7 FB               [12] 1240 	mov	r3,a
      0089B8 BA 01 05         [24] 1241 	cjne	r2,#0x01,00136$
      0089BB BB 00 02         [24] 1242 	cjne	r3,#0x00,00136$
      0089BE 80 05            [24] 1243 	sjmp	00109$
      0089C0                       1244 00136$:
      0089C0                       1245 00108$:
      0089C0 75 2B 00         [24] 1246 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      0089C3 80 03            [24] 1247 	sjmp	00110$
      0089C5                       1248 00109$:
      0089C5 75 2B 01         [24] 1249 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      0089C8                       1250 00110$:
                                   1251 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      0089C8 74 06            [12] 1252 	mov	a,#0x06
      0089CA 12 3A 31         [24] 1253 	lcall	_ak820_outline_0030
      0089CD 12 51 43         [24] 1254 	lcall	_ak820_outline_0165
      0089D0 12 3A 95         [24] 1255 	lcall	_ak820_outline_0117
      0089D3 F0               [24] 1256 	movx	@dptr,a
      0089D4 A3               [24] 1257 	inc	dptr
      0089D5 F0               [24] 1258 	movx	@dptr,a
                                   1259 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      0089D6 E5 2B            [12] 1260 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      0089D8 60 12            [24] 1261 	jz	00103$
      0089DA 12 45 60         [24] 1262 	lcall	_ak820_outline_0116
      0089DD C0 07            [24] 1263 	push	ar7
      0089DF C0 06            [24] 1264 	push	ar6
      0089E1 12 36 AE         [24] 1265 	lcall	_ak820_combo_valid
      0089E4 E5 82            [12] 1266 	mov	a, dpl
      0089E6 D0 06            [24] 1267 	pop	ar6
      0089E8 D0 07            [24] 1268 	pop	ar7
      0089EA 70 17            [24] 1269 	jnz	00104$
      0089EC                       1270 00103$:
      0089EC 7D 00            [12] 1271 	mov	r5,#0x00
      0089EE 90 0D A6         [24] 1272 	mov	dptr,#_memset_PARM_2
      0089F1 E4               [12] 1273 	clr	a
      0089F2 F0               [24] 1274 	movx	@dptr,a
      0089F3 90 0D A7         [24] 1275 	mov	dptr,#_memset_PARM_3
      0089F6 74 0A            [12] 1276 	mov	a,#0x0a
      0089F8 F0               [24] 1277 	movx	@dptr,a
      0089F9 E4               [12] 1278 	clr	a
      0089FA A3               [24] 1279 	inc	dptr
      0089FB 12 45 3B         [24] 1280 	lcall	_ak820_outline_0060
      0089FE 8D F0            [24] 1281 	mov	b, r5
      008A00 12 BA C8         [24] 1282 	lcall	_memset
      008A03                       1283 00104$:
                                   1284 ;	quantum/dynamic_keymap.c:329: return 0;
      008A03 90 00 00         [24] 1285 	mov	dptr,#0x0000
                                   1286 ;	quantum/dynamic_keymap.c:330: }
      008A06 22               [24] 1287 	ret
                                   1288 ;------------------------------------------------------------
                                   1289 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1290 ;------------------------------------------------------------
                                   1291 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1292 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_391'
                                   1293 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_392'
                                   1294 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_395'
                                   1295 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_396'
                                   1296 ;------------------------------------------------------------
                                   1297 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1298 ;	-----------------------------------------
                                   1299 ;	 function dynamic_keymap_set_combo
                                   1300 ;	-----------------------------------------
      008A07                       1301 _dynamic_keymap_set_combo:
      008A07 E5 82            [12] 1302 	mov	a,dpl
      008A09 90 0B 18         [24] 1303 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008A0C F0               [24] 1304 	movx	@dptr,a
                                   1305 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008A0D 90 0B 15         [24] 1306 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008A10 12 39 E1         [24] 1307 	lcall	_ak820_outline_0004
                                   1308 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008A13 C0 07            [24] 1309 	push	ar7
      008A15 C0 06            [24] 1310 	push	ar6
      008A17 12 36 AE         [24] 1311 	lcall	_ak820_combo_valid
      008A1A E5 82            [12] 1312 	mov	a, dpl
      008A1C D0 06            [24] 1313 	pop	ar6
      008A1E D0 07            [24] 1314 	pop	ar7
      008A20 60 07            [24] 1315 	jz	00101$
      008A22 12 40 1E         [24] 1316 	lcall	_ak820_nvm_ok
      008A25 E5 82            [12] 1317 	mov	a, dpl
      008A27 70 04            [24] 1318 	jnz	00102$
      008A29                       1319 00101$:
      008A29 90 FF FF         [24] 1320 	mov	dptr,#0xffff
      008A2C 22               [24] 1321 	ret
      008A2D                       1322 00102$:
                                   1323 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008A2D 90 0B 18         [24] 1324 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008A30 E0               [24] 1325 	movx	a,@dptr
      008A31 FD               [12] 1326 	mov	r5,a
      008A32 BD 08 00         [24] 1327 	cjne	r5,#0x08,00133$
      008A35                       1328 00133$:
      008A35 40 04            [24] 1329 	jc	00105$
                                   1330 ;	quantum/dynamic_keymap.c:342: return -1;
      008A37 90 FF FF         [24] 1331 	mov	dptr,#0xffff
      008A3A 22               [24] 1332 	ret
      008A3B                       1333 00105$:
                                   1334 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008A3B 12 92 1F         [24] 1335 	lcall	_ak820_outline_0078
                                   1336 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008A3E C0 07            [24] 1337 	push	ar7
      008A40 C0 06            [24] 1338 	push	ar6
      008A42 C0 05            [24] 1339 	push	ar5
      008A44 C0 04            [24] 1340 	push	ar4
      008A46 12 7A D2         [24] 1341 	lcall	_clear_keyboard
      008A49 D0 04            [24] 1342 	pop	ar4
      008A4B D0 05            [24] 1343 	pop	ar5
      008A4D D0 06            [24] 1344 	pop	ar6
      008A4F D0 07            [24] 1345 	pop	ar7
                                   1346 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008A51 90 0D 9E         [24] 1347 	mov	dptr,#___memcpy_PARM_2
      008A54 12 4A 79         [24] 1348 	lcall	_ak820_outline_0058
      008A57 E4               [12] 1349 	clr	a
      008A58 A3               [24] 1350 	inc	dptr
      008A59 F0               [24] 1351 	movx	@dptr,a
      008A5A 90 0D A1         [24] 1352 	mov	dptr,#___memcpy_PARM_3
      008A5D 74 0A            [12] 1353 	mov	a,#0x0a
      008A5F 12 3A A0         [24] 1354 	lcall	_ak820_outline_0122
      008A62 90 0B 19         [24] 1355 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008A65 F5 F0            [12] 1356 	mov	b,a
      008A67 C0 05            [24] 1357 	push	ar5
      008A69 C0 04            [24] 1358 	push	ar4
      008A6B 12 BA 52         [24] 1359 	lcall	___memcpy
      008A6E D0 04            [24] 1360 	pop	ar4
      008A70 D0 05            [24] 1361 	pop	ar5
                                   1362 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008A72 90 0B 1D         [24] 1363 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0004)
      008A75 74 20            [12] 1364 	mov	a,#0x20
      008A77 F0               [24] 1365 	movx	@dptr,a
      008A78 74 08            [12] 1366 	mov	a,#0x08
      008A7A A3               [24] 1367 	inc	dptr
      008A7B F0               [24] 1368 	movx	@dptr,a
                                   1369 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008A7C 90 0B 1F         [24] 1370 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0006)
      008A7F 74 01            [12] 1371 	mov	a,#0x01
      008A81 12 3A A0         [24] 1372 	lcall	_ak820_outline_0122
                                   1373 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008A84 90 05 9A         [24] 1374 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008A87 12 3A 66         [24] 1375 	lcall	_ak820_outline_0070
      008A8A E4               [12] 1376 	clr	a
      008A8B A3               [24] 1377 	inc	dptr
      008A8C F0               [24] 1378 	movx	@dptr,a
      008A8D 90 05 9D         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008A90 74 0A            [12] 1380 	mov	a,#0x0a
      008A92 12 3A A0         [24] 1381 	lcall	_ak820_outline_0122
      008A95 90 0B 19         [24] 1382 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008A98 12 43 3F         [24] 1383 	lcall	_ak820_eeprom_write_block_xdata
                                   1384 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008A9B 12 40 2D         [24] 1385 	lcall	_ak820_nvm_flush
                                   1386 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008A9E 12 40 1E         [24] 1387 	lcall	_ak820_nvm_ok
      008AA1 E5 82            [12] 1388 	mov	a, dpl
      008AA3 70 04            [24] 1389 	jnz	00107$
      008AA5 90 FF FF         [24] 1390 	mov	dptr,#0xffff
      008AA8 22               [24] 1391 	ret
      008AA9                       1392 00107$:
                                   1393 ;	quantum/dynamic_keymap.c:360: return 0;
      008AA9 90 00 00         [24] 1394 	mov	dptr,#0x0000
                                   1395 ;	quantum/dynamic_keymap.c:361: }
      008AAC 22               [24] 1396 	ret
                                   1397 ;------------------------------------------------------------
                                   1398 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1399 ;------------------------------------------------------------
                                   1400 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_399'
                                   1401 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_400'
                                   1402 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_402'
                                   1403 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_404'
                                   1404 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_406'
                                   1405 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_408'
                                   1406 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_409'
                                   1407 ;------------------------------------------------------------
                                   1408 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1409 ;	-----------------------------------------
                                   1410 ;	 function dynamic_keymap_reset
                                   1411 ;	-----------------------------------------
      008AAD                       1412 _dynamic_keymap_reset:
                                   1413 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008AAD 90 0E 1F         [24] 1414 	mov	dptr,#_vial_unlocked
      008AB0 E0               [24] 1415 	movx	a,@dptr
      008AB1 90 0B 23         [24] 1416 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008AB4 F0               [24] 1417 	movx	@dptr,a
                                   1418 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008AB5 90 0E 1F         [24] 1419 	mov	dptr,#_vial_unlocked
      008AB8 74 01            [12] 1420 	mov	a,#0x01
      008ABA F0               [24] 1421 	movx	@dptr,a
                                   1422 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008ABB 7F 00            [12] 1423 	mov	r7,#0x00
      008ABD                       1424 00116$:
      008ABD BF 06 00         [24] 1425 	cjne	r7,#0x06,00198$
      008AC0                       1426 00198$:
      008AC0 40 02            [24] 1427 	jc	00199$
      008AC2 61 6B            [12] 1428 	ajmp	00104$
      008AC4                       1429 00199$:
                                   1430 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008AC4 7E 00            [12] 1431 	mov	r6,#0x00
      008AC6                       1432 00110$:
      008AC6 BE 10 00         [24] 1433 	cjne	r6,#0x10,00200$
      008AC9                       1434 00200$:
      008AC9 50 4C            [24] 1435 	jnc	00102$
                                   1436 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008ACB 7D 00            [12] 1437 	mov	r5,#0x00
      008ACD                       1438 00107$:
      008ACD BD 08 00         [24] 1439 	cjne	r5,#0x08,00202$
      008AD0                       1440 00202$:
      008AD0 50 42            [24] 1441 	jnc	00111$
                                   1442 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008AD2 90 0B BF         [24] 1443 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008AD5 EE               [12] 1444 	mov	a,r6
      008AD6 F0               [24] 1445 	movx	@dptr,a
      008AD7 90 0B C0         [24] 1446 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008ADA ED               [12] 1447 	mov	a,r5
      008ADB F0               [24] 1448 	movx	@dptr,a
      008ADC 8F 82            [24] 1449 	mov	dpl, r7
      008ADE C0 07            [24] 1450 	push	ar7
      008AE0 C0 06            [24] 1451 	push	ar6
      008AE2 C0 05            [24] 1452 	push	ar5
      008AE4 12 9A 56         [24] 1453 	lcall	_keycode_at_keymap_location_raw
      008AE7 AB 82            [24] 1454 	mov	r3, dpl
      008AE9 AC 83            [24] 1455 	mov	r4, dph
      008AEB D0 05            [24] 1456 	pop	ar5
      008AED D0 06            [24] 1457 	pop	ar6
      008AEF D0 07            [24] 1458 	pop	ar7
      008AF1 90 0B 02         [24] 1459 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008AF4 EE               [12] 1460 	mov	a,r6
      008AF5 F0               [24] 1461 	movx	@dptr,a
      008AF6 90 0B 03         [24] 1462 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008AF9 ED               [12] 1463 	mov	a,r5
      008AFA F0               [24] 1464 	movx	@dptr,a
      008AFB 90 0B 04         [24] 1465 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008AFE 12 3A 6C         [24] 1466 	lcall	_ak820_outline_0076
      008B01 8F 82            [24] 1467 	mov	dpl, r7
      008B03 C0 07            [24] 1468 	push	ar7
      008B05 C0 06            [24] 1469 	push	ar6
      008B07 C0 05            [24] 1470 	push	ar5
      008B09 11 1C            [12] 1471 	acall	_dynamic_keymap_set_keycode
      008B0B D0 05            [24] 1472 	pop	ar5
      008B0D D0 06            [24] 1473 	pop	ar6
      008B0F D0 07            [24] 1474 	pop	ar7
                                   1475 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008B11 0D               [12] 1476 	inc	r5
      008B12 80 B9            [24] 1477 	sjmp	00107$
      008B14                       1478 00111$:
                                   1479 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008B14 0E               [12] 1480 	inc	r6
      008B15 80 AF            [24] 1481 	sjmp	00110$
      008B17                       1482 00102$:
                                   1483 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008B17 7E 00            [12] 1484 	mov	r6,#0x00
      008B19                       1485 00113$:
      008B19 BE 01 00         [24] 1486 	cjne	r6,#0x01,00204$
      008B1C                       1487 00204$:
      008B1C 50 4A            [24] 1488 	jnc	00117$
                                   1489 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008B1E 12 92 6E         [24] 1490 	lcall	_ak820_outline_0174
      008B21 04               [12] 1491 	inc	a
      008B22 F0               [24] 1492 	movx	@dptr,a
      008B23 8F 82            [24] 1493 	mov	dpl, r7
      008B25 C0 07            [24] 1494 	push	ar7
      008B27 12 9A 9B         [24] 1495 	lcall	_keycode_at_encodermap_location_raw
      008B2A 12 45 81         [24] 1496 	lcall	_ak820_outline_0147
      008B2D D0 07            [24] 1497 	pop	ar7
      008B2F 12 92 65         [24] 1498 	lcall	_ak820_outline_0173
      008B32 04               [12] 1499 	inc	a
      008B33 F0               [24] 1500 	movx	@dptr,a
      008B34 90 0B 0E         [24] 1501 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008B37 12 3A 66         [24] 1502 	lcall	_ak820_outline_0070
      008B3A 8F 82            [24] 1503 	mov	dpl, r7
      008B3C C0 07            [24] 1504 	push	ar7
      008B3E 11 F5            [24] 1505 	acall	_dynamic_keymap_set_encoder
      008B40 D0 07            [24] 1506 	pop	ar7
                                   1507 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008B42 12 92 6E         [24] 1508 	lcall	_ak820_outline_0174
      008B45 F0               [24] 1509 	movx	@dptr,a
      008B46 8F 82            [24] 1510 	mov	dpl, r7
      008B48 C0 07            [24] 1511 	push	ar7
      008B4A 12 9A 9B         [24] 1512 	lcall	_keycode_at_encodermap_location_raw
      008B4D 12 45 81         [24] 1513 	lcall	_ak820_outline_0147
      008B50 D0 07            [24] 1514 	pop	ar7
      008B52 12 92 65         [24] 1515 	lcall	_ak820_outline_0173
      008B55 F0               [24] 1516 	movx	@dptr,a
      008B56 90 0B 0E         [24] 1517 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008B59 12 3A 66         [24] 1518 	lcall	_ak820_outline_0070
      008B5C 8F 82            [24] 1519 	mov	dpl, r7
      008B5E C0 07            [24] 1520 	push	ar7
      008B60 11 F5            [24] 1521 	acall	_dynamic_keymap_set_encoder
      008B62 D0 07            [24] 1522 	pop	ar7
                                   1523 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008B64 7E 01            [12] 1524 	mov	r6,#0x01
      008B66 80 B1            [24] 1525 	sjmp	00113$
      008B68                       1526 00117$:
                                   1527 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008B68 0F               [12] 1528 	inc	r7
      008B69 41 BD            [12] 1529 	ajmp	00116$
      008B6B                       1530 00104$:
                                   1531 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008B6B 90 0B 24         [24] 1532 	mov	dptr,#_dynamic_keymap_reset_combo_10001_408
      008B6E 12 51 43         [24] 1533 	lcall	_ak820_outline_0165
      008B71 90 0B 26         [24] 1534 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0002)
      008B74 F0               [24] 1535 	movx	@dptr,a
      008B75 A3               [24] 1536 	inc	dptr
      008B76 F0               [24] 1537 	movx	@dptr,a
      008B77 90 0B 28         [24] 1538 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0004)
      008B7A F0               [24] 1539 	movx	@dptr,a
      008B7B A3               [24] 1540 	inc	dptr
      008B7C F0               [24] 1541 	movx	@dptr,a
      008B7D 90 0B 2A         [24] 1542 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0006)
      008B80 F0               [24] 1543 	movx	@dptr,a
      008B81 A3               [24] 1544 	inc	dptr
      008B82 F0               [24] 1545 	movx	@dptr,a
      008B83 90 0B 2C         [24] 1546 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0008)
      008B86 F0               [24] 1547 	movx	@dptr,a
      008B87 A3               [24] 1548 	inc	dptr
      008B88 F0               [24] 1549 	movx	@dptr,a
                                   1550 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008B89 FF               [12] 1551 	mov	r7,a
      008B8A                       1552 00119$:
      008B8A BF 08 00         [24] 1553 	cjne	r7,#0x08,00206$
      008B8D                       1554 00206$:
      008B8D 50 16            [24] 1555 	jnc	00105$
                                   1556 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008B8F 90 0B 15         [24] 1557 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008B92 74 24            [12] 1558 	mov	a,#_dynamic_keymap_reset_combo_10001_408
      008B94 F0               [24] 1559 	movx	@dptr,a
      008B95 74 0B            [12] 1560 	mov	a,#(_dynamic_keymap_reset_combo_10001_408 >> 8)
      008B97 12 3A 72         [24] 1561 	lcall	_ak820_outline_0096
      008B9A 8F 82            [24] 1562 	mov	dpl, r7
      008B9C C0 07            [24] 1563 	push	ar7
      008B9E 51 07            [24] 1564 	acall	_dynamic_keymap_set_combo
      008BA0 D0 07            [24] 1565 	pop	ar7
                                   1566 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008BA2 0F               [12] 1567 	inc	r7
      008BA3 80 E5            [24] 1568 	sjmp	00119$
      008BA5                       1569 00105$:
                                   1570 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008BA5 90 0B 23         [24] 1571 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008BA8 E0               [24] 1572 	movx	a,@dptr
      008BA9 90 0E 1F         [24] 1573 	mov	dptr,#_vial_unlocked
      008BAC F0               [24] 1574 	movx	@dptr,a
                                   1575 ;	quantum/dynamic_keymap.c:468: }
      008BAD 22               [24] 1576 	ret
                                   1577 ;------------------------------------------------------------
                                   1578 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1579 ;------------------------------------------------------------
                                   1580 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1581 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1582 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1583 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1584 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1585 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_410'
                                   1586 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_411'
                                   1587 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_411'
                                   1588 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_414'
                                   1589 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_416'
                                   1590 ;------------------------------------------------------------
                                   1591 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1592 ;	-----------------------------------------
                                   1593 ;	 function ak820_dynamic_read_buffer
                                   1594 ;	-----------------------------------------
      008BAE                       1595 _ak820_dynamic_read_buffer:
      008BAE 12 3A 84         [24] 1596 	lcall	_ak820_outline_0103
      008BB1 90 0B 37         [24] 1597 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008BB4 12 3A 89         [24] 1598 	lcall	_ak820_outline_0104
                                   1599 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008BB7 90 0B 34         [24] 1600 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008BBA 12 3A 41         [24] 1601 	lcall	_ak820_outline_0050
                                   1602 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008BBD 90 0B 39         [24] 1603 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008BC0 E4               [12] 1604 	clr	a
      008BC1 F0               [24] 1605 	movx	@dptr,a
                                   1606 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008BC2 90 0B 32         [24] 1607 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008BC5 12 3A 60         [24] 1608 	lcall	_ak820_outline_0059
      008BC8 8C 02            [24] 1609 	mov	ar2,r4
      008BCA 8D 03            [24] 1610 	mov	ar3,r5
      008BCC C3               [12] 1611 	clr	c
      008BCD 74 1C            [12] 1612 	mov	a,#0x1c
      008BCF 9A               [12] 1613 	subb	a,r2
      008BD0 E4               [12] 1614 	clr	a
      008BD1 9B               [12] 1615 	subb	a,r3
      008BD2 50 01            [24] 1616 	jnc	00102$
                                   1617 ;	free result
      008BD4 22               [24] 1618 	ret
      008BD5                       1619 00102$:
                                   1620 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008BD5 90 0B 30         [24] 1621 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008BD8 12 45 65         [24] 1622 	lcall	_ak820_outline_0119
      008BDB 90 0B 2E         [24] 1623 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008BDE 12 3A 7E         [24] 1624 	lcall	_ak820_outline_0099
      008BE1 C3               [12] 1625 	clr	c
      008BE2 EA               [12] 1626 	mov	a,r2
      008BE3 98               [12] 1627 	subb	a,r0
      008BE4 EB               [12] 1628 	mov	a,r3
      008BE5 99               [12] 1629 	subb	a,r1
      008BE6 50 17            [24] 1630 	jnc	00104$
                                   1631 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008BE8 E8               [12] 1632 	mov	a,r0
      008BE9 C3               [12] 1633 	clr	c
      008BEA 9A               [12] 1634 	subb	a,r2
      008BEB F8               [12] 1635 	mov	r0,a
      008BEC E9               [12] 1636 	mov	a,r1
      008BED 9B               [12] 1637 	subb	a,r3
      008BEE F9               [12] 1638 	mov	r1,a
                                   1639 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008BEF C3               [12] 1640 	clr	c
      008BF0 E8               [12] 1641 	mov	a,r0
      008BF1 9C               [12] 1642 	subb	a,r4
      008BF2 E9               [12] 1643 	mov	a,r1
      008BF3 9D               [12] 1644 	subb	a,r5
      008BF4 40 04            [24] 1645 	jc	00114$
      008BF6 8C 00            [24] 1646 	mov	ar0,r4
      008BF8 8D 01            [24] 1647 	mov	ar1,r5
      008BFA                       1648 00114$:
      008BFA 90 0B 39         [24] 1649 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008BFD E8               [12] 1650 	mov	a,r0
      008BFE F0               [24] 1651 	movx	@dptr,a
      008BFF                       1652 00104$:
                                   1653 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008BFF 90 0B 39         [24] 1654 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008C02 E0               [24] 1655 	movx	a,@dptr
      008C03 F5 2C            [12] 1656 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008C05 E0               [24] 1657 	movx	a,@dptr
      008C06 60 42            [24] 1658 	jz	00106$
      008C08 C0 04            [24] 1659 	push	ar4
      008C0A C0 05            [24] 1660 	push	ar5
      008C0C 8E 00            [24] 1661 	mov	ar0,r6
      008C0E 8F 05            [24] 1662 	mov	ar5,r7
      008C10 90 0B 37         [24] 1663 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008C13 E0               [24] 1664 	movx	a,@dptr
      008C14 F9               [12] 1665 	mov	r1,a
      008C15 A3               [24] 1666 	inc	dptr
      008C16 E0               [24] 1667 	movx	a,@dptr
      008C17 FC               [12] 1668 	mov	r4,a
      008C18 EA               [12] 1669 	mov	a,r2
      008C19 29               [12] 1670 	add	a, r1
      008C1A FA               [12] 1671 	mov	r2,a
      008C1B EB               [12] 1672 	mov	a,r3
      008C1C 3C               [12] 1673 	addc	a, r4
      008C1D FB               [12] 1674 	mov	r3,a
      008C1E 90 05 91         [24] 1675 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008C21 EA               [12] 1676 	mov	a,r2
      008C22 F0               [24] 1677 	movx	@dptr,a
      008C23 EB               [12] 1678 	mov	a,r3
      008C24 12 3A 72         [24] 1679 	lcall	_ak820_outline_0096
      008C27 90 05 94         [24] 1680 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008C2A E5 2C            [12] 1681 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008C2C 12 3A A0         [24] 1682 	lcall	_ak820_outline_0122
      008C2F 88 82            [24] 1683 	mov	dpl, r0
      008C31 8D 83            [24] 1684 	mov	dph, r5
      008C33 C0 07            [24] 1685 	push	ar7
      008C35 C0 06            [24] 1686 	push	ar6
      008C37 C0 05            [24] 1687 	push	ar5
      008C39 C0 04            [24] 1688 	push	ar4
      008C3B 12 42 B3         [24] 1689 	lcall	_ak820_eeprom_read_block_xdata
      008C3E D0 04            [24] 1690 	pop	ar4
      008C40 D0 05            [24] 1691 	pop	ar5
      008C42 D0 06            [24] 1692 	pop	ar6
      008C44 D0 07            [24] 1693 	pop	ar7
                                   1694 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008C46 D0 05            [24] 1695 	pop	ar5
      008C48 D0 04            [24] 1696 	pop	ar4
                                   1697 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008C4A                       1698 00106$:
                                   1699 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008C4A 90 0B 39         [24] 1700 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008C4D E0               [24] 1701 	movx	a,@dptr
      008C4E FB               [12] 1702 	mov	r3,a
      008C4F                       1703 00109$:
      008C4F 8B 01            [24] 1704 	mov	ar1,r3
      008C51 7A 00            [12] 1705 	mov	r2,#0x00
      008C53 C3               [12] 1706 	clr	c
      008C54 E9               [12] 1707 	mov	a,r1
      008C55 9C               [12] 1708 	subb	a,r4
      008C56 EA               [12] 1709 	mov	a,r2
      008C57 9D               [12] 1710 	subb	a,r5
      008C58 50 09            [24] 1711 	jnc	00111$
      008C5A EB               [12] 1712 	mov	a,r3
      008C5B 12 3A 31         [24] 1713 	lcall	_ak820_outline_0030
      008C5E E4               [12] 1714 	clr	a
      008C5F F0               [24] 1715 	movx	@dptr,a
      008C60 0B               [12] 1716 	inc	r3
      008C61 80 EC            [24] 1717 	sjmp	00109$
      008C63                       1718 00111$:
                                   1719 ;	quantum/dynamic_keymap.c:483: }
      008C63 22               [24] 1720 	ret
                                   1721 ;------------------------------------------------------------
                                   1722 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1723 ;------------------------------------------------------------
                                   1724 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1725 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1726 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_417'
                                   1727 ;------------------------------------------------------------
                                   1728 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1729 ;	-----------------------------------------
                                   1730 ;	 function dynamic_keymap_get_buffer
                                   1731 ;	-----------------------------------------
      008C64                       1732 _dynamic_keymap_get_buffer:
      008C64 12 3A 84         [24] 1733 	lcall	_ak820_outline_0103
      008C67 90 0B 3F         [24] 1734 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008C6A 12 3A 89         [24] 1735 	lcall	_ak820_outline_0104
                                   1736 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008C6D 90 0B 3F         [24] 1737 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008C70 12 3A 41         [24] 1738 	lcall	_ak820_outline_0050
      008C73 90 0B 3A         [24] 1739 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008C76 12 3A 60         [24] 1740 	lcall	_ak820_outline_0059
      008C79 90 0B 3C         [24] 1741 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008C7C 12 51 23         [24] 1742 	lcall	_ak820_outline_0087
      008C7F 90 0B 2E         [24] 1743 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008C82 E4               [12] 1744 	clr	a
      008C83 F0               [24] 1745 	movx	@dptr,a
      008C84 74 06            [12] 1746 	mov	a,#0x06
      008C86 A3               [24] 1747 	inc	dptr
      008C87 F0               [24] 1748 	movx	@dptr,a
      008C88 90 0B 30         [24] 1749 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008C8B 12 4A 79         [24] 1750 	lcall	_ak820_outline_0058
      008C8E 90 0B 32         [24] 1751 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008C91 12 3A 66         [24] 1752 	lcall	_ak820_outline_0070
      008C94 90 0B 34         [24] 1753 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008C97 E9               [12] 1754 	mov	a,r1
      008C98 12 51 3C         [24] 1755 	lcall	_ak820_outline_0153
      008C9B F0               [24] 1756 	movx	@dptr,a
      008C9C 90 00 40         [24] 1757 	mov	dptr,#0x0040
                                   1758 ;	quantum/dynamic_keymap.c:511: }
      008C9F 61 AE            [12] 1759 	ajmp	_ak820_dynamic_read_buffer
                                   1760 ;------------------------------------------------------------
                                   1761 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1762 ;------------------------------------------------------------
                                   1763 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1764 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1765 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1766 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1767 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1768 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_419'
                                   1769 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_420'
                                   1770 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_420'
                                   1771 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_420'
                                   1772 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_423'
                                   1773 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_426'
                                   1774 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_426'
                                   1775 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_428'
                                   1776 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_431'
                                   1777 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_433'
                                   1778 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_434'
                                   1779 ;------------------------------------------------------------
                                   1780 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1781 ;	-----------------------------------------
                                   1782 ;	 function dynamic_keymap_set_buffer
                                   1783 ;	-----------------------------------------
      008CA1                       1784 _dynamic_keymap_set_buffer:
      008CA1 12 3A 84         [24] 1785 	lcall	_ak820_outline_0103
      008CA4 90 0B 46         [24] 1786 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008CA7 12 3A 89         [24] 1787 	lcall	_ak820_outline_0104
                                   1788 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008CAA 90 0B 46         [24] 1789 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008CAD 12 3A 0C         [24] 1790 	lcall	_ak820_outline_0009
      008CB0 74 40            [12] 1791 	mov	a,#0x40
      008CB2 2C               [12] 1792 	add	a, r4
      008CB3 FA               [12] 1793 	mov	r2,a
      008CB4 E4               [12] 1794 	clr	a
      008CB5 3D               [12] 1795 	addc	a, r5
      008CB6 FB               [12] 1796 	mov	r3,a
                                   1797 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008CB7 90 0B 43         [24] 1798 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008CBA 12 3A 7E         [24] 1799 	lcall	_ak820_outline_0099
                                   1800 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008CBD 90 0B 41         [24] 1801 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008CC0 E0               [24] 1802 	movx	a,@dptr
      008CC1 F5 2D            [12] 1803 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008CC3 A3               [24] 1804 	inc	dptr
      008CC4 E0               [24] 1805 	movx	a,@dptr
      008CC5 F5 2E            [12] 1806 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008CC7 E5 2D            [12] 1807 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008CC9 45 2E            [12] 1808 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008CCB 70 01            [24] 1809 	jnz	00102$
      008CCD 22               [24] 1810 	ret
      008CCE                       1811 00102$:
                                   1812 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008CCE 85 2D 2F         [24] 1813 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008CD1 85 2E 30         [24] 1814 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008CD4 C3               [12] 1815 	clr	c
      008CD5 74 1C            [12] 1816 	mov	a,#0x1c
      008CD7 95 2F            [12] 1817 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008CD9 E4               [12] 1818 	clr	a
      008CDA 95 30            [12] 1819 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008CDC 50 01            [24] 1820 	jnc	00104$
                                   1821 ;	free result
      008CDE 22               [24] 1822 	ret
      008CDF                       1823 00104$:
                                   1824 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008CDF 85 2D 31         [24] 1825 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1826 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008CE2 74 FA            [12] 1827 	mov	a,#0x100 - 0x06
      008CE4 2F               [12] 1828 	add	a,r7
      008CE5 40 11            [24] 1829 	jc	00105$
      008CE7 E4               [12] 1830 	clr	a
      008CE8 C3               [12] 1831 	clr	c
      008CE9 9E               [12] 1832 	subb	a,r6
      008CEA FE               [12] 1833 	mov	r6,a
      008CEB 74 06            [12] 1834 	mov	a,#0x06
      008CED 9F               [12] 1835 	subb	a,r7
      008CEE FF               [12] 1836 	mov	r7,a
      008CEF C3               [12] 1837 	clr	c
      008CF0 EE               [12] 1838 	mov	a,r6
      008CF1 95 2D            [12] 1839 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008CF3 EF               [12] 1840 	mov	a,r7
      008CF4 95 2E            [12] 1841 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008CF6 50 01            [24] 1842 	jnc	00106$
      008CF8                       1843 00105$:
                                   1844 ;	quantum/dynamic_keymap.c:529: return;
      008CF8 22               [24] 1845 	ret
      008CF9                       1846 00106$:
                                   1847 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008CF9 90 0E 1F         [24] 1848 	mov	dptr,#_vial_unlocked
      008CFC E0               [24] 1849 	movx	a,@dptr
      008CFD 60 02            [24] 1850 	jz	00207$
      008CFF C1 0D            [12] 1851 	ajmp	00120$
      008D01                       1852 00207$:
                                   1853 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008D01 90 0B 48         [24] 1854 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008D04 E4               [12] 1855 	clr	a
      008D05 F0               [24] 1856 	movx	@dptr,a
                                   1857 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008D06 90 0B 49         [24] 1858 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008D09 E5 31            [12] 1859 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008D0B F0               [24] 1860 	movx	@dptr,a
                                   1861 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008D0C EC               [12] 1862 	mov	a,r4
      008D0D 30 E0 33         [24] 1863 	jnb	acc.0,00111$
                                   1864 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008D10 EA               [12] 1865 	mov	a,r2
      008D11 24 FF            [12] 1866 	add	a,#0xff
      008D13 FE               [12] 1867 	mov	r6,a
      008D14 EB               [12] 1868 	mov	a,r3
      008D15 34 FF            [12] 1869 	addc	a,#0xff
      008D17 FF               [12] 1870 	mov	r7,a
      008D18 7D 00            [12] 1871 	mov	r5,#0x00
      008D1A 12 45 60         [24] 1872 	lcall	_ak820_outline_0116
      008D1D 8D F0            [24] 1873 	mov	b, r5
      008D1F 12 42 78         [24] 1874 	lcall	_eeprom_read_byte
      008D22 AE 82            [24] 1875 	mov	r6,dpl
      008D24 7F 00            [12] 1876 	mov	r7,#0x00
      008D26 12 3A B0         [24] 1877 	lcall	_ak820_outline_0154
      008D29 E0               [24] 1878 	movx	a,@dptr
      008D2A 7C 00            [12] 1879 	mov	r4,#0x00
      008D2C 42 07            [12] 1880 	orl	ar7,a
      008D2E EC               [12] 1881 	mov	a,r4
      008D2F 42 06            [12] 1882 	orl	ar6,a
                                   1883 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008D31 BF 00 09         [24] 1884 	cjne	r7,#0x00,00109$
      008D34 BE 7C 06         [24] 1885 	cjne	r6,#0x7c,00109$
                                   1886 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008D37 12 3A B0         [24] 1887 	lcall	_ak820_outline_0154
      008D3A 74 FF            [12] 1888 	mov	a,#0xff
      008D3C F0               [24] 1889 	movx	@dptr,a
      008D3D                       1890 00109$:
                                   1891 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008D3D 90 0B 48         [24] 1892 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008D40 74 01            [12] 1893 	mov	a,#0x01
      008D42 F0               [24] 1894 	movx	@dptr,a
      008D43                       1895 00111$:
                                   1896 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008D43 90 0B 46         [24] 1897 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008D46 12 3A 41         [24] 1898 	lcall	_ak820_outline_0050
      008D49 E5 2D            [12] 1899 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008D4B 2E               [12] 1900 	add	a, r6
      008D4C FE               [12] 1901 	mov	r6,a
      008D4D E5 2E            [12] 1902 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008D4F 3F               [12] 1903 	addc	a, r7
      008D50 EE               [12] 1904 	mov	a,r6
      008D51 30 E0 5A         [24] 1905 	jnb	acc.0,00115$
                                   1906 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008D54 AE 31            [24] 1907 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008D56 7F 00            [12] 1908 	mov	r7,#0x00
      008D58 EE               [12] 1909 	mov	a,r6
      008D59 24 FF            [12] 1910 	add	a,#0xff
      008D5B FC               [12] 1911 	mov	r4,a
      008D5C EF               [12] 1912 	mov	a,r7
      008D5D 34 FF            [12] 1913 	addc	a,#0xff
      008D5F FD               [12] 1914 	mov	r5,a
      008D60 EC               [12] 1915 	mov	a,r4
      008D61 28               [12] 1916 	add	a, r0
      008D62 F5 82            [12] 1917 	mov	dpl,a
      008D64 ED               [12] 1918 	mov	a,r5
      008D65 39               [12] 1919 	addc	a, r1
      008D66 F5 83            [12] 1920 	mov	dph,a
      008D68 E0               [24] 1921 	movx	a,@dptr
      008D69 FC               [12] 1922 	mov	r4,a
      008D6A 7D 00            [12] 1923 	mov	r5,#0x00
      008D6C E5 31            [12] 1924 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008D6E 2A               [12] 1925 	add	a, r2
      008D6F FA               [12] 1926 	mov	r2,a
      008D70 E4               [12] 1927 	clr	a
      008D71 3B               [12] 1928 	addc	a, r3
      008D72 FB               [12] 1929 	mov	r3,a
      008D73 C0 00            [24] 1930 	push	ar0
      008D75 C0 01            [24] 1931 	push	ar1
      008D77 8B 01            [24] 1932 	mov	ar1,r3
      008D79 7B 00            [12] 1933 	mov	r3,#0x00
      008D7B 8A 82            [24] 1934 	mov	dpl, r2
      008D7D 89 83            [24] 1935 	mov	dph, r1
      008D7F 8B F0            [24] 1936 	mov	b, r3
      008D81 12 42 78         [24] 1937 	lcall	_eeprom_read_byte
      008D84 AB 82            [24] 1938 	mov	r3, dpl
      008D86 7A 00            [12] 1939 	mov	r2,#0x00
      008D88 EB               [12] 1940 	mov	a,r3
      008D89 12 45 76         [24] 1941 	lcall	_ak820_outline_0140
                                   1942 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008D8C BD 00 05         [24] 1943 	cjne	r5,#0x00,00212$
      008D8F BC 7C 02         [24] 1944 	cjne	r4,#0x7c,00212$
      008D92 80 06            [24] 1945 	sjmp	00213$
      008D94                       1946 00212$:
      008D94 D0 01            [24] 1947 	pop	ar1
      008D96 D0 00            [24] 1948 	pop	ar0
      008D98 80 0D            [24] 1949 	sjmp	00113$
      008D9A                       1950 00213$:
      008D9A D0 01            [24] 1951 	pop	ar1
      008D9C D0 00            [24] 1952 	pop	ar0
                                   1953 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008D9E 1E               [12] 1954 	dec	r6
      008D9F BE FF 01         [24] 1955 	cjne	r6,#0xff,00214$
      008DA2 1F               [12] 1956 	dec	r7
      008DA3                       1957 00214$:
      008DA3 EE               [12] 1958 	mov	a,r6
      008DA4 12 92 47         [24] 1959 	lcall	_ak820_outline_0126
      008DA7                       1960 00113$:
                                   1961 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008DA7 E5 31            [12] 1962 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008DA9 14               [12] 1963 	dec	a
      008DAA 90 0B 49         [24] 1964 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008DAD F0               [24] 1965 	movx	@dptr,a
      008DAE                       1966 00115$:
                                   1967 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008DAE 90 0B 48         [24] 1968 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008DB1 E0               [24] 1969 	movx	a,@dptr
      008DB2 90 0B 4A         [24] 1970 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008DB5 F0               [24] 1971 	movx	@dptr,a
      008DB6                       1972 00122$:
      008DB6 90 0B 4A         [24] 1973 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008DB9 E0               [24] 1974 	movx	a,@dptr
      008DBA FF               [12] 1975 	mov	r7,a
      008DBB 90 0B 49         [24] 1976 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008DBE E0               [24] 1977 	movx	a,@dptr
      008DBF FE               [12] 1978 	mov	r6,a
      008DC0 C3               [12] 1979 	clr	c
      008DC1 EF               [12] 1980 	mov	a,r7
      008DC2 9E               [12] 1981 	subb	a,r6
      008DC3 50 48            [24] 1982 	jnc	00120$
                                   1983 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008DC5 EF               [12] 1984 	mov	a,r7
      008DC6 28               [12] 1985 	add	a, r0
      008DC7 FD               [12] 1986 	mov	r5,a
      008DC8 E4               [12] 1987 	clr	a
      008DC9 39               [12] 1988 	addc	a, r1
      008DCA FE               [12] 1989 	mov	r6,a
      008DCB 12 4A 7F         [24] 1990 	lcall	_ak820_outline_0074
      008DCE 7B 00            [12] 1991 	mov	r3,#0x00
      008DD0 8C 2E            [24] 1992 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008DD2 8B 2D            [24] 1993 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008DD4 8F 02            [24] 1994 	mov	ar2,r7
      008DD6 7F 00            [12] 1995 	mov	r7,#0x00
      008DD8 74 01            [12] 1996 	mov	a,#0x01
      008DDA 2A               [12] 1997 	add	a, r2
      008DDB FB               [12] 1998 	mov	r3,a
      008DDC E4               [12] 1999 	clr	a
      008DDD 3F               [12] 2000 	addc	a, r7
      008DDE FC               [12] 2001 	mov	r4,a
      008DDF EB               [12] 2002 	mov	a,r3
      008DE0 28               [12] 2003 	add	a, r0
      008DE1 F5 82            [12] 2004 	mov	dpl,a
      008DE3 EC               [12] 2005 	mov	a,r4
      008DE4 39               [12] 2006 	addc	a, r1
      008DE5 F5 83            [12] 2007 	mov	dph,a
      008DE7 E0               [24] 2008 	movx	a,@dptr
      008DE8 FC               [12] 2009 	mov	r4,a
      008DE9 7B 00            [12] 2010 	mov	r3,#0x00
      008DEB E5 2E            [12] 2011 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008DED 42 03            [12] 2012 	orl	ar3,a
                                   2013 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008DEF BC 00 12         [24] 2014 	cjne	r4,#0x00,00123$
      008DF2 BB 7C 0F         [24] 2015 	cjne	r3,#0x7c,00123$
                                   2016 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008DF5 12 3A A5         [24] 2017 	lcall	_ak820_outline_0131
      008DF8 74 FF            [12] 2018 	mov	a,#0xff
      008DFA F0               [24] 2019 	movx	@dptr,a
                                   2020 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008DFB 0A               [12] 2021 	inc	r2
      008DFC BA 00 01         [24] 2022 	cjne	r2,#0x00,00218$
      008DFF 0F               [12] 2023 	inc	r7
      008E00                       2024 00218$:
      008E00 EA               [12] 2025 	mov	a,r2
      008E01 12 92 47         [24] 2026 	lcall	_ak820_outline_0126
      008E04                       2027 00123$:
                                   2028 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008E04 90 0B 4A         [24] 2029 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008E07 E0               [24] 2030 	movx	a,@dptr
      008E08 24 02            [12] 2031 	add	a,#0x02
      008E0A F0               [24] 2032 	movx	@dptr,a
      008E0B 80 A9            [24] 2033 	sjmp	00122$
      008E0D                       2034 00120$:
                                   2035 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008E0D 90 0B 46         [24] 2036 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008E10 12 3A 41         [24] 2037 	lcall	_ak820_outline_0050
      008E13 74 40            [12] 2038 	mov	a,#0x40
      008E15 12 45 70         [24] 2039 	lcall	_ak820_outline_0133
      008E18 90 05 9A         [24] 2040 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008E1B 12 4A 79         [24] 2041 	lcall	_ak820_outline_0058
      008E1E E4               [12] 2042 	clr	a
      008E1F A3               [24] 2043 	inc	dptr
      008E20 F0               [24] 2044 	movx	@dptr,a
      008E21 90 05 9D         [24] 2045 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008E24 E5 2F            [12] 2046 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008E26 F0               [24] 2047 	movx	@dptr,a
      008E27 E5 30            [12] 2048 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008E29 A3               [24] 2049 	inc	dptr
      008E2A F0               [24] 2050 	movx	@dptr,a
      008E2B 12 3A B0         [24] 2051 	lcall	_ak820_outline_0154
                                   2052 ;	quantum/dynamic_keymap.c:584: }
      008E2E 02 43 3F         [24] 2053 	ljmp	_ak820_eeprom_write_block_xdata
                                   2054 ;------------------------------------------------------------
                                   2055 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2056 ;------------------------------------------------------------
                                   2057 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2058 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2059 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_437'
                                   2060 ;------------------------------------------------------------
                                   2061 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2062 ;	-----------------------------------------
                                   2063 ;	 function keycode_at_keymap_location
                                   2064 ;	-----------------------------------------
      008E31                       2065 _keycode_at_keymap_location:
      008E31 E5 82            [12] 2066 	mov	a,dpl
      008E33 90 0B 4D         [24] 2067 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_437
      008E36 F0               [24] 2068 	movx	@dptr,a
                                   2069 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008E37 E0               [24] 2070 	movx	a,@dptr
      008E38 FF               [12] 2071 	mov	r7,a
      008E39 BF 06 00         [24] 2072 	cjne	r7,#0x06,00128$
      008E3C                       2073 00128$:
      008E3C 50 23            [24] 2074 	jnc	00102$
      008E3E 90 0B 4B         [24] 2075 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008E41 E0               [24] 2076 	movx	a,@dptr
      008E42 FE               [12] 2077 	mov	r6,a
      008E43 BE 10 00         [24] 2078 	cjne	r6,#0x10,00130$
      008E46                       2079 00130$:
      008E46 50 19            [24] 2080 	jnc	00102$
      008E48 90 0B 4C         [24] 2081 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008E4B E0               [24] 2082 	movx	a,@dptr
      008E4C FD               [12] 2083 	mov	r5,a
      008E4D BD 08 00         [24] 2084 	cjne	r5,#0x08,00132$
      008E50                       2085 00132$:
      008E50 50 0F            [24] 2086 	jnc	00102$
                                   2087 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008E52 90 0A FF         [24] 2088 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008E55 EE               [12] 2089 	mov	a,r6
      008E56 F0               [24] 2090 	movx	@dptr,a
      008E57 90 0B 00         [24] 2091 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008E5A ED               [12] 2092 	mov	a,r5
      008E5B F0               [24] 2093 	movx	@dptr,a
      008E5C 8F 82            [24] 2094 	mov	dpl, r7
      008E5E 02 87 CE         [24] 2095 	ljmp	_dynamic_keymap_get_keycode
      008E61                       2096 00102$:
                                   2097 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008E61 90 00 00         [24] 2098 	mov	dptr,#0x0000
                                   2099 ;	quantum/dynamic_keymap.c:591: }
      008E64 22               [24] 2100 	ret
                                   2101 ;------------------------------------------------------------
                                   2102 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2103 ;------------------------------------------------------------
                                   2104 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2105 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2106 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_441'
                                   2107 ;------------------------------------------------------------
                                   2108 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2109 ;	-----------------------------------------
                                   2110 ;	 function keycode_at_encodermap_location
                                   2111 ;	-----------------------------------------
      008E65                       2112 _keycode_at_encodermap_location:
      008E65 E5 82            [12] 2113 	mov	a,dpl
      008E67 90 0B 50         [24] 2114 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_441
      008E6A F0               [24] 2115 	movx	@dptr,a
                                   2116 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008E6B E0               [24] 2117 	movx	a,@dptr
      008E6C FF               [12] 2118 	mov	r7,a
      008E6D BF 06 00         [24] 2119 	cjne	r7,#0x06,00120$
      008E70                       2120 00120$:
      008E70 50 1D            [24] 2121 	jnc	00102$
      008E72 90 0B 4E         [24] 2122 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008E75 E0               [24] 2123 	movx	a,@dptr
      008E76 FE               [12] 2124 	mov	r6,a
      008E77 BE 01 00         [24] 2125 	cjne	r6,#0x01,00122$
      008E7A                       2126 00122$:
      008E7A 50 13            [24] 2127 	jnc	00102$
                                   2128 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008E7C 90 0B 4F         [24] 2129 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008E7F E0               [24] 2130 	movx	a,@dptr
      008E80 FE               [12] 2131 	mov	r6,a
      008E81 90 0B 09         [24] 2132 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008E84 E4               [12] 2133 	clr	a
      008E85 F0               [24] 2134 	movx	@dptr,a
      008E86 90 0B 0A         [24] 2135 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008E89 EE               [12] 2136 	mov	a,r6
      008E8A F0               [24] 2137 	movx	@dptr,a
      008E8B 8F 82            [24] 2138 	mov	dpl, r7
      008E8D 01 8F            [12] 2139 	ajmp	_dynamic_keymap_get_encoder
      008E8F                       2140 00102$:
                                   2141 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008E8F 90 00 00         [24] 2142 	mov	dptr,#0x0000
                                   2143 ;	quantum/dynamic_keymap.c:599: }
      008E92 22               [24] 2144 	ret
                                   2145 ;------------------------------------------------------------
                                   2146 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2147 ;------------------------------------------------------------
                                   2148 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2149 ;	-----------------------------------------
                                   2150 ;	 function dynamic_keymap_macro_get_count
                                   2151 ;	-----------------------------------------
      008E93                       2152 _dynamic_keymap_macro_get_count:
                                   2153 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008E93 75 82 10         [24] 2154 	mov	dpl, #0x10
                                   2155 ;	quantum/dynamic_keymap.c:604: }
      008E96 22               [24] 2156 	ret
                                   2157 ;------------------------------------------------------------
                                   2158 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2159 ;------------------------------------------------------------
                                   2160 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2161 ;	-----------------------------------------
                                   2162 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2163 ;	-----------------------------------------
      008E97                       2164 _dynamic_keymap_macro_get_buffer_size:
                                   2165 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008E97 90 20 00         [24] 2166 	mov	dptr,#0x2000
                                   2167 ;	quantum/dynamic_keymap.c:608: }
      008E9A 22               [24] 2168 	ret
                                   2169 ;------------------------------------------------------------
                                   2170 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2171 ;------------------------------------------------------------
                                   2172 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2173 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2174 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2175 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_449'
                                   2176 ;------------------------------------------------------------
                                   2177 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2178 ;	-----------------------------------------
                                   2179 ;	 function dynamic_keymap_macro_get_buffer
                                   2180 ;	-----------------------------------------
      008E9B                       2181 _dynamic_keymap_macro_get_buffer:
      008E9B 12 3A 84         [24] 2182 	lcall	_ak820_outline_0103
      008E9E 90 0B 56         [24] 2183 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008EA1 12 3A 89         [24] 2184 	lcall	_ak820_outline_0104
                                   2185 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008EA4 12 2B 2B         [24] 2186 	lcall	_ak820_macro_length
      008EA7 12 45 6B         [24] 2187 	lcall	_ak820_outline_0130
      008EAA 90 0B 56         [24] 2188 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008EAD 12 3A 60         [24] 2189 	lcall	_ak820_outline_0059
      008EB0 90 0B 51         [24] 2190 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008EB3 E0               [24] 2191 	movx	a,@dptr
      008EB4 F5 32            [12] 2192 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008EB6 A3               [24] 2193 	inc	dptr
      008EB7 E0               [24] 2194 	movx	a,@dptr
      008EB8 F5 33            [12] 2195 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008EBA 90 0B 53         [24] 2196 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008EBD 12 3A 7E         [24] 2197 	lcall	_ak820_outline_0099
      008EC0 A3               [24] 2198 	inc	dptr
      008EC1 E0               [24] 2199 	movx	a,@dptr
      008EC2 FB               [12] 2200 	mov	r3,a
      008EC3 90 0B 2E         [24] 2201 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008EC6 12 4A 79         [24] 2202 	lcall	_ak820_outline_0058
      008EC9 90 0B 30         [24] 2203 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008ECC 12 3A 66         [24] 2204 	lcall	_ak820_outline_0070
      008ECF 90 0B 32         [24] 2205 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008ED2 E5 32            [12] 2206 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008ED4 F0               [24] 2207 	movx	@dptr,a
      008ED5 E5 33            [12] 2208 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008ED7 A3               [24] 2209 	inc	dptr
      008ED8 F0               [24] 2210 	movx	@dptr,a
      008ED9 90 0B 34         [24] 2211 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008EDC E8               [12] 2212 	mov	a,r0
      008EDD F0               [24] 2213 	movx	@dptr,a
      008EDE E9               [12] 2214 	mov	a,r1
      008EDF A3               [24] 2215 	inc	dptr
      008EE0 F0               [24] 2216 	movx	@dptr,a
      008EE1 EB               [12] 2217 	mov	a,r3
      008EE2 A3               [24] 2218 	inc	dptr
      008EE3 F0               [24] 2219 	movx	@dptr,a
      008EE4 90 08 00         [24] 2220 	mov	dptr,#0x0800
                                   2221 ;	quantum/dynamic_keymap.c:635: }
      008EE7 61 AE            [12] 2222 	ajmp	_ak820_dynamic_read_buffer
                                   2223 ;------------------------------------------------------------
                                   2224 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2225 ;------------------------------------------------------------
                                   2226 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2227 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2228 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_451'
                                   2229 ;------------------------------------------------------------
                                   2230 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2231 ;	-----------------------------------------
                                   2232 ;	 function dynamic_keymap_macro_set_buffer
                                   2233 ;	-----------------------------------------
      008EE9                       2234 _dynamic_keymap_macro_set_buffer:
      008EE9 12 3A 84         [24] 2235 	lcall	_ak820_outline_0103
      008EEC 90 0B 5D         [24] 2236 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008EEF 12 3A 89         [24] 2237 	lcall	_ak820_outline_0104
                                   2238 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      008EF2 90 0B 5D         [24] 2239 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008EF5 12 3A 41         [24] 2240 	lcall	_ak820_outline_0050
      008EF8 90 0B 58         [24] 2241 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008EFB 12 3A 60         [24] 2242 	lcall	_ak820_outline_0059
      008EFE 90 0B 5A         [24] 2243 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008F01 12 51 23         [24] 2244 	lcall	_ak820_outline_0087
      008F04 90 05 20         [24] 2245 	mov	dptr,#_ak820_macro_write_PARM_2
      008F07 12 3A 66         [24] 2246 	lcall	_ak820_outline_0070
      008F0A 90 05 22         [24] 2247 	mov	dptr,#_ak820_macro_write_PARM_3
      008F0D E9               [12] 2248 	mov	a,r1
      008F0E 12 51 3C         [24] 2249 	lcall	_ak820_outline_0153
      008F11 12 45 3B         [24] 2250 	lcall	_ak820_outline_0060
                                   2251 ;	quantum/dynamic_keymap.c:640: }
      008F14 02 2B 45         [24] 2252 	ljmp	_ak820_macro_write
                                   2253 ;------------------------------------------------------------
                                   2254 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2255 ;------------------------------------------------------------
                                   2256 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2257 ;	-----------------------------------------
                                   2258 ;	 function dynamic_keymap_macro_reset
                                   2259 ;	-----------------------------------------
      008F17                       2260 _dynamic_keymap_macro_reset:
                                   2261 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2262 ;	quantum/dynamic_keymap.c:666: }
      008F17 02 2E 64         [24] 2263 	ljmp	_ak820_macro_reset
                                   2264 ;------------------------------------------------------------
                                   2265 ;Allocation info for local variables in function 'decode_keycode'
                                   2266 ;------------------------------------------------------------
                                   2267 ;kc            Allocated with name '_decode_keycode_kc_10000_455'
                                   2268 ;------------------------------------------------------------
                                   2269 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2270 ;	-----------------------------------------
                                   2271 ;	 function decode_keycode
                                   2272 ;	-----------------------------------------
      008F1A                       2273 _decode_keycode:
      008F1A 12 3A 84         [24] 2274 	lcall	_ak820_outline_0103
      008F1D 90 0B 5F         [24] 2275 	mov	dptr,#_decode_keycode_kc_10000_455
      008F20 12 3A 89         [24] 2276 	lcall	_ak820_outline_0104
                                   2277 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      008F23 90 0B 5F         [24] 2278 	mov	dptr,#_decode_keycode_kc_10000_455
      008F26 12 3A 0C         [24] 2279 	lcall	_ak820_outline_0009
      008F29 C3               [12] 2280 	clr	c
      008F2A E4               [12] 2281 	clr	a
      008F2B 9C               [12] 2282 	subb	a,r4
      008F2C 74 FF            [12] 2283 	mov	a,#0xff
      008F2E 9D               [12] 2284 	subb	a,r5
      008F2F 50 08            [24] 2285 	jnc	00102$
                                   2286 ;	free result
                                   2287 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      008F31 8C 05            [24] 2288 	mov	ar5,r4
      008F33 7C 00            [12] 2289 	mov	r4,#0x00
      008F35 12 3A 95         [24] 2290 	lcall	_ak820_outline_0117
      008F38 22               [24] 2291 	ret
      008F39                       2292 00102$:
                                   2293 ;	quantum/dynamic_keymap.c:672: return kc;
      008F39 12 45 60         [24] 2294 	lcall	_ak820_outline_0116
                                   2295 ;	quantum/dynamic_keymap.c:673: }
      008F3C 22               [24] 2296 	ret
                                   2297 ;------------------------------------------------------------
                                   2298 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2299 ;------------------------------------------------------------
                                   2300 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_458'
                                   2301 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_459'
                                   2302 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_464'
                                   2303 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_465'
                                   2304 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_471'
                                   2305 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_489'
                                   2306 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_493'
                                   2307 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_493'
                                   2308 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_495'
                                   2309 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_497'
                                   2310 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_501'
                                   2311 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_503'
                                   2312 ;------------------------------------------------------------
                                   2313 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2314 ;	-----------------------------------------
                                   2315 ;	 function dynamic_keymap_macro_send
                                   2316 ;	-----------------------------------------
      008F3D                       2317 _dynamic_keymap_macro_send:
      008F3D E5 82            [12] 2318 	mov	a,dpl
      008F3F 90 0B 61         [24] 2319 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008F42 F0               [24] 2320 	movx	@dptr,a
                                   2321 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      008F43 90 0B 62         [24] 2322 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008F46 E0               [24] 2323 	movx	a,@dptr
      008F47 60 01            [24] 2324 	jz	00102$
      008F49 22               [24] 2325 	ret
      008F4A                       2326 00102$:
                                   2327 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008F4A 90 0B 61         [24] 2328 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008F4D E0               [24] 2329 	movx	a,@dptr
      008F4E FF               [12] 2330 	mov	r7,a
      008F4F BF 10 00         [24] 2331 	cjne	r7,#0x10,00422$
      008F52                       2332 00422$:
      008F52 40 01            [24] 2333 	jc	00104$
                                   2334 ;	quantum/dynamic_keymap.c:683: return;
      008F54 22               [24] 2335 	ret
      008F55                       2336 00104$:
                                   2337 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      008F55 C0 07            [24] 2338 	push	ar7
      008F57 12 2A F2         [24] 2339 	lcall	_ak820_macro_ready
      008F5A E5 82            [12] 2340 	mov	a, dpl
      008F5C D0 07            [24] 2341 	pop	ar7
      008F5E 70 01            [24] 2342 	jnz	00106$
      008F60 22               [24] 2343 	ret
      008F61                       2344 00106$:
                                   2345 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008F61 90 0B 63         [24] 2346 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008F64 E4               [12] 2347 	clr	a
      008F65 F0               [24] 2348 	movx	@dptr,a
      008F66 74 08            [12] 2349 	mov	a,#0x08
      008F68 A3               [24] 2350 	inc	dptr
      008F69 F0               [24] 2351 	movx	@dptr,a
                                   2352 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008F6A C0 07            [24] 2353 	push	ar7
      008F6C 12 2B 2B         [24] 2354 	lcall	_ak820_macro_length
      008F6F AD 82            [24] 2355 	mov	r5, dpl
      008F71 AE 83            [24] 2356 	mov	r6, dph
      008F73 D0 07            [24] 2357 	pop	ar7
      008F75 74 08            [12] 2358 	mov	a,#0x08
      008F77 2E               [12] 2359 	add	a, r6
      008F78 FE               [12] 2360 	mov	r6,a
                                   2361 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      008F79 7B 00            [12] 2362 	mov	r3,#0x00
      008F7B 7C 08            [12] 2363 	mov	r4,#0x08
      008F7D                       2364 00111$:
      008F7D EF               [12] 2365 	mov	a,r7
      008F7E 60 31            [24] 2366 	jz	00113$
                                   2367 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008F80 EB               [12] 2368 	mov	a,r3
      008F81 B5 05 05         [24] 2369 	cjne	a,ar5,00108$
      008F84 EC               [12] 2370 	mov	a,r4
      008F85 B5 06 01         [24] 2371 	cjne	a,ar6,00108$
                                   2372 ;	quantum/dynamic_keymap.c:717: return;
      008F88 22               [24] 2373 	ret
      008F89                       2374 00108$:
                                   2375 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008F89 8B 01            [24] 2376 	mov	ar1,r3
      008F8B 8C 02            [24] 2377 	mov	ar2,r4
      008F8D 8A 00            [24] 2378 	mov	ar0,r2
      008F8F 7A 00            [12] 2379 	mov	r2,#0x00
      008F91 89 82            [24] 2380 	mov	dpl, r1
      008F93 88 83            [24] 2381 	mov	dph, r0
      008F95 8A F0            [24] 2382 	mov	b, r2
      008F97 12 42 78         [24] 2383 	lcall	_eeprom_read_byte
      008F9A E5 82            [12] 2384 	mov	a, dpl
      008F9C 70 06            [24] 2385 	jnz	00110$
                                   2386 ;	quantum/dynamic_keymap.c:720: --id;
      008F9E 1F               [12] 2387 	dec	r7
      008F9F 90 0B 61         [24] 2388 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008FA2 EF               [12] 2389 	mov	a,r7
      008FA3 F0               [24] 2390 	movx	@dptr,a
      008FA4                       2391 00110$:
                                   2392 ;	quantum/dynamic_keymap.c:722: ++p;
      008FA4 0B               [12] 2393 	inc	r3
      008FA5 BB 00 01         [24] 2394 	cjne	r3,#0x00,00429$
      008FA8 0C               [12] 2395 	inc	r4
      008FA9                       2396 00429$:
      008FA9 90 0B 63         [24] 2397 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008FAC 12 3A 6C         [24] 2398 	lcall	_ak820_outline_0076
      008FAF 80 CC            [24] 2399 	sjmp	00111$
      008FB1                       2400 00113$:
                                   2401 ;	quantum/dynamic_keymap.c:728: sending = true;
      008FB1 90 0B 62         [24] 2402 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008FB4 74 01            [12] 2403 	mov	a,#0x01
      008FB6 F0               [24] 2404 	movx	@dptr,a
                                   2405 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      008FB7 12 92 5F         [24] 2406 	lcall	_ak820_outline_0161
      008FBA 90 09 AB         [24] 2407 	mov	dptr,#_ak820_macro_cancelled
      008FBD F0               [24] 2408 	movx	@dptr,a
                                   2409 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      008FBE 90 0B 65         [24] 2410 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008FC1 F0               [24] 2411 	movx	@dptr,a
      008FC2 90 0B 66         [24] 2412 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008FC5 F0               [24] 2413 	movx	@dptr,a
      008FC6 90 0B 67         [24] 2414 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008FC9 F0               [24] 2415 	movx	@dptr,a
      008FCA 90 0B 68         [24] 2416 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008FCD F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	quantum/dynamic_keymap.c:738: while (p < end
      008FCE                       2419 00167$:
                                   2420 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      008FCE 90 0B 63         [24] 2421 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008FD1 E0               [24] 2422 	movx	a,@dptr
      008FD2 FC               [12] 2423 	mov	r4,a
      008FD3 A3               [24] 2424 	inc	dptr
      008FD4 E0               [24] 2425 	movx	a,@dptr
      008FD5 FF               [12] 2426 	mov	r7,a
      008FD6 C3               [12] 2427 	clr	c
      008FD7 EC               [12] 2428 	mov	a,r4
      008FD8 9D               [12] 2429 	subb	a,r5
      008FD9 EF               [12] 2430 	mov	a,r7
      008FDA 9E               [12] 2431 	subb	a,r6
      008FDB 40 03            [24] 2432 	jc	00430$
      008FDD 02 91 ED         [24] 2433 	ljmp	00169$
      008FE0                       2434 00430$:
      008FE0 90 09 AB         [24] 2435 	mov	dptr,#_ak820_macro_cancelled
      008FE3 E0               [24] 2436 	movx	a,@dptr
      008FE4 60 03            [24] 2437 	jz	00431$
      008FE6 02 91 ED         [24] 2438 	ljmp	00169$
      008FE9                       2439 00431$:
                                   2440 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008FE9 8C 02            [24] 2441 	mov	ar2,r4
      008FEB 8F 03            [24] 2442 	mov	ar3,r7
      008FED 90 0B 63         [24] 2443 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008FF0 74 01            [12] 2444 	mov	a,#0x01
      008FF2 2C               [12] 2445 	add	a, r4
      008FF3 F0               [24] 2446 	movx	@dptr,a
      008FF4 E4               [12] 2447 	clr	a
      008FF5 3F               [12] 2448 	addc	a, r7
      008FF6 A3               [24] 2449 	inc	dptr
      008FF7 F0               [24] 2450 	movx	@dptr,a
      008FF8 7F 00            [12] 2451 	mov	r7,#0x00
      008FFA 12 45 7C         [24] 2452 	lcall	_ak820_outline_0141
      008FFD 8F F0            [24] 2453 	mov	b, r7
      008FFF 12 42 78         [24] 2454 	lcall	_eeprom_read_byte
      009002 AF 82            [24] 2455 	mov	r7, dpl
      009004 90 0B 65         [24] 2456 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      009007 EF               [12] 2457 	mov	a,r7
      009008 F0               [24] 2458 	movx	@dptr,a
                                   2459 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      009009 90 0B 66         [24] 2460 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      00900C E4               [12] 2461 	clr	a
      00900D F0               [24] 2462 	movx	@dptr,a
                                   2463 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      00900E 90 0B 65         [24] 2464 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      009011 E0               [24] 2465 	movx	a,@dptr
      009012 70 02            [24] 2466 	jnz	00432$
      009014 21 ED            [12] 2467 	ajmp	00169$
      009016                       2468 00432$:
                                   2469 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      009016 90 0B 65         [24] 2470 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      009019 E0               [24] 2471 	movx	a,@dptr
      00901A FF               [12] 2472 	mov	r7,a
      00901B BF 01 02         [24] 2473 	cjne	r7,#0x01,00433$
      00901E 80 02            [24] 2474 	sjmp	00434$
      009020                       2475 00433$:
      009020 21 CF            [12] 2476 	ajmp	00164$
      009022                       2477 00434$:
                                   2478 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009022 12 91 F5         [24] 2479 	lcall	_ak820_outline_0000
      009025 12 42 78         [24] 2480 	lcall	_eeprom_read_byte
      009028 AF 82            [24] 2481 	mov	r7, dpl
      00902A 90 0B 66         [24] 2482 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      00902D EF               [12] 2483 	mov	a,r7
      00902E F0               [24] 2484 	movx	@dptr,a
                                   2485 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      00902F EF               [12] 2486 	mov	a,r7
      009030 70 02            [24] 2487 	jnz	00435$
      009032 21 ED            [12] 2488 	ajmp	00169$
      009034                       2489 00435$:
                                   2490 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      009034 12 92 2D         [24] 2491 	lcall	_ak820_outline_0089
      009037 BF 01 02         [24] 2492 	cjne	r7,#0x01,00436$
      00903A 80 12            [24] 2493 	sjmp	00151$
      00903C                       2494 00436$:
      00903C 12 92 2D         [24] 2495 	lcall	_ak820_outline_0089
      00903F BF 02 02         [24] 2496 	cjne	r7,#0x02,00437$
      009042 80 0A            [24] 2497 	sjmp	00151$
      009044                       2498 00437$:
      009044 12 92 2D         [24] 2499 	lcall	_ak820_outline_0089
      009047 BF 03 02         [24] 2500 	cjne	r7,#0x03,00438$
      00904A 80 02            [24] 2501 	sjmp	00439$
      00904C                       2502 00438$:
      00904C 01 AF            [12] 2503 	ajmp	00152$
      00904E                       2504 00439$:
      00904E                       2505 00151$:
                                   2506 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00904E 12 91 F5         [24] 2507 	lcall	_ak820_outline_0000
      009051 12 42 78         [24] 2508 	lcall	_eeprom_read_byte
      009054 12 92 77         [24] 2509 	lcall	_ak820_outline_0177
                                   2510 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      009057 70 03            [24] 2511 	jnz	00440$
      009059 02 8F CE         [24] 2512 	ljmp	00167$
      00905C                       2513 00440$:
                                   2514 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      00905C 12 92 2D         [24] 2515 	lcall	_ak820_outline_0089
      00905F BF 01 03         [24] 2516 	cjne	r7,#0x01,00441$
      009062 D3               [12] 2517 	setb	c
      009063 80 01            [24] 2518 	sjmp	00442$
      009065                       2519 00441$:
      009065 C3               [12] 2520 	clr	c
      009066                       2521 00442$:
      009066 92 23            [24] 2522 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      009068 90 09 AA         [24] 2523 	mov	dptr,#_ak820_macro_primitive
      00906B B3               [12] 2524 	cpl	c
      00906C E4               [12] 2525 	clr	a
      00906D 33               [12] 2526 	rlc	a
      00906E F0               [24] 2527 	movx	@dptr,a
                                   2528 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      00906F 12 92 2D         [24] 2529 	lcall	_ak820_outline_0089
      009072 BF 01 10         [24] 2530 	cjne	r7,#0x01,00122$
      009075 12 92 58         [24] 2531 	lcall	_ak820_outline_0149
      009078 C0 06            [24] 2532 	push	ar6
      00907A C0 05            [24] 2533 	push	ar5
      00907C 12 7A 66         [24] 2534 	lcall	_tap_code
      00907F D0 05            [24] 2535 	pop	ar5
      009081 D0 06            [24] 2536 	pop	ar6
      009083 80 24            [24] 2537 	sjmp	00123$
      009085                       2538 00122$:
                                   2539 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      009085 12 92 2D         [24] 2540 	lcall	_ak820_outline_0089
      009088 BF 02 10         [24] 2541 	cjne	r7,#0x02,00119$
      00908B 12 92 58         [24] 2542 	lcall	_ak820_outline_0149
      00908E C0 06            [24] 2543 	push	ar6
      009090 C0 05            [24] 2544 	push	ar5
      009092 12 79 35         [24] 2545 	lcall	_register_code
      009095 D0 05            [24] 2546 	pop	ar5
      009097 D0 06            [24] 2547 	pop	ar6
      009099 80 0E            [24] 2548 	sjmp	00123$
      00909B                       2549 00119$:
                                   2550 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      00909B 12 92 58         [24] 2551 	lcall	_ak820_outline_0149
      00909E C0 06            [24] 2552 	push	ar6
      0090A0 C0 05            [24] 2553 	push	ar5
      0090A2 12 79 BA         [24] 2554 	lcall	_unregister_code
      0090A5 D0 05            [24] 2555 	pop	ar5
      0090A7 D0 06            [24] 2556 	pop	ar6
      0090A9                       2557 00123$:
                                   2558 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      0090A9 12 92 5F         [24] 2559 	lcall	_ak820_outline_0161
      0090AC 02 8F CE         [24] 2560 	ljmp	00167$
      0090AF                       2561 00152$:
                                   2562 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      0090AF 12 92 2D         [24] 2563 	lcall	_ak820_outline_0089
      0090B2 BF 05 02         [24] 2564 	cjne	r7,#0x05,00447$
      0090B5 80 12            [24] 2565 	sjmp	00146$
      0090B7                       2566 00447$:
      0090B7 12 92 2D         [24] 2567 	lcall	_ak820_outline_0089
      0090BA BF 06 02         [24] 2568 	cjne	r7,#0x06,00448$
      0090BD 80 0A            [24] 2569 	sjmp	00146$
      0090BF                       2570 00448$:
      0090BF 12 92 2D         [24] 2571 	lcall	_ak820_outline_0089
      0090C2 BF 07 02         [24] 2572 	cjne	r7,#0x07,00449$
      0090C5 80 02            [24] 2573 	sjmp	00450$
      0090C7                       2574 00449$:
      0090C7 21 6F            [12] 2575 	ajmp	00147$
      0090C9                       2576 00450$:
      0090C9                       2577 00146$:
                                   2578 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0090C9 12 91 F5         [24] 2579 	lcall	_ak820_outline_0000
      0090CC 12 42 78         [24] 2580 	lcall	_eeprom_read_byte
      0090CF 12 92 77         [24] 2581 	lcall	_ak820_outline_0177
                                   2582 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      0090D2 70 03            [24] 2583 	jnz	00451$
      0090D4 02 8F CE         [24] 2584 	ljmp	00167$
      0090D7                       2585 00451$:
                                   2586 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0090D7 12 91 F5         [24] 2587 	lcall	_ak820_outline_0000
      0090DA 12 42 78         [24] 2588 	lcall	_eeprom_read_byte
      0090DD AF 82            [24] 2589 	mov	r7, dpl
      0090DF 90 0B 68         [24] 2590 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      0090E2 EF               [12] 2591 	mov	a,r7
      0090E3 F0               [24] 2592 	movx	@dptr,a
                                   2593 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      0090E4 EF               [12] 2594 	mov	a,r7
      0090E5 70 03            [24] 2595 	jnz	00452$
      0090E7 02 8F CE         [24] 2596 	ljmp	00167$
      0090EA                       2597 00452$:
                                   2598 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      0090EA 90 0B 67         [24] 2599 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      0090ED E0               [24] 2600 	movx	a,@dptr
      0090EE FF               [12] 2601 	mov	r7,a
      0090EF 90 0B 68         [24] 2602 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      0090F2 E0               [24] 2603 	movx	a,@dptr
      0090F3 FB               [12] 2604 	mov	r3,a
      0090F4 E4               [12] 2605 	clr	a
      0090F5 FC               [12] 2606 	mov	r4,a
      0090F6 FA               [12] 2607 	mov	r2,a
      0090F7 EF               [12] 2608 	mov	a,r7
      0090F8 42 04            [12] 2609 	orl	ar4,a
      0090FA EA               [12] 2610 	mov	a,r2
      0090FB 42 03            [12] 2611 	orl	ar3,a
                                   2612 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      0090FD 12 45 9C         [24] 2613 	lcall	_ak820_outline_0179
      009100 C0 06            [24] 2614 	push	ar6
      009102 C0 05            [24] 2615 	push	ar5
      009104 12 8F 1A         [24] 2616 	lcall	_decode_keycode
      009107 AC 82            [24] 2617 	mov	r4, dpl
      009109 AF 83            [24] 2618 	mov	r7, dph
      00910B D0 05            [24] 2619 	pop	ar5
      00910D D0 06            [24] 2620 	pop	ar6
                                   2621 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      00910F 90 0B 66         [24] 2622 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      009112 E0               [24] 2623 	movx	a,@dptr
      009113 FB               [12] 2624 	mov	r3,a
      009114 BB 05 03         [24] 2625 	cjne	r3,#0x05,00453$
      009117 D3               [12] 2626 	setb	c
      009118 80 01            [24] 2627 	sjmp	00454$
      00911A                       2628 00453$:
      00911A C3               [12] 2629 	clr	c
      00911B                       2630 00454$:
      00911B 92 23            [24] 2631 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      00911D 90 09 AA         [24] 2632 	mov	dptr,#_ak820_macro_primitive
      009120 B3               [12] 2633 	cpl	c
      009121 E4               [12] 2634 	clr	a
      009122 33               [12] 2635 	rlc	a
      009123 F0               [24] 2636 	movx	@dptr,a
                                   2637 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      009124 90 0B 66         [24] 2638 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      009127 E0               [24] 2639 	movx	a,@dptr
      009128 FB               [12] 2640 	mov	r3,a
      009129 BB 05 02         [24] 2641 	cjne	r3,#0x05,00455$
      00912C 80 0A            [24] 2642 	sjmp	00126$
      00912E                       2643 00455$:
      00912E BB 06 02         [24] 2644 	cjne	r3,#0x06,00456$
      009131 80 16            [24] 2645 	sjmp	00127$
      009133                       2646 00456$:
                                   2647 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      009133 BB 07 33         [24] 2648 	cjne	r3,#0x07,00129$
      009136 80 22            [24] 2649 	sjmp	00128$
      009138                       2650 00126$:
                                   2651 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      009138 8C 82            [24] 2652 	mov	dpl, r4
      00913A 8F 83            [24] 2653 	mov	dph, r7
      00913C C0 06            [24] 2654 	push	ar6
      00913E C0 05            [24] 2655 	push	ar5
      009140 12 B4 51         [24] 2656 	lcall	_vial_keycode_tap
      009143 D0 05            [24] 2657 	pop	ar5
      009145 D0 06            [24] 2658 	pop	ar6
                                   2659 ;	quantum/dynamic_keymap.c:795: break;
                                   2660 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      009147 80 20            [24] 2661 	sjmp	00129$
      009149                       2662 00127$:
                                   2663 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      009149 8C 82            [24] 2664 	mov	dpl, r4
      00914B 8F 83            [24] 2665 	mov	dph, r7
      00914D C0 06            [24] 2666 	push	ar6
      00914F C0 05            [24] 2667 	push	ar5
      009151 12 B3 86         [24] 2668 	lcall	_vial_keycode_down
      009154 D0 05            [24] 2669 	pop	ar5
      009156 D0 06            [24] 2670 	pop	ar6
                                   2671 ;	quantum/dynamic_keymap.c:798: break;
                                   2672 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      009158 80 0F            [24] 2673 	sjmp	00129$
      00915A                       2674 00128$:
                                   2675 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      00915A 8C 82            [24] 2676 	mov	dpl, r4
      00915C 8F 83            [24] 2677 	mov	dph, r7
      00915E C0 06            [24] 2678 	push	ar6
      009160 C0 05            [24] 2679 	push	ar5
      009162 12 B3 EC         [24] 2680 	lcall	_vial_keycode_up
      009165 D0 05            [24] 2681 	pop	ar5
      009167 D0 06            [24] 2682 	pop	ar6
                                   2683 ;	quantum/dynamic_keymap.c:802: }
      009169                       2684 00129$:
                                   2685 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      009169 12 92 5F         [24] 2686 	lcall	_ak820_outline_0161
      00916C 02 8F CE         [24] 2687 	ljmp	00167$
      00916F                       2688 00147$:
                                   2689 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      00916F 12 92 2D         [24] 2690 	lcall	_ak820_outline_0089
      009172 BF 04 02         [24] 2691 	cjne	r7,#0x04,00458$
      009175 80 03            [24] 2692 	sjmp	00459$
      009177                       2693 00458$:
      009177 02 8F CE         [24] 2694 	ljmp	00167$
      00917A                       2695 00459$:
                                   2696 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00917A 12 91 F5         [24] 2697 	lcall	_ak820_outline_0000
      00917D 12 42 78         [24] 2698 	lcall	_eeprom_read_byte
      009180 AF 82            [24] 2699 	mov	r7, dpl
                                   2700 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009182 90 0B 63         [24] 2701 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009185 12 3A 9A         [24] 2702 	lcall	_ak820_outline_0120
      009188 90 0B 63         [24] 2703 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      00918B 74 01            [12] 2704 	mov	a,#0x01
      00918D 2B               [12] 2705 	add	a, r3
      00918E F0               [24] 2706 	movx	@dptr,a
      00918F E4               [12] 2707 	clr	a
      009190 3C               [12] 2708 	addc	a, r4
      009191 A3               [24] 2709 	inc	dptr
      009192 F0               [24] 2710 	movx	@dptr,a
      009193 7A 00            [12] 2711 	mov	r2,#0x00
      009195 12 36 42         [24] 2712 	lcall	_ak820_outline_0121
      009198 8A F0            [24] 2713 	mov	b, r2
      00919A 12 42 78         [24] 2714 	lcall	_eeprom_read_byte
      00919D AC 82            [24] 2715 	mov	r4, dpl
                                   2716 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      00919F EF               [12] 2717 	mov	a,r7
      0091A0 60 4B            [24] 2718 	jz	00169$
      0091A2 EC               [12] 2719 	mov	a,r4
      0091A3 60 48            [24] 2720 	jz	00169$
                                   2721 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      0091A5 1F               [12] 2722 	dec	r7
      0091A6 1C               [12] 2723 	dec	r4
      0091A7 EC               [12] 2724 	mov	a,r4
      0091A8 75 F0 FF         [24] 2725 	mov	b,#0xff
      0091AB A4               [48] 2726 	mul	ab
      0091AC FC               [12] 2727 	mov	r4,a
      0091AD AB F0            [24] 2728 	mov	r3,b
      0091AF 7A 00            [12] 2729 	mov	r2,#0x00
      0091B1 EC               [12] 2730 	mov	a,r4
      0091B2 2F               [12] 2731 	add	a, r7
      0091B3 FC               [12] 2732 	mov	r4,a
      0091B4 EB               [12] 2733 	mov	a,r3
      0091B5 3A               [12] 2734 	addc	a, r2
      0091B6 FB               [12] 2735 	mov	r3,a
                                   2736 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      0091B7                       2737 00141$:
      0091B7 8C 02            [24] 2738 	mov	ar2,r4
      0091B9 8B 07            [24] 2739 	mov	ar7,r3
      0091BB 1C               [12] 2740 	dec	r4
      0091BC BC FF 01         [24] 2741 	cjne	r4,#0xff,00462$
      0091BF 1B               [12] 2742 	dec	r3
      0091C0                       2743 00462$:
      0091C0 EA               [12] 2744 	mov	a,r2
      0091C1 4F               [12] 2745 	orl	a,r7
      0091C2 70 03            [24] 2746 	jnz	00463$
      0091C4 02 8F CE         [24] 2747 	ljmp	00167$
      0091C7                       2748 00463$:
      0091C7 90 00 01         [24] 2749 	mov	dptr,#0x0001
      0091CA 12 5D 11         [24] 2750 	lcall	_mDelaymS
      0091CD 80 E8            [24] 2751 	sjmp	00141$
      0091CF                       2752 00164$:
                                   2753 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      0091CF 90 0B 65         [24] 2754 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      0091D2 E0               [24] 2755 	movx	a,@dptr
      0091D3 FF               [12] 2756 	mov	r7,a
      0091D4 BF 80 00         [24] 2757 	cjne	r7,#0x80,00464$
      0091D7                       2758 00464$:
      0091D7 50 14            [24] 2759 	jnc	00169$
                                   2760 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      0091D9 90 0B 65         [24] 2761 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      0091DC E0               [24] 2762 	movx	a,@dptr
      0091DD F5 82            [12] 2763 	mov	dpl,a
      0091DF C0 06            [24] 2764 	push	ar6
      0091E1 C0 05            [24] 2765 	push	ar5
      0091E3 12 A7 28         [24] 2766 	lcall	_send_char
      0091E6 D0 05            [24] 2767 	pop	ar5
      0091E8 D0 06            [24] 2768 	pop	ar6
                                   2769 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      0091EA 02 8F CE         [24] 2770 	ljmp	00167$
      0091ED                       2771 00169$:
                                   2772 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      0091ED 12 92 5F         [24] 2773 	lcall	_ak820_outline_0161
                                   2774 ;	quantum/dynamic_keymap.c:837: sending = false;
      0091F0 90 0B 62         [24] 2775 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      0091F3 F0               [24] 2776 	movx	@dptr,a
                                   2777 ;	quantum/dynamic_keymap.c:839: }
      0091F4 22               [24] 2778 	ret
                                   2779 	.area CSEG    (CODE)
                                   2780 	.area CONST   (CODE)
                                   2781 	.area XINIT   (CODE)
                                   2782 	.area CABS    (ABS,CODE)
                                   2783 
                                   2784 ; Experimental exact instruction outlining.
                                   2785 	.globl _ak820_outline_0000
                                   2786 	.globl _ak820_outline_0004
                                   2787 	.globl _ak820_outline_0009
                                   2788 	.globl _ak820_outline_0011
                                   2789 	.globl _ak820_outline_0016
                                   2790 	.globl _ak820_outline_0024
                                   2791 	.globl _ak820_outline_0030
                                   2792 	.globl _ak820_outline_0043
                                   2793 	.globl _ak820_outline_0050
                                   2794 	.globl _ak820_outline_0058
                                   2795 	.globl _ak820_outline_0059
                                   2796 	.globl _ak820_outline_0060
                                   2797 	.globl _ak820_outline_0070
                                   2798 	.globl _ak820_outline_0074
                                   2799 	.globl _ak820_outline_0076
                                   2800 	.globl _ak820_outline_0078
                                   2801 	.globl _ak820_outline_0087
                                   2802 	.globl _ak820_outline_0089
                                   2803 	.globl _ak820_outline_0095
                                   2804 	.globl _ak820_outline_0096
                                   2805 	.globl _ak820_outline_0099
                                   2806 	.globl _ak820_outline_0103
                                   2807 	.globl _ak820_outline_0104
                                   2808 	.globl _ak820_outline_0112
                                   2809 	.globl _ak820_outline_0116
                                   2810 	.globl _ak820_outline_0117
                                   2811 	.globl _ak820_outline_0119
                                   2812 	.globl _ak820_outline_0120
                                   2813 	.globl _ak820_outline_0121
                                   2814 	.globl _ak820_outline_0122
                                   2815 	.globl _ak820_outline_0126
                                   2816 	.globl _ak820_outline_0130
                                   2817 	.globl _ak820_outline_0131
                                   2818 	.globl _ak820_outline_0132
                                   2819 	.globl _ak820_outline_0133
                                   2820 	.globl _ak820_outline_0140
                                   2821 	.globl _ak820_outline_0141
                                   2822 	.globl _ak820_outline_0147
                                   2823 	.globl _ak820_outline_0149
                                   2824 	.globl _ak820_outline_0153
                                   2825 	.globl _ak820_outline_0154
                                   2826 	.globl _ak820_outline_0156
                                   2827 	.globl _ak820_outline_0161
                                   2828 	.globl _ak820_outline_0165
                                   2829 	.globl _ak820_outline_0173
                                   2830 	.globl _ak820_outline_0174
                                   2831 	.globl _ak820_outline_0177
                                   2832 	.globl _ak820_outline_0178
                                   2833 	.globl _ak820_outline_0179
                                   2834 	.globl _ak820_outline_0183
                                   2835 
                                   2836 	.area CSEG (CODE)
                                   2837 ; function ak820_outline_0000
      0091F5                       2838 _ak820_outline_0000:
      0091F5 90 0B 63         [24] 2839 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      0091F8 E0               [24] 2840 	movx	a,@dptr
      0091F9 FC               [12] 2841 	mov	r4,a
      0091FA A3               [24] 2842 	inc	dptr
      0091FB E0               [24] 2843 	movx	a,@dptr
      0091FC FF               [12] 2844 	mov	r7,a
      0091FD 90 0B 63         [24] 2845 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009200 74 01            [12] 2846 	mov	a,#0x01
      009202 2C               [12] 2847 	add	a,r4
      009203 F0               [24] 2848 	movx	@dptr,a
      009204 E4               [12] 2849 	clr	a
      009205 3F               [12] 2850 	addc	a,r7
      009206 A3               [24] 2851 	inc	dptr
      009207 F0               [24] 2852 	movx	@dptr,a
      009208 7B 00            [12] 2853 	mov	r3,#0x00
      00920A 8C 82            [24] 2854 	mov	dpl,r4
      00920C 8F 83            [24] 2855 	mov	dph,r7
      00920E 8B F0            [24] 2856 	mov	b,r3
      009210 22               [24] 2857 	ret
                                   2858 
                                   2859 	.area CSEG (CODE)
                                   2860 ; function ak820_outline_0024
      009211                       2861 _ak820_outline_0024:
      009211 2D               [12] 2862 	add	a,r5
      009212 F9               [12] 2863 	mov	r1,a
      009213 E4               [12] 2864 	clr	a
      009214 3E               [12] 2865 	addc	a,r6
      009215 FA               [12] 2866 	mov	r2,a
      009216 8F 03            [24] 2867 	mov	ar3,r7
      009218 89 82            [24] 2868 	mov	dpl,r1
      00921A 8A 83            [24] 2869 	mov	dph,r2
      00921C 8B F0            [24] 2870 	mov	b,r3
      00921E 22               [24] 2871 	ret
                                   2872 
                                   2873 	.area CSEG (CODE)
                                   2874 ; function ak820_outline_0078
      00921F                       2875 _ak820_outline_0078:
      00921F ED               [12] 2876 	mov	a,r5
      009220 75 F0 0A         [24] 2877 	mov	b,#0x0a
      009223 A4               [48] 2878 	mul	ab
      009224 24 58            [12] 2879 	add	a,#0x58
      009226 FC               [12] 2880 	mov	r4,a
      009227 74 06            [12] 2881 	mov	a,#0x06
      009229 35 F0            [12] 2882 	addc	a,b
      00922B FD               [12] 2883 	mov	r5,a
      00922C 22               [24] 2884 	ret
                                   2885 
                                   2886 	.area CSEG (CODE)
                                   2887 ; function ak820_outline_0089
      00922D                       2888 _ak820_outline_0089:
      00922D 90 0B 66         [24] 2889 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0001)
      009230 E0               [24] 2890 	movx	a,@dptr
      009231 FF               [12] 2891 	mov	r7,a
      009232 22               [24] 2892 	ret
                                   2893 
                                   2894 	.area CSEG (CODE)
                                   2895 ; function ak820_outline_0095
      009233                       2896 _ak820_outline_0095:
      009233 90 0A FC         [24] 2897 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      009236 EE               [12] 2898 	mov	a,r6
      009237 F0               [24] 2899 	movx	@dptr,a
      009238 90 0A FD         [24] 2900 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      00923B ED               [12] 2901 	mov	a,r5
      00923C F0               [24] 2902 	movx	@dptr,a
      00923D 8F 82            [24] 2903 	mov	dpl,r7
      00923F 22               [24] 2904 	ret
                                   2905 
                                   2906 	.area CSEG (CODE)
                                   2907 ; function ak820_outline_0112
      009240                       2908 _ak820_outline_0112:
      009240 AD 82            [24] 2909 	mov	r5,dpl
      009242 AE 83            [24] 2910 	mov	r6,dph
      009244 AF F0            [24] 2911 	mov	r7,b
      009246 22               [24] 2912 	ret
                                   2913 
                                   2914 	.area CSEG (CODE)
                                   2915 ; function ak820_outline_0126
      009247                       2916 _ak820_outline_0126:
      009247 28               [12] 2917 	add	a,r0
      009248 F5 82            [12] 2918 	mov	dpl,a
      00924A EF               [12] 2919 	mov	a,r7
      00924B 39               [12] 2920 	addc	a,r1
      00924C F5 83            [12] 2921 	mov	dph,a
      00924E 74 FF            [12] 2922 	mov	a,#0xff
      009250 F0               [24] 2923 	movx	@dptr,a
      009251 22               [24] 2924 	ret
                                   2925 
                                   2926 	.area CSEG (CODE)
                                   2927 ; function ak820_outline_0132
      009252                       2928 _ak820_outline_0132:
      009252 2D               [12] 2929 	add	a,r5
      009253 F9               [12] 2930 	mov	r1,a
      009254 E4               [12] 2931 	clr	a
      009255 3E               [12] 2932 	addc	a,r6
      009256 FA               [12] 2933 	mov	r2,a
      009257 22               [24] 2934 	ret
                                   2935 
                                   2936 	.area CSEG (CODE)
                                   2937 ; function ak820_outline_0149
      009258                       2938 _ak820_outline_0149:
      009258 90 0B 67         [24] 2939 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      00925B E0               [24] 2940 	movx	a,@dptr
      00925C F5 82            [12] 2941 	mov	dpl,a
      00925E 22               [24] 2942 	ret
                                   2943 
                                   2944 	.area CSEG (CODE)
                                   2945 ; function ak820_outline_0161
      00925F                       2946 _ak820_outline_0161:
      00925F 90 09 AA         [24] 2947 	mov	dptr,#_ak820_macro_primitive
      009262 E4               [12] 2948 	clr	a
      009263 F0               [24] 2949 	movx	@dptr,a
      009264 22               [24] 2950 	ret
                                   2951 
                                   2952 	.area CSEG (CODE)
                                   2953 ; function ak820_outline_0173
      009265                       2954 _ak820_outline_0173:
      009265 90 0B 0C         [24] 2955 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      009268 E4               [12] 2956 	clr	a
      009269 F0               [24] 2957 	movx	@dptr,a
      00926A 90 0B 0D         [24] 2958 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00926D 22               [24] 2959 	ret
                                   2960 
                                   2961 	.area CSEG (CODE)
                                   2962 ; function ak820_outline_0174
      00926E                       2963 _ak820_outline_0174:
      00926E 90 0B C2         [24] 2964 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      009271 E4               [12] 2965 	clr	a
      009272 F0               [24] 2966 	movx	@dptr,a
      009273 90 0B C3         [24] 2967 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      009276 22               [24] 2968 	ret
                                   2969 
                                   2970 	.area CSEG (CODE)
                                   2971 ; function ak820_outline_0177
      009277                       2972 _ak820_outline_0177:
      009277 AF 82            [24] 2973 	mov	r7,dpl
      009279 90 0B 67         [24] 2974 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      00927C EF               [12] 2975 	mov	a,r7
      00927D F0               [24] 2976 	movx	@dptr,a
      00927E EF               [12] 2977 	mov	a,r7
      00927F 22               [24] 2978 	ret
