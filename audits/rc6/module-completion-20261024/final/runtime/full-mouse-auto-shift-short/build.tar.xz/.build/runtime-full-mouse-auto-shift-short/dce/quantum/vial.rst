                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000042                        541 _vial_handle_cmd_sloc0_1_0:
      000042                        542 	.ds 2
      000044                        543 _vial_handle_cmd_sloc1_1_0:
      000044                        544 	.ds 2
      000046                        545 _vial_handle_cmd_sloc2_1_0:
      000046                        546 	.ds 2
      000048                        547 _vial_handle_cmd_sloc3_1_0:
      000048                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C54                        573 _vial_unlock_timer:
      000C54                        574 	.ds 4
      000C58                        575 _vial_unlock_holding:
      000C58                        576 	.ds 1
      000C59                        577 _vial_keycode_firewall_in_10000_610:
      000C59                        578 	.ds 2
      000C5B                        579 _vial_fill_packet_PARM_2:
      000C5B                        580 	.ds 1
      000C5C                        581 _vial_fill_packet_msg_10000_613:
      000C5C                        582 	.ds 2
      000C5E                        583 _vial_handle_cmd_PARM_2:
      000C5E                        584 	.ds 1
      000C5F                        585 _vial_handle_cmd_data_10000_618:
      000C5F                        586 	.ds 3
      000C62                        587 _vial_handle_cmd_entry_70000_646:
      000C62                        588 	.ds 10
      000C6C                        589 _vial_handle_cmd_entry_70000_647:
      000C6C                        590 	.ds 10
      000C76                        591 _g_vial_magic_keycode_override::
      000C76                        592 	.ds 2
      000C78                        593 _vial_keycode_down_keycode_10000_649:
      000C78                        594 	.ds 2
      000C7A                        595 _vial_keycode_down_dummy_event_30000_656:
      000C7A                        596 	.ds 6
      000C80                        597 _vial_keycode_up_keycode_10000_657:
      000C80                        598 	.ds 2
      000C82                        599 _vial_keycode_up_dummy_event_30000_664:
      000C82                        600 	.ds 6
      000C88                        601 _vial_keycode_tap_keycode_10000_665:
      000C88                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000E1F                        611 _vial_unlocked::
      000E1F                        612 	.ds 1
      000E20                        613 _vial_unlock_in_progress::
      000E20                        614 	.ds 1
      000E21                        615 _vial_unlock_counter:
      000E21                        616 	.ds 1
      000E22                        617 _vial_unlock_combo_rows:
      000E22                        618 	.ds 2
      000E24                        619 _vial_unlock_combo_cols:
      000E24                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00AEDE                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00AEDE 90 0E 20         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00AEE1 E0               [24]  667 	movx	a,@dptr
      00AEE2 70 01            [24]  668 	jnz	00131$
      00AEE4 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AEE5                        671 00131$:
      00AEE5 7F 00            [12]  672 	mov	r7,#0x00
      00AEE7                        673 00115$:
      00AEE7 BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00AEEA                        675 00184$:
      00AEEA 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00AEEC EF               [12]  678 	mov	a,r7
      00AEED 12 B4 A2         [24]  679 	lcall	_ak820_outline_0125
      00AEF0 FE               [12]  680 	mov	r6,a
      00AEF1 EF               [12]  681 	mov	a,r7
      00AEF2 12 B4 97         [24]  682 	lcall	_ak820_outline_0124
      00AEF5 90 07 81         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00AEF8 F0               [24]  684 	movx	@dptr,a
      00AEF9 8E 82            [24]  685 	mov	dpl, r6
      00AEFB C0 07            [24]  686 	push	ar7
      00AEFD 12 5D 83         [24]  687 	lcall	_matrix_is_on
      00AF00 E5 82            [12]  688 	mov	a, dpl
      00AF02 D0 07            [24]  689 	pop	ar7
      00AF04 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00AF06 90 0C 58         [24]  692 	mov	dptr,#_vial_unlock_holding
      00AF09 E4               [12]  693 	clr	a
      00AF0A F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AF0B 90 0E 21         [24]  696 	mov	dptr,#_vial_unlock_counter
      00AF0E 74 1E            [12]  697 	mov	a,#0x1e
      00AF10 F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00AF11 22               [24]  700 	ret
      00AF12                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AF12 0F               [12]  703 	inc	r7
      00AF13 80 D2            [24]  704 	sjmp	00115$
      00AF15                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00AF15 90 0C 58         [24]  707 	mov	dptr,#_vial_unlock_holding
      00AF18 E0               [24]  708 	movx	a,@dptr
      00AF19 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00AF1B 90 0C 58         [24]  711 	mov	dptr,#_vial_unlock_holding
      00AF1E 74 01            [12]  712 	mov	a,#0x01
      00AF20 F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00AF21 12 4A E0         [24]  715 	lcall	_timer_read32
      00AF24 12 51 1B         [24]  716 	lcall	_ak820_outline_0056
      00AF27 90 0C 54         [24]  717 	mov	dptr,#_vial_unlock_timer
      00AF2A 12 93 F5         [24]  718 	lcall	_ak820_outline_0007
      00AF2D                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00AF2D 90 0C 54         [24]  721 	mov	dptr,#_vial_unlock_timer
      00AF30 12 51 0A         [24]  722 	lcall	_ak820_outline_0053
      00AF33 12 4B 39         [24]  723 	lcall	_timer_elapsed32
      00AF36 12 51 1B         [24]  724 	lcall	_ak820_outline_0056
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00AF39 7B 1E            [12]  726 	mov	r3,#0x1e
      00AF3B                        727 00109$:
      00AF3B EB               [12]  728 	mov	a,r3
      00AF3C 60 22            [24]  729 	jz	00111$
      00AF3E C3               [12]  730 	clr	c
      00AF3F EC               [12]  731 	mov	a,r4
      00AF40 94 64            [12]  732 	subb	a,#0x64
      00AF42 ED               [12]  733 	mov	a,r5
      00AF43 94 00            [12]  734 	subb	a,#0x00
      00AF45 EE               [12]  735 	mov	a,r6
      00AF46 94 00            [12]  736 	subb	a,#0x00
      00AF48 EF               [12]  737 	mov	a,r7
      00AF49 94 00            [12]  738 	subb	a,#0x00
      00AF4B 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00AF4D EC               [12]  741 	mov	a,r4
      00AF4E 24 9C            [12]  742 	add	a,#0x9c
      00AF50 FC               [12]  743 	mov	r4,a
      00AF51 ED               [12]  744 	mov	a,r5
      00AF52 34 FF            [12]  745 	addc	a,#0xff
      00AF54 FD               [12]  746 	mov	r5,a
      00AF55 EE               [12]  747 	mov	a,r6
      00AF56 34 FF            [12]  748 	addc	a,#0xff
      00AF58 FE               [12]  749 	mov	r6,a
      00AF59 EF               [12]  750 	mov	a,r7
      00AF5A 34 FF            [12]  751 	addc	a,#0xff
      00AF5C FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00AF5D 1B               [12]  754 	dec	r3
      00AF5E 80 DB            [24]  755 	sjmp	00109$
      00AF60                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00AF60 90 0E 21         [24]  758 	mov	dptr,#_vial_unlock_counter
      00AF63 EB               [12]  759 	mov	a,r3
      00AF64 F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00AF65 EB               [12]  762 	mov	a,r3
      00AF66 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00AF68 90 0E 20         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00AF6B E4               [12]  766 	clr	a
      00AF6C F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00AF6D 90 0E 1F         [24]  769 	mov	dptr,#_vial_unlocked
      00AF70 04               [12]  770 	inc	a
      00AF71 F0               [24]  771 	movx	@dptr,a
      00AF72                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00AF72 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:117: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00AF73                        782 _vial_init:
                                    783 ;	quantum/vial.c:125: reload_combo();
                                    784 ;	quantum/vial.c:130: }
      00AF73 02 37 7D         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_610'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00AF76                        795 _vial_keycode_firewall:
      00AF76 12 3A 84         [24]  796 	lcall	_ak820_outline_0103
      00AF79 90 0C 59         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_610
      00AF7C 12 3A 89         [24]  798 	lcall	_ak820_outline_0104
                                    799 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00AF7F 90 0C 59         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_610
      00AF82 12 3A 0C         [24]  801 	lcall	_ak820_outline_0009
      00AF85 BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00AF88 BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00AF8B 90 0E 1F         [24]  804 	mov	dptr,#_vial_unlocked
      00AF8E E0               [24]  805 	movx	a,@dptr
      00AF8F 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:134: return 0;
      00AF91 90 00 00         [24]  808 	mov	dptr,#0x0000
      00AF94 22               [24]  809 	ret
      00AF95                        810 00102$:
                                    811 ;	quantum/vial.c:135: return in;
      00AF95 12 45 60         [24]  812 	lcall	_ak820_outline_0116
                                    813 ;	quantum/vial.c:136: }
      00AF98 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_613'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_615'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00AF99                        826 _vial_fill_packet:
      00AF99 12 3A 84         [24]  827 	lcall	_ak820_outline_0103
      00AF9C 90 0C 5C         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_613
      00AF9F 12 3A 89         [24]  829 	lcall	_ak820_outline_0104
                                    830 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00AFA2 90 0C 5C         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_613
      00AFA5 12 3A 41         [24]  832 	lcall	_ak820_outline_0050
      00AFA8 90 0C 5B         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00AFAB E0               [24]  834 	movx	a,@dptr
      00AFAC FD               [12]  835 	mov	r5,a
      00AFAD 7C 00            [12]  836 	mov	r4,#0x00
      00AFAF                        837 00103$:
      00AFAF BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00AFB2                        839 00122$:
      00AFB2 50 09            [24]  840 	jnc	00105$
      00AFB4 EC               [12]  841 	mov	a,r4
      00AFB5 12 3A 31         [24]  842 	lcall	_ak820_outline_0030
      00AFB8 ED               [12]  843 	mov	a,r5
      00AFB9 F0               [24]  844 	movx	@dptr,a
      00AFBA 0C               [12]  845 	inc	r4
      00AFBB 80 F2            [24]  846 	sjmp	00103$
      00AFBD                        847 00105$:
                                    848 ;	quantum/vial.c:141: }
      00AFBD 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00AFBE                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:174: repeat_key_cancel();
      00AFBE 12 A3 FA         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:176: clear_keyboard();
                                    861 ;	quantum/vial.c:177: }
      00AFC1 02 7A D2         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_618'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_619'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_624'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_625'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_628'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_630'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_630'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_630'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_631'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_632'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_632'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_632'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_635'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_647'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_647'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00AFC4                        893 _vial_handle_cmd:
      00AFC4 12 45 17         [24]  894 	lcall	_ak820_outline_0036
      00AFC7 90 0C 5F         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_618
      00AFCA 12 3A 20         [24]  896 	lcall	_ak820_outline_0015
                                    897 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00AFCD 90 0C 5F         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_618
      00AFD0 12 3A 41         [24]  899 	lcall	_ak820_outline_0050
                                    900 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00AFD3 90 0C 5E         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AFD6 E0               [24]  902 	movx	a,@dptr
      00AFD7 FD               [12]  903 	mov	r5,a
      00AFD8 BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00AFDB 80 01            [24]  905 	sjmp	00102$
      00AFDD                        906 00258$:
                                    907 ;	quantum/vial.c:190: return;
      00AFDD 22               [24]  908 	ret
      00AFDE                        909 00102$:
                                    910 ;	quantum/vial.c:193: switch (msg[1]) {
      00AFDE 74 01            [12]  911 	mov	a,#0x01
      00AFE0 12 4A 1F         [24]  912 	lcall	_ak820_outline_0011
      00AFE3 FB               [12]  913 	mov  r3,a
      00AFE4 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00AFE6 50 01            [24]  915 	jnc	00259$
      00AFE8 22               [24]  916 	ret
      00AFE9                        917 00259$:
                                    918 ;	free result
      00AFE9 EB               [12]  919 	mov	a,r3
      00AFEA 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00AFEC 83               [24]  921 	movc	a,@a+pc
      00AFED F5 82            [12]  922 	mov	dpl,a
      00AFEF EB               [12]  923 	mov	a,r3
      00AFF0 24 12            [12]  924 	add	a,#(00261$-3-.)
      00AFF2 83               [24]  925 	movc	a,@a+pc
      00AFF3 F5 83            [12]  926 	mov	dph,a
      00AFF5 E4               [12]  927 	clr	a
      00AFF6 73               [24]  928 	jmp	@a+dptr
      00AFF7                        929 00260$:
      00AFF7 13                     930 	.db	00103$
      00AFF8 5B                     931 	.db	00105$
      00AFF9 70                     932 	.db	00106$
      00AFFA FC                     933 	.db	00112$
      00AFFB 82                     934 	.db	00113$
      00AFFC CD                     935 	.db	00114$
      00AFFD 3C                     936 	.db	00116$
      00AFFE 57                     937 	.db	00119$
      00AFFF 77                     938 	.db	00120$
      00B000 85                     939 	.db	00121$
      00B001 85                     940 	.db	00139$
      00B002 85                     941 	.db	00139$
      00B003 85                     942 	.db	00139$
      00B004 90                     943 	.db	00122$
      00B005                        944 00261$:
      00B005 B0                     945 	.db	00103$>>8
      00B006 B0                     946 	.db	00105$>>8
      00B007 B0                     947 	.db	00106$>>8
      00B008 B0                     948 	.db	00112$>>8
      00B009 B1                     949 	.db	00113$>>8
      00B00A B1                     950 	.db	00114$>>8
      00B00B B2                     951 	.db	00116$>>8
      00B00C B2                     952 	.db	00119$>>8
      00B00D B2                     953 	.db	00120$>>8
      00B00E B2                     954 	.db	00121$>>8
      00B00F B3                     955 	.db	00139$>>8
      00B010 B3                     956 	.db	00139$>>8
      00B011 B3                     957 	.db	00139$>>8
      00B012 B2                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B013                        960 00103$:
                                    961 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B013 90 0C 5B         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00B016 E4               [12]  963 	clr	a
      00B017 12 45 3B         [24]  964 	lcall	_ak820_outline_0060
      00B01A C0 07            [24]  965 	push	ar7
      00B01C C0 06            [24]  966 	push	ar6
      00B01E 12 AF 99         [24]  967 	lcall	_vial_fill_packet
      00B021 D0 06            [24]  968 	pop	ar6
      00B023 D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B025 12 45 60         [24]  971 	lcall	_ak820_outline_0116
      00B028 74 06            [12]  972 	mov	a,#0x06
      00B02A 12 45 3B         [24]  973 	lcall	_ak820_outline_0060
                                    974 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B02D A3               [24]  975 	inc	dptr
      00B02E E4               [12]  976 	clr	a
      00B02F 12 45 0F         [24]  977 	lcall	_ak820_outline_0029
                                    978 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B032 12 45 0F         [24]  979 	lcall	_ak820_outline_0029
                                    980 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B035 A3               [24]  981 	inc	dptr
      00B036 F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B037 FB               [12]  984 	mov	r3,a
      00B038                        985 00131$:
      00B038 BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00B03B                        987 00262$:
      00B03B 50 15            [24]  988 	jnc	00104$
      00B03D 8B 02            [24]  989 	mov	ar2,r3
      00B03F 74 04            [12]  990 	mov	a,#0x04
      00B041 2A               [12]  991 	add	a, r2
      00B042 2E               [12]  992 	add	a, r6
      00B043 F9               [12]  993 	mov	r1,a
      00B044 E4               [12]  994 	clr	a
      00B045 3F               [12]  995 	addc	a,r7
      00B046 FA               [12]  996 	mov	r2,a
      00B047 EB               [12]  997 	mov	a,r3
      00B048 90 C1 54         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_623
      00B04B 93               [24]  999 	movc	a,@a+dptr
      00B04C 12 70 7A         [24] 1000 	lcall	_ak820_outline_0135
      00B04F 0B               [12] 1001 	inc	r3
      00B050 80 E6            [24] 1002 	sjmp	00131$
      00B052                       1003 00104$:
                                   1004 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B052 74 0C            [12] 1005 	mov	a,#0x0c
      00B054 12 3A 31         [24] 1006 	lcall	_ak820_outline_0030
      00B057 74 01            [12] 1007 	mov	a,#0x01
      00B059 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:207: break;
      00B05A 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:210: case vial_get_size: {
      00B05B                       1012 00105$:
                                   1013 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B05B 12 45 60         [24] 1014 	lcall	_ak820_outline_0116
      00B05E 74 7C            [12] 1015 	mov	a,#0x7c
      00B060 F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B061 12 3A 95         [24] 1018 	lcall	_ak820_outline_0117
      00B064 74 01            [12] 1019 	mov	a,#0x01
      00B066 12 45 0F         [24] 1020 	lcall	_ak820_outline_0029
                                   1021 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B069 E4               [12] 1022 	clr	a
      00B06A 12 45 0F         [24] 1023 	lcall	_ak820_outline_0029
                                   1024 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B06D A3               [24] 1025 	inc	dptr
      00B06E F0               [24] 1026 	movx	@dptr,a
                                   1027 ;	quantum/vial.c:216: break;
      00B06F 22               [24] 1028 	ret
                                   1029 ;	quantum/vial.c:219: case vial_get_def: {
      00B070                       1030 00106$:
                                   1031 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B070 12 AE A2         [24] 1032 	lcall	_ak820_outline_0020
      00B073 E0               [24] 1033 	movx	a,@dptr
      00B074 FB               [12] 1034 	mov	r3,a
      00B075 12 45 05         [24] 1035 	lcall	_ak820_outline_0010
      00B078 E0               [24] 1036 	movx	a,@dptr
      00B079 4B               [12] 1037 	orl	a,r3
      00B07A 60 01            [24] 1038 	jz	00108$
      00B07C 22               [24] 1039 	ret
      00B07D                       1040 00108$:
                                   1041 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B07D 12 3A 39         [24] 1042 	lcall	_ak820_outline_0033
      00B080 FB               [12] 1043 	mov	r3,a
      00B081 7A 00            [12] 1044 	mov	r2,#0x00
      00B083 12 AE 99         [24] 1045 	lcall	_ak820_outline_0014
      00B086 F9               [12] 1046 	mov	r1,a
      00B087 E4               [12] 1047 	clr	a
      00B088 42 03            [12] 1048 	orl	ar3,a
      00B08A E9               [12] 1049 	mov	a,r1
      00B08B 42 02            [12] 1050 	orl	ar2,a
                                   1051 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B08D C3               [12] 1052 	clr	c
      00B08E EB               [12] 1053 	mov	a,r3
      00B08F 94 0C            [12] 1054 	subb	a,#0x0c
      00B091 EA               [12] 1055 	mov	a,r2
      00B092 94 00            [12] 1056 	subb	a,#0x00
      00B094 40 01            [24] 1057 	jc	00110$
      00B096 22               [24] 1058 	ret
      00B097                       1059 00110$:
                                   1060 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B097 EA               [12] 1061 	mov	a,r2
      00B098 C4               [12] 1062 	swap	a
      00B099 23               [12] 1063 	rl	a
      00B09A 54 E0            [12] 1064 	anl	a,#0xe0
      00B09C CB               [12] 1065 	xch	a,r3
      00B09D C4               [12] 1066 	swap	a
      00B09E 23               [12] 1067 	rl	a
      00B09F CB               [12] 1068 	xch	a,r3
      00B0A0 6B               [12] 1069 	xrl	a,r3
      00B0A1 CB               [12] 1070 	xch	a,r3
      00B0A2 54 E0            [12] 1071 	anl	a,#0xe0
      00B0A4 CB               [12] 1072 	xch	a,r3
      00B0A5 6B               [12] 1073 	xrl	a,r3
      00B0A6 FA               [12] 1074 	mov	r2,a
      00B0A7 8B 42            [24] 1075 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B0A9 8A 43            [24] 1076 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1077 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B0AB 74 7C            [12] 1078 	mov	a,#0x7c
      00B0AD C3               [12] 1079 	clr	c
      00B0AE 95 42            [12] 1080 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B0B0 F8               [12] 1081 	mov	r0,a
      00B0B1 74 01            [12] 1082 	mov	a,#0x01
      00B0B3 95 43            [12] 1083 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B0B5 F9               [12] 1084 	mov	r1,a
                                   1085 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B0B6 C3               [12] 1086 	clr	c
      00B0B7 E8               [12] 1087 	mov	a,r0
      00B0B8 94 20            [12] 1088 	subb	a,#0x20
      00B0BA E9               [12] 1089 	mov	a,r1
      00B0BB 94 00            [12] 1090 	subb	a,#0x00
      00B0BD 40 02            [24] 1091 	jc	00142$
      00B0BF 78 20            [12] 1092 	mov	r0,#0x20
      00B0C1                       1093 00142$:
                                   1094 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B0C1 79 00            [12] 1095 	mov	r1,#0x00
      00B0C3                       1096 00134$:
      00B0C3 C3               [12] 1097 	clr	c
      00B0C4 E9               [12] 1098 	mov	a,r1
      00B0C5 98               [12] 1099 	subb	a,r0
      00B0C6 40 01            [24] 1100 	jc	00267$
      00B0C8 22               [24] 1101 	ret
      00B0C9                       1102 00267$:
      00B0C9 C0 00            [24] 1103 	push	ar0
      00B0CB E9               [12] 1104 	mov	a,r1
      00B0CC 2E               [12] 1105 	add	a, r6
      00B0CD F5 44            [12] 1106 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B0CF E4               [12] 1107 	clr	a
      00B0D0 3F               [12] 1108 	addc	a, r7
      00B0D1 F5 45            [12] 1109 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B0D3 89 46            [24] 1110 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B0D5 75 47 00         [24] 1111 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B0D8 A8 42            [24] 1112 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B0DA AB 43            [24] 1113 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B0DC E5 46            [12] 1114 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B0DE 28               [12] 1115 	add	a, r0
      00B0DF F8               [12] 1116 	mov	r0,a
      00B0E0 E5 47            [12] 1117 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B0E2 3B               [12] 1118 	addc	a, r3
      00B0E3 FB               [12] 1119 	mov	r3,a
      00B0E4 E8               [12] 1120 	mov	a,r0
      00B0E5 24 D8            [12] 1121 	add	a, #_keyboard_definition
      00B0E7 F5 82            [12] 1122 	mov	dpl,a
      00B0E9 EB               [12] 1123 	mov	a,r3
      00B0EA 34 BF            [12] 1124 	addc	a, #(_keyboard_definition >> 8)
      00B0EC F5 83            [12] 1125 	mov	dph,a
      00B0EE E4               [12] 1126 	clr	a
      00B0EF 93               [24] 1127 	movc	a,@a+dptr
      00B0F0 85 44 82         [24] 1128 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B0F3 85 45 83         [24] 1129 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B0F6 F0               [24] 1130 	movx	@dptr,a
      00B0F7 09               [12] 1131 	inc	r1
      00B0F8 D0 00            [24] 1132 	pop	ar0
                                   1133 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B0FA 80 C7            [24] 1134 	sjmp	00134$
      00B0FC                       1135 00112$:
                                   1136 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B0FC 74 02            [12] 1137 	mov	a,#0x02
      00B0FE 12 4A 5E         [24] 1138 	lcall	_ak820_outline_0045
      00B101 F5 46            [12] 1139 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1140 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B103 74 03            [12] 1141 	mov	a,#0x03
      00B105 2E               [12] 1142 	add	a, r6
      00B106 F5 44            [12] 1143 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B108 E4               [12] 1144 	clr	a
      00B109 3F               [12] 1145 	addc	a, r7
      00B10A F5 45            [12] 1146 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B10C 85 44 82         [24] 1147 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B10F 85 45 83         [24] 1148 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B112 E0               [24] 1149 	movx	a,@dptr
                                   1150 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B113 F5 42            [12] 1151 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B115 90 0B 09         [24] 1152 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B118 F0               [24] 1153 	movx	@dptr,a
      00B119 90 0B 0A         [24] 1154 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B11C E4               [12] 1155 	clr	a
      00B11D F0               [24] 1156 	movx	@dptr,a
      00B11E 85 46 82         [24] 1157 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B121 C0 07            [24] 1158 	push	ar7
      00B123 C0 06            [24] 1159 	push	ar6
      00B125 C0 05            [24] 1160 	push	ar5
      00B127 C0 04            [24] 1161 	push	ar4
      00B129 C0 03            [24] 1162 	push	ar3
      00B12B C0 02            [24] 1163 	push	ar2
      00B12D 12 88 8F         [24] 1164 	lcall	_dynamic_keymap_get_encoder
      00B130 85 82 48         [24] 1165 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B133 85 83 49         [24] 1166 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B136 D0 02            [24] 1167 	pop	ar2
      00B138 D0 03            [24] 1168 	pop	ar3
      00B13A D0 04            [24] 1169 	pop	ar4
      00B13C D0 05            [24] 1170 	pop	ar5
      00B13E D0 06            [24] 1171 	pop	ar6
      00B140 D0 07            [24] 1172 	pop	ar7
                                   1173 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B142 A9 49            [24] 1174 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B144 12 45 60         [24] 1175 	lcall	_ak820_outline_0116
      00B147 E9               [12] 1176 	mov	a,r1
      00B148 F0               [24] 1177 	movx	@dptr,a
                                   1178 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B149 A8 48            [24] 1179 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B14B 12 3A 95         [24] 1180 	lcall	_ak820_outline_0117
      00B14E E8               [12] 1181 	mov	a,r0
      00B14F F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B150 90 0B 09         [24] 1184 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B153 E5 42            [12] 1185 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B155 F0               [24] 1186 	movx	@dptr,a
      00B156 90 0B 0A         [24] 1187 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B159 74 01            [12] 1188 	mov	a,#0x01
      00B15B F0               [24] 1189 	movx	@dptr,a
      00B15C 85 46 82         [24] 1190 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B15F C0 03            [24] 1191 	push	ar3
      00B161 C0 02            [24] 1192 	push	ar2
      00B163 12 88 8F         [24] 1193 	lcall	_dynamic_keymap_get_encoder
      00B166 85 82 48         [24] 1194 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B169 85 83 49         [24] 1195 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B16C D0 02            [24] 1196 	pop	ar2
      00B16E D0 03            [24] 1197 	pop	ar3
                                   1198 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B170 A9 49            [24] 1199 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B172 12 45 7C         [24] 1200 	lcall	_ak820_outline_0141
      00B175 E9               [12] 1201 	mov	a,r1
      00B176 F0               [24] 1202 	movx	@dptr,a
                                   1203 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B177 A8 48            [24] 1204 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B179 85 44 82         [24] 1205 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B17C 85 45 83         [24] 1206 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B17F E8               [12] 1207 	mov	a,r0
      00B180 F0               [24] 1208 	movx	@dptr,a
                                   1209 ;	quantum/vial.c:255: break;
      00B181 22               [24] 1210 	ret
                                   1211 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B182                       1212 00113$:
                                   1213 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B182 12 3A 39         [24] 1214 	lcall	_ak820_outline_0033
      00B185 F5 44            [12] 1215 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B187 12 AE 99         [24] 1216 	lcall	_ak820_outline_0014
      00B18A F5 46            [12] 1217 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B18C 12 AE A2         [24] 1218 	lcall	_ak820_outline_0020
      00B18F E0               [24] 1219 	movx	a,@dptr
                                   1220 ;	assignBit
      00B190 24 FF            [12] 1221 	add	a,#0xff
      00B192 E4               [12] 1222 	clr	a
      00B193 33               [12] 1223 	rlc	a
      00B194 F5 48            [12] 1224 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B196 12 45 05         [24] 1225 	lcall	_ak820_outline_0010
      00B199 E0               [24] 1226 	movx	a,@dptr
      00B19A F9               [12] 1227 	mov	r1,a
      00B19B 78 00            [12] 1228 	mov	r0,#0x00
      00B19D 74 06            [12] 1229 	mov	a,#0x06
      00B19F 12 3A 28         [24] 1230 	lcall	_ak820_outline_0016
      00B1A2 7B 00            [12] 1231 	mov	r3,#0x00
      00B1A4 42 00            [12] 1232 	orl	ar0,a
      00B1A6 EB               [12] 1233 	mov	a,r3
      00B1A7 42 01            [12] 1234 	orl	ar1,a
      00B1A9 12 3A B0         [24] 1235 	lcall	_ak820_outline_0154
      00B1AC 12 AF 76         [24] 1236 	lcall	_vial_keycode_firewall
      00B1AF AA 82            [24] 1237 	mov	r2, dpl
      00B1B1 AB 83            [24] 1238 	mov	r3, dph
      00B1B3 90 0B 0C         [24] 1239 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B1B6 E5 46            [12] 1240 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B1B8 F0               [24] 1241 	movx	@dptr,a
      00B1B9 90 0B 0D         [24] 1242 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B1BC E5 48            [12] 1243 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B1BE F0               [24] 1244 	movx	@dptr,a
      00B1BF 90 0B 0E         [24] 1245 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B1C2 EA               [12] 1246 	mov	a,r2
      00B1C3 F0               [24] 1247 	movx	@dptr,a
      00B1C4 EB               [12] 1248 	mov	a,r3
      00B1C5 A3               [24] 1249 	inc	dptr
      00B1C6 F0               [24] 1250 	movx	@dptr,a
      00B1C7 85 44 82         [24] 1251 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1252 ;	quantum/vial.c:259: break;
      00B1CA 02 88 F5         [24] 1253 	ljmp	_dynamic_keymap_set_encoder
                                   1254 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B1CD                       1255 00114$:
                                   1256 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B1CD 90 0C 5B         [24] 1257 	mov	dptr,#_vial_fill_packet_PARM_2
      00B1D0 74 FF            [12] 1258 	mov	a,#0xff
      00B1D2 12 45 3B         [24] 1259 	lcall	_ak820_outline_0060
      00B1D5 C0 07            [24] 1260 	push	ar7
      00B1D7 C0 06            [24] 1261 	push	ar6
      00B1D9 12 AF 99         [24] 1262 	lcall	_vial_fill_packet
      00B1DC D0 06            [24] 1263 	pop	ar6
      00B1DE D0 07            [24] 1264 	pop	ar7
                                   1265 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B1E0 90 0E 1F         [24] 1266 	mov	dptr,#_vial_unlocked
      00B1E3 E0               [24] 1267 	movx	a,@dptr
      00B1E4 12 45 60         [24] 1268 	lcall	_ak820_outline_0116
      00B1E7 F0               [24] 1269 	movx	@dptr,a
                                   1270 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B1E8 74 01            [12] 1271 	mov	a,#0x01
      00B1EA 2E               [12] 1272 	add	a, r6
      00B1EB FA               [12] 1273 	mov	r2,a
      00B1EC E4               [12] 1274 	clr	a
      00B1ED 3F               [12] 1275 	addc	a, r7
      00B1EE FB               [12] 1276 	mov	r3,a
      00B1EF 90 0E 20         [24] 1277 	mov	dptr,#_vial_unlock_in_progress
      00B1F2 E0               [24] 1278 	movx	a,@dptr
      00B1F3 12 45 7C         [24] 1279 	lcall	_ak820_outline_0141
      00B1F6 F0               [24] 1280 	movx	@dptr,a
                                   1281 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B1F7 7B 00            [12] 1282 	mov	r3,#0x00
      00B1F9                       1283 00137$:
      00B1F9 BB 02 00         [24] 1284 	cjne	r3,#0x02,00268$
      00B1FC                       1285 00268$:
      00B1FC 40 01            [24] 1286 	jc	00269$
      00B1FE 22               [24] 1287 	ret
      00B1FF                       1288 00269$:
                                   1289 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B1FF 8B 01            [24] 1290 	mov	ar1,r3
      00B201 7A 00            [12] 1291 	mov	r2,#0x00
      00B203 E9               [12] 1292 	mov	a,r1
      00B204 29               [12] 1293 	add	a,r1
      00B205 F5 48            [12] 1294 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B207 EA               [12] 1295 	mov	a,r2
      00B208 33               [12] 1296 	rlc	a
      00B209 F5 49            [12] 1297 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B20B 74 02            [12] 1298 	mov	a,#0x02
      00B20D 25 48            [12] 1299 	add	a, _vial_handle_cmd_sloc3_1_0
      00B20F F8               [12] 1300 	mov	r0,a
      00B210 E4               [12] 1301 	clr	a
      00B211 35 49            [12] 1302 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B213 FA               [12] 1303 	mov	r2,a
      00B214 E8               [12] 1304 	mov	a,r0
      00B215 2E               [12] 1305 	add	a, r6
      00B216 F8               [12] 1306 	mov	r0,a
      00B217 EA               [12] 1307 	mov	a,r2
      00B218 3F               [12] 1308 	addc	a, r7
      00B219 FA               [12] 1309 	mov	r2,a
      00B21A EB               [12] 1310 	mov	a,r3
      00B21B 12 B4 A2         [24] 1311 	lcall	_ak820_outline_0125
      00B21E 88 82            [24] 1312 	mov	dpl,r0
      00B220 8A 83            [24] 1313 	mov	dph,r2
      00B222 F0               [24] 1314 	movx	@dptr,a
                                   1315 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B223 74 03            [12] 1316 	mov	a,#0x03
      00B225 25 48            [12] 1317 	add	a, _vial_handle_cmd_sloc3_1_0
      00B227 F9               [12] 1318 	mov	r1,a
      00B228 E4               [12] 1319 	clr	a
      00B229 35 49            [12] 1320 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B22B FA               [12] 1321 	mov	r2,a
      00B22C E9               [12] 1322 	mov	a,r1
      00B22D 2E               [12] 1323 	add	a, r6
      00B22E F9               [12] 1324 	mov	r1,a
      00B22F EA               [12] 1325 	mov	a,r2
      00B230 3F               [12] 1326 	addc	a, r7
      00B231 FA               [12] 1327 	mov	r2,a
      00B232 EB               [12] 1328 	mov	a,r3
      00B233 12 B4 97         [24] 1329 	lcall	_ak820_outline_0124
      00B236 12 70 7A         [24] 1330 	lcall	_ak820_outline_0135
                                   1331 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B239 0B               [12] 1332 	inc	r3
                                   1333 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B23A 80 BD            [24] 1334 	sjmp	00137$
      00B23C                       1335 00116$:
                                   1336 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B23C 90 0E 20         [24] 1337 	mov	dptr,#_vial_unlock_in_progress
      00B23F E0               [24] 1338 	movx	a,@dptr
      00B240 70 03            [24] 1339 	jnz	00118$
      00B242 12 AF BE         [24] 1340 	lcall	_vial_release_held_state
      00B245                       1341 00118$:
                                   1342 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B245 90 0E 20         [24] 1343 	mov	dptr,#_vial_unlock_in_progress
      00B248 74 01            [12] 1344 	mov	a,#0x01
      00B24A F0               [24] 1345 	movx	@dptr,a
                                   1346 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B24B 90 0E 21         [24] 1347 	mov	dptr,#_vial_unlock_counter
      00B24E 74 1E            [12] 1348 	mov	a,#0x1e
      00B250 F0               [24] 1349 	movx	@dptr,a
                                   1350 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B251 90 0C 58         [24] 1351 	mov	dptr,#_vial_unlock_holding
      00B254 E4               [12] 1352 	clr	a
      00B255 F0               [24] 1353 	movx	@dptr,a
                                   1354 ;	quantum/vial.c:287: break;
      00B256 22               [24] 1355 	ret
                                   1356 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B257                       1357 00119$:
                                   1358 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B257 90 0E 1F         [24] 1359 	mov	dptr,#_vial_unlocked
      00B25A E0               [24] 1360 	movx	a,@dptr
      00B25B 12 45 60         [24] 1361 	lcall	_ak820_outline_0116
      00B25E F0               [24] 1362 	movx	@dptr,a
                                   1363 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B25F 90 0E 20         [24] 1364 	mov	dptr,#_vial_unlock_in_progress
      00B262 E0               [24] 1365 	movx	a,@dptr
      00B263 12 3A 95         [24] 1366 	lcall	_ak820_outline_0117
      00B266 F0               [24] 1367 	movx	@dptr,a
                                   1368 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B267 74 02            [12] 1369 	mov	a,#0x02
      00B269 2E               [12] 1370 	add	a, r6
      00B26A FA               [12] 1371 	mov	r2,a
      00B26B E4               [12] 1372 	clr	a
      00B26C 3F               [12] 1373 	addc	a, r7
      00B26D FB               [12] 1374 	mov	r3,a
      00B26E 90 0E 21         [24] 1375 	mov	dptr,#_vial_unlock_counter
      00B271 E0               [24] 1376 	movx	a,@dptr
      00B272 12 45 7C         [24] 1377 	lcall	_ak820_outline_0141
      00B275 F0               [24] 1378 	movx	@dptr,a
                                   1379 ;	quantum/vial.c:293: break;
      00B276 22               [24] 1380 	ret
                                   1381 ;	quantum/vial.c:295: case vial_lock: {
      00B277                       1382 00120$:
                                   1383 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B277 90 0E 1F         [24] 1384 	mov	dptr,#_vial_unlocked
      00B27A E4               [12] 1385 	clr	a
      00B27B F0               [24] 1386 	movx	@dptr,a
                                   1387 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B27C 90 0E 20         [24] 1388 	mov	dptr,#_vial_unlock_in_progress
      00B27F F0               [24] 1389 	movx	@dptr,a
                                   1390 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B280 90 0C 58         [24] 1391 	mov	dptr,#_vial_unlock_holding
      00B283 F0               [24] 1392 	movx	@dptr,a
                                   1393 ;	quantum/vial.c:301: break;
      00B284 22               [24] 1394 	ret
                                   1395 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B285                       1396 00121$:
                                   1397 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B285 90 0C 5B         [24] 1398 	mov	dptr,#_vial_fill_packet_PARM_2
      00B288 74 FF            [12] 1399 	mov	a,#0xff
      00B28A 12 45 3B         [24] 1400 	lcall	_ak820_outline_0060
                                   1401 ;	quantum/vial.c:314: break;
      00B28D 02 AF 99         [24] 1402 	ljmp	_vial_fill_packet
                                   1403 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B290                       1404 00122$:
                                   1405 ;	quantum/vial.c:347: switch (msg[2]) {
      00B290 12 3A 39         [24] 1406 	lcall	_ak820_outline_0033
      00B293 FB               [12] 1407 	mov	r3,a
      00B294 60 0C            [24] 1408 	jz	00123$
      00B296 BB 03 02         [24] 1409 	cjne	r3,#0x03,00272$
      00B299 80 31            [24] 1410 	sjmp	00124$
      00B29B                       1411 00272$:
      00B29B BB 04 03         [24] 1412 	cjne	r3,#0x04,00273$
      00B29E 02 B3 2A         [24] 1413 	ljmp	00125$
      00B2A1                       1414 00273$:
      00B2A1 22               [24] 1415 	ret
                                   1416 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B2A2                       1417 00123$:
                                   1418 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B2A2 90 0C 5B         [24] 1419 	mov	dptr,#_vial_fill_packet_PARM_2
      00B2A5 E4               [12] 1420 	clr	a
      00B2A6 12 45 3B         [24] 1421 	lcall	_ak820_outline_0060
      00B2A9 C0 07            [24] 1422 	push	ar7
      00B2AB C0 06            [24] 1423 	push	ar6
      00B2AD 12 AF 99         [24] 1424 	lcall	_vial_fill_packet
      00B2B0 D0 06            [24] 1425 	pop	ar6
      00B2B2 D0 07            [24] 1426 	pop	ar7
                                   1427 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B2B4 12 45 60         [24] 1428 	lcall	_ak820_outline_0116
      00B2B7 E4               [12] 1429 	clr	a
      00B2B8 12 45 3B         [24] 1430 	lcall	_ak820_outline_0060
                                   1431 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B2BB A3               [24] 1432 	inc	dptr
      00B2BC 74 08            [12] 1433 	mov	a,#0x08
      00B2BE 12 45 0F         [24] 1434 	lcall	_ak820_outline_0029
                                   1435 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B2C1 E4               [12] 1436 	clr	a
      00B2C2 F0               [24] 1437 	movx	@dptr,a
                                   1438 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B2C3 74 1F            [12] 1439 	mov	a,#0x1f
      00B2C5 12 3A 31         [24] 1440 	lcall	_ak820_outline_0030
      00B2C8 74 01            [12] 1441 	mov	a,#0x01
      00B2CA F0               [24] 1442 	movx	@dptr,a
                                   1443 ;	quantum/vial.c:356: break;
      00B2CB 22               [24] 1444 	ret
                                   1445 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B2CC                       1446 00124$:
                                   1447 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B2CC 12 AE 99         [24] 1448 	lcall	_ak820_outline_0014
      00B2CF FB               [12] 1449 	mov	r3,a
                                   1450 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B2D0 90 0C 62         [24] 1451 	mov	dptr,#_vial_handle_cmd_entry_70000_646
      00B2D3 12 51 43         [24] 1452 	lcall	_ak820_outline_0165
      00B2D6 90 0C 64         [24] 1453 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0002)
      00B2D9 F0               [24] 1454 	movx	@dptr,a
      00B2DA A3               [24] 1455 	inc	dptr
      00B2DB F0               [24] 1456 	movx	@dptr,a
      00B2DC 90 0C 66         [24] 1457 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0004)
      00B2DF F0               [24] 1458 	movx	@dptr,a
      00B2E0 A3               [24] 1459 	inc	dptr
      00B2E1 F0               [24] 1460 	movx	@dptr,a
      00B2E2 90 0C 68         [24] 1461 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0006)
      00B2E5 F0               [24] 1462 	movx	@dptr,a
      00B2E6 A3               [24] 1463 	inc	dptr
      00B2E7 F0               [24] 1464 	movx	@dptr,a
      00B2E8 90 0C 6A         [24] 1465 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00B2EB F0               [24] 1466 	movx	@dptr,a
      00B2EC A3               [24] 1467 	inc	dptr
      00B2ED F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B2EE 90 0B 11         [24] 1470 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B2F1 74 62            [12] 1471 	mov	a,#_vial_handle_cmd_entry_70000_646
      00B2F3 F0               [24] 1472 	movx	@dptr,a
      00B2F4 74 0C            [12] 1473 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00B2F6 12 3A 72         [24] 1474 	lcall	_ak820_outline_0096
      00B2F9 8B 82            [24] 1475 	mov	dpl, r3
      00B2FB C0 07            [24] 1476 	push	ar7
      00B2FD C0 06            [24] 1477 	push	ar6
      00B2FF C0 05            [24] 1478 	push	ar5
      00B301 C0 04            [24] 1479 	push	ar4
      00B303 12 89 60         [24] 1480 	lcall	_dynamic_keymap_get_combo
      00B306 AA 82            [24] 1481 	mov	r2, dpl
      00B308 D0 04            [24] 1482 	pop	ar4
      00B30A D0 05            [24] 1483 	pop	ar5
      00B30C D0 06            [24] 1484 	pop	ar6
      00B30E D0 07            [24] 1485 	pop	ar7
      00B310 12 45 60         [24] 1486 	lcall	_ak820_outline_0116
      00B313 EA               [12] 1487 	mov	a,r2
      00B314 F0               [24] 1488 	movx	@dptr,a
                                   1489 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B315 7B 00            [12] 1490 	mov	r3,#0x00
      00B317 90 0D 9E         [24] 1491 	mov	dptr,#___memcpy_PARM_2
      00B31A 74 62            [12] 1492 	mov	a,#_vial_handle_cmd_entry_70000_646
      00B31C F0               [24] 1493 	movx	@dptr,a
      00B31D 74 0C            [12] 1494 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00B31F 12 B4 88         [24] 1495 	lcall	_ak820_outline_0072
      00B322 12 3A 95         [24] 1496 	lcall	_ak820_outline_0117
      00B325 8B F0            [24] 1497 	mov	b, r3
                                   1498 ;	quantum/vial.c:387: break;
      00B327 02 BA 52         [24] 1499 	ljmp	___memcpy
                                   1500 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B32A                       1501 00125$:
                                   1502 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B32A 12 AE 99         [24] 1503 	lcall	_ak820_outline_0014
      00B32D FD               [12] 1504 	mov	r5,a
                                   1505 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B32E 74 04            [12] 1506 	mov	a,#0x04
      00B330 2E               [12] 1507 	add	a, r6
      00B331 FB               [12] 1508 	mov	r3,a
      00B332 E4               [12] 1509 	clr	a
      00B333 3F               [12] 1510 	addc	a, r7
      00B334 FC               [12] 1511 	mov	r4,a
      00B335 90 0D 9E         [24] 1512 	mov	dptr,#___memcpy_PARM_2
      00B338 EB               [12] 1513 	mov	a,r3
      00B339 F0               [24] 1514 	movx	@dptr,a
      00B33A EC               [12] 1515 	mov	a,r4
      00B33B 12 B4 88         [24] 1516 	lcall	_ak820_outline_0072
      00B33E 90 0C 6C         [24] 1517 	mov	dptr,#_vial_handle_cmd_entry_70000_647
      00B341 F5 F0            [12] 1518 	mov	b,a
      00B343 C0 07            [24] 1519 	push	ar7
      00B345 C0 06            [24] 1520 	push	ar6
      00B347 C0 05            [24] 1521 	push	ar5
      00B349 12 BA 52         [24] 1522 	lcall	___memcpy
                                   1523 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B34C 90 0C 74         [24] 1524 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00B34F 12 3A 9A         [24] 1525 	lcall	_ak820_outline_0120
      00B352 12 36 42         [24] 1526 	lcall	_ak820_outline_0121
      00B355 12 AF 76         [24] 1527 	lcall	_vial_keycode_firewall
      00B358 AB 82            [24] 1528 	mov	r3, dpl
      00B35A AC 83            [24] 1529 	mov	r4, dph
      00B35C D0 05            [24] 1530 	pop	ar5
      00B35E 90 0C 74         [24] 1531 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00B361 12 3A 6C         [24] 1532 	lcall	_ak820_outline_0076
                                   1533 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B364 90 0B 15         [24] 1534 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B367 74 6C            [12] 1535 	mov	a,#_vial_handle_cmd_entry_70000_647
      00B369 F0               [24] 1536 	movx	@dptr,a
      00B36A 74 0C            [12] 1537 	mov	a,#(_vial_handle_cmd_entry_70000_647 >> 8)
      00B36C 12 3A 72         [24] 1538 	lcall	_ak820_outline_0096
      00B36F 8D 82            [24] 1539 	mov	dpl, r5
      00B371 12 8A 07         [24] 1540 	lcall	_dynamic_keymap_set_combo
      00B374 AC 82            [24] 1541 	mov	r4, dpl
      00B376 D0 06            [24] 1542 	pop	ar6
      00B378 D0 07            [24] 1543 	pop	ar7
      00B37A 12 45 60         [24] 1544 	lcall	_ak820_outline_0116
      00B37D EC               [12] 1545 	mov	a,r4
      00B37E F0               [24] 1546 	movx	@dptr,a
                                   1547 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B37F EC               [12] 1548 	mov	a,r4
      00B380 70 03            [24] 1549 	jnz	00139$
                                   1550 ;	quantum/vial.c:423: }
                                   1551 ;	quantum/vial.c:424: }
      00B382 02 37 7D         [24] 1552 	ljmp	_ak820_combo_reload
      00B385                       1553 00139$:
      00B385 22               [24] 1554 	ret
                                   1555 ;------------------------------------------------------------
                                   1556 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1557 ;------------------------------------------------------------
                                   1558 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_649'
                                   1559 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_656'
                                   1560 ;------------------------------------------------------------
                                   1561 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1562 ;	-----------------------------------------
                                   1563 ;	 function vial_keycode_down
                                   1564 ;	-----------------------------------------
      00B386                       1565 _vial_keycode_down:
      00B386 12 3A 84         [24] 1566 	lcall	_ak820_outline_0103
      00B389 90 0C 78         [24] 1567 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B38C 12 3A 89         [24] 1568 	lcall	_ak820_outline_0104
                                   1569 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B38F 90 0C 78         [24] 1570 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B392 12 3A 0C         [24] 1571 	lcall	_ak820_outline_0009
      00B395 74 E0            [12] 1572 	mov	a,#0x100 - 0x20
      00B397 2D               [12] 1573 	add	a,r5
      00B398 50 19            [24] 1574 	jnc	00104$
      00B39A C3               [12] 1575 	clr	c
      00B39B 74 FF            [12] 1576 	mov	a,#0xff
      00B39D 9C               [12] 1577 	subb	a,r4
      00B39E 74 4F            [12] 1578 	mov	a,#0x4f
      00B3A0 9D               [12] 1579 	subb	a,r5
      00B3A1 40 10            [24] 1580 	jc	00104$
                                   1581 ;	free result
                                   1582 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B3A3 90 0C 78         [24] 1583 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B3A6 EE               [12] 1584 	mov	a,r6
      00B3A7 12 3A A0         [24] 1585 	lcall	_ak820_outline_0122
                                   1586 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B3AA 90 0C 78         [24] 1587 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B3AD E0               [24] 1588 	movx	a,@dptr
      00B3AE 24 FE            [12] 1589 	add	a,#0xff - 0x01
      00B3B0 40 01            [24] 1590 	jc	00104$
                                   1591 ;	free result
      00B3B2 22               [24] 1592 	ret
      00B3B3                       1593 00104$:
                                   1594 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B3B3 90 0C 78         [24] 1595 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B3B6 12 B4 6F         [24] 1596 	lcall	_ak820_outline_0023
                                   1597 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B3B9 40 06            [24] 1598 	jc	00107$
                                   1599 ;	free result
                                   1600 ;	quantum/vial.c:440: register_code16(keycode);
      00B3BB 12 45 60         [24] 1601 	lcall	_ak820_outline_0116
      00B3BE 02 A0 E7         [24] 1602 	ljmp	_register_code16
      00B3C1                       1603 00107$:
                                   1604 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B3C1 90 0C 7E         [24] 1605 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0004)
      00B3C4 74 01            [12] 1606 	mov	a,#0x01
      00B3C6 F0               [24] 1607 	movx	@dptr,a
      00B3C7 90 0C 7B         [24] 1608 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0001)
      00B3CA 74 F0            [12] 1609 	mov	a,#0xf0
      00B3CC F0               [24] 1610 	movx	@dptr,a
      00B3CD 90 0C 7A         [24] 1611 	mov	dptr,#_vial_keycode_down_dummy_event_30000_656
      00B3D0 F0               [24] 1612 	movx	@dptr,a
      00B3D1 90 0C 7F         [24] 1613 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0005)
      00B3D4 74 01            [12] 1614 	mov	a,#0x01
      00B3D6 F0               [24] 1615 	movx	@dptr,a
      00B3D7 12 4B 11         [24] 1616 	lcall	_timer_read
      00B3DA 12 45 6B         [24] 1617 	lcall	_ak820_outline_0130
      00B3DD 43 06 01         [24] 1618 	orl	ar6,#0x01
      00B3E0 90 0C 7C         [24] 1619 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0002)
      00B3E3 12 4A 79         [24] 1620 	lcall	_ak820_outline_0058
                                   1621 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B3E6 90 0C 7A         [24] 1622 	mov	dptr,#_vial_keycode_down_dummy_event_30000_656
                                   1623 ;	quantum/vial.c:448: }
      00B3E9 02 74 B5         [24] 1624 	ljmp	_ak820_action_exec
                                   1625 ;------------------------------------------------------------
                                   1626 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1627 ;------------------------------------------------------------
                                   1628 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_657'
                                   1629 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_664'
                                   1630 ;------------------------------------------------------------
                                   1631 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1632 ;	-----------------------------------------
                                   1633 ;	 function vial_keycode_up
                                   1634 ;	-----------------------------------------
      00B3EC                       1635 _vial_keycode_up:
      00B3EC 12 3A 84         [24] 1636 	lcall	_ak820_outline_0103
      00B3EF 90 0C 80         [24] 1637 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B3F2 12 3A 89         [24] 1638 	lcall	_ak820_outline_0104
                                   1639 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B3F5 90 0C 80         [24] 1640 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B3F8 12 3A 0C         [24] 1641 	lcall	_ak820_outline_0009
      00B3FB 74 E0            [12] 1642 	mov	a,#0x100 - 0x20
      00B3FD 2D               [12] 1643 	add	a,r5
      00B3FE 50 19            [24] 1644 	jnc	00104$
      00B400 C3               [12] 1645 	clr	c
      00B401 74 FF            [12] 1646 	mov	a,#0xff
      00B403 9C               [12] 1647 	subb	a,r4
      00B404 74 4F            [12] 1648 	mov	a,#0x4f
      00B406 9D               [12] 1649 	subb	a,r5
      00B407 40 10            [24] 1650 	jc	00104$
                                   1651 ;	free result
                                   1652 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B409 90 0C 80         [24] 1653 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B40C EE               [12] 1654 	mov	a,r6
      00B40D 12 3A A0         [24] 1655 	lcall	_ak820_outline_0122
                                   1656 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B410 90 0C 80         [24] 1657 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B413 E0               [24] 1658 	movx	a,@dptr
      00B414 24 FE            [12] 1659 	add	a,#0xff - 0x01
      00B416 40 01            [24] 1660 	jc	00104$
                                   1661 ;	free result
      00B418 22               [24] 1662 	ret
      00B419                       1663 00104$:
                                   1664 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B419 90 0C 80         [24] 1665 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B41C 12 B4 6F         [24] 1666 	lcall	_ak820_outline_0023
                                   1667 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B41F 40 06            [24] 1668 	jc	00107$
                                   1669 ;	free result
                                   1670 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B421 12 45 60         [24] 1671 	lcall	_ak820_outline_0116
      00B424 02 A1 2B         [24] 1672 	ljmp	_unregister_code16
      00B427                       1673 00107$:
                                   1674 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B427 90 0C 86         [24] 1675 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0004)
      00B42A 74 01            [12] 1676 	mov	a,#0x01
      00B42C F0               [24] 1677 	movx	@dptr,a
      00B42D 90 0C 83         [24] 1678 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0001)
      00B430 74 F0            [12] 1679 	mov	a,#0xf0
      00B432 F0               [24] 1680 	movx	@dptr,a
      00B433 90 0C 82         [24] 1681 	mov	dptr,#_vial_keycode_up_dummy_event_30000_664
      00B436 F0               [24] 1682 	movx	@dptr,a
      00B437 90 0C 87         [24] 1683 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0005)
      00B43A E4               [12] 1684 	clr	a
      00B43B F0               [24] 1685 	movx	@dptr,a
      00B43C 12 4B 11         [24] 1686 	lcall	_timer_read
      00B43F 12 45 6B         [24] 1687 	lcall	_ak820_outline_0130
      00B442 43 06 01         [24] 1688 	orl	ar6,#0x01
      00B445 90 0C 84         [24] 1689 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0002)
      00B448 12 4A 79         [24] 1690 	lcall	_ak820_outline_0058
                                   1691 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B44B 90 0C 82         [24] 1692 	mov	dptr,#_vial_keycode_up_dummy_event_30000_664
                                   1693 ;	quantum/vial.c:470: }
      00B44E 02 74 B5         [24] 1694 	ljmp	_ak820_action_exec
                                   1695 ;------------------------------------------------------------
                                   1696 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1697 ;------------------------------------------------------------
                                   1698 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_665'
                                   1699 ;i             Allocated with name '_vial_keycode_tap_i_30000_668'
                                   1700 ;------------------------------------------------------------
                                   1701 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1702 ;	-----------------------------------------
                                   1703 ;	 function vial_keycode_tap
                                   1704 ;	-----------------------------------------
      00B451                       1705 _vial_keycode_tap:
      00B451 12 3A 84         [24] 1706 	lcall	_ak820_outline_0103
      00B454 90 0C 88         [24] 1707 	mov	dptr,#_vial_keycode_tap_keycode_10000_665
      00B457 12 3A 89         [24] 1708 	lcall	_ak820_outline_0104
                                   1709 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B45A 90 0C 88         [24] 1710 	mov	dptr,#_vial_keycode_tap_keycode_10000_665
      00B45D 12 39 E1         [24] 1711 	lcall	_ak820_outline_0004
      00B460 C0 07            [24] 1712 	push	ar7
      00B462 C0 06            [24] 1713 	push	ar6
      00B464 71 86            [12] 1714 	acall	_vial_keycode_down
      00B466 D0 06            [24] 1715 	pop	ar6
      00B468 D0 07            [24] 1716 	pop	ar7
                                   1717 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B46A 12 45 60         [24] 1718 	lcall	_ak820_outline_0116
                                   1719 ;	quantum/vial.c:476: }
      00B46D 61 EC            [12] 1720 	ajmp	_vial_keycode_up
                                   1721 ;------------------------------------------------------------
                                   1722 ;Allocation info for local variables in function 'process_record_vial'
                                   1723 ;------------------------------------------------------------
                                   1724 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1725 ;keycode       Allocated with name '_process_record_vial_keycode_10000_670'
                                   1726 ;------------------------------------------------------------
                                   1727 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1728 ;	-----------------------------------------
                                   1729 	.area CSEG    (CODE)
                                   1730 	.area CONST   (CODE)
                                   1731 	.area CONST   (CODE)
      00BFD8                       1732 _keyboard_definition:
      00BFD8 FD                    1733 	.db #0xfd	; 253
      00BFD9 37                    1734 	.db #0x37	; 55	'7'
      00BFDA 7A                    1735 	.db #0x7a	; 122	'z'
      00BFDB 58                    1736 	.db #0x58	; 88	'X'
      00BFDC 5A                    1737 	.db #0x5a	; 90	'Z'
      00BFDD 00                    1738 	.db #0x00	; 0
      00BFDE 00                    1739 	.db #0x00	; 0
      00BFDF 04                    1740 	.db #0x04	; 4
      00BFE0 E6                    1741 	.db #0xe6	; 230
      00BFE1 D6                    1742 	.db #0xd6	; 214
      00BFE2 B4                    1743 	.db #0xb4	; 180
      00BFE3 46                    1744 	.db #0x46	; 70	'F'
      00BFE4 02                    1745 	.db #0x02	; 2
      00BFE5 00                    1746 	.db #0x00	; 0
      00BFE6 21                    1747 	.db #0x21	; 33
      00BFE7 01                    1748 	.db #0x01	; 1
      00BFE8 00                    1749 	.db #0x00	; 0
      00BFE9 00                    1750 	.db #0x00	; 0
      00BFEA 00                    1751 	.db #0x00	; 0
      00BFEB 00                    1752 	.db #0x00	; 0
      00BFEC 37                    1753 	.db #0x37	; 55	'7'
      00BFED 27                    1754 	.db #0x27	; 39
      00BFEE 97                    1755 	.db #0x97	; 151
      00BFEF D6                    1756 	.db #0xd6	; 214
      00BFF0 E0                    1757 	.db #0xe0	; 224
      00BFF1 03                    1758 	.db #0x03	; 3
      00BFF2 CB                    1759 	.db #0xcb	; 203
      00BFF3 01                    1760 	.db #0x01	; 1
      00BFF4 3C                    1761 	.db #0x3c	; 60
      00BFF5 00                    1762 	.db #0x00	; 0
      00BFF6 00                    1763 	.db #0x00	; 0
      00BFF7 3D                    1764 	.db #0x3d	; 61
      00BFF8 88                    1765 	.db #0x88	; 136
      00BFF9 CD                    1766 	.db #0xcd	; 205
      00BFFA A5                    1767 	.db #0xa5	; 165
      00BFFB AA                    1768 	.db #0xaa	; 170
      00BFFC E5                    1769 	.db #0xe5	; 229
      00BFFD A8                    1770 	.db #0xa8	; 168
      00BFFE 76                    1771 	.db #0x76	; 118	'v'
      00BFFF F6                    1772 	.db #0xf6	; 246
      00C000 43                    1773 	.db #0x43	; 67	'C'
      00C001 0E                    1774 	.db #0x0e	; 14
      00C002 D2                    1775 	.db #0xd2	; 210
      00C003 90                    1776 	.db #0x90	; 144
      00C004 7D                    1777 	.db #0x7d	; 125
      00C005 94                    1778 	.db #0x94	; 148
      00C006 79                    1779 	.db #0x79	; 121	'y'
      00C007 78                    1780 	.db #0x78	; 120	'x'
      00C008 EF                    1781 	.db #0xef	; 239
      00C009 49                    1782 	.db #0x49	; 73	'I'
      00C00A 3E                    1783 	.db #0x3e	; 62
      00C00B EF                    1784 	.db #0xef	; 239
      00C00C FD                    1785 	.db #0xfd	; 253
      00C00D 8F                    1786 	.db #0x8f	; 143
      00C00E EF                    1787 	.db #0xef	; 239
      00C00F 00                    1788 	.db #0x00	; 0
      00C010 C6                    1789 	.db #0xc6	; 198
      00C011 D1                    1790 	.db #0xd1	; 209
      00C012 DB                    1791 	.db #0xdb	; 219
      00C013 FB                    1792 	.db #0xfb	; 251
      00C014 EB                    1793 	.db #0xeb	; 235
      00C015 DE                    1794 	.db #0xde	; 222
      00C016 66                    1795 	.db #0x66	; 102	'f'
      00C017 63                    1796 	.db #0x63	; 99	'c'
      00C018 0C                    1797 	.db #0x0c	; 12
      00C019 92                    1798 	.db #0x92	; 146
      00C01A 7B                    1799 	.db #0x7b	; 123
      00C01B F9                    1800 	.db #0xf9	; 249
      00C01C D4                    1801 	.db #0xd4	; 212
      00C01D 7A                    1802 	.db #0x7a	; 122	'z'
      00C01E 4F                    1803 	.db #0x4f	; 79	'O'
      00C01F 83                    1804 	.db #0x83	; 131
      00C020 4B                    1805 	.db #0x4b	; 75	'K'
      00C021 86                    1806 	.db #0x86	; 134
      00C022 0E                    1807 	.db #0x0e	; 14
      00C023 6A                    1808 	.db #0x6a	; 106	'j'
      00C024 F2                    1809 	.db #0xf2	; 242
      00C025 22                    1810 	.db #0x22	; 34
      00C026 22                    1811 	.db #0x22	; 34
      00C027 0B                    1812 	.db #0x0b	; 11
      00C028 03                    1813 	.db #0x03	; 3
      00C029 BA                    1814 	.db #0xba	; 186
      00C02A 67                    1815 	.db #0x67	; 103	'g'
      00C02B 9B                    1816 	.db #0x9b	; 155
      00C02C 7A                    1817 	.db #0x7a	; 122	'z'
      00C02D E1                    1818 	.db #0xe1	; 225
      00C02E BC                    1819 	.db #0xbc	; 188
      00C02F 37                    1820 	.db #0x37	; 55	'7'
      00C030 26                    1821 	.db #0x26	; 38
      00C031 46                    1822 	.db #0x46	; 70	'F'
      00C032 78                    1823 	.db #0x78	; 120	'x'
      00C033 05                    1824 	.db #0x05	; 5
      00C034 0D                    1825 	.db #0x0d	; 13
      00C035 95                    1826 	.db #0x95	; 149
      00C036 02                    1827 	.db #0x02	; 2
      00C037 E4                    1828 	.db #0xe4	; 228
      00C038 18                    1829 	.db #0x18	; 24
      00C039 CA                    1830 	.db #0xca	; 202
      00C03A 33                    1831 	.db #0x33	; 51	'3'
      00C03B EA                    1832 	.db #0xea	; 234
      00C03C 24                    1833 	.db #0x24	; 36
      00C03D C8                    1834 	.db #0xc8	; 200
      00C03E 81                    1835 	.db #0x81	; 129
      00C03F 4E                    1836 	.db #0x4e	; 78	'N'
      00C040 47                    1837 	.db #0x47	; 71	'G'
      00C041 A8                    1838 	.db #0xa8	; 168
      00C042 44                    1839 	.db #0x44	; 68	'D'
      00C043 DD                    1840 	.db #0xdd	; 221
      00C044 91                    1841 	.db #0x91	; 145
      00C045 6D                    1842 	.db #0x6d	; 109	'm'
      00C046 69                    1843 	.db #0x69	; 105	'i'
      00C047 DB                    1844 	.db #0xdb	; 219
      00C048 4F                    1845 	.db #0x4f	; 79	'O'
      00C049 3A                    1846 	.db #0x3a	; 58
      00C04A 43                    1847 	.db #0x43	; 67	'C'
      00C04B 9D                    1848 	.db #0x9d	; 157
      00C04C 26                    1849 	.db #0x26	; 38
      00C04D 49                    1850 	.db #0x49	; 73	'I'
      00C04E 4C                    1851 	.db #0x4c	; 76	'L'
      00C04F EF                    1852 	.db #0xef	; 239
      00C050 2B                    1853 	.db #0x2b	; 43
      00C051 D8                    1854 	.db #0xd8	; 216
      00C052 55                    1855 	.db #0x55	; 85	'U'
      00C053 95                    1856 	.db #0x95	; 149
      00C054 70                    1857 	.db #0x70	; 112	'p'
      00C055 B1                    1858 	.db #0xb1	; 177
      00C056 CC                    1859 	.db #0xcc	; 204
      00C057 CF                    1860 	.db #0xcf	; 207
      00C058 13                    1861 	.db #0x13	; 19
      00C059 32                    1862 	.db #0x32	; 50	'2'
      00C05A 6A                    1863 	.db #0x6a	; 106	'j'
      00C05B A1                    1864 	.db #0xa1	; 161
      00C05C FF                    1865 	.db #0xff	; 255
      00C05D 99                    1866 	.db #0x99	; 153
      00C05E 61                    1867 	.db #0x61	; 97	'a'
      00C05F 95                    1868 	.db #0x95	; 149
      00C060 B1                    1869 	.db #0xb1	; 177
      00C061 89                    1870 	.db #0x89	; 137
      00C062 9B                    1871 	.db #0x9b	; 155
      00C063 11                    1872 	.db #0x11	; 17
      00C064 D9                    1873 	.db #0xd9	; 217
      00C065 35                    1874 	.db #0x35	; 53	'5'
      00C066 78                    1875 	.db #0x78	; 120	'x'
      00C067 ED                    1876 	.db #0xed	; 237
      00C068 CD                    1877 	.db #0xcd	; 205
      00C069 94                    1878 	.db #0x94	; 148
      00C06A 6E                    1879 	.db #0x6e	; 110	'n'
      00C06B 60                    1880 	.db #0x60	; 96
      00C06C 8E                    1881 	.db #0x8e	; 142
      00C06D 63                    1882 	.db #0x63	; 99	'c'
      00C06E 8B                    1883 	.db #0x8b	; 139
      00C06F FF                    1884 	.db #0xff	; 255
      00C070 4E                    1885 	.db #0x4e	; 78	'N'
      00C071 20                    1886 	.db #0x20	; 32
      00C072 7A                    1887 	.db #0x7a	; 122	'z'
      00C073 B5                    1888 	.db #0xb5	; 181
      00C074 87                    1889 	.db #0x87	; 135
      00C075 C2                    1890 	.db #0xc2	; 194
      00C076 35                    1891 	.db #0x35	; 53	'5'
      00C077 A4                    1892 	.db #0xa4	; 164
      00C078 6D                    1893 	.db #0x6d	; 109	'm'
      00C079 18                    1894 	.db #0x18	; 24
      00C07A C1                    1895 	.db #0xc1	; 193
      00C07B A3                    1896 	.db #0xa3	; 163
      00C07C DB                    1897 	.db #0xdb	; 219
      00C07D 53                    1898 	.db #0x53	; 83	'S'
      00C07E 1D                    1899 	.db #0x1d	; 29
      00C07F EC                    1900 	.db #0xec	; 236
      00C080 F0                    1901 	.db #0xf0	; 240
      00C081 BF                    1902 	.db #0xbf	; 191
      00C082 4A                    1903 	.db #0x4a	; 74	'J'
      00C083 4C                    1904 	.db #0x4c	; 76	'L'
      00C084 4A                    1905 	.db #0x4a	; 74	'J'
      00C085 C4                    1906 	.db #0xc4	; 196
      00C086 AA                    1907 	.db #0xaa	; 170
      00C087 37                    1908 	.db #0x37	; 55	'7'
      00C088 19                    1909 	.db #0x19	; 25
      00C089 34                    1910 	.db #0x34	; 52	'4'
      00C08A 3F                    1911 	.db #0x3f	; 63
      00C08B A1                    1912 	.db #0xa1	; 161
      00C08C D3                    1913 	.db #0xd3	; 211
      00C08D 1A                    1914 	.db #0x1a	; 26
      00C08E 5C                    1915 	.db #0x5c	; 92
      00C08F 03                    1916 	.db #0x03	; 3
      00C090 4D                    1917 	.db #0x4d	; 77	'M'
      00C091 BC                    1918 	.db #0xbc	; 188
      00C092 10                    1919 	.db #0x10	; 16
      00C093 2E                    1920 	.db #0x2e	; 46
      00C094 80                    1921 	.db #0x80	; 128
      00C095 F7                    1922 	.db #0xf7	; 247
      00C096 D6                    1923 	.db #0xd6	; 214
      00C097 82                    1924 	.db #0x82	; 130
      00C098 24                    1925 	.db #0x24	; 36
      00C099 4C                    1926 	.db #0x4c	; 76	'L'
      00C09A 87                    1927 	.db #0x87	; 135
      00C09B B9                    1928 	.db #0xb9	; 185
      00C09C F8                    1929 	.db #0xf8	; 248
      00C09D BE                    1930 	.db #0xbe	; 190
      00C09E 67                    1931 	.db #0x67	; 103	'g'
      00C09F 96                    1932 	.db #0x96	; 150
      00C0A0 89                    1933 	.db #0x89	; 137
      00C0A1 30                    1934 	.db #0x30	; 48	'0'
      00C0A2 C8                    1935 	.db #0xc8	; 200
      00C0A3 8D                    1936 	.db #0x8d	; 141
      00C0A4 2C                    1937 	.db #0x2c	; 44
      00C0A5 F5                    1938 	.db #0xf5	; 245
      00C0A6 06                    1939 	.db #0x06	; 6
      00C0A7 05                    1940 	.db #0x05	; 5
      00C0A8 7C                    1941 	.db #0x7c	; 124
      00C0A9 48                    1942 	.db #0x48	; 72	'H'
      00C0AA 1B                    1943 	.db #0x1b	; 27
      00C0AB 76                    1944 	.db #0x76	; 118	'v'
      00C0AC AA                    1945 	.db #0xaa	; 170
      00C0AD 3D                    1946 	.db #0x3d	; 61
      00C0AE 28                    1947 	.db #0x28	; 40
      00C0AF FC                    1948 	.db #0xfc	; 252
      00C0B0 80                    1949 	.db #0x80	; 128
      00C0B1 75                    1950 	.db #0x75	; 117	'u'
      00C0B2 EB                    1951 	.db #0xeb	; 235
      00C0B3 78                    1952 	.db #0x78	; 120	'x'
      00C0B4 D0                    1953 	.db #0xd0	; 208
      00C0B5 8A                    1954 	.db #0x8a	; 138
      00C0B6 8F                    1955 	.db #0x8f	; 143
      00C0B7 27                    1956 	.db #0x27	; 39
      00C0B8 F7                    1957 	.db #0xf7	; 247
      00C0B9 F2                    1958 	.db #0xf2	; 242
      00C0BA EB                    1959 	.db #0xeb	; 235
      00C0BB 58                    1960 	.db #0x58	; 88	'X'
      00C0BC 37                    1961 	.db #0x37	; 55	'7'
      00C0BD 3C                    1962 	.db #0x3c	; 60
      00C0BE 2B                    1963 	.db #0x2b	; 43
      00C0BF 6F                    1964 	.db #0x6f	; 111	'o'
      00C0C0 0E                    1965 	.db #0x0e	; 14
      00C0C1 C7                    1966 	.db #0xc7	; 199
      00C0C2 E2                    1967 	.db #0xe2	; 226
      00C0C3 A0                    1968 	.db #0xa0	; 160
      00C0C4 97                    1969 	.db #0x97	; 151
      00C0C5 EE                    1970 	.db #0xee	; 238
      00C0C6 FD                    1971 	.db #0xfd	; 253
      00C0C7 9F                    1972 	.db #0x9f	; 159
      00C0C8 45                    1973 	.db #0x45	; 69	'E'
      00C0C9 17                    1974 	.db #0x17	; 23
      00C0CA 94                    1975 	.db #0x94	; 148
      00C0CB E6                    1976 	.db #0xe6	; 230
      00C0CC E7                    1977 	.db #0xe7	; 231
      00C0CD FA                    1978 	.db #0xfa	; 250
      00C0CE 4C                    1979 	.db #0x4c	; 76	'L'
      00C0CF 7A                    1980 	.db #0x7a	; 122	'z'
      00C0D0 D6                    1981 	.db #0xd6	; 214
      00C0D1 7A                    1982 	.db #0x7a	; 122	'z'
      00C0D2 7B                    1983 	.db #0x7b	; 123
      00C0D3 ED                    1984 	.db #0xed	; 237
      00C0D4 10                    1985 	.db #0x10	; 16
      00C0D5 C5                    1986 	.db #0xc5	; 197
      00C0D6 BC                    1987 	.db #0xbc	; 188
      00C0D7 E3                    1988 	.db #0xe3	; 227
      00C0D8 A9                    1989 	.db #0xa9	; 169
      00C0D9 1F                    1990 	.db #0x1f	; 31
      00C0DA CF                    1991 	.db #0xcf	; 207
      00C0DB C4                    1992 	.db #0xc4	; 196
      00C0DC 9D                    1993 	.db #0x9d	; 157
      00C0DD DC                    1994 	.db #0xdc	; 220
      00C0DE 45                    1995 	.db #0x45	; 69	'E'
      00C0DF 2A                    1996 	.db #0x2a	; 42
      00C0E0 69                    1997 	.db #0x69	; 105	'i'
      00C0E1 57                    1998 	.db #0x57	; 87	'W'
      00C0E2 8F                    1999 	.db #0x8f	; 143
      00C0E3 EC                    2000 	.db #0xec	; 236
      00C0E4 85                    2001 	.db #0x85	; 133
      00C0E5 6C                    2002 	.db #0x6c	; 108	'l'
      00C0E6 43                    2003 	.db #0x43	; 67	'C'
      00C0E7 1C                    2004 	.db #0x1c	; 28
      00C0E8 BA                    2005 	.db #0xba	; 186
      00C0E9 89                    2006 	.db #0x89	; 137
      00C0EA 68                    2007 	.db #0x68	; 104	'h'
      00C0EB 4A                    2008 	.db #0x4a	; 74	'J'
      00C0EC 1C                    2009 	.db #0x1c	; 28
      00C0ED 91                    2010 	.db #0x91	; 145
      00C0EE 3F                    2011 	.db #0x3f	; 63
      00C0EF D1                    2012 	.db #0xd1	; 209
      00C0F0 B3                    2013 	.db #0xb3	; 179
      00C0F1 96                    2014 	.db #0x96	; 150
      00C0F2 1D                    2015 	.db #0x1d	; 29
      00C0F3 7C                    2016 	.db #0x7c	; 124
      00C0F4 14                    2017 	.db #0x14	; 20
      00C0F5 77                    2018 	.db #0x77	; 119	'w'
      00C0F6 9C                    2019 	.db #0x9c	; 156
      00C0F7 74                    2020 	.db #0x74	; 116	't'
      00C0F8 36                    2021 	.db #0x36	; 54	'6'
      00C0F9 FF                    2022 	.db #0xff	; 255
      00C0FA 2C                    2023 	.db #0x2c	; 44
      00C0FB 66                    2024 	.db #0x66	; 102	'f'
      00C0FC AF                    2025 	.db #0xaf	; 175
      00C0FD 0F                    2026 	.db #0x0f	; 15
      00C0FE 3C                    2027 	.db #0x3c	; 60
      00C0FF A2                    2028 	.db #0xa2	; 162
      00C100 23                    2029 	.db #0x23	; 35
      00C101 85                    2030 	.db #0x85	; 133
      00C102 05                    2031 	.db #0x05	; 5
      00C103 87                    2032 	.db #0x87	; 135
      00C104 DA                    2033 	.db #0xda	; 218
      00C105 61                    2034 	.db #0x61	; 97	'a'
      00C106 5E                    2035 	.db #0x5e	; 94
      00C107 42                    2036 	.db #0x42	; 66	'B'
      00C108 54                    2037 	.db #0x54	; 84	'T'
      00C109 60                    2038 	.db #0x60	; 96
      00C10A 23                    2039 	.db #0x23	; 35
      00C10B CA                    2040 	.db #0xca	; 202
      00C10C BC                    2041 	.db #0xbc	; 188
      00C10D B3                    2042 	.db #0xb3	; 179
      00C10E 18                    2043 	.db #0x18	; 24
      00C10F 1D                    2044 	.db #0x1d	; 29
      00C110 F8                    2045 	.db #0xf8	; 248
      00C111 0A                    2046 	.db #0x0a	; 10
      00C112 55                    2047 	.db #0x55	; 85	'U'
      00C113 CD                    2048 	.db #0xcd	; 205
      00C114 A3                    2049 	.db #0xa3	; 163
      00C115 DE                    2050 	.db #0xde	; 222
      00C116 FF                    2051 	.db #0xff	; 255
      00C117 B2                    2052 	.db #0xb2	; 178
      00C118 2A                    2053 	.db #0x2a	; 42
      00C119 35                    2054 	.db #0x35	; 53	'5'
      00C11A 00                    2055 	.db #0x00	; 0
      00C11B D6                    2056 	.db #0xd6	; 214
      00C11C 7B                    2057 	.db #0x7b	; 123
      00C11D E8                    2058 	.db #0xe8	; 232
      00C11E F2                    2059 	.db #0xf2	; 242
      00C11F 1A                    2060 	.db #0x1a	; 26
      00C120 BC                    2061 	.db #0xbc	; 188
      00C121 F5                    2062 	.db #0xf5	; 245
      00C122 7E                    2063 	.db #0x7e	; 126
      00C123 48                    2064 	.db #0x48	; 72	'H'
      00C124 72                    2065 	.db #0x72	; 114	'r'
      00C125 E0                    2066 	.db #0xe0	; 224
      00C126 E4                    2067 	.db #0xe4	; 228
      00C127 E0                    2068 	.db #0xe0	; 224
      00C128 27                    2069 	.db #0x27	; 39
      00C129 87                    2070 	.db #0x87	; 135
      00C12A 9A                    2071 	.db #0x9a	; 154
      00C12B 51                    2072 	.db #0x51	; 81	'Q'
      00C12C D4                    2073 	.db #0xd4	; 212
      00C12D DD                    2074 	.db #0xdd	; 221
      00C12E C3                    2075 	.db #0xc3	; 195
      00C12F AA                    2076 	.db #0xaa	; 170
      00C130 49                    2077 	.db #0x49	; 73	'I'
      00C131 5A                    2078 	.db #0x5a	; 90	'Z'
      00C132 2A                    2079 	.db #0x2a	; 42
      00C133 00                    2080 	.db #0x00	; 0
      00C134 A0                    2081 	.db #0xa0	; 160
      00C135 8C                    2082 	.db #0x8c	; 140
      00C136 FF                    2083 	.db #0xff	; 255
      00C137 74                    2084 	.db #0x74	; 116	't'
      00C138 BF                    2085 	.db #0xbf	; 191
      00C139 EC                    2086 	.db #0xec	; 236
      00C13A 1D                    2087 	.db #0x1d	; 29
      00C13B F1                    2088 	.db #0xf1	; 241
      00C13C 00                    2089 	.db #0x00	; 0
      00C13D 01                    2090 	.db #0x01	; 1
      00C13E D8                    2091 	.db #0xd8	; 216
      00C13F 02                    2092 	.db #0x02	; 2
      00C140 CC                    2093 	.db #0xcc	; 204
      00C141 07                    2094 	.db #0x07	; 7
      00C142 00                    2095 	.db #0x00	; 0
      00C143 00                    2096 	.db #0x00	; 0
      00C144 C4                    2097 	.db #0xc4	; 196
      00C145 5E                    2098 	.db #0x5e	; 94
      00C146 2C                    2099 	.db #0x2c	; 44
      00C147 7E                    2100 	.db #0x7e	; 126
      00C148 B1                    2101 	.db #0xb1	; 177
      00C149 C4                    2102 	.db #0xc4	; 196
      00C14A 67                    2103 	.db #0x67	; 103	'g'
      00C14B FB                    2104 	.db #0xfb	; 251
      00C14C 02                    2105 	.db #0x02	; 2
      00C14D 00                    2106 	.db #0x00	; 0
      00C14E 00                    2107 	.db #0x00	; 0
      00C14F 00                    2108 	.db #0x00	; 0
      00C150 00                    2109 	.db #0x00	; 0
      00C151 04                    2110 	.db #0x04	; 4
      00C152 59                    2111 	.db #0x59	; 89	'Y'
      00C153 5A                    2112 	.db #0x5a	; 90	'Z'
                                   2113 	.area CSEG    (CODE)
                                   2114 	.area CONST   (CODE)
      00C154                       2115 _vial_handle_cmd_keyboard_uid_40000_623:
      00C154 04                    2116 	.db #0x04	; 4
      00C155 70                    2117 	.db #0x70	; 112	'p'
      00C156 FF                    2118 	.db #0xff	; 255
      00C157 90                    2119 	.db #0x90	; 144
      00C158 01                    2120 	.db #0x01	; 1
      00C159 B9                    2121 	.db #0xb9	; 185
      00C15A 15                    2122 	.db #0x15	; 21
      00C15B D3                    2123 	.db #0xd3	; 211
                                   2124 	.area CSEG    (CODE)
                                   2125 	.area XINIT   (CODE)
      00C3D4                       2126 __xinit__vial_unlocked:
      00C3D4 00                    2127 	.db #0x00	;  0
      00C3D5                       2128 __xinit__vial_unlock_in_progress:
      00C3D5 00                    2129 	.db #0x00	;  0
      00C3D6                       2130 __xinit__vial_unlock_counter:
      00C3D6 00                    2131 	.db #0x00	; 0
      00C3D7                       2132 __xinit__vial_unlock_combo_rows:
      00C3D7 00                    2133 	.db #0x00	; 0
      00C3D8 00                    2134 	.db #0x00	; 0
      00C3D9                       2135 __xinit__vial_unlock_combo_cols:
      00C3D9 00                    2136 	.db #0x00	; 0
      00C3DA 05                    2137 	.db #0x05	; 5
                                   2138 	.area CABS    (ABS,CODE)
                                   2139 
                                   2140 ; Experimental exact instruction outlining.
                                   2141 	.globl _ak820_outline_0004
                                   2142 	.globl _ak820_outline_0007
                                   2143 	.globl _ak820_outline_0009
                                   2144 	.globl _ak820_outline_0010
                                   2145 	.globl _ak820_outline_0011
                                   2146 	.globl _ak820_outline_0014
                                   2147 	.globl _ak820_outline_0015
                                   2148 	.globl _ak820_outline_0016
                                   2149 	.globl _ak820_outline_0020
                                   2150 	.globl _ak820_outline_0023
                                   2151 	.globl _ak820_outline_0029
                                   2152 	.globl _ak820_outline_0030
                                   2153 	.globl _ak820_outline_0033
                                   2154 	.globl _ak820_outline_0036
                                   2155 	.globl _ak820_outline_0045
                                   2156 	.globl _ak820_outline_0050
                                   2157 	.globl _ak820_outline_0053
                                   2158 	.globl _ak820_outline_0056
                                   2159 	.globl _ak820_outline_0058
                                   2160 	.globl _ak820_outline_0060
                                   2161 	.globl _ak820_outline_0072
                                   2162 	.globl _ak820_outline_0076
                                   2163 	.globl _ak820_outline_0096
                                   2164 	.globl _ak820_outline_0103
                                   2165 	.globl _ak820_outline_0104
                                   2166 	.globl _ak820_outline_0116
                                   2167 	.globl _ak820_outline_0117
                                   2168 	.globl _ak820_outline_0120
                                   2169 	.globl _ak820_outline_0121
                                   2170 	.globl _ak820_outline_0122
                                   2171 	.globl _ak820_outline_0124
                                   2172 	.globl _ak820_outline_0125
                                   2173 	.globl _ak820_outline_0130
                                   2174 	.globl _ak820_outline_0135
                                   2175 	.globl _ak820_outline_0141
                                   2176 	.globl _ak820_outline_0154
                                   2177 	.globl _ak820_outline_0165
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0023
      00B46F                       2181 _ak820_outline_0023:
      00B46F E0               [24] 2182 	movx	a,@dptr
      00B470 FE               [12] 2183 	mov	r6,a
      00B471 A3               [24] 2184 	inc	dptr
      00B472 E0               [24] 2185 	movx	a,@dptr
      00B473 FF               [12] 2186 	mov	r7,a
      00B474 90 0C 76         [24] 2187 	mov	dptr,#_g_vial_magic_keycode_override
      00B477 EE               [12] 2188 	mov	a,r6
      00B478 F0               [24] 2189 	movx	@dptr,a
      00B479 EF               [12] 2190 	mov	a,r7
      00B47A A3               [24] 2191 	inc	dptr
      00B47B F0               [24] 2192 	movx	@dptr,a
      00B47C 8E 04            [24] 2193 	mov	ar4,r6
      00B47E 8F 05            [24] 2194 	mov	ar5,r7
      00B480 C3               [12] 2195 	clr	c
      00B481 74 FF            [12] 2196 	mov	a,#0xff
      00B483 9C               [12] 2197 	subb	a,r4
      00B484 74 1F            [12] 2198 	mov	a,#0x1f
      00B486 9D               [12] 2199 	subb	a,r5
      00B487 22               [24] 2200 	ret
                                   2201 
                                   2202 	.area CSEG (CODE)
                                   2203 ; function ak820_outline_0072
      00B488                       2204 _ak820_outline_0072:
      00B488 A3               [24] 2205 	inc	dptr
      00B489 F0               [24] 2206 	movx	@dptr,a
      00B48A E4               [12] 2207 	clr	a
      00B48B A3               [24] 2208 	inc	dptr
      00B48C F0               [24] 2209 	movx	@dptr,a
      00B48D 90 0D A1         [24] 2210 	mov	dptr,#___memcpy_PARM_3
      00B490 74 0A            [12] 2211 	mov	a,#0x0a
      00B492 F0               [24] 2212 	movx	@dptr,a
      00B493 E4               [12] 2213 	clr	a
      00B494 A3               [24] 2214 	inc	dptr
      00B495 F0               [24] 2215 	movx	@dptr,a
      00B496 22               [24] 2216 	ret
                                   2217 
                                   2218 	.area CSEG (CODE)
                                   2219 ; function ak820_outline_0124
      00B497                       2220 _ak820_outline_0124:
      00B497 24 24            [12] 2221 	add	a,#_vial_unlock_combo_cols
      00B499 F5 82            [12] 2222 	mov	dpl,a
      00B49B E4               [12] 2223 	clr	a
      00B49C 34 0E            [12] 2224 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B49E F5 83            [12] 2225 	mov	dph,a
      00B4A0 E0               [24] 2226 	movx	a,@dptr
      00B4A1 22               [24] 2227 	ret
                                   2228 
                                   2229 	.area CSEG (CODE)
                                   2230 ; function ak820_outline_0125
      00B4A2                       2231 _ak820_outline_0125:
      00B4A2 24 22            [12] 2232 	add	a,#_vial_unlock_combo_rows
      00B4A4 F5 82            [12] 2233 	mov	dpl,a
      00B4A6 E4               [12] 2234 	clr	a
      00B4A7 34 0E            [12] 2235 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B4A9 F5 83            [12] 2236 	mov	dph,a
      00B4AB E0               [24] 2237 	movx	a,@dptr
      00B4AC 22               [24] 2238 	ret
