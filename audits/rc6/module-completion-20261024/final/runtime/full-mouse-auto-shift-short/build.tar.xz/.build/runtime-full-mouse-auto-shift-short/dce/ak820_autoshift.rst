                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_autoshift
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _del_owned_mods
                                     12 	.globl _add_owned_mods
                                     13 	.globl _get_weak_mods
                                     14 	.globl _get_mods
                                     15 	.globl _send_keyboard_report
                                     16 	.globl _process_record
                                     17 	.globl _ADC_START
                                     18 	.globl _S0_R_FIFO
                                     19 	.globl _S0_T_FIFO
                                     20 	.globl _S0_FREE
                                     21 	.globl _S0_IF_BYTE
                                     22 	.globl _S0_IF_FIRST
                                     23 	.globl _S0_IF_OV
                                     24 	.globl _S0_FST_ACT
                                     25 	.globl _CP_RL2
                                     26 	.globl _C_T2
                                     27 	.globl _TR2
                                     28 	.globl _EXEN2
                                     29 	.globl _TCLK
                                     30 	.globl _RCLK
                                     31 	.globl _EXF2
                                     32 	.globl _CAP1F
                                     33 	.globl _TF2
                                     34 	.globl _RI
                                     35 	.globl _TI
                                     36 	.globl _RB8
                                     37 	.globl _TB8
                                     38 	.globl _REN
                                     39 	.globl _SM2
                                     40 	.globl _SM1
                                     41 	.globl _SM0
                                     42 	.globl _IT0
                                     43 	.globl _IE0
                                     44 	.globl _IT1
                                     45 	.globl _IE1
                                     46 	.globl _TR0
                                     47 	.globl _TF0
                                     48 	.globl _TR1
                                     49 	.globl _TF1
                                     50 	.globl _P4_0
                                     51 	.globl _P4_1
                                     52 	.globl _P4_2
                                     53 	.globl _P4_3
                                     54 	.globl _P4_4
                                     55 	.globl _P4_5
                                     56 	.globl _P4_6
                                     57 	.globl _RXD
                                     58 	.globl _TXD
                                     59 	.globl _INT0
                                     60 	.globl _INT1
                                     61 	.globl _T0
                                     62 	.globl _T1
                                     63 	.globl _MOSI1
                                     64 	.globl _MISO1
                                     65 	.globl _SCK1
                                     66 	.globl _P3_0
                                     67 	.globl _P3_1
                                     68 	.globl _P3_2
                                     69 	.globl _P3_3
                                     70 	.globl _P3_4
                                     71 	.globl _P3_5
                                     72 	.globl _P3_6
                                     73 	.globl _P3_7
                                     74 	.globl _CAP1_
                                     75 	.globl _T2_
                                     76 	.globl _CAP2_
                                     77 	.globl _T2EX_
                                     78 	.globl _RXD1
                                     79 	.globl _TXD1
                                     80 	.globl _P2_0
                                     81 	.globl _P2_1
                                     82 	.globl _P2_2
                                     83 	.globl _P2_3
                                     84 	.globl _P2_4
                                     85 	.globl _P2_5
                                     86 	.globl _P2_6
                                     87 	.globl _P2_7
                                     88 	.globl _AIN0
                                     89 	.globl _AIN1
                                     90 	.globl _AIN2
                                     91 	.globl _AIN3
                                     92 	.globl _AIN4
                                     93 	.globl _AIN5
                                     94 	.globl _AIN6
                                     95 	.globl _AIN7
                                     96 	.globl _CAP1
                                     97 	.globl _T2
                                     98 	.globl _CAP2
                                     99 	.globl _T2EX
                                    100 	.globl _INT0_
                                    101 	.globl _SCS
                                    102 	.globl _MOSI
                                    103 	.globl _MISO
                                    104 	.globl _SCK
                                    105 	.globl _RXD1_
                                    106 	.globl _TXD1_
                                    107 	.globl _P1_0
                                    108 	.globl _P1_1
                                    109 	.globl _P1_2
                                    110 	.globl _P1_3
                                    111 	.globl _P1_4
                                    112 	.globl _P1_5
                                    113 	.globl _P1_6
                                    114 	.globl _P1_7
                                    115 	.globl _AIN8
                                    116 	.globl _AIN9
                                    117 	.globl _AIN10
                                    118 	.globl _AIN11
                                    119 	.globl _AIN12
                                    120 	.globl _AIN13
                                    121 	.globl _RXD_
                                    122 	.globl _TXD_
                                    123 	.globl _SCL0
                                    124 	.globl _SDA0
                                    125 	.globl _P0_0
                                    126 	.globl _P0_1
                                    127 	.globl _P0_2
                                    128 	.globl _P0_3
                                    129 	.globl _P0_4
                                    130 	.globl _P0_5
                                    131 	.globl _P0_6
                                    132 	.globl _P0_7
                                    133 	.globl _IE_SPI0
                                    134 	.globl _IE_USB
                                    135 	.globl _IE_ADC
                                    136 	.globl _IE_UART1
                                    137 	.globl _IE_PWM_I2C
                                    138 	.globl _IE_GPIO
                                    139 	.globl _IE_WDOG
                                    140 	.globl _PX0
                                    141 	.globl _PT0
                                    142 	.globl _PX1
                                    143 	.globl _PT1
                                    144 	.globl _PS
                                    145 	.globl _PT2
                                    146 	.globl _PL_FLAG
                                    147 	.globl _PH_FLAG
                                    148 	.globl _EX0
                                    149 	.globl _ET0
                                    150 	.globl _EX1
                                    151 	.globl _ET1
                                    152 	.globl _ES
                                    153 	.globl _ET2
                                    154 	.globl _E_DIS
                                    155 	.globl _EA
                                    156 	.globl _P
                                    157 	.globl _F1
                                    158 	.globl _OV
                                    159 	.globl _RS0
                                    160 	.globl _RS1
                                    161 	.globl _F0
                                    162 	.globl _AC
                                    163 	.globl _CY
                                    164 	.globl _I2CS_INT_ST
                                    165 	.globl _I2CX_INT
                                    166 	.globl _LED_STATUS
                                    167 	.globl _LED_DMA_H
                                    168 	.globl _LED_DMA_L
                                    169 	.globl _LED_DMA
                                    170 	.globl _LED_PWM_OE
                                    171 	.globl _LED_COMMON
                                    172 	.globl _ADC_CHAN
                                    173 	.globl _ADC_DAT_H
                                    174 	.globl _ADC_DAT_L
                                    175 	.globl _ADC_DAT
                                    176 	.globl _ADC_CTRL
                                    177 	.globl _SPI1_CK_SE
                                    178 	.globl _SPI1_CTRL
                                    179 	.globl _SPI1_DATA
                                    180 	.globl _SPI1_STAT
                                    181 	.globl _SIF1
                                    182 	.globl _SBAUD1
                                    183 	.globl _SBUF1
                                    184 	.globl _SCON1
                                    185 	.globl _SPI0_SETUP
                                    186 	.globl _SPI0_CK_SE
                                    187 	.globl _SPI0_CTRL
                                    188 	.globl _SPI0_DATA
                                    189 	.globl _SPI0_STAT
                                    190 	.globl _T2CAP1H
                                    191 	.globl _T2CAP1L
                                    192 	.globl _T2CAP1
                                    193 	.globl _TH2
                                    194 	.globl _TL2
                                    195 	.globl _T2COUNT
                                    196 	.globl _RCAP2H
                                    197 	.globl _RCAP2L
                                    198 	.globl _RCAP2
                                    199 	.globl _T2MOD
                                    200 	.globl _T2CON
                                    201 	.globl _SBUF
                                    202 	.globl _SCON
                                    203 	.globl _TH1
                                    204 	.globl _TH0
                                    205 	.globl _TL1
                                    206 	.globl _TL0
                                    207 	.globl _TMOD
                                    208 	.globl _TCON
                                    209 	.globl _XBUS_AUX
                                    210 	.globl _P7
                                    211 	.globl _P6_DIR
                                    212 	.globl _P6_OUT_PU
                                    213 	.globl _P6_IN
                                    214 	.globl _P5_DIR
                                    215 	.globl _P5_OUT_PU
                                    216 	.globl _P5_IN
                                    217 	.globl _P4_LED_KEY
                                    218 	.globl _P4_DIR_PU
                                    219 	.globl _P4_MOD_OC
                                    220 	.globl _P4
                                    221 	.globl _P3_DIR_PU
                                    222 	.globl _P3_MOD_OC
                                    223 	.globl _P3
                                    224 	.globl _P2_DIR_PU
                                    225 	.globl _P2_MOD_OC
                                    226 	.globl _P2
                                    227 	.globl _P1_DIR_PU
                                    228 	.globl _P1_MOD_OC
                                    229 	.globl _P1
                                    230 	.globl _P0_DIR_PU
                                    231 	.globl _P0_MOD_OC
                                    232 	.globl _P0
                                    233 	.globl _ROM_CTRL
                                    234 	.globl _ROM_DATA_HH
                                    235 	.globl _ROM_DATA_HL
                                    236 	.globl _ROM_DATA_HI
                                    237 	.globl _ROM_ADDR_H
                                    238 	.globl _ROM_ADDR_L
                                    239 	.globl _ROM_ADDR
                                    240 	.globl _GPIO_IE
                                    241 	.globl _IP_EX
                                    242 	.globl _IE_EX
                                    243 	.globl _IP
                                    244 	.globl _IE
                                    245 	.globl _WDOG_COUNT
                                    246 	.globl _RESET_KEEP
                                    247 	.globl _WAKE_CTRL
                                    248 	.globl _CLOCK_CFG
                                    249 	.globl _POWER_CFG
                                    250 	.globl _PCON
                                    251 	.globl _GLOBAL_CFG
                                    252 	.globl _SAFE_MOD
                                    253 	.globl _DPH
                                    254 	.globl _DPL
                                    255 	.globl _SP
                                    256 	.globl _A_INV
                                    257 	.globl _B
                                    258 	.globl _ACC
                                    259 	.globl _PSW
                                    260 	.globl _ak820_autoshift_before
                                    261 	.globl _ak820_autoshift_process
                                    262 	.globl _ak820_autoshift_cancel
                                    263 ;--------------------------------------------------------
                                    264 ; special function registers
                                    265 ;--------------------------------------------------------
                                    266 	.area RSEG    (ABS,DATA)
      000000                        267 	.org 0x0000
                           0000D0   268 _PSW	=	0x00d0
                           0000E0   269 _ACC	=	0x00e0
                           0000F0   270 _B	=	0x00f0
                           0000FD   271 _A_INV	=	0x00fd
                           000081   272 _SP	=	0x0081
                           000082   273 _DPL	=	0x0082
                           000083   274 _DPH	=	0x0083
                           0000A1   275 _SAFE_MOD	=	0x00a1
                           0000B1   276 _GLOBAL_CFG	=	0x00b1
                           000087   277 _PCON	=	0x0087
                           0000BA   278 _POWER_CFG	=	0x00ba
                           0000B9   279 _CLOCK_CFG	=	0x00b9
                           0000A9   280 _WAKE_CTRL	=	0x00a9
                           0000FE   281 _RESET_KEEP	=	0x00fe
                           0000FF   282 _WDOG_COUNT	=	0x00ff
                           0000A8   283 _IE	=	0x00a8
                           0000B8   284 _IP	=	0x00b8
                           0000E8   285 _IE_EX	=	0x00e8
                           0000E9   286 _IP_EX	=	0x00e9
                           0000B2   287 _GPIO_IE	=	0x00b2
                           008584   288 _ROM_ADDR	=	0x8584
                           000084   289 _ROM_ADDR_L	=	0x0084
                           000085   290 _ROM_ADDR_H	=	0x0085
                           008F8E   291 _ROM_DATA_HI	=	0x8f8e
                           00008E   292 _ROM_DATA_HL	=	0x008e
                           00008F   293 _ROM_DATA_HH	=	0x008f
                           000086   294 _ROM_CTRL	=	0x0086
                           000080   295 _P0	=	0x0080
                           0000C4   296 _P0_MOD_OC	=	0x00c4
                           0000C5   297 _P0_DIR_PU	=	0x00c5
                           000090   298 _P1	=	0x0090
                           000092   299 _P1_MOD_OC	=	0x0092
                           000093   300 _P1_DIR_PU	=	0x0093
                           0000A0   301 _P2	=	0x00a0
                           000094   302 _P2_MOD_OC	=	0x0094
                           000095   303 _P2_DIR_PU	=	0x0095
                           0000B0   304 _P3	=	0x00b0
                           000096   305 _P3_MOD_OC	=	0x0096
                           000097   306 _P3_DIR_PU	=	0x0097
                           0000C0   307 _P4	=	0x00c0
                           0000C2   308 _P4_MOD_OC	=	0x00c2
                           0000C3   309 _P4_DIR_PU	=	0x00c3
                           0000C1   310 _P4_LED_KEY	=	0x00c1
                           0000AA   311 _P5_IN	=	0x00aa
                           0000AB   312 _P5_OUT_PU	=	0x00ab
                           0000AC   313 _P5_DIR	=	0x00ac
                           0000AD   314 _P6_IN	=	0x00ad
                           0000AE   315 _P6_OUT_PU	=	0x00ae
                           0000AF   316 _P6_DIR	=	0x00af
                           0000F1   317 _P7	=	0x00f1
                           0000A2   318 _XBUS_AUX	=	0x00a2
                           000088   319 _TCON	=	0x0088
                           000089   320 _TMOD	=	0x0089
                           00008A   321 _TL0	=	0x008a
                           00008B   322 _TL1	=	0x008b
                           00008C   323 _TH0	=	0x008c
                           00008D   324 _TH1	=	0x008d
                           000098   325 _SCON	=	0x0098
                           000099   326 _SBUF	=	0x0099
                           0000C8   327 _T2CON	=	0x00c8
                           0000C9   328 _T2MOD	=	0x00c9
                           00CBCA   329 _RCAP2	=	0xcbca
                           0000CA   330 _RCAP2L	=	0x00ca
                           0000CB   331 _RCAP2H	=	0x00cb
                           00CDCC   332 _T2COUNT	=	0xcdcc
                           0000CC   333 _TL2	=	0x00cc
                           0000CD   334 _TH2	=	0x00cd
                           00CFCE   335 _T2CAP1	=	0xcfce
                           0000CE   336 _T2CAP1L	=	0x00ce
                           0000CF   337 _T2CAP1H	=	0x00cf
                           0000F8   338 _SPI0_STAT	=	0x00f8
                           0000F9   339 _SPI0_DATA	=	0x00f9
                           0000FA   340 _SPI0_CTRL	=	0x00fa
                           0000FB   341 _SPI0_CK_SE	=	0x00fb
                           0000FC   342 _SPI0_SETUP	=	0x00fc
                           0000BC   343 _SCON1	=	0x00bc
                           0000BD   344 _SBUF1	=	0x00bd
                           0000BE   345 _SBAUD1	=	0x00be
                           0000BF   346 _SIF1	=	0x00bf
                           0000B4   347 _SPI1_STAT	=	0x00b4
                           0000B5   348 _SPI1_DATA	=	0x00b5
                           0000B6   349 _SPI1_CTRL	=	0x00b6
                           0000B7   350 _SPI1_CK_SE	=	0x00b7
                           0000F3   351 _ADC_CTRL	=	0x00f3
                           00F5F4   352 _ADC_DAT	=	0xf5f4
                           0000F4   353 _ADC_DAT_L	=	0x00f4
                           0000F5   354 _ADC_DAT_H	=	0x00f5
                           0000F6   355 _ADC_CHAN	=	0x00f6
                           0000A6   356 _LED_COMMON	=	0x00a6
                           0000A7   357 _LED_PWM_OE	=	0x00a7
                           00C7C6   358 _LED_DMA	=	0xc7c6
                           0000C6   359 _LED_DMA_L	=	0x00c6
                           0000C7   360 _LED_DMA_H	=	0x00c7
                           0000F7   361 _LED_STATUS	=	0x00f7
                           0000B3   362 _I2CX_INT	=	0x00b3
                           0000BB   363 _I2CS_INT_ST	=	0x00bb
                                    364 ;--------------------------------------------------------
                                    365 ; special function bits
                                    366 ;--------------------------------------------------------
                                    367 	.area RSEG    (ABS,DATA)
      000000                        368 	.org 0x0000
                           0000D7   369 _CY	=	0x00d7
                           0000D6   370 _AC	=	0x00d6
                           0000D5   371 _F0	=	0x00d5
                           0000D4   372 _RS1	=	0x00d4
                           0000D3   373 _RS0	=	0x00d3
                           0000D2   374 _OV	=	0x00d2
                           0000D1   375 _F1	=	0x00d1
                           0000D0   376 _P	=	0x00d0
                           0000AF   377 _EA	=	0x00af
                           0000AE   378 _E_DIS	=	0x00ae
                           0000AD   379 _ET2	=	0x00ad
                           0000AC   380 _ES	=	0x00ac
                           0000AB   381 _ET1	=	0x00ab
                           0000AA   382 _EX1	=	0x00aa
                           0000A9   383 _ET0	=	0x00a9
                           0000A8   384 _EX0	=	0x00a8
                           0000BF   385 _PH_FLAG	=	0x00bf
                           0000BE   386 _PL_FLAG	=	0x00be
                           0000BD   387 _PT2	=	0x00bd
                           0000BC   388 _PS	=	0x00bc
                           0000BB   389 _PT1	=	0x00bb
                           0000BA   390 _PX1	=	0x00ba
                           0000B9   391 _PT0	=	0x00b9
                           0000B8   392 _PX0	=	0x00b8
                           0000EF   393 _IE_WDOG	=	0x00ef
                           0000EE   394 _IE_GPIO	=	0x00ee
                           0000ED   395 _IE_PWM_I2C	=	0x00ed
                           0000EC   396 _IE_UART1	=	0x00ec
                           0000EB   397 _IE_ADC	=	0x00eb
                           0000E9   398 _IE_USB	=	0x00e9
                           0000E8   399 _IE_SPI0	=	0x00e8
                           000087   400 _P0_7	=	0x0087
                           000086   401 _P0_6	=	0x0086
                           000085   402 _P0_5	=	0x0085
                           000084   403 _P0_4	=	0x0084
                           000083   404 _P0_3	=	0x0083
                           000082   405 _P0_2	=	0x0082
                           000081   406 _P0_1	=	0x0081
                           000080   407 _P0_0	=	0x0080
                           000081   408 _SDA0	=	0x0081
                           000080   409 _SCL0	=	0x0080
                           000083   410 _TXD_	=	0x0083
                           000082   411 _RXD_	=	0x0082
                           000085   412 _AIN13	=	0x0085
                           000084   413 _AIN12	=	0x0084
                           000083   414 _AIN11	=	0x0083
                           000082   415 _AIN10	=	0x0082
                           000081   416 _AIN9	=	0x0081
                           000080   417 _AIN8	=	0x0080
                           000097   418 _P1_7	=	0x0097
                           000096   419 _P1_6	=	0x0096
                           000095   420 _P1_5	=	0x0095
                           000094   421 _P1_4	=	0x0094
                           000093   422 _P1_3	=	0x0093
                           000092   423 _P1_2	=	0x0092
                           000091   424 _P1_1	=	0x0091
                           000090   425 _P1_0	=	0x0090
                           000097   426 _TXD1_	=	0x0097
                           000096   427 _RXD1_	=	0x0096
                           000097   428 _SCK	=	0x0097
                           000096   429 _MISO	=	0x0096
                           000095   430 _MOSI	=	0x0095
                           000094   431 _SCS	=	0x0094
                           000092   432 _INT0_	=	0x0092
                           000091   433 _T2EX	=	0x0091
                           000091   434 _CAP2	=	0x0091
                           000090   435 _T2	=	0x0090
                           000090   436 _CAP1	=	0x0090
                           000097   437 _AIN7	=	0x0097
                           000096   438 _AIN6	=	0x0096
                           000095   439 _AIN5	=	0x0095
                           000094   440 _AIN4	=	0x0094
                           000093   441 _AIN3	=	0x0093
                           000092   442 _AIN2	=	0x0092
                           000091   443 _AIN1	=	0x0091
                           000090   444 _AIN0	=	0x0090
                           0000A7   445 _P2_7	=	0x00a7
                           0000A6   446 _P2_6	=	0x00a6
                           0000A5   447 _P2_5	=	0x00a5
                           0000A4   448 _P2_4	=	0x00a4
                           0000A3   449 _P2_3	=	0x00a3
                           0000A2   450 _P2_2	=	0x00a2
                           0000A1   451 _P2_1	=	0x00a1
                           0000A0   452 _P2_0	=	0x00a0
                           0000A7   453 _TXD1	=	0x00a7
                           0000A6   454 _RXD1	=	0x00a6
                           0000A5   455 _T2EX_	=	0x00a5
                           0000A5   456 _CAP2_	=	0x00a5
                           0000A4   457 _T2_	=	0x00a4
                           0000A4   458 _CAP1_	=	0x00a4
                           0000B7   459 _P3_7	=	0x00b7
                           0000B6   460 _P3_6	=	0x00b6
                           0000B5   461 _P3_5	=	0x00b5
                           0000B4   462 _P3_4	=	0x00b4
                           0000B3   463 _P3_3	=	0x00b3
                           0000B2   464 _P3_2	=	0x00b2
                           0000B1   465 _P3_1	=	0x00b1
                           0000B0   466 _P3_0	=	0x00b0
                           0000B7   467 _SCK1	=	0x00b7
                           0000B6   468 _MISO1	=	0x00b6
                           0000B5   469 _MOSI1	=	0x00b5
                           0000B5   470 _T1	=	0x00b5
                           0000B4   471 _T0	=	0x00b4
                           0000B3   472 _INT1	=	0x00b3
                           0000B2   473 _INT0	=	0x00b2
                           0000B1   474 _TXD	=	0x00b1
                           0000B0   475 _RXD	=	0x00b0
                           0000C6   476 _P4_6	=	0x00c6
                           0000C5   477 _P4_5	=	0x00c5
                           0000C4   478 _P4_4	=	0x00c4
                           0000C3   479 _P4_3	=	0x00c3
                           0000C2   480 _P4_2	=	0x00c2
                           0000C1   481 _P4_1	=	0x00c1
                           0000C0   482 _P4_0	=	0x00c0
                           00008F   483 _TF1	=	0x008f
                           00008E   484 _TR1	=	0x008e
                           00008D   485 _TF0	=	0x008d
                           00008C   486 _TR0	=	0x008c
                           00008B   487 _IE1	=	0x008b
                           00008A   488 _IT1	=	0x008a
                           000089   489 _IE0	=	0x0089
                           000088   490 _IT0	=	0x0088
                           00009F   491 _SM0	=	0x009f
                           00009E   492 _SM1	=	0x009e
                           00009D   493 _SM2	=	0x009d
                           00009C   494 _REN	=	0x009c
                           00009B   495 _TB8	=	0x009b
                           00009A   496 _RB8	=	0x009a
                           000099   497 _TI	=	0x0099
                           000098   498 _RI	=	0x0098
                           0000CF   499 _TF2	=	0x00cf
                           0000CF   500 _CAP1F	=	0x00cf
                           0000CE   501 _EXF2	=	0x00ce
                           0000CD   502 _RCLK	=	0x00cd
                           0000CC   503 _TCLK	=	0x00cc
                           0000CB   504 _EXEN2	=	0x00cb
                           0000CA   505 _TR2	=	0x00ca
                           0000C9   506 _C_T2	=	0x00c9
                           0000C8   507 _CP_RL2	=	0x00c8
                           0000FF   508 _S0_FST_ACT	=	0x00ff
                           0000FE   509 _S0_IF_OV	=	0x00fe
                           0000FD   510 _S0_IF_FIRST	=	0x00fd
                           0000FC   511 _S0_IF_BYTE	=	0x00fc
                           0000FB   512 _S0_FREE	=	0x00fb
                           0000FA   513 _S0_T_FIFO	=	0x00fa
                           0000F8   514 _S0_R_FIFO	=	0x00f8
                           0000F7   515 _ADC_START	=	0x00f7
                                    516 ;--------------------------------------------------------
                                    517 ; overlayable register banks
                                    518 ;--------------------------------------------------------
                                    519 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        520 	.ds 8
                                    521 ;--------------------------------------------------------
                                    522 ; internal ram data
                                    523 ;--------------------------------------------------------
                                    524 	.area DSEG    (DATA)
                                    525 ;--------------------------------------------------------
                                    526 ; overlayable items in internal ram
                                    527 ;--------------------------------------------------------
                                    528 ;--------------------------------------------------------
                                    529 ; indirectly addressable internal ram data
                                    530 ;--------------------------------------------------------
                                    531 	.area ISEG    (DATA)
                                    532 ;--------------------------------------------------------
                                    533 ; absolute internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area IABS    (ABS,DATA)
                                    536 	.area IABS    (ABS,DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; bit data
                                    539 ;--------------------------------------------------------
                                    540 	.area BSEG    (BIT)
      000000                        541 _ak820_autoshift_process_sloc0_1_0:
      000000                        542 	.ds 1
                                    543 ;--------------------------------------------------------
                                    544 ; paged external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area PSEG    (PAG,XDATA)
                                    547 ;--------------------------------------------------------
                                    548 ; uninitialized external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area XSEG    (XDATA)
      000400                        551 _as_saved:
      000400                        552 	.ds 9
      000409                        553 _as_state:
      000409                        554 	.ds 1
      00040A                        555 _as_emit_shifted_10000_591:
      00040A                        556 	.ds 1
      00040B                        557 _ak820_autoshift_before_event_10000_594:
      00040B                        558 	.ds 2
      00040D                        559 _ak820_autoshift_before_state_50001_608:
      00040D                        560 	.ds 1
      00040E                        561 _ak820_autoshift_process_record_10000_612:
      00040E                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; absolute external ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area XABS    (ABS,XDATA)
                                    567 ;--------------------------------------------------------
                                    568 ; initialized external ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area XISEG   (XDATA)
      000DAC                        571 _as_enabled:
      000DAC                        572 	.ds 1
                                    573 	.area HOME    (CODE)
                                    574 	.area GSINIT0 (CODE)
                                    575 	.area GSINIT1 (CODE)
                                    576 	.area GSINIT2 (CODE)
                                    577 	.area GSINIT3 (CODE)
                                    578 	.area GSINIT4 (CODE)
                                    579 	.area GSINIT5 (CODE)
                                    580 	.area GSINIT  (CODE)
                                    581 	.area GSFINAL (CODE)
                                    582 	.area CSEG    (CODE)
                                    583 ;--------------------------------------------------------
                                    584 ; global & static initialisations
                                    585 ;--------------------------------------------------------
                                    586 	.area HOME    (CODE)
                                    587 	.area GSINIT  (CODE)
                                    588 	.area GSFINAL (CODE)
                                    589 	.area GSINIT  (CODE)
                                    590 ;--------------------------------------------------------
                                    591 ; Home
                                    592 ;--------------------------------------------------------
                                    593 	.area HOME    (CODE)
                                    594 	.area HOME    (CODE)
                                    595 ;--------------------------------------------------------
                                    596 ; code
                                    597 ;--------------------------------------------------------
                                    598 	.area CSEG    (CODE)
                                    599 ;------------------------------------------------------------
                                    600 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    601 ;------------------------------------------------------------
                                    602 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    603 ;------------------------------------------------------------
                                    604 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    605 ;	-----------------------------------------
                           000007   606 	ar7 = 0x07
                           000006   607 	ar6 = 0x06
                           000005   608 	ar5 = 0x05
                           000004   609 	ar4 = 0x04
                           000003   610 	ar3 = 0x03
                           000002   611 	ar2 = 0x02
                           000001   612 	ar1 = 0x01
                           000000   613 	ar0 = 0x00
                                    614 ;	 function as_emit
                                    615 ;	-----------------------------------------
      003105                        616 _as_emit:
      003105 E5 82            [12]  617 	mov	a,dpl
      003107 90 04 0A         [24]  618 	mov	dptr,#_as_emit_shifted_10000_591
      00310A F0               [24]  619 	movx	@dptr,a
                                    620 ;	keyboards/ajazz/ak820/ak820_autoshift.c:19: as_state = shifted ? 3 : 2;
      00310B E0               [24]  621 	movx	a,@dptr
      00310C FF               [12]  622 	mov	r7,a
      00310D E0               [24]  623 	movx	a,@dptr
      00310E 60 04            [24]  624 	jz	00105$
      003110 7E 03            [12]  625 	mov	r6,#0x03
      003112 80 02            [24]  626 	sjmp	00106$
      003114                        627 00105$:
      003114 7E 02            [12]  628 	mov	r6,#0x02
      003116                        629 00106$:
      003116 90 04 09         [24]  630 	mov	dptr,#_as_state
      003119 EE               [12]  631 	mov	a,r6
      00311A F0               [24]  632 	movx	@dptr,a
                                    633 ;	keyboards/ajazz/ak820/ak820_autoshift.c:20: if (shifted) add_owned_mods(MOD_BIT(KC_LEFT_SHIFT));
      00311B EF               [12]  634 	mov	a,r7
      00311C 60 06            [24]  635 	jz	00102$
      00311E 75 82 02         [24]  636 	mov	dpl, #0x02
      003121 12 80 B9         [24]  637 	lcall	_add_owned_mods
      003124                        638 00102$:
                                    639 ;	keyboards/ajazz/ak820/ak820_autoshift.c:21: process_record(&as_saved);
      003124 90 04 00         [24]  640 	mov	dptr,#_as_saved
                                    641 ;	keyboards/ajazz/ak820/ak820_autoshift.c:22: }
      003127 02 74 F1         [24]  642 	ljmp	_process_record
                                    643 ;------------------------------------------------------------
                                    644 ;Allocation info for local variables in function 'ak820_autoshift_before'
                                    645 ;------------------------------------------------------------
                                    646 ;event         Allocated with name '_ak820_autoshift_before_event_10000_594'
                                    647 ;state         Allocated with name '_ak820_autoshift_before_state_50001_608'
                                    648 ;------------------------------------------------------------
                                    649 ;	keyboards/ajazz/ak820/ak820_autoshift.c:23: bool ak820_autoshift_before(const keyevent_t AK820_STATE_MEM *event) {
                                    650 ;	-----------------------------------------
                                    651 ;	 function ak820_autoshift_before
                                    652 ;	-----------------------------------------
      00312A                        653 _ak820_autoshift_before:
      00312A AF 83            [24]  654 	mov	r7,dph
      00312C E5 82            [12]  655 	mov	a,dpl
      00312E 90 04 0B         [24]  656 	mov	dptr,#_ak820_autoshift_before_event_10000_594
      003131 F0               [24]  657 	movx	@dptr,a
      003132 EF               [12]  658 	mov	a,r7
      003133 A3               [24]  659 	inc	dptr
      003134 F0               [24]  660 	movx	@dptr,a
                                    661 ;	keyboards/ajazz/ak820/ak820_autoshift.c:24: if (!as_state) return true;
      003135 90 04 09         [24]  662 	mov	dptr,#_as_state
      003138 E0               [24]  663 	movx	a,@dptr
      003139 FF               [12]  664 	mov	r7,a
      00313A E0               [24]  665 	movx	a,@dptr
      00313B 70 04            [24]  666 	jnz	00102$
      00313D 75 82 01         [24]  667 	mov	dpl, #0x01
      003140 22               [24]  668 	ret
      003141                        669 00102$:
                                    670 ;	keyboards/ajazz/ak820/ak820_autoshift.c:25: if (as_state == 1 && (uint16_t)(event->time - as_saved.event.time) >= AK820_AUTOSHIFT_TERM) {
      003141 BF 01 3A         [24]  671 	cjne	r7,#0x01,00106$
      003144 90 04 0B         [24]  672 	mov	dptr,#_ak820_autoshift_before_event_10000_594
      003147 E0               [24]  673 	movx	a,@dptr
      003148 FE               [12]  674 	mov	r6,a
      003149 A3               [24]  675 	inc	dptr
      00314A E0               [24]  676 	movx	a,@dptr
      00314B FF               [12]  677 	mov	r7,a
      00314C 8E 82            [24]  678 	mov	dpl,r6
      00314E 8F 83            [24]  679 	mov	dph,r7
      003150 A3               [24]  680 	inc	dptr
      003151 A3               [24]  681 	inc	dptr
      003152 E0               [24]  682 	movx	a,@dptr
      003153 FE               [12]  683 	mov	r6,a
      003154 A3               [24]  684 	inc	dptr
      003155 E0               [24]  685 	movx	a,@dptr
      003156 FF               [12]  686 	mov	r7,a
      003157 90 04 02         [24]  687 	mov	dptr,#(_as_saved + 0x0002)
      00315A E0               [24]  688 	movx	a,@dptr
      00315B FC               [12]  689 	mov	r4,a
      00315C A3               [24]  690 	inc	dptr
      00315D E0               [24]  691 	movx	a,@dptr
      00315E FD               [12]  692 	mov	r5,a
      00315F EE               [12]  693 	mov	a,r6
      003160 C3               [12]  694 	clr	c
      003161 9C               [12]  695 	subb	a,r4
      003162 FE               [12]  696 	mov	r6,a
      003163 EF               [12]  697 	mov	a,r7
      003164 9D               [12]  698 	subb	a,r5
      003165 FF               [12]  699 	mov	r7,a
      003166 C3               [12]  700 	clr	c
      003167 EE               [12]  701 	mov	a,r6
      003168 94 AF            [12]  702 	subb	a,#0xaf
      00316A EF               [12]  703 	mov	a,r7
      00316B 94 00            [12]  704 	subb	a,#0x00
      00316D 40 0F            [24]  705 	jc	00106$
                                    706 ;	keyboards/ajazz/ak820/ak820_autoshift.c:26: as_emit(true);
      00316F 75 82 01         [24]  707 	mov	dpl, #0x01
      003172 12 31 05         [24]  708 	lcall	_as_emit
                                    709 ;	keyboards/ajazz/ak820/ak820_autoshift.c:27: if (!as_state) return false;
      003175 90 04 09         [24]  710 	mov	dptr,#_as_state
      003178 E0               [24]  711 	movx	a,@dptr
      003179 70 03            [24]  712 	jnz	00106$
      00317B F5 82            [12]  713 	mov	dpl,a
      00317D 22               [24]  714 	ret
      00317E                        715 00106$:
                                    716 ;	keyboards/ajazz/ak820/ak820_autoshift.c:29: if (IS_NOEVENT(*event)) return true;
      00317E 90 04 0B         [24]  717 	mov	dptr,#_ak820_autoshift_before_event_10000_594
      003181 E0               [24]  718 	movx	a,@dptr
      003182 FE               [12]  719 	mov	r6,a
      003183 A3               [24]  720 	inc	dptr
      003184 E0               [24]  721 	movx	a,@dptr
      003185 FF               [12]  722 	mov	r7,a
      003186 74 04            [12]  723 	mov	a,#0x04
      003188 2E               [12]  724 	add	a, r6
      003189 FC               [12]  725 	mov	r4,a
      00318A E4               [12]  726 	clr	a
      00318B 3F               [12]  727 	addc	a, r7
      00318C FD               [12]  728 	mov	r5,a
      00318D 8C 82            [24]  729 	mov	dpl,r4
      00318F 8D 83            [24]  730 	mov	dph,r5
      003191 E0               [24]  731 	movx	a,@dptr
      003192 70 04            [24]  732 	jnz	00109$
      003194 75 82 01         [24]  733 	mov	dpl, #0x01
      003197 22               [24]  734 	ret
      003198                        735 00109$:
                                    736 ;	keyboards/ajazz/ak820/ak820_autoshift.c:30: if (event->key.row == as_saved.event.key.row && event->key.col == as_saved.event.key.col) {
      003198 8E 82            [24]  737 	mov	dpl,r6
      00319A 8F 83            [24]  738 	mov	dph,r7
      00319C A3               [24]  739 	inc	dptr
      00319D E0               [24]  740 	movx	a,@dptr
      00319E FD               [12]  741 	mov	r5,a
      00319F 90 04 01         [24]  742 	mov	dptr,#(_as_saved + 0x0001)
      0031A2 E0               [24]  743 	movx	a,@dptr
      0031A3 FC               [12]  744 	mov	r4,a
      0031A4 ED               [12]  745 	mov	a,r5
      0031A5 B5 04 60         [24]  746 	cjne	a,ar4,00119$
      0031A8 8E 82            [24]  747 	mov	dpl,r6
      0031AA 8F 83            [24]  748 	mov	dph,r7
      0031AC E0               [24]  749 	movx	a,@dptr
      0031AD FD               [12]  750 	mov	r5,a
      0031AE 90 04 00         [24]  751 	mov	dptr,#_as_saved
      0031B1 E0               [24]  752 	movx	a,@dptr
      0031B2 FC               [12]  753 	mov	r4,a
      0031B3 ED               [12]  754 	mov	a,r5
      0031B4 B5 04 51         [24]  755 	cjne	a,ar4,00119$
                                    756 ;	keyboards/ajazz/ak820/ak820_autoshift.c:31: if (!event->pressed) {
      0031B7 74 05            [12]  757 	mov	a,#0x05
      0031B9 2E               [12]  758 	add	a, r6
      0031BA FE               [12]  759 	mov	r6,a
      0031BB E4               [12]  760 	clr	a
      0031BC 3F               [12]  761 	addc	a, r7
      0031BD FF               [12]  762 	mov	r7,a
      0031BE 8E 82            [24]  763 	mov	dpl,r6
      0031C0 8F 83            [24]  764 	mov	dph,r7
      0031C2 E0               [24]  765 	movx	a,@dptr
      0031C3 70 3F            [24]  766 	jnz	00117$
                                    767 ;	keyboards/ajazz/ak820/ak820_autoshift.c:32: if (as_state == 1) {
      0031C5 90 04 09         [24]  768 	mov	dptr,#_as_state
      0031C8 E0               [24]  769 	movx	a,@dptr
      0031C9 FF               [12]  770 	mov	r7,a
      0031CA BF 01 0F         [24]  771 	cjne	r7,#0x01,00113$
                                    772 ;	keyboards/ajazz/ak820/ak820_autoshift.c:33: as_emit(false);
      0031CD 75 82 00         [24]  773 	mov	dpl, #0x00
      0031D0 12 31 05         [24]  774 	lcall	_as_emit
                                    775 ;	keyboards/ajazz/ak820/ak820_autoshift.c:34: if (!as_state) return false;
      0031D3 90 04 09         [24]  776 	mov	dptr,#_as_state
      0031D6 E0               [24]  777 	movx	a,@dptr
      0031D7 70 03            [24]  778 	jnz	00113$
      0031D9 F5 82            [12]  779 	mov	dpl,a
      0031DB 22               [24]  780 	ret
      0031DC                        781 00113$:
                                    782 ;	keyboards/ajazz/ak820/ak820_autoshift.c:36: uint8_t state = as_state;
      0031DC 90 04 09         [24]  783 	mov	dptr,#_as_state
      0031DF E0               [24]  784 	movx	a,@dptr
      0031E0 90 04 0D         [24]  785 	mov	dptr,#_ak820_autoshift_before_state_50001_608
      0031E3 F0               [24]  786 	movx	@dptr,a
                                    787 ;	keyboards/ajazz/ak820/ak820_autoshift.c:37: as_state = 0;
      0031E4 90 04 09         [24]  788 	mov	dptr,#_as_state
      0031E7 E4               [12]  789 	clr	a
      0031E8 F0               [24]  790 	movx	@dptr,a
                                    791 ;	keyboards/ajazz/ak820/ak820_autoshift.c:38: as_saved.event.pressed = false;
      0031E9 90 04 05         [24]  792 	mov	dptr,#(_as_saved + 0x0005)
      0031EC F0               [24]  793 	movx	@dptr,a
                                    794 ;	keyboards/ajazz/ak820/ak820_autoshift.c:39: process_record(&as_saved);
      0031ED 90 04 00         [24]  795 	mov	dptr,#_as_saved
      0031F0 12 74 F1         [24]  796 	lcall	_process_record
                                    797 ;	keyboards/ajazz/ak820/ak820_autoshift.c:40: if (state == 3) {
      0031F3 90 04 0D         [24]  798 	mov	dptr,#_ak820_autoshift_before_state_50001_608
      0031F6 E0               [24]  799 	movx	a,@dptr
      0031F7 FF               [12]  800 	mov	r7,a
      0031F8 BF 03 09         [24]  801 	cjne	r7,#0x03,00117$
                                    802 ;	keyboards/ajazz/ak820/ak820_autoshift.c:41: del_owned_mods(MOD_BIT(KC_LEFT_SHIFT));
      0031FB 75 82 02         [24]  803 	mov	dpl, #0x02
      0031FE 12 80 C9         [24]  804 	lcall	_del_owned_mods
                                    805 ;	keyboards/ajazz/ak820/ak820_autoshift.c:42: send_keyboard_report();
      003201 12 83 F1         [24]  806 	lcall	_send_keyboard_report
      003204                        807 00117$:
                                    808 ;	keyboards/ajazz/ak820/ak820_autoshift.c:45: return false;
      003204 75 82 00         [24]  809 	mov	dpl, #0x00
      003207 22               [24]  810 	ret
      003208                        811 00119$:
                                    812 ;	keyboards/ajazz/ak820/ak820_autoshift.c:47: if (as_state == 1 && event->pressed) as_emit(false);
      003208 90 04 09         [24]  813 	mov	dptr,#_as_state
      00320B E0               [24]  814 	movx	a,@dptr
      00320C FF               [12]  815 	mov	r7,a
      00320D BF 01 1C         [24]  816 	cjne	r7,#0x01,00122$
      003210 90 04 0B         [24]  817 	mov	dptr,#_ak820_autoshift_before_event_10000_594
      003213 E0               [24]  818 	movx	a,@dptr
      003214 FE               [12]  819 	mov	r6,a
      003215 A3               [24]  820 	inc	dptr
      003216 E0               [24]  821 	movx	a,@dptr
      003217 FF               [12]  822 	mov	r7,a
      003218 74 05            [12]  823 	mov	a,#0x05
      00321A 2E               [12]  824 	add	a, r6
      00321B FE               [12]  825 	mov	r6,a
      00321C E4               [12]  826 	clr	a
      00321D 3F               [12]  827 	addc	a, r7
      00321E FF               [12]  828 	mov	r7,a
      00321F 8E 82            [24]  829 	mov	dpl,r6
      003221 8F 83            [24]  830 	mov	dph,r7
      003223 E0               [24]  831 	movx	a,@dptr
      003224 60 06            [24]  832 	jz	00122$
      003226 75 82 00         [24]  833 	mov	dpl, #0x00
      003229 12 31 05         [24]  834 	lcall	_as_emit
      00322C                        835 00122$:
                                    836 ;	keyboards/ajazz/ak820/ak820_autoshift.c:48: return true;
      00322C 75 82 01         [24]  837 	mov	dpl, #0x01
                                    838 ;	keyboards/ajazz/ak820/ak820_autoshift.c:49: }
      00322F 22               [24]  839 	ret
                                    840 ;------------------------------------------------------------
                                    841 ;Allocation info for local variables in function 'ak820_autoshift_process'
                                    842 ;------------------------------------------------------------
                                    843 ;record        Allocated with name '_ak820_autoshift_process_record_10000_612'
                                    844 ;code          Allocated with name '_ak820_autoshift_process_code_10000_613'
                                    845 ;------------------------------------------------------------
                                    846 ;	keyboards/ajazz/ak820/ak820_autoshift.c:50: bool ak820_autoshift_process(keyrecord_t AK820_STATE_MEM *record) {
                                    847 ;	-----------------------------------------
                                    848 ;	 function ak820_autoshift_process
                                    849 ;	-----------------------------------------
      003230                        850 _ak820_autoshift_process:
      003230 AF 83            [24]  851 	mov	r7,dph
      003232 E5 82            [12]  852 	mov	a,dpl
      003234 90 04 0E         [24]  853 	mov	dptr,#_ak820_autoshift_process_record_10000_612
      003237 F0               [24]  854 	movx	@dptr,a
      003238 EF               [12]  855 	mov	a,r7
      003239 A3               [24]  856 	inc	dptr
      00323A F0               [24]  857 	movx	@dptr,a
                                    858 ;	keyboards/ajazz/ak820/ak820_autoshift.c:51: uint16_t code = record->keycode;
      00323B 90 04 0E         [24]  859 	mov	dptr,#_ak820_autoshift_process_record_10000_612
      00323E E0               [24]  860 	movx	a,@dptr
      00323F FE               [12]  861 	mov	r6,a
      003240 A3               [24]  862 	inc	dptr
      003241 E0               [24]  863 	movx	a,@dptr
      003242 FF               [12]  864 	mov	r7,a
      003243 74 07            [12]  865 	mov	a,#0x07
      003245 2E               [12]  866 	add	a, r6
      003246 F5 82            [12]  867 	mov	dpl,a
      003248 E4               [12]  868 	clr	a
      003249 3F               [12]  869 	addc	a, r7
      00324A F5 83            [12]  870 	mov	dph,a
      00324C E0               [24]  871 	movx	a,@dptr
      00324D FC               [12]  872 	mov	r4,a
      00324E A3               [24]  873 	inc	dptr
      00324F E0               [24]  874 	movx	a,@dptr
      003250 FD               [12]  875 	mov	r5,a
                                    876 ;	keyboards/ajazz/ak820/ak820_autoshift.c:52: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) return true;
      003251 8E 82            [24]  877 	mov	dpl,r6
      003253 8F 83            [24]  878 	mov	dph,r7
      003255 A3               [24]  879 	inc	dptr
      003256 E0               [24]  880 	movx	a,@dptr
      003257 FB               [12]  881 	mov	r3,a
      003258 BB 10 00         [24]  882 	cjne	r3,#0x10,00209$
      00325B                        883 00209$:
      00325B 50 0B            [24]  884 	jnc	00101$
      00325D 8E 82            [24]  885 	mov	dpl,r6
      00325F 8F 83            [24]  886 	mov	dph,r7
      003261 E0               [24]  887 	movx	a,@dptr
      003262 FB               [12]  888 	mov	r3,a
      003263 BB 08 00         [24]  889 	cjne	r3,#0x08,00211$
      003266                        890 00211$:
      003266 40 04            [24]  891 	jc	00102$
      003268                        892 00101$:
      003268 75 82 01         [24]  893 	mov	dpl, #0x01
      00326B 22               [24]  894 	ret
      00326C                        895 00102$:
                                    896 ;	keyboards/ajazz/ak820/ak820_autoshift.c:53: if (code >= QK_AUTO_SHIFT_ON && code <= QK_AUTO_SHIFT_TOGGLE) {
      00326C C3               [12]  897 	clr	c
      00326D EC               [12]  898 	mov	a,r4
      00326E 94 13            [12]  899 	subb	a,#0x13
      003270 ED               [12]  900 	mov	a,r5
      003271 94 7C            [12]  901 	subb	a,#0x7c
      003273 40 40            [24]  902 	jc	00107$
      003275 74 15            [12]  903 	mov	a,#0x15
      003277 9C               [12]  904 	subb	a,r4
      003278 74 7C            [12]  905 	mov	a,#0x7c
      00327A 9D               [12]  906 	subb	a,r5
      00327B 40 38            [24]  907 	jc	00107$
                                    908 ;	free result
                                    909 ;	keyboards/ajazz/ak820/ak820_autoshift.c:54: if (record->event.pressed)
      00327D 74 05            [12]  910 	mov	a,#0x05
      00327F 2E               [12]  911 	add	a, r6
      003280 FE               [12]  912 	mov	r6,a
      003281 E4               [12]  913 	clr	a
      003282 3F               [12]  914 	addc	a, r7
      003283 FF               [12]  915 	mov	r7,a
      003284 8E 82            [24]  916 	mov	dpl,r6
      003286 8F 83            [24]  917 	mov	dph,r7
      003288 E0               [24]  918 	movx	a,@dptr
      003289 60 26            [24]  919 	jz	00105$
                                    920 ;	keyboards/ajazz/ak820/ak820_autoshift.c:55: as_enabled = code == QK_AUTO_SHIFT_TOGGLE ? !as_enabled : code == QK_AUTO_SHIFT_ON;
      00328B BC 15 11         [24]  921 	cjne	r4,#0x15,00123$
      00328E BD 7C 0E         [24]  922 	cjne	r5,#0x7c,00123$
      003291 90 0D AC         [24]  923 	mov	dptr,#_as_enabled
      003294 E0               [24]  924 	movx	a,@dptr
      003295 B4 01 00         [24]  925 	cjne	a,#0x01,00218$
      003298                        926 00218$:
      003298 92 00            [24]  927 	mov  _ak820_autoshift_process_sloc0_1_0,c
      00329A E4               [12]  928 	clr	a
      00329B 33               [12]  929 	rlc	a
      00329C FF               [12]  930 	mov	r7,a
      00329D 80 09            [24]  931 	sjmp	00124$
      00329F                        932 00123$:
      00329F E4               [12]  933 	clr	a
      0032A0 BC 13 04         [24]  934 	cjne	r4,#0x13,00219$
      0032A3 BD 7C 01         [24]  935 	cjne	r5,#0x7c,00219$
      0032A6 04               [12]  936 	inc	a
      0032A7                        937 00219$:
      0032A7 FF               [12]  938 	mov	r7,a
      0032A8                        939 00124$:
      0032A8 90 0D AC         [24]  940 	mov	dptr,#_as_enabled
                                    941 ;	assignBit
      0032AB EF               [12]  942 	mov	a,r7
      0032AC 24 FF            [12]  943 	add	a,#0xff
      0032AE E4               [12]  944 	clr	a
      0032AF 33               [12]  945 	rlc	a
      0032B0 F0               [24]  946 	movx	@dptr,a
      0032B1                        947 00105$:
                                    948 ;	keyboards/ajazz/ak820/ak820_autoshift.c:56: return false;
      0032B1 75 82 00         [24]  949 	mov	dpl, #0x00
      0032B4 22               [24]  950 	ret
      0032B5                        951 00107$:
                                    952 ;	keyboards/ajazz/ak820/ak820_autoshift.c:58: if (!as_enabled || as_state || !record->event.pressed || get_mods() || get_weak_mods()) return true;
      0032B5 90 0D AC         [24]  953 	mov	dptr,#_as_enabled
      0032B8 E0               [24]  954 	movx	a,@dptr
      0032B9 60 2A            [24]  955 	jz	00109$
      0032BB 90 04 09         [24]  956 	mov	dptr,#_as_state
      0032BE E0               [24]  957 	movx	a,@dptr
      0032BF 70 24            [24]  958 	jnz	00109$
      0032C1 90 04 0E         [24]  959 	mov	dptr,#_ak820_autoshift_process_record_10000_612
      0032C4 E0               [24]  960 	movx	a,@dptr
      0032C5 FE               [12]  961 	mov	r6,a
      0032C6 A3               [24]  962 	inc	dptr
      0032C7 E0               [24]  963 	movx	a,@dptr
      0032C8 FF               [12]  964 	mov	r7,a
      0032C9 74 05            [12]  965 	mov	a,#0x05
      0032CB 2E               [12]  966 	add	a, r6
      0032CC FE               [12]  967 	mov	r6,a
      0032CD E4               [12]  968 	clr	a
      0032CE 3F               [12]  969 	addc	a, r7
      0032CF FF               [12]  970 	mov	r7,a
      0032D0 8E 82            [24]  971 	mov	dpl,r6
      0032D2 8F 83            [24]  972 	mov	dph,r7
      0032D4 E0               [24]  973 	movx	a,@dptr
      0032D5 60 0E            [24]  974 	jz	00109$
      0032D7 12 84 5C         [24]  975 	lcall	_get_mods
      0032DA E5 82            [12]  976 	mov	a, dpl
      0032DC 70 07            [24]  977 	jnz	00109$
      0032DE 12 84 72         [24]  978 	lcall	_get_weak_mods
      0032E1 E5 82            [12]  979 	mov	a, dpl
      0032E3 60 04            [24]  980 	jz	00110$
      0032E5                        981 00109$:
      0032E5 75 82 01         [24]  982 	mov	dpl, #0x01
      0032E8 22               [24]  983 	ret
      0032E9                        984 00110$:
                                    985 ;	keyboards/ajazz/ak820/ak820_autoshift.c:59: if (!((code >= KC_A && code <= KC_0) ||
      0032E9 C3               [12]  986 	clr	c
      0032EA EC               [12]  987 	mov	a,r4
      0032EB 94 04            [12]  988 	subb	a,#0x04
      0032ED ED               [12]  989 	mov	a,r5
      0032EE 94 00            [12]  990 	subb	a,#0x00
      0032F0 40 07            [24]  991 	jc	00119$
      0032F2 74 27            [12]  992 	mov	a,#0x27
      0032F4 9C               [12]  993 	subb	a,r4
      0032F5 E4               [12]  994 	clr	a
      0032F6 9D               [12]  995 	subb	a,r5
      0032F7 50 1C            [24]  996 	jnc	00116$
                                    997 ;	free result
      0032F9                        998 00119$:
                                    999 ;	keyboards/ajazz/ak820/ak820_autoshift.c:60: (code >= KC_MINUS && code <= KC_SLASH) || code == KC_NONUS_BACKSLASH)) return true;
      0032F9 C3               [12] 1000 	clr	c
      0032FA EC               [12] 1001 	mov	a,r4
      0032FB 94 2D            [12] 1002 	subb	a,#0x2d
      0032FD ED               [12] 1003 	mov	a,r5
      0032FE 94 00            [12] 1004 	subb	a,#0x00
      003300 40 07            [24] 1005 	jc	00120$
      003302 74 38            [12] 1006 	mov	a,#0x38
      003304 9C               [12] 1007 	subb	a,r4
      003305 E4               [12] 1008 	clr	a
      003306 9D               [12] 1009 	subb	a,r5
      003307 50 0C            [24] 1010 	jnc	00116$
                                   1011 ;	free result
      003309                       1012 00120$:
      003309 BC 64 05         [24] 1013 	cjne	r4,#0x64,00230$
      00330C BD 00 02         [24] 1014 	cjne	r5,#0x00,00230$
      00330F 80 04            [24] 1015 	sjmp	00116$
      003311                       1016 00230$:
      003311 75 82 01         [24] 1017 	mov	dpl, #0x01
      003314 22               [24] 1018 	ret
      003315                       1019 00116$:
                                   1020 ;	keyboards/ajazz/ak820/ak820_autoshift.c:61: as_saved = *record;
      003315 90 04 0E         [24] 1021 	mov	dptr,#_ak820_autoshift_process_record_10000_612
      003318 E0               [24] 1022 	movx	a,@dptr
      003319 FD               [12] 1023 	mov	r5,a
      00331A A3               [24] 1024 	inc	dptr
      00331B E0               [24] 1025 	movx	a,@dptr
      00331C FE               [12] 1026 	mov	r6,a
      00331D 7F 00            [12] 1027 	mov	r7,#0x00
      00331F 90 0D 9E         [24] 1028 	mov	dptr,#___memcpy_PARM_2
      003322 ED               [12] 1029 	mov	a,r5
      003323 F0               [24] 1030 	movx	@dptr,a
      003324 EE               [12] 1031 	mov	a,r6
      003325 A3               [24] 1032 	inc	dptr
      003326 F0               [24] 1033 	movx	@dptr,a
      003327 EF               [12] 1034 	mov	a,r7
      003328 A3               [24] 1035 	inc	dptr
      003329 F0               [24] 1036 	movx	@dptr,a
      00332A 90 0D A1         [24] 1037 	mov	dptr,#___memcpy_PARM_3
      00332D 74 09            [12] 1038 	mov	a,#0x09
      00332F F0               [24] 1039 	movx	@dptr,a
      003330 E4               [12] 1040 	clr	a
      003331 A3               [24] 1041 	inc	dptr
      003332 F0               [24] 1042 	movx	@dptr,a
      003333 90 04 00         [24] 1043 	mov	dptr,#_as_saved
      003336 F5 F0            [12] 1044 	mov	b,a
      003338 12 BA 52         [24] 1045 	lcall	___memcpy
                                   1046 ;	keyboards/ajazz/ak820/ak820_autoshift.c:62: as_state = 1;
      00333B 90 04 09         [24] 1047 	mov	dptr,#_as_state
      00333E 74 01            [12] 1048 	mov	a,#0x01
      003340 F0               [24] 1049 	movx	@dptr,a
                                   1050 ;	keyboards/ajazz/ak820/ak820_autoshift.c:63: return false;
      003341 75 82 00         [24] 1051 	mov	dpl, #0x00
                                   1052 ;	keyboards/ajazz/ak820/ak820_autoshift.c:64: }
      003344 22               [24] 1053 	ret
                                   1054 ;------------------------------------------------------------
                                   1055 ;Allocation info for local variables in function 'ak820_autoshift_cancel'
                                   1056 ;------------------------------------------------------------
                                   1057 ;	keyboards/ajazz/ak820/ak820_autoshift.c:65: void ak820_autoshift_cancel(void) { as_state = 0; }
                                   1058 ;	-----------------------------------------
                                   1059 ;	 function ak820_autoshift_cancel
                                   1060 ;	-----------------------------------------
      003345                       1061 _ak820_autoshift_cancel:
      003345 90 04 09         [24] 1062 	mov	dptr,#_as_state
      003348 E4               [12] 1063 	clr	a
      003349 F0               [24] 1064 	movx	@dptr,a
      00334A 22               [24] 1065 	ret
                                   1066 	.area CSEG    (CODE)
                                   1067 	.area CONST   (CODE)
                                   1068 	.area XINIT   (CODE)
      00C361                       1069 __xinit__as_enabled:
      00C361 01                    1070 	.db #0x01	;  1
                                   1071 	.area CABS    (ABS,CODE)
