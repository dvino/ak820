                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         47 bits:
      000025                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00066F                         85 _eeprom_read_word_addr_10000_91:
      00066F                         86 	.ds 3
      000672                         87 _eeprom_read_word_ret_10000_92:
      000672                         88 	.ds 2
      000674                         89 _eeprom_read_dword_addr_10000_93:
      000674                         90 	.ds 3
      000677                         91 _eeprom_read_dword_ret_10000_94:
      000677                         92 	.ds 4
      00067B                         93 _eeprom_write_byte_PARM_2:
      00067B                         94 	.ds 1
      00067C                         95 _eeprom_write_byte_addr_10000_95:
      00067C                         96 	.ds 3
      00067F                         97 _eeprom_write_word_PARM_2:
      00067F                         98 	.ds 2
      000681                         99 _eeprom_write_word_addr_10000_97:
      000681                        100 	.ds 3
      000684                        101 _eeprom_write_dword_PARM_2:
      000684                        102 	.ds 4
      000688                        103 _eeprom_write_dword_addr_10000_99:
      000688                        104 	.ds 3
      00068B                        105 _eeprom_update_byte_PARM_2:
      00068B                        106 	.ds 1
      00068C                        107 _eeprom_update_byte_addr_10000_107:
      00068C                        108 	.ds 3
      00068F                        109 _eeprom_update_word_PARM_2:
      00068F                        110 	.ds 2
      000691                        111 _eeprom_update_word_addr_10000_111:
      000691                        112 	.ds 3
      000694                        113 _eeprom_update_dword_PARM_2:
      000694                        114 	.ds 4
      000698                        115 _eeprom_update_dword_addr_10000_115:
      000698                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004B18                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004B18 12 42 D2         [24]  170 	lcall	_ak820_outline_0034
      004B1B 90 06 6F         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004B1E 12 37 E1         [24]  172 	lcall	_ak820_outline_0014
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004B21 90 06 72         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004B24 12 4D 21         [24]  175 	lcall	_ak820_outline_0159
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004B27 90 06 6F         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004B2A 12 4C D6         [24]  178 	lcall	_ak820_outline_0020
      004B2D 90 05 81         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004B30 ED               [12]  180 	mov	a,r5
      004B31 12 37 E1         [24]  181 	lcall	_ak820_outline_0014
      004B34 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004B37 74 02            [12]  183 	mov	a,#0x02
      004B39 12 38 58         [24]  184 	lcall	_ak820_outline_0115
      004B3C 90 06 72         [24]  185 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004B3F 12 40 6E         [24]  186 	lcall	_ak820_eeprom_read_block_xdata
                                    187 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004B42 90 06 72         [24]  188 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004B45 12 4D 11         [24]  189 	lcall	_ak820_outline_0082
                                    190 ;	drivers/eeprom/eeprom_driver.c:48: }
      004B48 22               [24]  191 	ret
                                    192 ;------------------------------------------------------------
                                    193 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    194 ;------------------------------------------------------------
                                    195 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    196 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    197 ;------------------------------------------------------------
                                    198 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    199 ;	-----------------------------------------
                                    200 ;	 function eeprom_read_dword
                                    201 ;	-----------------------------------------
      004B49                        202 _eeprom_read_dword:
      004B49 12 42 D2         [24]  203 	lcall	_ak820_outline_0034
      004B4C 90 06 74         [24]  204 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004B4F 12 37 E1         [24]  205 	lcall	_ak820_outline_0014
                                    206 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004B52 90 06 77         [24]  207 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004B55 12 4C E6         [24]  208 	lcall	_ak820_outline_0046
                                    209 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004B58 90 06 74         [24]  210 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004B5B 12 4C D6         [24]  211 	lcall	_ak820_outline_0020
      004B5E 90 05 81         [24]  212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004B61 ED               [12]  213 	mov	a,r5
      004B62 12 37 E1         [24]  214 	lcall	_ak820_outline_0014
      004B65 90 05 84         [24]  215 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004B68 74 04            [12]  216 	mov	a,#0x04
      004B6A 12 38 58         [24]  217 	lcall	_ak820_outline_0115
      004B6D 90 06 77         [24]  218 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004B70 12 40 6E         [24]  219 	lcall	_ak820_eeprom_read_block_xdata
                                    220 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004B73 90 06 77         [24]  221 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004B76 12 4C EF         [24]  222 	lcall	_ak820_outline_0050
                                    223 ;	drivers/eeprom/eeprom_driver.c:54: }
      004B79 22               [24]  224 	ret
                                    225 ;------------------------------------------------------------
                                    226 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    227 ;------------------------------------------------------------
                                    228 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    229 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    230 ;------------------------------------------------------------
                                    231 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    232 ;	-----------------------------------------
                                    233 ;	 function eeprom_write_byte
                                    234 ;	-----------------------------------------
      004B7A                        235 _eeprom_write_byte:
      004B7A 12 42 D2         [24]  236 	lcall	_ak820_outline_0034
      004B7D 90 06 7C         [24]  237 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004B80 12 37 E1         [24]  238 	lcall	_ak820_outline_0014
                                    239 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004B83 90 06 7C         [24]  240 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004B86 12 4C B0         [24]  241 	lcall	_ak820_outline_0002
      004B89 74 01            [12]  242 	mov	a,#0x01
      004B8B 12 38 58         [24]  243 	lcall	_ak820_outline_0115
      004B8E 90 06 7B         [24]  244 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    245 ;	drivers/eeprom/eeprom_driver.c:58: }
      004B91 02 40 FA         [24]  246 	ljmp	_ak820_eeprom_write_block_xdata
                                    247 ;------------------------------------------------------------
                                    248 ;Allocation info for local variables in function 'eeprom_write_word'
                                    249 ;------------------------------------------------------------
                                    250 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    251 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    252 ;------------------------------------------------------------
                                    253 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    254 ;	-----------------------------------------
                                    255 ;	 function eeprom_write_word
                                    256 ;	-----------------------------------------
      004B94                        257 _eeprom_write_word:
      004B94 12 42 D2         [24]  258 	lcall	_ak820_outline_0034
      004B97 90 06 81         [24]  259 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004B9A 12 37 E1         [24]  260 	lcall	_ak820_outline_0014
                                    261 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004B9D 90 06 81         [24]  262 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004BA0 12 4C B0         [24]  263 	lcall	_ak820_outline_0002
      004BA3 74 02            [12]  264 	mov	a,#0x02
      004BA5 12 38 58         [24]  265 	lcall	_ak820_outline_0115
      004BA8 90 06 7F         [24]  266 	mov	dptr,#_eeprom_write_word_PARM_2
                                    267 ;	drivers/eeprom/eeprom_driver.c:62: }
      004BAB 02 40 FA         [24]  268 	ljmp	_ak820_eeprom_write_block_xdata
                                    269 ;------------------------------------------------------------
                                    270 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    271 ;------------------------------------------------------------
                                    272 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    273 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    274 ;------------------------------------------------------------
                                    275 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    276 ;	-----------------------------------------
                                    277 ;	 function eeprom_write_dword
                                    278 ;	-----------------------------------------
      004BAE                        279 _eeprom_write_dword:
      004BAE 12 42 D2         [24]  280 	lcall	_ak820_outline_0034
      004BB1 90 06 88         [24]  281 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004BB4 12 37 E1         [24]  282 	lcall	_ak820_outline_0014
                                    283 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004BB7 90 06 88         [24]  284 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004BBA 12 4C B0         [24]  285 	lcall	_ak820_outline_0002
      004BBD 74 04            [12]  286 	mov	a,#0x04
      004BBF 12 38 58         [24]  287 	lcall	_ak820_outline_0115
      004BC2 90 06 84         [24]  288 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    289 ;	drivers/eeprom/eeprom_driver.c:66: }
      004BC5 02 40 FA         [24]  290 	ljmp	_ak820_eeprom_write_block_xdata
                                    291 ;------------------------------------------------------------
                                    292 ;Allocation info for local variables in function 'eeprom_update_block'
                                    293 ;------------------------------------------------------------
                                    294 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    295 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    296 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    297 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    298 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    299 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    300 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    301 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    302 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    303 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    304 ;------------------------------------------------------------
                                    305 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    306 ;	-----------------------------------------
                                    307 ;	 function eeprom_update_byte
                                    308 ;	-----------------------------------------
      004BC8                        309 _eeprom_update_byte:
      004BC8 C0 07            [24]  310 	push	ar7
      004BCA C0 06            [24]  311 	push	ar6
      004BCC C0 05            [24]  312 	push	ar5
      004BCE C0 04            [24]  313 	push	ar4
      004BD0 12 42 D2         [24]  314 	lcall	_ak820_outline_0034
      004BD3 90 06 8C         [24]  315 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004BD6 12 37 E1         [24]  316 	lcall	_ak820_outline_0014
                                    317 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004BD9 90 06 8C         [24]  318 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004BDC 12 4C C7         [24]  319 	lcall	_ak820_outline_0003
      004BDF 12 40 33         [24]  320 	lcall	_eeprom_read_byte
      004BE2 AF 82            [24]  321 	mov	r7, dpl
                                    322 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004BE4 90 06 8B         [24]  323 	mov	dptr,#_eeprom_update_byte_PARM_2
      004BE7 E0               [24]  324 	movx	a,@dptr
      004BE8 FE               [12]  325 	mov	r6,a
      004BE9 EF               [12]  326 	mov	a,r7
      004BEA B5 06 02         [24]  327 	cjne	a,ar6,00112$
      004BED 80 36            [24]  328 	sjmp	00103$
      004BEF                        329 00112$:
                                    330 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004BEF 90 06 8C         [24]  331 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004BF2 12 38 18         [24]  332 	lcall	_ak820_outline_0056
      004BF5 A3               [24]  333 	inc	dptr
      004BF6 E0               [24]  334 	movx	a,@dptr
      004BF7 FF               [12]  335 	mov	r7,a
      004BF8 90 06 7B         [24]  336 	mov	dptr,#_eeprom_write_byte_PARM_2
      004BFB EE               [12]  337 	mov	a,r6
      004BFC F0               [24]  338 	movx	@dptr,a
      004BFD 12 38 53         [24]  339 	lcall	_ak820_outline_0112
      004C00 8F F0            [24]  340 	mov	b, r7
      004C02 C0 07            [24]  341 	push	ar7
      004C04 C0 06            [24]  342 	push	ar6
      004C06 C0 05            [24]  343 	push	ar5
      004C08 C0 04            [24]  344 	push	ar4
      004C0A C0 03            [24]  345 	push	ar3
      004C0C C0 02            [24]  346 	push	ar2
      004C0E C0 01            [24]  347 	push	ar1
      004C10 C0 00            [24]  348 	push	ar0
      004C12 12 4B 7A         [24]  349 	lcall	_eeprom_write_byte
      004C15 D0 00            [24]  350 	pop	ar0
      004C17 D0 01            [24]  351 	pop	ar1
      004C19 D0 02            [24]  352 	pop	ar2
      004C1B D0 03            [24]  353 	pop	ar3
      004C1D D0 04            [24]  354 	pop	ar4
      004C1F D0 05            [24]  355 	pop	ar5
      004C21 D0 06            [24]  356 	pop	ar6
      004C23 D0 07            [24]  357 	pop	ar7
      004C25                        358 00103$:
                                    359 ;	drivers/eeprom/eeprom_driver.c:87: }
      004C25 D0 04            [24]  360 	pop	ar4
      004C27 D0 05            [24]  361 	pop	ar5
      004C29 D0 06            [24]  362 	pop	ar6
      004C2B D0 07            [24]  363 	pop	ar7
      004C2D 22               [24]  364 	ret
                                    365 ;------------------------------------------------------------
                                    366 ;Allocation info for local variables in function 'eeprom_update_word'
                                    367 ;------------------------------------------------------------
                                    368 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    369 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    370 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    371 ;------------------------------------------------------------
                                    372 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    373 ;	-----------------------------------------
                                    374 ;	 function eeprom_update_word
                                    375 ;	-----------------------------------------
      004C2E                        376 _eeprom_update_word:
      004C2E 12 42 D2         [24]  377 	lcall	_ak820_outline_0034
      004C31 90 06 91         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004C34 12 37 E1         [24]  379 	lcall	_ak820_outline_0014
                                    380 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004C37 90 06 91         [24]  381 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004C3A 12 4C C7         [24]  382 	lcall	_ak820_outline_0003
      004C3D 12 4B 18         [24]  383 	lcall	_eeprom_read_word
      004C40 12 43 1F         [24]  384 	lcall	_ak820_outline_0125
                                    385 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004C43 90 06 8F         [24]  386 	mov	dptr,#_eeprom_update_word_PARM_2
      004C46 12 38 18         [24]  387 	lcall	_ak820_outline_0056
      004C49 EE               [12]  388 	mov	a,r6
      004C4A B5 04 05         [24]  389 	cjne	a,ar4,00112$
      004C4D EF               [12]  390 	mov	a,r7
      004C4E B5 05 01         [24]  391 	cjne	a,ar5,00112$
      004C51 22               [24]  392 	ret
      004C52                        393 00112$:
                                    394 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004C52 90 06 91         [24]  395 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004C55 E0               [24]  396 	movx	a,@dptr
      004C56 FB               [12]  397 	mov	r3,a
      004C57 A3               [24]  398 	inc	dptr
      004C58 12 37 F9         [24]  399 	lcall	_ak820_outline_0047
      004C5B 90 06 7F         [24]  400 	mov	dptr,#_eeprom_write_word_PARM_2
      004C5E 12 38 24         [24]  401 	lcall	_ak820_outline_0070
      004C61 8B 82            [24]  402 	mov	dpl, r3
      004C63 8E 83            [24]  403 	mov	dph, r6
      004C65 8F F0            [24]  404 	mov	b, r7
                                    405 ;	drivers/eeprom/eeprom_driver.c:94: }
      004C67 02 4B 94         [24]  406 	ljmp	_eeprom_write_word
                                    407 ;------------------------------------------------------------
                                    408 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    409 ;------------------------------------------------------------
                                    410 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    411 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    412 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    413 ;------------------------------------------------------------
                                    414 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    415 ;	-----------------------------------------
                                    416 ;	 function eeprom_update_dword
                                    417 ;	-----------------------------------------
      004C6A                        418 _eeprom_update_dword:
      004C6A 12 42 D2         [24]  419 	lcall	_ak820_outline_0034
      004C6D 90 06 98         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004C70 12 37 E1         [24]  421 	lcall	_ak820_outline_0014
                                    422 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004C73 90 06 98         [24]  423 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004C76 12 4C C7         [24]  424 	lcall	_ak820_outline_0003
      004C79 12 4B 49         [24]  425 	lcall	_eeprom_read_dword
      004C7C 12 4D 00         [24]  426 	lcall	_ak820_outline_0052
                                    427 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004C7F 90 06 94         [24]  428 	mov	dptr,#_eeprom_update_dword_PARM_2
      004C82 E0               [24]  429 	movx	a,@dptr
      004C83 F8               [12]  430 	mov	r0,a
      004C84 A3               [24]  431 	inc	dptr
      004C85 12 4D 08         [24]  432 	lcall	_ak820_outline_0081
      004C88 EC               [12]  433 	mov	a,r4
      004C89 B5 00 0D         [24]  434 	cjne	a,ar0,00112$
      004C8C ED               [12]  435 	mov	a,r5
      004C8D B5 01 09         [24]  436 	cjne	a,ar1,00112$
      004C90 EE               [12]  437 	mov	a,r6
      004C91 B5 02 05         [24]  438 	cjne	a,ar2,00112$
      004C94 EF               [12]  439 	mov	a,r7
      004C95 B5 03 01         [24]  440 	cjne	a,ar3,00112$
      004C98 22               [24]  441 	ret
      004C99                        442 00112$:
                                    443 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004C99 90 06 98         [24]  444 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004C9C 12 4C D6         [24]  445 	lcall	_ak820_outline_0020
      004C9F 90 06 84         [24]  446 	mov	dptr,#_eeprom_write_dword_PARM_2
      004CA2 E8               [12]  447 	mov	a,r0
      004CA3 F0               [24]  448 	movx	@dptr,a
      004CA4 E9               [12]  449 	mov	a,r1
      004CA5 A3               [24]  450 	inc	dptr
      004CA6 12 4D 1A         [24]  451 	lcall	_ak820_outline_0144
      004CA9 F0               [24]  452 	movx	@dptr,a
      004CAA 12 4C DF         [24]  453 	lcall	_ak820_outline_0041
                                    454 ;	drivers/eeprom/eeprom_driver.c:101: }
      004CAD 02 4B AE         [24]  455 	ljmp	_eeprom_write_dword
                                    456 	.area CSEG    (CODE)
                                    457 	.area CONST   (CODE)
                                    458 	.area XINIT   (CODE)
                                    459 	.area CABS    (ABS,CODE)
                                    460 
                                    461 ; Experimental exact instruction outlining.
                                    462 	.globl _ak820_outline_0002
                                    463 	.globl _ak820_outline_0003
                                    464 	.globl _ak820_outline_0014
                                    465 	.globl _ak820_outline_0020
                                    466 	.globl _ak820_outline_0034
                                    467 	.globl _ak820_outline_0041
                                    468 	.globl _ak820_outline_0046
                                    469 	.globl _ak820_outline_0047
                                    470 	.globl _ak820_outline_0050
                                    471 	.globl _ak820_outline_0052
                                    472 	.globl _ak820_outline_0056
                                    473 	.globl _ak820_outline_0070
                                    474 	.globl _ak820_outline_0081
                                    475 	.globl _ak820_outline_0082
                                    476 	.globl _ak820_outline_0112
                                    477 	.globl _ak820_outline_0115
                                    478 	.globl _ak820_outline_0125
                                    479 	.globl _ak820_outline_0144
                                    480 	.globl _ak820_outline_0159
                                    481 
                                    482 	.area CSEG (CODE)
                                    483 ; function ak820_outline_0002
      004CB0                        484 _ak820_outline_0002:
      004CB0 E0               [24]  485 	movx	a,@dptr
      004CB1 FD               [12]  486 	mov	r5,a
      004CB2 A3               [24]  487 	inc	dptr
      004CB3 E0               [24]  488 	movx	a,@dptr
      004CB4 FE               [12]  489 	mov	r6,a
      004CB5 A3               [24]  490 	inc	dptr
      004CB6 E0               [24]  491 	movx	a,@dptr
      004CB7 FF               [12]  492 	mov	r7,a
      004CB8 90 05 8A         [24]  493 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004CBB ED               [12]  494 	mov	a,r5
      004CBC F0               [24]  495 	movx	@dptr,a
      004CBD EE               [12]  496 	mov	a,r6
      004CBE A3               [24]  497 	inc	dptr
      004CBF F0               [24]  498 	movx	@dptr,a
      004CC0 EF               [12]  499 	mov	a,r7
      004CC1 A3               [24]  500 	inc	dptr
      004CC2 F0               [24]  501 	movx	@dptr,a
      004CC3 90 05 8D         [24]  502 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004CC6 22               [24]  503 	ret
                                    504 
                                    505 	.area CSEG (CODE)
                                    506 ; function ak820_outline_0003
      004CC7                        507 _ak820_outline_0003:
      004CC7 E0               [24]  508 	movx	a,@dptr
      004CC8 FD               [12]  509 	mov	r5,a
      004CC9 A3               [24]  510 	inc	dptr
      004CCA E0               [24]  511 	movx	a,@dptr
      004CCB FE               [12]  512 	mov	r6,a
      004CCC A3               [24]  513 	inc	dptr
      004CCD E0               [24]  514 	movx	a,@dptr
      004CCE FF               [12]  515 	mov	r7,a
      004CCF 8D 82            [24]  516 	mov	dpl,r5
      004CD1 8E 83            [24]  517 	mov	dph,r6
      004CD3 8F F0            [24]  518 	mov	b,r7
      004CD5 22               [24]  519 	ret
                                    520 
                                    521 	.area CSEG (CODE)
                                    522 ; function ak820_outline_0020
      004CD6                        523 _ak820_outline_0020:
      004CD6 E0               [24]  524 	movx	a,@dptr
      004CD7 FD               [12]  525 	mov	r5,a
      004CD8 A3               [24]  526 	inc	dptr
      004CD9 E0               [24]  527 	movx	a,@dptr
      004CDA FE               [12]  528 	mov	r6,a
      004CDB A3               [24]  529 	inc	dptr
      004CDC E0               [24]  530 	movx	a,@dptr
      004CDD FF               [12]  531 	mov	r7,a
      004CDE 22               [24]  532 	ret
                                    533 
                                    534 	.area CSEG (CODE)
                                    535 ; function ak820_outline_0041
      004CDF                        536 _ak820_outline_0041:
      004CDF 8D 82            [24]  537 	mov	dpl,r5
      004CE1 8E 83            [24]  538 	mov	dph,r6
      004CE3 8F F0            [24]  539 	mov	b,r7
      004CE5 22               [24]  540 	ret
                                    541 
                                    542 	.area CSEG (CODE)
                                    543 ; function ak820_outline_0046
      004CE6                        544 _ak820_outline_0046:
      004CE6 E4               [12]  545 	clr	a
      004CE7 F0               [24]  546 	movx	@dptr,a
      004CE8 A3               [24]  547 	inc	dptr
      004CE9 F0               [24]  548 	movx	@dptr,a
      004CEA A3               [24]  549 	inc	dptr
      004CEB F0               [24]  550 	movx	@dptr,a
      004CEC A3               [24]  551 	inc	dptr
      004CED F0               [24]  552 	movx	@dptr,a
      004CEE 22               [24]  553 	ret
                                    554 
                                    555 	.area CSEG (CODE)
                                    556 ; function ak820_outline_0050
      004CEF                        557 _ak820_outline_0050:
      004CEF E0               [24]  558 	movx	a,@dptr
      004CF0 FC               [12]  559 	mov	r4,a
      004CF1 A3               [24]  560 	inc	dptr
      004CF2 E0               [24]  561 	movx	a,@dptr
      004CF3 FD               [12]  562 	mov	r5,a
      004CF4 A3               [24]  563 	inc	dptr
      004CF5 E0               [24]  564 	movx	a,@dptr
      004CF6 FE               [12]  565 	mov	r6,a
      004CF7 A3               [24]  566 	inc	dptr
      004CF8 E0               [24]  567 	movx	a,@dptr
      004CF9 8C 82            [24]  568 	mov	dpl,r4
      004CFB 8D 83            [24]  569 	mov	dph,r5
      004CFD 8E F0            [24]  570 	mov	b,r6
      004CFF 22               [24]  571 	ret
                                    572 
                                    573 	.area CSEG (CODE)
                                    574 ; function ak820_outline_0052
      004D00                        575 _ak820_outline_0052:
      004D00 AC 82            [24]  576 	mov	r4,dpl
      004D02 AD 83            [24]  577 	mov	r5,dph
      004D04 AE F0            [24]  578 	mov	r6,b
      004D06 FF               [12]  579 	mov	r7,a
      004D07 22               [24]  580 	ret
                                    581 
                                    582 	.area CSEG (CODE)
                                    583 ; function ak820_outline_0081
      004D08                        584 _ak820_outline_0081:
      004D08 E0               [24]  585 	movx	a,@dptr
      004D09 F9               [12]  586 	mov	r1,a
      004D0A A3               [24]  587 	inc	dptr
      004D0B E0               [24]  588 	movx	a,@dptr
      004D0C FA               [12]  589 	mov	r2,a
      004D0D A3               [24]  590 	inc	dptr
      004D0E E0               [24]  591 	movx	a,@dptr
      004D0F FB               [12]  592 	mov	r3,a
      004D10 22               [24]  593 	ret
                                    594 
                                    595 	.area CSEG (CODE)
                                    596 ; function ak820_outline_0082
      004D11                        597 _ak820_outline_0082:
      004D11 E0               [24]  598 	movx	a,@dptr
      004D12 FE               [12]  599 	mov	r6,a
      004D13 A3               [24]  600 	inc	dptr
      004D14 E0               [24]  601 	movx	a,@dptr
      004D15 8E 82            [24]  602 	mov	dpl,r6
      004D17 F5 83            [12]  603 	mov	dph,a
      004D19 22               [24]  604 	ret
                                    605 
                                    606 	.area CSEG (CODE)
                                    607 ; function ak820_outline_0144
      004D1A                        608 _ak820_outline_0144:
      004D1A F0               [24]  609 	movx	@dptr,a
      004D1B EA               [12]  610 	mov	a,r2
      004D1C A3               [24]  611 	inc	dptr
      004D1D F0               [24]  612 	movx	@dptr,a
      004D1E EB               [12]  613 	mov	a,r3
      004D1F A3               [24]  614 	inc	dptr
      004D20 22               [24]  615 	ret
                                    616 
                                    617 	.area CSEG (CODE)
                                    618 ; function ak820_outline_0159
      004D21                        619 _ak820_outline_0159:
      004D21 E4               [12]  620 	clr	a
      004D22 F0               [24]  621 	movx	@dptr,a
      004D23 A3               [24]  622 	inc	dptr
      004D24 F0               [24]  623 	movx	@dptr,a
      004D25 22               [24]  624 	ret
