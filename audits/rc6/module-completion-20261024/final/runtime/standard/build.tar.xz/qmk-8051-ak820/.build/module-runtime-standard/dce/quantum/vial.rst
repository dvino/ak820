                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000045                        541 _vial_handle_cmd_sloc0_1_0:
      000045                        542 	.ds 2
      000047                        543 _vial_handle_cmd_sloc1_1_0:
      000047                        544 	.ds 2
      000049                        545 _vial_handle_cmd_sloc2_1_0:
      000049                        546 	.ds 2
      00004B                        547 _vial_handle_cmd_sloc3_1_0:
      00004B                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C15                        573 _vial_unlock_timer:
      000C15                        574 	.ds 4
      000C19                        575 _vial_unlock_holding:
      000C19                        576 	.ds 1
      000C1A                        577 _vial_keycode_firewall_in_10000_609:
      000C1A                        578 	.ds 2
      000C1C                        579 _vial_fill_packet_PARM_2:
      000C1C                        580 	.ds 1
      000C1D                        581 _vial_fill_packet_msg_10000_612:
      000C1D                        582 	.ds 2
      000C1F                        583 _vial_handle_cmd_PARM_2:
      000C1F                        584 	.ds 1
      000C20                        585 _vial_handle_cmd_data_10000_617:
      000C20                        586 	.ds 3
      000C23                        587 _vial_handle_cmd_entry_70000_645:
      000C23                        588 	.ds 10
      000C2D                        589 _vial_handle_cmd_entry_70000_646:
      000C2D                        590 	.ds 10
      000C37                        591 _g_vial_magic_keycode_override::
      000C37                        592 	.ds 2
      000C39                        593 _vial_keycode_down_keycode_10000_648:
      000C39                        594 	.ds 2
      000C3B                        595 _vial_keycode_down_dummy_event_30000_655:
      000C3B                        596 	.ds 6
      000C41                        597 _vial_keycode_up_keycode_10000_656:
      000C41                        598 	.ds 2
      000C43                        599 _vial_keycode_up_dummy_event_30000_663:
      000C43                        600 	.ds 6
      000C49                        601 _vial_keycode_tap_keycode_10000_664:
      000C49                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000DDE                        611 _vial_unlocked::
      000DDE                        612 	.ds 1
      000DDF                        613 _vial_unlock_in_progress::
      000DDF                        614 	.ds 1
      000DE0                        615 _vial_unlock_counter:
      000DE0                        616 	.ds 1
      000DE1                        617 _vial_unlock_combo_rows:
      000DE1                        618 	.ds 2
      000DE3                        619 _vial_unlock_combo_cols:
      000DE3                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00A76D                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00A76D 90 0D DF         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00A770 E0               [24]  667 	movx	a,@dptr
      00A771 70 01            [24]  668 	jnz	00131$
      00A773 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00A774                        671 00131$:
      00A774 7F 00            [12]  672 	mov	r7,#0x00
      00A776                        673 00115$:
      00A776 BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00A779                        675 00184$:
      00A779 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00A77B EF               [12]  678 	mov	a,r7
      00A77C 12 AD 31         [24]  679 	lcall	_ak820_outline_0119
      00A77F FE               [12]  680 	mov	r6,a
      00A780 EF               [12]  681 	mov	a,r7
      00A781 12 AD 26         [24]  682 	lcall	_ak820_outline_0118
      00A784 90 07 4F         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00A787 F0               [24]  684 	movx	@dptr,a
      00A788 8E 82            [24]  685 	mov	dpl, r6
      00A78A C0 07            [24]  686 	push	ar7
      00A78C 12 57 16         [24]  687 	lcall	_matrix_is_on
      00A78F E5 82            [12]  688 	mov	a, dpl
      00A791 D0 07            [24]  689 	pop	ar7
      00A793 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00A795 90 0C 19         [24]  692 	mov	dptr,#_vial_unlock_holding
      00A798 E4               [12]  693 	clr	a
      00A799 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00A79A 90 0D E0         [24]  696 	mov	dptr,#_vial_unlock_counter
      00A79D 74 1E            [12]  697 	mov	a,#0x1e
      00A79F F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00A7A0 22               [24]  700 	ret
      00A7A1                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00A7A1 0F               [12]  703 	inc	r7
      00A7A2 80 D2            [24]  704 	sjmp	00115$
      00A7A4                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00A7A4 90 0C 19         [24]  707 	mov	dptr,#_vial_unlock_holding
      00A7A7 E0               [24]  708 	movx	a,@dptr
      00A7A8 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00A7AA 90 0C 19         [24]  711 	mov	dptr,#_vial_unlock_holding
      00A7AD 74 01            [12]  712 	mov	a,#0x01
      00A7AF F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00A7B0 12 46 EC         [24]  715 	lcall	_timer_read32
      00A7B3 12 4D 00         [24]  716 	lcall	_ak820_outline_0052
      00A7B6 90 0C 15         [24]  717 	mov	dptr,#_vial_unlock_timer
      00A7B9 12 8C 8D         [24]  718 	lcall	_ak820_outline_0005
      00A7BC                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00A7BC 90 0C 15         [24]  721 	mov	dptr,#_vial_unlock_timer
      00A7BF 12 4C EF         [24]  722 	lcall	_ak820_outline_0050
      00A7C2 12 47 45         [24]  723 	lcall	_timer_elapsed32
      00A7C5 12 4D 00         [24]  724 	lcall	_ak820_outline_0052
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00A7C8 7B 1E            [12]  726 	mov	r3,#0x1e
      00A7CA                        727 00109$:
      00A7CA EB               [12]  728 	mov	a,r3
      00A7CB 60 22            [24]  729 	jz	00111$
      00A7CD C3               [12]  730 	clr	c
      00A7CE EC               [12]  731 	mov	a,r4
      00A7CF 94 64            [12]  732 	subb	a,#0x64
      00A7D1 ED               [12]  733 	mov	a,r5
      00A7D2 94 00            [12]  734 	subb	a,#0x00
      00A7D4 EE               [12]  735 	mov	a,r6
      00A7D5 94 00            [12]  736 	subb	a,#0x00
      00A7D7 EF               [12]  737 	mov	a,r7
      00A7D8 94 00            [12]  738 	subb	a,#0x00
      00A7DA 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00A7DC EC               [12]  741 	mov	a,r4
      00A7DD 24 9C            [12]  742 	add	a,#0x9c
      00A7DF FC               [12]  743 	mov	r4,a
      00A7E0 ED               [12]  744 	mov	a,r5
      00A7E1 34 FF            [12]  745 	addc	a,#0xff
      00A7E3 FD               [12]  746 	mov	r5,a
      00A7E4 EE               [12]  747 	mov	a,r6
      00A7E5 34 FF            [12]  748 	addc	a,#0xff
      00A7E7 FE               [12]  749 	mov	r6,a
      00A7E8 EF               [12]  750 	mov	a,r7
      00A7E9 34 FF            [12]  751 	addc	a,#0xff
      00A7EB FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00A7EC 1B               [12]  754 	dec	r3
      00A7ED 80 DB            [24]  755 	sjmp	00109$
      00A7EF                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00A7EF 90 0D E0         [24]  758 	mov	dptr,#_vial_unlock_counter
      00A7F2 EB               [12]  759 	mov	a,r3
      00A7F3 F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00A7F4 EB               [12]  762 	mov	a,r3
      00A7F5 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00A7F7 90 0D DF         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00A7FA E4               [12]  766 	clr	a
      00A7FB F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00A7FC 90 0D DE         [24]  769 	mov	dptr,#_vial_unlocked
      00A7FF 04               [12]  770 	inc	a
      00A800 F0               [24]  771 	movx	@dptr,a
      00A801                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00A801 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:117: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00A802                        782 _vial_init:
                                    783 ;	quantum/vial.c:125: reload_combo();
                                    784 ;	quantum/vial.c:130: }
      00A802 02 35 38         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_609'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00A805                        795 _vial_keycode_firewall:
      00A805 12 38 47         [24]  796 	lcall	_ak820_outline_0100
      00A808 90 0C 1A         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_609
      00A80B 12 38 42         [24]  798 	lcall	_ak820_outline_0099
                                    799 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00A80E 90 0C 1A         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_609
      00A811 12 37 C0         [24]  801 	lcall	_ak820_outline_0007
      00A814 BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00A817 BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00A81A 90 0D DE         [24]  804 	mov	dptr,#_vial_unlocked
      00A81D E0               [24]  805 	movx	a,@dptr
      00A81E 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:134: return 0;
      00A820 90 00 00         [24]  808 	mov	dptr,#0x0000
      00A823 22               [24]  809 	ret
      00A824                        810 00102$:
                                    811 ;	quantum/vial.c:135: return in;
      00A824 12 43 1A         [24]  812 	lcall	_ak820_outline_0111
                                    813 ;	quantum/vial.c:136: }
      00A827 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_612'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_614'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00A828                        826 _vial_fill_packet:
      00A828 12 38 47         [24]  827 	lcall	_ak820_outline_0100
      00A82B 90 0C 1D         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_612
      00A82E 12 38 42         [24]  829 	lcall	_ak820_outline_0099
                                    830 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00A831 90 0C 1D         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_612
      00A834 12 37 F9         [24]  832 	lcall	_ak820_outline_0047
      00A837 90 0C 1C         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00A83A E0               [24]  834 	movx	a,@dptr
      00A83B FD               [12]  835 	mov	r5,a
      00A83C 7C 00            [12]  836 	mov	r4,#0x00
      00A83E                        837 00103$:
      00A83E BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00A841                        839 00122$:
      00A841 50 09            [24]  840 	jnc	00105$
      00A843 EC               [12]  841 	mov	a,r4
      00A844 12 37 E9         [24]  842 	lcall	_ak820_outline_0018
      00A847 ED               [12]  843 	mov	a,r5
      00A848 F0               [24]  844 	movx	@dptr,a
      00A849 0C               [12]  845 	inc	r4
      00A84A 80 F2            [24]  846 	sjmp	00103$
      00A84C                        847 00105$:
                                    848 ;	quantum/vial.c:141: }
      00A84C 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00A84D                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:174: repeat_key_cancel();
      00A84D 12 9C 40         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:176: clear_keyboard();
                                    861 ;	quantum/vial.c:177: }
      00A850 02 73 44         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_617'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_618'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_623'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_624'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_627'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_629'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_629'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_629'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_630'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_631'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_631'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_631'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_634'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_645'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_645'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00A853                        893 _vial_handle_cmd:
      00A853 12 42 D2         [24]  894 	lcall	_ak820_outline_0034
      00A856 90 0C 20         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_617
      00A859 12 37 E1         [24]  896 	lcall	_ak820_outline_0014
                                    897 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00A85C 90 0C 20         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_617
      00A85F 12 37 F9         [24]  899 	lcall	_ak820_outline_0047
                                    900 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00A862 90 0C 1F         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00A865 E0               [24]  902 	movx	a,@dptr
      00A866 FD               [12]  903 	mov	r5,a
      00A867 BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00A86A 80 01            [24]  905 	sjmp	00102$
      00A86C                        906 00258$:
                                    907 ;	quantum/vial.c:190: return;
      00A86C 22               [24]  908 	ret
      00A86D                        909 00102$:
                                    910 ;	quantum/vial.c:193: switch (msg[1]) {
      00A86D 74 01            [12]  911 	mov	a,#0x01
      00A86F 12 46 41         [24]  912 	lcall	_ak820_outline_0010
      00A872 FB               [12]  913 	mov  r3,a
      00A873 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00A875 50 01            [24]  915 	jnc	00259$
      00A877 22               [24]  916 	ret
      00A878                        917 00259$:
                                    918 ;	free result
      00A878 EB               [12]  919 	mov	a,r3
      00A879 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00A87B 83               [24]  921 	movc	a,@a+pc
      00A87C F5 82            [12]  922 	mov	dpl,a
      00A87E EB               [12]  923 	mov	a,r3
      00A87F 24 12            [12]  924 	add	a,#(00261$-3-.)
      00A881 83               [24]  925 	movc	a,@a+pc
      00A882 F5 83            [12]  926 	mov	dph,a
      00A884 E4               [12]  927 	clr	a
      00A885 73               [24]  928 	jmp	@a+dptr
      00A886                        929 00260$:
      00A886 A2                     930 	.db	00103$
      00A887 EA                     931 	.db	00105$
      00A888 FF                     932 	.db	00106$
      00A889 8B                     933 	.db	00112$
      00A88A 11                     934 	.db	00113$
      00A88B 5D                     935 	.db	00114$
      00A88C CC                     936 	.db	00116$
      00A88D E7                     937 	.db	00119$
      00A88E 07                     938 	.db	00120$
      00A88F 15                     939 	.db	00121$
      00A890 21                     940 	.db	00139$
      00A891 21                     941 	.db	00139$
      00A892 21                     942 	.db	00139$
      00A893 20                     943 	.db	00122$
      00A894                        944 00261$:
      00A894 A8                     945 	.db	00103$>>8
      00A895 A8                     946 	.db	00105$>>8
      00A896 A8                     947 	.db	00106$>>8
      00A897 A9                     948 	.db	00112$>>8
      00A898 AA                     949 	.db	00113$>>8
      00A899 AA                     950 	.db	00114$>>8
      00A89A AA                     951 	.db	00116$>>8
      00A89B AA                     952 	.db	00119$>>8
      00A89C AB                     953 	.db	00120$>>8
      00A89D AB                     954 	.db	00121$>>8
      00A89E AC                     955 	.db	00139$>>8
      00A89F AC                     956 	.db	00139$>>8
      00A8A0 AC                     957 	.db	00139$>>8
      00A8A1 AB                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00A8A2                        960 00103$:
                                    961 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00A8A2 90 0C 1C         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00A8A5 E4               [12]  963 	clr	a
      00A8A6 12 42 F6         [24]  964 	lcall	_ak820_outline_0057
      00A8A9 C0 07            [24]  965 	push	ar7
      00A8AB C0 06            [24]  966 	push	ar6
      00A8AD 12 A8 28         [24]  967 	lcall	_vial_fill_packet
      00A8B0 D0 06            [24]  968 	pop	ar6
      00A8B2 D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00A8B4 12 43 1A         [24]  971 	lcall	_ak820_outline_0111
      00A8B7 74 06            [12]  972 	mov	a,#0x06
      00A8B9 12 42 F6         [24]  973 	lcall	_ak820_outline_0057
                                    974 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00A8BC A3               [24]  975 	inc	dptr
      00A8BD E4               [12]  976 	clr	a
      00A8BE 12 42 CA         [24]  977 	lcall	_ak820_outline_0028
                                    978 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00A8C1 12 42 CA         [24]  979 	lcall	_ak820_outline_0028
                                    980 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00A8C4 A3               [24]  981 	inc	dptr
      00A8C5 F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00A8C6 FB               [12]  984 	mov	r3,a
      00A8C7                        985 00131$:
      00A8C7 BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00A8CA                        987 00262$:
      00A8CA 50 15            [24]  988 	jnc	00104$
      00A8CC 8B 02            [24]  989 	mov	ar2,r3
      00A8CE 74 04            [12]  990 	mov	a,#0x04
      00A8D0 2A               [12]  991 	add	a, r2
      00A8D1 2E               [12]  992 	add	a, r6
      00A8D2 F9               [12]  993 	mov	r1,a
      00A8D3 E4               [12]  994 	clr	a
      00A8D4 3F               [12]  995 	addc	a,r7
      00A8D5 FA               [12]  996 	mov	r2,a
      00A8D6 EB               [12]  997 	mov	a,r3
      00A8D7 90 B9 DB         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_622
      00A8DA 93               [24]  999 	movc	a,@a+dptr
      00A8DB 12 6A 07         [24] 1000 	lcall	_ak820_outline_0129
      00A8DE 0B               [12] 1001 	inc	r3
      00A8DF 80 E6            [24] 1002 	sjmp	00131$
      00A8E1                       1003 00104$:
                                   1004 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00A8E1 74 0C            [12] 1005 	mov	a,#0x0c
      00A8E3 12 37 E9         [24] 1006 	lcall	_ak820_outline_0018
      00A8E6 74 01            [12] 1007 	mov	a,#0x01
      00A8E8 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:207: break;
      00A8E9 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:210: case vial_get_size: {
      00A8EA                       1012 00105$:
                                   1013 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00A8EA 12 43 1A         [24] 1014 	lcall	_ak820_outline_0111
      00A8ED 74 7C            [12] 1015 	mov	a,#0x7c
      00A8EF F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00A8F0 12 38 53         [24] 1018 	lcall	_ak820_outline_0112
      00A8F3 74 01            [12] 1019 	mov	a,#0x01
      00A8F5 12 42 CA         [24] 1020 	lcall	_ak820_outline_0028
                                   1021 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00A8F8 E4               [12] 1022 	clr	a
      00A8F9 12 42 CA         [24] 1023 	lcall	_ak820_outline_0028
                                   1024 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00A8FC A3               [24] 1025 	inc	dptr
      00A8FD F0               [24] 1026 	movx	@dptr,a
                                   1027 ;	quantum/vial.c:216: break;
      00A8FE 22               [24] 1028 	ret
                                   1029 ;	quantum/vial.c:219: case vial_get_def: {
      00A8FF                       1030 00106$:
                                   1031 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00A8FF 12 A7 31         [24] 1032 	lcall	_ak820_outline_0019
      00A902 E0               [24] 1033 	movx	a,@dptr
      00A903 FB               [12] 1034 	mov	r3,a
      00A904 12 42 C0         [24] 1035 	lcall	_ak820_outline_0011
      00A907 E0               [24] 1036 	movx	a,@dptr
      00A908 4B               [12] 1037 	orl	a,r3
      00A909 60 01            [24] 1038 	jz	00108$
      00A90B 22               [24] 1039 	ret
      00A90C                       1040 00108$:
                                   1041 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00A90C 12 37 F1         [24] 1042 	lcall	_ak820_outline_0031
      00A90F FB               [12] 1043 	mov	r3,a
      00A910 7A 00            [12] 1044 	mov	r2,#0x00
      00A912 12 A7 28         [24] 1045 	lcall	_ak820_outline_0013
      00A915 F9               [12] 1046 	mov	r1,a
      00A916 E4               [12] 1047 	clr	a
      00A917 42 03            [12] 1048 	orl	ar3,a
      00A919 E9               [12] 1049 	mov	a,r1
      00A91A 42 02            [12] 1050 	orl	ar2,a
                                   1051 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00A91C C3               [12] 1052 	clr	c
      00A91D EB               [12] 1053 	mov	a,r3
      00A91E 94 0C            [12] 1054 	subb	a,#0x0c
      00A920 EA               [12] 1055 	mov	a,r2
      00A921 94 00            [12] 1056 	subb	a,#0x00
      00A923 40 01            [24] 1057 	jc	00110$
      00A925 22               [24] 1058 	ret
      00A926                       1059 00110$:
                                   1060 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00A926 EA               [12] 1061 	mov	a,r2
      00A927 C4               [12] 1062 	swap	a
      00A928 23               [12] 1063 	rl	a
      00A929 54 E0            [12] 1064 	anl	a,#0xe0
      00A92B CB               [12] 1065 	xch	a,r3
      00A92C C4               [12] 1066 	swap	a
      00A92D 23               [12] 1067 	rl	a
      00A92E CB               [12] 1068 	xch	a,r3
      00A92F 6B               [12] 1069 	xrl	a,r3
      00A930 CB               [12] 1070 	xch	a,r3
      00A931 54 E0            [12] 1071 	anl	a,#0xe0
      00A933 CB               [12] 1072 	xch	a,r3
      00A934 6B               [12] 1073 	xrl	a,r3
      00A935 FA               [12] 1074 	mov	r2,a
      00A936 8B 45            [24] 1075 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00A938 8A 46            [24] 1076 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1077 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00A93A 74 7C            [12] 1078 	mov	a,#0x7c
      00A93C C3               [12] 1079 	clr	c
      00A93D 95 45            [12] 1080 	subb	a,_vial_handle_cmd_sloc0_1_0
      00A93F F8               [12] 1081 	mov	r0,a
      00A940 74 01            [12] 1082 	mov	a,#0x01
      00A942 95 46            [12] 1083 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00A944 F9               [12] 1084 	mov	r1,a
                                   1085 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00A945 C3               [12] 1086 	clr	c
      00A946 E8               [12] 1087 	mov	a,r0
      00A947 94 20            [12] 1088 	subb	a,#0x20
      00A949 E9               [12] 1089 	mov	a,r1
      00A94A 94 00            [12] 1090 	subb	a,#0x00
      00A94C 40 02            [24] 1091 	jc	00142$
      00A94E 78 20            [12] 1092 	mov	r0,#0x20
      00A950                       1093 00142$:
                                   1094 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00A950 79 00            [12] 1095 	mov	r1,#0x00
      00A952                       1096 00134$:
      00A952 C3               [12] 1097 	clr	c
      00A953 E9               [12] 1098 	mov	a,r1
      00A954 98               [12] 1099 	subb	a,r0
      00A955 40 01            [24] 1100 	jc	00267$
      00A957 22               [24] 1101 	ret
      00A958                       1102 00267$:
      00A958 C0 00            [24] 1103 	push	ar0
      00A95A E9               [12] 1104 	mov	a,r1
      00A95B 2E               [12] 1105 	add	a, r6
      00A95C F5 47            [12] 1106 	mov	_vial_handle_cmd_sloc1_1_0,a
      00A95E E4               [12] 1107 	clr	a
      00A95F 3F               [12] 1108 	addc	a, r7
      00A960 F5 48            [12] 1109 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00A962 89 49            [24] 1110 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00A964 75 4A 00         [24] 1111 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00A967 A8 45            [24] 1112 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00A969 AB 46            [24] 1113 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00A96B E5 49            [12] 1114 	mov	a,_vial_handle_cmd_sloc2_1_0
      00A96D 28               [12] 1115 	add	a, r0
      00A96E F8               [12] 1116 	mov	r0,a
      00A96F E5 4A            [12] 1117 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00A971 3B               [12] 1118 	addc	a, r3
      00A972 FB               [12] 1119 	mov	r3,a
      00A973 E8               [12] 1120 	mov	a,r0
      00A974 24 5F            [12] 1121 	add	a, #_keyboard_definition
      00A976 F5 82            [12] 1122 	mov	dpl,a
      00A978 EB               [12] 1123 	mov	a,r3
      00A979 34 B8            [12] 1124 	addc	a, #(_keyboard_definition >> 8)
      00A97B F5 83            [12] 1125 	mov	dph,a
      00A97D E4               [12] 1126 	clr	a
      00A97E 93               [24] 1127 	movc	a,@a+dptr
      00A97F 85 47 82         [24] 1128 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00A982 85 48 83         [24] 1129 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00A985 F0               [24] 1130 	movx	@dptr,a
      00A986 09               [12] 1131 	inc	r1
      00A987 D0 00            [24] 1132 	pop	ar0
                                   1133 ;	quantum/vial.c:246: case vial_get_encoder: {
      00A989 80 C7            [24] 1134 	sjmp	00134$
      00A98B                       1135 00112$:
                                   1136 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00A98B 74 02            [12] 1137 	mov	a,#0x02
      00A98D 12 46 71         [24] 1138 	lcall	_ak820_outline_0043
      00A990 F5 49            [12] 1139 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1140 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00A992 74 03            [12] 1141 	mov	a,#0x03
      00A994 2E               [12] 1142 	add	a, r6
      00A995 F5 47            [12] 1143 	mov	_vial_handle_cmd_sloc1_1_0,a
      00A997 E4               [12] 1144 	clr	a
      00A998 3F               [12] 1145 	addc	a, r7
      00A999 F5 48            [12] 1146 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00A99B 85 47 82         [24] 1147 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00A99E 85 48 83         [24] 1148 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00A9A1 E0               [24] 1149 	movx	a,@dptr
                                   1150 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00A9A2 F5 45            [12] 1151 	mov	_vial_handle_cmd_sloc0_1_0,a
      00A9A4 90 0A CF         [24] 1152 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00A9A7 F0               [24] 1153 	movx	@dptr,a
      00A9A8 90 0A D0         [24] 1154 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00A9AB E4               [12] 1155 	clr	a
      00A9AC F0               [24] 1156 	movx	@dptr,a
      00A9AD 85 49 82         [24] 1157 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00A9B0 C0 07            [24] 1158 	push	ar7
      00A9B2 C0 06            [24] 1159 	push	ar6
      00A9B4 C0 05            [24] 1160 	push	ar5
      00A9B6 C0 04            [24] 1161 	push	ar4
      00A9B8 C0 03            [24] 1162 	push	ar3
      00A9BA C0 02            [24] 1163 	push	ar2
      00A9BC 12 81 10         [24] 1164 	lcall	_dynamic_keymap_get_encoder
      00A9BF 85 82 4B         [24] 1165 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00A9C2 85 83 4C         [24] 1166 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00A9C5 D0 02            [24] 1167 	pop	ar2
      00A9C7 D0 03            [24] 1168 	pop	ar3
      00A9C9 D0 04            [24] 1169 	pop	ar4
      00A9CB D0 05            [24] 1170 	pop	ar5
      00A9CD D0 06            [24] 1171 	pop	ar6
      00A9CF D0 07            [24] 1172 	pop	ar7
                                   1173 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00A9D1 A9 4C            [24] 1174 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00A9D3 12 43 1A         [24] 1175 	lcall	_ak820_outline_0111
      00A9D6 E9               [12] 1176 	mov	a,r1
      00A9D7 F0               [24] 1177 	movx	@dptr,a
                                   1178 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00A9D8 A8 4B            [24] 1179 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00A9DA 12 38 53         [24] 1180 	lcall	_ak820_outline_0112
      00A9DD E8               [12] 1181 	mov	a,r0
      00A9DE F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00A9DF 90 0A CF         [24] 1184 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00A9E2 E5 45            [12] 1185 	mov	a,_vial_handle_cmd_sloc0_1_0
      00A9E4 F0               [24] 1186 	movx	@dptr,a
      00A9E5 90 0A D0         [24] 1187 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00A9E8 74 01            [12] 1188 	mov	a,#0x01
      00A9EA F0               [24] 1189 	movx	@dptr,a
      00A9EB 85 49 82         [24] 1190 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00A9EE C0 03            [24] 1191 	push	ar3
      00A9F0 C0 02            [24] 1192 	push	ar2
      00A9F2 12 81 10         [24] 1193 	lcall	_dynamic_keymap_get_encoder
      00A9F5 85 82 4B         [24] 1194 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00A9F8 85 83 4C         [24] 1195 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00A9FB D0 02            [24] 1196 	pop	ar2
      00A9FD D0 03            [24] 1197 	pop	ar3
                                   1198 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00A9FF A9 4C            [24] 1199 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AA01 12 43 30         [24] 1200 	lcall	_ak820_outline_0134
      00AA04 E9               [12] 1201 	mov	a,r1
      00AA05 F0               [24] 1202 	movx	@dptr,a
                                   1203 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00AA06 A8 4B            [24] 1204 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AA08 85 47 82         [24] 1205 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AA0B 85 48 83         [24] 1206 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AA0E E8               [12] 1207 	mov	a,r0
      00AA0F F0               [24] 1208 	movx	@dptr,a
                                   1209 ;	quantum/vial.c:255: break;
      00AA10 22               [24] 1210 	ret
                                   1211 ;	quantum/vial.c:257: case vial_set_encoder: {
      00AA11                       1212 00113$:
                                   1213 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00AA11 12 37 F1         [24] 1214 	lcall	_ak820_outline_0031
      00AA14 F5 47            [12] 1215 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AA16 12 A7 28         [24] 1216 	lcall	_ak820_outline_0013
      00AA19 F5 49            [12] 1217 	mov	_vial_handle_cmd_sloc2_1_0,a
      00AA1B 12 A7 31         [24] 1218 	lcall	_ak820_outline_0019
      00AA1E E0               [24] 1219 	movx	a,@dptr
                                   1220 ;	assignBit
      00AA1F 24 FF            [12] 1221 	add	a,#0xff
      00AA21 E4               [12] 1222 	clr	a
      00AA22 33               [12] 1223 	rlc	a
      00AA23 F5 4B            [12] 1224 	mov	_vial_handle_cmd_sloc3_1_0,a
      00AA25 12 42 C0         [24] 1225 	lcall	_ak820_outline_0011
      00AA28 E0               [24] 1226 	movx	a,@dptr
      00AA29 F9               [12] 1227 	mov	r1,a
      00AA2A 78 00            [12] 1228 	mov	r0,#0x00
      00AA2C 74 06            [12] 1229 	mov	a,#0x06
      00AA2E 12 37 E9         [24] 1230 	lcall	_ak820_outline_0018
      00AA31 E0               [24] 1231 	movx	a,@dptr
      00AA32 7B 00            [12] 1232 	mov	r3,#0x00
      00AA34 42 00            [12] 1233 	orl	ar0,a
      00AA36 EB               [12] 1234 	mov	a,r3
      00AA37 42 01            [12] 1235 	orl	ar1,a
      00AA39 12 38 6E         [24] 1236 	lcall	_ak820_outline_0145
      00AA3C 12 A8 05         [24] 1237 	lcall	_vial_keycode_firewall
      00AA3F AA 82            [24] 1238 	mov	r2, dpl
      00AA41 AB 83            [24] 1239 	mov	r3, dph
      00AA43 90 0A D2         [24] 1240 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00AA46 E5 49            [12] 1241 	mov	a,_vial_handle_cmd_sloc2_1_0
      00AA48 F0               [24] 1242 	movx	@dptr,a
      00AA49 90 0A D3         [24] 1243 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00AA4C E5 4B            [12] 1244 	mov	a,_vial_handle_cmd_sloc3_1_0
      00AA4E F0               [24] 1245 	movx	@dptr,a
      00AA4F 90 0A D4         [24] 1246 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00AA52 EA               [12] 1247 	mov	a,r2
      00AA53 F0               [24] 1248 	movx	@dptr,a
      00AA54 EB               [12] 1249 	mov	a,r3
      00AA55 A3               [24] 1250 	inc	dptr
      00AA56 F0               [24] 1251 	movx	@dptr,a
      00AA57 85 47 82         [24] 1252 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1253 ;	quantum/vial.c:259: break;
      00AA5A 02 81 78         [24] 1254 	ljmp	_dynamic_keymap_set_encoder
                                   1255 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00AA5D                       1256 00114$:
                                   1257 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00AA5D 90 0C 1C         [24] 1258 	mov	dptr,#_vial_fill_packet_PARM_2
      00AA60 74 FF            [12] 1259 	mov	a,#0xff
      00AA62 12 42 F6         [24] 1260 	lcall	_ak820_outline_0057
      00AA65 C0 07            [24] 1261 	push	ar7
      00AA67 C0 06            [24] 1262 	push	ar6
      00AA69 12 A8 28         [24] 1263 	lcall	_vial_fill_packet
      00AA6C D0 06            [24] 1264 	pop	ar6
      00AA6E D0 07            [24] 1265 	pop	ar7
                                   1266 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00AA70 90 0D DE         [24] 1267 	mov	dptr,#_vial_unlocked
      00AA73 E0               [24] 1268 	movx	a,@dptr
      00AA74 12 43 1A         [24] 1269 	lcall	_ak820_outline_0111
      00AA77 F0               [24] 1270 	movx	@dptr,a
                                   1271 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00AA78 74 01            [12] 1272 	mov	a,#0x01
      00AA7A 2E               [12] 1273 	add	a, r6
      00AA7B FA               [12] 1274 	mov	r2,a
      00AA7C E4               [12] 1275 	clr	a
      00AA7D 3F               [12] 1276 	addc	a, r7
      00AA7E FB               [12] 1277 	mov	r3,a
      00AA7F 90 0D DF         [24] 1278 	mov	dptr,#_vial_unlock_in_progress
      00AA82 E0               [24] 1279 	movx	a,@dptr
      00AA83 12 43 30         [24] 1280 	lcall	_ak820_outline_0134
      00AA86 F0               [24] 1281 	movx	@dptr,a
                                   1282 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AA87 7B 00            [12] 1283 	mov	r3,#0x00
      00AA89                       1284 00137$:
      00AA89 BB 02 00         [24] 1285 	cjne	r3,#0x02,00268$
      00AA8C                       1286 00268$:
      00AA8C 40 01            [24] 1287 	jc	00269$
      00AA8E 22               [24] 1288 	ret
      00AA8F                       1289 00269$:
                                   1290 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00AA8F 8B 01            [24] 1291 	mov	ar1,r3
      00AA91 7A 00            [12] 1292 	mov	r2,#0x00
      00AA93 E9               [12] 1293 	mov	a,r1
      00AA94 29               [12] 1294 	add	a,r1
      00AA95 F5 4B            [12] 1295 	mov	_vial_handle_cmd_sloc3_1_0,a
      00AA97 EA               [12] 1296 	mov	a,r2
      00AA98 33               [12] 1297 	rlc	a
      00AA99 F5 4C            [12] 1298 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00AA9B 74 02            [12] 1299 	mov	a,#0x02
      00AA9D 25 4B            [12] 1300 	add	a, _vial_handle_cmd_sloc3_1_0
      00AA9F F8               [12] 1301 	mov	r0,a
      00AAA0 E4               [12] 1302 	clr	a
      00AAA1 35 4C            [12] 1303 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00AAA3 FA               [12] 1304 	mov	r2,a
      00AAA4 E8               [12] 1305 	mov	a,r0
      00AAA5 2E               [12] 1306 	add	a, r6
      00AAA6 F8               [12] 1307 	mov	r0,a
      00AAA7 EA               [12] 1308 	mov	a,r2
      00AAA8 3F               [12] 1309 	addc	a, r7
      00AAA9 FA               [12] 1310 	mov	r2,a
      00AAAA EB               [12] 1311 	mov	a,r3
      00AAAB 12 AD 31         [24] 1312 	lcall	_ak820_outline_0119
      00AAAE 88 82            [24] 1313 	mov	dpl,r0
      00AAB0 8A 83            [24] 1314 	mov	dph,r2
      00AAB2 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00AAB3 74 03            [12] 1317 	mov	a,#0x03
      00AAB5 25 4B            [12] 1318 	add	a, _vial_handle_cmd_sloc3_1_0
      00AAB7 F9               [12] 1319 	mov	r1,a
      00AAB8 E4               [12] 1320 	clr	a
      00AAB9 35 4C            [12] 1321 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00AABB FA               [12] 1322 	mov	r2,a
      00AABC E9               [12] 1323 	mov	a,r1
      00AABD 2E               [12] 1324 	add	a, r6
      00AABE F9               [12] 1325 	mov	r1,a
      00AABF EA               [12] 1326 	mov	a,r2
      00AAC0 3F               [12] 1327 	addc	a, r7
      00AAC1 FA               [12] 1328 	mov	r2,a
      00AAC2 EB               [12] 1329 	mov	a,r3
      00AAC3 12 AD 26         [24] 1330 	lcall	_ak820_outline_0118
      00AAC6 12 6A 07         [24] 1331 	lcall	_ak820_outline_0129
                                   1332 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AAC9 0B               [12] 1333 	inc	r3
                                   1334 ;	quantum/vial.c:278: case vial_unlock_start: {
      00AACA 80 BD            [24] 1335 	sjmp	00137$
      00AACC                       1336 00116$:
                                   1337 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00AACC 90 0D DF         [24] 1338 	mov	dptr,#_vial_unlock_in_progress
      00AACF E0               [24] 1339 	movx	a,@dptr
      00AAD0 70 03            [24] 1340 	jnz	00118$
      00AAD2 12 A8 4D         [24] 1341 	lcall	_vial_release_held_state
      00AAD5                       1342 00118$:
                                   1343 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00AAD5 90 0D DF         [24] 1344 	mov	dptr,#_vial_unlock_in_progress
      00AAD8 74 01            [12] 1345 	mov	a,#0x01
      00AADA F0               [24] 1346 	movx	@dptr,a
                                   1347 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AADB 90 0D E0         [24] 1348 	mov	dptr,#_vial_unlock_counter
      00AADE 74 1E            [12] 1349 	mov	a,#0x1e
      00AAE0 F0               [24] 1350 	movx	@dptr,a
                                   1351 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00AAE1 90 0C 19         [24] 1352 	mov	dptr,#_vial_unlock_holding
      00AAE4 E4               [12] 1353 	clr	a
      00AAE5 F0               [24] 1354 	movx	@dptr,a
                                   1355 ;	quantum/vial.c:287: break;
      00AAE6 22               [24] 1356 	ret
                                   1357 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00AAE7                       1358 00119$:
                                   1359 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00AAE7 90 0D DE         [24] 1360 	mov	dptr,#_vial_unlocked
      00AAEA E0               [24] 1361 	movx	a,@dptr
      00AAEB 12 43 1A         [24] 1362 	lcall	_ak820_outline_0111
      00AAEE F0               [24] 1363 	movx	@dptr,a
                                   1364 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00AAEF 90 0D DF         [24] 1365 	mov	dptr,#_vial_unlock_in_progress
      00AAF2 E0               [24] 1366 	movx	a,@dptr
      00AAF3 12 38 53         [24] 1367 	lcall	_ak820_outline_0112
      00AAF6 F0               [24] 1368 	movx	@dptr,a
                                   1369 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00AAF7 74 02            [12] 1370 	mov	a,#0x02
      00AAF9 2E               [12] 1371 	add	a, r6
      00AAFA FA               [12] 1372 	mov	r2,a
      00AAFB E4               [12] 1373 	clr	a
      00AAFC 3F               [12] 1374 	addc	a, r7
      00AAFD FB               [12] 1375 	mov	r3,a
      00AAFE 90 0D E0         [24] 1376 	mov	dptr,#_vial_unlock_counter
      00AB01 E0               [24] 1377 	movx	a,@dptr
      00AB02 12 43 30         [24] 1378 	lcall	_ak820_outline_0134
      00AB05 F0               [24] 1379 	movx	@dptr,a
                                   1380 ;	quantum/vial.c:293: break;
      00AB06 22               [24] 1381 	ret
                                   1382 ;	quantum/vial.c:295: case vial_lock: {
      00AB07                       1383 00120$:
                                   1384 ;	quantum/vial.c:297: vial_unlocked = 0;
      00AB07 90 0D DE         [24] 1385 	mov	dptr,#_vial_unlocked
      00AB0A E4               [12] 1386 	clr	a
      00AB0B F0               [24] 1387 	movx	@dptr,a
                                   1388 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00AB0C 90 0D DF         [24] 1389 	mov	dptr,#_vial_unlock_in_progress
      00AB0F F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00AB10 90 0C 19         [24] 1392 	mov	dptr,#_vial_unlock_holding
      00AB13 F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	quantum/vial.c:301: break;
      00AB14 22               [24] 1395 	ret
                                   1396 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00AB15                       1397 00121$:
                                   1398 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00AB15 90 0C 1C         [24] 1399 	mov	dptr,#_vial_fill_packet_PARM_2
      00AB18 74 FF            [12] 1400 	mov	a,#0xff
      00AB1A 12 42 F6         [24] 1401 	lcall	_ak820_outline_0057
                                   1402 ;	quantum/vial.c:314: break;
      00AB1D 02 A8 28         [24] 1403 	ljmp	_vial_fill_packet
                                   1404 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00AB20                       1405 00122$:
                                   1406 ;	quantum/vial.c:347: switch (msg[2]) {
      00AB20 12 37 F1         [24] 1407 	lcall	_ak820_outline_0031
      00AB23 FB               [12] 1408 	mov	r3,a
      00AB24 60 0C            [24] 1409 	jz	00123$
      00AB26 BB 03 02         [24] 1410 	cjne	r3,#0x03,00272$
      00AB29 80 31            [24] 1411 	sjmp	00124$
      00AB2B                       1412 00272$:
      00AB2B BB 04 03         [24] 1413 	cjne	r3,#0x04,00273$
      00AB2E 02 AB C0         [24] 1414 	ljmp	00125$
      00AB31                       1415 00273$:
      00AB31 22               [24] 1416 	ret
                                   1417 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00AB32                       1418 00123$:
                                   1419 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00AB32 90 0C 1C         [24] 1420 	mov	dptr,#_vial_fill_packet_PARM_2
      00AB35 E4               [12] 1421 	clr	a
      00AB36 12 42 F6         [24] 1422 	lcall	_ak820_outline_0057
      00AB39 C0 07            [24] 1423 	push	ar7
      00AB3B C0 06            [24] 1424 	push	ar6
      00AB3D 12 A8 28         [24] 1425 	lcall	_vial_fill_packet
      00AB40 D0 06            [24] 1426 	pop	ar6
      00AB42 D0 07            [24] 1427 	pop	ar7
                                   1428 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00AB44 12 43 1A         [24] 1429 	lcall	_ak820_outline_0111
      00AB47 E4               [12] 1430 	clr	a
      00AB48 12 42 F6         [24] 1431 	lcall	_ak820_outline_0057
                                   1432 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00AB4B A3               [24] 1433 	inc	dptr
      00AB4C 74 08            [12] 1434 	mov	a,#0x08
      00AB4E 12 42 CA         [24] 1435 	lcall	_ak820_outline_0028
                                   1436 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00AB51 E4               [12] 1437 	clr	a
      00AB52 F0               [24] 1438 	movx	@dptr,a
                                   1439 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00AB53 74 1F            [12] 1440 	mov	a,#0x1f
      00AB55 12 37 E9         [24] 1441 	lcall	_ak820_outline_0018
      00AB58 74 01            [12] 1442 	mov	a,#0x01
      00AB5A F0               [24] 1443 	movx	@dptr,a
                                   1444 ;	quantum/vial.c:356: break;
      00AB5B 22               [24] 1445 	ret
                                   1446 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00AB5C                       1447 00124$:
                                   1448 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00AB5C 12 A7 28         [24] 1449 	lcall	_ak820_outline_0013
      00AB5F FB               [12] 1450 	mov	r3,a
                                   1451 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00AB60 90 0C 23         [24] 1452 	mov	dptr,#_vial_handle_cmd_entry_70000_645
      00AB63 12 4D 21         [24] 1453 	lcall	_ak820_outline_0159
      00AB66 90 0C 25         [24] 1454 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0002)
      00AB69 F0               [24] 1455 	movx	@dptr,a
      00AB6A A3               [24] 1456 	inc	dptr
      00AB6B F0               [24] 1457 	movx	@dptr,a
      00AB6C 90 0C 27         [24] 1458 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0004)
      00AB6F F0               [24] 1459 	movx	@dptr,a
      00AB70 A3               [24] 1460 	inc	dptr
      00AB71 F0               [24] 1461 	movx	@dptr,a
      00AB72 90 0C 29         [24] 1462 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0006)
      00AB75 F0               [24] 1463 	movx	@dptr,a
      00AB76 A3               [24] 1464 	inc	dptr
      00AB77 F0               [24] 1465 	movx	@dptr,a
      00AB78 90 0C 2B         [24] 1466 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0008)
      00AB7B F0               [24] 1467 	movx	@dptr,a
      00AB7C A3               [24] 1468 	inc	dptr
      00AB7D F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00AB7E 90 0A D7         [24] 1471 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00AB81 74 23            [12] 1472 	mov	a,#_vial_handle_cmd_entry_70000_645
      00AB83 F0               [24] 1473 	movx	@dptr,a
      00AB84 74 0C            [12] 1474 	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
      00AB86 12 38 1E         [24] 1475 	lcall	_ak820_outline_0067
      00AB89 8B 82            [24] 1476 	mov	dpl, r3
      00AB8B C0 07            [24] 1477 	push	ar7
      00AB8D C0 06            [24] 1478 	push	ar6
      00AB8F C0 05            [24] 1479 	push	ar5
      00AB91 C0 04            [24] 1480 	push	ar4
      00AB93 12 81 E5         [24] 1481 	lcall	_dynamic_keymap_get_combo
      00AB96 AA 82            [24] 1482 	mov	r2, dpl
      00AB98 D0 04            [24] 1483 	pop	ar4
      00AB9A D0 05            [24] 1484 	pop	ar5
      00AB9C D0 06            [24] 1485 	pop	ar6
      00AB9E D0 07            [24] 1486 	pop	ar7
      00ABA0 12 43 1A         [24] 1487 	lcall	_ak820_outline_0111
      00ABA3 EA               [12] 1488 	mov	a,r2
      00ABA4 F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00ABA5 7B 00            [12] 1491 	mov	r3,#0x00
      00ABA7 90 0D 5F         [24] 1492 	mov	dptr,#___memcpy_PARM_2
      00ABAA 74 23            [12] 1493 	mov	a,#_vial_handle_cmd_entry_70000_645
      00ABAC F0               [24] 1494 	movx	@dptr,a
      00ABAD 74 0C            [12] 1495 	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
      00ABAF 12 38 1E         [24] 1496 	lcall	_ak820_outline_0067
      00ABB2 90 0D 62         [24] 1497 	mov	dptr,#___memcpy_PARM_3
      00ABB5 12 8A BF         [24] 1498 	lcall	_ak820_outline_0085
      00ABB8 12 38 53         [24] 1499 	lcall	_ak820_outline_0112
      00ABBB 8B F0            [24] 1500 	mov	b, r3
                                   1501 ;	quantum/vial.c:387: break;
      00ABBD 02 B2 E1         [24] 1502 	ljmp	___memcpy
                                   1503 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00ABC0                       1504 00125$:
                                   1505 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00ABC0 12 A7 28         [24] 1506 	lcall	_ak820_outline_0013
      00ABC3 FD               [12] 1507 	mov	r5,a
                                   1508 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00ABC4 74 04            [12] 1509 	mov	a,#0x04
      00ABC6 2E               [12] 1510 	add	a, r6
      00ABC7 FB               [12] 1511 	mov	r3,a
      00ABC8 E4               [12] 1512 	clr	a
      00ABC9 3F               [12] 1513 	addc	a, r7
      00ABCA FC               [12] 1514 	mov	r4,a
      00ABCB 90 0D 5F         [24] 1515 	mov	dptr,#___memcpy_PARM_2
      00ABCE EB               [12] 1516 	mov	a,r3
      00ABCF F0               [24] 1517 	movx	@dptr,a
      00ABD0 EC               [12] 1518 	mov	a,r4
      00ABD1 12 38 1E         [24] 1519 	lcall	_ak820_outline_0067
      00ABD4 90 0D 62         [24] 1520 	mov	dptr,#___memcpy_PARM_3
      00ABD7 12 8A BF         [24] 1521 	lcall	_ak820_outline_0085
      00ABDA 90 0C 2D         [24] 1522 	mov	dptr,#_vial_handle_cmd_entry_70000_646
      00ABDD F5 F0            [12] 1523 	mov	b,a
      00ABDF C0 07            [24] 1524 	push	ar7
      00ABE1 C0 06            [24] 1525 	push	ar6
      00ABE3 C0 05            [24] 1526 	push	ar5
      00ABE5 12 B2 E1         [24] 1527 	lcall	___memcpy
                                   1528 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00ABE8 90 0C 35         [24] 1529 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00ABEB 12 38 3C         [24] 1530 	lcall	_ak820_outline_0094
      00ABEE 12 33 FC         [24] 1531 	lcall	_ak820_outline_0116
      00ABF1 12 A8 05         [24] 1532 	lcall	_vial_keycode_firewall
      00ABF4 AB 82            [24] 1533 	mov	r3, dpl
      00ABF6 AC 83            [24] 1534 	mov	r4, dph
      00ABF8 D0 05            [24] 1535 	pop	ar5
      00ABFA 90 0C 35         [24] 1536 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00ABFD 12 38 2A         [24] 1537 	lcall	_ak820_outline_0071
                                   1538 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00AC00 90 0A DB         [24] 1539 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00AC03 74 2D            [12] 1540 	mov	a,#_vial_handle_cmd_entry_70000_646
      00AC05 F0               [24] 1541 	movx	@dptr,a
      00AC06 74 0C            [12] 1542 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00AC08 12 38 1E         [24] 1543 	lcall	_ak820_outline_0067
      00AC0B 8D 82            [24] 1544 	mov	dpl, r5
      00AC0D 12 82 89         [24] 1545 	lcall	_dynamic_keymap_set_combo
      00AC10 AC 82            [24] 1546 	mov	r4, dpl
      00AC12 D0 06            [24] 1547 	pop	ar6
      00AC14 D0 07            [24] 1548 	pop	ar7
      00AC16 12 43 1A         [24] 1549 	lcall	_ak820_outline_0111
      00AC19 EC               [12] 1550 	mov	a,r4
      00AC1A F0               [24] 1551 	movx	@dptr,a
                                   1552 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00AC1B EC               [12] 1553 	mov	a,r4
      00AC1C 70 03            [24] 1554 	jnz	00139$
                                   1555 ;	quantum/vial.c:423: }
                                   1556 ;	quantum/vial.c:424: }
      00AC1E 02 35 38         [24] 1557 	ljmp	_ak820_combo_reload
      00AC21                       1558 00139$:
      00AC21 22               [24] 1559 	ret
                                   1560 ;------------------------------------------------------------
                                   1561 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1562 ;------------------------------------------------------------
                                   1563 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_648'
                                   1564 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_655'
                                   1565 ;------------------------------------------------------------
                                   1566 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1567 ;	-----------------------------------------
                                   1568 ;	 function vial_keycode_down
                                   1569 ;	-----------------------------------------
      00AC22                       1570 _vial_keycode_down:
      00AC22 12 38 47         [24] 1571 	lcall	_ak820_outline_0100
      00AC25 90 0C 39         [24] 1572 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AC28 12 38 42         [24] 1573 	lcall	_ak820_outline_0099
                                   1574 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00AC2B 90 0C 39         [24] 1575 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AC2E 12 37 C0         [24] 1576 	lcall	_ak820_outline_0007
      00AC31 74 E0            [12] 1577 	mov	a,#0x100 - 0x20
      00AC33 2D               [12] 1578 	add	a,r5
      00AC34 50 19            [24] 1579 	jnc	00104$
      00AC36 C3               [12] 1580 	clr	c
      00AC37 74 FF            [12] 1581 	mov	a,#0xff
      00AC39 9C               [12] 1582 	subb	a,r4
      00AC3A 74 4F            [12] 1583 	mov	a,#0x4f
      00AC3C 9D               [12] 1584 	subb	a,r5
      00AC3D 40 10            [24] 1585 	jc	00104$
                                   1586 ;	free result
                                   1587 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00AC3F 90 0C 39         [24] 1588 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AC42 EE               [12] 1589 	mov	a,r6
      00AC43 12 38 58         [24] 1590 	lcall	_ak820_outline_0115
                                   1591 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00AC46 90 0C 39         [24] 1592 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AC49 E0               [24] 1593 	movx	a,@dptr
      00AC4A 24 FE            [12] 1594 	add	a,#0xff - 0x01
      00AC4C 40 01            [24] 1595 	jc	00104$
                                   1596 ;	free result
      00AC4E 22               [24] 1597 	ret
      00AC4F                       1598 00104$:
                                   1599 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00AC4F 90 0C 39         [24] 1600 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AC52 12 AD 0D         [24] 1601 	lcall	_ak820_outline_0022
                                   1602 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00AC55 40 06            [24] 1603 	jc	00107$
                                   1604 ;	free result
                                   1605 ;	quantum/vial.c:440: register_code16(keycode);
      00AC57 12 43 1A         [24] 1606 	lcall	_ak820_outline_0111
      00AC5A 02 99 A6         [24] 1607 	ljmp	_register_code16
      00AC5D                       1608 00107$:
                                   1609 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00AC5D 90 0C 3F         [24] 1610 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0004)
      00AC60 74 01            [12] 1611 	mov	a,#0x01
      00AC62 F0               [24] 1612 	movx	@dptr,a
      00AC63 90 0C 3C         [24] 1613 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0001)
      00AC66 74 F0            [12] 1614 	mov	a,#0xf0
      00AC68 F0               [24] 1615 	movx	@dptr,a
      00AC69 90 0C 3B         [24] 1616 	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
      00AC6C F0               [24] 1617 	movx	@dptr,a
      00AC6D 90 0C 40         [24] 1618 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0005)
      00AC70 74 01            [12] 1619 	mov	a,#0x01
      00AC72 F0               [24] 1620 	movx	@dptr,a
      00AC73 12 47 1D         [24] 1621 	lcall	_timer_read
      00AC76 12 43 1F         [24] 1622 	lcall	_ak820_outline_0125
      00AC79 43 06 01         [24] 1623 	orl	ar6,#0x01
      00AC7C 90 0C 3D         [24] 1624 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0002)
      00AC7F 12 46 8C         [24] 1625 	lcall	_ak820_outline_0055
                                   1626 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00AC82 90 0C 3B         [24] 1627 	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
                                   1628 ;	quantum/vial.c:448: }
      00AC85 02 6E 30         [24] 1629 	ljmp	_ak820_action_exec
                                   1630 ;------------------------------------------------------------
                                   1631 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1632 ;------------------------------------------------------------
                                   1633 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_656'
                                   1634 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_663'
                                   1635 ;------------------------------------------------------------
                                   1636 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1637 ;	-----------------------------------------
                                   1638 ;	 function vial_keycode_up
                                   1639 ;	-----------------------------------------
      00AC88                       1640 _vial_keycode_up:
      00AC88 12 38 47         [24] 1641 	lcall	_ak820_outline_0100
      00AC8B 90 0C 41         [24] 1642 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AC8E 12 38 42         [24] 1643 	lcall	_ak820_outline_0099
                                   1644 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00AC91 90 0C 41         [24] 1645 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AC94 12 37 C0         [24] 1646 	lcall	_ak820_outline_0007
      00AC97 74 E0            [12] 1647 	mov	a,#0x100 - 0x20
      00AC99 2D               [12] 1648 	add	a,r5
      00AC9A 50 19            [24] 1649 	jnc	00104$
      00AC9C C3               [12] 1650 	clr	c
      00AC9D 74 FF            [12] 1651 	mov	a,#0xff
      00AC9F 9C               [12] 1652 	subb	a,r4
      00ACA0 74 4F            [12] 1653 	mov	a,#0x4f
      00ACA2 9D               [12] 1654 	subb	a,r5
      00ACA3 40 10            [24] 1655 	jc	00104$
                                   1656 ;	free result
                                   1657 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00ACA5 90 0C 41         [24] 1658 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00ACA8 EE               [12] 1659 	mov	a,r6
      00ACA9 12 38 58         [24] 1660 	lcall	_ak820_outline_0115
                                   1661 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00ACAC 90 0C 41         [24] 1662 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00ACAF E0               [24] 1663 	movx	a,@dptr
      00ACB0 24 FE            [12] 1664 	add	a,#0xff - 0x01
      00ACB2 40 01            [24] 1665 	jc	00104$
                                   1666 ;	free result
      00ACB4 22               [24] 1667 	ret
      00ACB5                       1668 00104$:
                                   1669 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00ACB5 90 0C 41         [24] 1670 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00ACB8 12 AD 0D         [24] 1671 	lcall	_ak820_outline_0022
                                   1672 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00ACBB 40 06            [24] 1673 	jc	00107$
                                   1674 ;	free result
                                   1675 ;	quantum/vial.c:462: unregister_code16(keycode);
      00ACBD 12 43 1A         [24] 1676 	lcall	_ak820_outline_0111
      00ACC0 02 99 EB         [24] 1677 	ljmp	_unregister_code16
      00ACC3                       1678 00107$:
                                   1679 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00ACC3 90 0C 47         [24] 1680 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0004)
      00ACC6 74 01            [12] 1681 	mov	a,#0x01
      00ACC8 F0               [24] 1682 	movx	@dptr,a
      00ACC9 90 0C 44         [24] 1683 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0001)
      00ACCC 74 F0            [12] 1684 	mov	a,#0xf0
      00ACCE F0               [24] 1685 	movx	@dptr,a
      00ACCF 90 0C 43         [24] 1686 	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
      00ACD2 F0               [24] 1687 	movx	@dptr,a
      00ACD3 90 0C 48         [24] 1688 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0005)
      00ACD6 E4               [12] 1689 	clr	a
      00ACD7 F0               [24] 1690 	movx	@dptr,a
      00ACD8 12 47 1D         [24] 1691 	lcall	_timer_read
      00ACDB 12 43 1F         [24] 1692 	lcall	_ak820_outline_0125
      00ACDE 43 06 01         [24] 1693 	orl	ar6,#0x01
      00ACE1 90 0C 45         [24] 1694 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0002)
      00ACE4 12 46 8C         [24] 1695 	lcall	_ak820_outline_0055
                                   1696 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00ACE7 90 0C 43         [24] 1697 	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
                                   1698 ;	quantum/vial.c:470: }
      00ACEA 02 6E 30         [24] 1699 	ljmp	_ak820_action_exec
                                   1700 ;------------------------------------------------------------
                                   1701 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1702 ;------------------------------------------------------------
                                   1703 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_664'
                                   1704 ;i             Allocated with name '_vial_keycode_tap_i_30000_667'
                                   1705 ;------------------------------------------------------------
                                   1706 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1707 ;	-----------------------------------------
                                   1708 ;	 function vial_keycode_tap
                                   1709 ;	-----------------------------------------
      00ACED                       1710 _vial_keycode_tap:
      00ACED 12 38 47         [24] 1711 	lcall	_ak820_outline_0100
      00ACF0 90 0C 49         [24] 1712 	mov	dptr,#_vial_keycode_tap_keycode_10000_664
      00ACF3 12 38 42         [24] 1713 	lcall	_ak820_outline_0099
                                   1714 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00ACF6 90 0C 49         [24] 1715 	mov	dptr,#_vial_keycode_tap_keycode_10000_664
      00ACF9 12 37 A2         [24] 1716 	lcall	_ak820_outline_0004
      00ACFC C0 07            [24] 1717 	push	ar7
      00ACFE C0 06            [24] 1718 	push	ar6
      00AD00 12 AC 22         [24] 1719 	lcall	_vial_keycode_down
      00AD03 D0 06            [24] 1720 	pop	ar6
      00AD05 D0 07            [24] 1721 	pop	ar7
                                   1722 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00AD07 12 43 1A         [24] 1723 	lcall	_ak820_outline_0111
                                   1724 ;	quantum/vial.c:476: }
      00AD0A 02 AC 88         [24] 1725 	ljmp	_vial_keycode_up
                                   1726 ;------------------------------------------------------------
                                   1727 ;Allocation info for local variables in function 'process_record_vial'
                                   1728 ;------------------------------------------------------------
                                   1729 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1730 ;keycode       Allocated with name '_process_record_vial_keycode_10000_669'
                                   1731 ;------------------------------------------------------------
                                   1732 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1733 ;	-----------------------------------------
                                   1734 	.area CSEG    (CODE)
                                   1735 	.area CONST   (CODE)
                                   1736 	.area CONST   (CODE)
      00B85F                       1737 _keyboard_definition:
      00B85F FD                    1738 	.db #0xfd	; 253
      00B860 37                    1739 	.db #0x37	; 55	'7'
      00B861 7A                    1740 	.db #0x7a	; 122	'z'
      00B862 58                    1741 	.db #0x58	; 88	'X'
      00B863 5A                    1742 	.db #0x5a	; 90	'Z'
      00B864 00                    1743 	.db #0x00	; 0
      00B865 00                    1744 	.db #0x00	; 0
      00B866 04                    1745 	.db #0x04	; 4
      00B867 E6                    1746 	.db #0xe6	; 230
      00B868 D6                    1747 	.db #0xd6	; 214
      00B869 B4                    1748 	.db #0xb4	; 180
      00B86A 46                    1749 	.db #0x46	; 70	'F'
      00B86B 02                    1750 	.db #0x02	; 2
      00B86C 00                    1751 	.db #0x00	; 0
      00B86D 21                    1752 	.db #0x21	; 33
      00B86E 01                    1753 	.db #0x01	; 1
      00B86F 00                    1754 	.db #0x00	; 0
      00B870 00                    1755 	.db #0x00	; 0
      00B871 00                    1756 	.db #0x00	; 0
      00B872 00                    1757 	.db #0x00	; 0
      00B873 37                    1758 	.db #0x37	; 55	'7'
      00B874 27                    1759 	.db #0x27	; 39
      00B875 97                    1760 	.db #0x97	; 151
      00B876 D6                    1761 	.db #0xd6	; 214
      00B877 E0                    1762 	.db #0xe0	; 224
      00B878 03                    1763 	.db #0x03	; 3
      00B879 CB                    1764 	.db #0xcb	; 203
      00B87A 01                    1765 	.db #0x01	; 1
      00B87B 3C                    1766 	.db #0x3c	; 60
      00B87C 00                    1767 	.db #0x00	; 0
      00B87D 00                    1768 	.db #0x00	; 0
      00B87E 3D                    1769 	.db #0x3d	; 61
      00B87F 88                    1770 	.db #0x88	; 136
      00B880 CD                    1771 	.db #0xcd	; 205
      00B881 A5                    1772 	.db #0xa5	; 165
      00B882 AA                    1773 	.db #0xaa	; 170
      00B883 E5                    1774 	.db #0xe5	; 229
      00B884 A8                    1775 	.db #0xa8	; 168
      00B885 76                    1776 	.db #0x76	; 118	'v'
      00B886 F6                    1777 	.db #0xf6	; 246
      00B887 43                    1778 	.db #0x43	; 67	'C'
      00B888 0E                    1779 	.db #0x0e	; 14
      00B889 D2                    1780 	.db #0xd2	; 210
      00B88A 90                    1781 	.db #0x90	; 144
      00B88B 7D                    1782 	.db #0x7d	; 125
      00B88C 94                    1783 	.db #0x94	; 148
      00B88D 79                    1784 	.db #0x79	; 121	'y'
      00B88E 78                    1785 	.db #0x78	; 120	'x'
      00B88F EF                    1786 	.db #0xef	; 239
      00B890 49                    1787 	.db #0x49	; 73	'I'
      00B891 3E                    1788 	.db #0x3e	; 62
      00B892 EF                    1789 	.db #0xef	; 239
      00B893 FD                    1790 	.db #0xfd	; 253
      00B894 8F                    1791 	.db #0x8f	; 143
      00B895 EF                    1792 	.db #0xef	; 239
      00B896 00                    1793 	.db #0x00	; 0
      00B897 C6                    1794 	.db #0xc6	; 198
      00B898 D1                    1795 	.db #0xd1	; 209
      00B899 DB                    1796 	.db #0xdb	; 219
      00B89A FB                    1797 	.db #0xfb	; 251
      00B89B EB                    1798 	.db #0xeb	; 235
      00B89C DE                    1799 	.db #0xde	; 222
      00B89D 66                    1800 	.db #0x66	; 102	'f'
      00B89E 63                    1801 	.db #0x63	; 99	'c'
      00B89F 0C                    1802 	.db #0x0c	; 12
      00B8A0 92                    1803 	.db #0x92	; 146
      00B8A1 7B                    1804 	.db #0x7b	; 123
      00B8A2 F9                    1805 	.db #0xf9	; 249
      00B8A3 D4                    1806 	.db #0xd4	; 212
      00B8A4 7A                    1807 	.db #0x7a	; 122	'z'
      00B8A5 4F                    1808 	.db #0x4f	; 79	'O'
      00B8A6 83                    1809 	.db #0x83	; 131
      00B8A7 4B                    1810 	.db #0x4b	; 75	'K'
      00B8A8 86                    1811 	.db #0x86	; 134
      00B8A9 0E                    1812 	.db #0x0e	; 14
      00B8AA 6A                    1813 	.db #0x6a	; 106	'j'
      00B8AB F2                    1814 	.db #0xf2	; 242
      00B8AC 22                    1815 	.db #0x22	; 34
      00B8AD 22                    1816 	.db #0x22	; 34
      00B8AE 0B                    1817 	.db #0x0b	; 11
      00B8AF 03                    1818 	.db #0x03	; 3
      00B8B0 BA                    1819 	.db #0xba	; 186
      00B8B1 67                    1820 	.db #0x67	; 103	'g'
      00B8B2 9B                    1821 	.db #0x9b	; 155
      00B8B3 7A                    1822 	.db #0x7a	; 122	'z'
      00B8B4 E1                    1823 	.db #0xe1	; 225
      00B8B5 BC                    1824 	.db #0xbc	; 188
      00B8B6 37                    1825 	.db #0x37	; 55	'7'
      00B8B7 26                    1826 	.db #0x26	; 38
      00B8B8 46                    1827 	.db #0x46	; 70	'F'
      00B8B9 78                    1828 	.db #0x78	; 120	'x'
      00B8BA 05                    1829 	.db #0x05	; 5
      00B8BB 0D                    1830 	.db #0x0d	; 13
      00B8BC 95                    1831 	.db #0x95	; 149
      00B8BD 02                    1832 	.db #0x02	; 2
      00B8BE E4                    1833 	.db #0xe4	; 228
      00B8BF 18                    1834 	.db #0x18	; 24
      00B8C0 CA                    1835 	.db #0xca	; 202
      00B8C1 33                    1836 	.db #0x33	; 51	'3'
      00B8C2 EA                    1837 	.db #0xea	; 234
      00B8C3 24                    1838 	.db #0x24	; 36
      00B8C4 C8                    1839 	.db #0xc8	; 200
      00B8C5 81                    1840 	.db #0x81	; 129
      00B8C6 4E                    1841 	.db #0x4e	; 78	'N'
      00B8C7 47                    1842 	.db #0x47	; 71	'G'
      00B8C8 A8                    1843 	.db #0xa8	; 168
      00B8C9 44                    1844 	.db #0x44	; 68	'D'
      00B8CA DD                    1845 	.db #0xdd	; 221
      00B8CB 91                    1846 	.db #0x91	; 145
      00B8CC 6D                    1847 	.db #0x6d	; 109	'm'
      00B8CD 69                    1848 	.db #0x69	; 105	'i'
      00B8CE DB                    1849 	.db #0xdb	; 219
      00B8CF 4F                    1850 	.db #0x4f	; 79	'O'
      00B8D0 3A                    1851 	.db #0x3a	; 58
      00B8D1 43                    1852 	.db #0x43	; 67	'C'
      00B8D2 9D                    1853 	.db #0x9d	; 157
      00B8D3 26                    1854 	.db #0x26	; 38
      00B8D4 49                    1855 	.db #0x49	; 73	'I'
      00B8D5 4C                    1856 	.db #0x4c	; 76	'L'
      00B8D6 EF                    1857 	.db #0xef	; 239
      00B8D7 2B                    1858 	.db #0x2b	; 43
      00B8D8 D8                    1859 	.db #0xd8	; 216
      00B8D9 55                    1860 	.db #0x55	; 85	'U'
      00B8DA 95                    1861 	.db #0x95	; 149
      00B8DB 70                    1862 	.db #0x70	; 112	'p'
      00B8DC B1                    1863 	.db #0xb1	; 177
      00B8DD CC                    1864 	.db #0xcc	; 204
      00B8DE CF                    1865 	.db #0xcf	; 207
      00B8DF 13                    1866 	.db #0x13	; 19
      00B8E0 32                    1867 	.db #0x32	; 50	'2'
      00B8E1 6A                    1868 	.db #0x6a	; 106	'j'
      00B8E2 A1                    1869 	.db #0xa1	; 161
      00B8E3 FF                    1870 	.db #0xff	; 255
      00B8E4 99                    1871 	.db #0x99	; 153
      00B8E5 61                    1872 	.db #0x61	; 97	'a'
      00B8E6 95                    1873 	.db #0x95	; 149
      00B8E7 B1                    1874 	.db #0xb1	; 177
      00B8E8 89                    1875 	.db #0x89	; 137
      00B8E9 9B                    1876 	.db #0x9b	; 155
      00B8EA 11                    1877 	.db #0x11	; 17
      00B8EB D9                    1878 	.db #0xd9	; 217
      00B8EC 35                    1879 	.db #0x35	; 53	'5'
      00B8ED 78                    1880 	.db #0x78	; 120	'x'
      00B8EE ED                    1881 	.db #0xed	; 237
      00B8EF CD                    1882 	.db #0xcd	; 205
      00B8F0 94                    1883 	.db #0x94	; 148
      00B8F1 6E                    1884 	.db #0x6e	; 110	'n'
      00B8F2 60                    1885 	.db #0x60	; 96
      00B8F3 8E                    1886 	.db #0x8e	; 142
      00B8F4 63                    1887 	.db #0x63	; 99	'c'
      00B8F5 8B                    1888 	.db #0x8b	; 139
      00B8F6 FF                    1889 	.db #0xff	; 255
      00B8F7 4E                    1890 	.db #0x4e	; 78	'N'
      00B8F8 20                    1891 	.db #0x20	; 32
      00B8F9 7A                    1892 	.db #0x7a	; 122	'z'
      00B8FA B5                    1893 	.db #0xb5	; 181
      00B8FB 87                    1894 	.db #0x87	; 135
      00B8FC C2                    1895 	.db #0xc2	; 194
      00B8FD 35                    1896 	.db #0x35	; 53	'5'
      00B8FE A4                    1897 	.db #0xa4	; 164
      00B8FF 6D                    1898 	.db #0x6d	; 109	'm'
      00B900 18                    1899 	.db #0x18	; 24
      00B901 C1                    1900 	.db #0xc1	; 193
      00B902 A3                    1901 	.db #0xa3	; 163
      00B903 DB                    1902 	.db #0xdb	; 219
      00B904 53                    1903 	.db #0x53	; 83	'S'
      00B905 1D                    1904 	.db #0x1d	; 29
      00B906 EC                    1905 	.db #0xec	; 236
      00B907 F0                    1906 	.db #0xf0	; 240
      00B908 BF                    1907 	.db #0xbf	; 191
      00B909 4A                    1908 	.db #0x4a	; 74	'J'
      00B90A 4C                    1909 	.db #0x4c	; 76	'L'
      00B90B 4A                    1910 	.db #0x4a	; 74	'J'
      00B90C C4                    1911 	.db #0xc4	; 196
      00B90D AA                    1912 	.db #0xaa	; 170
      00B90E 37                    1913 	.db #0x37	; 55	'7'
      00B90F 19                    1914 	.db #0x19	; 25
      00B910 34                    1915 	.db #0x34	; 52	'4'
      00B911 3F                    1916 	.db #0x3f	; 63
      00B912 A1                    1917 	.db #0xa1	; 161
      00B913 D3                    1918 	.db #0xd3	; 211
      00B914 1A                    1919 	.db #0x1a	; 26
      00B915 5C                    1920 	.db #0x5c	; 92
      00B916 03                    1921 	.db #0x03	; 3
      00B917 4D                    1922 	.db #0x4d	; 77	'M'
      00B918 BC                    1923 	.db #0xbc	; 188
      00B919 10                    1924 	.db #0x10	; 16
      00B91A 2E                    1925 	.db #0x2e	; 46
      00B91B 80                    1926 	.db #0x80	; 128
      00B91C F7                    1927 	.db #0xf7	; 247
      00B91D D6                    1928 	.db #0xd6	; 214
      00B91E 82                    1929 	.db #0x82	; 130
      00B91F 24                    1930 	.db #0x24	; 36
      00B920 4C                    1931 	.db #0x4c	; 76	'L'
      00B921 87                    1932 	.db #0x87	; 135
      00B922 B9                    1933 	.db #0xb9	; 185
      00B923 F8                    1934 	.db #0xf8	; 248
      00B924 BE                    1935 	.db #0xbe	; 190
      00B925 67                    1936 	.db #0x67	; 103	'g'
      00B926 96                    1937 	.db #0x96	; 150
      00B927 89                    1938 	.db #0x89	; 137
      00B928 30                    1939 	.db #0x30	; 48	'0'
      00B929 C8                    1940 	.db #0xc8	; 200
      00B92A 8D                    1941 	.db #0x8d	; 141
      00B92B 2C                    1942 	.db #0x2c	; 44
      00B92C F5                    1943 	.db #0xf5	; 245
      00B92D 06                    1944 	.db #0x06	; 6
      00B92E 05                    1945 	.db #0x05	; 5
      00B92F 7C                    1946 	.db #0x7c	; 124
      00B930 48                    1947 	.db #0x48	; 72	'H'
      00B931 1B                    1948 	.db #0x1b	; 27
      00B932 76                    1949 	.db #0x76	; 118	'v'
      00B933 AA                    1950 	.db #0xaa	; 170
      00B934 3D                    1951 	.db #0x3d	; 61
      00B935 28                    1952 	.db #0x28	; 40
      00B936 FC                    1953 	.db #0xfc	; 252
      00B937 80                    1954 	.db #0x80	; 128
      00B938 75                    1955 	.db #0x75	; 117	'u'
      00B939 EB                    1956 	.db #0xeb	; 235
      00B93A 78                    1957 	.db #0x78	; 120	'x'
      00B93B D0                    1958 	.db #0xd0	; 208
      00B93C 8A                    1959 	.db #0x8a	; 138
      00B93D 8F                    1960 	.db #0x8f	; 143
      00B93E 27                    1961 	.db #0x27	; 39
      00B93F F7                    1962 	.db #0xf7	; 247
      00B940 F2                    1963 	.db #0xf2	; 242
      00B941 EB                    1964 	.db #0xeb	; 235
      00B942 58                    1965 	.db #0x58	; 88	'X'
      00B943 37                    1966 	.db #0x37	; 55	'7'
      00B944 3C                    1967 	.db #0x3c	; 60
      00B945 2B                    1968 	.db #0x2b	; 43
      00B946 6F                    1969 	.db #0x6f	; 111	'o'
      00B947 0E                    1970 	.db #0x0e	; 14
      00B948 C7                    1971 	.db #0xc7	; 199
      00B949 E2                    1972 	.db #0xe2	; 226
      00B94A A0                    1973 	.db #0xa0	; 160
      00B94B 97                    1974 	.db #0x97	; 151
      00B94C EE                    1975 	.db #0xee	; 238
      00B94D FD                    1976 	.db #0xfd	; 253
      00B94E 9F                    1977 	.db #0x9f	; 159
      00B94F 45                    1978 	.db #0x45	; 69	'E'
      00B950 17                    1979 	.db #0x17	; 23
      00B951 94                    1980 	.db #0x94	; 148
      00B952 E6                    1981 	.db #0xe6	; 230
      00B953 E7                    1982 	.db #0xe7	; 231
      00B954 FA                    1983 	.db #0xfa	; 250
      00B955 4C                    1984 	.db #0x4c	; 76	'L'
      00B956 7A                    1985 	.db #0x7a	; 122	'z'
      00B957 D6                    1986 	.db #0xd6	; 214
      00B958 7A                    1987 	.db #0x7a	; 122	'z'
      00B959 7B                    1988 	.db #0x7b	; 123
      00B95A ED                    1989 	.db #0xed	; 237
      00B95B 10                    1990 	.db #0x10	; 16
      00B95C C5                    1991 	.db #0xc5	; 197
      00B95D BC                    1992 	.db #0xbc	; 188
      00B95E E3                    1993 	.db #0xe3	; 227
      00B95F A9                    1994 	.db #0xa9	; 169
      00B960 1F                    1995 	.db #0x1f	; 31
      00B961 CF                    1996 	.db #0xcf	; 207
      00B962 C4                    1997 	.db #0xc4	; 196
      00B963 9D                    1998 	.db #0x9d	; 157
      00B964 DC                    1999 	.db #0xdc	; 220
      00B965 45                    2000 	.db #0x45	; 69	'E'
      00B966 2A                    2001 	.db #0x2a	; 42
      00B967 69                    2002 	.db #0x69	; 105	'i'
      00B968 57                    2003 	.db #0x57	; 87	'W'
      00B969 8F                    2004 	.db #0x8f	; 143
      00B96A EC                    2005 	.db #0xec	; 236
      00B96B 85                    2006 	.db #0x85	; 133
      00B96C 6C                    2007 	.db #0x6c	; 108	'l'
      00B96D 43                    2008 	.db #0x43	; 67	'C'
      00B96E 1C                    2009 	.db #0x1c	; 28
      00B96F BA                    2010 	.db #0xba	; 186
      00B970 89                    2011 	.db #0x89	; 137
      00B971 68                    2012 	.db #0x68	; 104	'h'
      00B972 4A                    2013 	.db #0x4a	; 74	'J'
      00B973 1C                    2014 	.db #0x1c	; 28
      00B974 91                    2015 	.db #0x91	; 145
      00B975 3F                    2016 	.db #0x3f	; 63
      00B976 D1                    2017 	.db #0xd1	; 209
      00B977 B3                    2018 	.db #0xb3	; 179
      00B978 96                    2019 	.db #0x96	; 150
      00B979 1D                    2020 	.db #0x1d	; 29
      00B97A 7C                    2021 	.db #0x7c	; 124
      00B97B 14                    2022 	.db #0x14	; 20
      00B97C 77                    2023 	.db #0x77	; 119	'w'
      00B97D 9C                    2024 	.db #0x9c	; 156
      00B97E 74                    2025 	.db #0x74	; 116	't'
      00B97F 36                    2026 	.db #0x36	; 54	'6'
      00B980 FF                    2027 	.db #0xff	; 255
      00B981 2C                    2028 	.db #0x2c	; 44
      00B982 66                    2029 	.db #0x66	; 102	'f'
      00B983 AF                    2030 	.db #0xaf	; 175
      00B984 0F                    2031 	.db #0x0f	; 15
      00B985 3C                    2032 	.db #0x3c	; 60
      00B986 A2                    2033 	.db #0xa2	; 162
      00B987 23                    2034 	.db #0x23	; 35
      00B988 85                    2035 	.db #0x85	; 133
      00B989 05                    2036 	.db #0x05	; 5
      00B98A 87                    2037 	.db #0x87	; 135
      00B98B DA                    2038 	.db #0xda	; 218
      00B98C 61                    2039 	.db #0x61	; 97	'a'
      00B98D 5E                    2040 	.db #0x5e	; 94
      00B98E 42                    2041 	.db #0x42	; 66	'B'
      00B98F 54                    2042 	.db #0x54	; 84	'T'
      00B990 60                    2043 	.db #0x60	; 96
      00B991 23                    2044 	.db #0x23	; 35
      00B992 CA                    2045 	.db #0xca	; 202
      00B993 BC                    2046 	.db #0xbc	; 188
      00B994 B3                    2047 	.db #0xb3	; 179
      00B995 18                    2048 	.db #0x18	; 24
      00B996 1D                    2049 	.db #0x1d	; 29
      00B997 F8                    2050 	.db #0xf8	; 248
      00B998 0A                    2051 	.db #0x0a	; 10
      00B999 55                    2052 	.db #0x55	; 85	'U'
      00B99A CD                    2053 	.db #0xcd	; 205
      00B99B A3                    2054 	.db #0xa3	; 163
      00B99C DE                    2055 	.db #0xde	; 222
      00B99D FF                    2056 	.db #0xff	; 255
      00B99E B2                    2057 	.db #0xb2	; 178
      00B99F 2A                    2058 	.db #0x2a	; 42
      00B9A0 35                    2059 	.db #0x35	; 53	'5'
      00B9A1 00                    2060 	.db #0x00	; 0
      00B9A2 D6                    2061 	.db #0xd6	; 214
      00B9A3 7B                    2062 	.db #0x7b	; 123
      00B9A4 E8                    2063 	.db #0xe8	; 232
      00B9A5 F2                    2064 	.db #0xf2	; 242
      00B9A6 1A                    2065 	.db #0x1a	; 26
      00B9A7 BC                    2066 	.db #0xbc	; 188
      00B9A8 F5                    2067 	.db #0xf5	; 245
      00B9A9 7E                    2068 	.db #0x7e	; 126
      00B9AA 48                    2069 	.db #0x48	; 72	'H'
      00B9AB 72                    2070 	.db #0x72	; 114	'r'
      00B9AC E0                    2071 	.db #0xe0	; 224
      00B9AD E4                    2072 	.db #0xe4	; 228
      00B9AE E0                    2073 	.db #0xe0	; 224
      00B9AF 27                    2074 	.db #0x27	; 39
      00B9B0 87                    2075 	.db #0x87	; 135
      00B9B1 9A                    2076 	.db #0x9a	; 154
      00B9B2 51                    2077 	.db #0x51	; 81	'Q'
      00B9B3 D4                    2078 	.db #0xd4	; 212
      00B9B4 DD                    2079 	.db #0xdd	; 221
      00B9B5 C3                    2080 	.db #0xc3	; 195
      00B9B6 AA                    2081 	.db #0xaa	; 170
      00B9B7 49                    2082 	.db #0x49	; 73	'I'
      00B9B8 5A                    2083 	.db #0x5a	; 90	'Z'
      00B9B9 2A                    2084 	.db #0x2a	; 42
      00B9BA 00                    2085 	.db #0x00	; 0
      00B9BB A0                    2086 	.db #0xa0	; 160
      00B9BC 8C                    2087 	.db #0x8c	; 140
      00B9BD FF                    2088 	.db #0xff	; 255
      00B9BE 74                    2089 	.db #0x74	; 116	't'
      00B9BF BF                    2090 	.db #0xbf	; 191
      00B9C0 EC                    2091 	.db #0xec	; 236
      00B9C1 1D                    2092 	.db #0x1d	; 29
      00B9C2 F1                    2093 	.db #0xf1	; 241
      00B9C3 00                    2094 	.db #0x00	; 0
      00B9C4 01                    2095 	.db #0x01	; 1
      00B9C5 D8                    2096 	.db #0xd8	; 216
      00B9C6 02                    2097 	.db #0x02	; 2
      00B9C7 CC                    2098 	.db #0xcc	; 204
      00B9C8 07                    2099 	.db #0x07	; 7
      00B9C9 00                    2100 	.db #0x00	; 0
      00B9CA 00                    2101 	.db #0x00	; 0
      00B9CB C4                    2102 	.db #0xc4	; 196
      00B9CC 5E                    2103 	.db #0x5e	; 94
      00B9CD 2C                    2104 	.db #0x2c	; 44
      00B9CE 7E                    2105 	.db #0x7e	; 126
      00B9CF B1                    2106 	.db #0xb1	; 177
      00B9D0 C4                    2107 	.db #0xc4	; 196
      00B9D1 67                    2108 	.db #0x67	; 103	'g'
      00B9D2 FB                    2109 	.db #0xfb	; 251
      00B9D3 02                    2110 	.db #0x02	; 2
      00B9D4 00                    2111 	.db #0x00	; 0
      00B9D5 00                    2112 	.db #0x00	; 0
      00B9D6 00                    2113 	.db #0x00	; 0
      00B9D7 00                    2114 	.db #0x00	; 0
      00B9D8 04                    2115 	.db #0x04	; 4
      00B9D9 59                    2116 	.db #0x59	; 89	'Y'
      00B9DA 5A                    2117 	.db #0x5a	; 90	'Z'
                                   2118 	.area CSEG    (CODE)
                                   2119 	.area CONST   (CODE)
      00B9DB                       2120 _vial_handle_cmd_keyboard_uid_40000_622:
      00B9DB 04                    2121 	.db #0x04	; 4
      00B9DC 70                    2122 	.db #0x70	; 112	'p'
      00B9DD FF                    2123 	.db #0xff	; 255
      00B9DE 90                    2124 	.db #0x90	; 144
      00B9DF 01                    2125 	.db #0x01	; 1
      00B9E0 B9                    2126 	.db #0xb9	; 185
      00B9E1 15                    2127 	.db #0x15	; 21
      00B9E2 D3                    2128 	.db #0xd3	; 211
                                   2129 	.area CSEG    (CODE)
                                   2130 	.area XINIT   (CODE)
      00BC10                       2131 __xinit__vial_unlocked:
      00BC10 00                    2132 	.db #0x00	;  0
      00BC11                       2133 __xinit__vial_unlock_in_progress:
      00BC11 00                    2134 	.db #0x00	;  0
      00BC12                       2135 __xinit__vial_unlock_counter:
      00BC12 00                    2136 	.db #0x00	; 0
      00BC13                       2137 __xinit__vial_unlock_combo_rows:
      00BC13 00                    2138 	.db #0x00	; 0
      00BC14 00                    2139 	.db #0x00	; 0
      00BC15                       2140 __xinit__vial_unlock_combo_cols:
      00BC15 00                    2141 	.db #0x00	; 0
      00BC16 05                    2142 	.db #0x05	; 5
                                   2143 	.area CABS    (ABS,CODE)
                                   2144 
                                   2145 ; Experimental exact instruction outlining.
                                   2146 	.globl _ak820_outline_0004
                                   2147 	.globl _ak820_outline_0005
                                   2148 	.globl _ak820_outline_0007
                                   2149 	.globl _ak820_outline_0010
                                   2150 	.globl _ak820_outline_0011
                                   2151 	.globl _ak820_outline_0013
                                   2152 	.globl _ak820_outline_0014
                                   2153 	.globl _ak820_outline_0018
                                   2154 	.globl _ak820_outline_0019
                                   2155 	.globl _ak820_outline_0022
                                   2156 	.globl _ak820_outline_0028
                                   2157 	.globl _ak820_outline_0031
                                   2158 	.globl _ak820_outline_0034
                                   2159 	.globl _ak820_outline_0043
                                   2160 	.globl _ak820_outline_0047
                                   2161 	.globl _ak820_outline_0050
                                   2162 	.globl _ak820_outline_0052
                                   2163 	.globl _ak820_outline_0055
                                   2164 	.globl _ak820_outline_0057
                                   2165 	.globl _ak820_outline_0067
                                   2166 	.globl _ak820_outline_0071
                                   2167 	.globl _ak820_outline_0085
                                   2168 	.globl _ak820_outline_0094
                                   2169 	.globl _ak820_outline_0099
                                   2170 	.globl _ak820_outline_0100
                                   2171 	.globl _ak820_outline_0111
                                   2172 	.globl _ak820_outline_0112
                                   2173 	.globl _ak820_outline_0115
                                   2174 	.globl _ak820_outline_0116
                                   2175 	.globl _ak820_outline_0118
                                   2176 	.globl _ak820_outline_0119
                                   2177 	.globl _ak820_outline_0125
                                   2178 	.globl _ak820_outline_0129
                                   2179 	.globl _ak820_outline_0134
                                   2180 	.globl _ak820_outline_0145
                                   2181 	.globl _ak820_outline_0159
                                   2182 
                                   2183 	.area CSEG (CODE)
                                   2184 ; function ak820_outline_0022
      00AD0D                       2185 _ak820_outline_0022:
      00AD0D E0               [24] 2186 	movx	a,@dptr
      00AD0E FE               [12] 2187 	mov	r6,a
      00AD0F A3               [24] 2188 	inc	dptr
      00AD10 E0               [24] 2189 	movx	a,@dptr
      00AD11 FF               [12] 2190 	mov	r7,a
      00AD12 90 0C 37         [24] 2191 	mov	dptr,#_g_vial_magic_keycode_override
      00AD15 EE               [12] 2192 	mov	a,r6
      00AD16 F0               [24] 2193 	movx	@dptr,a
      00AD17 EF               [12] 2194 	mov	a,r7
      00AD18 A3               [24] 2195 	inc	dptr
      00AD19 F0               [24] 2196 	movx	@dptr,a
      00AD1A 8E 04            [24] 2197 	mov	ar4,r6
      00AD1C 8F 05            [24] 2198 	mov	ar5,r7
      00AD1E C3               [12] 2199 	clr	c
      00AD1F 74 FF            [12] 2200 	mov	a,#0xff
      00AD21 9C               [12] 2201 	subb	a,r4
      00AD22 74 1F            [12] 2202 	mov	a,#0x1f
      00AD24 9D               [12] 2203 	subb	a,r5
      00AD25 22               [24] 2204 	ret
                                   2205 
                                   2206 	.area CSEG (CODE)
                                   2207 ; function ak820_outline_0118
      00AD26                       2208 _ak820_outline_0118:
      00AD26 24 E3            [12] 2209 	add	a,#_vial_unlock_combo_cols
      00AD28 F5 82            [12] 2210 	mov	dpl,a
      00AD2A E4               [12] 2211 	clr	a
      00AD2B 34 0D            [12] 2212 	addc	a,#(_vial_unlock_combo_cols>>8)
      00AD2D F5 83            [12] 2213 	mov	dph,a
      00AD2F E0               [24] 2214 	movx	a,@dptr
      00AD30 22               [24] 2215 	ret
                                   2216 
                                   2217 	.area CSEG (CODE)
                                   2218 ; function ak820_outline_0119
      00AD31                       2219 _ak820_outline_0119:
      00AD31 24 E1            [12] 2220 	add	a,#_vial_unlock_combo_rows
      00AD33 F5 82            [12] 2221 	mov	dpl,a
      00AD35 E4               [12] 2222 	clr	a
      00AD36 34 0D            [12] 2223 	addc	a,#(_vial_unlock_combo_rows>>8)
      00AD38 F5 83            [12] 2224 	mov	dph,a
      00AD3A E0               [24] 2225 	movx	a,@dptr
      00AD3B 22               [24] 2226 	ret
