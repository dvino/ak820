                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004D                        535 _fast_set_leds_sloc0_1_0:
      00004D                        536 	.ds 2
      00004F                        537 _fast_set_leds_sloc1_1_0:
      00004F                        538 	.ds 2
      000051                        539 _vialrgb_get_value_sloc0_1_0:
      000051                        540 	.ds 2
      000053                        541 _vialrgb_get_value_sloc1_1_0:
      000053                        542 	.ds 2
      000055                        543 _vialrgb_set_value_sloc0_1_0:
      000055                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000C4B                        569 _g_direct_mode_colors::
      000C4B                        570 	.ds 246
      000D41                        571 _get_supported_PARM_2:
      000D41                        572 	.ds 1
      000D42                        573 _get_supported_args_10000_255:
      000D42                        574 	.ds 2
      000D44                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000D44                        576 	.ds 2
      000D46                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000D46                        578 	.ds 2
      000D48                        579 _set_mode_mode_10000_275:
      000D48                        580 	.ds 2
      000D4A                        581 _get_matrix_pos_for_led_PARM_2:
      000D4A                        582 	.ds 2
      000D4C                        583 _get_matrix_pos_for_led_led_10000_280:
      000D4C                        584 	.ds 2
      000D4E                        585 _fast_set_leds_PARM_2:
      000D4E                        586 	.ds 1
      000D4F                        587 _fast_set_leds_args_10000_282:
      000D4F                        588 	.ds 2
      000D51                        589 _fast_set_leds_first_index_10001_285:
      000D51                        590 	.ds 2
      000D53                        591 _fast_set_leds_num_leds_10001_285:
      000D53                        592 	.ds 1
      000D54                        593 _vialrgb_get_value_PARM_2:
      000D54                        594 	.ds 1
      000D55                        595 _vialrgb_get_value_data_10000_291:
      000D55                        596 	.ds 3
      000D58                        597 _vialrgb_set_value_PARM_2:
      000D58                        598 	.ds 1
      000D59                        599 _vialrgb_set_value_data_10000_302:
      000D59                        600 	.ds 3
      000D5C                        601 _vialrgb_save_PARM_2:
      000D5C                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00AD3C                        654 _get_supported:
      00AD3C 12 38 47         [24]  655 	lcall	_ak820_outline_0100
      00AD3F 90 0D 42         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00AD42 12 38 42         [24]  657 	lcall	_ak820_outline_0099
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00AD45 90 0D 42         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00AD48 12 37 A2         [24]  660 	lcall	_ak820_outline_0004
      00AD4B E0               [24]  661 	movx	a,@dptr
      00AD4C FD               [12]  662 	mov	r5,a
      00AD4D 7C 00            [12]  663 	mov	r4,#0x00
      00AD4F 12 38 4C         [24]  664 	lcall	_ak820_outline_0102
      00AD52 FA               [12]  665 	mov	r2,a
      00AD53 E4               [12]  666 	clr	a
      00AD54 12 43 2A         [24]  667 	lcall	_ak820_outline_0133
                                    668 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00AD57 90 0D 41         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00AD5A E0               [24]  670 	movx	a,@dptr
      00AD5B FB               [12]  671 	mov	r3,a
      00AD5C 7A 00            [12]  672 	mov	r2,#0x00
      00AD5E                        673 00107$:
      00AD5E C3               [12]  674 	clr	c
      00AD5F EA               [12]  675 	mov	a,r2
      00AD60 9B               [12]  676 	subb	a,r3
      00AD61 50 0A            [24]  677 	jnc	00101$
      00AD63 EA               [12]  678 	mov	a,r2
      00AD64 12 37 E9         [24]  679 	lcall	_ak820_outline_0018
      00AD67 74 FF            [12]  680 	mov	a,#0xff
      00AD69 F0               [24]  681 	movx	@dptr,a
      00AD6A 0A               [12]  682 	inc	r2
      00AD6B 80 F1            [24]  683 	sjmp	00107$
      00AD6D                        684 00101$:
                                    685 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AD6D 8D 06            [24]  686 	mov	ar6,r5
      00AD6F 8C 07            [24]  687 	mov	ar7,r4
      00AD71 8B 05            [24]  688 	mov	ar5,r3
      00AD73 90 0D 42         [24]  689 	mov	dptr,#_get_supported_args_10000_255
      00AD76 12 38 3C         [24]  690 	lcall	_ak820_outline_0094
      00AD79 7A 00            [12]  691 	mov	r2,#0x00
      00AD7B                        692 00110$:
      00AD7B BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00AD7E                        694 00159$:
      00AD7E 50 45            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00AD80 EA               [12]  697 	mov	a,r2
      00AD81 75 F0 02         [24]  698 	mov	b,#0x02
      00AD84 A4               [48]  699 	mul	ab
      00AD85 24 E3            [12]  700 	add	a, #_supported_modes
      00AD87 F5 82            [12]  701 	mov	dpl,a
      00AD89 74 B9            [12]  702 	mov	a,#(_supported_modes >> 8)
      00AD8B 12 54 E7         [24]  703 	lcall	_ak820_outline_0101
      00AD8E F8               [12]  704 	mov	r0,a
      00AD8F 79 00            [12]  705 	mov	r1,#0x00
                                    706 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00AD91 C3               [12]  707 	clr	c
      00AD92 EE               [12]  708 	mov	a,r6
      00AD93 98               [12]  709 	subb	a,r0
      00AD94 EF               [12]  710 	mov	a,r7
      00AD95 99               [12]  711 	subb	a,r1
      00AD96 50 2A            [24]  712 	jnc	00111$
                                    713 ;	free result
      00AD98 BD 02 00         [24]  714 	cjne	r5,#0x02,00162$
      00AD9B                        715 00162$:
      00AD9B 40 25            [24]  716 	jc	00111$
                                    717 ;	quantum/vialrgb.c:49: args[0] = id;
      00AD9D C0 06            [24]  718 	push	ar6
      00AD9F C0 07            [24]  719 	push	ar7
      00ADA1 88 07            [24]  720 	mov	ar7,r0
      00ADA3 12 33 FC         [24]  721 	lcall	_ak820_outline_0116
      00ADA6 EF               [12]  722 	mov	a,r7
      00ADA7 12 46 9A         [24]  723 	lcall	_ak820_outline_0114
                                    724 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00ADAA A3               [24]  725 	inc	dptr
      00ADAB 89 00            [24]  726 	mov	ar0,r1
      00ADAD E8               [12]  727 	mov	a,r0
      00ADAE F0               [24]  728 	movx	@dptr,a
                                    729 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00ADAF 1D               [12]  730 	dec	r5
      00ADB0 1D               [12]  731 	dec	r5
                                    732 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00ADB1 74 02            [12]  733 	mov	a,#0x02
      00ADB3 2B               [12]  734 	add	a, r3
      00ADB4 FB               [12]  735 	mov	r3,a
      00ADB5 E4               [12]  736 	clr	a
      00ADB6 3C               [12]  737 	addc	a, r4
      00ADB7 FC               [12]  738 	mov	r4,a
      00ADB8 90 0D 42         [24]  739 	mov	dptr,#_get_supported_args_10000_255
      00ADBB 12 38 2A         [24]  740 	lcall	_ak820_outline_0071
                                    741 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00ADBE D0 07            [24]  742 	pop	ar7
      00ADC0 D0 06            [24]  743 	pop	ar6
                                    744 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00ADC2                        745 00111$:
                                    746 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00ADC2 0A               [12]  747 	inc	r2
      00ADC3 80 B6            [24]  748 	sjmp	00110$
      00ADC5                        749 00127$:
      00ADC5 90 0D 42         [24]  750 	mov	dptr,#_get_supported_args_10000_255
      00ADC8 12 38 2A         [24]  751 	lcall	_ak820_outline_0071
                                    752 ;	quantum/vialrgb.c:55: }
      00ADCB 22               [24]  753 	ret
                                    754 ;------------------------------------------------------------
                                    755 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    756 ;------------------------------------------------------------
                                    757 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    758 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    759 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    760 ;------------------------------------------------------------
                                    761 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    762 ;	-----------------------------------------
                                    763 ;	 function qmk_id_to_vialrgb_id
                                    764 ;	-----------------------------------------
      00ADCC                        765 _qmk_id_to_vialrgb_id:
      00ADCC 12 38 47         [24]  766 	lcall	_ak820_outline_0100
      00ADCF 90 0D 44         [24]  767 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00ADD2 12 38 42         [24]  768 	lcall	_ak820_outline_0099
                                    769 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00ADD5 90 0D 44         [24]  770 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00ADD8 12 37 F9         [24]  771 	lcall	_ak820_outline_0047
      00ADDB 7D 00            [12]  772 	mov	r5,#0x00
      00ADDD                        773 00105$:
      00ADDD BD 07 00         [24]  774 	cjne	r5,#0x07,00130$
      00ADE0                        775 00130$:
      00ADE0 50 19            [24]  776 	jnc	00103$
                                    777 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00ADE2 12 B2 02         [24]  778 	lcall	_ak820_outline_0042
      00ADE5 A3               [24]  779 	inc	dptr
      00ADE6 E4               [12]  780 	clr	a
      00ADE7 93               [24]  781 	movc	a,@a+dptr
                                    782 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00ADE8 7A 00            [12]  783 	mov	r2,#0x00
      00ADEA B5 06 0B         [24]  784 	cjne	a,ar6,00106$
      00ADED EA               [12]  785 	mov	a,r2
      00ADEE B5 07 07         [24]  786 	cjne	a,ar7,00106$
                                    787 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00ADF1 12 33 FC         [24]  788 	lcall	_ak820_outline_0116
      00ADF4 12 B2 2E         [24]  789 	lcall	_ak820_outline_0135
      00ADF7 22               [24]  790 	ret
      00ADF8                        791 00106$:
                                    792 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00ADF8 0D               [12]  793 	inc	r5
      00ADF9 80 E2            [24]  794 	sjmp	00105$
      00ADFB                        795 00103$:
                                    796 ;	quantum/vialrgb.c:63: return 0;
      00ADFB 90 00 00         [24]  797 	mov	dptr,#0x0000
                                    798 ;	quantum/vialrgb.c:64: }
      00ADFE 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    802 ;------------------------------------------------------------
                                    803 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    804 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    805 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    806 ;------------------------------------------------------------
                                    807 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    808 ;	-----------------------------------------
                                    809 ;	 function vialrgb_id_to_qmk_id
                                    810 ;	-----------------------------------------
      00ADFF                        811 _vialrgb_id_to_qmk_id:
      00ADFF 12 38 47         [24]  812 	lcall	_ak820_outline_0100
      00AE02 90 0D 46         [24]  813 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00AE05 12 38 42         [24]  814 	lcall	_ak820_outline_0099
                                    815 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AE08 90 0D 46         [24]  816 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00AE0B 12 37 F9         [24]  817 	lcall	_ak820_outline_0047
      00AE0E 7D 00            [12]  818 	mov	r5,#0x00
      00AE10                        819 00105$:
      00AE10 BD 07 00         [24]  820 	cjne	r5,#0x07,00130$
      00AE13                        821 00130$:
      00AE13 50 19            [24]  822 	jnc	00103$
                                    823 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00AE15 12 B2 02         [24]  824 	lcall	_ak820_outline_0042
      00AE18 E4               [12]  825 	clr	a
      00AE19 93               [24]  826 	movc	a,@a+dptr
                                    827 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00AE1A 7A 00            [12]  828 	mov	r2,#0x00
      00AE1C B5 06 0C         [24]  829 	cjne	a,ar6,00106$
      00AE1F EA               [12]  830 	mov	a,r2
      00AE20 B5 07 08         [24]  831 	cjne	a,ar7,00106$
                                    832 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00AE23 12 33 FC         [24]  833 	lcall	_ak820_outline_0116
      00AE26 A3               [24]  834 	inc	dptr
      00AE27 12 B2 2E         [24]  835 	lcall	_ak820_outline_0135
      00AE2A 22               [24]  836 	ret
      00AE2B                        837 00106$:
                                    838 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AE2B 0D               [12]  839 	inc	r5
      00AE2C 80 E2            [24]  840 	sjmp	00105$
      00AE2E                        841 00103$:
                                    842 ;	quantum/vialrgb.c:72: return 0;
      00AE2E 90 00 00         [24]  843 	mov	dptr,#0x0000
                                    844 ;	quantum/vialrgb.c:73: }
      00AE31 22               [24]  845 	ret
                                    846 ;------------------------------------------------------------
                                    847 ;Allocation info for local variables in function 'get_mode'
                                    848 ;------------------------------------------------------------
                                    849 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    850 ;	-----------------------------------------
                                    851 ;	 function get_mode
                                    852 ;	-----------------------------------------
      00AE32                        853 _get_mode:
                                    854 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00AE32 12 52 DC         [24]  855 	lcall	_rgb_matrix_is_enabled
      00AE35 E5 82            [12]  856 	mov	a, dpl
      00AE37 70 04            [24]  857 	jnz	00102$
                                    858 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00AE39 90 00 00         [24]  859 	mov	dptr,#0x0000
      00AE3C 22               [24]  860 	ret
      00AE3D                        861 00102$:
                                    862 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00AE3D 12 52 E2         [24]  863 	lcall	_rgb_matrix_get_mode
      00AE40 7E 00            [12]  864 	mov	r6,#0x00
      00AE42 8E 83            [24]  865 	mov	dph, r6
                                    866 ;	quantum/vialrgb.c:80: }
      00AE44 02 AD CC         [24]  867 	ljmp	_qmk_id_to_vialrgb_id
                                    868 ;------------------------------------------------------------
                                    869 ;Allocation info for local variables in function 'set_mode'
                                    870 ;------------------------------------------------------------
                                    871 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    872 ;------------------------------------------------------------
                                    873 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function set_mode
                                    876 ;	-----------------------------------------
      00AE47                        877 _set_mode:
      00AE47 12 38 47         [24]  878 	lcall	_ak820_outline_0100
      00AE4A 90 0D 48         [24]  879 	mov	dptr,#_set_mode_mode_10000_275
      00AE4D 12 38 42         [24]  880 	lcall	_ak820_outline_0099
                                    881 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00AE50 90 0D 48         [24]  882 	mov	dptr,#_set_mode_mode_10000_275
      00AE53 12 37 F9         [24]  883 	lcall	_ak820_outline_0047
      00AE56 90 0D 48         [24]  884 	mov	dptr,#_set_mode_mode_10000_275
      00AE59 12 6B 38         [24]  885 	lcall	_ak820_outline_0033
      00AE5C 70 03            [24]  886 	jnz	00102$
                                    887 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00AE5E 02 53 2F         [24]  888 	ljmp	_rgb_matrix_disable_noeeprom
      00AE61                        889 00102$:
                                    890 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00AE61 C0 07            [24]  891 	push	ar7
      00AE63 C0 06            [24]  892 	push	ar6
      00AE65 12 53 1E         [24]  893 	lcall	_rgb_matrix_enable_noeeprom
      00AE68 D0 06            [24]  894 	pop	ar6
      00AE6A D0 07            [24]  895 	pop	ar7
                                    896 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00AE6C 12 43 1A         [24]  897 	lcall	_ak820_outline_0111
      00AE6F 12 AD FF         [24]  898 	lcall	_vialrgb_id_to_qmk_id
                                    899 ;	quantum/vialrgb.c:90: }
      00AE72 02 53 38         [24]  900 	ljmp	_rgb_matrix_mode_noeeprom
                                    901 ;------------------------------------------------------------
                                    902 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    903 ;------------------------------------------------------------
                                    904 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    905 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    906 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    907 ;------------------------------------------------------------
                                    908 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    909 ;	-----------------------------------------
                                    910 ;	 function get_matrix_pos_for_led
                                    911 ;	-----------------------------------------
      00AE75                        912 _get_matrix_pos_for_led:
      00AE75 12 38 47         [24]  913 	lcall	_ak820_outline_0100
      00AE78 90 0D 4C         [24]  914 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00AE7B 12 38 42         [24]  915 	lcall	_ak820_outline_0099
                                    916 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00AE7E 90 0D 4C         [24]  917 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00AE81 12 37 F9         [24]  918 	lcall	_ak820_outline_0047
      00AE84 EE               [12]  919 	mov	a,r6
      00AE85 24 EA            [12]  920 	add	a, #_ak820_rgb_slots
      00AE87 F5 82            [12]  921 	mov	dpl,a
      00AE89 EF               [12]  922 	mov	a,r7
      00AE8A 34 B3            [12]  923 	addc	a, #(_ak820_rgb_slots >> 8)
      00AE8C F5 83            [12]  924 	mov	dph,a
      00AE8E E4               [12]  925 	clr	a
      00AE8F 93               [24]  926 	movc	a,@a+dptr
      00AE90 FF               [12]  927 	mov	r7,a
                                    928 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00AE91 90 0D 4A         [24]  929 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00AE94 12 43 08         [24]  930 	lcall	_ak820_outline_0095
      00AE97 EF               [12]  931 	mov	a,r7
      00AE98 12 55 1D         [24]  932 	lcall	_ak820_outline_0176
      00AE9B 12 7D 5A         [24]  933 	lcall	_ak820_outline_0113
                                    934 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00AE9E 12 38 5D         [24]  935 	lcall	_ak820_outline_0124
      00AEA1 A3               [24]  936 	inc	dptr
      00AEA2 53 07 07         [24]  937 	anl	ar7,#0x07
      00AEA5 EF               [12]  938 	mov	a,r7
      00AEA6 F0               [24]  939 	movx	@dptr,a
                                    940 ;	quantum/vialrgb.c:110: }
      00AEA7 22               [24]  941 	ret
                                    942 ;------------------------------------------------------------
                                    943 ;Allocation info for local variables in function 'fast_set_leds'
                                    944 ;------------------------------------------------------------
                                    945 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    946 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    947 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    948 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    949 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    950 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    951 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    952 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    953 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    954 ;------------------------------------------------------------
                                    955 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    956 ;	-----------------------------------------
                                    957 ;	 function fast_set_leds
                                    958 ;	-----------------------------------------
      00AEA8                        959 _fast_set_leds:
      00AEA8 12 38 47         [24]  960 	lcall	_ak820_outline_0100
      00AEAB 90 0D 4F         [24]  961 	mov	dptr,#_fast_set_leds_args_10000_282
      00AEAE 12 38 42         [24]  962 	lcall	_ak820_outline_0099
                                    963 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00AEB1 90 0D 4E         [24]  964 	mov	dptr,#_fast_set_leds_PARM_2
      00AEB4 E0               [24]  965 	movx	a,@dptr
      00AEB5 FF               [12]  966 	mov	r7,a
      00AEB6 BF 03 00         [24]  967 	cjne	r7,#0x03,00159$
      00AEB9                        968 00159$:
      00AEB9 50 01            [24]  969 	jnc	00102$
      00AEBB 22               [24]  970 	ret
      00AEBC                        971 00102$:
                                    972 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00AEBC 90 0D 4F         [24]  973 	mov	dptr,#_fast_set_leds_args_10000_282
      00AEBF E0               [24]  974 	movx	a,@dptr
      00AEC0 FD               [12]  975 	mov	r5,a
      00AEC1 A3               [24]  976 	inc	dptr
      00AEC2 E0               [24]  977 	movx	a,@dptr
      00AEC3 12 46 84         [24]  978 	lcall	_ak820_outline_0053
      00AEC6 7B 00            [12]  979 	mov	r3,#0x00
      00AEC8 12 38 5D         [24]  980 	lcall	_ak820_outline_0124
      00AECB A3               [24]  981 	inc	dptr
      00AECC E0               [24]  982 	movx	a,@dptr
      00AECD FA               [12]  983 	mov	r2,a
      00AECE 79 00            [12]  984 	mov	r1,#0x00
      00AED0 90 0D 51         [24]  985 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00AED3 E9               [12]  986 	mov	a,r1
      00AED4 4C               [12]  987 	orl	a,r4
      00AED5 F0               [24]  988 	movx	@dptr,a
      00AED6 EA               [12]  989 	mov	a,r2
      00AED7 4B               [12]  990 	orl	a,r3
      00AED8 A3               [24]  991 	inc	dptr
      00AED9 F0               [24]  992 	movx	@dptr,a
                                    993 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00AEDA 12 38 5D         [24]  994 	lcall	_ak820_outline_0124
      00AEDD A3               [24]  995 	inc	dptr
      00AEDE A3               [24]  996 	inc	dptr
      00AEDF E0               [24]  997 	movx	a,@dptr
      00AEE0 90 0D 53         [24]  998 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00AEE3 F0               [24]  999 	movx	@dptr,a
                                   1000 ;	quantum/vialrgb.c:119: length -= 3;
      00AEE4 EF               [12] 1001 	mov	a,r7
      00AEE5 24 FD            [12] 1002 	add	a,#0xfd
      00AEE7 90 0D 4E         [24] 1003 	mov	dptr,#_fast_set_leds_PARM_2
      00AEEA F0               [24] 1004 	movx	@dptr,a
                                   1005 ;	quantum/vialrgb.c:120: args += 3;
      00AEEB 90 0D 4F         [24] 1006 	mov	dptr,#_fast_set_leds_args_10000_282
      00AEEE 74 03            [12] 1007 	mov	a,#0x03
      00AEF0 2D               [12] 1008 	add	a, r5
      00AEF1 F0               [24] 1009 	movx	@dptr,a
      00AEF2 E4               [12] 1010 	clr	a
      00AEF3 3E               [12] 1011 	addc	a, r6
      00AEF4 A3               [24] 1012 	inc	dptr
      00AEF5 F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00AEF6 90 0D 53         [24] 1015 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00AEF9 E0               [24] 1016 	movx	a,@dptr
      00AEFA FF               [12] 1017 	mov	r7,a
      00AEFB 75 F0 03         [24] 1018 	mov	b,#0x03
      00AEFE A4               [48] 1019 	mul	ab
      00AEFF FE               [12] 1020 	mov	r6,a
      00AF00 AD F0            [24] 1021 	mov	r5,b
      00AF02 90 0D 4E         [24] 1022 	mov	dptr,#_fast_set_leds_PARM_2
      00AF05 E0               [24] 1023 	movx	a,@dptr
      00AF06 FB               [12] 1024 	mov	r3,a
      00AF07 7C 00            [12] 1025 	mov	r4,#0x00
      00AF09 C3               [12] 1026 	clr	c
      00AF0A EB               [12] 1027 	mov	a,r3
      00AF0B 9E               [12] 1028 	subb	a,r6
      00AF0C EC               [12] 1029 	mov	a,r4
      00AF0D 9D               [12] 1030 	subb	a,r5
      00AF0E 40 13            [24] 1031 	jc	00103$
                                   1032 ;	free result
      00AF10 90 0D 51         [24] 1033 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00AF13 12 43 08         [24] 1034 	lcall	_ak820_outline_0095
      00AF16 8D 03            [24] 1035 	mov	ar3,r5
      00AF18 8E 04            [24] 1036 	mov	ar4,r6
      00AF1A C3               [12] 1037 	clr	c
      00AF1B EB               [12] 1038 	mov	a,r3
      00AF1C 94 52            [12] 1039 	subb	a,#0x52
      00AF1E EC               [12] 1040 	mov	a,r4
      00AF1F 94 00            [12] 1041 	subb	a,#0x00
      00AF21 40 01            [24] 1042 	jc	00104$
      00AF23                       1043 00103$:
      00AF23 22               [24] 1044 	ret
      00AF24                       1045 00104$:
                                   1046 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00AF24 74 52            [12] 1047 	mov	a,#0x52
      00AF26 C3               [12] 1048 	clr	c
      00AF27 9D               [12] 1049 	subb	a,r5
      00AF28 FB               [12] 1050 	mov	r3,a
      00AF29 E4               [12] 1051 	clr	a
      00AF2A 9E               [12] 1052 	subb	a,r6
      00AF2B FC               [12] 1053 	mov	r4,a
      00AF2C 7A 00            [12] 1054 	mov	r2,#0x00
      00AF2E C3               [12] 1055 	clr	c
      00AF2F EB               [12] 1056 	mov	a,r3
      00AF30 9F               [12] 1057 	subb	a,r7
      00AF31 EC               [12] 1058 	mov	a,r4
      00AF32 9A               [12] 1059 	subb	a,r2
      00AF33 50 08            [24] 1060 	jnc	00127$
                                   1061 ;	free result
      00AF35 90 0D 53         [24] 1062 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00AF38 74 52            [12] 1063 	mov	a,#0x52
      00AF3A C3               [12] 1064 	clr	c
      00AF3B 9D               [12] 1065 	subb	a,r5
      00AF3C F0               [24] 1066 	movx	@dptr,a
                                   1067 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00AF3D                       1068 00127$:
      00AF3D 90 0D 53         [24] 1069 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00AF40 E0               [24] 1070 	movx	a,@dptr
      00AF41 FF               [12] 1071 	mov	r7,a
      00AF42 90 0D 51         [24] 1072 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00AF45 12 43 08         [24] 1073 	lcall	_ak820_outline_0095
      00AF48 7C 00            [12] 1074 	mov	r4,#0x00
      00AF4A                       1075 00110$:
      00AF4A C3               [12] 1076 	clr	c
      00AF4B EC               [12] 1077 	mov	a,r4
      00AF4C 9F               [12] 1078 	subb	a,r7
      00AF4D 40 01            [24] 1079 	jc	00164$
      00AF4F 22               [24] 1080 	ret
      00AF50                       1081 00164$:
                                   1082 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00AF50 C0 07            [24] 1083 	push	ar7
      00AF52 90 0D 6B         [24] 1084 	mov	dptr,#__mulint_PARM_2
      00AF55 12 43 4A         [24] 1085 	lcall	_ak820_outline_0151
      00AF58 90 00 03         [24] 1086 	mov	dptr,#0x0003
      00AF5B C0 07            [24] 1087 	push	ar7
      00AF5D C0 06            [24] 1088 	push	ar6
      00AF5F C0 05            [24] 1089 	push	ar5
      00AF61 C0 04            [24] 1090 	push	ar4
      00AF63 12 B3 9A         [24] 1091 	lcall	__mulint
      00AF66 AA 82            [24] 1092 	mov	r2, dpl
      00AF68 AB 83            [24] 1093 	mov	r3, dph
      00AF6A D0 04            [24] 1094 	pop	ar4
      00AF6C D0 05            [24] 1095 	pop	ar5
      00AF6E D0 06            [24] 1096 	pop	ar6
      00AF70 D0 07            [24] 1097 	pop	ar7
      00AF72 0D               [12] 1098 	inc	r5
      00AF73 BD 00 01         [24] 1099 	cjne	r5,#0x00,00165$
      00AF76 0E               [12] 1100 	inc	r6
      00AF77                       1101 00165$:
      00AF77 EA               [12] 1102 	mov	a,r2
      00AF78 24 4B            [12] 1103 	add	a, #_g_direct_mode_colors
      00AF7A FA               [12] 1104 	mov	r2,a
      00AF7B EB               [12] 1105 	mov	a,r3
      00AF7C 34 0C            [12] 1106 	addc	a, #(_g_direct_mode_colors >> 8)
      00AF7E FB               [12] 1107 	mov	r3,a
                                   1108 ;	quantum/vialrgb.c:128: color->h = *args++;
      00AF7F 8A 4D            [24] 1109 	mov	_fast_set_leds_sloc0_1_0,r2
      00AF81 8B 4E            [24] 1110 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00AF83 12 B2 14         [24] 1111 	lcall	_ak820_outline_0075
      00AF86 F8               [12] 1112 	mov	r0,a
      00AF87 12 B2 22         [24] 1113 	lcall	_ak820_outline_0098
      00AF8A 85 4D 82         [24] 1114 	mov	dpl,_fast_set_leds_sloc0_1_0
      00AF8D 85 4E 83         [24] 1115 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00AF90 E8               [12] 1116 	mov	a,r0
      00AF91 F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/vialrgb.c:129: color->s = *args++;
      00AF92 74 01            [12] 1119 	mov	a,#0x01
      00AF94 2A               [12] 1120 	add	a, r2
      00AF95 F5 4D            [12] 1121 	mov	_fast_set_leds_sloc0_1_0,a
      00AF97 E4               [12] 1122 	clr	a
      00AF98 3B               [12] 1123 	addc	a, r3
      00AF99 F5 4E            [12] 1124 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00AF9B 90 0D 4F         [24] 1125 	mov	dptr,#_fast_set_leds_args_10000_282
      00AF9E E0               [24] 1126 	movx	a,@dptr
      00AF9F F8               [12] 1127 	mov	r0,a
      00AFA0 A3               [24] 1128 	inc	dptr
      00AFA1 E0               [24] 1129 	movx	a,@dptr
      00AFA2 FF               [12] 1130 	mov	r7,a
      00AFA3 88 82            [24] 1131 	mov	dpl,r0
      00AFA5 8F 83            [24] 1132 	mov	dph,r7
      00AFA7 E0               [24] 1133 	movx	a,@dptr
      00AFA8 F9               [12] 1134 	mov	r1,a
      00AFA9 90 0D 4F         [24] 1135 	mov	dptr,#_fast_set_leds_args_10000_282
      00AFAC 74 01            [12] 1136 	mov	a,#0x01
      00AFAE 28               [12] 1137 	add	a, r0
      00AFAF F0               [24] 1138 	movx	@dptr,a
      00AFB0 E4               [12] 1139 	clr	a
      00AFB1 3F               [12] 1140 	addc	a, r7
      00AFB2 A3               [24] 1141 	inc	dptr
      00AFB3 F0               [24] 1142 	movx	@dptr,a
      00AFB4 85 4D 82         [24] 1143 	mov	dpl,_fast_set_leds_sloc0_1_0
      00AFB7 85 4E 83         [24] 1144 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00AFBA E9               [12] 1145 	mov	a,r1
      00AFBB F0               [24] 1146 	movx	@dptr,a
                                   1147 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00AFBC 12 B2 14         [24] 1148 	lcall	_ak820_outline_0075
      00AFBF F5 4D            [12] 1149 	mov	_fast_set_leds_sloc0_1_0,a
      00AFC1 12 B2 22         [24] 1150 	lcall	_ak820_outline_0098
                                   1151 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00AFC4 74 02            [12] 1152 	mov	a,#0x02
      00AFC6 2A               [12] 1153 	add	a, r2
      00AFC7 F5 4F            [12] 1154 	mov	_fast_set_leds_sloc1_1_0,a
      00AFC9 E4               [12] 1155 	clr	a
      00AFCA 3B               [12] 1156 	addc	a, r3
      00AFCB F5 50            [12] 1157 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00AFCD C3               [12] 1158 	clr	c
      00AFCE 74 A0            [12] 1159 	mov	a,#0xa0
      00AFD0 95 4D            [12] 1160 	subb	a,_fast_set_leds_sloc0_1_0
      00AFD2 D0 07            [24] 1161 	pop	ar7
      00AFD4 50 04            [24] 1162 	jnc	00114$
                                   1163 ;	free result
      00AFD6 7B A0            [12] 1164 	mov	r3,#0xa0
      00AFD8 80 04            [24] 1165 	sjmp	00115$
      00AFDA                       1166 00114$:
      00AFDA AA 4D            [24] 1167 	mov	r2,_fast_set_leds_sloc0_1_0
      00AFDC 8A 03            [24] 1168 	mov	ar3,r2
      00AFDE                       1169 00115$:
      00AFDE 85 4F 82         [24] 1170 	mov	dpl,_fast_set_leds_sloc1_1_0
      00AFE1 85 50 83         [24] 1171 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00AFE4 EB               [12] 1172 	mov	a,r3
      00AFE5 F0               [24] 1173 	movx	@dptr,a
                                   1174 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00AFE6 0C               [12] 1175 	inc	r4
                                   1176 ;	quantum/vialrgb.c:133: }
      00AFE7 02 AF 4A         [24] 1177 	ljmp	00110$
                                   1178 ;------------------------------------------------------------
                                   1179 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1180 ;------------------------------------------------------------
                                   1181 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1182 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1183 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1184 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1185 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1186 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1187 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1188 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function vialrgb_get_value
                                   1193 ;	-----------------------------------------
      00AFEA                       1194 _vialrgb_get_value:
      00AFEA 12 42 D2         [24] 1195 	lcall	_ak820_outline_0034
      00AFED 90 0D 55         [24] 1196 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00AFF0 12 37 E1         [24] 1197 	lcall	_ak820_outline_0014
                                   1198 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00AFF3 90 0D 54         [24] 1199 	mov	dptr,#_vialrgb_get_value_PARM_2
      00AFF6 E0               [24] 1200 	movx	a,@dptr
      00AFF7 FF               [12] 1201 	mov	r7,a
      00AFF8 BF 20 02         [24] 1202 	cjne	r7,#0x20,00162$
      00AFFB 80 01            [24] 1203 	sjmp	00102$
      00AFFD                       1204 00162$:
      00AFFD 22               [24] 1205 	ret
      00AFFE                       1206 00102$:
                                   1207 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00AFFE 90 0D 55         [24] 1208 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B001 12 B1 EE         [24] 1209 	lcall	_ak820_outline_0040
                                   1210 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1211 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B004 BA 40 02         [24] 1212 	cjne	r2,#0x40,00163$
      00B007 80 18            [24] 1213 	sjmp	00103$
      00B009                       1214 00163$:
      00B009 BA 41 02         [24] 1215 	cjne	r2,#0x41,00164$
      00B00C 80 26            [24] 1216 	sjmp	00104$
      00B00E                       1217 00164$:
      00B00E BA 42 03         [24] 1218 	cjne	r2,#0x42,00165$
      00B011 02 B0 C6         [24] 1219 	ljmp	00105$
      00B014                       1220 00165$:
      00B014 BA 43 03         [24] 1221 	cjne	r2,#0x43,00166$
      00B017 02 B0 D2         [24] 1222 	ljmp	00106$
      00B01A                       1223 00166$:
      00B01A BA 44 03         [24] 1224 	cjne	r2,#0x44,00167$
      00B01D 02 B0 DE         [24] 1225 	ljmp	00107$
      00B020                       1226 00167$:
      00B020 22               [24] 1227 	ret
                                   1228 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B021                       1229 00103$:
                                   1230 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B021 12 33 FC         [24] 1231 	lcall	_ak820_outline_0116
      00B024 74 01            [12] 1232 	mov	a,#0x01
      00B026 F0               [24] 1233 	movx	@dptr,a
                                   1234 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B027 12 B1 E6         [24] 1235 	lcall	_ak820_outline_0032
      00B02A E4               [12] 1236 	clr	a
      00B02B F0               [24] 1237 	movx	@dptr,a
                                   1238 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B02C 12 B1 E6         [24] 1239 	lcall	_ak820_outline_0032
      00B02F A3               [24] 1240 	inc	dptr
      00B030 74 A0            [12] 1241 	mov	a,#0xa0
      00B032 F0               [24] 1242 	movx	@dptr,a
                                   1243 ;	quantum/vialrgb.c:147: break;
      00B033 22               [24] 1244 	ret
                                   1245 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B034                       1246 00104$:
                                   1247 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B034 C0 06            [24] 1248 	push	ar6
      00B036 C0 05            [24] 1249 	push	ar5
      00B038 C0 04            [24] 1250 	push	ar4
      00B03A C0 03            [24] 1251 	push	ar3
      00B03C 12 AE 32         [24] 1252 	lcall	_get_mode
      00B03F A9 82            [24] 1253 	mov	r1, dpl
      00B041 AA 83            [24] 1254 	mov	r2, dph
      00B043 D0 03            [24] 1255 	pop	ar3
      00B045 D0 04            [24] 1256 	pop	ar4
      00B047 D0 05            [24] 1257 	pop	ar5
      00B049 D0 06            [24] 1258 	pop	ar6
                                   1259 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B04B 89 00            [24] 1260 	mov	ar0,r1
      00B04D 12 33 FC         [24] 1261 	lcall	_ak820_outline_0116
      00B050 E8               [12] 1262 	mov	a,r0
      00B051 F0               [24] 1263 	movx	@dptr,a
                                   1264 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B052 12 B1 E6         [24] 1265 	lcall	_ak820_outline_0032
      00B055 8A 01            [24] 1266 	mov	ar1,r2
      00B057 E9               [12] 1267 	mov	a,r1
      00B058 F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B059 74 04            [12] 1270 	mov	a,#0x04
      00B05B 12 8A E5         [24] 1271 	lcall	_ak820_outline_0126
      00B05E C0 06            [24] 1272 	push	ar6
      00B060 C0 05            [24] 1273 	push	ar5
      00B062 C0 02            [24] 1274 	push	ar2
      00B064 C0 01            [24] 1275 	push	ar1
      00B066 12 52 FD         [24] 1276 	lcall	_rgb_matrix_get_speed
      00B069 A8 82            [24] 1277 	mov	r0, dpl
      00B06B D0 01            [24] 1278 	pop	ar1
      00B06D D0 02            [24] 1279 	pop	ar2
      00B06F D0 05            [24] 1280 	pop	ar5
      00B071 D0 06            [24] 1281 	pop	ar6
      00B073 12 7D 33         [24] 1282 	lcall	_ak820_outline_0060
                                   1283 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B076 74 05            [12] 1284 	mov	a,#0x05
      00B078 12 8A E5         [24] 1285 	lcall	_ak820_outline_0126
      00B07B C0 06            [24] 1286 	push	ar6
      00B07D C0 05            [24] 1287 	push	ar5
      00B07F C0 02            [24] 1288 	push	ar2
      00B081 C0 01            [24] 1289 	push	ar1
      00B083 12 52 E8         [24] 1290 	lcall	_rgb_matrix_get_hue
      00B086 A8 82            [24] 1291 	mov	r0, dpl
      00B088 D0 01            [24] 1292 	pop	ar1
      00B08A D0 02            [24] 1293 	pop	ar2
      00B08C D0 05            [24] 1294 	pop	ar5
      00B08E D0 06            [24] 1295 	pop	ar6
      00B090 12 7D 33         [24] 1296 	lcall	_ak820_outline_0060
                                   1297 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B093 74 06            [12] 1298 	mov	a,#0x06
      00B095 12 8A E5         [24] 1299 	lcall	_ak820_outline_0126
      00B098 C0 06            [24] 1300 	push	ar6
      00B09A C0 05            [24] 1301 	push	ar5
      00B09C C0 02            [24] 1302 	push	ar2
      00B09E C0 01            [24] 1303 	push	ar1
      00B0A0 12 52 EF         [24] 1304 	lcall	_rgb_matrix_get_sat
      00B0A3 A8 82            [24] 1305 	mov	r0, dpl
      00B0A5 D0 01            [24] 1306 	pop	ar1
      00B0A7 D0 02            [24] 1307 	pop	ar2
      00B0A9 D0 05            [24] 1308 	pop	ar5
      00B0AB D0 06            [24] 1309 	pop	ar6
      00B0AD 12 7D 33         [24] 1310 	lcall	_ak820_outline_0060
                                   1311 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B0B0 74 07            [12] 1312 	mov	a,#0x07
      00B0B2 12 8A E5         [24] 1313 	lcall	_ak820_outline_0126
      00B0B5 C0 02            [24] 1314 	push	ar2
      00B0B7 C0 01            [24] 1315 	push	ar1
      00B0B9 12 52 F6         [24] 1316 	lcall	_rgb_matrix_get_val
      00B0BC A8 82            [24] 1317 	mov	r0, dpl
      00B0BE D0 01            [24] 1318 	pop	ar1
      00B0C0 D0 02            [24] 1319 	pop	ar2
      00B0C2 12 7D 33         [24] 1320 	lcall	_ak820_outline_0060
                                   1321 ;	quantum/vialrgb.c:156: break;
      00B0C5 22               [24] 1322 	ret
                                   1323 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B0C6                       1324 00105$:
                                   1325 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B0C6 EF               [12] 1326 	mov	a,r7
      00B0C7 24 FE            [12] 1327 	add	a,#0xfe
      00B0C9 90 0D 41         [24] 1328 	mov	dptr,#_get_supported_PARM_2
      00B0CC 12 46 9A         [24] 1329 	lcall	_ak820_outline_0114
                                   1330 ;	quantum/vialrgb.c:160: break;
      00B0CF 02 AD 3C         [24] 1331 	ljmp	_get_supported
                                   1332 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B0D2                       1333 00106$:
                                   1334 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B0D2 12 33 FC         [24] 1335 	lcall	_ak820_outline_0116
      00B0D5 74 52            [12] 1336 	mov	a,#0x52
      00B0D7 F0               [24] 1337 	movx	@dptr,a
                                   1338 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B0D8 12 B1 E6         [24] 1339 	lcall	_ak820_outline_0032
      00B0DB E4               [12] 1340 	clr	a
      00B0DC F0               [24] 1341 	movx	@dptr,a
                                   1342 ;	quantum/vialrgb.c:166: break;
      00B0DD 22               [24] 1343 	ret
                                   1344 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00B0DE                       1345 00107$:
                                   1346 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B0DE 12 33 FC         [24] 1347 	lcall	_ak820_outline_0116
      00B0E1 E0               [24] 1348 	movx	a,@dptr
      00B0E2 FF               [12] 1349 	mov	r7,a
      00B0E3 7A 00            [12] 1350 	mov	r2,#0x00
      00B0E5 74 03            [12] 1351 	mov	a,#0x03
      00B0E7 2D               [12] 1352 	add	a, r5
      00B0E8 F8               [12] 1353 	mov	r0,a
      00B0E9 E4               [12] 1354 	clr	a
      00B0EA 3E               [12] 1355 	addc	a, r6
      00B0EB F9               [12] 1356 	mov	r1,a
      00B0EC C0 03            [24] 1357 	push	ar3
      00B0EE C0 04            [24] 1358 	push	ar4
      00B0F0 12 38 6E         [24] 1359 	lcall	_ak820_outline_0145
      00B0F3 E0               [24] 1360 	movx	a,@dptr
      00B0F4 FB               [12] 1361 	mov	r3,a
      00B0F5 E4               [12] 1362 	clr	a
      00B0F6 4F               [12] 1363 	orl	a,r7
      00B0F7 F5 51            [12] 1364 	mov	_vialrgb_get_value_sloc0_1_0,a
      00B0F9 EB               [12] 1365 	mov	a,r3
      00B0FA 4A               [12] 1366 	orl	a,r2
      00B0FB F5 52            [12] 1367 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1368 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00B0FD AC 51            [24] 1369 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00B0FF AF 52            [24] 1370 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B101 C3               [12] 1371 	clr	c
      00B102 EC               [12] 1372 	mov	a,r4
      00B103 94 52            [12] 1373 	subb	a,#0x52
      00B105 EF               [12] 1374 	mov	a,r7
      00B106 94 00            [12] 1375 	subb	a,#0x00
      00B108 D0 04            [24] 1376 	pop	ar4
      00B10A D0 03            [24] 1377 	pop	ar3
      00B10C 40 01            [24] 1378 	jc	00109$
      00B10E 22               [24] 1379 	ret
      00B10F                       1380 00109$:
                                   1381 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00B10F E5 51            [12] 1382 	mov	a,_vialrgb_get_value_sloc0_1_0
      00B111 25 51            [12] 1383 	add	a,_vialrgb_get_value_sloc0_1_0
      00B113 FA               [12] 1384 	mov	r2,a
      00B114 E5 52            [12] 1385 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B116 33               [12] 1386 	rlc	a
      00B117 FF               [12] 1387 	mov	r7,a
      00B118 EA               [12] 1388 	mov	a,r2
      00B119 24 A4            [12] 1389 	add	a, #_ak820_led_points
      00B11B F5 53            [12] 1390 	mov	_vialrgb_get_value_sloc1_1_0,a
      00B11D EF               [12] 1391 	mov	a,r7
      00B11E 34 B6            [12] 1392 	addc	a, #(_ak820_led_points >> 8)
      00B120 F5 54            [12] 1393 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00B122 85 53 82         [24] 1394 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B125 85 54 83         [24] 1395 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B128 E4               [12] 1396 	clr	a
      00B129 93               [24] 1397 	movc	a,@a+dptr
      00B12A 12 33 FC         [24] 1398 	lcall	_ak820_outline_0116
      00B12D F0               [24] 1399 	movx	@dptr,a
                                   1400 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00B12E 85 53 82         [24] 1401 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B131 85 54 83         [24] 1402 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B134 A3               [24] 1403 	inc	dptr
      00B135 E4               [12] 1404 	clr	a
      00B136 93               [24] 1405 	movc	a,@a+dptr
      00B137 12 38 6E         [24] 1406 	lcall	_ak820_outline_0145
      00B13A F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00B13B 12 B1 E6         [24] 1409 	lcall	_ak820_outline_0032
      00B13E A3               [24] 1410 	inc	dptr
      00B13F 74 04            [12] 1411 	mov	a,#0x04
      00B141 F0               [24] 1412 	movx	@dptr,a
                                   1413 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00B142 90 0D 4A         [24] 1414 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B145 04               [12] 1415 	inc	a
      00B146 2D               [12] 1416 	add	a, r5
      00B147 F0               [24] 1417 	movx	@dptr,a
      00B148 E4               [12] 1418 	clr	a
      00B149 3E               [12] 1419 	addc	a, r6
      00B14A A3               [24] 1420 	inc	dptr
      00B14B F0               [24] 1421 	movx	@dptr,a
      00B14C 85 51 82         [24] 1422 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00B14F 85 52 83         [24] 1423 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1424 ;	quantum/vialrgb.c:187: }
                                   1425 ;	quantum/vialrgb.c:188: }
      00B152 02 AE 75         [24] 1426 	ljmp	_get_matrix_pos_for_led
                                   1427 ;------------------------------------------------------------
                                   1428 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1429 ;------------------------------------------------------------
                                   1430 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1431 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1432 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1433 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1434 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1435 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1436 ;------------------------------------------------------------
                                   1437 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1438 ;	-----------------------------------------
                                   1439 ;	 function vialrgb_set_value
                                   1440 ;	-----------------------------------------
      00B155                       1441 _vialrgb_set_value:
      00B155 12 42 D2         [24] 1442 	lcall	_ak820_outline_0034
      00B158 90 0D 59         [24] 1443 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B15B 12 37 E1         [24] 1444 	lcall	_ak820_outline_0014
                                   1445 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00B15E 90 0D 58         [24] 1446 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B161 E0               [24] 1447 	movx	a,@dptr
      00B162 FF               [12] 1448 	mov	r7,a
      00B163 BF 20 02         [24] 1449 	cjne	r7,#0x20,00129$
      00B166 80 01            [24] 1450 	sjmp	00102$
      00B168                       1451 00129$:
      00B168 22               [24] 1452 	ret
      00B169                       1453 00102$:
                                   1454 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B169 90 0D 59         [24] 1455 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B16C 12 B1 EE         [24] 1456 	lcall	_ak820_outline_0040
                                   1457 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1458 ;	quantum/vialrgb.c:196: switch (cmd) {
      00B16F BA 41 02         [24] 1459 	cjne	r2,#0x41,00130$
      00B172 80 06            [24] 1460 	sjmp	00103$
      00B174                       1461 00130$:
      00B174 BA 42 02         [24] 1462 	cjne	r2,#0x42,00131$
      00B177 80 5E            [24] 1463 	sjmp	00104$
      00B179                       1464 00131$:
      00B179 22               [24] 1465 	ret
                                   1466 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00B17A                       1467 00103$:
                                   1468 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00B17A 12 33 FC         [24] 1469 	lcall	_ak820_outline_0116
      00B17D E0               [24] 1470 	movx	a,@dptr
      00B17E FA               [12] 1471 	mov	r2,a
      00B17F 12 B1 E6         [24] 1472 	lcall	_ak820_outline_0032
      00B182 E0               [24] 1473 	movx	a,@dptr
      00B183 F8               [12] 1474 	mov	r0,a
      00B184 79 00            [12] 1475 	mov	r1,#0x00
      00B186 88 56            [24] 1476 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00B188 89 55            [24] 1477 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00B18A 8A 01            [24] 1478 	mov	ar1,r2
      00B18C 7A 00            [12] 1479 	mov	r2,#0x00
      00B18E E5 56            [12] 1480 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00B190 42 02            [12] 1481 	orl	ar2,a
                                   1482 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00B192 12 43 3A         [24] 1483 	lcall	_ak820_outline_0146
      00B195 C0 06            [24] 1484 	push	ar6
      00B197 C0 05            [24] 1485 	push	ar5
      00B199 12 AE 47         [24] 1486 	lcall	_set_mode
      00B19C D0 05            [24] 1487 	pop	ar5
      00B19E D0 06            [24] 1488 	pop	ar6
                                   1489 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00B1A0 12 B1 E6         [24] 1490 	lcall	_ak820_outline_0032
      00B1A3 A3               [24] 1491 	inc	dptr
      00B1A4 E0               [24] 1492 	movx	a,@dptr
      00B1A5 F5 82            [12] 1493 	mov	dpl,a
      00B1A7 C0 06            [24] 1494 	push	ar6
      00B1A9 C0 05            [24] 1495 	push	ar5
      00B1AB 12 53 CB         [24] 1496 	lcall	_rgb_matrix_set_speed_noeeprom
      00B1AE D0 05            [24] 1497 	pop	ar5
      00B1B0 D0 06            [24] 1498 	pop	ar6
                                   1499 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00B1B2 12 B1 E6         [24] 1500 	lcall	_ak820_outline_0032
      00B1B5 A3               [24] 1501 	inc	dptr
      00B1B6 A3               [24] 1502 	inc	dptr
      00B1B7 E0               [24] 1503 	movx	a,@dptr
      00B1B8 F9               [12] 1504 	mov	r1,a
      00B1B9 7A 00            [12] 1505 	mov	r2,#0x00
      00B1BB 74 06            [12] 1506 	mov	a,#0x06
      00B1BD 12 B2 38         [24] 1507 	lcall	_ak820_outline_0162
      00B1C0 F8               [12] 1508 	mov	r0,a
      00B1C1 74 07            [12] 1509 	mov	a,#0x07
      00B1C3 12 B2 38         [24] 1510 	lcall	_ak820_outline_0162
      00B1C6 FE               [12] 1511 	mov	r6,a
      00B1C7 90 07 20         [24] 1512 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00B1CA E8               [12] 1513 	mov	a,r0
      00B1CB F0               [24] 1514 	movx	@dptr,a
      00B1CC 90 07 21         [24] 1515 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00B1CF EE               [12] 1516 	mov	a,r6
      00B1D0 F0               [24] 1517 	movx	@dptr,a
      00B1D1 12 43 3A         [24] 1518 	lcall	_ak820_outline_0146
                                   1519 ;	quantum/vialrgb.c:202: break;
                                   1520 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00B1D4 02 53 9C         [24] 1521 	ljmp	_rgb_matrix_sethsv_noeeprom
      00B1D7                       1522 00104$:
                                   1523 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00B1D7 EF               [12] 1524 	mov	a,r7
      00B1D8 24 FE            [12] 1525 	add	a,#0xfe
      00B1DA 90 0D 4E         [24] 1526 	mov	dptr,#_fast_set_leds_PARM_2
      00B1DD 12 46 9A         [24] 1527 	lcall	_ak820_outline_0114
                                   1528 ;	quantum/vialrgb.c:210: }
                                   1529 ;	quantum/vialrgb.c:211: }
      00B1E0 02 AE A8         [24] 1530 	ljmp	_fast_set_leds
                                   1531 ;------------------------------------------------------------
                                   1532 ;Allocation info for local variables in function 'vialrgb_save'
                                   1533 ;------------------------------------------------------------
                                   1534 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1535 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1536 ;------------------------------------------------------------
                                   1537 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1538 ;	-----------------------------------------
                                   1539 ;	 function vialrgb_save
                                   1540 ;	-----------------------------------------
      00B1E3                       1541 _vialrgb_save:
                                   1542 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1543 ;	quantum/vialrgb.c:218: }
      00B1E3 02 4E 12         [24] 1544 	ljmp	_eeconfig_update_rgb_matrix
                                   1545 	.area CSEG    (CODE)
                                   1546 	.area CONST   (CODE)
                                   1547 	.area CONST   (CODE)
      00B9E3                       1548 _supported_modes:
      00B9E3 00                    1549 	.db #0x00	; 0
      00B9E4 00                    1550 	.db #0x00	; 0
      00B9E5 01                    1551 	.db #0x01	; 1
      00B9E6 05                    1552 	.db #0x05	; 5
      00B9E7 02                    1553 	.db #0x02	; 2
      00B9E8 01                    1554 	.db #0x01	; 1
      00B9E9 06                    1555 	.db #0x06	; 6
      00B9EA 02                    1556 	.db #0x02	; 2
      00B9EB 0D                    1557 	.db #0x0d	; 13
      00B9EC 03                    1558 	.db #0x03	; 3
      00B9ED 0E                    1559 	.db #0x0e	; 14
      00B9EE 04                    1560 	.db #0x04	; 4
      00B9EF 1F                    1561 	.db #0x1f	; 31
      00B9F0 06                    1562 	.db #0x06	; 6
                                   1563 	.area CSEG    (CODE)
                                   1564 	.area XINIT   (CODE)
                                   1565 	.area CABS    (ABS,CODE)
                                   1566 
                                   1567 ; Experimental exact instruction outlining.
                                   1568 	.globl _ak820_outline_0004
                                   1569 	.globl _ak820_outline_0014
                                   1570 	.globl _ak820_outline_0018
                                   1571 	.globl _ak820_outline_0032
                                   1572 	.globl _ak820_outline_0033
                                   1573 	.globl _ak820_outline_0034
                                   1574 	.globl _ak820_outline_0040
                                   1575 	.globl _ak820_outline_0042
                                   1576 	.globl _ak820_outline_0047
                                   1577 	.globl _ak820_outline_0053
                                   1578 	.globl _ak820_outline_0060
                                   1579 	.globl _ak820_outline_0071
                                   1580 	.globl _ak820_outline_0075
                                   1581 	.globl _ak820_outline_0094
                                   1582 	.globl _ak820_outline_0095
                                   1583 	.globl _ak820_outline_0098
                                   1584 	.globl _ak820_outline_0099
                                   1585 	.globl _ak820_outline_0100
                                   1586 	.globl _ak820_outline_0101
                                   1587 	.globl _ak820_outline_0102
                                   1588 	.globl _ak820_outline_0111
                                   1589 	.globl _ak820_outline_0113
                                   1590 	.globl _ak820_outline_0114
                                   1591 	.globl _ak820_outline_0116
                                   1592 	.globl _ak820_outline_0124
                                   1593 	.globl _ak820_outline_0126
                                   1594 	.globl _ak820_outline_0133
                                   1595 	.globl _ak820_outline_0135
                                   1596 	.globl _ak820_outline_0145
                                   1597 	.globl _ak820_outline_0146
                                   1598 	.globl _ak820_outline_0151
                                   1599 	.globl _ak820_outline_0162
                                   1600 	.globl _ak820_outline_0176
                                   1601 
                                   1602 	.area CSEG (CODE)
                                   1603 ; function ak820_outline_0032
      00B1E6                       1604 _ak820_outline_0032:
      00B1E6 8D 82            [24] 1605 	mov	dpl,r5
      00B1E8 8E 83            [24] 1606 	mov	dph,r6
      00B1EA A3               [24] 1607 	inc	dptr
      00B1EB A3               [24] 1608 	inc	dptr
      00B1EC A3               [24] 1609 	inc	dptr
      00B1ED 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0040
      00B1EE                       1614 _ak820_outline_0040:
      00B1EE E0               [24] 1615 	movx	a,@dptr
      00B1EF FD               [12] 1616 	mov	r5,a
      00B1F0 A3               [24] 1617 	inc	dptr
      00B1F1 E0               [24] 1618 	movx	a,@dptr
      00B1F2 FE               [12] 1619 	mov	r6,a
      00B1F3 74 02            [12] 1620 	mov	a,#0x02
      00B1F5 2D               [12] 1621 	add	a,r5
      00B1F6 FB               [12] 1622 	mov	r3,a
      00B1F7 E4               [12] 1623 	clr	a
      00B1F8 3E               [12] 1624 	addc	a,r6
      00B1F9 FC               [12] 1625 	mov	r4,a
      00B1FA 8D 82            [24] 1626 	mov	dpl,r5
      00B1FC 8E 83            [24] 1627 	mov	dph,r6
      00B1FE A3               [24] 1628 	inc	dptr
      00B1FF E0               [24] 1629 	movx	a,@dptr
      00B200 FA               [12] 1630 	mov	r2,a
      00B201 22               [24] 1631 	ret
                                   1632 
                                   1633 	.area CSEG (CODE)
                                   1634 ; function ak820_outline_0042
      00B202                       1635 _ak820_outline_0042:
      00B202 ED               [12] 1636 	mov	a,r5
      00B203 75 F0 02         [24] 1637 	mov	b,#0x02
      00B206 A4               [48] 1638 	mul	ab
      00B207 24 E3            [12] 1639 	add	a,#_supported_modes
      00B209 FB               [12] 1640 	mov	r3,a
      00B20A 74 B9            [12] 1641 	mov	a,#(_supported_modes>>8)
      00B20C 35 F0            [12] 1642 	addc	a,b
      00B20E FC               [12] 1643 	mov	r4,a
      00B20F 8B 82            [24] 1644 	mov	dpl,r3
      00B211 8C 83            [24] 1645 	mov	dph,r4
      00B213 22               [24] 1646 	ret
                                   1647 
                                   1648 	.area CSEG (CODE)
                                   1649 ; function ak820_outline_0075
      00B214                       1650 _ak820_outline_0075:
      00B214 90 0D 4F         [24] 1651 	mov	dptr,#_fast_set_leds_args_10000_282
      00B217 E0               [24] 1652 	movx	a,@dptr
      00B218 F9               [12] 1653 	mov	r1,a
      00B219 A3               [24] 1654 	inc	dptr
      00B21A E0               [24] 1655 	movx	a,@dptr
      00B21B FF               [12] 1656 	mov	r7,a
      00B21C 89 82            [24] 1657 	mov	dpl,r1
      00B21E 8F 83            [24] 1658 	mov	dph,r7
      00B220 E0               [24] 1659 	movx	a,@dptr
      00B221 22               [24] 1660 	ret
                                   1661 
                                   1662 	.area CSEG (CODE)
                                   1663 ; function ak820_outline_0098
      00B222                       1664 _ak820_outline_0098:
      00B222 90 0D 4F         [24] 1665 	mov	dptr,#_fast_set_leds_args_10000_282
      00B225 74 01            [12] 1666 	mov	a,#0x01
      00B227 29               [12] 1667 	add	a,r1
      00B228 F0               [24] 1668 	movx	@dptr,a
      00B229 E4               [12] 1669 	clr	a
      00B22A 3F               [12] 1670 	addc	a,r7
      00B22B A3               [24] 1671 	inc	dptr
      00B22C F0               [24] 1672 	movx	@dptr,a
      00B22D 22               [24] 1673 	ret
                                   1674 
                                   1675 	.area CSEG (CODE)
                                   1676 ; function ak820_outline_0135
      00B22E                       1677 _ak820_outline_0135:
      00B22E E4               [12] 1678 	clr	a
      00B22F 93               [24] 1679 	movc	a,@a+dptr
      00B230 FC               [12] 1680 	mov	r4,a
      00B231 7B 00            [12] 1681 	mov	r3,#0x00
      00B233 8C 82            [24] 1682 	mov	dpl,r4
      00B235 8B 83            [24] 1683 	mov	dph,r3
      00B237 22               [24] 1684 	ret
                                   1685 
                                   1686 	.area CSEG (CODE)
                                   1687 ; function ak820_outline_0162
      00B238                       1688 _ak820_outline_0162:
      00B238 2D               [12] 1689 	add	a,r5
      00B239 F5 82            [12] 1690 	mov	dpl,a
      00B23B E4               [12] 1691 	clr	a
      00B23C 3E               [12] 1692 	addc	a,r6
      00B23D F5 83            [12] 1693 	mov	dph,a
      00B23F E0               [24] 1694 	movx	a,@dptr
      00B240 22               [24] 1695 	ret
