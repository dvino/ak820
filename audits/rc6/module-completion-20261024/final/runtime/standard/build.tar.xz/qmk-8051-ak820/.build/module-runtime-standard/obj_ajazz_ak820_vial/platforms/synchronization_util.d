synchronization_util.o: platforms/synchronization_util.c \
 keyboards/ajazz/ak820/config.h \
 qmk-8051-ak820/.build/module-runtime-standard/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h platforms/synchronization_util.h
