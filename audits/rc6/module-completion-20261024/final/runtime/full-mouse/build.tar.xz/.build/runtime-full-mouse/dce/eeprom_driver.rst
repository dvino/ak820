                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         47 bits:
      000025                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00067E                         85 _eeprom_read_word_addr_10000_91:
      00067E                         86 	.ds 3
      000681                         87 _eeprom_read_word_ret_10000_92:
      000681                         88 	.ds 2
      000683                         89 _eeprom_read_dword_addr_10000_93:
      000683                         90 	.ds 3
      000686                         91 _eeprom_read_dword_ret_10000_94:
      000686                         92 	.ds 4
      00068A                         93 _eeprom_write_byte_PARM_2:
      00068A                         94 	.ds 1
      00068B                         95 _eeprom_write_byte_addr_10000_95:
      00068B                         96 	.ds 3
      00068E                         97 _eeprom_write_word_PARM_2:
      00068E                         98 	.ds 2
      000690                         99 _eeprom_write_word_addr_10000_97:
      000690                        100 	.ds 3
      000693                        101 _eeprom_write_dword_PARM_2:
      000693                        102 	.ds 4
      000697                        103 _eeprom_write_dword_addr_10000_99:
      000697                        104 	.ds 3
      00069A                        105 _eeprom_update_byte_PARM_2:
      00069A                        106 	.ds 1
      00069B                        107 _eeprom_update_byte_addr_10000_107:
      00069B                        108 	.ds 3
      00069E                        109 _eeprom_update_word_PARM_2:
      00069E                        110 	.ds 2
      0006A0                        111 _eeprom_update_word_addr_10000_111:
      0006A0                        112 	.ds 3
      0006A3                        113 _eeprom_update_dword_PARM_2:
      0006A3                        114 	.ds 4
      0006A7                        115 _eeprom_update_dword_addr_10000_115:
      0006A7                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004CFF                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004CFF 12 42 D7         [24]  170 	lcall	_ak820_outline_0036
      004D02 90 06 7E         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004D05 12 37 E0         [24]  172 	lcall	_ak820_outline_0015
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004D08 90 06 81         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D0B 12 4F 0B         [24]  175 	lcall	_ak820_outline_0165
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004D0E 90 06 7E         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004D11 12 4E B9         [24]  178 	lcall	_ak820_outline_0021
      004D14 90 05 81         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004D17 ED               [12]  180 	mov	a,r5
      004D18 12 37 E0         [24]  181 	lcall	_ak820_outline_0015
      004D1B 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004D1E 12 4E FD         [24]  183 	lcall	_ak820_outline_0106
      004D21 90 06 81         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D24 12 40 73         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004D27 90 06 81         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D2A 12 4E F4         [24]  188 	lcall	_ak820_outline_0088
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004D2D 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004D2E                        201 _eeprom_read_dword:
      004D2E 12 42 D7         [24]  202 	lcall	_ak820_outline_0036
      004D31 90 06 83         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004D34 12 37 E0         [24]  204 	lcall	_ak820_outline_0015
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004D37 90 06 86         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D3A 12 4E C9         [24]  207 	lcall	_ak820_outline_0048
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004D3D 90 06 83         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004D40 12 4E B9         [24]  210 	lcall	_ak820_outline_0021
      004D43 90 05 81         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004D46 ED               [12]  212 	mov	a,r5
      004D47 12 37 E0         [24]  213 	lcall	_ak820_outline_0015
      004D4A 90 05 84         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004D4D 74 04            [12]  215 	mov	a,#0x04
      004D4F 12 38 60         [24]  216 	lcall	_ak820_outline_0122
      004D52 90 06 86         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D55 12 40 73         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004D58 90 06 86         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D5B 12 4E D2         [24]  221 	lcall	_ak820_outline_0053
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004D5E 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004D5F                        234 _eeprom_write_byte:
      004D5F 12 42 D7         [24]  235 	lcall	_ak820_outline_0036
      004D62 90 06 8B         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004D65 12 37 E0         [24]  237 	lcall	_ak820_outline_0015
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004D68 90 06 8B         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004D6B 12 4E 93         [24]  240 	lcall	_ak820_outline_0002
      004D6E 74 01            [12]  241 	mov	a,#0x01
      004D70 12 38 60         [24]  242 	lcall	_ak820_outline_0122
      004D73 90 06 8A         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004D76 02 40 FF         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004D79                        256 _eeprom_write_word:
      004D79 12 42 D7         [24]  257 	lcall	_ak820_outline_0036
      004D7C 90 06 90         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004D7F 12 37 E0         [24]  259 	lcall	_ak820_outline_0015
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004D82 90 06 90         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004D85 12 4E 93         [24]  262 	lcall	_ak820_outline_0002
      004D88 12 4E FD         [24]  263 	lcall	_ak820_outline_0106
      004D8B 90 06 8E         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004D8E 02 40 FF         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004D91                        277 _eeprom_write_dword:
      004D91 12 42 D7         [24]  278 	lcall	_ak820_outline_0036
      004D94 90 06 97         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004D97 12 37 E0         [24]  280 	lcall	_ak820_outline_0015
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004D9A 90 06 97         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004D9D 12 4E 93         [24]  283 	lcall	_ak820_outline_0002
      004DA0 74 04            [12]  284 	mov	a,#0x04
      004DA2 12 38 60         [24]  285 	lcall	_ak820_outline_0122
      004DA5 90 06 93         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004DA8 02 40 FF         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004DAB                        307 _eeprom_update_byte:
      004DAB C0 07            [24]  308 	push	ar7
      004DAD C0 06            [24]  309 	push	ar6
      004DAF C0 05            [24]  310 	push	ar5
      004DB1 C0 04            [24]  311 	push	ar4
      004DB3 12 42 D7         [24]  312 	lcall	_ak820_outline_0036
      004DB6 90 06 9B         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004DB9 12 37 E0         [24]  314 	lcall	_ak820_outline_0015
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004DBC 90 06 9B         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004DBF 12 4E AA         [24]  317 	lcall	_ak820_outline_0003
      004DC2 12 40 38         [24]  318 	lcall	_eeprom_read_byte
      004DC5 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004DC7 90 06 9A         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004DCA E0               [24]  322 	movx	a,@dptr
      004DCB FE               [12]  323 	mov	r6,a
      004DCC EF               [12]  324 	mov	a,r7
      004DCD B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004DD0 80 36            [24]  326 	sjmp	00103$
      004DD2                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004DD2 90 06 9B         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004DD5 12 38 20         [24]  330 	lcall	_ak820_outline_0059
      004DD8 A3               [24]  331 	inc	dptr
      004DD9 E0               [24]  332 	movx	a,@dptr
      004DDA FF               [12]  333 	mov	r7,a
      004DDB 90 06 8A         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004DDE EE               [12]  335 	mov	a,r6
      004DDF F0               [24]  336 	movx	@dptr,a
      004DE0 12 38 55         [24]  337 	lcall	_ak820_outline_0117
      004DE3 8F F0            [24]  338 	mov	b, r7
      004DE5 C0 07            [24]  339 	push	ar7
      004DE7 C0 06            [24]  340 	push	ar6
      004DE9 C0 05            [24]  341 	push	ar5
      004DEB C0 04            [24]  342 	push	ar4
      004DED C0 03            [24]  343 	push	ar3
      004DEF C0 02            [24]  344 	push	ar2
      004DF1 C0 01            [24]  345 	push	ar1
      004DF3 C0 00            [24]  346 	push	ar0
      004DF5 12 4D 5F         [24]  347 	lcall	_eeprom_write_byte
      004DF8 D0 00            [24]  348 	pop	ar0
      004DFA D0 01            [24]  349 	pop	ar1
      004DFC D0 02            [24]  350 	pop	ar2
      004DFE D0 03            [24]  351 	pop	ar3
      004E00 D0 04            [24]  352 	pop	ar4
      004E02 D0 05            [24]  353 	pop	ar5
      004E04 D0 06            [24]  354 	pop	ar6
      004E06 D0 07            [24]  355 	pop	ar7
      004E08                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      004E08 D0 04            [24]  358 	pop	ar4
      004E0A D0 05            [24]  359 	pop	ar5
      004E0C D0 06            [24]  360 	pop	ar6
      004E0E D0 07            [24]  361 	pop	ar7
      004E10 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      004E11                        374 _eeprom_update_word:
      004E11 12 42 D7         [24]  375 	lcall	_ak820_outline_0036
      004E14 90 06 A0         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E17 12 37 E0         [24]  377 	lcall	_ak820_outline_0015
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004E1A 90 06 A0         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E1D 12 4E AA         [24]  380 	lcall	_ak820_outline_0003
      004E20 12 4C FF         [24]  381 	lcall	_eeprom_read_word
      004E23 12 43 2B         [24]  382 	lcall	_ak820_outline_0130
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004E26 90 06 9E         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      004E29 12 38 20         [24]  385 	lcall	_ak820_outline_0059
      004E2C EE               [12]  386 	mov	a,r6
      004E2D B5 04 05         [24]  387 	cjne	a,ar4,00112$
      004E30 EF               [12]  388 	mov	a,r7
      004E31 B5 05 01         [24]  389 	cjne	a,ar5,00112$
      004E34 22               [24]  390 	ret
      004E35                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004E35 90 06 A0         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E38 E0               [24]  394 	movx	a,@dptr
      004E39 FB               [12]  395 	mov	r3,a
      004E3A A3               [24]  396 	inc	dptr
      004E3B 12 38 01         [24]  397 	lcall	_ak820_outline_0050
      004E3E 90 06 8E         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      004E41 12 38 26         [24]  399 	lcall	_ak820_outline_0070
      004E44 8B 82            [24]  400 	mov	dpl, r3
      004E46 8E 83            [24]  401 	mov	dph, r6
      004E48 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      004E4A 02 4D 79         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      004E4D                        416 _eeprom_update_dword:
      004E4D 12 42 D7         [24]  417 	lcall	_ak820_outline_0036
      004E50 90 06 A7         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E53 12 37 E0         [24]  419 	lcall	_ak820_outline_0015
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004E56 90 06 A7         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E59 12 4E AA         [24]  422 	lcall	_ak820_outline_0003
      004E5C 12 4D 2E         [24]  423 	lcall	_eeprom_read_dword
      004E5F 12 4E E3         [24]  424 	lcall	_ak820_outline_0056
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004E62 90 06 A3         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      004E65 E0               [24]  427 	movx	a,@dptr
      004E66 F8               [12]  428 	mov	r0,a
      004E67 A3               [24]  429 	inc	dptr
      004E68 12 4E EB         [24]  430 	lcall	_ak820_outline_0087
      004E6B EC               [12]  431 	mov	a,r4
      004E6C B5 00 0D         [24]  432 	cjne	a,ar0,00112$
      004E6F ED               [12]  433 	mov	a,r5
      004E70 B5 01 09         [24]  434 	cjne	a,ar1,00112$
      004E73 EE               [12]  435 	mov	a,r6
      004E74 B5 02 05         [24]  436 	cjne	a,ar2,00112$
      004E77 EF               [12]  437 	mov	a,r7
      004E78 B5 03 01         [24]  438 	cjne	a,ar3,00112$
      004E7B 22               [24]  439 	ret
      004E7C                        440 00112$:
                                    441 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004E7C 90 06 A7         [24]  442 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E7F 12 4E B9         [24]  443 	lcall	_ak820_outline_0021
      004E82 90 06 93         [24]  444 	mov	dptr,#_eeprom_write_dword_PARM_2
      004E85 E8               [12]  445 	mov	a,r0
      004E86 F0               [24]  446 	movx	@dptr,a
      004E87 E9               [12]  447 	mov	a,r1
      004E88 A3               [24]  448 	inc	dptr
      004E89 12 4F 04         [24]  449 	lcall	_ak820_outline_0153
      004E8C F0               [24]  450 	movx	@dptr,a
      004E8D 12 4E C2         [24]  451 	lcall	_ak820_outline_0043
                                    452 ;	drivers/eeprom/eeprom_driver.c:101: }
      004E90 02 4D 91         [24]  453 	ljmp	_eeprom_write_dword
                                    454 	.area CSEG    (CODE)
                                    455 	.area CONST   (CODE)
                                    456 	.area XINIT   (CODE)
                                    457 	.area CABS    (ABS,CODE)
                                    458 
                                    459 ; Experimental exact instruction outlining.
                                    460 	.globl _ak820_outline_0002
                                    461 	.globl _ak820_outline_0003
                                    462 	.globl _ak820_outline_0015
                                    463 	.globl _ak820_outline_0021
                                    464 	.globl _ak820_outline_0036
                                    465 	.globl _ak820_outline_0043
                                    466 	.globl _ak820_outline_0048
                                    467 	.globl _ak820_outline_0050
                                    468 	.globl _ak820_outline_0053
                                    469 	.globl _ak820_outline_0056
                                    470 	.globl _ak820_outline_0059
                                    471 	.globl _ak820_outline_0070
                                    472 	.globl _ak820_outline_0087
                                    473 	.globl _ak820_outline_0088
                                    474 	.globl _ak820_outline_0106
                                    475 	.globl _ak820_outline_0117
                                    476 	.globl _ak820_outline_0122
                                    477 	.globl _ak820_outline_0130
                                    478 	.globl _ak820_outline_0153
                                    479 	.globl _ak820_outline_0165
                                    480 
                                    481 	.area CSEG (CODE)
                                    482 ; function ak820_outline_0002
      004E93                        483 _ak820_outline_0002:
      004E93 E0               [24]  484 	movx	a,@dptr
      004E94 FD               [12]  485 	mov	r5,a
      004E95 A3               [24]  486 	inc	dptr
      004E96 E0               [24]  487 	movx	a,@dptr
      004E97 FE               [12]  488 	mov	r6,a
      004E98 A3               [24]  489 	inc	dptr
      004E99 E0               [24]  490 	movx	a,@dptr
      004E9A FF               [12]  491 	mov	r7,a
      004E9B 90 05 8A         [24]  492 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004E9E ED               [12]  493 	mov	a,r5
      004E9F F0               [24]  494 	movx	@dptr,a
      004EA0 EE               [12]  495 	mov	a,r6
      004EA1 A3               [24]  496 	inc	dptr
      004EA2 F0               [24]  497 	movx	@dptr,a
      004EA3 EF               [12]  498 	mov	a,r7
      004EA4 A3               [24]  499 	inc	dptr
      004EA5 F0               [24]  500 	movx	@dptr,a
      004EA6 90 05 8D         [24]  501 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004EA9 22               [24]  502 	ret
                                    503 
                                    504 	.area CSEG (CODE)
                                    505 ; function ak820_outline_0003
      004EAA                        506 _ak820_outline_0003:
      004EAA E0               [24]  507 	movx	a,@dptr
      004EAB FD               [12]  508 	mov	r5,a
      004EAC A3               [24]  509 	inc	dptr
      004EAD E0               [24]  510 	movx	a,@dptr
      004EAE FE               [12]  511 	mov	r6,a
      004EAF A3               [24]  512 	inc	dptr
      004EB0 E0               [24]  513 	movx	a,@dptr
      004EB1 FF               [12]  514 	mov	r7,a
      004EB2 8D 82            [24]  515 	mov	dpl,r5
      004EB4 8E 83            [24]  516 	mov	dph,r6
      004EB6 8F F0            [24]  517 	mov	b,r7
      004EB8 22               [24]  518 	ret
                                    519 
                                    520 	.area CSEG (CODE)
                                    521 ; function ak820_outline_0021
      004EB9                        522 _ak820_outline_0021:
      004EB9 E0               [24]  523 	movx	a,@dptr
      004EBA FD               [12]  524 	mov	r5,a
      004EBB A3               [24]  525 	inc	dptr
      004EBC E0               [24]  526 	movx	a,@dptr
      004EBD FE               [12]  527 	mov	r6,a
      004EBE A3               [24]  528 	inc	dptr
      004EBF E0               [24]  529 	movx	a,@dptr
      004EC0 FF               [12]  530 	mov	r7,a
      004EC1 22               [24]  531 	ret
                                    532 
                                    533 	.area CSEG (CODE)
                                    534 ; function ak820_outline_0043
      004EC2                        535 _ak820_outline_0043:
      004EC2 8D 82            [24]  536 	mov	dpl,r5
      004EC4 8E 83            [24]  537 	mov	dph,r6
      004EC6 8F F0            [24]  538 	mov	b,r7
      004EC8 22               [24]  539 	ret
                                    540 
                                    541 	.area CSEG (CODE)
                                    542 ; function ak820_outline_0048
      004EC9                        543 _ak820_outline_0048:
      004EC9 E4               [12]  544 	clr	a
      004ECA F0               [24]  545 	movx	@dptr,a
      004ECB A3               [24]  546 	inc	dptr
      004ECC F0               [24]  547 	movx	@dptr,a
      004ECD A3               [24]  548 	inc	dptr
      004ECE F0               [24]  549 	movx	@dptr,a
      004ECF A3               [24]  550 	inc	dptr
      004ED0 F0               [24]  551 	movx	@dptr,a
      004ED1 22               [24]  552 	ret
                                    553 
                                    554 	.area CSEG (CODE)
                                    555 ; function ak820_outline_0053
      004ED2                        556 _ak820_outline_0053:
      004ED2 E0               [24]  557 	movx	a,@dptr
      004ED3 FC               [12]  558 	mov	r4,a
      004ED4 A3               [24]  559 	inc	dptr
      004ED5 E0               [24]  560 	movx	a,@dptr
      004ED6 FD               [12]  561 	mov	r5,a
      004ED7 A3               [24]  562 	inc	dptr
      004ED8 E0               [24]  563 	movx	a,@dptr
      004ED9 FE               [12]  564 	mov	r6,a
      004EDA A3               [24]  565 	inc	dptr
      004EDB E0               [24]  566 	movx	a,@dptr
      004EDC 8C 82            [24]  567 	mov	dpl,r4
      004EDE 8D 83            [24]  568 	mov	dph,r5
      004EE0 8E F0            [24]  569 	mov	b,r6
      004EE2 22               [24]  570 	ret
                                    571 
                                    572 	.area CSEG (CODE)
                                    573 ; function ak820_outline_0056
      004EE3                        574 _ak820_outline_0056:
      004EE3 AC 82            [24]  575 	mov	r4,dpl
      004EE5 AD 83            [24]  576 	mov	r5,dph
      004EE7 AE F0            [24]  577 	mov	r6,b
      004EE9 FF               [12]  578 	mov	r7,a
      004EEA 22               [24]  579 	ret
                                    580 
                                    581 	.area CSEG (CODE)
                                    582 ; function ak820_outline_0087
      004EEB                        583 _ak820_outline_0087:
      004EEB E0               [24]  584 	movx	a,@dptr
      004EEC F9               [12]  585 	mov	r1,a
      004EED A3               [24]  586 	inc	dptr
      004EEE E0               [24]  587 	movx	a,@dptr
      004EEF FA               [12]  588 	mov	r2,a
      004EF0 A3               [24]  589 	inc	dptr
      004EF1 E0               [24]  590 	movx	a,@dptr
      004EF2 FB               [12]  591 	mov	r3,a
      004EF3 22               [24]  592 	ret
                                    593 
                                    594 	.area CSEG (CODE)
                                    595 ; function ak820_outline_0088
      004EF4                        596 _ak820_outline_0088:
      004EF4 E0               [24]  597 	movx	a,@dptr
      004EF5 FE               [12]  598 	mov	r6,a
      004EF6 A3               [24]  599 	inc	dptr
      004EF7 E0               [24]  600 	movx	a,@dptr
      004EF8 8E 82            [24]  601 	mov	dpl,r6
      004EFA F5 83            [12]  602 	mov	dph,a
      004EFC 22               [24]  603 	ret
                                    604 
                                    605 	.area CSEG (CODE)
                                    606 ; function ak820_outline_0106
      004EFD                        607 _ak820_outline_0106:
      004EFD 74 02            [12]  608 	mov	a,#0x02
      004EFF F0               [24]  609 	movx	@dptr,a
      004F00 E4               [12]  610 	clr	a
      004F01 A3               [24]  611 	inc	dptr
      004F02 F0               [24]  612 	movx	@dptr,a
      004F03 22               [24]  613 	ret
                                    614 
                                    615 	.area CSEG (CODE)
                                    616 ; function ak820_outline_0153
      004F04                        617 _ak820_outline_0153:
      004F04 F0               [24]  618 	movx	@dptr,a
      004F05 EA               [12]  619 	mov	a,r2
      004F06 A3               [24]  620 	inc	dptr
      004F07 F0               [24]  621 	movx	@dptr,a
      004F08 EB               [12]  622 	mov	a,r3
      004F09 A3               [24]  623 	inc	dptr
      004F0A 22               [24]  624 	ret
                                    625 
                                    626 	.area CSEG (CODE)
                                    627 ; function ak820_outline_0165
      004F0B                        628 _ak820_outline_0165:
      004F0B E4               [12]  629 	clr	a
      004F0C F0               [24]  630 	movx	@dptr,a
      004F0D A3               [24]  631 	inc	dptr
      004F0E F0               [24]  632 	movx	@dptr,a
      004F0F 22               [24]  633 	ret
