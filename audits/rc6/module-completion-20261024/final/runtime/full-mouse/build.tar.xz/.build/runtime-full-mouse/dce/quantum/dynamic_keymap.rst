                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000028                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000028                        588 	.ds 2
      00002A                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002A                        590 	.ds 1
      00002B                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002B                        592 	.ds 1
      00002C                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002C                        594 	.ds 2
      00002E                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002E                        596 	.ds 2
      000030                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000030                        598 	.ds 1
      000031                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000031                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000022                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000022                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000AEC                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AEC                        628 	.ds 1
      000AED                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AED                        630 	.ds 1
      000AEE                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_365:
      000AEE                        632 	.ds 1
      000AEF                        633 _dynamic_keymap_get_keycode_PARM_2:
      000AEF                        634 	.ds 1
      000AF0                        635 _dynamic_keymap_get_keycode_PARM_3:
      000AF0                        636 	.ds 1
      000AF1                        637 _dynamic_keymap_get_keycode_layer_10000_367:
      000AF1                        638 	.ds 1
      000AF2                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AF2                        640 	.ds 1
      000AF3                        641 _dynamic_keymap_set_keycode_PARM_3:
      000AF3                        642 	.ds 1
      000AF4                        643 _dynamic_keymap_set_keycode_PARM_4:
      000AF4                        644 	.ds 2
      000AF6                        645 _dynamic_keymap_set_keycode_layer_10000_371:
      000AF6                        646 	.ds 1
      000AF7                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000AF7                        648 	.ds 1
      000AF8                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_375:
      000AF8                        650 	.ds 1
      000AF9                        651 _dynamic_keymap_get_encoder_PARM_2:
      000AF9                        652 	.ds 1
      000AFA                        653 _dynamic_keymap_get_encoder_PARM_3:
      000AFA                        654 	.ds 1
      000AFB                        655 _dynamic_keymap_get_encoder_layer_10000_377:
      000AFB                        656 	.ds 1
      000AFC                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AFC                        658 	.ds 1
      000AFD                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AFD                        660 	.ds 1
      000AFE                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AFE                        662 	.ds 2
      000B00                        663 _dynamic_keymap_set_encoder_layer_10000_381:
      000B00                        664 	.ds 1
      000B01                        665 _dynamic_keymap_get_combo_PARM_2:
      000B01                        666 	.ds 3
      000B04                        667 _dynamic_keymap_get_combo_index_10000_385:
      000B04                        668 	.ds 1
      000B05                        669 _dynamic_keymap_set_combo_PARM_2:
      000B05                        670 	.ds 3
      000B08                        671 _dynamic_keymap_set_combo_index_10000_391:
      000B08                        672 	.ds 1
      000B09                        673 _dynamic_keymap_set_combo_stored_10002_396:
      000B09                        674 	.ds 10
      000B13                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_399:
      000B13                        676 	.ds 1
      000B14                        677 _dynamic_keymap_reset_combo_10001_408:
      000B14                        678 	.ds 10
      000B1E                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B1E                        680 	.ds 2
      000B20                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B20                        682 	.ds 2
      000B22                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B22                        684 	.ds 2
      000B24                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B24                        686 	.ds 3
      000B27                        687 _ak820_dynamic_read_buffer_base_10000_410:
      000B27                        688 	.ds 2
      000B29                        689 _ak820_dynamic_read_buffer_available_10000_411:
      000B29                        690 	.ds 1
      000B2A                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B2A                        692 	.ds 2
      000B2C                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B2C                        694 	.ds 3
      000B2F                        695 _dynamic_keymap_get_buffer_offset_10000_417:
      000B2F                        696 	.ds 2
      000B31                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B31                        698 	.ds 2
      000B33                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B33                        700 	.ds 3
      000B36                        701 _dynamic_keymap_set_buffer_offset_10000_419:
      000B36                        702 	.ds 2
      000B38                        703 _dynamic_keymap_set_buffer_chk_offset_30001_426:
      000B38                        704 	.ds 1
      000B39                        705 _dynamic_keymap_set_buffer_chk_sz_30001_426:
      000B39                        706 	.ds 1
      000B3A                        707 _dynamic_keymap_set_buffer_i_40001_433:
      000B3A                        708 	.ds 1
      000B3B                        709 _keycode_at_keymap_location_PARM_2:
      000B3B                        710 	.ds 1
      000B3C                        711 _keycode_at_keymap_location_PARM_3:
      000B3C                        712 	.ds 1
      000B3D                        713 _keycode_at_keymap_location_layer_num_10000_437:
      000B3D                        714 	.ds 1
      000B3E                        715 _keycode_at_encodermap_location_PARM_2:
      000B3E                        716 	.ds 1
      000B3F                        717 _keycode_at_encodermap_location_PARM_3:
      000B3F                        718 	.ds 1
      000B40                        719 _keycode_at_encodermap_location_layer_num_10000_441:
      000B40                        720 	.ds 1
      000B41                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B41                        722 	.ds 2
      000B43                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B43                        724 	.ds 3
      000B46                        725 _dynamic_keymap_macro_get_buffer_offset_10000_449:
      000B46                        726 	.ds 2
      000B48                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B48                        728 	.ds 2
      000B4A                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B4A                        730 	.ds 3
      000B4D                        731 _dynamic_keymap_macro_set_buffer_offset_10000_451:
      000B4D                        732 	.ds 2
      000B4F                        733 _decode_keycode_kc_10000_455:
      000B4F                        734 	.ds 2
      000B51                        735 _dynamic_keymap_macro_send_id_10000_458:
      000B51                        736 	.ds 1
      000B52                        737 _dynamic_keymap_macro_send_sending_10000_459:
      000B52                        738 	.ds 1
      000B53                        739 _dynamic_keymap_macro_send_p_10001_464:
      000B53                        740 	.ds 2
      000B55                        741 _dynamic_keymap_macro_send_data_10003_471:
      000B55                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      00858B                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      00858B 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      00858E 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_365'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      00858F                        810 _dynamic_keymap_key_to_eeprom_address:
      00858F E5 82            [12]  811 	mov	a,dpl
      008591 90 0A EE         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_365
      008594 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008595 E0               [24]  815 	movx	a,@dptr
      008596 FF               [12]  816 	mov	r7,a
      008597 7E 00            [12]  817 	mov	r6,#0x00
      008599 74 40            [12]  818 	mov	a,#0x40
      00859B 12 43 30         [24]  819 	lcall	_ak820_outline_0133
      00859E 7D 00            [12]  820 	mov	r5,#0x00
      0085A0 90 0A EC         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0085A3 E0               [24]  822 	movx	a,@dptr
      0085A4 75 F0 10         [24]  823 	mov	b,#0x10
      0085A7 A4               [48]  824 	mul	ab
      0085A8 2E               [12]  825 	add	a, r6
      0085A9 FE               [12]  826 	mov	r6,a
      0085AA EF               [12]  827 	mov	a,r7
      0085AB 35 F0            [12]  828 	addc	a, b
      0085AD FF               [12]  829 	mov	r7,a
      0085AE 90 0A ED         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0085B1 E0               [24]  831 	movx	a,@dptr
      0085B2 7C 00            [12]  832 	mov	r4,#0x00
      0085B4 25 E0            [12]  833 	add	a,acc
      0085B6 FB               [12]  834 	mov	r3,a
      0085B7 EC               [12]  835 	mov	a,r4
      0085B8 33               [12]  836 	rlc	a
      0085B9 FC               [12]  837 	mov	r4,a
      0085BA EB               [12]  838 	mov	a,r3
      0085BB 2E               [12]  839 	add	a, r6
      0085BC FE               [12]  840 	mov	r6,a
      0085BD EC               [12]  841 	mov	a,r4
      0085BE 3F               [12]  842 	addc	a, r7
      0085BF FF               [12]  843 	mov	r7,a
      0085C0 12 43 20         [24]  844 	lcall	_ak820_outline_0116
      0085C3 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      0085C5 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_367'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_370'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_370'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      0085C6                        861 _dynamic_keymap_get_keycode:
      0085C6 E5 82            [12]  862 	mov	a,dpl
      0085C8 90 0A F1         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_367
      0085CB F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0085CC E0               [24]  866 	movx	a,@dptr
      0085CD FF               [12]  867 	mov	r7,a
      0085CE BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      0085D1                        869 00121$:
      0085D1 50 14            [24]  870 	jnc	00101$
      0085D3 90 0A EF         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0085D6 E0               [24]  872 	movx	a,@dptr
      0085D7 FE               [12]  873 	mov	r6,a
      0085D8 BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      0085DB                        875 00123$:
      0085DB 50 0A            [24]  876 	jnc	00101$
      0085DD 90 0A F0         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0085E0 E0               [24]  878 	movx	a,@dptr
      0085E1 FD               [12]  879 	mov	r5,a
      0085E2 BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      0085E5                        881 00125$:
      0085E5 40 04            [24]  882 	jc	00102$
      0085E7                        883 00101$:
      0085E7 90 00 00         [24]  884 	mov	dptr,#0x0000
      0085EA 22               [24]  885 	ret
      0085EB                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0085EB 12 90 3C         [24]  888 	lcall	_ak820_outline_0095
      0085EE 12 85 8F         [24]  889 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      0085F1 12 90 49         [24]  891 	lcall	_ak820_outline_0112
      0085F4 12 40 38         [24]  892 	lcall	_eeprom_read_byte
      0085F7 AB 82            [24]  893 	mov	r3,dpl
      0085F9 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      0085FB 0D               [12]  896 	inc	r5
      0085FC BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      0085FF 0E               [12]  898 	inc	r6
      008600                        899 00127$:
      008600 12 4E C2         [24]  900 	lcall	_ak820_outline_0043
      008603 12 40 38         [24]  901 	lcall	_eeprom_read_byte
      008606 AF 82            [24]  902 	mov	r7, dpl
      008608 7E 00            [12]  903 	mov	r6,#0x00
      00860A EF               [12]  904 	mov	a,r7
      00860B 42 04            [12]  905 	orl	ar4,a
      00860D EE               [12]  906 	mov	a,r6
      00860E 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      008610 12 43 5C         [24]  909 	lcall	_ak820_outline_0179
                                    910 ;	quantum/dynamic_keymap.c:215: }
      008613 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_371'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_374'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      008614                        925 _dynamic_keymap_set_keycode:
      008614 E5 82            [12]  926 	mov	a,dpl
      008616 90 0A F6         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_371
      008619 F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      00861A E0               [24]  930 	movx	a,@dptr
      00861B FF               [12]  931 	mov	r7,a
      00861C BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      00861F                        933 00121$:
      00861F 50 14            [24]  934 	jnc	00101$
      008621 90 0A F2         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008624 E0               [24]  936 	movx	a,@dptr
      008625 FE               [12]  937 	mov	r6,a
      008626 BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      008629                        939 00123$:
      008629 50 0A            [24]  940 	jnc	00101$
      00862B 90 0A F3         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00862E E0               [24]  942 	movx	a,@dptr
      00862F FD               [12]  943 	mov	r5,a
      008630 BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      008633                        945 00125$:
      008633 40 01            [24]  946 	jc	00102$
      008635                        947 00101$:
      008635 22               [24]  948 	ret
      008636                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008636 12 90 3C         [24]  951 	lcall	_ak820_outline_0095
      008639 12 85 8F         [24]  952 	lcall	_dynamic_keymap_key_to_eeprom_address
      00863C 12 90 49         [24]  953 	lcall	_ak820_outline_0112
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      00863F 90 0A F4         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008642 E0               [24]  956 	movx	a,@dptr
      008643 FB               [12]  957 	mov	r3,a
      008644 A3               [24]  958 	inc	dptr
      008645 E0               [24]  959 	movx	a,@dptr
      008646 90 06 9A         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      008649 F0               [24]  961 	movx	@dptr,a
      00864A 12 4E C2         [24]  962 	lcall	_ak820_outline_0043
      00864D 12 4D AB         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008650 0D               [12]  965 	inc	r5
      008651 BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      008654 0E               [12]  967 	inc	r6
      008655                        968 00127$:
      008655 90 06 9A         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      008658 EB               [12]  970 	mov	a,r3
      008659 F0               [24]  971 	movx	@dptr,a
      00865A 12 4E C2         [24]  972 	lcall	_ak820_outline_0043
                                    973 ;	quantum/dynamic_keymap.c:223: }
      00865D 02 4D AB         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      008660                        985 _dynamic_keymap_encoder_to_eeprom_address:
      008660 E5 82            [12]  986 	mov	a,dpl
      008662 90 0A F8         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375
      008665 F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008666 E0               [24]  990 	movx	a,@dptr
      008667 75 F0 04         [24]  991 	mov	b,#0x04
      00866A A4               [48]  992 	mul	ab
      00866B 24 40            [12]  993 	add	a, #0x40
      00866D FD               [12]  994 	mov	r5,a
      00866E 74 06            [12]  995 	mov	a,#0x06
      008670 35 F0            [12]  996 	addc	a, b
      008672 FE               [12]  997 	mov	r6,a
      008673 7F 00            [12]  998 	mov	r7,#0x00
      008675 90 0A F7         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008678 E0               [24] 1000 	movx	a,@dptr
      008679 75 F0 04         [24] 1001 	mov	b,#0x04
      00867C A4               [48] 1002 	mul	ab
      00867D 2D               [12] 1003 	add	a, r5
      00867E FD               [12] 1004 	mov	r5,a
      00867F EE               [12] 1005 	mov	a,r6
      008680 35 F0            [12] 1006 	addc	a, b
      008682 FE               [12] 1007 	mov	r6,a
      008683 12 4E C2         [24] 1008 	lcall	_ak820_outline_0043
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      008686 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_377'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_380'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_380'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      008687                       1024 _dynamic_keymap_get_encoder:
      008687 E5 82            [12] 1025 	mov	a,dpl
      008689 90 0A FB         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_377
      00868C F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      00868D E0               [24] 1029 	movx	a,@dptr
      00868E FF               [12] 1030 	mov	r7,a
      00868F BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      008692                       1032 00131$:
      008692 50 0A            [24] 1033 	jnc	00101$
      008694 90 0A F9         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008697 E0               [24] 1035 	movx	a,@dptr
      008698 FE               [12] 1036 	mov	r6,a
      008699 BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      00869C                       1038 00133$:
      00869C 40 04            [24] 1039 	jc	00102$
      00869E                       1040 00101$:
      00869E 90 00 00         [24] 1041 	mov	dptr,#0x0000
      0086A1 22               [24] 1042 	ret
      0086A2                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0086A2 90 0A F7         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0086A5 12 79 53         [24] 1046 	lcall	_ak820_outline_0183
      0086A8 12 86 60         [24] 1047 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0086AB 12 90 49         [24] 1048 	lcall	_ak820_outline_0112
                                   1049 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      0086AE 90 0A FA         [24] 1050 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0086B1 E0               [24] 1051 	movx	a,@dptr
      0086B2 FC               [12] 1052 	mov	r4,a
      0086B3 E0               [24] 1053 	movx	a,@dptr
      0086B4 60 04            [24] 1054 	jz	00106$
      0086B6 7B 00            [12] 1055 	mov	r3,#0x00
      0086B8 80 02            [24] 1056 	sjmp	00107$
      0086BA                       1057 00106$:
      0086BA 7B 02            [12] 1058 	mov	r3,#0x02
      0086BC                       1059 00107$:
      0086BC EB               [12] 1060 	mov	a,r3
      0086BD 12 90 1A         [24] 1061 	lcall	_ak820_outline_0024
      0086C0 12 40 38         [24] 1062 	lcall	_eeprom_read_byte
      0086C3 AA 82            [24] 1063 	mov	r2,dpl
      0086C5 7B 00            [12] 1064 	mov	r3,#0x00
                                   1065 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0086C7 EC               [12] 1066 	mov	a,r4
      0086C8 60 04            [24] 1067 	jz	00108$
      0086CA 7C 00            [12] 1068 	mov	r4,#0x00
      0086CC 80 02            [24] 1069 	sjmp	00109$
      0086CE                       1070 00108$:
      0086CE 7C 02            [12] 1071 	mov	r4,#0x02
      0086D0                       1072 00109$:
      0086D0 EC               [12] 1073 	mov	a,r4
      0086D1 12 38 75         [24] 1074 	lcall	_ak820_outline_0156
      0086D4 0D               [12] 1075 	inc	r5
      0086D5 BD 00 01         [24] 1076 	cjne	r5,#0x00,00137$
      0086D8 0E               [12] 1077 	inc	r6
      0086D9                       1078 00137$:
      0086D9 12 4E C2         [24] 1079 	lcall	_ak820_outline_0043
      0086DC 12 40 38         [24] 1080 	lcall	_eeprom_read_byte
      0086DF AF 82            [24] 1081 	mov	r7, dpl
      0086E1 7E 00            [12] 1082 	mov	r6,#0x00
      0086E3 EF               [12] 1083 	mov	a,r7
      0086E4 42 03            [12] 1084 	orl	ar3,a
      0086E6 EE               [12] 1085 	mov	a,r6
      0086E7 42 02            [12] 1086 	orl	ar2,a
                                   1087 ;	quantum/dynamic_keymap.c:236: return keycode;
      0086E9 8B 82            [24] 1088 	mov	dpl, r3
      0086EB 8A 83            [24] 1089 	mov	dph, r2
                                   1090 ;	quantum/dynamic_keymap.c:237: }
      0086ED 22               [24] 1091 	ret
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1094 ;------------------------------------------------------------
                                   1095 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1096 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1097 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1098 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1099 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_381'
                                   1100 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_384'
                                   1101 ;------------------------------------------------------------
                                   1102 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1103 ;	-----------------------------------------
                                   1104 ;	 function dynamic_keymap_set_encoder
                                   1105 ;	-----------------------------------------
      0086EE                       1106 _dynamic_keymap_set_encoder:
      0086EE E5 82            [12] 1107 	mov	a,dpl
      0086F0 90 0B 00         [24] 1108 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_381
      0086F3 F0               [24] 1109 	movx	@dptr,a
                                   1110 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      0086F4 E0               [24] 1111 	movx	a,@dptr
      0086F5 FF               [12] 1112 	mov	r7,a
      0086F6 BF 06 00         [24] 1113 	cjne	r7,#0x06,00131$
      0086F9                       1114 00131$:
      0086F9 50 0A            [24] 1115 	jnc	00101$
      0086FB 90 0A FC         [24] 1116 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0086FE E0               [24] 1117 	movx	a,@dptr
      0086FF FE               [12] 1118 	mov	r6,a
      008700 BE 01 00         [24] 1119 	cjne	r6,#0x01,00133$
      008703                       1120 00133$:
      008703 40 01            [24] 1121 	jc	00102$
      008705                       1122 00101$:
      008705 22               [24] 1123 	ret
      008706                       1124 00102$:
                                   1125 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008706 90 0A F7         [24] 1126 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008709 12 79 53         [24] 1127 	lcall	_ak820_outline_0183
      00870C 12 86 60         [24] 1128 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      00870F 12 90 49         [24] 1129 	lcall	_ak820_outline_0112
                                   1130 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008712 90 0A FD         [24] 1131 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008715 E0               [24] 1132 	movx	a,@dptr
      008716 FC               [12] 1133 	mov	r4,a
      008717 E0               [24] 1134 	movx	a,@dptr
      008718 60 04            [24] 1135 	jz	00106$
      00871A 7B 00            [12] 1136 	mov	r3,#0x00
      00871C 80 02            [24] 1137 	sjmp	00107$
      00871E                       1138 00106$:
      00871E 7B 02            [12] 1139 	mov	r3,#0x02
      008720                       1140 00107$:
      008720 EB               [12] 1141 	mov	a,r3
      008721 12 90 5B         [24] 1142 	lcall	_ak820_outline_0132
      008724 8F 03            [24] 1143 	mov	ar3,r7
      008726 90 0A FE         [24] 1144 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008729 E0               [24] 1145 	movx	a,@dptr
      00872A F5 28            [12] 1146 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      00872C A3               [24] 1147 	inc	dptr
      00872D E0               [24] 1148 	movx	a,@dptr
      00872E F5 29            [12] 1149 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008730 90 06 9A         [24] 1150 	mov	dptr,#_eeprom_update_byte_PARM_2
      008733 F0               [24] 1151 	movx	@dptr,a
      008734 12 43 57         [24] 1152 	lcall	_ak820_outline_0178
      008737 8B F0            [24] 1153 	mov	b, r3
      008739 12 4D AB         [24] 1154 	lcall	_eeprom_update_byte
                                   1155 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      00873C EC               [12] 1156 	mov	a,r4
      00873D 60 04            [24] 1157 	jz	00108$
      00873F 7C 00            [12] 1158 	mov	r4,#0x00
      008741 80 02            [24] 1159 	sjmp	00109$
      008743                       1160 00108$:
      008743 7C 02            [12] 1161 	mov	r4,#0x02
      008745                       1162 00109$:
      008745 EC               [12] 1163 	mov	a,r4
      008746 12 38 75         [24] 1164 	lcall	_ak820_outline_0156
      008749 0D               [12] 1165 	inc	r5
      00874A BD 00 01         [24] 1166 	cjne	r5,#0x00,00137$
      00874D 0E               [12] 1167 	inc	r6
      00874E                       1168 00137$:
      00874E 90 06 9A         [24] 1169 	mov	dptr,#_eeprom_update_byte_PARM_2
      008751 E5 28            [12] 1170 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008753 F0               [24] 1171 	movx	@dptr,a
      008754 12 4E C2         [24] 1172 	lcall	_ak820_outline_0043
                                   1173 ;	quantum/dynamic_keymap.c:245: }
      008757 02 4D AB         [24] 1174 	ljmp	_eeprom_update_byte
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1179 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1180 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_385'
                                   1181 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_386'
                                   1182 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_388'
                                   1183 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_389'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function dynamic_keymap_get_combo
                                   1188 ;	-----------------------------------------
      00875A                       1189 _dynamic_keymap_get_combo:
      00875A E5 82            [12] 1190 	mov	a,dpl
      00875C 90 0B 04         [24] 1191 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      00875F F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008760 90 0B 01         [24] 1194 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008763 12 38 01         [24] 1195 	lcall	_ak820_outline_0050
                                   1196 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008766 90 0B 04         [24] 1197 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008769 E0               [24] 1198 	movx	a,@dptr
      00876A FD               [12] 1199 	mov	r5,a
      00876B BD 08 00         [24] 1200 	cjne	r5,#0x08,00132$
      00876E                       1201 00132$:
      00876E 40 04            [24] 1202 	jc	00102$
                                   1203 ;	quantum/dynamic_keymap.c:315: return -1;
      008770 90 FF FF         [24] 1204 	mov	dptr,#0xffff
      008773 22               [24] 1205 	ret
      008774                       1206 00102$:
                                   1207 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008774 12 90 28         [24] 1208 	lcall	_ak820_outline_0078
                                   1209 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008777 8E 02            [24] 1210 	mov	ar2,r6
      008779 8F 03            [24] 1211 	mov	ar3,r7
      00877B 90 05 81         [24] 1212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00877E 12 38 26         [24] 1213 	lcall	_ak820_outline_0070
      008781 E4               [12] 1214 	clr	a
      008782 A3               [24] 1215 	inc	dptr
      008783 F0               [24] 1216 	movx	@dptr,a
      008784 90 05 84         [24] 1217 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008787 74 0A            [12] 1218 	mov	a,#0x0a
      008789 12 38 60         [24] 1219 	lcall	_ak820_outline_0122
      00878C 12 43 3C         [24] 1220 	lcall	_ak820_outline_0141
      00878F C0 07            [24] 1221 	push	ar7
      008791 C0 06            [24] 1222 	push	ar6
      008793 12 40 73         [24] 1223 	lcall	_ak820_eeprom_read_block_xdata
      008796 D0 06            [24] 1224 	pop	ar6
      008798 D0 07            [24] 1225 	pop	ar7
                                   1226 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      00879A 74 04            [12] 1227 	mov	a,#0x04
      00879C 12 47 E7         [24] 1228 	lcall	_ak820_outline_0011
      00879F FA               [12] 1229 	mov	r2,a
      0087A0 A3               [24] 1230 	inc	dptr
      0087A1 E0               [24] 1231 	movx	a,@dptr
      0087A2 FB               [12] 1232 	mov	r3,a
      0087A3 BA 20 14         [24] 1233 	cjne	r2,#0x20,00108$
      0087A6 BB 08 11         [24] 1234 	cjne	r3,#0x08,00108$
      0087A9 74 06            [12] 1235 	mov	a,#0x06
      0087AB 12 37 E8         [24] 1236 	lcall	_ak820_outline_0016
      0087AE FA               [12] 1237 	mov	r2,a
      0087AF A3               [24] 1238 	inc	dptr
      0087B0 E0               [24] 1239 	movx	a,@dptr
      0087B1 FB               [12] 1240 	mov	r3,a
      0087B2 BA 01 05         [24] 1241 	cjne	r2,#0x01,00136$
      0087B5 BB 00 02         [24] 1242 	cjne	r3,#0x00,00136$
      0087B8 80 05            [24] 1243 	sjmp	00109$
      0087BA                       1244 00136$:
      0087BA                       1245 00108$:
      0087BA 75 2A 00         [24] 1246 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      0087BD 80 03            [24] 1247 	sjmp	00110$
      0087BF                       1248 00109$:
      0087BF 75 2A 01         [24] 1249 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      0087C2                       1250 00110$:
                                   1251 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      0087C2 74 06            [12] 1252 	mov	a,#0x06
      0087C4 12 37 F1         [24] 1253 	lcall	_ak820_outline_0030
      0087C7 12 4F 0B         [24] 1254 	lcall	_ak820_outline_0165
      0087CA 12 38 55         [24] 1255 	lcall	_ak820_outline_0117
      0087CD F0               [24] 1256 	movx	@dptr,a
      0087CE A3               [24] 1257 	inc	dptr
      0087CF F0               [24] 1258 	movx	@dptr,a
                                   1259 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      0087D0 E5 2A            [12] 1260 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      0087D2 60 12            [24] 1261 	jz	00103$
      0087D4 12 43 20         [24] 1262 	lcall	_ak820_outline_0116
      0087D7 C0 07            [24] 1263 	push	ar7
      0087D9 C0 06            [24] 1264 	push	ar6
      0087DB 12 34 68         [24] 1265 	lcall	_ak820_combo_valid
      0087DE E5 82            [12] 1266 	mov	a, dpl
      0087E0 D0 06            [24] 1267 	pop	ar6
      0087E2 D0 07            [24] 1268 	pop	ar7
      0087E4 70 17            [24] 1269 	jnz	00104$
      0087E6                       1270 00103$:
      0087E6 7D 00            [12] 1271 	mov	r5,#0x00
      0087E8 90 0D 96         [24] 1272 	mov	dptr,#_memset_PARM_2
      0087EB E4               [12] 1273 	clr	a
      0087EC F0               [24] 1274 	movx	@dptr,a
      0087ED 90 0D 97         [24] 1275 	mov	dptr,#_memset_PARM_3
      0087F0 74 0A            [12] 1276 	mov	a,#0x0a
      0087F2 F0               [24] 1277 	movx	@dptr,a
      0087F3 E4               [12] 1278 	clr	a
      0087F4 A3               [24] 1279 	inc	dptr
      0087F5 12 42 FB         [24] 1280 	lcall	_ak820_outline_0060
      0087F8 8D F0            [24] 1281 	mov	b, r5
      0087FA 12 B9 47         [24] 1282 	lcall	_memset
      0087FD                       1283 00104$:
                                   1284 ;	quantum/dynamic_keymap.c:329: return 0;
      0087FD 90 00 00         [24] 1285 	mov	dptr,#0x0000
                                   1286 ;	quantum/dynamic_keymap.c:330: }
      008800 22               [24] 1287 	ret
                                   1288 ;------------------------------------------------------------
                                   1289 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1290 ;------------------------------------------------------------
                                   1291 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1292 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_391'
                                   1293 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_392'
                                   1294 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_395'
                                   1295 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_396'
                                   1296 ;------------------------------------------------------------
                                   1297 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1298 ;	-----------------------------------------
                                   1299 ;	 function dynamic_keymap_set_combo
                                   1300 ;	-----------------------------------------
      008801                       1301 _dynamic_keymap_set_combo:
      008801 E5 82            [12] 1302 	mov	a,dpl
      008803 90 0B 08         [24] 1303 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008806 F0               [24] 1304 	movx	@dptr,a
                                   1305 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008807 90 0B 05         [24] 1306 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00880A 12 37 A1         [24] 1307 	lcall	_ak820_outline_0004
                                   1308 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      00880D C0 07            [24] 1309 	push	ar7
      00880F C0 06            [24] 1310 	push	ar6
      008811 12 34 68         [24] 1311 	lcall	_ak820_combo_valid
      008814 E5 82            [12] 1312 	mov	a, dpl
      008816 D0 06            [24] 1313 	pop	ar6
      008818 D0 07            [24] 1314 	pop	ar7
      00881A 60 07            [24] 1315 	jz	00101$
      00881C 12 3D DE         [24] 1316 	lcall	_ak820_nvm_ok
      00881F E5 82            [12] 1317 	mov	a, dpl
      008821 70 04            [24] 1318 	jnz	00102$
      008823                       1319 00101$:
      008823 90 FF FF         [24] 1320 	mov	dptr,#0xffff
      008826 22               [24] 1321 	ret
      008827                       1322 00102$:
                                   1323 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008827 90 0B 08         [24] 1324 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      00882A E0               [24] 1325 	movx	a,@dptr
      00882B FD               [12] 1326 	mov	r5,a
      00882C BD 08 00         [24] 1327 	cjne	r5,#0x08,00133$
      00882F                       1328 00133$:
      00882F 40 04            [24] 1329 	jc	00105$
                                   1330 ;	quantum/dynamic_keymap.c:342: return -1;
      008831 90 FF FF         [24] 1331 	mov	dptr,#0xffff
      008834 22               [24] 1332 	ret
      008835                       1333 00105$:
                                   1334 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008835 12 90 28         [24] 1335 	lcall	_ak820_outline_0078
                                   1336 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008838 C0 07            [24] 1337 	push	ar7
      00883A C0 06            [24] 1338 	push	ar6
      00883C C0 05            [24] 1339 	push	ar5
      00883E C0 04            [24] 1340 	push	ar4
      008840 12 78 A9         [24] 1341 	lcall	_clear_keyboard
      008843 D0 04            [24] 1342 	pop	ar4
      008845 D0 05            [24] 1343 	pop	ar5
      008847 D0 06            [24] 1344 	pop	ar6
      008849 D0 07            [24] 1345 	pop	ar7
                                   1346 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      00884B 90 0D 8E         [24] 1347 	mov	dptr,#___memcpy_PARM_2
      00884E 12 48 41         [24] 1348 	lcall	_ak820_outline_0058
      008851 E4               [12] 1349 	clr	a
      008852 A3               [24] 1350 	inc	dptr
      008853 F0               [24] 1351 	movx	@dptr,a
      008854 90 0D 91         [24] 1352 	mov	dptr,#___memcpy_PARM_3
      008857 74 0A            [12] 1353 	mov	a,#0x0a
      008859 12 38 60         [24] 1354 	lcall	_ak820_outline_0122
      00885C 90 0B 09         [24] 1355 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      00885F F5 F0            [12] 1356 	mov	b,a
      008861 C0 05            [24] 1357 	push	ar5
      008863 C0 04            [24] 1358 	push	ar4
      008865 12 B8 D1         [24] 1359 	lcall	___memcpy
      008868 D0 04            [24] 1360 	pop	ar4
      00886A D0 05            [24] 1361 	pop	ar5
                                   1362 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      00886C 90 0B 0D         [24] 1363 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0004)
      00886F 74 20            [12] 1364 	mov	a,#0x20
      008871 F0               [24] 1365 	movx	@dptr,a
      008872 74 08            [12] 1366 	mov	a,#0x08
      008874 A3               [24] 1367 	inc	dptr
      008875 F0               [24] 1368 	movx	@dptr,a
                                   1369 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008876 90 0B 0F         [24] 1370 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0006)
      008879 74 01            [12] 1371 	mov	a,#0x01
      00887B 12 38 60         [24] 1372 	lcall	_ak820_outline_0122
                                   1373 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      00887E 90 05 8A         [24] 1374 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008881 12 38 26         [24] 1375 	lcall	_ak820_outline_0070
      008884 E4               [12] 1376 	clr	a
      008885 A3               [24] 1377 	inc	dptr
      008886 F0               [24] 1378 	movx	@dptr,a
      008887 90 05 8D         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00888A 74 0A            [12] 1380 	mov	a,#0x0a
      00888C 12 38 60         [24] 1381 	lcall	_ak820_outline_0122
      00888F 90 0B 09         [24] 1382 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008892 12 40 FF         [24] 1383 	lcall	_ak820_eeprom_write_block_xdata
                                   1384 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008895 12 3D ED         [24] 1385 	lcall	_ak820_nvm_flush
                                   1386 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008898 12 3D DE         [24] 1387 	lcall	_ak820_nvm_ok
      00889B E5 82            [12] 1388 	mov	a, dpl
      00889D 70 04            [24] 1389 	jnz	00107$
      00889F 90 FF FF         [24] 1390 	mov	dptr,#0xffff
      0088A2 22               [24] 1391 	ret
      0088A3                       1392 00107$:
                                   1393 ;	quantum/dynamic_keymap.c:360: return 0;
      0088A3 90 00 00         [24] 1394 	mov	dptr,#0x0000
                                   1395 ;	quantum/dynamic_keymap.c:361: }
      0088A6 22               [24] 1396 	ret
                                   1397 ;------------------------------------------------------------
                                   1398 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1399 ;------------------------------------------------------------
                                   1400 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_399'
                                   1401 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_400'
                                   1402 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_402'
                                   1403 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_404'
                                   1404 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_406'
                                   1405 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_408'
                                   1406 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_409'
                                   1407 ;------------------------------------------------------------
                                   1408 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1409 ;	-----------------------------------------
                                   1410 ;	 function dynamic_keymap_reset
                                   1411 ;	-----------------------------------------
      0088A7                       1412 _dynamic_keymap_reset:
                                   1413 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      0088A7 90 0E 0E         [24] 1414 	mov	dptr,#_vial_unlocked
      0088AA E0               [24] 1415 	movx	a,@dptr
      0088AB 90 0B 13         [24] 1416 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      0088AE F0               [24] 1417 	movx	@dptr,a
                                   1418 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      0088AF 90 0E 0E         [24] 1419 	mov	dptr,#_vial_unlocked
      0088B2 74 01            [12] 1420 	mov	a,#0x01
      0088B4 F0               [24] 1421 	movx	@dptr,a
                                   1422 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0088B5 7F 00            [12] 1423 	mov	r7,#0x00
      0088B7                       1424 00116$:
      0088B7 BF 06 00         [24] 1425 	cjne	r7,#0x06,00198$
      0088BA                       1426 00198$:
      0088BA 40 03            [24] 1427 	jc	00199$
      0088BC 02 89 6A         [24] 1428 	ljmp	00104$
      0088BF                       1429 00199$:
                                   1430 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0088BF 7E 00            [12] 1431 	mov	r6,#0x00
      0088C1                       1432 00110$:
      0088C1 BE 10 00         [24] 1433 	cjne	r6,#0x10,00200$
      0088C4                       1434 00200$:
      0088C4 50 4D            [24] 1435 	jnc	00102$
                                   1436 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0088C6 7D 00            [12] 1437 	mov	r5,#0x00
      0088C8                       1438 00107$:
      0088C8 BD 08 00         [24] 1439 	cjne	r5,#0x08,00202$
      0088CB                       1440 00202$:
      0088CB 50 43            [24] 1441 	jnc	00111$
                                   1442 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      0088CD 90 0B AF         [24] 1443 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      0088D0 EE               [12] 1444 	mov	a,r6
      0088D1 F0               [24] 1445 	movx	@dptr,a
      0088D2 90 0B B0         [24] 1446 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      0088D5 ED               [12] 1447 	mov	a,r5
      0088D6 F0               [24] 1448 	movx	@dptr,a
      0088D7 8F 82            [24] 1449 	mov	dpl, r7
      0088D9 C0 07            [24] 1450 	push	ar7
      0088DB C0 06            [24] 1451 	push	ar6
      0088DD C0 05            [24] 1452 	push	ar5
      0088DF 12 98 70         [24] 1453 	lcall	_keycode_at_keymap_location_raw
      0088E2 AB 82            [24] 1454 	mov	r3, dpl
      0088E4 AC 83            [24] 1455 	mov	r4, dph
      0088E6 D0 05            [24] 1456 	pop	ar5
      0088E8 D0 06            [24] 1457 	pop	ar6
      0088EA D0 07            [24] 1458 	pop	ar7
      0088EC 90 0A F2         [24] 1459 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0088EF EE               [12] 1460 	mov	a,r6
      0088F0 F0               [24] 1461 	movx	@dptr,a
      0088F1 90 0A F3         [24] 1462 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0088F4 ED               [12] 1463 	mov	a,r5
      0088F5 F0               [24] 1464 	movx	@dptr,a
      0088F6 90 0A F4         [24] 1465 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0088F9 12 38 2C         [24] 1466 	lcall	_ak820_outline_0076
      0088FC 8F 82            [24] 1467 	mov	dpl, r7
      0088FE C0 07            [24] 1468 	push	ar7
      008900 C0 06            [24] 1469 	push	ar6
      008902 C0 05            [24] 1470 	push	ar5
      008904 12 86 14         [24] 1471 	lcall	_dynamic_keymap_set_keycode
      008907 D0 05            [24] 1472 	pop	ar5
      008909 D0 06            [24] 1473 	pop	ar6
      00890B D0 07            [24] 1474 	pop	ar7
                                   1475 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      00890D 0D               [12] 1476 	inc	r5
      00890E 80 B8            [24] 1477 	sjmp	00107$
      008910                       1478 00111$:
                                   1479 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008910 0E               [12] 1480 	inc	r6
      008911 80 AE            [24] 1481 	sjmp	00110$
      008913                       1482 00102$:
                                   1483 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008913 7E 00            [12] 1484 	mov	r6,#0x00
      008915                       1485 00113$:
      008915 BE 01 00         [24] 1486 	cjne	r6,#0x01,00204$
      008918                       1487 00204$:
      008918 50 4C            [24] 1488 	jnc	00117$
                                   1489 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      00891A 12 90 77         [24] 1490 	lcall	_ak820_outline_0174
      00891D 04               [12] 1491 	inc	a
      00891E F0               [24] 1492 	movx	@dptr,a
      00891F 8F 82            [24] 1493 	mov	dpl, r7
      008921 C0 07            [24] 1494 	push	ar7
      008923 12 98 B5         [24] 1495 	lcall	_keycode_at_encodermap_location_raw
      008926 12 43 41         [24] 1496 	lcall	_ak820_outline_0147
      008929 D0 07            [24] 1497 	pop	ar7
      00892B 12 90 6E         [24] 1498 	lcall	_ak820_outline_0173
      00892E 04               [12] 1499 	inc	a
      00892F F0               [24] 1500 	movx	@dptr,a
      008930 90 0A FE         [24] 1501 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008933 12 38 26         [24] 1502 	lcall	_ak820_outline_0070
      008936 8F 82            [24] 1503 	mov	dpl, r7
      008938 C0 07            [24] 1504 	push	ar7
      00893A 12 86 EE         [24] 1505 	lcall	_dynamic_keymap_set_encoder
      00893D D0 07            [24] 1506 	pop	ar7
                                   1507 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      00893F 12 90 77         [24] 1508 	lcall	_ak820_outline_0174
      008942 F0               [24] 1509 	movx	@dptr,a
      008943 8F 82            [24] 1510 	mov	dpl, r7
      008945 C0 07            [24] 1511 	push	ar7
      008947 12 98 B5         [24] 1512 	lcall	_keycode_at_encodermap_location_raw
      00894A 12 43 41         [24] 1513 	lcall	_ak820_outline_0147
      00894D D0 07            [24] 1514 	pop	ar7
      00894F 12 90 6E         [24] 1515 	lcall	_ak820_outline_0173
      008952 F0               [24] 1516 	movx	@dptr,a
      008953 90 0A FE         [24] 1517 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008956 12 38 26         [24] 1518 	lcall	_ak820_outline_0070
      008959 8F 82            [24] 1519 	mov	dpl, r7
      00895B C0 07            [24] 1520 	push	ar7
      00895D 12 86 EE         [24] 1521 	lcall	_dynamic_keymap_set_encoder
      008960 D0 07            [24] 1522 	pop	ar7
                                   1523 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008962 7E 01            [12] 1524 	mov	r6,#0x01
      008964 80 AF            [24] 1525 	sjmp	00113$
      008966                       1526 00117$:
                                   1527 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008966 0F               [12] 1528 	inc	r7
      008967 02 88 B7         [24] 1529 	ljmp	00116$
      00896A                       1530 00104$:
                                   1531 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      00896A 90 0B 14         [24] 1532 	mov	dptr,#_dynamic_keymap_reset_combo_10001_408
      00896D 12 4F 0B         [24] 1533 	lcall	_ak820_outline_0165
      008970 90 0B 16         [24] 1534 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0002)
      008973 F0               [24] 1535 	movx	@dptr,a
      008974 A3               [24] 1536 	inc	dptr
      008975 F0               [24] 1537 	movx	@dptr,a
      008976 90 0B 18         [24] 1538 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0004)
      008979 F0               [24] 1539 	movx	@dptr,a
      00897A A3               [24] 1540 	inc	dptr
      00897B F0               [24] 1541 	movx	@dptr,a
      00897C 90 0B 1A         [24] 1542 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0006)
      00897F F0               [24] 1543 	movx	@dptr,a
      008980 A3               [24] 1544 	inc	dptr
      008981 F0               [24] 1545 	movx	@dptr,a
      008982 90 0B 1C         [24] 1546 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0008)
      008985 F0               [24] 1547 	movx	@dptr,a
      008986 A3               [24] 1548 	inc	dptr
      008987 F0               [24] 1549 	movx	@dptr,a
                                   1550 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008988 FF               [12] 1551 	mov	r7,a
      008989                       1552 00119$:
      008989 BF 08 00         [24] 1553 	cjne	r7,#0x08,00206$
      00898C                       1554 00206$:
      00898C 50 17            [24] 1555 	jnc	00105$
                                   1556 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      00898E 90 0B 05         [24] 1557 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008991 74 14            [12] 1558 	mov	a,#_dynamic_keymap_reset_combo_10001_408
      008993 F0               [24] 1559 	movx	@dptr,a
      008994 74 0B            [12] 1560 	mov	a,#(_dynamic_keymap_reset_combo_10001_408 >> 8)
      008996 12 38 32         [24] 1561 	lcall	_ak820_outline_0096
      008999 8F 82            [24] 1562 	mov	dpl, r7
      00899B C0 07            [24] 1563 	push	ar7
      00899D 12 88 01         [24] 1564 	lcall	_dynamic_keymap_set_combo
      0089A0 D0 07            [24] 1565 	pop	ar7
                                   1566 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0089A2 0F               [12] 1567 	inc	r7
      0089A3 80 E4            [24] 1568 	sjmp	00119$
      0089A5                       1569 00105$:
                                   1570 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      0089A5 90 0B 13         [24] 1571 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      0089A8 E0               [24] 1572 	movx	a,@dptr
      0089A9 90 0E 0E         [24] 1573 	mov	dptr,#_vial_unlocked
      0089AC F0               [24] 1574 	movx	@dptr,a
                                   1575 ;	quantum/dynamic_keymap.c:468: }
      0089AD 22               [24] 1576 	ret
                                   1577 ;------------------------------------------------------------
                                   1578 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1579 ;------------------------------------------------------------
                                   1580 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1581 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1582 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1583 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1584 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1585 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_410'
                                   1586 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_411'
                                   1587 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_411'
                                   1588 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_414'
                                   1589 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_416'
                                   1590 ;------------------------------------------------------------
                                   1591 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1592 ;	-----------------------------------------
                                   1593 ;	 function ak820_dynamic_read_buffer
                                   1594 ;	-----------------------------------------
      0089AE                       1595 _ak820_dynamic_read_buffer:
      0089AE 12 38 44         [24] 1596 	lcall	_ak820_outline_0103
      0089B1 90 0B 27         [24] 1597 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      0089B4 12 38 49         [24] 1598 	lcall	_ak820_outline_0104
                                   1599 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0089B7 90 0B 24         [24] 1600 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0089BA 12 38 01         [24] 1601 	lcall	_ak820_outline_0050
                                   1602 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      0089BD 90 0B 29         [24] 1603 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      0089C0 E4               [12] 1604 	clr	a
      0089C1 F0               [24] 1605 	movx	@dptr,a
                                   1606 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      0089C2 90 0B 22         [24] 1607 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0089C5 12 38 20         [24] 1608 	lcall	_ak820_outline_0059
      0089C8 8C 02            [24] 1609 	mov	ar2,r4
      0089CA 8D 03            [24] 1610 	mov	ar3,r5
      0089CC C3               [12] 1611 	clr	c
      0089CD 74 1C            [12] 1612 	mov	a,#0x1c
      0089CF 9A               [12] 1613 	subb	a,r2
      0089D0 E4               [12] 1614 	clr	a
      0089D1 9B               [12] 1615 	subb	a,r3
      0089D2 50 01            [24] 1616 	jnc	00102$
                                   1617 ;	free result
      0089D4 22               [24] 1618 	ret
      0089D5                       1619 00102$:
                                   1620 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      0089D5 90 0B 20         [24] 1621 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0089D8 12 43 25         [24] 1622 	lcall	_ak820_outline_0119
      0089DB 90 0B 1E         [24] 1623 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0089DE 12 38 3E         [24] 1624 	lcall	_ak820_outline_0099
      0089E1 C3               [12] 1625 	clr	c
      0089E2 EA               [12] 1626 	mov	a,r2
      0089E3 98               [12] 1627 	subb	a,r0
      0089E4 EB               [12] 1628 	mov	a,r3
      0089E5 99               [12] 1629 	subb	a,r1
      0089E6 50 17            [24] 1630 	jnc	00104$
                                   1631 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      0089E8 E8               [12] 1632 	mov	a,r0
      0089E9 C3               [12] 1633 	clr	c
      0089EA 9A               [12] 1634 	subb	a,r2
      0089EB F8               [12] 1635 	mov	r0,a
      0089EC E9               [12] 1636 	mov	a,r1
      0089ED 9B               [12] 1637 	subb	a,r3
      0089EE F9               [12] 1638 	mov	r1,a
                                   1639 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      0089EF C3               [12] 1640 	clr	c
      0089F0 E8               [12] 1641 	mov	a,r0
      0089F1 9C               [12] 1642 	subb	a,r4
      0089F2 E9               [12] 1643 	mov	a,r1
      0089F3 9D               [12] 1644 	subb	a,r5
      0089F4 40 04            [24] 1645 	jc	00114$
      0089F6 8C 00            [24] 1646 	mov	ar0,r4
      0089F8 8D 01            [24] 1647 	mov	ar1,r5
      0089FA                       1648 00114$:
      0089FA 90 0B 29         [24] 1649 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      0089FD E8               [12] 1650 	mov	a,r0
      0089FE F0               [24] 1651 	movx	@dptr,a
      0089FF                       1652 00104$:
                                   1653 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0089FF 90 0B 29         [24] 1654 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008A02 E0               [24] 1655 	movx	a,@dptr
      008A03 F5 2B            [12] 1656 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008A05 E0               [24] 1657 	movx	a,@dptr
      008A06 60 42            [24] 1658 	jz	00106$
      008A08 C0 04            [24] 1659 	push	ar4
      008A0A C0 05            [24] 1660 	push	ar5
      008A0C 8E 00            [24] 1661 	mov	ar0,r6
      008A0E 8F 05            [24] 1662 	mov	ar5,r7
      008A10 90 0B 27         [24] 1663 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008A13 E0               [24] 1664 	movx	a,@dptr
      008A14 F9               [12] 1665 	mov	r1,a
      008A15 A3               [24] 1666 	inc	dptr
      008A16 E0               [24] 1667 	movx	a,@dptr
      008A17 FC               [12] 1668 	mov	r4,a
      008A18 EA               [12] 1669 	mov	a,r2
      008A19 29               [12] 1670 	add	a, r1
      008A1A FA               [12] 1671 	mov	r2,a
      008A1B EB               [12] 1672 	mov	a,r3
      008A1C 3C               [12] 1673 	addc	a, r4
      008A1D FB               [12] 1674 	mov	r3,a
      008A1E 90 05 81         [24] 1675 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008A21 EA               [12] 1676 	mov	a,r2
      008A22 F0               [24] 1677 	movx	@dptr,a
      008A23 EB               [12] 1678 	mov	a,r3
      008A24 12 38 32         [24] 1679 	lcall	_ak820_outline_0096
      008A27 90 05 84         [24] 1680 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008A2A E5 2B            [12] 1681 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008A2C 12 38 60         [24] 1682 	lcall	_ak820_outline_0122
      008A2F 88 82            [24] 1683 	mov	dpl, r0
      008A31 8D 83            [24] 1684 	mov	dph, r5
      008A33 C0 07            [24] 1685 	push	ar7
      008A35 C0 06            [24] 1686 	push	ar6
      008A37 C0 05            [24] 1687 	push	ar5
      008A39 C0 04            [24] 1688 	push	ar4
      008A3B 12 40 73         [24] 1689 	lcall	_ak820_eeprom_read_block_xdata
      008A3E D0 04            [24] 1690 	pop	ar4
      008A40 D0 05            [24] 1691 	pop	ar5
      008A42 D0 06            [24] 1692 	pop	ar6
      008A44 D0 07            [24] 1693 	pop	ar7
                                   1694 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008A46 D0 05            [24] 1695 	pop	ar5
      008A48 D0 04            [24] 1696 	pop	ar4
                                   1697 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008A4A                       1698 00106$:
                                   1699 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008A4A 90 0B 29         [24] 1700 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008A4D E0               [24] 1701 	movx	a,@dptr
      008A4E FB               [12] 1702 	mov	r3,a
      008A4F                       1703 00109$:
      008A4F 8B 01            [24] 1704 	mov	ar1,r3
      008A51 7A 00            [12] 1705 	mov	r2,#0x00
      008A53 C3               [12] 1706 	clr	c
      008A54 E9               [12] 1707 	mov	a,r1
      008A55 9C               [12] 1708 	subb	a,r4
      008A56 EA               [12] 1709 	mov	a,r2
      008A57 9D               [12] 1710 	subb	a,r5
      008A58 50 09            [24] 1711 	jnc	00111$
      008A5A EB               [12] 1712 	mov	a,r3
      008A5B 12 37 F1         [24] 1713 	lcall	_ak820_outline_0030
      008A5E E4               [12] 1714 	clr	a
      008A5F F0               [24] 1715 	movx	@dptr,a
      008A60 0B               [12] 1716 	inc	r3
      008A61 80 EC            [24] 1717 	sjmp	00109$
      008A63                       1718 00111$:
                                   1719 ;	quantum/dynamic_keymap.c:483: }
      008A63 22               [24] 1720 	ret
                                   1721 ;------------------------------------------------------------
                                   1722 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1723 ;------------------------------------------------------------
                                   1724 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1725 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1726 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_417'
                                   1727 ;------------------------------------------------------------
                                   1728 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1729 ;	-----------------------------------------
                                   1730 ;	 function dynamic_keymap_get_buffer
                                   1731 ;	-----------------------------------------
      008A64                       1732 _dynamic_keymap_get_buffer:
      008A64 12 38 44         [24] 1733 	lcall	_ak820_outline_0103
      008A67 90 0B 2F         [24] 1734 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008A6A 12 38 49         [24] 1735 	lcall	_ak820_outline_0104
                                   1736 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008A6D 90 0B 2F         [24] 1737 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008A70 12 38 01         [24] 1738 	lcall	_ak820_outline_0050
      008A73 90 0B 2A         [24] 1739 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008A76 12 38 20         [24] 1740 	lcall	_ak820_outline_0059
      008A79 90 0B 2C         [24] 1741 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008A7C 12 4E EB         [24] 1742 	lcall	_ak820_outline_0087
      008A7F 90 0B 1E         [24] 1743 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008A82 E4               [12] 1744 	clr	a
      008A83 F0               [24] 1745 	movx	@dptr,a
      008A84 74 06            [12] 1746 	mov	a,#0x06
      008A86 A3               [24] 1747 	inc	dptr
      008A87 F0               [24] 1748 	movx	@dptr,a
      008A88 90 0B 20         [24] 1749 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008A8B 12 48 41         [24] 1750 	lcall	_ak820_outline_0058
      008A8E 90 0B 22         [24] 1751 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008A91 12 38 26         [24] 1752 	lcall	_ak820_outline_0070
      008A94 90 0B 24         [24] 1753 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008A97 E9               [12] 1754 	mov	a,r1
      008A98 12 4F 04         [24] 1755 	lcall	_ak820_outline_0153
      008A9B F0               [24] 1756 	movx	@dptr,a
      008A9C 90 00 40         [24] 1757 	mov	dptr,#0x0040
                                   1758 ;	quantum/dynamic_keymap.c:511: }
      008A9F 02 89 AE         [24] 1759 	ljmp	_ak820_dynamic_read_buffer
                                   1760 ;------------------------------------------------------------
                                   1761 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1762 ;------------------------------------------------------------
                                   1763 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1764 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1765 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1766 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1767 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1768 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_419'
                                   1769 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_420'
                                   1770 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_420'
                                   1771 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_420'
                                   1772 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_423'
                                   1773 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_426'
                                   1774 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_426'
                                   1775 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_428'
                                   1776 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_431'
                                   1777 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_433'
                                   1778 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_434'
                                   1779 ;------------------------------------------------------------
                                   1780 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1781 ;	-----------------------------------------
                                   1782 ;	 function dynamic_keymap_set_buffer
                                   1783 ;	-----------------------------------------
      008AA2                       1784 _dynamic_keymap_set_buffer:
      008AA2 12 38 44         [24] 1785 	lcall	_ak820_outline_0103
      008AA5 90 0B 36         [24] 1786 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008AA8 12 38 49         [24] 1787 	lcall	_ak820_outline_0104
                                   1788 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008AAB 90 0B 36         [24] 1789 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008AAE 12 37 CC         [24] 1790 	lcall	_ak820_outline_0009
      008AB1 74 40            [12] 1791 	mov	a,#0x40
      008AB3 2C               [12] 1792 	add	a, r4
      008AB4 FA               [12] 1793 	mov	r2,a
      008AB5 E4               [12] 1794 	clr	a
      008AB6 3D               [12] 1795 	addc	a, r5
      008AB7 FB               [12] 1796 	mov	r3,a
                                   1797 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008AB8 90 0B 33         [24] 1798 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008ABB 12 38 3E         [24] 1799 	lcall	_ak820_outline_0099
                                   1800 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008ABE 90 0B 31         [24] 1801 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008AC1 E0               [24] 1802 	movx	a,@dptr
      008AC2 F5 2C            [12] 1803 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008AC4 A3               [24] 1804 	inc	dptr
      008AC5 E0               [24] 1805 	movx	a,@dptr
      008AC6 F5 2D            [12] 1806 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008AC8 E5 2C            [12] 1807 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008ACA 45 2D            [12] 1808 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008ACC 70 01            [24] 1809 	jnz	00102$
      008ACE 22               [24] 1810 	ret
      008ACF                       1811 00102$:
                                   1812 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008ACF 85 2C 2E         [24] 1813 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008AD2 85 2D 2F         [24] 1814 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008AD5 C3               [12] 1815 	clr	c
      008AD6 74 1C            [12] 1816 	mov	a,#0x1c
      008AD8 95 2E            [12] 1817 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008ADA E4               [12] 1818 	clr	a
      008ADB 95 2F            [12] 1819 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008ADD 50 01            [24] 1820 	jnc	00104$
                                   1821 ;	free result
      008ADF 22               [24] 1822 	ret
      008AE0                       1823 00104$:
                                   1824 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008AE0 85 2C 30         [24] 1825 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1826 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008AE3 74 FA            [12] 1827 	mov	a,#0x100 - 0x06
      008AE5 2F               [12] 1828 	add	a,r7
      008AE6 40 11            [24] 1829 	jc	00105$
      008AE8 E4               [12] 1830 	clr	a
      008AE9 C3               [12] 1831 	clr	c
      008AEA 9E               [12] 1832 	subb	a,r6
      008AEB FE               [12] 1833 	mov	r6,a
      008AEC 74 06            [12] 1834 	mov	a,#0x06
      008AEE 9F               [12] 1835 	subb	a,r7
      008AEF FF               [12] 1836 	mov	r7,a
      008AF0 C3               [12] 1837 	clr	c
      008AF1 EE               [12] 1838 	mov	a,r6
      008AF2 95 2C            [12] 1839 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008AF4 EF               [12] 1840 	mov	a,r7
      008AF5 95 2D            [12] 1841 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008AF7 50 01            [24] 1842 	jnc	00106$
      008AF9                       1843 00105$:
                                   1844 ;	quantum/dynamic_keymap.c:529: return;
      008AF9 22               [24] 1845 	ret
      008AFA                       1846 00106$:
                                   1847 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008AFA 90 0E 0E         [24] 1848 	mov	dptr,#_vial_unlocked
      008AFD E0               [24] 1849 	movx	a,@dptr
      008AFE 60 03            [24] 1850 	jz	00207$
      008B00 02 8C 0F         [24] 1851 	ljmp	00120$
      008B03                       1852 00207$:
                                   1853 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008B03 90 0B 38         [24] 1854 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008B06 E4               [12] 1855 	clr	a
      008B07 F0               [24] 1856 	movx	@dptr,a
                                   1857 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008B08 90 0B 39         [24] 1858 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008B0B E5 30            [12] 1859 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008B0D F0               [24] 1860 	movx	@dptr,a
                                   1861 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008B0E EC               [12] 1862 	mov	a,r4
      008B0F 30 E0 33         [24] 1863 	jnb	acc.0,00111$
                                   1864 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008B12 EA               [12] 1865 	mov	a,r2
      008B13 24 FF            [12] 1866 	add	a,#0xff
      008B15 FE               [12] 1867 	mov	r6,a
      008B16 EB               [12] 1868 	mov	a,r3
      008B17 34 FF            [12] 1869 	addc	a,#0xff
      008B19 FF               [12] 1870 	mov	r7,a
      008B1A 7D 00            [12] 1871 	mov	r5,#0x00
      008B1C 12 43 20         [24] 1872 	lcall	_ak820_outline_0116
      008B1F 8D F0            [24] 1873 	mov	b, r5
      008B21 12 40 38         [24] 1874 	lcall	_eeprom_read_byte
      008B24 AE 82            [24] 1875 	mov	r6,dpl
      008B26 7F 00            [12] 1876 	mov	r7,#0x00
      008B28 12 38 70         [24] 1877 	lcall	_ak820_outline_0154
      008B2B E0               [24] 1878 	movx	a,@dptr
      008B2C 7C 00            [12] 1879 	mov	r4,#0x00
      008B2E 42 07            [12] 1880 	orl	ar7,a
      008B30 EC               [12] 1881 	mov	a,r4
      008B31 42 06            [12] 1882 	orl	ar6,a
                                   1883 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008B33 BF 00 09         [24] 1884 	cjne	r7,#0x00,00109$
      008B36 BE 7C 06         [24] 1885 	cjne	r6,#0x7c,00109$
                                   1886 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008B39 12 38 70         [24] 1887 	lcall	_ak820_outline_0154
      008B3C 74 FF            [12] 1888 	mov	a,#0xff
      008B3E F0               [24] 1889 	movx	@dptr,a
      008B3F                       1890 00109$:
                                   1891 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008B3F 90 0B 38         [24] 1892 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008B42 74 01            [12] 1893 	mov	a,#0x01
      008B44 F0               [24] 1894 	movx	@dptr,a
      008B45                       1895 00111$:
                                   1896 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008B45 90 0B 36         [24] 1897 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008B48 12 38 01         [24] 1898 	lcall	_ak820_outline_0050
      008B4B E5 2C            [12] 1899 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008B4D 2E               [12] 1900 	add	a, r6
      008B4E FE               [12] 1901 	mov	r6,a
      008B4F E5 2D            [12] 1902 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008B51 3F               [12] 1903 	addc	a, r7
      008B52 EE               [12] 1904 	mov	a,r6
      008B53 30 E0 5A         [24] 1905 	jnb	acc.0,00115$
                                   1906 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008B56 AE 30            [24] 1907 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008B58 7F 00            [12] 1908 	mov	r7,#0x00
      008B5A EE               [12] 1909 	mov	a,r6
      008B5B 24 FF            [12] 1910 	add	a,#0xff
      008B5D FC               [12] 1911 	mov	r4,a
      008B5E EF               [12] 1912 	mov	a,r7
      008B5F 34 FF            [12] 1913 	addc	a,#0xff
      008B61 FD               [12] 1914 	mov	r5,a
      008B62 EC               [12] 1915 	mov	a,r4
      008B63 28               [12] 1916 	add	a, r0
      008B64 F5 82            [12] 1917 	mov	dpl,a
      008B66 ED               [12] 1918 	mov	a,r5
      008B67 39               [12] 1919 	addc	a, r1
      008B68 F5 83            [12] 1920 	mov	dph,a
      008B6A E0               [24] 1921 	movx	a,@dptr
      008B6B FC               [12] 1922 	mov	r4,a
      008B6C 7D 00            [12] 1923 	mov	r5,#0x00
      008B6E E5 30            [12] 1924 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008B70 2A               [12] 1925 	add	a, r2
      008B71 FA               [12] 1926 	mov	r2,a
      008B72 E4               [12] 1927 	clr	a
      008B73 3B               [12] 1928 	addc	a, r3
      008B74 FB               [12] 1929 	mov	r3,a
      008B75 C0 00            [24] 1930 	push	ar0
      008B77 C0 01            [24] 1931 	push	ar1
      008B79 8B 01            [24] 1932 	mov	ar1,r3
      008B7B 7B 00            [12] 1933 	mov	r3,#0x00
      008B7D 8A 82            [24] 1934 	mov	dpl, r2
      008B7F 89 83            [24] 1935 	mov	dph, r1
      008B81 8B F0            [24] 1936 	mov	b, r3
      008B83 12 40 38         [24] 1937 	lcall	_eeprom_read_byte
      008B86 AB 82            [24] 1938 	mov	r3, dpl
      008B88 7A 00            [12] 1939 	mov	r2,#0x00
      008B8A EB               [12] 1940 	mov	a,r3
      008B8B 12 43 36         [24] 1941 	lcall	_ak820_outline_0140
                                   1942 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008B8E BD 00 05         [24] 1943 	cjne	r5,#0x00,00212$
      008B91 BC 7C 02         [24] 1944 	cjne	r4,#0x7c,00212$
      008B94 80 06            [24] 1945 	sjmp	00213$
      008B96                       1946 00212$:
      008B96 D0 01            [24] 1947 	pop	ar1
      008B98 D0 00            [24] 1948 	pop	ar0
      008B9A 80 0D            [24] 1949 	sjmp	00113$
      008B9C                       1950 00213$:
      008B9C D0 01            [24] 1951 	pop	ar1
      008B9E D0 00            [24] 1952 	pop	ar0
                                   1953 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008BA0 1E               [12] 1954 	dec	r6
      008BA1 BE FF 01         [24] 1955 	cjne	r6,#0xff,00214$
      008BA4 1F               [12] 1956 	dec	r7
      008BA5                       1957 00214$:
      008BA5 EE               [12] 1958 	mov	a,r6
      008BA6 12 90 50         [24] 1959 	lcall	_ak820_outline_0126
      008BA9                       1960 00113$:
                                   1961 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008BA9 E5 30            [12] 1962 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008BAB 14               [12] 1963 	dec	a
      008BAC 90 0B 39         [24] 1964 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008BAF F0               [24] 1965 	movx	@dptr,a
      008BB0                       1966 00115$:
                                   1967 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008BB0 90 0B 38         [24] 1968 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008BB3 E0               [24] 1969 	movx	a,@dptr
      008BB4 90 0B 3A         [24] 1970 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008BB7 F0               [24] 1971 	movx	@dptr,a
      008BB8                       1972 00122$:
      008BB8 90 0B 3A         [24] 1973 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008BBB E0               [24] 1974 	movx	a,@dptr
      008BBC FF               [12] 1975 	mov	r7,a
      008BBD 90 0B 39         [24] 1976 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008BC0 E0               [24] 1977 	movx	a,@dptr
      008BC1 FE               [12] 1978 	mov	r6,a
      008BC2 C3               [12] 1979 	clr	c
      008BC3 EF               [12] 1980 	mov	a,r7
      008BC4 9E               [12] 1981 	subb	a,r6
      008BC5 50 48            [24] 1982 	jnc	00120$
                                   1983 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008BC7 EF               [12] 1984 	mov	a,r7
      008BC8 28               [12] 1985 	add	a, r0
      008BC9 FD               [12] 1986 	mov	r5,a
      008BCA E4               [12] 1987 	clr	a
      008BCB 39               [12] 1988 	addc	a, r1
      008BCC FE               [12] 1989 	mov	r6,a
      008BCD 12 48 47         [24] 1990 	lcall	_ak820_outline_0074
      008BD0 7B 00            [12] 1991 	mov	r3,#0x00
      008BD2 8C 2D            [24] 1992 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008BD4 8B 2C            [24] 1993 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008BD6 8F 02            [24] 1994 	mov	ar2,r7
      008BD8 7F 00            [12] 1995 	mov	r7,#0x00
      008BDA 74 01            [12] 1996 	mov	a,#0x01
      008BDC 2A               [12] 1997 	add	a, r2
      008BDD FB               [12] 1998 	mov	r3,a
      008BDE E4               [12] 1999 	clr	a
      008BDF 3F               [12] 2000 	addc	a, r7
      008BE0 FC               [12] 2001 	mov	r4,a
      008BE1 EB               [12] 2002 	mov	a,r3
      008BE2 28               [12] 2003 	add	a, r0
      008BE3 F5 82            [12] 2004 	mov	dpl,a
      008BE5 EC               [12] 2005 	mov	a,r4
      008BE6 39               [12] 2006 	addc	a, r1
      008BE7 F5 83            [12] 2007 	mov	dph,a
      008BE9 E0               [24] 2008 	movx	a,@dptr
      008BEA FC               [12] 2009 	mov	r4,a
      008BEB 7B 00            [12] 2010 	mov	r3,#0x00
      008BED E5 2D            [12] 2011 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008BEF 42 03            [12] 2012 	orl	ar3,a
                                   2013 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008BF1 BC 00 12         [24] 2014 	cjne	r4,#0x00,00123$
      008BF4 BB 7C 0F         [24] 2015 	cjne	r3,#0x7c,00123$
                                   2016 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008BF7 12 38 65         [24] 2017 	lcall	_ak820_outline_0131
      008BFA 74 FF            [12] 2018 	mov	a,#0xff
      008BFC F0               [24] 2019 	movx	@dptr,a
                                   2020 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008BFD 0A               [12] 2021 	inc	r2
      008BFE BA 00 01         [24] 2022 	cjne	r2,#0x00,00218$
      008C01 0F               [12] 2023 	inc	r7
      008C02                       2024 00218$:
      008C02 EA               [12] 2025 	mov	a,r2
      008C03 12 90 50         [24] 2026 	lcall	_ak820_outline_0126
      008C06                       2027 00123$:
                                   2028 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008C06 90 0B 3A         [24] 2029 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008C09 E0               [24] 2030 	movx	a,@dptr
      008C0A 24 02            [12] 2031 	add	a,#0x02
      008C0C F0               [24] 2032 	movx	@dptr,a
      008C0D 80 A9            [24] 2033 	sjmp	00122$
      008C0F                       2034 00120$:
                                   2035 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008C0F 90 0B 36         [24] 2036 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008C12 12 38 01         [24] 2037 	lcall	_ak820_outline_0050
      008C15 74 40            [12] 2038 	mov	a,#0x40
      008C17 12 43 30         [24] 2039 	lcall	_ak820_outline_0133
      008C1A 90 05 8A         [24] 2040 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008C1D 12 48 41         [24] 2041 	lcall	_ak820_outline_0058
      008C20 E4               [12] 2042 	clr	a
      008C21 A3               [24] 2043 	inc	dptr
      008C22 F0               [24] 2044 	movx	@dptr,a
      008C23 90 05 8D         [24] 2045 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008C26 E5 2E            [12] 2046 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008C28 F0               [24] 2047 	movx	@dptr,a
      008C29 E5 2F            [12] 2048 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008C2B A3               [24] 2049 	inc	dptr
      008C2C F0               [24] 2050 	movx	@dptr,a
      008C2D 12 38 70         [24] 2051 	lcall	_ak820_outline_0154
                                   2052 ;	quantum/dynamic_keymap.c:584: }
      008C30 02 40 FF         [24] 2053 	ljmp	_ak820_eeprom_write_block_xdata
                                   2054 ;------------------------------------------------------------
                                   2055 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2056 ;------------------------------------------------------------
                                   2057 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2058 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2059 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_437'
                                   2060 ;------------------------------------------------------------
                                   2061 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2062 ;	-----------------------------------------
                                   2063 ;	 function keycode_at_keymap_location
                                   2064 ;	-----------------------------------------
      008C33                       2065 _keycode_at_keymap_location:
      008C33 E5 82            [12] 2066 	mov	a,dpl
      008C35 90 0B 3D         [24] 2067 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_437
      008C38 F0               [24] 2068 	movx	@dptr,a
                                   2069 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008C39 E0               [24] 2070 	movx	a,@dptr
      008C3A FF               [12] 2071 	mov	r7,a
      008C3B BF 06 00         [24] 2072 	cjne	r7,#0x06,00128$
      008C3E                       2073 00128$:
      008C3E 50 23            [24] 2074 	jnc	00102$
      008C40 90 0B 3B         [24] 2075 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008C43 E0               [24] 2076 	movx	a,@dptr
      008C44 FE               [12] 2077 	mov	r6,a
      008C45 BE 10 00         [24] 2078 	cjne	r6,#0x10,00130$
      008C48                       2079 00130$:
      008C48 50 19            [24] 2080 	jnc	00102$
      008C4A 90 0B 3C         [24] 2081 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008C4D E0               [24] 2082 	movx	a,@dptr
      008C4E FD               [12] 2083 	mov	r5,a
      008C4F BD 08 00         [24] 2084 	cjne	r5,#0x08,00132$
      008C52                       2085 00132$:
      008C52 50 0F            [24] 2086 	jnc	00102$
                                   2087 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008C54 90 0A EF         [24] 2088 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008C57 EE               [12] 2089 	mov	a,r6
      008C58 F0               [24] 2090 	movx	@dptr,a
      008C59 90 0A F0         [24] 2091 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008C5C ED               [12] 2092 	mov	a,r5
      008C5D F0               [24] 2093 	movx	@dptr,a
      008C5E 8F 82            [24] 2094 	mov	dpl, r7
      008C60 02 85 C6         [24] 2095 	ljmp	_dynamic_keymap_get_keycode
      008C63                       2096 00102$:
                                   2097 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008C63 90 00 00         [24] 2098 	mov	dptr,#0x0000
                                   2099 ;	quantum/dynamic_keymap.c:591: }
      008C66 22               [24] 2100 	ret
                                   2101 ;------------------------------------------------------------
                                   2102 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2103 ;------------------------------------------------------------
                                   2104 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2105 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2106 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_441'
                                   2107 ;------------------------------------------------------------
                                   2108 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2109 ;	-----------------------------------------
                                   2110 ;	 function keycode_at_encodermap_location
                                   2111 ;	-----------------------------------------
      008C67                       2112 _keycode_at_encodermap_location:
      008C67 E5 82            [12] 2113 	mov	a,dpl
      008C69 90 0B 40         [24] 2114 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_441
      008C6C F0               [24] 2115 	movx	@dptr,a
                                   2116 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008C6D E0               [24] 2117 	movx	a,@dptr
      008C6E FF               [12] 2118 	mov	r7,a
      008C6F BF 06 00         [24] 2119 	cjne	r7,#0x06,00120$
      008C72                       2120 00120$:
      008C72 50 1E            [24] 2121 	jnc	00102$
      008C74 90 0B 3E         [24] 2122 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008C77 E0               [24] 2123 	movx	a,@dptr
      008C78 FE               [12] 2124 	mov	r6,a
      008C79 BE 01 00         [24] 2125 	cjne	r6,#0x01,00122$
      008C7C                       2126 00122$:
      008C7C 50 14            [24] 2127 	jnc	00102$
                                   2128 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008C7E 90 0B 3F         [24] 2129 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008C81 E0               [24] 2130 	movx	a,@dptr
      008C82 FE               [12] 2131 	mov	r6,a
      008C83 90 0A F9         [24] 2132 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008C86 E4               [12] 2133 	clr	a
      008C87 F0               [24] 2134 	movx	@dptr,a
      008C88 90 0A FA         [24] 2135 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008C8B EE               [12] 2136 	mov	a,r6
      008C8C F0               [24] 2137 	movx	@dptr,a
      008C8D 8F 82            [24] 2138 	mov	dpl, r7
      008C8F 02 86 87         [24] 2139 	ljmp	_dynamic_keymap_get_encoder
      008C92                       2140 00102$:
                                   2141 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008C92 90 00 00         [24] 2142 	mov	dptr,#0x0000
                                   2143 ;	quantum/dynamic_keymap.c:599: }
      008C95 22               [24] 2144 	ret
                                   2145 ;------------------------------------------------------------
                                   2146 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2147 ;------------------------------------------------------------
                                   2148 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2149 ;	-----------------------------------------
                                   2150 ;	 function dynamic_keymap_macro_get_count
                                   2151 ;	-----------------------------------------
      008C96                       2152 _dynamic_keymap_macro_get_count:
                                   2153 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008C96 75 82 10         [24] 2154 	mov	dpl, #0x10
                                   2155 ;	quantum/dynamic_keymap.c:604: }
      008C99 22               [24] 2156 	ret
                                   2157 ;------------------------------------------------------------
                                   2158 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2159 ;------------------------------------------------------------
                                   2160 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2161 ;	-----------------------------------------
                                   2162 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2163 ;	-----------------------------------------
      008C9A                       2164 _dynamic_keymap_macro_get_buffer_size:
                                   2165 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008C9A 90 20 00         [24] 2166 	mov	dptr,#0x2000
                                   2167 ;	quantum/dynamic_keymap.c:608: }
      008C9D 22               [24] 2168 	ret
                                   2169 ;------------------------------------------------------------
                                   2170 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2171 ;------------------------------------------------------------
                                   2172 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2173 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2174 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2175 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_449'
                                   2176 ;------------------------------------------------------------
                                   2177 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2178 ;	-----------------------------------------
                                   2179 ;	 function dynamic_keymap_macro_get_buffer
                                   2180 ;	-----------------------------------------
      008C9E                       2181 _dynamic_keymap_macro_get_buffer:
      008C9E 12 38 44         [24] 2182 	lcall	_ak820_outline_0103
      008CA1 90 0B 46         [24] 2183 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008CA4 12 38 49         [24] 2184 	lcall	_ak820_outline_0104
                                   2185 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008CA7 12 2B 2B         [24] 2186 	lcall	_ak820_macro_length
      008CAA 12 43 2B         [24] 2187 	lcall	_ak820_outline_0130
      008CAD 90 0B 46         [24] 2188 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008CB0 12 38 20         [24] 2189 	lcall	_ak820_outline_0059
      008CB3 90 0B 41         [24] 2190 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008CB6 E0               [24] 2191 	movx	a,@dptr
      008CB7 F5 31            [12] 2192 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008CB9 A3               [24] 2193 	inc	dptr
      008CBA E0               [24] 2194 	movx	a,@dptr
      008CBB F5 32            [12] 2195 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008CBD 90 0B 43         [24] 2196 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008CC0 12 38 3E         [24] 2197 	lcall	_ak820_outline_0099
      008CC3 A3               [24] 2198 	inc	dptr
      008CC4 E0               [24] 2199 	movx	a,@dptr
      008CC5 FB               [12] 2200 	mov	r3,a
      008CC6 90 0B 1E         [24] 2201 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008CC9 12 48 41         [24] 2202 	lcall	_ak820_outline_0058
      008CCC 90 0B 20         [24] 2203 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008CCF 12 38 26         [24] 2204 	lcall	_ak820_outline_0070
      008CD2 90 0B 22         [24] 2205 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008CD5 E5 31            [12] 2206 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008CD7 F0               [24] 2207 	movx	@dptr,a
      008CD8 E5 32            [12] 2208 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008CDA A3               [24] 2209 	inc	dptr
      008CDB F0               [24] 2210 	movx	@dptr,a
      008CDC 90 0B 24         [24] 2211 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008CDF E8               [12] 2212 	mov	a,r0
      008CE0 F0               [24] 2213 	movx	@dptr,a
      008CE1 E9               [12] 2214 	mov	a,r1
      008CE2 A3               [24] 2215 	inc	dptr
      008CE3 F0               [24] 2216 	movx	@dptr,a
      008CE4 EB               [12] 2217 	mov	a,r3
      008CE5 A3               [24] 2218 	inc	dptr
      008CE6 F0               [24] 2219 	movx	@dptr,a
      008CE7 90 08 00         [24] 2220 	mov	dptr,#0x0800
                                   2221 ;	quantum/dynamic_keymap.c:635: }
      008CEA 02 89 AE         [24] 2222 	ljmp	_ak820_dynamic_read_buffer
                                   2223 ;------------------------------------------------------------
                                   2224 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2225 ;------------------------------------------------------------
                                   2226 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2227 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2228 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_451'
                                   2229 ;------------------------------------------------------------
                                   2230 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2231 ;	-----------------------------------------
                                   2232 ;	 function dynamic_keymap_macro_set_buffer
                                   2233 ;	-----------------------------------------
      008CED                       2234 _dynamic_keymap_macro_set_buffer:
      008CED 12 38 44         [24] 2235 	lcall	_ak820_outline_0103
      008CF0 90 0B 4D         [24] 2236 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008CF3 12 38 49         [24] 2237 	lcall	_ak820_outline_0104
                                   2238 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      008CF6 90 0B 4D         [24] 2239 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008CF9 12 38 01         [24] 2240 	lcall	_ak820_outline_0050
      008CFC 90 0B 48         [24] 2241 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008CFF 12 38 20         [24] 2242 	lcall	_ak820_outline_0059
      008D02 90 0B 4A         [24] 2243 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008D05 12 4E EB         [24] 2244 	lcall	_ak820_outline_0087
      008D08 90 05 10         [24] 2245 	mov	dptr,#_ak820_macro_write_PARM_2
      008D0B 12 38 26         [24] 2246 	lcall	_ak820_outline_0070
      008D0E 90 05 12         [24] 2247 	mov	dptr,#_ak820_macro_write_PARM_3
      008D11 E9               [12] 2248 	mov	a,r1
      008D12 12 4F 04         [24] 2249 	lcall	_ak820_outline_0153
      008D15 12 42 FB         [24] 2250 	lcall	_ak820_outline_0060
                                   2251 ;	quantum/dynamic_keymap.c:640: }
      008D18 02 2B 45         [24] 2252 	ljmp	_ak820_macro_write
                                   2253 ;------------------------------------------------------------
                                   2254 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2255 ;------------------------------------------------------------
                                   2256 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2257 ;	-----------------------------------------
                                   2258 ;	 function dynamic_keymap_macro_reset
                                   2259 ;	-----------------------------------------
      008D1B                       2260 _dynamic_keymap_macro_reset:
                                   2261 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2262 ;	quantum/dynamic_keymap.c:666: }
      008D1B 02 2E 64         [24] 2263 	ljmp	_ak820_macro_reset
                                   2264 ;------------------------------------------------------------
                                   2265 ;Allocation info for local variables in function 'decode_keycode'
                                   2266 ;------------------------------------------------------------
                                   2267 ;kc            Allocated with name '_decode_keycode_kc_10000_455'
                                   2268 ;------------------------------------------------------------
                                   2269 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2270 ;	-----------------------------------------
                                   2271 ;	 function decode_keycode
                                   2272 ;	-----------------------------------------
      008D1E                       2273 _decode_keycode:
      008D1E 12 38 44         [24] 2274 	lcall	_ak820_outline_0103
      008D21 90 0B 4F         [24] 2275 	mov	dptr,#_decode_keycode_kc_10000_455
      008D24 12 38 49         [24] 2276 	lcall	_ak820_outline_0104
                                   2277 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      008D27 90 0B 4F         [24] 2278 	mov	dptr,#_decode_keycode_kc_10000_455
      008D2A 12 37 CC         [24] 2279 	lcall	_ak820_outline_0009
      008D2D C3               [12] 2280 	clr	c
      008D2E E4               [12] 2281 	clr	a
      008D2F 9C               [12] 2282 	subb	a,r4
      008D30 74 FF            [12] 2283 	mov	a,#0xff
      008D32 9D               [12] 2284 	subb	a,r5
      008D33 50 08            [24] 2285 	jnc	00102$
                                   2286 ;	free result
                                   2287 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      008D35 8C 05            [24] 2288 	mov	ar5,r4
      008D37 7C 00            [12] 2289 	mov	r4,#0x00
      008D39 12 38 55         [24] 2290 	lcall	_ak820_outline_0117
      008D3C 22               [24] 2291 	ret
      008D3D                       2292 00102$:
                                   2293 ;	quantum/dynamic_keymap.c:672: return kc;
      008D3D 12 43 20         [24] 2294 	lcall	_ak820_outline_0116
                                   2295 ;	quantum/dynamic_keymap.c:673: }
      008D40 22               [24] 2296 	ret
                                   2297 ;------------------------------------------------------------
                                   2298 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2299 ;------------------------------------------------------------
                                   2300 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_458'
                                   2301 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_459'
                                   2302 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_464'
                                   2303 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_465'
                                   2304 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_471'
                                   2305 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_489'
                                   2306 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_493'
                                   2307 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_493'
                                   2308 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_495'
                                   2309 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_497'
                                   2310 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_501'
                                   2311 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_503'
                                   2312 ;------------------------------------------------------------
                                   2313 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2314 ;	-----------------------------------------
                                   2315 ;	 function dynamic_keymap_macro_send
                                   2316 ;	-----------------------------------------
      008D41                       2317 _dynamic_keymap_macro_send:
      008D41 E5 82            [12] 2318 	mov	a,dpl
      008D43 90 0B 51         [24] 2319 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008D46 F0               [24] 2320 	movx	@dptr,a
                                   2321 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      008D47 90 0B 52         [24] 2322 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008D4A E0               [24] 2323 	movx	a,@dptr
      008D4B 60 01            [24] 2324 	jz	00102$
      008D4D 22               [24] 2325 	ret
      008D4E                       2326 00102$:
                                   2327 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008D4E 90 0B 51         [24] 2328 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008D51 E0               [24] 2329 	movx	a,@dptr
      008D52 FF               [12] 2330 	mov	r7,a
      008D53 BF 10 00         [24] 2331 	cjne	r7,#0x10,00422$
      008D56                       2332 00422$:
      008D56 40 01            [24] 2333 	jc	00104$
                                   2334 ;	quantum/dynamic_keymap.c:683: return;
      008D58 22               [24] 2335 	ret
      008D59                       2336 00104$:
                                   2337 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      008D59 C0 07            [24] 2338 	push	ar7
      008D5B 12 2A F2         [24] 2339 	lcall	_ak820_macro_ready
      008D5E E5 82            [12] 2340 	mov	a, dpl
      008D60 D0 07            [24] 2341 	pop	ar7
      008D62 70 01            [24] 2342 	jnz	00106$
      008D64 22               [24] 2343 	ret
      008D65                       2344 00106$:
                                   2345 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008D65 90 0B 53         [24] 2346 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008D68 E4               [12] 2347 	clr	a
      008D69 F0               [24] 2348 	movx	@dptr,a
      008D6A 74 08            [12] 2349 	mov	a,#0x08
      008D6C A3               [24] 2350 	inc	dptr
      008D6D F0               [24] 2351 	movx	@dptr,a
                                   2352 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008D6E C0 07            [24] 2353 	push	ar7
      008D70 12 2B 2B         [24] 2354 	lcall	_ak820_macro_length
      008D73 AD 82            [24] 2355 	mov	r5, dpl
      008D75 AE 83            [24] 2356 	mov	r6, dph
      008D77 D0 07            [24] 2357 	pop	ar7
      008D79 74 08            [12] 2358 	mov	a,#0x08
      008D7B 2E               [12] 2359 	add	a, r6
      008D7C FE               [12] 2360 	mov	r6,a
                                   2361 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      008D7D 7B 00            [12] 2362 	mov	r3,#0x00
      008D7F 7C 08            [12] 2363 	mov	r4,#0x08
      008D81                       2364 00111$:
      008D81 EF               [12] 2365 	mov	a,r7
      008D82 60 31            [24] 2366 	jz	00113$
                                   2367 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008D84 EB               [12] 2368 	mov	a,r3
      008D85 B5 05 05         [24] 2369 	cjne	a,ar5,00108$
      008D88 EC               [12] 2370 	mov	a,r4
      008D89 B5 06 01         [24] 2371 	cjne	a,ar6,00108$
                                   2372 ;	quantum/dynamic_keymap.c:717: return;
      008D8C 22               [24] 2373 	ret
      008D8D                       2374 00108$:
                                   2375 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008D8D 8B 01            [24] 2376 	mov	ar1,r3
      008D8F 8C 02            [24] 2377 	mov	ar2,r4
      008D91 8A 00            [24] 2378 	mov	ar0,r2
      008D93 7A 00            [12] 2379 	mov	r2,#0x00
      008D95 89 82            [24] 2380 	mov	dpl, r1
      008D97 88 83            [24] 2381 	mov	dph, r0
      008D99 8A F0            [24] 2382 	mov	b, r2
      008D9B 12 40 38         [24] 2383 	lcall	_eeprom_read_byte
      008D9E E5 82            [12] 2384 	mov	a, dpl
      008DA0 70 06            [24] 2385 	jnz	00110$
                                   2386 ;	quantum/dynamic_keymap.c:720: --id;
      008DA2 1F               [12] 2387 	dec	r7
      008DA3 90 0B 51         [24] 2388 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008DA6 EF               [12] 2389 	mov	a,r7
      008DA7 F0               [24] 2390 	movx	@dptr,a
      008DA8                       2391 00110$:
                                   2392 ;	quantum/dynamic_keymap.c:722: ++p;
      008DA8 0B               [12] 2393 	inc	r3
      008DA9 BB 00 01         [24] 2394 	cjne	r3,#0x00,00429$
      008DAC 0C               [12] 2395 	inc	r4
      008DAD                       2396 00429$:
      008DAD 90 0B 53         [24] 2397 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008DB0 12 38 2C         [24] 2398 	lcall	_ak820_outline_0076
      008DB3 80 CC            [24] 2399 	sjmp	00111$
      008DB5                       2400 00113$:
                                   2401 ;	quantum/dynamic_keymap.c:728: sending = true;
      008DB5 90 0B 52         [24] 2402 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008DB8 74 01            [12] 2403 	mov	a,#0x01
      008DBA F0               [24] 2404 	movx	@dptr,a
                                   2405 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      008DBB 12 90 68         [24] 2406 	lcall	_ak820_outline_0161
      008DBE 90 09 9B         [24] 2407 	mov	dptr,#_ak820_macro_cancelled
      008DC1 F0               [24] 2408 	movx	@dptr,a
                                   2409 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      008DC2 90 0B 55         [24] 2410 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008DC5 F0               [24] 2411 	movx	@dptr,a
      008DC6 90 0B 56         [24] 2412 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008DC9 F0               [24] 2413 	movx	@dptr,a
      008DCA 90 0B 57         [24] 2414 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008DCD F0               [24] 2415 	movx	@dptr,a
      008DCE 90 0B 58         [24] 2416 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008DD1 F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	quantum/dynamic_keymap.c:738: while (p < end
      008DD2                       2419 00167$:
                                   2420 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      008DD2 90 0B 53         [24] 2421 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008DD5 E0               [24] 2422 	movx	a,@dptr
      008DD6 FC               [12] 2423 	mov	r4,a
      008DD7 A3               [24] 2424 	inc	dptr
      008DD8 E0               [24] 2425 	movx	a,@dptr
      008DD9 FF               [12] 2426 	mov	r7,a
      008DDA C3               [12] 2427 	clr	c
      008DDB EC               [12] 2428 	mov	a,r4
      008DDC 9D               [12] 2429 	subb	a,r5
      008DDD EF               [12] 2430 	mov	a,r7
      008DDE 9E               [12] 2431 	subb	a,r6
      008DDF 40 03            [24] 2432 	jc	00430$
      008DE1 02 8F F6         [24] 2433 	ljmp	00169$
      008DE4                       2434 00430$:
      008DE4 90 09 9B         [24] 2435 	mov	dptr,#_ak820_macro_cancelled
      008DE7 E0               [24] 2436 	movx	a,@dptr
      008DE8 60 03            [24] 2437 	jz	00431$
      008DEA 02 8F F6         [24] 2438 	ljmp	00169$
      008DED                       2439 00431$:
                                   2440 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008DED 8C 02            [24] 2441 	mov	ar2,r4
      008DEF 8F 03            [24] 2442 	mov	ar3,r7
      008DF1 90 0B 53         [24] 2443 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008DF4 74 01            [12] 2444 	mov	a,#0x01
      008DF6 2C               [12] 2445 	add	a, r4
      008DF7 F0               [24] 2446 	movx	@dptr,a
      008DF8 E4               [12] 2447 	clr	a
      008DF9 3F               [12] 2448 	addc	a, r7
      008DFA A3               [24] 2449 	inc	dptr
      008DFB F0               [24] 2450 	movx	@dptr,a
      008DFC 7F 00            [12] 2451 	mov	r7,#0x00
      008DFE 12 43 3C         [24] 2452 	lcall	_ak820_outline_0141
      008E01 8F F0            [24] 2453 	mov	b, r7
      008E03 12 40 38         [24] 2454 	lcall	_eeprom_read_byte
      008E06 AF 82            [24] 2455 	mov	r7, dpl
      008E08 90 0B 55         [24] 2456 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008E0B EF               [12] 2457 	mov	a,r7
      008E0C F0               [24] 2458 	movx	@dptr,a
                                   2459 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      008E0D 90 0B 56         [24] 2460 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008E10 E4               [12] 2461 	clr	a
      008E11 F0               [24] 2462 	movx	@dptr,a
                                   2463 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      008E12 90 0B 55         [24] 2464 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008E15 E0               [24] 2465 	movx	a,@dptr
      008E16 70 03            [24] 2466 	jnz	00432$
      008E18 02 8F F6         [24] 2467 	ljmp	00169$
      008E1B                       2468 00432$:
                                   2469 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      008E1B 90 0B 55         [24] 2470 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008E1E E0               [24] 2471 	movx	a,@dptr
      008E1F FF               [12] 2472 	mov	r7,a
      008E20 BF 01 02         [24] 2473 	cjne	r7,#0x01,00433$
      008E23 80 03            [24] 2474 	sjmp	00434$
      008E25                       2475 00433$:
      008E25 02 8F D8         [24] 2476 	ljmp	00164$
      008E28                       2477 00434$:
                                   2478 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E28 12 8F FE         [24] 2479 	lcall	_ak820_outline_0000
      008E2B 12 40 38         [24] 2480 	lcall	_eeprom_read_byte
      008E2E AF 82            [24] 2481 	mov	r7, dpl
      008E30 90 0B 56         [24] 2482 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008E33 EF               [12] 2483 	mov	a,r7
      008E34 F0               [24] 2484 	movx	@dptr,a
                                   2485 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      008E35 EF               [12] 2486 	mov	a,r7
      008E36 70 03            [24] 2487 	jnz	00435$
      008E38 02 8F F6         [24] 2488 	ljmp	00169$
      008E3B                       2489 00435$:
                                   2490 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008E3B 12 90 36         [24] 2491 	lcall	_ak820_outline_0089
      008E3E BF 01 02         [24] 2492 	cjne	r7,#0x01,00436$
      008E41 80 13            [24] 2493 	sjmp	00151$
      008E43                       2494 00436$:
      008E43 12 90 36         [24] 2495 	lcall	_ak820_outline_0089
      008E46 BF 02 02         [24] 2496 	cjne	r7,#0x02,00437$
      008E49 80 0B            [24] 2497 	sjmp	00151$
      008E4B                       2498 00437$:
      008E4B 12 90 36         [24] 2499 	lcall	_ak820_outline_0089
      008E4E BF 03 02         [24] 2500 	cjne	r7,#0x03,00438$
      008E51 80 03            [24] 2501 	sjmp	00439$
      008E53                       2502 00438$:
      008E53 02 8E B7         [24] 2503 	ljmp	00152$
      008E56                       2504 00439$:
      008E56                       2505 00151$:
                                   2506 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E56 12 8F FE         [24] 2507 	lcall	_ak820_outline_0000
      008E59 12 40 38         [24] 2508 	lcall	_eeprom_read_byte
      008E5C 12 90 80         [24] 2509 	lcall	_ak820_outline_0177
                                   2510 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      008E5F 70 03            [24] 2511 	jnz	00440$
      008E61 02 8D D2         [24] 2512 	ljmp	00167$
      008E64                       2513 00440$:
                                   2514 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008E64 12 90 36         [24] 2515 	lcall	_ak820_outline_0089
      008E67 BF 01 03         [24] 2516 	cjne	r7,#0x01,00441$
      008E6A D3               [12] 2517 	setb	c
      008E6B 80 01            [24] 2518 	sjmp	00442$
      008E6D                       2519 00441$:
      008E6D C3               [12] 2520 	clr	c
      008E6E                       2521 00442$:
      008E6E 92 22            [24] 2522 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008E70 90 09 9A         [24] 2523 	mov	dptr,#_ak820_macro_primitive
      008E73 B3               [12] 2524 	cpl	c
      008E74 E4               [12] 2525 	clr	a
      008E75 33               [12] 2526 	rlc	a
      008E76 F0               [24] 2527 	movx	@dptr,a
                                   2528 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008E77 12 90 36         [24] 2529 	lcall	_ak820_outline_0089
      008E7A BF 01 10         [24] 2530 	cjne	r7,#0x01,00122$
      008E7D 12 90 61         [24] 2531 	lcall	_ak820_outline_0149
      008E80 C0 06            [24] 2532 	push	ar6
      008E82 C0 05            [24] 2533 	push	ar5
      008E84 12 78 3C         [24] 2534 	lcall	_tap_code
      008E87 D0 05            [24] 2535 	pop	ar5
      008E89 D0 06            [24] 2536 	pop	ar6
      008E8B 80 24            [24] 2537 	sjmp	00123$
      008E8D                       2538 00122$:
                                   2539 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008E8D 12 90 36         [24] 2540 	lcall	_ak820_outline_0089
      008E90 BF 02 10         [24] 2541 	cjne	r7,#0x02,00119$
      008E93 12 90 61         [24] 2542 	lcall	_ak820_outline_0149
      008E96 C0 06            [24] 2543 	push	ar6
      008E98 C0 05            [24] 2544 	push	ar5
      008E9A 12 77 09         [24] 2545 	lcall	_register_code
      008E9D D0 05            [24] 2546 	pop	ar5
      008E9F D0 06            [24] 2547 	pop	ar6
      008EA1 80 0E            [24] 2548 	sjmp	00123$
      008EA3                       2549 00119$:
                                   2550 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      008EA3 12 90 61         [24] 2551 	lcall	_ak820_outline_0149
      008EA6 C0 06            [24] 2552 	push	ar6
      008EA8 C0 05            [24] 2553 	push	ar5
      008EAA 12 77 8E         [24] 2554 	lcall	_unregister_code
      008EAD D0 05            [24] 2555 	pop	ar5
      008EAF D0 06            [24] 2556 	pop	ar6
      008EB1                       2557 00123$:
                                   2558 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      008EB1 12 90 68         [24] 2559 	lcall	_ak820_outline_0161
      008EB4 02 8D D2         [24] 2560 	ljmp	00167$
      008EB7                       2561 00152$:
                                   2562 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008EB7 12 90 36         [24] 2563 	lcall	_ak820_outline_0089
      008EBA BF 05 02         [24] 2564 	cjne	r7,#0x05,00447$
      008EBD 80 13            [24] 2565 	sjmp	00146$
      008EBF                       2566 00447$:
      008EBF 12 90 36         [24] 2567 	lcall	_ak820_outline_0089
      008EC2 BF 06 02         [24] 2568 	cjne	r7,#0x06,00448$
      008EC5 80 0B            [24] 2569 	sjmp	00146$
      008EC7                       2570 00448$:
      008EC7 12 90 36         [24] 2571 	lcall	_ak820_outline_0089
      008ECA BF 07 02         [24] 2572 	cjne	r7,#0x07,00449$
      008ECD 80 03            [24] 2573 	sjmp	00450$
      008ECF                       2574 00449$:
      008ECF 02 8F 78         [24] 2575 	ljmp	00147$
      008ED2                       2576 00450$:
      008ED2                       2577 00146$:
                                   2578 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008ED2 12 8F FE         [24] 2579 	lcall	_ak820_outline_0000
      008ED5 12 40 38         [24] 2580 	lcall	_eeprom_read_byte
      008ED8 12 90 80         [24] 2581 	lcall	_ak820_outline_0177
                                   2582 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      008EDB 70 03            [24] 2583 	jnz	00451$
      008EDD 02 8D D2         [24] 2584 	ljmp	00167$
      008EE0                       2585 00451$:
                                   2586 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008EE0 12 8F FE         [24] 2587 	lcall	_ak820_outline_0000
      008EE3 12 40 38         [24] 2588 	lcall	_eeprom_read_byte
      008EE6 AF 82            [24] 2589 	mov	r7, dpl
      008EE8 90 0B 58         [24] 2590 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008EEB EF               [12] 2591 	mov	a,r7
      008EEC F0               [24] 2592 	movx	@dptr,a
                                   2593 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      008EED EF               [12] 2594 	mov	a,r7
      008EEE 70 03            [24] 2595 	jnz	00452$
      008EF0 02 8D D2         [24] 2596 	ljmp	00167$
      008EF3                       2597 00452$:
                                   2598 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008EF3 90 0B 57         [24] 2599 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008EF6 E0               [24] 2600 	movx	a,@dptr
      008EF7 FF               [12] 2601 	mov	r7,a
      008EF8 90 0B 58         [24] 2602 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008EFB E0               [24] 2603 	movx	a,@dptr
      008EFC FB               [12] 2604 	mov	r3,a
      008EFD E4               [12] 2605 	clr	a
      008EFE FC               [12] 2606 	mov	r4,a
      008EFF FA               [12] 2607 	mov	r2,a
      008F00 EF               [12] 2608 	mov	a,r7
      008F01 42 04            [12] 2609 	orl	ar4,a
      008F03 EA               [12] 2610 	mov	a,r2
      008F04 42 03            [12] 2611 	orl	ar3,a
                                   2612 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      008F06 12 43 5C         [24] 2613 	lcall	_ak820_outline_0179
      008F09 C0 06            [24] 2614 	push	ar6
      008F0B C0 05            [24] 2615 	push	ar5
      008F0D 12 8D 1E         [24] 2616 	lcall	_decode_keycode
      008F10 AC 82            [24] 2617 	mov	r4, dpl
      008F12 AF 83            [24] 2618 	mov	r7, dph
      008F14 D0 05            [24] 2619 	pop	ar5
      008F16 D0 06            [24] 2620 	pop	ar6
                                   2621 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008F18 90 0B 56         [24] 2622 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008F1B E0               [24] 2623 	movx	a,@dptr
      008F1C FB               [12] 2624 	mov	r3,a
      008F1D BB 05 03         [24] 2625 	cjne	r3,#0x05,00453$
      008F20 D3               [12] 2626 	setb	c
      008F21 80 01            [24] 2627 	sjmp	00454$
      008F23                       2628 00453$:
      008F23 C3               [12] 2629 	clr	c
      008F24                       2630 00454$:
      008F24 92 22            [24] 2631 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008F26 90 09 9A         [24] 2632 	mov	dptr,#_ak820_macro_primitive
      008F29 B3               [12] 2633 	cpl	c
      008F2A E4               [12] 2634 	clr	a
      008F2B 33               [12] 2635 	rlc	a
      008F2C F0               [24] 2636 	movx	@dptr,a
                                   2637 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      008F2D 90 0B 56         [24] 2638 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008F30 E0               [24] 2639 	movx	a,@dptr
      008F31 FB               [12] 2640 	mov	r3,a
      008F32 BB 05 02         [24] 2641 	cjne	r3,#0x05,00455$
      008F35 80 0A            [24] 2642 	sjmp	00126$
      008F37                       2643 00455$:
      008F37 BB 06 02         [24] 2644 	cjne	r3,#0x06,00456$
      008F3A 80 16            [24] 2645 	sjmp	00127$
      008F3C                       2646 00456$:
                                   2647 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      008F3C BB 07 33         [24] 2648 	cjne	r3,#0x07,00129$
      008F3F 80 22            [24] 2649 	sjmp	00128$
      008F41                       2650 00126$:
                                   2651 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      008F41 8C 82            [24] 2652 	mov	dpl, r4
      008F43 8F 83            [24] 2653 	mov	dph, r7
      008F45 C0 06            [24] 2654 	push	ar6
      008F47 C0 05            [24] 2655 	push	ar5
      008F49 12 B2 CC         [24] 2656 	lcall	_vial_keycode_tap
      008F4C D0 05            [24] 2657 	pop	ar5
      008F4E D0 06            [24] 2658 	pop	ar6
                                   2659 ;	quantum/dynamic_keymap.c:795: break;
                                   2660 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      008F50 80 20            [24] 2661 	sjmp	00129$
      008F52                       2662 00127$:
                                   2663 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      008F52 8C 82            [24] 2664 	mov	dpl, r4
      008F54 8F 83            [24] 2665 	mov	dph, r7
      008F56 C0 06            [24] 2666 	push	ar6
      008F58 C0 05            [24] 2667 	push	ar5
      008F5A 12 B2 01         [24] 2668 	lcall	_vial_keycode_down
      008F5D D0 05            [24] 2669 	pop	ar5
      008F5F D0 06            [24] 2670 	pop	ar6
                                   2671 ;	quantum/dynamic_keymap.c:798: break;
                                   2672 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      008F61 80 0F            [24] 2673 	sjmp	00129$
      008F63                       2674 00128$:
                                   2675 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      008F63 8C 82            [24] 2676 	mov	dpl, r4
      008F65 8F 83            [24] 2677 	mov	dph, r7
      008F67 C0 06            [24] 2678 	push	ar6
      008F69 C0 05            [24] 2679 	push	ar5
      008F6B 12 B2 67         [24] 2680 	lcall	_vial_keycode_up
      008F6E D0 05            [24] 2681 	pop	ar5
      008F70 D0 06            [24] 2682 	pop	ar6
                                   2683 ;	quantum/dynamic_keymap.c:802: }
      008F72                       2684 00129$:
                                   2685 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      008F72 12 90 68         [24] 2686 	lcall	_ak820_outline_0161
      008F75 02 8D D2         [24] 2687 	ljmp	00167$
      008F78                       2688 00147$:
                                   2689 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      008F78 12 90 36         [24] 2690 	lcall	_ak820_outline_0089
      008F7B BF 04 02         [24] 2691 	cjne	r7,#0x04,00458$
      008F7E 80 03            [24] 2692 	sjmp	00459$
      008F80                       2693 00458$:
      008F80 02 8D D2         [24] 2694 	ljmp	00167$
      008F83                       2695 00459$:
                                   2696 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F83 12 8F FE         [24] 2697 	lcall	_ak820_outline_0000
      008F86 12 40 38         [24] 2698 	lcall	_eeprom_read_byte
      008F89 AF 82            [24] 2699 	mov	r7, dpl
                                   2700 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F8B 90 0B 53         [24] 2701 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008F8E 12 38 5A         [24] 2702 	lcall	_ak820_outline_0120
      008F91 90 0B 53         [24] 2703 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008F94 74 01            [12] 2704 	mov	a,#0x01
      008F96 2B               [12] 2705 	add	a, r3
      008F97 F0               [24] 2706 	movx	@dptr,a
      008F98 E4               [12] 2707 	clr	a
      008F99 3C               [12] 2708 	addc	a, r4
      008F9A A3               [24] 2709 	inc	dptr
      008F9B F0               [24] 2710 	movx	@dptr,a
      008F9C 7A 00            [12] 2711 	mov	r2,#0x00
      008F9E 12 33 FC         [24] 2712 	lcall	_ak820_outline_0121
      008FA1 8A F0            [24] 2713 	mov	b, r2
      008FA3 12 40 38         [24] 2714 	lcall	_eeprom_read_byte
      008FA6 AC 82            [24] 2715 	mov	r4, dpl
                                   2716 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      008FA8 EF               [12] 2717 	mov	a,r7
      008FA9 60 4B            [24] 2718 	jz	00169$
      008FAB EC               [12] 2719 	mov	a,r4
      008FAC 60 48            [24] 2720 	jz	00169$
                                   2721 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008FAE 1F               [12] 2722 	dec	r7
      008FAF 1C               [12] 2723 	dec	r4
      008FB0 EC               [12] 2724 	mov	a,r4
      008FB1 75 F0 FF         [24] 2725 	mov	b,#0xff
      008FB4 A4               [48] 2726 	mul	ab
      008FB5 FC               [12] 2727 	mov	r4,a
      008FB6 AB F0            [24] 2728 	mov	r3,b
      008FB8 7A 00            [12] 2729 	mov	r2,#0x00
      008FBA EC               [12] 2730 	mov	a,r4
      008FBB 2F               [12] 2731 	add	a, r7
      008FBC FC               [12] 2732 	mov	r4,a
      008FBD EB               [12] 2733 	mov	a,r3
      008FBE 3A               [12] 2734 	addc	a, r2
      008FBF FB               [12] 2735 	mov	r3,a
                                   2736 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      008FC0                       2737 00141$:
      008FC0 8C 02            [24] 2738 	mov	ar2,r4
      008FC2 8B 07            [24] 2739 	mov	ar7,r3
      008FC4 1C               [12] 2740 	dec	r4
      008FC5 BC FF 01         [24] 2741 	cjne	r4,#0xff,00462$
      008FC8 1B               [12] 2742 	dec	r3
      008FC9                       2743 00462$:
      008FC9 EA               [12] 2744 	mov	a,r2
      008FCA 4F               [12] 2745 	orl	a,r7
      008FCB 70 03            [24] 2746 	jnz	00463$
      008FCD 02 8D D2         [24] 2747 	ljmp	00167$
      008FD0                       2748 00463$:
      008FD0 90 00 01         [24] 2749 	mov	dptr,#0x0001
      008FD3 12 5A F1         [24] 2750 	lcall	_mDelaymS
      008FD6 80 E8            [24] 2751 	sjmp	00141$
      008FD8                       2752 00164$:
                                   2753 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      008FD8 90 0B 55         [24] 2754 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008FDB E0               [24] 2755 	movx	a,@dptr
      008FDC FF               [12] 2756 	mov	r7,a
      008FDD BF 80 00         [24] 2757 	cjne	r7,#0x80,00464$
      008FE0                       2758 00464$:
      008FE0 50 14            [24] 2759 	jnc	00169$
                                   2760 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      008FE2 90 0B 55         [24] 2761 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008FE5 E0               [24] 2762 	movx	a,@dptr
      008FE6 F5 82            [12] 2763 	mov	dpl,a
      008FE8 C0 06            [24] 2764 	push	ar6
      008FEA C0 05            [24] 2765 	push	ar5
      008FEC 12 A5 68         [24] 2766 	lcall	_send_char
      008FEF D0 05            [24] 2767 	pop	ar5
      008FF1 D0 06            [24] 2768 	pop	ar6
                                   2769 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008FF3 02 8D D2         [24] 2770 	ljmp	00167$
      008FF6                       2771 00169$:
                                   2772 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      008FF6 12 90 68         [24] 2773 	lcall	_ak820_outline_0161
                                   2774 ;	quantum/dynamic_keymap.c:837: sending = false;
      008FF9 90 0B 52         [24] 2775 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008FFC F0               [24] 2776 	movx	@dptr,a
                                   2777 ;	quantum/dynamic_keymap.c:839: }
      008FFD 22               [24] 2778 	ret
                                   2779 	.area CSEG    (CODE)
                                   2780 	.area CONST   (CODE)
                                   2781 	.area XINIT   (CODE)
                                   2782 	.area CABS    (ABS,CODE)
                                   2783 
                                   2784 ; Experimental exact instruction outlining.
                                   2785 	.globl _ak820_outline_0000
                                   2786 	.globl _ak820_outline_0004
                                   2787 	.globl _ak820_outline_0009
                                   2788 	.globl _ak820_outline_0011
                                   2789 	.globl _ak820_outline_0016
                                   2790 	.globl _ak820_outline_0024
                                   2791 	.globl _ak820_outline_0030
                                   2792 	.globl _ak820_outline_0043
                                   2793 	.globl _ak820_outline_0050
                                   2794 	.globl _ak820_outline_0058
                                   2795 	.globl _ak820_outline_0059
                                   2796 	.globl _ak820_outline_0060
                                   2797 	.globl _ak820_outline_0070
                                   2798 	.globl _ak820_outline_0074
                                   2799 	.globl _ak820_outline_0076
                                   2800 	.globl _ak820_outline_0078
                                   2801 	.globl _ak820_outline_0087
                                   2802 	.globl _ak820_outline_0089
                                   2803 	.globl _ak820_outline_0095
                                   2804 	.globl _ak820_outline_0096
                                   2805 	.globl _ak820_outline_0099
                                   2806 	.globl _ak820_outline_0103
                                   2807 	.globl _ak820_outline_0104
                                   2808 	.globl _ak820_outline_0112
                                   2809 	.globl _ak820_outline_0116
                                   2810 	.globl _ak820_outline_0117
                                   2811 	.globl _ak820_outline_0119
                                   2812 	.globl _ak820_outline_0120
                                   2813 	.globl _ak820_outline_0121
                                   2814 	.globl _ak820_outline_0122
                                   2815 	.globl _ak820_outline_0126
                                   2816 	.globl _ak820_outline_0130
                                   2817 	.globl _ak820_outline_0131
                                   2818 	.globl _ak820_outline_0132
                                   2819 	.globl _ak820_outline_0133
                                   2820 	.globl _ak820_outline_0140
                                   2821 	.globl _ak820_outline_0141
                                   2822 	.globl _ak820_outline_0147
                                   2823 	.globl _ak820_outline_0149
                                   2824 	.globl _ak820_outline_0153
                                   2825 	.globl _ak820_outline_0154
                                   2826 	.globl _ak820_outline_0156
                                   2827 	.globl _ak820_outline_0161
                                   2828 	.globl _ak820_outline_0165
                                   2829 	.globl _ak820_outline_0173
                                   2830 	.globl _ak820_outline_0174
                                   2831 	.globl _ak820_outline_0177
                                   2832 	.globl _ak820_outline_0178
                                   2833 	.globl _ak820_outline_0179
                                   2834 	.globl _ak820_outline_0183
                                   2835 
                                   2836 	.area CSEG (CODE)
                                   2837 ; function ak820_outline_0000
      008FFE                       2838 _ak820_outline_0000:
      008FFE 90 0B 53         [24] 2839 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009001 E0               [24] 2840 	movx	a,@dptr
      009002 FC               [12] 2841 	mov	r4,a
      009003 A3               [24] 2842 	inc	dptr
      009004 E0               [24] 2843 	movx	a,@dptr
      009005 FF               [12] 2844 	mov	r7,a
      009006 90 0B 53         [24] 2845 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009009 74 01            [12] 2846 	mov	a,#0x01
      00900B 2C               [12] 2847 	add	a,r4
      00900C F0               [24] 2848 	movx	@dptr,a
      00900D E4               [12] 2849 	clr	a
      00900E 3F               [12] 2850 	addc	a,r7
      00900F A3               [24] 2851 	inc	dptr
      009010 F0               [24] 2852 	movx	@dptr,a
      009011 7B 00            [12] 2853 	mov	r3,#0x00
      009013 8C 82            [24] 2854 	mov	dpl,r4
      009015 8F 83            [24] 2855 	mov	dph,r7
      009017 8B F0            [24] 2856 	mov	b,r3
      009019 22               [24] 2857 	ret
                                   2858 
                                   2859 	.area CSEG (CODE)
                                   2860 ; function ak820_outline_0024
      00901A                       2861 _ak820_outline_0024:
      00901A 2D               [12] 2862 	add	a,r5
      00901B F9               [12] 2863 	mov	r1,a
      00901C E4               [12] 2864 	clr	a
      00901D 3E               [12] 2865 	addc	a,r6
      00901E FA               [12] 2866 	mov	r2,a
      00901F 8F 03            [24] 2867 	mov	ar3,r7
      009021 89 82            [24] 2868 	mov	dpl,r1
      009023 8A 83            [24] 2869 	mov	dph,r2
      009025 8B F0            [24] 2870 	mov	b,r3
      009027 22               [24] 2871 	ret
                                   2872 
                                   2873 	.area CSEG (CODE)
                                   2874 ; function ak820_outline_0078
      009028                       2875 _ak820_outline_0078:
      009028 ED               [12] 2876 	mov	a,r5
      009029 75 F0 0A         [24] 2877 	mov	b,#0x0a
      00902C A4               [48] 2878 	mul	ab
      00902D 24 58            [12] 2879 	add	a,#0x58
      00902F FC               [12] 2880 	mov	r4,a
      009030 74 06            [12] 2881 	mov	a,#0x06
      009032 35 F0            [12] 2882 	addc	a,b
      009034 FD               [12] 2883 	mov	r5,a
      009035 22               [24] 2884 	ret
                                   2885 
                                   2886 	.area CSEG (CODE)
                                   2887 ; function ak820_outline_0089
      009036                       2888 _ak820_outline_0089:
      009036 90 0B 56         [24] 2889 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0001)
      009039 E0               [24] 2890 	movx	a,@dptr
      00903A FF               [12] 2891 	mov	r7,a
      00903B 22               [24] 2892 	ret
                                   2893 
                                   2894 	.area CSEG (CODE)
                                   2895 ; function ak820_outline_0095
      00903C                       2896 _ak820_outline_0095:
      00903C 90 0A EC         [24] 2897 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00903F EE               [12] 2898 	mov	a,r6
      009040 F0               [24] 2899 	movx	@dptr,a
      009041 90 0A ED         [24] 2900 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      009044 ED               [12] 2901 	mov	a,r5
      009045 F0               [24] 2902 	movx	@dptr,a
      009046 8F 82            [24] 2903 	mov	dpl,r7
      009048 22               [24] 2904 	ret
                                   2905 
                                   2906 	.area CSEG (CODE)
                                   2907 ; function ak820_outline_0112
      009049                       2908 _ak820_outline_0112:
      009049 AD 82            [24] 2909 	mov	r5,dpl
      00904B AE 83            [24] 2910 	mov	r6,dph
      00904D AF F0            [24] 2911 	mov	r7,b
      00904F 22               [24] 2912 	ret
                                   2913 
                                   2914 	.area CSEG (CODE)
                                   2915 ; function ak820_outline_0126
      009050                       2916 _ak820_outline_0126:
      009050 28               [12] 2917 	add	a,r0
      009051 F5 82            [12] 2918 	mov	dpl,a
      009053 EF               [12] 2919 	mov	a,r7
      009054 39               [12] 2920 	addc	a,r1
      009055 F5 83            [12] 2921 	mov	dph,a
      009057 74 FF            [12] 2922 	mov	a,#0xff
      009059 F0               [24] 2923 	movx	@dptr,a
      00905A 22               [24] 2924 	ret
                                   2925 
                                   2926 	.area CSEG (CODE)
                                   2927 ; function ak820_outline_0132
      00905B                       2928 _ak820_outline_0132:
      00905B 2D               [12] 2929 	add	a,r5
      00905C F9               [12] 2930 	mov	r1,a
      00905D E4               [12] 2931 	clr	a
      00905E 3E               [12] 2932 	addc	a,r6
      00905F FA               [12] 2933 	mov	r2,a
      009060 22               [24] 2934 	ret
                                   2935 
                                   2936 	.area CSEG (CODE)
                                   2937 ; function ak820_outline_0149
      009061                       2938 _ak820_outline_0149:
      009061 90 0B 57         [24] 2939 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      009064 E0               [24] 2940 	movx	a,@dptr
      009065 F5 82            [12] 2941 	mov	dpl,a
      009067 22               [24] 2942 	ret
                                   2943 
                                   2944 	.area CSEG (CODE)
                                   2945 ; function ak820_outline_0161
      009068                       2946 _ak820_outline_0161:
      009068 90 09 9A         [24] 2947 	mov	dptr,#_ak820_macro_primitive
      00906B E4               [12] 2948 	clr	a
      00906C F0               [24] 2949 	movx	@dptr,a
      00906D 22               [24] 2950 	ret
                                   2951 
                                   2952 	.area CSEG (CODE)
                                   2953 ; function ak820_outline_0173
      00906E                       2954 _ak820_outline_0173:
      00906E 90 0A FC         [24] 2955 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      009071 E4               [12] 2956 	clr	a
      009072 F0               [24] 2957 	movx	@dptr,a
      009073 90 0A FD         [24] 2958 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      009076 22               [24] 2959 	ret
                                   2960 
                                   2961 	.area CSEG (CODE)
                                   2962 ; function ak820_outline_0174
      009077                       2963 _ak820_outline_0174:
      009077 90 0B B2         [24] 2964 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      00907A E4               [12] 2965 	clr	a
      00907B F0               [24] 2966 	movx	@dptr,a
      00907C 90 0B B3         [24] 2967 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      00907F 22               [24] 2968 	ret
                                   2969 
                                   2970 	.area CSEG (CODE)
                                   2971 ; function ak820_outline_0177
      009080                       2972 _ak820_outline_0177:
      009080 AF 82            [24] 2973 	mov	r7,dpl
      009082 90 0B 57         [24] 2974 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      009085 EF               [12] 2975 	mov	a,r7
      009086 F0               [24] 2976 	movx	@dptr,a
      009087 EF               [12] 2977 	mov	a,r7
      009088 22               [24] 2978 	ret
