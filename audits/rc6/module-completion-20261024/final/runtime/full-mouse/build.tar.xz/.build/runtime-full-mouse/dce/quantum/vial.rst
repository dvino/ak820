                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000041                        541 _vial_handle_cmd_sloc0_1_0:
      000041                        542 	.ds 2
      000043                        543 _vial_handle_cmd_sloc1_1_0:
      000043                        544 	.ds 2
      000045                        545 _vial_handle_cmd_sloc2_1_0:
      000045                        546 	.ds 2
      000047                        547 _vial_handle_cmd_sloc3_1_0:
      000047                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C44                        573 _vial_unlock_timer:
      000C44                        574 	.ds 4
      000C48                        575 _vial_unlock_holding:
      000C48                        576 	.ds 1
      000C49                        577 _vial_keycode_firewall_in_10000_610:
      000C49                        578 	.ds 2
      000C4B                        579 _vial_fill_packet_PARM_2:
      000C4B                        580 	.ds 1
      000C4C                        581 _vial_fill_packet_msg_10000_613:
      000C4C                        582 	.ds 2
      000C4E                        583 _vial_handle_cmd_PARM_2:
      000C4E                        584 	.ds 1
      000C4F                        585 _vial_handle_cmd_data_10000_618:
      000C4F                        586 	.ds 3
      000C52                        587 _vial_handle_cmd_entry_70000_646:
      000C52                        588 	.ds 10
      000C5C                        589 _vial_handle_cmd_entry_70000_647:
      000C5C                        590 	.ds 10
      000C66                        591 _g_vial_magic_keycode_override::
      000C66                        592 	.ds 2
      000C68                        593 _vial_keycode_down_keycode_10000_649:
      000C68                        594 	.ds 2
      000C6A                        595 _vial_keycode_down_dummy_event_30000_656:
      000C6A                        596 	.ds 6
      000C70                        597 _vial_keycode_up_keycode_10000_657:
      000C70                        598 	.ds 2
      000C72                        599 _vial_keycode_up_dummy_event_30000_664:
      000C72                        600 	.ds 6
      000C78                        601 _vial_keycode_tap_keycode_10000_665:
      000C78                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000E0E                        611 _vial_unlocked::
      000E0E                        612 	.ds 1
      000E0F                        613 _vial_unlock_in_progress::
      000E0F                        614 	.ds 1
      000E10                        615 _vial_unlock_counter:
      000E10                        616 	.ds 1
      000E11                        617 _vial_unlock_combo_rows:
      000E11                        618 	.ds 2
      000E13                        619 _vial_unlock_combo_cols:
      000E13                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00AD59                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00AD59 90 0E 0F         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00AD5C E0               [24]  667 	movx	a,@dptr
      00AD5D 70 01            [24]  668 	jnz	00131$
      00AD5F 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AD60                        671 00131$:
      00AD60 7F 00            [12]  672 	mov	r7,#0x00
      00AD62                        673 00115$:
      00AD62 BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00AD65                        675 00184$:
      00AD65 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00AD67 EF               [12]  678 	mov	a,r7
      00AD68 12 B3 1F         [24]  679 	lcall	_ak820_outline_0125
      00AD6B FE               [12]  680 	mov	r6,a
      00AD6C EF               [12]  681 	mov	a,r7
      00AD6D 12 B3 14         [24]  682 	lcall	_ak820_outline_0124
      00AD70 90 07 71         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00AD73 F0               [24]  684 	movx	@dptr,a
      00AD74 8E 82            [24]  685 	mov	dpl, r6
      00AD76 C0 07            [24]  686 	push	ar7
      00AD78 12 5B 63         [24]  687 	lcall	_matrix_is_on
      00AD7B E5 82            [12]  688 	mov	a, dpl
      00AD7D D0 07            [24]  689 	pop	ar7
      00AD7F 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00AD81 90 0C 48         [24]  692 	mov	dptr,#_vial_unlock_holding
      00AD84 E4               [12]  693 	clr	a
      00AD85 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AD86 90 0E 10         [24]  696 	mov	dptr,#_vial_unlock_counter
      00AD89 74 1E            [12]  697 	mov	a,#0x1e
      00AD8B F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00AD8C 22               [24]  700 	ret
      00AD8D                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AD8D 0F               [12]  703 	inc	r7
      00AD8E 80 D2            [24]  704 	sjmp	00115$
      00AD90                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00AD90 90 0C 48         [24]  707 	mov	dptr,#_vial_unlock_holding
      00AD93 E0               [24]  708 	movx	a,@dptr
      00AD94 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00AD96 90 0C 48         [24]  711 	mov	dptr,#_vial_unlock_holding
      00AD99 74 01            [12]  712 	mov	a,#0x01
      00AD9B F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00AD9C 12 48 A8         [24]  715 	lcall	_timer_read32
      00AD9F 12 4E E3         [24]  716 	lcall	_ak820_outline_0056
      00ADA2 90 0C 44         [24]  717 	mov	dptr,#_vial_unlock_timer
      00ADA5 12 92 03         [24]  718 	lcall	_ak820_outline_0007
      00ADA8                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00ADA8 90 0C 44         [24]  721 	mov	dptr,#_vial_unlock_timer
      00ADAB 12 4E D2         [24]  722 	lcall	_ak820_outline_0053
      00ADAE 12 49 01         [24]  723 	lcall	_timer_elapsed32
      00ADB1 12 4E E3         [24]  724 	lcall	_ak820_outline_0056
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00ADB4 7B 1E            [12]  726 	mov	r3,#0x1e
      00ADB6                        727 00109$:
      00ADB6 EB               [12]  728 	mov	a,r3
      00ADB7 60 22            [24]  729 	jz	00111$
      00ADB9 C3               [12]  730 	clr	c
      00ADBA EC               [12]  731 	mov	a,r4
      00ADBB 94 64            [12]  732 	subb	a,#0x64
      00ADBD ED               [12]  733 	mov	a,r5
      00ADBE 94 00            [12]  734 	subb	a,#0x00
      00ADC0 EE               [12]  735 	mov	a,r6
      00ADC1 94 00            [12]  736 	subb	a,#0x00
      00ADC3 EF               [12]  737 	mov	a,r7
      00ADC4 94 00            [12]  738 	subb	a,#0x00
      00ADC6 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00ADC8 EC               [12]  741 	mov	a,r4
      00ADC9 24 9C            [12]  742 	add	a,#0x9c
      00ADCB FC               [12]  743 	mov	r4,a
      00ADCC ED               [12]  744 	mov	a,r5
      00ADCD 34 FF            [12]  745 	addc	a,#0xff
      00ADCF FD               [12]  746 	mov	r5,a
      00ADD0 EE               [12]  747 	mov	a,r6
      00ADD1 34 FF            [12]  748 	addc	a,#0xff
      00ADD3 FE               [12]  749 	mov	r6,a
      00ADD4 EF               [12]  750 	mov	a,r7
      00ADD5 34 FF            [12]  751 	addc	a,#0xff
      00ADD7 FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00ADD8 1B               [12]  754 	dec	r3
      00ADD9 80 DB            [24]  755 	sjmp	00109$
      00ADDB                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00ADDB 90 0E 10         [24]  758 	mov	dptr,#_vial_unlock_counter
      00ADDE EB               [12]  759 	mov	a,r3
      00ADDF F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00ADE0 EB               [12]  762 	mov	a,r3
      00ADE1 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00ADE3 90 0E 0F         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00ADE6 E4               [12]  766 	clr	a
      00ADE7 F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00ADE8 90 0E 0E         [24]  769 	mov	dptr,#_vial_unlocked
      00ADEB 04               [12]  770 	inc	a
      00ADEC F0               [24]  771 	movx	@dptr,a
      00ADED                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00ADED 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:117: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00ADEE                        782 _vial_init:
                                    783 ;	quantum/vial.c:125: reload_combo();
                                    784 ;	quantum/vial.c:130: }
      00ADEE 02 35 37         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_610'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00ADF1                        795 _vial_keycode_firewall:
      00ADF1 12 38 44         [24]  796 	lcall	_ak820_outline_0103
      00ADF4 90 0C 49         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_610
      00ADF7 12 38 49         [24]  798 	lcall	_ak820_outline_0104
                                    799 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00ADFA 90 0C 49         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_610
      00ADFD 12 37 CC         [24]  801 	lcall	_ak820_outline_0009
      00AE00 BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00AE03 BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00AE06 90 0E 0E         [24]  804 	mov	dptr,#_vial_unlocked
      00AE09 E0               [24]  805 	movx	a,@dptr
      00AE0A 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:134: return 0;
      00AE0C 90 00 00         [24]  808 	mov	dptr,#0x0000
      00AE0F 22               [24]  809 	ret
      00AE10                        810 00102$:
                                    811 ;	quantum/vial.c:135: return in;
      00AE10 12 43 20         [24]  812 	lcall	_ak820_outline_0116
                                    813 ;	quantum/vial.c:136: }
      00AE13 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_613'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_615'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00AE14                        826 _vial_fill_packet:
      00AE14 12 38 44         [24]  827 	lcall	_ak820_outline_0103
      00AE17 90 0C 4C         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_613
      00AE1A 12 38 49         [24]  829 	lcall	_ak820_outline_0104
                                    830 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00AE1D 90 0C 4C         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_613
      00AE20 12 38 01         [24]  832 	lcall	_ak820_outline_0050
      00AE23 90 0C 4B         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00AE26 E0               [24]  834 	movx	a,@dptr
      00AE27 FD               [12]  835 	mov	r5,a
      00AE28 7C 00            [12]  836 	mov	r4,#0x00
      00AE2A                        837 00103$:
      00AE2A BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00AE2D                        839 00122$:
      00AE2D 50 09            [24]  840 	jnc	00105$
      00AE2F EC               [12]  841 	mov	a,r4
      00AE30 12 37 F1         [24]  842 	lcall	_ak820_outline_0030
      00AE33 ED               [12]  843 	mov	a,r5
      00AE34 F0               [24]  844 	movx	@dptr,a
      00AE35 0C               [12]  845 	inc	r4
      00AE36 80 F2            [24]  846 	sjmp	00103$
      00AE38                        847 00105$:
                                    848 ;	quantum/vial.c:141: }
      00AE38 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00AE39                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:174: repeat_key_cancel();
      00AE39 12 A2 30         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:176: clear_keyboard();
                                    861 ;	quantum/vial.c:177: }
      00AE3C 02 78 A9         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_618'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_619'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_624'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_625'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_628'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_630'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_630'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_630'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_631'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_632'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_632'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_632'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_635'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_647'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_647'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00AE3F                        893 _vial_handle_cmd:
      00AE3F 12 42 D7         [24]  894 	lcall	_ak820_outline_0036
      00AE42 90 0C 4F         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_618
      00AE45 12 37 E0         [24]  896 	lcall	_ak820_outline_0015
                                    897 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00AE48 90 0C 4F         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_618
      00AE4B 12 38 01         [24]  899 	lcall	_ak820_outline_0050
                                    900 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00AE4E 90 0C 4E         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AE51 E0               [24]  902 	movx	a,@dptr
      00AE52 FD               [12]  903 	mov	r5,a
      00AE53 BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00AE56 80 01            [24]  905 	sjmp	00102$
      00AE58                        906 00258$:
                                    907 ;	quantum/vial.c:190: return;
      00AE58 22               [24]  908 	ret
      00AE59                        909 00102$:
                                    910 ;	quantum/vial.c:193: switch (msg[1]) {
      00AE59 74 01            [12]  911 	mov	a,#0x01
      00AE5B 12 47 E7         [24]  912 	lcall	_ak820_outline_0011
      00AE5E FB               [12]  913 	mov  r3,a
      00AE5F 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00AE61 50 01            [24]  915 	jnc	00259$
      00AE63 22               [24]  916 	ret
      00AE64                        917 00259$:
                                    918 ;	free result
      00AE64 EB               [12]  919 	mov	a,r3
      00AE65 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00AE67 83               [24]  921 	movc	a,@a+pc
      00AE68 F5 82            [12]  922 	mov	dpl,a
      00AE6A EB               [12]  923 	mov	a,r3
      00AE6B 24 12            [12]  924 	add	a,#(00261$-3-.)
      00AE6D 83               [24]  925 	movc	a,@a+pc
      00AE6E F5 83            [12]  926 	mov	dph,a
      00AE70 E4               [12]  927 	clr	a
      00AE71 73               [24]  928 	jmp	@a+dptr
      00AE72                        929 00260$:
      00AE72 8E                     930 	.db	00103$
      00AE73 D6                     931 	.db	00105$
      00AE74 EB                     932 	.db	00106$
      00AE75 77                     933 	.db	00112$
      00AE76 FD                     934 	.db	00113$
      00AE77 48                     935 	.db	00114$
      00AE78 B7                     936 	.db	00116$
      00AE79 D2                     937 	.db	00119$
      00AE7A F2                     938 	.db	00120$
      00AE7B 00                     939 	.db	00121$
      00AE7C 00                     940 	.db	00139$
      00AE7D 00                     941 	.db	00139$
      00AE7E 00                     942 	.db	00139$
      00AE7F 0B                     943 	.db	00122$
      00AE80                        944 00261$:
      00AE80 AE                     945 	.db	00103$>>8
      00AE81 AE                     946 	.db	00105$>>8
      00AE82 AE                     947 	.db	00106$>>8
      00AE83 AF                     948 	.db	00112$>>8
      00AE84 AF                     949 	.db	00113$>>8
      00AE85 B0                     950 	.db	00114$>>8
      00AE86 B0                     951 	.db	00116$>>8
      00AE87 B0                     952 	.db	00119$>>8
      00AE88 B0                     953 	.db	00120$>>8
      00AE89 B1                     954 	.db	00121$>>8
      00AE8A B2                     955 	.db	00139$>>8
      00AE8B B2                     956 	.db	00139$>>8
      00AE8C B2                     957 	.db	00139$>>8
      00AE8D B1                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00AE8E                        960 00103$:
                                    961 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00AE8E 90 0C 4B         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00AE91 E4               [12]  963 	clr	a
      00AE92 12 42 FB         [24]  964 	lcall	_ak820_outline_0060
      00AE95 C0 07            [24]  965 	push	ar7
      00AE97 C0 06            [24]  966 	push	ar6
      00AE99 12 AE 14         [24]  967 	lcall	_vial_fill_packet
      00AE9C D0 06            [24]  968 	pop	ar6
      00AE9E D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00AEA0 12 43 20         [24]  971 	lcall	_ak820_outline_0116
      00AEA3 74 06            [12]  972 	mov	a,#0x06
      00AEA5 12 42 FB         [24]  973 	lcall	_ak820_outline_0060
                                    974 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00AEA8 A3               [24]  975 	inc	dptr
      00AEA9 E4               [12]  976 	clr	a
      00AEAA 12 42 CF         [24]  977 	lcall	_ak820_outline_0029
                                    978 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00AEAD 12 42 CF         [24]  979 	lcall	_ak820_outline_0029
                                    980 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00AEB0 A3               [24]  981 	inc	dptr
      00AEB1 F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00AEB2 FB               [12]  984 	mov	r3,a
      00AEB3                        985 00131$:
      00AEB3 BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00AEB6                        987 00262$:
      00AEB6 50 15            [24]  988 	jnc	00104$
      00AEB8 8B 02            [24]  989 	mov	ar2,r3
      00AEBA 74 04            [12]  990 	mov	a,#0x04
      00AEBC 2A               [12]  991 	add	a, r2
      00AEBD 2E               [12]  992 	add	a, r6
      00AEBE F9               [12]  993 	mov	r1,a
      00AEBF E4               [12]  994 	clr	a
      00AEC0 3F               [12]  995 	addc	a,r7
      00AEC1 FA               [12]  996 	mov	r2,a
      00AEC2 EB               [12]  997 	mov	a,r3
      00AEC3 90 BF D3         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_623
      00AEC6 93               [24]  999 	movc	a,@a+dptr
      00AEC7 12 6E 5A         [24] 1000 	lcall	_ak820_outline_0135
      00AECA 0B               [12] 1001 	inc	r3
      00AECB 80 E6            [24] 1002 	sjmp	00131$
      00AECD                       1003 00104$:
                                   1004 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00AECD 74 0C            [12] 1005 	mov	a,#0x0c
      00AECF 12 37 F1         [24] 1006 	lcall	_ak820_outline_0030
      00AED2 74 01            [12] 1007 	mov	a,#0x01
      00AED4 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:207: break;
      00AED5 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:210: case vial_get_size: {
      00AED6                       1012 00105$:
                                   1013 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00AED6 12 43 20         [24] 1014 	lcall	_ak820_outline_0116
      00AED9 74 7C            [12] 1015 	mov	a,#0x7c
      00AEDB F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00AEDC 12 38 55         [24] 1018 	lcall	_ak820_outline_0117
      00AEDF 74 01            [12] 1019 	mov	a,#0x01
      00AEE1 12 42 CF         [24] 1020 	lcall	_ak820_outline_0029
                                   1021 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00AEE4 E4               [12] 1022 	clr	a
      00AEE5 12 42 CF         [24] 1023 	lcall	_ak820_outline_0029
                                   1024 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00AEE8 A3               [24] 1025 	inc	dptr
      00AEE9 F0               [24] 1026 	movx	@dptr,a
                                   1027 ;	quantum/vial.c:216: break;
      00AEEA 22               [24] 1028 	ret
                                   1029 ;	quantum/vial.c:219: case vial_get_def: {
      00AEEB                       1030 00106$:
                                   1031 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00AEEB 12 AD 1D         [24] 1032 	lcall	_ak820_outline_0020
      00AEEE E0               [24] 1033 	movx	a,@dptr
      00AEEF FB               [12] 1034 	mov	r3,a
      00AEF0 12 42 C5         [24] 1035 	lcall	_ak820_outline_0010
      00AEF3 E0               [24] 1036 	movx	a,@dptr
      00AEF4 4B               [12] 1037 	orl	a,r3
      00AEF5 60 01            [24] 1038 	jz	00108$
      00AEF7 22               [24] 1039 	ret
      00AEF8                       1040 00108$:
                                   1041 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00AEF8 12 37 F9         [24] 1042 	lcall	_ak820_outline_0033
      00AEFB FB               [12] 1043 	mov	r3,a
      00AEFC 7A 00            [12] 1044 	mov	r2,#0x00
      00AEFE 12 AD 14         [24] 1045 	lcall	_ak820_outline_0014
      00AF01 F9               [12] 1046 	mov	r1,a
      00AF02 E4               [12] 1047 	clr	a
      00AF03 42 03            [12] 1048 	orl	ar3,a
      00AF05 E9               [12] 1049 	mov	a,r1
      00AF06 42 02            [12] 1050 	orl	ar2,a
                                   1051 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00AF08 C3               [12] 1052 	clr	c
      00AF09 EB               [12] 1053 	mov	a,r3
      00AF0A 94 0C            [12] 1054 	subb	a,#0x0c
      00AF0C EA               [12] 1055 	mov	a,r2
      00AF0D 94 00            [12] 1056 	subb	a,#0x00
      00AF0F 40 01            [24] 1057 	jc	00110$
      00AF11 22               [24] 1058 	ret
      00AF12                       1059 00110$:
                                   1060 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00AF12 EA               [12] 1061 	mov	a,r2
      00AF13 C4               [12] 1062 	swap	a
      00AF14 23               [12] 1063 	rl	a
      00AF15 54 E0            [12] 1064 	anl	a,#0xe0
      00AF17 CB               [12] 1065 	xch	a,r3
      00AF18 C4               [12] 1066 	swap	a
      00AF19 23               [12] 1067 	rl	a
      00AF1A CB               [12] 1068 	xch	a,r3
      00AF1B 6B               [12] 1069 	xrl	a,r3
      00AF1C CB               [12] 1070 	xch	a,r3
      00AF1D 54 E0            [12] 1071 	anl	a,#0xe0
      00AF1F CB               [12] 1072 	xch	a,r3
      00AF20 6B               [12] 1073 	xrl	a,r3
      00AF21 FA               [12] 1074 	mov	r2,a
      00AF22 8B 41            [24] 1075 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00AF24 8A 42            [24] 1076 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1077 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00AF26 74 7C            [12] 1078 	mov	a,#0x7c
      00AF28 C3               [12] 1079 	clr	c
      00AF29 95 41            [12] 1080 	subb	a,_vial_handle_cmd_sloc0_1_0
      00AF2B F8               [12] 1081 	mov	r0,a
      00AF2C 74 01            [12] 1082 	mov	a,#0x01
      00AF2E 95 42            [12] 1083 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00AF30 F9               [12] 1084 	mov	r1,a
                                   1085 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00AF31 C3               [12] 1086 	clr	c
      00AF32 E8               [12] 1087 	mov	a,r0
      00AF33 94 20            [12] 1088 	subb	a,#0x20
      00AF35 E9               [12] 1089 	mov	a,r1
      00AF36 94 00            [12] 1090 	subb	a,#0x00
      00AF38 40 02            [24] 1091 	jc	00142$
      00AF3A 78 20            [12] 1092 	mov	r0,#0x20
      00AF3C                       1093 00142$:
                                   1094 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00AF3C 79 00            [12] 1095 	mov	r1,#0x00
      00AF3E                       1096 00134$:
      00AF3E C3               [12] 1097 	clr	c
      00AF3F E9               [12] 1098 	mov	a,r1
      00AF40 98               [12] 1099 	subb	a,r0
      00AF41 40 01            [24] 1100 	jc	00267$
      00AF43 22               [24] 1101 	ret
      00AF44                       1102 00267$:
      00AF44 C0 00            [24] 1103 	push	ar0
      00AF46 E9               [12] 1104 	mov	a,r1
      00AF47 2E               [12] 1105 	add	a, r6
      00AF48 F5 43            [12] 1106 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AF4A E4               [12] 1107 	clr	a
      00AF4B 3F               [12] 1108 	addc	a, r7
      00AF4C F5 44            [12] 1109 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00AF4E 89 45            [24] 1110 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00AF50 75 46 00         [24] 1111 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00AF53 A8 41            [24] 1112 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00AF55 AB 42            [24] 1113 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00AF57 E5 45            [12] 1114 	mov	a,_vial_handle_cmd_sloc2_1_0
      00AF59 28               [12] 1115 	add	a, r0
      00AF5A F8               [12] 1116 	mov	r0,a
      00AF5B E5 46            [12] 1117 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00AF5D 3B               [12] 1118 	addc	a, r3
      00AF5E FB               [12] 1119 	mov	r3,a
      00AF5F E8               [12] 1120 	mov	a,r0
      00AF60 24 57            [12] 1121 	add	a, #_keyboard_definition
      00AF62 F5 82            [12] 1122 	mov	dpl,a
      00AF64 EB               [12] 1123 	mov	a,r3
      00AF65 34 BE            [12] 1124 	addc	a, #(_keyboard_definition >> 8)
      00AF67 F5 83            [12] 1125 	mov	dph,a
      00AF69 E4               [12] 1126 	clr	a
      00AF6A 93               [24] 1127 	movc	a,@a+dptr
      00AF6B 85 43 82         [24] 1128 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AF6E 85 44 83         [24] 1129 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AF71 F0               [24] 1130 	movx	@dptr,a
      00AF72 09               [12] 1131 	inc	r1
      00AF73 D0 00            [24] 1132 	pop	ar0
                                   1133 ;	quantum/vial.c:246: case vial_get_encoder: {
      00AF75 80 C7            [24] 1134 	sjmp	00134$
      00AF77                       1135 00112$:
                                   1136 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00AF77 74 02            [12] 1137 	mov	a,#0x02
      00AF79 12 48 26         [24] 1138 	lcall	_ak820_outline_0045
      00AF7C F5 45            [12] 1139 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1140 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00AF7E 74 03            [12] 1141 	mov	a,#0x03
      00AF80 2E               [12] 1142 	add	a, r6
      00AF81 F5 43            [12] 1143 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AF83 E4               [12] 1144 	clr	a
      00AF84 3F               [12] 1145 	addc	a, r7
      00AF85 F5 44            [12] 1146 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00AF87 85 43 82         [24] 1147 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AF8A 85 44 83         [24] 1148 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AF8D E0               [24] 1149 	movx	a,@dptr
                                   1150 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00AF8E F5 41            [12] 1151 	mov	_vial_handle_cmd_sloc0_1_0,a
      00AF90 90 0A F9         [24] 1152 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00AF93 F0               [24] 1153 	movx	@dptr,a
      00AF94 90 0A FA         [24] 1154 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AF97 E4               [12] 1155 	clr	a
      00AF98 F0               [24] 1156 	movx	@dptr,a
      00AF99 85 45 82         [24] 1157 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AF9C C0 07            [24] 1158 	push	ar7
      00AF9E C0 06            [24] 1159 	push	ar6
      00AFA0 C0 05            [24] 1160 	push	ar5
      00AFA2 C0 04            [24] 1161 	push	ar4
      00AFA4 C0 03            [24] 1162 	push	ar3
      00AFA6 C0 02            [24] 1163 	push	ar2
      00AFA8 12 86 87         [24] 1164 	lcall	_dynamic_keymap_get_encoder
      00AFAB 85 82 47         [24] 1165 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AFAE 85 83 48         [24] 1166 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AFB1 D0 02            [24] 1167 	pop	ar2
      00AFB3 D0 03            [24] 1168 	pop	ar3
      00AFB5 D0 04            [24] 1169 	pop	ar4
      00AFB7 D0 05            [24] 1170 	pop	ar5
      00AFB9 D0 06            [24] 1171 	pop	ar6
      00AFBB D0 07            [24] 1172 	pop	ar7
                                   1173 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00AFBD A9 48            [24] 1174 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AFBF 12 43 20         [24] 1175 	lcall	_ak820_outline_0116
      00AFC2 E9               [12] 1176 	mov	a,r1
      00AFC3 F0               [24] 1177 	movx	@dptr,a
                                   1178 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00AFC4 A8 47            [24] 1179 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AFC6 12 38 55         [24] 1180 	lcall	_ak820_outline_0117
      00AFC9 E8               [12] 1181 	mov	a,r0
      00AFCA F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00AFCB 90 0A F9         [24] 1184 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00AFCE E5 41            [12] 1185 	mov	a,_vial_handle_cmd_sloc0_1_0
      00AFD0 F0               [24] 1186 	movx	@dptr,a
      00AFD1 90 0A FA         [24] 1187 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AFD4 74 01            [12] 1188 	mov	a,#0x01
      00AFD6 F0               [24] 1189 	movx	@dptr,a
      00AFD7 85 45 82         [24] 1190 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AFDA C0 03            [24] 1191 	push	ar3
      00AFDC C0 02            [24] 1192 	push	ar2
      00AFDE 12 86 87         [24] 1193 	lcall	_dynamic_keymap_get_encoder
      00AFE1 85 82 47         [24] 1194 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AFE4 85 83 48         [24] 1195 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AFE7 D0 02            [24] 1196 	pop	ar2
      00AFE9 D0 03            [24] 1197 	pop	ar3
                                   1198 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00AFEB A9 48            [24] 1199 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AFED 12 43 3C         [24] 1200 	lcall	_ak820_outline_0141
      00AFF0 E9               [12] 1201 	mov	a,r1
      00AFF1 F0               [24] 1202 	movx	@dptr,a
                                   1203 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00AFF2 A8 47            [24] 1204 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AFF4 85 43 82         [24] 1205 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AFF7 85 44 83         [24] 1206 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AFFA E8               [12] 1207 	mov	a,r0
      00AFFB F0               [24] 1208 	movx	@dptr,a
                                   1209 ;	quantum/vial.c:255: break;
      00AFFC 22               [24] 1210 	ret
                                   1211 ;	quantum/vial.c:257: case vial_set_encoder: {
      00AFFD                       1212 00113$:
                                   1213 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00AFFD 12 37 F9         [24] 1214 	lcall	_ak820_outline_0033
      00B000 F5 43            [12] 1215 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B002 12 AD 14         [24] 1216 	lcall	_ak820_outline_0014
      00B005 F5 45            [12] 1217 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B007 12 AD 1D         [24] 1218 	lcall	_ak820_outline_0020
      00B00A E0               [24] 1219 	movx	a,@dptr
                                   1220 ;	assignBit
      00B00B 24 FF            [12] 1221 	add	a,#0xff
      00B00D E4               [12] 1222 	clr	a
      00B00E 33               [12] 1223 	rlc	a
      00B00F F5 47            [12] 1224 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B011 12 42 C5         [24] 1225 	lcall	_ak820_outline_0010
      00B014 E0               [24] 1226 	movx	a,@dptr
      00B015 F9               [12] 1227 	mov	r1,a
      00B016 78 00            [12] 1228 	mov	r0,#0x00
      00B018 74 06            [12] 1229 	mov	a,#0x06
      00B01A 12 37 E8         [24] 1230 	lcall	_ak820_outline_0016
      00B01D 7B 00            [12] 1231 	mov	r3,#0x00
      00B01F 42 00            [12] 1232 	orl	ar0,a
      00B021 EB               [12] 1233 	mov	a,r3
      00B022 42 01            [12] 1234 	orl	ar1,a
      00B024 12 38 70         [24] 1235 	lcall	_ak820_outline_0154
      00B027 12 AD F1         [24] 1236 	lcall	_vial_keycode_firewall
      00B02A AA 82            [24] 1237 	mov	r2, dpl
      00B02C AB 83            [24] 1238 	mov	r3, dph
      00B02E 90 0A FC         [24] 1239 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B031 E5 45            [12] 1240 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B033 F0               [24] 1241 	movx	@dptr,a
      00B034 90 0A FD         [24] 1242 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B037 E5 47            [12] 1243 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B039 F0               [24] 1244 	movx	@dptr,a
      00B03A 90 0A FE         [24] 1245 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B03D EA               [12] 1246 	mov	a,r2
      00B03E F0               [24] 1247 	movx	@dptr,a
      00B03F EB               [12] 1248 	mov	a,r3
      00B040 A3               [24] 1249 	inc	dptr
      00B041 F0               [24] 1250 	movx	@dptr,a
      00B042 85 43 82         [24] 1251 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1252 ;	quantum/vial.c:259: break;
      00B045 02 86 EE         [24] 1253 	ljmp	_dynamic_keymap_set_encoder
                                   1254 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B048                       1255 00114$:
                                   1256 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B048 90 0C 4B         [24] 1257 	mov	dptr,#_vial_fill_packet_PARM_2
      00B04B 74 FF            [12] 1258 	mov	a,#0xff
      00B04D 12 42 FB         [24] 1259 	lcall	_ak820_outline_0060
      00B050 C0 07            [24] 1260 	push	ar7
      00B052 C0 06            [24] 1261 	push	ar6
      00B054 12 AE 14         [24] 1262 	lcall	_vial_fill_packet
      00B057 D0 06            [24] 1263 	pop	ar6
      00B059 D0 07            [24] 1264 	pop	ar7
                                   1265 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B05B 90 0E 0E         [24] 1266 	mov	dptr,#_vial_unlocked
      00B05E E0               [24] 1267 	movx	a,@dptr
      00B05F 12 43 20         [24] 1268 	lcall	_ak820_outline_0116
      00B062 F0               [24] 1269 	movx	@dptr,a
                                   1270 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B063 74 01            [12] 1271 	mov	a,#0x01
      00B065 2E               [12] 1272 	add	a, r6
      00B066 FA               [12] 1273 	mov	r2,a
      00B067 E4               [12] 1274 	clr	a
      00B068 3F               [12] 1275 	addc	a, r7
      00B069 FB               [12] 1276 	mov	r3,a
      00B06A 90 0E 0F         [24] 1277 	mov	dptr,#_vial_unlock_in_progress
      00B06D E0               [24] 1278 	movx	a,@dptr
      00B06E 12 43 3C         [24] 1279 	lcall	_ak820_outline_0141
      00B071 F0               [24] 1280 	movx	@dptr,a
                                   1281 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B072 7B 00            [12] 1282 	mov	r3,#0x00
      00B074                       1283 00137$:
      00B074 BB 02 00         [24] 1284 	cjne	r3,#0x02,00268$
      00B077                       1285 00268$:
      00B077 40 01            [24] 1286 	jc	00269$
      00B079 22               [24] 1287 	ret
      00B07A                       1288 00269$:
                                   1289 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B07A 8B 01            [24] 1290 	mov	ar1,r3
      00B07C 7A 00            [12] 1291 	mov	r2,#0x00
      00B07E E9               [12] 1292 	mov	a,r1
      00B07F 29               [12] 1293 	add	a,r1
      00B080 F5 47            [12] 1294 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B082 EA               [12] 1295 	mov	a,r2
      00B083 33               [12] 1296 	rlc	a
      00B084 F5 48            [12] 1297 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B086 74 02            [12] 1298 	mov	a,#0x02
      00B088 25 47            [12] 1299 	add	a, _vial_handle_cmd_sloc3_1_0
      00B08A F8               [12] 1300 	mov	r0,a
      00B08B E4               [12] 1301 	clr	a
      00B08C 35 48            [12] 1302 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B08E FA               [12] 1303 	mov	r2,a
      00B08F E8               [12] 1304 	mov	a,r0
      00B090 2E               [12] 1305 	add	a, r6
      00B091 F8               [12] 1306 	mov	r0,a
      00B092 EA               [12] 1307 	mov	a,r2
      00B093 3F               [12] 1308 	addc	a, r7
      00B094 FA               [12] 1309 	mov	r2,a
      00B095 EB               [12] 1310 	mov	a,r3
      00B096 12 B3 1F         [24] 1311 	lcall	_ak820_outline_0125
      00B099 88 82            [24] 1312 	mov	dpl,r0
      00B09B 8A 83            [24] 1313 	mov	dph,r2
      00B09D F0               [24] 1314 	movx	@dptr,a
                                   1315 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B09E 74 03            [12] 1316 	mov	a,#0x03
      00B0A0 25 47            [12] 1317 	add	a, _vial_handle_cmd_sloc3_1_0
      00B0A2 F9               [12] 1318 	mov	r1,a
      00B0A3 E4               [12] 1319 	clr	a
      00B0A4 35 48            [12] 1320 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B0A6 FA               [12] 1321 	mov	r2,a
      00B0A7 E9               [12] 1322 	mov	a,r1
      00B0A8 2E               [12] 1323 	add	a, r6
      00B0A9 F9               [12] 1324 	mov	r1,a
      00B0AA EA               [12] 1325 	mov	a,r2
      00B0AB 3F               [12] 1326 	addc	a, r7
      00B0AC FA               [12] 1327 	mov	r2,a
      00B0AD EB               [12] 1328 	mov	a,r3
      00B0AE 12 B3 14         [24] 1329 	lcall	_ak820_outline_0124
      00B0B1 12 6E 5A         [24] 1330 	lcall	_ak820_outline_0135
                                   1331 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B0B4 0B               [12] 1332 	inc	r3
                                   1333 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B0B5 80 BD            [24] 1334 	sjmp	00137$
      00B0B7                       1335 00116$:
                                   1336 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B0B7 90 0E 0F         [24] 1337 	mov	dptr,#_vial_unlock_in_progress
      00B0BA E0               [24] 1338 	movx	a,@dptr
      00B0BB 70 03            [24] 1339 	jnz	00118$
      00B0BD 12 AE 39         [24] 1340 	lcall	_vial_release_held_state
      00B0C0                       1341 00118$:
                                   1342 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B0C0 90 0E 0F         [24] 1343 	mov	dptr,#_vial_unlock_in_progress
      00B0C3 74 01            [12] 1344 	mov	a,#0x01
      00B0C5 F0               [24] 1345 	movx	@dptr,a
                                   1346 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B0C6 90 0E 10         [24] 1347 	mov	dptr,#_vial_unlock_counter
      00B0C9 74 1E            [12] 1348 	mov	a,#0x1e
      00B0CB F0               [24] 1349 	movx	@dptr,a
                                   1350 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B0CC 90 0C 48         [24] 1351 	mov	dptr,#_vial_unlock_holding
      00B0CF E4               [12] 1352 	clr	a
      00B0D0 F0               [24] 1353 	movx	@dptr,a
                                   1354 ;	quantum/vial.c:287: break;
      00B0D1 22               [24] 1355 	ret
                                   1356 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B0D2                       1357 00119$:
                                   1358 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B0D2 90 0E 0E         [24] 1359 	mov	dptr,#_vial_unlocked
      00B0D5 E0               [24] 1360 	movx	a,@dptr
      00B0D6 12 43 20         [24] 1361 	lcall	_ak820_outline_0116
      00B0D9 F0               [24] 1362 	movx	@dptr,a
                                   1363 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B0DA 90 0E 0F         [24] 1364 	mov	dptr,#_vial_unlock_in_progress
      00B0DD E0               [24] 1365 	movx	a,@dptr
      00B0DE 12 38 55         [24] 1366 	lcall	_ak820_outline_0117
      00B0E1 F0               [24] 1367 	movx	@dptr,a
                                   1368 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B0E2 74 02            [12] 1369 	mov	a,#0x02
      00B0E4 2E               [12] 1370 	add	a, r6
      00B0E5 FA               [12] 1371 	mov	r2,a
      00B0E6 E4               [12] 1372 	clr	a
      00B0E7 3F               [12] 1373 	addc	a, r7
      00B0E8 FB               [12] 1374 	mov	r3,a
      00B0E9 90 0E 10         [24] 1375 	mov	dptr,#_vial_unlock_counter
      00B0EC E0               [24] 1376 	movx	a,@dptr
      00B0ED 12 43 3C         [24] 1377 	lcall	_ak820_outline_0141
      00B0F0 F0               [24] 1378 	movx	@dptr,a
                                   1379 ;	quantum/vial.c:293: break;
      00B0F1 22               [24] 1380 	ret
                                   1381 ;	quantum/vial.c:295: case vial_lock: {
      00B0F2                       1382 00120$:
                                   1383 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B0F2 90 0E 0E         [24] 1384 	mov	dptr,#_vial_unlocked
      00B0F5 E4               [12] 1385 	clr	a
      00B0F6 F0               [24] 1386 	movx	@dptr,a
                                   1387 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B0F7 90 0E 0F         [24] 1388 	mov	dptr,#_vial_unlock_in_progress
      00B0FA F0               [24] 1389 	movx	@dptr,a
                                   1390 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B0FB 90 0C 48         [24] 1391 	mov	dptr,#_vial_unlock_holding
      00B0FE F0               [24] 1392 	movx	@dptr,a
                                   1393 ;	quantum/vial.c:301: break;
      00B0FF 22               [24] 1394 	ret
                                   1395 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B100                       1396 00121$:
                                   1397 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B100 90 0C 4B         [24] 1398 	mov	dptr,#_vial_fill_packet_PARM_2
      00B103 74 FF            [12] 1399 	mov	a,#0xff
      00B105 12 42 FB         [24] 1400 	lcall	_ak820_outline_0060
                                   1401 ;	quantum/vial.c:314: break;
      00B108 02 AE 14         [24] 1402 	ljmp	_vial_fill_packet
                                   1403 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B10B                       1404 00122$:
                                   1405 ;	quantum/vial.c:347: switch (msg[2]) {
      00B10B 12 37 F9         [24] 1406 	lcall	_ak820_outline_0033
      00B10E FB               [12] 1407 	mov	r3,a
      00B10F 60 0C            [24] 1408 	jz	00123$
      00B111 BB 03 02         [24] 1409 	cjne	r3,#0x03,00272$
      00B114 80 31            [24] 1410 	sjmp	00124$
      00B116                       1411 00272$:
      00B116 BB 04 03         [24] 1412 	cjne	r3,#0x04,00273$
      00B119 02 B1 A5         [24] 1413 	ljmp	00125$
      00B11C                       1414 00273$:
      00B11C 22               [24] 1415 	ret
                                   1416 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B11D                       1417 00123$:
                                   1418 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B11D 90 0C 4B         [24] 1419 	mov	dptr,#_vial_fill_packet_PARM_2
      00B120 E4               [12] 1420 	clr	a
      00B121 12 42 FB         [24] 1421 	lcall	_ak820_outline_0060
      00B124 C0 07            [24] 1422 	push	ar7
      00B126 C0 06            [24] 1423 	push	ar6
      00B128 12 AE 14         [24] 1424 	lcall	_vial_fill_packet
      00B12B D0 06            [24] 1425 	pop	ar6
      00B12D D0 07            [24] 1426 	pop	ar7
                                   1427 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B12F 12 43 20         [24] 1428 	lcall	_ak820_outline_0116
      00B132 E4               [12] 1429 	clr	a
      00B133 12 42 FB         [24] 1430 	lcall	_ak820_outline_0060
                                   1431 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B136 A3               [24] 1432 	inc	dptr
      00B137 74 08            [12] 1433 	mov	a,#0x08
      00B139 12 42 CF         [24] 1434 	lcall	_ak820_outline_0029
                                   1435 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B13C E4               [12] 1436 	clr	a
      00B13D F0               [24] 1437 	movx	@dptr,a
                                   1438 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B13E 74 1F            [12] 1439 	mov	a,#0x1f
      00B140 12 37 F1         [24] 1440 	lcall	_ak820_outline_0030
      00B143 74 01            [12] 1441 	mov	a,#0x01
      00B145 F0               [24] 1442 	movx	@dptr,a
                                   1443 ;	quantum/vial.c:356: break;
      00B146 22               [24] 1444 	ret
                                   1445 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B147                       1446 00124$:
                                   1447 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B147 12 AD 14         [24] 1448 	lcall	_ak820_outline_0014
      00B14A FB               [12] 1449 	mov	r3,a
                                   1450 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B14B 90 0C 52         [24] 1451 	mov	dptr,#_vial_handle_cmd_entry_70000_646
      00B14E 12 4F 0B         [24] 1452 	lcall	_ak820_outline_0165
      00B151 90 0C 54         [24] 1453 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0002)
      00B154 F0               [24] 1454 	movx	@dptr,a
      00B155 A3               [24] 1455 	inc	dptr
      00B156 F0               [24] 1456 	movx	@dptr,a
      00B157 90 0C 56         [24] 1457 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0004)
      00B15A F0               [24] 1458 	movx	@dptr,a
      00B15B A3               [24] 1459 	inc	dptr
      00B15C F0               [24] 1460 	movx	@dptr,a
      00B15D 90 0C 58         [24] 1461 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0006)
      00B160 F0               [24] 1462 	movx	@dptr,a
      00B161 A3               [24] 1463 	inc	dptr
      00B162 F0               [24] 1464 	movx	@dptr,a
      00B163 90 0C 5A         [24] 1465 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00B166 F0               [24] 1466 	movx	@dptr,a
      00B167 A3               [24] 1467 	inc	dptr
      00B168 F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B169 90 0B 01         [24] 1470 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B16C 74 52            [12] 1471 	mov	a,#_vial_handle_cmd_entry_70000_646
      00B16E F0               [24] 1472 	movx	@dptr,a
      00B16F 74 0C            [12] 1473 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00B171 12 38 32         [24] 1474 	lcall	_ak820_outline_0096
      00B174 8B 82            [24] 1475 	mov	dpl, r3
      00B176 C0 07            [24] 1476 	push	ar7
      00B178 C0 06            [24] 1477 	push	ar6
      00B17A C0 05            [24] 1478 	push	ar5
      00B17C C0 04            [24] 1479 	push	ar4
      00B17E 12 87 5A         [24] 1480 	lcall	_dynamic_keymap_get_combo
      00B181 AA 82            [24] 1481 	mov	r2, dpl
      00B183 D0 04            [24] 1482 	pop	ar4
      00B185 D0 05            [24] 1483 	pop	ar5
      00B187 D0 06            [24] 1484 	pop	ar6
      00B189 D0 07            [24] 1485 	pop	ar7
      00B18B 12 43 20         [24] 1486 	lcall	_ak820_outline_0116
      00B18E EA               [12] 1487 	mov	a,r2
      00B18F F0               [24] 1488 	movx	@dptr,a
                                   1489 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B190 7B 00            [12] 1490 	mov	r3,#0x00
      00B192 90 0D 8E         [24] 1491 	mov	dptr,#___memcpy_PARM_2
      00B195 74 52            [12] 1492 	mov	a,#_vial_handle_cmd_entry_70000_646
      00B197 F0               [24] 1493 	movx	@dptr,a
      00B198 74 0C            [12] 1494 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00B19A 12 B3 05         [24] 1495 	lcall	_ak820_outline_0072
      00B19D 12 38 55         [24] 1496 	lcall	_ak820_outline_0117
      00B1A0 8B F0            [24] 1497 	mov	b, r3
                                   1498 ;	quantum/vial.c:387: break;
      00B1A2 02 B8 D1         [24] 1499 	ljmp	___memcpy
                                   1500 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B1A5                       1501 00125$:
                                   1502 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B1A5 12 AD 14         [24] 1503 	lcall	_ak820_outline_0014
      00B1A8 FD               [12] 1504 	mov	r5,a
                                   1505 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B1A9 74 04            [12] 1506 	mov	a,#0x04
      00B1AB 2E               [12] 1507 	add	a, r6
      00B1AC FB               [12] 1508 	mov	r3,a
      00B1AD E4               [12] 1509 	clr	a
      00B1AE 3F               [12] 1510 	addc	a, r7
      00B1AF FC               [12] 1511 	mov	r4,a
      00B1B0 90 0D 8E         [24] 1512 	mov	dptr,#___memcpy_PARM_2
      00B1B3 EB               [12] 1513 	mov	a,r3
      00B1B4 F0               [24] 1514 	movx	@dptr,a
      00B1B5 EC               [12] 1515 	mov	a,r4
      00B1B6 12 B3 05         [24] 1516 	lcall	_ak820_outline_0072
      00B1B9 90 0C 5C         [24] 1517 	mov	dptr,#_vial_handle_cmd_entry_70000_647
      00B1BC F5 F0            [12] 1518 	mov	b,a
      00B1BE C0 07            [24] 1519 	push	ar7
      00B1C0 C0 06            [24] 1520 	push	ar6
      00B1C2 C0 05            [24] 1521 	push	ar5
      00B1C4 12 B8 D1         [24] 1522 	lcall	___memcpy
                                   1523 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B1C7 90 0C 64         [24] 1524 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00B1CA 12 38 5A         [24] 1525 	lcall	_ak820_outline_0120
      00B1CD 12 33 FC         [24] 1526 	lcall	_ak820_outline_0121
      00B1D0 12 AD F1         [24] 1527 	lcall	_vial_keycode_firewall
      00B1D3 AB 82            [24] 1528 	mov	r3, dpl
      00B1D5 AC 83            [24] 1529 	mov	r4, dph
      00B1D7 D0 05            [24] 1530 	pop	ar5
      00B1D9 90 0C 64         [24] 1531 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00B1DC 12 38 2C         [24] 1532 	lcall	_ak820_outline_0076
                                   1533 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B1DF 90 0B 05         [24] 1534 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B1E2 74 5C            [12] 1535 	mov	a,#_vial_handle_cmd_entry_70000_647
      00B1E4 F0               [24] 1536 	movx	@dptr,a
      00B1E5 74 0C            [12] 1537 	mov	a,#(_vial_handle_cmd_entry_70000_647 >> 8)
      00B1E7 12 38 32         [24] 1538 	lcall	_ak820_outline_0096
      00B1EA 8D 82            [24] 1539 	mov	dpl, r5
      00B1EC 12 88 01         [24] 1540 	lcall	_dynamic_keymap_set_combo
      00B1EF AC 82            [24] 1541 	mov	r4, dpl
      00B1F1 D0 06            [24] 1542 	pop	ar6
      00B1F3 D0 07            [24] 1543 	pop	ar7
      00B1F5 12 43 20         [24] 1544 	lcall	_ak820_outline_0116
      00B1F8 EC               [12] 1545 	mov	a,r4
      00B1F9 F0               [24] 1546 	movx	@dptr,a
                                   1547 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B1FA EC               [12] 1548 	mov	a,r4
      00B1FB 70 03            [24] 1549 	jnz	00139$
                                   1550 ;	quantum/vial.c:423: }
                                   1551 ;	quantum/vial.c:424: }
      00B1FD 02 35 37         [24] 1552 	ljmp	_ak820_combo_reload
      00B200                       1553 00139$:
      00B200 22               [24] 1554 	ret
                                   1555 ;------------------------------------------------------------
                                   1556 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1557 ;------------------------------------------------------------
                                   1558 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_649'
                                   1559 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_656'
                                   1560 ;------------------------------------------------------------
                                   1561 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1562 ;	-----------------------------------------
                                   1563 ;	 function vial_keycode_down
                                   1564 ;	-----------------------------------------
      00B201                       1565 _vial_keycode_down:
      00B201 12 38 44         [24] 1566 	lcall	_ak820_outline_0103
      00B204 90 0C 68         [24] 1567 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B207 12 38 49         [24] 1568 	lcall	_ak820_outline_0104
                                   1569 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B20A 90 0C 68         [24] 1570 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B20D 12 37 CC         [24] 1571 	lcall	_ak820_outline_0009
      00B210 74 E0            [12] 1572 	mov	a,#0x100 - 0x20
      00B212 2D               [12] 1573 	add	a,r5
      00B213 50 19            [24] 1574 	jnc	00104$
      00B215 C3               [12] 1575 	clr	c
      00B216 74 FF            [12] 1576 	mov	a,#0xff
      00B218 9C               [12] 1577 	subb	a,r4
      00B219 74 4F            [12] 1578 	mov	a,#0x4f
      00B21B 9D               [12] 1579 	subb	a,r5
      00B21C 40 10            [24] 1580 	jc	00104$
                                   1581 ;	free result
                                   1582 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B21E 90 0C 68         [24] 1583 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B221 EE               [12] 1584 	mov	a,r6
      00B222 12 38 60         [24] 1585 	lcall	_ak820_outline_0122
                                   1586 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B225 90 0C 68         [24] 1587 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B228 E0               [24] 1588 	movx	a,@dptr
      00B229 24 FE            [12] 1589 	add	a,#0xff - 0x01
      00B22B 40 01            [24] 1590 	jc	00104$
                                   1591 ;	free result
      00B22D 22               [24] 1592 	ret
      00B22E                       1593 00104$:
                                   1594 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B22E 90 0C 68         [24] 1595 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B231 12 B2 EC         [24] 1596 	lcall	_ak820_outline_0023
                                   1597 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B234 40 06            [24] 1598 	jc	00107$
                                   1599 ;	free result
                                   1600 ;	quantum/vial.c:440: register_code16(keycode);
      00B236 12 43 20         [24] 1601 	lcall	_ak820_outline_0116
      00B239 02 9F 0D         [24] 1602 	ljmp	_register_code16
      00B23C                       1603 00107$:
                                   1604 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B23C 90 0C 6E         [24] 1605 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0004)
      00B23F 74 01            [12] 1606 	mov	a,#0x01
      00B241 F0               [24] 1607 	movx	@dptr,a
      00B242 90 0C 6B         [24] 1608 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0001)
      00B245 74 F0            [12] 1609 	mov	a,#0xf0
      00B247 F0               [24] 1610 	movx	@dptr,a
      00B248 90 0C 6A         [24] 1611 	mov	dptr,#_vial_keycode_down_dummy_event_30000_656
      00B24B F0               [24] 1612 	movx	@dptr,a
      00B24C 90 0C 6F         [24] 1613 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0005)
      00B24F 74 01            [12] 1614 	mov	a,#0x01
      00B251 F0               [24] 1615 	movx	@dptr,a
      00B252 12 48 D9         [24] 1616 	lcall	_timer_read
      00B255 12 43 2B         [24] 1617 	lcall	_ak820_outline_0130
      00B258 43 06 01         [24] 1618 	orl	ar6,#0x01
      00B25B 90 0C 6C         [24] 1619 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0002)
      00B25E 12 48 41         [24] 1620 	lcall	_ak820_outline_0058
                                   1621 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B261 90 0C 6A         [24] 1622 	mov	dptr,#_vial_keycode_down_dummy_event_30000_656
                                   1623 ;	quantum/vial.c:448: }
      00B264 02 72 86         [24] 1624 	ljmp	_ak820_action_exec
                                   1625 ;------------------------------------------------------------
                                   1626 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1627 ;------------------------------------------------------------
                                   1628 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_657'
                                   1629 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_664'
                                   1630 ;------------------------------------------------------------
                                   1631 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1632 ;	-----------------------------------------
                                   1633 ;	 function vial_keycode_up
                                   1634 ;	-----------------------------------------
      00B267                       1635 _vial_keycode_up:
      00B267 12 38 44         [24] 1636 	lcall	_ak820_outline_0103
      00B26A 90 0C 70         [24] 1637 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B26D 12 38 49         [24] 1638 	lcall	_ak820_outline_0104
                                   1639 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B270 90 0C 70         [24] 1640 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B273 12 37 CC         [24] 1641 	lcall	_ak820_outline_0009
      00B276 74 E0            [12] 1642 	mov	a,#0x100 - 0x20
      00B278 2D               [12] 1643 	add	a,r5
      00B279 50 19            [24] 1644 	jnc	00104$
      00B27B C3               [12] 1645 	clr	c
      00B27C 74 FF            [12] 1646 	mov	a,#0xff
      00B27E 9C               [12] 1647 	subb	a,r4
      00B27F 74 4F            [12] 1648 	mov	a,#0x4f
      00B281 9D               [12] 1649 	subb	a,r5
      00B282 40 10            [24] 1650 	jc	00104$
                                   1651 ;	free result
                                   1652 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B284 90 0C 70         [24] 1653 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B287 EE               [12] 1654 	mov	a,r6
      00B288 12 38 60         [24] 1655 	lcall	_ak820_outline_0122
                                   1656 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B28B 90 0C 70         [24] 1657 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B28E E0               [24] 1658 	movx	a,@dptr
      00B28F 24 FE            [12] 1659 	add	a,#0xff - 0x01
      00B291 40 01            [24] 1660 	jc	00104$
                                   1661 ;	free result
      00B293 22               [24] 1662 	ret
      00B294                       1663 00104$:
                                   1664 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B294 90 0C 70         [24] 1665 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B297 12 B2 EC         [24] 1666 	lcall	_ak820_outline_0023
                                   1667 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B29A 40 06            [24] 1668 	jc	00107$
                                   1669 ;	free result
                                   1670 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B29C 12 43 20         [24] 1671 	lcall	_ak820_outline_0116
      00B29F 02 9F 52         [24] 1672 	ljmp	_unregister_code16
      00B2A2                       1673 00107$:
                                   1674 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B2A2 90 0C 76         [24] 1675 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0004)
      00B2A5 74 01            [12] 1676 	mov	a,#0x01
      00B2A7 F0               [24] 1677 	movx	@dptr,a
      00B2A8 90 0C 73         [24] 1678 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0001)
      00B2AB 74 F0            [12] 1679 	mov	a,#0xf0
      00B2AD F0               [24] 1680 	movx	@dptr,a
      00B2AE 90 0C 72         [24] 1681 	mov	dptr,#_vial_keycode_up_dummy_event_30000_664
      00B2B1 F0               [24] 1682 	movx	@dptr,a
      00B2B2 90 0C 77         [24] 1683 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0005)
      00B2B5 E4               [12] 1684 	clr	a
      00B2B6 F0               [24] 1685 	movx	@dptr,a
      00B2B7 12 48 D9         [24] 1686 	lcall	_timer_read
      00B2BA 12 43 2B         [24] 1687 	lcall	_ak820_outline_0130
      00B2BD 43 06 01         [24] 1688 	orl	ar6,#0x01
      00B2C0 90 0C 74         [24] 1689 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0002)
      00B2C3 12 48 41         [24] 1690 	lcall	_ak820_outline_0058
                                   1691 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B2C6 90 0C 72         [24] 1692 	mov	dptr,#_vial_keycode_up_dummy_event_30000_664
                                   1693 ;	quantum/vial.c:470: }
      00B2C9 02 72 86         [24] 1694 	ljmp	_ak820_action_exec
                                   1695 ;------------------------------------------------------------
                                   1696 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1697 ;------------------------------------------------------------
                                   1698 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_665'
                                   1699 ;i             Allocated with name '_vial_keycode_tap_i_30000_668'
                                   1700 ;------------------------------------------------------------
                                   1701 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1702 ;	-----------------------------------------
                                   1703 ;	 function vial_keycode_tap
                                   1704 ;	-----------------------------------------
      00B2CC                       1705 _vial_keycode_tap:
      00B2CC 12 38 44         [24] 1706 	lcall	_ak820_outline_0103
      00B2CF 90 0C 78         [24] 1707 	mov	dptr,#_vial_keycode_tap_keycode_10000_665
      00B2D2 12 38 49         [24] 1708 	lcall	_ak820_outline_0104
                                   1709 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B2D5 90 0C 78         [24] 1710 	mov	dptr,#_vial_keycode_tap_keycode_10000_665
      00B2D8 12 37 A1         [24] 1711 	lcall	_ak820_outline_0004
      00B2DB C0 07            [24] 1712 	push	ar7
      00B2DD C0 06            [24] 1713 	push	ar6
      00B2DF 12 B2 01         [24] 1714 	lcall	_vial_keycode_down
      00B2E2 D0 06            [24] 1715 	pop	ar6
      00B2E4 D0 07            [24] 1716 	pop	ar7
                                   1717 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B2E6 12 43 20         [24] 1718 	lcall	_ak820_outline_0116
                                   1719 ;	quantum/vial.c:476: }
      00B2E9 02 B2 67         [24] 1720 	ljmp	_vial_keycode_up
                                   1721 ;------------------------------------------------------------
                                   1722 ;Allocation info for local variables in function 'process_record_vial'
                                   1723 ;------------------------------------------------------------
                                   1724 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1725 ;keycode       Allocated with name '_process_record_vial_keycode_10000_670'
                                   1726 ;------------------------------------------------------------
                                   1727 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1728 ;	-----------------------------------------
                                   1729 	.area CSEG    (CODE)
                                   1730 	.area CONST   (CODE)
                                   1731 	.area CONST   (CODE)
      00BE57                       1732 _keyboard_definition:
      00BE57 FD                    1733 	.db #0xfd	; 253
      00BE58 37                    1734 	.db #0x37	; 55	'7'
      00BE59 7A                    1735 	.db #0x7a	; 122	'z'
      00BE5A 58                    1736 	.db #0x58	; 88	'X'
      00BE5B 5A                    1737 	.db #0x5a	; 90	'Z'
      00BE5C 00                    1738 	.db #0x00	; 0
      00BE5D 00                    1739 	.db #0x00	; 0
      00BE5E 04                    1740 	.db #0x04	; 4
      00BE5F E6                    1741 	.db #0xe6	; 230
      00BE60 D6                    1742 	.db #0xd6	; 214
      00BE61 B4                    1743 	.db #0xb4	; 180
      00BE62 46                    1744 	.db #0x46	; 70	'F'
      00BE63 02                    1745 	.db #0x02	; 2
      00BE64 00                    1746 	.db #0x00	; 0
      00BE65 21                    1747 	.db #0x21	; 33
      00BE66 01                    1748 	.db #0x01	; 1
      00BE67 00                    1749 	.db #0x00	; 0
      00BE68 00                    1750 	.db #0x00	; 0
      00BE69 00                    1751 	.db #0x00	; 0
      00BE6A 00                    1752 	.db #0x00	; 0
      00BE6B 37                    1753 	.db #0x37	; 55	'7'
      00BE6C 27                    1754 	.db #0x27	; 39
      00BE6D 97                    1755 	.db #0x97	; 151
      00BE6E D6                    1756 	.db #0xd6	; 214
      00BE6F E0                    1757 	.db #0xe0	; 224
      00BE70 03                    1758 	.db #0x03	; 3
      00BE71 CB                    1759 	.db #0xcb	; 203
      00BE72 01                    1760 	.db #0x01	; 1
      00BE73 3C                    1761 	.db #0x3c	; 60
      00BE74 00                    1762 	.db #0x00	; 0
      00BE75 00                    1763 	.db #0x00	; 0
      00BE76 3D                    1764 	.db #0x3d	; 61
      00BE77 88                    1765 	.db #0x88	; 136
      00BE78 CD                    1766 	.db #0xcd	; 205
      00BE79 A5                    1767 	.db #0xa5	; 165
      00BE7A AA                    1768 	.db #0xaa	; 170
      00BE7B E5                    1769 	.db #0xe5	; 229
      00BE7C A8                    1770 	.db #0xa8	; 168
      00BE7D 76                    1771 	.db #0x76	; 118	'v'
      00BE7E F6                    1772 	.db #0xf6	; 246
      00BE7F 43                    1773 	.db #0x43	; 67	'C'
      00BE80 0E                    1774 	.db #0x0e	; 14
      00BE81 D2                    1775 	.db #0xd2	; 210
      00BE82 90                    1776 	.db #0x90	; 144
      00BE83 7D                    1777 	.db #0x7d	; 125
      00BE84 94                    1778 	.db #0x94	; 148
      00BE85 79                    1779 	.db #0x79	; 121	'y'
      00BE86 78                    1780 	.db #0x78	; 120	'x'
      00BE87 EF                    1781 	.db #0xef	; 239
      00BE88 49                    1782 	.db #0x49	; 73	'I'
      00BE89 3E                    1783 	.db #0x3e	; 62
      00BE8A EF                    1784 	.db #0xef	; 239
      00BE8B FD                    1785 	.db #0xfd	; 253
      00BE8C 8F                    1786 	.db #0x8f	; 143
      00BE8D EF                    1787 	.db #0xef	; 239
      00BE8E 00                    1788 	.db #0x00	; 0
      00BE8F C6                    1789 	.db #0xc6	; 198
      00BE90 D1                    1790 	.db #0xd1	; 209
      00BE91 DB                    1791 	.db #0xdb	; 219
      00BE92 FB                    1792 	.db #0xfb	; 251
      00BE93 EB                    1793 	.db #0xeb	; 235
      00BE94 DE                    1794 	.db #0xde	; 222
      00BE95 66                    1795 	.db #0x66	; 102	'f'
      00BE96 63                    1796 	.db #0x63	; 99	'c'
      00BE97 0C                    1797 	.db #0x0c	; 12
      00BE98 92                    1798 	.db #0x92	; 146
      00BE99 7B                    1799 	.db #0x7b	; 123
      00BE9A F9                    1800 	.db #0xf9	; 249
      00BE9B D4                    1801 	.db #0xd4	; 212
      00BE9C 7A                    1802 	.db #0x7a	; 122	'z'
      00BE9D 4F                    1803 	.db #0x4f	; 79	'O'
      00BE9E 83                    1804 	.db #0x83	; 131
      00BE9F 4B                    1805 	.db #0x4b	; 75	'K'
      00BEA0 86                    1806 	.db #0x86	; 134
      00BEA1 0E                    1807 	.db #0x0e	; 14
      00BEA2 6A                    1808 	.db #0x6a	; 106	'j'
      00BEA3 F2                    1809 	.db #0xf2	; 242
      00BEA4 22                    1810 	.db #0x22	; 34
      00BEA5 22                    1811 	.db #0x22	; 34
      00BEA6 0B                    1812 	.db #0x0b	; 11
      00BEA7 03                    1813 	.db #0x03	; 3
      00BEA8 BA                    1814 	.db #0xba	; 186
      00BEA9 67                    1815 	.db #0x67	; 103	'g'
      00BEAA 9B                    1816 	.db #0x9b	; 155
      00BEAB 7A                    1817 	.db #0x7a	; 122	'z'
      00BEAC E1                    1818 	.db #0xe1	; 225
      00BEAD BC                    1819 	.db #0xbc	; 188
      00BEAE 37                    1820 	.db #0x37	; 55	'7'
      00BEAF 26                    1821 	.db #0x26	; 38
      00BEB0 46                    1822 	.db #0x46	; 70	'F'
      00BEB1 78                    1823 	.db #0x78	; 120	'x'
      00BEB2 05                    1824 	.db #0x05	; 5
      00BEB3 0D                    1825 	.db #0x0d	; 13
      00BEB4 95                    1826 	.db #0x95	; 149
      00BEB5 02                    1827 	.db #0x02	; 2
      00BEB6 E4                    1828 	.db #0xe4	; 228
      00BEB7 18                    1829 	.db #0x18	; 24
      00BEB8 CA                    1830 	.db #0xca	; 202
      00BEB9 33                    1831 	.db #0x33	; 51	'3'
      00BEBA EA                    1832 	.db #0xea	; 234
      00BEBB 24                    1833 	.db #0x24	; 36
      00BEBC C8                    1834 	.db #0xc8	; 200
      00BEBD 81                    1835 	.db #0x81	; 129
      00BEBE 4E                    1836 	.db #0x4e	; 78	'N'
      00BEBF 47                    1837 	.db #0x47	; 71	'G'
      00BEC0 A8                    1838 	.db #0xa8	; 168
      00BEC1 44                    1839 	.db #0x44	; 68	'D'
      00BEC2 DD                    1840 	.db #0xdd	; 221
      00BEC3 91                    1841 	.db #0x91	; 145
      00BEC4 6D                    1842 	.db #0x6d	; 109	'm'
      00BEC5 69                    1843 	.db #0x69	; 105	'i'
      00BEC6 DB                    1844 	.db #0xdb	; 219
      00BEC7 4F                    1845 	.db #0x4f	; 79	'O'
      00BEC8 3A                    1846 	.db #0x3a	; 58
      00BEC9 43                    1847 	.db #0x43	; 67	'C'
      00BECA 9D                    1848 	.db #0x9d	; 157
      00BECB 26                    1849 	.db #0x26	; 38
      00BECC 49                    1850 	.db #0x49	; 73	'I'
      00BECD 4C                    1851 	.db #0x4c	; 76	'L'
      00BECE EF                    1852 	.db #0xef	; 239
      00BECF 2B                    1853 	.db #0x2b	; 43
      00BED0 D8                    1854 	.db #0xd8	; 216
      00BED1 55                    1855 	.db #0x55	; 85	'U'
      00BED2 95                    1856 	.db #0x95	; 149
      00BED3 70                    1857 	.db #0x70	; 112	'p'
      00BED4 B1                    1858 	.db #0xb1	; 177
      00BED5 CC                    1859 	.db #0xcc	; 204
      00BED6 CF                    1860 	.db #0xcf	; 207
      00BED7 13                    1861 	.db #0x13	; 19
      00BED8 32                    1862 	.db #0x32	; 50	'2'
      00BED9 6A                    1863 	.db #0x6a	; 106	'j'
      00BEDA A1                    1864 	.db #0xa1	; 161
      00BEDB FF                    1865 	.db #0xff	; 255
      00BEDC 99                    1866 	.db #0x99	; 153
      00BEDD 61                    1867 	.db #0x61	; 97	'a'
      00BEDE 95                    1868 	.db #0x95	; 149
      00BEDF B1                    1869 	.db #0xb1	; 177
      00BEE0 89                    1870 	.db #0x89	; 137
      00BEE1 9B                    1871 	.db #0x9b	; 155
      00BEE2 11                    1872 	.db #0x11	; 17
      00BEE3 D9                    1873 	.db #0xd9	; 217
      00BEE4 35                    1874 	.db #0x35	; 53	'5'
      00BEE5 78                    1875 	.db #0x78	; 120	'x'
      00BEE6 ED                    1876 	.db #0xed	; 237
      00BEE7 CD                    1877 	.db #0xcd	; 205
      00BEE8 94                    1878 	.db #0x94	; 148
      00BEE9 6E                    1879 	.db #0x6e	; 110	'n'
      00BEEA 60                    1880 	.db #0x60	; 96
      00BEEB 8E                    1881 	.db #0x8e	; 142
      00BEEC 63                    1882 	.db #0x63	; 99	'c'
      00BEED 8B                    1883 	.db #0x8b	; 139
      00BEEE FF                    1884 	.db #0xff	; 255
      00BEEF 4E                    1885 	.db #0x4e	; 78	'N'
      00BEF0 20                    1886 	.db #0x20	; 32
      00BEF1 7A                    1887 	.db #0x7a	; 122	'z'
      00BEF2 B5                    1888 	.db #0xb5	; 181
      00BEF3 87                    1889 	.db #0x87	; 135
      00BEF4 C2                    1890 	.db #0xc2	; 194
      00BEF5 35                    1891 	.db #0x35	; 53	'5'
      00BEF6 A4                    1892 	.db #0xa4	; 164
      00BEF7 6D                    1893 	.db #0x6d	; 109	'm'
      00BEF8 18                    1894 	.db #0x18	; 24
      00BEF9 C1                    1895 	.db #0xc1	; 193
      00BEFA A3                    1896 	.db #0xa3	; 163
      00BEFB DB                    1897 	.db #0xdb	; 219
      00BEFC 53                    1898 	.db #0x53	; 83	'S'
      00BEFD 1D                    1899 	.db #0x1d	; 29
      00BEFE EC                    1900 	.db #0xec	; 236
      00BEFF F0                    1901 	.db #0xf0	; 240
      00BF00 BF                    1902 	.db #0xbf	; 191
      00BF01 4A                    1903 	.db #0x4a	; 74	'J'
      00BF02 4C                    1904 	.db #0x4c	; 76	'L'
      00BF03 4A                    1905 	.db #0x4a	; 74	'J'
      00BF04 C4                    1906 	.db #0xc4	; 196
      00BF05 AA                    1907 	.db #0xaa	; 170
      00BF06 37                    1908 	.db #0x37	; 55	'7'
      00BF07 19                    1909 	.db #0x19	; 25
      00BF08 34                    1910 	.db #0x34	; 52	'4'
      00BF09 3F                    1911 	.db #0x3f	; 63
      00BF0A A1                    1912 	.db #0xa1	; 161
      00BF0B D3                    1913 	.db #0xd3	; 211
      00BF0C 1A                    1914 	.db #0x1a	; 26
      00BF0D 5C                    1915 	.db #0x5c	; 92
      00BF0E 03                    1916 	.db #0x03	; 3
      00BF0F 4D                    1917 	.db #0x4d	; 77	'M'
      00BF10 BC                    1918 	.db #0xbc	; 188
      00BF11 10                    1919 	.db #0x10	; 16
      00BF12 2E                    1920 	.db #0x2e	; 46
      00BF13 80                    1921 	.db #0x80	; 128
      00BF14 F7                    1922 	.db #0xf7	; 247
      00BF15 D6                    1923 	.db #0xd6	; 214
      00BF16 82                    1924 	.db #0x82	; 130
      00BF17 24                    1925 	.db #0x24	; 36
      00BF18 4C                    1926 	.db #0x4c	; 76	'L'
      00BF19 87                    1927 	.db #0x87	; 135
      00BF1A B9                    1928 	.db #0xb9	; 185
      00BF1B F8                    1929 	.db #0xf8	; 248
      00BF1C BE                    1930 	.db #0xbe	; 190
      00BF1D 67                    1931 	.db #0x67	; 103	'g'
      00BF1E 96                    1932 	.db #0x96	; 150
      00BF1F 89                    1933 	.db #0x89	; 137
      00BF20 30                    1934 	.db #0x30	; 48	'0'
      00BF21 C8                    1935 	.db #0xc8	; 200
      00BF22 8D                    1936 	.db #0x8d	; 141
      00BF23 2C                    1937 	.db #0x2c	; 44
      00BF24 F5                    1938 	.db #0xf5	; 245
      00BF25 06                    1939 	.db #0x06	; 6
      00BF26 05                    1940 	.db #0x05	; 5
      00BF27 7C                    1941 	.db #0x7c	; 124
      00BF28 48                    1942 	.db #0x48	; 72	'H'
      00BF29 1B                    1943 	.db #0x1b	; 27
      00BF2A 76                    1944 	.db #0x76	; 118	'v'
      00BF2B AA                    1945 	.db #0xaa	; 170
      00BF2C 3D                    1946 	.db #0x3d	; 61
      00BF2D 28                    1947 	.db #0x28	; 40
      00BF2E FC                    1948 	.db #0xfc	; 252
      00BF2F 80                    1949 	.db #0x80	; 128
      00BF30 75                    1950 	.db #0x75	; 117	'u'
      00BF31 EB                    1951 	.db #0xeb	; 235
      00BF32 78                    1952 	.db #0x78	; 120	'x'
      00BF33 D0                    1953 	.db #0xd0	; 208
      00BF34 8A                    1954 	.db #0x8a	; 138
      00BF35 8F                    1955 	.db #0x8f	; 143
      00BF36 27                    1956 	.db #0x27	; 39
      00BF37 F7                    1957 	.db #0xf7	; 247
      00BF38 F2                    1958 	.db #0xf2	; 242
      00BF39 EB                    1959 	.db #0xeb	; 235
      00BF3A 58                    1960 	.db #0x58	; 88	'X'
      00BF3B 37                    1961 	.db #0x37	; 55	'7'
      00BF3C 3C                    1962 	.db #0x3c	; 60
      00BF3D 2B                    1963 	.db #0x2b	; 43
      00BF3E 6F                    1964 	.db #0x6f	; 111	'o'
      00BF3F 0E                    1965 	.db #0x0e	; 14
      00BF40 C7                    1966 	.db #0xc7	; 199
      00BF41 E2                    1967 	.db #0xe2	; 226
      00BF42 A0                    1968 	.db #0xa0	; 160
      00BF43 97                    1969 	.db #0x97	; 151
      00BF44 EE                    1970 	.db #0xee	; 238
      00BF45 FD                    1971 	.db #0xfd	; 253
      00BF46 9F                    1972 	.db #0x9f	; 159
      00BF47 45                    1973 	.db #0x45	; 69	'E'
      00BF48 17                    1974 	.db #0x17	; 23
      00BF49 94                    1975 	.db #0x94	; 148
      00BF4A E6                    1976 	.db #0xe6	; 230
      00BF4B E7                    1977 	.db #0xe7	; 231
      00BF4C FA                    1978 	.db #0xfa	; 250
      00BF4D 4C                    1979 	.db #0x4c	; 76	'L'
      00BF4E 7A                    1980 	.db #0x7a	; 122	'z'
      00BF4F D6                    1981 	.db #0xd6	; 214
      00BF50 7A                    1982 	.db #0x7a	; 122	'z'
      00BF51 7B                    1983 	.db #0x7b	; 123
      00BF52 ED                    1984 	.db #0xed	; 237
      00BF53 10                    1985 	.db #0x10	; 16
      00BF54 C5                    1986 	.db #0xc5	; 197
      00BF55 BC                    1987 	.db #0xbc	; 188
      00BF56 E3                    1988 	.db #0xe3	; 227
      00BF57 A9                    1989 	.db #0xa9	; 169
      00BF58 1F                    1990 	.db #0x1f	; 31
      00BF59 CF                    1991 	.db #0xcf	; 207
      00BF5A C4                    1992 	.db #0xc4	; 196
      00BF5B 9D                    1993 	.db #0x9d	; 157
      00BF5C DC                    1994 	.db #0xdc	; 220
      00BF5D 45                    1995 	.db #0x45	; 69	'E'
      00BF5E 2A                    1996 	.db #0x2a	; 42
      00BF5F 69                    1997 	.db #0x69	; 105	'i'
      00BF60 57                    1998 	.db #0x57	; 87	'W'
      00BF61 8F                    1999 	.db #0x8f	; 143
      00BF62 EC                    2000 	.db #0xec	; 236
      00BF63 85                    2001 	.db #0x85	; 133
      00BF64 6C                    2002 	.db #0x6c	; 108	'l'
      00BF65 43                    2003 	.db #0x43	; 67	'C'
      00BF66 1C                    2004 	.db #0x1c	; 28
      00BF67 BA                    2005 	.db #0xba	; 186
      00BF68 89                    2006 	.db #0x89	; 137
      00BF69 68                    2007 	.db #0x68	; 104	'h'
      00BF6A 4A                    2008 	.db #0x4a	; 74	'J'
      00BF6B 1C                    2009 	.db #0x1c	; 28
      00BF6C 91                    2010 	.db #0x91	; 145
      00BF6D 3F                    2011 	.db #0x3f	; 63
      00BF6E D1                    2012 	.db #0xd1	; 209
      00BF6F B3                    2013 	.db #0xb3	; 179
      00BF70 96                    2014 	.db #0x96	; 150
      00BF71 1D                    2015 	.db #0x1d	; 29
      00BF72 7C                    2016 	.db #0x7c	; 124
      00BF73 14                    2017 	.db #0x14	; 20
      00BF74 77                    2018 	.db #0x77	; 119	'w'
      00BF75 9C                    2019 	.db #0x9c	; 156
      00BF76 74                    2020 	.db #0x74	; 116	't'
      00BF77 36                    2021 	.db #0x36	; 54	'6'
      00BF78 FF                    2022 	.db #0xff	; 255
      00BF79 2C                    2023 	.db #0x2c	; 44
      00BF7A 66                    2024 	.db #0x66	; 102	'f'
      00BF7B AF                    2025 	.db #0xaf	; 175
      00BF7C 0F                    2026 	.db #0x0f	; 15
      00BF7D 3C                    2027 	.db #0x3c	; 60
      00BF7E A2                    2028 	.db #0xa2	; 162
      00BF7F 23                    2029 	.db #0x23	; 35
      00BF80 85                    2030 	.db #0x85	; 133
      00BF81 05                    2031 	.db #0x05	; 5
      00BF82 87                    2032 	.db #0x87	; 135
      00BF83 DA                    2033 	.db #0xda	; 218
      00BF84 61                    2034 	.db #0x61	; 97	'a'
      00BF85 5E                    2035 	.db #0x5e	; 94
      00BF86 42                    2036 	.db #0x42	; 66	'B'
      00BF87 54                    2037 	.db #0x54	; 84	'T'
      00BF88 60                    2038 	.db #0x60	; 96
      00BF89 23                    2039 	.db #0x23	; 35
      00BF8A CA                    2040 	.db #0xca	; 202
      00BF8B BC                    2041 	.db #0xbc	; 188
      00BF8C B3                    2042 	.db #0xb3	; 179
      00BF8D 18                    2043 	.db #0x18	; 24
      00BF8E 1D                    2044 	.db #0x1d	; 29
      00BF8F F8                    2045 	.db #0xf8	; 248
      00BF90 0A                    2046 	.db #0x0a	; 10
      00BF91 55                    2047 	.db #0x55	; 85	'U'
      00BF92 CD                    2048 	.db #0xcd	; 205
      00BF93 A3                    2049 	.db #0xa3	; 163
      00BF94 DE                    2050 	.db #0xde	; 222
      00BF95 FF                    2051 	.db #0xff	; 255
      00BF96 B2                    2052 	.db #0xb2	; 178
      00BF97 2A                    2053 	.db #0x2a	; 42
      00BF98 35                    2054 	.db #0x35	; 53	'5'
      00BF99 00                    2055 	.db #0x00	; 0
      00BF9A D6                    2056 	.db #0xd6	; 214
      00BF9B 7B                    2057 	.db #0x7b	; 123
      00BF9C E8                    2058 	.db #0xe8	; 232
      00BF9D F2                    2059 	.db #0xf2	; 242
      00BF9E 1A                    2060 	.db #0x1a	; 26
      00BF9F BC                    2061 	.db #0xbc	; 188
      00BFA0 F5                    2062 	.db #0xf5	; 245
      00BFA1 7E                    2063 	.db #0x7e	; 126
      00BFA2 48                    2064 	.db #0x48	; 72	'H'
      00BFA3 72                    2065 	.db #0x72	; 114	'r'
      00BFA4 E0                    2066 	.db #0xe0	; 224
      00BFA5 E4                    2067 	.db #0xe4	; 228
      00BFA6 E0                    2068 	.db #0xe0	; 224
      00BFA7 27                    2069 	.db #0x27	; 39
      00BFA8 87                    2070 	.db #0x87	; 135
      00BFA9 9A                    2071 	.db #0x9a	; 154
      00BFAA 51                    2072 	.db #0x51	; 81	'Q'
      00BFAB D4                    2073 	.db #0xd4	; 212
      00BFAC DD                    2074 	.db #0xdd	; 221
      00BFAD C3                    2075 	.db #0xc3	; 195
      00BFAE AA                    2076 	.db #0xaa	; 170
      00BFAF 49                    2077 	.db #0x49	; 73	'I'
      00BFB0 5A                    2078 	.db #0x5a	; 90	'Z'
      00BFB1 2A                    2079 	.db #0x2a	; 42
      00BFB2 00                    2080 	.db #0x00	; 0
      00BFB3 A0                    2081 	.db #0xa0	; 160
      00BFB4 8C                    2082 	.db #0x8c	; 140
      00BFB5 FF                    2083 	.db #0xff	; 255
      00BFB6 74                    2084 	.db #0x74	; 116	't'
      00BFB7 BF                    2085 	.db #0xbf	; 191
      00BFB8 EC                    2086 	.db #0xec	; 236
      00BFB9 1D                    2087 	.db #0x1d	; 29
      00BFBA F1                    2088 	.db #0xf1	; 241
      00BFBB 00                    2089 	.db #0x00	; 0
      00BFBC 01                    2090 	.db #0x01	; 1
      00BFBD D8                    2091 	.db #0xd8	; 216
      00BFBE 02                    2092 	.db #0x02	; 2
      00BFBF CC                    2093 	.db #0xcc	; 204
      00BFC0 07                    2094 	.db #0x07	; 7
      00BFC1 00                    2095 	.db #0x00	; 0
      00BFC2 00                    2096 	.db #0x00	; 0
      00BFC3 C4                    2097 	.db #0xc4	; 196
      00BFC4 5E                    2098 	.db #0x5e	; 94
      00BFC5 2C                    2099 	.db #0x2c	; 44
      00BFC6 7E                    2100 	.db #0x7e	; 126
      00BFC7 B1                    2101 	.db #0xb1	; 177
      00BFC8 C4                    2102 	.db #0xc4	; 196
      00BFC9 67                    2103 	.db #0x67	; 103	'g'
      00BFCA FB                    2104 	.db #0xfb	; 251
      00BFCB 02                    2105 	.db #0x02	; 2
      00BFCC 00                    2106 	.db #0x00	; 0
      00BFCD 00                    2107 	.db #0x00	; 0
      00BFCE 00                    2108 	.db #0x00	; 0
      00BFCF 00                    2109 	.db #0x00	; 0
      00BFD0 04                    2110 	.db #0x04	; 4
      00BFD1 59                    2111 	.db #0x59	; 89	'Y'
      00BFD2 5A                    2112 	.db #0x5a	; 90	'Z'
                                   2113 	.area CSEG    (CODE)
                                   2114 	.area CONST   (CODE)
      00BFD3                       2115 _vial_handle_cmd_keyboard_uid_40000_623:
      00BFD3 04                    2116 	.db #0x04	; 4
      00BFD4 70                    2117 	.db #0x70	; 112	'p'
      00BFD5 FF                    2118 	.db #0xff	; 255
      00BFD6 90                    2119 	.db #0x90	; 144
      00BFD7 01                    2120 	.db #0x01	; 1
      00BFD8 B9                    2121 	.db #0xb9	; 185
      00BFD9 15                    2122 	.db #0x15	; 21
      00BFDA D3                    2123 	.db #0xd3	; 211
                                   2124 	.area CSEG    (CODE)
                                   2125 	.area XINIT   (CODE)
      00C252                       2126 __xinit__vial_unlocked:
      00C252 00                    2127 	.db #0x00	;  0
      00C253                       2128 __xinit__vial_unlock_in_progress:
      00C253 00                    2129 	.db #0x00	;  0
      00C254                       2130 __xinit__vial_unlock_counter:
      00C254 00                    2131 	.db #0x00	; 0
      00C255                       2132 __xinit__vial_unlock_combo_rows:
      00C255 00                    2133 	.db #0x00	; 0
      00C256 00                    2134 	.db #0x00	; 0
      00C257                       2135 __xinit__vial_unlock_combo_cols:
      00C257 00                    2136 	.db #0x00	; 0
      00C258 05                    2137 	.db #0x05	; 5
                                   2138 	.area CABS    (ABS,CODE)
                                   2139 
                                   2140 ; Experimental exact instruction outlining.
                                   2141 	.globl _ak820_outline_0004
                                   2142 	.globl _ak820_outline_0007
                                   2143 	.globl _ak820_outline_0009
                                   2144 	.globl _ak820_outline_0010
                                   2145 	.globl _ak820_outline_0011
                                   2146 	.globl _ak820_outline_0014
                                   2147 	.globl _ak820_outline_0015
                                   2148 	.globl _ak820_outline_0016
                                   2149 	.globl _ak820_outline_0020
                                   2150 	.globl _ak820_outline_0023
                                   2151 	.globl _ak820_outline_0029
                                   2152 	.globl _ak820_outline_0030
                                   2153 	.globl _ak820_outline_0033
                                   2154 	.globl _ak820_outline_0036
                                   2155 	.globl _ak820_outline_0045
                                   2156 	.globl _ak820_outline_0050
                                   2157 	.globl _ak820_outline_0053
                                   2158 	.globl _ak820_outline_0056
                                   2159 	.globl _ak820_outline_0058
                                   2160 	.globl _ak820_outline_0060
                                   2161 	.globl _ak820_outline_0072
                                   2162 	.globl _ak820_outline_0076
                                   2163 	.globl _ak820_outline_0096
                                   2164 	.globl _ak820_outline_0103
                                   2165 	.globl _ak820_outline_0104
                                   2166 	.globl _ak820_outline_0116
                                   2167 	.globl _ak820_outline_0117
                                   2168 	.globl _ak820_outline_0120
                                   2169 	.globl _ak820_outline_0121
                                   2170 	.globl _ak820_outline_0122
                                   2171 	.globl _ak820_outline_0124
                                   2172 	.globl _ak820_outline_0125
                                   2173 	.globl _ak820_outline_0130
                                   2174 	.globl _ak820_outline_0135
                                   2175 	.globl _ak820_outline_0141
                                   2176 	.globl _ak820_outline_0154
                                   2177 	.globl _ak820_outline_0165
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0023
      00B2EC                       2181 _ak820_outline_0023:
      00B2EC E0               [24] 2182 	movx	a,@dptr
      00B2ED FE               [12] 2183 	mov	r6,a
      00B2EE A3               [24] 2184 	inc	dptr
      00B2EF E0               [24] 2185 	movx	a,@dptr
      00B2F0 FF               [12] 2186 	mov	r7,a
      00B2F1 90 0C 66         [24] 2187 	mov	dptr,#_g_vial_magic_keycode_override
      00B2F4 EE               [12] 2188 	mov	a,r6
      00B2F5 F0               [24] 2189 	movx	@dptr,a
      00B2F6 EF               [12] 2190 	mov	a,r7
      00B2F7 A3               [24] 2191 	inc	dptr
      00B2F8 F0               [24] 2192 	movx	@dptr,a
      00B2F9 8E 04            [24] 2193 	mov	ar4,r6
      00B2FB 8F 05            [24] 2194 	mov	ar5,r7
      00B2FD C3               [12] 2195 	clr	c
      00B2FE 74 FF            [12] 2196 	mov	a,#0xff
      00B300 9C               [12] 2197 	subb	a,r4
      00B301 74 1F            [12] 2198 	mov	a,#0x1f
      00B303 9D               [12] 2199 	subb	a,r5
      00B304 22               [24] 2200 	ret
                                   2201 
                                   2202 	.area CSEG (CODE)
                                   2203 ; function ak820_outline_0072
      00B305                       2204 _ak820_outline_0072:
      00B305 A3               [24] 2205 	inc	dptr
      00B306 F0               [24] 2206 	movx	@dptr,a
      00B307 E4               [12] 2207 	clr	a
      00B308 A3               [24] 2208 	inc	dptr
      00B309 F0               [24] 2209 	movx	@dptr,a
      00B30A 90 0D 91         [24] 2210 	mov	dptr,#___memcpy_PARM_3
      00B30D 74 0A            [12] 2211 	mov	a,#0x0a
      00B30F F0               [24] 2212 	movx	@dptr,a
      00B310 E4               [12] 2213 	clr	a
      00B311 A3               [24] 2214 	inc	dptr
      00B312 F0               [24] 2215 	movx	@dptr,a
      00B313 22               [24] 2216 	ret
                                   2217 
                                   2218 	.area CSEG (CODE)
                                   2219 ; function ak820_outline_0124
      00B314                       2220 _ak820_outline_0124:
      00B314 24 13            [12] 2221 	add	a,#_vial_unlock_combo_cols
      00B316 F5 82            [12] 2222 	mov	dpl,a
      00B318 E4               [12] 2223 	clr	a
      00B319 34 0E            [12] 2224 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B31B F5 83            [12] 2225 	mov	dph,a
      00B31D E0               [24] 2226 	movx	a,@dptr
      00B31E 22               [24] 2227 	ret
                                   2228 
                                   2229 	.area CSEG (CODE)
                                   2230 ; function ak820_outline_0125
      00B31F                       2231 _ak820_outline_0125:
      00B31F 24 11            [12] 2232 	add	a,#_vial_unlock_combo_rows
      00B321 F5 82            [12] 2233 	mov	dpl,a
      00B323 E4               [12] 2234 	clr	a
      00B324 34 0E            [12] 2235 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B326 F5 83            [12] 2236 	mov	dph,a
      00B328 E0               [24] 2237 	movx	a,@dptr
      00B329 22               [24] 2238 	ret
