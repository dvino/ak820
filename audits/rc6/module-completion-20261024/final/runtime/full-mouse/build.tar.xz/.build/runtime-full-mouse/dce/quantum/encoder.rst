                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module encoder
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _encoder_wait_pullup_charge
                                     12 	.globl _tap_code_delay
                                     13 	.globl _ak820_action_exec
                                     14 	.globl _is_keyboard_master
                                     15 	.globl _timer_read
                                     16 	.globl _mDelayuS
                                     17 	.globl _readPin
                                     18 	.globl _pinModeInputHighQMK
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _encoder_init
                                    263 	.globl _encoder_read
                                    264 ;--------------------------------------------------------
                                    265 ; special function registers
                                    266 ;--------------------------------------------------------
                                    267 	.area RSEG    (ABS,DATA)
      000000                        268 	.org 0x0000
                           0000D0   269 _PSW	=	0x00d0
                           0000E0   270 _ACC	=	0x00e0
                           0000F0   271 _B	=	0x00f0
                           0000FD   272 _A_INV	=	0x00fd
                           000081   273 _SP	=	0x0081
                           000082   274 _DPL	=	0x0082
                           000083   275 _DPH	=	0x0083
                           0000A1   276 _SAFE_MOD	=	0x00a1
                           0000B1   277 _GLOBAL_CFG	=	0x00b1
                           000087   278 _PCON	=	0x0087
                           0000BA   279 _POWER_CFG	=	0x00ba
                           0000B9   280 _CLOCK_CFG	=	0x00b9
                           0000A9   281 _WAKE_CTRL	=	0x00a9
                           0000FE   282 _RESET_KEEP	=	0x00fe
                           0000FF   283 _WDOG_COUNT	=	0x00ff
                           0000A8   284 _IE	=	0x00a8
                           0000B8   285 _IP	=	0x00b8
                           0000E8   286 _IE_EX	=	0x00e8
                           0000E9   287 _IP_EX	=	0x00e9
                           0000B2   288 _GPIO_IE	=	0x00b2
                           008584   289 _ROM_ADDR	=	0x8584
                           000084   290 _ROM_ADDR_L	=	0x0084
                           000085   291 _ROM_ADDR_H	=	0x0085
                           008F8E   292 _ROM_DATA_HI	=	0x8f8e
                           00008E   293 _ROM_DATA_HL	=	0x008e
                           00008F   294 _ROM_DATA_HH	=	0x008f
                           000086   295 _ROM_CTRL	=	0x0086
                           000080   296 _P0	=	0x0080
                           0000C4   297 _P0_MOD_OC	=	0x00c4
                           0000C5   298 _P0_DIR_PU	=	0x00c5
                           000090   299 _P1	=	0x0090
                           000092   300 _P1_MOD_OC	=	0x0092
                           000093   301 _P1_DIR_PU	=	0x0093
                           0000A0   302 _P2	=	0x00a0
                           000094   303 _P2_MOD_OC	=	0x0094
                           000095   304 _P2_DIR_PU	=	0x0095
                           0000B0   305 _P3	=	0x00b0
                           000096   306 _P3_MOD_OC	=	0x0096
                           000097   307 _P3_DIR_PU	=	0x0097
                           0000C0   308 _P4	=	0x00c0
                           0000C2   309 _P4_MOD_OC	=	0x00c2
                           0000C3   310 _P4_DIR_PU	=	0x00c3
                           0000C1   311 _P4_LED_KEY	=	0x00c1
                           0000AA   312 _P5_IN	=	0x00aa
                           0000AB   313 _P5_OUT_PU	=	0x00ab
                           0000AC   314 _P5_DIR	=	0x00ac
                           0000AD   315 _P6_IN	=	0x00ad
                           0000AE   316 _P6_OUT_PU	=	0x00ae
                           0000AF   317 _P6_DIR	=	0x00af
                           0000F1   318 _P7	=	0x00f1
                           0000A2   319 _XBUS_AUX	=	0x00a2
                           000088   320 _TCON	=	0x0088
                           000089   321 _TMOD	=	0x0089
                           00008A   322 _TL0	=	0x008a
                           00008B   323 _TL1	=	0x008b
                           00008C   324 _TH0	=	0x008c
                           00008D   325 _TH1	=	0x008d
                           000098   326 _SCON	=	0x0098
                           000099   327 _SBUF	=	0x0099
                           0000C8   328 _T2CON	=	0x00c8
                           0000C9   329 _T2MOD	=	0x00c9
                           00CBCA   330 _RCAP2	=	0xcbca
                           0000CA   331 _RCAP2L	=	0x00ca
                           0000CB   332 _RCAP2H	=	0x00cb
                           00CDCC   333 _T2COUNT	=	0xcdcc
                           0000CC   334 _TL2	=	0x00cc
                           0000CD   335 _TH2	=	0x00cd
                           00CFCE   336 _T2CAP1	=	0xcfce
                           0000CE   337 _T2CAP1L	=	0x00ce
                           0000CF   338 _T2CAP1H	=	0x00cf
                           0000F8   339 _SPI0_STAT	=	0x00f8
                           0000F9   340 _SPI0_DATA	=	0x00f9
                           0000FA   341 _SPI0_CTRL	=	0x00fa
                           0000FB   342 _SPI0_CK_SE	=	0x00fb
                           0000FC   343 _SPI0_SETUP	=	0x00fc
                           0000BC   344 _SCON1	=	0x00bc
                           0000BD   345 _SBUF1	=	0x00bd
                           0000BE   346 _SBAUD1	=	0x00be
                           0000BF   347 _SIF1	=	0x00bf
                           0000B4   348 _SPI1_STAT	=	0x00b4
                           0000B5   349 _SPI1_DATA	=	0x00b5
                           0000B6   350 _SPI1_CTRL	=	0x00b6
                           0000B7   351 _SPI1_CK_SE	=	0x00b7
                           0000F3   352 _ADC_CTRL	=	0x00f3
                           00F5F4   353 _ADC_DAT	=	0xf5f4
                           0000F4   354 _ADC_DAT_L	=	0x00f4
                           0000F5   355 _ADC_DAT_H	=	0x00f5
                           0000F6   356 _ADC_CHAN	=	0x00f6
                           0000A6   357 _LED_COMMON	=	0x00a6
                           0000A7   358 _LED_PWM_OE	=	0x00a7
                           00C7C6   359 _LED_DMA	=	0xc7c6
                           0000C6   360 _LED_DMA_L	=	0x00c6
                           0000C7   361 _LED_DMA_H	=	0x00c7
                           0000F7   362 _LED_STATUS	=	0x00f7
                           0000B3   363 _I2CX_INT	=	0x00b3
                           0000BB   364 _I2CS_INT_ST	=	0x00bb
                                    365 ;--------------------------------------------------------
                                    366 ; special function bits
                                    367 ;--------------------------------------------------------
                                    368 	.area RSEG    (ABS,DATA)
      000000                        369 	.org 0x0000
                           0000D7   370 _CY	=	0x00d7
                           0000D6   371 _AC	=	0x00d6
                           0000D5   372 _F0	=	0x00d5
                           0000D4   373 _RS1	=	0x00d4
                           0000D3   374 _RS0	=	0x00d3
                           0000D2   375 _OV	=	0x00d2
                           0000D1   376 _F1	=	0x00d1
                           0000D0   377 _P	=	0x00d0
                           0000AF   378 _EA	=	0x00af
                           0000AE   379 _E_DIS	=	0x00ae
                           0000AD   380 _ET2	=	0x00ad
                           0000AC   381 _ES	=	0x00ac
                           0000AB   382 _ET1	=	0x00ab
                           0000AA   383 _EX1	=	0x00aa
                           0000A9   384 _ET0	=	0x00a9
                           0000A8   385 _EX0	=	0x00a8
                           0000BF   386 _PH_FLAG	=	0x00bf
                           0000BE   387 _PL_FLAG	=	0x00be
                           0000BD   388 _PT2	=	0x00bd
                           0000BC   389 _PS	=	0x00bc
                           0000BB   390 _PT1	=	0x00bb
                           0000BA   391 _PX1	=	0x00ba
                           0000B9   392 _PT0	=	0x00b9
                           0000B8   393 _PX0	=	0x00b8
                           0000EF   394 _IE_WDOG	=	0x00ef
                           0000EE   395 _IE_GPIO	=	0x00ee
                           0000ED   396 _IE_PWM_I2C	=	0x00ed
                           0000EC   397 _IE_UART1	=	0x00ec
                           0000EB   398 _IE_ADC	=	0x00eb
                           0000E9   399 _IE_USB	=	0x00e9
                           0000E8   400 _IE_SPI0	=	0x00e8
                           000087   401 _P0_7	=	0x0087
                           000086   402 _P0_6	=	0x0086
                           000085   403 _P0_5	=	0x0085
                           000084   404 _P0_4	=	0x0084
                           000083   405 _P0_3	=	0x0083
                           000082   406 _P0_2	=	0x0082
                           000081   407 _P0_1	=	0x0081
                           000080   408 _P0_0	=	0x0080
                           000081   409 _SDA0	=	0x0081
                           000080   410 _SCL0	=	0x0080
                           000083   411 _TXD_	=	0x0083
                           000082   412 _RXD_	=	0x0082
                           000085   413 _AIN13	=	0x0085
                           000084   414 _AIN12	=	0x0084
                           000083   415 _AIN11	=	0x0083
                           000082   416 _AIN10	=	0x0082
                           000081   417 _AIN9	=	0x0081
                           000080   418 _AIN8	=	0x0080
                           000097   419 _P1_7	=	0x0097
                           000096   420 _P1_6	=	0x0096
                           000095   421 _P1_5	=	0x0095
                           000094   422 _P1_4	=	0x0094
                           000093   423 _P1_3	=	0x0093
                           000092   424 _P1_2	=	0x0092
                           000091   425 _P1_1	=	0x0091
                           000090   426 _P1_0	=	0x0090
                           000097   427 _TXD1_	=	0x0097
                           000096   428 _RXD1_	=	0x0096
                           000097   429 _SCK	=	0x0097
                           000096   430 _MISO	=	0x0096
                           000095   431 _MOSI	=	0x0095
                           000094   432 _SCS	=	0x0094
                           000092   433 _INT0_	=	0x0092
                           000091   434 _T2EX	=	0x0091
                           000091   435 _CAP2	=	0x0091
                           000090   436 _T2	=	0x0090
                           000090   437 _CAP1	=	0x0090
                           000097   438 _AIN7	=	0x0097
                           000096   439 _AIN6	=	0x0096
                           000095   440 _AIN5	=	0x0095
                           000094   441 _AIN4	=	0x0094
                           000093   442 _AIN3	=	0x0093
                           000092   443 _AIN2	=	0x0092
                           000091   444 _AIN1	=	0x0091
                           000090   445 _AIN0	=	0x0090
                           0000A7   446 _P2_7	=	0x00a7
                           0000A6   447 _P2_6	=	0x00a6
                           0000A5   448 _P2_5	=	0x00a5
                           0000A4   449 _P2_4	=	0x00a4
                           0000A3   450 _P2_3	=	0x00a3
                           0000A2   451 _P2_2	=	0x00a2
                           0000A1   452 _P2_1	=	0x00a1
                           0000A0   453 _P2_0	=	0x00a0
                           0000A7   454 _TXD1	=	0x00a7
                           0000A6   455 _RXD1	=	0x00a6
                           0000A5   456 _T2EX_	=	0x00a5
                           0000A5   457 _CAP2_	=	0x00a5
                           0000A4   458 _T2_	=	0x00a4
                           0000A4   459 _CAP1_	=	0x00a4
                           0000B7   460 _P3_7	=	0x00b7
                           0000B6   461 _P3_6	=	0x00b6
                           0000B5   462 _P3_5	=	0x00b5
                           0000B4   463 _P3_4	=	0x00b4
                           0000B3   464 _P3_3	=	0x00b3
                           0000B2   465 _P3_2	=	0x00b2
                           0000B1   466 _P3_1	=	0x00b1
                           0000B0   467 _P3_0	=	0x00b0
                           0000B7   468 _SCK1	=	0x00b7
                           0000B6   469 _MISO1	=	0x00b6
                           0000B5   470 _MOSI1	=	0x00b5
                           0000B5   471 _T1	=	0x00b5
                           0000B4   472 _T0	=	0x00b4
                           0000B3   473 _INT1	=	0x00b3
                           0000B2   474 _INT0	=	0x00b2
                           0000B1   475 _TXD	=	0x00b1
                           0000B0   476 _RXD	=	0x00b0
                           0000C6   477 _P4_6	=	0x00c6
                           0000C5   478 _P4_5	=	0x00c5
                           0000C4   479 _P4_4	=	0x00c4
                           0000C3   480 _P4_3	=	0x00c3
                           0000C2   481 _P4_2	=	0x00c2
                           0000C1   482 _P4_1	=	0x00c1
                           0000C0   483 _P4_0	=	0x00c0
                           00008F   484 _TF1	=	0x008f
                           00008E   485 _TR1	=	0x008e
                           00008D   486 _TF0	=	0x008d
                           00008C   487 _TR0	=	0x008c
                           00008B   488 _IE1	=	0x008b
                           00008A   489 _IT1	=	0x008a
                           000089   490 _IE0	=	0x0089
                           000088   491 _IT0	=	0x0088
                           00009F   492 _SM0	=	0x009f
                           00009E   493 _SM1	=	0x009e
                           00009D   494 _SM2	=	0x009d
                           00009C   495 _REN	=	0x009c
                           00009B   496 _TB8	=	0x009b
                           00009A   497 _RB8	=	0x009a
                           000099   498 _TI	=	0x0099
                           000098   499 _RI	=	0x0098
                           0000CF   500 _TF2	=	0x00cf
                           0000CF   501 _CAP1F	=	0x00cf
                           0000CE   502 _EXF2	=	0x00ce
                           0000CD   503 _RCLK	=	0x00cd
                           0000CC   504 _TCLK	=	0x00cc
                           0000CB   505 _EXEN2	=	0x00cb
                           0000CA   506 _TR2	=	0x00ca
                           0000C9   507 _C_T2	=	0x00c9
                           0000C8   508 _CP_RL2	=	0x00c8
                           0000FF   509 _S0_FST_ACT	=	0x00ff
                           0000FE   510 _S0_IF_OV	=	0x00fe
                           0000FD   511 _S0_IF_FIRST	=	0x00fd
                           0000FC   512 _S0_IF_BYTE	=	0x00fc
                           0000FB   513 _S0_FREE	=	0x00fb
                           0000FA   514 _S0_T_FIFO	=	0x00fa
                           0000F8   515 _S0_R_FIFO	=	0x00f8
                           0000F7   516 _ADC_START	=	0x00f7
                                    517 ;--------------------------------------------------------
                                    518 ; overlayable register banks
                                    519 ;--------------------------------------------------------
                                    520 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        521 	.ds 8
                                    522 ;--------------------------------------------------------
                                    523 ; internal ram data
                                    524 ;--------------------------------------------------------
                                    525 	.area DSEG    (DATA)
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable items in internal ram
                                    528 ;--------------------------------------------------------
                                    529 ;--------------------------------------------------------
                                    530 ; indirectly addressable internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area ISEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; absolute internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area IABS    (ABS,DATA)
                                    537 	.area IABS    (ABS,DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; bit data
                                    540 ;--------------------------------------------------------
                                    541 	.area BSEG    (BIT)
                                    542 ;--------------------------------------------------------
                                    543 ; paged external ram data
                                    544 ;--------------------------------------------------------
                                    545 	.area PSEG    (PAG,XDATA)
                                    546 ;--------------------------------------------------------
                                    547 ; uninitialized external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area XSEG    (XDATA)
      000B6A                        550 _thisCount:
      000B6A                        551 	.ds 1
      000B6B                        552 _encoder_exec_mapping_PARM_2:
      000B6B                        553 	.ds 1
      000B6C                        554 _encoder_exec_mapping_index_10000_166:
      000B6C                        555 	.ds 1
      000B6D                        556 _encoder_exec_mapping_dummy_event_10000_167:
      000B6D                        557 	.ds 6
      000B73                        558 _encoder_update_PARM_2:
      000B73                        559 	.ds 1
      000B74                        560 _encoder_update_index_10000_168:
      000B74                        561 	.ds 1
      000B75                        562 _encoder_update_changed_10000_169:
      000B75                        563 	.ds 1
      000B76                        564 _encoder_read_changed_10000_175:
      000B76                        565 	.ds 1
                                    566 ;--------------------------------------------------------
                                    567 ; absolute external ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area XABS    (ABS,XDATA)
                                    570 ;--------------------------------------------------------
                                    571 ; initialized external ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area XISEG   (XDATA)
      000DD7                        574 _encoders_pad_a:
      000DD7                        575 	.ds 1
      000DD8                        576 _encoders_pad_b:
      000DD8                        577 	.ds 1
      000DD9                        578 _encoder_LUT:
      000DD9                        579 	.ds 16
      000DE9                        580 _encoder_state:
      000DE9                        581 	.ds 1
      000DEA                        582 _encoder_pulses:
      000DEA                        583 	.ds 1
      000DEB                        584 _encoder_value:
      000DEB                        585 	.ds 1
                                    586 	.area HOME    (CODE)
                                    587 	.area GSINIT0 (CODE)
                                    588 	.area GSINIT1 (CODE)
                                    589 	.area GSINIT2 (CODE)
                                    590 	.area GSINIT3 (CODE)
                                    591 	.area GSINIT4 (CODE)
                                    592 	.area GSINIT5 (CODE)
                                    593 	.area GSINIT  (CODE)
                                    594 	.area GSFINAL (CODE)
                                    595 	.area CSEG    (CODE)
                                    596 ;--------------------------------------------------------
                                    597 ; global & static initialisations
                                    598 ;--------------------------------------------------------
                                    599 	.area HOME    (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area GSINIT  (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; Home
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area HOME    (CODE)
                                    608 ;--------------------------------------------------------
                                    609 ; code
                                    610 ;--------------------------------------------------------
                                    611 	.area CSEG    (CODE)
                                    612 ;------------------------------------------------------------
                                    613 ;Allocation info for local variables in function 'encoder_wait_pullup_charge'
                                    614 ;------------------------------------------------------------
                                    615 ;i             Allocated with name '_encoder_wait_pullup_charge_i_30000_147'
                                    616 ;------------------------------------------------------------
                                    617 ;	quantum/encoder.c:77: __attribute__((weak)) void encoder_wait_pullup_charge(void) {
                                    618 ;	-----------------------------------------
                                    619 ;	 function encoder_wait_pullup_charge
                                    620 ;	-----------------------------------------
      009237                        621 _encoder_wait_pullup_charge:
                           000007   622 	ar7 = 0x07
                           000006   623 	ar6 = 0x06
                           000005   624 	ar5 = 0x05
                           000004   625 	ar4 = 0x04
                           000003   626 	ar3 = 0x03
                           000002   627 	ar2 = 0x02
                           000001   628 	ar1 = 0x01
                           000000   629 	ar0 = 0x00
                                    630 ;	quantum/encoder.c:78: wait_us(100);
      009237 7F 64            [12]  631 	mov	r7,#0x64
      009239                        632 00106$:
      009239 EF               [12]  633 	mov	a,r7
      00923A 60 09            [24]  634 	jz	00108$
      00923C 90 00 01         [24]  635 	mov	dptr,#0x0001
      00923F 12 5A AD         [24]  636 	lcall	_mDelayuS
      009242 1F               [12]  637 	dec	r7
      009243 80 F4            [24]  638 	sjmp	00106$
      009245                        639 00108$:
                                    640 ;	quantum/encoder.c:79: }
      009245 22               [24]  641 	ret
                                    642 ;------------------------------------------------------------
                                    643 ;Allocation info for local variables in function 'encoder_update_user'
                                    644 ;------------------------------------------------------------
                                    645 ;clockwise     Allocated with name '_encoder_update_user_PARM_2'
                                    646 ;index         Allocated with name '_encoder_update_user_index_10000_149'
                                    647 ;------------------------------------------------------------
                                    648 ;	quantum/encoder.c:81: __attribute__((weak)) bool encoder_update_user(uint8_t index, bool clockwise) {
                                    649 ;	-----------------------------------------
                                    650 ;	 function encoder_init
                                    651 ;	-----------------------------------------
      009246                        652 _encoder_init:
                                    653 ;	quantum/encoder.c:122: thisCount                = NUM_ENCODERS;
      009246 90 0B 6A         [24]  654 	mov	dptr,#_thisCount
      009249 74 01            [12]  655 	mov	a,#0x01
      00924B F0               [24]  656 	movx	@dptr,a
                                    657 ;	quantum/encoder.c:165: for (uint8_t i = 0; i < thisCount; i++) {
      00924C 7F 00            [12]  658 	mov	r7,#0x00
      00924E                        659 00104$:
      00924E 12 94 34         [24]  660 	lcall	_ak820_outline_0086
      009251 50 17            [24]  661 	jnc	00101$
                                    662 ;	quantum/encoder.c:166: setPinInputHigh(encoders_pad_a[i]);
      009253 12 94 08         [24]  663 	lcall	_ak820_outline_0026
      009256 C0 07            [24]  664 	push	ar7
      009258 12 59 6F         [24]  665 	lcall	_pinModeInputHighQMK
      00925B D0 07            [24]  666 	pop	ar7
                                    667 ;	quantum/encoder.c:167: setPinInputHigh(encoders_pad_b[i]);
      00925D 12 94 16         [24]  668 	lcall	_ak820_outline_0027
      009260 C0 07            [24]  669 	push	ar7
      009262 12 59 6F         [24]  670 	lcall	_pinModeInputHighQMK
      009265 D0 07            [24]  671 	pop	ar7
                                    672 ;	quantum/encoder.c:165: for (uint8_t i = 0; i < thisCount; i++) {
      009267 0F               [12]  673 	inc	r7
      009268 80 E4            [24]  674 	sjmp	00104$
      00926A                        675 00101$:
                                    676 ;	quantum/encoder.c:169: encoder_wait_pullup_charge();
      00926A 12 92 37         [24]  677 	lcall	_encoder_wait_pullup_charge
                                    678 ;	quantum/encoder.c:170: for (uint8_t i = 0; i < thisCount; i++) {
      00926D 7F 00            [12]  679 	mov	r7,#0x00
      00926F                        680 00107$:
      00926F 12 94 34         [24]  681 	lcall	_ak820_outline_0086
      009272 50 22            [24]  682 	jnc	00109$
                                    683 ;	quantum/encoder.c:171: encoder_state[i] = (readPin(encoders_pad_a[i]) << 0) | (readPin(encoders_pad_b[i]) << 1);
      009274 EF               [12]  684 	mov	a,r7
      009275 24 E9            [12]  685 	add	a, #_encoder_state
      009277 FD               [12]  686 	mov	r5,a
      009278 E4               [12]  687 	clr	a
      009279 34 0D            [12]  688 	addc	a, #(_encoder_state >> 8)
      00927B FE               [12]  689 	mov	r6,a
      00927C 12 94 08         [24]  690 	lcall	_ak820_outline_0026
      00927F 12 59 BB         [24]  691 	lcall	_readPin
      009282 AC 82            [24]  692 	mov	r4, dpl
      009284 12 94 16         [24]  693 	lcall	_ak820_outline_0027
      009287 12 59 BB         [24]  694 	lcall	_readPin
      00928A E5 82            [12]  695 	mov	a,dpl
      00928C 25 82            [12]  696 	add	a,dpl
      00928E 42 04            [12]  697 	orl	ar4,a
      009290 12 43 01         [24]  698 	lcall	_ak820_outline_0064
                                    699 ;	quantum/encoder.c:170: for (uint8_t i = 0; i < thisCount; i++) {
      009293 0F               [12]  700 	inc	r7
      009294 80 D9            [24]  701 	sjmp	00107$
      009296                        702 00109$:
                                    703 ;	quantum/encoder.c:173: }
      009296 22               [24]  704 	ret
                                    705 ;------------------------------------------------------------
                                    706 ;Allocation info for local variables in function 'encoder_exec_mapping'
                                    707 ;------------------------------------------------------------
                                    708 ;clockwise     Allocated with name '_encoder_exec_mapping_PARM_2'
                                    709 ;index         Allocated with name '_encoder_exec_mapping_index_10000_166'
                                    710 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_10000_167'
                                    711 ;------------------------------------------------------------
                                    712 ;	quantum/encoder.c:176: static void encoder_exec_mapping(uint8_t index, bool clockwise) {
                                    713 ;	-----------------------------------------
                                    714 ;	 function encoder_exec_mapping
                                    715 ;	-----------------------------------------
      009297                        716 _encoder_exec_mapping:
      009297 E5 82            [12]  717 	mov	a,dpl
      009299 90 0B 6C         [24]  718 	mov	dptr,#_encoder_exec_mapping_index_10000_166
      00929C F0               [24]  719 	movx	@dptr,a
                                    720 ;	quantum/encoder.c:179: MAKE_EVENT(clockwise ? KEYLOC_ENCODER_CW : KEYLOC_ENCODER_CCW, index, true,
      00929D E0               [24]  721 	movx	a,@dptr
      00929E 90 0B 6D         [24]  722 	mov	dptr,#_encoder_exec_mapping_dummy_event_10000_167
      0092A1 F0               [24]  723 	movx	@dptr,a
      0092A2 90 0B 6B         [24]  724 	mov	dptr,#_encoder_exec_mapping_PARM_2
      0092A5 E0               [24]  725 	movx	a,@dptr
      0092A6 FF               [12]  726 	mov	r7,a
      0092A7 E0               [24]  727 	movx	a,@dptr
      0092A8 60 04            [24]  728 	jz	00103$
      0092AA 7E FD            [12]  729 	mov	r6,#0xfd
      0092AC 80 02            [24]  730 	sjmp	00104$
      0092AE                        731 00103$:
      0092AE 7E FC            [12]  732 	mov	r6,#0xfc
      0092B0                        733 00104$:
      0092B0 90 0B 6E         [24]  734 	mov	dptr,#(_encoder_exec_mapping_dummy_event_10000_167 + 0x0001)
      0092B3 EE               [12]  735 	mov	a,r6
      0092B4 F0               [24]  736 	movx	@dptr,a
      0092B5 12 48 D9         [24]  737 	lcall	_timer_read
      0092B8 AD 82            [24]  738 	mov	r5, dpl
      0092BA AE 83            [24]  739 	mov	r6, dph
      0092BC 90 0B 6F         [24]  740 	mov	dptr,#(_encoder_exec_mapping_dummy_event_10000_167 + 0x0002)
      0092BF 12 43 51         [24]  741 	lcall	_ak820_outline_0158
      0092C2 EF               [12]  742 	mov	a,r7
      0092C3 60 04            [24]  743 	jz	00105$
      0092C5 7F 02            [12]  744 	mov	r7,#0x02
      0092C7 80 02            [24]  745 	sjmp	00106$
      0092C9                        746 00105$:
      0092C9 7F 03            [12]  747 	mov	r7,#0x03
      0092CB                        748 00106$:
      0092CB 90 0B 71         [24]  749 	mov	dptr,#(_encoder_exec_mapping_dummy_event_10000_167 + 0x0004)
      0092CE EF               [12]  750 	mov	a,r7
      0092CF F0               [24]  751 	movx	@dptr,a
      0092D0 90 0B 72         [24]  752 	mov	dptr,#(_encoder_exec_mapping_dummy_event_10000_167 + 0x0005)
      0092D3 74 01            [12]  753 	mov	a,#0x01
      0092D5 F0               [24]  754 	movx	@dptr,a
                                    755 ;	quantum/encoder.c:181: AK820_ACTION_EXEC(dummy_event);
      0092D6 90 0B 6D         [24]  756 	mov	dptr,#_encoder_exec_mapping_dummy_event_10000_167
      0092D9 12 72 86         [24]  757 	lcall	_ak820_action_exec
                                    758 ;	quantum/encoder.c:185: dummy_event.time = timer_read();
      0092DC 12 48 D9         [24]  759 	lcall	_timer_read
      0092DF 12 43 2B         [24]  760 	lcall	_ak820_outline_0130
      0092E2 90 0B 6F         [24]  761 	mov	dptr,#(_encoder_exec_mapping_dummy_event_10000_167 + 0x0002)
      0092E5 12 48 41         [24]  762 	lcall	_ak820_outline_0058
                                    763 ;	quantum/encoder.c:186: dummy_event.pressed = false;
      0092E8 90 0B 72         [24]  764 	mov	dptr,#(_encoder_exec_mapping_dummy_event_10000_167 + 0x0005)
      0092EB E4               [12]  765 	clr	a
      0092EC F0               [24]  766 	movx	@dptr,a
                                    767 ;	quantum/encoder.c:187: AK820_ACTION_EXEC(dummy_event);
      0092ED 90 0B 6D         [24]  768 	mov	dptr,#_encoder_exec_mapping_dummy_event_10000_167
                                    769 ;	quantum/encoder.c:217: }
      0092F0 02 72 86         [24]  770 	ljmp	_ak820_action_exec
                                    771 ;------------------------------------------------------------
                                    772 ;Allocation info for local variables in function 'encoder_update'
                                    773 ;------------------------------------------------------------
                                    774 ;state         Allocated with name '_encoder_update_PARM_2'
                                    775 ;index         Allocated with name '_encoder_update_index_10000_168'
                                    776 ;changed       Allocated with name '_encoder_update_changed_10000_169'
                                    777 ;i             Allocated with name '_encoder_update_i_10000_169'
                                    778 ;resolution    Allocated with name '_encoder_update_resolution_10000_169'
                                    779 ;------------------------------------------------------------
                                    780 ;	quantum/encoder.c:220: static bool encoder_update(uint8_t index, uint8_t state) {
                                    781 ;	-----------------------------------------
                                    782 ;	 function encoder_update
                                    783 ;	-----------------------------------------
      0092F3                        784 _encoder_update:
      0092F3 E5 82            [12]  785 	mov	a,dpl
      0092F5 90 0B 74         [24]  786 	mov	dptr,#_encoder_update_index_10000_168
      0092F8 F0               [24]  787 	movx	@dptr,a
                                    788 ;	quantum/encoder.c:221: bool    changed = false;
      0092F9 90 0B 75         [24]  789 	mov	dptr,#_encoder_update_changed_10000_169
      0092FC E4               [12]  790 	clr	a
      0092FD F0               [24]  791 	movx	@dptr,a
                                    792 ;	quantum/encoder.c:222: uint8_t i       = index;
      0092FE 90 0B 74         [24]  793 	mov	dptr,#_encoder_update_index_10000_168
      009301 E0               [24]  794 	movx	a,@dptr
                                    795 ;	quantum/encoder.c:233: encoder_pulses[i] += encoder_LUT[state & 0xF];
      009302 FF               [12]  796 	mov	r7,a
      009303 24 EA            [12]  797 	add	a, #_encoder_pulses
      009305 FD               [12]  798 	mov	r5,a
      009306 E4               [12]  799 	clr	a
      009307 34 0D            [12]  800 	addc	a, #(_encoder_pulses >> 8)
      009309 FE               [12]  801 	mov	r6,a
      00930A 12 48 47         [24]  802 	lcall	_ak820_outline_0074
      00930D 90 0B 73         [24]  803 	mov	dptr,#_encoder_update_PARM_2
      009310 E0               [24]  804 	movx	a,@dptr
      009311 FB               [12]  805 	mov	r3,a
      009312 74 0F            [12]  806 	mov	a,#0x0f
      009314 5B               [12]  807 	anl	a,r3
      009315 24 D9            [12]  808 	add	a, #_encoder_LUT
      009317 F5 82            [12]  809 	mov	dpl,a
      009319 E4               [12]  810 	clr	a
      00931A 34 0D            [12]  811 	addc	a,#(_encoder_LUT >> 8)
      00931C F5 83            [12]  812 	mov	dph,a
      00931E E0               [24]  813 	movx	a,@dptr
      00931F 2C               [12]  814 	add	a, r4
      009320 FC               [12]  815 	mov	r4,a
      009321 12 82 D1         [24]  816 	lcall	_ak820_outline_0118
                                    817 ;	quantum/encoder.c:239: if (encoder_pulses[i] >= resolution) {
      009324 EC               [12]  818 	mov	a,r4
      009325 33               [12]  819 	rlc	a
      009326 95 E0            [12]  820 	subb	a,acc
      009328 FB               [12]  821 	mov	r3,a
      009329 C3               [12]  822 	clr	c
      00932A EC               [12]  823 	mov	a,r4
      00932B 94 02            [12]  824 	subb	a,#0x02
      00932D EB               [12]  825 	mov	a,r3
      00932E 64 80            [12]  826 	xrl	a,#0x80
      009330 94 80            [12]  827 	subb	a,#0x80
      009332 40 1C            [24]  828 	jc	00102$
                                    829 ;	quantum/encoder.c:242: encoder_value[index]++;
      009334 EF               [12]  830 	mov	a,r7
      009335 24 EB            [12]  831 	add	a, #_encoder_value
      009337 FB               [12]  832 	mov	r3,a
      009338 E4               [12]  833 	clr	a
      009339 34 0D            [12]  834 	addc	a, #(_encoder_value >> 8)
      00933B 12 48 39         [24]  835 	lcall	_ak820_outline_0055
      00933E 0A               [12]  836 	inc	r2
      00933F 12 94 24         [24]  837 	lcall	_ak820_outline_0061
                                    838 ;	quantum/encoder.c:243: changed = true;
                                    839 ;	quantum/encoder.c:248: encoder_exec_mapping(index, ENCODER_COUNTER_CLOCKWISE);
      009342 12 79 53         [24]  840 	lcall	_ak820_outline_0183
      009345 C0 06            [24]  841 	push	ar6
      009347 C0 05            [24]  842 	push	ar5
      009349 12 92 97         [24]  843 	lcall	_encoder_exec_mapping
      00934C D0 05            [24]  844 	pop	ar5
      00934E D0 06            [24]  845 	pop	ar6
      009350                        846 00102$:
                                    847 ;	quantum/encoder.c:257: if (encoder_pulses[i] <= -resolution) { // direction is arbitrary here, but this clockwise
      009350 12 38 65         [24]  848 	lcall	_ak820_outline_0131
      009353 E0               [24]  849 	movx	a,@dptr
      009354 FF               [12]  850 	mov	r7,a
      009355 33               [12]  851 	rlc	a
      009356 95 E0            [12]  852 	subb	a,acc
      009358 FC               [12]  853 	mov	r4,a
      009359 C3               [12]  854 	clr	c
      00935A 74 FE            [12]  855 	mov	a,#0xfe
      00935C 9F               [12]  856 	subb	a,r7
      00935D 74 7F            [12]  857 	mov	a,#(0xff ^ 0x80)
      00935F 8C F0            [24]  858 	mov	b,r4
      009361 63 F0 80         [24]  859 	xrl	b,#0x80
      009364 95 F0            [12]  860 	subb	a,b
      009366 40 20            [24]  861 	jc	00104$
                                    862 ;	free result
                                    863 ;	quantum/encoder.c:259: encoder_value[index]--;
      009368 90 0B 74         [24]  864 	mov	dptr,#_encoder_update_index_10000_168
      00936B E0               [24]  865 	movx	a,@dptr
      00936C FF               [12]  866 	mov	r7,a
      00936D 24 EB            [12]  867 	add	a, #_encoder_value
      00936F FB               [12]  868 	mov	r3,a
      009370 E4               [12]  869 	clr	a
      009371 34 0D            [12]  870 	addc	a, #(_encoder_value >> 8)
      009373 12 48 39         [24]  871 	lcall	_ak820_outline_0055
      009376 1A               [12]  872 	dec	r2
      009377 12 94 24         [24]  873 	lcall	_ak820_outline_0061
                                    874 ;	quantum/encoder.c:260: changed = true;
                                    875 ;	quantum/encoder.c:265: encoder_exec_mapping(index, ENCODER_CLOCKWISE);
      00937A F0               [24]  876 	movx	@dptr,a
      00937B 8F 82            [24]  877 	mov	dpl, r7
      00937D C0 06            [24]  878 	push	ar6
      00937F C0 05            [24]  879 	push	ar5
      009381 12 92 97         [24]  880 	lcall	_encoder_exec_mapping
      009384 D0 05            [24]  881 	pop	ar5
      009386 D0 06            [24]  882 	pop	ar6
      009388                        883 00104$:
                                    884 ;	quantum/encoder.c:270: encoder_pulses[i] %= resolution;
      009388 12 38 65         [24]  885 	lcall	_ak820_outline_0131
      00938B E0               [24]  886 	movx	a,@dptr
      00938C A2 E7            [12]  887 	mov	c,acc.7
      00938E 54 01            [12]  888 	anl	a,#0x01
      009390 60 04            [24]  889 	jz	00123$
      009392 50 02            [24]  890 	jnc	00123$
      009394 44 FE            [12]  891 	orl	a,#0xfe
      009396                        892 00123$:
      009396 12 82 D1         [24]  893 	lcall	_ak820_outline_0118
                                    894 ;	quantum/encoder.c:275: return changed;
      009399 90 0B 75         [24]  895 	mov	dptr,#_encoder_update_changed_10000_169
      00939C E0               [24]  896 	movx	a,@dptr
                                    897 ;	quantum/encoder.c:276: }
      00939D F5 82            [12]  898 	mov	dpl,a
      00939F 22               [24]  899 	ret
                                    900 ;------------------------------------------------------------
                                    901 ;Allocation info for local variables in function 'encoder_read'
                                    902 ;------------------------------------------------------------
                                    903 ;changed       Allocated with name '_encoder_read_changed_10000_175'
                                    904 ;i             Allocated with name '_encoder_read_i_20000_176'
                                    905 ;new_status    Allocated with name '_encoder_read_new_status_30000_177'
                                    906 ;------------------------------------------------------------
                                    907 ;	quantum/encoder.c:278: bool encoder_read(void) {
                                    908 ;	-----------------------------------------
                                    909 ;	 function encoder_read
                                    910 ;	-----------------------------------------
      0093A0                        911 _encoder_read:
                                    912 ;	quantum/encoder.c:279: bool changed = false;
      0093A0 90 0B 76         [24]  913 	mov	dptr,#_encoder_read_changed_10000_175
      0093A3 E4               [12]  914 	clr	a
      0093A4 F0               [24]  915 	movx	@dptr,a
                                    916 ;	quantum/encoder.c:280: for (uint8_t i = 0; i < thisCount; i++) {
      0093A5 FF               [12]  917 	mov	r7,a
      0093A6                        918 00105$:
      0093A6 12 94 34         [24]  919 	lcall	_ak820_outline_0086
      0093A9 50 56            [24]  920 	jnc	00103$
                                    921 ;	quantum/encoder.c:281: uint8_t new_status = (readPin(encoders_pad_a[i]) << 0) | (readPin(encoders_pad_b[i]) << 1);
      0093AB 12 94 08         [24]  922 	lcall	_ak820_outline_0026
      0093AE 12 59 BB         [24]  923 	lcall	_readPin
      0093B1 AE 82            [24]  924 	mov	r6, dpl
      0093B3 12 94 16         [24]  925 	lcall	_ak820_outline_0027
      0093B6 12 59 BB         [24]  926 	lcall	_readPin
      0093B9 E5 82            [12]  927 	mov	a,dpl
      0093BB 25 82            [12]  928 	add	a,dpl
      0093BD 42 06            [12]  929 	orl	ar6,a
                                    930 ;	quantum/encoder.c:282: if ((encoder_state[i] & 0x3) != new_status) {
      0093BF EF               [12]  931 	mov	a,r7
      0093C0 24 E9            [12]  932 	add	a, #_encoder_state
      0093C2 FC               [12]  933 	mov	r4,a
      0093C3 E4               [12]  934 	clr	a
      0093C4 34 0D            [12]  935 	addc	a, #(_encoder_state >> 8)
      0093C6 FD               [12]  936 	mov	r5,a
      0093C7 12 43 08         [24]  937 	lcall	_ak820_outline_0091
      0093CA FB               [12]  938 	mov	r3,a
      0093CB FA               [12]  939 	mov	r2,a
      0093CC 53 02 03         [24]  940 	anl	ar2,#0x03
      0093CF 8E 01            [24]  941 	mov	ar1,r6
      0093D1 EA               [12]  942 	mov	a,r2
      0093D2 B5 01 02         [24]  943 	cjne	a,ar1,00132$
      0093D5 80 27            [24]  944 	sjmp	00106$
      0093D7                        945 00132$:
                                    946 ;	quantum/encoder.c:283: encoder_state[i] <<= 2;
      0093D7 EB               [12]  947 	mov	a,r3
      0093D8 2B               [12]  948 	add	a,r3
      0093D9 25 E0            [12]  949 	add	a,acc
      0093DB FB               [12]  950 	mov	r3,a
      0093DC 12 38 55         [24]  951 	lcall	_ak820_outline_0117
      0093DF F0               [24]  952 	movx	@dptr,a
                                    953 ;	quantum/encoder.c:284: encoder_state[i] |= new_status;
      0093E0 EB               [12]  954 	mov	a,r3
      0093E1 42 06            [12]  955 	orl	ar6,a
      0093E3 12 38 55         [24]  956 	lcall	_ak820_outline_0117
      0093E6 EE               [12]  957 	mov	a,r6
      0093E7 F0               [24]  958 	movx	@dptr,a
                                    959 ;	quantum/encoder.c:285: changed |= encoder_update(i, encoder_state[i]);
      0093E8 90 0B 73         [24]  960 	mov	dptr,#_encoder_update_PARM_2
      0093EB EE               [12]  961 	mov	a,r6
      0093EC F0               [24]  962 	movx	@dptr,a
      0093ED 8F 82            [24]  963 	mov	dpl, r7
      0093EF C0 07            [24]  964 	push	ar7
      0093F1 12 92 F3         [24]  965 	lcall	_encoder_update
      0093F4 AE 82            [24]  966 	mov	r6, dpl
      0093F6 D0 07            [24]  967 	pop	ar7
      0093F8 90 0B 76         [24]  968 	mov	dptr,#_encoder_read_changed_10000_175
      0093FB E0               [24]  969 	movx	a,@dptr
      0093FC 4E               [12]  970 	orl	a,r6
      0093FD F0               [24]  971 	movx	@dptr,a
      0093FE                        972 00106$:
                                    973 ;	quantum/encoder.c:280: for (uint8_t i = 0; i < thisCount; i++) {
      0093FE 0F               [12]  974 	inc	r7
      0093FF 80 A5            [24]  975 	sjmp	00105$
      009401                        976 00103$:
                                    977 ;	quantum/encoder.c:288: return changed;
      009401 90 0B 76         [24]  978 	mov	dptr,#_encoder_read_changed_10000_175
      009404 E0               [24]  979 	movx	a,@dptr
                                    980 ;	quantum/encoder.c:289: }
      009405 F5 82            [12]  981 	mov	dpl,a
      009407 22               [24]  982 	ret
                                    983 	.area CSEG    (CODE)
                                    984 	.area CONST   (CODE)
                                    985 	.area XINIT   (CODE)
      00C21B                        986 __xinit__encoders_pad_a:
      00C21B 39                     987 	.db #0x39	; 57	'9'
      00C21C                        988 __xinit__encoders_pad_b:
      00C21C 38                     989 	.db #0x38	; 56	'8'
      00C21D                        990 __xinit__encoder_LUT:
      00C21D 00                     991 	.db #0x00	;  0
      00C21E FF                     992 	.db #0xff	; -1
      00C21F 01                     993 	.db #0x01	;  1
      00C220 00                     994 	.db #0x00	;  0
      00C221 01                     995 	.db #0x01	;  1
      00C222 00                     996 	.db #0x00	;  0
      00C223 00                     997 	.db #0x00	;  0
      00C224 FF                     998 	.db #0xff	; -1
      00C225 FF                     999 	.db #0xff	; -1
      00C226 00                    1000 	.db #0x00	;  0
      00C227 00                    1001 	.db #0x00	;  0
      00C228 01                    1002 	.db #0x01	;  1
      00C229 00                    1003 	.db #0x00	;  0
      00C22A 01                    1004 	.db #0x01	;  1
      00C22B FF                    1005 	.db #0xff	; -1
      00C22C 00                    1006 	.db #0x00	;  0
      00C22D                       1007 __xinit__encoder_state:
      00C22D 00                    1008 	.db #0x00	; 0
      00C22E                       1009 __xinit__encoder_pulses:
      00C22E 00                    1010 	.db #0x00	;  0
      00C22F                       1011 __xinit__encoder_value:
      00C22F 00                    1012 	.db #0x00	; 0
                                   1013 	.area CABS    (ABS,CODE)
                                   1014 
                                   1015 ; Experimental exact instruction outlining.
                                   1016 	.globl _ak820_outline_0026
                                   1017 	.globl _ak820_outline_0027
                                   1018 	.globl _ak820_outline_0055
                                   1019 	.globl _ak820_outline_0058
                                   1020 	.globl _ak820_outline_0061
                                   1021 	.globl _ak820_outline_0064
                                   1022 	.globl _ak820_outline_0074
                                   1023 	.globl _ak820_outline_0086
                                   1024 	.globl _ak820_outline_0091
                                   1025 	.globl _ak820_outline_0117
                                   1026 	.globl _ak820_outline_0118
                                   1027 	.globl _ak820_outline_0130
                                   1028 	.globl _ak820_outline_0131
                                   1029 	.globl _ak820_outline_0158
                                   1030 	.globl _ak820_outline_0183
                                   1031 
                                   1032 	.area CSEG (CODE)
                                   1033 ; function ak820_outline_0026
      009408                       1034 _ak820_outline_0026:
      009408 EF               [12] 1035 	mov	a,r7
      009409 24 D7            [12] 1036 	add	a,#_encoders_pad_a
      00940B F5 82            [12] 1037 	mov	dpl,a
      00940D E4               [12] 1038 	clr	a
      00940E 34 0D            [12] 1039 	addc	a,#(_encoders_pad_a>>8)
      009410 F5 83            [12] 1040 	mov	dph,a
      009412 E0               [24] 1041 	movx	a,@dptr
      009413 F5 82            [12] 1042 	mov	dpl,a
      009415 22               [24] 1043 	ret
                                   1044 
                                   1045 	.area CSEG (CODE)
                                   1046 ; function ak820_outline_0027
      009416                       1047 _ak820_outline_0027:
      009416 EF               [12] 1048 	mov	a,r7
      009417 24 D8            [12] 1049 	add	a,#_encoders_pad_b
      009419 F5 82            [12] 1050 	mov	dpl,a
      00941B E4               [12] 1051 	clr	a
      00941C 34 0D            [12] 1052 	addc	a,#(_encoders_pad_b>>8)
      00941E F5 83            [12] 1053 	mov	dph,a
      009420 E0               [24] 1054 	movx	a,@dptr
      009421 F5 82            [12] 1055 	mov	dpl,a
      009423 22               [24] 1056 	ret
                                   1057 
                                   1058 	.area CSEG (CODE)
                                   1059 ; function ak820_outline_0061
      009424                       1060 _ak820_outline_0061:
      009424 8B 82            [24] 1061 	mov	dpl,r3
      009426 8C 83            [24] 1062 	mov	dph,r4
      009428 EA               [12] 1063 	mov	a,r2
      009429 F0               [24] 1064 	movx	@dptr,a
      00942A 90 0B 75         [24] 1065 	mov	dptr,#_encoder_update_changed_10000_169
      00942D 74 01            [12] 1066 	mov	a,#0x01
      00942F F0               [24] 1067 	movx	@dptr,a
      009430 90 0B 6B         [24] 1068 	mov	dptr,#_encoder_exec_mapping_PARM_2
      009433 22               [24] 1069 	ret
                                   1070 
                                   1071 	.area CSEG (CODE)
                                   1072 ; function ak820_outline_0086
      009434                       1073 _ak820_outline_0086:
      009434 90 0B 6A         [24] 1074 	mov	dptr,#_thisCount
      009437 E0               [24] 1075 	movx	a,@dptr
      009438 FE               [12] 1076 	mov	r6,a
      009439 C3               [12] 1077 	clr	c
      00943A EF               [12] 1078 	mov	a,r7
      00943B 9E               [12] 1079 	subb	a,r6
      00943C 22               [24] 1080 	ret
