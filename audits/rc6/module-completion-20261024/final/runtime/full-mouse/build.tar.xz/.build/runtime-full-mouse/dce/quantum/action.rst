                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _register_mouse
                                     12 	.globl _ak820_combo_cancel
                                     13 	.globl _ak820_combo_tick
                                     14 	.globl _ak820_oneshot_cancel
                                     15 	.globl _ak820_oneshot_post
                                     16 	.globl _ak820_oneshot_process
                                     17 	.globl _ak820_tapping_source
                                     18 	.globl _ak820_tapping_cancel
                                     19 	.globl _ak820_tapping_process
                                     20 	.globl _ak820_tapping_before
                                     21 	.globl _pre_process_record_quantum
                                     22 	.globl _get_record_keycode
                                     23 	.globl _repeat_key_cancel
                                     24 	.globl _clear_owned_usages
                                     25 	.globl _owned_usage_key
                                     26 	.globl _clear_owned_keys
                                     27 	.globl _del_owned_key
                                     28 	.globl _add_owned_key
                                     29 	.globl _clear_owned_mods
                                     30 	.globl _del_owned_weak_mods
                                     31 	.globl _add_owned_weak_mods
                                     32 	.globl _del_owned_mods
                                     33 	.globl _add_owned_mods
                                     34 	.globl _clear_weak_mods
                                     35 	.globl _clear_mods
                                     36 	.globl _send_keyboard_report
                                     37 	.globl _layer_hold_clear
                                     38 	.globl _layer_hold_off
                                     39 	.globl _layer_hold_on
                                     40 	.globl _ak820_resolve_key
                                     41 	.globl _layer_xor
                                     42 	.globl _layer_and
                                     43 	.globl _layer_or
                                     44 	.globl _layer_off
                                     45 	.globl _layer_on
                                     46 	.globl _layer_move
                                     47 	.globl _layer_clear
                                     48 	.globl _layer_state_set
                                     49 	.globl _default_layer_xor
                                     50 	.globl _default_layer_and
                                     51 	.globl _default_layer_or
                                     52 	.globl _default_layer_set
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mousekey_send
                                     56 	.globl _mousekey_clear
                                     57 	.globl _mousekey_off
                                     58 	.globl _mousekey_on
                                     59 	.globl _mDelaymS
                                     60 	.globl _host_consumer_send
                                     61 	.globl _host_system_send
                                     62 	.globl _host_keyboard_leds
                                     63 	.globl _led_set
                                     64 	.globl _clear_keys_from_report
                                     65 	.globl ___memcpy
                                     66 	.globl _ADC_START
                                     67 	.globl _S0_R_FIFO
                                     68 	.globl _S0_T_FIFO
                                     69 	.globl _S0_FREE
                                     70 	.globl _S0_IF_BYTE
                                     71 	.globl _S0_IF_FIRST
                                     72 	.globl _S0_IF_OV
                                     73 	.globl _S0_FST_ACT
                                     74 	.globl _CP_RL2
                                     75 	.globl _C_T2
                                     76 	.globl _TR2
                                     77 	.globl _EXEN2
                                     78 	.globl _TCLK
                                     79 	.globl _RCLK
                                     80 	.globl _EXF2
                                     81 	.globl _CAP1F
                                     82 	.globl _TF2
                                     83 	.globl _RI
                                     84 	.globl _TI
                                     85 	.globl _RB8
                                     86 	.globl _TB8
                                     87 	.globl _REN
                                     88 	.globl _SM2
                                     89 	.globl _SM1
                                     90 	.globl _SM0
                                     91 	.globl _IT0
                                     92 	.globl _IE0
                                     93 	.globl _IT1
                                     94 	.globl _IE1
                                     95 	.globl _TR0
                                     96 	.globl _TF0
                                     97 	.globl _TR1
                                     98 	.globl _TF1
                                     99 	.globl _P4_0
                                    100 	.globl _P4_1
                                    101 	.globl _P4_2
                                    102 	.globl _P4_3
                                    103 	.globl _P4_4
                                    104 	.globl _P4_5
                                    105 	.globl _P4_6
                                    106 	.globl _RXD
                                    107 	.globl _TXD
                                    108 	.globl _INT0
                                    109 	.globl _INT1
                                    110 	.globl _T0
                                    111 	.globl _T1
                                    112 	.globl _MOSI1
                                    113 	.globl _MISO1
                                    114 	.globl _SCK1
                                    115 	.globl _P3_0
                                    116 	.globl _P3_1
                                    117 	.globl _P3_2
                                    118 	.globl _P3_3
                                    119 	.globl _P3_4
                                    120 	.globl _P3_5
                                    121 	.globl _P3_6
                                    122 	.globl _P3_7
                                    123 	.globl _CAP1_
                                    124 	.globl _T2_
                                    125 	.globl _CAP2_
                                    126 	.globl _T2EX_
                                    127 	.globl _RXD1
                                    128 	.globl _TXD1
                                    129 	.globl _P2_0
                                    130 	.globl _P2_1
                                    131 	.globl _P2_2
                                    132 	.globl _P2_3
                                    133 	.globl _P2_4
                                    134 	.globl _P2_5
                                    135 	.globl _P2_6
                                    136 	.globl _P2_7
                                    137 	.globl _AIN0
                                    138 	.globl _AIN1
                                    139 	.globl _AIN2
                                    140 	.globl _AIN3
                                    141 	.globl _AIN4
                                    142 	.globl _AIN5
                                    143 	.globl _AIN6
                                    144 	.globl _AIN7
                                    145 	.globl _CAP1
                                    146 	.globl _T2
                                    147 	.globl _CAP2
                                    148 	.globl _T2EX
                                    149 	.globl _INT0_
                                    150 	.globl _SCS
                                    151 	.globl _MOSI
                                    152 	.globl _MISO
                                    153 	.globl _SCK
                                    154 	.globl _RXD1_
                                    155 	.globl _TXD1_
                                    156 	.globl _P1_0
                                    157 	.globl _P1_1
                                    158 	.globl _P1_2
                                    159 	.globl _P1_3
                                    160 	.globl _P1_4
                                    161 	.globl _P1_5
                                    162 	.globl _P1_6
                                    163 	.globl _P1_7
                                    164 	.globl _AIN8
                                    165 	.globl _AIN9
                                    166 	.globl _AIN10
                                    167 	.globl _AIN11
                                    168 	.globl _AIN12
                                    169 	.globl _AIN13
                                    170 	.globl _RXD_
                                    171 	.globl _TXD_
                                    172 	.globl _SCL0
                                    173 	.globl _SDA0
                                    174 	.globl _P0_0
                                    175 	.globl _P0_1
                                    176 	.globl _P0_2
                                    177 	.globl _P0_3
                                    178 	.globl _P0_4
                                    179 	.globl _P0_5
                                    180 	.globl _P0_6
                                    181 	.globl _P0_7
                                    182 	.globl _IE_SPI0
                                    183 	.globl _IE_USB
                                    184 	.globl _IE_ADC
                                    185 	.globl _IE_UART1
                                    186 	.globl _IE_PWM_I2C
                                    187 	.globl _IE_GPIO
                                    188 	.globl _IE_WDOG
                                    189 	.globl _PX0
                                    190 	.globl _PT0
                                    191 	.globl _PX1
                                    192 	.globl _PT1
                                    193 	.globl _PS
                                    194 	.globl _PT2
                                    195 	.globl _PL_FLAG
                                    196 	.globl _PH_FLAG
                                    197 	.globl _EX0
                                    198 	.globl _ET0
                                    199 	.globl _EX1
                                    200 	.globl _ET1
                                    201 	.globl _ES
                                    202 	.globl _ET2
                                    203 	.globl _E_DIS
                                    204 	.globl _EA
                                    205 	.globl _P
                                    206 	.globl _F1
                                    207 	.globl _OV
                                    208 	.globl _RS0
                                    209 	.globl _RS1
                                    210 	.globl _F0
                                    211 	.globl _AC
                                    212 	.globl _CY
                                    213 	.globl _I2CS_INT_ST
                                    214 	.globl _I2CX_INT
                                    215 	.globl _LED_STATUS
                                    216 	.globl _LED_DMA_H
                                    217 	.globl _LED_DMA_L
                                    218 	.globl _LED_DMA
                                    219 	.globl _LED_PWM_OE
                                    220 	.globl _LED_COMMON
                                    221 	.globl _ADC_CHAN
                                    222 	.globl _ADC_DAT_H
                                    223 	.globl _ADC_DAT_L
                                    224 	.globl _ADC_DAT
                                    225 	.globl _ADC_CTRL
                                    226 	.globl _SPI1_CK_SE
                                    227 	.globl _SPI1_CTRL
                                    228 	.globl _SPI1_DATA
                                    229 	.globl _SPI1_STAT
                                    230 	.globl _SIF1
                                    231 	.globl _SBAUD1
                                    232 	.globl _SBUF1
                                    233 	.globl _SCON1
                                    234 	.globl _SPI0_SETUP
                                    235 	.globl _SPI0_CK_SE
                                    236 	.globl _SPI0_CTRL
                                    237 	.globl _SPI0_DATA
                                    238 	.globl _SPI0_STAT
                                    239 	.globl _T2CAP1H
                                    240 	.globl _T2CAP1L
                                    241 	.globl _T2CAP1
                                    242 	.globl _TH2
                                    243 	.globl _TL2
                                    244 	.globl _T2COUNT
                                    245 	.globl _RCAP2H
                                    246 	.globl _RCAP2L
                                    247 	.globl _RCAP2
                                    248 	.globl _T2MOD
                                    249 	.globl _T2CON
                                    250 	.globl _SBUF
                                    251 	.globl _SCON
                                    252 	.globl _TH1
                                    253 	.globl _TH0
                                    254 	.globl _TL1
                                    255 	.globl _TL0
                                    256 	.globl _TMOD
                                    257 	.globl _TCON
                                    258 	.globl _XBUS_AUX
                                    259 	.globl _P7
                                    260 	.globl _P6_DIR
                                    261 	.globl _P6_OUT_PU
                                    262 	.globl _P6_IN
                                    263 	.globl _P5_DIR
                                    264 	.globl _P5_OUT_PU
                                    265 	.globl _P5_IN
                                    266 	.globl _P4_LED_KEY
                                    267 	.globl _P4_DIR_PU
                                    268 	.globl _P4_MOD_OC
                                    269 	.globl _P4
                                    270 	.globl _P3_DIR_PU
                                    271 	.globl _P3_MOD_OC
                                    272 	.globl _P3
                                    273 	.globl _P2_DIR_PU
                                    274 	.globl _P2_MOD_OC
                                    275 	.globl _P2
                                    276 	.globl _P1_DIR_PU
                                    277 	.globl _P1_MOD_OC
                                    278 	.globl _P1
                                    279 	.globl _P0_DIR_PU
                                    280 	.globl _P0_MOD_OC
                                    281 	.globl _P0
                                    282 	.globl _ROM_CTRL
                                    283 	.globl _ROM_DATA_HH
                                    284 	.globl _ROM_DATA_HL
                                    285 	.globl _ROM_DATA_HI
                                    286 	.globl _ROM_ADDR_H
                                    287 	.globl _ROM_ADDR_L
                                    288 	.globl _ROM_ADDR
                                    289 	.globl _GPIO_IE
                                    290 	.globl _IP_EX
                                    291 	.globl _IE_EX
                                    292 	.globl _IP
                                    293 	.globl _IE
                                    294 	.globl _WDOG_COUNT
                                    295 	.globl _RESET_KEEP
                                    296 	.globl _WAKE_CTRL
                                    297 	.globl _CLOCK_CFG
                                    298 	.globl _POWER_CFG
                                    299 	.globl _PCON
                                    300 	.globl _GLOBAL_CFG
                                    301 	.globl _SAFE_MOD
                                    302 	.globl _DPH
                                    303 	.globl _DPL
                                    304 	.globl _SP
                                    305 	.globl _A_INV
                                    306 	.globl _B
                                    307 	.globl _ACC
                                    308 	.globl _PSW
                                    309 	.globl _disable_action_cache
                                    310 	.globl _tap_code_delay_PARM_2
                                    311 	.globl _process_action_PARM_2
                                    312 	.globl _register_mouse_PARM_2
                                    313 	.globl _action_exec_PARM_1
                                    314 	.globl _tp_buttons
                                    315 	.globl _action_exec
                                    316 	.globl _ak820_action_exec
                                    317 	.globl _process_record
                                    318 	.globl _process_record_handler
                                    319 	.globl _process_action
                                    320 	.globl _register_code
                                    321 	.globl _unregister_code
                                    322 	.globl _tap_code_delay
                                    323 	.globl _tap_code
                                    324 	.globl _register_mods
                                    325 	.globl _unregister_mods
                                    326 	.globl _register_weak_mods
                                    327 	.globl _unregister_weak_mods
                                    328 	.globl _clear_keyboard
                                    329 	.globl _clear_keyboard_but_mods
                                    330 	.globl _clear_keyboard_but_mods_and_keys
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      000026                        593 _process_action_sloc0_1_0:
      000026                        594 	.ds 1
                                    595 ;--------------------------------------------------------
                                    596 ; overlayable items in internal ram
                                    597 ;--------------------------------------------------------
                                    598 ;--------------------------------------------------------
                                    599 ; indirectly addressable internal ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area ISEG    (DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; absolute internal ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area IABS    (ABS,DATA)
                                    606 	.area IABS    (ABS,DATA)
                                    607 ;--------------------------------------------------------
                                    608 ; bit data
                                    609 ;--------------------------------------------------------
                                    610 	.area BSEG    (BIT)
      00001D                        611 _process_action_sloc1_1_0:
      00001D                        612 	.ds 1
                                    613 ;--------------------------------------------------------
                                    614 ; paged external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area PSEG    (PAG,XDATA)
                                    617 ;--------------------------------------------------------
                                    618 ; uninitialized external ram data
                                    619 ;--------------------------------------------------------
                                    620 	.area XSEG    (XDATA)
      000826                        621 _tp_buttons::
      000826                        622 	.ds 2
      000828                        623 _action_exec_PARM_1:
      000828                        624 	.ds 6
      00082E                        625 _action_exec_record_10001_625:
      00082E                        626 	.ds 9
      000837                        627 _ak820_action_exec_event_10000_629:
      000837                        628 	.ds 2
      000839                        629 _ak820_action_exec_snapshot_10000_630:
      000839                        630 	.ds 6
      00083F                        631 _process_record_record_argument_10000_633:
      00083F                        632 	.ds 2
      000841                        633 _process_record_handler_record_argument_10000_641:
      000841                        634 	.ds 2
      000843                        635 _process_record_handler_action_10000_642:
      000843                        636 	.ds 2
      000845                        637 _register_mouse_PARM_2:
      000845                        638 	.ds 1
      000846                        639 _register_mouse_mouse_keycode_10000_650:
      000846                        640 	.ds 1
      000847                        641 _process_action_PARM_2:
      000847                        642 	.ds 2
      000849                        643 _process_action_record_argument_10000_657:
      000849                        644 	.ds 2
      00084B                        645 _process_action_on_40000_680:
      00084B                        646 	.ds 1
      00084C                        647 _register_code_code_10000_714:
      00084C                        648 	.ds 1
      00084D                        649 _unregister_code_code_10000_728:
      00084D                        650 	.ds 1
      00084E                        651 _tap_code_delay_PARM_2:
      00084E                        652 	.ds 2
      000850                        653 _tap_code_delay_code_10000_741:
      000850                        654 	.ds 1
      000851                        655 _tap_code_code_10000_748:
      000851                        656 	.ds 1
      000852                        657 _register_mods_mods_10000_750:
      000852                        658 	.ds 1
      000853                        659 _unregister_mods_mods_10000_754:
      000853                        660 	.ds 1
      000854                        661 _register_weak_mods_mods_10000_758:
      000854                        662 	.ds 1
      000855                        663 _unregister_weak_mods_mods_10000_762:
      000855                        664 	.ds 1
                                    665 ;--------------------------------------------------------
                                    666 ; absolute external ram data
                                    667 ;--------------------------------------------------------
                                    668 	.area XABS    (ABS,XDATA)
                                    669 ;--------------------------------------------------------
                                    670 ; initialized external ram data
                                    671 ;--------------------------------------------------------
                                    672 	.area XISEG   (XDATA)
      000DAE                        673 _disable_action_cache::
      000DAE                        674 	.ds 1
                                    675 	.area HOME    (CODE)
                                    676 	.area GSINIT0 (CODE)
                                    677 	.area GSINIT1 (CODE)
                                    678 	.area GSINIT2 (CODE)
                                    679 	.area GSINIT3 (CODE)
                                    680 	.area GSINIT4 (CODE)
                                    681 	.area GSINIT5 (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 	.area GSFINAL (CODE)
                                    684 	.area CSEG    (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; global & static initialisations
                                    687 ;--------------------------------------------------------
                                    688 	.area HOME    (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area GSINIT  (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; Home
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area HOME    (CODE)
                                    697 ;--------------------------------------------------------
                                    698 ; code
                                    699 ;--------------------------------------------------------
                                    700 	.area CSEG    (CODE)
                                    701 ;------------------------------------------------------------
                                    702 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    703 ;------------------------------------------------------------
                                    704 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    705 ;------------------------------------------------------------
                                    706 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    707 ;	-----------------------------------------
                           000007   708 	ar7 = 0x07
                           000006   709 	ar6 = 0x06
                           000005   710 	ar5 = 0x05
                           000004   711 	ar4 = 0x04
                           000003   712 	ar3 = 0x03
                           000002   713 	ar2 = 0x02
                           000001   714 	ar1 = 0x01
                           000000   715 	ar0 = 0x00
                                    716 ;	 function action_exec
                                    717 ;	-----------------------------------------
      007224                        718 _action_exec:
                                    719 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      007224 90 08 2A         [24]  720 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007227 12 37 A1         [24]  721 	lcall	_ak820_outline_0004
      00722A 12 35 B8         [24]  722 	lcall	_ak820_combo_tick
                                    723 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      00722D 90 08 28         [24]  724 	mov	dptr,#_action_exec_PARM_1
      007230 12 44 25         [24]  725 	lcall	_ak820_tapping_before
      007233 E5 82            [12]  726 	mov	a, dpl
      007235 70 01            [24]  727 	jnz	00102$
      007237 22               [24]  728 	ret
      007238                        729 00102$:
                                    730 ;	quantum/action.c:126: if (event.pressed) {
      007238 90 08 2D         [24]  731 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00723B E0               [24]  732 	movx	a,@dptr
      00723C 60 03            [24]  733 	jz	00104$
                                    734 ;	quantum/action.c:128: clear_weak_mods();
      00723E 12 82 96         [24]  735 	lcall	_clear_weak_mods
      007241                        736 00104$:
                                    737 ;	quantum/action.c:140: record.event = event;
      007241 90 0D 8E         [24]  738 	mov	dptr,#___memcpy_PARM_2
      007244 74 28            [12]  739 	mov	a,#_action_exec_PARM_1
      007246 F0               [24]  740 	movx	@dptr,a
      007247 74 08            [12]  741 	mov	a,#(_action_exec_PARM_1 >> 8)
      007249 12 79 09         [24]  742 	lcall	_ak820_outline_0049
      00724C 12 79 29         [24]  743 	lcall	_ak820_outline_0107
      00724F 90 08 2E         [24]  744 	mov	dptr,#_action_exec_record_10001_625
      007252 F5 F0            [12]  745 	mov	b,a
      007254 12 B8 D1         [24]  746 	lcall	___memcpy
                                    747 ;	quantum/action.c:142: record.tap.count = 0;
      007257 90 08 34         [24]  748 	mov	dptr,#(_action_exec_record_10001_625 + 0x0006)
      00725A E0               [24]  749 	movx	a,@dptr
      00725B 54 0F            [12]  750 	anl	a,#0x0f
      00725D F0               [24]  751 	movx	@dptr,a
                                    752 ;	quantum/action.c:147: record.keycode = 0;
      00725E 90 08 35         [24]  753 	mov	dptr,#(_action_exec_record_10001_625 + 0x0007)
      007261 12 4F 0B         [24]  754 	lcall	_ak820_outline_0165
                                    755 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007264 90 08 32         [24]  756 	mov	dptr,#(_action_exec_record_10001_625 + 0x0004)
      007267 E0               [24]  757 	movx	a,@dptr
      007268 60 0A            [24]  758 	jz	00107$
      00726A 90 08 2E         [24]  759 	mov	dptr,#_action_exec_record_10001_625
      00726D 12 9F FA         [24]  760 	lcall	_pre_process_record_quantum
      007270 E5 82            [12]  761 	mov	a, dpl
      007272 60 11            [24]  762 	jz	00110$
      007274                        763 00107$:
                                    764 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      007274 90 08 2E         [24]  765 	mov	dptr,#_action_exec_record_10001_625
      007277 12 45 11         [24]  766 	lcall	_ak820_tapping_process
      00727A E5 82            [12]  767 	mov	a, dpl
      00727C 70 01            [24]  768 	jnz	00106$
      00727E 22               [24]  769 	ret
      00727F                        770 00106$:
                                    771 ;	quantum/action.c:185: process_record(&record);
      00727F 90 08 2E         [24]  772 	mov	dptr,#_action_exec_record_10001_625
                                    773 ;	quantum/action.c:200: }
      007282 02 72 C3         [24]  774 	ljmp	_process_record
      007285                        775 00110$:
      007285 22               [24]  776 	ret
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'ak820_action_exec'
                                    779 ;------------------------------------------------------------
                                    780 ;event         Allocated with name '_ak820_action_exec_event_10000_629'
                                    781 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_630'
                                    782 ;------------------------------------------------------------
                                    783 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    784 ;	-----------------------------------------
                                    785 ;	 function ak820_action_exec
                                    786 ;	-----------------------------------------
      007286                        787 _ak820_action_exec:
      007286 12 38 44         [24]  788 	lcall	_ak820_outline_0103
      007289 90 08 37         [24]  789 	mov	dptr,#_ak820_action_exec_event_10000_629
      00728C 12 38 49         [24]  790 	lcall	_ak820_outline_0104
                                    791 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      00728F 90 08 37         [24]  792 	mov	dptr,#_ak820_action_exec_event_10000_629
      007292 12 38 18         [24]  793 	lcall	_ak820_outline_0057
      007295 90 0D 8E         [24]  794 	mov	dptr,#___memcpy_PARM_2
      007298 ED               [12]  795 	mov	a,r5
      007299 12 37 E0         [24]  796 	lcall	_ak820_outline_0015
      00729C 90 0D 91         [24]  797 	mov	dptr,#___memcpy_PARM_3
      00729F 12 79 29         [24]  798 	lcall	_ak820_outline_0107
      0072A2 90 08 39         [24]  799 	mov	dptr,#_ak820_action_exec_snapshot_10000_630
      0072A5 F5 F0            [12]  800 	mov	b,a
      0072A7 12 B8 D1         [24]  801 	lcall	___memcpy
                                    802 ;	quantum/action.c:207: action_exec(snapshot);
      0072AA 90 0D 8E         [24]  803 	mov	dptr,#___memcpy_PARM_2
      0072AD 74 39            [12]  804 	mov	a,#_ak820_action_exec_snapshot_10000_630
      0072AF F0               [24]  805 	movx	@dptr,a
      0072B0 74 08            [12]  806 	mov	a,#(_ak820_action_exec_snapshot_10000_630 >> 8)
      0072B2 12 79 09         [24]  807 	lcall	_ak820_outline_0049
      0072B5 12 79 29         [24]  808 	lcall	_ak820_outline_0107
      0072B8 90 08 28         [24]  809 	mov	dptr,#_action_exec_PARM_1
      0072BB F5 F0            [12]  810 	mov	b,a
      0072BD 12 B8 D1         [24]  811 	lcall	___memcpy
                                    812 ;	quantum/action.c:208: }
      0072C0 02 72 24         [24]  813 	ljmp	_action_exec
                                    814 ;------------------------------------------------------------
                                    815 ;Allocation info for local variables in function 'process_record_nocache'
                                    816 ;------------------------------------------------------------
                                    817 ;record        Allocated with name '_process_record_nocache_record_10000_631'
                                    818 ;------------------------------------------------------------
                                    819 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    820 ;	-----------------------------------------
                                    821 ;	 function process_record
                                    822 ;	-----------------------------------------
      0072C3                        823 _process_record:
      0072C3 12 38 44         [24]  824 	lcall	_ak820_outline_0103
      0072C6 90 08 3F         [24]  825 	mov	dptr,#_process_record_record_argument_10000_633
      0072C9 12 38 49         [24]  826 	lcall	_ak820_outline_0104
                                    827 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0072CC 90 08 3F         [24]  828 	mov	dptr,#_process_record_record_argument_10000_633
      0072CF 12 38 01         [24]  829 	lcall	_ak820_outline_0050
                                    830 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      0072D2 74 04            [12]  831 	mov	a,#0x04
      0072D4 12 47 E7         [24]  832 	lcall	_ak820_outline_0011
      0072D7 70 01            [24]  833 	jnz	00102$
                                    834 ;	quantum/action.c:354: return;
      0072D9 22               [24]  835 	ret
      0072DA                        836 00102$:
                                    837 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0072DA 8E 04            [24]  838 	mov	ar4,r6
      0072DC 8F 05            [24]  839 	mov	ar5,r7
      0072DE 90 0D 8E         [24]  840 	mov	dptr,#___memcpy_PARM_2
      0072E1 EC               [12]  841 	mov	a,r4
      0072E2 F0               [24]  842 	movx	@dptr,a
      0072E3 ED               [12]  843 	mov	a,r5
      0072E4 12 79 09         [24]  844 	lcall	_ak820_outline_0049
      0072E7 12 4E FD         [24]  845 	lcall	_ak820_outline_0106
      0072EA 90 06 20         [24]  846 	mov	dptr,#_ak820_tapping_source_PARM_1
      0072ED F5 F0            [12]  847 	mov	b,a
      0072EF C0 07            [24]  848 	push	ar7
      0072F1 C0 06            [24]  849 	push	ar6
      0072F3 12 B8 D1         [24]  850 	lcall	___memcpy
      0072F6 12 43 61         [24]  851 	lcall	_ak820_tapping_source
      0072F9 AD 82            [24]  852 	mov	r5, dpl
      0072FB D0 06            [24]  853 	pop	ar6
      0072FD D0 07            [24]  854 	pop	ar7
                                    855 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      0072FF 12 42 C5         [24]  856 	lcall	_ak820_outline_0010
      007302 E0               [24]  857 	movx	a,@dptr
      007303 FC               [12]  858 	mov	r4,a
                                    859 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      007304 74 07            [12]  860 	mov	a,#0x07
      007306 2E               [12]  861 	add	a, r6
      007307 FA               [12]  862 	mov	r2,a
      007308 E4               [12]  863 	clr	a
      007309 3F               [12]  864 	addc	a, r7
      00730A FB               [12]  865 	mov	r3,a
      00730B 90 0B F0         [24]  866 	mov	dptr,#_get_record_keycode_PARM_2
      00730E 12 48 31         [24]  867 	lcall	_ak820_outline_0054
      007311 C0 07            [24]  868 	push	ar7
      007313 C0 06            [24]  869 	push	ar6
      007315 C0 05            [24]  870 	push	ar5
      007317 C0 04            [24]  871 	push	ar4
      007319 C0 03            [24]  872 	push	ar3
      00731B C0 02            [24]  873 	push	ar2
      00731D 12 9F BC         [24]  874 	lcall	_get_record_keycode
      007320 A8 82            [24]  875 	mov	r0, dpl
      007322 A9 83            [24]  876 	mov	r1, dph
      007324 D0 02            [24]  877 	pop	ar2
      007326 D0 03            [24]  878 	pop	ar3
      007328 D0 04            [24]  879 	pop	ar4
      00732A D0 05            [24]  880 	pop	ar5
      00732C D0 06            [24]  881 	pop	ar6
      00732E D0 07            [24]  882 	pop	ar7
      007330 12 43 3C         [24]  883 	lcall	_ak820_outline_0141
      007333 E8               [12]  884 	mov	a,r0
      007334 F0               [24]  885 	movx	@dptr,a
      007335 E9               [12]  886 	mov	a,r1
      007336 A3               [24]  887 	inc	dptr
      007337 F0               [24]  888 	movx	@dptr,a
                                    889 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007338 74 07            [12]  890 	mov	a,#0x07
      00733A 12 37 E8         [24]  891 	lcall	_ak820_outline_0016
      00733D FA               [12]  892 	mov	r2,a
      00733E A3               [24]  893 	inc	dptr
      00733F E0               [24]  894 	movx	a,@dptr
      007340 FB               [12]  895 	mov	r3,a
      007341 90 06 30         [24]  896 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007344 ED               [12]  897 	mov	a,r5
      007345 F0               [24]  898 	movx	@dptr,a
      007346 90 06 31         [24]  899 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007349 EC               [12]  900 	mov	a,r4
      00734A F0               [24]  901 	movx	@dptr,a
      00734B 12 43 3C         [24]  902 	lcall	_ak820_outline_0141
      00734E C0 07            [24]  903 	push	ar7
      007350 C0 06            [24]  904 	push	ar6
      007352 C0 05            [24]  905 	push	ar5
      007354 C0 04            [24]  906 	push	ar4
      007356 12 46 B1         [24]  907 	lcall	_ak820_oneshot_process
      007359 E5 82            [12]  908 	mov	a, dpl
      00735B D0 04            [24]  909 	pop	ar4
      00735D D0 05            [24]  910 	pop	ar5
      00735F D0 06            [24]  911 	pop	ar6
      007361 D0 07            [24]  912 	pop	ar7
      007363 70 01            [24]  913 	jnz	00104$
      007365 22               [24]  914 	ret
      007366                        915 00104$:
                                    916 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      007366 12 43 20         [24]  917 	lcall	_ak820_outline_0116
      007369 C0 07            [24]  918 	push	ar7
      00736B C0 06            [24]  919 	push	ar6
      00736D C0 05            [24]  920 	push	ar5
      00736F C0 04            [24]  921 	push	ar4
      007371 12 A0 3C         [24]  922 	lcall	_process_record_quantum
      007374 E5 82            [12]  923 	mov	a, dpl
      007376 D0 04            [24]  924 	pop	ar4
      007378 D0 05            [24]  925 	pop	ar5
      00737A D0 06            [24]  926 	pop	ar6
      00737C D0 07            [24]  927 	pop	ar7
      00737E 70 0A            [24]  928 	jnz	00106$
                                    929 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007380 90 05 98         [24]  930 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007383 EC               [12]  931 	mov	a,r4
      007384 F0               [24]  932 	movx	@dptr,a
      007385 8D 82            [24]  933 	mov	dpl, r5
                                    934 ;	quantum/action.c:376: return;
      007387 02 2E BB         [24]  935 	ljmp	_ak820_oneshot_post
      00738A                        936 00106$:
                                    937 ;	quantum/action.c:382: process_record_handler(record);
      00738A 12 43 20         [24]  938 	lcall	_ak820_outline_0116
      00738D C0 05            [24]  939 	push	ar5
      00738F C0 04            [24]  940 	push	ar4
      007391 12 73 A2         [24]  941 	lcall	_process_record_handler
      007394 D0 04            [24]  942 	pop	ar4
      007396 D0 05            [24]  943 	pop	ar5
                                    944 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007398 90 05 98         [24]  945 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00739B EC               [12]  946 	mov	a,r4
      00739C F0               [24]  947 	movx	@dptr,a
      00739D 8D 82            [24]  948 	mov	dpl, r5
                                    949 ;	quantum/action.c:392: }
      00739F 02 2E BB         [24]  950 	ljmp	_ak820_oneshot_post
                                    951 ;------------------------------------------------------------
                                    952 ;Allocation info for local variables in function 'process_record_handler'
                                    953 ;------------------------------------------------------------
                                    954 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_641'
                                    955 ;record        Allocated with name '_process_record_handler_record_10000_642'
                                    956 ;action        Allocated with name '_process_record_handler_action_10000_642'
                                    957 ;------------------------------------------------------------
                                    958 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    959 ;	-----------------------------------------
                                    960 ;	 function process_record_handler
                                    961 ;	-----------------------------------------
      0073A2                        962 _process_record_handler:
      0073A2 12 38 44         [24]  963 	lcall	_ak820_outline_0103
      0073A5 90 08 41         [24]  964 	mov	dptr,#_process_record_handler_record_argument_10000_641
      0073A8 12 38 49         [24]  965 	lcall	_ak820_outline_0104
                                    966 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0073AB 90 08 41         [24]  967 	mov	dptr,#_process_record_handler_record_argument_10000_641
      0073AE 12 37 B8         [24]  968 	lcall	_ak820_outline_0008
                                    969 ;	quantum/action.c:405: if (record->keycode) {
      0073B1 4C               [12]  970 	orl	a,r4
      0073B2 60 19            [24]  971 	jz	00102$
                                    972 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      0073B4 12 38 55         [24]  973 	lcall	_ak820_outline_0117
      0073B7 C0 07            [24]  974 	push	ar7
      0073B9 C0 06            [24]  975 	push	ar6
      0073BB 12 96 8D         [24]  976 	lcall	_action_for_keycode
      0073BE 12 43 41         [24]  977 	lcall	_ak820_outline_0147
      0073C1 D0 06            [24]  978 	pop	ar6
      0073C3 D0 07            [24]  979 	pop	ar7
      0073C5 90 08 43         [24]  980 	mov	dptr,#_process_record_handler_action_10000_642
      0073C8 12 38 26         [24]  981 	lcall	_ak820_outline_0070
      0073CB 80 2B            [24]  982 	sjmp	00104$
      0073CD                        983 00102$:
                                    984 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0073CD 12 78 F1         [24]  985 	lcall	_ak820_outline_0019
      0073D0 7A 00            [12]  986 	mov	r2,#0x00
      0073D2 12 43 36         [24]  987 	lcall	_ak820_outline_0140
      0073D5 12 42 C5         [24]  988 	lcall	_ak820_outline_0010
      0073D8 E0               [24]  989 	movx	a,@dptr
      0073D9 90 09 80         [24]  990 	mov	dptr,#_ak820_resolve_key_PARM_2
      0073DC F0               [24]  991 	movx	@dptr,a
      0073DD 8D 82            [24]  992 	mov	dpl, r5
      0073DF 8C 83            [24]  993 	mov	dph, r4
      0073E1 C0 07            [24]  994 	push	ar7
      0073E3 C0 06            [24]  995 	push	ar6
      0073E5 12 7C 93         [24]  996 	lcall	_ak820_resolve_key
      0073E8 12 96 8D         [24]  997 	lcall	_action_for_keycode
      0073EB 12 43 41         [24]  998 	lcall	_ak820_outline_0147
      0073EE D0 06            [24]  999 	pop	ar6
      0073F0 D0 07            [24] 1000 	pop	ar7
      0073F2 90 08 43         [24] 1001 	mov	dptr,#_process_record_handler_action_10000_642
      0073F5 12 38 26         [24] 1002 	lcall	_ak820_outline_0070
                                   1003 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      0073F8                       1004 00104$:
                                   1005 ;	quantum/action.c:429: process_action(record, action);
      0073F8 90 0D 8E         [24] 1006 	mov	dptr,#___memcpy_PARM_2
      0073FB 74 43            [12] 1007 	mov	a,#_process_record_handler_action_10000_642
      0073FD F0               [24] 1008 	movx	@dptr,a
      0073FE 74 08            [12] 1009 	mov	a,#(_process_record_handler_action_10000_642 >> 8)
      007400 12 79 09         [24] 1010 	lcall	_ak820_outline_0049
      007403 12 4E FD         [24] 1011 	lcall	_ak820_outline_0106
      007406 90 08 47         [24] 1012 	mov	dptr,#_process_action_PARM_2
      007409 F5 F0            [12] 1013 	mov	b,a
      00740B C0 07            [24] 1014 	push	ar7
      00740D C0 06            [24] 1015 	push	ar6
      00740F 12 B8 D1         [24] 1016 	lcall	___memcpy
      007412 D0 06            [24] 1017 	pop	ar6
      007414 D0 07            [24] 1018 	pop	ar7
      007416 12 43 20         [24] 1019 	lcall	_ak820_outline_0116
                                   1020 ;	quantum/action.c:430: }
      007419 02 74 3F         [24] 1021 	ljmp	_process_action
                                   1022 ;------------------------------------------------------------
                                   1023 ;Allocation info for local variables in function 'register_mouse'
                                   1024 ;------------------------------------------------------------
                                   1025 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1026 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_650'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function register_mouse
                                   1031 ;	-----------------------------------------
      00741C                       1032 _register_mouse:
      00741C E5 82            [12] 1033 	mov	a,dpl
      00741E 90 08 46         [24] 1034 	mov	dptr,#_register_mouse_mouse_keycode_10000_650
      007421 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	quantum/action.c:445: if (pressed) {
      007422 90 08 45         [24] 1037 	mov	dptr,#_register_mouse_PARM_2
      007425 E0               [24] 1038 	movx	a,@dptr
      007426 60 0B            [24] 1039 	jz	00102$
                                   1040 ;	quantum/action.c:446: mousekey_on(mouse_keycode);
      007428 90 08 46         [24] 1041 	mov	dptr,#_register_mouse_mouse_keycode_10000_650
      00742B E0               [24] 1042 	movx	a,@dptr
      00742C F5 82            [12] 1043 	mov	dpl,a
      00742E 12 4F 5B         [24] 1044 	lcall	_mousekey_on
      007431 80 09            [24] 1045 	sjmp	00103$
      007433                       1046 00102$:
                                   1047 ;	quantum/action.c:448: mousekey_off(mouse_keycode);
      007433 90 08 46         [24] 1048 	mov	dptr,#_register_mouse_mouse_keycode_10000_650
      007436 E0               [24] 1049 	movx	a,@dptr
      007437 F5 82            [12] 1050 	mov	dpl,a
      007439 12 4F CF         [24] 1051 	lcall	_mousekey_off
      00743C                       1052 00103$:
                                   1053 ;	quantum/action.c:469: mousekey_send();
                                   1054 ;	quantum/action.c:471: }
                                   1055 ;	quantum/action.c:487: }
      00743C 02 50 2E         [24] 1056 	ljmp	_mousekey_send
                                   1057 ;------------------------------------------------------------
                                   1058 ;Allocation info for local variables in function 'process_action'
                                   1059 ;------------------------------------------------------------
                                   1060 ;sloc0         Allocated with name '_process_action_sloc0_1_0'
                                   1061 ;action        Allocated with name '_process_action_PARM_2'
                                   1062 ;record_argument Allocated with name '_process_action_record_argument_10000_657'
                                   1063 ;record        Allocated with name '_process_action_record_10000_658'
                                   1064 ;pressed       Allocated with name '_process_action_pressed_10000_658'
                                   1065 ;mods          Allocated with name '_process_action_mods_10000_658'
                                   1066 ;on            Allocated with name '_process_action_on_40000_680'
                                   1067 ;shift         Allocated with name '_process_action_shift_60000_682'
                                   1068 ;bits          Allocated with name '_process_action_bits_60000_682'
                                   1069 ;mask          Allocated with name '_process_action_mask_60000_682'
                                   1070 ;i             Allocated with name '_process_action_i_110000_706'
                                   1071 ;i             Allocated with name '_process_action_i_110000_710'
                                   1072 ;------------------------------------------------------------
                                   1073 ;	quantum/action.c:493: void process_action(keyrecord_t AK820_RECORD_MEM *record_argument, action_t action) {
                                   1074 ;	-----------------------------------------
                                   1075 ;	 function process_action
                                   1076 ;	-----------------------------------------
      00743F                       1077 _process_action:
      00743F 12 38 44         [24] 1078 	lcall	_ak820_outline_0103
      007442 90 08 49         [24] 1079 	mov	dptr,#_process_action_record_argument_10000_657
      007445 12 38 49         [24] 1080 	lcall	_ak820_outline_0104
                                   1081 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007448 90 08 49         [24] 1082 	mov	dptr,#_process_action_record_argument_10000_657
      00744B 12 37 A1         [24] 1083 	lcall	_ak820_outline_0004
                                   1084 ;	quantum/action.c:501: pressed = record->event.pressed;
      00744E A3               [24] 1085 	inc	dptr
      00744F A3               [24] 1086 	inc	dptr
      007450 A3               [24] 1087 	inc	dptr
      007451 A3               [24] 1088 	inc	dptr
      007452 A3               [24] 1089 	inc	dptr
      007453 E0               [24] 1090 	movx	a,@dptr
      007454 F5 26            [12] 1091 	mov	_process_action_sloc0_1_0,a
                                   1092 ;	quantum/action.c:525: switch (action.kind.id) {
      007456 90 08 48         [24] 1093 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007459 E0               [24] 1094 	movx	a,@dptr
      00745A C4               [12] 1095 	swap	a
      00745B 54 0F            [12] 1096 	anl	a,#0x0f
      00745D FD               [12] 1097 	mov  r5,a
      00745E 24 F4            [12] 1098 	add	a,#0xff - 0x0b
      007460 50 03            [24] 1099 	jnc	00434$
      007462 02 76 F2         [24] 1100 	ljmp	00181$
      007465                       1101 00434$:
                                   1102 ;	free result
      007465 ED               [12] 1103 	mov	a,r5
      007466 24 0A            [12] 1104 	add	a,#(00435$-3-.)
      007468 83               [24] 1105 	movc	a,@a+pc
      007469 F5 82            [12] 1106 	mov	dpl,a
      00746B ED               [12] 1107 	mov	a,r5
      00746C 24 10            [12] 1108 	add	a,#(00436$-3-.)
      00746E 83               [24] 1109 	movc	a,@a+pc
      00746F F5 83            [12] 1110 	mov	dph,a
      007471 E4               [12] 1111 	clr	a
      007472 73               [24] 1112 	jmp	@a+dptr
      007473                       1113 00435$:
      007473 8B                    1114 	.db	00102$
      007474 8B                    1115 	.db	00102$
      007475 F2                    1116 	.db	00181$
      007476 F2                    1117 	.db	00181$
      007477 15                    1118 	.db	00123$
      007478 75                    1119 	.db	00130$
      007479 F2                    1120 	.db	00181$
      00747A F2                    1121 	.db	00181$
      00747B 87                    1122 	.db	00131$
      00747C 59                    1123 	.db	00147$
      00747D 7F                    1124 	.db	00152$
      00747E 7F                    1125 	.db	00152$
      00747F                       1126 00436$:
      00747F 74                    1127 	.db	00102$>>8
      007480 74                    1128 	.db	00102$>>8
      007481 76                    1129 	.db	00181$>>8
      007482 76                    1130 	.db	00181$>>8
      007483 75                    1131 	.db	00123$>>8
      007484 75                    1132 	.db	00130$>>8
      007485 76                    1133 	.db	00181$>>8
      007486 76                    1134 	.db	00181$>>8
      007487 75                    1135 	.db	00131$>>8
      007488 76                    1136 	.db	00147$>>8
      007489 76                    1137 	.db	00152$>>8
      00748A 76                    1138 	.db	00152$>>8
                                   1139 ;	quantum/action.c:528: case ACT_RMODS: {
      00748B                       1140 00102$:
                                   1141 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00748B 90 08 48         [24] 1142 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00748E E0               [24] 1143 	movx	a,@dptr
      00748F 54 F0            [12] 1144 	anl	a,#0xf0
      007491 70 06            [24] 1145 	jnz	00194$
      007493 12 79 30         [24] 1146 	lcall	_ak820_outline_0109
      007496 FD               [12] 1147 	mov	r5,a
      007497 80 07            [24] 1148 	sjmp	00195$
      007499                       1149 00194$:
      007499 12 79 30         [24] 1150 	lcall	_ak820_outline_0109
      00749C C4               [12] 1151 	swap	a
      00749D 54 F0            [12] 1152 	anl	a,#0xf0
      00749F FD               [12] 1153 	mov	r5,a
      0074A0                       1154 00195$:
                                   1155 ;	quantum/action.c:531: if (pressed) {
      0074A0 E5 26            [12] 1156 	mov	a,_process_action_sloc0_1_0
      0074A2 60 35            [24] 1157 	jz	00119$
                                   1158 ;	quantum/action.c:532: if (mods) {
      0074A4 ED               [12] 1159 	mov	a,r5
      0074A5 60 29            [24] 1160 	jz	00110$
                                   1161 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0074A7 12 79 4E         [24] 1162 	lcall	_ak820_outline_0146
      0074AA FC               [12] 1163 	mov	r4,a
      0074AB BC E0 00         [24] 1164 	cjne	r4,#0xe0,00440$
      0074AE                       1165 00440$:
      0074AE 40 07            [24] 1166 	jc	00108$
      0074B0 12 79 4E         [24] 1167 	lcall	_ak820_outline_0146
      0074B3 24 18            [12] 1168 	add	a,#0xff - 0xe7
      0074B5 50 0A            [24] 1169 	jnc	00104$
                                   1170 ;	free result
      0074B7                       1171 00108$:
      0074B7 7B 47            [12] 1172 	mov	r3,#_process_action_PARM_2
      0074B9 7C 08            [12] 1173 	mov	r4,#(_process_action_PARM_2 >> 8)
      0074BB 12 33 FC         [24] 1174 	lcall	_ak820_outline_0121
      0074BE E0               [24] 1175 	movx	a,@dptr
      0074BF 70 07            [24] 1176 	jnz	00105$
      0074C1                       1177 00104$:
                                   1178 ;	quantum/action.c:537: add_owned_mods(mods);
      0074C1 8D 82            [24] 1179 	mov	dpl, r5
      0074C3 12 7E AD         [24] 1180 	lcall	_add_owned_mods
      0074C6 80 05            [24] 1181 	sjmp	00106$
      0074C8                       1182 00105$:
                                   1183 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      0074C8 8D 82            [24] 1184 	mov	dpl, r5
      0074CA 12 7E CB         [24] 1185 	lcall	_add_owned_weak_mods
      0074CD                       1186 00106$:
                                   1187 ;	quantum/action.c:541: send_keyboard_report();
      0074CD 12 81 E6         [24] 1188 	lcall	_send_keyboard_report
      0074D0                       1189 00110$:
                                   1190 ;	quantum/action.c:543: register_code(action.key.code);
      0074D0 12 79 19         [24] 1191 	lcall	_ak820_outline_0075
      0074D3 12 77 09         [24] 1192 	lcall	_register_code
      0074D6 02 76 F2         [24] 1193 	ljmp	00181$
      0074D9                       1194 00119$:
                                   1195 ;	quantum/action.c:545: unregister_code(action.key.code);
      0074D9 12 79 19         [24] 1196 	lcall	_ak820_outline_0075
      0074DC C0 05            [24] 1197 	push	ar5
      0074DE 12 77 8E         [24] 1198 	lcall	_unregister_code
      0074E1 D0 05            [24] 1199 	pop	ar5
                                   1200 ;	quantum/action.c:546: if (mods) {
      0074E3 ED               [12] 1201 	mov	a,r5
      0074E4 70 03            [24] 1202 	jnz	00444$
      0074E6 02 76 F2         [24] 1203 	ljmp	00181$
      0074E9                       1204 00444$:
                                   1205 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0074E9 12 79 4E         [24] 1206 	lcall	_ak820_outline_0146
      0074EC FC               [12] 1207 	mov	r4,a
      0074ED BC E0 00         [24] 1208 	cjne	r4,#0xe0,00445$
      0074F0                       1209 00445$:
      0074F0 40 07            [24] 1210 	jc	00115$
      0074F2 12 79 4E         [24] 1211 	lcall	_ak820_outline_0146
      0074F5 24 18            [12] 1212 	add	a,#0xff - 0xe7
      0074F7 50 0A            [24] 1213 	jnc	00111$
                                   1214 ;	free result
      0074F9                       1215 00115$:
      0074F9 7B 47            [12] 1216 	mov	r3,#_process_action_PARM_2
      0074FB 7C 08            [12] 1217 	mov	r4,#(_process_action_PARM_2 >> 8)
      0074FD 12 33 FC         [24] 1218 	lcall	_ak820_outline_0121
      007500 E0               [24] 1219 	movx	a,@dptr
      007501 70 07            [24] 1220 	jnz	00112$
      007503                       1221 00111$:
                                   1222 ;	quantum/action.c:548: del_owned_mods(mods);
      007503 8D 82            [24] 1223 	mov	dpl, r5
      007505 12 7E BD         [24] 1224 	lcall	_del_owned_mods
      007508 80 05            [24] 1225 	sjmp	00113$
      00750A                       1226 00112$:
                                   1227 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      00750A 8D 82            [24] 1228 	mov	dpl, r5
      00750C 12 7E DB         [24] 1229 	lcall	_del_owned_weak_mods
      00750F                       1230 00113$:
                                   1231 ;	quantum/action.c:552: send_keyboard_report();
      00750F 12 81 E6         [24] 1232 	lcall	_send_keyboard_report
                                   1233 ;	quantum/action.c:555: } break;
      007512 02 76 F2         [24] 1234 	ljmp	00181$
                                   1235 ;	quantum/action.c:632: case ACT_USAGE:
      007515                       1236 00123$:
                                   1237 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007515 74 07            [12] 1238 	mov	a,#0x07
      007517 12 37 F1         [24] 1239 	lcall	_ak820_outline_0030
      00751A 12 37 CC         [24] 1240 	lcall	_ak820_outline_0009
      00751D C3               [12] 1241 	clr	c
      00751E EC               [12] 1242 	mov	a,r4
      00751F 94 A5            [12] 1243 	subb	a,#0xa5
      007521 ED               [12] 1244 	mov	a,r5
      007522 94 00            [12] 1245 	subb	a,#0x00
      007524 40 15            [24] 1246 	jc	00125$
      007526 74 C2            [12] 1247 	mov	a,#0xc2
      007528 9C               [12] 1248 	subb	a,r4
      007529 E4               [12] 1249 	clr	a
      00752A 9D               [12] 1250 	subb	a,r5
      00752B 40 0E            [24] 1251 	jc	00125$
                                   1252 ;	free result
                                   1253 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      00752D 90 0A A7         [24] 1254 	mov	dptr,#_owned_usage_key_PARM_2
      007530 E5 26            [12] 1255 	mov	a,_process_action_sloc0_1_0
      007532 F0               [24] 1256 	movx	@dptr,a
      007533 8E 82            [24] 1257 	mov	dpl, r6
      007535 12 80 91         [24] 1258 	lcall	_owned_usage_key
                                   1259 ;	quantum/action.c:640: break;
      007538 02 76 F2         [24] 1260 	ljmp	00181$
      00753B                       1261 00125$:
                                   1262 ;	quantum/action.c:643: switch (action.usage.page) {
      00753B 12 79 20         [24] 1263 	lcall	_ak820_outline_0085
      00753E FF               [12] 1264 	mov	r7,a
      00753F 60 08            [24] 1265 	jz	00127$
      007541 BF 01 02         [24] 1266 	cjne	r7,#0x01,00452$
      007544 80 19            [24] 1267 	sjmp	00128$
      007546                       1268 00452$:
      007546 02 76 F2         [24] 1269 	ljmp	00181$
                                   1270 ;	quantum/action.c:644: case PAGE_SYSTEM:
      007549                       1271 00127$:
                                   1272 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      007549 E5 26            [12] 1273 	mov	a,_process_action_sloc0_1_0
      00754B 60 05            [24] 1274 	jz	00196$
      00754D 12 79 37         [24] 1275 	lcall	_ak820_outline_0128
      007550 80 04            [24] 1276 	sjmp	00197$
      007552                       1277 00196$:
      007552 7E 00            [12] 1278 	mov	r6,#0x00
      007554 7F 00            [12] 1279 	mov	r7,#0x00
      007556                       1280 00197$:
      007556 12 43 20         [24] 1281 	lcall	_ak820_outline_0116
      007559 12 6F 1D         [24] 1282 	lcall	_host_system_send
                                   1283 ;	quantum/action.c:646: break;
      00755C 02 76 F2         [24] 1284 	ljmp	00181$
                                   1285 ;	quantum/action.c:647: case PAGE_CONSUMER:
      00755F                       1286 00128$:
                                   1287 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      00755F E5 26            [12] 1288 	mov	a,_process_action_sloc0_1_0
      007561 60 05            [24] 1289 	jz	00198$
      007563 12 79 37         [24] 1290 	lcall	_ak820_outline_0128
      007566 80 04            [24] 1291 	sjmp	00199$
      007568                       1292 00198$:
      007568 7E 00            [12] 1293 	mov	r6,#0x00
      00756A 7F 00            [12] 1294 	mov	r7,#0x00
      00756C                       1295 00199$:
      00756C 12 43 20         [24] 1296 	lcall	_ak820_outline_0116
      00756F 12 6F 4D         [24] 1297 	lcall	_host_consumer_send
                                   1298 ;	quantum/action.c:651: break;
      007572 02 76 F2         [24] 1299 	ljmp	00181$
                                   1300 ;	quantum/action.c:654: case ACT_MOUSEKEY:
      007575                       1301 00130$:
                                   1302 ;	quantum/action.c:655: register_mouse(action.key.code, pressed);
      007575 12 79 4E         [24] 1303 	lcall	_ak820_outline_0146
      007578 FF               [12] 1304 	mov	r7,a
      007579 90 08 45         [24] 1305 	mov	dptr,#_register_mouse_PARM_2
      00757C E5 26            [12] 1306 	mov	a,_process_action_sloc0_1_0
      00757E F0               [24] 1307 	movx	@dptr,a
      00757F 8F 82            [24] 1308 	mov	dpl, r7
      007581 12 74 1C         [24] 1309 	lcall	_register_mouse
                                   1310 ;	quantum/action.c:656: break;
      007584 02 76 F2         [24] 1311 	ljmp	00181$
                                   1312 ;	quantum/action.c:658: case ACT_LAYER: {
      007587                       1313 00131$:
                                   1314 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      007587 90 08 48         [24] 1315 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00758A E0               [24] 1316 	movx	a,@dptr
      00758B 54 03            [12] 1317 	anl	a,#0x03
      00758D 90 08 4B         [24] 1318 	mov	dptr,#_process_action_on_40000_680
      007590 F0               [24] 1319 	movx	@dptr,a
                                   1320 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007591 E0               [24] 1321 	movx	a,@dptr
      007592 FF               [12] 1322 	mov	r7,a
      007593 60 11            [24] 1323 	jz	00200$
      007595 E5 26            [12] 1324 	mov	a,_process_action_sloc0_1_0
      007597 60 07            [24] 1325 	jz	00202$
      007599 8F 06            [24] 1326 	mov	ar6,r7
      00759B 53 06 01         [24] 1327 	anl	ar6,#0x01
      00759E 80 10            [24] 1328 	sjmp	00201$
      0075A0                       1329 00202$:
      0075A0 74 02            [12] 1330 	mov	a,#0x02
      0075A2 5F               [12] 1331 	anl	a,r7
      0075A3 FE               [12] 1332 	mov	r6,a
      0075A4 80 0A            [24] 1333 	sjmp	00201$
      0075A6                       1334 00200$:
      0075A6 E5 26            [12] 1335 	mov	a,_process_action_sloc0_1_0
      0075A8 B4 01 00         [24] 1336 	cjne	a,#0x01,00457$
      0075AB                       1337 00457$:
      0075AB 92 1D            [24] 1338 	mov  _process_action_sloc1_1_0,c
      0075AD E4               [12] 1339 	clr	a
      0075AE 33               [12] 1340 	rlc	a
      0075AF FE               [12] 1341 	mov	r6,a
      0075B0                       1342 00201$:
      0075B0 EE               [12] 1343 	mov	a,r6
      0075B1 70 03            [24] 1344 	jnz	00458$
      0075B3 02 76 F2         [24] 1345 	ljmp	00181$
      0075B6                       1346 00458$:
                                   1347 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      0075B6 12 79 4E         [24] 1348 	lcall	_ak820_outline_0146
      0075B9 C4               [12] 1349 	swap	a
      0075BA 03               [12] 1350 	rr	a
      0075BB 54 07            [12] 1351 	anl	a,#0x07
      0075BD 25 E0            [12] 1352 	add	a,acc
      0075BF 25 E0            [12] 1353 	add	a,acc
      0075C1 FF               [12] 1354 	mov	r7,a
                                   1355 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0075C2 12 79 4E         [24] 1356 	lcall	_ak820_outline_0146
      0075C5 54 0F            [12] 1357 	anl	a,#0x0f
      0075C7 FE               [12] 1358 	mov	r6,a
      0075C8 8F F0            [24] 1359 	mov	b,r7
      0075CA 05 F0            [12] 1360 	inc	b
      0075CC EE               [12] 1361 	mov	a,r6
      0075CD 80 02            [24] 1362 	sjmp	00460$
      0075CF                       1363 00459$:
      0075CF 25 E0            [12] 1364 	add	a,acc
      0075D1                       1365 00460$:
      0075D1 D5 F0 FB         [24] 1366 	djnz	b,00459$
      0075D4 FE               [12] 1367 	mov	r6,a
                                   1368 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0075D5 12 79 4E         [24] 1369 	lcall	_ak820_outline_0146
      0075D8 30 E4 11         [24] 1370 	jnb	acc.4,00204$
      0075DB 8F F0            [24] 1371 	mov	b,r7
      0075DD 05 F0            [12] 1372 	inc	b
      0075DF 74 0F            [12] 1373 	mov	a,#0x0f
      0075E1 80 02            [24] 1374 	sjmp	00463$
      0075E3                       1375 00462$:
      0075E3 25 E0            [12] 1376 	add	a,acc
      0075E5                       1377 00463$:
      0075E5 D5 F0 FB         [24] 1378 	djnz	b,00462$
      0075E8 F4               [12] 1379 	cpl	a
      0075E9 FF               [12] 1380 	mov	r7,a
      0075EA 80 02            [24] 1381 	sjmp	00205$
      0075EC                       1382 00204$:
      0075EC 7F 00            [12] 1383 	mov	r7,#0x00
      0075EE                       1384 00205$:
                                   1385 ;	quantum/action.c:666: bits |= mask;
      0075EE EE               [12] 1386 	mov	a,r6
      0075EF 42 07            [12] 1387 	orl	ar7,a
                                   1388 ;	quantum/action.c:667: if (!on) {
      0075F1 90 08 4B         [24] 1389 	mov	dptr,#_process_action_on_40000_680
      0075F4 E0               [24] 1390 	movx	a,@dptr
      0075F5 70 31            [24] 1391 	jnz	00143$
                                   1392 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      0075F7 12 79 20         [24] 1393 	lcall	_ak820_outline_0085
      0075FA FE               [12] 1394 	mov	r6,a
      0075FB 2E               [12] 1395 	add	a,r6
                                   1396 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      0075FC 90 76 00         [24] 1397 	mov	dptr,#00465$
      0075FF 73               [24] 1398 	jmp	@a+dptr
      007600                       1399 00465$:
      007600 80 06            [24] 1400 	sjmp	00132$
      007602 80 0C            [24] 1401 	sjmp	00133$
      007604 80 12            [24] 1402 	sjmp	00134$
      007606 80 18            [24] 1403 	sjmp	00135$
      007608                       1404 00132$:
      007608 8F 82            [24] 1405 	mov	dpl, r7
      00760A 12 79 A2         [24] 1406 	lcall	_default_layer_and
      00760D 02 76 F2         [24] 1407 	ljmp	00181$
                                   1408 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      007610                       1409 00133$:
      007610 8F 82            [24] 1410 	mov	dpl, r7
      007612 12 79 91         [24] 1411 	lcall	_default_layer_or
      007615 02 76 F2         [24] 1412 	ljmp	00181$
                                   1413 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      007618                       1414 00134$:
      007618 8F 82            [24] 1415 	mov	dpl, r7
      00761A 12 79 B8         [24] 1416 	lcall	_default_layer_xor
      00761D 02 76 F2         [24] 1417 	ljmp	00181$
                                   1418 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      007620                       1419 00135$:
      007620 8F 82            [24] 1420 	mov	dpl, r7
      007622 12 79 86         [24] 1421 	lcall	_default_layer_set
                                   1422 ;	quantum/action.c:673: }
      007625 02 76 F2         [24] 1423 	ljmp	00181$
      007628                       1424 00143$:
                                   1425 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      007628 12 79 20         [24] 1426 	lcall	_ak820_outline_0085
      00762B FE               [12] 1427 	mov	r6,a
      00762C 2E               [12] 1428 	add	a,r6
                                   1429 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      00762D 90 76 31         [24] 1430 	mov	dptr,#00466$
      007630 73               [24] 1431 	jmp	@a+dptr
      007631                       1432 00466$:
      007631 80 06            [24] 1433 	sjmp	00137$
      007633 80 0C            [24] 1434 	sjmp	00138$
      007635 80 12            [24] 1435 	sjmp	00139$
      007637 80 18            [24] 1436 	sjmp	00140$
      007639                       1437 00137$:
      007639 8F 82            [24] 1438 	mov	dpl, r7
      00763B 12 7B 3B         [24] 1439 	lcall	_layer_and
      00763E 02 76 F2         [24] 1440 	ljmp	00181$
                                   1441 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      007641                       1442 00138$:
      007641 8F 82            [24] 1443 	mov	dpl, r7
      007643 12 7B 2A         [24] 1444 	lcall	_layer_or
      007646 02 76 F2         [24] 1445 	ljmp	00181$
                                   1446 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      007649                       1447 00139$:
      007649 8F 82            [24] 1448 	mov	dpl, r7
      00764B 12 7B 51         [24] 1449 	lcall	_layer_xor
      00764E 02 76 F2         [24] 1450 	ljmp	00181$
                                   1451 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      007651                       1452 00140$:
      007651 8F 82            [24] 1453 	mov	dpl, r7
      007653 12 7A C7         [24] 1454 	lcall	_layer_state_set
                                   1455 ;	quantum/action.c:683: break;
      007656 02 76 F2         [24] 1456 	ljmp	00181$
                                   1457 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      007659                       1458 00147$:
                                   1459 ;	quantum/action.c:686: if (pressed) {
      007659 E5 26            [12] 1460 	mov	a,_process_action_sloc0_1_0
      00765B 60 11            [24] 1461 	jz	00149$
                                   1462 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      00765D 12 79 30         [24] 1463 	lcall	_ak820_outline_0109
      007660 F5 82            [12] 1464 	mov	dpl,a
      007662 12 7A 28         [24] 1465 	lcall	_layer_hold_on
                                   1466 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      007665 12 79 19         [24] 1467 	lcall	_ak820_outline_0075
      007668 12 78 59         [24] 1468 	lcall	_register_mods
      00766B 02 76 F2         [24] 1469 	ljmp	00181$
      00766E                       1470 00149$:
                                   1471 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      00766E 12 79 19         [24] 1472 	lcall	_ak820_outline_0075
      007671 12 78 6D         [24] 1473 	lcall	_unregister_mods
                                   1474 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      007674 12 79 30         [24] 1475 	lcall	_ak820_outline_0109
      007677 F5 82            [12] 1476 	mov	dpl,a
      007679 12 7A 60         [24] 1477 	lcall	_layer_hold_off
                                   1478 ;	quantum/action.c:693: break;
      00767C 02 76 F2         [24] 1479 	ljmp	00181$
                                   1480 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      00767F                       1481 00152$:
                                   1482 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      00767F 12 79 4E         [24] 1483 	lcall	_ak820_outline_0146
      007682 FF               [12] 1484 	mov	r7,a
      007683 BF F1 02         [24] 1485 	cjne	r7,#0xf1,00468$
      007686 80 0A            [24] 1486 	sjmp	00154$
      007688                       1487 00468$:
      007688 BF F2 02         [24] 1488 	cjne	r7,#0xf2,00469$
      00768B 80 19            [24] 1489 	sjmp	00155$
      00768D                       1490 00469$:
                                   1491 ;	quantum/action.c:712: momentary_layer_action:
      00768D BF F3 3B         [24] 1492 	cjne	r7,#0xf3,00160$
      007690 80 28            [24] 1493 	sjmp	00156$
      007692                       1494 00154$:
                                   1495 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007692 E5 26            [12] 1496 	mov	a,_process_action_sloc0_1_0
      007694 60 08            [24] 1497 	jz	00206$
      007696 12 79 00         [24] 1498 	lcall	_ak820_outline_0038
      007699 12 7A 28         [24] 1499 	lcall	_layer_hold_on
      00769C 80 54            [24] 1500 	sjmp	00181$
      00769E                       1501 00206$:
      00769E 12 79 00         [24] 1502 	lcall	_ak820_outline_0038
      0076A1 12 7A 60         [24] 1503 	lcall	_layer_hold_off
                                   1504 ;	quantum/action.c:714: break;
                                   1505 ;	quantum/action.c:715: case OP_OFF_ON:
      0076A4 80 4C            [24] 1506 	sjmp	00181$
      0076A6                       1507 00155$:
                                   1508 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0076A6 E5 26            [12] 1509 	mov	a,_process_action_sloc0_1_0
      0076A8 60 08            [24] 1510 	jz	00208$
      0076AA 12 79 00         [24] 1511 	lcall	_ak820_outline_0038
      0076AD 12 7B 0C         [24] 1512 	lcall	_layer_off
      0076B0 80 40            [24] 1513 	sjmp	00181$
      0076B2                       1514 00208$:
      0076B2 12 79 00         [24] 1515 	lcall	_ak820_outline_0038
      0076B5 12 7A F1         [24] 1516 	lcall	_layer_on
                                   1517 ;	quantum/action.c:717: break;
                                   1518 ;	quantum/action.c:718: case OP_SET_CLEAR:
      0076B8 80 38            [24] 1519 	sjmp	00181$
      0076BA                       1520 00156$:
                                   1521 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0076BA E5 26            [12] 1522 	mov	a,_process_action_sloc0_1_0
      0076BC 60 08            [24] 1523 	jz	00210$
      0076BE 12 79 00         [24] 1524 	lcall	_ak820_outline_0038
      0076C1 12 7A DB         [24] 1525 	lcall	_layer_move
      0076C4 80 2C            [24] 1526 	sjmp	00181$
      0076C6                       1527 00210$:
      0076C6 12 7A D5         [24] 1528 	lcall	_layer_clear
                                   1529 ;	quantum/action.c:720: break;
                                   1530 ;	quantum/action.c:766: default:
      0076C9 80 27            [24] 1531 	sjmp	00181$
      0076CB                       1532 00160$:
                                   1533 ;	quantum/action.c:773: if (pressed) {
      0076CB E5 26            [12] 1534 	mov	a,_process_action_sloc0_1_0
      0076CD 60 08            [24] 1535 	jz	00163$
                                   1536 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      0076CF 12 79 19         [24] 1537 	lcall	_ak820_outline_0075
      0076D2 12 77 09         [24] 1538 	lcall	_register_code
                                   1539 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0076D5 80 1B            [24] 1540 	sjmp	00181$
      0076D7                       1541 00163$:
                                   1542 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      0076D7 12 79 4E         [24] 1543 	lcall	_ak820_outline_0146
      0076DA FF               [12] 1544 	mov	r7,a
      0076DB BF 39 0E         [24] 1545 	cjne	r7,#0x39,00175$
                                   1546 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      0076DE 7F 50            [12] 1547 	mov	r7,#0x50
      0076E0                       1548 00187$:
      0076E0 EF               [12] 1549 	mov	a,r7
      0076E1 60 09            [24] 1550 	jz	00175$
      0076E3 90 00 01         [24] 1551 	mov	dptr,#0x0001
      0076E6 12 5A F1         [24] 1552 	lcall	_mDelaymS
      0076E9 1F               [12] 1553 	dec	r7
                                   1554 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      0076EA 80 F4            [24] 1555 	sjmp	00187$
      0076EC                       1556 00175$:
                                   1557 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      0076EC 12 79 19         [24] 1558 	lcall	_ak820_outline_0075
      0076EF 12 77 8E         [24] 1559 	lcall	_unregister_code
                                   1560 ;	quantum/action.c:866: }
      0076F2                       1561 00181$:
                                   1562 ;	quantum/action.c:887: switch (action.kind.id) {
      0076F2 90 08 48         [24] 1563 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076F5 E0               [24] 1564 	movx	a,@dptr
      0076F6 C4               [12] 1565 	swap	a
      0076F7 54 0F            [12] 1566 	anl	a,#0x0f
      0076F9 FF               [12] 1567 	mov	r7,a
      0076FA BF 08 02         [24] 1568 	cjne	r7,#0x08,00478$
      0076FD 80 03            [24] 1569 	sjmp	00183$
      0076FF                       1570 00478$:
      0076FF BF 09 06         [24] 1571 	cjne	r7,#0x09,00192$
                                   1572 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007702                       1573 00183$:
                                   1574 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007702 12 6E 82         [24] 1575 	lcall	_host_keyboard_leds
                                   1576 ;	quantum/action.c:898: }
                                   1577 ;	quantum/action.c:951: }
      007705 02 99 42         [24] 1578 	ljmp	_led_set
      007708                       1579 00192$:
      007708 22               [24] 1580 	ret
                                   1581 ;------------------------------------------------------------
                                   1582 ;Allocation info for local variables in function 'register_code'
                                   1583 ;------------------------------------------------------------
                                   1584 ;code          Allocated with name '_register_code_code_10000_714'
                                   1585 ;------------------------------------------------------------
                                   1586 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1587 ;	-----------------------------------------
                                   1588 ;	 function register_code
                                   1589 ;	-----------------------------------------
      007709                       1590 _register_code:
      007709 E5 82            [12] 1591 	mov	a,dpl
      00770B 90 08 4C         [24] 1592 	mov	dptr,#_register_code_code_10000_714
      00770E F0               [24] 1593 	movx	@dptr,a
                                   1594 ;	quantum/action.c:958: if (code == KC_NO) {
      00770F E0               [24] 1595 	movx	a,@dptr
      007710 FF               [12] 1596 	mov	r7,a
      007711 70 01            [24] 1597 	jnz	00123$
                                   1598 ;	quantum/action.c:959: return;
      007713 22               [24] 1599 	ret
      007714                       1600 00123$:
                                   1601 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007714 BF 04 00         [24] 1602 	cjne	r7,#0x04,00198$
      007717                       1603 00198$:
      007717 40 12            [24] 1604 	jc	00119$
      007719 EF               [12] 1605 	mov	a,r7
      00771A 24 5B            [12] 1606 	add	a,#0xff - 0xa4
      00771C 40 0D            [24] 1607 	jc	00119$
                                   1608 ;	free result
                                   1609 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      00771E 8F 82            [24] 1610 	mov	dpl, r7
      007720 12 7F 50         [24] 1611 	lcall	_add_owned_key
      007723 E5 82            [12] 1612 	mov	a, dpl
      007725 70 01            [24] 1613 	jnz	00104$
      007727 22               [24] 1614 	ret
      007728                       1615 00104$:
                                   1616 ;	quantum/action.c:1013: send_keyboard_report();
      007728 02 81 E6         [24] 1617 	ljmp	_send_keyboard_report
      00772B                       1618 00119$:
                                   1619 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      00772B 12 79 42         [24] 1620 	lcall	_ak820_outline_0137
      00772E BF E0 00         [24] 1621 	cjne	r7,#0xe0,00202$
      007731                       1622 00202$:
      007731 40 1A            [24] 1623 	jc	00115$
      007733 EF               [12] 1624 	mov	a,r7
      007734 24 18            [12] 1625 	add	a,#0xff - 0xe7
      007736 40 15            [24] 1626 	jc	00115$
                                   1627 ;	free result
                                   1628 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      007738 74 07            [12] 1629 	mov	a,#0x07
      00773A 5F               [12] 1630 	anl	a,r7
      00773B 12 79 12         [24] 1631 	lcall	_ak820_outline_0062
      00773E 80 02            [24] 1632 	sjmp	00206$
      007740                       1633 00205$:
      007740 25 E0            [12] 1634 	add	a,acc
      007742                       1635 00206$:
      007742 D5 F0 FB         [24] 1636 	djnz	b,00205$
      007745 F5 82            [12] 1637 	mov	dpl,a
      007747 12 7E AD         [24] 1638 	lcall	_add_owned_mods
                                   1639 ;	quantum/action.c:1016: send_keyboard_report();
      00774A 02 81 E6         [24] 1640 	ljmp	_send_keyboard_report
      00774D                       1641 00115$:
                                   1642 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00774D 12 79 42         [24] 1643 	lcall	_ak820_outline_0137
      007750 BF A5 00         [24] 1644 	cjne	r7,#0xa5,00207$
      007753                       1645 00207$:
      007753 40 05            [24] 1646 	jc	00113$
      007755 EF               [12] 1647 	mov	a,r7
      007756 24 58            [12] 1648 	add	a,#0xff - 0xa7
      007758 50 0D            [24] 1649 	jnc	00108$
                                   1650 ;	free result
      00775A                       1651 00113$:
      00775A 12 79 42         [24] 1652 	lcall	_ak820_outline_0137
      00775D BF A8 00         [24] 1653 	cjne	r7,#0xa8,00210$
      007760                       1654 00210$:
      007760 40 13            [24] 1655 	jc	00109$
      007762 EF               [12] 1656 	mov	a,r7
      007763 24 3D            [12] 1657 	add	a,#0xff - 0xc2
      007765 40 0E            [24] 1658 	jc	00109$
                                   1659 ;	free result
      007767                       1660 00108$:
                                   1661 ;	quantum/action.c:1021: owned_usage_key(code, true);
      007767 12 79 42         [24] 1662 	lcall	_ak820_outline_0137
      00776A 90 0A A7         [24] 1663 	mov	dptr,#_owned_usage_key_PARM_2
      00776D 74 01            [12] 1664 	mov	a,#0x01
      00776F F0               [24] 1665 	movx	@dptr,a
      007770 8F 82            [24] 1666 	mov	dpl, r7
      007772 02 80 91         [24] 1667 	ljmp	_owned_usage_key
      007775                       1668 00109$:
                                   1669 ;	quantum/action.c:1028: } else if (IS_MOUSE_KEYCODE(code)) {
      007775 12 79 42         [24] 1670 	lcall	_ak820_outline_0137
      007778 BF CD 00         [24] 1671 	cjne	r7,#0xcd,00213$
      00777B                       1672 00213$:
      00777B 40 10            [24] 1673 	jc	00125$
      00777D EF               [12] 1674 	mov	a,r7
      00777E 24 20            [12] 1675 	add	a,#0xff - 0xdf
      007780 40 0B            [24] 1676 	jc	00125$
                                   1677 ;	free result
                                   1678 ;	quantum/action.c:1029: register_mouse(code, true);
      007782 90 08 45         [24] 1679 	mov	dptr,#_register_mouse_PARM_2
      007785 74 01            [12] 1680 	mov	a,#0x01
      007787 F0               [24] 1681 	movx	@dptr,a
      007788 8F 82            [24] 1682 	mov	dpl, r7
                                   1683 ;	quantum/action.c:1031: }
      00778A 02 74 1C         [24] 1684 	ljmp	_register_mouse
      00778D                       1685 00125$:
      00778D 22               [24] 1686 	ret
                                   1687 ;------------------------------------------------------------
                                   1688 ;Allocation info for local variables in function 'unregister_code'
                                   1689 ;------------------------------------------------------------
                                   1690 ;code          Allocated with name '_unregister_code_code_10000_728'
                                   1691 ;------------------------------------------------------------
                                   1692 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1693 ;	-----------------------------------------
                                   1694 ;	 function unregister_code
                                   1695 ;	-----------------------------------------
      00778E                       1696 _unregister_code:
      00778E E5 82            [12] 1697 	mov	a,dpl
      007790 90 08 4D         [24] 1698 	mov	dptr,#_unregister_code_code_10000_728
      007793 F0               [24] 1699 	movx	@dptr,a
                                   1700 ;	quantum/action.c:1038: if (code == KC_NO) {
      007794 E0               [24] 1701 	movx	a,@dptr
      007795 FF               [12] 1702 	mov	r7,a
      007796 70 01            [24] 1703 	jnz	00121$
                                   1704 ;	quantum/action.c:1039: return;
      007798 22               [24] 1705 	ret
      007799                       1706 00121$:
                                   1707 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      007799 BF 04 00         [24] 1708 	cjne	r7,#0x04,00196$
      00779C                       1709 00196$:
      00779C 40 12            [24] 1710 	jc	00117$
      00779E EF               [12] 1711 	mov	a,r7
      00779F 24 5B            [12] 1712 	add	a,#0xff - 0xa4
      0077A1 40 0D            [24] 1713 	jc	00117$
                                   1714 ;	free result
                                   1715 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      0077A3 8F 82            [24] 1716 	mov	dpl, r7
      0077A5 12 7F CA         [24] 1717 	lcall	_del_owned_key
      0077A8 E5 82            [12] 1718 	mov	a, dpl
      0077AA 70 01            [24] 1719 	jnz	00102$
      0077AC 22               [24] 1720 	ret
      0077AD                       1721 00102$:
                                   1722 ;	quantum/action.c:1080: send_keyboard_report();
      0077AD 02 81 E6         [24] 1723 	ljmp	_send_keyboard_report
      0077B0                       1724 00117$:
                                   1725 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      0077B0 12 79 48         [24] 1726 	lcall	_ak820_outline_0138
      0077B3 BF E0 00         [24] 1727 	cjne	r7,#0xe0,00200$
      0077B6                       1728 00200$:
      0077B6 40 1A            [24] 1729 	jc	00113$
      0077B8 EF               [12] 1730 	mov	a,r7
      0077B9 24 18            [12] 1731 	add	a,#0xff - 0xe7
      0077BB 40 15            [24] 1732 	jc	00113$
                                   1733 ;	free result
                                   1734 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      0077BD 74 07            [12] 1735 	mov	a,#0x07
      0077BF 5F               [12] 1736 	anl	a,r7
      0077C0 12 79 12         [24] 1737 	lcall	_ak820_outline_0062
      0077C3 80 02            [24] 1738 	sjmp	00204$
      0077C5                       1739 00203$:
      0077C5 25 E0            [12] 1740 	add	a,acc
      0077C7                       1741 00204$:
      0077C7 D5 F0 FB         [24] 1742 	djnz	b,00203$
      0077CA F5 82            [12] 1743 	mov	dpl,a
      0077CC 12 7E BD         [24] 1744 	lcall	_del_owned_mods
                                   1745 ;	quantum/action.c:1083: send_keyboard_report();
      0077CF 02 81 E6         [24] 1746 	ljmp	_send_keyboard_report
      0077D2                       1747 00113$:
                                   1748 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0077D2 12 79 48         [24] 1749 	lcall	_ak820_outline_0138
      0077D5 BF A5 00         [24] 1750 	cjne	r7,#0xa5,00205$
      0077D8                       1751 00205$:
      0077D8 40 05            [24] 1752 	jc	00111$
      0077DA EF               [12] 1753 	mov	a,r7
      0077DB 24 58            [12] 1754 	add	a,#0xff - 0xa7
      0077DD 50 0D            [24] 1755 	jnc	00106$
                                   1756 ;	free result
      0077DF                       1757 00111$:
      0077DF 12 79 48         [24] 1758 	lcall	_ak820_outline_0138
      0077E2 BF A8 00         [24] 1759 	cjne	r7,#0xa8,00208$
      0077E5                       1760 00208$:
      0077E5 40 11            [24] 1761 	jc	00107$
      0077E7 EF               [12] 1762 	mov	a,r7
      0077E8 24 3D            [12] 1763 	add	a,#0xff - 0xc2
      0077EA 40 0C            [24] 1764 	jc	00107$
                                   1765 ;	free result
      0077EC                       1766 00106$:
                                   1767 ;	quantum/action.c:1088: owned_usage_key(code, false);
      0077EC 12 79 48         [24] 1768 	lcall	_ak820_outline_0138
      0077EF 90 0A A7         [24] 1769 	mov	dptr,#_owned_usage_key_PARM_2
      0077F2 12 79 53         [24] 1770 	lcall	_ak820_outline_0183
      0077F5 02 80 91         [24] 1771 	ljmp	_owned_usage_key
      0077F8                       1772 00107$:
                                   1773 ;	quantum/action.c:1095: } else if (IS_MOUSE_KEYCODE(code)) {
      0077F8 12 79 48         [24] 1774 	lcall	_ak820_outline_0138
      0077FB BF CD 00         [24] 1775 	cjne	r7,#0xcd,00211$
      0077FE                       1776 00211$:
      0077FE 40 0E            [24] 1777 	jc	00123$
      007800 EF               [12] 1778 	mov	a,r7
      007801 24 20            [12] 1779 	add	a,#0xff - 0xdf
      007803 40 09            [24] 1780 	jc	00123$
                                   1781 ;	free result
                                   1782 ;	quantum/action.c:1096: register_mouse(code, false);
      007805 90 08 45         [24] 1783 	mov	dptr,#_register_mouse_PARM_2
      007808 12 79 53         [24] 1784 	lcall	_ak820_outline_0183
                                   1785 ;	quantum/action.c:1098: }
      00780B 02 74 1C         [24] 1786 	ljmp	_register_mouse
      00780E                       1787 00123$:
      00780E 22               [24] 1788 	ret
                                   1789 ;------------------------------------------------------------
                                   1790 ;Allocation info for local variables in function 'tap_code_delay'
                                   1791 ;------------------------------------------------------------
                                   1792 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1793 ;code          Allocated with name '_tap_code_delay_code_10000_741'
                                   1794 ;i             Allocated with name '_tap_code_delay_i_20000_743'
                                   1795 ;i             Allocated with name '_tap_code_delay_i_50000_746'
                                   1796 ;------------------------------------------------------------
                                   1797 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1798 ;	-----------------------------------------
                                   1799 ;	 function tap_code_delay
                                   1800 ;	-----------------------------------------
      00780F                       1801 _tap_code_delay:
      00780F E5 82            [12] 1802 	mov	a,dpl
      007811 90 08 50         [24] 1803 	mov	dptr,#_tap_code_delay_code_10000_741
      007814 F0               [24] 1804 	movx	@dptr,a
                                   1805 ;	quantum/action.c:1106: register_code(code);
      007815 E0               [24] 1806 	movx	a,@dptr
      007816 FF               [12] 1807 	mov	r7,a
      007817 F5 82            [12] 1808 	mov	dpl,a
      007819 C0 07            [24] 1809 	push	ar7
      00781B 12 77 09         [24] 1810 	lcall	_register_code
      00781E D0 07            [24] 1811 	pop	ar7
                                   1812 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007820 90 08 4E         [24] 1813 	mov	dptr,#_tap_code_delay_PARM_2
      007823 12 43 0E         [24] 1814 	lcall	_ak820_outline_0092
      007826                       1815 00110$:
      007826 ED               [12] 1816 	mov	a,r5
      007827 4E               [12] 1817 	orl	a,r6
      007828 60 0D            [24] 1818 	jz	00105$
                                   1819 ;	quantum/action.c:1108: wait_ms(1);
      00782A 90 00 01         [24] 1820 	mov	dptr,#0x0001
      00782D 12 5A F1         [24] 1821 	lcall	_mDelaymS
                                   1822 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007830 1D               [12] 1823 	dec	r5
      007831 BD FF 01         [24] 1824 	cjne	r5,#0xff,00141$
      007834 1E               [12] 1825 	dec	r6
      007835                       1826 00141$:
      007835 80 EF            [24] 1827 	sjmp	00110$
      007837                       1828 00105$:
                                   1829 ;	quantum/action.c:1110: unregister_code(code);
      007837 8F 82            [24] 1830 	mov	dpl, r7
                                   1831 ;	quantum/action.c:1111: }
      007839 02 77 8E         [24] 1832 	ljmp	_unregister_code
                                   1833 ;------------------------------------------------------------
                                   1834 ;Allocation info for local variables in function 'tap_code'
                                   1835 ;------------------------------------------------------------
                                   1836 ;code          Allocated with name '_tap_code_code_10000_748'
                                   1837 ;------------------------------------------------------------
                                   1838 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1839 ;	-----------------------------------------
                                   1840 ;	 function tap_code
                                   1841 ;	-----------------------------------------
      00783C                       1842 _tap_code:
      00783C E5 82            [12] 1843 	mov	a,dpl
      00783E 90 08 51         [24] 1844 	mov	dptr,#_tap_code_code_10000_748
      007841 F0               [24] 1845 	movx	@dptr,a
                                   1846 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007842 E0               [24] 1847 	movx	a,@dptr
      007843 FF               [12] 1848 	mov	r7,a
      007844 BF 39 04         [24] 1849 	cjne	r7,#0x39,00103$
      007847 7E 50            [12] 1850 	mov	r6,#0x50
      007849 80 02            [24] 1851 	sjmp	00104$
      00784B                       1852 00103$:
      00784B 7E 00            [12] 1853 	mov	r6,#0x00
      00784D                       1854 00104$:
      00784D 90 08 4E         [24] 1855 	mov	dptr,#_tap_code_delay_PARM_2
      007850 EE               [12] 1856 	mov	a,r6
      007851 12 38 60         [24] 1857 	lcall	_ak820_outline_0122
      007854 8F 82            [24] 1858 	mov	dpl, r7
                                   1859 ;	quantum/action.c:1119: }
      007856 02 78 0F         [24] 1860 	ljmp	_tap_code_delay
                                   1861 ;------------------------------------------------------------
                                   1862 ;Allocation info for local variables in function 'register_mods'
                                   1863 ;------------------------------------------------------------
                                   1864 ;mods          Allocated with name '_register_mods_mods_10000_750'
                                   1865 ;------------------------------------------------------------
                                   1866 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1867 ;	-----------------------------------------
                                   1868 ;	 function register_mods
                                   1869 ;	-----------------------------------------
      007859                       1870 _register_mods:
      007859 E5 82            [12] 1871 	mov	a,dpl
      00785B 90 08 52         [24] 1872 	mov	dptr,#_register_mods_mods_10000_750
      00785E F0               [24] 1873 	movx	@dptr,a
                                   1874 ;	quantum/action.c:1126: if (mods) {
      00785F E0               [24] 1875 	movx	a,@dptr
      007860 FF               [12] 1876 	mov	r7,a
      007861 E0               [24] 1877 	movx	a,@dptr
      007862 60 08            [24] 1878 	jz	00103$
                                   1879 ;	quantum/action.c:1127: add_owned_mods(mods);
      007864 8F 82            [24] 1880 	mov	dpl, r7
      007866 12 7E AD         [24] 1881 	lcall	_add_owned_mods
                                   1882 ;	quantum/action.c:1128: send_keyboard_report();
                                   1883 ;	quantum/action.c:1130: }
      007869 02 81 E6         [24] 1884 	ljmp	_send_keyboard_report
      00786C                       1885 00103$:
      00786C 22               [24] 1886 	ret
                                   1887 ;------------------------------------------------------------
                                   1888 ;Allocation info for local variables in function 'unregister_mods'
                                   1889 ;------------------------------------------------------------
                                   1890 ;mods          Allocated with name '_unregister_mods_mods_10000_754'
                                   1891 ;------------------------------------------------------------
                                   1892 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1893 ;	-----------------------------------------
                                   1894 ;	 function unregister_mods
                                   1895 ;	-----------------------------------------
      00786D                       1896 _unregister_mods:
      00786D E5 82            [12] 1897 	mov	a,dpl
      00786F 90 08 53         [24] 1898 	mov	dptr,#_unregister_mods_mods_10000_754
      007872 F0               [24] 1899 	movx	@dptr,a
                                   1900 ;	quantum/action.c:1137: if (mods) {
      007873 E0               [24] 1901 	movx	a,@dptr
      007874 FF               [12] 1902 	mov	r7,a
      007875 E0               [24] 1903 	movx	a,@dptr
      007876 60 08            [24] 1904 	jz	00103$
                                   1905 ;	quantum/action.c:1138: del_owned_mods(mods);
      007878 8F 82            [24] 1906 	mov	dpl, r7
      00787A 12 7E BD         [24] 1907 	lcall	_del_owned_mods
                                   1908 ;	quantum/action.c:1139: send_keyboard_report();
                                   1909 ;	quantum/action.c:1141: }
      00787D 02 81 E6         [24] 1910 	ljmp	_send_keyboard_report
      007880                       1911 00103$:
      007880 22               [24] 1912 	ret
                                   1913 ;------------------------------------------------------------
                                   1914 ;Allocation info for local variables in function 'register_weak_mods'
                                   1915 ;------------------------------------------------------------
                                   1916 ;mods          Allocated with name '_register_weak_mods_mods_10000_758'
                                   1917 ;------------------------------------------------------------
                                   1918 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1919 ;	-----------------------------------------
                                   1920 ;	 function register_weak_mods
                                   1921 ;	-----------------------------------------
      007881                       1922 _register_weak_mods:
      007881 E5 82            [12] 1923 	mov	a,dpl
      007883 90 08 54         [24] 1924 	mov	dptr,#_register_weak_mods_mods_10000_758
      007886 F0               [24] 1925 	movx	@dptr,a
                                   1926 ;	quantum/action.c:1148: if (mods) {
      007887 E0               [24] 1927 	movx	a,@dptr
      007888 FF               [12] 1928 	mov	r7,a
      007889 E0               [24] 1929 	movx	a,@dptr
      00788A 60 08            [24] 1930 	jz	00103$
                                   1931 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      00788C 8F 82            [24] 1932 	mov	dpl, r7
      00788E 12 7E CB         [24] 1933 	lcall	_add_owned_weak_mods
                                   1934 ;	quantum/action.c:1150: send_keyboard_report();
                                   1935 ;	quantum/action.c:1152: }
      007891 02 81 E6         [24] 1936 	ljmp	_send_keyboard_report
      007894                       1937 00103$:
      007894 22               [24] 1938 	ret
                                   1939 ;------------------------------------------------------------
                                   1940 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1941 ;------------------------------------------------------------
                                   1942 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_762'
                                   1943 ;------------------------------------------------------------
                                   1944 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1945 ;	-----------------------------------------
                                   1946 ;	 function unregister_weak_mods
                                   1947 ;	-----------------------------------------
      007895                       1948 _unregister_weak_mods:
      007895 E5 82            [12] 1949 	mov	a,dpl
      007897 90 08 55         [24] 1950 	mov	dptr,#_unregister_weak_mods_mods_10000_762
      00789A F0               [24] 1951 	movx	@dptr,a
                                   1952 ;	quantum/action.c:1159: if (mods) {
      00789B E0               [24] 1953 	movx	a,@dptr
      00789C FF               [12] 1954 	mov	r7,a
      00789D E0               [24] 1955 	movx	a,@dptr
      00789E 60 08            [24] 1956 	jz	00103$
                                   1957 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      0078A0 8F 82            [24] 1958 	mov	dpl, r7
      0078A2 12 7E DB         [24] 1959 	lcall	_del_owned_weak_mods
                                   1960 ;	quantum/action.c:1161: send_keyboard_report();
                                   1961 ;	quantum/action.c:1163: }
      0078A5 02 81 E6         [24] 1962 	ljmp	_send_keyboard_report
      0078A8                       1963 00103$:
      0078A8 22               [24] 1964 	ret
                                   1965 ;------------------------------------------------------------
                                   1966 ;Allocation info for local variables in function 'clear_keyboard'
                                   1967 ;------------------------------------------------------------
                                   1968 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1969 ;	-----------------------------------------
                                   1970 ;	 function clear_keyboard
                                   1971 ;	-----------------------------------------
      0078A9                       1972 _clear_keyboard:
                                   1973 ;	quantum/action.c:1170: clear_mods();
      0078A9 12 82 61         [24] 1974 	lcall	_clear_mods
                                   1975 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1976 ;	quantum/action.c:1172: }
      0078AC 02 78 AF         [24] 1977 	ljmp	_clear_keyboard_but_mods
                                   1978 ;------------------------------------------------------------
                                   1979 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1980 ;------------------------------------------------------------
                                   1981 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1982 ;	-----------------------------------------
                                   1983 ;	 function clear_keyboard_but_mods
                                   1984 ;	-----------------------------------------
      0078AF                       1985 _clear_keyboard_but_mods:
                                   1986 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0078AF 90 0D B3         [24] 1987 	mov	dptr,#_actual_keyboard_report
      0078B2 12 71 42         [24] 1988 	lcall	_clear_keys_from_report
                                   1989 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1990 ;	quantum/action.c:1181: }
      0078B5 02 78 B8         [24] 1991 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1992 ;------------------------------------------------------------
                                   1993 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1994 ;------------------------------------------------------------
                                   1995 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1996 ;	-----------------------------------------
                                   1997 ;	 function clear_keyboard_but_mods_and_keys
                                   1998 ;	-----------------------------------------
      0078B8                       1999 _clear_keyboard_but_mods_and_keys:
                                   2000 ;	quantum/action.c:1189: ak820_tapping_cancel();
      0078B8 12 46 90         [24] 2001 	lcall	_ak820_tapping_cancel
                                   2002 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      0078BB 12 2E F0         [24] 2003 	lcall	_ak820_oneshot_cancel
                                   2004 ;	quantum/action.c:1209: ak820_combo_cancel();
      0078BE 12 35 27         [24] 2005 	lcall	_ak820_combo_cancel
                                   2006 ;	quantum/action.c:1212: repeat_key_cancel();
      0078C1 12 A2 30         [24] 2007 	lcall	_repeat_key_cancel
                                   2008 ;	quantum/action.c:1214: clear_owned_mods();
      0078C4 12 7E EB         [24] 2009 	lcall	_clear_owned_mods
                                   2010 ;	quantum/action.c:1215: clear_owned_keys();
      0078C7 12 7F 23         [24] 2011 	lcall	_clear_owned_keys
                                   2012 ;	quantum/action.c:1216: clear_owned_usages();
      0078CA 12 80 59         [24] 2013 	lcall	_clear_owned_usages
                                   2014 ;	quantum/action.c:1217: layer_hold_clear();
      0078CD 12 7A 98         [24] 2015 	lcall	_layer_hold_clear
                                   2016 ;	quantum/action.c:1219: clear_macro_tri_layer();
      0078D0 12 9D D0         [24] 2017 	lcall	_clear_macro_tri_layer
                                   2018 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0078D3 90 0D B3         [24] 2019 	mov	dptr,#_actual_keyboard_report
      0078D6 12 71 42         [24] 2020 	lcall	_clear_keys_from_report
                                   2021 ;	quantum/action.c:1224: host_system_send(0);
      0078D9 90 00 00         [24] 2022 	mov	dptr,#0x0000
      0078DC 12 6F 1D         [24] 2023 	lcall	_host_system_send
                                   2024 ;	quantum/action.c:1225: host_consumer_send(0);
      0078DF 90 00 00         [24] 2025 	mov	dptr,#0x0000
      0078E2 12 6F 4D         [24] 2026 	lcall	_host_consumer_send
                                   2027 ;	quantum/action.c:1227: clear_weak_mods();
      0078E5 12 82 96         [24] 2028 	lcall	_clear_weak_mods
                                   2029 ;	quantum/action.c:1228: send_keyboard_report();
      0078E8 12 81 E6         [24] 2030 	lcall	_send_keyboard_report
                                   2031 ;	quantum/action.c:1230: mousekey_clear();
      0078EB 12 51 66         [24] 2032 	lcall	_mousekey_clear
                                   2033 ;	quantum/action.c:1231: mousekey_send();
                                   2034 ;	quantum/action.c:1236: }
      0078EE 02 50 2E         [24] 2035 	ljmp	_mousekey_send
                                   2036 ;------------------------------------------------------------
                                   2037 ;Allocation info for local variables in function 'is_tap_record'
                                   2038 ;------------------------------------------------------------
                                   2039 ;record        Allocated with name '_is_tap_record_record_10000_778'
                                   2040 ;action        Allocated with name '_is_tap_record_action_10001_782'
                                   2041 ;------------------------------------------------------------
                                   2042 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   2043 ;	-----------------------------------------
                                   2044 	.area CSEG    (CODE)
                                   2045 	.area CONST   (CODE)
                                   2046 	.area XINIT   (CODE)
      00C1F2                       2047 __xinit__disable_action_cache:
      00C1F2 00                    2048 	.db #0x00	;  0
                                   2049 	.area CABS    (ABS,CODE)
                                   2050 
                                   2051 ; Experimental exact instruction outlining.
                                   2052 	.globl _ak820_outline_0004
                                   2053 	.globl _ak820_outline_0008
                                   2054 	.globl _ak820_outline_0009
                                   2055 	.globl _ak820_outline_0010
                                   2056 	.globl _ak820_outline_0011
                                   2057 	.globl _ak820_outline_0015
                                   2058 	.globl _ak820_outline_0016
                                   2059 	.globl _ak820_outline_0019
                                   2060 	.globl _ak820_outline_0030
                                   2061 	.globl _ak820_outline_0038
                                   2062 	.globl _ak820_outline_0049
                                   2063 	.globl _ak820_outline_0050
                                   2064 	.globl _ak820_outline_0054
                                   2065 	.globl _ak820_outline_0057
                                   2066 	.globl _ak820_outline_0062
                                   2067 	.globl _ak820_outline_0070
                                   2068 	.globl _ak820_outline_0075
                                   2069 	.globl _ak820_outline_0085
                                   2070 	.globl _ak820_outline_0092
                                   2071 	.globl _ak820_outline_0103
                                   2072 	.globl _ak820_outline_0104
                                   2073 	.globl _ak820_outline_0106
                                   2074 	.globl _ak820_outline_0107
                                   2075 	.globl _ak820_outline_0109
                                   2076 	.globl _ak820_outline_0116
                                   2077 	.globl _ak820_outline_0117
                                   2078 	.globl _ak820_outline_0121
                                   2079 	.globl _ak820_outline_0122
                                   2080 	.globl _ak820_outline_0128
                                   2081 	.globl _ak820_outline_0137
                                   2082 	.globl _ak820_outline_0138
                                   2083 	.globl _ak820_outline_0140
                                   2084 	.globl _ak820_outline_0141
                                   2085 	.globl _ak820_outline_0146
                                   2086 	.globl _ak820_outline_0147
                                   2087 	.globl _ak820_outline_0165
                                   2088 	.globl _ak820_outline_0183
                                   2089 
                                   2090 	.area CSEG (CODE)
                                   2091 ; function ak820_outline_0019
      0078F1                       2092 _ak820_outline_0019:
      0078F1 8E 82            [24] 2093 	mov	dpl,r6
      0078F3 8F 83            [24] 2094 	mov	dph,r7
      0078F5 A3               [24] 2095 	inc	dptr
      0078F6 E0               [24] 2096 	movx	a,@dptr
      0078F7 FC               [12] 2097 	mov	r4,a
      0078F8 7D 00            [12] 2098 	mov	r5,#0x00
      0078FA 8E 82            [24] 2099 	mov	dpl,r6
      0078FC 8F 83            [24] 2100 	mov	dph,r7
      0078FE E0               [24] 2101 	movx	a,@dptr
      0078FF 22               [24] 2102 	ret
                                   2103 
                                   2104 	.area CSEG (CODE)
                                   2105 ; function ak820_outline_0038
      007900                       2106 _ak820_outline_0038:
      007900 90 08 48         [24] 2107 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007903 E0               [24] 2108 	movx	a,@dptr
      007904 54 1F            [12] 2109 	anl	a,#0x1f
      007906 F5 82            [12] 2110 	mov	dpl,a
      007908 22               [24] 2111 	ret
                                   2112 
                                   2113 	.area CSEG (CODE)
                                   2114 ; function ak820_outline_0049
      007909                       2115 _ak820_outline_0049:
      007909 A3               [24] 2116 	inc	dptr
      00790A F0               [24] 2117 	movx	@dptr,a
      00790B E4               [12] 2118 	clr	a
      00790C A3               [24] 2119 	inc	dptr
      00790D F0               [24] 2120 	movx	@dptr,a
      00790E 90 0D 91         [24] 2121 	mov	dptr,#___memcpy_PARM_3
      007911 22               [24] 2122 	ret
                                   2123 
                                   2124 	.area CSEG (CODE)
                                   2125 ; function ak820_outline_0062
      007912                       2126 _ak820_outline_0062:
      007912 F5 F0            [12] 2127 	mov	b,a
      007914 05 F0            [12] 2128 	inc	b
      007916 74 01            [12] 2129 	mov	a,#0x01
      007918 22               [24] 2130 	ret
                                   2131 
                                   2132 	.area CSEG (CODE)
                                   2133 ; function ak820_outline_0075
      007919                       2134 _ak820_outline_0075:
      007919 90 08 47         [24] 2135 	mov	dptr,#_process_action_PARM_2
      00791C E0               [24] 2136 	movx	a,@dptr
      00791D F5 82            [12] 2137 	mov	dpl,a
      00791F 22               [24] 2138 	ret
                                   2139 
                                   2140 	.area CSEG (CODE)
                                   2141 ; function ak820_outline_0085
      007920                       2142 _ak820_outline_0085:
      007920 90 08 48         [24] 2143 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007923 E0               [24] 2144 	movx	a,@dptr
      007924 03               [12] 2145 	rr	a
      007925 03               [12] 2146 	rr	a
      007926 54 03            [12] 2147 	anl	a,#0x03
      007928 22               [24] 2148 	ret
                                   2149 
                                   2150 	.area CSEG (CODE)
                                   2151 ; function ak820_outline_0107
      007929                       2152 _ak820_outline_0107:
      007929 74 06            [12] 2153 	mov	a,#0x06
      00792B F0               [24] 2154 	movx	@dptr,a
      00792C E4               [12] 2155 	clr	a
      00792D A3               [24] 2156 	inc	dptr
      00792E F0               [24] 2157 	movx	@dptr,a
      00792F 22               [24] 2158 	ret
                                   2159 
                                   2160 	.area CSEG (CODE)
                                   2161 ; function ak820_outline_0109
      007930                       2162 _ak820_outline_0109:
      007930 90 08 48         [24] 2163 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007933 E0               [24] 2164 	movx	a,@dptr
      007934 54 0F            [12] 2165 	anl	a,#0x0f
      007936 22               [24] 2166 	ret
                                   2167 
                                   2168 	.area CSEG (CODE)
                                   2169 ; function ak820_outline_0128
      007937                       2170 _ak820_outline_0128:
      007937 90 08 47         [24] 2171 	mov	dptr,#_process_action_PARM_2
      00793A E0               [24] 2172 	movx	a,@dptr
      00793B FE               [12] 2173 	mov	r6,a
      00793C A3               [24] 2174 	inc	dptr
      00793D E0               [24] 2175 	movx	a,@dptr
      00793E 54 03            [12] 2176 	anl	a,#0x03
      007940 FF               [12] 2177 	mov	r7,a
      007941 22               [24] 2178 	ret
                                   2179 
                                   2180 	.area CSEG (CODE)
                                   2181 ; function ak820_outline_0137
      007942                       2182 _ak820_outline_0137:
      007942 90 08 4C         [24] 2183 	mov	dptr,#_register_code_code_10000_714
      007945 E0               [24] 2184 	movx	a,@dptr
      007946 FF               [12] 2185 	mov	r7,a
      007947 22               [24] 2186 	ret
                                   2187 
                                   2188 	.area CSEG (CODE)
                                   2189 ; function ak820_outline_0138
      007948                       2190 _ak820_outline_0138:
      007948 90 08 4D         [24] 2191 	mov	dptr,#_unregister_code_code_10000_728
      00794B E0               [24] 2192 	movx	a,@dptr
      00794C FF               [12] 2193 	mov	r7,a
      00794D 22               [24] 2194 	ret
                                   2195 
                                   2196 	.area CSEG (CODE)
                                   2197 ; function ak820_outline_0146
      00794E                       2198 _ak820_outline_0146:
      00794E 90 08 47         [24] 2199 	mov	dptr,#_process_action_PARM_2
      007951 E0               [24] 2200 	movx	a,@dptr
      007952 22               [24] 2201 	ret
                                   2202 
                                   2203 	.area CSEG (CODE)
                                   2204 ; function ak820_outline_0183
      007953                       2205 _ak820_outline_0183:
      007953 E4               [12] 2206 	clr	a
      007954 F0               [24] 2207 	movx	@dptr,a
      007955 8F 82            [24] 2208 	mov	dpl,r7
      007957 22               [24] 2209 	ret
